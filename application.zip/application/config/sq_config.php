<?php 
        $sq_base_url='http://savsoftquiz.dev:8081/';
        $sq_hostname='localhost';
        $sq_dbname='quizto';
        $sq_dbusername='root';
        $sq_dbpassword='';
        ?>
