<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-21 13:35:47 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
ERROR - 2016-07-21 13:35:48 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:36:25 --> Config Class Initialized
INFO - 2016-07-21 13:36:25 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:36:25 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:36:25 --> Utf8 Class Initialized
INFO - 2016-07-21 13:36:25 --> URI Class Initialized
INFO - 2016-07-21 13:36:25 --> Router Class Initialized
INFO - 2016-07-21 13:36:25 --> Output Class Initialized
INFO - 2016-07-21 13:36:25 --> Security Class Initialized
DEBUG - 2016-07-21 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:36:25 --> Input Class Initialized
INFO - 2016-07-21 13:36:25 --> Language Class Initialized
INFO - 2016-07-21 13:36:25 --> Loader Class Initialized
INFO - 2016-07-21 13:36:25 --> Helper loaded: url_helper
INFO - 2016-07-21 13:36:25 --> Helper loaded: language_helper
INFO - 2016-07-21 13:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:36:25 --> Controller Class Initialized
DEBUG - 2016-07-21 13:36:25 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:36:25 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:36:25 --> Config Class Initialized
INFO - 2016-07-21 13:36:25 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:36:25 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:36:25 --> Utf8 Class Initialized
INFO - 2016-07-21 13:36:25 --> URI Class Initialized
INFO - 2016-07-21 13:36:25 --> Router Class Initialized
INFO - 2016-07-21 13:36:25 --> Output Class Initialized
INFO - 2016-07-21 13:36:25 --> Security Class Initialized
DEBUG - 2016-07-21 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:36:25 --> Input Class Initialized
INFO - 2016-07-21 13:36:25 --> Language Class Initialized
INFO - 2016-07-21 13:36:25 --> Loader Class Initialized
INFO - 2016-07-21 13:36:25 --> Helper loaded: url_helper
INFO - 2016-07-21 13:36:25 --> Helper loaded: language_helper
INFO - 2016-07-21 13:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:36:25 --> Controller Class Initialized
DEBUG - 2016-07-21 13:36:25 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:36:25 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:36:25 --> Config Class Initialized
INFO - 2016-07-21 13:36:25 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:36:25 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:36:25 --> Utf8 Class Initialized
INFO - 2016-07-21 13:36:25 --> URI Class Initialized
INFO - 2016-07-21 13:36:25 --> Router Class Initialized
INFO - 2016-07-21 13:36:25 --> Output Class Initialized
INFO - 2016-07-21 13:36:25 --> Security Class Initialized
DEBUG - 2016-07-21 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:36:25 --> Input Class Initialized
INFO - 2016-07-21 13:36:25 --> Language Class Initialized
INFO - 2016-07-21 13:36:25 --> Loader Class Initialized
INFO - 2016-07-21 13:36:25 --> Helper loaded: url_helper
INFO - 2016-07-21 13:36:25 --> Helper loaded: language_helper
INFO - 2016-07-21 13:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:36:25 --> Controller Class Initialized
DEBUG - 2016-07-21 13:36:25 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:36:25 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:36:26 --> Config Class Initialized
INFO - 2016-07-21 13:36:26 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:36:26 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:36:26 --> Utf8 Class Initialized
INFO - 2016-07-21 13:36:26 --> URI Class Initialized
INFO - 2016-07-21 13:36:26 --> Router Class Initialized
INFO - 2016-07-21 13:36:26 --> Output Class Initialized
INFO - 2016-07-21 13:36:26 --> Security Class Initialized
DEBUG - 2016-07-21 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:36:26 --> Input Class Initialized
INFO - 2016-07-21 13:36:26 --> Language Class Initialized
INFO - 2016-07-21 13:36:26 --> Loader Class Initialized
INFO - 2016-07-21 13:36:26 --> Helper loaded: url_helper
INFO - 2016-07-21 13:36:26 --> Helper loaded: language_helper
INFO - 2016-07-21 13:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:36:26 --> Controller Class Initialized
DEBUG - 2016-07-21 13:36:26 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:36:26 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:36:26 --> Config Class Initialized
INFO - 2016-07-21 13:36:26 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:36:26 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:36:26 --> Utf8 Class Initialized
INFO - 2016-07-21 13:36:26 --> URI Class Initialized
INFO - 2016-07-21 13:36:26 --> Router Class Initialized
INFO - 2016-07-21 13:36:26 --> Output Class Initialized
INFO - 2016-07-21 13:36:26 --> Security Class Initialized
DEBUG - 2016-07-21 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:36:26 --> Input Class Initialized
INFO - 2016-07-21 13:36:26 --> Language Class Initialized
INFO - 2016-07-21 13:36:26 --> Loader Class Initialized
INFO - 2016-07-21 13:36:26 --> Helper loaded: url_helper
INFO - 2016-07-21 13:36:26 --> Helper loaded: language_helper
INFO - 2016-07-21 13:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:36:26 --> Controller Class Initialized
DEBUG - 2016-07-21 13:36:26 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:36:26 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:36:44 --> Config Class Initialized
INFO - 2016-07-21 13:36:44 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:36:44 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:36:44 --> Utf8 Class Initialized
INFO - 2016-07-21 13:36:44 --> URI Class Initialized
INFO - 2016-07-21 13:36:44 --> Router Class Initialized
INFO - 2016-07-21 13:36:44 --> Output Class Initialized
INFO - 2016-07-21 13:36:44 --> Security Class Initialized
DEBUG - 2016-07-21 13:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:36:44 --> Input Class Initialized
INFO - 2016-07-21 13:36:44 --> Language Class Initialized
INFO - 2016-07-21 13:36:44 --> Loader Class Initialized
INFO - 2016-07-21 13:36:44 --> Helper loaded: url_helper
INFO - 2016-07-21 13:36:44 --> Helper loaded: language_helper
INFO - 2016-07-21 13:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:36:44 --> Controller Class Initialized
DEBUG - 2016-07-21 13:36:44 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:36:44 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:41:03 --> Config Class Initialized
INFO - 2016-07-21 13:41:03 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:41:03 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:41:03 --> Utf8 Class Initialized
INFO - 2016-07-21 13:41:03 --> URI Class Initialized
INFO - 2016-07-21 13:41:03 --> Router Class Initialized
INFO - 2016-07-21 13:41:03 --> Output Class Initialized
INFO - 2016-07-21 13:41:03 --> Security Class Initialized
DEBUG - 2016-07-21 13:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:41:03 --> Input Class Initialized
INFO - 2016-07-21 13:41:03 --> Language Class Initialized
INFO - 2016-07-21 13:41:03 --> Loader Class Initialized
INFO - 2016-07-21 13:41:03 --> Helper loaded: url_helper
INFO - 2016-07-21 13:41:03 --> Helper loaded: language_helper
INFO - 2016-07-21 13:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:41:03 --> Controller Class Initialized
DEBUG - 2016-07-21 13:41:03 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:41:03 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:43:23 --> Config Class Initialized
INFO - 2016-07-21 13:43:23 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:43:23 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:43:23 --> Utf8 Class Initialized
INFO - 2016-07-21 13:43:23 --> URI Class Initialized
INFO - 2016-07-21 13:43:23 --> Router Class Initialized
INFO - 2016-07-21 13:43:23 --> Output Class Initialized
INFO - 2016-07-21 13:43:23 --> Security Class Initialized
DEBUG - 2016-07-21 13:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:43:23 --> Input Class Initialized
INFO - 2016-07-21 13:43:23 --> Language Class Initialized
ERROR - 2016-07-21 13:43:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 60
INFO - 2016-07-21 13:43:24 --> Config Class Initialized
INFO - 2016-07-21 13:43:24 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:43:24 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:43:24 --> Utf8 Class Initialized
INFO - 2016-07-21 13:43:24 --> URI Class Initialized
INFO - 2016-07-21 13:43:24 --> Router Class Initialized
INFO - 2016-07-21 13:43:24 --> Output Class Initialized
INFO - 2016-07-21 13:43:24 --> Security Class Initialized
DEBUG - 2016-07-21 13:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:43:24 --> Input Class Initialized
INFO - 2016-07-21 13:43:24 --> Language Class Initialized
ERROR - 2016-07-21 13:43:24 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 60
INFO - 2016-07-21 13:46:05 --> Config Class Initialized
INFO - 2016-07-21 13:46:05 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:05 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:05 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:05 --> URI Class Initialized
INFO - 2016-07-21 13:46:05 --> Router Class Initialized
INFO - 2016-07-21 13:46:05 --> Output Class Initialized
INFO - 2016-07-21 13:46:05 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:05 --> Input Class Initialized
INFO - 2016-07-21 13:46:05 --> Language Class Initialized
ERROR - 2016-07-21 13:46:05 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:06 --> Config Class Initialized
INFO - 2016-07-21 13:46:06 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:06 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:06 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:06 --> URI Class Initialized
INFO - 2016-07-21 13:46:06 --> Router Class Initialized
INFO - 2016-07-21 13:46:06 --> Output Class Initialized
INFO - 2016-07-21 13:46:06 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:06 --> Input Class Initialized
INFO - 2016-07-21 13:46:06 --> Language Class Initialized
ERROR - 2016-07-21 13:46:06 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:27 --> Config Class Initialized
INFO - 2016-07-21 13:46:27 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:27 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:27 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:27 --> URI Class Initialized
INFO - 2016-07-21 13:46:27 --> Router Class Initialized
INFO - 2016-07-21 13:46:27 --> Output Class Initialized
INFO - 2016-07-21 13:46:27 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:27 --> Input Class Initialized
INFO - 2016-07-21 13:46:27 --> Language Class Initialized
ERROR - 2016-07-21 13:46:27 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:39 --> Config Class Initialized
INFO - 2016-07-21 13:46:39 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:39 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:39 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:39 --> URI Class Initialized
INFO - 2016-07-21 13:46:39 --> Router Class Initialized
INFO - 2016-07-21 13:46:39 --> Output Class Initialized
INFO - 2016-07-21 13:46:39 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:39 --> Input Class Initialized
INFO - 2016-07-21 13:46:39 --> Language Class Initialized
ERROR - 2016-07-21 13:46:39 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:40 --> Config Class Initialized
INFO - 2016-07-21 13:46:40 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:40 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:40 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:40 --> URI Class Initialized
INFO - 2016-07-21 13:46:40 --> Router Class Initialized
INFO - 2016-07-21 13:46:40 --> Output Class Initialized
INFO - 2016-07-21 13:46:40 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:40 --> Input Class Initialized
INFO - 2016-07-21 13:46:40 --> Language Class Initialized
ERROR - 2016-07-21 13:46:40 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:41 --> Config Class Initialized
INFO - 2016-07-21 13:46:41 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:41 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:41 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:41 --> URI Class Initialized
INFO - 2016-07-21 13:46:41 --> Router Class Initialized
INFO - 2016-07-21 13:46:41 --> Output Class Initialized
INFO - 2016-07-21 13:46:41 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:41 --> Input Class Initialized
INFO - 2016-07-21 13:46:41 --> Language Class Initialized
ERROR - 2016-07-21 13:46:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:41 --> Config Class Initialized
INFO - 2016-07-21 13:46:41 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:41 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:41 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:41 --> URI Class Initialized
INFO - 2016-07-21 13:46:41 --> Router Class Initialized
INFO - 2016-07-21 13:46:41 --> Output Class Initialized
INFO - 2016-07-21 13:46:41 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:41 --> Input Class Initialized
INFO - 2016-07-21 13:46:41 --> Language Class Initialized
ERROR - 2016-07-21 13:46:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:41 --> Config Class Initialized
INFO - 2016-07-21 13:46:41 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:41 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:41 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:41 --> URI Class Initialized
INFO - 2016-07-21 13:46:41 --> Router Class Initialized
INFO - 2016-07-21 13:46:41 --> Output Class Initialized
INFO - 2016-07-21 13:46:41 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:41 --> Input Class Initialized
INFO - 2016-07-21 13:46:41 --> Language Class Initialized
ERROR - 2016-07-21 13:46:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:41 --> Config Class Initialized
INFO - 2016-07-21 13:46:41 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:41 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:41 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:41 --> URI Class Initialized
INFO - 2016-07-21 13:46:41 --> Router Class Initialized
INFO - 2016-07-21 13:46:41 --> Output Class Initialized
INFO - 2016-07-21 13:46:41 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:41 --> Input Class Initialized
INFO - 2016-07-21 13:46:41 --> Language Class Initialized
ERROR - 2016-07-21 13:46:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:41 --> Config Class Initialized
INFO - 2016-07-21 13:46:41 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:41 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:41 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:41 --> URI Class Initialized
INFO - 2016-07-21 13:46:41 --> Router Class Initialized
INFO - 2016-07-21 13:46:41 --> Output Class Initialized
INFO - 2016-07-21 13:46:41 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:41 --> Input Class Initialized
INFO - 2016-07-21 13:46:41 --> Language Class Initialized
ERROR - 2016-07-21 13:46:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:56 --> Config Class Initialized
INFO - 2016-07-21 13:46:56 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:56 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:56 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:56 --> URI Class Initialized
INFO - 2016-07-21 13:46:56 --> Router Class Initialized
INFO - 2016-07-21 13:46:56 --> Output Class Initialized
INFO - 2016-07-21 13:46:56 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:56 --> Input Class Initialized
INFO - 2016-07-21 13:46:56 --> Language Class Initialized
ERROR - 2016-07-21 13:46:56 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:57 --> Config Class Initialized
INFO - 2016-07-21 13:46:57 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:57 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:57 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:57 --> URI Class Initialized
INFO - 2016-07-21 13:46:57 --> Router Class Initialized
INFO - 2016-07-21 13:46:57 --> Output Class Initialized
INFO - 2016-07-21 13:46:57 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:57 --> Input Class Initialized
INFO - 2016-07-21 13:46:57 --> Language Class Initialized
ERROR - 2016-07-21 13:46:57 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:57 --> Config Class Initialized
INFO - 2016-07-21 13:46:57 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:57 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:57 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:57 --> URI Class Initialized
INFO - 2016-07-21 13:46:57 --> Router Class Initialized
INFO - 2016-07-21 13:46:57 --> Output Class Initialized
INFO - 2016-07-21 13:46:57 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:57 --> Input Class Initialized
INFO - 2016-07-21 13:46:57 --> Language Class Initialized
ERROR - 2016-07-21 13:46:57 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:57 --> Config Class Initialized
INFO - 2016-07-21 13:46:57 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:57 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:57 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:57 --> URI Class Initialized
INFO - 2016-07-21 13:46:57 --> Router Class Initialized
INFO - 2016-07-21 13:46:57 --> Output Class Initialized
INFO - 2016-07-21 13:46:57 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:57 --> Input Class Initialized
INFO - 2016-07-21 13:46:57 --> Language Class Initialized
ERROR - 2016-07-21 13:46:57 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:57 --> Config Class Initialized
INFO - 2016-07-21 13:46:57 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:57 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:57 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:57 --> URI Class Initialized
INFO - 2016-07-21 13:46:57 --> Router Class Initialized
INFO - 2016-07-21 13:46:57 --> Output Class Initialized
INFO - 2016-07-21 13:46:57 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:57 --> Input Class Initialized
INFO - 2016-07-21 13:46:57 --> Language Class Initialized
ERROR - 2016-07-21 13:46:57 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:46:58 --> Config Class Initialized
INFO - 2016-07-21 13:46:58 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:46:58 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:46:58 --> Utf8 Class Initialized
INFO - 2016-07-21 13:46:58 --> URI Class Initialized
INFO - 2016-07-21 13:46:58 --> Router Class Initialized
INFO - 2016-07-21 13:46:58 --> Output Class Initialized
INFO - 2016-07-21 13:46:58 --> Security Class Initialized
DEBUG - 2016-07-21 13:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:46:58 --> Input Class Initialized
INFO - 2016-07-21 13:46:58 --> Language Class Initialized
ERROR - 2016-07-21 13:46:58 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:09 --> Config Class Initialized
INFO - 2016-07-21 13:47:09 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:09 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:09 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:09 --> URI Class Initialized
INFO - 2016-07-21 13:47:09 --> Router Class Initialized
INFO - 2016-07-21 13:47:09 --> Output Class Initialized
INFO - 2016-07-21 13:47:09 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:09 --> Input Class Initialized
INFO - 2016-07-21 13:47:09 --> Language Class Initialized
ERROR - 2016-07-21 13:47:09 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:10 --> Config Class Initialized
INFO - 2016-07-21 13:47:10 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:10 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:10 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:10 --> URI Class Initialized
INFO - 2016-07-21 13:47:10 --> Router Class Initialized
INFO - 2016-07-21 13:47:10 --> Output Class Initialized
INFO - 2016-07-21 13:47:10 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:10 --> Input Class Initialized
INFO - 2016-07-21 13:47:10 --> Language Class Initialized
ERROR - 2016-07-21 13:47:10 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:10 --> Config Class Initialized
INFO - 2016-07-21 13:47:10 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:10 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:10 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:10 --> URI Class Initialized
INFO - 2016-07-21 13:47:10 --> Router Class Initialized
INFO - 2016-07-21 13:47:10 --> Output Class Initialized
INFO - 2016-07-21 13:47:10 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:10 --> Input Class Initialized
INFO - 2016-07-21 13:47:10 --> Language Class Initialized
ERROR - 2016-07-21 13:47:10 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:10 --> Config Class Initialized
INFO - 2016-07-21 13:47:10 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:10 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:10 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:10 --> URI Class Initialized
INFO - 2016-07-21 13:47:10 --> Router Class Initialized
INFO - 2016-07-21 13:47:10 --> Output Class Initialized
INFO - 2016-07-21 13:47:10 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:10 --> Input Class Initialized
INFO - 2016-07-21 13:47:10 --> Language Class Initialized
ERROR - 2016-07-21 13:47:10 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:10 --> Config Class Initialized
INFO - 2016-07-21 13:47:10 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:10 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:10 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:10 --> URI Class Initialized
INFO - 2016-07-21 13:47:10 --> Router Class Initialized
INFO - 2016-07-21 13:47:10 --> Output Class Initialized
INFO - 2016-07-21 13:47:10 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:10 --> Input Class Initialized
INFO - 2016-07-21 13:47:10 --> Language Class Initialized
ERROR - 2016-07-21 13:47:10 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:29 --> Config Class Initialized
INFO - 2016-07-21 13:47:29 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:29 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:29 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:29 --> URI Class Initialized
INFO - 2016-07-21 13:47:29 --> Router Class Initialized
INFO - 2016-07-21 13:47:29 --> Output Class Initialized
INFO - 2016-07-21 13:47:29 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:29 --> Input Class Initialized
INFO - 2016-07-21 13:47:29 --> Language Class Initialized
ERROR - 2016-07-21 13:47:29 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 63
INFO - 2016-07-21 13:47:52 --> Config Class Initialized
INFO - 2016-07-21 13:47:52 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:47:52 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:47:52 --> Utf8 Class Initialized
INFO - 2016-07-21 13:47:52 --> URI Class Initialized
INFO - 2016-07-21 13:47:52 --> Router Class Initialized
INFO - 2016-07-21 13:47:52 --> Output Class Initialized
INFO - 2016-07-21 13:47:52 --> Security Class Initialized
DEBUG - 2016-07-21 13:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:47:52 --> Input Class Initialized
INFO - 2016-07-21 13:47:52 --> Language Class Initialized
INFO - 2016-07-21 13:47:52 --> Loader Class Initialized
INFO - 2016-07-21 13:47:52 --> Helper loaded: url_helper
INFO - 2016-07-21 13:47:52 --> Helper loaded: language_helper
INFO - 2016-07-21 13:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:47:52 --> Controller Class Initialized
INFO - 2016-07-21 13:47:52 --> Final output sent to browser
DEBUG - 2016-07-21 13:47:52 --> Total execution time: 0.0361
INFO - 2016-07-21 13:48:15 --> Config Class Initialized
INFO - 2016-07-21 13:48:15 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:48:15 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:48:15 --> Utf8 Class Initialized
INFO - 2016-07-21 13:48:15 --> URI Class Initialized
INFO - 2016-07-21 13:48:15 --> Router Class Initialized
INFO - 2016-07-21 13:48:15 --> Output Class Initialized
INFO - 2016-07-21 13:48:15 --> Security Class Initialized
DEBUG - 2016-07-21 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:48:15 --> Input Class Initialized
INFO - 2016-07-21 13:48:15 --> Language Class Initialized
INFO - 2016-07-21 13:48:15 --> Loader Class Initialized
INFO - 2016-07-21 13:48:15 --> Helper loaded: url_helper
INFO - 2016-07-21 13:48:15 --> Helper loaded: language_helper
INFO - 2016-07-21 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:48:15 --> Controller Class Initialized
INFO - 2016-07-21 13:48:15 --> Final output sent to browser
DEBUG - 2016-07-21 13:48:15 --> Total execution time: 0.0355
INFO - 2016-07-21 13:48:40 --> Config Class Initialized
INFO - 2016-07-21 13:48:40 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:48:40 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:48:40 --> Utf8 Class Initialized
INFO - 2016-07-21 13:48:40 --> URI Class Initialized
INFO - 2016-07-21 13:48:40 --> Router Class Initialized
INFO - 2016-07-21 13:48:40 --> Output Class Initialized
INFO - 2016-07-21 13:48:40 --> Security Class Initialized
DEBUG - 2016-07-21 13:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:48:40 --> Input Class Initialized
INFO - 2016-07-21 13:48:40 --> Language Class Initialized
INFO - 2016-07-21 13:48:40 --> Loader Class Initialized
INFO - 2016-07-21 13:48:40 --> Helper loaded: url_helper
INFO - 2016-07-21 13:48:40 --> Helper loaded: language_helper
INFO - 2016-07-21 13:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:48:40 --> Controller Class Initialized
DEBUG - 2016-07-21 13:48:40 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:48:40 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:49:16 --> Config Class Initialized
INFO - 2016-07-21 13:49:16 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:49:16 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:49:16 --> Utf8 Class Initialized
INFO - 2016-07-21 13:49:16 --> URI Class Initialized
INFO - 2016-07-21 13:49:16 --> Router Class Initialized
INFO - 2016-07-21 13:49:16 --> Output Class Initialized
INFO - 2016-07-21 13:49:16 --> Security Class Initialized
DEBUG - 2016-07-21 13:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:49:16 --> Input Class Initialized
INFO - 2016-07-21 13:49:16 --> Language Class Initialized
INFO - 2016-07-21 13:49:16 --> Loader Class Initialized
INFO - 2016-07-21 13:49:16 --> Helper loaded: url_helper
INFO - 2016-07-21 13:49:16 --> Helper loaded: language_helper
INFO - 2016-07-21 13:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:49:16 --> Controller Class Initialized
DEBUG - 2016-07-21 13:49:16 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:49:16 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:49:25 --> Config Class Initialized
INFO - 2016-07-21 13:49:25 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:49:25 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:49:25 --> Utf8 Class Initialized
INFO - 2016-07-21 13:49:25 --> URI Class Initialized
INFO - 2016-07-21 13:49:25 --> Router Class Initialized
INFO - 2016-07-21 13:49:25 --> Output Class Initialized
INFO - 2016-07-21 13:49:25 --> Security Class Initialized
DEBUG - 2016-07-21 13:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:49:25 --> Input Class Initialized
INFO - 2016-07-21 13:49:25 --> Language Class Initialized
INFO - 2016-07-21 13:49:25 --> Loader Class Initialized
INFO - 2016-07-21 13:49:25 --> Helper loaded: url_helper
INFO - 2016-07-21 13:49:25 --> Helper loaded: language_helper
INFO - 2016-07-21 13:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:49:25 --> Controller Class Initialized
DEBUG - 2016-07-21 13:49:25 --> Excel class already loaded. Second attempt ignored.
INFO - 2016-07-21 13:49:25 --> Final output sent to browser
DEBUG - 2016-07-21 13:49:25 --> Total execution time: 0.0401
INFO - 2016-07-21 13:52:26 --> Config Class Initialized
INFO - 2016-07-21 13:52:26 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:52:26 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:52:26 --> Utf8 Class Initialized
INFO - 2016-07-21 13:52:26 --> URI Class Initialized
INFO - 2016-07-21 13:52:26 --> Router Class Initialized
INFO - 2016-07-21 13:52:26 --> Output Class Initialized
INFO - 2016-07-21 13:52:26 --> Security Class Initialized
DEBUG - 2016-07-21 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:52:26 --> Input Class Initialized
INFO - 2016-07-21 13:52:26 --> Language Class Initialized
INFO - 2016-07-21 13:52:26 --> Loader Class Initialized
INFO - 2016-07-21 13:52:26 --> Helper loaded: url_helper
INFO - 2016-07-21 13:52:26 --> Helper loaded: language_helper
INFO - 2016-07-21 13:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:52:26 --> Controller Class Initialized
DEBUG - 2016-07-21 13:52:26 --> Excel class already loaded. Second attempt ignored.
INFO - 2016-07-21 13:52:26 --> Final output sent to browser
DEBUG - 2016-07-21 13:52:26 --> Total execution time: 0.0351
INFO - 2016-07-21 13:52:46 --> Config Class Initialized
INFO - 2016-07-21 13:52:46 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:52:46 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:52:46 --> Utf8 Class Initialized
INFO - 2016-07-21 13:52:46 --> URI Class Initialized
INFO - 2016-07-21 13:52:46 --> Router Class Initialized
INFO - 2016-07-21 13:52:46 --> Output Class Initialized
INFO - 2016-07-21 13:52:46 --> Security Class Initialized
DEBUG - 2016-07-21 13:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:52:46 --> Input Class Initialized
INFO - 2016-07-21 13:52:46 --> Language Class Initialized
INFO - 2016-07-21 13:52:46 --> Loader Class Initialized
INFO - 2016-07-21 13:52:46 --> Helper loaded: url_helper
INFO - 2016-07-21 13:52:46 --> Helper loaded: language_helper
INFO - 2016-07-21 13:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:52:46 --> Controller Class Initialized
DEBUG - 2016-07-21 13:52:46 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:52:46 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:53:42 --> Config Class Initialized
INFO - 2016-07-21 13:53:42 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:53:42 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:53:42 --> Utf8 Class Initialized
INFO - 2016-07-21 13:53:42 --> URI Class Initialized
INFO - 2016-07-21 13:53:42 --> Router Class Initialized
INFO - 2016-07-21 13:53:42 --> Output Class Initialized
INFO - 2016-07-21 13:53:42 --> Security Class Initialized
DEBUG - 2016-07-21 13:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:53:42 --> Input Class Initialized
INFO - 2016-07-21 13:53:42 --> Language Class Initialized
INFO - 2016-07-21 13:53:42 --> Loader Class Initialized
INFO - 2016-07-21 13:53:42 --> Helper loaded: url_helper
INFO - 2016-07-21 13:53:42 --> Helper loaded: language_helper
INFO - 2016-07-21 13:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:53:42 --> Controller Class Initialized
DEBUG - 2016-07-21 13:53:42 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:53:42 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 13:54:23 --> Config Class Initialized
INFO - 2016-07-21 13:54:23 --> Hooks Class Initialized
DEBUG - 2016-07-21 13:54:23 --> UTF-8 Support Enabled
INFO - 2016-07-21 13:54:23 --> Utf8 Class Initialized
INFO - 2016-07-21 13:54:23 --> URI Class Initialized
INFO - 2016-07-21 13:54:23 --> Router Class Initialized
INFO - 2016-07-21 13:54:23 --> Output Class Initialized
INFO - 2016-07-21 13:54:23 --> Security Class Initialized
DEBUG - 2016-07-21 13:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 13:54:23 --> Input Class Initialized
INFO - 2016-07-21 13:54:23 --> Language Class Initialized
INFO - 2016-07-21 13:54:23 --> Loader Class Initialized
INFO - 2016-07-21 13:54:23 --> Helper loaded: url_helper
INFO - 2016-07-21 13:54:23 --> Helper loaded: language_helper
INFO - 2016-07-21 13:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 13:54:23 --> Controller Class Initialized
DEBUG - 2016-07-21 13:54:23 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 13:54:23 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:16:31 --> Config Class Initialized
INFO - 2016-07-21 14:16:31 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:16:31 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:16:31 --> Utf8 Class Initialized
INFO - 2016-07-21 14:16:31 --> URI Class Initialized
INFO - 2016-07-21 14:16:31 --> Router Class Initialized
INFO - 2016-07-21 14:16:31 --> Output Class Initialized
INFO - 2016-07-21 14:16:31 --> Security Class Initialized
DEBUG - 2016-07-21 14:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:16:31 --> Input Class Initialized
INFO - 2016-07-21 14:16:31 --> Language Class Initialized
INFO - 2016-07-21 14:16:31 --> Loader Class Initialized
INFO - 2016-07-21 14:16:31 --> Helper loaded: url_helper
INFO - 2016-07-21 14:16:31 --> Helper loaded: language_helper
INFO - 2016-07-21 14:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:16:31 --> Controller Class Initialized
DEBUG - 2016-07-21 14:16:31 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:16:31 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:17:45 --> Config Class Initialized
INFO - 2016-07-21 14:17:45 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:17:45 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:17:45 --> Utf8 Class Initialized
INFO - 2016-07-21 14:17:45 --> URI Class Initialized
INFO - 2016-07-21 14:17:45 --> Router Class Initialized
INFO - 2016-07-21 14:17:45 --> Output Class Initialized
INFO - 2016-07-21 14:17:45 --> Security Class Initialized
DEBUG - 2016-07-21 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:17:45 --> Input Class Initialized
INFO - 2016-07-21 14:17:45 --> Language Class Initialized
INFO - 2016-07-21 14:17:45 --> Loader Class Initialized
INFO - 2016-07-21 14:17:45 --> Helper loaded: url_helper
INFO - 2016-07-21 14:17:45 --> Helper loaded: language_helper
INFO - 2016-07-21 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:17:45 --> Controller Class Initialized
DEBUG - 2016-07-21 14:17:45 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:17:45 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:18:14 --> Config Class Initialized
INFO - 2016-07-21 14:18:14 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:18:14 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:18:14 --> Utf8 Class Initialized
INFO - 2016-07-21 14:18:14 --> URI Class Initialized
INFO - 2016-07-21 14:18:14 --> Router Class Initialized
INFO - 2016-07-21 14:18:14 --> Output Class Initialized
INFO - 2016-07-21 14:18:14 --> Security Class Initialized
DEBUG - 2016-07-21 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:18:14 --> Input Class Initialized
INFO - 2016-07-21 14:18:14 --> Language Class Initialized
INFO - 2016-07-21 14:18:14 --> Loader Class Initialized
INFO - 2016-07-21 14:18:14 --> Helper loaded: url_helper
INFO - 2016-07-21 14:18:14 --> Helper loaded: language_helper
INFO - 2016-07-21 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:18:14 --> Controller Class Initialized
DEBUG - 2016-07-21 14:18:14 --> Excel class already loaded. Second attempt ignored.
DEBUG - 2016-07-21 14:18:14 --> Excel class already loaded. Second attempt ignored.
INFO - 2016-07-21 14:18:14 --> Final output sent to browser
DEBUG - 2016-07-21 14:18:14 --> Total execution time: 0.0470
INFO - 2016-07-21 14:21:17 --> Config Class Initialized
INFO - 2016-07-21 14:21:17 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:21:17 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:21:17 --> Utf8 Class Initialized
INFO - 2016-07-21 14:21:17 --> URI Class Initialized
INFO - 2016-07-21 14:21:17 --> Router Class Initialized
INFO - 2016-07-21 14:21:17 --> Output Class Initialized
INFO - 2016-07-21 14:21:17 --> Security Class Initialized
DEBUG - 2016-07-21 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:21:17 --> Input Class Initialized
INFO - 2016-07-21 14:21:17 --> Language Class Initialized
INFO - 2016-07-21 14:21:17 --> Loader Class Initialized
INFO - 2016-07-21 14:21:17 --> Helper loaded: url_helper
INFO - 2016-07-21 14:21:17 --> Helper loaded: language_helper
INFO - 2016-07-21 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:21:17 --> Controller Class Initialized
DEBUG - 2016-07-21 14:21:17 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:21:17 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:28:38 --> Config Class Initialized
INFO - 2016-07-21 14:28:38 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:28:38 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:28:38 --> Utf8 Class Initialized
INFO - 2016-07-21 14:28:38 --> URI Class Initialized
INFO - 2016-07-21 14:28:38 --> Router Class Initialized
INFO - 2016-07-21 14:28:38 --> Output Class Initialized
INFO - 2016-07-21 14:28:38 --> Security Class Initialized
DEBUG - 2016-07-21 14:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:28:38 --> Input Class Initialized
INFO - 2016-07-21 14:28:38 --> Language Class Initialized
INFO - 2016-07-21 14:28:38 --> Loader Class Initialized
INFO - 2016-07-21 14:28:38 --> Helper loaded: url_helper
INFO - 2016-07-21 14:28:38 --> Helper loaded: language_helper
INFO - 2016-07-21 14:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:28:38 --> Controller Class Initialized
ERROR - 2016-07-21 14:28:38 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 14:28:53 --> Config Class Initialized
INFO - 2016-07-21 14:28:53 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:28:53 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:28:53 --> Utf8 Class Initialized
INFO - 2016-07-21 14:28:53 --> URI Class Initialized
INFO - 2016-07-21 14:28:53 --> Router Class Initialized
INFO - 2016-07-21 14:28:53 --> Output Class Initialized
INFO - 2016-07-21 14:28:53 --> Security Class Initialized
DEBUG - 2016-07-21 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:28:53 --> Input Class Initialized
INFO - 2016-07-21 14:28:53 --> Language Class Initialized
INFO - 2016-07-21 14:28:53 --> Loader Class Initialized
INFO - 2016-07-21 14:28:53 --> Helper loaded: url_helper
INFO - 2016-07-21 14:28:53 --> Helper loaded: language_helper
INFO - 2016-07-21 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:28:53 --> Controller Class Initialized
ERROR - 2016-07-21 14:28:53 --> Unable to load the requested class: Excesl
INFO - 2016-07-21 14:28:59 --> Config Class Initialized
INFO - 2016-07-21 14:28:59 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:28:59 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:28:59 --> Utf8 Class Initialized
INFO - 2016-07-21 14:28:59 --> URI Class Initialized
INFO - 2016-07-21 14:28:59 --> Router Class Initialized
INFO - 2016-07-21 14:28:59 --> Output Class Initialized
INFO - 2016-07-21 14:28:59 --> Security Class Initialized
DEBUG - 2016-07-21 14:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:28:59 --> Input Class Initialized
INFO - 2016-07-21 14:28:59 --> Language Class Initialized
INFO - 2016-07-21 14:28:59 --> Loader Class Initialized
INFO - 2016-07-21 14:28:59 --> Helper loaded: url_helper
INFO - 2016-07-21 14:28:59 --> Helper loaded: language_helper
INFO - 2016-07-21 14:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:28:59 --> Controller Class Initialized
DEBUG - 2016-07-21 14:28:59 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:28:59 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:29:39 --> Config Class Initialized
INFO - 2016-07-21 14:29:39 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:29:39 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:29:39 --> Utf8 Class Initialized
INFO - 2016-07-21 14:29:39 --> URI Class Initialized
INFO - 2016-07-21 14:29:39 --> Router Class Initialized
INFO - 2016-07-21 14:29:39 --> Output Class Initialized
INFO - 2016-07-21 14:29:39 --> Security Class Initialized
DEBUG - 2016-07-21 14:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:29:39 --> Input Class Initialized
INFO - 2016-07-21 14:29:39 --> Language Class Initialized
INFO - 2016-07-21 14:29:39 --> Loader Class Initialized
INFO - 2016-07-21 14:29:39 --> Helper loaded: url_helper
INFO - 2016-07-21 14:29:39 --> Helper loaded: language_helper
INFO - 2016-07-21 14:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:29:39 --> Controller Class Initialized
DEBUG - 2016-07-21 14:29:39 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:29:39 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:31:14 --> Config Class Initialized
INFO - 2016-07-21 14:31:14 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:31:14 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:31:14 --> Utf8 Class Initialized
INFO - 2016-07-21 14:31:14 --> URI Class Initialized
INFO - 2016-07-21 14:31:14 --> Router Class Initialized
INFO - 2016-07-21 14:31:14 --> Output Class Initialized
INFO - 2016-07-21 14:31:14 --> Security Class Initialized
DEBUG - 2016-07-21 14:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:31:14 --> Input Class Initialized
INFO - 2016-07-21 14:31:14 --> Language Class Initialized
INFO - 2016-07-21 14:31:14 --> Loader Class Initialized
INFO - 2016-07-21 14:31:14 --> Helper loaded: url_helper
INFO - 2016-07-21 14:31:14 --> Helper loaded: language_helper
INFO - 2016-07-21 14:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:31:14 --> Controller Class Initialized
ERROR - 2016-07-21 14:31:14 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 14:32:02 --> Config Class Initialized
INFO - 2016-07-21 14:32:02 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:32:02 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:32:02 --> Utf8 Class Initialized
INFO - 2016-07-21 14:32:02 --> URI Class Initialized
INFO - 2016-07-21 14:32:02 --> Router Class Initialized
INFO - 2016-07-21 14:32:02 --> Output Class Initialized
INFO - 2016-07-21 14:32:02 --> Security Class Initialized
DEBUG - 2016-07-21 14:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:32:02 --> Input Class Initialized
INFO - 2016-07-21 14:32:02 --> Language Class Initialized
INFO - 2016-07-21 14:32:02 --> Loader Class Initialized
INFO - 2016-07-21 14:32:02 --> Helper loaded: url_helper
INFO - 2016-07-21 14:32:02 --> Helper loaded: language_helper
INFO - 2016-07-21 14:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:32:02 --> Controller Class Initialized
ERROR - 2016-07-21 14:32:02 --> Unable to load the requested class: IOFactory
INFO - 2016-07-21 14:32:31 --> Config Class Initialized
INFO - 2016-07-21 14:32:31 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:32:31 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:32:31 --> Utf8 Class Initialized
INFO - 2016-07-21 14:32:31 --> URI Class Initialized
INFO - 2016-07-21 14:32:31 --> Router Class Initialized
INFO - 2016-07-21 14:32:31 --> Output Class Initialized
INFO - 2016-07-21 14:32:31 --> Security Class Initialized
DEBUG - 2016-07-21 14:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:32:31 --> Input Class Initialized
INFO - 2016-07-21 14:32:31 --> Language Class Initialized
INFO - 2016-07-21 14:32:31 --> Loader Class Initialized
INFO - 2016-07-21 14:32:31 --> Helper loaded: url_helper
INFO - 2016-07-21 14:32:31 --> Helper loaded: language_helper
INFO - 2016-07-21 14:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:32:31 --> Controller Class Initialized
DEBUG - 2016-07-21 14:32:31 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:32:31 --> Severity: error --> Exception: Class 'IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 14:32:40 --> Config Class Initialized
INFO - 2016-07-21 14:32:40 --> Hooks Class Initialized
DEBUG - 2016-07-21 14:32:40 --> UTF-8 Support Enabled
INFO - 2016-07-21 14:32:40 --> Utf8 Class Initialized
INFO - 2016-07-21 14:32:40 --> URI Class Initialized
INFO - 2016-07-21 14:32:40 --> Router Class Initialized
INFO - 2016-07-21 14:32:40 --> Output Class Initialized
INFO - 2016-07-21 14:32:40 --> Security Class Initialized
DEBUG - 2016-07-21 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 14:32:40 --> Input Class Initialized
INFO - 2016-07-21 14:32:40 --> Language Class Initialized
INFO - 2016-07-21 14:32:40 --> Loader Class Initialized
INFO - 2016-07-21 14:32:40 --> Helper loaded: url_helper
INFO - 2016-07-21 14:32:40 --> Helper loaded: language_helper
INFO - 2016-07-21 14:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 14:32:40 --> Controller Class Initialized
DEBUG - 2016-07-21 14:32:40 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 14:32:40 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:09:11 --> Config Class Initialized
INFO - 2016-07-21 15:09:11 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:09:11 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:09:11 --> Utf8 Class Initialized
INFO - 2016-07-21 15:09:11 --> URI Class Initialized
INFO - 2016-07-21 15:09:11 --> Router Class Initialized
INFO - 2016-07-21 15:09:11 --> Output Class Initialized
INFO - 2016-07-21 15:09:11 --> Security Class Initialized
DEBUG - 2016-07-21 15:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:09:11 --> Input Class Initialized
INFO - 2016-07-21 15:09:11 --> Language Class Initialized
INFO - 2016-07-21 15:09:11 --> Loader Class Initialized
INFO - 2016-07-21 15:09:11 --> Helper loaded: url_helper
INFO - 2016-07-21 15:09:11 --> Helper loaded: language_helper
INFO - 2016-07-21 15:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:09:11 --> Controller Class Initialized
DEBUG - 2016-07-21 15:09:11 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:09:11 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:09:12 --> Config Class Initialized
INFO - 2016-07-21 15:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:09:12 --> Utf8 Class Initialized
INFO - 2016-07-21 15:09:12 --> URI Class Initialized
INFO - 2016-07-21 15:09:12 --> Router Class Initialized
INFO - 2016-07-21 15:09:12 --> Output Class Initialized
INFO - 2016-07-21 15:09:12 --> Security Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:09:12 --> Input Class Initialized
INFO - 2016-07-21 15:09:12 --> Language Class Initialized
INFO - 2016-07-21 15:09:12 --> Loader Class Initialized
INFO - 2016-07-21 15:09:12 --> Helper loaded: url_helper
INFO - 2016-07-21 15:09:12 --> Helper loaded: language_helper
INFO - 2016-07-21 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:09:12 --> Controller Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:09:12 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:09:12 --> Config Class Initialized
INFO - 2016-07-21 15:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:09:12 --> Utf8 Class Initialized
INFO - 2016-07-21 15:09:12 --> URI Class Initialized
INFO - 2016-07-21 15:09:12 --> Router Class Initialized
INFO - 2016-07-21 15:09:12 --> Output Class Initialized
INFO - 2016-07-21 15:09:12 --> Security Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:09:12 --> Input Class Initialized
INFO - 2016-07-21 15:09:12 --> Language Class Initialized
INFO - 2016-07-21 15:09:12 --> Loader Class Initialized
INFO - 2016-07-21 15:09:12 --> Helper loaded: url_helper
INFO - 2016-07-21 15:09:12 --> Helper loaded: language_helper
INFO - 2016-07-21 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:09:12 --> Controller Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:09:12 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:09:12 --> Config Class Initialized
INFO - 2016-07-21 15:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:09:12 --> Utf8 Class Initialized
INFO - 2016-07-21 15:09:12 --> URI Class Initialized
INFO - 2016-07-21 15:09:12 --> Router Class Initialized
INFO - 2016-07-21 15:09:12 --> Output Class Initialized
INFO - 2016-07-21 15:09:12 --> Security Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:09:12 --> Input Class Initialized
INFO - 2016-07-21 15:09:12 --> Language Class Initialized
INFO - 2016-07-21 15:09:12 --> Loader Class Initialized
INFO - 2016-07-21 15:09:12 --> Helper loaded: url_helper
INFO - 2016-07-21 15:09:12 --> Helper loaded: language_helper
INFO - 2016-07-21 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:09:12 --> Controller Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:09:12 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:09:12 --> Config Class Initialized
INFO - 2016-07-21 15:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:09:12 --> Utf8 Class Initialized
INFO - 2016-07-21 15:09:12 --> URI Class Initialized
INFO - 2016-07-21 15:09:12 --> Router Class Initialized
INFO - 2016-07-21 15:09:12 --> Output Class Initialized
INFO - 2016-07-21 15:09:12 --> Security Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:09:12 --> Input Class Initialized
INFO - 2016-07-21 15:09:12 --> Language Class Initialized
INFO - 2016-07-21 15:09:12 --> Loader Class Initialized
INFO - 2016-07-21 15:09:12 --> Helper loaded: url_helper
INFO - 2016-07-21 15:09:12 --> Helper loaded: language_helper
INFO - 2016-07-21 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:09:12 --> Controller Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:09:12 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:09:12 --> Config Class Initialized
INFO - 2016-07-21 15:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:09:12 --> Utf8 Class Initialized
INFO - 2016-07-21 15:09:12 --> URI Class Initialized
INFO - 2016-07-21 15:09:12 --> Router Class Initialized
INFO - 2016-07-21 15:09:12 --> Output Class Initialized
INFO - 2016-07-21 15:09:12 --> Security Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:09:12 --> Input Class Initialized
INFO - 2016-07-21 15:09:12 --> Language Class Initialized
INFO - 2016-07-21 15:09:12 --> Loader Class Initialized
INFO - 2016-07-21 15:09:12 --> Helper loaded: url_helper
INFO - 2016-07-21 15:09:12 --> Helper loaded: language_helper
INFO - 2016-07-21 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:09:12 --> Controller Class Initialized
DEBUG - 2016-07-21 15:09:12 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:09:12 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:13:34 --> Config Class Initialized
INFO - 2016-07-21 15:13:34 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:13:34 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:13:34 --> Utf8 Class Initialized
INFO - 2016-07-21 15:13:34 --> URI Class Initialized
INFO - 2016-07-21 15:13:34 --> Router Class Initialized
INFO - 2016-07-21 15:13:34 --> Output Class Initialized
INFO - 2016-07-21 15:13:34 --> Security Class Initialized
DEBUG - 2016-07-21 15:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:13:34 --> Input Class Initialized
INFO - 2016-07-21 15:13:34 --> Language Class Initialized
INFO - 2016-07-21 15:13:34 --> Loader Class Initialized
INFO - 2016-07-21 15:13:34 --> Helper loaded: url_helper
INFO - 2016-07-21 15:13:34 --> Helper loaded: language_helper
INFO - 2016-07-21 15:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:13:34 --> Controller Class Initialized
DEBUG - 2016-07-21 15:13:34 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:13:34 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:13:36 --> Config Class Initialized
INFO - 2016-07-21 15:13:36 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:13:36 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:13:36 --> Utf8 Class Initialized
INFO - 2016-07-21 15:13:36 --> URI Class Initialized
INFO - 2016-07-21 15:13:36 --> Router Class Initialized
INFO - 2016-07-21 15:13:36 --> Output Class Initialized
INFO - 2016-07-21 15:13:36 --> Security Class Initialized
DEBUG - 2016-07-21 15:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:13:36 --> Input Class Initialized
INFO - 2016-07-21 15:13:36 --> Language Class Initialized
INFO - 2016-07-21 15:13:36 --> Loader Class Initialized
INFO - 2016-07-21 15:13:36 --> Helper loaded: url_helper
INFO - 2016-07-21 15:13:36 --> Helper loaded: language_helper
INFO - 2016-07-21 15:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:13:36 --> Controller Class Initialized
DEBUG - 2016-07-21 15:13:36 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:13:36 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:16:58 --> Config Class Initialized
INFO - 2016-07-21 15:16:58 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:16:58 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:16:58 --> Utf8 Class Initialized
INFO - 2016-07-21 15:16:58 --> URI Class Initialized
INFO - 2016-07-21 15:16:58 --> Router Class Initialized
INFO - 2016-07-21 15:16:58 --> Output Class Initialized
INFO - 2016-07-21 15:16:58 --> Security Class Initialized
DEBUG - 2016-07-21 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:16:58 --> Input Class Initialized
INFO - 2016-07-21 15:16:58 --> Language Class Initialized
INFO - 2016-07-21 15:16:58 --> Loader Class Initialized
INFO - 2016-07-21 15:16:58 --> Helper loaded: url_helper
INFO - 2016-07-21 15:16:58 --> Helper loaded: language_helper
INFO - 2016-07-21 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:16:58 --> Controller Class Initialized
DEBUG - 2016-07-21 15:16:58 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:16:58 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:17:00 --> Config Class Initialized
INFO - 2016-07-21 15:17:00 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:17:00 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:17:00 --> Utf8 Class Initialized
INFO - 2016-07-21 15:17:00 --> URI Class Initialized
INFO - 2016-07-21 15:17:00 --> Router Class Initialized
INFO - 2016-07-21 15:17:00 --> Output Class Initialized
INFO - 2016-07-21 15:17:00 --> Security Class Initialized
DEBUG - 2016-07-21 15:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:17:00 --> Input Class Initialized
INFO - 2016-07-21 15:17:00 --> Language Class Initialized
INFO - 2016-07-21 15:17:00 --> Loader Class Initialized
INFO - 2016-07-21 15:17:00 --> Helper loaded: url_helper
INFO - 2016-07-21 15:17:00 --> Helper loaded: language_helper
INFO - 2016-07-21 15:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:17:00 --> Controller Class Initialized
DEBUG - 2016-07-21 15:17:00 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:17:00 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:19:13 --> Config Class Initialized
INFO - 2016-07-21 15:19:13 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:19:13 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:19:13 --> Utf8 Class Initialized
INFO - 2016-07-21 15:19:13 --> URI Class Initialized
INFO - 2016-07-21 15:19:13 --> Router Class Initialized
INFO - 2016-07-21 15:19:13 --> Output Class Initialized
INFO - 2016-07-21 15:19:13 --> Security Class Initialized
DEBUG - 2016-07-21 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:19:13 --> Input Class Initialized
INFO - 2016-07-21 15:19:13 --> Language Class Initialized
INFO - 2016-07-21 15:19:13 --> Loader Class Initialized
INFO - 2016-07-21 15:19:13 --> Helper loaded: url_helper
INFO - 2016-07-21 15:19:13 --> Helper loaded: language_helper
INFO - 2016-07-21 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:19:13 --> Controller Class Initialized
ERROR - 2016-07-21 15:19:13 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:19:28 --> Config Class Initialized
INFO - 2016-07-21 15:19:28 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:19:28 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:19:28 --> Utf8 Class Initialized
INFO - 2016-07-21 15:19:28 --> URI Class Initialized
INFO - 2016-07-21 15:19:28 --> Router Class Initialized
INFO - 2016-07-21 15:19:28 --> Output Class Initialized
INFO - 2016-07-21 15:19:28 --> Security Class Initialized
DEBUG - 2016-07-21 15:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:19:28 --> Input Class Initialized
INFO - 2016-07-21 15:19:28 --> Language Class Initialized
INFO - 2016-07-21 15:19:28 --> Loader Class Initialized
INFO - 2016-07-21 15:19:28 --> Helper loaded: url_helper
INFO - 2016-07-21 15:19:28 --> Helper loaded: language_helper
INFO - 2016-07-21 15:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:19:28 --> Controller Class Initialized
ERROR - 2016-07-21 15:19:28 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:20:14 --> Config Class Initialized
INFO - 2016-07-21 15:20:14 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:20:14 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:20:14 --> Utf8 Class Initialized
INFO - 2016-07-21 15:20:14 --> URI Class Initialized
INFO - 2016-07-21 15:20:14 --> Router Class Initialized
INFO - 2016-07-21 15:20:14 --> Output Class Initialized
INFO - 2016-07-21 15:20:14 --> Security Class Initialized
DEBUG - 2016-07-21 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:20:14 --> Input Class Initialized
INFO - 2016-07-21 15:20:14 --> Language Class Initialized
INFO - 2016-07-21 15:20:14 --> Loader Class Initialized
INFO - 2016-07-21 15:20:14 --> Helper loaded: url_helper
INFO - 2016-07-21 15:20:14 --> Helper loaded: language_helper
INFO - 2016-07-21 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:20:14 --> Controller Class Initialized
ERROR - 2016-07-21 15:20:14 --> Unable to load the requested class: Phpexcel
INFO - 2016-07-21 15:20:26 --> Config Class Initialized
INFO - 2016-07-21 15:20:26 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:20:26 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:20:26 --> Utf8 Class Initialized
INFO - 2016-07-21 15:20:26 --> URI Class Initialized
INFO - 2016-07-21 15:20:26 --> Router Class Initialized
INFO - 2016-07-21 15:20:26 --> Output Class Initialized
INFO - 2016-07-21 15:20:26 --> Security Class Initialized
DEBUG - 2016-07-21 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:20:26 --> Input Class Initialized
INFO - 2016-07-21 15:20:26 --> Language Class Initialized
INFO - 2016-07-21 15:20:26 --> Loader Class Initialized
INFO - 2016-07-21 15:20:26 --> Helper loaded: url_helper
INFO - 2016-07-21 15:20:26 --> Helper loaded: language_helper
INFO - 2016-07-21 15:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:20:26 --> Controller Class Initialized
DEBUG - 2016-07-21 15:20:26 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:20:26 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:20:33 --> Config Class Initialized
INFO - 2016-07-21 15:20:33 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:20:33 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:20:33 --> Utf8 Class Initialized
INFO - 2016-07-21 15:20:33 --> URI Class Initialized
INFO - 2016-07-21 15:20:33 --> Router Class Initialized
INFO - 2016-07-21 15:20:33 --> Output Class Initialized
INFO - 2016-07-21 15:20:33 --> Security Class Initialized
DEBUG - 2016-07-21 15:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:20:33 --> Input Class Initialized
INFO - 2016-07-21 15:20:33 --> Language Class Initialized
INFO - 2016-07-21 15:20:33 --> Loader Class Initialized
INFO - 2016-07-21 15:20:33 --> Helper loaded: url_helper
INFO - 2016-07-21 15:20:33 --> Helper loaded: language_helper
INFO - 2016-07-21 15:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:20:33 --> Controller Class Initialized
DEBUG - 2016-07-21 15:20:33 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:20:33 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:20:34 --> Config Class Initialized
INFO - 2016-07-21 15:20:34 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:20:34 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:20:34 --> Utf8 Class Initialized
INFO - 2016-07-21 15:20:34 --> URI Class Initialized
INFO - 2016-07-21 15:20:34 --> Router Class Initialized
INFO - 2016-07-21 15:20:34 --> Output Class Initialized
INFO - 2016-07-21 15:20:34 --> Security Class Initialized
DEBUG - 2016-07-21 15:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:20:34 --> Input Class Initialized
INFO - 2016-07-21 15:20:34 --> Language Class Initialized
INFO - 2016-07-21 15:20:34 --> Loader Class Initialized
INFO - 2016-07-21 15:20:34 --> Helper loaded: url_helper
INFO - 2016-07-21 15:20:34 --> Helper loaded: language_helper
INFO - 2016-07-21 15:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:20:34 --> Controller Class Initialized
DEBUG - 2016-07-21 15:20:34 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:20:34 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:20:49 --> Config Class Initialized
INFO - 2016-07-21 15:20:49 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:20:49 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:20:49 --> Utf8 Class Initialized
INFO - 2016-07-21 15:20:49 --> URI Class Initialized
INFO - 2016-07-21 15:20:49 --> Router Class Initialized
INFO - 2016-07-21 15:20:49 --> Output Class Initialized
INFO - 2016-07-21 15:20:49 --> Security Class Initialized
DEBUG - 2016-07-21 15:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:20:49 --> Input Class Initialized
INFO - 2016-07-21 15:20:49 --> Language Class Initialized
INFO - 2016-07-21 15:20:49 --> Loader Class Initialized
INFO - 2016-07-21 15:20:49 --> Helper loaded: url_helper
INFO - 2016-07-21 15:20:49 --> Helper loaded: language_helper
INFO - 2016-07-21 15:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:20:49 --> Controller Class Initialized
DEBUG - 2016-07-21 15:20:49 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:20:49 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:21:38 --> Config Class Initialized
INFO - 2016-07-21 15:21:38 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:21:38 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:21:38 --> Utf8 Class Initialized
INFO - 2016-07-21 15:21:38 --> URI Class Initialized
INFO - 2016-07-21 15:21:38 --> Router Class Initialized
INFO - 2016-07-21 15:21:38 --> Output Class Initialized
INFO - 2016-07-21 15:21:38 --> Security Class Initialized
DEBUG - 2016-07-21 15:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:21:38 --> Input Class Initialized
INFO - 2016-07-21 15:21:38 --> Language Class Initialized
INFO - 2016-07-21 15:21:38 --> Loader Class Initialized
INFO - 2016-07-21 15:21:38 --> Helper loaded: url_helper
INFO - 2016-07-21 15:21:38 --> Helper loaded: language_helper
INFO - 2016-07-21 15:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:21:38 --> Controller Class Initialized
DEBUG - 2016-07-21 15:21:38 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:21:38 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:21:39 --> Config Class Initialized
INFO - 2016-07-21 15:21:39 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:21:39 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:21:39 --> Utf8 Class Initialized
INFO - 2016-07-21 15:21:39 --> URI Class Initialized
INFO - 2016-07-21 15:21:39 --> Router Class Initialized
INFO - 2016-07-21 15:21:39 --> Output Class Initialized
INFO - 2016-07-21 15:21:39 --> Security Class Initialized
DEBUG - 2016-07-21 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:21:39 --> Input Class Initialized
INFO - 2016-07-21 15:21:39 --> Language Class Initialized
INFO - 2016-07-21 15:21:39 --> Loader Class Initialized
INFO - 2016-07-21 15:21:39 --> Helper loaded: url_helper
INFO - 2016-07-21 15:21:39 --> Helper loaded: language_helper
INFO - 2016-07-21 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:21:39 --> Controller Class Initialized
DEBUG - 2016-07-21 15:21:39 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:21:39 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:21:39 --> Config Class Initialized
INFO - 2016-07-21 15:21:39 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:21:39 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:21:39 --> Utf8 Class Initialized
INFO - 2016-07-21 15:21:39 --> URI Class Initialized
INFO - 2016-07-21 15:21:39 --> Router Class Initialized
INFO - 2016-07-21 15:21:39 --> Output Class Initialized
INFO - 2016-07-21 15:21:39 --> Security Class Initialized
DEBUG - 2016-07-21 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:21:39 --> Input Class Initialized
INFO - 2016-07-21 15:21:39 --> Language Class Initialized
INFO - 2016-07-21 15:21:39 --> Loader Class Initialized
INFO - 2016-07-21 15:21:39 --> Helper loaded: url_helper
INFO - 2016-07-21 15:21:39 --> Helper loaded: language_helper
INFO - 2016-07-21 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:21:39 --> Controller Class Initialized
DEBUG - 2016-07-21 15:21:39 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:21:39 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:21:40 --> Config Class Initialized
INFO - 2016-07-21 15:21:40 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:21:40 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:21:40 --> Utf8 Class Initialized
INFO - 2016-07-21 15:21:40 --> URI Class Initialized
INFO - 2016-07-21 15:21:40 --> Router Class Initialized
INFO - 2016-07-21 15:21:40 --> Output Class Initialized
INFO - 2016-07-21 15:21:40 --> Security Class Initialized
DEBUG - 2016-07-21 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:21:40 --> Input Class Initialized
INFO - 2016-07-21 15:21:40 --> Language Class Initialized
INFO - 2016-07-21 15:21:40 --> Loader Class Initialized
INFO - 2016-07-21 15:21:40 --> Helper loaded: url_helper
INFO - 2016-07-21 15:21:40 --> Helper loaded: language_helper
INFO - 2016-07-21 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:21:40 --> Controller Class Initialized
DEBUG - 2016-07-21 15:21:40 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:21:40 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:21:50 --> Config Class Initialized
INFO - 2016-07-21 15:21:50 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:21:50 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:21:50 --> Utf8 Class Initialized
INFO - 2016-07-21 15:21:50 --> URI Class Initialized
INFO - 2016-07-21 15:21:50 --> Router Class Initialized
INFO - 2016-07-21 15:21:50 --> Output Class Initialized
INFO - 2016-07-21 15:21:50 --> Security Class Initialized
DEBUG - 2016-07-21 15:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:21:50 --> Input Class Initialized
INFO - 2016-07-21 15:21:50 --> Language Class Initialized
INFO - 2016-07-21 15:21:50 --> Loader Class Initialized
INFO - 2016-07-21 15:21:50 --> Helper loaded: url_helper
INFO - 2016-07-21 15:21:50 --> Helper loaded: language_helper
INFO - 2016-07-21 15:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:21:50 --> Controller Class Initialized
ERROR - 2016-07-21 15:21:50 --> Severity: Compile Error --> Cannot declare class PHPExcel, because the name is already in use C:\wamp64\www\savsoftquiz\application\libraries\PHPExcel.php 6
INFO - 2016-07-21 15:22:34 --> Config Class Initialized
INFO - 2016-07-21 15:22:34 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:22:34 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:22:34 --> Utf8 Class Initialized
INFO - 2016-07-21 15:22:34 --> URI Class Initialized
INFO - 2016-07-21 15:22:34 --> Router Class Initialized
INFO - 2016-07-21 15:22:34 --> Output Class Initialized
INFO - 2016-07-21 15:22:34 --> Security Class Initialized
DEBUG - 2016-07-21 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:22:34 --> Input Class Initialized
INFO - 2016-07-21 15:22:34 --> Language Class Initialized
INFO - 2016-07-21 15:22:34 --> Loader Class Initialized
INFO - 2016-07-21 15:22:34 --> Helper loaded: url_helper
INFO - 2016-07-21 15:22:34 --> Helper loaded: language_helper
INFO - 2016-07-21 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:22:34 --> Controller Class Initialized
DEBUG - 2016-07-21 15:22:34 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:22:34 --> Unable to load the requested class: Iofactory
INFO - 2016-07-21 15:22:48 --> Config Class Initialized
INFO - 2016-07-21 15:22:48 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:22:48 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:22:48 --> Utf8 Class Initialized
INFO - 2016-07-21 15:22:48 --> URI Class Initialized
INFO - 2016-07-21 15:22:48 --> Router Class Initialized
INFO - 2016-07-21 15:22:48 --> Output Class Initialized
INFO - 2016-07-21 15:22:48 --> Security Class Initialized
DEBUG - 2016-07-21 15:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:22:48 --> Input Class Initialized
INFO - 2016-07-21 15:22:48 --> Language Class Initialized
INFO - 2016-07-21 15:22:48 --> Loader Class Initialized
INFO - 2016-07-21 15:22:48 --> Helper loaded: url_helper
INFO - 2016-07-21 15:22:48 --> Helper loaded: language_helper
INFO - 2016-07-21 15:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:22:48 --> Controller Class Initialized
DEBUG - 2016-07-21 15:22:48 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:22:48 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-21 15:24:39 --> Config Class Initialized
INFO - 2016-07-21 15:24:39 --> Hooks Class Initialized
DEBUG - 2016-07-21 15:24:39 --> UTF-8 Support Enabled
INFO - 2016-07-21 15:24:39 --> Utf8 Class Initialized
INFO - 2016-07-21 15:24:39 --> URI Class Initialized
INFO - 2016-07-21 15:24:39 --> Router Class Initialized
INFO - 2016-07-21 15:24:39 --> Output Class Initialized
INFO - 2016-07-21 15:24:39 --> Security Class Initialized
DEBUG - 2016-07-21 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 15:24:39 --> Input Class Initialized
INFO - 2016-07-21 15:24:39 --> Language Class Initialized
INFO - 2016-07-21 15:24:39 --> Loader Class Initialized
INFO - 2016-07-21 15:24:39 --> Helper loaded: url_helper
INFO - 2016-07-21 15:24:39 --> Helper loaded: language_helper
INFO - 2016-07-21 15:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 15:24:39 --> Controller Class Initialized
DEBUG - 2016-07-21 15:24:39 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-21 15:24:39 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
