<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-22 09:45:14 --> Config Class Initialized
INFO - 2016-07-22 09:45:14 --> Hooks Class Initialized
DEBUG - 2016-07-22 09:45:14 --> UTF-8 Support Enabled
INFO - 2016-07-22 09:45:14 --> Utf8 Class Initialized
INFO - 2016-07-22 09:45:14 --> URI Class Initialized
INFO - 2016-07-22 09:45:14 --> Router Class Initialized
INFO - 2016-07-22 09:45:14 --> Output Class Initialized
INFO - 2016-07-22 09:45:14 --> Security Class Initialized
DEBUG - 2016-07-22 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 09:45:14 --> Input Class Initialized
INFO - 2016-07-22 09:45:14 --> Language Class Initialized
INFO - 2016-07-22 09:45:14 --> Loader Class Initialized
INFO - 2016-07-22 09:45:14 --> Helper loaded: url_helper
INFO - 2016-07-22 09:45:14 --> Helper loaded: language_helper
INFO - 2016-07-22 09:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 09:45:14 --> Controller Class Initialized
DEBUG - 2016-07-22 09:45:14 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 09:45:14 --> Severity: error --> Exception: Class 'PHPExcel_IOFactory' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 42
INFO - 2016-07-22 10:02:57 --> Config Class Initialized
INFO - 2016-07-22 10:02:57 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:02:57 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:02:57 --> Utf8 Class Initialized
INFO - 2016-07-22 10:02:57 --> URI Class Initialized
INFO - 2016-07-22 10:02:57 --> Router Class Initialized
INFO - 2016-07-22 10:02:57 --> Output Class Initialized
INFO - 2016-07-22 10:02:57 --> Security Class Initialized
DEBUG - 2016-07-22 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:02:57 --> Input Class Initialized
INFO - 2016-07-22 10:02:57 --> Language Class Initialized
INFO - 2016-07-22 10:02:57 --> Loader Class Initialized
INFO - 2016-07-22 10:02:57 --> Helper loaded: url_helper
INFO - 2016-07-22 10:02:57 --> Helper loaded: language_helper
INFO - 2016-07-22 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:02:57 --> Controller Class Initialized
DEBUG - 2016-07-22 10:02:57 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:02:57 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:04:55 --> Config Class Initialized
INFO - 2016-07-22 10:04:55 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:04:55 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:04:55 --> Utf8 Class Initialized
INFO - 2016-07-22 10:04:55 --> URI Class Initialized
INFO - 2016-07-22 10:04:55 --> Router Class Initialized
INFO - 2016-07-22 10:04:55 --> Output Class Initialized
INFO - 2016-07-22 10:04:55 --> Security Class Initialized
DEBUG - 2016-07-22 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:04:55 --> Input Class Initialized
INFO - 2016-07-22 10:04:55 --> Language Class Initialized
INFO - 2016-07-22 10:04:55 --> Loader Class Initialized
INFO - 2016-07-22 10:04:55 --> Helper loaded: url_helper
INFO - 2016-07-22 10:04:55 --> Helper loaded: language_helper
INFO - 2016-07-22 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:04:55 --> Controller Class Initialized
ERROR - 2016-07-22 10:04:55 --> Unable to load the requested class: Phpexcel
INFO - 2016-07-22 10:07:05 --> Config Class Initialized
INFO - 2016-07-22 10:07:05 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:07:05 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:07:05 --> Utf8 Class Initialized
INFO - 2016-07-22 10:07:05 --> URI Class Initialized
INFO - 2016-07-22 10:07:05 --> Router Class Initialized
INFO - 2016-07-22 10:07:05 --> Output Class Initialized
INFO - 2016-07-22 10:07:05 --> Security Class Initialized
DEBUG - 2016-07-22 10:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:07:05 --> Input Class Initialized
INFO - 2016-07-22 10:07:05 --> Language Class Initialized
INFO - 2016-07-22 10:07:05 --> Loader Class Initialized
INFO - 2016-07-22 10:07:05 --> Helper loaded: url_helper
INFO - 2016-07-22 10:07:05 --> Helper loaded: language_helper
INFO - 2016-07-22 10:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:07:05 --> Controller Class Initialized
DEBUG - 2016-07-22 10:07:05 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:07:05 --> Unable to load the requested class: Iofactory
INFO - 2016-07-22 10:07:20 --> Config Class Initialized
INFO - 2016-07-22 10:07:20 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:07:20 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:07:20 --> Utf8 Class Initialized
INFO - 2016-07-22 10:07:20 --> URI Class Initialized
INFO - 2016-07-22 10:07:20 --> Router Class Initialized
INFO - 2016-07-22 10:07:20 --> Output Class Initialized
INFO - 2016-07-22 10:07:20 --> Security Class Initialized
DEBUG - 2016-07-22 10:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:07:20 --> Input Class Initialized
INFO - 2016-07-22 10:07:20 --> Language Class Initialized
INFO - 2016-07-22 10:07:20 --> Loader Class Initialized
INFO - 2016-07-22 10:07:20 --> Helper loaded: url_helper
INFO - 2016-07-22 10:07:20 --> Helper loaded: language_helper
INFO - 2016-07-22 10:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:07:20 --> Controller Class Initialized
DEBUG - 2016-07-22 10:07:20 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:07:20 --> Unable to load the requested class: Iofactory
INFO - 2016-07-22 10:11:50 --> Config Class Initialized
INFO - 2016-07-22 10:11:50 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:11:50 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:11:50 --> Utf8 Class Initialized
INFO - 2016-07-22 10:11:50 --> URI Class Initialized
INFO - 2016-07-22 10:11:50 --> Router Class Initialized
INFO - 2016-07-22 10:11:50 --> Output Class Initialized
INFO - 2016-07-22 10:11:50 --> Security Class Initialized
DEBUG - 2016-07-22 10:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:11:50 --> Input Class Initialized
INFO - 2016-07-22 10:11:50 --> Language Class Initialized
INFO - 2016-07-22 10:11:50 --> Loader Class Initialized
INFO - 2016-07-22 10:11:50 --> Helper loaded: url_helper
INFO - 2016-07-22 10:11:50 --> Helper loaded: language_helper
INFO - 2016-07-22 10:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:11:50 --> Controller Class Initialized
DEBUG - 2016-07-22 10:11:50 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:11:50 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:11:51 --> Config Class Initialized
INFO - 2016-07-22 10:11:51 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:11:51 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:11:51 --> Utf8 Class Initialized
INFO - 2016-07-22 10:11:51 --> URI Class Initialized
INFO - 2016-07-22 10:11:51 --> Router Class Initialized
INFO - 2016-07-22 10:11:51 --> Output Class Initialized
INFO - 2016-07-22 10:11:51 --> Security Class Initialized
DEBUG - 2016-07-22 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:11:51 --> Input Class Initialized
INFO - 2016-07-22 10:11:51 --> Language Class Initialized
INFO - 2016-07-22 10:11:51 --> Loader Class Initialized
INFO - 2016-07-22 10:11:51 --> Helper loaded: url_helper
INFO - 2016-07-22 10:11:51 --> Helper loaded: language_helper
INFO - 2016-07-22 10:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:11:51 --> Controller Class Initialized
DEBUG - 2016-07-22 10:11:51 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:11:51 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:15:07 --> Config Class Initialized
INFO - 2016-07-22 10:15:07 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:15:07 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:15:07 --> Utf8 Class Initialized
INFO - 2016-07-22 10:15:07 --> URI Class Initialized
INFO - 2016-07-22 10:15:07 --> Router Class Initialized
INFO - 2016-07-22 10:15:07 --> Output Class Initialized
INFO - 2016-07-22 10:15:07 --> Security Class Initialized
DEBUG - 2016-07-22 10:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:15:07 --> Input Class Initialized
INFO - 2016-07-22 10:15:07 --> Language Class Initialized
INFO - 2016-07-22 10:15:07 --> Loader Class Initialized
INFO - 2016-07-22 10:15:07 --> Helper loaded: url_helper
INFO - 2016-07-22 10:15:07 --> Helper loaded: language_helper
INFO - 2016-07-22 10:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:15:07 --> Controller Class Initialized
ERROR - 2016-07-22 10:15:07 --> Unable to load the requested class: PHPExcel
INFO - 2016-07-22 10:15:08 --> Config Class Initialized
INFO - 2016-07-22 10:15:08 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:15:08 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:15:08 --> Utf8 Class Initialized
INFO - 2016-07-22 10:15:08 --> URI Class Initialized
INFO - 2016-07-22 10:15:08 --> Router Class Initialized
INFO - 2016-07-22 10:15:08 --> Output Class Initialized
INFO - 2016-07-22 10:15:08 --> Security Class Initialized
DEBUG - 2016-07-22 10:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:15:08 --> Input Class Initialized
INFO - 2016-07-22 10:15:08 --> Language Class Initialized
INFO - 2016-07-22 10:15:08 --> Loader Class Initialized
INFO - 2016-07-22 10:15:08 --> Helper loaded: url_helper
INFO - 2016-07-22 10:15:08 --> Helper loaded: language_helper
INFO - 2016-07-22 10:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:15:08 --> Controller Class Initialized
ERROR - 2016-07-22 10:15:08 --> Unable to load the requested class: PHPExcel
INFO - 2016-07-22 10:15:24 --> Config Class Initialized
INFO - 2016-07-22 10:15:24 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:15:24 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:15:24 --> Utf8 Class Initialized
INFO - 2016-07-22 10:15:24 --> URI Class Initialized
INFO - 2016-07-22 10:15:24 --> Router Class Initialized
INFO - 2016-07-22 10:15:24 --> Output Class Initialized
INFO - 2016-07-22 10:15:24 --> Security Class Initialized
DEBUG - 2016-07-22 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:15:24 --> Input Class Initialized
INFO - 2016-07-22 10:15:24 --> Language Class Initialized
INFO - 2016-07-22 10:15:24 --> Loader Class Initialized
INFO - 2016-07-22 10:15:24 --> Helper loaded: url_helper
INFO - 2016-07-22 10:15:24 --> Helper loaded: language_helper
INFO - 2016-07-22 10:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:15:24 --> Controller Class Initialized
DEBUG - 2016-07-22 10:15:24 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:15:24 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:37 --> Config Class Initialized
INFO - 2016-07-22 10:18:37 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:37 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:37 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:37 --> URI Class Initialized
INFO - 2016-07-22 10:18:37 --> Router Class Initialized
INFO - 2016-07-22 10:18:37 --> Output Class Initialized
INFO - 2016-07-22 10:18:37 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:37 --> Input Class Initialized
INFO - 2016-07-22 10:18:37 --> Language Class Initialized
INFO - 2016-07-22 10:18:37 --> Loader Class Initialized
INFO - 2016-07-22 10:18:37 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:37 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:37 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:37 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:37 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:42 --> Config Class Initialized
INFO - 2016-07-22 10:18:42 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:42 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:42 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:42 --> URI Class Initialized
INFO - 2016-07-22 10:18:42 --> Router Class Initialized
INFO - 2016-07-22 10:18:42 --> Output Class Initialized
INFO - 2016-07-22 10:18:42 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:42 --> Input Class Initialized
INFO - 2016-07-22 10:18:42 --> Language Class Initialized
INFO - 2016-07-22 10:18:42 --> Loader Class Initialized
INFO - 2016-07-22 10:18:42 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:42 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:42 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:42 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:42 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:50 --> Config Class Initialized
INFO - 2016-07-22 10:18:50 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:50 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:50 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:50 --> URI Class Initialized
INFO - 2016-07-22 10:18:50 --> Router Class Initialized
INFO - 2016-07-22 10:18:50 --> Output Class Initialized
INFO - 2016-07-22 10:18:50 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:50 --> Input Class Initialized
INFO - 2016-07-22 10:18:50 --> Language Class Initialized
INFO - 2016-07-22 10:18:50 --> Loader Class Initialized
INFO - 2016-07-22 10:18:50 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:50 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:50 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:50 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:50 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:51 --> Config Class Initialized
INFO - 2016-07-22 10:18:51 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:51 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:51 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:51 --> URI Class Initialized
INFO - 2016-07-22 10:18:51 --> Router Class Initialized
INFO - 2016-07-22 10:18:51 --> Output Class Initialized
INFO - 2016-07-22 10:18:51 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:51 --> Input Class Initialized
INFO - 2016-07-22 10:18:51 --> Language Class Initialized
INFO - 2016-07-22 10:18:51 --> Loader Class Initialized
INFO - 2016-07-22 10:18:51 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:51 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:51 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:51 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:51 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:51 --> Config Class Initialized
INFO - 2016-07-22 10:18:51 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:51 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:51 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:51 --> URI Class Initialized
INFO - 2016-07-22 10:18:51 --> Router Class Initialized
INFO - 2016-07-22 10:18:51 --> Output Class Initialized
INFO - 2016-07-22 10:18:51 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:51 --> Input Class Initialized
INFO - 2016-07-22 10:18:51 --> Language Class Initialized
INFO - 2016-07-22 10:18:51 --> Loader Class Initialized
INFO - 2016-07-22 10:18:51 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:51 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:51 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:51 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:51 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:51 --> Config Class Initialized
INFO - 2016-07-22 10:18:51 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:52 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:52 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:52 --> URI Class Initialized
INFO - 2016-07-22 10:18:52 --> Router Class Initialized
INFO - 2016-07-22 10:18:52 --> Output Class Initialized
INFO - 2016-07-22 10:18:52 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:52 --> Input Class Initialized
INFO - 2016-07-22 10:18:52 --> Language Class Initialized
INFO - 2016-07-22 10:18:52 --> Loader Class Initialized
INFO - 2016-07-22 10:18:52 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:52 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:52 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:52 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:52 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 10:18:58 --> Config Class Initialized
INFO - 2016-07-22 10:18:58 --> Hooks Class Initialized
DEBUG - 2016-07-22 10:18:58 --> UTF-8 Support Enabled
INFO - 2016-07-22 10:18:58 --> Utf8 Class Initialized
INFO - 2016-07-22 10:18:58 --> URI Class Initialized
INFO - 2016-07-22 10:18:58 --> Router Class Initialized
INFO - 2016-07-22 10:18:58 --> Output Class Initialized
INFO - 2016-07-22 10:18:58 --> Security Class Initialized
DEBUG - 2016-07-22 10:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 10:18:58 --> Input Class Initialized
INFO - 2016-07-22 10:18:58 --> Language Class Initialized
INFO - 2016-07-22 10:18:58 --> Loader Class Initialized
INFO - 2016-07-22 10:18:58 --> Helper loaded: url_helper
INFO - 2016-07-22 10:18:58 --> Helper loaded: language_helper
INFO - 2016-07-22 10:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 10:18:58 --> Controller Class Initialized
DEBUG - 2016-07-22 10:18:58 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 10:18:58 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 13:45:06 --> Config Class Initialized
INFO - 2016-07-22 13:45:06 --> Hooks Class Initialized
DEBUG - 2016-07-22 13:45:06 --> UTF-8 Support Enabled
INFO - 2016-07-22 13:45:06 --> Utf8 Class Initialized
INFO - 2016-07-22 13:45:06 --> URI Class Initialized
INFO - 2016-07-22 13:45:06 --> Router Class Initialized
INFO - 2016-07-22 13:45:06 --> Output Class Initialized
INFO - 2016-07-22 13:45:06 --> Security Class Initialized
DEBUG - 2016-07-22 13:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 13:45:06 --> Input Class Initialized
INFO - 2016-07-22 13:45:06 --> Language Class Initialized
INFO - 2016-07-22 13:45:06 --> Loader Class Initialized
INFO - 2016-07-22 13:45:06 --> Helper loaded: url_helper
INFO - 2016-07-22 13:45:06 --> Helper loaded: language_helper
INFO - 2016-07-22 13:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 13:45:06 --> Controller Class Initialized
ERROR - 2016-07-22 13:45:06 --> Unable to load the requested class: PHPExcel
INFO - 2016-07-22 13:46:31 --> Config Class Initialized
INFO - 2016-07-22 13:46:31 --> Hooks Class Initialized
DEBUG - 2016-07-22 13:46:31 --> UTF-8 Support Enabled
INFO - 2016-07-22 13:46:31 --> Utf8 Class Initialized
INFO - 2016-07-22 13:46:31 --> URI Class Initialized
INFO - 2016-07-22 13:46:31 --> Router Class Initialized
INFO - 2016-07-22 13:46:31 --> Output Class Initialized
INFO - 2016-07-22 13:46:31 --> Security Class Initialized
DEBUG - 2016-07-22 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 13:46:31 --> Input Class Initialized
INFO - 2016-07-22 13:46:31 --> Language Class Initialized
INFO - 2016-07-22 13:46:31 --> Loader Class Initialized
INFO - 2016-07-22 13:46:31 --> Helper loaded: url_helper
INFO - 2016-07-22 13:46:31 --> Helper loaded: language_helper
INFO - 2016-07-22 13:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 13:46:31 --> Controller Class Initialized
ERROR - 2016-07-22 13:46:31 --> Unable to load the requested class: PHPExcel
INFO - 2016-07-22 14:23:15 --> Config Class Initialized
INFO - 2016-07-22 14:23:15 --> Hooks Class Initialized
DEBUG - 2016-07-22 14:23:15 --> UTF-8 Support Enabled
INFO - 2016-07-22 14:23:15 --> Utf8 Class Initialized
INFO - 2016-07-22 14:23:15 --> URI Class Initialized
INFO - 2016-07-22 14:23:15 --> Router Class Initialized
INFO - 2016-07-22 14:23:15 --> Output Class Initialized
INFO - 2016-07-22 14:23:15 --> Security Class Initialized
DEBUG - 2016-07-22 14:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 14:23:15 --> Input Class Initialized
INFO - 2016-07-22 14:23:15 --> Language Class Initialized
INFO - 2016-07-22 14:23:15 --> Loader Class Initialized
INFO - 2016-07-22 14:23:15 --> Helper loaded: url_helper
INFO - 2016-07-22 14:23:15 --> Helper loaded: language_helper
INFO - 2016-07-22 14:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 14:23:15 --> Controller Class Initialized
ERROR - 2016-07-22 14:23:15 --> Unable to load the requested class: PHPExcel
INFO - 2016-07-22 14:23:41 --> Config Class Initialized
INFO - 2016-07-22 14:23:41 --> Hooks Class Initialized
DEBUG - 2016-07-22 14:23:41 --> UTF-8 Support Enabled
INFO - 2016-07-22 14:23:41 --> Utf8 Class Initialized
INFO - 2016-07-22 14:23:41 --> URI Class Initialized
INFO - 2016-07-22 14:23:41 --> Router Class Initialized
INFO - 2016-07-22 14:23:41 --> Output Class Initialized
INFO - 2016-07-22 14:23:41 --> Security Class Initialized
DEBUG - 2016-07-22 14:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 14:23:41 --> Input Class Initialized
INFO - 2016-07-22 14:23:41 --> Language Class Initialized
INFO - 2016-07-22 14:23:41 --> Loader Class Initialized
INFO - 2016-07-22 14:23:41 --> Helper loaded: url_helper
INFO - 2016-07-22 14:23:41 --> Helper loaded: language_helper
INFO - 2016-07-22 14:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 14:23:41 --> Controller Class Initialized
DEBUG - 2016-07-22 14:23:41 --> Excel class already loaded. Second attempt ignored.
ERROR - 2016-07-22 14:23:41 --> Severity: error --> Exception: Class 'PHPExcel' not found C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 14
INFO - 2016-07-22 14:23:56 --> Config Class Initialized
INFO - 2016-07-22 14:23:56 --> Hooks Class Initialized
DEBUG - 2016-07-22 14:23:56 --> UTF-8 Support Enabled
INFO - 2016-07-22 14:23:56 --> Utf8 Class Initialized
INFO - 2016-07-22 14:23:56 --> URI Class Initialized
INFO - 2016-07-22 14:23:56 --> Router Class Initialized
INFO - 2016-07-22 14:23:56 --> Output Class Initialized
INFO - 2016-07-22 14:23:56 --> Security Class Initialized
DEBUG - 2016-07-22 14:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 14:23:56 --> Input Class Initialized
INFO - 2016-07-22 14:23:56 --> Language Class Initialized
INFO - 2016-07-22 14:23:56 --> Loader Class Initialized
INFO - 2016-07-22 14:23:56 --> Helper loaded: url_helper
INFO - 2016-07-22 14:23:56 --> Helper loaded: language_helper
INFO - 2016-07-22 14:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 14:23:56 --> Controller Class Initialized
DEBUG - 2016-07-22 14:23:56 --> Excel class already loaded. Second attempt ignored.
INFO - 2016-07-22 14:23:56 --> Final output sent to browser
DEBUG - 2016-07-22 14:23:56 --> Total execution time: 0.0358
INFO - 2016-07-22 14:24:16 --> Config Class Initialized
INFO - 2016-07-22 14:24:16 --> Hooks Class Initialized
DEBUG - 2016-07-22 14:24:16 --> UTF-8 Support Enabled
INFO - 2016-07-22 14:24:16 --> Utf8 Class Initialized
INFO - 2016-07-22 14:24:16 --> URI Class Initialized
INFO - 2016-07-22 14:24:16 --> Router Class Initialized
INFO - 2016-07-22 14:24:16 --> Output Class Initialized
INFO - 2016-07-22 14:24:16 --> Security Class Initialized
DEBUG - 2016-07-22 14:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 14:24:16 --> Input Class Initialized
INFO - 2016-07-22 14:24:16 --> Language Class Initialized
INFO - 2016-07-22 14:24:16 --> Loader Class Initialized
INFO - 2016-07-22 14:24:16 --> Helper loaded: url_helper
INFO - 2016-07-22 14:24:16 --> Helper loaded: language_helper
INFO - 2016-07-22 14:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 14:24:16 --> Controller Class Initialized
DEBUG - 2016-07-22 14:24:16 --> Excel class already loaded. Second attempt ignored.
INFO - 2016-07-22 14:24:16 --> Final output sent to browser
DEBUG - 2016-07-22 14:24:16 --> Total execution time: 0.0354
INFO - 2016-07-22 14:38:27 --> Config Class Initialized
INFO - 2016-07-22 14:38:27 --> Hooks Class Initialized
DEBUG - 2016-07-22 14:38:27 --> UTF-8 Support Enabled
INFO - 2016-07-22 14:38:27 --> Utf8 Class Initialized
INFO - 2016-07-22 14:38:27 --> URI Class Initialized
INFO - 2016-07-22 14:38:27 --> Router Class Initialized
INFO - 2016-07-22 14:38:27 --> Output Class Initialized
INFO - 2016-07-22 14:38:27 --> Security Class Initialized
DEBUG - 2016-07-22 14:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-22 14:38:27 --> Input Class Initialized
INFO - 2016-07-22 14:38:27 --> Language Class Initialized
INFO - 2016-07-22 14:38:27 --> Loader Class Initialized
INFO - 2016-07-22 14:38:27 --> Helper loaded: url_helper
INFO - 2016-07-22 14:38:27 --> Helper loaded: language_helper
INFO - 2016-07-22 14:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-22 14:38:27 --> Controller Class Initialized
DEBUG - 2016-07-22 14:38:27 --> Excel class already loaded. Second attempt ignored.
INFO - 2016-07-22 14:38:27 --> Final output sent to browser
DEBUG - 2016-07-22 14:38:27 --> Total execution time: 0.0357
