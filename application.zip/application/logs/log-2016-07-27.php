<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-27 12:17:19 --> Config Class Initialized
INFO - 2016-07-27 12:17:19 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:17:19 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:17:19 --> Utf8 Class Initialized
INFO - 2016-07-27 12:17:19 --> URI Class Initialized
DEBUG - 2016-07-27 12:17:19 --> No URI present. Default controller set.
INFO - 2016-07-27 12:17:19 --> Router Class Initialized
INFO - 2016-07-27 12:17:19 --> Output Class Initialized
INFO - 2016-07-27 12:17:19 --> Security Class Initialized
DEBUG - 2016-07-27 12:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:17:19 --> Input Class Initialized
INFO - 2016-07-27 12:17:19 --> Language Class Initialized
INFO - 2016-07-27 12:17:19 --> Loader Class Initialized
INFO - 2016-07-27 12:17:19 --> Helper loaded: url_helper
INFO - 2016-07-27 12:17:19 --> Helper loaded: language_helper
INFO - 2016-07-27 12:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:17:19 --> Controller Class Initialized
INFO - 2016-07-27 12:17:19 --> Database Driver Class Initialized
INFO - 2016-07-27 12:17:19 --> Model Class Initialized
INFO - 2016-07-27 12:17:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:17:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-07-27 12:17:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-07-27 12:17:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-07-27 12:17:19 --> Final output sent to browser
DEBUG - 2016-07-27 12:17:19 --> Total execution time: 0.1457
INFO - 2016-07-27 12:17:24 --> Config Class Initialized
INFO - 2016-07-27 12:17:24 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:17:24 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:17:24 --> Utf8 Class Initialized
INFO - 2016-07-27 12:17:24 --> URI Class Initialized
INFO - 2016-07-27 12:17:24 --> Router Class Initialized
INFO - 2016-07-27 12:17:24 --> Output Class Initialized
INFO - 2016-07-27 12:17:24 --> Security Class Initialized
DEBUG - 2016-07-27 12:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:17:24 --> Input Class Initialized
INFO - 2016-07-27 12:17:24 --> Language Class Initialized
INFO - 2016-07-27 12:17:24 --> Loader Class Initialized
INFO - 2016-07-27 12:17:24 --> Helper loaded: url_helper
INFO - 2016-07-27 12:17:24 --> Helper loaded: language_helper
INFO - 2016-07-27 12:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:17:24 --> Controller Class Initialized
INFO - 2016-07-27 12:17:24 --> Database Driver Class Initialized
INFO - 2016-07-27 12:17:24 --> Model Class Initialized
INFO - 2016-07-27 12:17:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:17:24 --> Config Class Initialized
INFO - 2016-07-27 12:17:24 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:17:24 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:17:24 --> Utf8 Class Initialized
INFO - 2016-07-27 12:17:24 --> URI Class Initialized
INFO - 2016-07-27 12:17:24 --> Router Class Initialized
INFO - 2016-07-27 12:17:24 --> Output Class Initialized
INFO - 2016-07-27 12:17:24 --> Security Class Initialized
DEBUG - 2016-07-27 12:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:17:24 --> Input Class Initialized
INFO - 2016-07-27 12:17:24 --> Language Class Initialized
INFO - 2016-07-27 12:17:24 --> Loader Class Initialized
INFO - 2016-07-27 12:17:24 --> Helper loaded: url_helper
INFO - 2016-07-27 12:17:24 --> Helper loaded: language_helper
INFO - 2016-07-27 12:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:17:24 --> Controller Class Initialized
INFO - 2016-07-27 12:17:24 --> Database Driver Class Initialized
INFO - 2016-07-27 12:17:24 --> Model Class Initialized
INFO - 2016-07-27 12:17:24 --> Model Class Initialized
INFO - 2016-07-27 12:17:24 --> Model Class Initialized
INFO - 2016-07-27 12:17:24 --> Model Class Initialized
INFO - 2016-07-27 12:17:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-07-27 12:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:17:24 --> Final output sent to browser
DEBUG - 2016-07-27 12:17:24 --> Total execution time: 0.0973
INFO - 2016-07-27 12:17:27 --> Config Class Initialized
INFO - 2016-07-27 12:17:27 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:17:27 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:17:27 --> Utf8 Class Initialized
INFO - 2016-07-27 12:17:27 --> URI Class Initialized
INFO - 2016-07-27 12:17:27 --> Router Class Initialized
INFO - 2016-07-27 12:17:27 --> Output Class Initialized
INFO - 2016-07-27 12:17:27 --> Security Class Initialized
DEBUG - 2016-07-27 12:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:17:27 --> Input Class Initialized
INFO - 2016-07-27 12:17:27 --> Language Class Initialized
INFO - 2016-07-27 12:17:27 --> Loader Class Initialized
INFO - 2016-07-27 12:17:27 --> Helper loaded: url_helper
INFO - 2016-07-27 12:17:27 --> Helper loaded: language_helper
INFO - 2016-07-27 12:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:17:27 --> Controller Class Initialized
INFO - 2016-07-27 12:17:27 --> Database Driver Class Initialized
INFO - 2016-07-27 12:17:27 --> Model Class Initialized
INFO - 2016-07-27 12:17:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:17:27 --> Model Class Initialized
INFO - 2016-07-27 12:17:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:17:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\result_list.php
INFO - 2016-07-27 12:17:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:17:27 --> Final output sent to browser
DEBUG - 2016-07-27 12:17:27 --> Total execution time: 0.0927
INFO - 2016-07-27 12:18:17 --> Config Class Initialized
INFO - 2016-07-27 12:18:17 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:18:17 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:18:17 --> Utf8 Class Initialized
INFO - 2016-07-27 12:18:17 --> URI Class Initialized
INFO - 2016-07-27 12:18:17 --> Router Class Initialized
INFO - 2016-07-27 12:18:17 --> Output Class Initialized
INFO - 2016-07-27 12:18:17 --> Security Class Initialized
DEBUG - 2016-07-27 12:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:18:17 --> Input Class Initialized
INFO - 2016-07-27 12:18:17 --> Language Class Initialized
INFO - 2016-07-27 12:18:17 --> Loader Class Initialized
INFO - 2016-07-27 12:18:17 --> Helper loaded: url_helper
INFO - 2016-07-27 12:18:17 --> Helper loaded: language_helper
INFO - 2016-07-27 12:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:18:17 --> Controller Class Initialized
INFO - 2016-07-27 12:18:17 --> Database Driver Class Initialized
INFO - 2016-07-27 12:18:17 --> Model Class Initialized
INFO - 2016-07-27 12:18:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:18:17 --> Model Class Initialized
INFO - 2016-07-27 12:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\view_result.php
INFO - 2016-07-27 12:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:18:17 --> Final output sent to browser
DEBUG - 2016-07-27 12:18:17 --> Total execution time: 0.1079
INFO - 2016-07-27 12:18:47 --> Config Class Initialized
INFO - 2016-07-27 12:18:47 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:18:47 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:18:47 --> Utf8 Class Initialized
INFO - 2016-07-27 12:18:47 --> URI Class Initialized
INFO - 2016-07-27 12:18:47 --> Router Class Initialized
INFO - 2016-07-27 12:18:47 --> Output Class Initialized
INFO - 2016-07-27 12:18:47 --> Security Class Initialized
DEBUG - 2016-07-27 12:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:18:47 --> Input Class Initialized
INFO - 2016-07-27 12:18:47 --> Language Class Initialized
INFO - 2016-07-27 12:18:47 --> Loader Class Initialized
INFO - 2016-07-27 12:18:47 --> Helper loaded: url_helper
INFO - 2016-07-27 12:18:47 --> Helper loaded: language_helper
INFO - 2016-07-27 12:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:18:47 --> Controller Class Initialized
INFO - 2016-07-27 12:18:47 --> Database Driver Class Initialized
INFO - 2016-07-27 12:18:47 --> Model Class Initialized
INFO - 2016-07-27 12:18:47 --> Model Class Initialized
INFO - 2016-07-27 12:18:47 --> Model Class Initialized
INFO - 2016-07-27 12:18:47 --> Model Class Initialized
INFO - 2016-07-27 12:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:18:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:18:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-07-27 12:18:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:18:47 --> Final output sent to browser
DEBUG - 2016-07-27 12:18:47 --> Total execution time: 0.0753
INFO - 2016-07-27 12:19:01 --> Config Class Initialized
INFO - 2016-07-27 12:19:01 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:19:01 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:19:01 --> Utf8 Class Initialized
INFO - 2016-07-27 12:19:01 --> URI Class Initialized
INFO - 2016-07-27 12:19:01 --> Router Class Initialized
INFO - 2016-07-27 12:19:01 --> Output Class Initialized
INFO - 2016-07-27 12:19:01 --> Security Class Initialized
DEBUG - 2016-07-27 12:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:19:01 --> Input Class Initialized
INFO - 2016-07-27 12:19:01 --> Language Class Initialized
INFO - 2016-07-27 12:19:01 --> Loader Class Initialized
INFO - 2016-07-27 12:19:01 --> Helper loaded: url_helper
INFO - 2016-07-27 12:19:01 --> Helper loaded: language_helper
INFO - 2016-07-27 12:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:19:01 --> Controller Class Initialized
INFO - 2016-07-27 12:19:01 --> Database Driver Class Initialized
INFO - 2016-07-27 12:19:01 --> Model Class Initialized
INFO - 2016-07-27 12:19:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-07-27 12:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:19:01 --> Final output sent to browser
DEBUG - 2016-07-27 12:19:01 --> Total execution time: 0.0608
INFO - 2016-07-27 12:19:47 --> Config Class Initialized
INFO - 2016-07-27 12:19:47 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:19:47 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:19:47 --> Utf8 Class Initialized
INFO - 2016-07-27 12:19:47 --> URI Class Initialized
INFO - 2016-07-27 12:19:47 --> Router Class Initialized
INFO - 2016-07-27 12:19:47 --> Output Class Initialized
INFO - 2016-07-27 12:19:47 --> Security Class Initialized
DEBUG - 2016-07-27 12:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:19:47 --> Input Class Initialized
INFO - 2016-07-27 12:19:47 --> Language Class Initialized
INFO - 2016-07-27 12:19:47 --> Loader Class Initialized
INFO - 2016-07-27 12:19:47 --> Helper loaded: url_helper
INFO - 2016-07-27 12:19:47 --> Helper loaded: language_helper
INFO - 2016-07-27 12:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:19:47 --> Controller Class Initialized
INFO - 2016-07-27 12:19:47 --> Database Driver Class Initialized
INFO - 2016-07-27 12:19:47 --> Model Class Initialized
INFO - 2016-07-27 12:19:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:19:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:19:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-07-27 12:19:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:19:47 --> Final output sent to browser
DEBUG - 2016-07-27 12:19:47 --> Total execution time: 0.0697
INFO - 2016-07-27 12:20:04 --> Config Class Initialized
INFO - 2016-07-27 12:20:04 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:20:04 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:20:04 --> Utf8 Class Initialized
INFO - 2016-07-27 12:20:04 --> URI Class Initialized
INFO - 2016-07-27 12:20:04 --> Router Class Initialized
INFO - 2016-07-27 12:20:04 --> Output Class Initialized
INFO - 2016-07-27 12:20:04 --> Security Class Initialized
DEBUG - 2016-07-27 12:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:20:04 --> Input Class Initialized
INFO - 2016-07-27 12:20:04 --> Language Class Initialized
INFO - 2016-07-27 12:20:04 --> Loader Class Initialized
INFO - 2016-07-27 12:20:04 --> Helper loaded: url_helper
INFO - 2016-07-27 12:20:04 --> Helper loaded: language_helper
INFO - 2016-07-27 12:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:20:04 --> Controller Class Initialized
INFO - 2016-07-27 12:20:04 --> Database Driver Class Initialized
INFO - 2016-07-27 12:20:04 --> Model Class Initialized
INFO - 2016-07-27 12:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:20:04 --> Config Class Initialized
INFO - 2016-07-27 12:20:04 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:20:04 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:20:04 --> Utf8 Class Initialized
INFO - 2016-07-27 12:20:04 --> URI Class Initialized
INFO - 2016-07-27 12:20:04 --> Router Class Initialized
INFO - 2016-07-27 12:20:04 --> Output Class Initialized
INFO - 2016-07-27 12:20:04 --> Security Class Initialized
DEBUG - 2016-07-27 12:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:20:04 --> Input Class Initialized
INFO - 2016-07-27 12:20:04 --> Language Class Initialized
INFO - 2016-07-27 12:20:04 --> Loader Class Initialized
INFO - 2016-07-27 12:20:04 --> Helper loaded: url_helper
INFO - 2016-07-27 12:20:04 --> Helper loaded: language_helper
INFO - 2016-07-27 12:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:20:04 --> Controller Class Initialized
INFO - 2016-07-27 12:20:04 --> Database Driver Class Initialized
INFO - 2016-07-27 12:20:04 --> Model Class Initialized
INFO - 2016-07-27 12:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_3.php
INFO - 2016-07-27 12:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:20:04 --> Final output sent to browser
DEBUG - 2016-07-27 12:20:04 --> Total execution time: 0.0738
INFO - 2016-07-27 12:21:11 --> Config Class Initialized
INFO - 2016-07-27 12:21:11 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:21:11 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:21:11 --> Utf8 Class Initialized
INFO - 2016-07-27 12:21:11 --> URI Class Initialized
INFO - 2016-07-27 12:21:11 --> Router Class Initialized
INFO - 2016-07-27 12:21:11 --> Output Class Initialized
INFO - 2016-07-27 12:21:11 --> Security Class Initialized
DEBUG - 2016-07-27 12:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:21:11 --> Input Class Initialized
INFO - 2016-07-27 12:21:11 --> Language Class Initialized
INFO - 2016-07-27 12:21:11 --> Loader Class Initialized
INFO - 2016-07-27 12:21:11 --> Helper loaded: url_helper
INFO - 2016-07-27 12:21:11 --> Helper loaded: language_helper
INFO - 2016-07-27 12:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:21:11 --> Controller Class Initialized
INFO - 2016-07-27 12:21:11 --> Database Driver Class Initialized
INFO - 2016-07-27 12:21:11 --> Model Class Initialized
INFO - 2016-07-27 12:21:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:21:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:21:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_3.php
INFO - 2016-07-27 12:21:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:21:11 --> Final output sent to browser
DEBUG - 2016-07-27 12:21:11 --> Total execution time: 0.0779
INFO - 2016-07-27 12:21:52 --> Config Class Initialized
INFO - 2016-07-27 12:21:52 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:21:52 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:21:52 --> Utf8 Class Initialized
INFO - 2016-07-27 12:21:52 --> URI Class Initialized
INFO - 2016-07-27 12:21:52 --> Router Class Initialized
INFO - 2016-07-27 12:21:52 --> Output Class Initialized
INFO - 2016-07-27 12:21:52 --> Security Class Initialized
DEBUG - 2016-07-27 12:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:21:52 --> Input Class Initialized
INFO - 2016-07-27 12:21:52 --> Language Class Initialized
INFO - 2016-07-27 12:21:52 --> Loader Class Initialized
INFO - 2016-07-27 12:21:52 --> Helper loaded: url_helper
INFO - 2016-07-27 12:21:52 --> Helper loaded: language_helper
INFO - 2016-07-27 12:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:21:52 --> Controller Class Initialized
INFO - 2016-07-27 12:21:52 --> Database Driver Class Initialized
INFO - 2016-07-27 12:21:52 --> Model Class Initialized
INFO - 2016-07-27 12:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-07-27 12:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:21:52 --> Final output sent to browser
DEBUG - 2016-07-27 12:21:52 --> Total execution time: 0.0567
INFO - 2016-07-27 12:21:57 --> Config Class Initialized
INFO - 2016-07-27 12:21:57 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:21:57 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:21:57 --> Utf8 Class Initialized
INFO - 2016-07-27 12:21:57 --> URI Class Initialized
INFO - 2016-07-27 12:21:57 --> Router Class Initialized
INFO - 2016-07-27 12:21:57 --> Output Class Initialized
INFO - 2016-07-27 12:21:57 --> Security Class Initialized
DEBUG - 2016-07-27 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:21:57 --> Input Class Initialized
INFO - 2016-07-27 12:21:57 --> Language Class Initialized
INFO - 2016-07-27 12:21:57 --> Loader Class Initialized
INFO - 2016-07-27 12:21:57 --> Helper loaded: url_helper
INFO - 2016-07-27 12:21:57 --> Helper loaded: language_helper
INFO - 2016-07-27 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:21:57 --> Controller Class Initialized
INFO - 2016-07-27 12:21:57 --> Database Driver Class Initialized
INFO - 2016-07-27 12:21:57 --> Model Class Initialized
INFO - 2016-07-27 12:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:21:57 --> Config Class Initialized
INFO - 2016-07-27 12:21:57 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:21:57 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:21:57 --> Utf8 Class Initialized
INFO - 2016-07-27 12:21:57 --> URI Class Initialized
INFO - 2016-07-27 12:21:57 --> Router Class Initialized
INFO - 2016-07-27 12:21:57 --> Output Class Initialized
INFO - 2016-07-27 12:21:57 --> Security Class Initialized
DEBUG - 2016-07-27 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:21:57 --> Input Class Initialized
INFO - 2016-07-27 12:21:57 --> Language Class Initialized
INFO - 2016-07-27 12:21:57 --> Loader Class Initialized
INFO - 2016-07-27 12:21:57 --> Helper loaded: url_helper
INFO - 2016-07-27 12:21:57 --> Helper loaded: language_helper
INFO - 2016-07-27 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:21:57 --> Controller Class Initialized
INFO - 2016-07-27 12:21:57 --> Database Driver Class Initialized
INFO - 2016-07-27 12:21:57 --> Model Class Initialized
INFO - 2016-07-27 12:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-07-27 12:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:21:57 --> Final output sent to browser
DEBUG - 2016-07-27 12:21:57 --> Total execution time: 0.0626
INFO - 2016-07-27 12:26:45 --> Config Class Initialized
INFO - 2016-07-27 12:26:45 --> Hooks Class Initialized
DEBUG - 2016-07-27 12:26:45 --> UTF-8 Support Enabled
INFO - 2016-07-27 12:26:45 --> Utf8 Class Initialized
INFO - 2016-07-27 12:26:45 --> URI Class Initialized
INFO - 2016-07-27 12:26:45 --> Router Class Initialized
INFO - 2016-07-27 12:26:45 --> Output Class Initialized
INFO - 2016-07-27 12:26:45 --> Security Class Initialized
DEBUG - 2016-07-27 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-27 12:26:45 --> Input Class Initialized
INFO - 2016-07-27 12:26:45 --> Language Class Initialized
INFO - 2016-07-27 12:26:45 --> Loader Class Initialized
INFO - 2016-07-27 12:26:45 --> Helper loaded: url_helper
INFO - 2016-07-27 12:26:45 --> Helper loaded: language_helper
INFO - 2016-07-27 12:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-27 12:26:45 --> Controller Class Initialized
INFO - 2016-07-27 12:26:45 --> Database Driver Class Initialized
INFO - 2016-07-27 12:26:45 --> Model Class Initialized
INFO - 2016-07-27 12:26:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-07-27 12:26:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-07-27 12:26:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-07-27 12:26:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-07-27 12:26:45 --> Final output sent to browser
DEBUG - 2016-07-27 12:26:45 --> Total execution time: 0.0854
