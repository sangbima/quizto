<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-03 08:10:26 --> Config Class Initialized
INFO - 2016-08-03 08:10:26 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:10:26 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:10:26 --> Utf8 Class Initialized
INFO - 2016-08-03 08:10:26 --> URI Class Initialized
INFO - 2016-08-03 08:10:26 --> Router Class Initialized
INFO - 2016-08-03 08:10:26 --> Output Class Initialized
INFO - 2016-08-03 08:10:26 --> Security Class Initialized
DEBUG - 2016-08-03 08:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:10:26 --> Input Class Initialized
INFO - 2016-08-03 08:10:26 --> Language Class Initialized
INFO - 2016-08-03 08:10:26 --> Loader Class Initialized
INFO - 2016-08-03 08:10:26 --> Helper loaded: url_helper
INFO - 2016-08-03 08:10:26 --> Helper loaded: language_helper
INFO - 2016-08-03 08:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:10:26 --> Controller Class Initialized
INFO - 2016-08-03 08:10:26 --> Database Driver Class Initialized
INFO - 2016-08-03 08:10:26 --> Model Class Initialized
INFO - 2016-08-03 08:10:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:10:26 --> Config Class Initialized
INFO - 2016-08-03 08:10:26 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:10:26 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:10:26 --> Utf8 Class Initialized
INFO - 2016-08-03 08:10:26 --> URI Class Initialized
INFO - 2016-08-03 08:10:26 --> Router Class Initialized
INFO - 2016-08-03 08:10:26 --> Output Class Initialized
INFO - 2016-08-03 08:10:26 --> Security Class Initialized
DEBUG - 2016-08-03 08:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:10:26 --> Input Class Initialized
INFO - 2016-08-03 08:10:26 --> Language Class Initialized
INFO - 2016-08-03 08:10:26 --> Loader Class Initialized
INFO - 2016-08-03 08:10:26 --> Helper loaded: url_helper
INFO - 2016-08-03 08:10:26 --> Helper loaded: language_helper
INFO - 2016-08-03 08:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:10:26 --> Controller Class Initialized
INFO - 2016-08-03 08:10:26 --> Database Driver Class Initialized
INFO - 2016-08-03 08:10:26 --> Model Class Initialized
INFO - 2016-08-03 08:10:26 --> Model Class Initialized
INFO - 2016-08-03 08:10:26 --> Model Class Initialized
INFO - 2016-08-03 08:10:26 --> Model Class Initialized
INFO - 2016-08-03 08:10:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:10:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:10:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 08:10:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:10:26 --> Final output sent to browser
DEBUG - 2016-08-03 08:10:26 --> Total execution time: 0.0711
INFO - 2016-08-03 08:12:48 --> Config Class Initialized
INFO - 2016-08-03 08:12:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:12:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:12:48 --> Utf8 Class Initialized
INFO - 2016-08-03 08:12:48 --> URI Class Initialized
INFO - 2016-08-03 08:12:48 --> Router Class Initialized
INFO - 2016-08-03 08:12:48 --> Output Class Initialized
INFO - 2016-08-03 08:12:48 --> Security Class Initialized
DEBUG - 2016-08-03 08:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:12:48 --> Input Class Initialized
INFO - 2016-08-03 08:12:48 --> Language Class Initialized
INFO - 2016-08-03 08:12:48 --> Loader Class Initialized
INFO - 2016-08-03 08:12:48 --> Helper loaded: url_helper
INFO - 2016-08-03 08:12:48 --> Helper loaded: language_helper
INFO - 2016-08-03 08:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:12:48 --> Controller Class Initialized
INFO - 2016-08-03 08:12:48 --> Database Driver Class Initialized
INFO - 2016-08-03 08:12:48 --> Model Class Initialized
INFO - 2016-08-03 08:12:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:12:48 --> Config Class Initialized
INFO - 2016-08-03 08:12:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:12:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:12:48 --> Utf8 Class Initialized
INFO - 2016-08-03 08:12:48 --> URI Class Initialized
INFO - 2016-08-03 08:12:48 --> Router Class Initialized
INFO - 2016-08-03 08:12:48 --> Output Class Initialized
INFO - 2016-08-03 08:12:48 --> Security Class Initialized
DEBUG - 2016-08-03 08:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:12:48 --> Input Class Initialized
INFO - 2016-08-03 08:12:48 --> Language Class Initialized
INFO - 2016-08-03 08:12:48 --> Loader Class Initialized
INFO - 2016-08-03 08:12:48 --> Helper loaded: url_helper
INFO - 2016-08-03 08:12:48 --> Helper loaded: language_helper
INFO - 2016-08-03 08:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:12:48 --> Controller Class Initialized
INFO - 2016-08-03 08:12:48 --> Database Driver Class Initialized
INFO - 2016-08-03 08:12:48 --> Model Class Initialized
INFO - 2016-08-03 08:12:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:12:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:12:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:12:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:12:48 --> Final output sent to browser
DEBUG - 2016-08-03 08:12:48 --> Total execution time: 0.0510
INFO - 2016-08-03 08:12:54 --> Config Class Initialized
INFO - 2016-08-03 08:12:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:12:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:12:54 --> Utf8 Class Initialized
INFO - 2016-08-03 08:12:54 --> URI Class Initialized
INFO - 2016-08-03 08:12:54 --> Router Class Initialized
INFO - 2016-08-03 08:12:54 --> Output Class Initialized
INFO - 2016-08-03 08:12:54 --> Security Class Initialized
DEBUG - 2016-08-03 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:12:54 --> Input Class Initialized
INFO - 2016-08-03 08:12:54 --> Language Class Initialized
INFO - 2016-08-03 08:12:54 --> Loader Class Initialized
INFO - 2016-08-03 08:12:54 --> Helper loaded: url_helper
INFO - 2016-08-03 08:12:54 --> Helper loaded: language_helper
INFO - 2016-08-03 08:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:12:54 --> Controller Class Initialized
INFO - 2016-08-03 08:12:54 --> Database Driver Class Initialized
INFO - 2016-08-03 08:12:54 --> Model Class Initialized
INFO - 2016-08-03 08:12:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:12:54 --> Config Class Initialized
INFO - 2016-08-03 08:12:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:12:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:12:54 --> Utf8 Class Initialized
INFO - 2016-08-03 08:12:54 --> URI Class Initialized
INFO - 2016-08-03 08:12:54 --> Router Class Initialized
INFO - 2016-08-03 08:12:54 --> Output Class Initialized
INFO - 2016-08-03 08:12:54 --> Security Class Initialized
DEBUG - 2016-08-03 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:12:54 --> Input Class Initialized
INFO - 2016-08-03 08:12:54 --> Language Class Initialized
INFO - 2016-08-03 08:12:54 --> Loader Class Initialized
INFO - 2016-08-03 08:12:54 --> Helper loaded: url_helper
INFO - 2016-08-03 08:12:54 --> Helper loaded: language_helper
INFO - 2016-08-03 08:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:12:54 --> Controller Class Initialized
INFO - 2016-08-03 08:12:54 --> Database Driver Class Initialized
INFO - 2016-08-03 08:12:54 --> Model Class Initialized
INFO - 2016-08-03 08:12:54 --> Model Class Initialized
INFO - 2016-08-03 08:12:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:12:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:12:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:12:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:12:54 --> Final output sent to browser
DEBUG - 2016-08-03 08:12:54 --> Total execution time: 0.0590
INFO - 2016-08-03 08:12:57 --> Config Class Initialized
INFO - 2016-08-03 08:12:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:12:57 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:12:57 --> Utf8 Class Initialized
INFO - 2016-08-03 08:12:57 --> URI Class Initialized
INFO - 2016-08-03 08:12:57 --> Router Class Initialized
INFO - 2016-08-03 08:12:57 --> Output Class Initialized
INFO - 2016-08-03 08:12:57 --> Security Class Initialized
DEBUG - 2016-08-03 08:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:12:57 --> Input Class Initialized
INFO - 2016-08-03 08:12:57 --> Language Class Initialized
INFO - 2016-08-03 08:12:57 --> Loader Class Initialized
INFO - 2016-08-03 08:12:57 --> Helper loaded: url_helper
INFO - 2016-08-03 08:12:57 --> Helper loaded: language_helper
INFO - 2016-08-03 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:12:57 --> Controller Class Initialized
INFO - 2016-08-03 08:12:57 --> Database Driver Class Initialized
INFO - 2016-08-03 08:12:57 --> Model Class Initialized
INFO - 2016-08-03 08:12:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:12:57 --> Model Class Initialized
INFO - 2016-08-03 08:12:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:12:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\myaccount.php
INFO - 2016-08-03 08:12:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:12:57 --> Final output sent to browser
DEBUG - 2016-08-03 08:12:57 --> Total execution time: 0.0611
INFO - 2016-08-03 08:13:55 --> Config Class Initialized
INFO - 2016-08-03 08:13:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:13:55 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:13:55 --> Utf8 Class Initialized
INFO - 2016-08-03 08:13:55 --> URI Class Initialized
INFO - 2016-08-03 08:13:55 --> Router Class Initialized
INFO - 2016-08-03 08:13:55 --> Output Class Initialized
INFO - 2016-08-03 08:13:55 --> Security Class Initialized
DEBUG - 2016-08-03 08:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:13:55 --> Input Class Initialized
INFO - 2016-08-03 08:13:55 --> Language Class Initialized
INFO - 2016-08-03 08:13:55 --> Loader Class Initialized
INFO - 2016-08-03 08:13:55 --> Helper loaded: url_helper
INFO - 2016-08-03 08:13:55 --> Helper loaded: language_helper
INFO - 2016-08-03 08:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:13:55 --> Controller Class Initialized
INFO - 2016-08-03 08:13:55 --> Database Driver Class Initialized
INFO - 2016-08-03 08:13:55 --> Model Class Initialized
INFO - 2016-08-03 08:13:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:13:55 --> Config Class Initialized
INFO - 2016-08-03 08:13:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:13:55 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:13:55 --> Utf8 Class Initialized
INFO - 2016-08-03 08:13:55 --> URI Class Initialized
INFO - 2016-08-03 08:13:55 --> Router Class Initialized
INFO - 2016-08-03 08:13:55 --> Output Class Initialized
INFO - 2016-08-03 08:13:55 --> Security Class Initialized
DEBUG - 2016-08-03 08:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:13:55 --> Input Class Initialized
INFO - 2016-08-03 08:13:55 --> Language Class Initialized
INFO - 2016-08-03 08:13:55 --> Loader Class Initialized
INFO - 2016-08-03 08:13:55 --> Helper loaded: url_helper
INFO - 2016-08-03 08:13:55 --> Helper loaded: language_helper
INFO - 2016-08-03 08:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:13:55 --> Controller Class Initialized
INFO - 2016-08-03 08:13:55 --> Database Driver Class Initialized
INFO - 2016-08-03 08:13:55 --> Model Class Initialized
INFO - 2016-08-03 08:13:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:13:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:13:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:13:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:13:55 --> Final output sent to browser
DEBUG - 2016-08-03 08:13:55 --> Total execution time: 0.0495
INFO - 2016-08-03 08:14:03 --> Config Class Initialized
INFO - 2016-08-03 08:14:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:03 --> URI Class Initialized
INFO - 2016-08-03 08:14:03 --> Router Class Initialized
INFO - 2016-08-03 08:14:03 --> Output Class Initialized
INFO - 2016-08-03 08:14:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:03 --> Input Class Initialized
INFO - 2016-08-03 08:14:03 --> Language Class Initialized
INFO - 2016-08-03 08:14:03 --> Loader Class Initialized
INFO - 2016-08-03 08:14:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:03 --> Controller Class Initialized
INFO - 2016-08-03 08:14:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:03 --> Model Class Initialized
INFO - 2016-08-03 08:14:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:03 --> Config Class Initialized
INFO - 2016-08-03 08:14:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:03 --> URI Class Initialized
INFO - 2016-08-03 08:14:03 --> Router Class Initialized
INFO - 2016-08-03 08:14:03 --> Output Class Initialized
INFO - 2016-08-03 08:14:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:03 --> Input Class Initialized
INFO - 2016-08-03 08:14:03 --> Language Class Initialized
INFO - 2016-08-03 08:14:03 --> Loader Class Initialized
INFO - 2016-08-03 08:14:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:03 --> Controller Class Initialized
INFO - 2016-08-03 08:14:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:03 --> Model Class Initialized
INFO - 2016-08-03 08:14:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:14:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:14:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:14:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:03 --> Total execution time: 0.0521
INFO - 2016-08-03 08:14:16 --> Config Class Initialized
INFO - 2016-08-03 08:14:16 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:16 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:16 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:16 --> URI Class Initialized
INFO - 2016-08-03 08:14:16 --> Router Class Initialized
INFO - 2016-08-03 08:14:16 --> Output Class Initialized
INFO - 2016-08-03 08:14:16 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:16 --> Input Class Initialized
INFO - 2016-08-03 08:14:16 --> Language Class Initialized
INFO - 2016-08-03 08:14:16 --> Loader Class Initialized
INFO - 2016-08-03 08:14:16 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:16 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:16 --> Controller Class Initialized
INFO - 2016-08-03 08:14:16 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:16 --> Model Class Initialized
INFO - 2016-08-03 08:14:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:16 --> Config Class Initialized
INFO - 2016-08-03 08:14:16 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:16 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:16 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:16 --> URI Class Initialized
INFO - 2016-08-03 08:14:16 --> Router Class Initialized
INFO - 2016-08-03 08:14:16 --> Output Class Initialized
INFO - 2016-08-03 08:14:16 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:16 --> Input Class Initialized
INFO - 2016-08-03 08:14:16 --> Language Class Initialized
INFO - 2016-08-03 08:14:16 --> Loader Class Initialized
INFO - 2016-08-03 08:14:16 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:16 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:16 --> Controller Class Initialized
INFO - 2016-08-03 08:14:16 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:16 --> Model Class Initialized
INFO - 2016-08-03 08:14:16 --> Model Class Initialized
INFO - 2016-08-03 08:14:16 --> Model Class Initialized
INFO - 2016-08-03 08:14:16 --> Model Class Initialized
INFO - 2016-08-03 08:14:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:14:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 08:14:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:14:16 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:16 --> Total execution time: 0.0783
INFO - 2016-08-03 08:14:20 --> Config Class Initialized
INFO - 2016-08-03 08:14:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:20 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:20 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:20 --> URI Class Initialized
INFO - 2016-08-03 08:14:20 --> Router Class Initialized
INFO - 2016-08-03 08:14:20 --> Output Class Initialized
INFO - 2016-08-03 08:14:20 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:20 --> Input Class Initialized
INFO - 2016-08-03 08:14:20 --> Language Class Initialized
INFO - 2016-08-03 08:14:20 --> Loader Class Initialized
INFO - 2016-08-03 08:14:20 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:20 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:20 --> Controller Class Initialized
INFO - 2016-08-03 08:14:20 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:20 --> Model Class Initialized
INFO - 2016-08-03 08:14:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:14:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2016-08-03 08:14:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:14:20 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:20 --> Total execution time: 0.0545
INFO - 2016-08-03 08:14:20 --> Config Class Initialized
INFO - 2016-08-03 08:14:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:20 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:20 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:20 --> URI Class Initialized
INFO - 2016-08-03 08:14:20 --> Router Class Initialized
INFO - 2016-08-03 08:14:20 --> Output Class Initialized
INFO - 2016-08-03 08:14:20 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:20 --> Input Class Initialized
INFO - 2016-08-03 08:14:20 --> Language Class Initialized
INFO - 2016-08-03 08:14:20 --> Loader Class Initialized
INFO - 2016-08-03 08:14:20 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:20 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:20 --> Controller Class Initialized
INFO - 2016-08-03 08:14:20 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:20 --> Model Class Initialized
INFO - 2016-08-03 08:14:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:20 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:20 --> Total execution time: 0.0709
INFO - 2016-08-03 08:14:23 --> Config Class Initialized
INFO - 2016-08-03 08:14:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:23 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:23 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:23 --> URI Class Initialized
INFO - 2016-08-03 08:14:23 --> Router Class Initialized
INFO - 2016-08-03 08:14:23 --> Output Class Initialized
INFO - 2016-08-03 08:14:23 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:23 --> Input Class Initialized
INFO - 2016-08-03 08:14:23 --> Language Class Initialized
INFO - 2016-08-03 08:14:23 --> Loader Class Initialized
INFO - 2016-08-03 08:14:23 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:23 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:23 --> Controller Class Initialized
INFO - 2016-08-03 08:14:23 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:23 --> Model Class Initialized
INFO - 2016-08-03 08:14:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:14:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-08-03 08:14:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:14:23 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:23 --> Total execution time: 0.0551
INFO - 2016-08-03 08:14:30 --> Config Class Initialized
INFO - 2016-08-03 08:14:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:30 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:30 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:30 --> URI Class Initialized
INFO - 2016-08-03 08:14:30 --> Router Class Initialized
INFO - 2016-08-03 08:14:30 --> Output Class Initialized
INFO - 2016-08-03 08:14:30 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:30 --> Input Class Initialized
INFO - 2016-08-03 08:14:30 --> Language Class Initialized
INFO - 2016-08-03 08:14:30 --> Loader Class Initialized
INFO - 2016-08-03 08:14:30 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:30 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:30 --> Controller Class Initialized
INFO - 2016-08-03 08:14:30 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:30 --> Model Class Initialized
INFO - 2016-08-03 08:14:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:30 --> Model Class Initialized
INFO - 2016-08-03 08:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2016-08-03 08:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:14:30 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:30 --> Total execution time: 0.0604
INFO - 2016-08-03 08:14:45 --> Config Class Initialized
INFO - 2016-08-03 08:14:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:45 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:45 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:45 --> URI Class Initialized
INFO - 2016-08-03 08:14:45 --> Router Class Initialized
INFO - 2016-08-03 08:14:45 --> Output Class Initialized
INFO - 2016-08-03 08:14:45 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:45 --> Input Class Initialized
INFO - 2016-08-03 08:14:45 --> Language Class Initialized
INFO - 2016-08-03 08:14:45 --> Loader Class Initialized
INFO - 2016-08-03 08:14:45 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:45 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:45 --> Controller Class Initialized
INFO - 2016-08-03 08:14:45 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:45 --> Model Class Initialized
INFO - 2016-08-03 08:14:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:45 --> Helper loaded: form_helper
INFO - 2016-08-03 08:14:45 --> Form Validation Class Initialized
INFO - 2016-08-03 08:14:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-03 08:14:45 --> Config Class Initialized
INFO - 2016-08-03 08:14:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:45 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:45 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:45 --> URI Class Initialized
INFO - 2016-08-03 08:14:45 --> Router Class Initialized
INFO - 2016-08-03 08:14:45 --> Output Class Initialized
INFO - 2016-08-03 08:14:45 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:45 --> Input Class Initialized
INFO - 2016-08-03 08:14:45 --> Language Class Initialized
INFO - 2016-08-03 08:14:45 --> Loader Class Initialized
INFO - 2016-08-03 08:14:45 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:45 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:45 --> Controller Class Initialized
INFO - 2016-08-03 08:14:45 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:45 --> Model Class Initialized
INFO - 2016-08-03 08:14:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:45 --> Model Class Initialized
INFO - 2016-08-03 08:14:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:14:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2016-08-03 08:14:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:14:45 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:45 --> Total execution time: 0.0594
INFO - 2016-08-03 08:14:47 --> Config Class Initialized
INFO - 2016-08-03 08:14:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:47 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:47 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:47 --> URI Class Initialized
INFO - 2016-08-03 08:14:47 --> Router Class Initialized
INFO - 2016-08-03 08:14:47 --> Output Class Initialized
INFO - 2016-08-03 08:14:47 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:47 --> Input Class Initialized
INFO - 2016-08-03 08:14:47 --> Language Class Initialized
INFO - 2016-08-03 08:14:47 --> Loader Class Initialized
INFO - 2016-08-03 08:14:47 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:47 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:47 --> Controller Class Initialized
INFO - 2016-08-03 08:14:47 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:47 --> Model Class Initialized
INFO - 2016-08-03 08:14:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:47 --> Config Class Initialized
INFO - 2016-08-03 08:14:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:47 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:47 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:47 --> URI Class Initialized
INFO - 2016-08-03 08:14:47 --> Router Class Initialized
INFO - 2016-08-03 08:14:47 --> Output Class Initialized
INFO - 2016-08-03 08:14:47 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:47 --> Input Class Initialized
INFO - 2016-08-03 08:14:47 --> Language Class Initialized
INFO - 2016-08-03 08:14:47 --> Loader Class Initialized
INFO - 2016-08-03 08:14:47 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:47 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:47 --> Controller Class Initialized
INFO - 2016-08-03 08:14:47 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:47 --> Model Class Initialized
INFO - 2016-08-03 08:14:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:14:47 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:47 --> Total execution time: 0.0652
INFO - 2016-08-03 08:14:57 --> Config Class Initialized
INFO - 2016-08-03 08:14:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:57 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:57 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:57 --> URI Class Initialized
INFO - 2016-08-03 08:14:57 --> Router Class Initialized
INFO - 2016-08-03 08:14:57 --> Output Class Initialized
INFO - 2016-08-03 08:14:57 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:57 --> Input Class Initialized
INFO - 2016-08-03 08:14:57 --> Language Class Initialized
INFO - 2016-08-03 08:14:57 --> Loader Class Initialized
INFO - 2016-08-03 08:14:57 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:57 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:57 --> Controller Class Initialized
INFO - 2016-08-03 08:14:57 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:57 --> Model Class Initialized
INFO - 2016-08-03 08:14:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:57 --> Config Class Initialized
INFO - 2016-08-03 08:14:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:14:57 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:14:57 --> Utf8 Class Initialized
INFO - 2016-08-03 08:14:57 --> URI Class Initialized
INFO - 2016-08-03 08:14:57 --> Router Class Initialized
INFO - 2016-08-03 08:14:57 --> Output Class Initialized
INFO - 2016-08-03 08:14:57 --> Security Class Initialized
DEBUG - 2016-08-03 08:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:14:57 --> Input Class Initialized
INFO - 2016-08-03 08:14:57 --> Language Class Initialized
INFO - 2016-08-03 08:14:57 --> Loader Class Initialized
INFO - 2016-08-03 08:14:57 --> Helper loaded: url_helper
INFO - 2016-08-03 08:14:57 --> Helper loaded: language_helper
INFO - 2016-08-03 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:14:57 --> Controller Class Initialized
INFO - 2016-08-03 08:14:57 --> Database Driver Class Initialized
INFO - 2016-08-03 08:14:57 --> Model Class Initialized
INFO - 2016-08-03 08:14:57 --> Model Class Initialized
INFO - 2016-08-03 08:14:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:14:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:14:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:14:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:14:57 --> Final output sent to browser
DEBUG - 2016-08-03 08:14:57 --> Total execution time: 0.0604
INFO - 2016-08-03 08:15:03 --> Config Class Initialized
INFO - 2016-08-03 08:15:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:03 --> URI Class Initialized
INFO - 2016-08-03 08:15:03 --> Router Class Initialized
INFO - 2016-08-03 08:15:03 --> Output Class Initialized
INFO - 2016-08-03 08:15:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:03 --> Input Class Initialized
INFO - 2016-08-03 08:15:03 --> Language Class Initialized
INFO - 2016-08-03 08:15:03 --> Loader Class Initialized
INFO - 2016-08-03 08:15:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:03 --> Controller Class Initialized
INFO - 2016-08-03 08:15:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:03 --> Model Class Initialized
INFO - 2016-08-03 08:15:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:03 --> Config Class Initialized
INFO - 2016-08-03 08:15:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:03 --> URI Class Initialized
INFO - 2016-08-03 08:15:03 --> Router Class Initialized
INFO - 2016-08-03 08:15:03 --> Output Class Initialized
INFO - 2016-08-03 08:15:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:03 --> Input Class Initialized
INFO - 2016-08-03 08:15:03 --> Language Class Initialized
INFO - 2016-08-03 08:15:03 --> Loader Class Initialized
INFO - 2016-08-03 08:15:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:03 --> Controller Class Initialized
INFO - 2016-08-03 08:15:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:03 --> Model Class Initialized
INFO - 2016-08-03 08:15:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:15:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:15:03 --> Total execution time: 0.0504
INFO - 2016-08-03 08:15:11 --> Config Class Initialized
INFO - 2016-08-03 08:15:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:11 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:11 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:11 --> URI Class Initialized
INFO - 2016-08-03 08:15:11 --> Router Class Initialized
INFO - 2016-08-03 08:15:11 --> Output Class Initialized
INFO - 2016-08-03 08:15:11 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:11 --> Input Class Initialized
INFO - 2016-08-03 08:15:11 --> Language Class Initialized
INFO - 2016-08-03 08:15:11 --> Loader Class Initialized
INFO - 2016-08-03 08:15:11 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:11 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:11 --> Controller Class Initialized
INFO - 2016-08-03 08:15:11 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:11 --> Model Class Initialized
INFO - 2016-08-03 08:15:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:11 --> Config Class Initialized
INFO - 2016-08-03 08:15:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:11 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:11 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:11 --> URI Class Initialized
INFO - 2016-08-03 08:15:11 --> Router Class Initialized
INFO - 2016-08-03 08:15:11 --> Output Class Initialized
INFO - 2016-08-03 08:15:11 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:11 --> Input Class Initialized
INFO - 2016-08-03 08:15:11 --> Language Class Initialized
INFO - 2016-08-03 08:15:11 --> Loader Class Initialized
INFO - 2016-08-03 08:15:11 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:11 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:11 --> Controller Class Initialized
INFO - 2016-08-03 08:15:11 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:11 --> Model Class Initialized
INFO - 2016-08-03 08:15:11 --> Model Class Initialized
INFO - 2016-08-03 08:15:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:15:11 --> Final output sent to browser
DEBUG - 2016-08-03 08:15:11 --> Total execution time: 0.0553
INFO - 2016-08-03 08:15:14 --> Config Class Initialized
INFO - 2016-08-03 08:15:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:14 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:14 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:14 --> URI Class Initialized
INFO - 2016-08-03 08:15:14 --> Router Class Initialized
INFO - 2016-08-03 08:15:14 --> Output Class Initialized
INFO - 2016-08-03 08:15:14 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:14 --> Input Class Initialized
INFO - 2016-08-03 08:15:14 --> Language Class Initialized
INFO - 2016-08-03 08:15:14 --> Loader Class Initialized
INFO - 2016-08-03 08:15:14 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:14 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:14 --> Controller Class Initialized
INFO - 2016-08-03 08:15:14 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:14 --> Model Class Initialized
INFO - 2016-08-03 08:15:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:14 --> Model Class Initialized
INFO - 2016-08-03 08:15:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:15:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\myaccount.php
INFO - 2016-08-03 08:15:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:15:14 --> Final output sent to browser
DEBUG - 2016-08-03 08:15:14 --> Total execution time: 0.0606
INFO - 2016-08-03 08:15:46 --> Config Class Initialized
INFO - 2016-08-03 08:15:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:46 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:46 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:46 --> URI Class Initialized
DEBUG - 2016-08-03 08:15:46 --> No URI present. Default controller set.
INFO - 2016-08-03 08:15:46 --> Router Class Initialized
INFO - 2016-08-03 08:15:46 --> Output Class Initialized
INFO - 2016-08-03 08:15:46 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:46 --> Input Class Initialized
INFO - 2016-08-03 08:15:46 --> Language Class Initialized
INFO - 2016-08-03 08:15:46 --> Loader Class Initialized
INFO - 2016-08-03 08:15:46 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:46 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:46 --> Controller Class Initialized
INFO - 2016-08-03 08:15:46 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:46 --> Model Class Initialized
INFO - 2016-08-03 08:15:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:46 --> Config Class Initialized
INFO - 2016-08-03 08:15:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:46 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:46 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:46 --> URI Class Initialized
INFO - 2016-08-03 08:15:46 --> Router Class Initialized
INFO - 2016-08-03 08:15:46 --> Output Class Initialized
INFO - 2016-08-03 08:15:46 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:46 --> Input Class Initialized
INFO - 2016-08-03 08:15:46 --> Language Class Initialized
INFO - 2016-08-03 08:15:46 --> Loader Class Initialized
INFO - 2016-08-03 08:15:46 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:46 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:46 --> Controller Class Initialized
INFO - 2016-08-03 08:15:46 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:46 --> Model Class Initialized
INFO - 2016-08-03 08:15:46 --> Model Class Initialized
INFO - 2016-08-03 08:15:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:15:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:15:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:15:46 --> Final output sent to browser
DEBUG - 2016-08-03 08:15:46 --> Total execution time: 0.0556
INFO - 2016-08-03 08:15:50 --> Config Class Initialized
INFO - 2016-08-03 08:15:50 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:50 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:50 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:50 --> URI Class Initialized
INFO - 2016-08-03 08:15:50 --> Router Class Initialized
INFO - 2016-08-03 08:15:50 --> Output Class Initialized
INFO - 2016-08-03 08:15:50 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:50 --> Input Class Initialized
INFO - 2016-08-03 08:15:50 --> Language Class Initialized
INFO - 2016-08-03 08:15:50 --> Loader Class Initialized
INFO - 2016-08-03 08:15:50 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:50 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:50 --> Controller Class Initialized
INFO - 2016-08-03 08:15:50 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:50 --> Model Class Initialized
INFO - 2016-08-03 08:15:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:50 --> Config Class Initialized
INFO - 2016-08-03 08:15:50 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:15:50 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:15:50 --> Utf8 Class Initialized
INFO - 2016-08-03 08:15:50 --> URI Class Initialized
INFO - 2016-08-03 08:15:50 --> Router Class Initialized
INFO - 2016-08-03 08:15:50 --> Output Class Initialized
INFO - 2016-08-03 08:15:50 --> Security Class Initialized
DEBUG - 2016-08-03 08:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:15:50 --> Input Class Initialized
INFO - 2016-08-03 08:15:50 --> Language Class Initialized
INFO - 2016-08-03 08:15:50 --> Loader Class Initialized
INFO - 2016-08-03 08:15:50 --> Helper loaded: url_helper
INFO - 2016-08-03 08:15:50 --> Helper loaded: language_helper
INFO - 2016-08-03 08:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:15:50 --> Controller Class Initialized
INFO - 2016-08-03 08:15:50 --> Database Driver Class Initialized
INFO - 2016-08-03 08:15:50 --> Model Class Initialized
INFO - 2016-08-03 08:15:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:15:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:15:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:15:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:15:50 --> Final output sent to browser
DEBUG - 2016-08-03 08:15:50 --> Total execution time: 0.0495
INFO - 2016-08-03 08:23:01 --> Config Class Initialized
INFO - 2016-08-03 08:23:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:23:01 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:23:01 --> Utf8 Class Initialized
INFO - 2016-08-03 08:23:01 --> URI Class Initialized
INFO - 2016-08-03 08:23:01 --> Router Class Initialized
INFO - 2016-08-03 08:23:01 --> Output Class Initialized
INFO - 2016-08-03 08:23:01 --> Security Class Initialized
DEBUG - 2016-08-03 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:23:01 --> Input Class Initialized
INFO - 2016-08-03 08:23:01 --> Language Class Initialized
INFO - 2016-08-03 08:23:01 --> Loader Class Initialized
INFO - 2016-08-03 08:23:01 --> Helper loaded: url_helper
INFO - 2016-08-03 08:23:01 --> Helper loaded: language_helper
INFO - 2016-08-03 08:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:23:01 --> Controller Class Initialized
INFO - 2016-08-03 08:23:01 --> Database Driver Class Initialized
INFO - 2016-08-03 08:23:01 --> Model Class Initialized
INFO - 2016-08-03 08:23:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:23:01 --> Config Class Initialized
INFO - 2016-08-03 08:23:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:23:01 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:23:01 --> Utf8 Class Initialized
INFO - 2016-08-03 08:23:01 --> URI Class Initialized
INFO - 2016-08-03 08:23:01 --> Router Class Initialized
INFO - 2016-08-03 08:23:01 --> Output Class Initialized
INFO - 2016-08-03 08:23:01 --> Security Class Initialized
DEBUG - 2016-08-03 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:23:01 --> Input Class Initialized
INFO - 2016-08-03 08:23:01 --> Language Class Initialized
INFO - 2016-08-03 08:23:01 --> Loader Class Initialized
INFO - 2016-08-03 08:23:01 --> Helper loaded: url_helper
INFO - 2016-08-03 08:23:01 --> Helper loaded: language_helper
INFO - 2016-08-03 08:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:23:01 --> Controller Class Initialized
INFO - 2016-08-03 08:23:01 --> Database Driver Class Initialized
INFO - 2016-08-03 08:23:01 --> Model Class Initialized
INFO - 2016-08-03 08:23:01 --> Model Class Initialized
INFO - 2016-08-03 08:23:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:23:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:23:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:23:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:23:01 --> Final output sent to browser
DEBUG - 2016-08-03 08:23:01 --> Total execution time: 0.0565
INFO - 2016-08-03 08:23:16 --> Config Class Initialized
INFO - 2016-08-03 08:23:16 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:23:16 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:23:16 --> Utf8 Class Initialized
INFO - 2016-08-03 08:23:16 --> URI Class Initialized
INFO - 2016-08-03 08:23:16 --> Router Class Initialized
INFO - 2016-08-03 08:23:16 --> Output Class Initialized
INFO - 2016-08-03 08:23:16 --> Security Class Initialized
DEBUG - 2016-08-03 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:23:16 --> Input Class Initialized
INFO - 2016-08-03 08:23:16 --> Language Class Initialized
INFO - 2016-08-03 08:23:16 --> Loader Class Initialized
INFO - 2016-08-03 08:23:16 --> Helper loaded: url_helper
INFO - 2016-08-03 08:23:16 --> Helper loaded: language_helper
INFO - 2016-08-03 08:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:23:16 --> Controller Class Initialized
INFO - 2016-08-03 08:23:16 --> Database Driver Class Initialized
INFO - 2016-08-03 08:23:16 --> Model Class Initialized
INFO - 2016-08-03 08:23:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:23:16 --> Model Class Initialized
INFO - 2016-08-03 08:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\myaccount.php
INFO - 2016-08-03 08:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:23:16 --> Final output sent to browser
DEBUG - 2016-08-03 08:23:16 --> Total execution time: 0.0572
INFO - 2016-08-03 08:24:25 --> Config Class Initialized
INFO - 2016-08-03 08:24:25 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:24:25 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:24:25 --> Utf8 Class Initialized
INFO - 2016-08-03 08:24:25 --> URI Class Initialized
DEBUG - 2016-08-03 08:24:25 --> No URI present. Default controller set.
INFO - 2016-08-03 08:24:25 --> Router Class Initialized
INFO - 2016-08-03 08:24:25 --> Output Class Initialized
INFO - 2016-08-03 08:24:25 --> Security Class Initialized
DEBUG - 2016-08-03 08:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:24:25 --> Input Class Initialized
INFO - 2016-08-03 08:24:25 --> Language Class Initialized
INFO - 2016-08-03 08:24:25 --> Loader Class Initialized
INFO - 2016-08-03 08:24:25 --> Helper loaded: url_helper
INFO - 2016-08-03 08:24:25 --> Helper loaded: language_helper
INFO - 2016-08-03 08:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:24:25 --> Controller Class Initialized
INFO - 2016-08-03 08:24:25 --> Database Driver Class Initialized
INFO - 2016-08-03 08:24:25 --> Model Class Initialized
INFO - 2016-08-03 08:24:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:24:25 --> Config Class Initialized
INFO - 2016-08-03 08:24:25 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:24:25 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:24:25 --> Utf8 Class Initialized
INFO - 2016-08-03 08:24:25 --> URI Class Initialized
INFO - 2016-08-03 08:24:25 --> Router Class Initialized
INFO - 2016-08-03 08:24:25 --> Output Class Initialized
INFO - 2016-08-03 08:24:25 --> Security Class Initialized
DEBUG - 2016-08-03 08:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:24:25 --> Input Class Initialized
INFO - 2016-08-03 08:24:25 --> Language Class Initialized
INFO - 2016-08-03 08:24:25 --> Loader Class Initialized
INFO - 2016-08-03 08:24:25 --> Helper loaded: url_helper
INFO - 2016-08-03 08:24:25 --> Helper loaded: language_helper
INFO - 2016-08-03 08:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:24:25 --> Controller Class Initialized
INFO - 2016-08-03 08:24:25 --> Database Driver Class Initialized
INFO - 2016-08-03 08:24:25 --> Model Class Initialized
INFO - 2016-08-03 08:24:25 --> Model Class Initialized
INFO - 2016-08-03 08:24:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:24:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:24:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:24:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:24:25 --> Final output sent to browser
DEBUG - 2016-08-03 08:24:25 --> Total execution time: 0.0545
INFO - 2016-08-03 08:24:27 --> Config Class Initialized
INFO - 2016-08-03 08:24:27 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:24:27 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:24:27 --> Utf8 Class Initialized
INFO - 2016-08-03 08:24:27 --> URI Class Initialized
INFO - 2016-08-03 08:24:27 --> Router Class Initialized
INFO - 2016-08-03 08:24:27 --> Output Class Initialized
INFO - 2016-08-03 08:24:27 --> Security Class Initialized
DEBUG - 2016-08-03 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:24:27 --> Input Class Initialized
INFO - 2016-08-03 08:24:27 --> Language Class Initialized
INFO - 2016-08-03 08:24:27 --> Loader Class Initialized
INFO - 2016-08-03 08:24:27 --> Helper loaded: url_helper
INFO - 2016-08-03 08:24:27 --> Helper loaded: language_helper
INFO - 2016-08-03 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:24:27 --> Controller Class Initialized
INFO - 2016-08-03 08:24:27 --> Database Driver Class Initialized
INFO - 2016-08-03 08:24:27 --> Model Class Initialized
INFO - 2016-08-03 08:24:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:24:27 --> Model Class Initialized
INFO - 2016-08-03 08:24:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:24:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\myaccount.php
INFO - 2016-08-03 08:24:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:24:27 --> Final output sent to browser
DEBUG - 2016-08-03 08:24:27 --> Total execution time: 0.0578
INFO - 2016-08-03 08:24:36 --> Config Class Initialized
INFO - 2016-08-03 08:24:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:24:36 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:24:36 --> Utf8 Class Initialized
INFO - 2016-08-03 08:24:36 --> URI Class Initialized
DEBUG - 2016-08-03 08:24:36 --> No URI present. Default controller set.
INFO - 2016-08-03 08:24:36 --> Router Class Initialized
INFO - 2016-08-03 08:24:36 --> Output Class Initialized
INFO - 2016-08-03 08:24:36 --> Security Class Initialized
DEBUG - 2016-08-03 08:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:24:36 --> Input Class Initialized
INFO - 2016-08-03 08:24:36 --> Language Class Initialized
INFO - 2016-08-03 08:24:36 --> Loader Class Initialized
INFO - 2016-08-03 08:24:36 --> Helper loaded: url_helper
INFO - 2016-08-03 08:24:36 --> Helper loaded: language_helper
INFO - 2016-08-03 08:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:24:36 --> Controller Class Initialized
INFO - 2016-08-03 08:24:36 --> Database Driver Class Initialized
INFO - 2016-08-03 08:24:36 --> Model Class Initialized
INFO - 2016-08-03 08:24:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:24:36 --> Config Class Initialized
INFO - 2016-08-03 08:24:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:24:36 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:24:36 --> Utf8 Class Initialized
INFO - 2016-08-03 08:24:36 --> URI Class Initialized
INFO - 2016-08-03 08:24:36 --> Router Class Initialized
INFO - 2016-08-03 08:24:36 --> Output Class Initialized
INFO - 2016-08-03 08:24:36 --> Security Class Initialized
DEBUG - 2016-08-03 08:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:24:36 --> Input Class Initialized
INFO - 2016-08-03 08:24:36 --> Language Class Initialized
INFO - 2016-08-03 08:24:36 --> Loader Class Initialized
INFO - 2016-08-03 08:24:36 --> Helper loaded: url_helper
INFO - 2016-08-03 08:24:36 --> Helper loaded: language_helper
INFO - 2016-08-03 08:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:24:36 --> Controller Class Initialized
INFO - 2016-08-03 08:24:36 --> Database Driver Class Initialized
INFO - 2016-08-03 08:24:36 --> Model Class Initialized
INFO - 2016-08-03 08:24:36 --> Model Class Initialized
INFO - 2016-08-03 08:24:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:24:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:24:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:24:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:24:36 --> Final output sent to browser
DEBUG - 2016-08-03 08:24:36 --> Total execution time: 0.0559
INFO - 2016-08-03 08:24:54 --> Config Class Initialized
INFO - 2016-08-03 08:24:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:24:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:24:54 --> Utf8 Class Initialized
INFO - 2016-08-03 08:24:54 --> URI Class Initialized
INFO - 2016-08-03 08:24:54 --> Router Class Initialized
INFO - 2016-08-03 08:24:54 --> Output Class Initialized
INFO - 2016-08-03 08:24:54 --> Security Class Initialized
DEBUG - 2016-08-03 08:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:24:54 --> Input Class Initialized
INFO - 2016-08-03 08:24:54 --> Language Class Initialized
INFO - 2016-08-03 08:24:54 --> Loader Class Initialized
INFO - 2016-08-03 08:24:54 --> Helper loaded: url_helper
INFO - 2016-08-03 08:24:54 --> Helper loaded: language_helper
INFO - 2016-08-03 08:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:24:54 --> Controller Class Initialized
INFO - 2016-08-03 08:24:54 --> Database Driver Class Initialized
INFO - 2016-08-03 08:24:54 --> Model Class Initialized
INFO - 2016-08-03 08:24:54 --> Model Class Initialized
INFO - 2016-08-03 08:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-08-03 08:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:24:54 --> Final output sent to browser
DEBUG - 2016-08-03 08:24:54 --> Total execution time: 0.0566
INFO - 2016-08-03 08:34:51 --> Config Class Initialized
INFO - 2016-08-03 08:34:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:34:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:34:51 --> Utf8 Class Initialized
INFO - 2016-08-03 08:34:51 --> URI Class Initialized
INFO - 2016-08-03 08:34:51 --> Router Class Initialized
INFO - 2016-08-03 08:34:51 --> Output Class Initialized
INFO - 2016-08-03 08:34:51 --> Security Class Initialized
DEBUG - 2016-08-03 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:34:51 --> Input Class Initialized
INFO - 2016-08-03 08:34:51 --> Language Class Initialized
INFO - 2016-08-03 08:34:51 --> Loader Class Initialized
INFO - 2016-08-03 08:34:51 --> Helper loaded: url_helper
INFO - 2016-08-03 08:34:51 --> Helper loaded: language_helper
INFO - 2016-08-03 08:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:34:51 --> Controller Class Initialized
INFO - 2016-08-03 08:34:51 --> Database Driver Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:34:51 --> Config Class Initialized
INFO - 2016-08-03 08:34:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:34:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:34:51 --> Utf8 Class Initialized
INFO - 2016-08-03 08:34:51 --> URI Class Initialized
INFO - 2016-08-03 08:34:51 --> Router Class Initialized
INFO - 2016-08-03 08:34:51 --> Output Class Initialized
INFO - 2016-08-03 08:34:51 --> Security Class Initialized
DEBUG - 2016-08-03 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:34:51 --> Input Class Initialized
INFO - 2016-08-03 08:34:51 --> Language Class Initialized
INFO - 2016-08-03 08:34:51 --> Loader Class Initialized
INFO - 2016-08-03 08:34:51 --> Helper loaded: url_helper
INFO - 2016-08-03 08:34:51 --> Helper loaded: language_helper
INFO - 2016-08-03 08:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:34:51 --> Controller Class Initialized
INFO - 2016-08-03 08:34:51 --> Database Driver Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:34:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:34:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-03 08:34:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:34:51 --> Final output sent to browser
DEBUG - 2016-08-03 08:34:51 --> Total execution time: 0.0647
INFO - 2016-08-03 08:34:51 --> Config Class Initialized
INFO - 2016-08-03 08:34:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:34:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:34:51 --> Utf8 Class Initialized
INFO - 2016-08-03 08:34:51 --> URI Class Initialized
INFO - 2016-08-03 08:34:51 --> Router Class Initialized
INFO - 2016-08-03 08:34:51 --> Output Class Initialized
INFO - 2016-08-03 08:34:51 --> Config Class Initialized
INFO - 2016-08-03 08:34:51 --> Hooks Class Initialized
INFO - 2016-08-03 08:34:51 --> Security Class Initialized
DEBUG - 2016-08-03 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:34:51 --> Input Class Initialized
DEBUG - 2016-08-03 08:34:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:34:51 --> Utf8 Class Initialized
INFO - 2016-08-03 08:34:51 --> Language Class Initialized
INFO - 2016-08-03 08:34:51 --> URI Class Initialized
INFO - 2016-08-03 08:34:51 --> Loader Class Initialized
INFO - 2016-08-03 08:34:51 --> Router Class Initialized
INFO - 2016-08-03 08:34:51 --> Helper loaded: url_helper
INFO - 2016-08-03 08:34:51 --> Helper loaded: language_helper
INFO - 2016-08-03 08:34:51 --> Output Class Initialized
INFO - 2016-08-03 08:34:51 --> Security Class Initialized
INFO - 2016-08-03 08:34:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-08-03 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:34:51 --> Controller Class Initialized
INFO - 2016-08-03 08:34:51 --> Input Class Initialized
INFO - 2016-08-03 08:34:51 --> Language Class Initialized
INFO - 2016-08-03 08:34:51 --> Loader Class Initialized
INFO - 2016-08-03 08:34:51 --> Helper loaded: url_helper
INFO - 2016-08-03 08:34:51 --> Helper loaded: language_helper
INFO - 2016-08-03 08:34:51 --> Database Driver Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:34:51 --> Final output sent to browser
DEBUG - 2016-08-03 08:34:51 --> Total execution time: 0.0815
INFO - 2016-08-03 08:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:34:51 --> Controller Class Initialized
INFO - 2016-08-03 08:34:51 --> Database Driver Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Model Class Initialized
INFO - 2016-08-03 08:34:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:34:51 --> Final output sent to browser
DEBUG - 2016-08-03 08:34:51 --> Total execution time: 0.1089
INFO - 2016-08-03 08:35:05 --> Config Class Initialized
INFO - 2016-08-03 08:35:05 --> Hooks Class Initialized
INFO - 2016-08-03 08:35:05 --> Config Class Initialized
INFO - 2016-08-03 08:35:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:35:05 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:35:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 08:35:05 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:35:05 --> Utf8 Class Initialized
INFO - 2016-08-03 08:35:05 --> URI Class Initialized
INFO - 2016-08-03 08:35:05 --> URI Class Initialized
INFO - 2016-08-03 08:35:05 --> Router Class Initialized
INFO - 2016-08-03 08:35:05 --> Router Class Initialized
INFO - 2016-08-03 08:35:05 --> Output Class Initialized
INFO - 2016-08-03 08:35:05 --> Output Class Initialized
INFO - 2016-08-03 08:35:05 --> Security Class Initialized
INFO - 2016-08-03 08:35:05 --> Security Class Initialized
DEBUG - 2016-08-03 08:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:35:05 --> Input Class Initialized
DEBUG - 2016-08-03 08:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:35:05 --> Input Class Initialized
INFO - 2016-08-03 08:35:05 --> Language Class Initialized
INFO - 2016-08-03 08:35:05 --> Language Class Initialized
INFO - 2016-08-03 08:35:05 --> Loader Class Initialized
INFO - 2016-08-03 08:35:05 --> Loader Class Initialized
INFO - 2016-08-03 08:35:05 --> Helper loaded: url_helper
INFO - 2016-08-03 08:35:05 --> Helper loaded: language_helper
INFO - 2016-08-03 08:35:05 --> Helper loaded: url_helper
INFO - 2016-08-03 08:35:05 --> Helper loaded: language_helper
INFO - 2016-08-03 08:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:35:05 --> Controller Class Initialized
INFO - 2016-08-03 08:35:05 --> Database Driver Class Initialized
INFO - 2016-08-03 08:35:05 --> Model Class Initialized
INFO - 2016-08-03 08:35:05 --> Model Class Initialized
INFO - 2016-08-03 08:35:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:35:05 --> Final output sent to browser
DEBUG - 2016-08-03 08:35:05 --> Total execution time: 0.0598
INFO - 2016-08-03 08:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:35:05 --> Controller Class Initialized
INFO - 2016-08-03 08:35:05 --> Database Driver Class Initialized
INFO - 2016-08-03 08:35:05 --> Model Class Initialized
INFO - 2016-08-03 08:35:05 --> Model Class Initialized
INFO - 2016-08-03 08:35:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:35:05 --> Final output sent to browser
DEBUG - 2016-08-03 08:35:05 --> Total execution time: 0.0831
INFO - 2016-08-03 08:35:21 --> Config Class Initialized
INFO - 2016-08-03 08:35:21 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:35:21 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:35:21 --> Utf8 Class Initialized
INFO - 2016-08-03 08:35:21 --> URI Class Initialized
INFO - 2016-08-03 08:35:21 --> Router Class Initialized
INFO - 2016-08-03 08:35:21 --> Output Class Initialized
INFO - 2016-08-03 08:35:21 --> Security Class Initialized
DEBUG - 2016-08-03 08:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:35:21 --> Input Class Initialized
INFO - 2016-08-03 08:35:21 --> Language Class Initialized
INFO - 2016-08-03 08:35:21 --> Loader Class Initialized
INFO - 2016-08-03 08:35:21 --> Helper loaded: url_helper
INFO - 2016-08-03 08:35:21 --> Helper loaded: language_helper
INFO - 2016-08-03 08:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:35:21 --> Controller Class Initialized
INFO - 2016-08-03 08:35:21 --> Database Driver Class Initialized
INFO - 2016-08-03 08:35:21 --> Model Class Initialized
INFO - 2016-08-03 08:35:21 --> Model Class Initialized
INFO - 2016-08-03 08:35:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:35:21 --> Final output sent to browser
DEBUG - 2016-08-03 08:35:21 --> Total execution time: 0.0520
INFO - 2016-08-03 08:35:51 --> Config Class Initialized
INFO - 2016-08-03 08:35:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:35:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:35:51 --> Utf8 Class Initialized
INFO - 2016-08-03 08:35:51 --> URI Class Initialized
INFO - 2016-08-03 08:35:51 --> Router Class Initialized
INFO - 2016-08-03 08:35:51 --> Output Class Initialized
INFO - 2016-08-03 08:35:51 --> Security Class Initialized
DEBUG - 2016-08-03 08:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:35:51 --> Input Class Initialized
INFO - 2016-08-03 08:35:51 --> Language Class Initialized
INFO - 2016-08-03 08:35:51 --> Loader Class Initialized
INFO - 2016-08-03 08:35:51 --> Helper loaded: url_helper
INFO - 2016-08-03 08:35:51 --> Helper loaded: language_helper
INFO - 2016-08-03 08:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:35:51 --> Controller Class Initialized
INFO - 2016-08-03 08:35:51 --> Database Driver Class Initialized
INFO - 2016-08-03 08:35:51 --> Model Class Initialized
INFO - 2016-08-03 08:35:51 --> Model Class Initialized
INFO - 2016-08-03 08:35:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:35:51 --> Final output sent to browser
DEBUG - 2016-08-03 08:35:51 --> Total execution time: 0.0509
INFO - 2016-08-03 08:36:21 --> Config Class Initialized
INFO - 2016-08-03 08:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:36:21 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:36:21 --> Utf8 Class Initialized
INFO - 2016-08-03 08:36:21 --> URI Class Initialized
INFO - 2016-08-03 08:36:21 --> Router Class Initialized
INFO - 2016-08-03 08:36:21 --> Output Class Initialized
INFO - 2016-08-03 08:36:21 --> Security Class Initialized
DEBUG - 2016-08-03 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:36:21 --> Input Class Initialized
INFO - 2016-08-03 08:36:21 --> Language Class Initialized
INFO - 2016-08-03 08:36:21 --> Loader Class Initialized
INFO - 2016-08-03 08:36:21 --> Helper loaded: url_helper
INFO - 2016-08-03 08:36:21 --> Helper loaded: language_helper
INFO - 2016-08-03 08:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:36:21 --> Controller Class Initialized
INFO - 2016-08-03 08:36:21 --> Database Driver Class Initialized
INFO - 2016-08-03 08:36:21 --> Model Class Initialized
INFO - 2016-08-03 08:36:21 --> Model Class Initialized
INFO - 2016-08-03 08:36:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:36:21 --> Final output sent to browser
DEBUG - 2016-08-03 08:36:21 --> Total execution time: 0.0649
INFO - 2016-08-03 08:36:51 --> Config Class Initialized
INFO - 2016-08-03 08:36:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:36:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:36:51 --> Utf8 Class Initialized
INFO - 2016-08-03 08:36:51 --> URI Class Initialized
INFO - 2016-08-03 08:36:51 --> Router Class Initialized
INFO - 2016-08-03 08:36:51 --> Output Class Initialized
INFO - 2016-08-03 08:36:51 --> Security Class Initialized
DEBUG - 2016-08-03 08:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:36:51 --> Input Class Initialized
INFO - 2016-08-03 08:36:51 --> Language Class Initialized
INFO - 2016-08-03 08:36:51 --> Loader Class Initialized
INFO - 2016-08-03 08:36:51 --> Helper loaded: url_helper
INFO - 2016-08-03 08:36:51 --> Helper loaded: language_helper
INFO - 2016-08-03 08:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:36:51 --> Controller Class Initialized
INFO - 2016-08-03 08:36:51 --> Database Driver Class Initialized
INFO - 2016-08-03 08:36:51 --> Model Class Initialized
INFO - 2016-08-03 08:36:51 --> Model Class Initialized
INFO - 2016-08-03 08:36:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:36:51 --> Final output sent to browser
DEBUG - 2016-08-03 08:36:51 --> Total execution time: 0.0548
INFO - 2016-08-03 08:37:15 --> Config Class Initialized
INFO - 2016-08-03 08:37:15 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:37:15 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:37:15 --> Utf8 Class Initialized
INFO - 2016-08-03 08:37:15 --> URI Class Initialized
DEBUG - 2016-08-03 08:37:15 --> No URI present. Default controller set.
INFO - 2016-08-03 08:37:15 --> Router Class Initialized
INFO - 2016-08-03 08:37:15 --> Output Class Initialized
INFO - 2016-08-03 08:37:15 --> Security Class Initialized
DEBUG - 2016-08-03 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:37:15 --> Input Class Initialized
INFO - 2016-08-03 08:37:15 --> Language Class Initialized
INFO - 2016-08-03 08:37:15 --> Loader Class Initialized
INFO - 2016-08-03 08:37:15 --> Helper loaded: url_helper
INFO - 2016-08-03 08:37:15 --> Helper loaded: language_helper
INFO - 2016-08-03 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:37:15 --> Controller Class Initialized
INFO - 2016-08-03 08:37:15 --> Database Driver Class Initialized
INFO - 2016-08-03 08:37:15 --> Model Class Initialized
INFO - 2016-08-03 08:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:37:15 --> Config Class Initialized
INFO - 2016-08-03 08:37:15 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:37:15 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:37:15 --> Utf8 Class Initialized
INFO - 2016-08-03 08:37:15 --> URI Class Initialized
INFO - 2016-08-03 08:37:15 --> Router Class Initialized
INFO - 2016-08-03 08:37:15 --> Output Class Initialized
INFO - 2016-08-03 08:37:15 --> Security Class Initialized
DEBUG - 2016-08-03 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:37:15 --> Input Class Initialized
INFO - 2016-08-03 08:37:15 --> Language Class Initialized
INFO - 2016-08-03 08:37:15 --> Loader Class Initialized
INFO - 2016-08-03 08:37:15 --> Helper loaded: url_helper
INFO - 2016-08-03 08:37:15 --> Helper loaded: language_helper
INFO - 2016-08-03 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:37:15 --> Controller Class Initialized
INFO - 2016-08-03 08:37:15 --> Database Driver Class Initialized
INFO - 2016-08-03 08:37:15 --> Model Class Initialized
INFO - 2016-08-03 08:37:15 --> Model Class Initialized
INFO - 2016-08-03 08:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:37:15 --> Final output sent to browser
DEBUG - 2016-08-03 08:37:15 --> Total execution time: 0.0608
INFO - 2016-08-03 08:51:01 --> Config Class Initialized
INFO - 2016-08-03 08:51:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:51:01 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:01 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:01 --> URI Class Initialized
INFO - 2016-08-03 08:51:01 --> Router Class Initialized
INFO - 2016-08-03 08:51:01 --> Output Class Initialized
INFO - 2016-08-03 08:51:01 --> Security Class Initialized
DEBUG - 2016-08-03 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:01 --> Input Class Initialized
INFO - 2016-08-03 08:51:01 --> Language Class Initialized
INFO - 2016-08-03 08:51:01 --> Loader Class Initialized
INFO - 2016-08-03 08:51:01 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:01 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:01 --> Controller Class Initialized
INFO - 2016-08-03 08:51:01 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:01 --> Model Class Initialized
INFO - 2016-08-03 08:51:01 --> Model Class Initialized
INFO - 2016-08-03 08:51:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-08-03 08:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:51:01 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:01 --> Total execution time: 0.0615
INFO - 2016-08-03 08:51:03 --> Config Class Initialized
INFO - 2016-08-03 08:51:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:51:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:03 --> URI Class Initialized
INFO - 2016-08-03 08:51:03 --> Router Class Initialized
INFO - 2016-08-03 08:51:03 --> Output Class Initialized
INFO - 2016-08-03 08:51:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:03 --> Input Class Initialized
INFO - 2016-08-03 08:51:03 --> Language Class Initialized
INFO - 2016-08-03 08:51:03 --> Loader Class Initialized
INFO - 2016-08-03 08:51:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:03 --> Controller Class Initialized
INFO - 2016-08-03 08:51:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:03 --> Config Class Initialized
INFO - 2016-08-03 08:51:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:51:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:03 --> URI Class Initialized
INFO - 2016-08-03 08:51:03 --> Router Class Initialized
INFO - 2016-08-03 08:51:03 --> Output Class Initialized
INFO - 2016-08-03 08:51:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:03 --> Input Class Initialized
INFO - 2016-08-03 08:51:03 --> Language Class Initialized
INFO - 2016-08-03 08:51:03 --> Loader Class Initialized
INFO - 2016-08-03 08:51:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:03 --> Controller Class Initialized
INFO - 2016-08-03 08:51:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:51:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-03 08:51:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:51:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:03 --> Total execution time: 0.0658
INFO - 2016-08-03 08:51:03 --> Config Class Initialized
INFO - 2016-08-03 08:51:03 --> Hooks Class Initialized
INFO - 2016-08-03 08:51:03 --> Config Class Initialized
INFO - 2016-08-03 08:51:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:51:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:03 --> URI Class Initialized
DEBUG - 2016-08-03 08:51:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:03 --> Router Class Initialized
INFO - 2016-08-03 08:51:03 --> Output Class Initialized
INFO - 2016-08-03 08:51:03 --> URI Class Initialized
INFO - 2016-08-03 08:51:03 --> Router Class Initialized
INFO - 2016-08-03 08:51:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:03 --> Input Class Initialized
INFO - 2016-08-03 08:51:03 --> Output Class Initialized
INFO - 2016-08-03 08:51:03 --> Language Class Initialized
INFO - 2016-08-03 08:51:03 --> Security Class Initialized
INFO - 2016-08-03 08:51:03 --> Loader Class Initialized
DEBUG - 2016-08-03 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:03 --> Input Class Initialized
INFO - 2016-08-03 08:51:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:03 --> Language Class Initialized
INFO - 2016-08-03 08:51:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:03 --> Loader Class Initialized
INFO - 2016-08-03 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:03 --> Controller Class Initialized
INFO - 2016-08-03 08:51:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:03 --> Total execution time: 0.0801
INFO - 2016-08-03 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:03 --> Controller Class Initialized
INFO - 2016-08-03 08:51:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Model Class Initialized
INFO - 2016-08-03 08:51:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:04 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:04 --> Total execution time: 0.1158
INFO - 2016-08-03 08:51:33 --> Config Class Initialized
INFO - 2016-08-03 08:51:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:51:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:33 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:33 --> URI Class Initialized
INFO - 2016-08-03 08:51:33 --> Router Class Initialized
INFO - 2016-08-03 08:51:33 --> Output Class Initialized
INFO - 2016-08-03 08:51:33 --> Security Class Initialized
DEBUG - 2016-08-03 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:33 --> Input Class Initialized
INFO - 2016-08-03 08:51:33 --> Language Class Initialized
INFO - 2016-08-03 08:51:33 --> Loader Class Initialized
INFO - 2016-08-03 08:51:33 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:33 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:33 --> Controller Class Initialized
INFO - 2016-08-03 08:51:33 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:33 --> Model Class Initialized
INFO - 2016-08-03 08:51:33 --> Model Class Initialized
INFO - 2016-08-03 08:51:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:33 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:33 --> Total execution time: 0.0556
INFO - 2016-08-03 08:51:46 --> Config Class Initialized
INFO - 2016-08-03 08:51:46 --> Hooks Class Initialized
INFO - 2016-08-03 08:51:46 --> Config Class Initialized
INFO - 2016-08-03 08:51:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:51:46 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 08:51:46 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:51:46 --> URI Class Initialized
INFO - 2016-08-03 08:51:46 --> Utf8 Class Initialized
INFO - 2016-08-03 08:51:46 --> Router Class Initialized
INFO - 2016-08-03 08:51:46 --> URI Class Initialized
INFO - 2016-08-03 08:51:46 --> Router Class Initialized
INFO - 2016-08-03 08:51:46 --> Output Class Initialized
INFO - 2016-08-03 08:51:46 --> Output Class Initialized
INFO - 2016-08-03 08:51:46 --> Security Class Initialized
DEBUG - 2016-08-03 08:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:46 --> Security Class Initialized
INFO - 2016-08-03 08:51:46 --> Input Class Initialized
INFO - 2016-08-03 08:51:46 --> Language Class Initialized
DEBUG - 2016-08-03 08:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:51:46 --> Input Class Initialized
INFO - 2016-08-03 08:51:46 --> Language Class Initialized
INFO - 2016-08-03 08:51:46 --> Loader Class Initialized
INFO - 2016-08-03 08:51:46 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:46 --> Loader Class Initialized
INFO - 2016-08-03 08:51:46 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:46 --> Helper loaded: url_helper
INFO - 2016-08-03 08:51:46 --> Helper loaded: language_helper
INFO - 2016-08-03 08:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:46 --> Controller Class Initialized
INFO - 2016-08-03 08:51:46 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:46 --> Model Class Initialized
INFO - 2016-08-03 08:51:46 --> Model Class Initialized
INFO - 2016-08-03 08:51:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:46 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:46 --> Total execution time: 0.0775
INFO - 2016-08-03 08:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:51:46 --> Controller Class Initialized
INFO - 2016-08-03 08:51:46 --> Database Driver Class Initialized
INFO - 2016-08-03 08:51:46 --> Model Class Initialized
INFO - 2016-08-03 08:51:46 --> Model Class Initialized
INFO - 2016-08-03 08:51:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:51:46 --> Final output sent to browser
DEBUG - 2016-08-03 08:51:46 --> Total execution time: 0.1022
INFO - 2016-08-03 08:52:03 --> Config Class Initialized
INFO - 2016-08-03 08:52:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:52:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:52:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:52:03 --> URI Class Initialized
INFO - 2016-08-03 08:52:03 --> Router Class Initialized
INFO - 2016-08-03 08:52:03 --> Output Class Initialized
INFO - 2016-08-03 08:52:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:52:03 --> Input Class Initialized
INFO - 2016-08-03 08:52:03 --> Language Class Initialized
INFO - 2016-08-03 08:52:03 --> Loader Class Initialized
INFO - 2016-08-03 08:52:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:52:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:52:03 --> Controller Class Initialized
INFO - 2016-08-03 08:52:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:52:03 --> Model Class Initialized
INFO - 2016-08-03 08:52:03 --> Model Class Initialized
INFO - 2016-08-03 08:52:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:52:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:52:03 --> Total execution time: 0.0507
INFO - 2016-08-03 08:52:33 --> Config Class Initialized
INFO - 2016-08-03 08:52:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:52:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:52:33 --> Utf8 Class Initialized
INFO - 2016-08-03 08:52:33 --> URI Class Initialized
INFO - 2016-08-03 08:52:33 --> Router Class Initialized
INFO - 2016-08-03 08:52:33 --> Output Class Initialized
INFO - 2016-08-03 08:52:33 --> Security Class Initialized
DEBUG - 2016-08-03 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:52:33 --> Input Class Initialized
INFO - 2016-08-03 08:52:33 --> Language Class Initialized
INFO - 2016-08-03 08:52:33 --> Loader Class Initialized
INFO - 2016-08-03 08:52:33 --> Helper loaded: url_helper
INFO - 2016-08-03 08:52:33 --> Helper loaded: language_helper
INFO - 2016-08-03 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:52:33 --> Controller Class Initialized
INFO - 2016-08-03 08:52:33 --> Database Driver Class Initialized
INFO - 2016-08-03 08:52:33 --> Model Class Initialized
INFO - 2016-08-03 08:52:33 --> Model Class Initialized
INFO - 2016-08-03 08:52:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:52:33 --> Final output sent to browser
DEBUG - 2016-08-03 08:52:33 --> Total execution time: 0.0518
INFO - 2016-08-03 08:53:03 --> Config Class Initialized
INFO - 2016-08-03 08:53:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:53:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:53:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:53:03 --> URI Class Initialized
INFO - 2016-08-03 08:53:03 --> Router Class Initialized
INFO - 2016-08-03 08:53:03 --> Output Class Initialized
INFO - 2016-08-03 08:53:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:53:03 --> Input Class Initialized
INFO - 2016-08-03 08:53:03 --> Language Class Initialized
INFO - 2016-08-03 08:53:03 --> Loader Class Initialized
INFO - 2016-08-03 08:53:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:53:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:53:03 --> Controller Class Initialized
INFO - 2016-08-03 08:53:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:53:03 --> Model Class Initialized
INFO - 2016-08-03 08:53:03 --> Model Class Initialized
INFO - 2016-08-03 08:53:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:53:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:53:03 --> Total execution time: 0.0516
INFO - 2016-08-03 08:53:33 --> Config Class Initialized
INFO - 2016-08-03 08:53:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:53:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:53:33 --> Utf8 Class Initialized
INFO - 2016-08-03 08:53:33 --> URI Class Initialized
INFO - 2016-08-03 08:53:33 --> Router Class Initialized
INFO - 2016-08-03 08:53:33 --> Output Class Initialized
INFO - 2016-08-03 08:53:33 --> Security Class Initialized
DEBUG - 2016-08-03 08:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:53:33 --> Input Class Initialized
INFO - 2016-08-03 08:53:33 --> Language Class Initialized
INFO - 2016-08-03 08:53:33 --> Loader Class Initialized
INFO - 2016-08-03 08:53:33 --> Helper loaded: url_helper
INFO - 2016-08-03 08:53:33 --> Helper loaded: language_helper
INFO - 2016-08-03 08:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:53:33 --> Controller Class Initialized
INFO - 2016-08-03 08:53:33 --> Database Driver Class Initialized
INFO - 2016-08-03 08:53:33 --> Model Class Initialized
INFO - 2016-08-03 08:53:33 --> Model Class Initialized
INFO - 2016-08-03 08:53:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:53:33 --> Final output sent to browser
DEBUG - 2016-08-03 08:53:33 --> Total execution time: 0.0510
INFO - 2016-08-03 08:54:03 --> Config Class Initialized
INFO - 2016-08-03 08:54:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:54:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:54:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:54:03 --> URI Class Initialized
INFO - 2016-08-03 08:54:03 --> Router Class Initialized
INFO - 2016-08-03 08:54:03 --> Output Class Initialized
INFO - 2016-08-03 08:54:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:54:03 --> Input Class Initialized
INFO - 2016-08-03 08:54:03 --> Language Class Initialized
INFO - 2016-08-03 08:54:03 --> Loader Class Initialized
INFO - 2016-08-03 08:54:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:54:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:54:03 --> Controller Class Initialized
INFO - 2016-08-03 08:54:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:54:03 --> Model Class Initialized
INFO - 2016-08-03 08:54:03 --> Model Class Initialized
INFO - 2016-08-03 08:54:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:54:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:54:03 --> Total execution time: 0.0503
INFO - 2016-08-03 08:54:33 --> Config Class Initialized
INFO - 2016-08-03 08:54:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:54:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:54:33 --> Utf8 Class Initialized
INFO - 2016-08-03 08:54:33 --> URI Class Initialized
INFO - 2016-08-03 08:54:33 --> Router Class Initialized
INFO - 2016-08-03 08:54:33 --> Output Class Initialized
INFO - 2016-08-03 08:54:33 --> Security Class Initialized
DEBUG - 2016-08-03 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:54:33 --> Input Class Initialized
INFO - 2016-08-03 08:54:33 --> Language Class Initialized
INFO - 2016-08-03 08:54:33 --> Loader Class Initialized
INFO - 2016-08-03 08:54:33 --> Helper loaded: url_helper
INFO - 2016-08-03 08:54:33 --> Helper loaded: language_helper
INFO - 2016-08-03 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:54:33 --> Controller Class Initialized
INFO - 2016-08-03 08:54:33 --> Database Driver Class Initialized
INFO - 2016-08-03 08:54:33 --> Model Class Initialized
INFO - 2016-08-03 08:54:33 --> Model Class Initialized
INFO - 2016-08-03 08:54:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:54:33 --> Final output sent to browser
DEBUG - 2016-08-03 08:54:33 --> Total execution time: 0.0514
INFO - 2016-08-03 08:55:03 --> Config Class Initialized
INFO - 2016-08-03 08:55:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:55:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:55:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:55:03 --> URI Class Initialized
INFO - 2016-08-03 08:55:03 --> Router Class Initialized
INFO - 2016-08-03 08:55:03 --> Output Class Initialized
INFO - 2016-08-03 08:55:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:55:03 --> Input Class Initialized
INFO - 2016-08-03 08:55:03 --> Language Class Initialized
INFO - 2016-08-03 08:55:03 --> Loader Class Initialized
INFO - 2016-08-03 08:55:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:55:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:55:03 --> Controller Class Initialized
INFO - 2016-08-03 08:55:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:55:03 --> Model Class Initialized
INFO - 2016-08-03 08:55:03 --> Model Class Initialized
INFO - 2016-08-03 08:55:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:55:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:55:03 --> Total execution time: 0.0527
INFO - 2016-08-03 08:55:33 --> Config Class Initialized
INFO - 2016-08-03 08:55:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:55:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:55:33 --> Utf8 Class Initialized
INFO - 2016-08-03 08:55:33 --> URI Class Initialized
INFO - 2016-08-03 08:55:33 --> Router Class Initialized
INFO - 2016-08-03 08:55:33 --> Output Class Initialized
INFO - 2016-08-03 08:55:33 --> Security Class Initialized
DEBUG - 2016-08-03 08:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:55:33 --> Input Class Initialized
INFO - 2016-08-03 08:55:33 --> Language Class Initialized
INFO - 2016-08-03 08:55:33 --> Loader Class Initialized
INFO - 2016-08-03 08:55:33 --> Helper loaded: url_helper
INFO - 2016-08-03 08:55:33 --> Helper loaded: language_helper
INFO - 2016-08-03 08:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:55:33 --> Controller Class Initialized
INFO - 2016-08-03 08:55:33 --> Database Driver Class Initialized
INFO - 2016-08-03 08:55:33 --> Model Class Initialized
INFO - 2016-08-03 08:55:33 --> Model Class Initialized
INFO - 2016-08-03 08:55:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:55:33 --> Final output sent to browser
DEBUG - 2016-08-03 08:55:33 --> Total execution time: 0.0560
INFO - 2016-08-03 08:56:03 --> Config Class Initialized
INFO - 2016-08-03 08:56:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:03 --> URI Class Initialized
INFO - 2016-08-03 08:56:03 --> Router Class Initialized
INFO - 2016-08-03 08:56:03 --> Output Class Initialized
INFO - 2016-08-03 08:56:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:03 --> Input Class Initialized
INFO - 2016-08-03 08:56:03 --> Language Class Initialized
INFO - 2016-08-03 08:56:03 --> Loader Class Initialized
INFO - 2016-08-03 08:56:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:03 --> Controller Class Initialized
INFO - 2016-08-03 08:56:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:03 --> Model Class Initialized
INFO - 2016-08-03 08:56:03 --> Model Class Initialized
INFO - 2016-08-03 08:56:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:03 --> Total execution time: 0.0529
INFO - 2016-08-03 08:56:28 --> Config Class Initialized
INFO - 2016-08-03 08:56:28 --> Hooks Class Initialized
INFO - 2016-08-03 08:56:28 --> Config Class Initialized
INFO - 2016-08-03 08:56:28 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:28 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:28 --> Utf8 Class Initialized
DEBUG - 2016-08-03 08:56:28 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:28 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:28 --> URI Class Initialized
INFO - 2016-08-03 08:56:28 --> URI Class Initialized
INFO - 2016-08-03 08:56:28 --> Router Class Initialized
INFO - 2016-08-03 08:56:28 --> Router Class Initialized
INFO - 2016-08-03 08:56:28 --> Output Class Initialized
INFO - 2016-08-03 08:56:28 --> Output Class Initialized
INFO - 2016-08-03 08:56:28 --> Security Class Initialized
INFO - 2016-08-03 08:56:28 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:28 --> Input Class Initialized
DEBUG - 2016-08-03 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:28 --> Input Class Initialized
INFO - 2016-08-03 08:56:28 --> Language Class Initialized
INFO - 2016-08-03 08:56:28 --> Language Class Initialized
INFO - 2016-08-03 08:56:28 --> Loader Class Initialized
INFO - 2016-08-03 08:56:28 --> Loader Class Initialized
INFO - 2016-08-03 08:56:28 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:28 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:28 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:28 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:28 --> Controller Class Initialized
INFO - 2016-08-03 08:56:28 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:28 --> Model Class Initialized
INFO - 2016-08-03 08:56:28 --> Model Class Initialized
INFO - 2016-08-03 08:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:28 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:28 --> Total execution time: 0.0614
INFO - 2016-08-03 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:28 --> Controller Class Initialized
INFO - 2016-08-03 08:56:28 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:28 --> Model Class Initialized
INFO - 2016-08-03 08:56:28 --> Model Class Initialized
INFO - 2016-08-03 08:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:28 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:28 --> Total execution time: 0.0848
INFO - 2016-08-03 08:56:33 --> Config Class Initialized
INFO - 2016-08-03 08:56:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:33 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:33 --> URI Class Initialized
INFO - 2016-08-03 08:56:33 --> Router Class Initialized
INFO - 2016-08-03 08:56:33 --> Output Class Initialized
INFO - 2016-08-03 08:56:33 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:33 --> Input Class Initialized
INFO - 2016-08-03 08:56:33 --> Language Class Initialized
INFO - 2016-08-03 08:56:33 --> Loader Class Initialized
INFO - 2016-08-03 08:56:33 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:33 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:33 --> Controller Class Initialized
INFO - 2016-08-03 08:56:33 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:33 --> Model Class Initialized
INFO - 2016-08-03 08:56:33 --> Model Class Initialized
INFO - 2016-08-03 08:56:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:33 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:33 --> Total execution time: 0.0501
INFO - 2016-08-03 08:56:35 --> Config Class Initialized
INFO - 2016-08-03 08:56:35 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:35 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:35 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:35 --> URI Class Initialized
INFO - 2016-08-03 08:56:35 --> Router Class Initialized
INFO - 2016-08-03 08:56:35 --> Output Class Initialized
INFO - 2016-08-03 08:56:35 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:35 --> Input Class Initialized
INFO - 2016-08-03 08:56:35 --> Language Class Initialized
INFO - 2016-08-03 08:56:35 --> Loader Class Initialized
INFO - 2016-08-03 08:56:35 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:35 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:35 --> Controller Class Initialized
INFO - 2016-08-03 08:56:35 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:35 --> Model Class Initialized
INFO - 2016-08-03 08:56:35 --> Model Class Initialized
INFO - 2016-08-03 08:56:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:35 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:35 --> Total execution time: 0.0762
INFO - 2016-08-03 08:56:45 --> Config Class Initialized
INFO - 2016-08-03 08:56:45 --> Hooks Class Initialized
INFO - 2016-08-03 08:56:45 --> Config Class Initialized
INFO - 2016-08-03 08:56:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:45 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 08:56:45 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:45 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:45 --> URI Class Initialized
INFO - 2016-08-03 08:56:45 --> URI Class Initialized
INFO - 2016-08-03 08:56:45 --> Router Class Initialized
INFO - 2016-08-03 08:56:45 --> Router Class Initialized
INFO - 2016-08-03 08:56:45 --> Output Class Initialized
INFO - 2016-08-03 08:56:45 --> Output Class Initialized
INFO - 2016-08-03 08:56:45 --> Security Class Initialized
INFO - 2016-08-03 08:56:45 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:45 --> Input Class Initialized
INFO - 2016-08-03 08:56:45 --> Language Class Initialized
DEBUG - 2016-08-03 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:45 --> Input Class Initialized
INFO - 2016-08-03 08:56:45 --> Language Class Initialized
INFO - 2016-08-03 08:56:45 --> Loader Class Initialized
INFO - 2016-08-03 08:56:45 --> Loader Class Initialized
INFO - 2016-08-03 08:56:45 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:45 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:45 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:45 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:45 --> Controller Class Initialized
INFO - 2016-08-03 08:56:45 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:45 --> Model Class Initialized
INFO - 2016-08-03 08:56:45 --> Model Class Initialized
INFO - 2016-08-03 08:56:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:45 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:45 --> Total execution time: 0.0662
INFO - 2016-08-03 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:45 --> Controller Class Initialized
INFO - 2016-08-03 08:56:45 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:45 --> Model Class Initialized
INFO - 2016-08-03 08:56:45 --> Model Class Initialized
INFO - 2016-08-03 08:56:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:45 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:45 --> Total execution time: 0.0971
INFO - 2016-08-03 08:56:48 --> Config Class Initialized
INFO - 2016-08-03 08:56:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:48 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:48 --> URI Class Initialized
INFO - 2016-08-03 08:56:48 --> Router Class Initialized
INFO - 2016-08-03 08:56:48 --> Output Class Initialized
INFO - 2016-08-03 08:56:48 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:48 --> Input Class Initialized
INFO - 2016-08-03 08:56:48 --> Language Class Initialized
INFO - 2016-08-03 08:56:48 --> Loader Class Initialized
INFO - 2016-08-03 08:56:48 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:48 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:48 --> Controller Class Initialized
INFO - 2016-08-03 08:56:48 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:48 --> Model Class Initialized
INFO - 2016-08-03 08:56:48 --> Model Class Initialized
INFO - 2016-08-03 08:56:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:48 --> Config Class Initialized
INFO - 2016-08-03 08:56:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:56:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:56:48 --> Utf8 Class Initialized
INFO - 2016-08-03 08:56:48 --> URI Class Initialized
INFO - 2016-08-03 08:56:48 --> Router Class Initialized
INFO - 2016-08-03 08:56:48 --> Output Class Initialized
INFO - 2016-08-03 08:56:48 --> Security Class Initialized
DEBUG - 2016-08-03 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:56:48 --> Input Class Initialized
INFO - 2016-08-03 08:56:48 --> Language Class Initialized
INFO - 2016-08-03 08:56:48 --> Loader Class Initialized
INFO - 2016-08-03 08:56:48 --> Helper loaded: url_helper
INFO - 2016-08-03 08:56:48 --> Helper loaded: language_helper
INFO - 2016-08-03 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:56:48 --> Controller Class Initialized
INFO - 2016-08-03 08:56:48 --> Database Driver Class Initialized
INFO - 2016-08-03 08:56:48 --> Model Class Initialized
INFO - 2016-08-03 08:56:48 --> Model Class Initialized
INFO - 2016-08-03 08:56:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:56:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:56:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 08:56:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:56:48 --> Final output sent to browser
DEBUG - 2016-08-03 08:56:48 --> Total execution time: 0.0562
INFO - 2016-08-03 08:58:49 --> Config Class Initialized
INFO - 2016-08-03 08:58:49 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:58:49 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:58:49 --> Utf8 Class Initialized
INFO - 2016-08-03 08:58:49 --> URI Class Initialized
INFO - 2016-08-03 08:58:49 --> Router Class Initialized
INFO - 2016-08-03 08:58:49 --> Output Class Initialized
INFO - 2016-08-03 08:58:49 --> Security Class Initialized
DEBUG - 2016-08-03 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:58:49 --> Input Class Initialized
INFO - 2016-08-03 08:58:49 --> Language Class Initialized
INFO - 2016-08-03 08:58:49 --> Loader Class Initialized
INFO - 2016-08-03 08:58:49 --> Helper loaded: url_helper
INFO - 2016-08-03 08:58:49 --> Helper loaded: language_helper
INFO - 2016-08-03 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:58:49 --> Controller Class Initialized
INFO - 2016-08-03 08:58:49 --> Database Driver Class Initialized
INFO - 2016-08-03 08:58:49 --> Model Class Initialized
INFO - 2016-08-03 08:58:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:58:49 --> Config Class Initialized
INFO - 2016-08-03 08:58:49 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:58:49 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:58:49 --> Utf8 Class Initialized
INFO - 2016-08-03 08:58:49 --> URI Class Initialized
INFO - 2016-08-03 08:58:49 --> Router Class Initialized
INFO - 2016-08-03 08:58:49 --> Output Class Initialized
INFO - 2016-08-03 08:58:49 --> Security Class Initialized
DEBUG - 2016-08-03 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:58:49 --> Input Class Initialized
INFO - 2016-08-03 08:58:49 --> Language Class Initialized
INFO - 2016-08-03 08:58:49 --> Loader Class Initialized
INFO - 2016-08-03 08:58:49 --> Helper loaded: url_helper
INFO - 2016-08-03 08:58:49 --> Helper loaded: language_helper
INFO - 2016-08-03 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:58:49 --> Controller Class Initialized
INFO - 2016-08-03 08:58:49 --> Database Driver Class Initialized
INFO - 2016-08-03 08:58:49 --> Model Class Initialized
INFO - 2016-08-03 08:58:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:58:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 08:58:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 08:58:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 08:58:49 --> Final output sent to browser
DEBUG - 2016-08-03 08:58:49 --> Total execution time: 0.0514
INFO - 2016-08-03 08:59:03 --> Config Class Initialized
INFO - 2016-08-03 08:59:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:59:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:59:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:59:03 --> URI Class Initialized
INFO - 2016-08-03 08:59:03 --> Router Class Initialized
INFO - 2016-08-03 08:59:03 --> Output Class Initialized
INFO - 2016-08-03 08:59:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:59:03 --> Input Class Initialized
INFO - 2016-08-03 08:59:03 --> Language Class Initialized
INFO - 2016-08-03 08:59:03 --> Loader Class Initialized
INFO - 2016-08-03 08:59:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:59:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:59:03 --> Controller Class Initialized
INFO - 2016-08-03 08:59:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:59:03 --> Model Class Initialized
INFO - 2016-08-03 08:59:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:59:03 --> Config Class Initialized
INFO - 2016-08-03 08:59:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 08:59:03 --> UTF-8 Support Enabled
INFO - 2016-08-03 08:59:03 --> Utf8 Class Initialized
INFO - 2016-08-03 08:59:03 --> URI Class Initialized
INFO - 2016-08-03 08:59:03 --> Router Class Initialized
INFO - 2016-08-03 08:59:03 --> Output Class Initialized
INFO - 2016-08-03 08:59:03 --> Security Class Initialized
DEBUG - 2016-08-03 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 08:59:03 --> Input Class Initialized
INFO - 2016-08-03 08:59:03 --> Language Class Initialized
INFO - 2016-08-03 08:59:03 --> Loader Class Initialized
INFO - 2016-08-03 08:59:03 --> Helper loaded: url_helper
INFO - 2016-08-03 08:59:03 --> Helper loaded: language_helper
INFO - 2016-08-03 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 08:59:03 --> Controller Class Initialized
INFO - 2016-08-03 08:59:03 --> Database Driver Class Initialized
INFO - 2016-08-03 08:59:03 --> Model Class Initialized
INFO - 2016-08-03 08:59:03 --> Model Class Initialized
INFO - 2016-08-03 08:59:03 --> Model Class Initialized
INFO - 2016-08-03 08:59:03 --> Model Class Initialized
INFO - 2016-08-03 08:59:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 08:59:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 08:59:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 08:59:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 08:59:03 --> Final output sent to browser
DEBUG - 2016-08-03 08:59:03 --> Total execution time: 0.0635
INFO - 2016-08-03 09:00:02 --> Config Class Initialized
INFO - 2016-08-03 09:00:02 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:00:02 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:00:02 --> Utf8 Class Initialized
INFO - 2016-08-03 09:00:02 --> URI Class Initialized
INFO - 2016-08-03 09:00:02 --> Router Class Initialized
INFO - 2016-08-03 09:00:02 --> Output Class Initialized
INFO - 2016-08-03 09:00:02 --> Security Class Initialized
DEBUG - 2016-08-03 09:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:00:02 --> Input Class Initialized
INFO - 2016-08-03 09:00:02 --> Language Class Initialized
INFO - 2016-08-03 09:00:02 --> Loader Class Initialized
INFO - 2016-08-03 09:00:02 --> Helper loaded: url_helper
INFO - 2016-08-03 09:00:02 --> Helper loaded: language_helper
INFO - 2016-08-03 09:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:00:02 --> Controller Class Initialized
INFO - 2016-08-03 09:00:02 --> Database Driver Class Initialized
INFO - 2016-08-03 09:00:02 --> Model Class Initialized
INFO - 2016-08-03 09:00:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\group_list.php
INFO - 2016-08-03 09:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:00:02 --> Final output sent to browser
DEBUG - 2016-08-03 09:00:02 --> Total execution time: 0.0560
INFO - 2016-08-03 09:00:21 --> Config Class Initialized
INFO - 2016-08-03 09:00:21 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:00:21 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:00:21 --> Utf8 Class Initialized
INFO - 2016-08-03 09:00:21 --> URI Class Initialized
INFO - 2016-08-03 09:00:21 --> Router Class Initialized
INFO - 2016-08-03 09:00:21 --> Output Class Initialized
INFO - 2016-08-03 09:00:21 --> Security Class Initialized
DEBUG - 2016-08-03 09:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:00:21 --> Input Class Initialized
INFO - 2016-08-03 09:00:21 --> Language Class Initialized
INFO - 2016-08-03 09:00:21 --> Loader Class Initialized
INFO - 2016-08-03 09:00:21 --> Helper loaded: url_helper
INFO - 2016-08-03 09:00:21 --> Helper loaded: language_helper
INFO - 2016-08-03 09:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:00:21 --> Controller Class Initialized
INFO - 2016-08-03 09:00:21 --> Database Driver Class Initialized
INFO - 2016-08-03 09:00:21 --> Model Class Initialized
INFO - 2016-08-03 09:00:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:00:21 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-08-03 09:00:23 --> Config Class Initialized
INFO - 2016-08-03 09:00:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:00:23 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:00:23 --> Utf8 Class Initialized
INFO - 2016-08-03 09:00:23 --> URI Class Initialized
INFO - 2016-08-03 09:00:23 --> Router Class Initialized
INFO - 2016-08-03 09:00:23 --> Output Class Initialized
INFO - 2016-08-03 09:00:23 --> Security Class Initialized
DEBUG - 2016-08-03 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:00:23 --> Input Class Initialized
INFO - 2016-08-03 09:00:23 --> Language Class Initialized
INFO - 2016-08-03 09:00:23 --> Loader Class Initialized
INFO - 2016-08-03 09:00:23 --> Helper loaded: url_helper
INFO - 2016-08-03 09:00:23 --> Helper loaded: language_helper
INFO - 2016-08-03 09:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:00:23 --> Controller Class Initialized
INFO - 2016-08-03 09:00:23 --> Database Driver Class Initialized
INFO - 2016-08-03 09:00:23 --> Model Class Initialized
INFO - 2016-08-03 09:00:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-08-03 09:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:00:23 --> Final output sent to browser
DEBUG - 2016-08-03 09:00:23 --> Total execution time: 0.0636
INFO - 2016-08-03 09:00:39 --> Config Class Initialized
INFO - 2016-08-03 09:00:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:00:39 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:00:39 --> Utf8 Class Initialized
INFO - 2016-08-03 09:00:39 --> URI Class Initialized
INFO - 2016-08-03 09:00:39 --> Router Class Initialized
INFO - 2016-08-03 09:00:39 --> Output Class Initialized
INFO - 2016-08-03 09:00:39 --> Security Class Initialized
DEBUG - 2016-08-03 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:00:39 --> Input Class Initialized
INFO - 2016-08-03 09:00:39 --> Language Class Initialized
INFO - 2016-08-03 09:00:39 --> Loader Class Initialized
INFO - 2016-08-03 09:00:39 --> Helper loaded: url_helper
INFO - 2016-08-03 09:00:39 --> Helper loaded: language_helper
INFO - 2016-08-03 09:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:00:39 --> Controller Class Initialized
INFO - 2016-08-03 09:00:39 --> Database Driver Class Initialized
INFO - 2016-08-03 09:00:40 --> Model Class Initialized
INFO - 2016-08-03 09:00:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\level_list.php
INFO - 2016-08-03 09:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:00:40 --> Final output sent to browser
DEBUG - 2016-08-03 09:00:40 --> Total execution time: 0.0586
INFO - 2016-08-03 09:01:00 --> Config Class Initialized
INFO - 2016-08-03 09:01:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:01:00 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:01:00 --> Utf8 Class Initialized
INFO - 2016-08-03 09:01:00 --> URI Class Initialized
INFO - 2016-08-03 09:01:00 --> Router Class Initialized
INFO - 2016-08-03 09:01:00 --> Output Class Initialized
INFO - 2016-08-03 09:01:00 --> Security Class Initialized
DEBUG - 2016-08-03 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:01:00 --> Input Class Initialized
INFO - 2016-08-03 09:01:00 --> Language Class Initialized
INFO - 2016-08-03 09:01:00 --> Loader Class Initialized
INFO - 2016-08-03 09:01:00 --> Helper loaded: url_helper
INFO - 2016-08-03 09:01:00 --> Helper loaded: language_helper
INFO - 2016-08-03 09:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:01:00 --> Controller Class Initialized
INFO - 2016-08-03 09:01:00 --> Database Driver Class Initialized
INFO - 2016-08-03 09:01:00 --> Model Class Initialized
INFO - 2016-08-03 09:01:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:01:00 --> Helper loaded: form_helper
INFO - 2016-08-03 09:01:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:01:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-08-03 09:01:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:01:00 --> Final output sent to browser
DEBUG - 2016-08-03 09:01:00 --> Total execution time: 0.0640
INFO - 2016-08-03 09:01:38 --> Config Class Initialized
INFO - 2016-08-03 09:01:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:01:38 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:01:38 --> Utf8 Class Initialized
INFO - 2016-08-03 09:01:38 --> URI Class Initialized
INFO - 2016-08-03 09:01:38 --> Router Class Initialized
INFO - 2016-08-03 09:01:38 --> Output Class Initialized
INFO - 2016-08-03 09:01:38 --> Security Class Initialized
DEBUG - 2016-08-03 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:01:38 --> Input Class Initialized
INFO - 2016-08-03 09:01:38 --> Language Class Initialized
INFO - 2016-08-03 09:01:38 --> Loader Class Initialized
INFO - 2016-08-03 09:01:38 --> Helper loaded: url_helper
INFO - 2016-08-03 09:01:38 --> Helper loaded: language_helper
INFO - 2016-08-03 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:01:38 --> Controller Class Initialized
INFO - 2016-08-03 09:01:38 --> Database Driver Class Initialized
INFO - 2016-08-03 09:01:38 --> Model Class Initialized
INFO - 2016-08-03 09:01:38 --> Model Class Initialized
INFO - 2016-08-03 09:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-08-03 09:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:01:38 --> Final output sent to browser
DEBUG - 2016-08-03 09:01:38 --> Total execution time: 0.0608
INFO - 2016-08-03 09:03:54 --> Config Class Initialized
INFO - 2016-08-03 09:03:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:03:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:03:54 --> Utf8 Class Initialized
INFO - 2016-08-03 09:03:54 --> URI Class Initialized
INFO - 2016-08-03 09:03:54 --> Router Class Initialized
INFO - 2016-08-03 09:03:54 --> Output Class Initialized
INFO - 2016-08-03 09:03:54 --> Security Class Initialized
DEBUG - 2016-08-03 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:03:54 --> Input Class Initialized
INFO - 2016-08-03 09:03:54 --> Language Class Initialized
INFO - 2016-08-03 09:03:54 --> Loader Class Initialized
INFO - 2016-08-03 09:03:54 --> Helper loaded: url_helper
INFO - 2016-08-03 09:03:54 --> Helper loaded: language_helper
INFO - 2016-08-03 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:03:54 --> Controller Class Initialized
INFO - 2016-08-03 09:03:54 --> Database Driver Class Initialized
INFO - 2016-08-03 09:03:54 --> Model Class Initialized
INFO - 2016-08-03 09:03:54 --> Model Class Initialized
INFO - 2016-08-03 09:03:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:03:54 --> Helper loaded: form_helper
INFO - 2016-08-03 09:03:54 --> Form Validation Class Initialized
INFO - 2016-08-03 09:03:54 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-03 09:03:54 --> Config Class Initialized
INFO - 2016-08-03 09:03:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:03:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:03:54 --> Utf8 Class Initialized
INFO - 2016-08-03 09:03:54 --> URI Class Initialized
INFO - 2016-08-03 09:03:54 --> Router Class Initialized
INFO - 2016-08-03 09:03:54 --> Output Class Initialized
INFO - 2016-08-03 09:03:54 --> Security Class Initialized
DEBUG - 2016-08-03 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:03:54 --> Input Class Initialized
INFO - 2016-08-03 09:03:54 --> Language Class Initialized
INFO - 2016-08-03 09:03:54 --> Loader Class Initialized
INFO - 2016-08-03 09:03:54 --> Helper loaded: url_helper
INFO - 2016-08-03 09:03:54 --> Helper loaded: language_helper
INFO - 2016-08-03 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:03:54 --> Controller Class Initialized
INFO - 2016-08-03 09:03:54 --> Database Driver Class Initialized
INFO - 2016-08-03 09:03:54 --> Model Class Initialized
INFO - 2016-08-03 09:03:54 --> Model Class Initialized
INFO - 2016-08-03 09:03:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-08-03 09:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:03:54 --> Final output sent to browser
DEBUG - 2016-08-03 09:03:54 --> Total execution time: 0.0616
INFO - 2016-08-03 09:04:13 --> Config Class Initialized
INFO - 2016-08-03 09:04:13 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:04:13 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:04:13 --> Utf8 Class Initialized
INFO - 2016-08-03 09:04:13 --> URI Class Initialized
INFO - 2016-08-03 09:04:13 --> Router Class Initialized
INFO - 2016-08-03 09:04:13 --> Output Class Initialized
INFO - 2016-08-03 09:04:13 --> Security Class Initialized
DEBUG - 2016-08-03 09:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:04:13 --> Input Class Initialized
INFO - 2016-08-03 09:04:13 --> Language Class Initialized
INFO - 2016-08-03 09:04:13 --> Loader Class Initialized
INFO - 2016-08-03 09:04:13 --> Helper loaded: url_helper
INFO - 2016-08-03 09:04:13 --> Helper loaded: language_helper
INFO - 2016-08-03 09:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:04:13 --> Controller Class Initialized
INFO - 2016-08-03 09:04:13 --> Database Driver Class Initialized
INFO - 2016-08-03 09:04:13 --> Model Class Initialized
INFO - 2016-08-03 09:04:13 --> Model Class Initialized
INFO - 2016-08-03 09:04:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:04:13 --> Model Class Initialized
INFO - 2016-08-03 09:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-03 09:04:13 --> Severity: Notice --> Undefined variable: level_list C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
ERROR - 2016-08-03 09:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
INFO - 2016-08-03 09:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php
INFO - 2016-08-03 09:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:04:13 --> Final output sent to browser
DEBUG - 2016-08-03 09:04:13 --> Total execution time: 0.0686
INFO - 2016-08-03 09:04:41 --> Config Class Initialized
INFO - 2016-08-03 09:04:41 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:04:41 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:04:41 --> Utf8 Class Initialized
INFO - 2016-08-03 09:04:41 --> URI Class Initialized
INFO - 2016-08-03 09:04:41 --> Router Class Initialized
INFO - 2016-08-03 09:04:41 --> Output Class Initialized
INFO - 2016-08-03 09:04:41 --> Security Class Initialized
DEBUG - 2016-08-03 09:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:04:41 --> Input Class Initialized
INFO - 2016-08-03 09:04:41 --> Language Class Initialized
INFO - 2016-08-03 09:04:41 --> Loader Class Initialized
INFO - 2016-08-03 09:04:41 --> Helper loaded: url_helper
INFO - 2016-08-03 09:04:41 --> Helper loaded: language_helper
INFO - 2016-08-03 09:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:04:41 --> Controller Class Initialized
INFO - 2016-08-03 09:04:41 --> Database Driver Class Initialized
INFO - 2016-08-03 09:04:41 --> Model Class Initialized
INFO - 2016-08-03 09:04:41 --> Model Class Initialized
INFO - 2016-08-03 09:04:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:04:41 --> Final output sent to browser
DEBUG - 2016-08-03 09:04:41 --> Total execution time: 0.0749
INFO - 2016-08-03 09:04:47 --> Config Class Initialized
INFO - 2016-08-03 09:04:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:04:47 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:04:47 --> Utf8 Class Initialized
INFO - 2016-08-03 09:04:47 --> URI Class Initialized
INFO - 2016-08-03 09:04:47 --> Router Class Initialized
INFO - 2016-08-03 09:04:47 --> Output Class Initialized
INFO - 2016-08-03 09:04:47 --> Security Class Initialized
DEBUG - 2016-08-03 09:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:04:47 --> Input Class Initialized
INFO - 2016-08-03 09:04:47 --> Language Class Initialized
INFO - 2016-08-03 09:04:47 --> Loader Class Initialized
INFO - 2016-08-03 09:04:47 --> Helper loaded: url_helper
INFO - 2016-08-03 09:04:47 --> Helper loaded: language_helper
INFO - 2016-08-03 09:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:04:47 --> Controller Class Initialized
INFO - 2016-08-03 09:04:47 --> Database Driver Class Initialized
INFO - 2016-08-03 09:04:47 --> Model Class Initialized
INFO - 2016-08-03 09:04:47 --> Model Class Initialized
INFO - 2016-08-03 09:04:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-08-03 09:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:04:47 --> Final output sent to browser
DEBUG - 2016-08-03 09:04:47 --> Total execution time: 0.0602
INFO - 2016-08-03 09:05:55 --> Config Class Initialized
INFO - 2016-08-03 09:05:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:05:55 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:05:55 --> Utf8 Class Initialized
INFO - 2016-08-03 09:05:55 --> URI Class Initialized
INFO - 2016-08-03 09:05:55 --> Router Class Initialized
INFO - 2016-08-03 09:05:55 --> Output Class Initialized
INFO - 2016-08-03 09:05:55 --> Security Class Initialized
DEBUG - 2016-08-03 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:05:55 --> Input Class Initialized
INFO - 2016-08-03 09:05:55 --> Language Class Initialized
INFO - 2016-08-03 09:05:55 --> Loader Class Initialized
INFO - 2016-08-03 09:05:55 --> Helper loaded: url_helper
INFO - 2016-08-03 09:05:55 --> Helper loaded: language_helper
INFO - 2016-08-03 09:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:05:55 --> Controller Class Initialized
INFO - 2016-08-03 09:05:55 --> Database Driver Class Initialized
INFO - 2016-08-03 09:05:55 --> Model Class Initialized
INFO - 2016-08-03 09:05:55 --> Model Class Initialized
INFO - 2016-08-03 09:05:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:05:55 --> Model Class Initialized
INFO - 2016-08-03 09:05:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-03 09:05:55 --> Severity: Notice --> Undefined variable: level_list C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
ERROR - 2016-08-03 09:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
INFO - 2016-08-03 09:05:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php
INFO - 2016-08-03 09:05:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:05:55 --> Final output sent to browser
DEBUG - 2016-08-03 09:05:55 --> Total execution time: 0.0698
INFO - 2016-08-03 09:06:07 --> Config Class Initialized
INFO - 2016-08-03 09:06:07 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:07 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:07 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:07 --> URI Class Initialized
INFO - 2016-08-03 09:06:07 --> Router Class Initialized
INFO - 2016-08-03 09:06:07 --> Output Class Initialized
INFO - 2016-08-03 09:06:07 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:07 --> Input Class Initialized
INFO - 2016-08-03 09:06:07 --> Language Class Initialized
INFO - 2016-08-03 09:06:07 --> Loader Class Initialized
INFO - 2016-08-03 09:06:07 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:07 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:07 --> Controller Class Initialized
INFO - 2016-08-03 09:06:07 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:07 --> Model Class Initialized
INFO - 2016-08-03 09:06:07 --> Model Class Initialized
INFO - 2016-08-03 09:06:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:06:07 --> Final output sent to browser
DEBUG - 2016-08-03 09:06:07 --> Total execution time: 0.0536
INFO - 2016-08-03 09:06:08 --> Config Class Initialized
INFO - 2016-08-03 09:06:08 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:08 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:08 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:08 --> URI Class Initialized
INFO - 2016-08-03 09:06:08 --> Router Class Initialized
INFO - 2016-08-03 09:06:08 --> Output Class Initialized
INFO - 2016-08-03 09:06:08 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:08 --> Input Class Initialized
INFO - 2016-08-03 09:06:08 --> Language Class Initialized
INFO - 2016-08-03 09:06:08 --> Loader Class Initialized
INFO - 2016-08-03 09:06:08 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:08 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:08 --> Controller Class Initialized
INFO - 2016-08-03 09:06:08 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:08 --> Model Class Initialized
INFO - 2016-08-03 09:06:08 --> Model Class Initialized
INFO - 2016-08-03 09:06:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:06:08 --> Final output sent to browser
DEBUG - 2016-08-03 09:06:08 --> Total execution time: 0.0590
INFO - 2016-08-03 09:06:10 --> Config Class Initialized
INFO - 2016-08-03 09:06:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:10 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:10 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:10 --> URI Class Initialized
INFO - 2016-08-03 09:06:10 --> Router Class Initialized
INFO - 2016-08-03 09:06:10 --> Output Class Initialized
INFO - 2016-08-03 09:06:10 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:10 --> Input Class Initialized
INFO - 2016-08-03 09:06:10 --> Language Class Initialized
INFO - 2016-08-03 09:06:10 --> Loader Class Initialized
INFO - 2016-08-03 09:06:10 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:10 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:10 --> Controller Class Initialized
INFO - 2016-08-03 09:06:10 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:10 --> Model Class Initialized
INFO - 2016-08-03 09:06:10 --> Model Class Initialized
INFO - 2016-08-03 09:06:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:06:10 --> Final output sent to browser
DEBUG - 2016-08-03 09:06:10 --> Total execution time: 0.0715
INFO - 2016-08-03 09:06:18 --> Config Class Initialized
INFO - 2016-08-03 09:06:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:18 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:18 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:18 --> URI Class Initialized
INFO - 2016-08-03 09:06:18 --> Router Class Initialized
INFO - 2016-08-03 09:06:18 --> Output Class Initialized
INFO - 2016-08-03 09:06:18 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:18 --> Input Class Initialized
INFO - 2016-08-03 09:06:18 --> Language Class Initialized
INFO - 2016-08-03 09:06:18 --> Loader Class Initialized
INFO - 2016-08-03 09:06:18 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:18 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:18 --> Controller Class Initialized
INFO - 2016-08-03 09:06:18 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:18 --> Model Class Initialized
INFO - 2016-08-03 09:06:18 --> Model Class Initialized
INFO - 2016-08-03 09:06:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-08-03 09:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:06:18 --> Final output sent to browser
DEBUG - 2016-08-03 09:06:18 --> Total execution time: 0.0667
INFO - 2016-08-03 09:06:38 --> Config Class Initialized
INFO - 2016-08-03 09:06:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:38 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:38 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:38 --> URI Class Initialized
INFO - 2016-08-03 09:06:38 --> Router Class Initialized
INFO - 2016-08-03 09:06:38 --> Output Class Initialized
INFO - 2016-08-03 09:06:38 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:38 --> Input Class Initialized
INFO - 2016-08-03 09:06:38 --> Language Class Initialized
INFO - 2016-08-03 09:06:38 --> Loader Class Initialized
INFO - 2016-08-03 09:06:38 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:38 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:38 --> Controller Class Initialized
INFO - 2016-08-03 09:06:38 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:38 --> Model Class Initialized
INFO - 2016-08-03 09:06:38 --> Model Class Initialized
INFO - 2016-08-03 09:06:38 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-08-03 09:06:38 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 666
ERROR - 2016-08-03 09:06:38 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
ERROR - 2016-08-03 09:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
ERROR - 2016-08-03 09:06:38 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 854
INFO - 2016-08-03 09:06:38 --> Final output sent to browser
DEBUG - 2016-08-03 09:06:38 --> Total execution time: 0.0645
INFO - 2016-08-03 09:06:42 --> Config Class Initialized
INFO - 2016-08-03 09:06:42 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:42 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:42 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:42 --> URI Class Initialized
INFO - 2016-08-03 09:06:42 --> Router Class Initialized
INFO - 2016-08-03 09:06:42 --> Output Class Initialized
INFO - 2016-08-03 09:06:42 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:42 --> Input Class Initialized
INFO - 2016-08-03 09:06:42 --> Language Class Initialized
INFO - 2016-08-03 09:06:42 --> Loader Class Initialized
INFO - 2016-08-03 09:06:42 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:42 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:42 --> Controller Class Initialized
INFO - 2016-08-03 09:06:42 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:42 --> Model Class Initialized
INFO - 2016-08-03 09:06:42 --> Model Class Initialized
INFO - 2016-08-03 09:06:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:06:42 --> Config Class Initialized
INFO - 2016-08-03 09:06:42 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:06:42 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:06:42 --> Utf8 Class Initialized
INFO - 2016-08-03 09:06:42 --> URI Class Initialized
INFO - 2016-08-03 09:06:42 --> Router Class Initialized
INFO - 2016-08-03 09:06:42 --> Output Class Initialized
INFO - 2016-08-03 09:06:42 --> Security Class Initialized
DEBUG - 2016-08-03 09:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:06:42 --> Input Class Initialized
INFO - 2016-08-03 09:06:42 --> Language Class Initialized
INFO - 2016-08-03 09:06:42 --> Loader Class Initialized
INFO - 2016-08-03 09:06:42 --> Helper loaded: url_helper
INFO - 2016-08-03 09:06:42 --> Helper loaded: language_helper
INFO - 2016-08-03 09:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:06:42 --> Controller Class Initialized
INFO - 2016-08-03 09:06:42 --> Database Driver Class Initialized
INFO - 2016-08-03 09:06:42 --> Model Class Initialized
INFO - 2016-08-03 09:06:42 --> Model Class Initialized
INFO - 2016-08-03 09:06:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:06:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:06:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-08-03 09:06:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:06:42 --> Final output sent to browser
DEBUG - 2016-08-03 09:06:42 --> Total execution time: 0.0810
INFO - 2016-08-03 09:07:17 --> Config Class Initialized
INFO - 2016-08-03 09:07:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:07:17 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:07:17 --> Utf8 Class Initialized
INFO - 2016-08-03 09:07:17 --> URI Class Initialized
INFO - 2016-08-03 09:07:17 --> Router Class Initialized
INFO - 2016-08-03 09:07:17 --> Output Class Initialized
INFO - 2016-08-03 09:07:17 --> Security Class Initialized
DEBUG - 2016-08-03 09:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:07:17 --> Input Class Initialized
INFO - 2016-08-03 09:07:17 --> Language Class Initialized
INFO - 2016-08-03 09:07:17 --> Loader Class Initialized
INFO - 2016-08-03 09:07:17 --> Helper loaded: url_helper
INFO - 2016-08-03 09:07:17 --> Helper loaded: language_helper
INFO - 2016-08-03 09:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:07:17 --> Controller Class Initialized
INFO - 2016-08-03 09:07:17 --> Database Driver Class Initialized
INFO - 2016-08-03 09:07:17 --> Model Class Initialized
INFO - 2016-08-03 09:07:17 --> Model Class Initialized
INFO - 2016-08-03 09:07:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:07:17 --> Helper loaded: form_helper
INFO - 2016-08-03 09:07:17 --> Form Validation Class Initialized
INFO - 2016-08-03 09:07:17 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-03 09:07:17 --> Config Class Initialized
INFO - 2016-08-03 09:07:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:07:17 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:07:17 --> Utf8 Class Initialized
INFO - 2016-08-03 09:07:17 --> URI Class Initialized
INFO - 2016-08-03 09:07:17 --> Router Class Initialized
INFO - 2016-08-03 09:07:17 --> Output Class Initialized
INFO - 2016-08-03 09:07:17 --> Security Class Initialized
DEBUG - 2016-08-03 09:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:07:17 --> Input Class Initialized
INFO - 2016-08-03 09:07:17 --> Language Class Initialized
INFO - 2016-08-03 09:07:17 --> Loader Class Initialized
INFO - 2016-08-03 09:07:17 --> Helper loaded: url_helper
INFO - 2016-08-03 09:07:17 --> Helper loaded: language_helper
INFO - 2016-08-03 09:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:07:17 --> Controller Class Initialized
INFO - 2016-08-03 09:07:17 --> Database Driver Class Initialized
INFO - 2016-08-03 09:07:17 --> Model Class Initialized
INFO - 2016-08-03 09:07:17 --> Model Class Initialized
INFO - 2016-08-03 09:07:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:07:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:07:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-08-03 09:07:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:07:17 --> Final output sent to browser
DEBUG - 2016-08-03 09:07:17 --> Total execution time: 0.0597
INFO - 2016-08-03 09:07:22 --> Config Class Initialized
INFO - 2016-08-03 09:07:22 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:07:22 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:07:22 --> Utf8 Class Initialized
INFO - 2016-08-03 09:07:22 --> URI Class Initialized
INFO - 2016-08-03 09:07:22 --> Router Class Initialized
INFO - 2016-08-03 09:07:22 --> Output Class Initialized
INFO - 2016-08-03 09:07:22 --> Security Class Initialized
DEBUG - 2016-08-03 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:07:22 --> Input Class Initialized
INFO - 2016-08-03 09:07:22 --> Language Class Initialized
INFO - 2016-08-03 09:07:22 --> Loader Class Initialized
INFO - 2016-08-03 09:07:22 --> Helper loaded: url_helper
INFO - 2016-08-03 09:07:22 --> Helper loaded: language_helper
INFO - 2016-08-03 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:07:22 --> Controller Class Initialized
INFO - 2016-08-03 09:07:22 --> Database Driver Class Initialized
INFO - 2016-08-03 09:07:22 --> Model Class Initialized
INFO - 2016-08-03 09:07:22 --> Model Class Initialized
INFO - 2016-08-03 09:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:07:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:07:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-03 09:07:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:07:22 --> Final output sent to browser
DEBUG - 2016-08-03 09:07:22 --> Total execution time: 0.0607
INFO - 2016-08-03 09:07:50 --> Config Class Initialized
INFO - 2016-08-03 09:07:50 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:07:50 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:07:50 --> Utf8 Class Initialized
INFO - 2016-08-03 09:07:50 --> URI Class Initialized
INFO - 2016-08-03 09:07:50 --> Router Class Initialized
INFO - 2016-08-03 09:07:50 --> Output Class Initialized
INFO - 2016-08-03 09:07:50 --> Security Class Initialized
DEBUG - 2016-08-03 09:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:07:50 --> Input Class Initialized
INFO - 2016-08-03 09:07:50 --> Language Class Initialized
INFO - 2016-08-03 09:07:50 --> Loader Class Initialized
INFO - 2016-08-03 09:07:50 --> Helper loaded: url_helper
INFO - 2016-08-03 09:07:50 --> Helper loaded: language_helper
INFO - 2016-08-03 09:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:07:50 --> Controller Class Initialized
INFO - 2016-08-03 09:07:50 --> Database Driver Class Initialized
INFO - 2016-08-03 09:07:50 --> Model Class Initialized
INFO - 2016-08-03 09:07:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:07:50 --> Helper loaded: form_helper
INFO - 2016-08-03 09:07:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:07:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-08-03 09:07:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:07:50 --> Final output sent to browser
DEBUG - 2016-08-03 09:07:50 --> Total execution time: 0.0621
INFO - 2016-08-03 09:07:59 --> Config Class Initialized
INFO - 2016-08-03 09:07:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:07:59 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:07:59 --> Utf8 Class Initialized
INFO - 2016-08-03 09:07:59 --> URI Class Initialized
INFO - 2016-08-03 09:07:59 --> Router Class Initialized
INFO - 2016-08-03 09:07:59 --> Output Class Initialized
INFO - 2016-08-03 09:07:59 --> Security Class Initialized
DEBUG - 2016-08-03 09:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:07:59 --> Input Class Initialized
INFO - 2016-08-03 09:07:59 --> Language Class Initialized
INFO - 2016-08-03 09:07:59 --> Loader Class Initialized
INFO - 2016-08-03 09:07:59 --> Helper loaded: url_helper
INFO - 2016-08-03 09:07:59 --> Helper loaded: language_helper
INFO - 2016-08-03 09:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:07:59 --> Controller Class Initialized
INFO - 2016-08-03 09:07:59 --> Database Driver Class Initialized
INFO - 2016-08-03 09:07:59 --> Model Class Initialized
INFO - 2016-08-03 09:07:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:07:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:07:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 09:07:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:07:59 --> Final output sent to browser
DEBUG - 2016-08-03 09:07:59 --> Total execution time: 0.0551
INFO - 2016-08-03 09:08:20 --> Config Class Initialized
INFO - 2016-08-03 09:08:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:08:20 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:08:20 --> Utf8 Class Initialized
INFO - 2016-08-03 09:08:20 --> URI Class Initialized
INFO - 2016-08-03 09:08:20 --> Router Class Initialized
INFO - 2016-08-03 09:08:20 --> Output Class Initialized
INFO - 2016-08-03 09:08:20 --> Security Class Initialized
DEBUG - 2016-08-03 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:08:20 --> Input Class Initialized
INFO - 2016-08-03 09:08:20 --> Language Class Initialized
INFO - 2016-08-03 09:08:20 --> Loader Class Initialized
INFO - 2016-08-03 09:08:20 --> Helper loaded: url_helper
INFO - 2016-08-03 09:08:20 --> Helper loaded: language_helper
INFO - 2016-08-03 09:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:08:20 --> Controller Class Initialized
INFO - 2016-08-03 09:08:20 --> Database Driver Class Initialized
INFO - 2016-08-03 09:08:20 --> Model Class Initialized
INFO - 2016-08-03 09:08:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:08:20 --> Config Class Initialized
INFO - 2016-08-03 09:08:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:08:20 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:08:20 --> Utf8 Class Initialized
INFO - 2016-08-03 09:08:20 --> URI Class Initialized
INFO - 2016-08-03 09:08:20 --> Router Class Initialized
INFO - 2016-08-03 09:08:20 --> Output Class Initialized
INFO - 2016-08-03 09:08:20 --> Security Class Initialized
DEBUG - 2016-08-03 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:08:20 --> Input Class Initialized
INFO - 2016-08-03 09:08:20 --> Language Class Initialized
INFO - 2016-08-03 09:08:20 --> Loader Class Initialized
INFO - 2016-08-03 09:08:20 --> Helper loaded: url_helper
INFO - 2016-08-03 09:08:20 --> Helper loaded: language_helper
INFO - 2016-08-03 09:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:08:20 --> Controller Class Initialized
INFO - 2016-08-03 09:08:20 --> Database Driver Class Initialized
INFO - 2016-08-03 09:08:20 --> Model Class Initialized
INFO - 2016-08-03 09:08:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:08:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:08:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-08-03 09:08:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:08:20 --> Final output sent to browser
DEBUG - 2016-08-03 09:08:20 --> Total execution time: 0.0555
INFO - 2016-08-03 09:10:46 --> Config Class Initialized
INFO - 2016-08-03 09:10:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:10:46 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:10:46 --> Utf8 Class Initialized
INFO - 2016-08-03 09:10:46 --> URI Class Initialized
INFO - 2016-08-03 09:10:46 --> Router Class Initialized
INFO - 2016-08-03 09:10:46 --> Output Class Initialized
INFO - 2016-08-03 09:10:46 --> Security Class Initialized
DEBUG - 2016-08-03 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:10:46 --> Input Class Initialized
INFO - 2016-08-03 09:10:46 --> Language Class Initialized
INFO - 2016-08-03 09:10:46 --> Loader Class Initialized
INFO - 2016-08-03 09:10:46 --> Helper loaded: url_helper
INFO - 2016-08-03 09:10:46 --> Helper loaded: language_helper
INFO - 2016-08-03 09:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:10:46 --> Controller Class Initialized
INFO - 2016-08-03 09:10:46 --> Database Driver Class Initialized
INFO - 2016-08-03 09:10:46 --> Model Class Initialized
INFO - 2016-08-03 09:10:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:10:46 --> Config Class Initialized
INFO - 2016-08-03 09:10:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:10:46 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:10:46 --> Utf8 Class Initialized
INFO - 2016-08-03 09:10:46 --> URI Class Initialized
INFO - 2016-08-03 09:10:46 --> Router Class Initialized
INFO - 2016-08-03 09:10:46 --> Output Class Initialized
INFO - 2016-08-03 09:10:46 --> Security Class Initialized
DEBUG - 2016-08-03 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:10:46 --> Input Class Initialized
INFO - 2016-08-03 09:10:46 --> Language Class Initialized
INFO - 2016-08-03 09:10:46 --> Loader Class Initialized
INFO - 2016-08-03 09:10:46 --> Helper loaded: url_helper
INFO - 2016-08-03 09:10:46 --> Helper loaded: language_helper
INFO - 2016-08-03 09:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:10:47 --> Controller Class Initialized
INFO - 2016-08-03 09:10:47 --> Database Driver Class Initialized
INFO - 2016-08-03 09:10:47 --> Model Class Initialized
INFO - 2016-08-03 09:10:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 09:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:10:47 --> Final output sent to browser
DEBUG - 2016-08-03 09:10:47 --> Total execution time: 0.0659
INFO - 2016-08-03 09:11:29 --> Config Class Initialized
INFO - 2016-08-03 09:11:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:11:29 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:11:29 --> Utf8 Class Initialized
INFO - 2016-08-03 09:11:29 --> URI Class Initialized
INFO - 2016-08-03 09:11:29 --> Router Class Initialized
INFO - 2016-08-03 09:11:29 --> Output Class Initialized
INFO - 2016-08-03 09:11:29 --> Security Class Initialized
DEBUG - 2016-08-03 09:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:11:29 --> Input Class Initialized
INFO - 2016-08-03 09:11:29 --> Language Class Initialized
INFO - 2016-08-03 09:11:29 --> Loader Class Initialized
INFO - 2016-08-03 09:11:29 --> Helper loaded: url_helper
INFO - 2016-08-03 09:11:29 --> Helper loaded: language_helper
INFO - 2016-08-03 09:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:11:29 --> Controller Class Initialized
INFO - 2016-08-03 09:11:29 --> Database Driver Class Initialized
INFO - 2016-08-03 09:11:29 --> Model Class Initialized
INFO - 2016-08-03 09:11:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:11:29 --> Helper loaded: form_helper
INFO - 2016-08-03 09:11:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:11:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-08-03 09:11:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:11:29 --> Final output sent to browser
DEBUG - 2016-08-03 09:11:29 --> Total execution time: 0.0626
INFO - 2016-08-03 09:13:27 --> Config Class Initialized
INFO - 2016-08-03 09:13:27 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:13:27 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:13:27 --> Utf8 Class Initialized
INFO - 2016-08-03 09:13:27 --> URI Class Initialized
INFO - 2016-08-03 09:13:27 --> Router Class Initialized
INFO - 2016-08-03 09:13:27 --> Output Class Initialized
INFO - 2016-08-03 09:13:27 --> Security Class Initialized
DEBUG - 2016-08-03 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:13:27 --> Input Class Initialized
INFO - 2016-08-03 09:13:27 --> Language Class Initialized
INFO - 2016-08-03 09:13:27 --> Loader Class Initialized
INFO - 2016-08-03 09:13:27 --> Helper loaded: url_helper
INFO - 2016-08-03 09:13:27 --> Helper loaded: language_helper
INFO - 2016-08-03 09:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:13:27 --> Controller Class Initialized
INFO - 2016-08-03 09:13:27 --> Database Driver Class Initialized
INFO - 2016-08-03 09:13:27 --> Model Class Initialized
INFO - 2016-08-03 09:13:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:13:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:13:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-08-03 09:13:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:13:27 --> Final output sent to browser
DEBUG - 2016-08-03 09:13:27 --> Total execution time: 0.0668
INFO - 2016-08-03 09:13:36 --> Config Class Initialized
INFO - 2016-08-03 09:13:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:13:36 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:13:36 --> Utf8 Class Initialized
INFO - 2016-08-03 09:13:36 --> URI Class Initialized
INFO - 2016-08-03 09:13:36 --> Router Class Initialized
INFO - 2016-08-03 09:13:36 --> Output Class Initialized
INFO - 2016-08-03 09:13:36 --> Security Class Initialized
DEBUG - 2016-08-03 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:13:36 --> Input Class Initialized
INFO - 2016-08-03 09:13:36 --> Language Class Initialized
INFO - 2016-08-03 09:13:36 --> Loader Class Initialized
INFO - 2016-08-03 09:13:36 --> Helper loaded: url_helper
INFO - 2016-08-03 09:13:36 --> Helper loaded: language_helper
INFO - 2016-08-03 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:13:36 --> Controller Class Initialized
INFO - 2016-08-03 09:13:36 --> Database Driver Class Initialized
INFO - 2016-08-03 09:13:36 --> Model Class Initialized
INFO - 2016-08-03 09:13:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:13:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:13:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2016-08-03 09:13:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:13:36 --> Final output sent to browser
DEBUG - 2016-08-03 09:13:36 --> Total execution time: 0.0594
INFO - 2016-08-03 09:13:36 --> Config Class Initialized
INFO - 2016-08-03 09:13:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:13:36 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:13:36 --> Utf8 Class Initialized
INFO - 2016-08-03 09:13:36 --> URI Class Initialized
INFO - 2016-08-03 09:13:36 --> Router Class Initialized
INFO - 2016-08-03 09:13:36 --> Output Class Initialized
INFO - 2016-08-03 09:13:36 --> Security Class Initialized
DEBUG - 2016-08-03 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:13:36 --> Input Class Initialized
INFO - 2016-08-03 09:13:36 --> Language Class Initialized
INFO - 2016-08-03 09:13:36 --> Loader Class Initialized
INFO - 2016-08-03 09:13:36 --> Helper loaded: url_helper
INFO - 2016-08-03 09:13:36 --> Helper loaded: language_helper
INFO - 2016-08-03 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:13:36 --> Controller Class Initialized
INFO - 2016-08-03 09:13:36 --> Database Driver Class Initialized
INFO - 2016-08-03 09:13:36 --> Model Class Initialized
INFO - 2016-08-03 09:13:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:13:36 --> Final output sent to browser
DEBUG - 2016-08-03 09:13:36 --> Total execution time: 0.0683
INFO - 2016-08-03 09:14:47 --> Config Class Initialized
INFO - 2016-08-03 09:14:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 09:14:47 --> UTF-8 Support Enabled
INFO - 2016-08-03 09:14:47 --> Utf8 Class Initialized
INFO - 2016-08-03 09:14:47 --> URI Class Initialized
INFO - 2016-08-03 09:14:47 --> Router Class Initialized
INFO - 2016-08-03 09:14:47 --> Output Class Initialized
INFO - 2016-08-03 09:14:47 --> Security Class Initialized
DEBUG - 2016-08-03 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 09:14:47 --> Input Class Initialized
INFO - 2016-08-03 09:14:47 --> Language Class Initialized
INFO - 2016-08-03 09:14:47 --> Loader Class Initialized
INFO - 2016-08-03 09:14:47 --> Helper loaded: url_helper
INFO - 2016-08-03 09:14:47 --> Helper loaded: language_helper
INFO - 2016-08-03 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 09:14:47 --> Controller Class Initialized
INFO - 2016-08-03 09:14:47 --> Database Driver Class Initialized
INFO - 2016-08-03 09:14:47 --> Model Class Initialized
INFO - 2016-08-03 09:14:47 --> Model Class Initialized
INFO - 2016-08-03 09:14:47 --> Model Class Initialized
INFO - 2016-08-03 09:14:47 --> Model Class Initialized
INFO - 2016-08-03 09:14:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 09:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 09:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 09:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 09:14:47 --> Final output sent to browser
DEBUG - 2016-08-03 09:14:47 --> Total execution time: 0.0660
INFO - 2016-08-03 12:08:53 --> Config Class Initialized
INFO - 2016-08-03 12:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 12:08:53 --> UTF-8 Support Enabled
INFO - 2016-08-03 12:08:53 --> Utf8 Class Initialized
INFO - 2016-08-03 12:08:53 --> URI Class Initialized
INFO - 2016-08-03 12:08:53 --> Router Class Initialized
INFO - 2016-08-03 12:08:53 --> Output Class Initialized
INFO - 2016-08-03 12:08:53 --> Security Class Initialized
DEBUG - 2016-08-03 12:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 12:08:53 --> Input Class Initialized
INFO - 2016-08-03 12:08:53 --> Language Class Initialized
INFO - 2016-08-03 12:08:53 --> Loader Class Initialized
INFO - 2016-08-03 12:08:53 --> Helper loaded: url_helper
INFO - 2016-08-03 12:08:53 --> Helper loaded: language_helper
INFO - 2016-08-03 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 12:08:53 --> Controller Class Initialized
INFO - 2016-08-03 12:08:53 --> Database Driver Class Initialized
INFO - 2016-08-03 12:08:53 --> Model Class Initialized
INFO - 2016-08-03 12:08:53 --> Model Class Initialized
INFO - 2016-08-03 12:08:53 --> Model Class Initialized
INFO - 2016-08-03 12:08:53 --> Model Class Initialized
INFO - 2016-08-03 12:08:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 12:08:53 --> Config Class Initialized
INFO - 2016-08-03 12:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 12:08:53 --> UTF-8 Support Enabled
INFO - 2016-08-03 12:08:53 --> Utf8 Class Initialized
INFO - 2016-08-03 12:08:53 --> URI Class Initialized
INFO - 2016-08-03 12:08:53 --> Router Class Initialized
INFO - 2016-08-03 12:08:53 --> Output Class Initialized
INFO - 2016-08-03 12:08:53 --> Security Class Initialized
DEBUG - 2016-08-03 12:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 12:08:53 --> Input Class Initialized
INFO - 2016-08-03 12:08:53 --> Language Class Initialized
INFO - 2016-08-03 12:08:53 --> Loader Class Initialized
INFO - 2016-08-03 12:08:53 --> Helper loaded: url_helper
INFO - 2016-08-03 12:08:53 --> Helper loaded: language_helper
INFO - 2016-08-03 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 12:08:53 --> Controller Class Initialized
INFO - 2016-08-03 12:08:53 --> Database Driver Class Initialized
INFO - 2016-08-03 12:08:53 --> Model Class Initialized
INFO - 2016-08-03 12:08:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 12:08:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 12:08:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 12:08:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 12:08:53 --> Final output sent to browser
DEBUG - 2016-08-03 12:08:53 --> Total execution time: 0.1311
INFO - 2016-08-03 12:30:45 --> Config Class Initialized
INFO - 2016-08-03 12:30:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 12:30:45 --> UTF-8 Support Enabled
INFO - 2016-08-03 12:30:45 --> Utf8 Class Initialized
INFO - 2016-08-03 12:30:45 --> URI Class Initialized
INFO - 2016-08-03 12:30:45 --> Router Class Initialized
INFO - 2016-08-03 12:30:45 --> Output Class Initialized
INFO - 2016-08-03 12:30:45 --> Security Class Initialized
DEBUG - 2016-08-03 12:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 12:30:45 --> Input Class Initialized
INFO - 2016-08-03 12:30:45 --> Language Class Initialized
INFO - 2016-08-03 12:30:45 --> Loader Class Initialized
INFO - 2016-08-03 12:30:45 --> Helper loaded: url_helper
INFO - 2016-08-03 12:30:45 --> Helper loaded: language_helper
INFO - 2016-08-03 12:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 12:30:45 --> Controller Class Initialized
INFO - 2016-08-03 12:30:45 --> Database Driver Class Initialized
INFO - 2016-08-03 12:30:45 --> Model Class Initialized
INFO - 2016-08-03 12:30:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 12:30:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 12:30:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 12:30:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 12:30:45 --> Final output sent to browser
DEBUG - 2016-08-03 12:30:45 --> Total execution time: 0.0960
INFO - 2016-08-03 13:13:51 --> Config Class Initialized
INFO - 2016-08-03 13:13:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:13:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:13:51 --> Utf8 Class Initialized
INFO - 2016-08-03 13:13:51 --> URI Class Initialized
INFO - 2016-08-03 13:13:51 --> Router Class Initialized
INFO - 2016-08-03 13:13:51 --> Output Class Initialized
INFO - 2016-08-03 13:13:51 --> Security Class Initialized
DEBUG - 2016-08-03 13:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:13:51 --> Input Class Initialized
INFO - 2016-08-03 13:13:51 --> Language Class Initialized
INFO - 2016-08-03 13:13:51 --> Loader Class Initialized
INFO - 2016-08-03 13:13:51 --> Helper loaded: url_helper
INFO - 2016-08-03 13:13:51 --> Helper loaded: language_helper
INFO - 2016-08-03 13:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:13:51 --> Controller Class Initialized
INFO - 2016-08-03 13:13:51 --> Database Driver Class Initialized
INFO - 2016-08-03 13:13:51 --> Model Class Initialized
INFO - 2016-08-03 13:13:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:13:51 --> Config Class Initialized
INFO - 2016-08-03 13:13:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:13:51 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:13:51 --> Utf8 Class Initialized
INFO - 2016-08-03 13:13:51 --> URI Class Initialized
INFO - 2016-08-03 13:13:51 --> Router Class Initialized
INFO - 2016-08-03 13:13:51 --> Output Class Initialized
INFO - 2016-08-03 13:13:51 --> Security Class Initialized
DEBUG - 2016-08-03 13:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:13:51 --> Input Class Initialized
INFO - 2016-08-03 13:13:51 --> Language Class Initialized
INFO - 2016-08-03 13:13:51 --> Loader Class Initialized
INFO - 2016-08-03 13:13:51 --> Helper loaded: url_helper
INFO - 2016-08-03 13:13:51 --> Helper loaded: language_helper
INFO - 2016-08-03 13:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:13:51 --> Controller Class Initialized
INFO - 2016-08-03 13:13:51 --> Database Driver Class Initialized
INFO - 2016-08-03 13:13:51 --> Model Class Initialized
INFO - 2016-08-03 13:13:51 --> Model Class Initialized
INFO - 2016-08-03 13:13:51 --> Model Class Initialized
INFO - 2016-08-03 13:13:51 --> Model Class Initialized
INFO - 2016-08-03 13:13:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:13:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:13:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 13:13:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:13:51 --> Final output sent to browser
DEBUG - 2016-08-03 13:13:51 --> Total execution time: 0.0802
INFO - 2016-08-03 13:13:56 --> Config Class Initialized
INFO - 2016-08-03 13:13:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:13:56 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:13:56 --> Utf8 Class Initialized
INFO - 2016-08-03 13:13:56 --> URI Class Initialized
INFO - 2016-08-03 13:13:56 --> Router Class Initialized
INFO - 2016-08-03 13:13:56 --> Output Class Initialized
INFO - 2016-08-03 13:13:56 --> Security Class Initialized
DEBUG - 2016-08-03 13:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:13:56 --> Input Class Initialized
INFO - 2016-08-03 13:13:56 --> Language Class Initialized
INFO - 2016-08-03 13:13:56 --> Loader Class Initialized
INFO - 2016-08-03 13:13:56 --> Helper loaded: url_helper
INFO - 2016-08-03 13:13:56 --> Helper loaded: language_helper
INFO - 2016-08-03 13:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:13:56 --> Controller Class Initialized
INFO - 2016-08-03 13:13:56 --> Database Driver Class Initialized
INFO - 2016-08-03 13:13:56 --> Model Class Initialized
INFO - 2016-08-03 13:13:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:13:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:13:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 13:13:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:13:56 --> Final output sent to browser
DEBUG - 2016-08-03 13:13:56 --> Total execution time: 0.0570
INFO - 2016-08-03 13:17:32 --> Config Class Initialized
INFO - 2016-08-03 13:17:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:17:32 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:17:32 --> Utf8 Class Initialized
INFO - 2016-08-03 13:17:32 --> URI Class Initialized
INFO - 2016-08-03 13:17:32 --> Router Class Initialized
INFO - 2016-08-03 13:17:32 --> Output Class Initialized
INFO - 2016-08-03 13:17:32 --> Security Class Initialized
DEBUG - 2016-08-03 13:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:17:32 --> Input Class Initialized
INFO - 2016-08-03 13:17:32 --> Language Class Initialized
INFO - 2016-08-03 13:17:32 --> Loader Class Initialized
INFO - 2016-08-03 13:17:32 --> Helper loaded: url_helper
INFO - 2016-08-03 13:17:32 --> Helper loaded: language_helper
INFO - 2016-08-03 13:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:17:32 --> Controller Class Initialized
INFO - 2016-08-03 13:17:32 --> Database Driver Class Initialized
INFO - 2016-08-03 13:17:32 --> Model Class Initialized
INFO - 2016-08-03 13:17:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:17:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:17:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 13:17:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:17:32 --> Final output sent to browser
DEBUG - 2016-08-03 13:17:32 --> Total execution time: 0.0535
INFO - 2016-08-03 13:17:43 --> Config Class Initialized
INFO - 2016-08-03 13:17:43 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:17:43 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:17:43 --> Utf8 Class Initialized
INFO - 2016-08-03 13:17:43 --> URI Class Initialized
INFO - 2016-08-03 13:17:43 --> Router Class Initialized
INFO - 2016-08-03 13:17:43 --> Output Class Initialized
INFO - 2016-08-03 13:17:43 --> Security Class Initialized
DEBUG - 2016-08-03 13:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:17:43 --> Input Class Initialized
INFO - 2016-08-03 13:17:43 --> Language Class Initialized
INFO - 2016-08-03 13:17:43 --> Loader Class Initialized
INFO - 2016-08-03 13:17:43 --> Helper loaded: url_helper
INFO - 2016-08-03 13:17:43 --> Helper loaded: language_helper
INFO - 2016-08-03 13:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:17:43 --> Controller Class Initialized
INFO - 2016-08-03 13:17:43 --> Database Driver Class Initialized
INFO - 2016-08-03 13:17:43 --> Model Class Initialized
INFO - 2016-08-03 13:17:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:17:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:17:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 13:17:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:17:43 --> Final output sent to browser
DEBUG - 2016-08-03 13:17:43 --> Total execution time: 0.0550
INFO - 2016-08-03 13:17:48 --> Config Class Initialized
INFO - 2016-08-03 13:17:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:17:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:17:48 --> Utf8 Class Initialized
INFO - 2016-08-03 13:17:48 --> URI Class Initialized
INFO - 2016-08-03 13:17:48 --> Router Class Initialized
INFO - 2016-08-03 13:17:48 --> Output Class Initialized
INFO - 2016-08-03 13:17:48 --> Security Class Initialized
DEBUG - 2016-08-03 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:17:48 --> Input Class Initialized
INFO - 2016-08-03 13:17:48 --> Language Class Initialized
INFO - 2016-08-03 13:17:48 --> Loader Class Initialized
INFO - 2016-08-03 13:17:48 --> Helper loaded: url_helper
INFO - 2016-08-03 13:17:48 --> Helper loaded: language_helper
INFO - 2016-08-03 13:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:17:48 --> Controller Class Initialized
INFO - 2016-08-03 13:17:48 --> Database Driver Class Initialized
INFO - 2016-08-03 13:17:48 --> Model Class Initialized
INFO - 2016-08-03 13:17:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:17:48 --> Config Class Initialized
INFO - 2016-08-03 13:17:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:17:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:17:48 --> Utf8 Class Initialized
INFO - 2016-08-03 13:17:48 --> URI Class Initialized
INFO - 2016-08-03 13:17:48 --> Router Class Initialized
INFO - 2016-08-03 13:17:48 --> Output Class Initialized
INFO - 2016-08-03 13:17:48 --> Security Class Initialized
DEBUG - 2016-08-03 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:17:48 --> Input Class Initialized
INFO - 2016-08-03 13:17:48 --> Language Class Initialized
INFO - 2016-08-03 13:17:48 --> Loader Class Initialized
INFO - 2016-08-03 13:17:48 --> Helper loaded: url_helper
INFO - 2016-08-03 13:17:48 --> Helper loaded: language_helper
INFO - 2016-08-03 13:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:17:48 --> Controller Class Initialized
INFO - 2016-08-03 13:17:48 --> Database Driver Class Initialized
INFO - 2016-08-03 13:17:48 --> Model Class Initialized
INFO - 2016-08-03 13:17:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:17:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:17:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-08-03 13:17:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:17:48 --> Final output sent to browser
DEBUG - 2016-08-03 13:17:48 --> Total execution time: 0.0658
INFO - 2016-08-03 13:18:14 --> Config Class Initialized
INFO - 2016-08-03 13:18:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:18:14 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:18:14 --> Utf8 Class Initialized
INFO - 2016-08-03 13:18:14 --> URI Class Initialized
INFO - 2016-08-03 13:18:14 --> Router Class Initialized
INFO - 2016-08-03 13:18:14 --> Output Class Initialized
INFO - 2016-08-03 13:18:14 --> Security Class Initialized
DEBUG - 2016-08-03 13:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:18:14 --> Input Class Initialized
INFO - 2016-08-03 13:18:14 --> Language Class Initialized
INFO - 2016-08-03 13:18:14 --> Loader Class Initialized
INFO - 2016-08-03 13:18:14 --> Helper loaded: url_helper
INFO - 2016-08-03 13:18:14 --> Helper loaded: language_helper
INFO - 2016-08-03 13:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:18:14 --> Controller Class Initialized
INFO - 2016-08-03 13:18:14 --> Database Driver Class Initialized
INFO - 2016-08-03 13:18:14 --> Model Class Initialized
INFO - 2016-08-03 13:18:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 13:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:18:14 --> Final output sent to browser
DEBUG - 2016-08-03 13:18:14 --> Total execution time: 0.0560
INFO - 2016-08-03 13:20:19 --> Config Class Initialized
INFO - 2016-08-03 13:20:19 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:20:19 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:20:19 --> Utf8 Class Initialized
INFO - 2016-08-03 13:20:19 --> URI Class Initialized
INFO - 2016-08-03 13:20:19 --> Router Class Initialized
INFO - 2016-08-03 13:20:19 --> Output Class Initialized
INFO - 2016-08-03 13:20:19 --> Security Class Initialized
DEBUG - 2016-08-03 13:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:20:19 --> Input Class Initialized
INFO - 2016-08-03 13:20:19 --> Language Class Initialized
INFO - 2016-08-03 13:20:19 --> Loader Class Initialized
INFO - 2016-08-03 13:20:19 --> Helper loaded: url_helper
INFO - 2016-08-03 13:20:19 --> Helper loaded: language_helper
INFO - 2016-08-03 13:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:20:19 --> Controller Class Initialized
INFO - 2016-08-03 13:20:19 --> Database Driver Class Initialized
INFO - 2016-08-03 13:20:19 --> Model Class Initialized
INFO - 2016-08-03 13:20:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:20:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:20:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 13:20:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:20:19 --> Final output sent to browser
DEBUG - 2016-08-03 13:20:19 --> Total execution time: 0.0573
INFO - 2016-08-03 13:20:23 --> Config Class Initialized
INFO - 2016-08-03 13:20:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:20:23 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:20:23 --> Utf8 Class Initialized
INFO - 2016-08-03 13:20:23 --> URI Class Initialized
INFO - 2016-08-03 13:20:23 --> Router Class Initialized
INFO - 2016-08-03 13:20:23 --> Output Class Initialized
INFO - 2016-08-03 13:20:23 --> Security Class Initialized
DEBUG - 2016-08-03 13:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:20:23 --> Input Class Initialized
INFO - 2016-08-03 13:20:23 --> Language Class Initialized
INFO - 2016-08-03 13:20:23 --> Loader Class Initialized
INFO - 2016-08-03 13:20:23 --> Helper loaded: url_helper
INFO - 2016-08-03 13:20:23 --> Helper loaded: language_helper
INFO - 2016-08-03 13:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:20:23 --> Controller Class Initialized
INFO - 2016-08-03 13:20:23 --> Database Driver Class Initialized
INFO - 2016-08-03 13:20:23 --> Model Class Initialized
INFO - 2016-08-03 13:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:20:23 --> Config Class Initialized
INFO - 2016-08-03 13:20:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:20:23 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:20:23 --> Utf8 Class Initialized
INFO - 2016-08-03 13:20:23 --> URI Class Initialized
INFO - 2016-08-03 13:20:23 --> Router Class Initialized
INFO - 2016-08-03 13:20:23 --> Output Class Initialized
INFO - 2016-08-03 13:20:23 --> Security Class Initialized
DEBUG - 2016-08-03 13:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:20:23 --> Input Class Initialized
INFO - 2016-08-03 13:20:23 --> Language Class Initialized
ERROR - 2016-08-03 13:20:23 --> 404 Page Not Found: Qbank/new_question_6
INFO - 2016-08-03 13:21:22 --> Config Class Initialized
INFO - 2016-08-03 13:21:22 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:21:22 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:21:22 --> Utf8 Class Initialized
INFO - 2016-08-03 13:21:22 --> URI Class Initialized
INFO - 2016-08-03 13:21:22 --> Router Class Initialized
INFO - 2016-08-03 13:21:22 --> Output Class Initialized
INFO - 2016-08-03 13:21:22 --> Security Class Initialized
DEBUG - 2016-08-03 13:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:21:22 --> Input Class Initialized
INFO - 2016-08-03 13:21:22 --> Language Class Initialized
ERROR - 2016-08-03 13:21:22 --> Severity: Compile Error --> Cannot redeclare Qbank::new_question_5() C:\wamp64\www\savsoftquiz\application\controllers\Qbank.php 257
INFO - 2016-08-03 13:21:36 --> Config Class Initialized
INFO - 2016-08-03 13:21:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:21:36 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:21:36 --> Utf8 Class Initialized
INFO - 2016-08-03 13:21:36 --> URI Class Initialized
INFO - 2016-08-03 13:21:36 --> Router Class Initialized
INFO - 2016-08-03 13:21:36 --> Output Class Initialized
INFO - 2016-08-03 13:21:36 --> Security Class Initialized
DEBUG - 2016-08-03 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:21:36 --> Input Class Initialized
INFO - 2016-08-03 13:21:36 --> Language Class Initialized
INFO - 2016-08-03 13:21:36 --> Loader Class Initialized
INFO - 2016-08-03 13:21:36 --> Helper loaded: url_helper
INFO - 2016-08-03 13:21:36 --> Helper loaded: language_helper
INFO - 2016-08-03 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:21:36 --> Controller Class Initialized
INFO - 2016-08-03 13:21:36 --> Database Driver Class Initialized
INFO - 2016-08-03 13:21:36 --> Model Class Initialized
INFO - 2016-08-03 13:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:21:36 --> Final output sent to browser
DEBUG - 2016-08-03 13:21:36 --> Total execution time: 0.0663
INFO - 2016-08-03 13:22:57 --> Config Class Initialized
INFO - 2016-08-03 13:22:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 13:22:57 --> UTF-8 Support Enabled
INFO - 2016-08-03 13:22:57 --> Utf8 Class Initialized
INFO - 2016-08-03 13:22:57 --> URI Class Initialized
INFO - 2016-08-03 13:22:57 --> Router Class Initialized
INFO - 2016-08-03 13:22:57 --> Output Class Initialized
INFO - 2016-08-03 13:22:57 --> Security Class Initialized
DEBUG - 2016-08-03 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 13:22:57 --> Input Class Initialized
INFO - 2016-08-03 13:22:57 --> Language Class Initialized
INFO - 2016-08-03 13:22:57 --> Loader Class Initialized
INFO - 2016-08-03 13:22:57 --> Helper loaded: url_helper
INFO - 2016-08-03 13:22:57 --> Helper loaded: language_helper
INFO - 2016-08-03 13:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 13:22:57 --> Controller Class Initialized
INFO - 2016-08-03 13:22:57 --> Database Driver Class Initialized
INFO - 2016-08-03 13:22:57 --> Model Class Initialized
INFO - 2016-08-03 13:22:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 13:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 13:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 13:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 13:22:57 --> Final output sent to browser
DEBUG - 2016-08-03 13:22:57 --> Total execution time: 0.0598
INFO - 2016-08-03 14:18:14 --> Config Class Initialized
INFO - 2016-08-03 14:18:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:18:14 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:18:14 --> Utf8 Class Initialized
INFO - 2016-08-03 14:18:14 --> URI Class Initialized
INFO - 2016-08-03 14:18:14 --> Router Class Initialized
INFO - 2016-08-03 14:18:14 --> Output Class Initialized
INFO - 2016-08-03 14:18:14 --> Security Class Initialized
DEBUG - 2016-08-03 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:18:14 --> Input Class Initialized
INFO - 2016-08-03 14:18:14 --> Language Class Initialized
INFO - 2016-08-03 14:18:14 --> Loader Class Initialized
INFO - 2016-08-03 14:18:14 --> Helper loaded: url_helper
INFO - 2016-08-03 14:18:14 --> Helper loaded: language_helper
INFO - 2016-08-03 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:18:14 --> Controller Class Initialized
INFO - 2016-08-03 14:18:14 --> Database Driver Class Initialized
INFO - 2016-08-03 14:18:14 --> Model Class Initialized
INFO - 2016-08-03 14:18:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:18:14 --> Final output sent to browser
DEBUG - 2016-08-03 14:18:14 --> Total execution time: 0.0729
INFO - 2016-08-03 14:18:27 --> Config Class Initialized
INFO - 2016-08-03 14:18:27 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:18:27 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:18:27 --> Utf8 Class Initialized
INFO - 2016-08-03 14:18:27 --> URI Class Initialized
INFO - 2016-08-03 14:18:27 --> Router Class Initialized
INFO - 2016-08-03 14:18:27 --> Output Class Initialized
INFO - 2016-08-03 14:18:27 --> Security Class Initialized
DEBUG - 2016-08-03 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:18:27 --> Input Class Initialized
INFO - 2016-08-03 14:18:27 --> Language Class Initialized
INFO - 2016-08-03 14:18:27 --> Loader Class Initialized
INFO - 2016-08-03 14:18:27 --> Helper loaded: url_helper
INFO - 2016-08-03 14:18:27 --> Helper loaded: language_helper
INFO - 2016-08-03 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:18:27 --> Controller Class Initialized
INFO - 2016-08-03 14:18:27 --> Database Driver Class Initialized
INFO - 2016-08-03 14:18:27 --> Model Class Initialized
INFO - 2016-08-03 14:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:18:27 --> Final output sent to browser
DEBUG - 2016-08-03 14:18:27 --> Total execution time: 0.0636
INFO - 2016-08-03 14:18:40 --> Config Class Initialized
INFO - 2016-08-03 14:18:40 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:18:40 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:18:40 --> Utf8 Class Initialized
INFO - 2016-08-03 14:18:40 --> URI Class Initialized
INFO - 2016-08-03 14:18:40 --> Router Class Initialized
INFO - 2016-08-03 14:18:40 --> Output Class Initialized
INFO - 2016-08-03 14:18:40 --> Security Class Initialized
DEBUG - 2016-08-03 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:18:40 --> Input Class Initialized
INFO - 2016-08-03 14:18:40 --> Language Class Initialized
INFO - 2016-08-03 14:18:40 --> Loader Class Initialized
INFO - 2016-08-03 14:18:40 --> Helper loaded: url_helper
INFO - 2016-08-03 14:18:40 --> Helper loaded: language_helper
INFO - 2016-08-03 14:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:18:40 --> Controller Class Initialized
INFO - 2016-08-03 14:18:40 --> Database Driver Class Initialized
INFO - 2016-08-03 14:18:40 --> Model Class Initialized
INFO - 2016-08-03 14:18:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:18:40 --> Final output sent to browser
DEBUG - 2016-08-03 14:18:40 --> Total execution time: 0.0633
INFO - 2016-08-03 14:22:40 --> Config Class Initialized
INFO - 2016-08-03 14:22:40 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:22:40 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:22:40 --> Utf8 Class Initialized
INFO - 2016-08-03 14:22:40 --> URI Class Initialized
INFO - 2016-08-03 14:22:40 --> Router Class Initialized
INFO - 2016-08-03 14:22:40 --> Output Class Initialized
INFO - 2016-08-03 14:22:40 --> Security Class Initialized
DEBUG - 2016-08-03 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:22:40 --> Input Class Initialized
INFO - 2016-08-03 14:22:40 --> Language Class Initialized
INFO - 2016-08-03 14:22:40 --> Loader Class Initialized
INFO - 2016-08-03 14:22:40 --> Helper loaded: url_helper
INFO - 2016-08-03 14:22:40 --> Helper loaded: language_helper
INFO - 2016-08-03 14:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:22:40 --> Controller Class Initialized
INFO - 2016-08-03 14:22:40 --> Database Driver Class Initialized
INFO - 2016-08-03 14:22:40 --> Model Class Initialized
INFO - 2016-08-03 14:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:22:40 --> Final output sent to browser
DEBUG - 2016-08-03 14:22:40 --> Total execution time: 0.0690
INFO - 2016-08-03 14:22:45 --> Config Class Initialized
INFO - 2016-08-03 14:22:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:22:45 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:22:45 --> Utf8 Class Initialized
INFO - 2016-08-03 14:22:45 --> URI Class Initialized
INFO - 2016-08-03 14:22:45 --> Router Class Initialized
INFO - 2016-08-03 14:22:45 --> Output Class Initialized
INFO - 2016-08-03 14:22:45 --> Security Class Initialized
DEBUG - 2016-08-03 14:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:22:45 --> Input Class Initialized
INFO - 2016-08-03 14:22:45 --> Language Class Initialized
INFO - 2016-08-03 14:22:45 --> Loader Class Initialized
INFO - 2016-08-03 14:22:45 --> Helper loaded: url_helper
INFO - 2016-08-03 14:22:45 --> Helper loaded: language_helper
INFO - 2016-08-03 14:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:22:45 --> Controller Class Initialized
INFO - 2016-08-03 14:22:45 --> Database Driver Class Initialized
INFO - 2016-08-03 14:22:45 --> Model Class Initialized
INFO - 2016-08-03 14:22:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:22:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:22:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:22:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:22:45 --> Final output sent to browser
DEBUG - 2016-08-03 14:22:45 --> Total execution time: 0.0631
INFO - 2016-08-03 14:22:52 --> Config Class Initialized
INFO - 2016-08-03 14:22:52 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:22:52 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:22:52 --> Utf8 Class Initialized
INFO - 2016-08-03 14:22:52 --> URI Class Initialized
INFO - 2016-08-03 14:22:52 --> Router Class Initialized
INFO - 2016-08-03 14:22:52 --> Output Class Initialized
INFO - 2016-08-03 14:22:52 --> Security Class Initialized
DEBUG - 2016-08-03 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:22:52 --> Input Class Initialized
INFO - 2016-08-03 14:22:52 --> Language Class Initialized
INFO - 2016-08-03 14:22:52 --> Loader Class Initialized
INFO - 2016-08-03 14:22:52 --> Helper loaded: url_helper
INFO - 2016-08-03 14:22:52 --> Helper loaded: language_helper
INFO - 2016-08-03 14:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:22:52 --> Controller Class Initialized
INFO - 2016-08-03 14:22:52 --> Database Driver Class Initialized
INFO - 2016-08-03 14:22:52 --> Model Class Initialized
INFO - 2016-08-03 14:22:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:22:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:22:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:22:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:22:52 --> Final output sent to browser
DEBUG - 2016-08-03 14:22:52 --> Total execution time: 0.0636
INFO - 2016-08-03 14:22:57 --> Config Class Initialized
INFO - 2016-08-03 14:22:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:22:57 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:22:57 --> Utf8 Class Initialized
INFO - 2016-08-03 14:22:57 --> URI Class Initialized
INFO - 2016-08-03 14:22:57 --> Router Class Initialized
INFO - 2016-08-03 14:22:57 --> Output Class Initialized
INFO - 2016-08-03 14:22:57 --> Security Class Initialized
DEBUG - 2016-08-03 14:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:22:57 --> Input Class Initialized
INFO - 2016-08-03 14:22:57 --> Language Class Initialized
INFO - 2016-08-03 14:22:57 --> Loader Class Initialized
INFO - 2016-08-03 14:22:57 --> Helper loaded: url_helper
INFO - 2016-08-03 14:22:57 --> Helper loaded: language_helper
INFO - 2016-08-03 14:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:22:57 --> Controller Class Initialized
INFO - 2016-08-03 14:22:57 --> Database Driver Class Initialized
INFO - 2016-08-03 14:22:57 --> Model Class Initialized
INFO - 2016-08-03 14:22:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:22:57 --> Final output sent to browser
DEBUG - 2016-08-03 14:22:57 --> Total execution time: 0.0603
INFO - 2016-08-03 14:28:20 --> Config Class Initialized
INFO - 2016-08-03 14:28:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:28:20 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:28:20 --> Utf8 Class Initialized
INFO - 2016-08-03 14:28:20 --> URI Class Initialized
INFO - 2016-08-03 14:28:20 --> Router Class Initialized
INFO - 2016-08-03 14:28:20 --> Output Class Initialized
INFO - 2016-08-03 14:28:20 --> Security Class Initialized
DEBUG - 2016-08-03 14:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:28:20 --> Input Class Initialized
INFO - 2016-08-03 14:28:20 --> Language Class Initialized
INFO - 2016-08-03 14:28:20 --> Loader Class Initialized
INFO - 2016-08-03 14:28:20 --> Helper loaded: url_helper
INFO - 2016-08-03 14:28:20 --> Helper loaded: language_helper
INFO - 2016-08-03 14:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:28:20 --> Controller Class Initialized
INFO - 2016-08-03 14:28:20 --> Database Driver Class Initialized
INFO - 2016-08-03 14:28:20 --> Model Class Initialized
INFO - 2016-08-03 14:28:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:28:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:28:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:28:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:28:20 --> Final output sent to browser
DEBUG - 2016-08-03 14:28:20 --> Total execution time: 0.0670
INFO - 2016-08-03 14:29:53 --> Config Class Initialized
INFO - 2016-08-03 14:29:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:29:53 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:29:53 --> Utf8 Class Initialized
INFO - 2016-08-03 14:29:53 --> URI Class Initialized
INFO - 2016-08-03 14:29:53 --> Router Class Initialized
INFO - 2016-08-03 14:29:53 --> Output Class Initialized
INFO - 2016-08-03 14:29:53 --> Security Class Initialized
DEBUG - 2016-08-03 14:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:29:53 --> Input Class Initialized
INFO - 2016-08-03 14:29:53 --> Language Class Initialized
INFO - 2016-08-03 14:29:53 --> Loader Class Initialized
INFO - 2016-08-03 14:29:53 --> Helper loaded: url_helper
INFO - 2016-08-03 14:29:53 --> Helper loaded: language_helper
INFO - 2016-08-03 14:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:29:53 --> Controller Class Initialized
INFO - 2016-08-03 14:29:53 --> Database Driver Class Initialized
INFO - 2016-08-03 14:29:53 --> Model Class Initialized
INFO - 2016-08-03 14:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:29:53 --> Final output sent to browser
DEBUG - 2016-08-03 14:29:53 --> Total execution time: 0.0710
INFO - 2016-08-03 14:31:04 --> Config Class Initialized
INFO - 2016-08-03 14:31:04 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:04 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:31:04 --> Utf8 Class Initialized
INFO - 2016-08-03 14:31:04 --> URI Class Initialized
INFO - 2016-08-03 14:31:04 --> Router Class Initialized
INFO - 2016-08-03 14:31:04 --> Output Class Initialized
INFO - 2016-08-03 14:31:04 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:31:04 --> Input Class Initialized
INFO - 2016-08-03 14:31:04 --> Language Class Initialized
INFO - 2016-08-03 14:31:04 --> Loader Class Initialized
INFO - 2016-08-03 14:31:04 --> Helper loaded: url_helper
INFO - 2016-08-03 14:31:04 --> Helper loaded: language_helper
INFO - 2016-08-03 14:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:31:04 --> Controller Class Initialized
INFO - 2016-08-03 14:31:04 --> Database Driver Class Initialized
INFO - 2016-08-03 14:31:04 --> Model Class Initialized
INFO - 2016-08-03 14:31:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:31:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:31:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:31:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:31:04 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:04 --> Total execution time: 0.0562
INFO - 2016-08-03 14:31:35 --> Config Class Initialized
INFO - 2016-08-03 14:31:35 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:35 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:31:35 --> Utf8 Class Initialized
INFO - 2016-08-03 14:31:35 --> URI Class Initialized
INFO - 2016-08-03 14:31:35 --> Router Class Initialized
INFO - 2016-08-03 14:31:35 --> Output Class Initialized
INFO - 2016-08-03 14:31:35 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:31:35 --> Input Class Initialized
INFO - 2016-08-03 14:31:35 --> Language Class Initialized
INFO - 2016-08-03 14:31:35 --> Loader Class Initialized
INFO - 2016-08-03 14:31:35 --> Helper loaded: url_helper
INFO - 2016-08-03 14:31:35 --> Helper loaded: language_helper
INFO - 2016-08-03 14:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:31:35 --> Controller Class Initialized
INFO - 2016-08-03 14:31:35 --> Database Driver Class Initialized
INFO - 2016-08-03 14:31:35 --> Model Class Initialized
INFO - 2016-08-03 14:31:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:31:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:31:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:31:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:31:35 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:35 --> Total execution time: 0.0642
INFO - 2016-08-03 14:32:36 --> Config Class Initialized
INFO - 2016-08-03 14:32:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:32:36 --> UTF-8 Support Enabled
INFO - 2016-08-03 14:32:36 --> Utf8 Class Initialized
INFO - 2016-08-03 14:32:36 --> URI Class Initialized
INFO - 2016-08-03 14:32:36 --> Router Class Initialized
INFO - 2016-08-03 14:32:36 --> Output Class Initialized
INFO - 2016-08-03 14:32:36 --> Security Class Initialized
DEBUG - 2016-08-03 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 14:32:36 --> Input Class Initialized
INFO - 2016-08-03 14:32:36 --> Language Class Initialized
INFO - 2016-08-03 14:32:36 --> Loader Class Initialized
INFO - 2016-08-03 14:32:36 --> Helper loaded: url_helper
INFO - 2016-08-03 14:32:36 --> Helper loaded: language_helper
INFO - 2016-08-03 14:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 14:32:36 --> Controller Class Initialized
INFO - 2016-08-03 14:32:36 --> Database Driver Class Initialized
INFO - 2016-08-03 14:32:36 --> Model Class Initialized
INFO - 2016-08-03 14:32:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 14:32:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 14:32:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 14:32:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 14:32:36 --> Final output sent to browser
DEBUG - 2016-08-03 14:32:36 --> Total execution time: 0.0626
INFO - 2016-08-03 16:59:48 --> Config Class Initialized
INFO - 2016-08-03 16:59:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 16:59:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 16:59:48 --> Utf8 Class Initialized
INFO - 2016-08-03 16:59:48 --> URI Class Initialized
INFO - 2016-08-03 16:59:48 --> Router Class Initialized
INFO - 2016-08-03 16:59:48 --> Output Class Initialized
INFO - 2016-08-03 16:59:48 --> Security Class Initialized
DEBUG - 2016-08-03 16:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 16:59:48 --> Input Class Initialized
INFO - 2016-08-03 16:59:48 --> Language Class Initialized
INFO - 2016-08-03 16:59:48 --> Loader Class Initialized
INFO - 2016-08-03 16:59:48 --> Helper loaded: url_helper
INFO - 2016-08-03 16:59:48 --> Helper loaded: language_helper
INFO - 2016-08-03 16:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 16:59:48 --> Controller Class Initialized
INFO - 2016-08-03 16:59:48 --> Database Driver Class Initialized
INFO - 2016-08-03 16:59:48 --> Model Class Initialized
INFO - 2016-08-03 16:59:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 16:59:48 --> Config Class Initialized
INFO - 2016-08-03 16:59:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 16:59:48 --> UTF-8 Support Enabled
INFO - 2016-08-03 16:59:48 --> Utf8 Class Initialized
INFO - 2016-08-03 16:59:48 --> URI Class Initialized
INFO - 2016-08-03 16:59:48 --> Router Class Initialized
INFO - 2016-08-03 16:59:48 --> Output Class Initialized
INFO - 2016-08-03 16:59:48 --> Security Class Initialized
DEBUG - 2016-08-03 16:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 16:59:48 --> Input Class Initialized
INFO - 2016-08-03 16:59:48 --> Language Class Initialized
INFO - 2016-08-03 16:59:48 --> Loader Class Initialized
INFO - 2016-08-03 16:59:48 --> Helper loaded: url_helper
INFO - 2016-08-03 16:59:48 --> Helper loaded: language_helper
INFO - 2016-08-03 16:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 16:59:48 --> Controller Class Initialized
INFO - 2016-08-03 16:59:48 --> Database Driver Class Initialized
INFO - 2016-08-03 16:59:48 --> Model Class Initialized
INFO - 2016-08-03 16:59:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 16:59:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 16:59:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 16:59:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 16:59:48 --> Final output sent to browser
DEBUG - 2016-08-03 16:59:48 --> Total execution time: 0.0627
INFO - 2016-08-03 16:59:54 --> Config Class Initialized
INFO - 2016-08-03 16:59:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 16:59:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 16:59:54 --> Utf8 Class Initialized
INFO - 2016-08-03 16:59:54 --> URI Class Initialized
INFO - 2016-08-03 16:59:54 --> Router Class Initialized
INFO - 2016-08-03 16:59:54 --> Output Class Initialized
INFO - 2016-08-03 16:59:54 --> Security Class Initialized
DEBUG - 2016-08-03 16:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 16:59:54 --> Input Class Initialized
INFO - 2016-08-03 16:59:54 --> Language Class Initialized
INFO - 2016-08-03 16:59:54 --> Loader Class Initialized
INFO - 2016-08-03 16:59:54 --> Helper loaded: url_helper
INFO - 2016-08-03 16:59:54 --> Helper loaded: language_helper
INFO - 2016-08-03 16:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 16:59:54 --> Controller Class Initialized
INFO - 2016-08-03 16:59:54 --> Database Driver Class Initialized
INFO - 2016-08-03 16:59:54 --> Model Class Initialized
INFO - 2016-08-03 16:59:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 16:59:54 --> Config Class Initialized
INFO - 2016-08-03 16:59:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 16:59:54 --> UTF-8 Support Enabled
INFO - 2016-08-03 16:59:54 --> Utf8 Class Initialized
INFO - 2016-08-03 16:59:54 --> URI Class Initialized
INFO - 2016-08-03 16:59:54 --> Router Class Initialized
INFO - 2016-08-03 16:59:54 --> Output Class Initialized
INFO - 2016-08-03 16:59:54 --> Security Class Initialized
DEBUG - 2016-08-03 16:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 16:59:54 --> Input Class Initialized
INFO - 2016-08-03 16:59:54 --> Language Class Initialized
INFO - 2016-08-03 16:59:54 --> Loader Class Initialized
INFO - 2016-08-03 16:59:54 --> Helper loaded: url_helper
INFO - 2016-08-03 16:59:54 --> Helper loaded: language_helper
INFO - 2016-08-03 16:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 16:59:54 --> Controller Class Initialized
INFO - 2016-08-03 16:59:54 --> Database Driver Class Initialized
INFO - 2016-08-03 16:59:54 --> Model Class Initialized
INFO - 2016-08-03 16:59:54 --> Model Class Initialized
INFO - 2016-08-03 16:59:54 --> Model Class Initialized
INFO - 2016-08-03 16:59:54 --> Model Class Initialized
INFO - 2016-08-03 16:59:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 16:59:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 16:59:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 16:59:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 16:59:54 --> Final output sent to browser
DEBUG - 2016-08-03 16:59:54 --> Total execution time: 0.0703
INFO - 2016-08-03 16:59:57 --> Config Class Initialized
INFO - 2016-08-03 16:59:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 16:59:57 --> UTF-8 Support Enabled
INFO - 2016-08-03 16:59:57 --> Utf8 Class Initialized
INFO - 2016-08-03 16:59:57 --> URI Class Initialized
INFO - 2016-08-03 16:59:57 --> Router Class Initialized
INFO - 2016-08-03 16:59:57 --> Output Class Initialized
INFO - 2016-08-03 16:59:57 --> Security Class Initialized
DEBUG - 2016-08-03 16:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 16:59:57 --> Input Class Initialized
INFO - 2016-08-03 16:59:57 --> Language Class Initialized
INFO - 2016-08-03 16:59:57 --> Loader Class Initialized
INFO - 2016-08-03 16:59:57 --> Helper loaded: url_helper
INFO - 2016-08-03 16:59:57 --> Helper loaded: language_helper
INFO - 2016-08-03 16:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 16:59:57 --> Controller Class Initialized
INFO - 2016-08-03 16:59:57 --> Database Driver Class Initialized
INFO - 2016-08-03 16:59:57 --> Model Class Initialized
INFO - 2016-08-03 16:59:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 16:59:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 16:59:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 16:59:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 16:59:57 --> Final output sent to browser
DEBUG - 2016-08-03 16:59:57 --> Total execution time: 0.0544
INFO - 2016-08-03 17:00:01 --> Config Class Initialized
INFO - 2016-08-03 17:00:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 17:00:01 --> UTF-8 Support Enabled
INFO - 2016-08-03 17:00:01 --> Utf8 Class Initialized
INFO - 2016-08-03 17:00:01 --> URI Class Initialized
INFO - 2016-08-03 17:00:01 --> Router Class Initialized
INFO - 2016-08-03 17:00:01 --> Output Class Initialized
INFO - 2016-08-03 17:00:01 --> Security Class Initialized
DEBUG - 2016-08-03 17:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 17:00:01 --> Input Class Initialized
INFO - 2016-08-03 17:00:01 --> Language Class Initialized
INFO - 2016-08-03 17:00:01 --> Loader Class Initialized
INFO - 2016-08-03 17:00:01 --> Helper loaded: url_helper
INFO - 2016-08-03 17:00:01 --> Helper loaded: language_helper
INFO - 2016-08-03 17:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 17:00:01 --> Controller Class Initialized
INFO - 2016-08-03 17:00:01 --> Database Driver Class Initialized
INFO - 2016-08-03 17:00:01 --> Model Class Initialized
INFO - 2016-08-03 17:00:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 17:00:01 --> Config Class Initialized
INFO - 2016-08-03 17:00:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 17:00:01 --> UTF-8 Support Enabled
INFO - 2016-08-03 17:00:01 --> Utf8 Class Initialized
INFO - 2016-08-03 17:00:01 --> URI Class Initialized
INFO - 2016-08-03 17:00:01 --> Router Class Initialized
INFO - 2016-08-03 17:00:01 --> Output Class Initialized
INFO - 2016-08-03 17:00:01 --> Security Class Initialized
DEBUG - 2016-08-03 17:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 17:00:01 --> Input Class Initialized
INFO - 2016-08-03 17:00:01 --> Language Class Initialized
INFO - 2016-08-03 17:00:01 --> Loader Class Initialized
INFO - 2016-08-03 17:00:01 --> Helper loaded: url_helper
INFO - 2016-08-03 17:00:01 --> Helper loaded: language_helper
INFO - 2016-08-03 17:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 17:00:01 --> Controller Class Initialized
INFO - 2016-08-03 17:00:01 --> Database Driver Class Initialized
INFO - 2016-08-03 17:00:01 --> Model Class Initialized
INFO - 2016-08-03 17:00:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 17:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 17:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 17:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 17:00:01 --> Final output sent to browser
DEBUG - 2016-08-03 17:00:01 --> Total execution time: 0.0588
INFO - 2016-08-03 17:01:23 --> Config Class Initialized
INFO - 2016-08-03 17:01:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 17:01:23 --> UTF-8 Support Enabled
INFO - 2016-08-03 17:01:23 --> Utf8 Class Initialized
INFO - 2016-08-03 17:01:23 --> URI Class Initialized
INFO - 2016-08-03 17:01:23 --> Router Class Initialized
INFO - 2016-08-03 17:01:23 --> Output Class Initialized
INFO - 2016-08-03 17:01:23 --> Security Class Initialized
DEBUG - 2016-08-03 17:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 17:01:23 --> Input Class Initialized
INFO - 2016-08-03 17:01:23 --> Language Class Initialized
INFO - 2016-08-03 17:01:23 --> Loader Class Initialized
INFO - 2016-08-03 17:01:23 --> Helper loaded: url_helper
INFO - 2016-08-03 17:01:23 --> Helper loaded: language_helper
INFO - 2016-08-03 17:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 17:01:23 --> Controller Class Initialized
INFO - 2016-08-03 17:01:23 --> Database Driver Class Initialized
INFO - 2016-08-03 17:01:23 --> Model Class Initialized
INFO - 2016-08-03 17:01:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 17:01:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 17:01:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 17:01:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 17:01:23 --> Final output sent to browser
DEBUG - 2016-08-03 17:01:23 --> Total execution time: 0.0585
INFO - 2016-08-03 17:02:11 --> Config Class Initialized
INFO - 2016-08-03 17:02:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 17:02:11 --> UTF-8 Support Enabled
INFO - 2016-08-03 17:02:11 --> Utf8 Class Initialized
INFO - 2016-08-03 17:02:11 --> URI Class Initialized
INFO - 2016-08-03 17:02:11 --> Router Class Initialized
INFO - 2016-08-03 17:02:11 --> Output Class Initialized
INFO - 2016-08-03 17:02:11 --> Security Class Initialized
DEBUG - 2016-08-03 17:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 17:02:11 --> Input Class Initialized
INFO - 2016-08-03 17:02:11 --> Language Class Initialized
INFO - 2016-08-03 17:02:11 --> Loader Class Initialized
INFO - 2016-08-03 17:02:11 --> Helper loaded: url_helper
INFO - 2016-08-03 17:02:11 --> Helper loaded: language_helper
INFO - 2016-08-03 17:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 17:02:11 --> Controller Class Initialized
INFO - 2016-08-03 17:02:11 --> Database Driver Class Initialized
INFO - 2016-08-03 17:02:11 --> Model Class Initialized
INFO - 2016-08-03 17:02:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 17:02:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 17:02:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 17:02:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 17:02:11 --> Final output sent to browser
DEBUG - 2016-08-03 17:02:11 --> Total execution time: 0.0662
INFO - 2016-08-03 17:32:23 --> Config Class Initialized
INFO - 2016-08-03 17:32:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 17:32:23 --> UTF-8 Support Enabled
INFO - 2016-08-03 17:32:23 --> Utf8 Class Initialized
INFO - 2016-08-03 17:32:23 --> URI Class Initialized
INFO - 2016-08-03 17:32:23 --> Router Class Initialized
INFO - 2016-08-03 17:32:23 --> Output Class Initialized
INFO - 2016-08-03 17:32:23 --> Security Class Initialized
DEBUG - 2016-08-03 17:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 17:32:23 --> Input Class Initialized
INFO - 2016-08-03 17:32:23 --> Language Class Initialized
INFO - 2016-08-03 17:32:23 --> Loader Class Initialized
INFO - 2016-08-03 17:32:23 --> Helper loaded: url_helper
INFO - 2016-08-03 17:32:23 --> Helper loaded: language_helper
INFO - 2016-08-03 17:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 17:32:23 --> Controller Class Initialized
INFO - 2016-08-03 17:32:23 --> Database Driver Class Initialized
INFO - 2016-08-03 17:32:23 --> Model Class Initialized
INFO - 2016-08-03 17:32:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 17:32:23 --> Helper loaded: form_helper
INFO - 2016-08-03 17:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 17:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-08-03 17:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 17:32:23 --> Final output sent to browser
DEBUG - 2016-08-03 17:32:23 --> Total execution time: 0.0747
INFO - 2016-08-03 17:32:33 --> Config Class Initialized
INFO - 2016-08-03 17:32:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 17:32:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 17:32:33 --> Utf8 Class Initialized
INFO - 2016-08-03 17:32:33 --> URI Class Initialized
INFO - 2016-08-03 17:32:33 --> Router Class Initialized
INFO - 2016-08-03 17:32:33 --> Output Class Initialized
INFO - 2016-08-03 17:32:33 --> Security Class Initialized
DEBUG - 2016-08-03 17:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 17:32:33 --> Input Class Initialized
INFO - 2016-08-03 17:32:33 --> Language Class Initialized
INFO - 2016-08-03 17:32:33 --> Loader Class Initialized
INFO - 2016-08-03 17:32:33 --> Helper loaded: url_helper
INFO - 2016-08-03 17:32:33 --> Helper loaded: language_helper
INFO - 2016-08-03 17:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 17:32:33 --> Controller Class Initialized
INFO - 2016-08-03 17:32:33 --> Database Driver Class Initialized
INFO - 2016-08-03 17:32:33 --> Model Class Initialized
INFO - 2016-08-03 17:32:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 17:32:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 17:32:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-08-03 17:32:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 17:32:33 --> Final output sent to browser
DEBUG - 2016-08-03 17:32:33 --> Total execution time: 0.0619
INFO - 2016-08-03 22:01:38 --> Config Class Initialized
INFO - 2016-08-03 22:01:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:38 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:38 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:38 --> URI Class Initialized
INFO - 2016-08-03 22:01:38 --> Router Class Initialized
INFO - 2016-08-03 22:01:38 --> Output Class Initialized
INFO - 2016-08-03 22:01:38 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:38 --> Input Class Initialized
INFO - 2016-08-03 22:01:38 --> Language Class Initialized
INFO - 2016-08-03 22:01:38 --> Loader Class Initialized
INFO - 2016-08-03 22:01:38 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:38 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:38 --> Controller Class Initialized
INFO - 2016-08-03 22:01:38 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:38 --> Model Class Initialized
INFO - 2016-08-03 22:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:38 --> Config Class Initialized
INFO - 2016-08-03 22:01:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:38 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:38 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:38 --> URI Class Initialized
INFO - 2016-08-03 22:01:38 --> Router Class Initialized
INFO - 2016-08-03 22:01:38 --> Output Class Initialized
INFO - 2016-08-03 22:01:38 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:38 --> Input Class Initialized
INFO - 2016-08-03 22:01:38 --> Language Class Initialized
INFO - 2016-08-03 22:01:38 --> Loader Class Initialized
INFO - 2016-08-03 22:01:38 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:38 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:38 --> Controller Class Initialized
INFO - 2016-08-03 22:01:38 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:38 --> Model Class Initialized
INFO - 2016-08-03 22:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-03 22:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-03 22:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-03 22:01:38 --> Final output sent to browser
DEBUG - 2016-08-03 22:01:38 --> Total execution time: 0.0532
INFO - 2016-08-03 22:01:43 --> Config Class Initialized
INFO - 2016-08-03 22:01:43 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:43 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:43 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:43 --> URI Class Initialized
INFO - 2016-08-03 22:01:43 --> Router Class Initialized
INFO - 2016-08-03 22:01:43 --> Output Class Initialized
INFO - 2016-08-03 22:01:43 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:43 --> Input Class Initialized
INFO - 2016-08-03 22:01:43 --> Language Class Initialized
INFO - 2016-08-03 22:01:43 --> Loader Class Initialized
INFO - 2016-08-03 22:01:43 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:43 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:43 --> Controller Class Initialized
INFO - 2016-08-03 22:01:43 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:43 --> Model Class Initialized
INFO - 2016-08-03 22:01:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:43 --> Config Class Initialized
INFO - 2016-08-03 22:01:43 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:43 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:43 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:43 --> URI Class Initialized
INFO - 2016-08-03 22:01:43 --> Router Class Initialized
INFO - 2016-08-03 22:01:43 --> Output Class Initialized
INFO - 2016-08-03 22:01:43 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:43 --> Input Class Initialized
INFO - 2016-08-03 22:01:43 --> Language Class Initialized
INFO - 2016-08-03 22:01:43 --> Loader Class Initialized
INFO - 2016-08-03 22:01:43 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:43 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:43 --> Controller Class Initialized
INFO - 2016-08-03 22:01:43 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:43 --> Model Class Initialized
INFO - 2016-08-03 22:01:43 --> Model Class Initialized
INFO - 2016-08-03 22:01:43 --> Model Class Initialized
INFO - 2016-08-03 22:01:43 --> Model Class Initialized
INFO - 2016-08-03 22:01:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 22:01:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-03 22:01:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 22:01:43 --> Final output sent to browser
DEBUG - 2016-08-03 22:01:43 --> Total execution time: 0.0751
INFO - 2016-08-03 22:01:47 --> Config Class Initialized
INFO - 2016-08-03 22:01:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:47 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:47 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:47 --> URI Class Initialized
INFO - 2016-08-03 22:01:47 --> Router Class Initialized
INFO - 2016-08-03 22:01:47 --> Output Class Initialized
INFO - 2016-08-03 22:01:47 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:47 --> Input Class Initialized
INFO - 2016-08-03 22:01:47 --> Language Class Initialized
INFO - 2016-08-03 22:01:47 --> Loader Class Initialized
INFO - 2016-08-03 22:01:47 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:47 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:47 --> Controller Class Initialized
INFO - 2016-08-03 22:01:47 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:47 --> Model Class Initialized
INFO - 2016-08-03 22:01:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 22:01:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-03 22:01:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 22:01:47 --> Final output sent to browser
DEBUG - 2016-08-03 22:01:47 --> Total execution time: 0.0612
INFO - 2016-08-03 22:01:50 --> Config Class Initialized
INFO - 2016-08-03 22:01:50 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:50 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:50 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:50 --> URI Class Initialized
INFO - 2016-08-03 22:01:50 --> Router Class Initialized
INFO - 2016-08-03 22:01:50 --> Output Class Initialized
INFO - 2016-08-03 22:01:50 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:50 --> Input Class Initialized
INFO - 2016-08-03 22:01:50 --> Language Class Initialized
INFO - 2016-08-03 22:01:50 --> Loader Class Initialized
INFO - 2016-08-03 22:01:50 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:50 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:50 --> Controller Class Initialized
INFO - 2016-08-03 22:01:50 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:50 --> Model Class Initialized
INFO - 2016-08-03 22:01:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:50 --> Config Class Initialized
INFO - 2016-08-03 22:01:50 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:01:50 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:01:50 --> Utf8 Class Initialized
INFO - 2016-08-03 22:01:50 --> URI Class Initialized
INFO - 2016-08-03 22:01:50 --> Router Class Initialized
INFO - 2016-08-03 22:01:50 --> Output Class Initialized
INFO - 2016-08-03 22:01:50 --> Security Class Initialized
DEBUG - 2016-08-03 22:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:01:50 --> Input Class Initialized
INFO - 2016-08-03 22:01:50 --> Language Class Initialized
INFO - 2016-08-03 22:01:50 --> Loader Class Initialized
INFO - 2016-08-03 22:01:50 --> Helper loaded: url_helper
INFO - 2016-08-03 22:01:50 --> Helper loaded: language_helper
INFO - 2016-08-03 22:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:01:50 --> Controller Class Initialized
INFO - 2016-08-03 22:01:50 --> Database Driver Class Initialized
INFO - 2016-08-03 22:01:50 --> Model Class Initialized
INFO - 2016-08-03 22:01:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:01:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 22:01:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 22:01:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 22:01:50 --> Final output sent to browser
DEBUG - 2016-08-03 22:01:50 --> Total execution time: 0.0581
INFO - 2016-08-03 22:02:14 --> Config Class Initialized
INFO - 2016-08-03 22:02:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:02:14 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:02:14 --> Utf8 Class Initialized
INFO - 2016-08-03 22:02:14 --> URI Class Initialized
INFO - 2016-08-03 22:02:14 --> Router Class Initialized
INFO - 2016-08-03 22:02:14 --> Output Class Initialized
INFO - 2016-08-03 22:02:14 --> Security Class Initialized
DEBUG - 2016-08-03 22:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:02:14 --> Input Class Initialized
INFO - 2016-08-03 22:02:14 --> Language Class Initialized
INFO - 2016-08-03 22:02:14 --> Loader Class Initialized
INFO - 2016-08-03 22:02:14 --> Helper loaded: url_helper
INFO - 2016-08-03 22:02:14 --> Helper loaded: language_helper
INFO - 2016-08-03 22:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:02:14 --> Controller Class Initialized
INFO - 2016-08-03 22:02:14 --> Database Driver Class Initialized
INFO - 2016-08-03 22:02:14 --> Model Class Initialized
INFO - 2016-08-03 22:02:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:02:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 22:02:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 22:02:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 22:02:14 --> Final output sent to browser
DEBUG - 2016-08-03 22:02:14 --> Total execution time: 0.0574
INFO - 2016-08-03 22:02:33 --> Config Class Initialized
INFO - 2016-08-03 22:02:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 22:02:33 --> UTF-8 Support Enabled
INFO - 2016-08-03 22:02:33 --> Utf8 Class Initialized
INFO - 2016-08-03 22:02:33 --> URI Class Initialized
INFO - 2016-08-03 22:02:33 --> Router Class Initialized
INFO - 2016-08-03 22:02:33 --> Output Class Initialized
INFO - 2016-08-03 22:02:33 --> Security Class Initialized
DEBUG - 2016-08-03 22:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-03 22:02:33 --> Input Class Initialized
INFO - 2016-08-03 22:02:33 --> Language Class Initialized
INFO - 2016-08-03 22:02:33 --> Loader Class Initialized
INFO - 2016-08-03 22:02:33 --> Helper loaded: url_helper
INFO - 2016-08-03 22:02:33 --> Helper loaded: language_helper
INFO - 2016-08-03 22:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-03 22:02:33 --> Controller Class Initialized
INFO - 2016-08-03 22:02:33 --> Database Driver Class Initialized
INFO - 2016-08-03 22:02:33 --> Model Class Initialized
INFO - 2016-08-03 22:02:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-03 22:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-03 22:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-03 22:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-03 22:02:33 --> Final output sent to browser
DEBUG - 2016-08-03 22:02:33 --> Total execution time: 0.0738
