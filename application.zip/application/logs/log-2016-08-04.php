<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-04 08:22:34 --> Config Class Initialized
INFO - 2016-08-04 08:22:34 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:34 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:34 --> URI Class Initialized
INFO - 2016-08-04 08:22:34 --> Router Class Initialized
INFO - 2016-08-04 08:22:34 --> Output Class Initialized
INFO - 2016-08-04 08:22:34 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:34 --> Input Class Initialized
INFO - 2016-08-04 08:22:34 --> Language Class Initialized
INFO - 2016-08-04 08:22:34 --> Loader Class Initialized
INFO - 2016-08-04 08:22:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:34 --> Controller Class Initialized
INFO - 2016-08-04 08:22:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:34 --> Model Class Initialized
INFO - 2016-08-04 08:22:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:34 --> Config Class Initialized
INFO - 2016-08-04 08:22:34 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:34 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:34 --> URI Class Initialized
INFO - 2016-08-04 08:22:34 --> Router Class Initialized
INFO - 2016-08-04 08:22:34 --> Output Class Initialized
INFO - 2016-08-04 08:22:34 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:34 --> Input Class Initialized
INFO - 2016-08-04 08:22:34 --> Language Class Initialized
INFO - 2016-08-04 08:22:34 --> Loader Class Initialized
INFO - 2016-08-04 08:22:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:34 --> Controller Class Initialized
INFO - 2016-08-04 08:22:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:34 --> Model Class Initialized
INFO - 2016-08-04 08:22:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-04 08:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-04 08:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-04 08:22:34 --> Final output sent to browser
DEBUG - 2016-08-04 08:22:34 --> Total execution time: 0.0549
INFO - 2016-08-04 08:22:38 --> Config Class Initialized
INFO - 2016-08-04 08:22:38 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:38 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:38 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:38 --> URI Class Initialized
INFO - 2016-08-04 08:22:38 --> Router Class Initialized
INFO - 2016-08-04 08:22:38 --> Output Class Initialized
INFO - 2016-08-04 08:22:38 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:38 --> Input Class Initialized
INFO - 2016-08-04 08:22:38 --> Language Class Initialized
INFO - 2016-08-04 08:22:38 --> Loader Class Initialized
INFO - 2016-08-04 08:22:38 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:38 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:38 --> Controller Class Initialized
INFO - 2016-08-04 08:22:38 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:38 --> Model Class Initialized
INFO - 2016-08-04 08:22:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:38 --> Config Class Initialized
INFO - 2016-08-04 08:22:38 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:38 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:38 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:38 --> URI Class Initialized
INFO - 2016-08-04 08:22:38 --> Router Class Initialized
INFO - 2016-08-04 08:22:38 --> Output Class Initialized
INFO - 2016-08-04 08:22:38 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:38 --> Input Class Initialized
INFO - 2016-08-04 08:22:38 --> Language Class Initialized
INFO - 2016-08-04 08:22:38 --> Loader Class Initialized
INFO - 2016-08-04 08:22:38 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:38 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:38 --> Controller Class Initialized
INFO - 2016-08-04 08:22:38 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:38 --> Model Class Initialized
INFO - 2016-08-04 08:22:38 --> Model Class Initialized
INFO - 2016-08-04 08:22:38 --> Model Class Initialized
INFO - 2016-08-04 08:22:38 --> Model Class Initialized
INFO - 2016-08-04 08:22:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-04 08:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-04 08:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-04 08:22:38 --> Final output sent to browser
DEBUG - 2016-08-04 08:22:38 --> Total execution time: 0.0821
INFO - 2016-08-04 08:22:42 --> Config Class Initialized
INFO - 2016-08-04 08:22:42 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:42 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:42 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:42 --> URI Class Initialized
INFO - 2016-08-04 08:22:42 --> Router Class Initialized
INFO - 2016-08-04 08:22:42 --> Output Class Initialized
INFO - 2016-08-04 08:22:42 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:42 --> Input Class Initialized
INFO - 2016-08-04 08:22:42 --> Language Class Initialized
INFO - 2016-08-04 08:22:42 --> Loader Class Initialized
INFO - 2016-08-04 08:22:42 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:42 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:42 --> Controller Class Initialized
INFO - 2016-08-04 08:22:42 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:42 --> Model Class Initialized
INFO - 2016-08-04 08:22:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-04 08:22:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-04 08:22:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-04 08:22:42 --> Final output sent to browser
DEBUG - 2016-08-04 08:22:42 --> Total execution time: 0.0529
INFO - 2016-08-04 08:22:46 --> Config Class Initialized
INFO - 2016-08-04 08:22:46 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:46 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:46 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:46 --> URI Class Initialized
INFO - 2016-08-04 08:22:46 --> Router Class Initialized
INFO - 2016-08-04 08:22:46 --> Output Class Initialized
INFO - 2016-08-04 08:22:46 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:46 --> Input Class Initialized
INFO - 2016-08-04 08:22:46 --> Language Class Initialized
INFO - 2016-08-04 08:22:46 --> Loader Class Initialized
INFO - 2016-08-04 08:22:46 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:46 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:46 --> Controller Class Initialized
INFO - 2016-08-04 08:22:46 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:46 --> Model Class Initialized
INFO - 2016-08-04 08:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:46 --> Config Class Initialized
INFO - 2016-08-04 08:22:46 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:46 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:46 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:46 --> URI Class Initialized
INFO - 2016-08-04 08:22:46 --> Router Class Initialized
INFO - 2016-08-04 08:22:46 --> Output Class Initialized
INFO - 2016-08-04 08:22:46 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:46 --> Input Class Initialized
INFO - 2016-08-04 08:22:46 --> Language Class Initialized
INFO - 2016-08-04 08:22:46 --> Loader Class Initialized
INFO - 2016-08-04 08:22:46 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:46 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:46 --> Controller Class Initialized
INFO - 2016-08-04 08:22:46 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:46 --> Model Class Initialized
INFO - 2016-08-04 08:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:22:46 --> Final output sent to browser
DEBUG - 2016-08-04 08:22:46 --> Total execution time: 0.0544
INFO - 2016-08-04 08:22:46 --> Config Class Initialized
INFO - 2016-08-04 08:22:46 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:46 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:46 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:46 --> URI Class Initialized
INFO - 2016-08-04 08:22:46 --> Router Class Initialized
INFO - 2016-08-04 08:22:46 --> Output Class Initialized
INFO - 2016-08-04 08:22:46 --> Security Class Initialized
DEBUG - 2016-08-04 08:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:46 --> Input Class Initialized
INFO - 2016-08-04 08:22:46 --> Language Class Initialized
INFO - 2016-08-04 08:22:46 --> Loader Class Initialized
INFO - 2016-08-04 08:22:46 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:46 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:46 --> Controller Class Initialized
INFO - 2016-08-04 08:22:46 --> Config Class Initialized
INFO - 2016-08-04 08:22:46 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:22:46 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:22:46 --> Utf8 Class Initialized
INFO - 2016-08-04 08:22:46 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:46 --> URI Class Initialized
INFO - 2016-08-04 08:22:46 --> Router Class Initialized
INFO - 2016-08-04 08:22:46 --> Model Class Initialized
INFO - 2016-08-04 08:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:46 --> Output Class Initialized
INFO - 2016-08-04 08:22:46 --> Security Class Initialized
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
DEBUG - 2016-08-04 08:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:22:46 --> Input Class Initialized
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:22:46 --> Final output sent to browser
DEBUG - 2016-08-04 08:22:46 --> Total execution time: 0.0735
INFO - 2016-08-04 08:22:46 --> Language Class Initialized
INFO - 2016-08-04 08:22:46 --> Loader Class Initialized
INFO - 2016-08-04 08:22:46 --> Helper loaded: url_helper
INFO - 2016-08-04 08:22:46 --> Helper loaded: language_helper
INFO - 2016-08-04 08:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:22:46 --> Controller Class Initialized
INFO - 2016-08-04 08:22:46 --> Database Driver Class Initialized
INFO - 2016-08-04 08:22:46 --> Model Class Initialized
INFO - 2016-08-04 08:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:22:46 --> Final output sent to browser
DEBUG - 2016-08-04 08:22:46 --> Total execution time: 0.0867
INFO - 2016-08-04 08:23:34 --> Config Class Initialized
INFO - 2016-08-04 08:23:34 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:23:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:23:34 --> Utf8 Class Initialized
INFO - 2016-08-04 08:23:34 --> URI Class Initialized
INFO - 2016-08-04 08:23:34 --> Router Class Initialized
INFO - 2016-08-04 08:23:34 --> Output Class Initialized
INFO - 2016-08-04 08:23:34 --> Security Class Initialized
DEBUG - 2016-08-04 08:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:23:34 --> Input Class Initialized
INFO - 2016-08-04 08:23:34 --> Language Class Initialized
INFO - 2016-08-04 08:23:34 --> Loader Class Initialized
INFO - 2016-08-04 08:23:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:23:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:23:34 --> Controller Class Initialized
INFO - 2016-08-04 08:23:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:23:34 --> Model Class Initialized
INFO - 2016-08-04 08:23:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:23:34 --> Final output sent to browser
DEBUG - 2016-08-04 08:23:34 --> Total execution time: 0.0569
INFO - 2016-08-04 08:23:34 --> Config Class Initialized
INFO - 2016-08-04 08:23:34 --> Hooks Class Initialized
INFO - 2016-08-04 08:23:34 --> Config Class Initialized
INFO - 2016-08-04 08:23:34 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:23:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:23:34 --> Utf8 Class Initialized
DEBUG - 2016-08-04 08:23:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:23:34 --> URI Class Initialized
INFO - 2016-08-04 08:23:34 --> Utf8 Class Initialized
INFO - 2016-08-04 08:23:34 --> URI Class Initialized
INFO - 2016-08-04 08:23:34 --> Router Class Initialized
INFO - 2016-08-04 08:23:34 --> Router Class Initialized
INFO - 2016-08-04 08:23:34 --> Output Class Initialized
INFO - 2016-08-04 08:23:34 --> Output Class Initialized
INFO - 2016-08-04 08:23:34 --> Security Class Initialized
INFO - 2016-08-04 08:23:34 --> Security Class Initialized
DEBUG - 2016-08-04 08:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:23:34 --> Input Class Initialized
INFO - 2016-08-04 08:23:34 --> Language Class Initialized
DEBUG - 2016-08-04 08:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:23:34 --> Input Class Initialized
INFO - 2016-08-04 08:23:34 --> Language Class Initialized
INFO - 2016-08-04 08:23:34 --> Loader Class Initialized
INFO - 2016-08-04 08:23:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:23:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:23:34 --> Loader Class Initialized
INFO - 2016-08-04 08:23:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:23:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:23:34 --> Controller Class Initialized
INFO - 2016-08-04 08:23:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:23:34 --> Model Class Initialized
INFO - 2016-08-04 08:23:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:23:34 --> Final output sent to browser
DEBUG - 2016-08-04 08:23:34 --> Total execution time: 0.0761
INFO - 2016-08-04 08:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:23:34 --> Controller Class Initialized
INFO - 2016-08-04 08:23:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:23:34 --> Model Class Initialized
INFO - 2016-08-04 08:23:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:23:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:23:34 --> Final output sent to browser
DEBUG - 2016-08-04 08:23:34 --> Total execution time: 0.1017
INFO - 2016-08-04 08:25:00 --> Config Class Initialized
INFO - 2016-08-04 08:25:00 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:25:00 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:25:00 --> Utf8 Class Initialized
INFO - 2016-08-04 08:25:00 --> URI Class Initialized
INFO - 2016-08-04 08:25:00 --> Router Class Initialized
INFO - 2016-08-04 08:25:00 --> Output Class Initialized
INFO - 2016-08-04 08:25:00 --> Security Class Initialized
DEBUG - 2016-08-04 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:25:00 --> Input Class Initialized
INFO - 2016-08-04 08:25:00 --> Language Class Initialized
INFO - 2016-08-04 08:25:00 --> Loader Class Initialized
INFO - 2016-08-04 08:25:00 --> Helper loaded: url_helper
INFO - 2016-08-04 08:25:00 --> Helper loaded: language_helper
INFO - 2016-08-04 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:25:00 --> Controller Class Initialized
INFO - 2016-08-04 08:25:00 --> Database Driver Class Initialized
INFO - 2016-08-04 08:25:00 --> Model Class Initialized
INFO - 2016-08-04 08:25:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:25:00 --> Final output sent to browser
DEBUG - 2016-08-04 08:25:00 --> Total execution time: 0.0619
INFO - 2016-08-04 08:25:00 --> Config Class Initialized
INFO - 2016-08-04 08:25:00 --> Hooks Class Initialized
INFO - 2016-08-04 08:25:00 --> Config Class Initialized
INFO - 2016-08-04 08:25:00 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:25:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-04 08:25:00 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:25:00 --> Utf8 Class Initialized
INFO - 2016-08-04 08:25:00 --> Utf8 Class Initialized
INFO - 2016-08-04 08:25:00 --> URI Class Initialized
INFO - 2016-08-04 08:25:00 --> URI Class Initialized
INFO - 2016-08-04 08:25:00 --> Router Class Initialized
INFO - 2016-08-04 08:25:00 --> Router Class Initialized
INFO - 2016-08-04 08:25:00 --> Output Class Initialized
INFO - 2016-08-04 08:25:00 --> Output Class Initialized
INFO - 2016-08-04 08:25:00 --> Security Class Initialized
INFO - 2016-08-04 08:25:00 --> Security Class Initialized
DEBUG - 2016-08-04 08:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-04 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:25:00 --> Input Class Initialized
INFO - 2016-08-04 08:25:00 --> Input Class Initialized
INFO - 2016-08-04 08:25:00 --> Language Class Initialized
INFO - 2016-08-04 08:25:00 --> Language Class Initialized
INFO - 2016-08-04 08:25:00 --> Loader Class Initialized
INFO - 2016-08-04 08:25:00 --> Loader Class Initialized
INFO - 2016-08-04 08:25:00 --> Helper loaded: url_helper
INFO - 2016-08-04 08:25:00 --> Helper loaded: language_helper
INFO - 2016-08-04 08:25:00 --> Helper loaded: url_helper
INFO - 2016-08-04 08:25:00 --> Helper loaded: language_helper
INFO - 2016-08-04 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:25:00 --> Controller Class Initialized
INFO - 2016-08-04 08:25:00 --> Database Driver Class Initialized
INFO - 2016-08-04 08:25:00 --> Model Class Initialized
INFO - 2016-08-04 08:25:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:25:00 --> Final output sent to browser
DEBUG - 2016-08-04 08:25:00 --> Total execution time: 0.0708
INFO - 2016-08-04 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:25:00 --> Controller Class Initialized
INFO - 2016-08-04 08:25:00 --> Database Driver Class Initialized
INFO - 2016-08-04 08:25:00 --> Model Class Initialized
INFO - 2016-08-04 08:25:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:25:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:25:00 --> Final output sent to browser
DEBUG - 2016-08-04 08:25:00 --> Total execution time: 0.0967
INFO - 2016-08-04 08:26:00 --> Config Class Initialized
INFO - 2016-08-04 08:26:00 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:26:00 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:26:00 --> Utf8 Class Initialized
INFO - 2016-08-04 08:26:00 --> URI Class Initialized
INFO - 2016-08-04 08:26:00 --> Router Class Initialized
INFO - 2016-08-04 08:26:00 --> Output Class Initialized
INFO - 2016-08-04 08:26:00 --> Security Class Initialized
DEBUG - 2016-08-04 08:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:26:00 --> Input Class Initialized
INFO - 2016-08-04 08:26:00 --> Language Class Initialized
INFO - 2016-08-04 08:26:00 --> Loader Class Initialized
INFO - 2016-08-04 08:26:00 --> Helper loaded: url_helper
INFO - 2016-08-04 08:26:00 --> Helper loaded: language_helper
INFO - 2016-08-04 08:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:26:00 --> Controller Class Initialized
INFO - 2016-08-04 08:26:00 --> Database Driver Class Initialized
INFO - 2016-08-04 08:26:00 --> Model Class Initialized
INFO - 2016-08-04 08:26:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:26:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:26:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:26:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:26:00 --> Final output sent to browser
DEBUG - 2016-08-04 08:26:00 --> Total execution time: 0.0701
INFO - 2016-08-04 08:26:02 --> Config Class Initialized
INFO - 2016-08-04 08:26:02 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:26:02 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:26:02 --> Utf8 Class Initialized
INFO - 2016-08-04 08:26:02 --> URI Class Initialized
INFO - 2016-08-04 08:26:02 --> Router Class Initialized
INFO - 2016-08-04 08:26:02 --> Output Class Initialized
INFO - 2016-08-04 08:26:02 --> Security Class Initialized
DEBUG - 2016-08-04 08:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:26:02 --> Input Class Initialized
INFO - 2016-08-04 08:26:02 --> Language Class Initialized
INFO - 2016-08-04 08:26:02 --> Loader Class Initialized
INFO - 2016-08-04 08:26:02 --> Helper loaded: url_helper
INFO - 2016-08-04 08:26:02 --> Helper loaded: language_helper
INFO - 2016-08-04 08:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:26:02 --> Controller Class Initialized
INFO - 2016-08-04 08:26:02 --> Database Driver Class Initialized
INFO - 2016-08-04 08:26:02 --> Model Class Initialized
INFO - 2016-08-04 08:26:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:26:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:26:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:26:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:26:02 --> Final output sent to browser
DEBUG - 2016-08-04 08:26:02 --> Total execution time: 0.0676
INFO - 2016-08-04 08:26:02 --> Config Class Initialized
INFO - 2016-08-04 08:26:02 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:26:02 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:26:02 --> Utf8 Class Initialized
INFO - 2016-08-04 08:26:02 --> URI Class Initialized
INFO - 2016-08-04 08:26:02 --> Router Class Initialized
INFO - 2016-08-04 08:26:02 --> Output Class Initialized
INFO - 2016-08-04 08:26:02 --> Security Class Initialized
DEBUG - 2016-08-04 08:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:26:02 --> Input Class Initialized
INFO - 2016-08-04 08:26:02 --> Language Class Initialized
INFO - 2016-08-04 08:26:02 --> Loader Class Initialized
INFO - 2016-08-04 08:26:02 --> Helper loaded: url_helper
INFO - 2016-08-04 08:26:02 --> Helper loaded: language_helper
INFO - 2016-08-04 08:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:26:02 --> Controller Class Initialized
INFO - 2016-08-04 08:26:02 --> Database Driver Class Initialized
INFO - 2016-08-04 08:26:02 --> Model Class Initialized
INFO - 2016-08-04 08:26:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:26:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:26:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:26:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:26:02 --> Final output sent to browser
DEBUG - 2016-08-04 08:26:02 --> Total execution time: 0.0794
INFO - 2016-08-04 08:26:03 --> Config Class Initialized
INFO - 2016-08-04 08:26:03 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:26:03 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:26:03 --> Utf8 Class Initialized
INFO - 2016-08-04 08:26:03 --> URI Class Initialized
INFO - 2016-08-04 08:26:03 --> Router Class Initialized
INFO - 2016-08-04 08:26:03 --> Output Class Initialized
INFO - 2016-08-04 08:26:03 --> Security Class Initialized
DEBUG - 2016-08-04 08:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:26:03 --> Input Class Initialized
INFO - 2016-08-04 08:26:03 --> Language Class Initialized
INFO - 2016-08-04 08:26:03 --> Loader Class Initialized
INFO - 2016-08-04 08:26:03 --> Helper loaded: url_helper
INFO - 2016-08-04 08:26:03 --> Helper loaded: language_helper
INFO - 2016-08-04 08:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:26:03 --> Controller Class Initialized
INFO - 2016-08-04 08:26:03 --> Database Driver Class Initialized
INFO - 2016-08-04 08:26:03 --> Model Class Initialized
INFO - 2016-08-04 08:26:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:26:03 --> Final output sent to browser
DEBUG - 2016-08-04 08:26:03 --> Total execution time: 0.0742
INFO - 2016-08-04 08:27:07 --> Config Class Initialized
INFO - 2016-08-04 08:27:07 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:27:07 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:27:07 --> Utf8 Class Initialized
INFO - 2016-08-04 08:27:07 --> URI Class Initialized
INFO - 2016-08-04 08:27:07 --> Router Class Initialized
INFO - 2016-08-04 08:27:07 --> Output Class Initialized
INFO - 2016-08-04 08:27:07 --> Security Class Initialized
DEBUG - 2016-08-04 08:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:27:07 --> Input Class Initialized
INFO - 2016-08-04 08:27:07 --> Language Class Initialized
INFO - 2016-08-04 08:27:07 --> Loader Class Initialized
INFO - 2016-08-04 08:27:07 --> Helper loaded: url_helper
INFO - 2016-08-04 08:27:07 --> Helper loaded: language_helper
INFO - 2016-08-04 08:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:27:07 --> Controller Class Initialized
INFO - 2016-08-04 08:27:07 --> Database Driver Class Initialized
INFO - 2016-08-04 08:27:07 --> Model Class Initialized
INFO - 2016-08-04 08:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:27:07 --> Final output sent to browser
DEBUG - 2016-08-04 08:27:07 --> Total execution time: 0.0595
INFO - 2016-08-04 08:27:07 --> Config Class Initialized
INFO - 2016-08-04 08:27:07 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:27:07 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:27:07 --> Utf8 Class Initialized
INFO - 2016-08-04 08:27:07 --> URI Class Initialized
INFO - 2016-08-04 08:27:07 --> Router Class Initialized
INFO - 2016-08-04 08:27:07 --> Output Class Initialized
INFO - 2016-08-04 08:27:07 --> Security Class Initialized
DEBUG - 2016-08-04 08:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:27:07 --> Input Class Initialized
INFO - 2016-08-04 08:27:07 --> Language Class Initialized
INFO - 2016-08-04 08:27:07 --> Loader Class Initialized
INFO - 2016-08-04 08:27:07 --> Helper loaded: url_helper
INFO - 2016-08-04 08:27:07 --> Helper loaded: language_helper
INFO - 2016-08-04 08:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:27:07 --> Controller Class Initialized
INFO - 2016-08-04 08:27:07 --> Database Driver Class Initialized
INFO - 2016-08-04 08:27:07 --> Model Class Initialized
INFO - 2016-08-04 08:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:27:07 --> Final output sent to browser
DEBUG - 2016-08-04 08:27:07 --> Total execution time: 0.0678
INFO - 2016-08-04 08:28:51 --> Config Class Initialized
INFO - 2016-08-04 08:28:51 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:28:51 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:28:51 --> Utf8 Class Initialized
INFO - 2016-08-04 08:28:51 --> URI Class Initialized
INFO - 2016-08-04 08:28:51 --> Router Class Initialized
INFO - 2016-08-04 08:28:51 --> Output Class Initialized
INFO - 2016-08-04 08:28:51 --> Security Class Initialized
DEBUG - 2016-08-04 08:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:28:51 --> Input Class Initialized
INFO - 2016-08-04 08:28:51 --> Language Class Initialized
INFO - 2016-08-04 08:28:51 --> Loader Class Initialized
INFO - 2016-08-04 08:28:51 --> Helper loaded: url_helper
INFO - 2016-08-04 08:28:51 --> Helper loaded: language_helper
INFO - 2016-08-04 08:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:28:51 --> Controller Class Initialized
INFO - 2016-08-04 08:28:51 --> Database Driver Class Initialized
INFO - 2016-08-04 08:28:51 --> Model Class Initialized
INFO - 2016-08-04 08:28:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:28:51 --> Final output sent to browser
DEBUG - 2016-08-04 08:28:51 --> Total execution time: 0.0583
INFO - 2016-08-04 08:28:51 --> Config Class Initialized
INFO - 2016-08-04 08:28:51 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:28:51 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:28:51 --> Utf8 Class Initialized
INFO - 2016-08-04 08:28:51 --> URI Class Initialized
INFO - 2016-08-04 08:28:51 --> Router Class Initialized
INFO - 2016-08-04 08:28:51 --> Output Class Initialized
INFO - 2016-08-04 08:28:51 --> Security Class Initialized
DEBUG - 2016-08-04 08:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:28:51 --> Input Class Initialized
INFO - 2016-08-04 08:28:51 --> Language Class Initialized
INFO - 2016-08-04 08:28:51 --> Loader Class Initialized
INFO - 2016-08-04 08:28:51 --> Helper loaded: url_helper
INFO - 2016-08-04 08:28:51 --> Helper loaded: language_helper
INFO - 2016-08-04 08:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:28:51 --> Controller Class Initialized
INFO - 2016-08-04 08:28:51 --> Database Driver Class Initialized
INFO - 2016-08-04 08:28:51 --> Model Class Initialized
INFO - 2016-08-04 08:28:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:28:51 --> Final output sent to browser
DEBUG - 2016-08-04 08:28:51 --> Total execution time: 0.0780
INFO - 2016-08-04 08:29:34 --> Config Class Initialized
INFO - 2016-08-04 08:29:34 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:29:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:29:34 --> Utf8 Class Initialized
INFO - 2016-08-04 08:29:34 --> URI Class Initialized
INFO - 2016-08-04 08:29:34 --> Router Class Initialized
INFO - 2016-08-04 08:29:34 --> Output Class Initialized
INFO - 2016-08-04 08:29:34 --> Security Class Initialized
DEBUG - 2016-08-04 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:29:34 --> Input Class Initialized
INFO - 2016-08-04 08:29:34 --> Language Class Initialized
INFO - 2016-08-04 08:29:34 --> Loader Class Initialized
INFO - 2016-08-04 08:29:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:29:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:29:34 --> Controller Class Initialized
INFO - 2016-08-04 08:29:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:29:34 --> Model Class Initialized
INFO - 2016-08-04 08:29:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:29:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:29:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:29:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:29:34 --> Final output sent to browser
DEBUG - 2016-08-04 08:29:34 --> Total execution time: 0.0593
INFO - 2016-08-04 08:29:34 --> Config Class Initialized
INFO - 2016-08-04 08:29:34 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:29:34 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:29:34 --> Utf8 Class Initialized
INFO - 2016-08-04 08:29:34 --> URI Class Initialized
INFO - 2016-08-04 08:29:34 --> Router Class Initialized
INFO - 2016-08-04 08:29:34 --> Output Class Initialized
INFO - 2016-08-04 08:29:34 --> Security Class Initialized
DEBUG - 2016-08-04 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:29:34 --> Input Class Initialized
INFO - 2016-08-04 08:29:34 --> Language Class Initialized
INFO - 2016-08-04 08:29:34 --> Loader Class Initialized
INFO - 2016-08-04 08:29:34 --> Helper loaded: url_helper
INFO - 2016-08-04 08:29:34 --> Helper loaded: language_helper
INFO - 2016-08-04 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:29:34 --> Controller Class Initialized
INFO - 2016-08-04 08:29:34 --> Database Driver Class Initialized
INFO - 2016-08-04 08:29:34 --> Model Class Initialized
INFO - 2016-08-04 08:29:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:29:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:29:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:29:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:29:34 --> Final output sent to browser
DEBUG - 2016-08-04 08:29:34 --> Total execution time: 0.0774
INFO - 2016-08-04 08:29:48 --> Config Class Initialized
INFO - 2016-08-04 08:29:48 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:29:48 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:29:48 --> Utf8 Class Initialized
INFO - 2016-08-04 08:29:48 --> URI Class Initialized
INFO - 2016-08-04 08:29:48 --> Router Class Initialized
INFO - 2016-08-04 08:29:48 --> Output Class Initialized
INFO - 2016-08-04 08:29:48 --> Security Class Initialized
DEBUG - 2016-08-04 08:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:29:48 --> Input Class Initialized
INFO - 2016-08-04 08:29:48 --> Language Class Initialized
INFO - 2016-08-04 08:29:48 --> Loader Class Initialized
INFO - 2016-08-04 08:29:48 --> Helper loaded: url_helper
INFO - 2016-08-04 08:29:48 --> Helper loaded: language_helper
INFO - 2016-08-04 08:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:29:48 --> Controller Class Initialized
INFO - 2016-08-04 08:29:48 --> Database Driver Class Initialized
INFO - 2016-08-04 08:29:48 --> Model Class Initialized
INFO - 2016-08-04 08:29:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:29:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:29:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:29:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:29:48 --> Final output sent to browser
DEBUG - 2016-08-04 08:29:48 --> Total execution time: 0.0810
INFO - 2016-08-04 08:30:23 --> Config Class Initialized
INFO - 2016-08-04 08:30:23 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:30:23 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:30:23 --> Utf8 Class Initialized
INFO - 2016-08-04 08:30:23 --> URI Class Initialized
INFO - 2016-08-04 08:30:23 --> Router Class Initialized
INFO - 2016-08-04 08:30:23 --> Output Class Initialized
INFO - 2016-08-04 08:30:23 --> Security Class Initialized
DEBUG - 2016-08-04 08:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:30:23 --> Input Class Initialized
INFO - 2016-08-04 08:30:23 --> Language Class Initialized
INFO - 2016-08-04 08:30:23 --> Loader Class Initialized
INFO - 2016-08-04 08:30:23 --> Helper loaded: url_helper
INFO - 2016-08-04 08:30:23 --> Helper loaded: language_helper
INFO - 2016-08-04 08:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:30:23 --> Controller Class Initialized
INFO - 2016-08-04 08:30:23 --> Database Driver Class Initialized
INFO - 2016-08-04 08:30:23 --> Model Class Initialized
INFO - 2016-08-04 08:30:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:30:23 --> Final output sent to browser
DEBUG - 2016-08-04 08:30:23 --> Total execution time: 0.0916
INFO - 2016-08-04 08:30:23 --> Config Class Initialized
INFO - 2016-08-04 08:30:23 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:30:23 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:30:23 --> Utf8 Class Initialized
INFO - 2016-08-04 08:30:23 --> URI Class Initialized
INFO - 2016-08-04 08:30:23 --> Router Class Initialized
INFO - 2016-08-04 08:30:23 --> Output Class Initialized
INFO - 2016-08-04 08:30:23 --> Security Class Initialized
DEBUG - 2016-08-04 08:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:30:23 --> Input Class Initialized
INFO - 2016-08-04 08:30:23 --> Language Class Initialized
INFO - 2016-08-04 08:30:23 --> Loader Class Initialized
INFO - 2016-08-04 08:30:23 --> Helper loaded: url_helper
INFO - 2016-08-04 08:30:23 --> Helper loaded: language_helper
INFO - 2016-08-04 08:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:30:23 --> Controller Class Initialized
INFO - 2016-08-04 08:30:23 --> Database Driver Class Initialized
INFO - 2016-08-04 08:30:23 --> Model Class Initialized
INFO - 2016-08-04 08:30:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:30:23 --> Final output sent to browser
DEBUG - 2016-08-04 08:30:23 --> Total execution time: 0.0834
INFO - 2016-08-04 08:30:48 --> Config Class Initialized
INFO - 2016-08-04 08:30:48 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:30:48 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:30:48 --> Utf8 Class Initialized
INFO - 2016-08-04 08:30:48 --> URI Class Initialized
INFO - 2016-08-04 08:30:48 --> Router Class Initialized
INFO - 2016-08-04 08:30:48 --> Output Class Initialized
INFO - 2016-08-04 08:30:48 --> Security Class Initialized
DEBUG - 2016-08-04 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:30:48 --> Input Class Initialized
INFO - 2016-08-04 08:30:48 --> Language Class Initialized
INFO - 2016-08-04 08:30:48 --> Loader Class Initialized
INFO - 2016-08-04 08:30:48 --> Helper loaded: url_helper
INFO - 2016-08-04 08:30:48 --> Helper loaded: language_helper
INFO - 2016-08-04 08:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:30:48 --> Controller Class Initialized
INFO - 2016-08-04 08:30:48 --> Database Driver Class Initialized
INFO - 2016-08-04 08:30:48 --> Model Class Initialized
INFO - 2016-08-04 08:30:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:30:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:30:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:30:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:30:48 --> Final output sent to browser
DEBUG - 2016-08-04 08:30:48 --> Total execution time: 0.0543
INFO - 2016-08-04 08:30:56 --> Config Class Initialized
INFO - 2016-08-04 08:30:56 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:30:56 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:30:56 --> Utf8 Class Initialized
INFO - 2016-08-04 08:30:56 --> URI Class Initialized
INFO - 2016-08-04 08:30:56 --> Router Class Initialized
INFO - 2016-08-04 08:30:56 --> Output Class Initialized
INFO - 2016-08-04 08:30:56 --> Security Class Initialized
DEBUG - 2016-08-04 08:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:30:56 --> Input Class Initialized
INFO - 2016-08-04 08:30:56 --> Language Class Initialized
INFO - 2016-08-04 08:30:56 --> Loader Class Initialized
INFO - 2016-08-04 08:30:56 --> Helper loaded: url_helper
INFO - 2016-08-04 08:30:56 --> Helper loaded: language_helper
INFO - 2016-08-04 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:30:56 --> Controller Class Initialized
INFO - 2016-08-04 08:30:56 --> Database Driver Class Initialized
INFO - 2016-08-04 08:30:56 --> Model Class Initialized
INFO - 2016-08-04 08:30:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:30:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:30:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:30:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:30:56 --> Final output sent to browser
DEBUG - 2016-08-04 08:30:56 --> Total execution time: 0.0666
INFO - 2016-08-04 08:31:16 --> Config Class Initialized
INFO - 2016-08-04 08:31:16 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:31:16 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:31:16 --> Utf8 Class Initialized
INFO - 2016-08-04 08:31:16 --> URI Class Initialized
INFO - 2016-08-04 08:31:16 --> Router Class Initialized
INFO - 2016-08-04 08:31:16 --> Output Class Initialized
INFO - 2016-08-04 08:31:16 --> Security Class Initialized
DEBUG - 2016-08-04 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:31:16 --> Input Class Initialized
INFO - 2016-08-04 08:31:16 --> Language Class Initialized
INFO - 2016-08-04 08:31:16 --> Loader Class Initialized
INFO - 2016-08-04 08:31:16 --> Helper loaded: url_helper
INFO - 2016-08-04 08:31:16 --> Helper loaded: language_helper
INFO - 2016-08-04 08:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:31:16 --> Controller Class Initialized
INFO - 2016-08-04 08:31:16 --> Database Driver Class Initialized
INFO - 2016-08-04 08:31:16 --> Model Class Initialized
INFO - 2016-08-04 08:31:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:31:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:31:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:31:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:31:16 --> Final output sent to browser
DEBUG - 2016-08-04 08:31:16 --> Total execution time: 0.0603
INFO - 2016-08-04 08:33:26 --> Config Class Initialized
INFO - 2016-08-04 08:33:26 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:33:26 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:33:26 --> Utf8 Class Initialized
INFO - 2016-08-04 08:33:26 --> URI Class Initialized
INFO - 2016-08-04 08:33:26 --> Router Class Initialized
INFO - 2016-08-04 08:33:26 --> Output Class Initialized
INFO - 2016-08-04 08:33:26 --> Security Class Initialized
DEBUG - 2016-08-04 08:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:33:26 --> Input Class Initialized
INFO - 2016-08-04 08:33:26 --> Language Class Initialized
INFO - 2016-08-04 08:33:26 --> Loader Class Initialized
INFO - 2016-08-04 08:33:26 --> Helper loaded: url_helper
INFO - 2016-08-04 08:33:26 --> Helper loaded: language_helper
INFO - 2016-08-04 08:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:33:26 --> Controller Class Initialized
INFO - 2016-08-04 08:33:26 --> Database Driver Class Initialized
INFO - 2016-08-04 08:33:26 --> Model Class Initialized
INFO - 2016-08-04 08:33:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:33:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:33:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:33:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:33:26 --> Final output sent to browser
DEBUG - 2016-08-04 08:33:26 --> Total execution time: 0.0580
INFO - 2016-08-04 08:36:31 --> Config Class Initialized
INFO - 2016-08-04 08:36:31 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:36:31 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:36:31 --> Utf8 Class Initialized
INFO - 2016-08-04 08:36:31 --> URI Class Initialized
INFO - 2016-08-04 08:36:31 --> Router Class Initialized
INFO - 2016-08-04 08:36:31 --> Output Class Initialized
INFO - 2016-08-04 08:36:31 --> Security Class Initialized
DEBUG - 2016-08-04 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:36:31 --> Input Class Initialized
INFO - 2016-08-04 08:36:31 --> Language Class Initialized
INFO - 2016-08-04 08:36:31 --> Loader Class Initialized
INFO - 2016-08-04 08:36:31 --> Helper loaded: url_helper
INFO - 2016-08-04 08:36:31 --> Helper loaded: language_helper
INFO - 2016-08-04 08:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:36:31 --> Controller Class Initialized
INFO - 2016-08-04 08:36:31 --> Database Driver Class Initialized
INFO - 2016-08-04 08:36:31 --> Model Class Initialized
INFO - 2016-08-04 08:36:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:36:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:36:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:36:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:36:31 --> Final output sent to browser
DEBUG - 2016-08-04 08:36:31 --> Total execution time: 0.0566
INFO - 2016-08-04 08:36:45 --> Config Class Initialized
INFO - 2016-08-04 08:36:45 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:36:45 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:36:45 --> Utf8 Class Initialized
INFO - 2016-08-04 08:36:45 --> URI Class Initialized
INFO - 2016-08-04 08:36:45 --> Router Class Initialized
INFO - 2016-08-04 08:36:45 --> Output Class Initialized
INFO - 2016-08-04 08:36:45 --> Security Class Initialized
DEBUG - 2016-08-04 08:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:36:45 --> Input Class Initialized
INFO - 2016-08-04 08:36:45 --> Language Class Initialized
INFO - 2016-08-04 08:36:45 --> Loader Class Initialized
INFO - 2016-08-04 08:36:45 --> Helper loaded: url_helper
INFO - 2016-08-04 08:36:45 --> Helper loaded: language_helper
INFO - 2016-08-04 08:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:36:45 --> Controller Class Initialized
INFO - 2016-08-04 08:36:45 --> Database Driver Class Initialized
INFO - 2016-08-04 08:36:45 --> Model Class Initialized
INFO - 2016-08-04 08:36:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:36:45 --> Final output sent to browser
DEBUG - 2016-08-04 08:36:45 --> Total execution time: 0.0564
INFO - 2016-08-04 08:37:50 --> Config Class Initialized
INFO - 2016-08-04 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-08-04 08:37:50 --> UTF-8 Support Enabled
INFO - 2016-08-04 08:37:50 --> Utf8 Class Initialized
INFO - 2016-08-04 08:37:50 --> URI Class Initialized
INFO - 2016-08-04 08:37:50 --> Router Class Initialized
INFO - 2016-08-04 08:37:50 --> Output Class Initialized
INFO - 2016-08-04 08:37:50 --> Security Class Initialized
DEBUG - 2016-08-04 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 08:37:50 --> Input Class Initialized
INFO - 2016-08-04 08:37:50 --> Language Class Initialized
INFO - 2016-08-04 08:37:50 --> Loader Class Initialized
INFO - 2016-08-04 08:37:50 --> Helper loaded: url_helper
INFO - 2016-08-04 08:37:50 --> Helper loaded: language_helper
INFO - 2016-08-04 08:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 08:37:50 --> Controller Class Initialized
INFO - 2016-08-04 08:37:50 --> Database Driver Class Initialized
INFO - 2016-08-04 08:37:50 --> Model Class Initialized
INFO - 2016-08-04 08:37:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 08:37:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 08:37:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 08:37:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 08:37:50 --> Final output sent to browser
DEBUG - 2016-08-04 08:37:50 --> Total execution time: 0.0588
INFO - 2016-08-04 09:29:24 --> Config Class Initialized
INFO - 2016-08-04 09:29:24 --> Hooks Class Initialized
DEBUG - 2016-08-04 09:29:24 --> UTF-8 Support Enabled
INFO - 2016-08-04 09:29:24 --> Utf8 Class Initialized
INFO - 2016-08-04 09:29:24 --> URI Class Initialized
INFO - 2016-08-04 09:29:24 --> Router Class Initialized
INFO - 2016-08-04 09:29:24 --> Output Class Initialized
INFO - 2016-08-04 09:29:24 --> Security Class Initialized
DEBUG - 2016-08-04 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-04 09:29:24 --> Input Class Initialized
INFO - 2016-08-04 09:29:24 --> Language Class Initialized
INFO - 2016-08-04 09:29:24 --> Loader Class Initialized
INFO - 2016-08-04 09:29:24 --> Helper loaded: url_helper
INFO - 2016-08-04 09:29:24 --> Helper loaded: language_helper
INFO - 2016-08-04 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-04 09:29:24 --> Controller Class Initialized
INFO - 2016-08-04 09:29:24 --> Database Driver Class Initialized
INFO - 2016-08-04 09:29:24 --> Model Class Initialized
INFO - 2016-08-04 09:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-04 09:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-04 09:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-04 09:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-04 09:29:24 --> Final output sent to browser
DEBUG - 2016-08-04 09:29:24 --> Total execution time: 0.0969
