<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-11 08:49:07 --> Config Class Initialized
INFO - 2016-08-11 08:49:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 08:49:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 08:49:07 --> Utf8 Class Initialized
INFO - 2016-08-11 08:49:07 --> URI Class Initialized
INFO - 2016-08-11 08:49:07 --> Router Class Initialized
INFO - 2016-08-11 08:49:07 --> Output Class Initialized
INFO - 2016-08-11 08:49:07 --> Security Class Initialized
DEBUG - 2016-08-11 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 08:49:07 --> Input Class Initialized
INFO - 2016-08-11 08:49:07 --> Language Class Initialized
INFO - 2016-08-11 08:49:07 --> Loader Class Initialized
INFO - 2016-08-11 08:49:07 --> Helper loaded: url_helper
INFO - 2016-08-11 08:49:07 --> Helper loaded: language_helper
INFO - 2016-08-11 08:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 08:49:07 --> Controller Class Initialized
INFO - 2016-08-11 08:49:07 --> Database Driver Class Initialized
INFO - 2016-08-11 08:49:07 --> Model Class Initialized
INFO - 2016-08-11 08:49:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-11 08:49:07 --> Config Class Initialized
INFO - 2016-08-11 08:49:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 08:49:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 08:49:07 --> Utf8 Class Initialized
INFO - 2016-08-11 08:49:07 --> URI Class Initialized
INFO - 2016-08-11 08:49:07 --> Router Class Initialized
INFO - 2016-08-11 08:49:07 --> Output Class Initialized
INFO - 2016-08-11 08:49:07 --> Security Class Initialized
DEBUG - 2016-08-11 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 08:49:07 --> Input Class Initialized
INFO - 2016-08-11 08:49:07 --> Language Class Initialized
INFO - 2016-08-11 08:49:07 --> Loader Class Initialized
INFO - 2016-08-11 08:49:07 --> Helper loaded: url_helper
INFO - 2016-08-11 08:49:07 --> Helper loaded: language_helper
INFO - 2016-08-11 08:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 08:49:07 --> Controller Class Initialized
INFO - 2016-08-11 08:49:07 --> Database Driver Class Initialized
INFO - 2016-08-11 08:49:07 --> Model Class Initialized
INFO - 2016-08-11 08:49:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-11 08:49:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-11 08:49:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-11 08:49:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-11 08:49:07 --> Final output sent to browser
DEBUG - 2016-08-11 08:49:07 --> Total execution time: 0.0869
INFO - 2016-08-11 08:54:15 --> Config Class Initialized
INFO - 2016-08-11 08:54:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 08:54:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 08:54:15 --> Utf8 Class Initialized
INFO - 2016-08-11 08:54:15 --> URI Class Initialized
INFO - 2016-08-11 08:54:15 --> Router Class Initialized
INFO - 2016-08-11 08:54:15 --> Output Class Initialized
INFO - 2016-08-11 08:54:15 --> Security Class Initialized
DEBUG - 2016-08-11 08:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 08:54:15 --> Input Class Initialized
INFO - 2016-08-11 08:54:15 --> Language Class Initialized
INFO - 2016-08-11 08:54:15 --> Loader Class Initialized
INFO - 2016-08-11 08:54:15 --> Helper loaded: url_helper
INFO - 2016-08-11 08:54:15 --> Helper loaded: language_helper
INFO - 2016-08-11 08:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 08:54:15 --> Controller Class Initialized
INFO - 2016-08-11 08:54:15 --> Database Driver Class Initialized
INFO - 2016-08-11 08:54:15 --> Model Class Initialized
INFO - 2016-08-11 08:54:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-11 08:54:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-11 08:54:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-11 08:54:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-11 08:54:15 --> Final output sent to browser
DEBUG - 2016-08-11 08:54:15 --> Total execution time: 0.0922
