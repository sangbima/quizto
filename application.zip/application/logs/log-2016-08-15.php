<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-15 19:25:47 --> Config Class Initialized
INFO - 2016-08-15 19:25:47 --> Hooks Class Initialized
DEBUG - 2016-08-15 19:25:47 --> UTF-8 Support Enabled
INFO - 2016-08-15 19:25:47 --> Utf8 Class Initialized
INFO - 2016-08-15 19:25:47 --> URI Class Initialized
INFO - 2016-08-15 19:25:47 --> Router Class Initialized
INFO - 2016-08-15 19:25:47 --> Output Class Initialized
INFO - 2016-08-15 19:25:47 --> Security Class Initialized
DEBUG - 2016-08-15 19:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 19:25:47 --> Input Class Initialized
INFO - 2016-08-15 19:25:47 --> Language Class Initialized
INFO - 2016-08-15 19:25:47 --> Loader Class Initialized
INFO - 2016-08-15 19:25:47 --> Helper loaded: url_helper
INFO - 2016-08-15 19:25:47 --> Helper loaded: language_helper
INFO - 2016-08-15 19:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 19:25:48 --> Controller Class Initialized
INFO - 2016-08-15 19:25:48 --> Database Driver Class Initialized
INFO - 2016-08-15 19:25:48 --> Model Class Initialized
INFO - 2016-08-15 19:25:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-15 19:25:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-15 19:25:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-15 19:25:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-15 19:25:48 --> Final output sent to browser
DEBUG - 2016-08-15 19:25:48 --> Total execution time: 0.1583
