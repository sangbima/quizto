<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-18 12:18:51 --> Config Class Initialized
INFO - 2016-08-18 12:18:51 --> Hooks Class Initialized
DEBUG - 2016-08-18 12:18:51 --> UTF-8 Support Enabled
INFO - 2016-08-18 12:18:51 --> Utf8 Class Initialized
INFO - 2016-08-18 12:18:51 --> URI Class Initialized
INFO - 2016-08-18 12:18:51 --> Router Class Initialized
INFO - 2016-08-18 12:18:51 --> Output Class Initialized
INFO - 2016-08-18 12:18:51 --> Security Class Initialized
DEBUG - 2016-08-18 12:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-18 12:18:51 --> Input Class Initialized
INFO - 2016-08-18 12:18:51 --> Language Class Initialized
INFO - 2016-08-18 12:18:51 --> Loader Class Initialized
INFO - 2016-08-18 12:18:51 --> Helper loaded: url_helper
INFO - 2016-08-18 12:18:51 --> Helper loaded: language_helper
INFO - 2016-08-18 12:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-18 12:18:51 --> Controller Class Initialized
INFO - 2016-08-18 12:18:51 --> Database Driver Class Initialized
INFO - 2016-08-18 12:18:51 --> Model Class Initialized
INFO - 2016-08-18 12:18:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-18 12:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-18 12:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-18 12:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-18 12:18:51 --> Final output sent to browser
DEBUG - 2016-08-18 12:18:51 --> Total execution time: 0.1367
