<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-23 09:05:46 --> Config Class Initialized
INFO - 2016-08-23 09:05:46 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:05:46 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:05:46 --> Utf8 Class Initialized
INFO - 2016-08-23 09:05:46 --> URI Class Initialized
INFO - 2016-08-23 09:05:46 --> Router Class Initialized
INFO - 2016-08-23 09:05:46 --> Output Class Initialized
INFO - 2016-08-23 09:05:46 --> Security Class Initialized
DEBUG - 2016-08-23 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:05:46 --> Input Class Initialized
INFO - 2016-08-23 09:05:46 --> Language Class Initialized
INFO - 2016-08-23 09:05:46 --> Loader Class Initialized
INFO - 2016-08-23 09:05:46 --> Helper loaded: url_helper
INFO - 2016-08-23 09:05:46 --> Helper loaded: language_helper
INFO - 2016-08-23 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:05:46 --> Controller Class Initialized
INFO - 2016-08-23 09:05:46 --> Database Driver Class Initialized
INFO - 2016-08-23 09:05:46 --> Model Class Initialized
INFO - 2016-08-23 09:05:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:05:47 --> Config Class Initialized
INFO - 2016-08-23 09:05:47 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:05:47 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:05:47 --> Utf8 Class Initialized
INFO - 2016-08-23 09:05:47 --> URI Class Initialized
INFO - 2016-08-23 09:05:47 --> Router Class Initialized
INFO - 2016-08-23 09:05:47 --> Output Class Initialized
INFO - 2016-08-23 09:05:47 --> Security Class Initialized
DEBUG - 2016-08-23 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:05:47 --> Input Class Initialized
INFO - 2016-08-23 09:05:47 --> Language Class Initialized
INFO - 2016-08-23 09:05:47 --> Loader Class Initialized
INFO - 2016-08-23 09:05:47 --> Helper loaded: url_helper
INFO - 2016-08-23 09:05:47 --> Helper loaded: language_helper
INFO - 2016-08-23 09:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:05:47 --> Controller Class Initialized
INFO - 2016-08-23 09:05:47 --> Database Driver Class Initialized
INFO - 2016-08-23 09:05:47 --> Model Class Initialized
INFO - 2016-08-23 09:05:47 --> Model Class Initialized
INFO - 2016-08-23 09:05:47 --> Model Class Initialized
INFO - 2016-08-23 09:05:47 --> Model Class Initialized
INFO - 2016-08-23 09:05:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:05:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:05:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-23 09:05:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:05:47 --> Final output sent to browser
DEBUG - 2016-08-23 09:05:47 --> Total execution time: 0.0984
INFO - 2016-08-23 09:05:51 --> Config Class Initialized
INFO - 2016-08-23 09:05:51 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:05:51 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:05:51 --> Utf8 Class Initialized
INFO - 2016-08-23 09:05:51 --> URI Class Initialized
INFO - 2016-08-23 09:05:51 --> Router Class Initialized
INFO - 2016-08-23 09:05:51 --> Output Class Initialized
INFO - 2016-08-23 09:05:51 --> Security Class Initialized
DEBUG - 2016-08-23 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:05:51 --> Input Class Initialized
INFO - 2016-08-23 09:05:51 --> Language Class Initialized
INFO - 2016-08-23 09:05:51 --> Loader Class Initialized
INFO - 2016-08-23 09:05:51 --> Helper loaded: url_helper
INFO - 2016-08-23 09:05:51 --> Helper loaded: language_helper
INFO - 2016-08-23 09:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:05:51 --> Controller Class Initialized
INFO - 2016-08-23 09:05:51 --> Database Driver Class Initialized
INFO - 2016-08-23 09:05:51 --> Model Class Initialized
INFO - 2016-08-23 09:05:51 --> Model Class Initialized
INFO - 2016-08-23 09:05:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:05:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:05:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-23 09:05:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:05:51 --> Final output sent to browser
DEBUG - 2016-08-23 09:05:51 --> Total execution time: 0.0665
INFO - 2016-08-23 09:05:55 --> Config Class Initialized
INFO - 2016-08-23 09:05:55 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:05:55 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:05:55 --> Utf8 Class Initialized
INFO - 2016-08-23 09:05:55 --> URI Class Initialized
INFO - 2016-08-23 09:05:55 --> Router Class Initialized
INFO - 2016-08-23 09:05:55 --> Output Class Initialized
INFO - 2016-08-23 09:05:55 --> Security Class Initialized
DEBUG - 2016-08-23 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:05:55 --> Input Class Initialized
INFO - 2016-08-23 09:05:55 --> Language Class Initialized
INFO - 2016-08-23 09:05:55 --> Loader Class Initialized
INFO - 2016-08-23 09:05:55 --> Helper loaded: url_helper
INFO - 2016-08-23 09:05:55 --> Helper loaded: language_helper
INFO - 2016-08-23 09:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:05:55 --> Controller Class Initialized
INFO - 2016-08-23 09:05:55 --> Database Driver Class Initialized
INFO - 2016-08-23 09:05:55 --> Model Class Initialized
INFO - 2016-08-23 09:05:55 --> Model Class Initialized
INFO - 2016-08-23 09:05:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:05:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:05:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-08-23 09:05:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:05:55 --> Final output sent to browser
DEBUG - 2016-08-23 09:05:55 --> Total execution time: 0.0644
INFO - 2016-08-23 09:05:56 --> Config Class Initialized
INFO - 2016-08-23 09:05:56 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:05:56 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:05:56 --> Utf8 Class Initialized
INFO - 2016-08-23 09:05:56 --> URI Class Initialized
INFO - 2016-08-23 09:05:56 --> Router Class Initialized
INFO - 2016-08-23 09:05:56 --> Output Class Initialized
INFO - 2016-08-23 09:05:56 --> Security Class Initialized
DEBUG - 2016-08-23 09:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:05:56 --> Input Class Initialized
INFO - 2016-08-23 09:05:56 --> Language Class Initialized
INFO - 2016-08-23 09:05:56 --> Loader Class Initialized
INFO - 2016-08-23 09:05:56 --> Helper loaded: url_helper
INFO - 2016-08-23 09:05:56 --> Helper loaded: language_helper
INFO - 2016-08-23 09:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:05:56 --> Controller Class Initialized
INFO - 2016-08-23 09:05:56 --> Database Driver Class Initialized
INFO - 2016-08-23 09:05:56 --> Model Class Initialized
INFO - 2016-08-23 09:05:56 --> Model Class Initialized
INFO - 2016-08-23 09:05:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:05:56 --> Config Class Initialized
INFO - 2016-08-23 09:05:56 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:05:56 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:05:56 --> Utf8 Class Initialized
INFO - 2016-08-23 09:05:56 --> URI Class Initialized
INFO - 2016-08-23 09:05:56 --> Router Class Initialized
INFO - 2016-08-23 09:05:56 --> Output Class Initialized
INFO - 2016-08-23 09:05:56 --> Security Class Initialized
DEBUG - 2016-08-23 09:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:05:56 --> Input Class Initialized
INFO - 2016-08-23 09:05:56 --> Language Class Initialized
INFO - 2016-08-23 09:05:56 --> Loader Class Initialized
INFO - 2016-08-23 09:05:57 --> Helper loaded: url_helper
INFO - 2016-08-23 09:05:57 --> Helper loaded: language_helper
INFO - 2016-08-23 09:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:05:57 --> Controller Class Initialized
INFO - 2016-08-23 09:05:57 --> Database Driver Class Initialized
INFO - 2016-08-23 09:05:57 --> Model Class Initialized
INFO - 2016-08-23 09:05:57 --> Model Class Initialized
INFO - 2016-08-23 09:05:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:05:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:05:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-08-23 09:05:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:05:57 --> Final output sent to browser
DEBUG - 2016-08-23 09:05:57 --> Total execution time: 0.0783
INFO - 2016-08-23 09:06:01 --> Config Class Initialized
INFO - 2016-08-23 09:06:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:01 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:01 --> URI Class Initialized
INFO - 2016-08-23 09:06:01 --> Router Class Initialized
INFO - 2016-08-23 09:06:01 --> Output Class Initialized
INFO - 2016-08-23 09:06:01 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:01 --> Input Class Initialized
INFO - 2016-08-23 09:06:01 --> Language Class Initialized
INFO - 2016-08-23 09:06:01 --> Loader Class Initialized
INFO - 2016-08-23 09:06:01 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:01 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:01 --> Controller Class Initialized
INFO - 2016-08-23 09:06:01 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:01 --> Model Class Initialized
INFO - 2016-08-23 09:06:01 --> Model Class Initialized
INFO - 2016-08-23 09:06:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-08-23 09:06:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:01 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:01 --> Total execution time: 0.0613
INFO - 2016-08-23 09:06:03 --> Config Class Initialized
INFO - 2016-08-23 09:06:03 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:03 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:03 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:03 --> URI Class Initialized
INFO - 2016-08-23 09:06:03 --> Router Class Initialized
INFO - 2016-08-23 09:06:03 --> Output Class Initialized
INFO - 2016-08-23 09:06:03 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:03 --> Input Class Initialized
INFO - 2016-08-23 09:06:03 --> Language Class Initialized
INFO - 2016-08-23 09:06:03 --> Loader Class Initialized
INFO - 2016-08-23 09:06:03 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:03 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:03 --> Controller Class Initialized
INFO - 2016-08-23 09:06:03 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:03 --> Model Class Initialized
INFO - 2016-08-23 09:06:03 --> Model Class Initialized
INFO - 2016-08-23 09:06:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-23 09:06:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:03 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:03 --> Total execution time: 0.0581
INFO - 2016-08-23 09:06:05 --> Config Class Initialized
INFO - 2016-08-23 09:06:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:05 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:05 --> URI Class Initialized
INFO - 2016-08-23 09:06:05 --> Router Class Initialized
INFO - 2016-08-23 09:06:05 --> Output Class Initialized
INFO - 2016-08-23 09:06:05 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:05 --> Input Class Initialized
INFO - 2016-08-23 09:06:05 --> Language Class Initialized
INFO - 2016-08-23 09:06:05 --> Loader Class Initialized
INFO - 2016-08-23 09:06:05 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:05 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:05 --> Controller Class Initialized
INFO - 2016-08-23 09:06:05 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:05 --> Model Class Initialized
INFO - 2016-08-23 09:06:05 --> Model Class Initialized
INFO - 2016-08-23 09:06:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-08-23 09:06:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:05 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:05 --> Total execution time: 0.0709
INFO - 2016-08-23 09:06:06 --> Config Class Initialized
INFO - 2016-08-23 09:06:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:06 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:06 --> URI Class Initialized
INFO - 2016-08-23 09:06:06 --> Router Class Initialized
INFO - 2016-08-23 09:06:06 --> Output Class Initialized
INFO - 2016-08-23 09:06:06 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:06 --> Input Class Initialized
INFO - 2016-08-23 09:06:06 --> Language Class Initialized
INFO - 2016-08-23 09:06:06 --> Loader Class Initialized
INFO - 2016-08-23 09:06:06 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:06 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:06 --> Controller Class Initialized
INFO - 2016-08-23 09:06:06 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:06 --> Config Class Initialized
INFO - 2016-08-23 09:06:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:06 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:06 --> URI Class Initialized
INFO - 2016-08-23 09:06:06 --> Router Class Initialized
INFO - 2016-08-23 09:06:06 --> Output Class Initialized
INFO - 2016-08-23 09:06:06 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:06 --> Input Class Initialized
INFO - 2016-08-23 09:06:06 --> Language Class Initialized
INFO - 2016-08-23 09:06:06 --> Loader Class Initialized
INFO - 2016-08-23 09:06:06 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:06 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:06 --> Controller Class Initialized
INFO - 2016-08-23 09:06:06 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-23 09:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:06 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:06 --> Total execution time: 0.0871
INFO - 2016-08-23 09:06:06 --> Config Class Initialized
INFO - 2016-08-23 09:06:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:06 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:06 --> Config Class Initialized
INFO - 2016-08-23 09:06:06 --> Hooks Class Initialized
INFO - 2016-08-23 09:06:06 --> URI Class Initialized
INFO - 2016-08-23 09:06:06 --> Router Class Initialized
DEBUG - 2016-08-23 09:06:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:06 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:06 --> URI Class Initialized
INFO - 2016-08-23 09:06:06 --> Output Class Initialized
INFO - 2016-08-23 09:06:06 --> Router Class Initialized
INFO - 2016-08-23 09:06:06 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:06 --> Output Class Initialized
INFO - 2016-08-23 09:06:06 --> Input Class Initialized
INFO - 2016-08-23 09:06:06 --> Language Class Initialized
INFO - 2016-08-23 09:06:06 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:06 --> Loader Class Initialized
INFO - 2016-08-23 09:06:06 --> Input Class Initialized
INFO - 2016-08-23 09:06:06 --> Language Class Initialized
INFO - 2016-08-23 09:06:06 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:06 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:06 --> Loader Class Initialized
INFO - 2016-08-23 09:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:06 --> Controller Class Initialized
INFO - 2016-08-23 09:06:06 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:06 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:06 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:06 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:06 --> Total execution time: 0.0858
INFO - 2016-08-23 09:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:06 --> Controller Class Initialized
INFO - 2016-08-23 09:06:06 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Model Class Initialized
INFO - 2016-08-23 09:06:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:06 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:06 --> Total execution time: 0.1290
INFO - 2016-08-23 09:06:09 --> Config Class Initialized
INFO - 2016-08-23 09:06:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:09 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:09 --> URI Class Initialized
INFO - 2016-08-23 09:06:09 --> Router Class Initialized
INFO - 2016-08-23 09:06:09 --> Output Class Initialized
INFO - 2016-08-23 09:06:09 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:09 --> Input Class Initialized
INFO - 2016-08-23 09:06:09 --> Language Class Initialized
INFO - 2016-08-23 09:06:09 --> Loader Class Initialized
INFO - 2016-08-23 09:06:09 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:09 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:09 --> Controller Class Initialized
INFO - 2016-08-23 09:06:09 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:09 --> Model Class Initialized
INFO - 2016-08-23 09:06:09 --> Model Class Initialized
INFO - 2016-08-23 09:06:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-23 09:06:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:09 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:09 --> Total execution time: 0.0776
INFO - 2016-08-23 09:06:09 --> Config Class Initialized
INFO - 2016-08-23 09:06:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:09 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:09 --> URI Class Initialized
INFO - 2016-08-23 09:06:09 --> Router Class Initialized
INFO - 2016-08-23 09:06:09 --> Output Class Initialized
INFO - 2016-08-23 09:06:09 --> Config Class Initialized
INFO - 2016-08-23 09:06:09 --> Hooks Class Initialized
INFO - 2016-08-23 09:06:09 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:09 --> Input Class Initialized
INFO - 2016-08-23 09:06:09 --> Language Class Initialized
DEBUG - 2016-08-23 09:06:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:09 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:09 --> URI Class Initialized
INFO - 2016-08-23 09:06:09 --> Loader Class Initialized
INFO - 2016-08-23 09:06:09 --> Router Class Initialized
INFO - 2016-08-23 09:06:09 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:09 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:09 --> Output Class Initialized
INFO - 2016-08-23 09:06:09 --> Security Class Initialized
INFO - 2016-08-23 09:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:09 --> Controller Class Initialized
DEBUG - 2016-08-23 09:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:09 --> Input Class Initialized
INFO - 2016-08-23 09:06:09 --> Language Class Initialized
INFO - 2016-08-23 09:06:09 --> Loader Class Initialized
INFO - 2016-08-23 09:06:09 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:09 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:09 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:09 --> Model Class Initialized
INFO - 2016-08-23 09:06:09 --> Model Class Initialized
INFO - 2016-08-23 09:06:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:09 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:09 --> Total execution time: 0.0788
INFO - 2016-08-23 09:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:09 --> Controller Class Initialized
INFO - 2016-08-23 09:06:09 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:09 --> Model Class Initialized
INFO - 2016-08-23 09:06:09 --> Model Class Initialized
INFO - 2016-08-23 09:06:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:09 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:09 --> Total execution time: 0.1153
INFO - 2016-08-23 09:06:11 --> Config Class Initialized
INFO - 2016-08-23 09:06:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:11 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:11 --> URI Class Initialized
INFO - 2016-08-23 09:06:11 --> Router Class Initialized
INFO - 2016-08-23 09:06:11 --> Output Class Initialized
INFO - 2016-08-23 09:06:11 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:11 --> Input Class Initialized
INFO - 2016-08-23 09:06:11 --> Language Class Initialized
INFO - 2016-08-23 09:06:11 --> Loader Class Initialized
INFO - 2016-08-23 09:06:11 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:11 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:11 --> Controller Class Initialized
INFO - 2016-08-23 09:06:11 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:11 --> Model Class Initialized
INFO - 2016-08-23 09:06:11 --> Model Class Initialized
INFO - 2016-08-23 09:06:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-23 09:06:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:11 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:11 --> Total execution time: 0.0750
INFO - 2016-08-23 09:06:11 --> Config Class Initialized
INFO - 2016-08-23 09:06:11 --> Hooks Class Initialized
INFO - 2016-08-23 09:06:11 --> Config Class Initialized
INFO - 2016-08-23 09:06:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:11 --> Utf8 Class Initialized
DEBUG - 2016-08-23 09:06:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:11 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:11 --> URI Class Initialized
INFO - 2016-08-23 09:06:11 --> URI Class Initialized
INFO - 2016-08-23 09:06:11 --> Router Class Initialized
INFO - 2016-08-23 09:06:11 --> Router Class Initialized
INFO - 2016-08-23 09:06:11 --> Output Class Initialized
INFO - 2016-08-23 09:06:11 --> Output Class Initialized
INFO - 2016-08-23 09:06:11 --> Security Class Initialized
INFO - 2016-08-23 09:06:11 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-23 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:11 --> Input Class Initialized
INFO - 2016-08-23 09:06:11 --> Input Class Initialized
INFO - 2016-08-23 09:06:11 --> Language Class Initialized
INFO - 2016-08-23 09:06:11 --> Language Class Initialized
INFO - 2016-08-23 09:06:11 --> Loader Class Initialized
INFO - 2016-08-23 09:06:11 --> Loader Class Initialized
INFO - 2016-08-23 09:06:11 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:11 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:11 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:11 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:11 --> Controller Class Initialized
INFO - 2016-08-23 09:06:11 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:11 --> Model Class Initialized
INFO - 2016-08-23 09:06:11 --> Model Class Initialized
INFO - 2016-08-23 09:06:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:11 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:11 --> Total execution time: 0.0775
INFO - 2016-08-23 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:11 --> Controller Class Initialized
INFO - 2016-08-23 09:06:11 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:11 --> Model Class Initialized
INFO - 2016-08-23 09:06:11 --> Model Class Initialized
INFO - 2016-08-23 09:06:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:11 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:11 --> Total execution time: 0.1318
INFO - 2016-08-23 09:06:13 --> Config Class Initialized
INFO - 2016-08-23 09:06:13 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:13 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:13 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:13 --> URI Class Initialized
INFO - 2016-08-23 09:06:13 --> Router Class Initialized
INFO - 2016-08-23 09:06:13 --> Output Class Initialized
INFO - 2016-08-23 09:06:13 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:13 --> Input Class Initialized
INFO - 2016-08-23 09:06:13 --> Language Class Initialized
INFO - 2016-08-23 09:06:13 --> Loader Class Initialized
INFO - 2016-08-23 09:06:13 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:13 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:13 --> Controller Class Initialized
INFO - 2016-08-23 09:06:13 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:13 --> Model Class Initialized
INFO - 2016-08-23 09:06:13 --> Model Class Initialized
INFO - 2016-08-23 09:06:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-23 09:06:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:13 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:13 --> Total execution time: 0.1094
INFO - 2016-08-23 09:06:13 --> Config Class Initialized
INFO - 2016-08-23 09:06:13 --> Hooks Class Initialized
INFO - 2016-08-23 09:06:13 --> Config Class Initialized
INFO - 2016-08-23 09:06:13 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:13 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:13 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:13 --> URI Class Initialized
DEBUG - 2016-08-23 09:06:13 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:13 --> Router Class Initialized
INFO - 2016-08-23 09:06:13 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:13 --> URI Class Initialized
INFO - 2016-08-23 09:06:13 --> Output Class Initialized
INFO - 2016-08-23 09:06:13 --> Security Class Initialized
INFO - 2016-08-23 09:06:13 --> Router Class Initialized
DEBUG - 2016-08-23 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:13 --> Output Class Initialized
INFO - 2016-08-23 09:06:13 --> Input Class Initialized
INFO - 2016-08-23 09:06:13 --> Language Class Initialized
INFO - 2016-08-23 09:06:13 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:13 --> Input Class Initialized
INFO - 2016-08-23 09:06:13 --> Language Class Initialized
INFO - 2016-08-23 09:06:13 --> Loader Class Initialized
INFO - 2016-08-23 09:06:13 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:13 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:13 --> Loader Class Initialized
INFO - 2016-08-23 09:06:13 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:13 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:13 --> Controller Class Initialized
INFO - 2016-08-23 09:06:13 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:13 --> Model Class Initialized
INFO - 2016-08-23 09:06:13 --> Model Class Initialized
INFO - 2016-08-23 09:06:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:13 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:13 --> Total execution time: 0.0933
INFO - 2016-08-23 09:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:13 --> Controller Class Initialized
INFO - 2016-08-23 09:06:13 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:13 --> Model Class Initialized
INFO - 2016-08-23 09:06:13 --> Model Class Initialized
INFO - 2016-08-23 09:06:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:13 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:13 --> Total execution time: 0.1253
INFO - 2016-08-23 09:06:15 --> Config Class Initialized
INFO - 2016-08-23 09:06:15 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:15 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:15 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:15 --> URI Class Initialized
INFO - 2016-08-23 09:06:15 --> Router Class Initialized
INFO - 2016-08-23 09:06:15 --> Output Class Initialized
INFO - 2016-08-23 09:06:15 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:15 --> Input Class Initialized
INFO - 2016-08-23 09:06:15 --> Language Class Initialized
INFO - 2016-08-23 09:06:15 --> Loader Class Initialized
INFO - 2016-08-23 09:06:15 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:15 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:15 --> Controller Class Initialized
INFO - 2016-08-23 09:06:15 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:15 --> Model Class Initialized
INFO - 2016-08-23 09:06:15 --> Model Class Initialized
INFO - 2016-08-23 09:06:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-23 09:06:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:15 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:15 --> Total execution time: 0.0720
INFO - 2016-08-23 09:06:15 --> Config Class Initialized
INFO - 2016-08-23 09:06:15 --> Hooks Class Initialized
INFO - 2016-08-23 09:06:15 --> Config Class Initialized
INFO - 2016-08-23 09:06:15 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:15 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:15 --> Utf8 Class Initialized
DEBUG - 2016-08-23 09:06:15 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:15 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:15 --> URI Class Initialized
INFO - 2016-08-23 09:06:15 --> URI Class Initialized
INFO - 2016-08-23 09:06:15 --> Router Class Initialized
INFO - 2016-08-23 09:06:15 --> Router Class Initialized
INFO - 2016-08-23 09:06:15 --> Output Class Initialized
INFO - 2016-08-23 09:06:15 --> Output Class Initialized
INFO - 2016-08-23 09:06:15 --> Security Class Initialized
INFO - 2016-08-23 09:06:15 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:15 --> Input Class Initialized
DEBUG - 2016-08-23 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:15 --> Input Class Initialized
INFO - 2016-08-23 09:06:15 --> Language Class Initialized
INFO - 2016-08-23 09:06:15 --> Language Class Initialized
INFO - 2016-08-23 09:06:15 --> Loader Class Initialized
INFO - 2016-08-23 09:06:15 --> Loader Class Initialized
INFO - 2016-08-23 09:06:15 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:15 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:15 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:15 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:15 --> Controller Class Initialized
INFO - 2016-08-23 09:06:15 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:15 --> Model Class Initialized
INFO - 2016-08-23 09:06:15 --> Model Class Initialized
INFO - 2016-08-23 09:06:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:15 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:15 --> Total execution time: 0.0792
INFO - 2016-08-23 09:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:15 --> Controller Class Initialized
INFO - 2016-08-23 09:06:15 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:16 --> Model Class Initialized
INFO - 2016-08-23 09:06:16 --> Model Class Initialized
INFO - 2016-08-23 09:06:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:16 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:16 --> Total execution time: 0.1238
INFO - 2016-08-23 09:06:21 --> Config Class Initialized
INFO - 2016-08-23 09:06:21 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:21 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:21 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:21 --> URI Class Initialized
INFO - 2016-08-23 09:06:21 --> Router Class Initialized
INFO - 2016-08-23 09:06:21 --> Output Class Initialized
INFO - 2016-08-23 09:06:21 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:21 --> Input Class Initialized
INFO - 2016-08-23 09:06:21 --> Language Class Initialized
INFO - 2016-08-23 09:06:21 --> Loader Class Initialized
INFO - 2016-08-23 09:06:21 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:21 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:21 --> Controller Class Initialized
INFO - 2016-08-23 09:06:21 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:21 --> Model Class Initialized
INFO - 2016-08-23 09:06:21 --> Model Class Initialized
INFO - 2016-08-23 09:06:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 09:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-08-23 09:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 09:06:21 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:21 --> Total execution time: 0.0696
INFO - 2016-08-23 09:06:22 --> Config Class Initialized
INFO - 2016-08-23 09:06:22 --> Hooks Class Initialized
INFO - 2016-08-23 09:06:22 --> Config Class Initialized
INFO - 2016-08-23 09:06:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:22 --> URI Class Initialized
INFO - 2016-08-23 09:06:22 --> Router Class Initialized
DEBUG - 2016-08-23 09:06:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:22 --> Output Class Initialized
INFO - 2016-08-23 09:06:22 --> URI Class Initialized
INFO - 2016-08-23 09:06:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:22 --> Input Class Initialized
INFO - 2016-08-23 09:06:22 --> Router Class Initialized
INFO - 2016-08-23 09:06:22 --> Language Class Initialized
INFO - 2016-08-23 09:06:22 --> Output Class Initialized
INFO - 2016-08-23 09:06:22 --> Security Class Initialized
INFO - 2016-08-23 09:06:22 --> Loader Class Initialized
DEBUG - 2016-08-23 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:22 --> Input Class Initialized
INFO - 2016-08-23 09:06:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:22 --> Language Class Initialized
INFO - 2016-08-23 09:06:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:22 --> Loader Class Initialized
INFO - 2016-08-23 09:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:22 --> Controller Class Initialized
INFO - 2016-08-23 09:06:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:22 --> Model Class Initialized
INFO - 2016-08-23 09:06:22 --> Model Class Initialized
INFO - 2016-08-23 09:06:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:22 --> Total execution time: 0.0765
INFO - 2016-08-23 09:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:22 --> Controller Class Initialized
INFO - 2016-08-23 09:06:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:22 --> Model Class Initialized
INFO - 2016-08-23 09:06:22 --> Model Class Initialized
INFO - 2016-08-23 09:06:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:22 --> Total execution time: 0.1251
INFO - 2016-08-23 09:06:52 --> Config Class Initialized
INFO - 2016-08-23 09:06:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:06:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:06:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:06:52 --> URI Class Initialized
INFO - 2016-08-23 09:06:52 --> Router Class Initialized
INFO - 2016-08-23 09:06:52 --> Output Class Initialized
INFO - 2016-08-23 09:06:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:06:52 --> Input Class Initialized
INFO - 2016-08-23 09:06:52 --> Language Class Initialized
INFO - 2016-08-23 09:06:52 --> Loader Class Initialized
INFO - 2016-08-23 09:06:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:06:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:06:52 --> Controller Class Initialized
INFO - 2016-08-23 09:06:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:06:52 --> Model Class Initialized
INFO - 2016-08-23 09:06:52 --> Model Class Initialized
INFO - 2016-08-23 09:06:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:06:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:06:52 --> Total execution time: 0.0541
INFO - 2016-08-23 09:07:22 --> Config Class Initialized
INFO - 2016-08-23 09:07:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:07:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:07:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:07:22 --> URI Class Initialized
INFO - 2016-08-23 09:07:22 --> Router Class Initialized
INFO - 2016-08-23 09:07:22 --> Output Class Initialized
INFO - 2016-08-23 09:07:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:07:22 --> Input Class Initialized
INFO - 2016-08-23 09:07:22 --> Language Class Initialized
INFO - 2016-08-23 09:07:22 --> Loader Class Initialized
INFO - 2016-08-23 09:07:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:07:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:07:22 --> Controller Class Initialized
INFO - 2016-08-23 09:07:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:07:22 --> Model Class Initialized
INFO - 2016-08-23 09:07:22 --> Model Class Initialized
INFO - 2016-08-23 09:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:07:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:07:22 --> Total execution time: 0.0561
INFO - 2016-08-23 09:07:52 --> Config Class Initialized
INFO - 2016-08-23 09:07:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:07:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:07:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:07:52 --> URI Class Initialized
INFO - 2016-08-23 09:07:52 --> Router Class Initialized
INFO - 2016-08-23 09:07:52 --> Output Class Initialized
INFO - 2016-08-23 09:07:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:07:52 --> Input Class Initialized
INFO - 2016-08-23 09:07:52 --> Language Class Initialized
INFO - 2016-08-23 09:07:52 --> Loader Class Initialized
INFO - 2016-08-23 09:07:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:07:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:07:52 --> Controller Class Initialized
INFO - 2016-08-23 09:07:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:07:52 --> Model Class Initialized
INFO - 2016-08-23 09:07:52 --> Model Class Initialized
INFO - 2016-08-23 09:07:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:07:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:07:52 --> Total execution time: 0.0540
INFO - 2016-08-23 09:08:22 --> Config Class Initialized
INFO - 2016-08-23 09:08:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:08:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:08:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:08:22 --> URI Class Initialized
INFO - 2016-08-23 09:08:22 --> Router Class Initialized
INFO - 2016-08-23 09:08:22 --> Output Class Initialized
INFO - 2016-08-23 09:08:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:08:22 --> Input Class Initialized
INFO - 2016-08-23 09:08:22 --> Language Class Initialized
INFO - 2016-08-23 09:08:22 --> Loader Class Initialized
INFO - 2016-08-23 09:08:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:08:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:08:22 --> Controller Class Initialized
INFO - 2016-08-23 09:08:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:08:22 --> Model Class Initialized
INFO - 2016-08-23 09:08:22 --> Model Class Initialized
INFO - 2016-08-23 09:08:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:08:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:08:22 --> Total execution time: 0.0664
INFO - 2016-08-23 09:08:52 --> Config Class Initialized
INFO - 2016-08-23 09:08:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:08:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:08:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:08:52 --> URI Class Initialized
INFO - 2016-08-23 09:08:52 --> Router Class Initialized
INFO - 2016-08-23 09:08:52 --> Output Class Initialized
INFO - 2016-08-23 09:08:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:08:52 --> Input Class Initialized
INFO - 2016-08-23 09:08:52 --> Language Class Initialized
INFO - 2016-08-23 09:08:52 --> Loader Class Initialized
INFO - 2016-08-23 09:08:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:08:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:08:52 --> Controller Class Initialized
INFO - 2016-08-23 09:08:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:08:52 --> Model Class Initialized
INFO - 2016-08-23 09:08:52 --> Model Class Initialized
INFO - 2016-08-23 09:08:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:08:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:08:52 --> Total execution time: 0.0533
INFO - 2016-08-23 09:09:22 --> Config Class Initialized
INFO - 2016-08-23 09:09:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:09:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:09:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:09:22 --> URI Class Initialized
INFO - 2016-08-23 09:09:22 --> Router Class Initialized
INFO - 2016-08-23 09:09:22 --> Output Class Initialized
INFO - 2016-08-23 09:09:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:09:22 --> Input Class Initialized
INFO - 2016-08-23 09:09:22 --> Language Class Initialized
INFO - 2016-08-23 09:09:22 --> Loader Class Initialized
INFO - 2016-08-23 09:09:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:09:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:09:22 --> Controller Class Initialized
INFO - 2016-08-23 09:09:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:09:22 --> Model Class Initialized
INFO - 2016-08-23 09:09:22 --> Model Class Initialized
INFO - 2016-08-23 09:09:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:09:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:09:22 --> Total execution time: 0.0533
INFO - 2016-08-23 09:09:52 --> Config Class Initialized
INFO - 2016-08-23 09:09:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:09:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:09:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:09:52 --> URI Class Initialized
INFO - 2016-08-23 09:09:52 --> Router Class Initialized
INFO - 2016-08-23 09:09:52 --> Output Class Initialized
INFO - 2016-08-23 09:09:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:09:52 --> Input Class Initialized
INFO - 2016-08-23 09:09:52 --> Language Class Initialized
INFO - 2016-08-23 09:09:52 --> Loader Class Initialized
INFO - 2016-08-23 09:09:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:09:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:09:52 --> Controller Class Initialized
INFO - 2016-08-23 09:09:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:09:52 --> Model Class Initialized
INFO - 2016-08-23 09:09:52 --> Model Class Initialized
INFO - 2016-08-23 09:09:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:09:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:09:52 --> Total execution time: 0.0595
INFO - 2016-08-23 09:10:22 --> Config Class Initialized
INFO - 2016-08-23 09:10:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:10:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:10:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:10:22 --> URI Class Initialized
INFO - 2016-08-23 09:10:22 --> Router Class Initialized
INFO - 2016-08-23 09:10:22 --> Output Class Initialized
INFO - 2016-08-23 09:10:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:10:22 --> Input Class Initialized
INFO - 2016-08-23 09:10:22 --> Language Class Initialized
INFO - 2016-08-23 09:10:22 --> Loader Class Initialized
INFO - 2016-08-23 09:10:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:10:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:10:22 --> Controller Class Initialized
INFO - 2016-08-23 09:10:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:10:22 --> Model Class Initialized
INFO - 2016-08-23 09:10:22 --> Model Class Initialized
INFO - 2016-08-23 09:10:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:10:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:10:22 --> Total execution time: 0.0523
INFO - 2016-08-23 09:10:52 --> Config Class Initialized
INFO - 2016-08-23 09:10:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:10:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:10:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:10:52 --> URI Class Initialized
INFO - 2016-08-23 09:10:52 --> Router Class Initialized
INFO - 2016-08-23 09:10:52 --> Output Class Initialized
INFO - 2016-08-23 09:10:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:10:52 --> Input Class Initialized
INFO - 2016-08-23 09:10:52 --> Language Class Initialized
INFO - 2016-08-23 09:10:52 --> Loader Class Initialized
INFO - 2016-08-23 09:10:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:10:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:10:52 --> Controller Class Initialized
INFO - 2016-08-23 09:10:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:10:52 --> Model Class Initialized
INFO - 2016-08-23 09:10:52 --> Model Class Initialized
INFO - 2016-08-23 09:10:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:10:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:10:52 --> Total execution time: 0.0538
INFO - 2016-08-23 09:11:22 --> Config Class Initialized
INFO - 2016-08-23 09:11:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:11:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:11:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:11:22 --> URI Class Initialized
INFO - 2016-08-23 09:11:22 --> Router Class Initialized
INFO - 2016-08-23 09:11:22 --> Output Class Initialized
INFO - 2016-08-23 09:11:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:11:22 --> Input Class Initialized
INFO - 2016-08-23 09:11:22 --> Language Class Initialized
INFO - 2016-08-23 09:11:22 --> Loader Class Initialized
INFO - 2016-08-23 09:11:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:11:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:11:22 --> Controller Class Initialized
INFO - 2016-08-23 09:11:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:11:22 --> Model Class Initialized
INFO - 2016-08-23 09:11:22 --> Model Class Initialized
INFO - 2016-08-23 09:11:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:11:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:11:22 --> Total execution time: 0.0624
INFO - 2016-08-23 09:11:52 --> Config Class Initialized
INFO - 2016-08-23 09:11:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:11:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:11:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:11:52 --> URI Class Initialized
INFO - 2016-08-23 09:11:52 --> Router Class Initialized
INFO - 2016-08-23 09:11:52 --> Output Class Initialized
INFO - 2016-08-23 09:11:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:11:52 --> Input Class Initialized
INFO - 2016-08-23 09:11:52 --> Language Class Initialized
INFO - 2016-08-23 09:11:52 --> Loader Class Initialized
INFO - 2016-08-23 09:11:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:11:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:11:52 --> Controller Class Initialized
INFO - 2016-08-23 09:11:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:11:52 --> Model Class Initialized
INFO - 2016-08-23 09:11:52 --> Model Class Initialized
INFO - 2016-08-23 09:11:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:11:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:11:52 --> Total execution time: 0.0625
INFO - 2016-08-23 09:12:22 --> Config Class Initialized
INFO - 2016-08-23 09:12:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:12:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:12:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:12:22 --> URI Class Initialized
INFO - 2016-08-23 09:12:22 --> Router Class Initialized
INFO - 2016-08-23 09:12:22 --> Output Class Initialized
INFO - 2016-08-23 09:12:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:12:22 --> Input Class Initialized
INFO - 2016-08-23 09:12:22 --> Language Class Initialized
INFO - 2016-08-23 09:12:22 --> Loader Class Initialized
INFO - 2016-08-23 09:12:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:12:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:12:22 --> Controller Class Initialized
INFO - 2016-08-23 09:12:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:12:22 --> Model Class Initialized
INFO - 2016-08-23 09:12:22 --> Model Class Initialized
INFO - 2016-08-23 09:12:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:12:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:12:22 --> Total execution time: 0.0541
INFO - 2016-08-23 09:13:22 --> Config Class Initialized
INFO - 2016-08-23 09:13:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:13:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:13:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:13:22 --> URI Class Initialized
INFO - 2016-08-23 09:13:22 --> Router Class Initialized
INFO - 2016-08-23 09:13:22 --> Output Class Initialized
INFO - 2016-08-23 09:13:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:13:22 --> Input Class Initialized
INFO - 2016-08-23 09:13:22 --> Language Class Initialized
INFO - 2016-08-23 09:13:22 --> Loader Class Initialized
INFO - 2016-08-23 09:13:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:13:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:13:22 --> Controller Class Initialized
INFO - 2016-08-23 09:13:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:13:22 --> Model Class Initialized
INFO - 2016-08-23 09:13:22 --> Model Class Initialized
INFO - 2016-08-23 09:13:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:13:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:13:22 --> Total execution time: 0.0597
INFO - 2016-08-23 09:13:52 --> Config Class Initialized
INFO - 2016-08-23 09:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:13:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:13:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:13:52 --> URI Class Initialized
INFO - 2016-08-23 09:13:52 --> Router Class Initialized
INFO - 2016-08-23 09:13:52 --> Output Class Initialized
INFO - 2016-08-23 09:13:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:13:52 --> Input Class Initialized
INFO - 2016-08-23 09:13:52 --> Language Class Initialized
INFO - 2016-08-23 09:13:52 --> Loader Class Initialized
INFO - 2016-08-23 09:13:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:13:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:13:52 --> Controller Class Initialized
INFO - 2016-08-23 09:13:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:13:52 --> Model Class Initialized
INFO - 2016-08-23 09:13:52 --> Model Class Initialized
INFO - 2016-08-23 09:13:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:13:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:13:52 --> Total execution time: 0.0554
INFO - 2016-08-23 09:14:22 --> Config Class Initialized
INFO - 2016-08-23 09:14:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:14:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:14:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:14:22 --> URI Class Initialized
INFO - 2016-08-23 09:14:22 --> Router Class Initialized
INFO - 2016-08-23 09:14:22 --> Output Class Initialized
INFO - 2016-08-23 09:14:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:14:22 --> Input Class Initialized
INFO - 2016-08-23 09:14:22 --> Language Class Initialized
INFO - 2016-08-23 09:14:22 --> Loader Class Initialized
INFO - 2016-08-23 09:14:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:14:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:14:22 --> Controller Class Initialized
INFO - 2016-08-23 09:14:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:14:22 --> Model Class Initialized
INFO - 2016-08-23 09:14:22 --> Model Class Initialized
INFO - 2016-08-23 09:14:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:14:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:14:22 --> Total execution time: 0.0510
INFO - 2016-08-23 09:14:52 --> Config Class Initialized
INFO - 2016-08-23 09:14:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:14:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:14:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:14:52 --> URI Class Initialized
INFO - 2016-08-23 09:14:52 --> Router Class Initialized
INFO - 2016-08-23 09:14:52 --> Output Class Initialized
INFO - 2016-08-23 09:14:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:14:52 --> Input Class Initialized
INFO - 2016-08-23 09:14:52 --> Language Class Initialized
INFO - 2016-08-23 09:14:52 --> Loader Class Initialized
INFO - 2016-08-23 09:14:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:14:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:14:52 --> Controller Class Initialized
INFO - 2016-08-23 09:14:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:14:52 --> Model Class Initialized
INFO - 2016-08-23 09:14:52 --> Model Class Initialized
INFO - 2016-08-23 09:14:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:14:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:14:52 --> Total execution time: 0.0566
INFO - 2016-08-23 09:15:22 --> Config Class Initialized
INFO - 2016-08-23 09:15:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:15:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:15:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:15:22 --> URI Class Initialized
INFO - 2016-08-23 09:15:22 --> Router Class Initialized
INFO - 2016-08-23 09:15:22 --> Output Class Initialized
INFO - 2016-08-23 09:15:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:15:22 --> Input Class Initialized
INFO - 2016-08-23 09:15:22 --> Language Class Initialized
INFO - 2016-08-23 09:15:22 --> Loader Class Initialized
INFO - 2016-08-23 09:15:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:15:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:15:22 --> Controller Class Initialized
INFO - 2016-08-23 09:15:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:15:22 --> Model Class Initialized
INFO - 2016-08-23 09:15:22 --> Model Class Initialized
INFO - 2016-08-23 09:15:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:15:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:15:22 --> Total execution time: 0.0572
INFO - 2016-08-23 09:15:52 --> Config Class Initialized
INFO - 2016-08-23 09:15:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:15:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:15:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:15:52 --> URI Class Initialized
INFO - 2016-08-23 09:15:52 --> Router Class Initialized
INFO - 2016-08-23 09:15:52 --> Output Class Initialized
INFO - 2016-08-23 09:15:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:15:52 --> Input Class Initialized
INFO - 2016-08-23 09:15:52 --> Language Class Initialized
INFO - 2016-08-23 09:15:52 --> Loader Class Initialized
INFO - 2016-08-23 09:15:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:15:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:15:52 --> Controller Class Initialized
INFO - 2016-08-23 09:15:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:15:52 --> Model Class Initialized
INFO - 2016-08-23 09:15:52 --> Model Class Initialized
INFO - 2016-08-23 09:15:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:15:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:15:52 --> Total execution time: 0.0555
INFO - 2016-08-23 09:16:22 --> Config Class Initialized
INFO - 2016-08-23 09:16:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:16:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:16:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:16:22 --> URI Class Initialized
INFO - 2016-08-23 09:16:22 --> Router Class Initialized
INFO - 2016-08-23 09:16:22 --> Output Class Initialized
INFO - 2016-08-23 09:16:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:16:22 --> Input Class Initialized
INFO - 2016-08-23 09:16:22 --> Language Class Initialized
INFO - 2016-08-23 09:16:22 --> Loader Class Initialized
INFO - 2016-08-23 09:16:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:16:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:16:22 --> Controller Class Initialized
INFO - 2016-08-23 09:16:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:16:22 --> Model Class Initialized
INFO - 2016-08-23 09:16:22 --> Model Class Initialized
INFO - 2016-08-23 09:16:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:16:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:16:22 --> Total execution time: 0.0685
INFO - 2016-08-23 09:16:52 --> Config Class Initialized
INFO - 2016-08-23 09:16:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:16:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:16:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:16:52 --> URI Class Initialized
INFO - 2016-08-23 09:16:52 --> Router Class Initialized
INFO - 2016-08-23 09:16:52 --> Output Class Initialized
INFO - 2016-08-23 09:16:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:16:52 --> Input Class Initialized
INFO - 2016-08-23 09:16:52 --> Language Class Initialized
INFO - 2016-08-23 09:16:52 --> Loader Class Initialized
INFO - 2016-08-23 09:16:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:16:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:16:52 --> Controller Class Initialized
INFO - 2016-08-23 09:16:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:16:52 --> Model Class Initialized
INFO - 2016-08-23 09:16:52 --> Model Class Initialized
INFO - 2016-08-23 09:16:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:16:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:16:52 --> Total execution time: 0.0623
INFO - 2016-08-23 09:17:22 --> Config Class Initialized
INFO - 2016-08-23 09:17:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:17:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:17:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:17:22 --> URI Class Initialized
INFO - 2016-08-23 09:17:22 --> Router Class Initialized
INFO - 2016-08-23 09:17:22 --> Output Class Initialized
INFO - 2016-08-23 09:17:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:17:22 --> Input Class Initialized
INFO - 2016-08-23 09:17:22 --> Language Class Initialized
INFO - 2016-08-23 09:17:22 --> Loader Class Initialized
INFO - 2016-08-23 09:17:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:17:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:17:22 --> Controller Class Initialized
INFO - 2016-08-23 09:17:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:17:22 --> Model Class Initialized
INFO - 2016-08-23 09:17:22 --> Model Class Initialized
INFO - 2016-08-23 09:17:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:17:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:17:22 --> Total execution time: 0.0714
INFO - 2016-08-23 09:17:52 --> Config Class Initialized
INFO - 2016-08-23 09:17:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:17:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:17:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:17:52 --> URI Class Initialized
INFO - 2016-08-23 09:17:52 --> Router Class Initialized
INFO - 2016-08-23 09:17:52 --> Output Class Initialized
INFO - 2016-08-23 09:17:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:17:52 --> Input Class Initialized
INFO - 2016-08-23 09:17:52 --> Language Class Initialized
INFO - 2016-08-23 09:17:52 --> Loader Class Initialized
INFO - 2016-08-23 09:17:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:17:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:17:52 --> Controller Class Initialized
INFO - 2016-08-23 09:17:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:17:52 --> Model Class Initialized
INFO - 2016-08-23 09:17:52 --> Model Class Initialized
INFO - 2016-08-23 09:17:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:17:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:17:52 --> Total execution time: 0.0554
INFO - 2016-08-23 09:18:22 --> Config Class Initialized
INFO - 2016-08-23 09:18:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:18:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:18:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:18:22 --> URI Class Initialized
INFO - 2016-08-23 09:18:22 --> Router Class Initialized
INFO - 2016-08-23 09:18:22 --> Output Class Initialized
INFO - 2016-08-23 09:18:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:18:22 --> Input Class Initialized
INFO - 2016-08-23 09:18:22 --> Language Class Initialized
INFO - 2016-08-23 09:18:22 --> Loader Class Initialized
INFO - 2016-08-23 09:18:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:18:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:18:22 --> Controller Class Initialized
INFO - 2016-08-23 09:18:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:18:22 --> Model Class Initialized
INFO - 2016-08-23 09:18:22 --> Model Class Initialized
INFO - 2016-08-23 09:18:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:18:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:18:22 --> Total execution time: 0.0677
INFO - 2016-08-23 09:18:52 --> Config Class Initialized
INFO - 2016-08-23 09:18:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:18:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:18:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:18:52 --> URI Class Initialized
INFO - 2016-08-23 09:18:52 --> Router Class Initialized
INFO - 2016-08-23 09:18:52 --> Output Class Initialized
INFO - 2016-08-23 09:18:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:18:52 --> Input Class Initialized
INFO - 2016-08-23 09:18:52 --> Language Class Initialized
INFO - 2016-08-23 09:18:52 --> Loader Class Initialized
INFO - 2016-08-23 09:18:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:18:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:18:52 --> Controller Class Initialized
INFO - 2016-08-23 09:18:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:18:52 --> Model Class Initialized
INFO - 2016-08-23 09:18:52 --> Model Class Initialized
INFO - 2016-08-23 09:18:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:18:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:18:52 --> Total execution time: 0.0559
INFO - 2016-08-23 09:19:22 --> Config Class Initialized
INFO - 2016-08-23 09:19:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:19:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:19:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:19:22 --> URI Class Initialized
INFO - 2016-08-23 09:19:22 --> Router Class Initialized
INFO - 2016-08-23 09:19:22 --> Output Class Initialized
INFO - 2016-08-23 09:19:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:19:22 --> Input Class Initialized
INFO - 2016-08-23 09:19:22 --> Language Class Initialized
INFO - 2016-08-23 09:19:22 --> Loader Class Initialized
INFO - 2016-08-23 09:19:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:19:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:19:22 --> Controller Class Initialized
INFO - 2016-08-23 09:19:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:19:22 --> Model Class Initialized
INFO - 2016-08-23 09:19:22 --> Model Class Initialized
INFO - 2016-08-23 09:19:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:19:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:19:22 --> Total execution time: 0.0683
INFO - 2016-08-23 09:19:52 --> Config Class Initialized
INFO - 2016-08-23 09:19:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:19:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:19:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:19:52 --> URI Class Initialized
INFO - 2016-08-23 09:19:52 --> Router Class Initialized
INFO - 2016-08-23 09:19:52 --> Output Class Initialized
INFO - 2016-08-23 09:19:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:19:52 --> Input Class Initialized
INFO - 2016-08-23 09:19:52 --> Language Class Initialized
INFO - 2016-08-23 09:19:52 --> Loader Class Initialized
INFO - 2016-08-23 09:19:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:19:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:19:52 --> Controller Class Initialized
INFO - 2016-08-23 09:19:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:19:52 --> Model Class Initialized
INFO - 2016-08-23 09:19:52 --> Model Class Initialized
INFO - 2016-08-23 09:19:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:19:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:19:52 --> Total execution time: 0.0544
INFO - 2016-08-23 09:20:22 --> Config Class Initialized
INFO - 2016-08-23 09:20:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:20:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:20:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:20:22 --> URI Class Initialized
INFO - 2016-08-23 09:20:22 --> Router Class Initialized
INFO - 2016-08-23 09:20:22 --> Output Class Initialized
INFO - 2016-08-23 09:20:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:20:22 --> Input Class Initialized
INFO - 2016-08-23 09:20:22 --> Language Class Initialized
INFO - 2016-08-23 09:20:22 --> Loader Class Initialized
INFO - 2016-08-23 09:20:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:20:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:20:22 --> Controller Class Initialized
INFO - 2016-08-23 09:20:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:20:22 --> Model Class Initialized
INFO - 2016-08-23 09:20:22 --> Model Class Initialized
INFO - 2016-08-23 09:20:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:20:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:20:22 --> Total execution time: 0.0611
INFO - 2016-08-23 09:20:52 --> Config Class Initialized
INFO - 2016-08-23 09:20:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:20:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:20:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:20:52 --> URI Class Initialized
INFO - 2016-08-23 09:20:52 --> Router Class Initialized
INFO - 2016-08-23 09:20:52 --> Output Class Initialized
INFO - 2016-08-23 09:20:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:20:52 --> Input Class Initialized
INFO - 2016-08-23 09:20:52 --> Language Class Initialized
INFO - 2016-08-23 09:20:52 --> Loader Class Initialized
INFO - 2016-08-23 09:20:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:20:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:20:52 --> Controller Class Initialized
INFO - 2016-08-23 09:20:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:20:52 --> Model Class Initialized
INFO - 2016-08-23 09:20:52 --> Model Class Initialized
INFO - 2016-08-23 09:20:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:20:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:20:52 --> Total execution time: 0.0635
INFO - 2016-08-23 09:21:22 --> Config Class Initialized
INFO - 2016-08-23 09:21:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:21:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:21:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:21:22 --> URI Class Initialized
INFO - 2016-08-23 09:21:22 --> Router Class Initialized
INFO - 2016-08-23 09:21:22 --> Output Class Initialized
INFO - 2016-08-23 09:21:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:21:22 --> Input Class Initialized
INFO - 2016-08-23 09:21:22 --> Language Class Initialized
INFO - 2016-08-23 09:21:22 --> Loader Class Initialized
INFO - 2016-08-23 09:21:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:21:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:21:22 --> Controller Class Initialized
INFO - 2016-08-23 09:21:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:21:22 --> Model Class Initialized
INFO - 2016-08-23 09:21:22 --> Model Class Initialized
INFO - 2016-08-23 09:21:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:21:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:21:22 --> Total execution time: 0.0606
INFO - 2016-08-23 09:21:52 --> Config Class Initialized
INFO - 2016-08-23 09:21:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:21:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:21:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:21:52 --> URI Class Initialized
INFO - 2016-08-23 09:21:52 --> Router Class Initialized
INFO - 2016-08-23 09:21:52 --> Output Class Initialized
INFO - 2016-08-23 09:21:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:21:52 --> Input Class Initialized
INFO - 2016-08-23 09:21:52 --> Language Class Initialized
INFO - 2016-08-23 09:21:52 --> Loader Class Initialized
INFO - 2016-08-23 09:21:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:21:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:21:52 --> Controller Class Initialized
INFO - 2016-08-23 09:21:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:21:52 --> Model Class Initialized
INFO - 2016-08-23 09:21:52 --> Model Class Initialized
INFO - 2016-08-23 09:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:21:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:21:52 --> Total execution time: 0.0572
INFO - 2016-08-23 09:22:22 --> Config Class Initialized
INFO - 2016-08-23 09:22:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:22:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:22:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:22:22 --> URI Class Initialized
INFO - 2016-08-23 09:22:22 --> Router Class Initialized
INFO - 2016-08-23 09:22:22 --> Output Class Initialized
INFO - 2016-08-23 09:22:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:22:22 --> Input Class Initialized
INFO - 2016-08-23 09:22:22 --> Language Class Initialized
INFO - 2016-08-23 09:22:22 --> Loader Class Initialized
INFO - 2016-08-23 09:22:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:22:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:22:22 --> Controller Class Initialized
INFO - 2016-08-23 09:22:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:22:22 --> Model Class Initialized
INFO - 2016-08-23 09:22:22 --> Model Class Initialized
INFO - 2016-08-23 09:22:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:22:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:22:22 --> Total execution time: 0.0590
INFO - 2016-08-23 09:22:52 --> Config Class Initialized
INFO - 2016-08-23 09:22:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:22:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:22:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:22:52 --> URI Class Initialized
INFO - 2016-08-23 09:22:52 --> Router Class Initialized
INFO - 2016-08-23 09:22:52 --> Output Class Initialized
INFO - 2016-08-23 09:22:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:22:52 --> Input Class Initialized
INFO - 2016-08-23 09:22:52 --> Language Class Initialized
INFO - 2016-08-23 09:22:52 --> Loader Class Initialized
INFO - 2016-08-23 09:22:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:22:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:22:52 --> Controller Class Initialized
INFO - 2016-08-23 09:22:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:22:52 --> Model Class Initialized
INFO - 2016-08-23 09:22:52 --> Model Class Initialized
INFO - 2016-08-23 09:22:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:22:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:22:52 --> Total execution time: 0.0713
INFO - 2016-08-23 09:23:22 --> Config Class Initialized
INFO - 2016-08-23 09:23:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:23:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:23:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:23:22 --> URI Class Initialized
INFO - 2016-08-23 09:23:22 --> Router Class Initialized
INFO - 2016-08-23 09:23:22 --> Output Class Initialized
INFO - 2016-08-23 09:23:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:23:22 --> Input Class Initialized
INFO - 2016-08-23 09:23:22 --> Language Class Initialized
INFO - 2016-08-23 09:23:22 --> Loader Class Initialized
INFO - 2016-08-23 09:23:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:23:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:23:22 --> Controller Class Initialized
INFO - 2016-08-23 09:23:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:23:22 --> Model Class Initialized
INFO - 2016-08-23 09:23:22 --> Model Class Initialized
INFO - 2016-08-23 09:23:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:23:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:23:22 --> Total execution time: 0.0761
INFO - 2016-08-23 09:23:52 --> Config Class Initialized
INFO - 2016-08-23 09:23:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:23:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:23:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:23:52 --> URI Class Initialized
INFO - 2016-08-23 09:23:52 --> Router Class Initialized
INFO - 2016-08-23 09:23:52 --> Output Class Initialized
INFO - 2016-08-23 09:23:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:23:52 --> Input Class Initialized
INFO - 2016-08-23 09:23:52 --> Language Class Initialized
INFO - 2016-08-23 09:23:52 --> Loader Class Initialized
INFO - 2016-08-23 09:23:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:23:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:23:52 --> Controller Class Initialized
INFO - 2016-08-23 09:23:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:23:52 --> Model Class Initialized
INFO - 2016-08-23 09:23:52 --> Model Class Initialized
INFO - 2016-08-23 09:23:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:23:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:23:52 --> Total execution time: 0.0636
INFO - 2016-08-23 09:24:22 --> Config Class Initialized
INFO - 2016-08-23 09:24:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:24:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:24:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:24:22 --> URI Class Initialized
INFO - 2016-08-23 09:24:22 --> Router Class Initialized
INFO - 2016-08-23 09:24:22 --> Output Class Initialized
INFO - 2016-08-23 09:24:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:24:22 --> Input Class Initialized
INFO - 2016-08-23 09:24:22 --> Language Class Initialized
INFO - 2016-08-23 09:24:22 --> Loader Class Initialized
INFO - 2016-08-23 09:24:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:24:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:24:22 --> Controller Class Initialized
INFO - 2016-08-23 09:24:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:24:22 --> Model Class Initialized
INFO - 2016-08-23 09:24:22 --> Model Class Initialized
INFO - 2016-08-23 09:24:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:24:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:24:22 --> Total execution time: 0.0587
INFO - 2016-08-23 09:24:52 --> Config Class Initialized
INFO - 2016-08-23 09:24:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:24:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:24:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:24:52 --> URI Class Initialized
INFO - 2016-08-23 09:24:52 --> Router Class Initialized
INFO - 2016-08-23 09:24:52 --> Output Class Initialized
INFO - 2016-08-23 09:24:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:24:52 --> Input Class Initialized
INFO - 2016-08-23 09:24:52 --> Language Class Initialized
INFO - 2016-08-23 09:24:52 --> Loader Class Initialized
INFO - 2016-08-23 09:24:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:24:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:24:52 --> Controller Class Initialized
INFO - 2016-08-23 09:24:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:24:52 --> Model Class Initialized
INFO - 2016-08-23 09:24:52 --> Model Class Initialized
INFO - 2016-08-23 09:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:24:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:24:52 --> Total execution time: 0.0754
INFO - 2016-08-23 09:25:22 --> Config Class Initialized
INFO - 2016-08-23 09:25:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:25:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:25:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:25:22 --> URI Class Initialized
INFO - 2016-08-23 09:25:22 --> Router Class Initialized
INFO - 2016-08-23 09:25:22 --> Output Class Initialized
INFO - 2016-08-23 09:25:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:25:22 --> Input Class Initialized
INFO - 2016-08-23 09:25:22 --> Language Class Initialized
INFO - 2016-08-23 09:25:22 --> Loader Class Initialized
INFO - 2016-08-23 09:25:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:25:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:25:22 --> Controller Class Initialized
INFO - 2016-08-23 09:25:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:25:22 --> Model Class Initialized
INFO - 2016-08-23 09:25:22 --> Model Class Initialized
INFO - 2016-08-23 09:25:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:25:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:25:22 --> Total execution time: 0.0533
INFO - 2016-08-23 09:25:52 --> Config Class Initialized
INFO - 2016-08-23 09:25:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:25:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:25:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:25:52 --> URI Class Initialized
INFO - 2016-08-23 09:25:52 --> Router Class Initialized
INFO - 2016-08-23 09:25:52 --> Output Class Initialized
INFO - 2016-08-23 09:25:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:25:52 --> Input Class Initialized
INFO - 2016-08-23 09:25:52 --> Language Class Initialized
INFO - 2016-08-23 09:25:52 --> Loader Class Initialized
INFO - 2016-08-23 09:25:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:25:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:25:52 --> Controller Class Initialized
INFO - 2016-08-23 09:25:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:25:52 --> Model Class Initialized
INFO - 2016-08-23 09:25:52 --> Model Class Initialized
INFO - 2016-08-23 09:25:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:25:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:25:52 --> Total execution time: 0.0514
INFO - 2016-08-23 09:26:22 --> Config Class Initialized
INFO - 2016-08-23 09:26:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:26:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:26:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:26:22 --> URI Class Initialized
INFO - 2016-08-23 09:26:22 --> Router Class Initialized
INFO - 2016-08-23 09:26:22 --> Output Class Initialized
INFO - 2016-08-23 09:26:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:26:22 --> Input Class Initialized
INFO - 2016-08-23 09:26:22 --> Language Class Initialized
INFO - 2016-08-23 09:26:22 --> Loader Class Initialized
INFO - 2016-08-23 09:26:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:26:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:26:22 --> Controller Class Initialized
INFO - 2016-08-23 09:26:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:26:22 --> Model Class Initialized
INFO - 2016-08-23 09:26:22 --> Model Class Initialized
INFO - 2016-08-23 09:26:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:26:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:26:22 --> Total execution time: 0.0651
INFO - 2016-08-23 09:26:52 --> Config Class Initialized
INFO - 2016-08-23 09:26:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:26:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:26:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:26:52 --> URI Class Initialized
INFO - 2016-08-23 09:26:52 --> Router Class Initialized
INFO - 2016-08-23 09:26:52 --> Output Class Initialized
INFO - 2016-08-23 09:26:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:26:52 --> Input Class Initialized
INFO - 2016-08-23 09:26:52 --> Language Class Initialized
INFO - 2016-08-23 09:26:52 --> Loader Class Initialized
INFO - 2016-08-23 09:26:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:26:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:26:52 --> Controller Class Initialized
INFO - 2016-08-23 09:26:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:26:52 --> Model Class Initialized
INFO - 2016-08-23 09:26:52 --> Model Class Initialized
INFO - 2016-08-23 09:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:26:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:26:52 --> Total execution time: 0.0531
INFO - 2016-08-23 09:27:22 --> Config Class Initialized
INFO - 2016-08-23 09:27:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:27:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:27:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:27:22 --> URI Class Initialized
INFO - 2016-08-23 09:27:22 --> Router Class Initialized
INFO - 2016-08-23 09:27:22 --> Output Class Initialized
INFO - 2016-08-23 09:27:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:27:22 --> Input Class Initialized
INFO - 2016-08-23 09:27:22 --> Language Class Initialized
INFO - 2016-08-23 09:27:22 --> Loader Class Initialized
INFO - 2016-08-23 09:27:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:27:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:27:22 --> Controller Class Initialized
INFO - 2016-08-23 09:27:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:27:22 --> Model Class Initialized
INFO - 2016-08-23 09:27:22 --> Model Class Initialized
INFO - 2016-08-23 09:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:27:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:27:22 --> Total execution time: 0.0595
INFO - 2016-08-23 09:27:52 --> Config Class Initialized
INFO - 2016-08-23 09:27:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:27:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:27:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:27:52 --> URI Class Initialized
INFO - 2016-08-23 09:27:52 --> Router Class Initialized
INFO - 2016-08-23 09:27:52 --> Output Class Initialized
INFO - 2016-08-23 09:27:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:27:52 --> Input Class Initialized
INFO - 2016-08-23 09:27:52 --> Language Class Initialized
INFO - 2016-08-23 09:27:52 --> Loader Class Initialized
INFO - 2016-08-23 09:27:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:27:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:27:52 --> Controller Class Initialized
INFO - 2016-08-23 09:27:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:27:52 --> Model Class Initialized
INFO - 2016-08-23 09:27:52 --> Model Class Initialized
INFO - 2016-08-23 09:27:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:27:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:27:52 --> Total execution time: 0.0512
INFO - 2016-08-23 09:28:22 --> Config Class Initialized
INFO - 2016-08-23 09:28:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:28:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:28:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:28:22 --> URI Class Initialized
INFO - 2016-08-23 09:28:22 --> Router Class Initialized
INFO - 2016-08-23 09:28:22 --> Output Class Initialized
INFO - 2016-08-23 09:28:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:28:22 --> Input Class Initialized
INFO - 2016-08-23 09:28:22 --> Language Class Initialized
INFO - 2016-08-23 09:28:22 --> Loader Class Initialized
INFO - 2016-08-23 09:28:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:28:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:28:22 --> Controller Class Initialized
INFO - 2016-08-23 09:28:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:28:22 --> Model Class Initialized
INFO - 2016-08-23 09:28:22 --> Model Class Initialized
INFO - 2016-08-23 09:28:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:28:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:28:22 --> Total execution time: 0.0610
INFO - 2016-08-23 09:28:52 --> Config Class Initialized
INFO - 2016-08-23 09:28:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:28:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:28:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:28:52 --> URI Class Initialized
INFO - 2016-08-23 09:28:52 --> Router Class Initialized
INFO - 2016-08-23 09:28:52 --> Output Class Initialized
INFO - 2016-08-23 09:28:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:28:52 --> Input Class Initialized
INFO - 2016-08-23 09:28:52 --> Language Class Initialized
INFO - 2016-08-23 09:28:52 --> Loader Class Initialized
INFO - 2016-08-23 09:28:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:28:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:28:52 --> Controller Class Initialized
INFO - 2016-08-23 09:28:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:28:52 --> Model Class Initialized
INFO - 2016-08-23 09:28:52 --> Model Class Initialized
INFO - 2016-08-23 09:28:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:28:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:28:52 --> Total execution time: 0.0559
INFO - 2016-08-23 09:29:22 --> Config Class Initialized
INFO - 2016-08-23 09:29:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:29:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:29:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:29:22 --> URI Class Initialized
INFO - 2016-08-23 09:29:22 --> Router Class Initialized
INFO - 2016-08-23 09:29:22 --> Output Class Initialized
INFO - 2016-08-23 09:29:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:29:22 --> Input Class Initialized
INFO - 2016-08-23 09:29:22 --> Language Class Initialized
INFO - 2016-08-23 09:29:22 --> Loader Class Initialized
INFO - 2016-08-23 09:29:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:29:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:29:22 --> Controller Class Initialized
INFO - 2016-08-23 09:29:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:29:22 --> Model Class Initialized
INFO - 2016-08-23 09:29:22 --> Model Class Initialized
INFO - 2016-08-23 09:29:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:29:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:29:22 --> Total execution time: 0.0597
INFO - 2016-08-23 09:29:52 --> Config Class Initialized
INFO - 2016-08-23 09:29:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:29:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:29:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:29:52 --> URI Class Initialized
INFO - 2016-08-23 09:29:52 --> Router Class Initialized
INFO - 2016-08-23 09:29:52 --> Output Class Initialized
INFO - 2016-08-23 09:29:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:29:52 --> Input Class Initialized
INFO - 2016-08-23 09:29:52 --> Language Class Initialized
INFO - 2016-08-23 09:29:52 --> Loader Class Initialized
INFO - 2016-08-23 09:29:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:29:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:29:52 --> Controller Class Initialized
INFO - 2016-08-23 09:29:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:29:52 --> Model Class Initialized
INFO - 2016-08-23 09:29:52 --> Model Class Initialized
INFO - 2016-08-23 09:29:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:29:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:29:52 --> Total execution time: 0.0662
INFO - 2016-08-23 09:30:22 --> Config Class Initialized
INFO - 2016-08-23 09:30:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:30:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:30:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:30:22 --> URI Class Initialized
INFO - 2016-08-23 09:30:22 --> Router Class Initialized
INFO - 2016-08-23 09:30:22 --> Output Class Initialized
INFO - 2016-08-23 09:30:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:30:22 --> Input Class Initialized
INFO - 2016-08-23 09:30:22 --> Language Class Initialized
INFO - 2016-08-23 09:30:22 --> Loader Class Initialized
INFO - 2016-08-23 09:30:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:30:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:30:22 --> Controller Class Initialized
INFO - 2016-08-23 09:30:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:30:22 --> Model Class Initialized
INFO - 2016-08-23 09:30:22 --> Model Class Initialized
INFO - 2016-08-23 09:30:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:30:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:30:22 --> Total execution time: 0.0618
INFO - 2016-08-23 09:30:52 --> Config Class Initialized
INFO - 2016-08-23 09:30:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:30:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:30:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:30:52 --> URI Class Initialized
INFO - 2016-08-23 09:30:52 --> Router Class Initialized
INFO - 2016-08-23 09:30:52 --> Output Class Initialized
INFO - 2016-08-23 09:30:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:30:52 --> Input Class Initialized
INFO - 2016-08-23 09:30:52 --> Language Class Initialized
INFO - 2016-08-23 09:30:52 --> Loader Class Initialized
INFO - 2016-08-23 09:30:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:30:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:30:52 --> Controller Class Initialized
INFO - 2016-08-23 09:30:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:30:52 --> Model Class Initialized
INFO - 2016-08-23 09:30:52 --> Model Class Initialized
INFO - 2016-08-23 09:30:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:30:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:30:52 --> Total execution time: 0.0528
INFO - 2016-08-23 09:31:22 --> Config Class Initialized
INFO - 2016-08-23 09:31:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:31:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:31:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:31:22 --> URI Class Initialized
INFO - 2016-08-23 09:31:22 --> Router Class Initialized
INFO - 2016-08-23 09:31:22 --> Output Class Initialized
INFO - 2016-08-23 09:31:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:31:22 --> Input Class Initialized
INFO - 2016-08-23 09:31:22 --> Language Class Initialized
INFO - 2016-08-23 09:31:22 --> Loader Class Initialized
INFO - 2016-08-23 09:31:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:31:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:31:22 --> Controller Class Initialized
INFO - 2016-08-23 09:31:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:31:22 --> Model Class Initialized
INFO - 2016-08-23 09:31:22 --> Model Class Initialized
INFO - 2016-08-23 09:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:31:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:31:22 --> Total execution time: 0.0547
INFO - 2016-08-23 09:31:52 --> Config Class Initialized
INFO - 2016-08-23 09:31:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:31:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:31:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:31:52 --> URI Class Initialized
INFO - 2016-08-23 09:31:52 --> Router Class Initialized
INFO - 2016-08-23 09:31:52 --> Output Class Initialized
INFO - 2016-08-23 09:31:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:31:52 --> Input Class Initialized
INFO - 2016-08-23 09:31:52 --> Language Class Initialized
INFO - 2016-08-23 09:31:52 --> Loader Class Initialized
INFO - 2016-08-23 09:31:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:31:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:31:52 --> Controller Class Initialized
INFO - 2016-08-23 09:31:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:31:52 --> Model Class Initialized
INFO - 2016-08-23 09:31:52 --> Model Class Initialized
INFO - 2016-08-23 09:31:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:31:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:31:52 --> Total execution time: 0.0520
INFO - 2016-08-23 09:32:22 --> Config Class Initialized
INFO - 2016-08-23 09:32:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:32:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:32:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:32:22 --> URI Class Initialized
INFO - 2016-08-23 09:32:22 --> Router Class Initialized
INFO - 2016-08-23 09:32:22 --> Output Class Initialized
INFO - 2016-08-23 09:32:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:32:22 --> Input Class Initialized
INFO - 2016-08-23 09:32:22 --> Language Class Initialized
INFO - 2016-08-23 09:32:22 --> Loader Class Initialized
INFO - 2016-08-23 09:32:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:32:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:32:22 --> Controller Class Initialized
INFO - 2016-08-23 09:32:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:32:22 --> Model Class Initialized
INFO - 2016-08-23 09:32:22 --> Model Class Initialized
INFO - 2016-08-23 09:32:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:32:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:32:22 --> Total execution time: 0.0559
INFO - 2016-08-23 09:32:52 --> Config Class Initialized
INFO - 2016-08-23 09:32:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:32:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:32:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:32:52 --> URI Class Initialized
INFO - 2016-08-23 09:32:52 --> Router Class Initialized
INFO - 2016-08-23 09:32:52 --> Output Class Initialized
INFO - 2016-08-23 09:32:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:32:52 --> Input Class Initialized
INFO - 2016-08-23 09:32:52 --> Language Class Initialized
INFO - 2016-08-23 09:32:52 --> Loader Class Initialized
INFO - 2016-08-23 09:32:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:32:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:32:52 --> Controller Class Initialized
INFO - 2016-08-23 09:32:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:32:52 --> Model Class Initialized
INFO - 2016-08-23 09:32:52 --> Model Class Initialized
INFO - 2016-08-23 09:32:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:32:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:32:52 --> Total execution time: 0.0592
INFO - 2016-08-23 09:33:22 --> Config Class Initialized
INFO - 2016-08-23 09:33:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:33:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:33:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:33:22 --> URI Class Initialized
INFO - 2016-08-23 09:33:22 --> Router Class Initialized
INFO - 2016-08-23 09:33:22 --> Output Class Initialized
INFO - 2016-08-23 09:33:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:33:22 --> Input Class Initialized
INFO - 2016-08-23 09:33:22 --> Language Class Initialized
INFO - 2016-08-23 09:33:22 --> Loader Class Initialized
INFO - 2016-08-23 09:33:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:33:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:33:22 --> Controller Class Initialized
INFO - 2016-08-23 09:33:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:33:22 --> Model Class Initialized
INFO - 2016-08-23 09:33:22 --> Model Class Initialized
INFO - 2016-08-23 09:33:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:33:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:33:22 --> Total execution time: 0.0634
INFO - 2016-08-23 09:33:52 --> Config Class Initialized
INFO - 2016-08-23 09:33:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:33:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:33:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:33:52 --> URI Class Initialized
INFO - 2016-08-23 09:33:52 --> Router Class Initialized
INFO - 2016-08-23 09:33:52 --> Output Class Initialized
INFO - 2016-08-23 09:33:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:33:52 --> Input Class Initialized
INFO - 2016-08-23 09:33:52 --> Language Class Initialized
INFO - 2016-08-23 09:33:52 --> Loader Class Initialized
INFO - 2016-08-23 09:33:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:33:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:33:52 --> Controller Class Initialized
INFO - 2016-08-23 09:33:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:33:52 --> Model Class Initialized
INFO - 2016-08-23 09:33:52 --> Model Class Initialized
INFO - 2016-08-23 09:33:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:33:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:33:52 --> Total execution time: 0.0708
INFO - 2016-08-23 09:34:22 --> Config Class Initialized
INFO - 2016-08-23 09:34:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:34:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:34:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:34:22 --> URI Class Initialized
INFO - 2016-08-23 09:34:22 --> Router Class Initialized
INFO - 2016-08-23 09:34:22 --> Output Class Initialized
INFO - 2016-08-23 09:34:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:34:22 --> Input Class Initialized
INFO - 2016-08-23 09:34:22 --> Language Class Initialized
INFO - 2016-08-23 09:34:22 --> Loader Class Initialized
INFO - 2016-08-23 09:34:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:34:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:34:22 --> Controller Class Initialized
INFO - 2016-08-23 09:34:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:34:22 --> Model Class Initialized
INFO - 2016-08-23 09:34:22 --> Model Class Initialized
INFO - 2016-08-23 09:34:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:34:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:34:22 --> Total execution time: 0.0514
INFO - 2016-08-23 09:34:52 --> Config Class Initialized
INFO - 2016-08-23 09:34:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:34:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:34:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:34:52 --> URI Class Initialized
INFO - 2016-08-23 09:34:52 --> Router Class Initialized
INFO - 2016-08-23 09:34:52 --> Output Class Initialized
INFO - 2016-08-23 09:34:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:34:52 --> Input Class Initialized
INFO - 2016-08-23 09:34:52 --> Language Class Initialized
INFO - 2016-08-23 09:34:52 --> Loader Class Initialized
INFO - 2016-08-23 09:34:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:34:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:34:52 --> Controller Class Initialized
INFO - 2016-08-23 09:34:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:34:52 --> Model Class Initialized
INFO - 2016-08-23 09:34:52 --> Model Class Initialized
INFO - 2016-08-23 09:34:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:34:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:34:52 --> Total execution time: 0.0614
INFO - 2016-08-23 09:35:22 --> Config Class Initialized
INFO - 2016-08-23 09:35:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:35:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:35:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:35:22 --> URI Class Initialized
INFO - 2016-08-23 09:35:22 --> Router Class Initialized
INFO - 2016-08-23 09:35:22 --> Output Class Initialized
INFO - 2016-08-23 09:35:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:35:22 --> Input Class Initialized
INFO - 2016-08-23 09:35:22 --> Language Class Initialized
INFO - 2016-08-23 09:35:22 --> Loader Class Initialized
INFO - 2016-08-23 09:35:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:35:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:35:22 --> Controller Class Initialized
INFO - 2016-08-23 09:35:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:35:22 --> Model Class Initialized
INFO - 2016-08-23 09:35:22 --> Model Class Initialized
INFO - 2016-08-23 09:35:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:35:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:35:22 --> Total execution time: 0.0525
INFO - 2016-08-23 09:35:52 --> Config Class Initialized
INFO - 2016-08-23 09:35:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:35:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:35:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:35:52 --> URI Class Initialized
INFO - 2016-08-23 09:35:52 --> Router Class Initialized
INFO - 2016-08-23 09:35:52 --> Output Class Initialized
INFO - 2016-08-23 09:35:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:35:52 --> Input Class Initialized
INFO - 2016-08-23 09:35:52 --> Language Class Initialized
INFO - 2016-08-23 09:35:52 --> Loader Class Initialized
INFO - 2016-08-23 09:35:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:35:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:35:52 --> Controller Class Initialized
INFO - 2016-08-23 09:35:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:35:52 --> Model Class Initialized
INFO - 2016-08-23 09:35:52 --> Model Class Initialized
INFO - 2016-08-23 09:35:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:35:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:35:52 --> Total execution time: 0.0540
INFO - 2016-08-23 09:36:22 --> Config Class Initialized
INFO - 2016-08-23 09:36:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:36:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:36:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:36:22 --> URI Class Initialized
INFO - 2016-08-23 09:36:22 --> Router Class Initialized
INFO - 2016-08-23 09:36:22 --> Output Class Initialized
INFO - 2016-08-23 09:36:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:36:22 --> Input Class Initialized
INFO - 2016-08-23 09:36:22 --> Language Class Initialized
INFO - 2016-08-23 09:36:22 --> Loader Class Initialized
INFO - 2016-08-23 09:36:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:36:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:36:22 --> Controller Class Initialized
INFO - 2016-08-23 09:36:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:36:22 --> Model Class Initialized
INFO - 2016-08-23 09:36:22 --> Model Class Initialized
INFO - 2016-08-23 09:36:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:36:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:36:22 --> Total execution time: 0.0573
INFO - 2016-08-23 09:36:52 --> Config Class Initialized
INFO - 2016-08-23 09:36:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:36:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:36:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:36:52 --> URI Class Initialized
INFO - 2016-08-23 09:36:52 --> Router Class Initialized
INFO - 2016-08-23 09:36:52 --> Output Class Initialized
INFO - 2016-08-23 09:36:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:36:52 --> Input Class Initialized
INFO - 2016-08-23 09:36:52 --> Language Class Initialized
INFO - 2016-08-23 09:36:52 --> Loader Class Initialized
INFO - 2016-08-23 09:36:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:36:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:36:52 --> Controller Class Initialized
INFO - 2016-08-23 09:36:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:36:52 --> Model Class Initialized
INFO - 2016-08-23 09:36:52 --> Model Class Initialized
INFO - 2016-08-23 09:36:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:36:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:36:52 --> Total execution time: 0.0547
INFO - 2016-08-23 09:37:22 --> Config Class Initialized
INFO - 2016-08-23 09:37:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:37:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:37:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:37:22 --> URI Class Initialized
INFO - 2016-08-23 09:37:22 --> Router Class Initialized
INFO - 2016-08-23 09:37:22 --> Output Class Initialized
INFO - 2016-08-23 09:37:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:37:22 --> Input Class Initialized
INFO - 2016-08-23 09:37:22 --> Language Class Initialized
INFO - 2016-08-23 09:37:22 --> Loader Class Initialized
INFO - 2016-08-23 09:37:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:37:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:37:22 --> Controller Class Initialized
INFO - 2016-08-23 09:37:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:37:22 --> Model Class Initialized
INFO - 2016-08-23 09:37:22 --> Model Class Initialized
INFO - 2016-08-23 09:37:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:37:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:37:22 --> Total execution time: 0.0524
INFO - 2016-08-23 09:37:52 --> Config Class Initialized
INFO - 2016-08-23 09:37:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:37:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:37:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:37:52 --> URI Class Initialized
INFO - 2016-08-23 09:37:52 --> Router Class Initialized
INFO - 2016-08-23 09:37:52 --> Output Class Initialized
INFO - 2016-08-23 09:37:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:37:52 --> Input Class Initialized
INFO - 2016-08-23 09:37:52 --> Language Class Initialized
INFO - 2016-08-23 09:37:52 --> Loader Class Initialized
INFO - 2016-08-23 09:37:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:37:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:37:52 --> Controller Class Initialized
INFO - 2016-08-23 09:37:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:37:52 --> Model Class Initialized
INFO - 2016-08-23 09:37:52 --> Model Class Initialized
INFO - 2016-08-23 09:37:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:37:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:37:52 --> Total execution time: 0.0519
INFO - 2016-08-23 09:38:22 --> Config Class Initialized
INFO - 2016-08-23 09:38:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:38:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:38:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:38:22 --> URI Class Initialized
INFO - 2016-08-23 09:38:22 --> Router Class Initialized
INFO - 2016-08-23 09:38:22 --> Output Class Initialized
INFO - 2016-08-23 09:38:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:38:22 --> Input Class Initialized
INFO - 2016-08-23 09:38:22 --> Language Class Initialized
INFO - 2016-08-23 09:38:22 --> Loader Class Initialized
INFO - 2016-08-23 09:38:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:38:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:38:22 --> Controller Class Initialized
INFO - 2016-08-23 09:38:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:38:22 --> Model Class Initialized
INFO - 2016-08-23 09:38:22 --> Model Class Initialized
INFO - 2016-08-23 09:38:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:38:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:38:22 --> Total execution time: 0.0556
INFO - 2016-08-23 09:38:52 --> Config Class Initialized
INFO - 2016-08-23 09:38:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:38:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:38:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:38:52 --> URI Class Initialized
INFO - 2016-08-23 09:38:52 --> Router Class Initialized
INFO - 2016-08-23 09:38:52 --> Output Class Initialized
INFO - 2016-08-23 09:38:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:38:52 --> Input Class Initialized
INFO - 2016-08-23 09:38:52 --> Language Class Initialized
INFO - 2016-08-23 09:38:52 --> Loader Class Initialized
INFO - 2016-08-23 09:38:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:38:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:38:52 --> Controller Class Initialized
INFO - 2016-08-23 09:38:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:38:52 --> Model Class Initialized
INFO - 2016-08-23 09:38:52 --> Model Class Initialized
INFO - 2016-08-23 09:38:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:38:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:38:52 --> Total execution time: 0.0553
INFO - 2016-08-23 09:39:22 --> Config Class Initialized
INFO - 2016-08-23 09:39:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:39:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:39:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:39:22 --> URI Class Initialized
INFO - 2016-08-23 09:39:22 --> Router Class Initialized
INFO - 2016-08-23 09:39:22 --> Output Class Initialized
INFO - 2016-08-23 09:39:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:39:22 --> Input Class Initialized
INFO - 2016-08-23 09:39:22 --> Language Class Initialized
INFO - 2016-08-23 09:39:22 --> Loader Class Initialized
INFO - 2016-08-23 09:39:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:39:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:39:22 --> Controller Class Initialized
INFO - 2016-08-23 09:39:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:39:22 --> Model Class Initialized
INFO - 2016-08-23 09:39:22 --> Model Class Initialized
INFO - 2016-08-23 09:39:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:39:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:39:22 --> Total execution time: 0.0590
INFO - 2016-08-23 09:39:52 --> Config Class Initialized
INFO - 2016-08-23 09:39:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:39:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:39:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:39:52 --> URI Class Initialized
INFO - 2016-08-23 09:39:52 --> Router Class Initialized
INFO - 2016-08-23 09:39:52 --> Output Class Initialized
INFO - 2016-08-23 09:39:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:39:52 --> Input Class Initialized
INFO - 2016-08-23 09:39:52 --> Language Class Initialized
INFO - 2016-08-23 09:39:52 --> Loader Class Initialized
INFO - 2016-08-23 09:39:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:39:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:39:52 --> Controller Class Initialized
INFO - 2016-08-23 09:39:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:39:52 --> Model Class Initialized
INFO - 2016-08-23 09:39:52 --> Model Class Initialized
INFO - 2016-08-23 09:39:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:39:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:39:52 --> Total execution time: 0.0543
INFO - 2016-08-23 09:40:22 --> Config Class Initialized
INFO - 2016-08-23 09:40:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:40:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:40:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:40:22 --> URI Class Initialized
INFO - 2016-08-23 09:40:22 --> Router Class Initialized
INFO - 2016-08-23 09:40:22 --> Output Class Initialized
INFO - 2016-08-23 09:40:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:40:22 --> Input Class Initialized
INFO - 2016-08-23 09:40:22 --> Language Class Initialized
INFO - 2016-08-23 09:40:22 --> Loader Class Initialized
INFO - 2016-08-23 09:40:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:40:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:40:22 --> Controller Class Initialized
INFO - 2016-08-23 09:40:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:40:22 --> Model Class Initialized
INFO - 2016-08-23 09:40:22 --> Model Class Initialized
INFO - 2016-08-23 09:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:40:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:40:22 --> Total execution time: 0.0591
INFO - 2016-08-23 09:40:52 --> Config Class Initialized
INFO - 2016-08-23 09:40:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:40:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:40:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:40:52 --> URI Class Initialized
INFO - 2016-08-23 09:40:52 --> Router Class Initialized
INFO - 2016-08-23 09:40:52 --> Output Class Initialized
INFO - 2016-08-23 09:40:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:40:52 --> Input Class Initialized
INFO - 2016-08-23 09:40:52 --> Language Class Initialized
INFO - 2016-08-23 09:40:52 --> Loader Class Initialized
INFO - 2016-08-23 09:40:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:40:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:40:52 --> Controller Class Initialized
INFO - 2016-08-23 09:40:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:40:52 --> Model Class Initialized
INFO - 2016-08-23 09:40:52 --> Model Class Initialized
INFO - 2016-08-23 09:40:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:40:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:40:52 --> Total execution time: 0.0581
INFO - 2016-08-23 09:41:22 --> Config Class Initialized
INFO - 2016-08-23 09:41:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:41:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:41:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:41:22 --> URI Class Initialized
INFO - 2016-08-23 09:41:22 --> Router Class Initialized
INFO - 2016-08-23 09:41:22 --> Output Class Initialized
INFO - 2016-08-23 09:41:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:41:22 --> Input Class Initialized
INFO - 2016-08-23 09:41:22 --> Language Class Initialized
INFO - 2016-08-23 09:41:22 --> Loader Class Initialized
INFO - 2016-08-23 09:41:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:41:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:41:22 --> Controller Class Initialized
INFO - 2016-08-23 09:41:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:41:22 --> Model Class Initialized
INFO - 2016-08-23 09:41:22 --> Model Class Initialized
INFO - 2016-08-23 09:41:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:41:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:41:22 --> Total execution time: 0.0693
INFO - 2016-08-23 09:41:52 --> Config Class Initialized
INFO - 2016-08-23 09:41:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:41:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:41:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:41:52 --> URI Class Initialized
INFO - 2016-08-23 09:41:52 --> Router Class Initialized
INFO - 2016-08-23 09:41:52 --> Output Class Initialized
INFO - 2016-08-23 09:41:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:41:52 --> Input Class Initialized
INFO - 2016-08-23 09:41:52 --> Language Class Initialized
INFO - 2016-08-23 09:41:52 --> Loader Class Initialized
INFO - 2016-08-23 09:41:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:41:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:41:52 --> Controller Class Initialized
INFO - 2016-08-23 09:41:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:41:52 --> Model Class Initialized
INFO - 2016-08-23 09:41:52 --> Model Class Initialized
INFO - 2016-08-23 09:41:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:41:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:41:52 --> Total execution time: 0.0504
INFO - 2016-08-23 09:42:22 --> Config Class Initialized
INFO - 2016-08-23 09:42:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:42:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:42:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:42:22 --> URI Class Initialized
INFO - 2016-08-23 09:42:22 --> Router Class Initialized
INFO - 2016-08-23 09:42:22 --> Output Class Initialized
INFO - 2016-08-23 09:42:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:42:22 --> Input Class Initialized
INFO - 2016-08-23 09:42:22 --> Language Class Initialized
INFO - 2016-08-23 09:42:22 --> Loader Class Initialized
INFO - 2016-08-23 09:42:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:42:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:42:22 --> Controller Class Initialized
INFO - 2016-08-23 09:42:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:42:22 --> Model Class Initialized
INFO - 2016-08-23 09:42:22 --> Model Class Initialized
INFO - 2016-08-23 09:42:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:42:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:42:22 --> Total execution time: 0.0542
INFO - 2016-08-23 09:42:52 --> Config Class Initialized
INFO - 2016-08-23 09:42:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:42:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:42:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:42:52 --> URI Class Initialized
INFO - 2016-08-23 09:42:52 --> Router Class Initialized
INFO - 2016-08-23 09:42:52 --> Output Class Initialized
INFO - 2016-08-23 09:42:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:42:52 --> Input Class Initialized
INFO - 2016-08-23 09:42:52 --> Language Class Initialized
INFO - 2016-08-23 09:42:52 --> Loader Class Initialized
INFO - 2016-08-23 09:42:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:42:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:42:52 --> Controller Class Initialized
INFO - 2016-08-23 09:42:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:42:52 --> Model Class Initialized
INFO - 2016-08-23 09:42:52 --> Model Class Initialized
INFO - 2016-08-23 09:42:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:42:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:42:52 --> Total execution time: 0.0539
INFO - 2016-08-23 09:43:22 --> Config Class Initialized
INFO - 2016-08-23 09:43:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:43:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:43:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:43:22 --> URI Class Initialized
INFO - 2016-08-23 09:43:22 --> Router Class Initialized
INFO - 2016-08-23 09:43:22 --> Output Class Initialized
INFO - 2016-08-23 09:43:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:43:22 --> Input Class Initialized
INFO - 2016-08-23 09:43:22 --> Language Class Initialized
INFO - 2016-08-23 09:43:22 --> Loader Class Initialized
INFO - 2016-08-23 09:43:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:43:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:43:22 --> Controller Class Initialized
INFO - 2016-08-23 09:43:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:43:22 --> Model Class Initialized
INFO - 2016-08-23 09:43:22 --> Model Class Initialized
INFO - 2016-08-23 09:43:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:43:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:43:22 --> Total execution time: 0.0689
INFO - 2016-08-23 09:43:52 --> Config Class Initialized
INFO - 2016-08-23 09:43:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:43:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:43:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:43:52 --> URI Class Initialized
INFO - 2016-08-23 09:43:52 --> Router Class Initialized
INFO - 2016-08-23 09:43:52 --> Output Class Initialized
INFO - 2016-08-23 09:43:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:43:52 --> Input Class Initialized
INFO - 2016-08-23 09:43:52 --> Language Class Initialized
INFO - 2016-08-23 09:43:52 --> Loader Class Initialized
INFO - 2016-08-23 09:43:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:43:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:43:52 --> Controller Class Initialized
INFO - 2016-08-23 09:43:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:43:52 --> Model Class Initialized
INFO - 2016-08-23 09:43:52 --> Model Class Initialized
INFO - 2016-08-23 09:43:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:43:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:43:52 --> Total execution time: 0.0546
INFO - 2016-08-23 09:44:22 --> Config Class Initialized
INFO - 2016-08-23 09:44:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:44:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:44:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:44:22 --> URI Class Initialized
INFO - 2016-08-23 09:44:22 --> Router Class Initialized
INFO - 2016-08-23 09:44:22 --> Output Class Initialized
INFO - 2016-08-23 09:44:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:44:22 --> Input Class Initialized
INFO - 2016-08-23 09:44:22 --> Language Class Initialized
INFO - 2016-08-23 09:44:22 --> Loader Class Initialized
INFO - 2016-08-23 09:44:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:44:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:44:22 --> Controller Class Initialized
INFO - 2016-08-23 09:44:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:44:22 --> Model Class Initialized
INFO - 2016-08-23 09:44:22 --> Model Class Initialized
INFO - 2016-08-23 09:44:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:44:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:44:22 --> Total execution time: 0.0544
INFO - 2016-08-23 09:44:52 --> Config Class Initialized
INFO - 2016-08-23 09:44:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:44:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:44:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:44:52 --> URI Class Initialized
INFO - 2016-08-23 09:44:52 --> Router Class Initialized
INFO - 2016-08-23 09:44:52 --> Output Class Initialized
INFO - 2016-08-23 09:44:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:44:52 --> Input Class Initialized
INFO - 2016-08-23 09:44:52 --> Language Class Initialized
INFO - 2016-08-23 09:44:52 --> Loader Class Initialized
INFO - 2016-08-23 09:44:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:44:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:44:52 --> Controller Class Initialized
INFO - 2016-08-23 09:44:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:44:52 --> Model Class Initialized
INFO - 2016-08-23 09:44:52 --> Model Class Initialized
INFO - 2016-08-23 09:44:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:44:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:44:52 --> Total execution time: 0.0499
INFO - 2016-08-23 09:45:22 --> Config Class Initialized
INFO - 2016-08-23 09:45:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:45:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:45:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:45:22 --> URI Class Initialized
INFO - 2016-08-23 09:45:22 --> Router Class Initialized
INFO - 2016-08-23 09:45:22 --> Output Class Initialized
INFO - 2016-08-23 09:45:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:45:22 --> Input Class Initialized
INFO - 2016-08-23 09:45:22 --> Language Class Initialized
INFO - 2016-08-23 09:45:22 --> Loader Class Initialized
INFO - 2016-08-23 09:45:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:45:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:45:22 --> Controller Class Initialized
INFO - 2016-08-23 09:45:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:45:22 --> Model Class Initialized
INFO - 2016-08-23 09:45:22 --> Model Class Initialized
INFO - 2016-08-23 09:45:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:45:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:45:22 --> Total execution time: 0.0649
INFO - 2016-08-23 09:45:52 --> Config Class Initialized
INFO - 2016-08-23 09:45:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:45:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:45:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:45:52 --> URI Class Initialized
INFO - 2016-08-23 09:45:52 --> Router Class Initialized
INFO - 2016-08-23 09:45:52 --> Output Class Initialized
INFO - 2016-08-23 09:45:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:45:52 --> Input Class Initialized
INFO - 2016-08-23 09:45:52 --> Language Class Initialized
INFO - 2016-08-23 09:45:52 --> Loader Class Initialized
INFO - 2016-08-23 09:45:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:45:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:45:52 --> Controller Class Initialized
INFO - 2016-08-23 09:45:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:45:52 --> Model Class Initialized
INFO - 2016-08-23 09:45:52 --> Model Class Initialized
INFO - 2016-08-23 09:45:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:45:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:45:52 --> Total execution time: 0.0523
INFO - 2016-08-23 09:46:22 --> Config Class Initialized
INFO - 2016-08-23 09:46:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:46:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:46:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:46:22 --> URI Class Initialized
INFO - 2016-08-23 09:46:22 --> Router Class Initialized
INFO - 2016-08-23 09:46:22 --> Output Class Initialized
INFO - 2016-08-23 09:46:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:46:22 --> Input Class Initialized
INFO - 2016-08-23 09:46:22 --> Language Class Initialized
INFO - 2016-08-23 09:46:22 --> Loader Class Initialized
INFO - 2016-08-23 09:46:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:46:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:46:22 --> Controller Class Initialized
INFO - 2016-08-23 09:46:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:46:22 --> Model Class Initialized
INFO - 2016-08-23 09:46:22 --> Model Class Initialized
INFO - 2016-08-23 09:46:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:46:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:46:22 --> Total execution time: 0.0528
INFO - 2016-08-23 09:46:52 --> Config Class Initialized
INFO - 2016-08-23 09:46:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:46:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:46:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:46:52 --> URI Class Initialized
INFO - 2016-08-23 09:46:52 --> Router Class Initialized
INFO - 2016-08-23 09:46:52 --> Output Class Initialized
INFO - 2016-08-23 09:46:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:46:52 --> Input Class Initialized
INFO - 2016-08-23 09:46:52 --> Language Class Initialized
INFO - 2016-08-23 09:46:52 --> Loader Class Initialized
INFO - 2016-08-23 09:46:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:46:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:46:52 --> Controller Class Initialized
INFO - 2016-08-23 09:46:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:46:52 --> Model Class Initialized
INFO - 2016-08-23 09:46:52 --> Model Class Initialized
INFO - 2016-08-23 09:46:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:46:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:46:52 --> Total execution time: 0.0577
INFO - 2016-08-23 09:47:22 --> Config Class Initialized
INFO - 2016-08-23 09:47:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:47:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:47:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:47:22 --> URI Class Initialized
INFO - 2016-08-23 09:47:22 --> Router Class Initialized
INFO - 2016-08-23 09:47:22 --> Output Class Initialized
INFO - 2016-08-23 09:47:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:47:22 --> Input Class Initialized
INFO - 2016-08-23 09:47:22 --> Language Class Initialized
INFO - 2016-08-23 09:47:22 --> Loader Class Initialized
INFO - 2016-08-23 09:47:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:47:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:47:22 --> Controller Class Initialized
INFO - 2016-08-23 09:47:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:47:22 --> Model Class Initialized
INFO - 2016-08-23 09:47:22 --> Model Class Initialized
INFO - 2016-08-23 09:47:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:47:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:47:22 --> Total execution time: 0.0556
INFO - 2016-08-23 09:47:52 --> Config Class Initialized
INFO - 2016-08-23 09:47:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:47:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:47:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:47:52 --> URI Class Initialized
INFO - 2016-08-23 09:47:52 --> Router Class Initialized
INFO - 2016-08-23 09:47:52 --> Output Class Initialized
INFO - 2016-08-23 09:47:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:47:52 --> Input Class Initialized
INFO - 2016-08-23 09:47:52 --> Language Class Initialized
INFO - 2016-08-23 09:47:52 --> Loader Class Initialized
INFO - 2016-08-23 09:47:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:47:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:47:52 --> Controller Class Initialized
INFO - 2016-08-23 09:47:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:47:52 --> Model Class Initialized
INFO - 2016-08-23 09:47:52 --> Model Class Initialized
INFO - 2016-08-23 09:47:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:47:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:47:52 --> Total execution time: 0.0652
INFO - 2016-08-23 09:48:22 --> Config Class Initialized
INFO - 2016-08-23 09:48:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:48:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:48:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:48:22 --> URI Class Initialized
INFO - 2016-08-23 09:48:22 --> Router Class Initialized
INFO - 2016-08-23 09:48:22 --> Output Class Initialized
INFO - 2016-08-23 09:48:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:48:22 --> Input Class Initialized
INFO - 2016-08-23 09:48:22 --> Language Class Initialized
INFO - 2016-08-23 09:48:22 --> Loader Class Initialized
INFO - 2016-08-23 09:48:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:48:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:48:22 --> Controller Class Initialized
INFO - 2016-08-23 09:48:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:48:22 --> Model Class Initialized
INFO - 2016-08-23 09:48:22 --> Model Class Initialized
INFO - 2016-08-23 09:48:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:48:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:48:22 --> Total execution time: 0.0520
INFO - 2016-08-23 09:48:52 --> Config Class Initialized
INFO - 2016-08-23 09:48:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:48:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:48:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:48:52 --> URI Class Initialized
INFO - 2016-08-23 09:48:52 --> Router Class Initialized
INFO - 2016-08-23 09:48:52 --> Output Class Initialized
INFO - 2016-08-23 09:48:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:48:52 --> Input Class Initialized
INFO - 2016-08-23 09:48:52 --> Language Class Initialized
INFO - 2016-08-23 09:48:52 --> Loader Class Initialized
INFO - 2016-08-23 09:48:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:48:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:48:52 --> Controller Class Initialized
INFO - 2016-08-23 09:48:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:48:52 --> Model Class Initialized
INFO - 2016-08-23 09:48:52 --> Model Class Initialized
INFO - 2016-08-23 09:48:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:48:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:48:52 --> Total execution time: 0.0543
INFO - 2016-08-23 09:49:22 --> Config Class Initialized
INFO - 2016-08-23 09:49:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:49:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:49:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:49:22 --> URI Class Initialized
INFO - 2016-08-23 09:49:22 --> Router Class Initialized
INFO - 2016-08-23 09:49:22 --> Output Class Initialized
INFO - 2016-08-23 09:49:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:49:22 --> Input Class Initialized
INFO - 2016-08-23 09:49:22 --> Language Class Initialized
INFO - 2016-08-23 09:49:22 --> Loader Class Initialized
INFO - 2016-08-23 09:49:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:49:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:49:22 --> Controller Class Initialized
INFO - 2016-08-23 09:49:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:49:22 --> Model Class Initialized
INFO - 2016-08-23 09:49:22 --> Model Class Initialized
INFO - 2016-08-23 09:49:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:49:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:49:22 --> Total execution time: 0.0534
INFO - 2016-08-23 09:49:52 --> Config Class Initialized
INFO - 2016-08-23 09:49:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:49:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:49:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:49:52 --> URI Class Initialized
INFO - 2016-08-23 09:49:52 --> Router Class Initialized
INFO - 2016-08-23 09:49:52 --> Output Class Initialized
INFO - 2016-08-23 09:49:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:49:52 --> Input Class Initialized
INFO - 2016-08-23 09:49:52 --> Language Class Initialized
INFO - 2016-08-23 09:49:52 --> Loader Class Initialized
INFO - 2016-08-23 09:49:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:49:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:49:52 --> Controller Class Initialized
INFO - 2016-08-23 09:49:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:49:52 --> Model Class Initialized
INFO - 2016-08-23 09:49:52 --> Model Class Initialized
INFO - 2016-08-23 09:49:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:49:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:49:52 --> Total execution time: 0.0517
INFO - 2016-08-23 09:50:22 --> Config Class Initialized
INFO - 2016-08-23 09:50:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:50:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:50:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:50:22 --> URI Class Initialized
INFO - 2016-08-23 09:50:22 --> Router Class Initialized
INFO - 2016-08-23 09:50:22 --> Output Class Initialized
INFO - 2016-08-23 09:50:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:50:22 --> Input Class Initialized
INFO - 2016-08-23 09:50:22 --> Language Class Initialized
INFO - 2016-08-23 09:50:22 --> Loader Class Initialized
INFO - 2016-08-23 09:50:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:50:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:50:22 --> Controller Class Initialized
INFO - 2016-08-23 09:50:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:50:22 --> Model Class Initialized
INFO - 2016-08-23 09:50:22 --> Model Class Initialized
INFO - 2016-08-23 09:50:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:50:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:50:22 --> Total execution time: 0.0601
INFO - 2016-08-23 09:50:52 --> Config Class Initialized
INFO - 2016-08-23 09:50:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:50:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:50:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:50:52 --> URI Class Initialized
INFO - 2016-08-23 09:50:52 --> Router Class Initialized
INFO - 2016-08-23 09:50:52 --> Output Class Initialized
INFO - 2016-08-23 09:50:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:50:52 --> Input Class Initialized
INFO - 2016-08-23 09:50:52 --> Language Class Initialized
INFO - 2016-08-23 09:50:52 --> Loader Class Initialized
INFO - 2016-08-23 09:50:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:50:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:50:52 --> Controller Class Initialized
INFO - 2016-08-23 09:50:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:50:52 --> Model Class Initialized
INFO - 2016-08-23 09:50:52 --> Model Class Initialized
INFO - 2016-08-23 09:50:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:50:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:50:52 --> Total execution time: 0.0505
INFO - 2016-08-23 09:51:22 --> Config Class Initialized
INFO - 2016-08-23 09:51:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:51:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:51:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:51:22 --> URI Class Initialized
INFO - 2016-08-23 09:51:22 --> Router Class Initialized
INFO - 2016-08-23 09:51:22 --> Output Class Initialized
INFO - 2016-08-23 09:51:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:51:22 --> Input Class Initialized
INFO - 2016-08-23 09:51:22 --> Language Class Initialized
INFO - 2016-08-23 09:51:22 --> Loader Class Initialized
INFO - 2016-08-23 09:51:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:51:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:51:22 --> Controller Class Initialized
INFO - 2016-08-23 09:51:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:51:22 --> Model Class Initialized
INFO - 2016-08-23 09:51:22 --> Model Class Initialized
INFO - 2016-08-23 09:51:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:51:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:51:22 --> Total execution time: 0.0516
INFO - 2016-08-23 09:51:52 --> Config Class Initialized
INFO - 2016-08-23 09:51:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:51:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:51:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:51:52 --> URI Class Initialized
INFO - 2016-08-23 09:51:52 --> Router Class Initialized
INFO - 2016-08-23 09:51:52 --> Output Class Initialized
INFO - 2016-08-23 09:51:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:51:52 --> Input Class Initialized
INFO - 2016-08-23 09:51:52 --> Language Class Initialized
INFO - 2016-08-23 09:51:52 --> Loader Class Initialized
INFO - 2016-08-23 09:51:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:51:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:51:52 --> Controller Class Initialized
INFO - 2016-08-23 09:51:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:51:52 --> Model Class Initialized
INFO - 2016-08-23 09:51:52 --> Model Class Initialized
INFO - 2016-08-23 09:51:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:51:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:51:52 --> Total execution time: 0.0520
INFO - 2016-08-23 09:52:22 --> Config Class Initialized
INFO - 2016-08-23 09:52:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:52:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:52:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:52:22 --> URI Class Initialized
INFO - 2016-08-23 09:52:22 --> Router Class Initialized
INFO - 2016-08-23 09:52:22 --> Output Class Initialized
INFO - 2016-08-23 09:52:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:52:22 --> Input Class Initialized
INFO - 2016-08-23 09:52:22 --> Language Class Initialized
INFO - 2016-08-23 09:52:22 --> Loader Class Initialized
INFO - 2016-08-23 09:52:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:52:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:52:22 --> Controller Class Initialized
INFO - 2016-08-23 09:52:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:52:22 --> Model Class Initialized
INFO - 2016-08-23 09:52:22 --> Model Class Initialized
INFO - 2016-08-23 09:52:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:52:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:52:22 --> Total execution time: 0.0510
INFO - 2016-08-23 09:52:52 --> Config Class Initialized
INFO - 2016-08-23 09:52:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:52:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:52:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:52:52 --> URI Class Initialized
INFO - 2016-08-23 09:52:52 --> Router Class Initialized
INFO - 2016-08-23 09:52:52 --> Output Class Initialized
INFO - 2016-08-23 09:52:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:52:52 --> Input Class Initialized
INFO - 2016-08-23 09:52:52 --> Language Class Initialized
INFO - 2016-08-23 09:52:52 --> Loader Class Initialized
INFO - 2016-08-23 09:52:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:52:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:52:52 --> Controller Class Initialized
INFO - 2016-08-23 09:52:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:52:52 --> Model Class Initialized
INFO - 2016-08-23 09:52:52 --> Model Class Initialized
INFO - 2016-08-23 09:52:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:52:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:52:52 --> Total execution time: 0.0634
INFO - 2016-08-23 09:53:22 --> Config Class Initialized
INFO - 2016-08-23 09:53:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:53:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:53:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:53:22 --> URI Class Initialized
INFO - 2016-08-23 09:53:22 --> Router Class Initialized
INFO - 2016-08-23 09:53:22 --> Output Class Initialized
INFO - 2016-08-23 09:53:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:53:22 --> Input Class Initialized
INFO - 2016-08-23 09:53:22 --> Language Class Initialized
INFO - 2016-08-23 09:53:22 --> Loader Class Initialized
INFO - 2016-08-23 09:53:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:53:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:53:22 --> Controller Class Initialized
INFO - 2016-08-23 09:53:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:53:22 --> Model Class Initialized
INFO - 2016-08-23 09:53:22 --> Model Class Initialized
INFO - 2016-08-23 09:53:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:53:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:53:22 --> Total execution time: 0.0547
INFO - 2016-08-23 09:53:52 --> Config Class Initialized
INFO - 2016-08-23 09:53:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:53:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:53:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:53:52 --> URI Class Initialized
INFO - 2016-08-23 09:53:52 --> Router Class Initialized
INFO - 2016-08-23 09:53:52 --> Output Class Initialized
INFO - 2016-08-23 09:53:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:53:52 --> Input Class Initialized
INFO - 2016-08-23 09:53:52 --> Language Class Initialized
INFO - 2016-08-23 09:53:52 --> Loader Class Initialized
INFO - 2016-08-23 09:53:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:53:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:53:52 --> Controller Class Initialized
INFO - 2016-08-23 09:53:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:53:52 --> Model Class Initialized
INFO - 2016-08-23 09:53:52 --> Model Class Initialized
INFO - 2016-08-23 09:53:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:53:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:53:52 --> Total execution time: 0.0519
INFO - 2016-08-23 09:54:22 --> Config Class Initialized
INFO - 2016-08-23 09:54:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:54:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:54:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:54:22 --> URI Class Initialized
INFO - 2016-08-23 09:54:22 --> Router Class Initialized
INFO - 2016-08-23 09:54:22 --> Output Class Initialized
INFO - 2016-08-23 09:54:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:54:22 --> Input Class Initialized
INFO - 2016-08-23 09:54:22 --> Language Class Initialized
INFO - 2016-08-23 09:54:22 --> Loader Class Initialized
INFO - 2016-08-23 09:54:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:54:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:54:22 --> Controller Class Initialized
INFO - 2016-08-23 09:54:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:54:22 --> Model Class Initialized
INFO - 2016-08-23 09:54:22 --> Model Class Initialized
INFO - 2016-08-23 09:54:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:54:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:54:22 --> Total execution time: 0.0524
INFO - 2016-08-23 09:54:52 --> Config Class Initialized
INFO - 2016-08-23 09:54:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:54:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:54:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:54:52 --> URI Class Initialized
INFO - 2016-08-23 09:54:52 --> Router Class Initialized
INFO - 2016-08-23 09:54:52 --> Output Class Initialized
INFO - 2016-08-23 09:54:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:54:52 --> Input Class Initialized
INFO - 2016-08-23 09:54:52 --> Language Class Initialized
INFO - 2016-08-23 09:54:52 --> Loader Class Initialized
INFO - 2016-08-23 09:54:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:54:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:54:52 --> Controller Class Initialized
INFO - 2016-08-23 09:54:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:54:52 --> Model Class Initialized
INFO - 2016-08-23 09:54:52 --> Model Class Initialized
INFO - 2016-08-23 09:54:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:54:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:54:52 --> Total execution time: 0.0514
INFO - 2016-08-23 09:55:22 --> Config Class Initialized
INFO - 2016-08-23 09:55:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:55:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:55:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:55:22 --> URI Class Initialized
INFO - 2016-08-23 09:55:22 --> Router Class Initialized
INFO - 2016-08-23 09:55:22 --> Output Class Initialized
INFO - 2016-08-23 09:55:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:55:22 --> Input Class Initialized
INFO - 2016-08-23 09:55:22 --> Language Class Initialized
INFO - 2016-08-23 09:55:22 --> Loader Class Initialized
INFO - 2016-08-23 09:55:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:55:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:55:22 --> Controller Class Initialized
INFO - 2016-08-23 09:55:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:55:22 --> Model Class Initialized
INFO - 2016-08-23 09:55:22 --> Model Class Initialized
INFO - 2016-08-23 09:55:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:55:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:55:22 --> Total execution time: 0.0518
INFO - 2016-08-23 09:55:52 --> Config Class Initialized
INFO - 2016-08-23 09:55:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:55:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:55:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:55:52 --> URI Class Initialized
INFO - 2016-08-23 09:55:52 --> Router Class Initialized
INFO - 2016-08-23 09:55:52 --> Output Class Initialized
INFO - 2016-08-23 09:55:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:55:52 --> Input Class Initialized
INFO - 2016-08-23 09:55:52 --> Language Class Initialized
INFO - 2016-08-23 09:55:52 --> Loader Class Initialized
INFO - 2016-08-23 09:55:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:55:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:55:52 --> Controller Class Initialized
INFO - 2016-08-23 09:55:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:55:52 --> Model Class Initialized
INFO - 2016-08-23 09:55:52 --> Model Class Initialized
INFO - 2016-08-23 09:55:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:55:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:55:52 --> Total execution time: 0.0498
INFO - 2016-08-23 09:56:22 --> Config Class Initialized
INFO - 2016-08-23 09:56:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:56:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:56:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:56:22 --> URI Class Initialized
INFO - 2016-08-23 09:56:22 --> Router Class Initialized
INFO - 2016-08-23 09:56:22 --> Output Class Initialized
INFO - 2016-08-23 09:56:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:56:22 --> Input Class Initialized
INFO - 2016-08-23 09:56:22 --> Language Class Initialized
INFO - 2016-08-23 09:56:22 --> Loader Class Initialized
INFO - 2016-08-23 09:56:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:56:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:56:22 --> Controller Class Initialized
INFO - 2016-08-23 09:56:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:56:22 --> Model Class Initialized
INFO - 2016-08-23 09:56:22 --> Model Class Initialized
INFO - 2016-08-23 09:56:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:56:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:56:22 --> Total execution time: 0.0543
INFO - 2016-08-23 09:56:52 --> Config Class Initialized
INFO - 2016-08-23 09:56:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:56:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:56:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:56:52 --> URI Class Initialized
INFO - 2016-08-23 09:56:52 --> Router Class Initialized
INFO - 2016-08-23 09:56:52 --> Output Class Initialized
INFO - 2016-08-23 09:56:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:56:52 --> Input Class Initialized
INFO - 2016-08-23 09:56:52 --> Language Class Initialized
INFO - 2016-08-23 09:56:52 --> Loader Class Initialized
INFO - 2016-08-23 09:56:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:56:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:56:52 --> Controller Class Initialized
INFO - 2016-08-23 09:56:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:56:52 --> Model Class Initialized
INFO - 2016-08-23 09:56:52 --> Model Class Initialized
INFO - 2016-08-23 09:56:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:56:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:56:52 --> Total execution time: 0.0532
INFO - 2016-08-23 09:57:22 --> Config Class Initialized
INFO - 2016-08-23 09:57:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:57:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:57:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:57:22 --> URI Class Initialized
INFO - 2016-08-23 09:57:22 --> Router Class Initialized
INFO - 2016-08-23 09:57:22 --> Output Class Initialized
INFO - 2016-08-23 09:57:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:57:22 --> Input Class Initialized
INFO - 2016-08-23 09:57:22 --> Language Class Initialized
INFO - 2016-08-23 09:57:22 --> Loader Class Initialized
INFO - 2016-08-23 09:57:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:57:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:57:22 --> Controller Class Initialized
INFO - 2016-08-23 09:57:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:57:22 --> Model Class Initialized
INFO - 2016-08-23 09:57:22 --> Model Class Initialized
INFO - 2016-08-23 09:57:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:57:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:57:22 --> Total execution time: 0.0509
INFO - 2016-08-23 09:57:52 --> Config Class Initialized
INFO - 2016-08-23 09:57:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:57:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:57:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:57:52 --> URI Class Initialized
INFO - 2016-08-23 09:57:52 --> Router Class Initialized
INFO - 2016-08-23 09:57:52 --> Output Class Initialized
INFO - 2016-08-23 09:57:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:57:52 --> Input Class Initialized
INFO - 2016-08-23 09:57:52 --> Language Class Initialized
INFO - 2016-08-23 09:57:52 --> Loader Class Initialized
INFO - 2016-08-23 09:57:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:57:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:57:52 --> Controller Class Initialized
INFO - 2016-08-23 09:57:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:57:52 --> Model Class Initialized
INFO - 2016-08-23 09:57:52 --> Model Class Initialized
INFO - 2016-08-23 09:57:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:57:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:57:52 --> Total execution time: 0.0506
INFO - 2016-08-23 09:58:22 --> Config Class Initialized
INFO - 2016-08-23 09:58:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:58:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:58:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:58:22 --> URI Class Initialized
INFO - 2016-08-23 09:58:22 --> Router Class Initialized
INFO - 2016-08-23 09:58:22 --> Output Class Initialized
INFO - 2016-08-23 09:58:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:58:22 --> Input Class Initialized
INFO - 2016-08-23 09:58:22 --> Language Class Initialized
INFO - 2016-08-23 09:58:22 --> Loader Class Initialized
INFO - 2016-08-23 09:58:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:58:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:58:22 --> Controller Class Initialized
INFO - 2016-08-23 09:58:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:58:22 --> Model Class Initialized
INFO - 2016-08-23 09:58:22 --> Model Class Initialized
INFO - 2016-08-23 09:58:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:58:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:58:22 --> Total execution time: 0.0502
INFO - 2016-08-23 09:58:52 --> Config Class Initialized
INFO - 2016-08-23 09:58:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:58:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:58:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:58:52 --> URI Class Initialized
INFO - 2016-08-23 09:58:52 --> Router Class Initialized
INFO - 2016-08-23 09:58:52 --> Output Class Initialized
INFO - 2016-08-23 09:58:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:58:52 --> Input Class Initialized
INFO - 2016-08-23 09:58:52 --> Language Class Initialized
INFO - 2016-08-23 09:58:52 --> Loader Class Initialized
INFO - 2016-08-23 09:58:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:58:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:58:52 --> Controller Class Initialized
INFO - 2016-08-23 09:58:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:58:52 --> Model Class Initialized
INFO - 2016-08-23 09:58:52 --> Model Class Initialized
INFO - 2016-08-23 09:58:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:58:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:58:52 --> Total execution time: 0.0507
INFO - 2016-08-23 09:59:22 --> Config Class Initialized
INFO - 2016-08-23 09:59:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:59:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:59:22 --> Utf8 Class Initialized
INFO - 2016-08-23 09:59:22 --> URI Class Initialized
INFO - 2016-08-23 09:59:22 --> Router Class Initialized
INFO - 2016-08-23 09:59:22 --> Output Class Initialized
INFO - 2016-08-23 09:59:22 --> Security Class Initialized
DEBUG - 2016-08-23 09:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:59:22 --> Input Class Initialized
INFO - 2016-08-23 09:59:22 --> Language Class Initialized
INFO - 2016-08-23 09:59:22 --> Loader Class Initialized
INFO - 2016-08-23 09:59:22 --> Helper loaded: url_helper
INFO - 2016-08-23 09:59:22 --> Helper loaded: language_helper
INFO - 2016-08-23 09:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:59:22 --> Controller Class Initialized
INFO - 2016-08-23 09:59:22 --> Database Driver Class Initialized
INFO - 2016-08-23 09:59:22 --> Model Class Initialized
INFO - 2016-08-23 09:59:22 --> Model Class Initialized
INFO - 2016-08-23 09:59:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:59:22 --> Final output sent to browser
DEBUG - 2016-08-23 09:59:22 --> Total execution time: 0.0727
INFO - 2016-08-23 09:59:52 --> Config Class Initialized
INFO - 2016-08-23 09:59:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:59:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:59:52 --> Utf8 Class Initialized
INFO - 2016-08-23 09:59:52 --> URI Class Initialized
INFO - 2016-08-23 09:59:52 --> Router Class Initialized
INFO - 2016-08-23 09:59:52 --> Output Class Initialized
INFO - 2016-08-23 09:59:52 --> Security Class Initialized
DEBUG - 2016-08-23 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:59:52 --> Input Class Initialized
INFO - 2016-08-23 09:59:52 --> Language Class Initialized
INFO - 2016-08-23 09:59:52 --> Loader Class Initialized
INFO - 2016-08-23 09:59:52 --> Helper loaded: url_helper
INFO - 2016-08-23 09:59:52 --> Helper loaded: language_helper
INFO - 2016-08-23 09:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:59:52 --> Controller Class Initialized
INFO - 2016-08-23 09:59:52 --> Database Driver Class Initialized
INFO - 2016-08-23 09:59:52 --> Model Class Initialized
INFO - 2016-08-23 09:59:52 --> Model Class Initialized
INFO - 2016-08-23 09:59:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 09:59:52 --> Final output sent to browser
DEBUG - 2016-08-23 09:59:52 --> Total execution time: 0.0529
INFO - 2016-08-23 10:00:22 --> Config Class Initialized
INFO - 2016-08-23 10:00:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:00:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:00:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:00:22 --> URI Class Initialized
INFO - 2016-08-23 10:00:22 --> Router Class Initialized
INFO - 2016-08-23 10:00:22 --> Output Class Initialized
INFO - 2016-08-23 10:00:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:00:22 --> Input Class Initialized
INFO - 2016-08-23 10:00:22 --> Language Class Initialized
INFO - 2016-08-23 10:00:22 --> Loader Class Initialized
INFO - 2016-08-23 10:00:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:00:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:00:22 --> Controller Class Initialized
INFO - 2016-08-23 10:00:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:00:22 --> Model Class Initialized
INFO - 2016-08-23 10:00:22 --> Model Class Initialized
INFO - 2016-08-23 10:00:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:00:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:00:22 --> Total execution time: 0.0548
INFO - 2016-08-23 10:00:52 --> Config Class Initialized
INFO - 2016-08-23 10:00:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:00:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:00:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:00:52 --> URI Class Initialized
INFO - 2016-08-23 10:00:52 --> Router Class Initialized
INFO - 2016-08-23 10:00:52 --> Output Class Initialized
INFO - 2016-08-23 10:00:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:00:52 --> Input Class Initialized
INFO - 2016-08-23 10:00:52 --> Language Class Initialized
INFO - 2016-08-23 10:00:52 --> Loader Class Initialized
INFO - 2016-08-23 10:00:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:00:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:00:52 --> Controller Class Initialized
INFO - 2016-08-23 10:00:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:00:52 --> Model Class Initialized
INFO - 2016-08-23 10:00:52 --> Model Class Initialized
INFO - 2016-08-23 10:00:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:00:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:00:52 --> Total execution time: 0.0525
INFO - 2016-08-23 10:01:22 --> Config Class Initialized
INFO - 2016-08-23 10:01:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:01:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:01:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:01:22 --> URI Class Initialized
INFO - 2016-08-23 10:01:22 --> Router Class Initialized
INFO - 2016-08-23 10:01:22 --> Output Class Initialized
INFO - 2016-08-23 10:01:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:01:22 --> Input Class Initialized
INFO - 2016-08-23 10:01:22 --> Language Class Initialized
INFO - 2016-08-23 10:01:22 --> Loader Class Initialized
INFO - 2016-08-23 10:01:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:01:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:01:22 --> Controller Class Initialized
INFO - 2016-08-23 10:01:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:01:22 --> Model Class Initialized
INFO - 2016-08-23 10:01:22 --> Model Class Initialized
INFO - 2016-08-23 10:01:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:01:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:01:22 --> Total execution time: 0.0507
INFO - 2016-08-23 10:01:52 --> Config Class Initialized
INFO - 2016-08-23 10:01:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:01:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:01:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:01:52 --> URI Class Initialized
INFO - 2016-08-23 10:01:52 --> Router Class Initialized
INFO - 2016-08-23 10:01:52 --> Output Class Initialized
INFO - 2016-08-23 10:01:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:01:52 --> Input Class Initialized
INFO - 2016-08-23 10:01:52 --> Language Class Initialized
INFO - 2016-08-23 10:01:52 --> Loader Class Initialized
INFO - 2016-08-23 10:01:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:01:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:01:52 --> Controller Class Initialized
INFO - 2016-08-23 10:01:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:01:52 --> Model Class Initialized
INFO - 2016-08-23 10:01:52 --> Model Class Initialized
INFO - 2016-08-23 10:01:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:01:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:01:52 --> Total execution time: 0.0715
INFO - 2016-08-23 10:02:22 --> Config Class Initialized
INFO - 2016-08-23 10:02:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:02:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:02:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:02:22 --> URI Class Initialized
INFO - 2016-08-23 10:02:22 --> Router Class Initialized
INFO - 2016-08-23 10:02:22 --> Output Class Initialized
INFO - 2016-08-23 10:02:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:02:22 --> Input Class Initialized
INFO - 2016-08-23 10:02:22 --> Language Class Initialized
INFO - 2016-08-23 10:02:22 --> Loader Class Initialized
INFO - 2016-08-23 10:02:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:02:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:02:22 --> Controller Class Initialized
INFO - 2016-08-23 10:02:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:02:22 --> Model Class Initialized
INFO - 2016-08-23 10:02:22 --> Model Class Initialized
INFO - 2016-08-23 10:02:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:02:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:02:22 --> Total execution time: 0.0801
INFO - 2016-08-23 10:02:52 --> Config Class Initialized
INFO - 2016-08-23 10:02:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:02:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:02:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:02:52 --> URI Class Initialized
INFO - 2016-08-23 10:02:52 --> Router Class Initialized
INFO - 2016-08-23 10:02:52 --> Output Class Initialized
INFO - 2016-08-23 10:02:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:02:52 --> Input Class Initialized
INFO - 2016-08-23 10:02:52 --> Language Class Initialized
INFO - 2016-08-23 10:02:52 --> Loader Class Initialized
INFO - 2016-08-23 10:02:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:02:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:02:52 --> Controller Class Initialized
INFO - 2016-08-23 10:02:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:02:52 --> Model Class Initialized
INFO - 2016-08-23 10:02:52 --> Model Class Initialized
INFO - 2016-08-23 10:02:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:02:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:02:52 --> Total execution time: 0.0526
INFO - 2016-08-23 10:03:22 --> Config Class Initialized
INFO - 2016-08-23 10:03:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:03:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:03:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:03:22 --> URI Class Initialized
INFO - 2016-08-23 10:03:22 --> Router Class Initialized
INFO - 2016-08-23 10:03:22 --> Output Class Initialized
INFO - 2016-08-23 10:03:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:03:22 --> Input Class Initialized
INFO - 2016-08-23 10:03:22 --> Language Class Initialized
INFO - 2016-08-23 10:03:22 --> Loader Class Initialized
INFO - 2016-08-23 10:03:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:03:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:03:22 --> Controller Class Initialized
INFO - 2016-08-23 10:03:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:03:22 --> Model Class Initialized
INFO - 2016-08-23 10:03:22 --> Model Class Initialized
INFO - 2016-08-23 10:03:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:03:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:03:22 --> Total execution time: 0.0570
INFO - 2016-08-23 10:03:52 --> Config Class Initialized
INFO - 2016-08-23 10:03:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:03:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:03:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:03:52 --> URI Class Initialized
INFO - 2016-08-23 10:03:52 --> Router Class Initialized
INFO - 2016-08-23 10:03:52 --> Output Class Initialized
INFO - 2016-08-23 10:03:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:03:52 --> Input Class Initialized
INFO - 2016-08-23 10:03:52 --> Language Class Initialized
INFO - 2016-08-23 10:03:52 --> Loader Class Initialized
INFO - 2016-08-23 10:03:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:03:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:03:52 --> Controller Class Initialized
INFO - 2016-08-23 10:03:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:03:52 --> Model Class Initialized
INFO - 2016-08-23 10:03:52 --> Model Class Initialized
INFO - 2016-08-23 10:03:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:03:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:03:52 --> Total execution time: 0.0611
INFO - 2016-08-23 10:04:22 --> Config Class Initialized
INFO - 2016-08-23 10:04:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:04:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:04:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:04:22 --> URI Class Initialized
INFO - 2016-08-23 10:04:22 --> Router Class Initialized
INFO - 2016-08-23 10:04:22 --> Output Class Initialized
INFO - 2016-08-23 10:04:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:04:22 --> Input Class Initialized
INFO - 2016-08-23 10:04:22 --> Language Class Initialized
INFO - 2016-08-23 10:04:22 --> Loader Class Initialized
INFO - 2016-08-23 10:04:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:04:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:04:22 --> Controller Class Initialized
INFO - 2016-08-23 10:04:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:04:22 --> Model Class Initialized
INFO - 2016-08-23 10:04:22 --> Model Class Initialized
INFO - 2016-08-23 10:04:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:04:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:04:22 --> Total execution time: 0.0669
INFO - 2016-08-23 10:04:52 --> Config Class Initialized
INFO - 2016-08-23 10:04:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:04:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:04:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:04:52 --> URI Class Initialized
INFO - 2016-08-23 10:04:52 --> Router Class Initialized
INFO - 2016-08-23 10:04:52 --> Output Class Initialized
INFO - 2016-08-23 10:04:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:04:52 --> Input Class Initialized
INFO - 2016-08-23 10:04:52 --> Language Class Initialized
INFO - 2016-08-23 10:04:52 --> Loader Class Initialized
INFO - 2016-08-23 10:04:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:04:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:04:52 --> Controller Class Initialized
INFO - 2016-08-23 10:04:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:04:52 --> Model Class Initialized
INFO - 2016-08-23 10:04:52 --> Model Class Initialized
INFO - 2016-08-23 10:04:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:04:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:04:52 --> Total execution time: 0.0625
INFO - 2016-08-23 10:05:22 --> Config Class Initialized
INFO - 2016-08-23 10:05:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:05:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:05:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:05:22 --> URI Class Initialized
INFO - 2016-08-23 10:05:22 --> Router Class Initialized
INFO - 2016-08-23 10:05:22 --> Output Class Initialized
INFO - 2016-08-23 10:05:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:05:22 --> Input Class Initialized
INFO - 2016-08-23 10:05:22 --> Language Class Initialized
INFO - 2016-08-23 10:05:22 --> Loader Class Initialized
INFO - 2016-08-23 10:05:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:05:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:05:22 --> Controller Class Initialized
INFO - 2016-08-23 10:05:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:05:22 --> Model Class Initialized
INFO - 2016-08-23 10:05:22 --> Model Class Initialized
INFO - 2016-08-23 10:05:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:05:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:05:22 --> Total execution time: 0.0635
INFO - 2016-08-23 10:05:52 --> Config Class Initialized
INFO - 2016-08-23 10:05:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:05:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:05:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:05:52 --> URI Class Initialized
INFO - 2016-08-23 10:05:52 --> Router Class Initialized
INFO - 2016-08-23 10:05:52 --> Output Class Initialized
INFO - 2016-08-23 10:05:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:05:52 --> Input Class Initialized
INFO - 2016-08-23 10:05:52 --> Language Class Initialized
INFO - 2016-08-23 10:05:52 --> Loader Class Initialized
INFO - 2016-08-23 10:05:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:05:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:05:52 --> Controller Class Initialized
INFO - 2016-08-23 10:05:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:05:52 --> Model Class Initialized
INFO - 2016-08-23 10:05:52 --> Model Class Initialized
INFO - 2016-08-23 10:05:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:05:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:05:52 --> Total execution time: 0.0594
INFO - 2016-08-23 10:06:22 --> Config Class Initialized
INFO - 2016-08-23 10:06:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:06:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:06:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:06:22 --> URI Class Initialized
INFO - 2016-08-23 10:06:22 --> Router Class Initialized
INFO - 2016-08-23 10:06:22 --> Output Class Initialized
INFO - 2016-08-23 10:06:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:06:22 --> Input Class Initialized
INFO - 2016-08-23 10:06:22 --> Language Class Initialized
INFO - 2016-08-23 10:06:22 --> Loader Class Initialized
INFO - 2016-08-23 10:06:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:06:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:06:22 --> Controller Class Initialized
INFO - 2016-08-23 10:06:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:06:22 --> Model Class Initialized
INFO - 2016-08-23 10:06:22 --> Model Class Initialized
INFO - 2016-08-23 10:06:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:06:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:06:22 --> Total execution time: 0.0701
INFO - 2016-08-23 10:06:52 --> Config Class Initialized
INFO - 2016-08-23 10:06:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:06:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:06:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:06:52 --> URI Class Initialized
INFO - 2016-08-23 10:06:52 --> Router Class Initialized
INFO - 2016-08-23 10:06:52 --> Output Class Initialized
INFO - 2016-08-23 10:06:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:06:52 --> Input Class Initialized
INFO - 2016-08-23 10:06:52 --> Language Class Initialized
INFO - 2016-08-23 10:06:52 --> Loader Class Initialized
INFO - 2016-08-23 10:06:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:06:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:06:52 --> Controller Class Initialized
INFO - 2016-08-23 10:06:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:06:52 --> Model Class Initialized
INFO - 2016-08-23 10:06:52 --> Model Class Initialized
INFO - 2016-08-23 10:06:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:06:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:06:52 --> Total execution time: 0.0588
INFO - 2016-08-23 10:07:22 --> Config Class Initialized
INFO - 2016-08-23 10:07:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:07:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:07:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:07:22 --> URI Class Initialized
INFO - 2016-08-23 10:07:22 --> Router Class Initialized
INFO - 2016-08-23 10:07:22 --> Output Class Initialized
INFO - 2016-08-23 10:07:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:07:22 --> Input Class Initialized
INFO - 2016-08-23 10:07:22 --> Language Class Initialized
INFO - 2016-08-23 10:07:22 --> Loader Class Initialized
INFO - 2016-08-23 10:07:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:07:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:07:22 --> Controller Class Initialized
INFO - 2016-08-23 10:07:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:07:22 --> Model Class Initialized
INFO - 2016-08-23 10:07:22 --> Model Class Initialized
INFO - 2016-08-23 10:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:07:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:07:22 --> Total execution time: 0.0657
INFO - 2016-08-23 10:07:52 --> Config Class Initialized
INFO - 2016-08-23 10:07:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:07:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:07:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:07:52 --> URI Class Initialized
INFO - 2016-08-23 10:07:52 --> Router Class Initialized
INFO - 2016-08-23 10:07:52 --> Output Class Initialized
INFO - 2016-08-23 10:07:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:07:52 --> Input Class Initialized
INFO - 2016-08-23 10:07:52 --> Language Class Initialized
INFO - 2016-08-23 10:07:52 --> Loader Class Initialized
INFO - 2016-08-23 10:07:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:07:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:07:52 --> Controller Class Initialized
INFO - 2016-08-23 10:07:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:07:52 --> Model Class Initialized
INFO - 2016-08-23 10:07:52 --> Model Class Initialized
INFO - 2016-08-23 10:07:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:07:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:07:52 --> Total execution time: 0.0579
INFO - 2016-08-23 10:08:22 --> Config Class Initialized
INFO - 2016-08-23 10:08:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:08:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:08:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:08:22 --> URI Class Initialized
INFO - 2016-08-23 10:08:22 --> Router Class Initialized
INFO - 2016-08-23 10:08:22 --> Output Class Initialized
INFO - 2016-08-23 10:08:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:08:22 --> Input Class Initialized
INFO - 2016-08-23 10:08:22 --> Language Class Initialized
INFO - 2016-08-23 10:08:22 --> Loader Class Initialized
INFO - 2016-08-23 10:08:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:08:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:08:22 --> Controller Class Initialized
INFO - 2016-08-23 10:08:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:08:22 --> Model Class Initialized
INFO - 2016-08-23 10:08:22 --> Model Class Initialized
INFO - 2016-08-23 10:08:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:08:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:08:22 --> Total execution time: 0.0582
INFO - 2016-08-23 10:08:52 --> Config Class Initialized
INFO - 2016-08-23 10:08:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:08:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:08:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:08:52 --> URI Class Initialized
INFO - 2016-08-23 10:08:52 --> Router Class Initialized
INFO - 2016-08-23 10:08:52 --> Output Class Initialized
INFO - 2016-08-23 10:08:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:08:52 --> Input Class Initialized
INFO - 2016-08-23 10:08:52 --> Language Class Initialized
INFO - 2016-08-23 10:08:52 --> Loader Class Initialized
INFO - 2016-08-23 10:08:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:08:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:08:52 --> Controller Class Initialized
INFO - 2016-08-23 10:08:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:08:52 --> Model Class Initialized
INFO - 2016-08-23 10:08:52 --> Model Class Initialized
INFO - 2016-08-23 10:08:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:08:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:08:52 --> Total execution time: 0.0530
INFO - 2016-08-23 10:09:22 --> Config Class Initialized
INFO - 2016-08-23 10:09:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:09:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:09:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:09:22 --> URI Class Initialized
INFO - 2016-08-23 10:09:22 --> Router Class Initialized
INFO - 2016-08-23 10:09:22 --> Output Class Initialized
INFO - 2016-08-23 10:09:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:09:22 --> Input Class Initialized
INFO - 2016-08-23 10:09:22 --> Language Class Initialized
INFO - 2016-08-23 10:09:22 --> Loader Class Initialized
INFO - 2016-08-23 10:09:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:09:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:09:22 --> Controller Class Initialized
INFO - 2016-08-23 10:09:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:09:22 --> Model Class Initialized
INFO - 2016-08-23 10:09:22 --> Model Class Initialized
INFO - 2016-08-23 10:09:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:09:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:09:22 --> Total execution time: 0.0674
INFO - 2016-08-23 10:09:52 --> Config Class Initialized
INFO - 2016-08-23 10:09:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:09:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:09:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:09:52 --> URI Class Initialized
INFO - 2016-08-23 10:09:52 --> Router Class Initialized
INFO - 2016-08-23 10:09:52 --> Output Class Initialized
INFO - 2016-08-23 10:09:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:09:52 --> Input Class Initialized
INFO - 2016-08-23 10:09:52 --> Language Class Initialized
INFO - 2016-08-23 10:09:52 --> Loader Class Initialized
INFO - 2016-08-23 10:09:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:09:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:09:52 --> Controller Class Initialized
INFO - 2016-08-23 10:09:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:09:52 --> Model Class Initialized
INFO - 2016-08-23 10:09:52 --> Model Class Initialized
INFO - 2016-08-23 10:09:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:09:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:09:52 --> Total execution time: 0.0555
INFO - 2016-08-23 10:10:22 --> Config Class Initialized
INFO - 2016-08-23 10:10:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:10:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:10:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:10:22 --> URI Class Initialized
INFO - 2016-08-23 10:10:22 --> Router Class Initialized
INFO - 2016-08-23 10:10:22 --> Output Class Initialized
INFO - 2016-08-23 10:10:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:10:22 --> Input Class Initialized
INFO - 2016-08-23 10:10:22 --> Language Class Initialized
INFO - 2016-08-23 10:10:22 --> Loader Class Initialized
INFO - 2016-08-23 10:10:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:10:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:10:22 --> Controller Class Initialized
INFO - 2016-08-23 10:10:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:10:22 --> Model Class Initialized
INFO - 2016-08-23 10:10:22 --> Model Class Initialized
INFO - 2016-08-23 10:10:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:10:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:10:22 --> Total execution time: 0.0539
INFO - 2016-08-23 10:10:52 --> Config Class Initialized
INFO - 2016-08-23 10:10:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:10:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:10:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:10:52 --> URI Class Initialized
INFO - 2016-08-23 10:10:52 --> Router Class Initialized
INFO - 2016-08-23 10:10:52 --> Output Class Initialized
INFO - 2016-08-23 10:10:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:10:52 --> Input Class Initialized
INFO - 2016-08-23 10:10:52 --> Language Class Initialized
INFO - 2016-08-23 10:10:52 --> Loader Class Initialized
INFO - 2016-08-23 10:10:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:10:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:10:52 --> Controller Class Initialized
INFO - 2016-08-23 10:10:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:10:52 --> Model Class Initialized
INFO - 2016-08-23 10:10:52 --> Model Class Initialized
INFO - 2016-08-23 10:10:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:10:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:10:52 --> Total execution time: 0.0541
INFO - 2016-08-23 10:11:22 --> Config Class Initialized
INFO - 2016-08-23 10:11:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:11:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:11:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:11:22 --> URI Class Initialized
INFO - 2016-08-23 10:11:22 --> Router Class Initialized
INFO - 2016-08-23 10:11:22 --> Output Class Initialized
INFO - 2016-08-23 10:11:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:11:22 --> Input Class Initialized
INFO - 2016-08-23 10:11:22 --> Language Class Initialized
INFO - 2016-08-23 10:11:22 --> Loader Class Initialized
INFO - 2016-08-23 10:11:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:11:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:11:22 --> Controller Class Initialized
INFO - 2016-08-23 10:11:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:11:22 --> Model Class Initialized
INFO - 2016-08-23 10:11:22 --> Model Class Initialized
INFO - 2016-08-23 10:11:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:11:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:11:22 --> Total execution time: 0.0534
INFO - 2016-08-23 10:11:52 --> Config Class Initialized
INFO - 2016-08-23 10:11:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:11:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:11:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:11:52 --> URI Class Initialized
INFO - 2016-08-23 10:11:52 --> Router Class Initialized
INFO - 2016-08-23 10:11:52 --> Output Class Initialized
INFO - 2016-08-23 10:11:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:11:52 --> Input Class Initialized
INFO - 2016-08-23 10:11:52 --> Language Class Initialized
INFO - 2016-08-23 10:11:52 --> Loader Class Initialized
INFO - 2016-08-23 10:11:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:11:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:11:52 --> Controller Class Initialized
INFO - 2016-08-23 10:11:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:11:52 --> Model Class Initialized
INFO - 2016-08-23 10:11:52 --> Model Class Initialized
INFO - 2016-08-23 10:11:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:11:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:11:52 --> Total execution time: 0.0528
INFO - 2016-08-23 10:12:22 --> Config Class Initialized
INFO - 2016-08-23 10:12:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:12:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:12:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:12:22 --> URI Class Initialized
INFO - 2016-08-23 10:12:22 --> Router Class Initialized
INFO - 2016-08-23 10:12:22 --> Output Class Initialized
INFO - 2016-08-23 10:12:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:12:22 --> Input Class Initialized
INFO - 2016-08-23 10:12:22 --> Language Class Initialized
INFO - 2016-08-23 10:12:22 --> Loader Class Initialized
INFO - 2016-08-23 10:12:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:12:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:12:22 --> Controller Class Initialized
INFO - 2016-08-23 10:12:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:12:22 --> Model Class Initialized
INFO - 2016-08-23 10:12:22 --> Model Class Initialized
INFO - 2016-08-23 10:12:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:12:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:12:22 --> Total execution time: 0.0603
INFO - 2016-08-23 10:12:52 --> Config Class Initialized
INFO - 2016-08-23 10:12:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:12:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:12:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:12:52 --> URI Class Initialized
INFO - 2016-08-23 10:12:52 --> Router Class Initialized
INFO - 2016-08-23 10:12:52 --> Output Class Initialized
INFO - 2016-08-23 10:12:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:12:52 --> Input Class Initialized
INFO - 2016-08-23 10:12:52 --> Language Class Initialized
INFO - 2016-08-23 10:12:52 --> Loader Class Initialized
INFO - 2016-08-23 10:12:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:12:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:12:52 --> Controller Class Initialized
INFO - 2016-08-23 10:12:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:12:52 --> Model Class Initialized
INFO - 2016-08-23 10:12:52 --> Model Class Initialized
INFO - 2016-08-23 10:12:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:12:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:12:52 --> Total execution time: 0.0626
INFO - 2016-08-23 10:13:22 --> Config Class Initialized
INFO - 2016-08-23 10:13:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:13:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:13:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:13:22 --> URI Class Initialized
INFO - 2016-08-23 10:13:22 --> Router Class Initialized
INFO - 2016-08-23 10:13:22 --> Output Class Initialized
INFO - 2016-08-23 10:13:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:13:22 --> Input Class Initialized
INFO - 2016-08-23 10:13:22 --> Language Class Initialized
INFO - 2016-08-23 10:13:22 --> Loader Class Initialized
INFO - 2016-08-23 10:13:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:13:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:13:22 --> Controller Class Initialized
INFO - 2016-08-23 10:13:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:13:22 --> Model Class Initialized
INFO - 2016-08-23 10:13:22 --> Model Class Initialized
INFO - 2016-08-23 10:13:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:13:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:13:22 --> Total execution time: 0.0664
INFO - 2016-08-23 10:13:52 --> Config Class Initialized
INFO - 2016-08-23 10:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:13:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:13:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:13:52 --> URI Class Initialized
INFO - 2016-08-23 10:13:52 --> Router Class Initialized
INFO - 2016-08-23 10:13:52 --> Output Class Initialized
INFO - 2016-08-23 10:13:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:13:52 --> Input Class Initialized
INFO - 2016-08-23 10:13:52 --> Language Class Initialized
INFO - 2016-08-23 10:13:52 --> Loader Class Initialized
INFO - 2016-08-23 10:13:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:13:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:13:52 --> Controller Class Initialized
INFO - 2016-08-23 10:13:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:13:52 --> Model Class Initialized
INFO - 2016-08-23 10:13:52 --> Model Class Initialized
INFO - 2016-08-23 10:13:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:13:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:13:52 --> Total execution time: 0.0667
INFO - 2016-08-23 10:14:22 --> Config Class Initialized
INFO - 2016-08-23 10:14:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:14:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:14:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:14:22 --> URI Class Initialized
INFO - 2016-08-23 10:14:22 --> Router Class Initialized
INFO - 2016-08-23 10:14:22 --> Output Class Initialized
INFO - 2016-08-23 10:14:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:14:22 --> Input Class Initialized
INFO - 2016-08-23 10:14:22 --> Language Class Initialized
INFO - 2016-08-23 10:14:22 --> Loader Class Initialized
INFO - 2016-08-23 10:14:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:14:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:14:22 --> Controller Class Initialized
INFO - 2016-08-23 10:14:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:14:22 --> Model Class Initialized
INFO - 2016-08-23 10:14:22 --> Model Class Initialized
INFO - 2016-08-23 10:14:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:14:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:14:22 --> Total execution time: 0.0609
INFO - 2016-08-23 10:14:52 --> Config Class Initialized
INFO - 2016-08-23 10:14:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:14:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:14:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:14:52 --> URI Class Initialized
INFO - 2016-08-23 10:14:52 --> Router Class Initialized
INFO - 2016-08-23 10:14:52 --> Output Class Initialized
INFO - 2016-08-23 10:14:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:14:52 --> Input Class Initialized
INFO - 2016-08-23 10:14:52 --> Language Class Initialized
INFO - 2016-08-23 10:14:52 --> Loader Class Initialized
INFO - 2016-08-23 10:14:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:14:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:14:52 --> Controller Class Initialized
INFO - 2016-08-23 10:14:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:14:52 --> Model Class Initialized
INFO - 2016-08-23 10:14:52 --> Model Class Initialized
INFO - 2016-08-23 10:14:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:14:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:14:52 --> Total execution time: 0.0590
INFO - 2016-08-23 10:15:22 --> Config Class Initialized
INFO - 2016-08-23 10:15:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:15:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:15:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:15:22 --> URI Class Initialized
INFO - 2016-08-23 10:15:22 --> Router Class Initialized
INFO - 2016-08-23 10:15:22 --> Output Class Initialized
INFO - 2016-08-23 10:15:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:15:22 --> Input Class Initialized
INFO - 2016-08-23 10:15:22 --> Language Class Initialized
INFO - 2016-08-23 10:15:22 --> Loader Class Initialized
INFO - 2016-08-23 10:15:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:15:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:15:22 --> Controller Class Initialized
INFO - 2016-08-23 10:15:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:15:22 --> Model Class Initialized
INFO - 2016-08-23 10:15:22 --> Model Class Initialized
INFO - 2016-08-23 10:15:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:15:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:15:22 --> Total execution time: 0.0610
INFO - 2016-08-23 10:15:52 --> Config Class Initialized
INFO - 2016-08-23 10:15:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:15:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:15:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:15:52 --> URI Class Initialized
INFO - 2016-08-23 10:15:52 --> Router Class Initialized
INFO - 2016-08-23 10:15:52 --> Output Class Initialized
INFO - 2016-08-23 10:15:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:15:52 --> Input Class Initialized
INFO - 2016-08-23 10:15:52 --> Language Class Initialized
INFO - 2016-08-23 10:15:52 --> Loader Class Initialized
INFO - 2016-08-23 10:15:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:15:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:15:52 --> Controller Class Initialized
INFO - 2016-08-23 10:15:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:15:52 --> Model Class Initialized
INFO - 2016-08-23 10:15:52 --> Model Class Initialized
INFO - 2016-08-23 10:15:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:15:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:15:52 --> Total execution time: 0.0764
INFO - 2016-08-23 10:16:22 --> Config Class Initialized
INFO - 2016-08-23 10:16:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:16:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:16:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:16:22 --> URI Class Initialized
INFO - 2016-08-23 10:16:22 --> Router Class Initialized
INFO - 2016-08-23 10:16:22 --> Output Class Initialized
INFO - 2016-08-23 10:16:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:16:22 --> Input Class Initialized
INFO - 2016-08-23 10:16:22 --> Language Class Initialized
INFO - 2016-08-23 10:16:22 --> Loader Class Initialized
INFO - 2016-08-23 10:16:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:16:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:16:22 --> Controller Class Initialized
INFO - 2016-08-23 10:16:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:16:22 --> Model Class Initialized
INFO - 2016-08-23 10:16:22 --> Model Class Initialized
INFO - 2016-08-23 10:16:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:16:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:16:22 --> Total execution time: 0.0577
INFO - 2016-08-23 10:16:52 --> Config Class Initialized
INFO - 2016-08-23 10:16:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:16:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:16:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:16:52 --> URI Class Initialized
INFO - 2016-08-23 10:16:52 --> Router Class Initialized
INFO - 2016-08-23 10:16:52 --> Output Class Initialized
INFO - 2016-08-23 10:16:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:16:52 --> Input Class Initialized
INFO - 2016-08-23 10:16:52 --> Language Class Initialized
INFO - 2016-08-23 10:16:52 --> Loader Class Initialized
INFO - 2016-08-23 10:16:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:16:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:16:52 --> Controller Class Initialized
INFO - 2016-08-23 10:16:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:16:52 --> Model Class Initialized
INFO - 2016-08-23 10:16:52 --> Model Class Initialized
INFO - 2016-08-23 10:16:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:16:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:16:52 --> Total execution time: 0.0598
INFO - 2016-08-23 10:17:22 --> Config Class Initialized
INFO - 2016-08-23 10:17:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:17:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:17:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:17:22 --> URI Class Initialized
INFO - 2016-08-23 10:17:22 --> Router Class Initialized
INFO - 2016-08-23 10:17:22 --> Output Class Initialized
INFO - 2016-08-23 10:17:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:17:22 --> Input Class Initialized
INFO - 2016-08-23 10:17:22 --> Language Class Initialized
INFO - 2016-08-23 10:17:22 --> Loader Class Initialized
INFO - 2016-08-23 10:17:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:17:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:17:22 --> Controller Class Initialized
INFO - 2016-08-23 10:17:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:17:22 --> Model Class Initialized
INFO - 2016-08-23 10:17:22 --> Model Class Initialized
INFO - 2016-08-23 10:17:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:17:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:17:22 --> Total execution time: 0.1136
INFO - 2016-08-23 10:17:52 --> Config Class Initialized
INFO - 2016-08-23 10:17:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:17:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:17:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:17:52 --> URI Class Initialized
INFO - 2016-08-23 10:17:52 --> Router Class Initialized
INFO - 2016-08-23 10:17:52 --> Output Class Initialized
INFO - 2016-08-23 10:17:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:17:52 --> Input Class Initialized
INFO - 2016-08-23 10:17:52 --> Language Class Initialized
INFO - 2016-08-23 10:17:52 --> Loader Class Initialized
INFO - 2016-08-23 10:17:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:17:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:17:52 --> Controller Class Initialized
INFO - 2016-08-23 10:17:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:17:52 --> Model Class Initialized
INFO - 2016-08-23 10:17:52 --> Model Class Initialized
INFO - 2016-08-23 10:17:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:17:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:17:52 --> Total execution time: 0.0561
INFO - 2016-08-23 10:18:22 --> Config Class Initialized
INFO - 2016-08-23 10:18:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:18:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:18:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:18:22 --> URI Class Initialized
INFO - 2016-08-23 10:18:22 --> Router Class Initialized
INFO - 2016-08-23 10:18:22 --> Output Class Initialized
INFO - 2016-08-23 10:18:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:18:22 --> Input Class Initialized
INFO - 2016-08-23 10:18:22 --> Language Class Initialized
INFO - 2016-08-23 10:18:22 --> Loader Class Initialized
INFO - 2016-08-23 10:18:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:18:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:18:22 --> Controller Class Initialized
INFO - 2016-08-23 10:18:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:18:22 --> Model Class Initialized
INFO - 2016-08-23 10:18:22 --> Model Class Initialized
INFO - 2016-08-23 10:18:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:18:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:18:22 --> Total execution time: 0.0570
INFO - 2016-08-23 10:18:52 --> Config Class Initialized
INFO - 2016-08-23 10:18:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:18:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:18:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:18:52 --> URI Class Initialized
INFO - 2016-08-23 10:18:52 --> Router Class Initialized
INFO - 2016-08-23 10:18:52 --> Output Class Initialized
INFO - 2016-08-23 10:18:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:18:52 --> Input Class Initialized
INFO - 2016-08-23 10:18:52 --> Language Class Initialized
INFO - 2016-08-23 10:18:52 --> Loader Class Initialized
INFO - 2016-08-23 10:18:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:18:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:18:52 --> Controller Class Initialized
INFO - 2016-08-23 10:18:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:18:52 --> Model Class Initialized
INFO - 2016-08-23 10:18:52 --> Model Class Initialized
INFO - 2016-08-23 10:18:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:18:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:18:52 --> Total execution time: 0.0703
INFO - 2016-08-23 10:19:22 --> Config Class Initialized
INFO - 2016-08-23 10:19:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:19:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:19:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:19:22 --> URI Class Initialized
INFO - 2016-08-23 10:19:22 --> Router Class Initialized
INFO - 2016-08-23 10:19:22 --> Output Class Initialized
INFO - 2016-08-23 10:19:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:19:22 --> Input Class Initialized
INFO - 2016-08-23 10:19:22 --> Language Class Initialized
INFO - 2016-08-23 10:19:22 --> Loader Class Initialized
INFO - 2016-08-23 10:19:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:19:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:19:22 --> Controller Class Initialized
INFO - 2016-08-23 10:19:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:19:22 --> Model Class Initialized
INFO - 2016-08-23 10:19:22 --> Model Class Initialized
INFO - 2016-08-23 10:19:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:19:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:19:22 --> Total execution time: 0.0578
INFO - 2016-08-23 10:19:52 --> Config Class Initialized
INFO - 2016-08-23 10:19:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:19:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:19:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:19:52 --> URI Class Initialized
INFO - 2016-08-23 10:19:52 --> Router Class Initialized
INFO - 2016-08-23 10:19:52 --> Output Class Initialized
INFO - 2016-08-23 10:19:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:19:52 --> Input Class Initialized
INFO - 2016-08-23 10:19:52 --> Language Class Initialized
INFO - 2016-08-23 10:19:52 --> Loader Class Initialized
INFO - 2016-08-23 10:19:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:19:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:19:52 --> Controller Class Initialized
INFO - 2016-08-23 10:19:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:19:52 --> Model Class Initialized
INFO - 2016-08-23 10:19:52 --> Model Class Initialized
INFO - 2016-08-23 10:19:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:19:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:19:52 --> Total execution time: 0.0583
INFO - 2016-08-23 10:20:22 --> Config Class Initialized
INFO - 2016-08-23 10:20:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:20:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:20:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:20:22 --> URI Class Initialized
INFO - 2016-08-23 10:20:22 --> Router Class Initialized
INFO - 2016-08-23 10:20:22 --> Output Class Initialized
INFO - 2016-08-23 10:20:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:20:22 --> Input Class Initialized
INFO - 2016-08-23 10:20:22 --> Language Class Initialized
INFO - 2016-08-23 10:20:22 --> Loader Class Initialized
INFO - 2016-08-23 10:20:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:20:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:20:22 --> Controller Class Initialized
INFO - 2016-08-23 10:20:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:20:22 --> Model Class Initialized
INFO - 2016-08-23 10:20:22 --> Model Class Initialized
INFO - 2016-08-23 10:20:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:20:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:20:22 --> Total execution time: 0.0596
INFO - 2016-08-23 10:20:52 --> Config Class Initialized
INFO - 2016-08-23 10:20:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:20:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:20:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:20:52 --> URI Class Initialized
INFO - 2016-08-23 10:20:52 --> Router Class Initialized
INFO - 2016-08-23 10:20:52 --> Output Class Initialized
INFO - 2016-08-23 10:20:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:20:52 --> Input Class Initialized
INFO - 2016-08-23 10:20:52 --> Language Class Initialized
INFO - 2016-08-23 10:20:52 --> Loader Class Initialized
INFO - 2016-08-23 10:20:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:20:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:20:52 --> Controller Class Initialized
INFO - 2016-08-23 10:20:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:20:52 --> Model Class Initialized
INFO - 2016-08-23 10:20:52 --> Model Class Initialized
INFO - 2016-08-23 10:20:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:20:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:20:52 --> Total execution time: 0.0708
INFO - 2016-08-23 10:21:22 --> Config Class Initialized
INFO - 2016-08-23 10:21:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:21:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:21:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:21:22 --> URI Class Initialized
INFO - 2016-08-23 10:21:22 --> Router Class Initialized
INFO - 2016-08-23 10:21:22 --> Output Class Initialized
INFO - 2016-08-23 10:21:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:21:22 --> Input Class Initialized
INFO - 2016-08-23 10:21:22 --> Language Class Initialized
INFO - 2016-08-23 10:21:22 --> Loader Class Initialized
INFO - 2016-08-23 10:21:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:21:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:21:22 --> Controller Class Initialized
INFO - 2016-08-23 10:21:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:21:22 --> Model Class Initialized
INFO - 2016-08-23 10:21:22 --> Model Class Initialized
INFO - 2016-08-23 10:21:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:21:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:21:22 --> Total execution time: 0.0553
INFO - 2016-08-23 10:21:52 --> Config Class Initialized
INFO - 2016-08-23 10:21:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:21:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:21:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:21:52 --> URI Class Initialized
INFO - 2016-08-23 10:21:52 --> Router Class Initialized
INFO - 2016-08-23 10:21:52 --> Output Class Initialized
INFO - 2016-08-23 10:21:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:21:52 --> Input Class Initialized
INFO - 2016-08-23 10:21:52 --> Language Class Initialized
INFO - 2016-08-23 10:21:52 --> Loader Class Initialized
INFO - 2016-08-23 10:21:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:21:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:21:52 --> Controller Class Initialized
INFO - 2016-08-23 10:21:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:21:52 --> Model Class Initialized
INFO - 2016-08-23 10:21:52 --> Model Class Initialized
INFO - 2016-08-23 10:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:21:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:21:52 --> Total execution time: 0.0637
INFO - 2016-08-23 10:22:22 --> Config Class Initialized
INFO - 2016-08-23 10:22:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:22:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:22:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:22:22 --> URI Class Initialized
INFO - 2016-08-23 10:22:22 --> Router Class Initialized
INFO - 2016-08-23 10:22:22 --> Output Class Initialized
INFO - 2016-08-23 10:22:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:22:22 --> Input Class Initialized
INFO - 2016-08-23 10:22:22 --> Language Class Initialized
INFO - 2016-08-23 10:22:22 --> Loader Class Initialized
INFO - 2016-08-23 10:22:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:22:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:22:22 --> Controller Class Initialized
INFO - 2016-08-23 10:22:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:22:22 --> Model Class Initialized
INFO - 2016-08-23 10:22:22 --> Model Class Initialized
INFO - 2016-08-23 10:22:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:22:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:22:22 --> Total execution time: 0.0572
INFO - 2016-08-23 10:22:52 --> Config Class Initialized
INFO - 2016-08-23 10:22:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:22:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:22:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:22:52 --> URI Class Initialized
INFO - 2016-08-23 10:22:52 --> Router Class Initialized
INFO - 2016-08-23 10:22:52 --> Output Class Initialized
INFO - 2016-08-23 10:22:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:22:52 --> Input Class Initialized
INFO - 2016-08-23 10:22:52 --> Language Class Initialized
INFO - 2016-08-23 10:22:52 --> Loader Class Initialized
INFO - 2016-08-23 10:22:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:22:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:22:52 --> Controller Class Initialized
INFO - 2016-08-23 10:22:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:22:52 --> Model Class Initialized
INFO - 2016-08-23 10:22:52 --> Model Class Initialized
INFO - 2016-08-23 10:22:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:22:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:22:52 --> Total execution time: 0.0590
INFO - 2016-08-23 10:23:22 --> Config Class Initialized
INFO - 2016-08-23 10:23:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:23:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:23:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:23:22 --> URI Class Initialized
INFO - 2016-08-23 10:23:22 --> Router Class Initialized
INFO - 2016-08-23 10:23:22 --> Output Class Initialized
INFO - 2016-08-23 10:23:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:23:22 --> Input Class Initialized
INFO - 2016-08-23 10:23:22 --> Language Class Initialized
INFO - 2016-08-23 10:23:22 --> Loader Class Initialized
INFO - 2016-08-23 10:23:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:23:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:23:22 --> Controller Class Initialized
INFO - 2016-08-23 10:23:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:23:22 --> Model Class Initialized
INFO - 2016-08-23 10:23:22 --> Model Class Initialized
INFO - 2016-08-23 10:23:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:23:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:23:22 --> Total execution time: 0.0572
INFO - 2016-08-23 10:23:52 --> Config Class Initialized
INFO - 2016-08-23 10:23:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:23:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:23:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:23:52 --> URI Class Initialized
INFO - 2016-08-23 10:23:52 --> Router Class Initialized
INFO - 2016-08-23 10:23:52 --> Output Class Initialized
INFO - 2016-08-23 10:23:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:23:52 --> Input Class Initialized
INFO - 2016-08-23 10:23:52 --> Language Class Initialized
INFO - 2016-08-23 10:23:52 --> Loader Class Initialized
INFO - 2016-08-23 10:23:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:23:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:23:52 --> Controller Class Initialized
INFO - 2016-08-23 10:23:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:23:52 --> Model Class Initialized
INFO - 2016-08-23 10:23:52 --> Model Class Initialized
INFO - 2016-08-23 10:23:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:23:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:23:52 --> Total execution time: 0.0618
INFO - 2016-08-23 10:24:22 --> Config Class Initialized
INFO - 2016-08-23 10:24:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:24:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:24:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:24:22 --> URI Class Initialized
INFO - 2016-08-23 10:24:22 --> Router Class Initialized
INFO - 2016-08-23 10:24:22 --> Output Class Initialized
INFO - 2016-08-23 10:24:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:24:22 --> Input Class Initialized
INFO - 2016-08-23 10:24:22 --> Language Class Initialized
INFO - 2016-08-23 10:24:22 --> Loader Class Initialized
INFO - 2016-08-23 10:24:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:24:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:24:22 --> Controller Class Initialized
INFO - 2016-08-23 10:24:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:24:22 --> Model Class Initialized
INFO - 2016-08-23 10:24:22 --> Model Class Initialized
INFO - 2016-08-23 10:24:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:24:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:24:22 --> Total execution time: 0.0742
INFO - 2016-08-23 10:24:52 --> Config Class Initialized
INFO - 2016-08-23 10:24:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:24:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:24:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:24:52 --> URI Class Initialized
INFO - 2016-08-23 10:24:52 --> Router Class Initialized
INFO - 2016-08-23 10:24:52 --> Output Class Initialized
INFO - 2016-08-23 10:24:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:24:52 --> Input Class Initialized
INFO - 2016-08-23 10:24:52 --> Language Class Initialized
INFO - 2016-08-23 10:24:52 --> Loader Class Initialized
INFO - 2016-08-23 10:24:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:24:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:24:52 --> Controller Class Initialized
INFO - 2016-08-23 10:24:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:24:52 --> Model Class Initialized
INFO - 2016-08-23 10:24:52 --> Model Class Initialized
INFO - 2016-08-23 10:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:24:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:24:52 --> Total execution time: 0.0563
INFO - 2016-08-23 10:25:22 --> Config Class Initialized
INFO - 2016-08-23 10:25:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:25:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:25:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:25:22 --> URI Class Initialized
INFO - 2016-08-23 10:25:22 --> Router Class Initialized
INFO - 2016-08-23 10:25:22 --> Output Class Initialized
INFO - 2016-08-23 10:25:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:25:22 --> Input Class Initialized
INFO - 2016-08-23 10:25:22 --> Language Class Initialized
INFO - 2016-08-23 10:25:22 --> Loader Class Initialized
INFO - 2016-08-23 10:25:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:25:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:25:22 --> Controller Class Initialized
INFO - 2016-08-23 10:25:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:25:22 --> Model Class Initialized
INFO - 2016-08-23 10:25:22 --> Model Class Initialized
INFO - 2016-08-23 10:25:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:25:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:25:22 --> Total execution time: 0.0665
INFO - 2016-08-23 10:25:52 --> Config Class Initialized
INFO - 2016-08-23 10:25:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:25:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:25:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:25:52 --> URI Class Initialized
INFO - 2016-08-23 10:25:52 --> Router Class Initialized
INFO - 2016-08-23 10:25:52 --> Output Class Initialized
INFO - 2016-08-23 10:25:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:25:52 --> Input Class Initialized
INFO - 2016-08-23 10:25:52 --> Language Class Initialized
INFO - 2016-08-23 10:25:52 --> Loader Class Initialized
INFO - 2016-08-23 10:25:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:25:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:25:52 --> Controller Class Initialized
INFO - 2016-08-23 10:25:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:25:52 --> Model Class Initialized
INFO - 2016-08-23 10:25:52 --> Model Class Initialized
INFO - 2016-08-23 10:25:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:25:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:25:52 --> Total execution time: 0.0567
INFO - 2016-08-23 10:26:22 --> Config Class Initialized
INFO - 2016-08-23 10:26:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:26:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:26:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:26:22 --> URI Class Initialized
INFO - 2016-08-23 10:26:22 --> Router Class Initialized
INFO - 2016-08-23 10:26:22 --> Output Class Initialized
INFO - 2016-08-23 10:26:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:26:22 --> Input Class Initialized
INFO - 2016-08-23 10:26:22 --> Language Class Initialized
INFO - 2016-08-23 10:26:22 --> Loader Class Initialized
INFO - 2016-08-23 10:26:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:26:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:26:22 --> Controller Class Initialized
INFO - 2016-08-23 10:26:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:26:22 --> Model Class Initialized
INFO - 2016-08-23 10:26:22 --> Model Class Initialized
INFO - 2016-08-23 10:26:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:26:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:26:22 --> Total execution time: 0.0737
INFO - 2016-08-23 10:26:52 --> Config Class Initialized
INFO - 2016-08-23 10:26:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:26:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:26:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:26:52 --> URI Class Initialized
INFO - 2016-08-23 10:26:52 --> Router Class Initialized
INFO - 2016-08-23 10:26:52 --> Output Class Initialized
INFO - 2016-08-23 10:26:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:26:52 --> Input Class Initialized
INFO - 2016-08-23 10:26:52 --> Language Class Initialized
INFO - 2016-08-23 10:26:52 --> Loader Class Initialized
INFO - 2016-08-23 10:26:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:26:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:26:52 --> Controller Class Initialized
INFO - 2016-08-23 10:26:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:26:52 --> Model Class Initialized
INFO - 2016-08-23 10:26:52 --> Model Class Initialized
INFO - 2016-08-23 10:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:26:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:26:52 --> Total execution time: 0.0522
INFO - 2016-08-23 10:27:22 --> Config Class Initialized
INFO - 2016-08-23 10:27:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:27:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:27:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:27:22 --> URI Class Initialized
INFO - 2016-08-23 10:27:22 --> Router Class Initialized
INFO - 2016-08-23 10:27:22 --> Output Class Initialized
INFO - 2016-08-23 10:27:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:27:22 --> Input Class Initialized
INFO - 2016-08-23 10:27:22 --> Language Class Initialized
INFO - 2016-08-23 10:27:22 --> Loader Class Initialized
INFO - 2016-08-23 10:27:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:27:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:27:22 --> Controller Class Initialized
INFO - 2016-08-23 10:27:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:27:22 --> Model Class Initialized
INFO - 2016-08-23 10:27:22 --> Model Class Initialized
INFO - 2016-08-23 10:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:27:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:27:22 --> Total execution time: 0.0526
INFO - 2016-08-23 10:27:52 --> Config Class Initialized
INFO - 2016-08-23 10:27:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:27:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:27:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:27:52 --> URI Class Initialized
INFO - 2016-08-23 10:27:52 --> Router Class Initialized
INFO - 2016-08-23 10:27:52 --> Output Class Initialized
INFO - 2016-08-23 10:27:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:27:52 --> Input Class Initialized
INFO - 2016-08-23 10:27:52 --> Language Class Initialized
INFO - 2016-08-23 10:27:52 --> Loader Class Initialized
INFO - 2016-08-23 10:27:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:27:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:27:52 --> Controller Class Initialized
INFO - 2016-08-23 10:27:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:27:52 --> Model Class Initialized
INFO - 2016-08-23 10:27:52 --> Model Class Initialized
INFO - 2016-08-23 10:27:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:27:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:27:52 --> Total execution time: 0.0525
INFO - 2016-08-23 10:28:22 --> Config Class Initialized
INFO - 2016-08-23 10:28:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:28:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:28:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:28:22 --> URI Class Initialized
INFO - 2016-08-23 10:28:22 --> Router Class Initialized
INFO - 2016-08-23 10:28:22 --> Output Class Initialized
INFO - 2016-08-23 10:28:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:28:22 --> Input Class Initialized
INFO - 2016-08-23 10:28:22 --> Language Class Initialized
INFO - 2016-08-23 10:28:22 --> Loader Class Initialized
INFO - 2016-08-23 10:28:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:28:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:28:22 --> Controller Class Initialized
INFO - 2016-08-23 10:28:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:28:22 --> Model Class Initialized
INFO - 2016-08-23 10:28:22 --> Model Class Initialized
INFO - 2016-08-23 10:28:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:28:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:28:22 --> Total execution time: 0.0643
INFO - 2016-08-23 10:28:52 --> Config Class Initialized
INFO - 2016-08-23 10:28:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:28:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:28:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:28:52 --> URI Class Initialized
INFO - 2016-08-23 10:28:52 --> Router Class Initialized
INFO - 2016-08-23 10:28:52 --> Output Class Initialized
INFO - 2016-08-23 10:28:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:28:52 --> Input Class Initialized
INFO - 2016-08-23 10:28:52 --> Language Class Initialized
INFO - 2016-08-23 10:28:52 --> Loader Class Initialized
INFO - 2016-08-23 10:28:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:28:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:28:52 --> Controller Class Initialized
INFO - 2016-08-23 10:28:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:28:52 --> Model Class Initialized
INFO - 2016-08-23 10:28:52 --> Model Class Initialized
INFO - 2016-08-23 10:28:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:28:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:28:52 --> Total execution time: 0.0618
INFO - 2016-08-23 10:29:22 --> Config Class Initialized
INFO - 2016-08-23 10:29:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:29:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:29:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:29:22 --> URI Class Initialized
INFO - 2016-08-23 10:29:22 --> Router Class Initialized
INFO - 2016-08-23 10:29:22 --> Output Class Initialized
INFO - 2016-08-23 10:29:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:29:22 --> Input Class Initialized
INFO - 2016-08-23 10:29:22 --> Language Class Initialized
INFO - 2016-08-23 10:29:22 --> Loader Class Initialized
INFO - 2016-08-23 10:29:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:29:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:29:22 --> Controller Class Initialized
INFO - 2016-08-23 10:29:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:29:22 --> Model Class Initialized
INFO - 2016-08-23 10:29:22 --> Model Class Initialized
INFO - 2016-08-23 10:29:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:29:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:29:22 --> Total execution time: 0.0520
INFO - 2016-08-23 10:29:52 --> Config Class Initialized
INFO - 2016-08-23 10:29:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:29:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:29:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:29:52 --> URI Class Initialized
INFO - 2016-08-23 10:29:52 --> Router Class Initialized
INFO - 2016-08-23 10:29:52 --> Output Class Initialized
INFO - 2016-08-23 10:29:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:29:52 --> Input Class Initialized
INFO - 2016-08-23 10:29:52 --> Language Class Initialized
INFO - 2016-08-23 10:29:52 --> Loader Class Initialized
INFO - 2016-08-23 10:29:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:29:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:29:52 --> Controller Class Initialized
INFO - 2016-08-23 10:29:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:29:52 --> Model Class Initialized
INFO - 2016-08-23 10:29:52 --> Model Class Initialized
INFO - 2016-08-23 10:29:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:29:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:29:52 --> Total execution time: 0.0953
INFO - 2016-08-23 10:30:22 --> Config Class Initialized
INFO - 2016-08-23 10:30:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:30:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:30:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:30:22 --> URI Class Initialized
INFO - 2016-08-23 10:30:22 --> Router Class Initialized
INFO - 2016-08-23 10:30:22 --> Output Class Initialized
INFO - 2016-08-23 10:30:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:30:22 --> Input Class Initialized
INFO - 2016-08-23 10:30:22 --> Language Class Initialized
INFO - 2016-08-23 10:30:22 --> Loader Class Initialized
INFO - 2016-08-23 10:30:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:30:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:30:22 --> Controller Class Initialized
INFO - 2016-08-23 10:30:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:30:22 --> Model Class Initialized
INFO - 2016-08-23 10:30:22 --> Model Class Initialized
INFO - 2016-08-23 10:30:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:30:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:30:22 --> Total execution time: 0.0577
INFO - 2016-08-23 10:30:52 --> Config Class Initialized
INFO - 2016-08-23 10:30:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:30:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:30:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:30:52 --> URI Class Initialized
INFO - 2016-08-23 10:30:52 --> Router Class Initialized
INFO - 2016-08-23 10:30:52 --> Output Class Initialized
INFO - 2016-08-23 10:30:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:30:52 --> Input Class Initialized
INFO - 2016-08-23 10:30:52 --> Language Class Initialized
INFO - 2016-08-23 10:30:52 --> Loader Class Initialized
INFO - 2016-08-23 10:30:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:30:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:30:52 --> Controller Class Initialized
INFO - 2016-08-23 10:30:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:30:52 --> Model Class Initialized
INFO - 2016-08-23 10:30:52 --> Model Class Initialized
INFO - 2016-08-23 10:30:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:30:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:30:52 --> Total execution time: 0.0518
INFO - 2016-08-23 10:31:22 --> Config Class Initialized
INFO - 2016-08-23 10:31:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:31:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:31:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:31:22 --> URI Class Initialized
INFO - 2016-08-23 10:31:22 --> Router Class Initialized
INFO - 2016-08-23 10:31:22 --> Output Class Initialized
INFO - 2016-08-23 10:31:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:31:22 --> Input Class Initialized
INFO - 2016-08-23 10:31:22 --> Language Class Initialized
INFO - 2016-08-23 10:31:22 --> Loader Class Initialized
INFO - 2016-08-23 10:31:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:31:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:31:22 --> Controller Class Initialized
INFO - 2016-08-23 10:31:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:31:22 --> Model Class Initialized
INFO - 2016-08-23 10:31:22 --> Model Class Initialized
INFO - 2016-08-23 10:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:31:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:31:22 --> Total execution time: 0.0620
INFO - 2016-08-23 10:31:52 --> Config Class Initialized
INFO - 2016-08-23 10:31:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:31:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:31:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:31:52 --> URI Class Initialized
INFO - 2016-08-23 10:31:52 --> Router Class Initialized
INFO - 2016-08-23 10:31:52 --> Output Class Initialized
INFO - 2016-08-23 10:31:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:31:52 --> Input Class Initialized
INFO - 2016-08-23 10:31:52 --> Language Class Initialized
INFO - 2016-08-23 10:31:52 --> Loader Class Initialized
INFO - 2016-08-23 10:31:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:31:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:31:52 --> Controller Class Initialized
INFO - 2016-08-23 10:31:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:31:52 --> Model Class Initialized
INFO - 2016-08-23 10:31:52 --> Model Class Initialized
INFO - 2016-08-23 10:31:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:31:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:31:52 --> Total execution time: 0.0524
INFO - 2016-08-23 10:32:22 --> Config Class Initialized
INFO - 2016-08-23 10:32:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:32:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:32:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:32:22 --> URI Class Initialized
INFO - 2016-08-23 10:32:22 --> Router Class Initialized
INFO - 2016-08-23 10:32:22 --> Output Class Initialized
INFO - 2016-08-23 10:32:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:32:22 --> Input Class Initialized
INFO - 2016-08-23 10:32:22 --> Language Class Initialized
INFO - 2016-08-23 10:32:22 --> Loader Class Initialized
INFO - 2016-08-23 10:32:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:32:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:32:22 --> Controller Class Initialized
INFO - 2016-08-23 10:32:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:32:22 --> Model Class Initialized
INFO - 2016-08-23 10:32:22 --> Model Class Initialized
INFO - 2016-08-23 10:32:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:32:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:32:22 --> Total execution time: 0.0523
INFO - 2016-08-23 10:32:52 --> Config Class Initialized
INFO - 2016-08-23 10:32:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:32:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:32:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:32:52 --> URI Class Initialized
INFO - 2016-08-23 10:32:52 --> Router Class Initialized
INFO - 2016-08-23 10:32:52 --> Output Class Initialized
INFO - 2016-08-23 10:32:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:32:52 --> Input Class Initialized
INFO - 2016-08-23 10:32:52 --> Language Class Initialized
INFO - 2016-08-23 10:32:52 --> Loader Class Initialized
INFO - 2016-08-23 10:32:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:32:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:32:52 --> Controller Class Initialized
INFO - 2016-08-23 10:32:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:32:52 --> Model Class Initialized
INFO - 2016-08-23 10:32:52 --> Model Class Initialized
INFO - 2016-08-23 10:32:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:32:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:32:52 --> Total execution time: 0.0531
INFO - 2016-08-23 10:33:22 --> Config Class Initialized
INFO - 2016-08-23 10:33:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:33:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:33:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:33:22 --> URI Class Initialized
INFO - 2016-08-23 10:33:22 --> Router Class Initialized
INFO - 2016-08-23 10:33:22 --> Output Class Initialized
INFO - 2016-08-23 10:33:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:33:22 --> Input Class Initialized
INFO - 2016-08-23 10:33:22 --> Language Class Initialized
INFO - 2016-08-23 10:33:22 --> Loader Class Initialized
INFO - 2016-08-23 10:33:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:33:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:33:22 --> Controller Class Initialized
INFO - 2016-08-23 10:33:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:33:22 --> Model Class Initialized
INFO - 2016-08-23 10:33:22 --> Model Class Initialized
INFO - 2016-08-23 10:33:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:33:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:33:22 --> Total execution time: 0.0518
INFO - 2016-08-23 10:33:52 --> Config Class Initialized
INFO - 2016-08-23 10:33:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:33:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:33:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:33:52 --> URI Class Initialized
INFO - 2016-08-23 10:33:52 --> Router Class Initialized
INFO - 2016-08-23 10:33:52 --> Output Class Initialized
INFO - 2016-08-23 10:33:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:33:52 --> Input Class Initialized
INFO - 2016-08-23 10:33:52 --> Language Class Initialized
INFO - 2016-08-23 10:33:52 --> Loader Class Initialized
INFO - 2016-08-23 10:33:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:33:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:33:52 --> Controller Class Initialized
INFO - 2016-08-23 10:33:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:33:52 --> Model Class Initialized
INFO - 2016-08-23 10:33:52 --> Model Class Initialized
INFO - 2016-08-23 10:33:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:33:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:33:52 --> Total execution time: 0.0511
INFO - 2016-08-23 10:34:22 --> Config Class Initialized
INFO - 2016-08-23 10:34:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:34:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:34:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:34:22 --> URI Class Initialized
INFO - 2016-08-23 10:34:22 --> Router Class Initialized
INFO - 2016-08-23 10:34:22 --> Output Class Initialized
INFO - 2016-08-23 10:34:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:34:22 --> Input Class Initialized
INFO - 2016-08-23 10:34:22 --> Language Class Initialized
INFO - 2016-08-23 10:34:22 --> Loader Class Initialized
INFO - 2016-08-23 10:34:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:34:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:34:22 --> Controller Class Initialized
INFO - 2016-08-23 10:34:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:34:22 --> Model Class Initialized
INFO - 2016-08-23 10:34:22 --> Model Class Initialized
INFO - 2016-08-23 10:34:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:34:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:34:22 --> Total execution time: 0.0512
INFO - 2016-08-23 10:34:52 --> Config Class Initialized
INFO - 2016-08-23 10:34:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:34:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:34:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:34:52 --> URI Class Initialized
INFO - 2016-08-23 10:34:52 --> Router Class Initialized
INFO - 2016-08-23 10:34:52 --> Output Class Initialized
INFO - 2016-08-23 10:34:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:34:52 --> Input Class Initialized
INFO - 2016-08-23 10:34:52 --> Language Class Initialized
INFO - 2016-08-23 10:34:52 --> Loader Class Initialized
INFO - 2016-08-23 10:34:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:34:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:34:52 --> Controller Class Initialized
INFO - 2016-08-23 10:34:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:34:52 --> Model Class Initialized
INFO - 2016-08-23 10:34:52 --> Model Class Initialized
INFO - 2016-08-23 10:34:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:34:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:34:52 --> Total execution time: 0.0541
INFO - 2016-08-23 10:35:22 --> Config Class Initialized
INFO - 2016-08-23 10:35:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:35:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:35:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:35:22 --> URI Class Initialized
INFO - 2016-08-23 10:35:22 --> Router Class Initialized
INFO - 2016-08-23 10:35:22 --> Output Class Initialized
INFO - 2016-08-23 10:35:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:35:22 --> Input Class Initialized
INFO - 2016-08-23 10:35:22 --> Language Class Initialized
INFO - 2016-08-23 10:35:22 --> Loader Class Initialized
INFO - 2016-08-23 10:35:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:35:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:35:22 --> Controller Class Initialized
INFO - 2016-08-23 10:35:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:35:22 --> Model Class Initialized
INFO - 2016-08-23 10:35:22 --> Model Class Initialized
INFO - 2016-08-23 10:35:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:35:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:35:22 --> Total execution time: 0.0514
INFO - 2016-08-23 10:35:52 --> Config Class Initialized
INFO - 2016-08-23 10:35:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:35:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:35:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:35:52 --> URI Class Initialized
INFO - 2016-08-23 10:35:52 --> Router Class Initialized
INFO - 2016-08-23 10:35:52 --> Output Class Initialized
INFO - 2016-08-23 10:35:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:35:52 --> Input Class Initialized
INFO - 2016-08-23 10:35:52 --> Language Class Initialized
INFO - 2016-08-23 10:35:52 --> Loader Class Initialized
INFO - 2016-08-23 10:35:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:35:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:35:52 --> Controller Class Initialized
INFO - 2016-08-23 10:35:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:35:52 --> Model Class Initialized
INFO - 2016-08-23 10:35:52 --> Model Class Initialized
INFO - 2016-08-23 10:35:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:35:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:35:52 --> Total execution time: 0.0512
INFO - 2016-08-23 10:36:22 --> Config Class Initialized
INFO - 2016-08-23 10:36:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:36:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:36:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:36:22 --> URI Class Initialized
INFO - 2016-08-23 10:36:22 --> Router Class Initialized
INFO - 2016-08-23 10:36:22 --> Output Class Initialized
INFO - 2016-08-23 10:36:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:36:22 --> Input Class Initialized
INFO - 2016-08-23 10:36:22 --> Language Class Initialized
INFO - 2016-08-23 10:36:22 --> Loader Class Initialized
INFO - 2016-08-23 10:36:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:36:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:36:22 --> Controller Class Initialized
INFO - 2016-08-23 10:36:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:36:22 --> Model Class Initialized
INFO - 2016-08-23 10:36:22 --> Model Class Initialized
INFO - 2016-08-23 10:36:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:36:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:36:22 --> Total execution time: 0.0528
INFO - 2016-08-23 10:36:52 --> Config Class Initialized
INFO - 2016-08-23 10:36:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:36:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:36:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:36:52 --> URI Class Initialized
INFO - 2016-08-23 10:36:52 --> Router Class Initialized
INFO - 2016-08-23 10:36:52 --> Output Class Initialized
INFO - 2016-08-23 10:36:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:36:52 --> Input Class Initialized
INFO - 2016-08-23 10:36:52 --> Language Class Initialized
INFO - 2016-08-23 10:36:52 --> Loader Class Initialized
INFO - 2016-08-23 10:36:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:36:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:36:52 --> Controller Class Initialized
INFO - 2016-08-23 10:36:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:36:52 --> Model Class Initialized
INFO - 2016-08-23 10:36:52 --> Model Class Initialized
INFO - 2016-08-23 10:36:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:36:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:36:52 --> Total execution time: 0.0507
INFO - 2016-08-23 10:37:22 --> Config Class Initialized
INFO - 2016-08-23 10:37:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:37:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:37:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:37:22 --> URI Class Initialized
INFO - 2016-08-23 10:37:22 --> Router Class Initialized
INFO - 2016-08-23 10:37:22 --> Output Class Initialized
INFO - 2016-08-23 10:37:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:37:22 --> Input Class Initialized
INFO - 2016-08-23 10:37:22 --> Language Class Initialized
INFO - 2016-08-23 10:37:22 --> Loader Class Initialized
INFO - 2016-08-23 10:37:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:37:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:37:22 --> Controller Class Initialized
INFO - 2016-08-23 10:37:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:37:22 --> Model Class Initialized
INFO - 2016-08-23 10:37:22 --> Model Class Initialized
INFO - 2016-08-23 10:37:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:37:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:37:22 --> Total execution time: 0.0505
INFO - 2016-08-23 10:37:52 --> Config Class Initialized
INFO - 2016-08-23 10:37:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:37:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:37:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:37:52 --> URI Class Initialized
INFO - 2016-08-23 10:37:52 --> Router Class Initialized
INFO - 2016-08-23 10:37:52 --> Output Class Initialized
INFO - 2016-08-23 10:37:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:37:52 --> Input Class Initialized
INFO - 2016-08-23 10:37:52 --> Language Class Initialized
INFO - 2016-08-23 10:37:52 --> Loader Class Initialized
INFO - 2016-08-23 10:37:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:37:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:37:52 --> Controller Class Initialized
INFO - 2016-08-23 10:37:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:37:52 --> Model Class Initialized
INFO - 2016-08-23 10:37:52 --> Model Class Initialized
INFO - 2016-08-23 10:37:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:37:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:37:52 --> Total execution time: 0.0609
INFO - 2016-08-23 10:38:22 --> Config Class Initialized
INFO - 2016-08-23 10:38:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:38:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:38:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:38:22 --> URI Class Initialized
INFO - 2016-08-23 10:38:22 --> Router Class Initialized
INFO - 2016-08-23 10:38:22 --> Output Class Initialized
INFO - 2016-08-23 10:38:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:38:22 --> Input Class Initialized
INFO - 2016-08-23 10:38:22 --> Language Class Initialized
INFO - 2016-08-23 10:38:22 --> Loader Class Initialized
INFO - 2016-08-23 10:38:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:38:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:38:22 --> Controller Class Initialized
INFO - 2016-08-23 10:38:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:38:22 --> Model Class Initialized
INFO - 2016-08-23 10:38:22 --> Model Class Initialized
INFO - 2016-08-23 10:38:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:38:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:38:22 --> Total execution time: 0.0522
INFO - 2016-08-23 10:38:52 --> Config Class Initialized
INFO - 2016-08-23 10:38:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:38:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:38:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:38:52 --> URI Class Initialized
INFO - 2016-08-23 10:38:52 --> Router Class Initialized
INFO - 2016-08-23 10:38:52 --> Output Class Initialized
INFO - 2016-08-23 10:38:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:38:52 --> Input Class Initialized
INFO - 2016-08-23 10:38:52 --> Language Class Initialized
INFO - 2016-08-23 10:38:52 --> Loader Class Initialized
INFO - 2016-08-23 10:38:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:38:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:38:52 --> Controller Class Initialized
INFO - 2016-08-23 10:38:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:38:52 --> Model Class Initialized
INFO - 2016-08-23 10:38:52 --> Model Class Initialized
INFO - 2016-08-23 10:38:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:38:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:38:52 --> Total execution time: 0.0511
INFO - 2016-08-23 10:39:22 --> Config Class Initialized
INFO - 2016-08-23 10:39:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:39:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:39:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:39:22 --> URI Class Initialized
INFO - 2016-08-23 10:39:22 --> Router Class Initialized
INFO - 2016-08-23 10:39:22 --> Output Class Initialized
INFO - 2016-08-23 10:39:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:39:22 --> Input Class Initialized
INFO - 2016-08-23 10:39:22 --> Language Class Initialized
INFO - 2016-08-23 10:39:22 --> Loader Class Initialized
INFO - 2016-08-23 10:39:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:39:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:39:22 --> Controller Class Initialized
INFO - 2016-08-23 10:39:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:39:22 --> Model Class Initialized
INFO - 2016-08-23 10:39:22 --> Model Class Initialized
INFO - 2016-08-23 10:39:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:39:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:39:22 --> Total execution time: 0.0519
INFO - 2016-08-23 10:39:52 --> Config Class Initialized
INFO - 2016-08-23 10:39:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:39:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:39:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:39:52 --> URI Class Initialized
INFO - 2016-08-23 10:39:52 --> Router Class Initialized
INFO - 2016-08-23 10:39:52 --> Output Class Initialized
INFO - 2016-08-23 10:39:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:39:52 --> Input Class Initialized
INFO - 2016-08-23 10:39:52 --> Language Class Initialized
INFO - 2016-08-23 10:39:52 --> Loader Class Initialized
INFO - 2016-08-23 10:39:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:39:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:39:52 --> Controller Class Initialized
INFO - 2016-08-23 10:39:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:39:52 --> Model Class Initialized
INFO - 2016-08-23 10:39:52 --> Model Class Initialized
INFO - 2016-08-23 10:39:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:39:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:39:52 --> Total execution time: 0.0561
INFO - 2016-08-23 10:40:22 --> Config Class Initialized
INFO - 2016-08-23 10:40:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:40:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:40:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:40:22 --> URI Class Initialized
INFO - 2016-08-23 10:40:22 --> Router Class Initialized
INFO - 2016-08-23 10:40:22 --> Output Class Initialized
INFO - 2016-08-23 10:40:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:40:22 --> Input Class Initialized
INFO - 2016-08-23 10:40:22 --> Language Class Initialized
INFO - 2016-08-23 10:40:22 --> Loader Class Initialized
INFO - 2016-08-23 10:40:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:40:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:40:22 --> Controller Class Initialized
INFO - 2016-08-23 10:40:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:40:22 --> Model Class Initialized
INFO - 2016-08-23 10:40:22 --> Model Class Initialized
INFO - 2016-08-23 10:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:40:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:40:22 --> Total execution time: 0.0529
INFO - 2016-08-23 10:40:52 --> Config Class Initialized
INFO - 2016-08-23 10:40:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:40:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:40:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:40:52 --> URI Class Initialized
INFO - 2016-08-23 10:40:52 --> Router Class Initialized
INFO - 2016-08-23 10:40:52 --> Output Class Initialized
INFO - 2016-08-23 10:40:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:40:52 --> Input Class Initialized
INFO - 2016-08-23 10:40:52 --> Language Class Initialized
INFO - 2016-08-23 10:40:52 --> Loader Class Initialized
INFO - 2016-08-23 10:40:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:40:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:40:52 --> Controller Class Initialized
INFO - 2016-08-23 10:40:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:40:52 --> Model Class Initialized
INFO - 2016-08-23 10:40:52 --> Model Class Initialized
INFO - 2016-08-23 10:40:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:40:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:40:52 --> Total execution time: 0.0536
INFO - 2016-08-23 10:41:22 --> Config Class Initialized
INFO - 2016-08-23 10:41:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:41:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:41:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:41:22 --> URI Class Initialized
INFO - 2016-08-23 10:41:22 --> Router Class Initialized
INFO - 2016-08-23 10:41:22 --> Output Class Initialized
INFO - 2016-08-23 10:41:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:41:22 --> Input Class Initialized
INFO - 2016-08-23 10:41:22 --> Language Class Initialized
INFO - 2016-08-23 10:41:22 --> Loader Class Initialized
INFO - 2016-08-23 10:41:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:41:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:41:22 --> Controller Class Initialized
INFO - 2016-08-23 10:41:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:41:22 --> Model Class Initialized
INFO - 2016-08-23 10:41:22 --> Model Class Initialized
INFO - 2016-08-23 10:41:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:41:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:41:22 --> Total execution time: 0.0522
INFO - 2016-08-23 10:41:52 --> Config Class Initialized
INFO - 2016-08-23 10:41:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:41:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:41:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:41:52 --> URI Class Initialized
INFO - 2016-08-23 10:41:52 --> Router Class Initialized
INFO - 2016-08-23 10:41:52 --> Output Class Initialized
INFO - 2016-08-23 10:41:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:41:52 --> Input Class Initialized
INFO - 2016-08-23 10:41:52 --> Language Class Initialized
INFO - 2016-08-23 10:41:52 --> Loader Class Initialized
INFO - 2016-08-23 10:41:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:41:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:41:52 --> Controller Class Initialized
INFO - 2016-08-23 10:41:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:41:52 --> Model Class Initialized
INFO - 2016-08-23 10:41:52 --> Model Class Initialized
INFO - 2016-08-23 10:41:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:41:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:41:52 --> Total execution time: 0.0535
INFO - 2016-08-23 10:42:22 --> Config Class Initialized
INFO - 2016-08-23 10:42:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:42:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:42:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:42:22 --> URI Class Initialized
INFO - 2016-08-23 10:42:22 --> Router Class Initialized
INFO - 2016-08-23 10:42:22 --> Output Class Initialized
INFO - 2016-08-23 10:42:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:42:22 --> Input Class Initialized
INFO - 2016-08-23 10:42:22 --> Language Class Initialized
INFO - 2016-08-23 10:42:22 --> Loader Class Initialized
INFO - 2016-08-23 10:42:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:42:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:42:22 --> Controller Class Initialized
INFO - 2016-08-23 10:42:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:42:22 --> Model Class Initialized
INFO - 2016-08-23 10:42:22 --> Model Class Initialized
INFO - 2016-08-23 10:42:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:42:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:42:22 --> Total execution time: 0.0535
INFO - 2016-08-23 10:42:52 --> Config Class Initialized
INFO - 2016-08-23 10:42:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:42:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:42:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:42:52 --> URI Class Initialized
INFO - 2016-08-23 10:42:52 --> Router Class Initialized
INFO - 2016-08-23 10:42:52 --> Output Class Initialized
INFO - 2016-08-23 10:42:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:42:52 --> Input Class Initialized
INFO - 2016-08-23 10:42:52 --> Language Class Initialized
INFO - 2016-08-23 10:42:52 --> Loader Class Initialized
INFO - 2016-08-23 10:42:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:42:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:42:52 --> Controller Class Initialized
INFO - 2016-08-23 10:42:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:42:52 --> Model Class Initialized
INFO - 2016-08-23 10:42:52 --> Model Class Initialized
INFO - 2016-08-23 10:42:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:42:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:42:52 --> Total execution time: 0.0550
INFO - 2016-08-23 10:43:22 --> Config Class Initialized
INFO - 2016-08-23 10:43:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:43:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:43:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:43:22 --> URI Class Initialized
INFO - 2016-08-23 10:43:22 --> Router Class Initialized
INFO - 2016-08-23 10:43:22 --> Output Class Initialized
INFO - 2016-08-23 10:43:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:43:22 --> Input Class Initialized
INFO - 2016-08-23 10:43:22 --> Language Class Initialized
INFO - 2016-08-23 10:43:22 --> Loader Class Initialized
INFO - 2016-08-23 10:43:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:43:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:43:22 --> Controller Class Initialized
INFO - 2016-08-23 10:43:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:43:22 --> Model Class Initialized
INFO - 2016-08-23 10:43:22 --> Model Class Initialized
INFO - 2016-08-23 10:43:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:43:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:43:22 --> Total execution time: 0.0517
INFO - 2016-08-23 10:43:52 --> Config Class Initialized
INFO - 2016-08-23 10:43:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:43:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:43:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:43:52 --> URI Class Initialized
INFO - 2016-08-23 10:43:52 --> Router Class Initialized
INFO - 2016-08-23 10:43:52 --> Output Class Initialized
INFO - 2016-08-23 10:43:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:43:52 --> Input Class Initialized
INFO - 2016-08-23 10:43:52 --> Language Class Initialized
INFO - 2016-08-23 10:43:52 --> Loader Class Initialized
INFO - 2016-08-23 10:43:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:43:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:43:52 --> Controller Class Initialized
INFO - 2016-08-23 10:43:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:43:52 --> Model Class Initialized
INFO - 2016-08-23 10:43:52 --> Model Class Initialized
INFO - 2016-08-23 10:43:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:43:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:43:52 --> Total execution time: 0.0504
INFO - 2016-08-23 10:44:22 --> Config Class Initialized
INFO - 2016-08-23 10:44:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:44:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:44:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:44:22 --> URI Class Initialized
INFO - 2016-08-23 10:44:22 --> Router Class Initialized
INFO - 2016-08-23 10:44:22 --> Output Class Initialized
INFO - 2016-08-23 10:44:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:44:22 --> Input Class Initialized
INFO - 2016-08-23 10:44:22 --> Language Class Initialized
INFO - 2016-08-23 10:44:22 --> Loader Class Initialized
INFO - 2016-08-23 10:44:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:44:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:44:22 --> Controller Class Initialized
INFO - 2016-08-23 10:44:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:44:22 --> Model Class Initialized
INFO - 2016-08-23 10:44:22 --> Model Class Initialized
INFO - 2016-08-23 10:44:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:44:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:44:22 --> Total execution time: 0.0568
INFO - 2016-08-23 10:44:52 --> Config Class Initialized
INFO - 2016-08-23 10:44:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:44:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:44:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:44:52 --> URI Class Initialized
INFO - 2016-08-23 10:44:52 --> Router Class Initialized
INFO - 2016-08-23 10:44:52 --> Output Class Initialized
INFO - 2016-08-23 10:44:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:44:52 --> Input Class Initialized
INFO - 2016-08-23 10:44:52 --> Language Class Initialized
INFO - 2016-08-23 10:44:52 --> Loader Class Initialized
INFO - 2016-08-23 10:44:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:44:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:44:52 --> Controller Class Initialized
INFO - 2016-08-23 10:44:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:44:52 --> Model Class Initialized
INFO - 2016-08-23 10:44:52 --> Model Class Initialized
INFO - 2016-08-23 10:44:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:44:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:44:52 --> Total execution time: 0.0512
INFO - 2016-08-23 10:45:22 --> Config Class Initialized
INFO - 2016-08-23 10:45:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:45:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:45:22 --> Utf8 Class Initialized
INFO - 2016-08-23 10:45:22 --> URI Class Initialized
INFO - 2016-08-23 10:45:22 --> Router Class Initialized
INFO - 2016-08-23 10:45:22 --> Output Class Initialized
INFO - 2016-08-23 10:45:22 --> Security Class Initialized
DEBUG - 2016-08-23 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:45:22 --> Input Class Initialized
INFO - 2016-08-23 10:45:22 --> Language Class Initialized
INFO - 2016-08-23 10:45:22 --> Loader Class Initialized
INFO - 2016-08-23 10:45:22 --> Helper loaded: url_helper
INFO - 2016-08-23 10:45:22 --> Helper loaded: language_helper
INFO - 2016-08-23 10:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:45:22 --> Controller Class Initialized
INFO - 2016-08-23 10:45:22 --> Database Driver Class Initialized
INFO - 2016-08-23 10:45:22 --> Model Class Initialized
INFO - 2016-08-23 10:45:22 --> Model Class Initialized
INFO - 2016-08-23 10:45:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:45:22 --> Final output sent to browser
DEBUG - 2016-08-23 10:45:22 --> Total execution time: 0.0533
INFO - 2016-08-23 10:45:52 --> Config Class Initialized
INFO - 2016-08-23 10:45:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:45:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:45:52 --> Utf8 Class Initialized
INFO - 2016-08-23 10:45:52 --> URI Class Initialized
INFO - 2016-08-23 10:45:52 --> Router Class Initialized
INFO - 2016-08-23 10:45:52 --> Output Class Initialized
INFO - 2016-08-23 10:45:52 --> Security Class Initialized
DEBUG - 2016-08-23 10:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:45:52 --> Input Class Initialized
INFO - 2016-08-23 10:45:52 --> Language Class Initialized
INFO - 2016-08-23 10:45:52 --> Loader Class Initialized
INFO - 2016-08-23 10:45:52 --> Helper loaded: url_helper
INFO - 2016-08-23 10:45:52 --> Helper loaded: language_helper
INFO - 2016-08-23 10:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:45:52 --> Controller Class Initialized
INFO - 2016-08-23 10:45:52 --> Database Driver Class Initialized
INFO - 2016-08-23 10:45:52 --> Model Class Initialized
INFO - 2016-08-23 10:45:52 --> Model Class Initialized
INFO - 2016-08-23 10:45:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 10:45:52 --> Final output sent to browser
DEBUG - 2016-08-23 10:45:52 --> Total execution time: 0.0505
INFO - 2016-08-23 11:56:59 --> Config Class Initialized
INFO - 2016-08-23 11:56:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 11:56:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 11:56:59 --> Utf8 Class Initialized
INFO - 2016-08-23 11:56:59 --> URI Class Initialized
INFO - 2016-08-23 11:56:59 --> Router Class Initialized
INFO - 2016-08-23 11:56:59 --> Output Class Initialized
INFO - 2016-08-23 11:56:59 --> Security Class Initialized
DEBUG - 2016-08-23 11:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 11:56:59 --> Input Class Initialized
INFO - 2016-08-23 11:56:59 --> Language Class Initialized
INFO - 2016-08-23 11:56:59 --> Loader Class Initialized
INFO - 2016-08-23 11:56:59 --> Helper loaded: url_helper
INFO - 2016-08-23 11:56:59 --> Helper loaded: language_helper
INFO - 2016-08-23 11:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 11:56:59 --> Controller Class Initialized
INFO - 2016-08-23 11:56:59 --> Database Driver Class Initialized
INFO - 2016-08-23 11:56:59 --> Model Class Initialized
INFO - 2016-08-23 11:56:59 --> Model Class Initialized
INFO - 2016-08-23 11:56:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 11:56:59 --> Config Class Initialized
INFO - 2016-08-23 11:56:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 11:56:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 11:56:59 --> Utf8 Class Initialized
INFO - 2016-08-23 11:56:59 --> URI Class Initialized
INFO - 2016-08-23 11:56:59 --> Router Class Initialized
INFO - 2016-08-23 11:56:59 --> Output Class Initialized
INFO - 2016-08-23 11:56:59 --> Security Class Initialized
DEBUG - 2016-08-23 11:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 11:56:59 --> Input Class Initialized
INFO - 2016-08-23 11:56:59 --> Language Class Initialized
INFO - 2016-08-23 11:56:59 --> Loader Class Initialized
INFO - 2016-08-23 11:56:59 --> Helper loaded: url_helper
INFO - 2016-08-23 11:56:59 --> Helper loaded: language_helper
INFO - 2016-08-23 11:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 11:56:59 --> Controller Class Initialized
INFO - 2016-08-23 11:56:59 --> Database Driver Class Initialized
INFO - 2016-08-23 11:56:59 --> Model Class Initialized
INFO - 2016-08-23 11:56:59 --> Model Class Initialized
INFO - 2016-08-23 11:56:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-23 11:56:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-23 11:56:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-23 11:56:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-23 11:56:59 --> Final output sent to browser
DEBUG - 2016-08-23 11:56:59 --> Total execution time: 0.0583
