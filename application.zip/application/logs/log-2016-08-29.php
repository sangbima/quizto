<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-29 11:37:09 --> Config Class Initialized
INFO - 2016-08-29 11:37:09 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:37:09 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:37:09 --> Utf8 Class Initialized
INFO - 2016-08-29 11:37:09 --> URI Class Initialized
INFO - 2016-08-29 11:37:09 --> Router Class Initialized
INFO - 2016-08-29 11:37:09 --> Output Class Initialized
INFO - 2016-08-29 11:37:09 --> Security Class Initialized
DEBUG - 2016-08-29 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:37:09 --> Input Class Initialized
INFO - 2016-08-29 11:37:09 --> Language Class Initialized
INFO - 2016-08-29 11:37:09 --> Loader Class Initialized
INFO - 2016-08-29 11:37:09 --> Helper loaded: url_helper
INFO - 2016-08-29 11:37:09 --> Helper loaded: language_helper
INFO - 2016-08-29 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:37:09 --> Controller Class Initialized
INFO - 2016-08-29 11:37:09 --> Database Driver Class Initialized
INFO - 2016-08-29 11:37:09 --> Model Class Initialized
INFO - 2016-08-29 11:37:09 --> Model Class Initialized
INFO - 2016-08-29 11:37:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:37:09 --> Config Class Initialized
INFO - 2016-08-29 11:37:09 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:37:09 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:37:09 --> Utf8 Class Initialized
INFO - 2016-08-29 11:37:09 --> URI Class Initialized
INFO - 2016-08-29 11:37:09 --> Router Class Initialized
INFO - 2016-08-29 11:37:09 --> Output Class Initialized
INFO - 2016-08-29 11:37:09 --> Security Class Initialized
DEBUG - 2016-08-29 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:37:09 --> Input Class Initialized
INFO - 2016-08-29 11:37:09 --> Language Class Initialized
INFO - 2016-08-29 11:37:09 --> Loader Class Initialized
INFO - 2016-08-29 11:37:09 --> Helper loaded: url_helper
INFO - 2016-08-29 11:37:09 --> Helper loaded: language_helper
INFO - 2016-08-29 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:37:09 --> Controller Class Initialized
INFO - 2016-08-29 11:37:09 --> Database Driver Class Initialized
INFO - 2016-08-29 11:37:09 --> Model Class Initialized
INFO - 2016-08-29 11:37:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:37:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-29 11:37:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-29 11:37:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-29 11:37:09 --> Final output sent to browser
DEBUG - 2016-08-29 11:37:09 --> Total execution time: 0.0541
INFO - 2016-08-29 11:37:15 --> Config Class Initialized
INFO - 2016-08-29 11:37:15 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:37:15 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:37:15 --> Utf8 Class Initialized
INFO - 2016-08-29 11:37:15 --> URI Class Initialized
INFO - 2016-08-29 11:37:15 --> Router Class Initialized
INFO - 2016-08-29 11:37:15 --> Output Class Initialized
INFO - 2016-08-29 11:37:15 --> Security Class Initialized
DEBUG - 2016-08-29 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:37:15 --> Input Class Initialized
INFO - 2016-08-29 11:37:15 --> Language Class Initialized
INFO - 2016-08-29 11:37:15 --> Loader Class Initialized
INFO - 2016-08-29 11:37:15 --> Helper loaded: url_helper
INFO - 2016-08-29 11:37:15 --> Helper loaded: language_helper
INFO - 2016-08-29 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:37:15 --> Controller Class Initialized
INFO - 2016-08-29 11:37:15 --> Database Driver Class Initialized
INFO - 2016-08-29 11:37:15 --> Model Class Initialized
INFO - 2016-08-29 11:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:37:15 --> Config Class Initialized
INFO - 2016-08-29 11:37:15 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:37:15 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:37:15 --> Utf8 Class Initialized
INFO - 2016-08-29 11:37:15 --> URI Class Initialized
INFO - 2016-08-29 11:37:15 --> Router Class Initialized
INFO - 2016-08-29 11:37:15 --> Output Class Initialized
INFO - 2016-08-29 11:37:15 --> Security Class Initialized
DEBUG - 2016-08-29 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:37:15 --> Input Class Initialized
INFO - 2016-08-29 11:37:15 --> Language Class Initialized
INFO - 2016-08-29 11:37:15 --> Loader Class Initialized
INFO - 2016-08-29 11:37:15 --> Helper loaded: url_helper
INFO - 2016-08-29 11:37:15 --> Helper loaded: language_helper
INFO - 2016-08-29 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:37:15 --> Controller Class Initialized
INFO - 2016-08-29 11:37:15 --> Database Driver Class Initialized
INFO - 2016-08-29 11:37:15 --> Model Class Initialized
INFO - 2016-08-29 11:37:15 --> Model Class Initialized
INFO - 2016-08-29 11:37:15 --> Model Class Initialized
INFO - 2016-08-29 11:37:15 --> Model Class Initialized
INFO - 2016-08-29 11:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 11:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-29 11:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 11:37:15 --> Final output sent to browser
DEBUG - 2016-08-29 11:37:15 --> Total execution time: 0.0718
INFO - 2016-08-29 11:37:21 --> Config Class Initialized
INFO - 2016-08-29 11:37:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:37:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:37:21 --> Utf8 Class Initialized
INFO - 2016-08-29 11:37:21 --> URI Class Initialized
INFO - 2016-08-29 11:37:21 --> Router Class Initialized
INFO - 2016-08-29 11:37:21 --> Output Class Initialized
INFO - 2016-08-29 11:37:21 --> Security Class Initialized
DEBUG - 2016-08-29 11:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:37:21 --> Input Class Initialized
INFO - 2016-08-29 11:37:21 --> Language Class Initialized
INFO - 2016-08-29 11:37:21 --> Loader Class Initialized
INFO - 2016-08-29 11:37:21 --> Helper loaded: url_helper
INFO - 2016-08-29 11:37:21 --> Helper loaded: language_helper
INFO - 2016-08-29 11:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:37:21 --> Controller Class Initialized
INFO - 2016-08-29 11:37:21 --> Database Driver Class Initialized
INFO - 2016-08-29 11:37:21 --> Model Class Initialized
INFO - 2016-08-29 11:37:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:37:21 --> Helper loaded: form_helper
ERROR - 2016-08-29 11:37:21 --> Severity: error --> Exception: Call to undefined method Mscale_model::question_list() C:\wamp64\www\savsoftquiz\application\controllers\Mscale.php 40
INFO - 2016-08-29 11:39:00 --> Config Class Initialized
INFO - 2016-08-29 11:39:00 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:39:00 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:39:00 --> Utf8 Class Initialized
INFO - 2016-08-29 11:39:00 --> URI Class Initialized
INFO - 2016-08-29 11:39:00 --> Router Class Initialized
INFO - 2016-08-29 11:39:00 --> Output Class Initialized
INFO - 2016-08-29 11:39:00 --> Security Class Initialized
DEBUG - 2016-08-29 11:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:39:00 --> Input Class Initialized
INFO - 2016-08-29 11:39:00 --> Language Class Initialized
INFO - 2016-08-29 11:39:00 --> Loader Class Initialized
INFO - 2016-08-29 11:39:00 --> Helper loaded: url_helper
INFO - 2016-08-29 11:39:00 --> Helper loaded: language_helper
INFO - 2016-08-29 11:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:39:00 --> Controller Class Initialized
INFO - 2016-08-29 11:39:00 --> Database Driver Class Initialized
INFO - 2016-08-29 11:39:00 --> Model Class Initialized
INFO - 2016-08-29 11:39:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:39:00 --> Helper loaded: form_helper
INFO - 2016-08-29 11:39:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 11:39:00 --> Could not find the language line "value_d"
ERROR - 2016-08-29 11:39:00 --> Could not find the language line "value_i"
ERROR - 2016-08-29 11:39:00 --> Could not find the language line "value_s"
ERROR - 2016-08-29 11:39:00 --> Could not find the language line "value_c"
INFO - 2016-08-29 11:39:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\mscale_list.php
INFO - 2016-08-29 11:39:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 11:39:00 --> Final output sent to browser
DEBUG - 2016-08-29 11:39:00 --> Total execution time: 0.0636
INFO - 2016-08-29 11:40:04 --> Config Class Initialized
INFO - 2016-08-29 11:40:04 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:40:04 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:40:04 --> Utf8 Class Initialized
INFO - 2016-08-29 11:40:04 --> URI Class Initialized
INFO - 2016-08-29 11:40:04 --> Router Class Initialized
INFO - 2016-08-29 11:40:04 --> Output Class Initialized
INFO - 2016-08-29 11:40:04 --> Security Class Initialized
DEBUG - 2016-08-29 11:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:40:04 --> Input Class Initialized
INFO - 2016-08-29 11:40:04 --> Language Class Initialized
INFO - 2016-08-29 11:40:04 --> Loader Class Initialized
INFO - 2016-08-29 11:40:04 --> Helper loaded: url_helper
INFO - 2016-08-29 11:40:04 --> Helper loaded: language_helper
INFO - 2016-08-29 11:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:40:04 --> Controller Class Initialized
INFO - 2016-08-29 11:40:04 --> Database Driver Class Initialized
INFO - 2016-08-29 11:40:04 --> Model Class Initialized
INFO - 2016-08-29 11:40:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:40:04 --> Helper loaded: form_helper
INFO - 2016-08-29 11:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 11:40:04 --> Could not find the language line "value_d"
ERROR - 2016-08-29 11:40:04 --> Could not find the language line "value_i"
ERROR - 2016-08-29 11:40:04 --> Could not find the language line "value_s"
ERROR - 2016-08-29 11:40:04 --> Could not find the language line "value_c"
INFO - 2016-08-29 11:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\mscale_list.php
INFO - 2016-08-29 11:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 11:40:04 --> Final output sent to browser
DEBUG - 2016-08-29 11:40:04 --> Total execution time: 0.0722
INFO - 2016-08-29 11:41:00 --> Config Class Initialized
INFO - 2016-08-29 11:41:00 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:41:00 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:41:00 --> Utf8 Class Initialized
INFO - 2016-08-29 11:41:00 --> URI Class Initialized
INFO - 2016-08-29 11:41:00 --> Router Class Initialized
INFO - 2016-08-29 11:41:00 --> Output Class Initialized
INFO - 2016-08-29 11:41:00 --> Security Class Initialized
DEBUG - 2016-08-29 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:41:00 --> Input Class Initialized
INFO - 2016-08-29 11:41:00 --> Language Class Initialized
INFO - 2016-08-29 11:41:00 --> Loader Class Initialized
INFO - 2016-08-29 11:41:00 --> Helper loaded: url_helper
INFO - 2016-08-29 11:41:00 --> Helper loaded: language_helper
INFO - 2016-08-29 11:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:41:00 --> Controller Class Initialized
INFO - 2016-08-29 11:41:00 --> Database Driver Class Initialized
INFO - 2016-08-29 11:41:00 --> Model Class Initialized
INFO - 2016-08-29 11:41:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:41:00 --> Helper loaded: form_helper
INFO - 2016-08-29 11:41:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 11:41:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\mscale_list.php
INFO - 2016-08-29 11:41:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 11:41:00 --> Final output sent to browser
DEBUG - 2016-08-29 11:41:00 --> Total execution time: 0.0596
INFO - 2016-08-29 11:41:35 --> Config Class Initialized
INFO - 2016-08-29 11:41:35 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:41:35 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:41:35 --> Utf8 Class Initialized
INFO - 2016-08-29 11:41:35 --> URI Class Initialized
INFO - 2016-08-29 11:41:35 --> Router Class Initialized
INFO - 2016-08-29 11:41:35 --> Output Class Initialized
INFO - 2016-08-29 11:41:35 --> Security Class Initialized
DEBUG - 2016-08-29 11:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:41:36 --> Input Class Initialized
INFO - 2016-08-29 11:41:36 --> Language Class Initialized
INFO - 2016-08-29 11:41:36 --> Loader Class Initialized
INFO - 2016-08-29 11:41:36 --> Helper loaded: url_helper
INFO - 2016-08-29 11:41:36 --> Helper loaded: language_helper
INFO - 2016-08-29 11:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:41:36 --> Controller Class Initialized
INFO - 2016-08-29 11:41:36 --> Database Driver Class Initialized
INFO - 2016-08-29 11:41:36 --> Model Class Initialized
INFO - 2016-08-29 11:41:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:41:36 --> Helper loaded: form_helper
INFO - 2016-08-29 11:41:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 11:41:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\mscale_list.php
INFO - 2016-08-29 11:41:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 11:41:36 --> Final output sent to browser
DEBUG - 2016-08-29 11:41:36 --> Total execution time: 0.2063
INFO - 2016-08-29 11:43:30 --> Config Class Initialized
INFO - 2016-08-29 11:43:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:43:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:43:30 --> Utf8 Class Initialized
INFO - 2016-08-29 11:43:30 --> URI Class Initialized
INFO - 2016-08-29 11:43:30 --> Router Class Initialized
INFO - 2016-08-29 11:43:30 --> Output Class Initialized
INFO - 2016-08-29 11:43:30 --> Security Class Initialized
DEBUG - 2016-08-29 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:43:30 --> Input Class Initialized
INFO - 2016-08-29 11:43:30 --> Language Class Initialized
INFO - 2016-08-29 11:43:30 --> Loader Class Initialized
INFO - 2016-08-29 11:43:30 --> Helper loaded: url_helper
INFO - 2016-08-29 11:43:30 --> Helper loaded: language_helper
INFO - 2016-08-29 11:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:43:30 --> Controller Class Initialized
INFO - 2016-08-29 11:43:30 --> Database Driver Class Initialized
INFO - 2016-08-29 11:43:30 --> Model Class Initialized
INFO - 2016-08-29 11:43:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:43:30 --> Helper loaded: form_helper
ERROR - 2016-08-29 11:43:30 --> Severity: Notice --> Undefined property: Lscale::$mscale_model C:\wamp64\www\savsoftquiz\application\controllers\Lscale.php 40
ERROR - 2016-08-29 11:43:30 --> Severity: error --> Exception: Call to a member function question_list() on null C:\wamp64\www\savsoftquiz\application\controllers\Lscale.php 40
INFO - 2016-08-29 11:44:09 --> Config Class Initialized
INFO - 2016-08-29 11:44:09 --> Hooks Class Initialized
DEBUG - 2016-08-29 11:44:09 --> UTF-8 Support Enabled
INFO - 2016-08-29 11:44:09 --> Utf8 Class Initialized
INFO - 2016-08-29 11:44:09 --> URI Class Initialized
INFO - 2016-08-29 11:44:09 --> Router Class Initialized
INFO - 2016-08-29 11:44:09 --> Output Class Initialized
INFO - 2016-08-29 11:44:09 --> Security Class Initialized
DEBUG - 2016-08-29 11:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 11:44:09 --> Input Class Initialized
INFO - 2016-08-29 11:44:09 --> Language Class Initialized
INFO - 2016-08-29 11:44:09 --> Loader Class Initialized
INFO - 2016-08-29 11:44:09 --> Helper loaded: url_helper
INFO - 2016-08-29 11:44:09 --> Helper loaded: language_helper
INFO - 2016-08-29 11:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 11:44:09 --> Controller Class Initialized
INFO - 2016-08-29 11:44:09 --> Database Driver Class Initialized
INFO - 2016-08-29 11:44:09 --> Model Class Initialized
INFO - 2016-08-29 11:44:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 11:44:09 --> Helper loaded: form_helper
ERROR - 2016-08-29 11:44:09 --> Severity: Notice --> Undefined property: Lscale::$mscale_model C:\wamp64\www\savsoftquiz\application\controllers\Lscale.php 40
ERROR - 2016-08-29 11:44:09 --> Severity: error --> Exception: Call to a member function question_list() on null C:\wamp64\www\savsoftquiz\application\controllers\Lscale.php 40
INFO - 2016-08-29 12:06:29 --> Config Class Initialized
INFO - 2016-08-29 12:06:29 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:06:29 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:06:29 --> Utf8 Class Initialized
INFO - 2016-08-29 12:06:29 --> URI Class Initialized
INFO - 2016-08-29 12:06:29 --> Router Class Initialized
INFO - 2016-08-29 12:06:29 --> Output Class Initialized
INFO - 2016-08-29 12:06:29 --> Security Class Initialized
DEBUG - 2016-08-29 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:06:29 --> Input Class Initialized
INFO - 2016-08-29 12:06:29 --> Language Class Initialized
INFO - 2016-08-29 12:06:29 --> Loader Class Initialized
INFO - 2016-08-29 12:06:29 --> Helper loaded: url_helper
INFO - 2016-08-29 12:06:29 --> Helper loaded: language_helper
INFO - 2016-08-29 12:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:06:29 --> Controller Class Initialized
INFO - 2016-08-29 12:06:29 --> Database Driver Class Initialized
INFO - 2016-08-29 12:06:29 --> Model Class Initialized
INFO - 2016-08-29 12:06:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:06:29 --> Helper loaded: form_helper
INFO - 2016-08-29 12:06:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:06:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\lscale_list.php
INFO - 2016-08-29 12:06:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:06:29 --> Final output sent to browser
DEBUG - 2016-08-29 12:06:29 --> Total execution time: 0.0675
INFO - 2016-08-29 12:10:44 --> Config Class Initialized
INFO - 2016-08-29 12:10:44 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:10:44 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:10:44 --> Utf8 Class Initialized
INFO - 2016-08-29 12:10:44 --> URI Class Initialized
INFO - 2016-08-29 12:10:44 --> Router Class Initialized
INFO - 2016-08-29 12:10:44 --> Output Class Initialized
INFO - 2016-08-29 12:10:44 --> Security Class Initialized
DEBUG - 2016-08-29 12:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:10:44 --> Input Class Initialized
INFO - 2016-08-29 12:10:44 --> Language Class Initialized
INFO - 2016-08-29 12:10:44 --> Loader Class Initialized
INFO - 2016-08-29 12:10:44 --> Helper loaded: url_helper
INFO - 2016-08-29 12:10:44 --> Helper loaded: language_helper
INFO - 2016-08-29 12:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:10:44 --> Controller Class Initialized
INFO - 2016-08-29 12:10:44 --> Database Driver Class Initialized
INFO - 2016-08-29 12:10:44 --> Model Class Initialized
INFO - 2016-08-29 12:10:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:10:44 --> Helper loaded: form_helper
INFO - 2016-08-29 12:10:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:10:44 --> Could not find the language line "midline_d"
ERROR - 2016-08-29 12:10:44 --> Could not find the language line "midline_i"
ERROR - 2016-08-29 12:10:44 --> Could not find the language line "midline_s"
ERROR - 2016-08-29 12:10:44 --> Could not find the language line "midline_c"
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:44 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_d C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 31
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_i C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 34
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_s C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 37
ERROR - 2016-08-29 12:10:45 --> Severity: Notice --> Undefined index: least_c C:\wamp64\www\savsoftquiz\application\views\cscale_list.php 40
INFO - 2016-08-29 12:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\cscale_list.php
INFO - 2016-08-29 12:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:10:45 --> Final output sent to browser
DEBUG - 2016-08-29 12:10:45 --> Total execution time: 0.4573
INFO - 2016-08-29 12:11:30 --> Config Class Initialized
INFO - 2016-08-29 12:11:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:11:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:11:30 --> Utf8 Class Initialized
INFO - 2016-08-29 12:11:30 --> URI Class Initialized
INFO - 2016-08-29 12:11:30 --> Router Class Initialized
INFO - 2016-08-29 12:11:30 --> Output Class Initialized
INFO - 2016-08-29 12:11:30 --> Security Class Initialized
DEBUG - 2016-08-29 12:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:11:30 --> Input Class Initialized
INFO - 2016-08-29 12:11:30 --> Language Class Initialized
INFO - 2016-08-29 12:11:30 --> Loader Class Initialized
INFO - 2016-08-29 12:11:30 --> Helper loaded: url_helper
INFO - 2016-08-29 12:11:30 --> Helper loaded: language_helper
INFO - 2016-08-29 12:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:11:30 --> Controller Class Initialized
INFO - 2016-08-29 12:11:30 --> Database Driver Class Initialized
INFO - 2016-08-29 12:11:30 --> Model Class Initialized
INFO - 2016-08-29 12:11:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:11:30 --> Helper loaded: form_helper
INFO - 2016-08-29 12:11:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:11:30 --> Could not find the language line "midline_d"
ERROR - 2016-08-29 12:11:30 --> Could not find the language line "midline_i"
ERROR - 2016-08-29 12:11:30 --> Could not find the language line "midline_s"
ERROR - 2016-08-29 12:11:30 --> Could not find the language line "midline_c"
INFO - 2016-08-29 12:11:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\cscale_list.php
INFO - 2016-08-29 12:11:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:11:30 --> Final output sent to browser
DEBUG - 2016-08-29 12:11:30 --> Total execution time: 0.0667
INFO - 2016-08-29 12:17:14 --> Config Class Initialized
INFO - 2016-08-29 12:17:14 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:17:14 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:17:14 --> Utf8 Class Initialized
INFO - 2016-08-29 12:17:14 --> URI Class Initialized
INFO - 2016-08-29 12:17:14 --> Router Class Initialized
INFO - 2016-08-29 12:17:14 --> Output Class Initialized
INFO - 2016-08-29 12:17:14 --> Security Class Initialized
DEBUG - 2016-08-29 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:17:14 --> Input Class Initialized
INFO - 2016-08-29 12:17:14 --> Language Class Initialized
INFO - 2016-08-29 12:17:14 --> Loader Class Initialized
INFO - 2016-08-29 12:17:14 --> Helper loaded: url_helper
INFO - 2016-08-29 12:17:14 --> Helper loaded: language_helper
INFO - 2016-08-29 12:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:17:14 --> Controller Class Initialized
INFO - 2016-08-29 12:17:14 --> Database Driver Class Initialized
INFO - 2016-08-29 12:17:14 --> Model Class Initialized
INFO - 2016-08-29 12:17:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:17:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:17:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\most_statement.php
INFO - 2016-08-29 12:17:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:17:14 --> Final output sent to browser
DEBUG - 2016-08-29 12:17:14 --> Total execution time: 0.0565
INFO - 2016-08-29 12:20:57 --> Config Class Initialized
INFO - 2016-08-29 12:20:57 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:20:57 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:20:57 --> Utf8 Class Initialized
INFO - 2016-08-29 12:20:57 --> URI Class Initialized
INFO - 2016-08-29 12:20:57 --> Router Class Initialized
INFO - 2016-08-29 12:20:57 --> Output Class Initialized
INFO - 2016-08-29 12:20:57 --> Security Class Initialized
DEBUG - 2016-08-29 12:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:20:57 --> Input Class Initialized
INFO - 2016-08-29 12:20:57 --> Language Class Initialized
INFO - 2016-08-29 12:20:57 --> Loader Class Initialized
INFO - 2016-08-29 12:20:57 --> Helper loaded: url_helper
INFO - 2016-08-29 12:20:57 --> Helper loaded: language_helper
INFO - 2016-08-29 12:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:20:57 --> Controller Class Initialized
INFO - 2016-08-29 12:20:57 --> Database Driver Class Initialized
INFO - 2016-08-29 12:20:57 --> Model Class Initialized
INFO - 2016-08-29 12:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\most_statement.php
INFO - 2016-08-29 12:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:20:57 --> Final output sent to browser
DEBUG - 2016-08-29 12:20:57 --> Total execution time: 0.0599
INFO - 2016-08-29 12:25:12 --> Config Class Initialized
INFO - 2016-08-29 12:25:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:25:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:25:12 --> Utf8 Class Initialized
INFO - 2016-08-29 12:25:12 --> URI Class Initialized
INFO - 2016-08-29 12:25:12 --> Router Class Initialized
INFO - 2016-08-29 12:25:12 --> Output Class Initialized
INFO - 2016-08-29 12:25:12 --> Security Class Initialized
DEBUG - 2016-08-29 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:25:12 --> Input Class Initialized
INFO - 2016-08-29 12:25:12 --> Language Class Initialized
ERROR - 2016-08-29 12:25:12 --> 404 Page Not Found: Disc/add_statement
INFO - 2016-08-29 12:25:33 --> Config Class Initialized
INFO - 2016-08-29 12:25:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:25:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:25:33 --> Utf8 Class Initialized
INFO - 2016-08-29 12:25:33 --> URI Class Initialized
INFO - 2016-08-29 12:25:33 --> Router Class Initialized
INFO - 2016-08-29 12:25:33 --> Output Class Initialized
INFO - 2016-08-29 12:25:33 --> Security Class Initialized
DEBUG - 2016-08-29 12:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:25:33 --> Input Class Initialized
INFO - 2016-08-29 12:25:33 --> Language Class Initialized
INFO - 2016-08-29 12:25:33 --> Loader Class Initialized
INFO - 2016-08-29 12:25:33 --> Helper loaded: url_helper
INFO - 2016-08-29 12:25:33 --> Helper loaded: language_helper
INFO - 2016-08-29 12:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:25:33 --> Controller Class Initialized
INFO - 2016-08-29 12:25:33 --> Database Driver Class Initialized
INFO - 2016-08-29 12:25:33 --> Model Class Initialized
INFO - 2016-08-29 12:25:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:25:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:25:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:25:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:25:33 --> Final output sent to browser
DEBUG - 2016-08-29 12:25:33 --> Total execution time: 0.0642
INFO - 2016-08-29 12:33:13 --> Config Class Initialized
INFO - 2016-08-29 12:33:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:33:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:33:13 --> Utf8 Class Initialized
INFO - 2016-08-29 12:33:13 --> URI Class Initialized
INFO - 2016-08-29 12:33:13 --> Router Class Initialized
INFO - 2016-08-29 12:33:13 --> Output Class Initialized
INFO - 2016-08-29 12:33:13 --> Security Class Initialized
DEBUG - 2016-08-29 12:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:33:13 --> Input Class Initialized
INFO - 2016-08-29 12:33:13 --> Language Class Initialized
INFO - 2016-08-29 12:33:13 --> Loader Class Initialized
INFO - 2016-08-29 12:33:13 --> Helper loaded: url_helper
INFO - 2016-08-29 12:33:13 --> Helper loaded: language_helper
INFO - 2016-08-29 12:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:33:13 --> Controller Class Initialized
INFO - 2016-08-29 12:33:13 --> Database Driver Class Initialized
INFO - 2016-08-29 12:33:13 --> Model Class Initialized
INFO - 2016-08-29 12:33:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:33:13 --> Final output sent to browser
DEBUG - 2016-08-29 12:33:13 --> Total execution time: 0.0635
INFO - 2016-08-29 12:33:44 --> Config Class Initialized
INFO - 2016-08-29 12:33:44 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:33:44 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:33:44 --> Utf8 Class Initialized
INFO - 2016-08-29 12:33:44 --> URI Class Initialized
INFO - 2016-08-29 12:33:44 --> Router Class Initialized
INFO - 2016-08-29 12:33:44 --> Output Class Initialized
INFO - 2016-08-29 12:33:44 --> Security Class Initialized
DEBUG - 2016-08-29 12:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:33:44 --> Input Class Initialized
INFO - 2016-08-29 12:33:44 --> Language Class Initialized
INFO - 2016-08-29 12:33:44 --> Loader Class Initialized
INFO - 2016-08-29 12:33:44 --> Helper loaded: url_helper
INFO - 2016-08-29 12:33:44 --> Helper loaded: language_helper
INFO - 2016-08-29 12:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:33:44 --> Controller Class Initialized
INFO - 2016-08-29 12:33:44 --> Database Driver Class Initialized
INFO - 2016-08-29 12:33:44 --> Model Class Initialized
INFO - 2016-08-29 12:33:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:33:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:33:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:33:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:33:44 --> Final output sent to browser
DEBUG - 2016-08-29 12:33:44 --> Total execution time: 0.0525
INFO - 2016-08-29 12:34:54 --> Config Class Initialized
INFO - 2016-08-29 12:34:54 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:34:54 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:34:54 --> Utf8 Class Initialized
INFO - 2016-08-29 12:34:54 --> URI Class Initialized
INFO - 2016-08-29 12:34:54 --> Router Class Initialized
INFO - 2016-08-29 12:34:54 --> Output Class Initialized
INFO - 2016-08-29 12:34:54 --> Security Class Initialized
DEBUG - 2016-08-29 12:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:34:54 --> Input Class Initialized
INFO - 2016-08-29 12:34:54 --> Language Class Initialized
INFO - 2016-08-29 12:34:54 --> Loader Class Initialized
INFO - 2016-08-29 12:34:54 --> Helper loaded: url_helper
INFO - 2016-08-29 12:34:54 --> Helper loaded: language_helper
INFO - 2016-08-29 12:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:34:54 --> Controller Class Initialized
INFO - 2016-08-29 12:34:54 --> Database Driver Class Initialized
INFO - 2016-08-29 12:34:54 --> Model Class Initialized
INFO - 2016-08-29 12:34:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:34:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:34:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:34:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:34:54 --> Final output sent to browser
DEBUG - 2016-08-29 12:34:54 --> Total execution time: 0.0533
INFO - 2016-08-29 12:39:07 --> Config Class Initialized
INFO - 2016-08-29 12:39:07 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:39:07 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:39:07 --> Utf8 Class Initialized
INFO - 2016-08-29 12:39:07 --> URI Class Initialized
INFO - 2016-08-29 12:39:07 --> Router Class Initialized
INFO - 2016-08-29 12:39:07 --> Output Class Initialized
INFO - 2016-08-29 12:39:07 --> Security Class Initialized
DEBUG - 2016-08-29 12:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:39:07 --> Input Class Initialized
INFO - 2016-08-29 12:39:07 --> Language Class Initialized
INFO - 2016-08-29 12:39:07 --> Loader Class Initialized
INFO - 2016-08-29 12:39:07 --> Helper loaded: url_helper
INFO - 2016-08-29 12:39:07 --> Helper loaded: language_helper
INFO - 2016-08-29 12:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:39:07 --> Controller Class Initialized
INFO - 2016-08-29 12:39:07 --> Database Driver Class Initialized
INFO - 2016-08-29 12:39:07 --> Model Class Initialized
INFO - 2016-08-29 12:39:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:39:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:39:07 --> Could not find the language line "least"
INFO - 2016-08-29 12:39:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:39:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:39:07 --> Final output sent to browser
DEBUG - 2016-08-29 12:39:07 --> Total execution time: 0.0702
INFO - 2016-08-29 12:40:48 --> Config Class Initialized
INFO - 2016-08-29 12:40:48 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:40:48 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:40:48 --> Utf8 Class Initialized
INFO - 2016-08-29 12:40:48 --> URI Class Initialized
INFO - 2016-08-29 12:40:48 --> Router Class Initialized
INFO - 2016-08-29 12:40:48 --> Output Class Initialized
INFO - 2016-08-29 12:40:48 --> Security Class Initialized
DEBUG - 2016-08-29 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:40:48 --> Input Class Initialized
INFO - 2016-08-29 12:40:48 --> Language Class Initialized
INFO - 2016-08-29 12:40:48 --> Loader Class Initialized
INFO - 2016-08-29 12:40:48 --> Helper loaded: url_helper
INFO - 2016-08-29 12:40:48 --> Helper loaded: language_helper
INFO - 2016-08-29 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:40:48 --> Controller Class Initialized
INFO - 2016-08-29 12:40:48 --> Database Driver Class Initialized
INFO - 2016-08-29 12:40:48 --> Model Class Initialized
INFO - 2016-08-29 12:40:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:40:48 --> Could not find the language line "least"
INFO - 2016-08-29 12:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:40:48 --> Final output sent to browser
DEBUG - 2016-08-29 12:40:48 --> Total execution time: 0.0530
INFO - 2016-08-29 12:41:19 --> Config Class Initialized
INFO - 2016-08-29 12:41:19 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:41:19 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:41:19 --> Utf8 Class Initialized
INFO - 2016-08-29 12:41:19 --> URI Class Initialized
INFO - 2016-08-29 12:41:19 --> Router Class Initialized
INFO - 2016-08-29 12:41:19 --> Output Class Initialized
INFO - 2016-08-29 12:41:19 --> Security Class Initialized
DEBUG - 2016-08-29 12:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:41:19 --> Input Class Initialized
INFO - 2016-08-29 12:41:19 --> Language Class Initialized
INFO - 2016-08-29 12:41:19 --> Loader Class Initialized
INFO - 2016-08-29 12:41:19 --> Helper loaded: url_helper
INFO - 2016-08-29 12:41:19 --> Helper loaded: language_helper
INFO - 2016-08-29 12:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:41:19 --> Controller Class Initialized
INFO - 2016-08-29 12:41:19 --> Database Driver Class Initialized
INFO - 2016-08-29 12:41:19 --> Model Class Initialized
INFO - 2016-08-29 12:41:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:41:19 --> Could not find the language line "least"
INFO - 2016-08-29 12:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:41:19 --> Final output sent to browser
DEBUG - 2016-08-29 12:41:19 --> Total execution time: 0.0523
INFO - 2016-08-29 12:42:05 --> Config Class Initialized
INFO - 2016-08-29 12:42:05 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:42:05 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:42:05 --> Utf8 Class Initialized
INFO - 2016-08-29 12:42:05 --> URI Class Initialized
INFO - 2016-08-29 12:42:05 --> Router Class Initialized
INFO - 2016-08-29 12:42:05 --> Output Class Initialized
INFO - 2016-08-29 12:42:05 --> Security Class Initialized
DEBUG - 2016-08-29 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:42:05 --> Input Class Initialized
INFO - 2016-08-29 12:42:05 --> Language Class Initialized
INFO - 2016-08-29 12:42:05 --> Loader Class Initialized
INFO - 2016-08-29 12:42:05 --> Helper loaded: url_helper
INFO - 2016-08-29 12:42:05 --> Helper loaded: language_helper
INFO - 2016-08-29 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:42:05 --> Controller Class Initialized
INFO - 2016-08-29 12:42:05 --> Database Driver Class Initialized
INFO - 2016-08-29 12:42:05 --> Model Class Initialized
INFO - 2016-08-29 12:42:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:42:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:42:05 --> Could not find the language line "least"
INFO - 2016-08-29 12:42:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:42:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:42:05 --> Final output sent to browser
DEBUG - 2016-08-29 12:42:05 --> Total execution time: 0.0591
INFO - 2016-08-29 12:42:21 --> Config Class Initialized
INFO - 2016-08-29 12:42:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:42:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:42:21 --> Utf8 Class Initialized
INFO - 2016-08-29 12:42:21 --> URI Class Initialized
INFO - 2016-08-29 12:42:21 --> Router Class Initialized
INFO - 2016-08-29 12:42:21 --> Output Class Initialized
INFO - 2016-08-29 12:42:21 --> Security Class Initialized
DEBUG - 2016-08-29 12:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:42:21 --> Input Class Initialized
INFO - 2016-08-29 12:42:21 --> Language Class Initialized
INFO - 2016-08-29 12:42:21 --> Loader Class Initialized
INFO - 2016-08-29 12:42:21 --> Helper loaded: url_helper
INFO - 2016-08-29 12:42:21 --> Helper loaded: language_helper
INFO - 2016-08-29 12:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:42:21 --> Controller Class Initialized
INFO - 2016-08-29 12:42:21 --> Database Driver Class Initialized
INFO - 2016-08-29 12:42:21 --> Model Class Initialized
INFO - 2016-08-29 12:42:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:42:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:42:21 --> Could not find the language line "least"
INFO - 2016-08-29 12:42:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:42:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:42:21 --> Final output sent to browser
DEBUG - 2016-08-29 12:42:21 --> Total execution time: 0.0564
INFO - 2016-08-29 12:42:36 --> Config Class Initialized
INFO - 2016-08-29 12:42:36 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:42:36 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:42:36 --> Utf8 Class Initialized
INFO - 2016-08-29 12:42:36 --> URI Class Initialized
INFO - 2016-08-29 12:42:36 --> Router Class Initialized
INFO - 2016-08-29 12:42:36 --> Output Class Initialized
INFO - 2016-08-29 12:42:36 --> Security Class Initialized
DEBUG - 2016-08-29 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:42:36 --> Input Class Initialized
INFO - 2016-08-29 12:42:36 --> Language Class Initialized
INFO - 2016-08-29 12:42:36 --> Loader Class Initialized
INFO - 2016-08-29 12:42:36 --> Helper loaded: url_helper
INFO - 2016-08-29 12:42:36 --> Helper loaded: language_helper
INFO - 2016-08-29 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:42:36 --> Controller Class Initialized
INFO - 2016-08-29 12:42:36 --> Database Driver Class Initialized
INFO - 2016-08-29 12:42:36 --> Model Class Initialized
INFO - 2016-08-29 12:42:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:42:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:42:36 --> Could not find the language line "least"
INFO - 2016-08-29 12:42:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:42:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:42:36 --> Final output sent to browser
DEBUG - 2016-08-29 12:42:36 --> Total execution time: 0.0504
INFO - 2016-08-29 12:42:41 --> Config Class Initialized
INFO - 2016-08-29 12:42:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:42:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:42:41 --> Utf8 Class Initialized
INFO - 2016-08-29 12:42:41 --> URI Class Initialized
INFO - 2016-08-29 12:42:41 --> Router Class Initialized
INFO - 2016-08-29 12:42:41 --> Output Class Initialized
INFO - 2016-08-29 12:42:41 --> Security Class Initialized
DEBUG - 2016-08-29 12:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:42:41 --> Input Class Initialized
INFO - 2016-08-29 12:42:41 --> Language Class Initialized
INFO - 2016-08-29 12:42:41 --> Loader Class Initialized
INFO - 2016-08-29 12:42:41 --> Helper loaded: url_helper
INFO - 2016-08-29 12:42:41 --> Helper loaded: language_helper
INFO - 2016-08-29 12:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:42:41 --> Controller Class Initialized
INFO - 2016-08-29 12:42:41 --> Database Driver Class Initialized
INFO - 2016-08-29 12:42:41 --> Model Class Initialized
INFO - 2016-08-29 12:42:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:42:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:42:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2016-08-29 12:42:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:42:41 --> Final output sent to browser
DEBUG - 2016-08-29 12:42:41 --> Total execution time: 0.0646
INFO - 2016-08-29 12:42:41 --> Config Class Initialized
INFO - 2016-08-29 12:42:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:42:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:42:41 --> Utf8 Class Initialized
INFO - 2016-08-29 12:42:41 --> URI Class Initialized
INFO - 2016-08-29 12:42:41 --> Router Class Initialized
INFO - 2016-08-29 12:42:41 --> Output Class Initialized
INFO - 2016-08-29 12:42:41 --> Security Class Initialized
DEBUG - 2016-08-29 12:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:42:41 --> Input Class Initialized
INFO - 2016-08-29 12:42:41 --> Language Class Initialized
INFO - 2016-08-29 12:42:41 --> Loader Class Initialized
INFO - 2016-08-29 12:42:41 --> Helper loaded: url_helper
INFO - 2016-08-29 12:42:41 --> Helper loaded: language_helper
INFO - 2016-08-29 12:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:42:41 --> Controller Class Initialized
INFO - 2016-08-29 12:42:41 --> Database Driver Class Initialized
INFO - 2016-08-29 12:42:41 --> Model Class Initialized
INFO - 2016-08-29 12:42:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:42:41 --> Final output sent to browser
DEBUG - 2016-08-29 12:42:41 --> Total execution time: 0.0751
INFO - 2016-08-29 12:42:49 --> Config Class Initialized
INFO - 2016-08-29 12:42:49 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:42:49 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:42:49 --> Utf8 Class Initialized
INFO - 2016-08-29 12:42:49 --> URI Class Initialized
INFO - 2016-08-29 12:42:49 --> Router Class Initialized
INFO - 2016-08-29 12:42:49 --> Output Class Initialized
INFO - 2016-08-29 12:42:49 --> Security Class Initialized
DEBUG - 2016-08-29 12:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:42:49 --> Input Class Initialized
INFO - 2016-08-29 12:42:49 --> Language Class Initialized
INFO - 2016-08-29 12:42:49 --> Loader Class Initialized
INFO - 2016-08-29 12:42:49 --> Helper loaded: url_helper
INFO - 2016-08-29 12:42:49 --> Helper loaded: language_helper
INFO - 2016-08-29 12:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:42:49 --> Controller Class Initialized
INFO - 2016-08-29 12:42:49 --> Database Driver Class Initialized
INFO - 2016-08-29 12:42:49 --> Model Class Initialized
INFO - 2016-08-29 12:42:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:42:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:42:49 --> Could not find the language line "least"
INFO - 2016-08-29 12:42:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:42:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:42:49 --> Final output sent to browser
DEBUG - 2016-08-29 12:42:49 --> Total execution time: 0.0503
INFO - 2016-08-29 12:43:03 --> Config Class Initialized
INFO - 2016-08-29 12:43:03 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:43:03 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:43:03 --> Utf8 Class Initialized
INFO - 2016-08-29 12:43:03 --> URI Class Initialized
INFO - 2016-08-29 12:43:03 --> Router Class Initialized
INFO - 2016-08-29 12:43:03 --> Output Class Initialized
INFO - 2016-08-29 12:43:03 --> Security Class Initialized
DEBUG - 2016-08-29 12:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:43:03 --> Input Class Initialized
INFO - 2016-08-29 12:43:03 --> Language Class Initialized
INFO - 2016-08-29 12:43:03 --> Loader Class Initialized
INFO - 2016-08-29 12:43:03 --> Helper loaded: url_helper
INFO - 2016-08-29 12:43:03 --> Helper loaded: language_helper
INFO - 2016-08-29 12:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:43:03 --> Controller Class Initialized
INFO - 2016-08-29 12:43:03 --> Database Driver Class Initialized
INFO - 2016-08-29 12:43:03 --> Model Class Initialized
INFO - 2016-08-29 12:43:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:43:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:43:03 --> Could not find the language line "least"
INFO - 2016-08-29 12:43:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:43:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:43:03 --> Final output sent to browser
DEBUG - 2016-08-29 12:43:03 --> Total execution time: 0.0513
INFO - 2016-08-29 12:43:24 --> Config Class Initialized
INFO - 2016-08-29 12:43:24 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:43:24 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:43:24 --> Utf8 Class Initialized
INFO - 2016-08-29 12:43:24 --> URI Class Initialized
INFO - 2016-08-29 12:43:24 --> Router Class Initialized
INFO - 2016-08-29 12:43:24 --> Output Class Initialized
INFO - 2016-08-29 12:43:24 --> Security Class Initialized
DEBUG - 2016-08-29 12:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:43:24 --> Input Class Initialized
INFO - 2016-08-29 12:43:24 --> Language Class Initialized
INFO - 2016-08-29 12:43:24 --> Loader Class Initialized
INFO - 2016-08-29 12:43:24 --> Helper loaded: url_helper
INFO - 2016-08-29 12:43:24 --> Helper loaded: language_helper
INFO - 2016-08-29 12:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:43:24 --> Controller Class Initialized
INFO - 2016-08-29 12:43:24 --> Database Driver Class Initialized
INFO - 2016-08-29 12:43:24 --> Model Class Initialized
INFO - 2016-08-29 12:43:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:43:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:43:24 --> Could not find the language line "least"
INFO - 2016-08-29 12:43:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:43:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:43:24 --> Final output sent to browser
DEBUG - 2016-08-29 12:43:24 --> Total execution time: 0.0542
INFO - 2016-08-29 12:44:05 --> Config Class Initialized
INFO - 2016-08-29 12:44:05 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:44:05 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:44:05 --> Utf8 Class Initialized
INFO - 2016-08-29 12:44:05 --> URI Class Initialized
INFO - 2016-08-29 12:44:05 --> Router Class Initialized
INFO - 2016-08-29 12:44:05 --> Output Class Initialized
INFO - 2016-08-29 12:44:05 --> Security Class Initialized
DEBUG - 2016-08-29 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:44:05 --> Input Class Initialized
INFO - 2016-08-29 12:44:05 --> Language Class Initialized
INFO - 2016-08-29 12:44:06 --> Loader Class Initialized
INFO - 2016-08-29 12:44:06 --> Helper loaded: url_helper
INFO - 2016-08-29 12:44:06 --> Helper loaded: language_helper
INFO - 2016-08-29 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:44:06 --> Controller Class Initialized
INFO - 2016-08-29 12:44:06 --> Database Driver Class Initialized
INFO - 2016-08-29 12:44:06 --> Model Class Initialized
INFO - 2016-08-29 12:44:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:44:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 12:44:06 --> Could not find the language line "least"
INFO - 2016-08-29 12:44:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:44:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:44:06 --> Final output sent to browser
DEBUG - 2016-08-29 12:44:06 --> Total execution time: 0.0530
INFO - 2016-08-29 12:44:23 --> Config Class Initialized
INFO - 2016-08-29 12:44:23 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:44:23 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:44:23 --> Utf8 Class Initialized
INFO - 2016-08-29 12:44:23 --> URI Class Initialized
INFO - 2016-08-29 12:44:23 --> Router Class Initialized
INFO - 2016-08-29 12:44:23 --> Output Class Initialized
INFO - 2016-08-29 12:44:23 --> Security Class Initialized
DEBUG - 2016-08-29 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:44:23 --> Input Class Initialized
INFO - 2016-08-29 12:44:23 --> Language Class Initialized
INFO - 2016-08-29 12:44:23 --> Loader Class Initialized
INFO - 2016-08-29 12:44:23 --> Helper loaded: url_helper
INFO - 2016-08-29 12:44:23 --> Helper loaded: language_helper
INFO - 2016-08-29 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:44:23 --> Controller Class Initialized
INFO - 2016-08-29 12:44:23 --> Database Driver Class Initialized
INFO - 2016-08-29 12:44:23 --> Model Class Initialized
INFO - 2016-08-29 12:44:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:44:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:44:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:44:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:44:23 --> Final output sent to browser
DEBUG - 2016-08-29 12:44:23 --> Total execution time: 0.0646
INFO - 2016-08-29 12:47:42 --> Config Class Initialized
INFO - 2016-08-29 12:47:42 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:47:42 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:47:42 --> Utf8 Class Initialized
INFO - 2016-08-29 12:47:42 --> URI Class Initialized
INFO - 2016-08-29 12:47:42 --> Router Class Initialized
INFO - 2016-08-29 12:47:42 --> Output Class Initialized
INFO - 2016-08-29 12:47:42 --> Security Class Initialized
DEBUG - 2016-08-29 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:47:42 --> Input Class Initialized
INFO - 2016-08-29 12:47:42 --> Language Class Initialized
INFO - 2016-08-29 12:47:42 --> Loader Class Initialized
INFO - 2016-08-29 12:47:42 --> Helper loaded: url_helper
INFO - 2016-08-29 12:47:42 --> Helper loaded: language_helper
INFO - 2016-08-29 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:47:42 --> Controller Class Initialized
INFO - 2016-08-29 12:47:42 --> Database Driver Class Initialized
INFO - 2016-08-29 12:47:42 --> Model Class Initialized
INFO - 2016-08-29 12:47:42 --> Model Class Initialized
INFO - 2016-08-29 12:47:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-08-29 12:47:42 --> Could not find the language line "disc"
INFO - 2016-08-29 12:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:47:42 --> Final output sent to browser
DEBUG - 2016-08-29 12:47:42 --> Total execution time: 0.0597
INFO - 2016-08-29 12:48:25 --> Config Class Initialized
INFO - 2016-08-29 12:48:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:48:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:48:25 --> Utf8 Class Initialized
INFO - 2016-08-29 12:48:25 --> URI Class Initialized
INFO - 2016-08-29 12:48:25 --> Router Class Initialized
INFO - 2016-08-29 12:48:25 --> Output Class Initialized
INFO - 2016-08-29 12:48:25 --> Security Class Initialized
DEBUG - 2016-08-29 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:48:25 --> Input Class Initialized
INFO - 2016-08-29 12:48:25 --> Language Class Initialized
INFO - 2016-08-29 12:48:25 --> Loader Class Initialized
INFO - 2016-08-29 12:48:25 --> Helper loaded: url_helper
INFO - 2016-08-29 12:48:25 --> Helper loaded: language_helper
INFO - 2016-08-29 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:48:25 --> Controller Class Initialized
INFO - 2016-08-29 12:48:25 --> Database Driver Class Initialized
INFO - 2016-08-29 12:48:25 --> Model Class Initialized
INFO - 2016-08-29 12:48:25 --> Model Class Initialized
INFO - 2016-08-29 12:48:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:48:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:48:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:48:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:48:25 --> Final output sent to browser
DEBUG - 2016-08-29 12:48:25 --> Total execution time: 0.0543
INFO - 2016-08-29 12:52:11 --> Config Class Initialized
INFO - 2016-08-29 12:52:11 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:52:11 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:52:11 --> Utf8 Class Initialized
INFO - 2016-08-29 12:52:11 --> URI Class Initialized
INFO - 2016-08-29 12:52:11 --> Router Class Initialized
INFO - 2016-08-29 12:52:11 --> Output Class Initialized
INFO - 2016-08-29 12:52:11 --> Security Class Initialized
DEBUG - 2016-08-29 12:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:52:11 --> Input Class Initialized
INFO - 2016-08-29 12:52:11 --> Language Class Initialized
INFO - 2016-08-29 12:52:11 --> Loader Class Initialized
INFO - 2016-08-29 12:52:11 --> Helper loaded: url_helper
INFO - 2016-08-29 12:52:11 --> Helper loaded: language_helper
INFO - 2016-08-29 12:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:52:11 --> Controller Class Initialized
INFO - 2016-08-29 12:52:11 --> Database Driver Class Initialized
INFO - 2016-08-29 12:52:11 --> Model Class Initialized
INFO - 2016-08-29 12:52:11 --> Model Class Initialized
INFO - 2016-08-29 12:52:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:52:11 --> Final output sent to browser
DEBUG - 2016-08-29 12:52:11 --> Total execution time: 0.0559
INFO - 2016-08-29 12:52:25 --> Config Class Initialized
INFO - 2016-08-29 12:52:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:52:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:52:25 --> Utf8 Class Initialized
INFO - 2016-08-29 12:52:25 --> URI Class Initialized
INFO - 2016-08-29 12:52:25 --> Router Class Initialized
INFO - 2016-08-29 12:52:25 --> Output Class Initialized
INFO - 2016-08-29 12:52:25 --> Security Class Initialized
DEBUG - 2016-08-29 12:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:52:25 --> Input Class Initialized
INFO - 2016-08-29 12:52:25 --> Language Class Initialized
INFO - 2016-08-29 12:52:25 --> Loader Class Initialized
INFO - 2016-08-29 12:52:25 --> Helper loaded: url_helper
INFO - 2016-08-29 12:52:25 --> Helper loaded: language_helper
INFO - 2016-08-29 12:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:52:25 --> Controller Class Initialized
INFO - 2016-08-29 12:52:25 --> Database Driver Class Initialized
INFO - 2016-08-29 12:52:25 --> Model Class Initialized
INFO - 2016-08-29 12:52:25 --> Model Class Initialized
INFO - 2016-08-29 12:52:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:52:25 --> Helper loaded: form_helper
INFO - 2016-08-29 12:52:25 --> Form Validation Class Initialized
INFO - 2016-08-29 12:52:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 12:52:25 --> Config Class Initialized
INFO - 2016-08-29 12:52:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:52:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:52:25 --> Utf8 Class Initialized
INFO - 2016-08-29 12:52:25 --> URI Class Initialized
INFO - 2016-08-29 12:52:25 --> Router Class Initialized
INFO - 2016-08-29 12:52:25 --> Output Class Initialized
INFO - 2016-08-29 12:52:25 --> Security Class Initialized
DEBUG - 2016-08-29 12:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:52:25 --> Input Class Initialized
INFO - 2016-08-29 12:52:25 --> Language Class Initialized
INFO - 2016-08-29 12:52:25 --> Loader Class Initialized
INFO - 2016-08-29 12:52:25 --> Helper loaded: url_helper
INFO - 2016-08-29 12:52:25 --> Helper loaded: language_helper
INFO - 2016-08-29 12:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:52:25 --> Controller Class Initialized
INFO - 2016-08-29 12:52:25 --> Database Driver Class Initialized
INFO - 2016-08-29 12:52:25 --> Model Class Initialized
INFO - 2016-08-29 12:52:25 --> Model Class Initialized
INFO - 2016-08-29 12:52:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:52:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:52:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-08-29 12:52:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:52:25 --> Final output sent to browser
DEBUG - 2016-08-29 12:52:25 --> Total execution time: 0.0569
INFO - 2016-08-29 12:53:48 --> Config Class Initialized
INFO - 2016-08-29 12:53:48 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:53:48 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:53:48 --> Utf8 Class Initialized
INFO - 2016-08-29 12:53:48 --> URI Class Initialized
INFO - 2016-08-29 12:53:48 --> Router Class Initialized
INFO - 2016-08-29 12:53:48 --> Output Class Initialized
INFO - 2016-08-29 12:53:48 --> Security Class Initialized
DEBUG - 2016-08-29 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:53:48 --> Input Class Initialized
INFO - 2016-08-29 12:53:48 --> Language Class Initialized
INFO - 2016-08-29 12:53:48 --> Loader Class Initialized
INFO - 2016-08-29 12:53:48 --> Helper loaded: url_helper
INFO - 2016-08-29 12:53:48 --> Helper loaded: language_helper
INFO - 2016-08-29 12:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:53:48 --> Controller Class Initialized
INFO - 2016-08-29 12:53:48 --> Database Driver Class Initialized
INFO - 2016-08-29 12:53:48 --> Model Class Initialized
INFO - 2016-08-29 12:53:48 --> Model Class Initialized
INFO - 2016-08-29 12:53:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:53:48 --> Final output sent to browser
DEBUG - 2016-08-29 12:53:48 --> Total execution time: 0.0786
INFO - 2016-08-29 12:53:50 --> Config Class Initialized
INFO - 2016-08-29 12:53:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:53:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:53:50 --> Utf8 Class Initialized
INFO - 2016-08-29 12:53:50 --> URI Class Initialized
INFO - 2016-08-29 12:53:50 --> Router Class Initialized
INFO - 2016-08-29 12:53:50 --> Output Class Initialized
INFO - 2016-08-29 12:53:50 --> Security Class Initialized
DEBUG - 2016-08-29 12:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:53:50 --> Input Class Initialized
INFO - 2016-08-29 12:53:50 --> Language Class Initialized
INFO - 2016-08-29 12:53:50 --> Loader Class Initialized
INFO - 2016-08-29 12:53:50 --> Helper loaded: url_helper
INFO - 2016-08-29 12:53:50 --> Helper loaded: language_helper
INFO - 2016-08-29 12:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:53:50 --> Controller Class Initialized
INFO - 2016-08-29 12:53:50 --> Database Driver Class Initialized
INFO - 2016-08-29 12:53:50 --> Model Class Initialized
INFO - 2016-08-29 12:53:50 --> Model Class Initialized
INFO - 2016-08-29 12:53:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:53:50 --> Helper loaded: form_helper
INFO - 2016-08-29 12:53:50 --> Form Validation Class Initialized
INFO - 2016-08-29 12:53:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 12:53:50 --> Config Class Initialized
INFO - 2016-08-29 12:53:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:53:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:53:50 --> Utf8 Class Initialized
INFO - 2016-08-29 12:53:50 --> URI Class Initialized
INFO - 2016-08-29 12:53:50 --> Router Class Initialized
INFO - 2016-08-29 12:53:50 --> Output Class Initialized
INFO - 2016-08-29 12:53:50 --> Security Class Initialized
DEBUG - 2016-08-29 12:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:53:50 --> Input Class Initialized
INFO - 2016-08-29 12:53:50 --> Language Class Initialized
INFO - 2016-08-29 12:53:50 --> Loader Class Initialized
INFO - 2016-08-29 12:53:50 --> Helper loaded: url_helper
INFO - 2016-08-29 12:53:50 --> Helper loaded: language_helper
INFO - 2016-08-29 12:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:53:50 --> Controller Class Initialized
INFO - 2016-08-29 12:53:50 --> Database Driver Class Initialized
INFO - 2016-08-29 12:53:50 --> Model Class Initialized
INFO - 2016-08-29 12:53:50 --> Model Class Initialized
INFO - 2016-08-29 12:53:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:53:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:53:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:53:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:53:50 --> Final output sent to browser
DEBUG - 2016-08-29 12:53:50 --> Total execution time: 0.0548
INFO - 2016-08-29 12:54:32 --> Config Class Initialized
INFO - 2016-08-29 12:54:32 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:54:32 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:54:32 --> Utf8 Class Initialized
INFO - 2016-08-29 12:54:32 --> URI Class Initialized
INFO - 2016-08-29 12:54:32 --> Router Class Initialized
INFO - 2016-08-29 12:54:32 --> Output Class Initialized
INFO - 2016-08-29 12:54:32 --> Security Class Initialized
DEBUG - 2016-08-29 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:54:32 --> Input Class Initialized
INFO - 2016-08-29 12:54:32 --> Language Class Initialized
INFO - 2016-08-29 12:54:32 --> Loader Class Initialized
INFO - 2016-08-29 12:54:32 --> Helper loaded: url_helper
INFO - 2016-08-29 12:54:32 --> Helper loaded: language_helper
INFO - 2016-08-29 12:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:54:32 --> Controller Class Initialized
INFO - 2016-08-29 12:54:32 --> Database Driver Class Initialized
INFO - 2016-08-29 12:54:32 --> Model Class Initialized
INFO - 2016-08-29 12:54:32 --> Model Class Initialized
INFO - 2016-08-29 12:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-29 12:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:54:32 --> Final output sent to browser
DEBUG - 2016-08-29 12:54:32 --> Total execution time: 0.0601
INFO - 2016-08-29 12:54:37 --> Config Class Initialized
INFO - 2016-08-29 12:54:37 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:54:37 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:54:37 --> Utf8 Class Initialized
INFO - 2016-08-29 12:54:37 --> URI Class Initialized
INFO - 2016-08-29 12:54:37 --> Router Class Initialized
INFO - 2016-08-29 12:54:37 --> Output Class Initialized
INFO - 2016-08-29 12:54:37 --> Security Class Initialized
DEBUG - 2016-08-29 12:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:54:37 --> Input Class Initialized
INFO - 2016-08-29 12:54:37 --> Language Class Initialized
INFO - 2016-08-29 12:54:37 --> Loader Class Initialized
INFO - 2016-08-29 12:54:37 --> Helper loaded: url_helper
INFO - 2016-08-29 12:54:37 --> Helper loaded: language_helper
INFO - 2016-08-29 12:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:54:37 --> Controller Class Initialized
INFO - 2016-08-29 12:54:37 --> Database Driver Class Initialized
INFO - 2016-08-29 12:54:37 --> Model Class Initialized
INFO - 2016-08-29 12:54:37 --> Model Class Initialized
INFO - 2016-08-29 12:54:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-08-29 12:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:54:37 --> Final output sent to browser
DEBUG - 2016-08-29 12:54:37 --> Total execution time: 0.0744
INFO - 2016-08-29 12:55:51 --> Config Class Initialized
INFO - 2016-08-29 12:55:51 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:55:51 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:55:51 --> Utf8 Class Initialized
INFO - 2016-08-29 12:55:51 --> URI Class Initialized
INFO - 2016-08-29 12:55:51 --> Router Class Initialized
INFO - 2016-08-29 12:55:51 --> Output Class Initialized
INFO - 2016-08-29 12:55:51 --> Security Class Initialized
DEBUG - 2016-08-29 12:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:55:51 --> Input Class Initialized
INFO - 2016-08-29 12:55:51 --> Language Class Initialized
INFO - 2016-08-29 12:55:51 --> Loader Class Initialized
INFO - 2016-08-29 12:55:51 --> Helper loaded: url_helper
INFO - 2016-08-29 12:55:51 --> Helper loaded: language_helper
INFO - 2016-08-29 12:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:55:51 --> Controller Class Initialized
INFO - 2016-08-29 12:55:51 --> Database Driver Class Initialized
INFO - 2016-08-29 12:55:51 --> Model Class Initialized
INFO - 2016-08-29 12:55:51 --> Model Class Initialized
INFO - 2016-08-29 12:55:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:55:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:55:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:55:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:55:51 --> Final output sent to browser
DEBUG - 2016-08-29 12:55:51 --> Total execution time: 0.0625
INFO - 2016-08-29 12:55:58 --> Config Class Initialized
INFO - 2016-08-29 12:55:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:55:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:55:58 --> Utf8 Class Initialized
INFO - 2016-08-29 12:55:58 --> URI Class Initialized
INFO - 2016-08-29 12:55:58 --> Router Class Initialized
INFO - 2016-08-29 12:55:58 --> Output Class Initialized
INFO - 2016-08-29 12:55:58 --> Security Class Initialized
DEBUG - 2016-08-29 12:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:55:58 --> Input Class Initialized
INFO - 2016-08-29 12:55:58 --> Language Class Initialized
INFO - 2016-08-29 12:55:58 --> Loader Class Initialized
INFO - 2016-08-29 12:55:58 --> Helper loaded: url_helper
INFO - 2016-08-29 12:55:58 --> Helper loaded: language_helper
INFO - 2016-08-29 12:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:55:58 --> Controller Class Initialized
INFO - 2016-08-29 12:55:58 --> Database Driver Class Initialized
INFO - 2016-08-29 12:55:58 --> Model Class Initialized
INFO - 2016-08-29 12:55:58 --> Model Class Initialized
INFO - 2016-08-29 12:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:55:58 --> Final output sent to browser
DEBUG - 2016-08-29 12:55:58 --> Total execution time: 0.0527
INFO - 2016-08-29 12:57:30 --> Config Class Initialized
INFO - 2016-08-29 12:57:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:57:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:57:30 --> Utf8 Class Initialized
INFO - 2016-08-29 12:57:30 --> URI Class Initialized
INFO - 2016-08-29 12:57:30 --> Router Class Initialized
INFO - 2016-08-29 12:57:30 --> Output Class Initialized
INFO - 2016-08-29 12:57:30 --> Security Class Initialized
DEBUG - 2016-08-29 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:57:30 --> Input Class Initialized
INFO - 2016-08-29 12:57:30 --> Language Class Initialized
INFO - 2016-08-29 12:57:30 --> Loader Class Initialized
INFO - 2016-08-29 12:57:30 --> Helper loaded: url_helper
INFO - 2016-08-29 12:57:30 --> Helper loaded: language_helper
INFO - 2016-08-29 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:57:30 --> Controller Class Initialized
INFO - 2016-08-29 12:57:30 --> Database Driver Class Initialized
INFO - 2016-08-29 12:57:30 --> Model Class Initialized
INFO - 2016-08-29 12:57:30 --> Model Class Initialized
INFO - 2016-08-29 12:57:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:57:30 --> Helper loaded: form_helper
INFO - 2016-08-29 12:57:30 --> Form Validation Class Initialized
INFO - 2016-08-29 12:57:30 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-08-29 12:57:30 --> Severity: Notice --> Undefined property: Disc::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\Disc.php 55
ERROR - 2016-08-29 12:57:30 --> Severity: error --> Exception: Call to a member function insert_quiz() on null C:\wamp64\www\savsoftquiz\application\controllers\Disc.php 55
INFO - 2016-08-29 12:57:33 --> Config Class Initialized
INFO - 2016-08-29 12:57:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 12:57:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 12:57:33 --> Utf8 Class Initialized
INFO - 2016-08-29 12:57:33 --> URI Class Initialized
INFO - 2016-08-29 12:57:33 --> Router Class Initialized
INFO - 2016-08-29 12:57:33 --> Output Class Initialized
INFO - 2016-08-29 12:57:33 --> Security Class Initialized
DEBUG - 2016-08-29 12:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 12:57:33 --> Input Class Initialized
INFO - 2016-08-29 12:57:33 --> Language Class Initialized
INFO - 2016-08-29 12:57:33 --> Loader Class Initialized
INFO - 2016-08-29 12:57:33 --> Helper loaded: url_helper
INFO - 2016-08-29 12:57:33 --> Helper loaded: language_helper
INFO - 2016-08-29 12:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 12:57:33 --> Controller Class Initialized
INFO - 2016-08-29 12:57:33 --> Database Driver Class Initialized
INFO - 2016-08-29 12:57:33 --> Model Class Initialized
INFO - 2016-08-29 12:57:33 --> Model Class Initialized
INFO - 2016-08-29 12:57:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 12:57:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 12:57:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 12:57:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 12:57:33 --> Final output sent to browser
DEBUG - 2016-08-29 12:57:33 --> Total execution time: 0.0533
INFO - 2016-08-29 13:00:06 --> Config Class Initialized
INFO - 2016-08-29 13:00:06 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:00:06 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:00:06 --> Utf8 Class Initialized
INFO - 2016-08-29 13:00:06 --> URI Class Initialized
INFO - 2016-08-29 13:00:06 --> Router Class Initialized
INFO - 2016-08-29 13:00:06 --> Output Class Initialized
INFO - 2016-08-29 13:00:06 --> Security Class Initialized
DEBUG - 2016-08-29 13:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:00:06 --> Input Class Initialized
INFO - 2016-08-29 13:00:06 --> Language Class Initialized
INFO - 2016-08-29 13:00:06 --> Loader Class Initialized
INFO - 2016-08-29 13:00:06 --> Helper loaded: url_helper
INFO - 2016-08-29 13:00:06 --> Helper loaded: language_helper
INFO - 2016-08-29 13:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:00:06 --> Controller Class Initialized
INFO - 2016-08-29 13:00:06 --> Database Driver Class Initialized
INFO - 2016-08-29 13:00:06 --> Model Class Initialized
INFO - 2016-08-29 13:00:06 --> Model Class Initialized
INFO - 2016-08-29 13:00:06 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-08-29 13:00:06 --> Severity: error --> Exception: Call to undefined method Disc_model::disc_list() C:\wamp64\www\savsoftquiz\application\controllers\Disc.php 31
INFO - 2016-08-29 13:00:36 --> Config Class Initialized
INFO - 2016-08-29 13:00:36 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:00:36 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:00:36 --> Utf8 Class Initialized
INFO - 2016-08-29 13:00:36 --> URI Class Initialized
INFO - 2016-08-29 13:00:36 --> Router Class Initialized
INFO - 2016-08-29 13:00:36 --> Output Class Initialized
INFO - 2016-08-29 13:00:36 --> Security Class Initialized
DEBUG - 2016-08-29 13:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:00:36 --> Input Class Initialized
INFO - 2016-08-29 13:00:36 --> Language Class Initialized
INFO - 2016-08-29 13:00:36 --> Loader Class Initialized
INFO - 2016-08-29 13:00:36 --> Helper loaded: url_helper
INFO - 2016-08-29 13:00:36 --> Helper loaded: language_helper
INFO - 2016-08-29 13:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:00:36 --> Controller Class Initialized
INFO - 2016-08-29 13:00:36 --> Database Driver Class Initialized
INFO - 2016-08-29 13:00:36 --> Model Class Initialized
INFO - 2016-08-29 13:00:36 --> Model Class Initialized
INFO - 2016-08-29 13:00:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-08-29 13:00:36 --> Query error: Table 'quiz.disc' doesn't exist - Invalid query: SELECT *
FROM `disc`
ORDER BY `disc`.`id` ASC
INFO - 2016-08-29 13:00:36 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-08-29 13:01:03 --> Config Class Initialized
INFO - 2016-08-29 13:01:03 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:01:03 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:01:03 --> Utf8 Class Initialized
INFO - 2016-08-29 13:01:03 --> URI Class Initialized
INFO - 2016-08-29 13:01:03 --> Router Class Initialized
INFO - 2016-08-29 13:01:03 --> Output Class Initialized
INFO - 2016-08-29 13:01:03 --> Security Class Initialized
DEBUG - 2016-08-29 13:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:01:03 --> Input Class Initialized
INFO - 2016-08-29 13:01:03 --> Language Class Initialized
INFO - 2016-08-29 13:01:03 --> Loader Class Initialized
INFO - 2016-08-29 13:01:03 --> Helper loaded: url_helper
INFO - 2016-08-29 13:01:03 --> Helper loaded: language_helper
INFO - 2016-08-29 13:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:01:03 --> Controller Class Initialized
INFO - 2016-08-29 13:01:03 --> Database Driver Class Initialized
INFO - 2016-08-29 13:01:03 --> Model Class Initialized
INFO - 2016-08-29 13:01:03 --> Model Class Initialized
INFO - 2016-08-29 13:01:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:01:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:01:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:01:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:01:03 --> Final output sent to browser
DEBUG - 2016-08-29 13:01:03 --> Total execution time: 0.0572
INFO - 2016-08-29 13:01:12 --> Config Class Initialized
INFO - 2016-08-29 13:01:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:01:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:01:12 --> Utf8 Class Initialized
INFO - 2016-08-29 13:01:12 --> URI Class Initialized
INFO - 2016-08-29 13:01:12 --> Router Class Initialized
INFO - 2016-08-29 13:01:12 --> Output Class Initialized
INFO - 2016-08-29 13:01:12 --> Security Class Initialized
DEBUG - 2016-08-29 13:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:01:12 --> Input Class Initialized
INFO - 2016-08-29 13:01:12 --> Language Class Initialized
INFO - 2016-08-29 13:01:12 --> Loader Class Initialized
INFO - 2016-08-29 13:01:12 --> Helper loaded: url_helper
INFO - 2016-08-29 13:01:12 --> Helper loaded: language_helper
INFO - 2016-08-29 13:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:01:12 --> Controller Class Initialized
INFO - 2016-08-29 13:01:12 --> Database Driver Class Initialized
INFO - 2016-08-29 13:01:12 --> Model Class Initialized
INFO - 2016-08-29 13:01:12 --> Model Class Initialized
INFO - 2016-08-29 13:01:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:01:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:01:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:01:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:01:12 --> Final output sent to browser
DEBUG - 2016-08-29 13:01:12 --> Total execution time: 0.0552
INFO - 2016-08-29 13:13:48 --> Config Class Initialized
INFO - 2016-08-29 13:13:48 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:13:48 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:13:48 --> Utf8 Class Initialized
INFO - 2016-08-29 13:13:48 --> URI Class Initialized
INFO - 2016-08-29 13:13:48 --> Router Class Initialized
INFO - 2016-08-29 13:13:48 --> Output Class Initialized
INFO - 2016-08-29 13:13:48 --> Security Class Initialized
DEBUG - 2016-08-29 13:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:13:48 --> Input Class Initialized
INFO - 2016-08-29 13:13:48 --> Language Class Initialized
INFO - 2016-08-29 13:13:48 --> Loader Class Initialized
INFO - 2016-08-29 13:13:48 --> Helper loaded: url_helper
INFO - 2016-08-29 13:13:48 --> Helper loaded: language_helper
INFO - 2016-08-29 13:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:13:48 --> Controller Class Initialized
INFO - 2016-08-29 13:13:48 --> Database Driver Class Initialized
ERROR - 2016-08-29 13:13:48 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\wamp64\www\savsoftquiz\application\models\Disc_model.php 13
INFO - 2016-08-29 13:14:19 --> Config Class Initialized
INFO - 2016-08-29 13:14:19 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:14:19 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:14:19 --> Utf8 Class Initialized
INFO - 2016-08-29 13:14:19 --> URI Class Initialized
INFO - 2016-08-29 13:14:19 --> Router Class Initialized
INFO - 2016-08-29 13:14:19 --> Output Class Initialized
INFO - 2016-08-29 13:14:19 --> Security Class Initialized
DEBUG - 2016-08-29 13:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:14:19 --> Input Class Initialized
INFO - 2016-08-29 13:14:19 --> Language Class Initialized
INFO - 2016-08-29 13:14:19 --> Loader Class Initialized
INFO - 2016-08-29 13:14:19 --> Helper loaded: url_helper
INFO - 2016-08-29 13:14:19 --> Helper loaded: language_helper
INFO - 2016-08-29 13:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:14:19 --> Controller Class Initialized
INFO - 2016-08-29 13:14:19 --> Database Driver Class Initialized
INFO - 2016-08-29 13:14:19 --> Model Class Initialized
INFO - 2016-08-29 13:14:19 --> Model Class Initialized
INFO - 2016-08-29 13:14:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:14:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:14:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:14:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:14:19 --> Final output sent to browser
DEBUG - 2016-08-29 13:14:19 --> Total execution time: 0.0526
INFO - 2016-08-29 13:16:39 --> Config Class Initialized
INFO - 2016-08-29 13:16:39 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:16:39 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:16:39 --> Utf8 Class Initialized
INFO - 2016-08-29 13:16:39 --> URI Class Initialized
INFO - 2016-08-29 13:16:39 --> Router Class Initialized
INFO - 2016-08-29 13:16:39 --> Output Class Initialized
INFO - 2016-08-29 13:16:39 --> Security Class Initialized
DEBUG - 2016-08-29 13:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:16:39 --> Input Class Initialized
INFO - 2016-08-29 13:16:39 --> Language Class Initialized
INFO - 2016-08-29 13:16:39 --> Loader Class Initialized
INFO - 2016-08-29 13:16:39 --> Helper loaded: url_helper
INFO - 2016-08-29 13:16:39 --> Helper loaded: language_helper
INFO - 2016-08-29 13:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:16:39 --> Controller Class Initialized
INFO - 2016-08-29 13:16:39 --> Database Driver Class Initialized
INFO - 2016-08-29 13:16:39 --> Model Class Initialized
INFO - 2016-08-29 13:16:39 --> Model Class Initialized
INFO - 2016-08-29 13:16:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 13:16:39 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php 19
INFO - 2016-08-29 13:17:16 --> Config Class Initialized
INFO - 2016-08-29 13:17:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:17:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:17:16 --> Utf8 Class Initialized
INFO - 2016-08-29 13:17:16 --> URI Class Initialized
INFO - 2016-08-29 13:17:16 --> Router Class Initialized
INFO - 2016-08-29 13:17:16 --> Output Class Initialized
INFO - 2016-08-29 13:17:16 --> Security Class Initialized
DEBUG - 2016-08-29 13:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:17:16 --> Input Class Initialized
INFO - 2016-08-29 13:17:16 --> Language Class Initialized
INFO - 2016-08-29 13:17:16 --> Loader Class Initialized
INFO - 2016-08-29 13:17:16 --> Helper loaded: url_helper
INFO - 2016-08-29 13:17:16 --> Helper loaded: language_helper
INFO - 2016-08-29 13:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:17:16 --> Controller Class Initialized
INFO - 2016-08-29 13:17:16 --> Database Driver Class Initialized
INFO - 2016-08-29 13:17:16 --> Model Class Initialized
INFO - 2016-08-29 13:17:16 --> Model Class Initialized
INFO - 2016-08-29 13:17:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:17:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 13:17:16 --> Severity: error --> Exception: syntax error, unexpected '<' C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php 19
INFO - 2016-08-29 13:17:24 --> Config Class Initialized
INFO - 2016-08-29 13:17:24 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:17:24 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:17:24 --> Utf8 Class Initialized
INFO - 2016-08-29 13:17:24 --> URI Class Initialized
INFO - 2016-08-29 13:17:24 --> Router Class Initialized
INFO - 2016-08-29 13:17:24 --> Output Class Initialized
INFO - 2016-08-29 13:17:24 --> Security Class Initialized
DEBUG - 2016-08-29 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:17:24 --> Input Class Initialized
INFO - 2016-08-29 13:17:24 --> Language Class Initialized
INFO - 2016-08-29 13:17:24 --> Loader Class Initialized
INFO - 2016-08-29 13:17:24 --> Helper loaded: url_helper
INFO - 2016-08-29 13:17:24 --> Helper loaded: language_helper
INFO - 2016-08-29 13:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:17:24 --> Controller Class Initialized
INFO - 2016-08-29 13:17:24 --> Database Driver Class Initialized
INFO - 2016-08-29 13:17:24 --> Model Class Initialized
INFO - 2016-08-29 13:17:24 --> Model Class Initialized
INFO - 2016-08-29 13:17:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 13:17:24 --> Severity: error --> Exception: syntax error, unexpected '<=' (T_IS_SMALLER_OR_EQUAL) C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php 19
INFO - 2016-08-29 13:17:34 --> Config Class Initialized
INFO - 2016-08-29 13:17:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:17:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:17:34 --> Utf8 Class Initialized
INFO - 2016-08-29 13:17:34 --> URI Class Initialized
INFO - 2016-08-29 13:17:34 --> Router Class Initialized
INFO - 2016-08-29 13:17:34 --> Output Class Initialized
INFO - 2016-08-29 13:17:34 --> Security Class Initialized
DEBUG - 2016-08-29 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:17:34 --> Input Class Initialized
INFO - 2016-08-29 13:17:34 --> Language Class Initialized
INFO - 2016-08-29 13:17:34 --> Loader Class Initialized
INFO - 2016-08-29 13:17:34 --> Helper loaded: url_helper
INFO - 2016-08-29 13:17:34 --> Helper loaded: language_helper
INFO - 2016-08-29 13:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:17:34 --> Controller Class Initialized
INFO - 2016-08-29 13:17:34 --> Database Driver Class Initialized
INFO - 2016-08-29 13:17:34 --> Model Class Initialized
INFO - 2016-08-29 13:17:34 --> Model Class Initialized
INFO - 2016-08-29 13:17:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:17:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:17:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:17:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:17:34 --> Final output sent to browser
DEBUG - 2016-08-29 13:17:34 --> Total execution time: 0.0515
INFO - 2016-08-29 13:18:02 --> Config Class Initialized
INFO - 2016-08-29 13:18:02 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:18:02 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:18:02 --> Utf8 Class Initialized
INFO - 2016-08-29 13:18:02 --> URI Class Initialized
INFO - 2016-08-29 13:18:02 --> Router Class Initialized
INFO - 2016-08-29 13:18:02 --> Output Class Initialized
INFO - 2016-08-29 13:18:02 --> Security Class Initialized
DEBUG - 2016-08-29 13:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:18:02 --> Input Class Initialized
INFO - 2016-08-29 13:18:02 --> Language Class Initialized
INFO - 2016-08-29 13:18:02 --> Loader Class Initialized
INFO - 2016-08-29 13:18:02 --> Helper loaded: url_helper
INFO - 2016-08-29 13:18:02 --> Helper loaded: language_helper
INFO - 2016-08-29 13:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:18:02 --> Controller Class Initialized
INFO - 2016-08-29 13:18:02 --> Database Driver Class Initialized
INFO - 2016-08-29 13:18:02 --> Model Class Initialized
INFO - 2016-08-29 13:18:02 --> Model Class Initialized
INFO - 2016-08-29 13:18:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:18:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:18:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:18:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:18:02 --> Final output sent to browser
DEBUG - 2016-08-29 13:18:02 --> Total execution time: 0.0675
INFO - 2016-08-29 13:18:28 --> Config Class Initialized
INFO - 2016-08-29 13:18:28 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:18:28 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:18:28 --> Utf8 Class Initialized
INFO - 2016-08-29 13:18:28 --> URI Class Initialized
INFO - 2016-08-29 13:18:28 --> Router Class Initialized
INFO - 2016-08-29 13:18:28 --> Output Class Initialized
INFO - 2016-08-29 13:18:28 --> Security Class Initialized
DEBUG - 2016-08-29 13:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:18:28 --> Input Class Initialized
INFO - 2016-08-29 13:18:28 --> Language Class Initialized
INFO - 2016-08-29 13:18:28 --> Loader Class Initialized
INFO - 2016-08-29 13:18:28 --> Helper loaded: url_helper
INFO - 2016-08-29 13:18:28 --> Helper loaded: language_helper
INFO - 2016-08-29 13:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:18:28 --> Controller Class Initialized
INFO - 2016-08-29 13:18:28 --> Database Driver Class Initialized
INFO - 2016-08-29 13:18:28 --> Model Class Initialized
INFO - 2016-08-29 13:18:28 --> Model Class Initialized
INFO - 2016-08-29 13:18:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:18:28 --> Final output sent to browser
DEBUG - 2016-08-29 13:18:28 --> Total execution time: 0.0523
INFO - 2016-08-29 13:18:30 --> Config Class Initialized
INFO - 2016-08-29 13:18:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:18:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:18:30 --> Utf8 Class Initialized
INFO - 2016-08-29 13:18:30 --> URI Class Initialized
INFO - 2016-08-29 13:18:30 --> Router Class Initialized
INFO - 2016-08-29 13:18:30 --> Output Class Initialized
INFO - 2016-08-29 13:18:30 --> Security Class Initialized
DEBUG - 2016-08-29 13:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:18:30 --> Input Class Initialized
INFO - 2016-08-29 13:18:30 --> Language Class Initialized
INFO - 2016-08-29 13:18:30 --> Loader Class Initialized
INFO - 2016-08-29 13:18:30 --> Helper loaded: url_helper
INFO - 2016-08-29 13:18:30 --> Helper loaded: language_helper
INFO - 2016-08-29 13:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:18:30 --> Controller Class Initialized
INFO - 2016-08-29 13:18:30 --> Database Driver Class Initialized
INFO - 2016-08-29 13:18:30 --> Model Class Initialized
INFO - 2016-08-29 13:18:30 --> Model Class Initialized
INFO - 2016-08-29 13:18:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:18:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:18:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:18:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:18:30 --> Final output sent to browser
DEBUG - 2016-08-29 13:18:30 --> Total execution time: 0.0537
INFO - 2016-08-29 13:18:54 --> Config Class Initialized
INFO - 2016-08-29 13:18:54 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:18:54 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:18:54 --> Utf8 Class Initialized
INFO - 2016-08-29 13:18:54 --> URI Class Initialized
INFO - 2016-08-29 13:18:54 --> Router Class Initialized
INFO - 2016-08-29 13:18:54 --> Output Class Initialized
INFO - 2016-08-29 13:18:54 --> Security Class Initialized
DEBUG - 2016-08-29 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:18:54 --> Input Class Initialized
INFO - 2016-08-29 13:18:54 --> Language Class Initialized
INFO - 2016-08-29 13:18:54 --> Loader Class Initialized
INFO - 2016-08-29 13:18:54 --> Helper loaded: url_helper
INFO - 2016-08-29 13:18:54 --> Helper loaded: language_helper
INFO - 2016-08-29 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:18:54 --> Controller Class Initialized
INFO - 2016-08-29 13:18:54 --> Database Driver Class Initialized
INFO - 2016-08-29 13:18:54 --> Model Class Initialized
INFO - 2016-08-29 13:18:54 --> Model Class Initialized
INFO - 2016-08-29 13:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:18:54 --> Final output sent to browser
DEBUG - 2016-08-29 13:18:54 --> Total execution time: 0.0523
INFO - 2016-08-29 13:19:25 --> Config Class Initialized
INFO - 2016-08-29 13:19:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:19:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:19:25 --> Utf8 Class Initialized
INFO - 2016-08-29 13:19:25 --> URI Class Initialized
INFO - 2016-08-29 13:19:25 --> Router Class Initialized
INFO - 2016-08-29 13:19:25 --> Output Class Initialized
INFO - 2016-08-29 13:19:25 --> Security Class Initialized
DEBUG - 2016-08-29 13:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:19:25 --> Input Class Initialized
INFO - 2016-08-29 13:19:25 --> Language Class Initialized
INFO - 2016-08-29 13:19:25 --> Loader Class Initialized
INFO - 2016-08-29 13:19:25 --> Helper loaded: url_helper
INFO - 2016-08-29 13:19:25 --> Helper loaded: language_helper
INFO - 2016-08-29 13:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:19:25 --> Controller Class Initialized
INFO - 2016-08-29 13:19:25 --> Database Driver Class Initialized
INFO - 2016-08-29 13:19:25 --> Model Class Initialized
INFO - 2016-08-29 13:19:25 --> Model Class Initialized
INFO - 2016-08-29 13:19:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:19:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:19:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:19:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:19:25 --> Final output sent to browser
DEBUG - 2016-08-29 13:19:25 --> Total execution time: 0.0508
INFO - 2016-08-29 13:20:44 --> Config Class Initialized
INFO - 2016-08-29 13:20:44 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:20:44 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:20:44 --> Utf8 Class Initialized
INFO - 2016-08-29 13:20:44 --> URI Class Initialized
INFO - 2016-08-29 13:20:44 --> Router Class Initialized
INFO - 2016-08-29 13:20:44 --> Output Class Initialized
INFO - 2016-08-29 13:20:44 --> Security Class Initialized
DEBUG - 2016-08-29 13:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:20:44 --> Input Class Initialized
INFO - 2016-08-29 13:20:44 --> Language Class Initialized
INFO - 2016-08-29 13:20:44 --> Loader Class Initialized
INFO - 2016-08-29 13:20:44 --> Helper loaded: url_helper
INFO - 2016-08-29 13:20:44 --> Helper loaded: language_helper
INFO - 2016-08-29 13:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:20:44 --> Controller Class Initialized
INFO - 2016-08-29 13:20:44 --> Database Driver Class Initialized
INFO - 2016-08-29 13:20:44 --> Model Class Initialized
INFO - 2016-08-29 13:20:44 --> Model Class Initialized
INFO - 2016-08-29 13:20:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 13:20:44 --> Could not find the language line "no_statement"
INFO - 2016-08-29 13:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:20:44 --> Final output sent to browser
DEBUG - 2016-08-29 13:20:44 --> Total execution time: 0.0555
INFO - 2016-08-29 13:20:56 --> Config Class Initialized
INFO - 2016-08-29 13:20:56 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:20:56 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:20:56 --> Utf8 Class Initialized
INFO - 2016-08-29 13:20:56 --> URI Class Initialized
INFO - 2016-08-29 13:20:56 --> Router Class Initialized
INFO - 2016-08-29 13:20:56 --> Output Class Initialized
INFO - 2016-08-29 13:20:56 --> Security Class Initialized
DEBUG - 2016-08-29 13:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:20:56 --> Input Class Initialized
INFO - 2016-08-29 13:20:56 --> Language Class Initialized
INFO - 2016-08-29 13:20:56 --> Loader Class Initialized
INFO - 2016-08-29 13:20:56 --> Helper loaded: url_helper
INFO - 2016-08-29 13:20:56 --> Helper loaded: language_helper
INFO - 2016-08-29 13:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:20:56 --> Controller Class Initialized
INFO - 2016-08-29 13:20:56 --> Database Driver Class Initialized
INFO - 2016-08-29 13:20:56 --> Model Class Initialized
INFO - 2016-08-29 13:20:56 --> Model Class Initialized
INFO - 2016-08-29 13:20:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 13:20:56 --> Could not find the language line "no_statement"
INFO - 2016-08-29 13:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:20:56 --> Final output sent to browser
DEBUG - 2016-08-29 13:20:56 --> Total execution time: 0.0514
INFO - 2016-08-29 13:21:07 --> Config Class Initialized
INFO - 2016-08-29 13:21:07 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:21:07 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:21:07 --> Utf8 Class Initialized
INFO - 2016-08-29 13:21:07 --> URI Class Initialized
INFO - 2016-08-29 13:21:07 --> Router Class Initialized
INFO - 2016-08-29 13:21:07 --> Output Class Initialized
INFO - 2016-08-29 13:21:07 --> Security Class Initialized
DEBUG - 2016-08-29 13:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:21:07 --> Input Class Initialized
INFO - 2016-08-29 13:21:07 --> Language Class Initialized
INFO - 2016-08-29 13:21:07 --> Loader Class Initialized
INFO - 2016-08-29 13:21:07 --> Helper loaded: url_helper
INFO - 2016-08-29 13:21:07 --> Helper loaded: language_helper
INFO - 2016-08-29 13:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:21:07 --> Controller Class Initialized
INFO - 2016-08-29 13:21:07 --> Database Driver Class Initialized
INFO - 2016-08-29 13:21:07 --> Model Class Initialized
INFO - 2016-08-29 13:21:07 --> Model Class Initialized
INFO - 2016-08-29 13:21:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:21:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-08-29 13:21:07 --> Could not find the language line "no_statement"
INFO - 2016-08-29 13:21:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:21:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:21:07 --> Final output sent to browser
DEBUG - 2016-08-29 13:21:07 --> Total execution time: 0.0517
INFO - 2016-08-29 13:21:45 --> Config Class Initialized
INFO - 2016-08-29 13:21:45 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:21:45 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:21:45 --> Utf8 Class Initialized
INFO - 2016-08-29 13:21:45 --> URI Class Initialized
INFO - 2016-08-29 13:21:45 --> Router Class Initialized
INFO - 2016-08-29 13:21:45 --> Output Class Initialized
INFO - 2016-08-29 13:21:45 --> Security Class Initialized
DEBUG - 2016-08-29 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:21:45 --> Input Class Initialized
INFO - 2016-08-29 13:21:45 --> Language Class Initialized
INFO - 2016-08-29 13:21:45 --> Loader Class Initialized
INFO - 2016-08-29 13:21:45 --> Helper loaded: url_helper
INFO - 2016-08-29 13:21:45 --> Helper loaded: language_helper
INFO - 2016-08-29 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:21:45 --> Controller Class Initialized
INFO - 2016-08-29 13:21:45 --> Database Driver Class Initialized
INFO - 2016-08-29 13:21:45 --> Model Class Initialized
INFO - 2016-08-29 13:21:45 --> Model Class Initialized
INFO - 2016-08-29 13:21:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:21:45 --> Final output sent to browser
DEBUG - 2016-08-29 13:21:45 --> Total execution time: 0.0538
INFO - 2016-08-29 13:21:59 --> Config Class Initialized
INFO - 2016-08-29 13:21:59 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:21:59 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:21:59 --> Utf8 Class Initialized
INFO - 2016-08-29 13:21:59 --> URI Class Initialized
INFO - 2016-08-29 13:21:59 --> Router Class Initialized
INFO - 2016-08-29 13:21:59 --> Output Class Initialized
INFO - 2016-08-29 13:21:59 --> Security Class Initialized
DEBUG - 2016-08-29 13:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:21:59 --> Input Class Initialized
INFO - 2016-08-29 13:21:59 --> Language Class Initialized
INFO - 2016-08-29 13:21:59 --> Loader Class Initialized
INFO - 2016-08-29 13:21:59 --> Helper loaded: url_helper
INFO - 2016-08-29 13:21:59 --> Helper loaded: language_helper
INFO - 2016-08-29 13:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:21:59 --> Controller Class Initialized
INFO - 2016-08-29 13:21:59 --> Database Driver Class Initialized
INFO - 2016-08-29 13:21:59 --> Model Class Initialized
INFO - 2016-08-29 13:21:59 --> Model Class Initialized
INFO - 2016-08-29 13:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:21:59 --> Final output sent to browser
DEBUG - 2016-08-29 13:21:59 --> Total execution time: 0.0534
INFO - 2016-08-29 13:22:56 --> Config Class Initialized
INFO - 2016-08-29 13:22:56 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:22:56 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:22:56 --> Utf8 Class Initialized
INFO - 2016-08-29 13:22:56 --> URI Class Initialized
INFO - 2016-08-29 13:22:56 --> Router Class Initialized
INFO - 2016-08-29 13:22:56 --> Output Class Initialized
INFO - 2016-08-29 13:22:56 --> Security Class Initialized
DEBUG - 2016-08-29 13:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:22:56 --> Input Class Initialized
INFO - 2016-08-29 13:22:56 --> Language Class Initialized
INFO - 2016-08-29 13:22:56 --> Loader Class Initialized
INFO - 2016-08-29 13:22:56 --> Helper loaded: url_helper
INFO - 2016-08-29 13:22:56 --> Helper loaded: language_helper
INFO - 2016-08-29 13:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:22:56 --> Controller Class Initialized
INFO - 2016-08-29 13:22:56 --> Database Driver Class Initialized
INFO - 2016-08-29 13:22:56 --> Model Class Initialized
INFO - 2016-08-29 13:22:56 --> Model Class Initialized
INFO - 2016-08-29 13:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:22:56 --> Final output sent to browser
DEBUG - 2016-08-29 13:22:56 --> Total execution time: 0.0520
INFO - 2016-08-29 13:23:33 --> Config Class Initialized
INFO - 2016-08-29 13:23:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:23:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:23:33 --> Utf8 Class Initialized
INFO - 2016-08-29 13:23:33 --> URI Class Initialized
INFO - 2016-08-29 13:23:33 --> Router Class Initialized
INFO - 2016-08-29 13:23:33 --> Output Class Initialized
INFO - 2016-08-29 13:23:33 --> Security Class Initialized
DEBUG - 2016-08-29 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:23:33 --> Input Class Initialized
INFO - 2016-08-29 13:23:33 --> Language Class Initialized
INFO - 2016-08-29 13:23:33 --> Loader Class Initialized
INFO - 2016-08-29 13:23:33 --> Helper loaded: url_helper
INFO - 2016-08-29 13:23:33 --> Helper loaded: language_helper
INFO - 2016-08-29 13:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:23:33 --> Controller Class Initialized
INFO - 2016-08-29 13:23:33 --> Database Driver Class Initialized
INFO - 2016-08-29 13:23:33 --> Model Class Initialized
INFO - 2016-08-29 13:23:33 --> Model Class Initialized
INFO - 2016-08-29 13:23:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:23:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:23:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:23:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:23:33 --> Final output sent to browser
DEBUG - 2016-08-29 13:23:33 --> Total execution time: 0.0521
INFO - 2016-08-29 13:23:50 --> Config Class Initialized
INFO - 2016-08-29 13:23:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:23:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:23:50 --> Utf8 Class Initialized
INFO - 2016-08-29 13:23:50 --> URI Class Initialized
INFO - 2016-08-29 13:23:50 --> Router Class Initialized
INFO - 2016-08-29 13:23:50 --> Output Class Initialized
INFO - 2016-08-29 13:23:50 --> Security Class Initialized
DEBUG - 2016-08-29 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:23:50 --> Input Class Initialized
INFO - 2016-08-29 13:23:50 --> Language Class Initialized
INFO - 2016-08-29 13:23:50 --> Loader Class Initialized
INFO - 2016-08-29 13:23:50 --> Helper loaded: url_helper
INFO - 2016-08-29 13:23:50 --> Helper loaded: language_helper
INFO - 2016-08-29 13:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:23:50 --> Controller Class Initialized
INFO - 2016-08-29 13:23:50 --> Database Driver Class Initialized
INFO - 2016-08-29 13:23:50 --> Model Class Initialized
INFO - 2016-08-29 13:23:50 --> Model Class Initialized
INFO - 2016-08-29 13:23:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:23:50 --> Final output sent to browser
DEBUG - 2016-08-29 13:23:50 --> Total execution time: 0.0526
INFO - 2016-08-29 13:24:11 --> Config Class Initialized
INFO - 2016-08-29 13:24:11 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:24:11 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:24:11 --> Utf8 Class Initialized
INFO - 2016-08-29 13:24:11 --> URI Class Initialized
INFO - 2016-08-29 13:24:11 --> Router Class Initialized
INFO - 2016-08-29 13:24:11 --> Output Class Initialized
INFO - 2016-08-29 13:24:11 --> Security Class Initialized
DEBUG - 2016-08-29 13:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:24:11 --> Input Class Initialized
INFO - 2016-08-29 13:24:11 --> Language Class Initialized
INFO - 2016-08-29 13:24:11 --> Loader Class Initialized
INFO - 2016-08-29 13:24:11 --> Helper loaded: url_helper
INFO - 2016-08-29 13:24:11 --> Helper loaded: language_helper
INFO - 2016-08-29 13:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:24:11 --> Controller Class Initialized
INFO - 2016-08-29 13:24:11 --> Database Driver Class Initialized
INFO - 2016-08-29 13:24:11 --> Model Class Initialized
INFO - 2016-08-29 13:24:11 --> Model Class Initialized
INFO - 2016-08-29 13:24:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:24:11 --> Final output sent to browser
DEBUG - 2016-08-29 13:24:11 --> Total execution time: 0.0555
INFO - 2016-08-29 13:24:59 --> Config Class Initialized
INFO - 2016-08-29 13:24:59 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:24:59 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:24:59 --> Utf8 Class Initialized
INFO - 2016-08-29 13:24:59 --> URI Class Initialized
INFO - 2016-08-29 13:24:59 --> Router Class Initialized
INFO - 2016-08-29 13:24:59 --> Output Class Initialized
INFO - 2016-08-29 13:24:59 --> Security Class Initialized
DEBUG - 2016-08-29 13:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:24:59 --> Input Class Initialized
INFO - 2016-08-29 13:24:59 --> Language Class Initialized
INFO - 2016-08-29 13:24:59 --> Loader Class Initialized
INFO - 2016-08-29 13:24:59 --> Helper loaded: url_helper
INFO - 2016-08-29 13:24:59 --> Helper loaded: language_helper
INFO - 2016-08-29 13:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:24:59 --> Controller Class Initialized
INFO - 2016-08-29 13:24:59 --> Database Driver Class Initialized
INFO - 2016-08-29 13:24:59 --> Model Class Initialized
INFO - 2016-08-29 13:24:59 --> Model Class Initialized
INFO - 2016-08-29 13:24:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:24:59 --> Helper loaded: form_helper
INFO - 2016-08-29 13:24:59 --> Form Validation Class Initialized
INFO - 2016-08-29 13:24:59 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-08-29 13:24:59 --> Severity: error --> Exception: Call to undefined method Disc_model::insert_disc() C:\wamp64\www\savsoftquiz\application\controllers\Disc.php 68
INFO - 2016-08-29 13:25:21 --> Config Class Initialized
INFO - 2016-08-29 13:25:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:25:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:25:21 --> Utf8 Class Initialized
INFO - 2016-08-29 13:25:21 --> URI Class Initialized
INFO - 2016-08-29 13:25:21 --> Router Class Initialized
INFO - 2016-08-29 13:25:21 --> Output Class Initialized
INFO - 2016-08-29 13:25:21 --> Security Class Initialized
DEBUG - 2016-08-29 13:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:25:21 --> Input Class Initialized
INFO - 2016-08-29 13:25:21 --> Language Class Initialized
INFO - 2016-08-29 13:25:21 --> Loader Class Initialized
INFO - 2016-08-29 13:25:21 --> Helper loaded: url_helper
INFO - 2016-08-29 13:25:21 --> Helper loaded: language_helper
INFO - 2016-08-29 13:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:25:21 --> Controller Class Initialized
INFO - 2016-08-29 13:25:21 --> Database Driver Class Initialized
INFO - 2016-08-29 13:25:21 --> Model Class Initialized
INFO - 2016-08-29 13:25:21 --> Model Class Initialized
INFO - 2016-08-29 13:25:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:25:21 --> Helper loaded: form_helper
INFO - 2016-08-29 13:25:21 --> Form Validation Class Initialized
INFO - 2016-08-29 13:25:21 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-08-29 13:25:21 --> Query error: Unknown column 'disc_m_4' in 'field list' - Invalid query: INSERT INTO `disc_statement` (`no_pernyataan`, `disc_m_4`, `disc_l_4`, `statement_4`) VALUES ('1', 'D', 'D', 'Pernyataan 4 Soal 1')
INFO - 2016-08-29 13:25:21 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-08-29 13:26:10 --> Config Class Initialized
INFO - 2016-08-29 13:26:10 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:26:10 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:26:10 --> Utf8 Class Initialized
INFO - 2016-08-29 13:26:10 --> URI Class Initialized
INFO - 2016-08-29 13:26:10 --> Router Class Initialized
INFO - 2016-08-29 13:26:10 --> Output Class Initialized
INFO - 2016-08-29 13:26:10 --> Security Class Initialized
DEBUG - 2016-08-29 13:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:26:10 --> Input Class Initialized
INFO - 2016-08-29 13:26:10 --> Language Class Initialized
INFO - 2016-08-29 13:26:10 --> Loader Class Initialized
INFO - 2016-08-29 13:26:10 --> Helper loaded: url_helper
INFO - 2016-08-29 13:26:10 --> Helper loaded: language_helper
INFO - 2016-08-29 13:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:26:10 --> Controller Class Initialized
INFO - 2016-08-29 13:26:10 --> Database Driver Class Initialized
INFO - 2016-08-29 13:26:10 --> Model Class Initialized
INFO - 2016-08-29 13:26:10 --> Model Class Initialized
INFO - 2016-08-29 13:26:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:26:10 --> Helper loaded: form_helper
INFO - 2016-08-29 13:26:10 --> Form Validation Class Initialized
INFO - 2016-08-29 13:26:10 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 13:26:10 --> Config Class Initialized
INFO - 2016-08-29 13:26:10 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:26:10 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:26:10 --> Utf8 Class Initialized
INFO - 2016-08-29 13:26:10 --> URI Class Initialized
INFO - 2016-08-29 13:26:10 --> Router Class Initialized
INFO - 2016-08-29 13:26:10 --> Output Class Initialized
INFO - 2016-08-29 13:26:10 --> Security Class Initialized
DEBUG - 2016-08-29 13:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:26:10 --> Input Class Initialized
INFO - 2016-08-29 13:26:10 --> Language Class Initialized
INFO - 2016-08-29 13:26:10 --> Loader Class Initialized
INFO - 2016-08-29 13:26:10 --> Helper loaded: url_helper
INFO - 2016-08-29 13:26:10 --> Helper loaded: language_helper
INFO - 2016-08-29 13:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:26:10 --> Controller Class Initialized
INFO - 2016-08-29 13:26:10 --> Database Driver Class Initialized
INFO - 2016-08-29 13:26:10 --> Model Class Initialized
INFO - 2016-08-29 13:26:10 --> Model Class Initialized
INFO - 2016-08-29 13:26:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:26:10 --> Final output sent to browser
DEBUG - 2016-08-29 13:26:10 --> Total execution time: 0.0579
INFO - 2016-08-29 13:29:25 --> Config Class Initialized
INFO - 2016-08-29 13:29:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:29:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:29:25 --> Utf8 Class Initialized
INFO - 2016-08-29 13:29:25 --> URI Class Initialized
INFO - 2016-08-29 13:29:25 --> Router Class Initialized
INFO - 2016-08-29 13:29:25 --> Output Class Initialized
INFO - 2016-08-29 13:29:25 --> Security Class Initialized
DEBUG - 2016-08-29 13:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:29:25 --> Input Class Initialized
INFO - 2016-08-29 13:29:25 --> Language Class Initialized
INFO - 2016-08-29 13:29:25 --> Loader Class Initialized
INFO - 2016-08-29 13:29:25 --> Helper loaded: url_helper
INFO - 2016-08-29 13:29:25 --> Helper loaded: language_helper
INFO - 2016-08-29 13:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:29:25 --> Controller Class Initialized
INFO - 2016-08-29 13:29:25 --> Database Driver Class Initialized
INFO - 2016-08-29 13:29:25 --> Model Class Initialized
INFO - 2016-08-29 13:29:25 --> Model Class Initialized
INFO - 2016-08-29 13:29:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:29:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:29:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:29:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:29:25 --> Final output sent to browser
DEBUG - 2016-08-29 13:29:25 --> Total execution time: 0.0592
INFO - 2016-08-29 13:29:28 --> Config Class Initialized
INFO - 2016-08-29 13:29:28 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:29:28 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:29:28 --> Utf8 Class Initialized
INFO - 2016-08-29 13:29:28 --> URI Class Initialized
INFO - 2016-08-29 13:29:28 --> Router Class Initialized
INFO - 2016-08-29 13:29:28 --> Output Class Initialized
INFO - 2016-08-29 13:29:28 --> Security Class Initialized
DEBUG - 2016-08-29 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:29:28 --> Input Class Initialized
INFO - 2016-08-29 13:29:28 --> Language Class Initialized
INFO - 2016-08-29 13:29:28 --> Loader Class Initialized
INFO - 2016-08-29 13:29:28 --> Helper loaded: url_helper
INFO - 2016-08-29 13:29:28 --> Helper loaded: language_helper
INFO - 2016-08-29 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:29:28 --> Controller Class Initialized
INFO - 2016-08-29 13:29:28 --> Database Driver Class Initialized
INFO - 2016-08-29 13:29:28 --> Model Class Initialized
INFO - 2016-08-29 13:29:28 --> Model Class Initialized
INFO - 2016-08-29 13:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:29:28 --> Helper loaded: form_helper
INFO - 2016-08-29 13:29:28 --> Form Validation Class Initialized
INFO - 2016-08-29 13:29:28 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 13:29:28 --> Config Class Initialized
INFO - 2016-08-29 13:29:28 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:29:28 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:29:28 --> Utf8 Class Initialized
INFO - 2016-08-29 13:29:28 --> URI Class Initialized
INFO - 2016-08-29 13:29:28 --> Router Class Initialized
INFO - 2016-08-29 13:29:28 --> Output Class Initialized
INFO - 2016-08-29 13:29:28 --> Security Class Initialized
DEBUG - 2016-08-29 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:29:28 --> Input Class Initialized
INFO - 2016-08-29 13:29:28 --> Language Class Initialized
INFO - 2016-08-29 13:29:28 --> Loader Class Initialized
INFO - 2016-08-29 13:29:28 --> Helper loaded: url_helper
INFO - 2016-08-29 13:29:28 --> Helper loaded: language_helper
INFO - 2016-08-29 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:29:28 --> Controller Class Initialized
INFO - 2016-08-29 13:29:28 --> Database Driver Class Initialized
INFO - 2016-08-29 13:29:28 --> Model Class Initialized
INFO - 2016-08-29 13:29:28 --> Model Class Initialized
INFO - 2016-08-29 13:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:29:28 --> Final output sent to browser
DEBUG - 2016-08-29 13:29:28 --> Total execution time: 0.0565
INFO - 2016-08-29 13:34:44 --> Config Class Initialized
INFO - 2016-08-29 13:34:44 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:34:44 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:34:44 --> Utf8 Class Initialized
INFO - 2016-08-29 13:34:44 --> URI Class Initialized
INFO - 2016-08-29 13:34:44 --> Router Class Initialized
INFO - 2016-08-29 13:34:44 --> Output Class Initialized
INFO - 2016-08-29 13:34:44 --> Security Class Initialized
DEBUG - 2016-08-29 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:34:44 --> Input Class Initialized
INFO - 2016-08-29 13:34:45 --> Language Class Initialized
INFO - 2016-08-29 13:34:45 --> Loader Class Initialized
INFO - 2016-08-29 13:34:45 --> Helper loaded: url_helper
INFO - 2016-08-29 13:34:45 --> Helper loaded: language_helper
INFO - 2016-08-29 13:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:34:45 --> Controller Class Initialized
INFO - 2016-08-29 13:34:45 --> Database Driver Class Initialized
INFO - 2016-08-29 13:34:45 --> Model Class Initialized
INFO - 2016-08-29 13:34:45 --> Model Class Initialized
INFO - 2016-08-29 13:34:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:34:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:34:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:34:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:34:45 --> Final output sent to browser
DEBUG - 2016-08-29 13:34:45 --> Total execution time: 0.0590
INFO - 2016-08-29 13:35:31 --> Config Class Initialized
INFO - 2016-08-29 13:35:31 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:35:31 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:35:31 --> Utf8 Class Initialized
INFO - 2016-08-29 13:35:31 --> URI Class Initialized
INFO - 2016-08-29 13:35:31 --> Router Class Initialized
INFO - 2016-08-29 13:35:31 --> Output Class Initialized
INFO - 2016-08-29 13:35:31 --> Security Class Initialized
DEBUG - 2016-08-29 13:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:35:31 --> Input Class Initialized
INFO - 2016-08-29 13:35:31 --> Language Class Initialized
INFO - 2016-08-29 13:35:31 --> Loader Class Initialized
INFO - 2016-08-29 13:35:31 --> Helper loaded: url_helper
INFO - 2016-08-29 13:35:31 --> Helper loaded: language_helper
INFO - 2016-08-29 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:35:31 --> Controller Class Initialized
INFO - 2016-08-29 13:35:31 --> Database Driver Class Initialized
INFO - 2016-08-29 13:35:31 --> Model Class Initialized
INFO - 2016-08-29 13:35:31 --> Model Class Initialized
INFO - 2016-08-29 13:35:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:35:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:35:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 13:35:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:35:31 --> Final output sent to browser
DEBUG - 2016-08-29 13:35:31 --> Total execution time: 0.0528
INFO - 2016-08-29 13:37:34 --> Config Class Initialized
INFO - 2016-08-29 13:37:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:37:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:37:34 --> Utf8 Class Initialized
INFO - 2016-08-29 13:37:34 --> URI Class Initialized
INFO - 2016-08-29 13:37:34 --> Router Class Initialized
INFO - 2016-08-29 13:37:34 --> Output Class Initialized
INFO - 2016-08-29 13:37:34 --> Security Class Initialized
DEBUG - 2016-08-29 13:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:37:34 --> Input Class Initialized
INFO - 2016-08-29 13:37:34 --> Language Class Initialized
INFO - 2016-08-29 13:37:34 --> Loader Class Initialized
INFO - 2016-08-29 13:37:34 --> Helper loaded: url_helper
INFO - 2016-08-29 13:37:34 --> Helper loaded: language_helper
INFO - 2016-08-29 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:37:34 --> Controller Class Initialized
INFO - 2016-08-29 13:37:34 --> Database Driver Class Initialized
INFO - 2016-08-29 13:37:34 --> Model Class Initialized
INFO - 2016-08-29 13:37:34 --> Model Class Initialized
INFO - 2016-08-29 13:37:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:37:34 --> Helper loaded: form_helper
INFO - 2016-08-29 13:37:34 --> Form Validation Class Initialized
INFO - 2016-08-29 13:37:34 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 13:37:34 --> Config Class Initialized
INFO - 2016-08-29 13:37:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:37:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:37:34 --> Utf8 Class Initialized
INFO - 2016-08-29 13:37:34 --> URI Class Initialized
INFO - 2016-08-29 13:37:34 --> Router Class Initialized
INFO - 2016-08-29 13:37:34 --> Output Class Initialized
INFO - 2016-08-29 13:37:34 --> Security Class Initialized
DEBUG - 2016-08-29 13:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:37:34 --> Input Class Initialized
INFO - 2016-08-29 13:37:34 --> Language Class Initialized
INFO - 2016-08-29 13:37:34 --> Loader Class Initialized
INFO - 2016-08-29 13:37:34 --> Helper loaded: url_helper
INFO - 2016-08-29 13:37:34 --> Helper loaded: language_helper
INFO - 2016-08-29 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:37:34 --> Controller Class Initialized
INFO - 2016-08-29 13:37:34 --> Database Driver Class Initialized
INFO - 2016-08-29 13:37:34 --> Model Class Initialized
INFO - 2016-08-29 13:37:34 --> Model Class Initialized
INFO - 2016-08-29 13:37:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:37:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:37:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:37:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:37:34 --> Final output sent to browser
DEBUG - 2016-08-29 13:37:34 --> Total execution time: 0.0570
INFO - 2016-08-29 13:39:56 --> Config Class Initialized
INFO - 2016-08-29 13:39:56 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:39:56 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:39:56 --> Utf8 Class Initialized
INFO - 2016-08-29 13:39:56 --> URI Class Initialized
INFO - 2016-08-29 13:39:56 --> Router Class Initialized
INFO - 2016-08-29 13:39:56 --> Output Class Initialized
INFO - 2016-08-29 13:39:56 --> Security Class Initialized
DEBUG - 2016-08-29 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:39:56 --> Input Class Initialized
INFO - 2016-08-29 13:39:56 --> Language Class Initialized
INFO - 2016-08-29 13:39:56 --> Loader Class Initialized
INFO - 2016-08-29 13:39:56 --> Helper loaded: url_helper
INFO - 2016-08-29 13:39:56 --> Helper loaded: language_helper
INFO - 2016-08-29 13:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:39:56 --> Controller Class Initialized
INFO - 2016-08-29 13:39:56 --> Database Driver Class Initialized
INFO - 2016-08-29 13:39:56 --> Model Class Initialized
INFO - 2016-08-29 13:39:57 --> Model Class Initialized
INFO - 2016-08-29 13:39:57 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-08-29 13:39:57 --> Severity: Notice --> Undefined variable: limit C:\wamp64\www\savsoftquiz\application\controllers\Disc.php 28
INFO - 2016-08-29 13:39:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:39:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:39:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:39:57 --> Final output sent to browser
DEBUG - 2016-08-29 13:39:57 --> Total execution time: 0.0630
INFO - 2016-08-29 13:40:22 --> Config Class Initialized
INFO - 2016-08-29 13:40:22 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:40:22 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:40:22 --> Utf8 Class Initialized
INFO - 2016-08-29 13:40:22 --> URI Class Initialized
INFO - 2016-08-29 13:40:22 --> Router Class Initialized
INFO - 2016-08-29 13:40:22 --> Output Class Initialized
INFO - 2016-08-29 13:40:22 --> Security Class Initialized
DEBUG - 2016-08-29 13:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:40:22 --> Input Class Initialized
INFO - 2016-08-29 13:40:22 --> Language Class Initialized
INFO - 2016-08-29 13:40:22 --> Loader Class Initialized
INFO - 2016-08-29 13:40:22 --> Helper loaded: url_helper
INFO - 2016-08-29 13:40:22 --> Helper loaded: language_helper
INFO - 2016-08-29 13:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:40:22 --> Controller Class Initialized
INFO - 2016-08-29 13:40:22 --> Database Driver Class Initialized
INFO - 2016-08-29 13:40:22 --> Model Class Initialized
INFO - 2016-08-29 13:40:22 --> Model Class Initialized
INFO - 2016-08-29 13:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:40:22 --> Final output sent to browser
DEBUG - 2016-08-29 13:40:22 --> Total execution time: 0.0573
INFO - 2016-08-29 13:42:16 --> Config Class Initialized
INFO - 2016-08-29 13:42:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:42:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:42:16 --> Utf8 Class Initialized
INFO - 2016-08-29 13:42:16 --> URI Class Initialized
INFO - 2016-08-29 13:42:16 --> Router Class Initialized
INFO - 2016-08-29 13:42:16 --> Output Class Initialized
INFO - 2016-08-29 13:42:16 --> Security Class Initialized
DEBUG - 2016-08-29 13:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:42:16 --> Input Class Initialized
INFO - 2016-08-29 13:42:16 --> Language Class Initialized
INFO - 2016-08-29 13:42:16 --> Loader Class Initialized
INFO - 2016-08-29 13:42:16 --> Helper loaded: url_helper
INFO - 2016-08-29 13:42:16 --> Helper loaded: language_helper
INFO - 2016-08-29 13:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:42:16 --> Controller Class Initialized
INFO - 2016-08-29 13:42:16 --> Database Driver Class Initialized
INFO - 2016-08-29 13:42:16 --> Model Class Initialized
INFO - 2016-08-29 13:42:16 --> Model Class Initialized
INFO - 2016-08-29 13:42:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:42:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:42:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:42:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:42:16 --> Final output sent to browser
DEBUG - 2016-08-29 13:42:16 --> Total execution time: 0.0548
INFO - 2016-08-29 13:43:13 --> Config Class Initialized
INFO - 2016-08-29 13:43:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:43:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:43:13 --> Utf8 Class Initialized
INFO - 2016-08-29 13:43:13 --> URI Class Initialized
INFO - 2016-08-29 13:43:13 --> Router Class Initialized
INFO - 2016-08-29 13:43:13 --> Output Class Initialized
INFO - 2016-08-29 13:43:13 --> Security Class Initialized
DEBUG - 2016-08-29 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:43:13 --> Input Class Initialized
INFO - 2016-08-29 13:43:13 --> Language Class Initialized
INFO - 2016-08-29 13:43:13 --> Loader Class Initialized
INFO - 2016-08-29 13:43:13 --> Helper loaded: url_helper
INFO - 2016-08-29 13:43:13 --> Helper loaded: language_helper
INFO - 2016-08-29 13:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:43:13 --> Controller Class Initialized
INFO - 2016-08-29 13:43:13 --> Database Driver Class Initialized
INFO - 2016-08-29 13:43:13 --> Model Class Initialized
INFO - 2016-08-29 13:43:13 --> Model Class Initialized
INFO - 2016-08-29 13:43:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:43:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:43:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:43:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:43:13 --> Final output sent to browser
DEBUG - 2016-08-29 13:43:13 --> Total execution time: 0.0542
INFO - 2016-08-29 13:44:05 --> Config Class Initialized
INFO - 2016-08-29 13:44:05 --> Hooks Class Initialized
DEBUG - 2016-08-29 13:44:05 --> UTF-8 Support Enabled
INFO - 2016-08-29 13:44:05 --> Utf8 Class Initialized
INFO - 2016-08-29 13:44:05 --> URI Class Initialized
INFO - 2016-08-29 13:44:05 --> Router Class Initialized
INFO - 2016-08-29 13:44:05 --> Output Class Initialized
INFO - 2016-08-29 13:44:05 --> Security Class Initialized
DEBUG - 2016-08-29 13:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 13:44:05 --> Input Class Initialized
INFO - 2016-08-29 13:44:05 --> Language Class Initialized
INFO - 2016-08-29 13:44:05 --> Loader Class Initialized
INFO - 2016-08-29 13:44:05 --> Helper loaded: url_helper
INFO - 2016-08-29 13:44:05 --> Helper loaded: language_helper
INFO - 2016-08-29 13:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 13:44:05 --> Controller Class Initialized
INFO - 2016-08-29 13:44:05 --> Database Driver Class Initialized
INFO - 2016-08-29 13:44:05 --> Model Class Initialized
INFO - 2016-08-29 13:44:05 --> Model Class Initialized
INFO - 2016-08-29 13:44:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 13:44:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 13:44:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 13:44:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 13:44:05 --> Final output sent to browser
DEBUG - 2016-08-29 13:44:05 --> Total execution time: 0.0546
INFO - 2016-08-29 15:20:56 --> Config Class Initialized
INFO - 2016-08-29 15:20:56 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:20:56 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:20:56 --> Utf8 Class Initialized
INFO - 2016-08-29 15:20:56 --> URI Class Initialized
INFO - 2016-08-29 15:20:56 --> Router Class Initialized
INFO - 2016-08-29 15:20:56 --> Output Class Initialized
INFO - 2016-08-29 15:20:56 --> Security Class Initialized
DEBUG - 2016-08-29 15:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:20:56 --> Input Class Initialized
INFO - 2016-08-29 15:20:56 --> Language Class Initialized
INFO - 2016-08-29 15:20:56 --> Loader Class Initialized
INFO - 2016-08-29 15:20:56 --> Helper loaded: url_helper
INFO - 2016-08-29 15:20:56 --> Helper loaded: language_helper
INFO - 2016-08-29 15:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:20:56 --> Controller Class Initialized
INFO - 2016-08-29 15:20:56 --> Database Driver Class Initialized
INFO - 2016-08-29 15:20:56 --> Model Class Initialized
INFO - 2016-08-29 15:20:56 --> Model Class Initialized
INFO - 2016-08-29 15:20:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:20:56 --> Final output sent to browser
DEBUG - 2016-08-29 15:20:56 --> Total execution time: 0.1056
INFO - 2016-08-29 15:26:03 --> Config Class Initialized
INFO - 2016-08-29 15:26:03 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:26:03 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:26:03 --> Utf8 Class Initialized
INFO - 2016-08-29 15:26:03 --> URI Class Initialized
INFO - 2016-08-29 15:26:03 --> Router Class Initialized
INFO - 2016-08-29 15:26:03 --> Output Class Initialized
INFO - 2016-08-29 15:26:03 --> Security Class Initialized
DEBUG - 2016-08-29 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:26:03 --> Input Class Initialized
INFO - 2016-08-29 15:26:03 --> Language Class Initialized
INFO - 2016-08-29 15:26:03 --> Loader Class Initialized
INFO - 2016-08-29 15:26:03 --> Helper loaded: url_helper
INFO - 2016-08-29 15:26:03 --> Helper loaded: language_helper
INFO - 2016-08-29 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:26:03 --> Controller Class Initialized
INFO - 2016-08-29 15:26:03 --> Database Driver Class Initialized
INFO - 2016-08-29 15:26:03 --> Model Class Initialized
INFO - 2016-08-29 15:26:03 --> Model Class Initialized
INFO - 2016-08-29 15:26:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:26:03 --> Final output sent to browser
DEBUG - 2016-08-29 15:26:03 --> Total execution time: 0.0665
INFO - 2016-08-29 15:26:41 --> Config Class Initialized
INFO - 2016-08-29 15:26:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:26:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:26:41 --> Utf8 Class Initialized
INFO - 2016-08-29 15:26:41 --> URI Class Initialized
INFO - 2016-08-29 15:26:41 --> Router Class Initialized
INFO - 2016-08-29 15:26:41 --> Output Class Initialized
INFO - 2016-08-29 15:26:41 --> Security Class Initialized
DEBUG - 2016-08-29 15:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:26:41 --> Input Class Initialized
INFO - 2016-08-29 15:26:41 --> Language Class Initialized
INFO - 2016-08-29 15:26:41 --> Loader Class Initialized
INFO - 2016-08-29 15:26:41 --> Helper loaded: url_helper
INFO - 2016-08-29 15:26:41 --> Helper loaded: language_helper
INFO - 2016-08-29 15:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:26:41 --> Controller Class Initialized
INFO - 2016-08-29 15:26:41 --> Database Driver Class Initialized
INFO - 2016-08-29 15:26:41 --> Model Class Initialized
INFO - 2016-08-29 15:26:41 --> Model Class Initialized
INFO - 2016-08-29 15:26:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:26:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:26:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 15:26:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:26:41 --> Final output sent to browser
DEBUG - 2016-08-29 15:26:41 --> Total execution time: 0.0715
INFO - 2016-08-29 15:28:13 --> Config Class Initialized
INFO - 2016-08-29 15:28:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:28:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:28:13 --> Utf8 Class Initialized
INFO - 2016-08-29 15:28:13 --> URI Class Initialized
INFO - 2016-08-29 15:28:13 --> Router Class Initialized
INFO - 2016-08-29 15:28:13 --> Output Class Initialized
INFO - 2016-08-29 15:28:13 --> Security Class Initialized
DEBUG - 2016-08-29 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:28:13 --> Input Class Initialized
INFO - 2016-08-29 15:28:13 --> Language Class Initialized
INFO - 2016-08-29 15:28:13 --> Loader Class Initialized
INFO - 2016-08-29 15:28:13 --> Helper loaded: url_helper
INFO - 2016-08-29 15:28:13 --> Helper loaded: language_helper
INFO - 2016-08-29 15:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:28:13 --> Controller Class Initialized
INFO - 2016-08-29 15:28:13 --> Database Driver Class Initialized
INFO - 2016-08-29 15:28:13 --> Model Class Initialized
INFO - 2016-08-29 15:28:13 --> Model Class Initialized
INFO - 2016-08-29 15:28:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:28:13 --> Helper loaded: form_helper
INFO - 2016-08-29 15:28:13 --> Form Validation Class Initialized
INFO - 2016-08-29 15:28:13 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 15:28:13 --> Config Class Initialized
INFO - 2016-08-29 15:28:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:28:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:28:13 --> Utf8 Class Initialized
INFO - 2016-08-29 15:28:13 --> URI Class Initialized
INFO - 2016-08-29 15:28:13 --> Router Class Initialized
INFO - 2016-08-29 15:28:13 --> Output Class Initialized
INFO - 2016-08-29 15:28:13 --> Security Class Initialized
DEBUG - 2016-08-29 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:28:13 --> Input Class Initialized
INFO - 2016-08-29 15:28:13 --> Language Class Initialized
INFO - 2016-08-29 15:28:13 --> Loader Class Initialized
INFO - 2016-08-29 15:28:13 --> Helper loaded: url_helper
INFO - 2016-08-29 15:28:13 --> Helper loaded: language_helper
INFO - 2016-08-29 15:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:28:13 --> Controller Class Initialized
INFO - 2016-08-29 15:28:13 --> Database Driver Class Initialized
INFO - 2016-08-29 15:28:13 --> Model Class Initialized
INFO - 2016-08-29 15:28:13 --> Model Class Initialized
INFO - 2016-08-29 15:28:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:28:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:28:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:28:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:28:13 --> Final output sent to browser
DEBUG - 2016-08-29 15:28:13 --> Total execution time: 0.0590
INFO - 2016-08-29 15:28:19 --> Config Class Initialized
INFO - 2016-08-29 15:28:19 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:28:19 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:28:19 --> Utf8 Class Initialized
INFO - 2016-08-29 15:28:19 --> URI Class Initialized
INFO - 2016-08-29 15:28:19 --> Router Class Initialized
INFO - 2016-08-29 15:28:19 --> Output Class Initialized
INFO - 2016-08-29 15:28:19 --> Security Class Initialized
DEBUG - 2016-08-29 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:28:19 --> Input Class Initialized
INFO - 2016-08-29 15:28:19 --> Language Class Initialized
INFO - 2016-08-29 15:28:19 --> Loader Class Initialized
INFO - 2016-08-29 15:28:19 --> Helper loaded: url_helper
INFO - 2016-08-29 15:28:19 --> Helper loaded: language_helper
INFO - 2016-08-29 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:28:19 --> Controller Class Initialized
INFO - 2016-08-29 15:28:19 --> Database Driver Class Initialized
INFO - 2016-08-29 15:28:19 --> Model Class Initialized
INFO - 2016-08-29 15:28:19 --> Model Class Initialized
INFO - 2016-08-29 15:28:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:28:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:28:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 15:28:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:28:19 --> Final output sent to browser
DEBUG - 2016-08-29 15:28:19 --> Total execution time: 0.0505
INFO - 2016-08-29 15:29:12 --> Config Class Initialized
INFO - 2016-08-29 15:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:29:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:29:12 --> Utf8 Class Initialized
INFO - 2016-08-29 15:29:12 --> URI Class Initialized
INFO - 2016-08-29 15:29:12 --> Router Class Initialized
INFO - 2016-08-29 15:29:12 --> Output Class Initialized
INFO - 2016-08-29 15:29:12 --> Security Class Initialized
DEBUG - 2016-08-29 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:29:12 --> Input Class Initialized
INFO - 2016-08-29 15:29:12 --> Language Class Initialized
INFO - 2016-08-29 15:29:12 --> Loader Class Initialized
INFO - 2016-08-29 15:29:12 --> Helper loaded: url_helper
INFO - 2016-08-29 15:29:12 --> Helper loaded: language_helper
INFO - 2016-08-29 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:29:12 --> Controller Class Initialized
INFO - 2016-08-29 15:29:12 --> Database Driver Class Initialized
INFO - 2016-08-29 15:29:12 --> Model Class Initialized
INFO - 2016-08-29 15:29:12 --> Model Class Initialized
INFO - 2016-08-29 15:29:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:29:12 --> Helper loaded: form_helper
INFO - 2016-08-29 15:29:12 --> Form Validation Class Initialized
INFO - 2016-08-29 15:29:12 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 15:29:12 --> Config Class Initialized
INFO - 2016-08-29 15:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:29:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:29:12 --> Utf8 Class Initialized
INFO - 2016-08-29 15:29:12 --> URI Class Initialized
INFO - 2016-08-29 15:29:12 --> Router Class Initialized
INFO - 2016-08-29 15:29:12 --> Output Class Initialized
INFO - 2016-08-29 15:29:12 --> Security Class Initialized
DEBUG - 2016-08-29 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:29:12 --> Input Class Initialized
INFO - 2016-08-29 15:29:12 --> Language Class Initialized
INFO - 2016-08-29 15:29:12 --> Loader Class Initialized
INFO - 2016-08-29 15:29:12 --> Helper loaded: url_helper
INFO - 2016-08-29 15:29:12 --> Helper loaded: language_helper
INFO - 2016-08-29 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:29:12 --> Controller Class Initialized
INFO - 2016-08-29 15:29:12 --> Database Driver Class Initialized
INFO - 2016-08-29 15:29:12 --> Model Class Initialized
INFO - 2016-08-29 15:29:12 --> Model Class Initialized
INFO - 2016-08-29 15:29:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:29:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:29:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:29:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:29:12 --> Final output sent to browser
DEBUG - 2016-08-29 15:29:12 --> Total execution time: 0.0585
INFO - 2016-08-29 15:29:53 --> Config Class Initialized
INFO - 2016-08-29 15:29:53 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:29:53 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:29:53 --> Utf8 Class Initialized
INFO - 2016-08-29 15:29:53 --> URI Class Initialized
INFO - 2016-08-29 15:29:53 --> Router Class Initialized
INFO - 2016-08-29 15:29:53 --> Output Class Initialized
INFO - 2016-08-29 15:29:53 --> Security Class Initialized
DEBUG - 2016-08-29 15:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:29:53 --> Input Class Initialized
INFO - 2016-08-29 15:29:53 --> Language Class Initialized
INFO - 2016-08-29 15:29:53 --> Loader Class Initialized
INFO - 2016-08-29 15:29:53 --> Helper loaded: url_helper
INFO - 2016-08-29 15:29:53 --> Helper loaded: language_helper
INFO - 2016-08-29 15:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:29:53 --> Controller Class Initialized
INFO - 2016-08-29 15:29:53 --> Database Driver Class Initialized
INFO - 2016-08-29 15:29:53 --> Model Class Initialized
INFO - 2016-08-29 15:29:53 --> Model Class Initialized
INFO - 2016-08-29 15:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:29:53 --> Final output sent to browser
DEBUG - 2016-08-29 15:29:53 --> Total execution time: 0.0659
INFO - 2016-08-29 15:30:50 --> Config Class Initialized
INFO - 2016-08-29 15:30:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:30:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:30:50 --> Utf8 Class Initialized
INFO - 2016-08-29 15:30:50 --> URI Class Initialized
INFO - 2016-08-29 15:30:50 --> Router Class Initialized
INFO - 2016-08-29 15:30:50 --> Output Class Initialized
INFO - 2016-08-29 15:30:50 --> Security Class Initialized
DEBUG - 2016-08-29 15:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:30:50 --> Input Class Initialized
INFO - 2016-08-29 15:30:50 --> Language Class Initialized
INFO - 2016-08-29 15:30:50 --> Loader Class Initialized
INFO - 2016-08-29 15:30:50 --> Helper loaded: url_helper
INFO - 2016-08-29 15:30:50 --> Helper loaded: language_helper
INFO - 2016-08-29 15:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:30:50 --> Controller Class Initialized
INFO - 2016-08-29 15:30:50 --> Database Driver Class Initialized
INFO - 2016-08-29 15:30:50 --> Model Class Initialized
INFO - 2016-08-29 15:30:50 --> Model Class Initialized
INFO - 2016-08-29 15:30:50 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-08-29 15:30:50 --> Severity: Warning --> Missing argument 1 for Disc_model::disc_list_by_no(), called in C:\wamp64\www\savsoftquiz\application\controllers\Disc.php on line 31 and defined C:\wamp64\www\savsoftquiz\application\models\Disc_model.php 12
INFO - 2016-08-29 15:30:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:30:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:30:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:30:50 --> Final output sent to browser
DEBUG - 2016-08-29 15:30:50 --> Total execution time: 0.0725
INFO - 2016-08-29 15:31:18 --> Config Class Initialized
INFO - 2016-08-29 15:31:18 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:31:18 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:31:18 --> Utf8 Class Initialized
INFO - 2016-08-29 15:31:18 --> URI Class Initialized
INFO - 2016-08-29 15:31:18 --> Router Class Initialized
INFO - 2016-08-29 15:31:18 --> Output Class Initialized
INFO - 2016-08-29 15:31:18 --> Security Class Initialized
DEBUG - 2016-08-29 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:31:18 --> Input Class Initialized
INFO - 2016-08-29 15:31:18 --> Language Class Initialized
INFO - 2016-08-29 15:31:18 --> Loader Class Initialized
INFO - 2016-08-29 15:31:18 --> Helper loaded: url_helper
INFO - 2016-08-29 15:31:18 --> Helper loaded: language_helper
INFO - 2016-08-29 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:31:18 --> Controller Class Initialized
INFO - 2016-08-29 15:31:18 --> Database Driver Class Initialized
INFO - 2016-08-29 15:31:18 --> Model Class Initialized
INFO - 2016-08-29 15:31:18 --> Model Class Initialized
INFO - 2016-08-29 15:31:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:31:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:31:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:31:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:31:18 --> Final output sent to browser
DEBUG - 2016-08-29 15:31:18 --> Total execution time: 0.0703
INFO - 2016-08-29 15:31:26 --> Config Class Initialized
INFO - 2016-08-29 15:31:26 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:31:26 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:31:26 --> Utf8 Class Initialized
INFO - 2016-08-29 15:31:26 --> URI Class Initialized
INFO - 2016-08-29 15:31:26 --> Router Class Initialized
INFO - 2016-08-29 15:31:26 --> Output Class Initialized
INFO - 2016-08-29 15:31:26 --> Security Class Initialized
DEBUG - 2016-08-29 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:31:26 --> Input Class Initialized
INFO - 2016-08-29 15:31:26 --> Language Class Initialized
INFO - 2016-08-29 15:31:26 --> Loader Class Initialized
INFO - 2016-08-29 15:31:26 --> Helper loaded: url_helper
INFO - 2016-08-29 15:31:26 --> Helper loaded: language_helper
INFO - 2016-08-29 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:31:26 --> Controller Class Initialized
INFO - 2016-08-29 15:31:26 --> Database Driver Class Initialized
INFO - 2016-08-29 15:31:26 --> Model Class Initialized
INFO - 2016-08-29 15:31:26 --> Model Class Initialized
INFO - 2016-08-29 15:31:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:31:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:31:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:31:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:31:26 --> Final output sent to browser
DEBUG - 2016-08-29 15:31:26 --> Total execution time: 0.0659
INFO - 2016-08-29 15:35:21 --> Config Class Initialized
INFO - 2016-08-29 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:35:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:35:21 --> Utf8 Class Initialized
INFO - 2016-08-29 15:35:21 --> URI Class Initialized
INFO - 2016-08-29 15:35:21 --> Router Class Initialized
INFO - 2016-08-29 15:35:21 --> Output Class Initialized
INFO - 2016-08-29 15:35:21 --> Security Class Initialized
DEBUG - 2016-08-29 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:35:21 --> Input Class Initialized
INFO - 2016-08-29 15:35:21 --> Language Class Initialized
INFO - 2016-08-29 15:35:21 --> Loader Class Initialized
INFO - 2016-08-29 15:35:21 --> Helper loaded: url_helper
INFO - 2016-08-29 15:35:21 --> Helper loaded: language_helper
INFO - 2016-08-29 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:35:21 --> Controller Class Initialized
INFO - 2016-08-29 15:35:21 --> Database Driver Class Initialized
INFO - 2016-08-29 15:35:21 --> Model Class Initialized
INFO - 2016-08-29 15:35:21 --> Model Class Initialized
INFO - 2016-08-29 15:35:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:35:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:35:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:35:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:35:21 --> Final output sent to browser
DEBUG - 2016-08-29 15:35:21 --> Total execution time: 0.0642
INFO - 2016-08-29 15:36:30 --> Config Class Initialized
INFO - 2016-08-29 15:36:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:36:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:36:30 --> Utf8 Class Initialized
INFO - 2016-08-29 15:36:30 --> URI Class Initialized
INFO - 2016-08-29 15:36:30 --> Router Class Initialized
INFO - 2016-08-29 15:36:30 --> Output Class Initialized
INFO - 2016-08-29 15:36:30 --> Security Class Initialized
DEBUG - 2016-08-29 15:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:36:30 --> Input Class Initialized
INFO - 2016-08-29 15:36:30 --> Language Class Initialized
INFO - 2016-08-29 15:36:30 --> Loader Class Initialized
INFO - 2016-08-29 15:36:30 --> Helper loaded: url_helper
INFO - 2016-08-29 15:36:30 --> Helper loaded: language_helper
INFO - 2016-08-29 15:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:36:30 --> Controller Class Initialized
INFO - 2016-08-29 15:36:30 --> Database Driver Class Initialized
INFO - 2016-08-29 15:36:30 --> Model Class Initialized
INFO - 2016-08-29 15:36:30 --> Model Class Initialized
INFO - 2016-08-29 15:36:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:36:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:36:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:36:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:36:30 --> Final output sent to browser
DEBUG - 2016-08-29 15:36:30 --> Total execution time: 0.0566
INFO - 2016-08-29 15:36:49 --> Config Class Initialized
INFO - 2016-08-29 15:36:49 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:36:49 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:36:49 --> Utf8 Class Initialized
INFO - 2016-08-29 15:36:49 --> URI Class Initialized
INFO - 2016-08-29 15:36:49 --> Router Class Initialized
INFO - 2016-08-29 15:36:49 --> Output Class Initialized
INFO - 2016-08-29 15:36:49 --> Security Class Initialized
DEBUG - 2016-08-29 15:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:36:49 --> Input Class Initialized
INFO - 2016-08-29 15:36:49 --> Language Class Initialized
INFO - 2016-08-29 15:36:49 --> Loader Class Initialized
INFO - 2016-08-29 15:36:49 --> Helper loaded: url_helper
INFO - 2016-08-29 15:36:49 --> Helper loaded: language_helper
INFO - 2016-08-29 15:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:36:49 --> Controller Class Initialized
INFO - 2016-08-29 15:36:49 --> Database Driver Class Initialized
INFO - 2016-08-29 15:36:49 --> Model Class Initialized
INFO - 2016-08-29 15:36:49 --> Model Class Initialized
INFO - 2016-08-29 15:36:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:36:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:36:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:36:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:36:49 --> Final output sent to browser
DEBUG - 2016-08-29 15:36:49 --> Total execution time: 0.0573
INFO - 2016-08-29 15:37:15 --> Config Class Initialized
INFO - 2016-08-29 15:37:15 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:37:15 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:37:15 --> Utf8 Class Initialized
INFO - 2016-08-29 15:37:15 --> URI Class Initialized
INFO - 2016-08-29 15:37:15 --> Router Class Initialized
INFO - 2016-08-29 15:37:15 --> Output Class Initialized
INFO - 2016-08-29 15:37:15 --> Security Class Initialized
DEBUG - 2016-08-29 15:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:37:15 --> Input Class Initialized
INFO - 2016-08-29 15:37:15 --> Language Class Initialized
INFO - 2016-08-29 15:37:15 --> Loader Class Initialized
INFO - 2016-08-29 15:37:15 --> Helper loaded: url_helper
INFO - 2016-08-29 15:37:15 --> Helper loaded: language_helper
INFO - 2016-08-29 15:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:37:15 --> Controller Class Initialized
INFO - 2016-08-29 15:37:15 --> Database Driver Class Initialized
INFO - 2016-08-29 15:37:15 --> Model Class Initialized
INFO - 2016-08-29 15:37:15 --> Model Class Initialized
INFO - 2016-08-29 15:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:37:15 --> Final output sent to browser
DEBUG - 2016-08-29 15:37:15 --> Total execution time: 0.0581
INFO - 2016-08-29 15:39:05 --> Config Class Initialized
INFO - 2016-08-29 15:39:05 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:39:05 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:39:05 --> Utf8 Class Initialized
INFO - 2016-08-29 15:39:05 --> URI Class Initialized
INFO - 2016-08-29 15:39:05 --> Router Class Initialized
INFO - 2016-08-29 15:39:05 --> Output Class Initialized
INFO - 2016-08-29 15:39:05 --> Security Class Initialized
DEBUG - 2016-08-29 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:39:05 --> Input Class Initialized
INFO - 2016-08-29 15:39:05 --> Language Class Initialized
INFO - 2016-08-29 15:39:05 --> Loader Class Initialized
INFO - 2016-08-29 15:39:05 --> Helper loaded: url_helper
INFO - 2016-08-29 15:39:05 --> Helper loaded: language_helper
INFO - 2016-08-29 15:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:39:05 --> Controller Class Initialized
INFO - 2016-08-29 15:39:05 --> Database Driver Class Initialized
INFO - 2016-08-29 15:39:05 --> Model Class Initialized
INFO - 2016-08-29 15:39:05 --> Model Class Initialized
INFO - 2016-08-29 15:39:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:39:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:39:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:39:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:39:05 --> Final output sent to browser
DEBUG - 2016-08-29 15:39:05 --> Total execution time: 0.0589
INFO - 2016-08-29 15:39:53 --> Config Class Initialized
INFO - 2016-08-29 15:39:53 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:39:53 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:39:53 --> Utf8 Class Initialized
INFO - 2016-08-29 15:39:53 --> URI Class Initialized
INFO - 2016-08-29 15:39:53 --> Router Class Initialized
INFO - 2016-08-29 15:39:53 --> Output Class Initialized
INFO - 2016-08-29 15:39:53 --> Security Class Initialized
DEBUG - 2016-08-29 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:39:53 --> Input Class Initialized
INFO - 2016-08-29 15:39:53 --> Language Class Initialized
INFO - 2016-08-29 15:39:53 --> Loader Class Initialized
INFO - 2016-08-29 15:39:53 --> Helper loaded: url_helper
INFO - 2016-08-29 15:39:53 --> Helper loaded: language_helper
INFO - 2016-08-29 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:39:53 --> Controller Class Initialized
INFO - 2016-08-29 15:39:53 --> Database Driver Class Initialized
INFO - 2016-08-29 15:39:53 --> Model Class Initialized
INFO - 2016-08-29 15:39:53 --> Model Class Initialized
INFO - 2016-08-29 15:39:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:39:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:39:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:39:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:39:53 --> Final output sent to browser
DEBUG - 2016-08-29 15:39:53 --> Total execution time: 0.0706
INFO - 2016-08-29 15:41:31 --> Config Class Initialized
INFO - 2016-08-29 15:41:31 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:41:31 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:41:31 --> Utf8 Class Initialized
INFO - 2016-08-29 15:41:31 --> URI Class Initialized
INFO - 2016-08-29 15:41:31 --> Router Class Initialized
INFO - 2016-08-29 15:41:31 --> Output Class Initialized
INFO - 2016-08-29 15:41:31 --> Security Class Initialized
DEBUG - 2016-08-29 15:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:41:31 --> Input Class Initialized
INFO - 2016-08-29 15:41:31 --> Language Class Initialized
INFO - 2016-08-29 15:41:31 --> Loader Class Initialized
INFO - 2016-08-29 15:41:31 --> Helper loaded: url_helper
INFO - 2016-08-29 15:41:31 --> Helper loaded: language_helper
INFO - 2016-08-29 15:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:41:31 --> Controller Class Initialized
INFO - 2016-08-29 15:41:31 --> Database Driver Class Initialized
INFO - 2016-08-29 15:41:31 --> Model Class Initialized
INFO - 2016-08-29 15:41:31 --> Model Class Initialized
INFO - 2016-08-29 15:41:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:41:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:41:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:41:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:41:31 --> Final output sent to browser
DEBUG - 2016-08-29 15:41:31 --> Total execution time: 0.0634
INFO - 2016-08-29 15:42:02 --> Config Class Initialized
INFO - 2016-08-29 15:42:02 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:42:02 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:42:02 --> Utf8 Class Initialized
INFO - 2016-08-29 15:42:02 --> URI Class Initialized
INFO - 2016-08-29 15:42:02 --> Router Class Initialized
INFO - 2016-08-29 15:42:02 --> Output Class Initialized
INFO - 2016-08-29 15:42:02 --> Security Class Initialized
DEBUG - 2016-08-29 15:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:42:02 --> Input Class Initialized
INFO - 2016-08-29 15:42:02 --> Language Class Initialized
INFO - 2016-08-29 15:42:02 --> Loader Class Initialized
INFO - 2016-08-29 15:42:02 --> Helper loaded: url_helper
INFO - 2016-08-29 15:42:02 --> Helper loaded: language_helper
INFO - 2016-08-29 15:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:42:02 --> Controller Class Initialized
INFO - 2016-08-29 15:42:02 --> Database Driver Class Initialized
INFO - 2016-08-29 15:42:02 --> Model Class Initialized
INFO - 2016-08-29 15:42:02 --> Model Class Initialized
INFO - 2016-08-29 15:42:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:42:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:42:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:42:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:42:02 --> Final output sent to browser
DEBUG - 2016-08-29 15:42:02 --> Total execution time: 0.0579
INFO - 2016-08-29 15:42:37 --> Config Class Initialized
INFO - 2016-08-29 15:42:37 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:42:37 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:42:37 --> Utf8 Class Initialized
INFO - 2016-08-29 15:42:37 --> URI Class Initialized
INFO - 2016-08-29 15:42:37 --> Router Class Initialized
INFO - 2016-08-29 15:42:37 --> Output Class Initialized
INFO - 2016-08-29 15:42:37 --> Security Class Initialized
DEBUG - 2016-08-29 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:42:37 --> Input Class Initialized
INFO - 2016-08-29 15:42:37 --> Language Class Initialized
INFO - 2016-08-29 15:42:37 --> Loader Class Initialized
INFO - 2016-08-29 15:42:37 --> Helper loaded: url_helper
INFO - 2016-08-29 15:42:37 --> Helper loaded: language_helper
INFO - 2016-08-29 15:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:42:37 --> Controller Class Initialized
INFO - 2016-08-29 15:42:37 --> Database Driver Class Initialized
INFO - 2016-08-29 15:42:37 --> Model Class Initialized
INFO - 2016-08-29 15:42:37 --> Model Class Initialized
INFO - 2016-08-29 15:42:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:42:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:42:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 15:42:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:42:37 --> Final output sent to browser
DEBUG - 2016-08-29 15:42:37 --> Total execution time: 0.0534
INFO - 2016-08-29 15:43:58 --> Config Class Initialized
INFO - 2016-08-29 15:43:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:43:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:43:58 --> Utf8 Class Initialized
INFO - 2016-08-29 15:43:58 --> URI Class Initialized
INFO - 2016-08-29 15:43:58 --> Router Class Initialized
INFO - 2016-08-29 15:43:58 --> Output Class Initialized
INFO - 2016-08-29 15:43:58 --> Security Class Initialized
DEBUG - 2016-08-29 15:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:43:58 --> Input Class Initialized
INFO - 2016-08-29 15:43:58 --> Language Class Initialized
INFO - 2016-08-29 15:43:58 --> Loader Class Initialized
INFO - 2016-08-29 15:43:58 --> Helper loaded: url_helper
INFO - 2016-08-29 15:43:58 --> Helper loaded: language_helper
INFO - 2016-08-29 15:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:43:58 --> Controller Class Initialized
INFO - 2016-08-29 15:43:58 --> Database Driver Class Initialized
INFO - 2016-08-29 15:43:58 --> Model Class Initialized
INFO - 2016-08-29 15:43:58 --> Model Class Initialized
INFO - 2016-08-29 15:43:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:43:58 --> Helper loaded: form_helper
INFO - 2016-08-29 15:43:58 --> Form Validation Class Initialized
INFO - 2016-08-29 15:43:58 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 15:43:58 --> Config Class Initialized
INFO - 2016-08-29 15:43:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:43:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:43:58 --> Utf8 Class Initialized
INFO - 2016-08-29 15:43:58 --> URI Class Initialized
INFO - 2016-08-29 15:43:58 --> Router Class Initialized
INFO - 2016-08-29 15:43:58 --> Output Class Initialized
INFO - 2016-08-29 15:43:58 --> Security Class Initialized
DEBUG - 2016-08-29 15:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:43:58 --> Input Class Initialized
INFO - 2016-08-29 15:43:58 --> Language Class Initialized
INFO - 2016-08-29 15:43:58 --> Loader Class Initialized
INFO - 2016-08-29 15:43:58 --> Helper loaded: url_helper
INFO - 2016-08-29 15:43:58 --> Helper loaded: language_helper
INFO - 2016-08-29 15:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:43:58 --> Controller Class Initialized
INFO - 2016-08-29 15:43:58 --> Database Driver Class Initialized
INFO - 2016-08-29 15:43:58 --> Model Class Initialized
INFO - 2016-08-29 15:43:58 --> Model Class Initialized
INFO - 2016-08-29 15:43:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:43:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:43:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:43:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:43:58 --> Final output sent to browser
DEBUG - 2016-08-29 15:43:58 --> Total execution time: 0.0582
INFO - 2016-08-29 15:44:09 --> Config Class Initialized
INFO - 2016-08-29 15:44:09 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:44:09 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:44:09 --> Utf8 Class Initialized
INFO - 2016-08-29 15:44:09 --> URI Class Initialized
INFO - 2016-08-29 15:44:09 --> Router Class Initialized
INFO - 2016-08-29 15:44:09 --> Output Class Initialized
INFO - 2016-08-29 15:44:09 --> Security Class Initialized
DEBUG - 2016-08-29 15:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:44:09 --> Input Class Initialized
INFO - 2016-08-29 15:44:09 --> Language Class Initialized
INFO - 2016-08-29 15:44:09 --> Loader Class Initialized
INFO - 2016-08-29 15:44:09 --> Helper loaded: url_helper
INFO - 2016-08-29 15:44:09 --> Helper loaded: language_helper
INFO - 2016-08-29 15:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:44:09 --> Controller Class Initialized
INFO - 2016-08-29 15:44:09 --> Database Driver Class Initialized
INFO - 2016-08-29 15:44:09 --> Model Class Initialized
INFO - 2016-08-29 15:44:09 --> Model Class Initialized
INFO - 2016-08-29 15:44:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:44:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:44:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 15:44:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:44:09 --> Final output sent to browser
DEBUG - 2016-08-29 15:44:09 --> Total execution time: 0.0540
INFO - 2016-08-29 15:45:21 --> Config Class Initialized
INFO - 2016-08-29 15:45:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:45:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:45:21 --> Utf8 Class Initialized
INFO - 2016-08-29 15:45:21 --> URI Class Initialized
INFO - 2016-08-29 15:45:21 --> Router Class Initialized
INFO - 2016-08-29 15:45:21 --> Output Class Initialized
INFO - 2016-08-29 15:45:21 --> Security Class Initialized
DEBUG - 2016-08-29 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:45:21 --> Input Class Initialized
INFO - 2016-08-29 15:45:21 --> Language Class Initialized
INFO - 2016-08-29 15:45:21 --> Loader Class Initialized
INFO - 2016-08-29 15:45:21 --> Helper loaded: url_helper
INFO - 2016-08-29 15:45:21 --> Helper loaded: language_helper
INFO - 2016-08-29 15:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:45:21 --> Controller Class Initialized
INFO - 2016-08-29 15:45:21 --> Database Driver Class Initialized
INFO - 2016-08-29 15:45:21 --> Model Class Initialized
INFO - 2016-08-29 15:45:21 --> Model Class Initialized
INFO - 2016-08-29 15:45:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:45:21 --> Helper loaded: form_helper
INFO - 2016-08-29 15:45:21 --> Form Validation Class Initialized
INFO - 2016-08-29 15:45:21 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 15:45:21 --> Config Class Initialized
INFO - 2016-08-29 15:45:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:45:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:45:21 --> Utf8 Class Initialized
INFO - 2016-08-29 15:45:21 --> URI Class Initialized
INFO - 2016-08-29 15:45:21 --> Router Class Initialized
INFO - 2016-08-29 15:45:21 --> Output Class Initialized
INFO - 2016-08-29 15:45:21 --> Security Class Initialized
DEBUG - 2016-08-29 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:45:21 --> Input Class Initialized
INFO - 2016-08-29 15:45:21 --> Language Class Initialized
INFO - 2016-08-29 15:45:21 --> Loader Class Initialized
INFO - 2016-08-29 15:45:21 --> Helper loaded: url_helper
INFO - 2016-08-29 15:45:21 --> Helper loaded: language_helper
INFO - 2016-08-29 15:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:45:21 --> Controller Class Initialized
INFO - 2016-08-29 15:45:21 --> Database Driver Class Initialized
INFO - 2016-08-29 15:45:21 --> Model Class Initialized
INFO - 2016-08-29 15:45:21 --> Model Class Initialized
INFO - 2016-08-29 15:45:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:45:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:45:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:45:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:45:21 --> Final output sent to browser
DEBUG - 2016-08-29 15:45:21 --> Total execution time: 0.0588
INFO - 2016-08-29 15:45:25 --> Config Class Initialized
INFO - 2016-08-29 15:45:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:45:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:45:25 --> Utf8 Class Initialized
INFO - 2016-08-29 15:45:25 --> URI Class Initialized
INFO - 2016-08-29 15:45:25 --> Router Class Initialized
INFO - 2016-08-29 15:45:25 --> Output Class Initialized
INFO - 2016-08-29 15:45:25 --> Security Class Initialized
DEBUG - 2016-08-29 15:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:45:25 --> Input Class Initialized
INFO - 2016-08-29 15:45:25 --> Language Class Initialized
INFO - 2016-08-29 15:45:25 --> Loader Class Initialized
INFO - 2016-08-29 15:45:25 --> Helper loaded: url_helper
INFO - 2016-08-29 15:45:25 --> Helper loaded: language_helper
INFO - 2016-08-29 15:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:45:25 --> Controller Class Initialized
INFO - 2016-08-29 15:45:25 --> Database Driver Class Initialized
INFO - 2016-08-29 15:45:25 --> Model Class Initialized
INFO - 2016-08-29 15:45:25 --> Model Class Initialized
INFO - 2016-08-29 15:45:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:45:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:45:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-29 15:45:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:45:25 --> Final output sent to browser
DEBUG - 2016-08-29 15:45:25 --> Total execution time: 0.0507
INFO - 2016-08-29 15:46:11 --> Config Class Initialized
INFO - 2016-08-29 15:46:11 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:46:11 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:46:11 --> Utf8 Class Initialized
INFO - 2016-08-29 15:46:11 --> URI Class Initialized
INFO - 2016-08-29 15:46:11 --> Router Class Initialized
INFO - 2016-08-29 15:46:11 --> Output Class Initialized
INFO - 2016-08-29 15:46:11 --> Security Class Initialized
DEBUG - 2016-08-29 15:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:46:11 --> Input Class Initialized
INFO - 2016-08-29 15:46:11 --> Language Class Initialized
INFO - 2016-08-29 15:46:11 --> Loader Class Initialized
INFO - 2016-08-29 15:46:11 --> Helper loaded: url_helper
INFO - 2016-08-29 15:46:11 --> Helper loaded: language_helper
INFO - 2016-08-29 15:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:46:11 --> Controller Class Initialized
INFO - 2016-08-29 15:46:11 --> Database Driver Class Initialized
INFO - 2016-08-29 15:46:11 --> Model Class Initialized
INFO - 2016-08-29 15:46:11 --> Model Class Initialized
INFO - 2016-08-29 15:46:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:46:11 --> Helper loaded: form_helper
INFO - 2016-08-29 15:46:11 --> Form Validation Class Initialized
INFO - 2016-08-29 15:46:11 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-08-29 15:46:11 --> Config Class Initialized
INFO - 2016-08-29 15:46:11 --> Hooks Class Initialized
DEBUG - 2016-08-29 15:46:11 --> UTF-8 Support Enabled
INFO - 2016-08-29 15:46:11 --> Utf8 Class Initialized
INFO - 2016-08-29 15:46:11 --> URI Class Initialized
INFO - 2016-08-29 15:46:11 --> Router Class Initialized
INFO - 2016-08-29 15:46:11 --> Output Class Initialized
INFO - 2016-08-29 15:46:11 --> Security Class Initialized
DEBUG - 2016-08-29 15:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 15:46:11 --> Input Class Initialized
INFO - 2016-08-29 15:46:11 --> Language Class Initialized
INFO - 2016-08-29 15:46:11 --> Loader Class Initialized
INFO - 2016-08-29 15:46:11 --> Helper loaded: url_helper
INFO - 2016-08-29 15:46:11 --> Helper loaded: language_helper
INFO - 2016-08-29 15:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 15:46:11 --> Controller Class Initialized
INFO - 2016-08-29 15:46:11 --> Database Driver Class Initialized
INFO - 2016-08-29 15:46:11 --> Model Class Initialized
INFO - 2016-08-29 15:46:11 --> Model Class Initialized
INFO - 2016-08-29 15:46:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 15:46:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 15:46:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 15:46:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 15:46:11 --> Final output sent to browser
DEBUG - 2016-08-29 15:46:11 --> Total execution time: 0.0603
INFO - 2016-08-29 16:52:02 --> Config Class Initialized
INFO - 2016-08-29 16:52:02 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:52:02 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:52:02 --> Utf8 Class Initialized
INFO - 2016-08-29 16:52:02 --> URI Class Initialized
INFO - 2016-08-29 16:52:02 --> Router Class Initialized
INFO - 2016-08-29 16:52:02 --> Output Class Initialized
INFO - 2016-08-29 16:52:02 --> Security Class Initialized
DEBUG - 2016-08-29 16:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:52:02 --> Input Class Initialized
INFO - 2016-08-29 16:52:02 --> Language Class Initialized
INFO - 2016-08-29 16:52:02 --> Loader Class Initialized
INFO - 2016-08-29 16:52:02 --> Helper loaded: url_helper
INFO - 2016-08-29 16:52:02 --> Helper loaded: language_helper
INFO - 2016-08-29 16:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:52:02 --> Controller Class Initialized
INFO - 2016-08-29 16:52:02 --> Database Driver Class Initialized
INFO - 2016-08-29 16:52:02 --> Model Class Initialized
INFO - 2016-08-29 16:52:02 --> Model Class Initialized
INFO - 2016-08-29 16:52:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 16:52:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 16:52:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-08-29 16:52:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 16:52:02 --> Final output sent to browser
DEBUG - 2016-08-29 16:52:02 --> Total execution time: 0.1010
INFO - 2016-08-29 16:52:17 --> Config Class Initialized
INFO - 2016-08-29 16:52:17 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:52:17 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:52:17 --> Utf8 Class Initialized
INFO - 2016-08-29 16:52:17 --> URI Class Initialized
INFO - 2016-08-29 16:52:17 --> Router Class Initialized
INFO - 2016-08-29 16:52:17 --> Output Class Initialized
INFO - 2016-08-29 16:52:17 --> Security Class Initialized
DEBUG - 2016-08-29 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:52:17 --> Input Class Initialized
INFO - 2016-08-29 16:52:17 --> Language Class Initialized
INFO - 2016-08-29 16:52:17 --> Loader Class Initialized
INFO - 2016-08-29 16:52:17 --> Helper loaded: url_helper
INFO - 2016-08-29 16:52:17 --> Helper loaded: language_helper
INFO - 2016-08-29 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:52:17 --> Controller Class Initialized
INFO - 2016-08-29 16:52:17 --> Database Driver Class Initialized
INFO - 2016-08-29 16:52:17 --> Model Class Initialized
INFO - 2016-08-29 16:52:17 --> Model Class Initialized
INFO - 2016-08-29 16:52:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 16:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 16:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-08-29 16:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 16:52:17 --> Final output sent to browser
DEBUG - 2016-08-29 16:52:17 --> Total execution time: 0.0637
INFO - 2016-08-29 16:52:22 --> Config Class Initialized
INFO - 2016-08-29 16:52:22 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:52:22 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:52:22 --> Utf8 Class Initialized
INFO - 2016-08-29 16:52:22 --> URI Class Initialized
INFO - 2016-08-29 16:52:22 --> Router Class Initialized
INFO - 2016-08-29 16:52:22 --> Output Class Initialized
INFO - 2016-08-29 16:52:22 --> Security Class Initialized
DEBUG - 2016-08-29 16:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:52:22 --> Input Class Initialized
INFO - 2016-08-29 16:52:22 --> Language Class Initialized
INFO - 2016-08-29 16:52:22 --> Loader Class Initialized
INFO - 2016-08-29 16:52:22 --> Helper loaded: url_helper
INFO - 2016-08-29 16:52:22 --> Helper loaded: language_helper
INFO - 2016-08-29 16:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:52:22 --> Controller Class Initialized
INFO - 2016-08-29 16:52:22 --> Database Driver Class Initialized
INFO - 2016-08-29 16:52:22 --> Model Class Initialized
INFO - 2016-08-29 16:52:22 --> Model Class Initialized
INFO - 2016-08-29 16:52:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 16:52:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 16:52:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-08-29 16:52:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 16:52:22 --> Final output sent to browser
DEBUG - 2016-08-29 16:52:22 --> Total execution time: 0.0822
INFO - 2016-08-29 16:53:16 --> Config Class Initialized
INFO - 2016-08-29 16:53:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:53:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:53:16 --> Utf8 Class Initialized
INFO - 2016-08-29 16:53:16 --> URI Class Initialized
INFO - 2016-08-29 16:53:16 --> Router Class Initialized
INFO - 2016-08-29 16:53:16 --> Output Class Initialized
INFO - 2016-08-29 16:53:16 --> Security Class Initialized
DEBUG - 2016-08-29 16:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:53:16 --> Input Class Initialized
INFO - 2016-08-29 16:53:16 --> Language Class Initialized
INFO - 2016-08-29 16:53:16 --> Loader Class Initialized
INFO - 2016-08-29 16:53:16 --> Helper loaded: url_helper
INFO - 2016-08-29 16:53:16 --> Helper loaded: language_helper
INFO - 2016-08-29 16:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:53:16 --> Controller Class Initialized
INFO - 2016-08-29 16:53:16 --> Database Driver Class Initialized
INFO - 2016-08-29 16:53:17 --> Model Class Initialized
INFO - 2016-08-29 16:53:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 16:53:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 16:53:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-29 16:53:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 16:53:17 --> Final output sent to browser
DEBUG - 2016-08-29 16:53:17 --> Total execution time: 0.0590
INFO - 2016-08-29 16:53:20 --> Config Class Initialized
INFO - 2016-08-29 16:53:20 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:53:20 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:53:20 --> Utf8 Class Initialized
INFO - 2016-08-29 16:53:20 --> URI Class Initialized
INFO - 2016-08-29 16:53:20 --> Router Class Initialized
INFO - 2016-08-29 16:53:20 --> Output Class Initialized
INFO - 2016-08-29 16:53:20 --> Security Class Initialized
DEBUG - 2016-08-29 16:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:53:20 --> Input Class Initialized
INFO - 2016-08-29 16:53:20 --> Language Class Initialized
INFO - 2016-08-29 16:53:20 --> Loader Class Initialized
INFO - 2016-08-29 16:53:20 --> Helper loaded: url_helper
INFO - 2016-08-29 16:53:20 --> Helper loaded: language_helper
INFO - 2016-08-29 16:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:53:20 --> Controller Class Initialized
INFO - 2016-08-29 16:53:20 --> Database Driver Class Initialized
INFO - 2016-08-29 16:53:20 --> Model Class Initialized
INFO - 2016-08-29 16:53:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 16:53:20 --> Helper loaded: form_helper
INFO - 2016-08-29 16:53:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 16:53:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-08-29 16:53:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 16:53:20 --> Final output sent to browser
DEBUG - 2016-08-29 16:53:20 --> Total execution time: 0.0677
INFO - 2016-08-29 16:54:22 --> Config Class Initialized
INFO - 2016-08-29 16:54:22 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:54:22 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:54:22 --> Utf8 Class Initialized
INFO - 2016-08-29 16:54:22 --> URI Class Initialized
INFO - 2016-08-29 16:54:22 --> Router Class Initialized
INFO - 2016-08-29 16:54:22 --> Output Class Initialized
INFO - 2016-08-29 16:54:22 --> Security Class Initialized
DEBUG - 2016-08-29 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:54:22 --> Input Class Initialized
INFO - 2016-08-29 16:54:22 --> Language Class Initialized
INFO - 2016-08-29 16:54:22 --> Loader Class Initialized
INFO - 2016-08-29 16:54:22 --> Helper loaded: url_helper
INFO - 2016-08-29 16:54:22 --> Helper loaded: language_helper
INFO - 2016-08-29 16:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:54:22 --> Controller Class Initialized
INFO - 2016-08-29 16:54:22 --> Database Driver Class Initialized
INFO - 2016-08-29 16:54:22 --> Model Class Initialized
INFO - 2016-08-29 16:54:22 --> Model Class Initialized
INFO - 2016-08-29 16:54:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 16:54:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 16:54:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-29 16:54:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 16:54:22 --> Final output sent to browser
DEBUG - 2016-08-29 16:54:22 --> Total execution time: 0.0599
INFO - 2016-08-29 17:04:49 --> Config Class Initialized
INFO - 2016-08-29 17:04:49 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:04:49 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:04:49 --> Utf8 Class Initialized
INFO - 2016-08-29 17:04:49 --> URI Class Initialized
INFO - 2016-08-29 17:04:49 --> Router Class Initialized
INFO - 2016-08-29 17:04:49 --> Output Class Initialized
INFO - 2016-08-29 17:04:49 --> Security Class Initialized
DEBUG - 2016-08-29 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:04:49 --> Input Class Initialized
INFO - 2016-08-29 17:04:49 --> Language Class Initialized
INFO - 2016-08-29 17:04:49 --> Loader Class Initialized
INFO - 2016-08-29 17:04:49 --> Helper loaded: url_helper
INFO - 2016-08-29 17:04:49 --> Helper loaded: language_helper
INFO - 2016-08-29 17:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:04:49 --> Controller Class Initialized
INFO - 2016-08-29 17:04:49 --> Database Driver Class Initialized
INFO - 2016-08-29 17:04:49 --> Model Class Initialized
INFO - 2016-08-29 17:04:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:04:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:04:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-29 17:04:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:04:49 --> Final output sent to browser
DEBUG - 2016-08-29 17:04:49 --> Total execution time: 0.0642
INFO - 2016-08-29 17:04:58 --> Config Class Initialized
INFO - 2016-08-29 17:04:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:04:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:04:58 --> Utf8 Class Initialized
INFO - 2016-08-29 17:04:58 --> URI Class Initialized
INFO - 2016-08-29 17:04:58 --> Router Class Initialized
INFO - 2016-08-29 17:04:58 --> Output Class Initialized
INFO - 2016-08-29 17:04:58 --> Security Class Initialized
DEBUG - 2016-08-29 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:04:58 --> Input Class Initialized
INFO - 2016-08-29 17:04:58 --> Language Class Initialized
INFO - 2016-08-29 17:04:58 --> Loader Class Initialized
INFO - 2016-08-29 17:04:58 --> Helper loaded: url_helper
INFO - 2016-08-29 17:04:58 --> Helper loaded: language_helper
INFO - 2016-08-29 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:04:58 --> Controller Class Initialized
INFO - 2016-08-29 17:04:58 --> Database Driver Class Initialized
INFO - 2016-08-29 17:04:58 --> Model Class Initialized
INFO - 2016-08-29 17:04:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:04:59 --> Config Class Initialized
INFO - 2016-08-29 17:04:59 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:04:59 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:04:59 --> Utf8 Class Initialized
INFO - 2016-08-29 17:04:59 --> URI Class Initialized
INFO - 2016-08-29 17:04:59 --> Router Class Initialized
INFO - 2016-08-29 17:04:59 --> Output Class Initialized
INFO - 2016-08-29 17:04:59 --> Security Class Initialized
DEBUG - 2016-08-29 17:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:04:59 --> Input Class Initialized
INFO - 2016-08-29 17:04:59 --> Language Class Initialized
INFO - 2016-08-29 17:04:59 --> Loader Class Initialized
INFO - 2016-08-29 17:04:59 --> Helper loaded: url_helper
INFO - 2016-08-29 17:04:59 --> Helper loaded: language_helper
INFO - 2016-08-29 17:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:04:59 --> Controller Class Initialized
INFO - 2016-08-29 17:04:59 --> Database Driver Class Initialized
INFO - 2016-08-29 17:04:59 --> Model Class Initialized
INFO - 2016-08-29 17:04:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:04:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:04:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-08-29 17:04:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:04:59 --> Final output sent to browser
DEBUG - 2016-08-29 17:04:59 --> Total execution time: 0.0588
INFO - 2016-08-29 17:05:36 --> Config Class Initialized
INFO - 2016-08-29 17:05:36 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:05:36 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:05:36 --> Utf8 Class Initialized
INFO - 2016-08-29 17:05:36 --> URI Class Initialized
INFO - 2016-08-29 17:05:36 --> Router Class Initialized
INFO - 2016-08-29 17:05:36 --> Output Class Initialized
INFO - 2016-08-29 17:05:36 --> Security Class Initialized
DEBUG - 2016-08-29 17:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:05:36 --> Input Class Initialized
INFO - 2016-08-29 17:05:36 --> Language Class Initialized
INFO - 2016-08-29 17:05:36 --> Loader Class Initialized
INFO - 2016-08-29 17:05:36 --> Helper loaded: url_helper
INFO - 2016-08-29 17:05:36 --> Helper loaded: language_helper
INFO - 2016-08-29 17:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:05:36 --> Controller Class Initialized
INFO - 2016-08-29 17:05:36 --> Database Driver Class Initialized
INFO - 2016-08-29 17:05:36 --> Model Class Initialized
INFO - 2016-08-29 17:05:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:05:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:05:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-29 17:05:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:05:36 --> Final output sent to browser
DEBUG - 2016-08-29 17:05:36 --> Total execution time: 0.0681
INFO - 2016-08-29 17:05:42 --> Config Class Initialized
INFO - 2016-08-29 17:05:42 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:05:42 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:05:42 --> Utf8 Class Initialized
INFO - 2016-08-29 17:05:42 --> URI Class Initialized
INFO - 2016-08-29 17:05:42 --> Router Class Initialized
INFO - 2016-08-29 17:05:42 --> Output Class Initialized
INFO - 2016-08-29 17:05:42 --> Security Class Initialized
DEBUG - 2016-08-29 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:05:42 --> Input Class Initialized
INFO - 2016-08-29 17:05:42 --> Language Class Initialized
INFO - 2016-08-29 17:05:42 --> Loader Class Initialized
INFO - 2016-08-29 17:05:42 --> Helper loaded: url_helper
INFO - 2016-08-29 17:05:42 --> Helper loaded: language_helper
INFO - 2016-08-29 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:05:42 --> Controller Class Initialized
INFO - 2016-08-29 17:05:42 --> Database Driver Class Initialized
INFO - 2016-08-29 17:05:42 --> Model Class Initialized
INFO - 2016-08-29 17:05:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:05:42 --> Config Class Initialized
INFO - 2016-08-29 17:05:42 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:05:42 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:05:42 --> Utf8 Class Initialized
INFO - 2016-08-29 17:05:42 --> URI Class Initialized
INFO - 2016-08-29 17:05:42 --> Router Class Initialized
INFO - 2016-08-29 17:05:42 --> Output Class Initialized
INFO - 2016-08-29 17:05:42 --> Security Class Initialized
DEBUG - 2016-08-29 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:05:42 --> Input Class Initialized
INFO - 2016-08-29 17:05:42 --> Language Class Initialized
INFO - 2016-08-29 17:05:42 --> Loader Class Initialized
INFO - 2016-08-29 17:05:42 --> Helper loaded: url_helper
INFO - 2016-08-29 17:05:42 --> Helper loaded: language_helper
INFO - 2016-08-29 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:05:42 --> Controller Class Initialized
INFO - 2016-08-29 17:05:42 --> Database Driver Class Initialized
INFO - 2016-08-29 17:05:42 --> Model Class Initialized
INFO - 2016-08-29 17:05:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-08-29 17:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:05:42 --> Final output sent to browser
DEBUG - 2016-08-29 17:05:42 --> Total execution time: 0.0552
INFO - 2016-08-29 17:07:16 --> Config Class Initialized
INFO - 2016-08-29 17:07:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:07:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:07:16 --> Utf8 Class Initialized
INFO - 2016-08-29 17:07:16 --> URI Class Initialized
INFO - 2016-08-29 17:07:16 --> Router Class Initialized
INFO - 2016-08-29 17:07:16 --> Output Class Initialized
INFO - 2016-08-29 17:07:16 --> Security Class Initialized
DEBUG - 2016-08-29 17:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:07:16 --> Input Class Initialized
INFO - 2016-08-29 17:07:16 --> Language Class Initialized
INFO - 2016-08-29 17:07:16 --> Loader Class Initialized
INFO - 2016-08-29 17:07:16 --> Helper loaded: url_helper
INFO - 2016-08-29 17:07:16 --> Helper loaded: language_helper
INFO - 2016-08-29 17:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:07:16 --> Controller Class Initialized
INFO - 2016-08-29 17:07:16 --> Database Driver Class Initialized
INFO - 2016-08-29 17:07:16 --> Model Class Initialized
INFO - 2016-08-29 17:07:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:07:16 --> Helper loaded: form_helper
INFO - 2016-08-29 17:07:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:07:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-08-29 17:07:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:07:16 --> Final output sent to browser
DEBUG - 2016-08-29 17:07:16 --> Total execution time: 0.0619
INFO - 2016-08-29 17:07:20 --> Config Class Initialized
INFO - 2016-08-29 17:07:20 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:07:20 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:07:20 --> Utf8 Class Initialized
INFO - 2016-08-29 17:07:20 --> URI Class Initialized
INFO - 2016-08-29 17:07:20 --> Router Class Initialized
INFO - 2016-08-29 17:07:20 --> Output Class Initialized
INFO - 2016-08-29 17:07:20 --> Security Class Initialized
DEBUG - 2016-08-29 17:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:07:20 --> Input Class Initialized
INFO - 2016-08-29 17:07:20 --> Language Class Initialized
INFO - 2016-08-29 17:07:20 --> Loader Class Initialized
INFO - 2016-08-29 17:07:20 --> Helper loaded: url_helper
INFO - 2016-08-29 17:07:20 --> Helper loaded: language_helper
INFO - 2016-08-29 17:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:07:20 --> Controller Class Initialized
INFO - 2016-08-29 17:07:20 --> Database Driver Class Initialized
INFO - 2016-08-29 17:07:20 --> Model Class Initialized
INFO - 2016-08-29 17:07:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:07:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:07:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-08-29 17:07:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:07:20 --> Final output sent to browser
DEBUG - 2016-08-29 17:07:20 --> Total execution time: 0.0734
INFO - 2016-08-29 17:07:30 --> Config Class Initialized
INFO - 2016-08-29 17:07:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:07:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:07:30 --> Utf8 Class Initialized
INFO - 2016-08-29 17:07:30 --> URI Class Initialized
INFO - 2016-08-29 17:07:30 --> Router Class Initialized
INFO - 2016-08-29 17:07:30 --> Output Class Initialized
INFO - 2016-08-29 17:07:30 --> Security Class Initialized
DEBUG - 2016-08-29 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:07:30 --> Input Class Initialized
INFO - 2016-08-29 17:07:30 --> Language Class Initialized
INFO - 2016-08-29 17:07:30 --> Loader Class Initialized
INFO - 2016-08-29 17:07:30 --> Helper loaded: url_helper
INFO - 2016-08-29 17:07:30 --> Helper loaded: language_helper
INFO - 2016-08-29 17:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:07:30 --> Controller Class Initialized
INFO - 2016-08-29 17:07:30 --> Database Driver Class Initialized
INFO - 2016-08-29 17:07:30 --> Model Class Initialized
INFO - 2016-08-29 17:07:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:07:30 --> Config Class Initialized
INFO - 2016-08-29 17:07:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:07:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:07:30 --> Utf8 Class Initialized
INFO - 2016-08-29 17:07:30 --> URI Class Initialized
INFO - 2016-08-29 17:07:30 --> Router Class Initialized
INFO - 2016-08-29 17:07:30 --> Output Class Initialized
INFO - 2016-08-29 17:07:30 --> Security Class Initialized
DEBUG - 2016-08-29 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:07:30 --> Input Class Initialized
INFO - 2016-08-29 17:07:30 --> Language Class Initialized
INFO - 2016-08-29 17:07:30 --> Loader Class Initialized
INFO - 2016-08-29 17:07:30 --> Helper loaded: url_helper
INFO - 2016-08-29 17:07:30 --> Helper loaded: language_helper
INFO - 2016-08-29 17:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:07:30 --> Controller Class Initialized
INFO - 2016-08-29 17:07:30 --> Database Driver Class Initialized
INFO - 2016-08-29 17:07:30 --> Model Class Initialized
INFO - 2016-08-29 17:07:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:07:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:07:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-08-29 17:07:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:07:30 --> Final output sent to browser
DEBUG - 2016-08-29 17:07:30 --> Total execution time: 0.0618
INFO - 2016-08-29 17:10:47 --> Config Class Initialized
INFO - 2016-08-29 17:10:47 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:10:47 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:10:47 --> Utf8 Class Initialized
INFO - 2016-08-29 17:10:47 --> URI Class Initialized
INFO - 2016-08-29 17:10:47 --> Router Class Initialized
INFO - 2016-08-29 17:10:47 --> Output Class Initialized
INFO - 2016-08-29 17:10:47 --> Security Class Initialized
DEBUG - 2016-08-29 17:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:10:47 --> Input Class Initialized
INFO - 2016-08-29 17:10:47 --> Language Class Initialized
INFO - 2016-08-29 17:10:47 --> Loader Class Initialized
INFO - 2016-08-29 17:10:47 --> Helper loaded: url_helper
INFO - 2016-08-29 17:10:47 --> Helper loaded: language_helper
INFO - 2016-08-29 17:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:10:47 --> Controller Class Initialized
INFO - 2016-08-29 17:10:47 --> Database Driver Class Initialized
INFO - 2016-08-29 17:10:47 --> Model Class Initialized
INFO - 2016-08-29 17:10:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-29 17:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:10:47 --> Final output sent to browser
DEBUG - 2016-08-29 17:10:47 --> Total execution time: 0.0643
INFO - 2016-08-29 17:10:58 --> Config Class Initialized
INFO - 2016-08-29 17:10:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:10:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:10:58 --> Utf8 Class Initialized
INFO - 2016-08-29 17:10:58 --> URI Class Initialized
INFO - 2016-08-29 17:10:58 --> Router Class Initialized
INFO - 2016-08-29 17:10:58 --> Output Class Initialized
INFO - 2016-08-29 17:10:58 --> Security Class Initialized
DEBUG - 2016-08-29 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:10:58 --> Input Class Initialized
INFO - 2016-08-29 17:10:58 --> Language Class Initialized
INFO - 2016-08-29 17:10:58 --> Loader Class Initialized
INFO - 2016-08-29 17:10:58 --> Helper loaded: url_helper
INFO - 2016-08-29 17:10:58 --> Helper loaded: language_helper
INFO - 2016-08-29 17:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:10:58 --> Controller Class Initialized
INFO - 2016-08-29 17:10:58 --> Database Driver Class Initialized
INFO - 2016-08-29 17:10:58 --> Model Class Initialized
INFO - 2016-08-29 17:10:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:10:58 --> Config Class Initialized
INFO - 2016-08-29 17:10:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:10:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:10:58 --> Utf8 Class Initialized
INFO - 2016-08-29 17:10:58 --> URI Class Initialized
INFO - 2016-08-29 17:10:58 --> Router Class Initialized
INFO - 2016-08-29 17:10:58 --> Output Class Initialized
INFO - 2016-08-29 17:10:58 --> Security Class Initialized
DEBUG - 2016-08-29 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:10:58 --> Input Class Initialized
INFO - 2016-08-29 17:10:58 --> Language Class Initialized
INFO - 2016-08-29 17:10:58 --> Loader Class Initialized
INFO - 2016-08-29 17:10:58 --> Helper loaded: url_helper
INFO - 2016-08-29 17:10:58 --> Helper loaded: language_helper
INFO - 2016-08-29 17:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:10:58 --> Controller Class Initialized
INFO - 2016-08-29 17:10:58 --> Database Driver Class Initialized
INFO - 2016-08-29 17:10:58 --> Model Class Initialized
INFO - 2016-08-29 17:10:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:10:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:10:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-08-29 17:10:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:10:58 --> Final output sent to browser
DEBUG - 2016-08-29 17:10:58 --> Total execution time: 0.0532
INFO - 2016-08-29 17:11:33 --> Config Class Initialized
INFO - 2016-08-29 17:11:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:11:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:11:33 --> Utf8 Class Initialized
INFO - 2016-08-29 17:11:33 --> URI Class Initialized
INFO - 2016-08-29 17:11:33 --> Router Class Initialized
INFO - 2016-08-29 17:11:33 --> Output Class Initialized
INFO - 2016-08-29 17:11:33 --> Security Class Initialized
DEBUG - 2016-08-29 17:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:11:33 --> Input Class Initialized
INFO - 2016-08-29 17:11:33 --> Language Class Initialized
INFO - 2016-08-29 17:11:33 --> Loader Class Initialized
INFO - 2016-08-29 17:11:33 --> Helper loaded: url_helper
INFO - 2016-08-29 17:11:33 --> Helper loaded: language_helper
INFO - 2016-08-29 17:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:11:33 --> Controller Class Initialized
INFO - 2016-08-29 17:11:33 --> Database Driver Class Initialized
INFO - 2016-08-29 17:11:33 --> Model Class Initialized
INFO - 2016-08-29 17:11:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:11:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:11:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-29 17:11:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:11:33 --> Final output sent to browser
DEBUG - 2016-08-29 17:11:33 --> Total execution time: 0.0517
INFO - 2016-08-29 17:11:41 --> Config Class Initialized
INFO - 2016-08-29 17:11:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:11:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:11:41 --> Utf8 Class Initialized
INFO - 2016-08-29 17:11:41 --> URI Class Initialized
INFO - 2016-08-29 17:11:41 --> Router Class Initialized
INFO - 2016-08-29 17:11:41 --> Output Class Initialized
INFO - 2016-08-29 17:11:41 --> Security Class Initialized
DEBUG - 2016-08-29 17:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:11:41 --> Input Class Initialized
INFO - 2016-08-29 17:11:41 --> Language Class Initialized
INFO - 2016-08-29 17:11:41 --> Loader Class Initialized
INFO - 2016-08-29 17:11:41 --> Helper loaded: url_helper
INFO - 2016-08-29 17:11:41 --> Helper loaded: language_helper
INFO - 2016-08-29 17:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:11:41 --> Controller Class Initialized
INFO - 2016-08-29 17:11:41 --> Database Driver Class Initialized
INFO - 2016-08-29 17:11:41 --> Model Class Initialized
INFO - 2016-08-29 17:11:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:11:41 --> Config Class Initialized
INFO - 2016-08-29 17:11:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:11:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:11:41 --> Utf8 Class Initialized
INFO - 2016-08-29 17:11:41 --> URI Class Initialized
INFO - 2016-08-29 17:11:41 --> Router Class Initialized
INFO - 2016-08-29 17:11:41 --> Output Class Initialized
INFO - 2016-08-29 17:11:41 --> Security Class Initialized
DEBUG - 2016-08-29 17:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:11:41 --> Input Class Initialized
INFO - 2016-08-29 17:11:41 --> Language Class Initialized
INFO - 2016-08-29 17:11:41 --> Loader Class Initialized
INFO - 2016-08-29 17:11:41 --> Helper loaded: url_helper
INFO - 2016-08-29 17:11:41 --> Helper loaded: language_helper
INFO - 2016-08-29 17:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:11:41 --> Controller Class Initialized
INFO - 2016-08-29 17:11:41 --> Database Driver Class Initialized
INFO - 2016-08-29 17:11:41 --> Model Class Initialized
INFO - 2016-08-29 17:11:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:11:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-08-29 17:11:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-08-29 17:11:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-08-29 17:11:41 --> Final output sent to browser
DEBUG - 2016-08-29 17:11:41 --> Total execution time: 0.0572
INFO - 2016-08-29 17:12:03 --> Config Class Initialized
INFO - 2016-08-29 17:12:03 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:12:03 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:12:03 --> Utf8 Class Initialized
INFO - 2016-08-29 17:12:03 --> URI Class Initialized
INFO - 2016-08-29 17:12:03 --> Router Class Initialized
INFO - 2016-08-29 17:12:03 --> Output Class Initialized
INFO - 2016-08-29 17:12:03 --> Security Class Initialized
DEBUG - 2016-08-29 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:12:03 --> Input Class Initialized
INFO - 2016-08-29 17:12:03 --> Language Class Initialized
INFO - 2016-08-29 17:12:03 --> Loader Class Initialized
INFO - 2016-08-29 17:12:03 --> Helper loaded: url_helper
INFO - 2016-08-29 17:12:03 --> Helper loaded: language_helper
INFO - 2016-08-29 17:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:12:03 --> Controller Class Initialized
INFO - 2016-08-29 17:12:03 --> Database Driver Class Initialized
INFO - 2016-08-29 17:12:03 --> Model Class Initialized
INFO - 2016-08-29 17:12:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-29 17:12:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-29 17:12:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-08-29 17:12:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-29 17:12:03 --> Final output sent to browser
DEBUG - 2016-08-29 17:12:03 --> Total execution time: 0.0512
