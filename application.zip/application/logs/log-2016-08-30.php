<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-30 08:36:10 --> Config Class Initialized
INFO - 2016-08-30 08:36:10 --> Hooks Class Initialized
DEBUG - 2016-08-30 08:36:10 --> UTF-8 Support Enabled
INFO - 2016-08-30 08:36:10 --> Utf8 Class Initialized
INFO - 2016-08-30 08:36:10 --> URI Class Initialized
INFO - 2016-08-30 08:36:10 --> Router Class Initialized
INFO - 2016-08-30 08:36:10 --> Output Class Initialized
INFO - 2016-08-30 08:36:10 --> Security Class Initialized
DEBUG - 2016-08-30 08:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 08:36:10 --> Input Class Initialized
INFO - 2016-08-30 08:36:10 --> Language Class Initialized
INFO - 2016-08-30 08:36:10 --> Loader Class Initialized
INFO - 2016-08-30 08:36:10 --> Helper loaded: url_helper
INFO - 2016-08-30 08:36:10 --> Helper loaded: language_helper
INFO - 2016-08-30 08:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 08:36:10 --> Controller Class Initialized
INFO - 2016-08-30 08:36:10 --> Database Driver Class Initialized
INFO - 2016-08-30 08:36:10 --> Model Class Initialized
INFO - 2016-08-30 08:36:10 --> Model Class Initialized
INFO - 2016-08-30 08:36:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 08:36:10 --> Config Class Initialized
INFO - 2016-08-30 08:36:10 --> Hooks Class Initialized
DEBUG - 2016-08-30 08:36:10 --> UTF-8 Support Enabled
INFO - 2016-08-30 08:36:10 --> Utf8 Class Initialized
INFO - 2016-08-30 08:36:10 --> URI Class Initialized
INFO - 2016-08-30 08:36:10 --> Router Class Initialized
INFO - 2016-08-30 08:36:10 --> Output Class Initialized
INFO - 2016-08-30 08:36:10 --> Security Class Initialized
DEBUG - 2016-08-30 08:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 08:36:10 --> Input Class Initialized
INFO - 2016-08-30 08:36:10 --> Language Class Initialized
INFO - 2016-08-30 08:36:10 --> Loader Class Initialized
INFO - 2016-08-30 08:36:10 --> Helper loaded: url_helper
INFO - 2016-08-30 08:36:10 --> Helper loaded: language_helper
INFO - 2016-08-30 08:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 08:36:10 --> Controller Class Initialized
INFO - 2016-08-30 08:36:10 --> Database Driver Class Initialized
INFO - 2016-08-30 08:36:10 --> Model Class Initialized
INFO - 2016-08-30 08:36:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 08:36:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-30 08:36:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-30 08:36:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-30 08:36:10 --> Final output sent to browser
DEBUG - 2016-08-30 08:36:10 --> Total execution time: 0.0609
INFO - 2016-08-30 08:36:18 --> Config Class Initialized
INFO - 2016-08-30 08:36:18 --> Hooks Class Initialized
DEBUG - 2016-08-30 08:36:18 --> UTF-8 Support Enabled
INFO - 2016-08-30 08:36:18 --> Utf8 Class Initialized
INFO - 2016-08-30 08:36:18 --> URI Class Initialized
INFO - 2016-08-30 08:36:18 --> Router Class Initialized
INFO - 2016-08-30 08:36:18 --> Output Class Initialized
INFO - 2016-08-30 08:36:18 --> Security Class Initialized
DEBUG - 2016-08-30 08:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 08:36:18 --> Input Class Initialized
INFO - 2016-08-30 08:36:18 --> Language Class Initialized
INFO - 2016-08-30 08:36:18 --> Loader Class Initialized
INFO - 2016-08-30 08:36:18 --> Helper loaded: url_helper
INFO - 2016-08-30 08:36:18 --> Helper loaded: language_helper
INFO - 2016-08-30 08:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 08:36:18 --> Controller Class Initialized
INFO - 2016-08-30 08:36:18 --> Database Driver Class Initialized
INFO - 2016-08-30 08:36:18 --> Model Class Initialized
INFO - 2016-08-30 08:36:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 08:36:18 --> Config Class Initialized
INFO - 2016-08-30 08:36:18 --> Hooks Class Initialized
DEBUG - 2016-08-30 08:36:18 --> UTF-8 Support Enabled
INFO - 2016-08-30 08:36:18 --> Utf8 Class Initialized
INFO - 2016-08-30 08:36:18 --> URI Class Initialized
INFO - 2016-08-30 08:36:18 --> Router Class Initialized
INFO - 2016-08-30 08:36:18 --> Output Class Initialized
INFO - 2016-08-30 08:36:18 --> Security Class Initialized
DEBUG - 2016-08-30 08:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 08:36:18 --> Input Class Initialized
INFO - 2016-08-30 08:36:18 --> Language Class Initialized
INFO - 2016-08-30 08:36:18 --> Loader Class Initialized
INFO - 2016-08-30 08:36:18 --> Helper loaded: url_helper
INFO - 2016-08-30 08:36:18 --> Helper loaded: language_helper
INFO - 2016-08-30 08:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 08:36:18 --> Controller Class Initialized
INFO - 2016-08-30 08:36:18 --> Database Driver Class Initialized
INFO - 2016-08-30 08:36:18 --> Model Class Initialized
INFO - 2016-08-30 08:36:18 --> Model Class Initialized
INFO - 2016-08-30 08:36:18 --> Model Class Initialized
INFO - 2016-08-30 08:36:18 --> Model Class Initialized
INFO - 2016-08-30 08:36:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 08:36:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-30 08:36:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-08-30 08:36:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-30 08:36:18 --> Final output sent to browser
DEBUG - 2016-08-30 08:36:18 --> Total execution time: 0.0717
INFO - 2016-08-30 08:36:21 --> Config Class Initialized
INFO - 2016-08-30 08:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-30 08:36:21 --> UTF-8 Support Enabled
INFO - 2016-08-30 08:36:21 --> Utf8 Class Initialized
INFO - 2016-08-30 08:36:21 --> URI Class Initialized
INFO - 2016-08-30 08:36:21 --> Router Class Initialized
INFO - 2016-08-30 08:36:21 --> Output Class Initialized
INFO - 2016-08-30 08:36:21 --> Security Class Initialized
DEBUG - 2016-08-30 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 08:36:21 --> Input Class Initialized
INFO - 2016-08-30 08:36:21 --> Language Class Initialized
INFO - 2016-08-30 08:36:21 --> Loader Class Initialized
INFO - 2016-08-30 08:36:21 --> Helper loaded: url_helper
INFO - 2016-08-30 08:36:21 --> Helper loaded: language_helper
INFO - 2016-08-30 08:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 08:36:21 --> Controller Class Initialized
INFO - 2016-08-30 08:36:21 --> Database Driver Class Initialized
INFO - 2016-08-30 08:36:21 --> Model Class Initialized
INFO - 2016-08-30 08:36:21 --> Model Class Initialized
INFO - 2016-08-30 08:36:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 08:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-30 08:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-08-30 08:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-30 08:36:21 --> Final output sent to browser
DEBUG - 2016-08-30 08:36:21 --> Total execution time: 0.0580
INFO - 2016-08-30 08:36:25 --> Config Class Initialized
INFO - 2016-08-30 08:36:25 --> Hooks Class Initialized
DEBUG - 2016-08-30 08:36:25 --> UTF-8 Support Enabled
INFO - 2016-08-30 08:36:25 --> Utf8 Class Initialized
INFO - 2016-08-30 08:36:25 --> URI Class Initialized
INFO - 2016-08-30 08:36:25 --> Router Class Initialized
INFO - 2016-08-30 08:36:25 --> Output Class Initialized
INFO - 2016-08-30 08:36:25 --> Security Class Initialized
DEBUG - 2016-08-30 08:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 08:36:25 --> Input Class Initialized
INFO - 2016-08-30 08:36:25 --> Language Class Initialized
INFO - 2016-08-30 08:36:25 --> Loader Class Initialized
INFO - 2016-08-30 08:36:25 --> Helper loaded: url_helper
INFO - 2016-08-30 08:36:25 --> Helper loaded: language_helper
INFO - 2016-08-30 08:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 08:36:25 --> Controller Class Initialized
INFO - 2016-08-30 08:36:25 --> Database Driver Class Initialized
INFO - 2016-08-30 08:36:25 --> Model Class Initialized
INFO - 2016-08-30 08:36:25 --> Model Class Initialized
INFO - 2016-08-30 08:36:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 08:36:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-08-30 08:36:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-08-30 08:36:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-08-30 08:36:25 --> Final output sent to browser
DEBUG - 2016-08-30 08:36:25 --> Total execution time: 0.0719
INFO - 2016-08-30 13:40:53 --> Config Class Initialized
INFO - 2016-08-30 13:40:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 13:40:53 --> UTF-8 Support Enabled
INFO - 2016-08-30 13:40:53 --> Utf8 Class Initialized
INFO - 2016-08-30 13:40:53 --> URI Class Initialized
INFO - 2016-08-30 13:40:53 --> Router Class Initialized
INFO - 2016-08-30 13:40:53 --> Output Class Initialized
INFO - 2016-08-30 13:40:53 --> Security Class Initialized
DEBUG - 2016-08-30 13:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 13:40:53 --> Input Class Initialized
INFO - 2016-08-30 13:40:53 --> Language Class Initialized
INFO - 2016-08-30 13:40:53 --> Loader Class Initialized
INFO - 2016-08-30 13:40:53 --> Helper loaded: url_helper
INFO - 2016-08-30 13:40:53 --> Helper loaded: language_helper
INFO - 2016-08-30 13:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 13:40:53 --> Controller Class Initialized
INFO - 2016-08-30 13:40:53 --> Database Driver Class Initialized
INFO - 2016-08-30 13:40:53 --> Model Class Initialized
INFO - 2016-08-30 13:40:53 --> Model Class Initialized
INFO - 2016-08-30 13:40:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 13:40:53 --> Config Class Initialized
INFO - 2016-08-30 13:40:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 13:40:53 --> UTF-8 Support Enabled
INFO - 2016-08-30 13:40:53 --> Utf8 Class Initialized
INFO - 2016-08-30 13:40:53 --> URI Class Initialized
INFO - 2016-08-30 13:40:53 --> Router Class Initialized
INFO - 2016-08-30 13:40:53 --> Output Class Initialized
INFO - 2016-08-30 13:40:53 --> Security Class Initialized
DEBUG - 2016-08-30 13:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 13:40:53 --> Input Class Initialized
INFO - 2016-08-30 13:40:53 --> Language Class Initialized
INFO - 2016-08-30 13:40:53 --> Loader Class Initialized
INFO - 2016-08-30 13:40:53 --> Helper loaded: url_helper
INFO - 2016-08-30 13:40:53 --> Helper loaded: language_helper
INFO - 2016-08-30 13:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 13:40:53 --> Controller Class Initialized
INFO - 2016-08-30 13:40:53 --> Database Driver Class Initialized
INFO - 2016-08-30 13:40:53 --> Model Class Initialized
INFO - 2016-08-30 13:40:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 13:40:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-30 13:40:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-30 13:40:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-30 13:40:53 --> Final output sent to browser
DEBUG - 2016-08-30 13:40:53 --> Total execution time: 0.0946
INFO - 2016-08-30 16:26:23 --> Config Class Initialized
INFO - 2016-08-30 16:26:23 --> Hooks Class Initialized
DEBUG - 2016-08-30 16:26:23 --> UTF-8 Support Enabled
INFO - 2016-08-30 16:26:23 --> Utf8 Class Initialized
INFO - 2016-08-30 16:26:23 --> URI Class Initialized
INFO - 2016-08-30 16:26:23 --> Router Class Initialized
INFO - 2016-08-30 16:26:23 --> Output Class Initialized
INFO - 2016-08-30 16:26:23 --> Security Class Initialized
DEBUG - 2016-08-30 16:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 16:26:23 --> Input Class Initialized
INFO - 2016-08-30 16:26:23 --> Language Class Initialized
INFO - 2016-08-30 16:26:23 --> Loader Class Initialized
INFO - 2016-08-30 16:26:23 --> Helper loaded: url_helper
INFO - 2016-08-30 16:26:23 --> Helper loaded: language_helper
INFO - 2016-08-30 16:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 16:26:23 --> Controller Class Initialized
INFO - 2016-08-30 16:26:23 --> Database Driver Class Initialized
INFO - 2016-08-30 16:26:23 --> Model Class Initialized
INFO - 2016-08-30 16:26:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-08-30 16:26:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-08-30 16:26:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-08-30 16:26:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-08-30 16:26:23 --> Final output sent to browser
DEBUG - 2016-08-30 16:26:23 --> Total execution time: 0.1229
