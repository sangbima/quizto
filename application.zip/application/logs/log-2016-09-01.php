<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-01 08:19:12 --> Config Class Initialized
INFO - 2016-09-01 08:19:12 --> Hooks Class Initialized
DEBUG - 2016-09-01 08:19:12 --> UTF-8 Support Enabled
INFO - 2016-09-01 08:19:12 --> Utf8 Class Initialized
INFO - 2016-09-01 08:19:12 --> URI Class Initialized
INFO - 2016-09-01 08:19:12 --> Router Class Initialized
INFO - 2016-09-01 08:19:12 --> Output Class Initialized
INFO - 2016-09-01 08:19:12 --> Security Class Initialized
DEBUG - 2016-09-01 08:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 08:19:12 --> Input Class Initialized
INFO - 2016-09-01 08:19:12 --> Language Class Initialized
INFO - 2016-09-01 08:19:12 --> Loader Class Initialized
INFO - 2016-09-01 08:19:12 --> Helper loaded: url_helper
INFO - 2016-09-01 08:19:12 --> Helper loaded: language_helper
INFO - 2016-09-01 08:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 08:19:12 --> Controller Class Initialized
INFO - 2016-09-01 08:19:12 --> Database Driver Class Initialized
INFO - 2016-09-01 08:19:12 --> Model Class Initialized
INFO - 2016-09-01 08:19:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-01 08:19:12 --> Config Class Initialized
INFO - 2016-09-01 08:19:12 --> Hooks Class Initialized
DEBUG - 2016-09-01 08:19:12 --> UTF-8 Support Enabled
INFO - 2016-09-01 08:19:12 --> Utf8 Class Initialized
INFO - 2016-09-01 08:19:12 --> URI Class Initialized
INFO - 2016-09-01 08:19:12 --> Router Class Initialized
INFO - 2016-09-01 08:19:12 --> Output Class Initialized
INFO - 2016-09-01 08:19:12 --> Security Class Initialized
DEBUG - 2016-09-01 08:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 08:19:12 --> Input Class Initialized
INFO - 2016-09-01 08:19:12 --> Language Class Initialized
INFO - 2016-09-01 08:19:12 --> Loader Class Initialized
INFO - 2016-09-01 08:19:12 --> Helper loaded: url_helper
INFO - 2016-09-01 08:19:12 --> Helper loaded: language_helper
INFO - 2016-09-01 08:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 08:19:12 --> Controller Class Initialized
INFO - 2016-09-01 08:19:12 --> Database Driver Class Initialized
INFO - 2016-09-01 08:19:12 --> Model Class Initialized
INFO - 2016-09-01 08:19:12 --> Model Class Initialized
INFO - 2016-09-01 08:19:12 --> Model Class Initialized
INFO - 2016-09-01 08:19:12 --> Model Class Initialized
INFO - 2016-09-01 08:19:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-01 08:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-01 08:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-01 08:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-01 08:19:12 --> Final output sent to browser
DEBUG - 2016-09-01 08:19:12 --> Total execution time: 0.0894
INFO - 2016-09-01 08:19:18 --> Config Class Initialized
INFO - 2016-09-01 08:19:18 --> Hooks Class Initialized
DEBUG - 2016-09-01 08:19:18 --> UTF-8 Support Enabled
INFO - 2016-09-01 08:19:18 --> Utf8 Class Initialized
INFO - 2016-09-01 08:19:18 --> URI Class Initialized
INFO - 2016-09-01 08:19:18 --> Router Class Initialized
INFO - 2016-09-01 08:19:18 --> Output Class Initialized
INFO - 2016-09-01 08:19:18 --> Security Class Initialized
DEBUG - 2016-09-01 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 08:19:18 --> Input Class Initialized
INFO - 2016-09-01 08:19:18 --> Language Class Initialized
INFO - 2016-09-01 08:19:18 --> Loader Class Initialized
INFO - 2016-09-01 08:19:18 --> Helper loaded: url_helper
INFO - 2016-09-01 08:19:18 --> Helper loaded: language_helper
INFO - 2016-09-01 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 08:19:18 --> Controller Class Initialized
INFO - 2016-09-01 08:19:18 --> Database Driver Class Initialized
INFO - 2016-09-01 08:19:18 --> Model Class Initialized
INFO - 2016-09-01 08:19:18 --> Model Class Initialized
INFO - 2016-09-01 08:19:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-01 08:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-01 08:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-09-01 08:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-01 08:19:18 --> Final output sent to browser
DEBUG - 2016-09-01 08:19:18 --> Total execution time: 0.0839
INFO - 2016-09-01 08:19:26 --> Config Class Initialized
INFO - 2016-09-01 08:19:26 --> Hooks Class Initialized
DEBUG - 2016-09-01 08:19:26 --> UTF-8 Support Enabled
INFO - 2016-09-01 08:19:26 --> Utf8 Class Initialized
INFO - 2016-09-01 08:19:26 --> URI Class Initialized
INFO - 2016-09-01 08:19:26 --> Router Class Initialized
INFO - 2016-09-01 08:19:26 --> Output Class Initialized
INFO - 2016-09-01 08:19:26 --> Security Class Initialized
DEBUG - 2016-09-01 08:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 08:19:26 --> Input Class Initialized
INFO - 2016-09-01 08:19:26 --> Language Class Initialized
INFO - 2016-09-01 08:19:26 --> Loader Class Initialized
INFO - 2016-09-01 08:19:26 --> Helper loaded: url_helper
INFO - 2016-09-01 08:19:26 --> Helper loaded: language_helper
INFO - 2016-09-01 08:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 08:19:26 --> Controller Class Initialized
INFO - 2016-09-01 08:19:26 --> Database Driver Class Initialized
INFO - 2016-09-01 08:19:26 --> Model Class Initialized
INFO - 2016-09-01 08:19:26 --> Model Class Initialized
INFO - 2016-09-01 08:19:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-01 08:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-01 08:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-09-01 08:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-01 08:19:26 --> Final output sent to browser
DEBUG - 2016-09-01 08:19:26 --> Total execution time: 0.0673
INFO - 2016-09-01 08:21:57 --> Config Class Initialized
INFO - 2016-09-01 08:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-01 08:21:57 --> UTF-8 Support Enabled
INFO - 2016-09-01 08:21:57 --> Utf8 Class Initialized
INFO - 2016-09-01 08:21:57 --> URI Class Initialized
INFO - 2016-09-01 08:21:57 --> Router Class Initialized
INFO - 2016-09-01 08:21:57 --> Output Class Initialized
INFO - 2016-09-01 08:21:57 --> Security Class Initialized
DEBUG - 2016-09-01 08:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 08:21:57 --> Input Class Initialized
INFO - 2016-09-01 08:21:57 --> Language Class Initialized
INFO - 2016-09-01 08:21:57 --> Loader Class Initialized
INFO - 2016-09-01 08:21:57 --> Helper loaded: url_helper
INFO - 2016-09-01 08:21:57 --> Helper loaded: language_helper
INFO - 2016-09-01 08:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 08:21:57 --> Controller Class Initialized
INFO - 2016-09-01 08:21:57 --> Database Driver Class Initialized
INFO - 2016-09-01 08:21:57 --> Model Class Initialized
INFO - 2016-09-01 08:21:57 --> Model Class Initialized
INFO - 2016-09-01 08:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-01 08:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-01 08:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-09-01 08:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-01 08:21:57 --> Final output sent to browser
DEBUG - 2016-09-01 08:21:57 --> Total execution time: 0.0801
INFO - 2016-09-01 08:24:27 --> Config Class Initialized
INFO - 2016-09-01 08:24:27 --> Hooks Class Initialized
DEBUG - 2016-09-01 08:24:27 --> UTF-8 Support Enabled
INFO - 2016-09-01 08:24:27 --> Utf8 Class Initialized
INFO - 2016-09-01 08:24:27 --> URI Class Initialized
INFO - 2016-09-01 08:24:27 --> Router Class Initialized
INFO - 2016-09-01 08:24:27 --> Output Class Initialized
INFO - 2016-09-01 08:24:27 --> Security Class Initialized
DEBUG - 2016-09-01 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 08:24:27 --> Input Class Initialized
INFO - 2016-09-01 08:24:27 --> Language Class Initialized
INFO - 2016-09-01 08:24:27 --> Loader Class Initialized
INFO - 2016-09-01 08:24:27 --> Helper loaded: url_helper
INFO - 2016-09-01 08:24:27 --> Helper loaded: language_helper
INFO - 2016-09-01 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 08:24:27 --> Controller Class Initialized
INFO - 2016-09-01 08:24:27 --> Database Driver Class Initialized
INFO - 2016-09-01 08:24:27 --> Model Class Initialized
INFO - 2016-09-01 08:24:27 --> Model Class Initialized
INFO - 2016-09-01 08:24:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-01 08:24:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-01 08:24:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-09-01 08:24:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-01 08:24:27 --> Final output sent to browser
DEBUG - 2016-09-01 08:24:27 --> Total execution time: 0.0549
