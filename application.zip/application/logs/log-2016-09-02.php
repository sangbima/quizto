<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-02 14:12:00 --> Config Class Initialized
INFO - 2016-09-02 14:12:00 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:12:00 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:12:00 --> Utf8 Class Initialized
INFO - 2016-09-02 14:12:00 --> URI Class Initialized
INFO - 2016-09-02 14:12:00 --> Router Class Initialized
INFO - 2016-09-02 14:12:00 --> Output Class Initialized
INFO - 2016-09-02 14:12:00 --> Security Class Initialized
DEBUG - 2016-09-02 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:12:00 --> Input Class Initialized
INFO - 2016-09-02 14:12:00 --> Language Class Initialized
INFO - 2016-09-02 14:12:00 --> Loader Class Initialized
INFO - 2016-09-02 14:12:00 --> Helper loaded: url_helper
INFO - 2016-09-02 14:12:00 --> Helper loaded: language_helper
INFO - 2016-09-02 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:12:00 --> Controller Class Initialized
INFO - 2016-09-02 14:12:00 --> Database Driver Class Initialized
INFO - 2016-09-02 14:12:00 --> Model Class Initialized
INFO - 2016-09-02 14:12:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 14:12:00 --> Config Class Initialized
INFO - 2016-09-02 14:12:00 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:12:00 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:12:00 --> Utf8 Class Initialized
INFO - 2016-09-02 14:12:00 --> URI Class Initialized
INFO - 2016-09-02 14:12:00 --> Router Class Initialized
INFO - 2016-09-02 14:12:00 --> Output Class Initialized
INFO - 2016-09-02 14:12:00 --> Security Class Initialized
DEBUG - 2016-09-02 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:12:00 --> Input Class Initialized
INFO - 2016-09-02 14:12:00 --> Language Class Initialized
INFO - 2016-09-02 14:12:00 --> Loader Class Initialized
INFO - 2016-09-02 14:12:00 --> Helper loaded: url_helper
INFO - 2016-09-02 14:12:00 --> Helper loaded: language_helper
INFO - 2016-09-02 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:12:00 --> Controller Class Initialized
INFO - 2016-09-02 14:12:00 --> Database Driver Class Initialized
INFO - 2016-09-02 14:12:00 --> Model Class Initialized
INFO - 2016-09-02 14:12:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 14:12:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-02 14:12:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-02 14:12:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-02 14:12:00 --> Final output sent to browser
DEBUG - 2016-09-02 14:12:00 --> Total execution time: 0.0587
INFO - 2016-09-02 14:12:04 --> Config Class Initialized
INFO - 2016-09-02 14:12:04 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:12:04 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:12:04 --> Utf8 Class Initialized
INFO - 2016-09-02 14:12:04 --> URI Class Initialized
INFO - 2016-09-02 14:12:04 --> Router Class Initialized
INFO - 2016-09-02 14:12:04 --> Output Class Initialized
INFO - 2016-09-02 14:12:04 --> Security Class Initialized
DEBUG - 2016-09-02 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:12:04 --> Input Class Initialized
INFO - 2016-09-02 14:12:04 --> Language Class Initialized
INFO - 2016-09-02 14:12:04 --> Loader Class Initialized
INFO - 2016-09-02 14:12:04 --> Helper loaded: url_helper
INFO - 2016-09-02 14:12:04 --> Helper loaded: language_helper
INFO - 2016-09-02 14:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:12:04 --> Controller Class Initialized
INFO - 2016-09-02 14:12:04 --> Database Driver Class Initialized
INFO - 2016-09-02 14:12:04 --> Model Class Initialized
INFO - 2016-09-02 14:12:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 14:12:04 --> Config Class Initialized
INFO - 2016-09-02 14:12:04 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:12:04 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:12:04 --> Utf8 Class Initialized
INFO - 2016-09-02 14:12:04 --> URI Class Initialized
INFO - 2016-09-02 14:12:04 --> Router Class Initialized
INFO - 2016-09-02 14:12:04 --> Output Class Initialized
INFO - 2016-09-02 14:12:04 --> Security Class Initialized
DEBUG - 2016-09-02 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:12:04 --> Input Class Initialized
INFO - 2016-09-02 14:12:04 --> Language Class Initialized
INFO - 2016-09-02 14:12:04 --> Loader Class Initialized
INFO - 2016-09-02 14:12:04 --> Helper loaded: url_helper
INFO - 2016-09-02 14:12:04 --> Helper loaded: language_helper
INFO - 2016-09-02 14:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:12:04 --> Controller Class Initialized
INFO - 2016-09-02 14:12:04 --> Database Driver Class Initialized
INFO - 2016-09-02 14:12:04 --> Model Class Initialized
INFO - 2016-09-02 14:12:04 --> Model Class Initialized
INFO - 2016-09-02 14:12:04 --> Model Class Initialized
INFO - 2016-09-02 14:12:04 --> Model Class Initialized
INFO - 2016-09-02 14:12:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 14:12:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:12:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-02 14:12:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:12:04 --> Final output sent to browser
DEBUG - 2016-09-02 14:12:04 --> Total execution time: 0.0781
INFO - 2016-09-02 14:12:09 --> Config Class Initialized
INFO - 2016-09-02 14:12:09 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:12:09 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:12:09 --> Utf8 Class Initialized
INFO - 2016-09-02 14:12:09 --> URI Class Initialized
INFO - 2016-09-02 14:12:09 --> Router Class Initialized
INFO - 2016-09-02 14:12:09 --> Output Class Initialized
INFO - 2016-09-02 14:12:09 --> Security Class Initialized
DEBUG - 2016-09-02 14:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:12:09 --> Input Class Initialized
INFO - 2016-09-02 14:12:09 --> Language Class Initialized
INFO - 2016-09-02 14:12:09 --> Loader Class Initialized
INFO - 2016-09-02 14:12:09 --> Helper loaded: url_helper
INFO - 2016-09-02 14:12:09 --> Helper loaded: language_helper
INFO - 2016-09-02 14:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:12:09 --> Controller Class Initialized
INFO - 2016-09-02 14:12:09 --> Database Driver Class Initialized
INFO - 2016-09-02 14:12:09 --> Model Class Initialized
INFO - 2016-09-02 14:12:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 14:12:09 --> Helper loaded: form_helper
INFO - 2016-09-02 14:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-02 14:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:12:09 --> Final output sent to browser
DEBUG - 2016-09-02 14:12:09 --> Total execution time: 0.0812
INFO - 2016-09-02 14:12:18 --> Config Class Initialized
INFO - 2016-09-02 14:12:18 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:12:18 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:12:18 --> Utf8 Class Initialized
INFO - 2016-09-02 14:12:18 --> URI Class Initialized
INFO - 2016-09-02 14:12:18 --> Router Class Initialized
INFO - 2016-09-02 14:12:18 --> Output Class Initialized
INFO - 2016-09-02 14:12:18 --> Security Class Initialized
DEBUG - 2016-09-02 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:12:18 --> Input Class Initialized
INFO - 2016-09-02 14:12:18 --> Language Class Initialized
INFO - 2016-09-02 14:12:18 --> Loader Class Initialized
INFO - 2016-09-02 14:12:18 --> Helper loaded: url_helper
INFO - 2016-09-02 14:12:18 --> Helper loaded: language_helper
INFO - 2016-09-02 14:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:12:18 --> Controller Class Initialized
INFO - 2016-09-02 14:12:18 --> Database Driver Class Initialized
INFO - 2016-09-02 14:12:18 --> Model Class Initialized
INFO - 2016-09-02 14:12:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 14:12:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:12:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-02 14:12:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:12:18 --> Final output sent to browser
DEBUG - 2016-09-02 14:12:18 --> Total execution time: 0.0818
INFO - 2016-09-02 14:21:23 --> Config Class Initialized
INFO - 2016-09-02 14:21:23 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:21:23 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:21:23 --> Utf8 Class Initialized
INFO - 2016-09-02 14:21:23 --> URI Class Initialized
INFO - 2016-09-02 14:21:23 --> Router Class Initialized
INFO - 2016-09-02 14:21:23 --> Output Class Initialized
INFO - 2016-09-02 14:21:23 --> Security Class Initialized
DEBUG - 2016-09-02 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:21:23 --> Input Class Initialized
INFO - 2016-09-02 14:21:23 --> Language Class Initialized
INFO - 2016-09-02 14:21:23 --> Loader Class Initialized
INFO - 2016-09-02 14:21:23 --> Helper loaded: url_helper
INFO - 2016-09-02 14:21:23 --> Helper loaded: language_helper
INFO - 2016-09-02 14:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:21:23 --> Controller Class Initialized
INFO - 2016-09-02 14:21:23 --> Database Driver Class Initialized
INFO - 2016-09-02 14:21:23 --> Model Class Initialized
INFO - 2016-09-02 14:21:23 --> Model Class Initialized
INFO - 2016-09-02 14:21:23 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:21:23 --> Could not find the language line "typesoal"
ERROR - 2016-09-02 14:21:23 --> Severity: Notice --> Undefined property: Typesoal::$disc_model C:\wamp64\www\savsoftquiz\application\controllers\Typesoal.php 31
ERROR - 2016-09-02 14:21:23 --> Severity: error --> Exception: Call to a member function disc_list_group_by_no() on null C:\wamp64\www\savsoftquiz\application\controllers\Typesoal.php 31
INFO - 2016-09-02 14:21:41 --> Config Class Initialized
INFO - 2016-09-02 14:21:41 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:21:41 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:21:41 --> Utf8 Class Initialized
INFO - 2016-09-02 14:21:41 --> URI Class Initialized
INFO - 2016-09-02 14:21:41 --> Router Class Initialized
INFO - 2016-09-02 14:21:41 --> Output Class Initialized
INFO - 2016-09-02 14:21:41 --> Security Class Initialized
DEBUG - 2016-09-02 14:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:21:41 --> Input Class Initialized
INFO - 2016-09-02 14:21:41 --> Language Class Initialized
INFO - 2016-09-02 14:21:41 --> Loader Class Initialized
INFO - 2016-09-02 14:21:41 --> Helper loaded: url_helper
INFO - 2016-09-02 14:21:41 --> Helper loaded: language_helper
INFO - 2016-09-02 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:21:41 --> Controller Class Initialized
INFO - 2016-09-02 14:21:41 --> Database Driver Class Initialized
INFO - 2016-09-02 14:21:41 --> Model Class Initialized
INFO - 2016-09-02 14:21:41 --> Model Class Initialized
INFO - 2016-09-02 14:21:41 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:21:41 --> Could not find the language line "typesoal"
ERROR - 2016-09-02 14:21:41 --> Severity: error --> Exception: Call to undefined method Typesoal_model::disc_list_group_by_no() C:\wamp64\www\savsoftquiz\application\controllers\Typesoal.php 31
INFO - 2016-09-02 14:22:03 --> Config Class Initialized
INFO - 2016-09-02 14:22:03 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:22:03 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:22:03 --> Utf8 Class Initialized
INFO - 2016-09-02 14:22:03 --> URI Class Initialized
INFO - 2016-09-02 14:22:03 --> Router Class Initialized
INFO - 2016-09-02 14:22:03 --> Output Class Initialized
INFO - 2016-09-02 14:22:03 --> Security Class Initialized
DEBUG - 2016-09-02 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:22:03 --> Input Class Initialized
INFO - 2016-09-02 14:22:03 --> Language Class Initialized
INFO - 2016-09-02 14:22:03 --> Loader Class Initialized
INFO - 2016-09-02 14:22:03 --> Helper loaded: url_helper
INFO - 2016-09-02 14:22:03 --> Helper loaded: language_helper
INFO - 2016-09-02 14:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:22:03 --> Controller Class Initialized
INFO - 2016-09-02 14:22:03 --> Database Driver Class Initialized
INFO - 2016-09-02 14:22:03 --> Model Class Initialized
INFO - 2016-09-02 14:22:03 --> Model Class Initialized
INFO - 2016-09-02 14:22:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:22:03 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:22:03 --> Final output sent to browser
DEBUG - 2016-09-02 14:22:03 --> Total execution time: 0.0583
INFO - 2016-09-02 14:22:51 --> Config Class Initialized
INFO - 2016-09-02 14:22:51 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:22:51 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:22:51 --> Utf8 Class Initialized
INFO - 2016-09-02 14:22:51 --> URI Class Initialized
INFO - 2016-09-02 14:22:51 --> Router Class Initialized
INFO - 2016-09-02 14:22:51 --> Output Class Initialized
INFO - 2016-09-02 14:22:51 --> Security Class Initialized
DEBUG - 2016-09-02 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:22:51 --> Input Class Initialized
INFO - 2016-09-02 14:22:51 --> Language Class Initialized
INFO - 2016-09-02 14:22:51 --> Loader Class Initialized
INFO - 2016-09-02 14:22:51 --> Helper loaded: url_helper
INFO - 2016-09-02 14:22:51 --> Helper loaded: language_helper
INFO - 2016-09-02 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:22:51 --> Controller Class Initialized
INFO - 2016-09-02 14:22:51 --> Database Driver Class Initialized
INFO - 2016-09-02 14:22:51 --> Model Class Initialized
INFO - 2016-09-02 14:22:51 --> Model Class Initialized
INFO - 2016-09-02 14:22:51 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:22:51 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:22:51 --> Final output sent to browser
DEBUG - 2016-09-02 14:22:51 --> Total execution time: 0.0576
INFO - 2016-09-02 14:24:25 --> Config Class Initialized
INFO - 2016-09-02 14:24:25 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:24:25 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:24:25 --> Utf8 Class Initialized
INFO - 2016-09-02 14:24:25 --> URI Class Initialized
INFO - 2016-09-02 14:24:25 --> Router Class Initialized
INFO - 2016-09-02 14:24:25 --> Output Class Initialized
INFO - 2016-09-02 14:24:25 --> Security Class Initialized
DEBUG - 2016-09-02 14:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:24:25 --> Input Class Initialized
INFO - 2016-09-02 14:24:25 --> Language Class Initialized
INFO - 2016-09-02 14:24:25 --> Loader Class Initialized
INFO - 2016-09-02 14:24:25 --> Helper loaded: url_helper
INFO - 2016-09-02 14:24:25 --> Helper loaded: language_helper
INFO - 2016-09-02 14:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:24:25 --> Controller Class Initialized
INFO - 2016-09-02 14:24:25 --> Database Driver Class Initialized
INFO - 2016-09-02 14:24:25 --> Model Class Initialized
INFO - 2016-09-02 14:24:25 --> Model Class Initialized
INFO - 2016-09-02 14:24:25 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:24:25 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:24:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:24:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:24:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:24:25 --> Final output sent to browser
DEBUG - 2016-09-02 14:24:25 --> Total execution time: 0.0598
INFO - 2016-09-02 14:31:12 --> Config Class Initialized
INFO - 2016-09-02 14:31:12 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:31:12 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:31:12 --> Utf8 Class Initialized
INFO - 2016-09-02 14:31:12 --> URI Class Initialized
INFO - 2016-09-02 14:31:12 --> Router Class Initialized
INFO - 2016-09-02 14:31:12 --> Output Class Initialized
INFO - 2016-09-02 14:31:12 --> Security Class Initialized
DEBUG - 2016-09-02 14:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:31:12 --> Input Class Initialized
INFO - 2016-09-02 14:31:12 --> Language Class Initialized
INFO - 2016-09-02 14:31:12 --> Loader Class Initialized
INFO - 2016-09-02 14:31:12 --> Helper loaded: url_helper
INFO - 2016-09-02 14:31:12 --> Helper loaded: language_helper
INFO - 2016-09-02 14:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:31:12 --> Controller Class Initialized
INFO - 2016-09-02 14:31:12 --> Database Driver Class Initialized
INFO - 2016-09-02 14:31:12 --> Model Class Initialized
INFO - 2016-09-02 14:31:12 --> Model Class Initialized
INFO - 2016-09-02 14:31:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:31:12 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:31:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:31:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:31:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:31:12 --> Final output sent to browser
DEBUG - 2016-09-02 14:31:12 --> Total execution time: 0.0654
INFO - 2016-09-02 14:31:32 --> Config Class Initialized
INFO - 2016-09-02 14:31:32 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:31:32 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:31:32 --> Utf8 Class Initialized
INFO - 2016-09-02 14:31:32 --> URI Class Initialized
INFO - 2016-09-02 14:31:32 --> Router Class Initialized
INFO - 2016-09-02 14:31:32 --> Output Class Initialized
INFO - 2016-09-02 14:31:32 --> Security Class Initialized
DEBUG - 2016-09-02 14:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:31:32 --> Input Class Initialized
INFO - 2016-09-02 14:31:32 --> Language Class Initialized
INFO - 2016-09-02 14:31:32 --> Loader Class Initialized
INFO - 2016-09-02 14:31:32 --> Helper loaded: url_helper
INFO - 2016-09-02 14:31:32 --> Helper loaded: language_helper
INFO - 2016-09-02 14:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:31:32 --> Controller Class Initialized
INFO - 2016-09-02 14:31:32 --> Database Driver Class Initialized
INFO - 2016-09-02 14:31:32 --> Model Class Initialized
INFO - 2016-09-02 14:31:32 --> Model Class Initialized
INFO - 2016-09-02 14:31:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:31:32 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:31:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:31:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:31:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:31:32 --> Final output sent to browser
DEBUG - 2016-09-02 14:31:32 --> Total execution time: 0.0576
INFO - 2016-09-02 14:31:45 --> Config Class Initialized
INFO - 2016-09-02 14:31:45 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:31:45 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:31:45 --> Utf8 Class Initialized
INFO - 2016-09-02 14:31:45 --> URI Class Initialized
INFO - 2016-09-02 14:31:45 --> Router Class Initialized
INFO - 2016-09-02 14:31:45 --> Output Class Initialized
INFO - 2016-09-02 14:31:45 --> Security Class Initialized
DEBUG - 2016-09-02 14:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:31:45 --> Input Class Initialized
INFO - 2016-09-02 14:31:45 --> Language Class Initialized
INFO - 2016-09-02 14:31:45 --> Loader Class Initialized
INFO - 2016-09-02 14:31:45 --> Helper loaded: url_helper
INFO - 2016-09-02 14:31:45 --> Helper loaded: language_helper
INFO - 2016-09-02 14:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:31:45 --> Controller Class Initialized
INFO - 2016-09-02 14:31:45 --> Database Driver Class Initialized
INFO - 2016-09-02 14:31:45 --> Model Class Initialized
INFO - 2016-09-02 14:31:45 --> Model Class Initialized
INFO - 2016-09-02 14:31:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:31:45 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:31:45 --> Final output sent to browser
DEBUG - 2016-09-02 14:31:45 --> Total execution time: 0.0574
INFO - 2016-09-02 14:33:35 --> Config Class Initialized
INFO - 2016-09-02 14:33:35 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:33:35 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:33:35 --> Utf8 Class Initialized
INFO - 2016-09-02 14:33:35 --> URI Class Initialized
INFO - 2016-09-02 14:33:35 --> Router Class Initialized
INFO - 2016-09-02 14:33:35 --> Output Class Initialized
INFO - 2016-09-02 14:33:35 --> Security Class Initialized
DEBUG - 2016-09-02 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:33:35 --> Input Class Initialized
INFO - 2016-09-02 14:33:35 --> Language Class Initialized
INFO - 2016-09-02 14:33:35 --> Loader Class Initialized
INFO - 2016-09-02 14:33:35 --> Helper loaded: url_helper
INFO - 2016-09-02 14:33:35 --> Helper loaded: language_helper
INFO - 2016-09-02 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:33:35 --> Controller Class Initialized
INFO - 2016-09-02 14:33:35 --> Database Driver Class Initialized
INFO - 2016-09-02 14:33:35 --> Model Class Initialized
INFO - 2016-09-02 14:33:35 --> Model Class Initialized
INFO - 2016-09-02 14:33:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:33:35 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:33:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:33:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:33:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:33:35 --> Final output sent to browser
DEBUG - 2016-09-02 14:33:35 --> Total execution time: 0.0569
INFO - 2016-09-02 14:33:47 --> Config Class Initialized
INFO - 2016-09-02 14:33:47 --> Hooks Class Initialized
DEBUG - 2016-09-02 14:33:47 --> UTF-8 Support Enabled
INFO - 2016-09-02 14:33:47 --> Utf8 Class Initialized
INFO - 2016-09-02 14:33:47 --> URI Class Initialized
INFO - 2016-09-02 14:33:47 --> Router Class Initialized
INFO - 2016-09-02 14:33:47 --> Output Class Initialized
INFO - 2016-09-02 14:33:47 --> Security Class Initialized
DEBUG - 2016-09-02 14:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 14:33:47 --> Input Class Initialized
INFO - 2016-09-02 14:33:47 --> Language Class Initialized
INFO - 2016-09-02 14:33:47 --> Loader Class Initialized
INFO - 2016-09-02 14:33:47 --> Helper loaded: url_helper
INFO - 2016-09-02 14:33:47 --> Helper loaded: language_helper
INFO - 2016-09-02 14:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 14:33:47 --> Controller Class Initialized
INFO - 2016-09-02 14:33:47 --> Database Driver Class Initialized
INFO - 2016-09-02 14:33:47 --> Model Class Initialized
INFO - 2016-09-02 14:33:47 --> Model Class Initialized
INFO - 2016-09-02 14:33:47 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-02 14:33:47 --> Could not find the language line "typesoal"
INFO - 2016-09-02 14:33:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 14:33:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\typesoal_list.php
INFO - 2016-09-02 14:33:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 14:33:47 --> Final output sent to browser
DEBUG - 2016-09-02 14:33:47 --> Total execution time: 0.0601
INFO - 2016-09-02 19:36:28 --> Config Class Initialized
INFO - 2016-09-02 19:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-02 19:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-02 19:36:28 --> Utf8 Class Initialized
INFO - 2016-09-02 19:36:28 --> URI Class Initialized
INFO - 2016-09-02 19:36:28 --> Router Class Initialized
INFO - 2016-09-02 19:36:28 --> Output Class Initialized
INFO - 2016-09-02 19:36:28 --> Security Class Initialized
DEBUG - 2016-09-02 19:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 19:36:28 --> Input Class Initialized
INFO - 2016-09-02 19:36:28 --> Language Class Initialized
INFO - 2016-09-02 19:36:28 --> Loader Class Initialized
INFO - 2016-09-02 19:36:28 --> Helper loaded: url_helper
INFO - 2016-09-02 19:36:28 --> Helper loaded: language_helper
INFO - 2016-09-02 19:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 19:36:28 --> Controller Class Initialized
INFO - 2016-09-02 19:36:28 --> Database Driver Class Initialized
INFO - 2016-09-02 19:36:28 --> Model Class Initialized
INFO - 2016-09-02 19:36:28 --> Model Class Initialized
INFO - 2016-09-02 19:36:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 19:36:28 --> Config Class Initialized
INFO - 2016-09-02 19:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-02 19:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-02 19:36:28 --> Utf8 Class Initialized
INFO - 2016-09-02 19:36:28 --> URI Class Initialized
INFO - 2016-09-02 19:36:28 --> Router Class Initialized
INFO - 2016-09-02 19:36:28 --> Output Class Initialized
INFO - 2016-09-02 19:36:28 --> Security Class Initialized
DEBUG - 2016-09-02 19:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 19:36:28 --> Input Class Initialized
INFO - 2016-09-02 19:36:28 --> Language Class Initialized
INFO - 2016-09-02 19:36:28 --> Loader Class Initialized
INFO - 2016-09-02 19:36:28 --> Helper loaded: url_helper
INFO - 2016-09-02 19:36:28 --> Helper loaded: language_helper
INFO - 2016-09-02 19:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 19:36:28 --> Controller Class Initialized
INFO - 2016-09-02 19:36:28 --> Database Driver Class Initialized
INFO - 2016-09-02 19:36:28 --> Model Class Initialized
INFO - 2016-09-02 19:36:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 19:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-02 19:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-02 19:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-02 19:36:28 --> Final output sent to browser
DEBUG - 2016-09-02 19:36:28 --> Total execution time: 0.0559
INFO - 2016-09-02 19:36:36 --> Config Class Initialized
INFO - 2016-09-02 19:36:36 --> Hooks Class Initialized
DEBUG - 2016-09-02 19:36:36 --> UTF-8 Support Enabled
INFO - 2016-09-02 19:36:36 --> Utf8 Class Initialized
INFO - 2016-09-02 19:36:36 --> URI Class Initialized
INFO - 2016-09-02 19:36:36 --> Router Class Initialized
INFO - 2016-09-02 19:36:36 --> Output Class Initialized
INFO - 2016-09-02 19:36:36 --> Security Class Initialized
DEBUG - 2016-09-02 19:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 19:36:36 --> Input Class Initialized
INFO - 2016-09-02 19:36:36 --> Language Class Initialized
INFO - 2016-09-02 19:36:36 --> Loader Class Initialized
INFO - 2016-09-02 19:36:36 --> Helper loaded: url_helper
INFO - 2016-09-02 19:36:36 --> Helper loaded: language_helper
INFO - 2016-09-02 19:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 19:36:36 --> Controller Class Initialized
INFO - 2016-09-02 19:36:36 --> Database Driver Class Initialized
INFO - 2016-09-02 19:36:36 --> Model Class Initialized
INFO - 2016-09-02 19:36:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 19:36:36 --> Config Class Initialized
INFO - 2016-09-02 19:36:36 --> Hooks Class Initialized
DEBUG - 2016-09-02 19:36:36 --> UTF-8 Support Enabled
INFO - 2016-09-02 19:36:36 --> Utf8 Class Initialized
INFO - 2016-09-02 19:36:36 --> URI Class Initialized
INFO - 2016-09-02 19:36:36 --> Router Class Initialized
INFO - 2016-09-02 19:36:36 --> Output Class Initialized
INFO - 2016-09-02 19:36:36 --> Security Class Initialized
DEBUG - 2016-09-02 19:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 19:36:36 --> Input Class Initialized
INFO - 2016-09-02 19:36:36 --> Language Class Initialized
INFO - 2016-09-02 19:36:36 --> Loader Class Initialized
INFO - 2016-09-02 19:36:36 --> Helper loaded: url_helper
INFO - 2016-09-02 19:36:36 --> Helper loaded: language_helper
INFO - 2016-09-02 19:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 19:36:36 --> Controller Class Initialized
INFO - 2016-09-02 19:36:36 --> Database Driver Class Initialized
INFO - 2016-09-02 19:36:36 --> Model Class Initialized
INFO - 2016-09-02 19:36:36 --> Model Class Initialized
INFO - 2016-09-02 19:36:36 --> Model Class Initialized
INFO - 2016-09-02 19:36:36 --> Model Class Initialized
INFO - 2016-09-02 19:36:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-02 19:36:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-02 19:36:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-02 19:36:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-02 19:36:36 --> Final output sent to browser
DEBUG - 2016-09-02 19:36:36 --> Total execution time: 0.0770
