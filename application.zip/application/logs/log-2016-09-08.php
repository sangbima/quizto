<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-08 09:04:46 --> Config Class Initialized
INFO - 2016-09-08 09:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:04:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:04:46 --> Utf8 Class Initialized
INFO - 2016-09-08 09:04:46 --> URI Class Initialized
INFO - 2016-09-08 09:04:46 --> Router Class Initialized
INFO - 2016-09-08 09:04:46 --> Output Class Initialized
INFO - 2016-09-08 09:04:46 --> Security Class Initialized
DEBUG - 2016-09-08 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:04:46 --> Input Class Initialized
INFO - 2016-09-08 09:04:46 --> Language Class Initialized
INFO - 2016-09-08 09:04:46 --> Loader Class Initialized
INFO - 2016-09-08 09:04:46 --> Helper loaded: url_helper
INFO - 2016-09-08 09:04:46 --> Helper loaded: language_helper
INFO - 2016-09-08 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:04:46 --> Controller Class Initialized
INFO - 2016-09-08 09:04:46 --> Database Driver Class Initialized
INFO - 2016-09-08 09:04:46 --> Model Class Initialized
INFO - 2016-09-08 09:04:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:04:46 --> Config Class Initialized
INFO - 2016-09-08 09:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:04:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:04:46 --> Utf8 Class Initialized
INFO - 2016-09-08 09:04:46 --> URI Class Initialized
INFO - 2016-09-08 09:04:46 --> Router Class Initialized
INFO - 2016-09-08 09:04:46 --> Output Class Initialized
INFO - 2016-09-08 09:04:46 --> Security Class Initialized
DEBUG - 2016-09-08 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:04:46 --> Input Class Initialized
INFO - 2016-09-08 09:04:46 --> Language Class Initialized
INFO - 2016-09-08 09:04:46 --> Loader Class Initialized
INFO - 2016-09-08 09:04:46 --> Helper loaded: url_helper
INFO - 2016-09-08 09:04:46 --> Helper loaded: language_helper
INFO - 2016-09-08 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:04:46 --> Controller Class Initialized
INFO - 2016-09-08 09:04:46 --> Database Driver Class Initialized
INFO - 2016-09-08 09:04:46 --> Model Class Initialized
INFO - 2016-09-08 09:04:46 --> Model Class Initialized
INFO - 2016-09-08 09:04:46 --> Model Class Initialized
INFO - 2016-09-08 09:04:46 --> Model Class Initialized
INFO - 2016-09-08 09:04:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:04:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 09:04:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-08 09:04:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 09:04:46 --> Final output sent to browser
DEBUG - 2016-09-08 09:04:46 --> Total execution time: 0.0997
INFO - 2016-09-08 09:08:11 --> Config Class Initialized
INFO - 2016-09-08 09:08:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:08:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:08:11 --> Utf8 Class Initialized
INFO - 2016-09-08 09:08:11 --> URI Class Initialized
INFO - 2016-09-08 09:08:11 --> Router Class Initialized
INFO - 2016-09-08 09:08:11 --> Output Class Initialized
INFO - 2016-09-08 09:08:11 --> Security Class Initialized
DEBUG - 2016-09-08 09:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:08:11 --> Input Class Initialized
INFO - 2016-09-08 09:08:11 --> Language Class Initialized
INFO - 2016-09-08 09:08:11 --> Loader Class Initialized
INFO - 2016-09-08 09:08:11 --> Helper loaded: url_helper
INFO - 2016-09-08 09:08:11 --> Helper loaded: language_helper
INFO - 2016-09-08 09:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:08:11 --> Controller Class Initialized
INFO - 2016-09-08 09:08:11 --> Database Driver Class Initialized
INFO - 2016-09-08 09:08:11 --> Model Class Initialized
INFO - 2016-09-08 09:08:11 --> Model Class Initialized
INFO - 2016-09-08 09:08:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:08:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 09:08:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-09-08 09:08:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 09:08:11 --> Final output sent to browser
DEBUG - 2016-09-08 09:08:11 --> Total execution time: 0.0858
INFO - 2016-09-08 09:52:11 --> Config Class Initialized
INFO - 2016-09-08 09:52:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:52:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:52:11 --> Utf8 Class Initialized
INFO - 2016-09-08 09:52:11 --> URI Class Initialized
INFO - 2016-09-08 09:52:11 --> Router Class Initialized
INFO - 2016-09-08 09:52:11 --> Output Class Initialized
INFO - 2016-09-08 09:52:11 --> Security Class Initialized
DEBUG - 2016-09-08 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:52:11 --> Input Class Initialized
INFO - 2016-09-08 09:52:11 --> Language Class Initialized
INFO - 2016-09-08 09:52:11 --> Loader Class Initialized
INFO - 2016-09-08 09:52:11 --> Helper loaded: url_helper
INFO - 2016-09-08 09:52:11 --> Helper loaded: language_helper
INFO - 2016-09-08 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:52:11 --> Controller Class Initialized
INFO - 2016-09-08 09:52:11 --> Database Driver Class Initialized
INFO - 2016-09-08 09:52:11 --> Model Class Initialized
INFO - 2016-09-08 09:52:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 09:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 09:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 09:52:11 --> Final output sent to browser
DEBUG - 2016-09-08 09:52:11 --> Total execution time: 0.0798
INFO - 2016-09-08 09:52:16 --> Config Class Initialized
INFO - 2016-09-08 09:52:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:52:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:52:16 --> Utf8 Class Initialized
INFO - 2016-09-08 09:52:16 --> URI Class Initialized
INFO - 2016-09-08 09:52:16 --> Router Class Initialized
INFO - 2016-09-08 09:52:16 --> Output Class Initialized
INFO - 2016-09-08 09:52:16 --> Security Class Initialized
DEBUG - 2016-09-08 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:52:16 --> Input Class Initialized
INFO - 2016-09-08 09:52:16 --> Language Class Initialized
INFO - 2016-09-08 09:52:16 --> Loader Class Initialized
INFO - 2016-09-08 09:52:16 --> Helper loaded: url_helper
INFO - 2016-09-08 09:52:16 --> Helper loaded: language_helper
INFO - 2016-09-08 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:52:16 --> Controller Class Initialized
INFO - 2016-09-08 09:52:16 --> Database Driver Class Initialized
INFO - 2016-09-08 09:52:16 --> Model Class Initialized
INFO - 2016-09-08 09:52:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:52:16 --> Config Class Initialized
INFO - 2016-09-08 09:52:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:52:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:52:16 --> Utf8 Class Initialized
INFO - 2016-09-08 09:52:16 --> URI Class Initialized
INFO - 2016-09-08 09:52:16 --> Router Class Initialized
INFO - 2016-09-08 09:52:16 --> Output Class Initialized
INFO - 2016-09-08 09:52:16 --> Security Class Initialized
DEBUG - 2016-09-08 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:52:16 --> Input Class Initialized
INFO - 2016-09-08 09:52:16 --> Language Class Initialized
INFO - 2016-09-08 09:52:16 --> Loader Class Initialized
INFO - 2016-09-08 09:52:16 --> Helper loaded: url_helper
INFO - 2016-09-08 09:52:16 --> Helper loaded: language_helper
INFO - 2016-09-08 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:52:16 --> Controller Class Initialized
INFO - 2016-09-08 09:52:16 --> Database Driver Class Initialized
INFO - 2016-09-08 09:52:16 --> Model Class Initialized
INFO - 2016-09-08 09:52:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:52:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-09-08 09:52:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-09-08 09:52:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-09-08 09:52:16 --> Final output sent to browser
DEBUG - 2016-09-08 09:52:16 --> Total execution time: 0.0776
INFO - 2016-09-08 09:55:05 --> Config Class Initialized
INFO - 2016-09-08 09:55:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:55:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:55:05 --> Utf8 Class Initialized
INFO - 2016-09-08 09:55:05 --> URI Class Initialized
INFO - 2016-09-08 09:55:05 --> Router Class Initialized
INFO - 2016-09-08 09:55:05 --> Output Class Initialized
INFO - 2016-09-08 09:55:05 --> Security Class Initialized
DEBUG - 2016-09-08 09:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:55:05 --> Input Class Initialized
INFO - 2016-09-08 09:55:05 --> Language Class Initialized
INFO - 2016-09-08 09:55:05 --> Loader Class Initialized
INFO - 2016-09-08 09:55:05 --> Helper loaded: url_helper
INFO - 2016-09-08 09:55:05 --> Helper loaded: language_helper
INFO - 2016-09-08 09:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:55:05 --> Controller Class Initialized
INFO - 2016-09-08 09:55:05 --> Database Driver Class Initialized
INFO - 2016-09-08 09:55:05 --> Model Class Initialized
INFO - 2016-09-08 09:55:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:55:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-09-08 09:55:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-09-08 09:55:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-09-08 09:55:06 --> Final output sent to browser
DEBUG - 2016-09-08 09:55:06 --> Total execution time: 0.0675
INFO - 2016-09-08 09:56:00 --> Config Class Initialized
INFO - 2016-09-08 09:56:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:56:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:56:00 --> Utf8 Class Initialized
INFO - 2016-09-08 09:56:00 --> URI Class Initialized
INFO - 2016-09-08 09:56:00 --> Router Class Initialized
INFO - 2016-09-08 09:56:00 --> Output Class Initialized
INFO - 2016-09-08 09:56:00 --> Security Class Initialized
DEBUG - 2016-09-08 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:56:00 --> Input Class Initialized
INFO - 2016-09-08 09:56:00 --> Language Class Initialized
INFO - 2016-09-08 09:56:00 --> Loader Class Initialized
INFO - 2016-09-08 09:56:00 --> Helper loaded: url_helper
INFO - 2016-09-08 09:56:00 --> Helper loaded: language_helper
INFO - 2016-09-08 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:56:00 --> Controller Class Initialized
INFO - 2016-09-08 09:56:00 --> Database Driver Class Initialized
INFO - 2016-09-08 09:56:00 --> Model Class Initialized
INFO - 2016-09-08 09:56:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:56:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
ERROR - 2016-09-08 09:56:00 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\wamp64\www\savsoftquiz\application\views\new_question_6.php 23
INFO - 2016-09-08 09:56:15 --> Config Class Initialized
INFO - 2016-09-08 09:56:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:56:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:56:15 --> Utf8 Class Initialized
INFO - 2016-09-08 09:56:15 --> URI Class Initialized
INFO - 2016-09-08 09:56:15 --> Router Class Initialized
INFO - 2016-09-08 09:56:15 --> Output Class Initialized
INFO - 2016-09-08 09:56:15 --> Security Class Initialized
DEBUG - 2016-09-08 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:56:15 --> Input Class Initialized
INFO - 2016-09-08 09:56:15 --> Language Class Initialized
INFO - 2016-09-08 09:56:15 --> Loader Class Initialized
INFO - 2016-09-08 09:56:15 --> Helper loaded: url_helper
INFO - 2016-09-08 09:56:15 --> Helper loaded: language_helper
INFO - 2016-09-08 09:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:56:15 --> Controller Class Initialized
INFO - 2016-09-08 09:56:15 --> Database Driver Class Initialized
INFO - 2016-09-08 09:56:15 --> Model Class Initialized
INFO - 2016-09-08 09:56:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-09-08 09:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-09-08 09:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-09-08 09:56:15 --> Final output sent to browser
DEBUG - 2016-09-08 09:56:15 --> Total execution time: 0.0788
INFO - 2016-09-08 09:59:20 --> Config Class Initialized
INFO - 2016-09-08 09:59:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 09:59:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 09:59:20 --> Utf8 Class Initialized
INFO - 2016-09-08 09:59:20 --> URI Class Initialized
INFO - 2016-09-08 09:59:20 --> Router Class Initialized
INFO - 2016-09-08 09:59:20 --> Output Class Initialized
INFO - 2016-09-08 09:59:20 --> Security Class Initialized
DEBUG - 2016-09-08 09:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 09:59:20 --> Input Class Initialized
INFO - 2016-09-08 09:59:20 --> Language Class Initialized
INFO - 2016-09-08 09:59:20 --> Loader Class Initialized
INFO - 2016-09-08 09:59:20 --> Helper loaded: url_helper
INFO - 2016-09-08 09:59:20 --> Helper loaded: language_helper
INFO - 2016-09-08 09:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 09:59:20 --> Controller Class Initialized
INFO - 2016-09-08 09:59:20 --> Database Driver Class Initialized
INFO - 2016-09-08 09:59:20 --> Model Class Initialized
INFO - 2016-09-08 09:59:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 09:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-09-08 09:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-09-08 09:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-09-08 09:59:20 --> Final output sent to browser
DEBUG - 2016-09-08 09:59:20 --> Total execution time: 0.0882
INFO - 2016-09-08 10:13:41 --> Config Class Initialized
INFO - 2016-09-08 10:13:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:13:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:13:41 --> Utf8 Class Initialized
INFO - 2016-09-08 10:13:41 --> URI Class Initialized
INFO - 2016-09-08 10:13:41 --> Router Class Initialized
INFO - 2016-09-08 10:13:41 --> Output Class Initialized
INFO - 2016-09-08 10:13:41 --> Security Class Initialized
DEBUG - 2016-09-08 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:13:41 --> Input Class Initialized
INFO - 2016-09-08 10:13:41 --> Language Class Initialized
INFO - 2016-09-08 10:13:41 --> Loader Class Initialized
INFO - 2016-09-08 10:13:41 --> Helper loaded: url_helper
INFO - 2016-09-08 10:13:41 --> Helper loaded: language_helper
INFO - 2016-09-08 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:13:41 --> Controller Class Initialized
INFO - 2016-09-08 10:13:41 --> Database Driver Class Initialized
INFO - 2016-09-08 10:13:41 --> Model Class Initialized
INFO - 2016-09-08 10:13:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:13:41 --> Config Class Initialized
INFO - 2016-09-08 10:13:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:13:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:13:41 --> Utf8 Class Initialized
INFO - 2016-09-08 10:13:41 --> URI Class Initialized
INFO - 2016-09-08 10:13:41 --> Router Class Initialized
INFO - 2016-09-08 10:13:41 --> Output Class Initialized
INFO - 2016-09-08 10:13:41 --> Security Class Initialized
DEBUG - 2016-09-08 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:13:41 --> Input Class Initialized
INFO - 2016-09-08 10:13:41 --> Language Class Initialized
INFO - 2016-09-08 10:13:41 --> Loader Class Initialized
INFO - 2016-09-08 10:13:41 --> Helper loaded: url_helper
INFO - 2016-09-08 10:13:41 --> Helper loaded: language_helper
INFO - 2016-09-08 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:13:41 --> Controller Class Initialized
INFO - 2016-09-08 10:13:41 --> Database Driver Class Initialized
INFO - 2016-09-08 10:13:41 --> Model Class Initialized
INFO - 2016-09-08 10:13:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 10:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 10:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 10:13:41 --> Final output sent to browser
DEBUG - 2016-09-08 10:13:41 --> Total execution time: 0.0647
INFO - 2016-09-08 10:14:30 --> Config Class Initialized
INFO - 2016-09-08 10:14:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:14:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:14:30 --> Utf8 Class Initialized
INFO - 2016-09-08 10:14:30 --> URI Class Initialized
INFO - 2016-09-08 10:14:30 --> Router Class Initialized
INFO - 2016-09-08 10:14:30 --> Output Class Initialized
INFO - 2016-09-08 10:14:30 --> Security Class Initialized
DEBUG - 2016-09-08 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:14:30 --> Input Class Initialized
INFO - 2016-09-08 10:14:30 --> Language Class Initialized
INFO - 2016-09-08 10:14:30 --> Loader Class Initialized
INFO - 2016-09-08 10:14:30 --> Helper loaded: url_helper
INFO - 2016-09-08 10:14:30 --> Helper loaded: language_helper
INFO - 2016-09-08 10:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:14:30 --> Controller Class Initialized
INFO - 2016-09-08 10:14:30 --> Database Driver Class Initialized
INFO - 2016-09-08 10:14:30 --> Model Class Initialized
INFO - 2016-09-08 10:14:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:14:30 --> Helper loaded: form_helper
INFO - 2016-09-08 10:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 10:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 10:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 10:14:30 --> Final output sent to browser
DEBUG - 2016-09-08 10:14:30 --> Total execution time: 0.0928
INFO - 2016-09-08 10:14:46 --> Config Class Initialized
INFO - 2016-09-08 10:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:14:46 --> Utf8 Class Initialized
INFO - 2016-09-08 10:14:46 --> URI Class Initialized
INFO - 2016-09-08 10:14:46 --> Router Class Initialized
INFO - 2016-09-08 10:14:46 --> Output Class Initialized
INFO - 2016-09-08 10:14:46 --> Security Class Initialized
DEBUG - 2016-09-08 10:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:14:46 --> Input Class Initialized
INFO - 2016-09-08 10:14:46 --> Language Class Initialized
INFO - 2016-09-08 10:14:46 --> Loader Class Initialized
INFO - 2016-09-08 10:14:46 --> Helper loaded: url_helper
INFO - 2016-09-08 10:14:46 --> Helper loaded: language_helper
INFO - 2016-09-08 10:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:14:46 --> Controller Class Initialized
INFO - 2016-09-08 10:14:46 --> Database Driver Class Initialized
INFO - 2016-09-08 10:14:46 --> Model Class Initialized
INFO - 2016-09-08 10:14:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:14:46 --> Helper loaded: form_helper
INFO - 2016-09-08 10:14:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 10:14:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 10:14:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 10:14:46 --> Final output sent to browser
DEBUG - 2016-09-08 10:14:46 --> Total execution time: 0.0736
INFO - 2016-09-08 10:14:50 --> Config Class Initialized
INFO - 2016-09-08 10:14:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:14:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:14:50 --> Utf8 Class Initialized
INFO - 2016-09-08 10:14:50 --> URI Class Initialized
INFO - 2016-09-08 10:14:50 --> Router Class Initialized
INFO - 2016-09-08 10:14:50 --> Output Class Initialized
INFO - 2016-09-08 10:14:50 --> Security Class Initialized
DEBUG - 2016-09-08 10:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:14:50 --> Input Class Initialized
INFO - 2016-09-08 10:14:50 --> Language Class Initialized
INFO - 2016-09-08 10:14:50 --> Loader Class Initialized
INFO - 2016-09-08 10:14:50 --> Helper loaded: url_helper
INFO - 2016-09-08 10:14:50 --> Helper loaded: language_helper
INFO - 2016-09-08 10:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:14:50 --> Controller Class Initialized
INFO - 2016-09-08 10:14:50 --> Database Driver Class Initialized
INFO - 2016-09-08 10:14:50 --> Model Class Initialized
INFO - 2016-09-08 10:14:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:14:50 --> Helper loaded: form_helper
INFO - 2016-09-08 10:14:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 10:14:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 10:14:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 10:14:50 --> Final output sent to browser
DEBUG - 2016-09-08 10:14:50 --> Total execution time: 0.0917
INFO - 2016-09-08 10:15:13 --> Config Class Initialized
INFO - 2016-09-08 10:15:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:15:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:15:13 --> Utf8 Class Initialized
INFO - 2016-09-08 10:15:13 --> URI Class Initialized
INFO - 2016-09-08 10:15:13 --> Router Class Initialized
INFO - 2016-09-08 10:15:13 --> Output Class Initialized
INFO - 2016-09-08 10:15:13 --> Security Class Initialized
DEBUG - 2016-09-08 10:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:15:13 --> Input Class Initialized
INFO - 2016-09-08 10:15:13 --> Language Class Initialized
INFO - 2016-09-08 10:15:13 --> Loader Class Initialized
INFO - 2016-09-08 10:15:13 --> Helper loaded: url_helper
INFO - 2016-09-08 10:15:13 --> Helper loaded: language_helper
INFO - 2016-09-08 10:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:15:13 --> Controller Class Initialized
INFO - 2016-09-08 10:15:13 --> Database Driver Class Initialized
INFO - 2016-09-08 10:15:13 --> Model Class Initialized
INFO - 2016-09-08 10:15:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:15:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 10:15:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-08 10:15:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 10:15:13 --> Final output sent to browser
DEBUG - 2016-09-08 10:15:13 --> Total execution time: 0.0735
INFO - 2016-09-08 10:15:16 --> Config Class Initialized
INFO - 2016-09-08 10:15:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 10:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 10:15:16 --> Utf8 Class Initialized
INFO - 2016-09-08 10:15:16 --> URI Class Initialized
INFO - 2016-09-08 10:15:16 --> Router Class Initialized
INFO - 2016-09-08 10:15:16 --> Output Class Initialized
INFO - 2016-09-08 10:15:16 --> Security Class Initialized
DEBUG - 2016-09-08 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 10:15:16 --> Input Class Initialized
INFO - 2016-09-08 10:15:16 --> Language Class Initialized
INFO - 2016-09-08 10:15:16 --> Loader Class Initialized
INFO - 2016-09-08 10:15:16 --> Helper loaded: url_helper
INFO - 2016-09-08 10:15:16 --> Helper loaded: language_helper
INFO - 2016-09-08 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 10:15:16 --> Controller Class Initialized
INFO - 2016-09-08 10:15:16 --> Database Driver Class Initialized
INFO - 2016-09-08 10:15:16 --> Model Class Initialized
INFO - 2016-09-08 10:15:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 10:15:16 --> Helper loaded: form_helper
INFO - 2016-09-08 10:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 10:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 10:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 10:15:16 --> Final output sent to browser
DEBUG - 2016-09-08 10:15:16 --> Total execution time: 0.0712
INFO - 2016-09-08 12:06:02 --> Config Class Initialized
INFO - 2016-09-08 12:06:02 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:06:02 --> Utf8 Class Initialized
INFO - 2016-09-08 12:06:02 --> URI Class Initialized
INFO - 2016-09-08 12:06:02 --> Router Class Initialized
INFO - 2016-09-08 12:06:02 --> Output Class Initialized
INFO - 2016-09-08 12:06:02 --> Security Class Initialized
DEBUG - 2016-09-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:06:02 --> Input Class Initialized
INFO - 2016-09-08 12:06:02 --> Language Class Initialized
INFO - 2016-09-08 12:06:02 --> Loader Class Initialized
INFO - 2016-09-08 12:06:02 --> Helper loaded: url_helper
INFO - 2016-09-08 12:06:02 --> Helper loaded: language_helper
INFO - 2016-09-08 12:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:06:02 --> Controller Class Initialized
INFO - 2016-09-08 12:06:02 --> Database Driver Class Initialized
INFO - 2016-09-08 12:06:02 --> Model Class Initialized
INFO - 2016-09-08 12:06:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:06:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:06:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-08 12:06:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:06:02 --> Final output sent to browser
DEBUG - 2016-09-08 12:06:02 --> Total execution time: 0.1119
INFO - 2016-09-08 12:07:40 --> Config Class Initialized
INFO - 2016-09-08 12:07:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:07:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:07:40 --> Utf8 Class Initialized
INFO - 2016-09-08 12:07:40 --> URI Class Initialized
INFO - 2016-09-08 12:07:40 --> Router Class Initialized
INFO - 2016-09-08 12:07:40 --> Output Class Initialized
INFO - 2016-09-08 12:07:40 --> Security Class Initialized
DEBUG - 2016-09-08 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:07:40 --> Input Class Initialized
INFO - 2016-09-08 12:07:40 --> Language Class Initialized
INFO - 2016-09-08 12:07:40 --> Loader Class Initialized
INFO - 2016-09-08 12:07:40 --> Helper loaded: url_helper
INFO - 2016-09-08 12:07:40 --> Helper loaded: language_helper
INFO - 2016-09-08 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:07:40 --> Controller Class Initialized
INFO - 2016-09-08 12:07:40 --> Database Driver Class Initialized
INFO - 2016-09-08 12:07:40 --> Model Class Initialized
INFO - 2016-09-08 12:07:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:07:40 --> Helper loaded: form_helper
INFO - 2016-09-08 12:07:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:07:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:07:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:07:40 --> Final output sent to browser
DEBUG - 2016-09-08 12:07:40 --> Total execution time: 0.0779
INFO - 2016-09-08 12:07:43 --> Config Class Initialized
INFO - 2016-09-08 12:07:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:07:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:07:43 --> Utf8 Class Initialized
INFO - 2016-09-08 12:07:43 --> URI Class Initialized
INFO - 2016-09-08 12:07:43 --> Router Class Initialized
INFO - 2016-09-08 12:07:43 --> Output Class Initialized
INFO - 2016-09-08 12:07:43 --> Security Class Initialized
DEBUG - 2016-09-08 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:07:43 --> Input Class Initialized
INFO - 2016-09-08 12:07:43 --> Language Class Initialized
INFO - 2016-09-08 12:07:43 --> Loader Class Initialized
INFO - 2016-09-08 12:07:43 --> Helper loaded: url_helper
INFO - 2016-09-08 12:07:43 --> Helper loaded: language_helper
INFO - 2016-09-08 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:07:43 --> Controller Class Initialized
INFO - 2016-09-08 12:07:43 --> Database Driver Class Initialized
INFO - 2016-09-08 12:07:43 --> Model Class Initialized
INFO - 2016-09-08 12:07:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:07:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:07:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-08 12:07:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:07:43 --> Final output sent to browser
DEBUG - 2016-09-08 12:07:43 --> Total execution time: 0.0821
INFO - 2016-09-08 12:08:06 --> Config Class Initialized
INFO - 2016-09-08 12:08:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:08:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:08:06 --> Utf8 Class Initialized
INFO - 2016-09-08 12:08:06 --> URI Class Initialized
INFO - 2016-09-08 12:08:06 --> Router Class Initialized
INFO - 2016-09-08 12:08:06 --> Output Class Initialized
INFO - 2016-09-08 12:08:06 --> Security Class Initialized
DEBUG - 2016-09-08 12:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:08:06 --> Input Class Initialized
INFO - 2016-09-08 12:08:06 --> Language Class Initialized
INFO - 2016-09-08 12:08:06 --> Loader Class Initialized
INFO - 2016-09-08 12:08:06 --> Helper loaded: url_helper
INFO - 2016-09-08 12:08:06 --> Helper loaded: language_helper
INFO - 2016-09-08 12:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:08:06 --> Controller Class Initialized
INFO - 2016-09-08 12:08:06 --> Database Driver Class Initialized
INFO - 2016-09-08 12:08:06 --> Model Class Initialized
INFO - 2016-09-08 12:08:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:08:06 --> Helper loaded: form_helper
INFO - 2016-09-08 12:08:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:08:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:08:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:08:06 --> Final output sent to browser
DEBUG - 2016-09-08 12:08:06 --> Total execution time: 0.0691
INFO - 2016-09-08 12:11:53 --> Config Class Initialized
INFO - 2016-09-08 12:11:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:11:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:11:53 --> Utf8 Class Initialized
INFO - 2016-09-08 12:11:53 --> URI Class Initialized
INFO - 2016-09-08 12:11:53 --> Router Class Initialized
INFO - 2016-09-08 12:11:53 --> Output Class Initialized
INFO - 2016-09-08 12:11:53 --> Security Class Initialized
DEBUG - 2016-09-08 12:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:11:53 --> Input Class Initialized
INFO - 2016-09-08 12:11:53 --> Language Class Initialized
INFO - 2016-09-08 12:11:53 --> Loader Class Initialized
INFO - 2016-09-08 12:11:53 --> Helper loaded: url_helper
INFO - 2016-09-08 12:11:53 --> Helper loaded: language_helper
INFO - 2016-09-08 12:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:11:53 --> Controller Class Initialized
INFO - 2016-09-08 12:11:53 --> Database Driver Class Initialized
INFO - 2016-09-08 12:11:53 --> Model Class Initialized
INFO - 2016-09-08 12:11:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:11:53 --> Helper loaded: form_helper
INFO - 2016-09-08 12:11:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:11:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:11:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:11:53 --> Final output sent to browser
DEBUG - 2016-09-08 12:11:53 --> Total execution time: 0.0796
INFO - 2016-09-08 12:11:56 --> Config Class Initialized
INFO - 2016-09-08 12:11:56 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:11:56 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:11:56 --> Utf8 Class Initialized
INFO - 2016-09-08 12:11:56 --> URI Class Initialized
INFO - 2016-09-08 12:11:56 --> Router Class Initialized
INFO - 2016-09-08 12:11:56 --> Output Class Initialized
INFO - 2016-09-08 12:11:56 --> Security Class Initialized
DEBUG - 2016-09-08 12:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:11:56 --> Input Class Initialized
INFO - 2016-09-08 12:11:56 --> Language Class Initialized
INFO - 2016-09-08 12:11:56 --> Loader Class Initialized
INFO - 2016-09-08 12:11:56 --> Helper loaded: url_helper
INFO - 2016-09-08 12:11:56 --> Helper loaded: language_helper
INFO - 2016-09-08 12:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:11:56 --> Controller Class Initialized
INFO - 2016-09-08 12:11:56 --> Database Driver Class Initialized
INFO - 2016-09-08 12:11:57 --> Model Class Initialized
INFO - 2016-09-08 12:11:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:11:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:11:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:11:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:11:57 --> Final output sent to browser
DEBUG - 2016-09-08 12:11:57 --> Total execution time: 0.0731
INFO - 2016-09-08 12:15:43 --> Config Class Initialized
INFO - 2016-09-08 12:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:15:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:15:43 --> Utf8 Class Initialized
INFO - 2016-09-08 12:15:43 --> URI Class Initialized
INFO - 2016-09-08 12:15:43 --> Router Class Initialized
INFO - 2016-09-08 12:15:43 --> Output Class Initialized
INFO - 2016-09-08 12:15:43 --> Security Class Initialized
DEBUG - 2016-09-08 12:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:15:43 --> Input Class Initialized
INFO - 2016-09-08 12:15:43 --> Language Class Initialized
INFO - 2016-09-08 12:15:43 --> Loader Class Initialized
INFO - 2016-09-08 12:15:43 --> Helper loaded: url_helper
INFO - 2016-09-08 12:15:43 --> Helper loaded: language_helper
INFO - 2016-09-08 12:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:15:43 --> Controller Class Initialized
INFO - 2016-09-08 12:15:43 --> Database Driver Class Initialized
INFO - 2016-09-08 12:15:43 --> Model Class Initialized
INFO - 2016-09-08 12:15:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:15:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:15:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:15:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:15:44 --> Final output sent to browser
DEBUG - 2016-09-08 12:15:44 --> Total execution time: 0.0665
INFO - 2016-09-08 12:18:03 --> Config Class Initialized
INFO - 2016-09-08 12:18:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:18:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:18:03 --> Utf8 Class Initialized
INFO - 2016-09-08 12:18:03 --> URI Class Initialized
INFO - 2016-09-08 12:18:03 --> Router Class Initialized
INFO - 2016-09-08 12:18:03 --> Output Class Initialized
INFO - 2016-09-08 12:18:03 --> Security Class Initialized
DEBUG - 2016-09-08 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:18:03 --> Input Class Initialized
INFO - 2016-09-08 12:18:03 --> Language Class Initialized
INFO - 2016-09-08 12:18:03 --> Loader Class Initialized
INFO - 2016-09-08 12:18:03 --> Helper loaded: url_helper
INFO - 2016-09-08 12:18:03 --> Helper loaded: language_helper
INFO - 2016-09-08 12:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:18:03 --> Controller Class Initialized
INFO - 2016-09-08 12:18:03 --> Database Driver Class Initialized
INFO - 2016-09-08 12:18:03 --> Model Class Initialized
INFO - 2016-09-08 12:18:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:18:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:20:55 --> Config Class Initialized
INFO - 2016-09-08 12:20:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:20:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:20:55 --> Utf8 Class Initialized
INFO - 2016-09-08 12:20:55 --> URI Class Initialized
INFO - 2016-09-08 12:20:55 --> Router Class Initialized
INFO - 2016-09-08 12:20:55 --> Output Class Initialized
INFO - 2016-09-08 12:20:55 --> Security Class Initialized
DEBUG - 2016-09-08 12:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:20:55 --> Input Class Initialized
INFO - 2016-09-08 12:20:55 --> Language Class Initialized
INFO - 2016-09-08 12:20:55 --> Loader Class Initialized
INFO - 2016-09-08 12:20:55 --> Helper loaded: url_helper
INFO - 2016-09-08 12:20:55 --> Helper loaded: language_helper
INFO - 2016-09-08 12:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:20:55 --> Controller Class Initialized
INFO - 2016-09-08 12:20:55 --> Database Driver Class Initialized
INFO - 2016-09-08 12:20:55 --> Model Class Initialized
INFO - 2016-09-08 12:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:20:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:20:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:20:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:20:55 --> Final output sent to browser
DEBUG - 2016-09-08 12:20:55 --> Total execution time: 0.0650
INFO - 2016-09-08 12:21:12 --> Config Class Initialized
INFO - 2016-09-08 12:21:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:21:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:21:12 --> Utf8 Class Initialized
INFO - 2016-09-08 12:21:12 --> URI Class Initialized
INFO - 2016-09-08 12:21:12 --> Router Class Initialized
INFO - 2016-09-08 12:21:12 --> Output Class Initialized
INFO - 2016-09-08 12:21:12 --> Security Class Initialized
DEBUG - 2016-09-08 12:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:21:12 --> Input Class Initialized
INFO - 2016-09-08 12:21:12 --> Language Class Initialized
INFO - 2016-09-08 12:21:12 --> Loader Class Initialized
INFO - 2016-09-08 12:21:12 --> Helper loaded: url_helper
INFO - 2016-09-08 12:21:12 --> Helper loaded: language_helper
INFO - 2016-09-08 12:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:21:12 --> Controller Class Initialized
INFO - 2016-09-08 12:21:12 --> Database Driver Class Initialized
INFO - 2016-09-08 12:21:12 --> Model Class Initialized
INFO - 2016-09-08 12:21:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:21:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:21:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:21:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:21:12 --> Final output sent to browser
DEBUG - 2016-09-08 12:21:12 --> Total execution time: 0.0749
INFO - 2016-09-08 12:23:19 --> Config Class Initialized
INFO - 2016-09-08 12:23:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:23:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:23:19 --> Utf8 Class Initialized
INFO - 2016-09-08 12:23:19 --> URI Class Initialized
INFO - 2016-09-08 12:23:19 --> Router Class Initialized
INFO - 2016-09-08 12:23:19 --> Output Class Initialized
INFO - 2016-09-08 12:23:19 --> Security Class Initialized
DEBUG - 2016-09-08 12:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:23:19 --> Input Class Initialized
INFO - 2016-09-08 12:23:19 --> Language Class Initialized
INFO - 2016-09-08 12:23:19 --> Loader Class Initialized
INFO - 2016-09-08 12:23:19 --> Helper loaded: url_helper
INFO - 2016-09-08 12:23:19 --> Helper loaded: language_helper
INFO - 2016-09-08 12:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:23:20 --> Controller Class Initialized
INFO - 2016-09-08 12:23:20 --> Database Driver Class Initialized
INFO - 2016-09-08 12:23:20 --> Model Class Initialized
INFO - 2016-09-08 12:23:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:23:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:23:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:23:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:23:20 --> Final output sent to browser
DEBUG - 2016-09-08 12:23:20 --> Total execution time: 0.0934
INFO - 2016-09-08 12:24:16 --> Config Class Initialized
INFO - 2016-09-08 12:24:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:24:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:24:16 --> Utf8 Class Initialized
INFO - 2016-09-08 12:24:16 --> URI Class Initialized
INFO - 2016-09-08 12:24:16 --> Router Class Initialized
INFO - 2016-09-08 12:24:16 --> Output Class Initialized
INFO - 2016-09-08 12:24:16 --> Security Class Initialized
DEBUG - 2016-09-08 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:24:16 --> Input Class Initialized
INFO - 2016-09-08 12:24:16 --> Language Class Initialized
INFO - 2016-09-08 12:24:16 --> Loader Class Initialized
INFO - 2016-09-08 12:24:16 --> Helper loaded: url_helper
INFO - 2016-09-08 12:24:16 --> Helper loaded: language_helper
INFO - 2016-09-08 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:24:16 --> Controller Class Initialized
INFO - 2016-09-08 12:24:16 --> Database Driver Class Initialized
INFO - 2016-09-08 12:24:16 --> Model Class Initialized
INFO - 2016-09-08 12:24:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:24:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:24:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:24:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:24:16 --> Final output sent to browser
DEBUG - 2016-09-08 12:24:16 --> Total execution time: 0.0651
INFO - 2016-09-08 12:25:08 --> Config Class Initialized
INFO - 2016-09-08 12:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:25:08 --> Utf8 Class Initialized
INFO - 2016-09-08 12:25:08 --> URI Class Initialized
INFO - 2016-09-08 12:25:08 --> Router Class Initialized
INFO - 2016-09-08 12:25:08 --> Output Class Initialized
INFO - 2016-09-08 12:25:08 --> Security Class Initialized
DEBUG - 2016-09-08 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:25:08 --> Input Class Initialized
INFO - 2016-09-08 12:25:08 --> Language Class Initialized
INFO - 2016-09-08 12:25:08 --> Loader Class Initialized
INFO - 2016-09-08 12:25:08 --> Helper loaded: url_helper
INFO - 2016-09-08 12:25:08 --> Helper loaded: language_helper
INFO - 2016-09-08 12:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:25:08 --> Controller Class Initialized
INFO - 2016-09-08 12:25:08 --> Database Driver Class Initialized
INFO - 2016-09-08 12:25:08 --> Model Class Initialized
INFO - 2016-09-08 12:25:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:25:08 --> Final output sent to browser
DEBUG - 2016-09-08 12:25:08 --> Total execution time: 0.0790
INFO - 2016-09-08 12:25:41 --> Config Class Initialized
INFO - 2016-09-08 12:25:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:25:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:25:41 --> Utf8 Class Initialized
INFO - 2016-09-08 12:25:41 --> URI Class Initialized
INFO - 2016-09-08 12:25:41 --> Router Class Initialized
INFO - 2016-09-08 12:25:41 --> Output Class Initialized
INFO - 2016-09-08 12:25:41 --> Security Class Initialized
DEBUG - 2016-09-08 12:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:25:41 --> Input Class Initialized
INFO - 2016-09-08 12:25:41 --> Language Class Initialized
INFO - 2016-09-08 12:25:41 --> Loader Class Initialized
INFO - 2016-09-08 12:25:41 --> Helper loaded: url_helper
INFO - 2016-09-08 12:25:41 --> Helper loaded: language_helper
INFO - 2016-09-08 12:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:25:41 --> Controller Class Initialized
INFO - 2016-09-08 12:25:41 --> Database Driver Class Initialized
INFO - 2016-09-08 12:25:41 --> Model Class Initialized
INFO - 2016-09-08 12:25:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:25:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:25:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:25:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:25:41 --> Final output sent to browser
DEBUG - 2016-09-08 12:25:41 --> Total execution time: 0.0635
INFO - 2016-09-08 12:26:36 --> Config Class Initialized
INFO - 2016-09-08 12:26:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:26:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:26:36 --> Utf8 Class Initialized
INFO - 2016-09-08 12:26:36 --> URI Class Initialized
INFO - 2016-09-08 12:26:36 --> Router Class Initialized
INFO - 2016-09-08 12:26:36 --> Output Class Initialized
INFO - 2016-09-08 12:26:36 --> Security Class Initialized
DEBUG - 2016-09-08 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:26:36 --> Input Class Initialized
INFO - 2016-09-08 12:26:36 --> Language Class Initialized
INFO - 2016-09-08 12:26:36 --> Loader Class Initialized
INFO - 2016-09-08 12:26:36 --> Helper loaded: url_helper
INFO - 2016-09-08 12:26:36 --> Helper loaded: language_helper
INFO - 2016-09-08 12:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:26:36 --> Controller Class Initialized
INFO - 2016-09-08 12:26:36 --> Database Driver Class Initialized
INFO - 2016-09-08 12:26:36 --> Model Class Initialized
INFO - 2016-09-08 12:26:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:26:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:26:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:26:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:26:36 --> Final output sent to browser
DEBUG - 2016-09-08 12:26:36 --> Total execution time: 0.0677
INFO - 2016-09-08 12:26:53 --> Config Class Initialized
INFO - 2016-09-08 12:26:53 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:26:53 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:26:53 --> Utf8 Class Initialized
INFO - 2016-09-08 12:26:53 --> URI Class Initialized
INFO - 2016-09-08 12:26:53 --> Router Class Initialized
INFO - 2016-09-08 12:26:53 --> Output Class Initialized
INFO - 2016-09-08 12:26:53 --> Security Class Initialized
DEBUG - 2016-09-08 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:26:53 --> Input Class Initialized
INFO - 2016-09-08 12:26:53 --> Language Class Initialized
INFO - 2016-09-08 12:26:53 --> Loader Class Initialized
INFO - 2016-09-08 12:26:53 --> Helper loaded: url_helper
INFO - 2016-09-08 12:26:53 --> Helper loaded: language_helper
INFO - 2016-09-08 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:26:53 --> Controller Class Initialized
INFO - 2016-09-08 12:26:53 --> Database Driver Class Initialized
INFO - 2016-09-08 12:26:53 --> Model Class Initialized
INFO - 2016-09-08 12:26:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:26:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:26:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:26:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:26:53 --> Final output sent to browser
DEBUG - 2016-09-08 12:26:53 --> Total execution time: 0.0695
INFO - 2016-09-08 12:28:40 --> Config Class Initialized
INFO - 2016-09-08 12:28:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:28:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:28:40 --> Utf8 Class Initialized
INFO - 2016-09-08 12:28:40 --> URI Class Initialized
INFO - 2016-09-08 12:28:40 --> Router Class Initialized
INFO - 2016-09-08 12:28:40 --> Output Class Initialized
INFO - 2016-09-08 12:28:40 --> Security Class Initialized
DEBUG - 2016-09-08 12:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:28:40 --> Input Class Initialized
INFO - 2016-09-08 12:28:40 --> Language Class Initialized
INFO - 2016-09-08 12:28:40 --> Loader Class Initialized
INFO - 2016-09-08 12:28:40 --> Helper loaded: url_helper
INFO - 2016-09-08 12:28:40 --> Helper loaded: language_helper
INFO - 2016-09-08 12:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:28:40 --> Controller Class Initialized
INFO - 2016-09-08 12:28:40 --> Database Driver Class Initialized
INFO - 2016-09-08 12:28:40 --> Model Class Initialized
INFO - 2016-09-08 12:28:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:28:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:28:48 --> Config Class Initialized
INFO - 2016-09-08 12:28:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:28:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:28:48 --> Utf8 Class Initialized
INFO - 2016-09-08 12:28:48 --> URI Class Initialized
INFO - 2016-09-08 12:28:48 --> Router Class Initialized
INFO - 2016-09-08 12:28:48 --> Output Class Initialized
INFO - 2016-09-08 12:28:48 --> Security Class Initialized
DEBUG - 2016-09-08 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:28:48 --> Input Class Initialized
INFO - 2016-09-08 12:28:48 --> Language Class Initialized
INFO - 2016-09-08 12:28:48 --> Loader Class Initialized
INFO - 2016-09-08 12:28:48 --> Helper loaded: url_helper
INFO - 2016-09-08 12:28:48 --> Helper loaded: language_helper
INFO - 2016-09-08 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:28:48 --> Controller Class Initialized
INFO - 2016-09-08 12:28:48 --> Database Driver Class Initialized
INFO - 2016-09-08 12:28:48 --> Model Class Initialized
INFO - 2016-09-08 12:28:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:28:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:28:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:28:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:28:48 --> Final output sent to browser
DEBUG - 2016-09-08 12:28:48 --> Total execution time: 0.0703
INFO - 2016-09-08 12:30:21 --> Config Class Initialized
INFO - 2016-09-08 12:30:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:30:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:30:21 --> Utf8 Class Initialized
INFO - 2016-09-08 12:30:21 --> URI Class Initialized
INFO - 2016-09-08 12:30:21 --> Router Class Initialized
INFO - 2016-09-08 12:30:21 --> Output Class Initialized
INFO - 2016-09-08 12:30:21 --> Security Class Initialized
DEBUG - 2016-09-08 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:30:21 --> Input Class Initialized
INFO - 2016-09-08 12:30:21 --> Language Class Initialized
INFO - 2016-09-08 12:30:21 --> Loader Class Initialized
INFO - 2016-09-08 12:30:21 --> Helper loaded: url_helper
INFO - 2016-09-08 12:30:21 --> Helper loaded: language_helper
INFO - 2016-09-08 12:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:30:21 --> Controller Class Initialized
INFO - 2016-09-08 12:30:21 --> Database Driver Class Initialized
INFO - 2016-09-08 12:30:21 --> Model Class Initialized
INFO - 2016-09-08 12:30:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:30:21 --> Final output sent to browser
DEBUG - 2016-09-08 12:30:21 --> Total execution time: 0.0594
INFO - 2016-09-08 12:31:20 --> Config Class Initialized
INFO - 2016-09-08 12:31:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:31:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:31:20 --> Utf8 Class Initialized
INFO - 2016-09-08 12:31:20 --> URI Class Initialized
INFO - 2016-09-08 12:31:20 --> Router Class Initialized
INFO - 2016-09-08 12:31:20 --> Output Class Initialized
INFO - 2016-09-08 12:31:20 --> Security Class Initialized
DEBUG - 2016-09-08 12:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:31:20 --> Input Class Initialized
INFO - 2016-09-08 12:31:20 --> Language Class Initialized
INFO - 2016-09-08 12:31:20 --> Loader Class Initialized
INFO - 2016-09-08 12:31:20 --> Helper loaded: url_helper
INFO - 2016-09-08 12:31:20 --> Helper loaded: language_helper
INFO - 2016-09-08 12:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:31:20 --> Controller Class Initialized
INFO - 2016-09-08 12:31:20 --> Database Driver Class Initialized
INFO - 2016-09-08 12:31:20 --> Model Class Initialized
INFO - 2016-09-08 12:31:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:31:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:31:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:31:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:31:20 --> Final output sent to browser
DEBUG - 2016-09-08 12:31:20 --> Total execution time: 0.0770
INFO - 2016-09-08 12:32:28 --> Config Class Initialized
INFO - 2016-09-08 12:32:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:32:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:32:28 --> Utf8 Class Initialized
INFO - 2016-09-08 12:32:28 --> URI Class Initialized
INFO - 2016-09-08 12:32:28 --> Router Class Initialized
INFO - 2016-09-08 12:32:28 --> Output Class Initialized
INFO - 2016-09-08 12:32:28 --> Security Class Initialized
DEBUG - 2016-09-08 12:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:32:28 --> Input Class Initialized
INFO - 2016-09-08 12:32:28 --> Language Class Initialized
INFO - 2016-09-08 12:32:28 --> Loader Class Initialized
INFO - 2016-09-08 12:32:28 --> Helper loaded: url_helper
INFO - 2016-09-08 12:32:28 --> Helper loaded: language_helper
INFO - 2016-09-08 12:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:32:28 --> Controller Class Initialized
INFO - 2016-09-08 12:32:28 --> Database Driver Class Initialized
INFO - 2016-09-08 12:32:28 --> Model Class Initialized
INFO - 2016-09-08 12:32:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:32:28 --> Helper loaded: form_helper
INFO - 2016-09-08 12:32:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:32:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:32:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:32:28 --> Final output sent to browser
DEBUG - 2016-09-08 12:32:28 --> Total execution time: 0.0809
INFO - 2016-09-08 12:33:45 --> Config Class Initialized
INFO - 2016-09-08 12:33:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:33:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:33:45 --> Utf8 Class Initialized
INFO - 2016-09-08 12:33:45 --> URI Class Initialized
INFO - 2016-09-08 12:33:45 --> Router Class Initialized
INFO - 2016-09-08 12:33:45 --> Output Class Initialized
INFO - 2016-09-08 12:33:45 --> Security Class Initialized
DEBUG - 2016-09-08 12:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:33:45 --> Input Class Initialized
INFO - 2016-09-08 12:33:45 --> Language Class Initialized
INFO - 2016-09-08 12:33:45 --> Loader Class Initialized
INFO - 2016-09-08 12:33:45 --> Helper loaded: url_helper
INFO - 2016-09-08 12:33:45 --> Helper loaded: language_helper
INFO - 2016-09-08 12:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:33:45 --> Controller Class Initialized
INFO - 2016-09-08 12:33:45 --> Database Driver Class Initialized
INFO - 2016-09-08 12:33:45 --> Model Class Initialized
INFO - 2016-09-08 12:33:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:33:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:33:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 12:33:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:33:45 --> Final output sent to browser
DEBUG - 2016-09-08 12:33:45 --> Total execution time: 0.0582
INFO - 2016-09-08 12:33:50 --> Config Class Initialized
INFO - 2016-09-08 12:33:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:33:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:33:50 --> Utf8 Class Initialized
INFO - 2016-09-08 12:33:50 --> URI Class Initialized
INFO - 2016-09-08 12:33:50 --> Router Class Initialized
INFO - 2016-09-08 12:33:50 --> Output Class Initialized
INFO - 2016-09-08 12:33:50 --> Security Class Initialized
DEBUG - 2016-09-08 12:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:33:50 --> Input Class Initialized
INFO - 2016-09-08 12:33:50 --> Language Class Initialized
INFO - 2016-09-08 12:33:50 --> Loader Class Initialized
INFO - 2016-09-08 12:33:50 --> Helper loaded: url_helper
INFO - 2016-09-08 12:33:50 --> Helper loaded: language_helper
INFO - 2016-09-08 12:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:33:50 --> Controller Class Initialized
INFO - 2016-09-08 12:33:50 --> Database Driver Class Initialized
INFO - 2016-09-08 12:33:50 --> Model Class Initialized
INFO - 2016-09-08 12:33:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:33:50 --> Config Class Initialized
INFO - 2016-09-08 12:33:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:33:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:33:50 --> Utf8 Class Initialized
INFO - 2016-09-08 12:33:50 --> URI Class Initialized
INFO - 2016-09-08 12:33:50 --> Router Class Initialized
INFO - 2016-09-08 12:33:50 --> Output Class Initialized
INFO - 2016-09-08 12:33:50 --> Security Class Initialized
DEBUG - 2016-09-08 12:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:33:50 --> Input Class Initialized
INFO - 2016-09-08 12:33:50 --> Language Class Initialized
INFO - 2016-09-08 12:33:50 --> Loader Class Initialized
INFO - 2016-09-08 12:33:50 --> Helper loaded: url_helper
INFO - 2016-09-08 12:33:50 --> Helper loaded: language_helper
INFO - 2016-09-08 12:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:33:50 --> Controller Class Initialized
INFO - 2016-09-08 12:33:50 --> Database Driver Class Initialized
INFO - 2016-09-08 12:33:50 --> Model Class Initialized
INFO - 2016-09-08 12:33:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:33:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:33:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_3.php
INFO - 2016-09-08 12:33:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:33:50 --> Final output sent to browser
DEBUG - 2016-09-08 12:33:50 --> Total execution time: 0.0704
INFO - 2016-09-08 12:34:00 --> Config Class Initialized
INFO - 2016-09-08 12:34:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:34:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:34:00 --> Utf8 Class Initialized
INFO - 2016-09-08 12:34:00 --> URI Class Initialized
INFO - 2016-09-08 12:34:00 --> Router Class Initialized
INFO - 2016-09-08 12:34:00 --> Output Class Initialized
INFO - 2016-09-08 12:34:00 --> Security Class Initialized
DEBUG - 2016-09-08 12:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:34:00 --> Input Class Initialized
INFO - 2016-09-08 12:34:00 --> Language Class Initialized
INFO - 2016-09-08 12:34:00 --> Loader Class Initialized
INFO - 2016-09-08 12:34:00 --> Helper loaded: url_helper
INFO - 2016-09-08 12:34:00 --> Helper loaded: language_helper
INFO - 2016-09-08 12:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:34:00 --> Controller Class Initialized
INFO - 2016-09-08 12:34:00 --> Database Driver Class Initialized
INFO - 2016-09-08 12:34:00 --> Model Class Initialized
INFO - 2016-09-08 12:34:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:34:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:34:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 12:34:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:34:00 --> Final output sent to browser
DEBUG - 2016-09-08 12:34:00 --> Total execution time: 0.0547
INFO - 2016-09-08 12:34:06 --> Config Class Initialized
INFO - 2016-09-08 12:34:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:34:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:34:06 --> Utf8 Class Initialized
INFO - 2016-09-08 12:34:06 --> URI Class Initialized
INFO - 2016-09-08 12:34:06 --> Router Class Initialized
INFO - 2016-09-08 12:34:06 --> Output Class Initialized
INFO - 2016-09-08 12:34:06 --> Security Class Initialized
DEBUG - 2016-09-08 12:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:34:06 --> Input Class Initialized
INFO - 2016-09-08 12:34:06 --> Language Class Initialized
INFO - 2016-09-08 12:34:06 --> Loader Class Initialized
INFO - 2016-09-08 12:34:06 --> Helper loaded: url_helper
INFO - 2016-09-08 12:34:06 --> Helper loaded: language_helper
INFO - 2016-09-08 12:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:34:06 --> Controller Class Initialized
INFO - 2016-09-08 12:34:06 --> Database Driver Class Initialized
INFO - 2016-09-08 12:34:06 --> Model Class Initialized
INFO - 2016-09-08 12:34:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:34:06 --> Helper loaded: form_helper
INFO - 2016-09-08 12:34:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:34:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:34:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:34:06 --> Final output sent to browser
DEBUG - 2016-09-08 12:34:06 --> Total execution time: 0.0667
INFO - 2016-09-08 12:34:19 --> Config Class Initialized
INFO - 2016-09-08 12:34:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:34:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:34:19 --> Utf8 Class Initialized
INFO - 2016-09-08 12:34:19 --> URI Class Initialized
INFO - 2016-09-08 12:34:19 --> Router Class Initialized
INFO - 2016-09-08 12:34:19 --> Output Class Initialized
INFO - 2016-09-08 12:34:19 --> Security Class Initialized
DEBUG - 2016-09-08 12:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:34:19 --> Input Class Initialized
INFO - 2016-09-08 12:34:19 --> Language Class Initialized
INFO - 2016-09-08 12:34:19 --> Loader Class Initialized
INFO - 2016-09-08 12:34:19 --> Helper loaded: url_helper
INFO - 2016-09-08 12:34:19 --> Helper loaded: language_helper
INFO - 2016-09-08 12:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:34:19 --> Controller Class Initialized
INFO - 2016-09-08 12:34:19 --> Database Driver Class Initialized
INFO - 2016-09-08 12:34:19 --> Model Class Initialized
INFO - 2016-09-08 12:34:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:34:19 --> Helper loaded: form_helper
INFO - 2016-09-08 12:34:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:34:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:34:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:34:19 --> Final output sent to browser
DEBUG - 2016-09-08 12:34:19 --> Total execution time: 0.0652
INFO - 2016-09-08 12:34:22 --> Config Class Initialized
INFO - 2016-09-08 12:34:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:34:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:34:22 --> Utf8 Class Initialized
INFO - 2016-09-08 12:34:22 --> URI Class Initialized
INFO - 2016-09-08 12:34:22 --> Router Class Initialized
INFO - 2016-09-08 12:34:22 --> Output Class Initialized
INFO - 2016-09-08 12:34:22 --> Security Class Initialized
DEBUG - 2016-09-08 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:34:22 --> Input Class Initialized
INFO - 2016-09-08 12:34:22 --> Language Class Initialized
INFO - 2016-09-08 12:34:22 --> Loader Class Initialized
INFO - 2016-09-08 12:34:22 --> Helper loaded: url_helper
INFO - 2016-09-08 12:34:22 --> Helper loaded: language_helper
INFO - 2016-09-08 12:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:34:22 --> Controller Class Initialized
INFO - 2016-09-08 12:34:22 --> Database Driver Class Initialized
INFO - 2016-09-08 12:34:22 --> Model Class Initialized
INFO - 2016-09-08 12:34:22 --> Model Class Initialized
INFO - 2016-09-08 12:34:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:34:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:34:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-08 12:34:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:34:22 --> Final output sent to browser
DEBUG - 2016-09-08 12:34:22 --> Total execution time: 0.0659
INFO - 2016-09-08 12:34:30 --> Config Class Initialized
INFO - 2016-09-08 12:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:34:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:34:30 --> Utf8 Class Initialized
INFO - 2016-09-08 12:34:30 --> URI Class Initialized
INFO - 2016-09-08 12:34:30 --> Router Class Initialized
INFO - 2016-09-08 12:34:30 --> Output Class Initialized
INFO - 2016-09-08 12:34:30 --> Security Class Initialized
DEBUG - 2016-09-08 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:34:30 --> Input Class Initialized
INFO - 2016-09-08 12:34:30 --> Language Class Initialized
INFO - 2016-09-08 12:34:30 --> Loader Class Initialized
INFO - 2016-09-08 12:34:30 --> Helper loaded: url_helper
INFO - 2016-09-08 12:34:30 --> Helper loaded: language_helper
INFO - 2016-09-08 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:34:30 --> Controller Class Initialized
INFO - 2016-09-08 12:34:30 --> Database Driver Class Initialized
INFO - 2016-09-08 12:34:30 --> Model Class Initialized
INFO - 2016-09-08 12:34:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:34:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:34:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 12:34:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:34:30 --> Final output sent to browser
DEBUG - 2016-09-08 12:34:30 --> Total execution time: 0.0562
INFO - 2016-09-08 12:34:31 --> Config Class Initialized
INFO - 2016-09-08 12:34:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:34:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:34:31 --> Utf8 Class Initialized
INFO - 2016-09-08 12:34:31 --> URI Class Initialized
INFO - 2016-09-08 12:34:31 --> Router Class Initialized
INFO - 2016-09-08 12:34:31 --> Output Class Initialized
INFO - 2016-09-08 12:34:31 --> Security Class Initialized
DEBUG - 2016-09-08 12:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:34:31 --> Input Class Initialized
INFO - 2016-09-08 12:34:31 --> Language Class Initialized
INFO - 2016-09-08 12:34:31 --> Loader Class Initialized
INFO - 2016-09-08 12:34:31 --> Helper loaded: url_helper
INFO - 2016-09-08 12:34:31 --> Helper loaded: language_helper
INFO - 2016-09-08 12:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:34:31 --> Controller Class Initialized
INFO - 2016-09-08 12:34:31 --> Database Driver Class Initialized
INFO - 2016-09-08 12:34:31 --> Model Class Initialized
INFO - 2016-09-08 12:34:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:34:31 --> Helper loaded: form_helper
INFO - 2016-09-08 12:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:34:31 --> Final output sent to browser
DEBUG - 2016-09-08 12:34:31 --> Total execution time: 0.0756
INFO - 2016-09-08 12:37:34 --> Config Class Initialized
INFO - 2016-09-08 12:37:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:37:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:37:34 --> Utf8 Class Initialized
INFO - 2016-09-08 12:37:34 --> URI Class Initialized
INFO - 2016-09-08 12:37:34 --> Router Class Initialized
INFO - 2016-09-08 12:37:34 --> Output Class Initialized
INFO - 2016-09-08 12:37:34 --> Security Class Initialized
DEBUG - 2016-09-08 12:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:37:34 --> Input Class Initialized
INFO - 2016-09-08 12:37:34 --> Language Class Initialized
INFO - 2016-09-08 12:37:34 --> Loader Class Initialized
INFO - 2016-09-08 12:37:34 --> Helper loaded: url_helper
INFO - 2016-09-08 12:37:34 --> Helper loaded: language_helper
INFO - 2016-09-08 12:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:37:34 --> Controller Class Initialized
INFO - 2016-09-08 12:37:34 --> Database Driver Class Initialized
INFO - 2016-09-08 12:37:34 --> Model Class Initialized
INFO - 2016-09-08 12:37:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:37:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:37:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:37:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:37:34 --> Final output sent to browser
DEBUG - 2016-09-08 12:37:34 --> Total execution time: 0.0780
INFO - 2016-09-08 12:38:52 --> Config Class Initialized
INFO - 2016-09-08 12:38:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:38:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:38:52 --> Utf8 Class Initialized
INFO - 2016-09-08 12:38:52 --> URI Class Initialized
INFO - 2016-09-08 12:38:52 --> Router Class Initialized
INFO - 2016-09-08 12:38:52 --> Output Class Initialized
INFO - 2016-09-08 12:38:52 --> Security Class Initialized
DEBUG - 2016-09-08 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:38:52 --> Input Class Initialized
INFO - 2016-09-08 12:38:52 --> Language Class Initialized
INFO - 2016-09-08 12:38:52 --> Loader Class Initialized
INFO - 2016-09-08 12:38:52 --> Helper loaded: url_helper
INFO - 2016-09-08 12:38:52 --> Helper loaded: language_helper
INFO - 2016-09-08 12:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:38:52 --> Controller Class Initialized
INFO - 2016-09-08 12:38:52 --> Database Driver Class Initialized
INFO - 2016-09-08 12:38:52 --> Model Class Initialized
INFO - 2016-09-08 12:38:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:38:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:38:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:38:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:38:52 --> Final output sent to browser
DEBUG - 2016-09-08 12:38:52 --> Total execution time: 0.0639
INFO - 2016-09-08 12:40:14 --> Config Class Initialized
INFO - 2016-09-08 12:40:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:40:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:40:14 --> Utf8 Class Initialized
INFO - 2016-09-08 12:40:14 --> URI Class Initialized
INFO - 2016-09-08 12:40:14 --> Router Class Initialized
INFO - 2016-09-08 12:40:14 --> Output Class Initialized
INFO - 2016-09-08 12:40:14 --> Security Class Initialized
DEBUG - 2016-09-08 12:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:40:14 --> Input Class Initialized
INFO - 2016-09-08 12:40:14 --> Language Class Initialized
INFO - 2016-09-08 12:40:14 --> Loader Class Initialized
INFO - 2016-09-08 12:40:14 --> Helper loaded: url_helper
INFO - 2016-09-08 12:40:14 --> Helper loaded: language_helper
INFO - 2016-09-08 12:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:40:14 --> Controller Class Initialized
INFO - 2016-09-08 12:40:14 --> Database Driver Class Initialized
INFO - 2016-09-08 12:40:14 --> Model Class Initialized
INFO - 2016-09-08 12:40:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:40:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:40:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:40:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:40:14 --> Final output sent to browser
DEBUG - 2016-09-08 12:40:14 --> Total execution time: 0.0603
INFO - 2016-09-08 12:44:27 --> Config Class Initialized
INFO - 2016-09-08 12:44:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:44:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:44:27 --> Utf8 Class Initialized
INFO - 2016-09-08 12:44:27 --> URI Class Initialized
INFO - 2016-09-08 12:44:27 --> Router Class Initialized
INFO - 2016-09-08 12:44:27 --> Output Class Initialized
INFO - 2016-09-08 12:44:27 --> Security Class Initialized
DEBUG - 2016-09-08 12:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:44:27 --> Input Class Initialized
INFO - 2016-09-08 12:44:27 --> Language Class Initialized
INFO - 2016-09-08 12:44:27 --> Loader Class Initialized
INFO - 2016-09-08 12:44:27 --> Helper loaded: url_helper
INFO - 2016-09-08 12:44:27 --> Helper loaded: language_helper
INFO - 2016-09-08 12:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:44:27 --> Controller Class Initialized
INFO - 2016-09-08 12:44:27 --> Database Driver Class Initialized
INFO - 2016-09-08 12:44:27 --> Model Class Initialized
INFO - 2016-09-08 12:44:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:44:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:44:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:44:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:44:27 --> Final output sent to browser
DEBUG - 2016-09-08 12:44:27 --> Total execution time: 0.0632
INFO - 2016-09-08 12:45:12 --> Config Class Initialized
INFO - 2016-09-08 12:45:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:45:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:45:12 --> Utf8 Class Initialized
INFO - 2016-09-08 12:45:12 --> URI Class Initialized
INFO - 2016-09-08 12:45:12 --> Router Class Initialized
INFO - 2016-09-08 12:45:12 --> Output Class Initialized
INFO - 2016-09-08 12:45:12 --> Security Class Initialized
DEBUG - 2016-09-08 12:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:45:12 --> Input Class Initialized
INFO - 2016-09-08 12:45:12 --> Language Class Initialized
INFO - 2016-09-08 12:45:12 --> Loader Class Initialized
INFO - 2016-09-08 12:45:12 --> Helper loaded: url_helper
INFO - 2016-09-08 12:45:12 --> Helper loaded: language_helper
INFO - 2016-09-08 12:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:45:12 --> Controller Class Initialized
INFO - 2016-09-08 12:45:12 --> Database Driver Class Initialized
INFO - 2016-09-08 12:45:12 --> Model Class Initialized
INFO - 2016-09-08 12:45:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:45:12 --> Final output sent to browser
DEBUG - 2016-09-08 12:45:12 --> Total execution time: 0.0755
INFO - 2016-09-08 12:51:44 --> Config Class Initialized
INFO - 2016-09-08 12:51:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:51:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:51:44 --> Utf8 Class Initialized
INFO - 2016-09-08 12:51:44 --> URI Class Initialized
INFO - 2016-09-08 12:51:44 --> Router Class Initialized
INFO - 2016-09-08 12:51:44 --> Output Class Initialized
INFO - 2016-09-08 12:51:44 --> Security Class Initialized
DEBUG - 2016-09-08 12:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:51:44 --> Input Class Initialized
INFO - 2016-09-08 12:51:44 --> Language Class Initialized
INFO - 2016-09-08 12:51:44 --> Loader Class Initialized
INFO - 2016-09-08 12:51:44 --> Helper loaded: url_helper
INFO - 2016-09-08 12:51:44 --> Helper loaded: language_helper
INFO - 2016-09-08 12:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:51:44 --> Controller Class Initialized
INFO - 2016-09-08 12:51:44 --> Database Driver Class Initialized
INFO - 2016-09-08 12:51:44 --> Model Class Initialized
INFO - 2016-09-08 12:51:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:51:44 --> Config Class Initialized
INFO - 2016-09-08 12:51:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:51:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:51:44 --> Utf8 Class Initialized
INFO - 2016-09-08 12:51:44 --> URI Class Initialized
INFO - 2016-09-08 12:51:44 --> Router Class Initialized
INFO - 2016-09-08 12:51:44 --> Output Class Initialized
INFO - 2016-09-08 12:51:44 --> Security Class Initialized
DEBUG - 2016-09-08 12:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:51:44 --> Input Class Initialized
INFO - 2016-09-08 12:51:44 --> Language Class Initialized
INFO - 2016-09-08 12:51:44 --> Loader Class Initialized
INFO - 2016-09-08 12:51:44 --> Helper loaded: url_helper
INFO - 2016-09-08 12:51:44 --> Helper loaded: language_helper
INFO - 2016-09-08 12:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:51:44 --> Controller Class Initialized
INFO - 2016-09-08 12:51:44 --> Database Driver Class Initialized
INFO - 2016-09-08 12:51:44 --> Model Class Initialized
INFO - 2016-09-08 12:51:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:51:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:51:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:51:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:51:44 --> Final output sent to browser
DEBUG - 2016-09-08 12:51:44 --> Total execution time: 0.0655
INFO - 2016-09-08 12:51:58 --> Config Class Initialized
INFO - 2016-09-08 12:51:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:51:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:51:58 --> Utf8 Class Initialized
INFO - 2016-09-08 12:51:58 --> URI Class Initialized
INFO - 2016-09-08 12:51:58 --> Router Class Initialized
INFO - 2016-09-08 12:51:58 --> Output Class Initialized
INFO - 2016-09-08 12:51:58 --> Security Class Initialized
DEBUG - 2016-09-08 12:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:51:58 --> Input Class Initialized
INFO - 2016-09-08 12:51:58 --> Language Class Initialized
INFO - 2016-09-08 12:51:58 --> Loader Class Initialized
INFO - 2016-09-08 12:51:58 --> Helper loaded: url_helper
INFO - 2016-09-08 12:51:58 --> Helper loaded: language_helper
INFO - 2016-09-08 12:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:51:58 --> Controller Class Initialized
INFO - 2016-09-08 12:51:59 --> Database Driver Class Initialized
INFO - 2016-09-08 12:51:59 --> Model Class Initialized
INFO - 2016-09-08 12:51:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:51:59 --> Config Class Initialized
INFO - 2016-09-08 12:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:51:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:51:59 --> Utf8 Class Initialized
INFO - 2016-09-08 12:51:59 --> URI Class Initialized
INFO - 2016-09-08 12:51:59 --> Router Class Initialized
INFO - 2016-09-08 12:51:59 --> Output Class Initialized
INFO - 2016-09-08 12:51:59 --> Security Class Initialized
DEBUG - 2016-09-08 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:51:59 --> Input Class Initialized
INFO - 2016-09-08 12:51:59 --> Language Class Initialized
INFO - 2016-09-08 12:51:59 --> Loader Class Initialized
INFO - 2016-09-08 12:51:59 --> Helper loaded: url_helper
INFO - 2016-09-08 12:51:59 --> Helper loaded: language_helper
INFO - 2016-09-08 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:51:59 --> Controller Class Initialized
INFO - 2016-09-08 12:51:59 --> Database Driver Class Initialized
INFO - 2016-09-08 12:51:59 --> Model Class Initialized
INFO - 2016-09-08 12:51:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:51:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:51:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:51:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:51:59 --> Final output sent to browser
DEBUG - 2016-09-08 12:51:59 --> Total execution time: 0.0811
INFO - 2016-09-08 12:53:10 --> Config Class Initialized
INFO - 2016-09-08 12:53:10 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:53:10 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:53:10 --> Utf8 Class Initialized
INFO - 2016-09-08 12:53:10 --> URI Class Initialized
INFO - 2016-09-08 12:53:10 --> Router Class Initialized
INFO - 2016-09-08 12:53:10 --> Output Class Initialized
INFO - 2016-09-08 12:53:10 --> Security Class Initialized
DEBUG - 2016-09-08 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:53:10 --> Input Class Initialized
INFO - 2016-09-08 12:53:10 --> Language Class Initialized
INFO - 2016-09-08 12:53:10 --> Loader Class Initialized
INFO - 2016-09-08 12:53:10 --> Helper loaded: url_helper
INFO - 2016-09-08 12:53:10 --> Helper loaded: language_helper
INFO - 2016-09-08 12:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:53:10 --> Controller Class Initialized
INFO - 2016-09-08 12:53:10 --> Database Driver Class Initialized
INFO - 2016-09-08 12:53:10 --> Model Class Initialized
INFO - 2016-09-08 12:53:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:53:10 --> Helper loaded: form_helper
INFO - 2016-09-08 12:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:53:10 --> Final output sent to browser
DEBUG - 2016-09-08 12:53:10 --> Total execution time: 0.0658
INFO - 2016-09-08 12:53:12 --> Config Class Initialized
INFO - 2016-09-08 12:53:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:53:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:53:12 --> Utf8 Class Initialized
INFO - 2016-09-08 12:53:12 --> URI Class Initialized
INFO - 2016-09-08 12:53:12 --> Router Class Initialized
INFO - 2016-09-08 12:53:12 --> Output Class Initialized
INFO - 2016-09-08 12:53:12 --> Security Class Initialized
DEBUG - 2016-09-08 12:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:53:12 --> Input Class Initialized
INFO - 2016-09-08 12:53:12 --> Language Class Initialized
INFO - 2016-09-08 12:53:12 --> Loader Class Initialized
INFO - 2016-09-08 12:53:12 --> Helper loaded: url_helper
INFO - 2016-09-08 12:53:12 --> Helper loaded: language_helper
INFO - 2016-09-08 12:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:53:12 --> Controller Class Initialized
INFO - 2016-09-08 12:53:12 --> Database Driver Class Initialized
INFO - 2016-09-08 12:53:12 --> Model Class Initialized
INFO - 2016-09-08 12:53:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:53:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:53:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:53:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:53:12 --> Final output sent to browser
DEBUG - 2016-09-08 12:53:12 --> Total execution time: 0.0621
INFO - 2016-09-08 12:53:48 --> Config Class Initialized
INFO - 2016-09-08 12:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:53:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:53:48 --> Utf8 Class Initialized
INFO - 2016-09-08 12:53:48 --> URI Class Initialized
INFO - 2016-09-08 12:53:48 --> Router Class Initialized
INFO - 2016-09-08 12:53:48 --> Output Class Initialized
INFO - 2016-09-08 12:53:48 --> Security Class Initialized
DEBUG - 2016-09-08 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:53:48 --> Input Class Initialized
INFO - 2016-09-08 12:53:48 --> Language Class Initialized
INFO - 2016-09-08 12:53:48 --> Loader Class Initialized
INFO - 2016-09-08 12:53:48 --> Helper loaded: url_helper
INFO - 2016-09-08 12:53:48 --> Helper loaded: language_helper
INFO - 2016-09-08 12:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:53:48 --> Controller Class Initialized
INFO - 2016-09-08 12:53:48 --> Database Driver Class Initialized
INFO - 2016-09-08 12:53:48 --> Model Class Initialized
INFO - 2016-09-08 12:53:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:54:08 --> Config Class Initialized
INFO - 2016-09-08 12:54:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:54:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:54:08 --> Utf8 Class Initialized
INFO - 2016-09-08 12:54:08 --> URI Class Initialized
INFO - 2016-09-08 12:54:08 --> Router Class Initialized
INFO - 2016-09-08 12:54:08 --> Output Class Initialized
INFO - 2016-09-08 12:54:08 --> Security Class Initialized
DEBUG - 2016-09-08 12:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:54:08 --> Input Class Initialized
INFO - 2016-09-08 12:54:08 --> Language Class Initialized
INFO - 2016-09-08 12:54:08 --> Loader Class Initialized
INFO - 2016-09-08 12:54:08 --> Helper loaded: url_helper
INFO - 2016-09-08 12:54:08 --> Helper loaded: language_helper
INFO - 2016-09-08 12:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:54:08 --> Controller Class Initialized
INFO - 2016-09-08 12:54:08 --> Database Driver Class Initialized
INFO - 2016-09-08 12:54:08 --> Model Class Initialized
INFO - 2016-09-08 12:54:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:54:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:54:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:54:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:54:08 --> Final output sent to browser
DEBUG - 2016-09-08 12:54:08 --> Total execution time: 0.0630
INFO - 2016-09-08 12:54:31 --> Config Class Initialized
INFO - 2016-09-08 12:54:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:54:31 --> Utf8 Class Initialized
INFO - 2016-09-08 12:54:31 --> URI Class Initialized
INFO - 2016-09-08 12:54:31 --> Router Class Initialized
INFO - 2016-09-08 12:54:31 --> Output Class Initialized
INFO - 2016-09-08 12:54:31 --> Security Class Initialized
DEBUG - 2016-09-08 12:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:54:31 --> Input Class Initialized
INFO - 2016-09-08 12:54:31 --> Language Class Initialized
INFO - 2016-09-08 12:54:31 --> Loader Class Initialized
INFO - 2016-09-08 12:54:31 --> Helper loaded: url_helper
INFO - 2016-09-08 12:54:31 --> Helper loaded: language_helper
INFO - 2016-09-08 12:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:54:31 --> Controller Class Initialized
INFO - 2016-09-08 12:54:31 --> Database Driver Class Initialized
INFO - 2016-09-08 12:54:31 --> Model Class Initialized
INFO - 2016-09-08 12:54:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:54:31 --> Final output sent to browser
DEBUG - 2016-09-08 12:54:31 --> Total execution time: 0.0594
INFO - 2016-09-08 12:54:41 --> Config Class Initialized
INFO - 2016-09-08 12:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:54:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:54:41 --> Utf8 Class Initialized
INFO - 2016-09-08 12:54:41 --> URI Class Initialized
INFO - 2016-09-08 12:54:41 --> Router Class Initialized
INFO - 2016-09-08 12:54:41 --> Output Class Initialized
INFO - 2016-09-08 12:54:41 --> Security Class Initialized
DEBUG - 2016-09-08 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:54:41 --> Input Class Initialized
INFO - 2016-09-08 12:54:41 --> Language Class Initialized
INFO - 2016-09-08 12:54:41 --> Loader Class Initialized
INFO - 2016-09-08 12:54:41 --> Helper loaded: url_helper
INFO - 2016-09-08 12:54:41 --> Helper loaded: language_helper
INFO - 2016-09-08 12:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:54:41 --> Controller Class Initialized
INFO - 2016-09-08 12:54:41 --> Database Driver Class Initialized
INFO - 2016-09-08 12:54:41 --> Model Class Initialized
INFO - 2016-09-08 12:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:54:41 --> Config Class Initialized
INFO - 2016-09-08 12:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:54:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:54:41 --> Utf8 Class Initialized
INFO - 2016-09-08 12:54:41 --> URI Class Initialized
INFO - 2016-09-08 12:54:41 --> Router Class Initialized
INFO - 2016-09-08 12:54:41 --> Output Class Initialized
INFO - 2016-09-08 12:54:41 --> Security Class Initialized
DEBUG - 2016-09-08 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:54:41 --> Input Class Initialized
INFO - 2016-09-08 12:54:41 --> Language Class Initialized
INFO - 2016-09-08 12:54:41 --> Loader Class Initialized
INFO - 2016-09-08 12:54:41 --> Helper loaded: url_helper
INFO - 2016-09-08 12:54:41 --> Helper loaded: language_helper
INFO - 2016-09-08 12:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:54:41 --> Controller Class Initialized
INFO - 2016-09-08 12:54:41 --> Database Driver Class Initialized
INFO - 2016-09-08 12:54:41 --> Model Class Initialized
INFO - 2016-09-08 12:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:54:41 --> Final output sent to browser
DEBUG - 2016-09-08 12:54:41 --> Total execution time: 0.0588
INFO - 2016-09-08 12:55:36 --> Config Class Initialized
INFO - 2016-09-08 12:55:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:55:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:55:36 --> Utf8 Class Initialized
INFO - 2016-09-08 12:55:36 --> URI Class Initialized
INFO - 2016-09-08 12:55:36 --> Router Class Initialized
INFO - 2016-09-08 12:55:36 --> Output Class Initialized
INFO - 2016-09-08 12:55:36 --> Security Class Initialized
DEBUG - 2016-09-08 12:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:55:36 --> Input Class Initialized
INFO - 2016-09-08 12:55:36 --> Language Class Initialized
INFO - 2016-09-08 12:55:36 --> Loader Class Initialized
INFO - 2016-09-08 12:55:36 --> Helper loaded: url_helper
INFO - 2016-09-08 12:55:36 --> Helper loaded: language_helper
INFO - 2016-09-08 12:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:55:36 --> Controller Class Initialized
INFO - 2016-09-08 12:55:36 --> Database Driver Class Initialized
INFO - 2016-09-08 12:55:36 --> Model Class Initialized
INFO - 2016-09-08 12:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 12:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:55:36 --> Final output sent to browser
DEBUG - 2016-09-08 12:55:36 --> Total execution time: 0.0670
INFO - 2016-09-08 12:55:41 --> Config Class Initialized
INFO - 2016-09-08 12:55:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:55:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:55:41 --> Utf8 Class Initialized
INFO - 2016-09-08 12:55:41 --> URI Class Initialized
INFO - 2016-09-08 12:55:41 --> Router Class Initialized
INFO - 2016-09-08 12:55:41 --> Output Class Initialized
INFO - 2016-09-08 12:55:41 --> Security Class Initialized
DEBUG - 2016-09-08 12:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:55:41 --> Input Class Initialized
INFO - 2016-09-08 12:55:41 --> Language Class Initialized
INFO - 2016-09-08 12:55:41 --> Loader Class Initialized
INFO - 2016-09-08 12:55:41 --> Helper loaded: url_helper
INFO - 2016-09-08 12:55:41 --> Helper loaded: language_helper
INFO - 2016-09-08 12:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:55:41 --> Controller Class Initialized
INFO - 2016-09-08 12:55:41 --> Database Driver Class Initialized
INFO - 2016-09-08 12:55:41 --> Model Class Initialized
INFO - 2016-09-08 12:55:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:55:41 --> Config Class Initialized
INFO - 2016-09-08 12:55:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:55:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:55:41 --> Utf8 Class Initialized
INFO - 2016-09-08 12:55:41 --> URI Class Initialized
INFO - 2016-09-08 12:55:41 --> Router Class Initialized
INFO - 2016-09-08 12:55:41 --> Output Class Initialized
INFO - 2016-09-08 12:55:41 --> Security Class Initialized
DEBUG - 2016-09-08 12:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:55:41 --> Input Class Initialized
INFO - 2016-09-08 12:55:41 --> Language Class Initialized
INFO - 2016-09-08 12:55:41 --> Loader Class Initialized
INFO - 2016-09-08 12:55:41 --> Helper loaded: url_helper
INFO - 2016-09-08 12:55:41 --> Helper loaded: language_helper
INFO - 2016-09-08 12:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:55:41 --> Controller Class Initialized
INFO - 2016-09-08 12:55:41 --> Database Driver Class Initialized
INFO - 2016-09-08 12:55:41 --> Model Class Initialized
INFO - 2016-09-08 12:55:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:55:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2016-09-08 12:55:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2016-09-08 12:55:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2016-09-08 12:55:41 --> Final output sent to browser
DEBUG - 2016-09-08 12:55:41 --> Total execution time: 0.0618
INFO - 2016-09-08 12:56:28 --> Config Class Initialized
INFO - 2016-09-08 12:56:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:56:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:56:28 --> Utf8 Class Initialized
INFO - 2016-09-08 12:56:28 --> URI Class Initialized
INFO - 2016-09-08 12:56:28 --> Router Class Initialized
INFO - 2016-09-08 12:56:28 --> Output Class Initialized
INFO - 2016-09-08 12:56:28 --> Security Class Initialized
DEBUG - 2016-09-08 12:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:56:28 --> Input Class Initialized
INFO - 2016-09-08 12:56:28 --> Language Class Initialized
INFO - 2016-09-08 12:56:28 --> Loader Class Initialized
INFO - 2016-09-08 12:56:28 --> Helper loaded: url_helper
INFO - 2016-09-08 12:56:28 --> Helper loaded: language_helper
INFO - 2016-09-08 12:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:56:28 --> Controller Class Initialized
INFO - 2016-09-08 12:56:28 --> Database Driver Class Initialized
INFO - 2016-09-08 12:56:28 --> Model Class Initialized
INFO - 2016-09-08 12:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:56:28 --> Config Class Initialized
INFO - 2016-09-08 12:56:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:56:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:56:28 --> Utf8 Class Initialized
INFO - 2016-09-08 12:56:28 --> URI Class Initialized
INFO - 2016-09-08 12:56:28 --> Router Class Initialized
INFO - 2016-09-08 12:56:28 --> Output Class Initialized
INFO - 2016-09-08 12:56:28 --> Security Class Initialized
DEBUG - 2016-09-08 12:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:56:28 --> Input Class Initialized
INFO - 2016-09-08 12:56:28 --> Language Class Initialized
INFO - 2016-09-08 12:56:28 --> Loader Class Initialized
INFO - 2016-09-08 12:56:28 --> Helper loaded: url_helper
INFO - 2016-09-08 12:56:28 --> Helper loaded: language_helper
INFO - 2016-09-08 12:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:56:28 --> Controller Class Initialized
INFO - 2016-09-08 12:56:28 --> Database Driver Class Initialized
INFO - 2016-09-08 12:56:28 --> Model Class Initialized
INFO - 2016-09-08 12:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:56:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:56:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 12:56:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:56:28 --> Final output sent to browser
DEBUG - 2016-09-08 12:56:28 --> Total execution time: 0.0696
INFO - 2016-09-08 12:56:33 --> Config Class Initialized
INFO - 2016-09-08 12:56:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:56:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:56:33 --> Utf8 Class Initialized
INFO - 2016-09-08 12:56:33 --> URI Class Initialized
INFO - 2016-09-08 12:56:33 --> Router Class Initialized
INFO - 2016-09-08 12:56:33 --> Output Class Initialized
INFO - 2016-09-08 12:56:33 --> Security Class Initialized
DEBUG - 2016-09-08 12:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:56:33 --> Input Class Initialized
INFO - 2016-09-08 12:56:33 --> Language Class Initialized
INFO - 2016-09-08 12:56:33 --> Loader Class Initialized
INFO - 2016-09-08 12:56:33 --> Helper loaded: url_helper
INFO - 2016-09-08 12:56:33 --> Helper loaded: language_helper
INFO - 2016-09-08 12:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:56:33 --> Controller Class Initialized
INFO - 2016-09-08 12:56:33 --> Database Driver Class Initialized
INFO - 2016-09-08 12:56:33 --> Model Class Initialized
INFO - 2016-09-08 12:56:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:56:33 --> Helper loaded: form_helper
INFO - 2016-09-08 12:56:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:56:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 12:56:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:56:33 --> Final output sent to browser
DEBUG - 2016-09-08 12:56:33 --> Total execution time: 0.0660
INFO - 2016-09-08 12:56:41 --> Config Class Initialized
INFO - 2016-09-08 12:56:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:56:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:56:41 --> Utf8 Class Initialized
INFO - 2016-09-08 12:56:41 --> URI Class Initialized
INFO - 2016-09-08 12:56:41 --> Router Class Initialized
INFO - 2016-09-08 12:56:41 --> Output Class Initialized
INFO - 2016-09-08 12:56:41 --> Security Class Initialized
DEBUG - 2016-09-08 12:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:56:41 --> Input Class Initialized
INFO - 2016-09-08 12:56:41 --> Language Class Initialized
INFO - 2016-09-08 12:56:41 --> Loader Class Initialized
INFO - 2016-09-08 12:56:41 --> Helper loaded: url_helper
INFO - 2016-09-08 12:56:41 --> Helper loaded: language_helper
INFO - 2016-09-08 12:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:56:41 --> Controller Class Initialized
INFO - 2016-09-08 12:56:41 --> Database Driver Class Initialized
INFO - 2016-09-08 12:56:41 --> Model Class Initialized
INFO - 2016-09-08 12:56:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:56:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:56:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:56:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:56:41 --> Final output sent to browser
DEBUG - 2016-09-08 12:56:41 --> Total execution time: 0.0595
INFO - 2016-09-08 12:56:48 --> Config Class Initialized
INFO - 2016-09-08 12:56:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:56:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:56:48 --> Utf8 Class Initialized
INFO - 2016-09-08 12:56:48 --> URI Class Initialized
INFO - 2016-09-08 12:56:48 --> Router Class Initialized
INFO - 2016-09-08 12:56:48 --> Output Class Initialized
INFO - 2016-09-08 12:56:48 --> Security Class Initialized
DEBUG - 2016-09-08 12:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:56:48 --> Input Class Initialized
INFO - 2016-09-08 12:56:48 --> Language Class Initialized
INFO - 2016-09-08 12:56:48 --> Loader Class Initialized
INFO - 2016-09-08 12:56:48 --> Helper loaded: url_helper
INFO - 2016-09-08 12:56:48 --> Helper loaded: language_helper
INFO - 2016-09-08 12:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:56:48 --> Controller Class Initialized
INFO - 2016-09-08 12:56:48 --> Database Driver Class Initialized
INFO - 2016-09-08 12:56:48 --> Model Class Initialized
INFO - 2016-09-08 12:56:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:56:48 --> Config Class Initialized
INFO - 2016-09-08 12:56:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 12:56:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 12:56:48 --> Utf8 Class Initialized
INFO - 2016-09-08 12:56:48 --> URI Class Initialized
INFO - 2016-09-08 12:56:48 --> Router Class Initialized
INFO - 2016-09-08 12:56:48 --> Output Class Initialized
INFO - 2016-09-08 12:56:48 --> Security Class Initialized
DEBUG - 2016-09-08 12:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 12:56:48 --> Input Class Initialized
INFO - 2016-09-08 12:56:48 --> Language Class Initialized
INFO - 2016-09-08 12:56:48 --> Loader Class Initialized
INFO - 2016-09-08 12:56:48 --> Helper loaded: url_helper
INFO - 2016-09-08 12:56:48 --> Helper loaded: language_helper
INFO - 2016-09-08 12:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 12:56:48 --> Controller Class Initialized
INFO - 2016-09-08 12:56:48 --> Database Driver Class Initialized
INFO - 2016-09-08 12:56:48 --> Model Class Initialized
INFO - 2016-09-08 12:56:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 12:56:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 12:56:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2016-09-08 12:56:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 12:56:48 --> Final output sent to browser
DEBUG - 2016-09-08 12:56:48 --> Total execution time: 0.0622
INFO - 2016-09-08 13:00:01 --> Config Class Initialized
INFO - 2016-09-08 13:00:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:00:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:00:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:00:01 --> URI Class Initialized
INFO - 2016-09-08 13:00:01 --> Router Class Initialized
INFO - 2016-09-08 13:00:01 --> Output Class Initialized
INFO - 2016-09-08 13:00:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:00:01 --> Input Class Initialized
INFO - 2016-09-08 13:00:01 --> Language Class Initialized
INFO - 2016-09-08 13:00:01 --> Loader Class Initialized
INFO - 2016-09-08 13:00:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:00:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:00:01 --> Controller Class Initialized
INFO - 2016-09-08 13:00:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:00:01 --> Model Class Initialized
INFO - 2016-09-08 13:00:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:00:01 --> Helper loaded: form_helper
INFO - 2016-09-08 13:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:00:01 --> Final output sent to browser
DEBUG - 2016-09-08 13:00:01 --> Total execution time: 0.0750
INFO - 2016-09-08 13:00:05 --> Config Class Initialized
INFO - 2016-09-08 13:00:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:00:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:00:05 --> Utf8 Class Initialized
INFO - 2016-09-08 13:00:05 --> URI Class Initialized
INFO - 2016-09-08 13:00:05 --> Router Class Initialized
INFO - 2016-09-08 13:00:05 --> Output Class Initialized
INFO - 2016-09-08 13:00:05 --> Security Class Initialized
DEBUG - 2016-09-08 13:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:00:05 --> Input Class Initialized
INFO - 2016-09-08 13:00:05 --> Language Class Initialized
INFO - 2016-09-08 13:00:05 --> Loader Class Initialized
INFO - 2016-09-08 13:00:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:00:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:00:05 --> Controller Class Initialized
INFO - 2016-09-08 13:00:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:00:05 --> Model Class Initialized
INFO - 2016-09-08 13:00:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:00:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:00:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-08 13:00:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:00:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:00:05 --> Total execution time: 0.0608
INFO - 2016-09-08 13:01:27 --> Config Class Initialized
INFO - 2016-09-08 13:01:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:01:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:01:27 --> Utf8 Class Initialized
INFO - 2016-09-08 13:01:27 --> URI Class Initialized
INFO - 2016-09-08 13:01:27 --> Router Class Initialized
INFO - 2016-09-08 13:01:27 --> Output Class Initialized
INFO - 2016-09-08 13:01:27 --> Security Class Initialized
DEBUG - 2016-09-08 13:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:01:27 --> Input Class Initialized
INFO - 2016-09-08 13:01:27 --> Language Class Initialized
INFO - 2016-09-08 13:01:27 --> Loader Class Initialized
INFO - 2016-09-08 13:01:27 --> Helper loaded: url_helper
INFO - 2016-09-08 13:01:27 --> Helper loaded: language_helper
INFO - 2016-09-08 13:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:01:27 --> Controller Class Initialized
INFO - 2016-09-08 13:01:27 --> Database Driver Class Initialized
INFO - 2016-09-08 13:01:27 --> Model Class Initialized
INFO - 2016-09-08 13:01:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:01:27 --> Config Class Initialized
INFO - 2016-09-08 13:01:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:01:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:01:27 --> Utf8 Class Initialized
INFO - 2016-09-08 13:01:27 --> URI Class Initialized
INFO - 2016-09-08 13:01:27 --> Router Class Initialized
INFO - 2016-09-08 13:01:27 --> Output Class Initialized
INFO - 2016-09-08 13:01:27 --> Security Class Initialized
DEBUG - 2016-09-08 13:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:01:27 --> Input Class Initialized
INFO - 2016-09-08 13:01:27 --> Language Class Initialized
INFO - 2016-09-08 13:01:27 --> Loader Class Initialized
INFO - 2016-09-08 13:01:27 --> Helper loaded: url_helper
INFO - 2016-09-08 13:01:27 --> Helper loaded: language_helper
INFO - 2016-09-08 13:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:01:27 --> Controller Class Initialized
INFO - 2016-09-08 13:01:27 --> Database Driver Class Initialized
INFO - 2016-09-08 13:01:27 --> Model Class Initialized
INFO - 2016-09-08 13:01:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:01:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:01:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-08 13:01:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:01:27 --> Final output sent to browser
DEBUG - 2016-09-08 13:01:27 --> Total execution time: 0.0631
INFO - 2016-09-08 13:02:22 --> Config Class Initialized
INFO - 2016-09-08 13:02:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:02:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:02:22 --> Utf8 Class Initialized
INFO - 2016-09-08 13:02:22 --> URI Class Initialized
INFO - 2016-09-08 13:02:22 --> Router Class Initialized
INFO - 2016-09-08 13:02:22 --> Output Class Initialized
INFO - 2016-09-08 13:02:22 --> Security Class Initialized
DEBUG - 2016-09-08 13:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:02:22 --> Input Class Initialized
INFO - 2016-09-08 13:02:22 --> Language Class Initialized
INFO - 2016-09-08 13:02:22 --> Loader Class Initialized
INFO - 2016-09-08 13:02:22 --> Helper loaded: url_helper
INFO - 2016-09-08 13:02:22 --> Helper loaded: language_helper
INFO - 2016-09-08 13:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:02:22 --> Controller Class Initialized
INFO - 2016-09-08 13:02:22 --> Database Driver Class Initialized
INFO - 2016-09-08 13:02:22 --> Model Class Initialized
INFO - 2016-09-08 13:02:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:02:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:02:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:02:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:02:22 --> Final output sent to browser
DEBUG - 2016-09-08 13:02:22 --> Total execution time: 0.0601
INFO - 2016-09-08 13:02:51 --> Config Class Initialized
INFO - 2016-09-08 13:02:51 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:02:51 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:02:51 --> Utf8 Class Initialized
INFO - 2016-09-08 13:02:51 --> URI Class Initialized
INFO - 2016-09-08 13:02:51 --> Router Class Initialized
INFO - 2016-09-08 13:02:51 --> Output Class Initialized
INFO - 2016-09-08 13:02:51 --> Security Class Initialized
DEBUG - 2016-09-08 13:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:02:51 --> Input Class Initialized
INFO - 2016-09-08 13:02:51 --> Language Class Initialized
INFO - 2016-09-08 13:02:51 --> Loader Class Initialized
INFO - 2016-09-08 13:02:51 --> Helper loaded: url_helper
INFO - 2016-09-08 13:02:51 --> Helper loaded: language_helper
INFO - 2016-09-08 13:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:02:51 --> Controller Class Initialized
INFO - 2016-09-08 13:02:51 --> Database Driver Class Initialized
INFO - 2016-09-08 13:02:51 --> Model Class Initialized
INFO - 2016-09-08 13:02:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:02:51 --> Helper loaded: form_helper
INFO - 2016-09-08 13:02:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:02:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:02:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:02:51 --> Final output sent to browser
DEBUG - 2016-09-08 13:02:51 --> Total execution time: 0.0834
INFO - 2016-09-08 13:02:57 --> Config Class Initialized
INFO - 2016-09-08 13:02:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:02:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:02:57 --> Utf8 Class Initialized
INFO - 2016-09-08 13:02:57 --> URI Class Initialized
INFO - 2016-09-08 13:02:57 --> Router Class Initialized
INFO - 2016-09-08 13:02:57 --> Output Class Initialized
INFO - 2016-09-08 13:02:57 --> Security Class Initialized
DEBUG - 2016-09-08 13:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:02:57 --> Input Class Initialized
INFO - 2016-09-08 13:02:57 --> Language Class Initialized
INFO - 2016-09-08 13:02:57 --> Loader Class Initialized
INFO - 2016-09-08 13:02:57 --> Helper loaded: url_helper
INFO - 2016-09-08 13:02:57 --> Helper loaded: language_helper
INFO - 2016-09-08 13:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:02:57 --> Controller Class Initialized
INFO - 2016-09-08 13:02:57 --> Database Driver Class Initialized
INFO - 2016-09-08 13:02:57 --> Model Class Initialized
INFO - 2016-09-08 13:02:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:02:57 --> Config Class Initialized
INFO - 2016-09-08 13:02:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:02:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:02:57 --> Utf8 Class Initialized
INFO - 2016-09-08 13:02:57 --> URI Class Initialized
INFO - 2016-09-08 13:02:57 --> Router Class Initialized
INFO - 2016-09-08 13:02:57 --> Output Class Initialized
INFO - 2016-09-08 13:02:57 --> Security Class Initialized
DEBUG - 2016-09-08 13:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:02:57 --> Input Class Initialized
INFO - 2016-09-08 13:02:57 --> Language Class Initialized
INFO - 2016-09-08 13:02:57 --> Loader Class Initialized
INFO - 2016-09-08 13:02:57 --> Helper loaded: url_helper
INFO - 2016-09-08 13:02:57 --> Helper loaded: language_helper
INFO - 2016-09-08 13:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:02:57 --> Controller Class Initialized
INFO - 2016-09-08 13:02:57 --> Database Driver Class Initialized
INFO - 2016-09-08 13:02:57 --> Model Class Initialized
INFO - 2016-09-08 13:02:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:02:57 --> Helper loaded: form_helper
INFO - 2016-09-08 13:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:02:57 --> Final output sent to browser
DEBUG - 2016-09-08 13:02:57 --> Total execution time: 0.0838
INFO - 2016-09-08 13:02:59 --> Config Class Initialized
INFO - 2016-09-08 13:02:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:02:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:02:59 --> Utf8 Class Initialized
INFO - 2016-09-08 13:02:59 --> URI Class Initialized
INFO - 2016-09-08 13:02:59 --> Router Class Initialized
INFO - 2016-09-08 13:02:59 --> Output Class Initialized
INFO - 2016-09-08 13:02:59 --> Security Class Initialized
DEBUG - 2016-09-08 13:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:02:59 --> Input Class Initialized
INFO - 2016-09-08 13:02:59 --> Language Class Initialized
INFO - 2016-09-08 13:02:59 --> Loader Class Initialized
INFO - 2016-09-08 13:02:59 --> Helper loaded: url_helper
INFO - 2016-09-08 13:02:59 --> Helper loaded: language_helper
INFO - 2016-09-08 13:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:02:59 --> Controller Class Initialized
INFO - 2016-09-08 13:02:59 --> Database Driver Class Initialized
INFO - 2016-09-08 13:02:59 --> Model Class Initialized
INFO - 2016-09-08 13:02:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:02:59 --> Config Class Initialized
INFO - 2016-09-08 13:02:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:02:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:02:59 --> Utf8 Class Initialized
INFO - 2016-09-08 13:02:59 --> URI Class Initialized
INFO - 2016-09-08 13:02:59 --> Router Class Initialized
INFO - 2016-09-08 13:02:59 --> Output Class Initialized
INFO - 2016-09-08 13:02:59 --> Security Class Initialized
DEBUG - 2016-09-08 13:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:02:59 --> Input Class Initialized
INFO - 2016-09-08 13:02:59 --> Language Class Initialized
INFO - 2016-09-08 13:02:59 --> Loader Class Initialized
INFO - 2016-09-08 13:02:59 --> Helper loaded: url_helper
INFO - 2016-09-08 13:02:59 --> Helper loaded: language_helper
INFO - 2016-09-08 13:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:02:59 --> Controller Class Initialized
INFO - 2016-09-08 13:02:59 --> Database Driver Class Initialized
INFO - 2016-09-08 13:02:59 --> Model Class Initialized
INFO - 2016-09-08 13:02:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:02:59 --> Helper loaded: form_helper
INFO - 2016-09-08 13:02:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:02:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:02:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:02:59 --> Final output sent to browser
DEBUG - 2016-09-08 13:02:59 --> Total execution time: 0.0634
INFO - 2016-09-08 13:03:01 --> Config Class Initialized
INFO - 2016-09-08 13:03:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:01 --> URI Class Initialized
INFO - 2016-09-08 13:03:01 --> Router Class Initialized
INFO - 2016-09-08 13:03:01 --> Output Class Initialized
INFO - 2016-09-08 13:03:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:01 --> Input Class Initialized
INFO - 2016-09-08 13:03:01 --> Language Class Initialized
INFO - 2016-09-08 13:03:01 --> Loader Class Initialized
INFO - 2016-09-08 13:03:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:01 --> Controller Class Initialized
INFO - 2016-09-08 13:03:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:01 --> Model Class Initialized
INFO - 2016-09-08 13:03:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:01 --> Config Class Initialized
INFO - 2016-09-08 13:03:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:01 --> URI Class Initialized
INFO - 2016-09-08 13:03:01 --> Router Class Initialized
INFO - 2016-09-08 13:03:01 --> Output Class Initialized
INFO - 2016-09-08 13:03:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:01 --> Input Class Initialized
INFO - 2016-09-08 13:03:01 --> Language Class Initialized
INFO - 2016-09-08 13:03:01 --> Loader Class Initialized
INFO - 2016-09-08 13:03:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:01 --> Controller Class Initialized
INFO - 2016-09-08 13:03:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:01 --> Model Class Initialized
INFO - 2016-09-08 13:03:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:01 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:01 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:01 --> Total execution time: 0.0725
INFO - 2016-09-08 13:03:03 --> Config Class Initialized
INFO - 2016-09-08 13:03:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:03 --> URI Class Initialized
INFO - 2016-09-08 13:03:03 --> Router Class Initialized
INFO - 2016-09-08 13:03:03 --> Output Class Initialized
INFO - 2016-09-08 13:03:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:03 --> Input Class Initialized
INFO - 2016-09-08 13:03:03 --> Language Class Initialized
INFO - 2016-09-08 13:03:03 --> Loader Class Initialized
INFO - 2016-09-08 13:03:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:03 --> Controller Class Initialized
INFO - 2016-09-08 13:03:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:03 --> Model Class Initialized
INFO - 2016-09-08 13:03:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:03 --> Config Class Initialized
INFO - 2016-09-08 13:03:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:03 --> URI Class Initialized
INFO - 2016-09-08 13:03:03 --> Router Class Initialized
INFO - 2016-09-08 13:03:03 --> Output Class Initialized
INFO - 2016-09-08 13:03:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:03 --> Input Class Initialized
INFO - 2016-09-08 13:03:03 --> Language Class Initialized
INFO - 2016-09-08 13:03:03 --> Loader Class Initialized
INFO - 2016-09-08 13:03:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:03 --> Controller Class Initialized
INFO - 2016-09-08 13:03:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:03 --> Model Class Initialized
INFO - 2016-09-08 13:03:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:03 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:03 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:03 --> Total execution time: 0.0649
INFO - 2016-09-08 13:03:05 --> Config Class Initialized
INFO - 2016-09-08 13:03:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:05 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:05 --> URI Class Initialized
INFO - 2016-09-08 13:03:05 --> Router Class Initialized
INFO - 2016-09-08 13:03:05 --> Output Class Initialized
INFO - 2016-09-08 13:03:05 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:05 --> Input Class Initialized
INFO - 2016-09-08 13:03:05 --> Language Class Initialized
INFO - 2016-09-08 13:03:05 --> Loader Class Initialized
INFO - 2016-09-08 13:03:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:05 --> Controller Class Initialized
INFO - 2016-09-08 13:03:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:05 --> Model Class Initialized
INFO - 2016-09-08 13:03:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:05 --> Config Class Initialized
INFO - 2016-09-08 13:03:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:05 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:05 --> URI Class Initialized
INFO - 2016-09-08 13:03:05 --> Router Class Initialized
INFO - 2016-09-08 13:03:05 --> Output Class Initialized
INFO - 2016-09-08 13:03:05 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:05 --> Input Class Initialized
INFO - 2016-09-08 13:03:05 --> Language Class Initialized
INFO - 2016-09-08 13:03:05 --> Loader Class Initialized
INFO - 2016-09-08 13:03:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:05 --> Controller Class Initialized
INFO - 2016-09-08 13:03:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:05 --> Model Class Initialized
INFO - 2016-09-08 13:03:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:05 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:05 --> Total execution time: 0.0742
INFO - 2016-09-08 13:03:07 --> Config Class Initialized
INFO - 2016-09-08 13:03:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:07 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:07 --> URI Class Initialized
INFO - 2016-09-08 13:03:07 --> Router Class Initialized
INFO - 2016-09-08 13:03:07 --> Output Class Initialized
INFO - 2016-09-08 13:03:07 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:07 --> Input Class Initialized
INFO - 2016-09-08 13:03:07 --> Language Class Initialized
INFO - 2016-09-08 13:03:07 --> Loader Class Initialized
INFO - 2016-09-08 13:03:07 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:07 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:07 --> Controller Class Initialized
INFO - 2016-09-08 13:03:07 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:07 --> Model Class Initialized
INFO - 2016-09-08 13:03:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:07 --> Config Class Initialized
INFO - 2016-09-08 13:03:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:07 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:07 --> URI Class Initialized
INFO - 2016-09-08 13:03:07 --> Router Class Initialized
INFO - 2016-09-08 13:03:07 --> Output Class Initialized
INFO - 2016-09-08 13:03:07 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:07 --> Input Class Initialized
INFO - 2016-09-08 13:03:07 --> Language Class Initialized
INFO - 2016-09-08 13:03:07 --> Loader Class Initialized
INFO - 2016-09-08 13:03:07 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:07 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:07 --> Controller Class Initialized
INFO - 2016-09-08 13:03:07 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:07 --> Model Class Initialized
INFO - 2016-09-08 13:03:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:07 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:07 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:07 --> Total execution time: 0.0652
INFO - 2016-09-08 13:03:09 --> Config Class Initialized
INFO - 2016-09-08 13:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:09 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:09 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:09 --> URI Class Initialized
INFO - 2016-09-08 13:03:09 --> Router Class Initialized
INFO - 2016-09-08 13:03:09 --> Output Class Initialized
INFO - 2016-09-08 13:03:09 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:09 --> Input Class Initialized
INFO - 2016-09-08 13:03:09 --> Language Class Initialized
INFO - 2016-09-08 13:03:09 --> Loader Class Initialized
INFO - 2016-09-08 13:03:09 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:09 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:09 --> Controller Class Initialized
INFO - 2016-09-08 13:03:09 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:09 --> Model Class Initialized
INFO - 2016-09-08 13:03:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:09 --> Config Class Initialized
INFO - 2016-09-08 13:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:09 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:09 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:09 --> URI Class Initialized
INFO - 2016-09-08 13:03:09 --> Router Class Initialized
INFO - 2016-09-08 13:03:09 --> Output Class Initialized
INFO - 2016-09-08 13:03:09 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:09 --> Input Class Initialized
INFO - 2016-09-08 13:03:09 --> Language Class Initialized
INFO - 2016-09-08 13:03:09 --> Loader Class Initialized
INFO - 2016-09-08 13:03:09 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:09 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:09 --> Controller Class Initialized
INFO - 2016-09-08 13:03:09 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:09 --> Model Class Initialized
INFO - 2016-09-08 13:03:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:09 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:09 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:09 --> Total execution time: 0.0636
INFO - 2016-09-08 13:03:11 --> Config Class Initialized
INFO - 2016-09-08 13:03:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:11 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:11 --> URI Class Initialized
INFO - 2016-09-08 13:03:11 --> Router Class Initialized
INFO - 2016-09-08 13:03:11 --> Output Class Initialized
INFO - 2016-09-08 13:03:11 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:11 --> Input Class Initialized
INFO - 2016-09-08 13:03:11 --> Language Class Initialized
INFO - 2016-09-08 13:03:11 --> Loader Class Initialized
INFO - 2016-09-08 13:03:11 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:11 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:11 --> Controller Class Initialized
INFO - 2016-09-08 13:03:11 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:11 --> Model Class Initialized
INFO - 2016-09-08 13:03:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:11 --> Config Class Initialized
INFO - 2016-09-08 13:03:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:11 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:11 --> URI Class Initialized
INFO - 2016-09-08 13:03:11 --> Router Class Initialized
INFO - 2016-09-08 13:03:11 --> Output Class Initialized
INFO - 2016-09-08 13:03:11 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:11 --> Input Class Initialized
INFO - 2016-09-08 13:03:11 --> Language Class Initialized
INFO - 2016-09-08 13:03:11 --> Loader Class Initialized
INFO - 2016-09-08 13:03:11 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:11 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:11 --> Controller Class Initialized
INFO - 2016-09-08 13:03:11 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:11 --> Model Class Initialized
INFO - 2016-09-08 13:03:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:11 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:11 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:11 --> Total execution time: 0.0805
INFO - 2016-09-08 13:03:13 --> Config Class Initialized
INFO - 2016-09-08 13:03:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:13 --> URI Class Initialized
INFO - 2016-09-08 13:03:13 --> Router Class Initialized
INFO - 2016-09-08 13:03:13 --> Output Class Initialized
INFO - 2016-09-08 13:03:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:13 --> Input Class Initialized
INFO - 2016-09-08 13:03:13 --> Language Class Initialized
INFO - 2016-09-08 13:03:13 --> Loader Class Initialized
INFO - 2016-09-08 13:03:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:13 --> Controller Class Initialized
INFO - 2016-09-08 13:03:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:13 --> Model Class Initialized
INFO - 2016-09-08 13:03:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:13 --> Config Class Initialized
INFO - 2016-09-08 13:03:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:13 --> URI Class Initialized
INFO - 2016-09-08 13:03:13 --> Router Class Initialized
INFO - 2016-09-08 13:03:13 --> Output Class Initialized
INFO - 2016-09-08 13:03:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:13 --> Input Class Initialized
INFO - 2016-09-08 13:03:13 --> Language Class Initialized
INFO - 2016-09-08 13:03:13 --> Loader Class Initialized
INFO - 2016-09-08 13:03:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:13 --> Controller Class Initialized
INFO - 2016-09-08 13:03:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:13 --> Model Class Initialized
INFO - 2016-09-08 13:03:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:13 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:13 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:13 --> Total execution time: 0.0628
INFO - 2016-09-08 13:03:15 --> Config Class Initialized
INFO - 2016-09-08 13:03:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:15 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:15 --> URI Class Initialized
INFO - 2016-09-08 13:03:15 --> Router Class Initialized
INFO - 2016-09-08 13:03:15 --> Output Class Initialized
INFO - 2016-09-08 13:03:15 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:15 --> Input Class Initialized
INFO - 2016-09-08 13:03:15 --> Language Class Initialized
INFO - 2016-09-08 13:03:15 --> Loader Class Initialized
INFO - 2016-09-08 13:03:15 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:15 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:15 --> Controller Class Initialized
INFO - 2016-09-08 13:03:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:15 --> Model Class Initialized
INFO - 2016-09-08 13:03:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:15 --> Config Class Initialized
INFO - 2016-09-08 13:03:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:15 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:15 --> URI Class Initialized
INFO - 2016-09-08 13:03:15 --> Router Class Initialized
INFO - 2016-09-08 13:03:15 --> Output Class Initialized
INFO - 2016-09-08 13:03:15 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:15 --> Input Class Initialized
INFO - 2016-09-08 13:03:15 --> Language Class Initialized
INFO - 2016-09-08 13:03:15 --> Loader Class Initialized
INFO - 2016-09-08 13:03:15 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:15 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:15 --> Controller Class Initialized
INFO - 2016-09-08 13:03:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:15 --> Model Class Initialized
INFO - 2016-09-08 13:03:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:15 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:15 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:15 --> Total execution time: 0.0744
INFO - 2016-09-08 13:03:17 --> Config Class Initialized
INFO - 2016-09-08 13:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:17 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:17 --> URI Class Initialized
INFO - 2016-09-08 13:03:17 --> Router Class Initialized
INFO - 2016-09-08 13:03:17 --> Output Class Initialized
INFO - 2016-09-08 13:03:17 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:17 --> Input Class Initialized
INFO - 2016-09-08 13:03:17 --> Language Class Initialized
INFO - 2016-09-08 13:03:17 --> Loader Class Initialized
INFO - 2016-09-08 13:03:17 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:17 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:17 --> Controller Class Initialized
INFO - 2016-09-08 13:03:17 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:17 --> Model Class Initialized
INFO - 2016-09-08 13:03:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:17 --> Config Class Initialized
INFO - 2016-09-08 13:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:17 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:17 --> URI Class Initialized
INFO - 2016-09-08 13:03:17 --> Router Class Initialized
INFO - 2016-09-08 13:03:17 --> Output Class Initialized
INFO - 2016-09-08 13:03:17 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:17 --> Input Class Initialized
INFO - 2016-09-08 13:03:17 --> Language Class Initialized
INFO - 2016-09-08 13:03:17 --> Loader Class Initialized
INFO - 2016-09-08 13:03:17 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:17 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:17 --> Controller Class Initialized
INFO - 2016-09-08 13:03:17 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:17 --> Model Class Initialized
INFO - 2016-09-08 13:03:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:17 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:17 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:17 --> Total execution time: 0.0797
INFO - 2016-09-08 13:03:20 --> Config Class Initialized
INFO - 2016-09-08 13:03:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:20 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:20 --> URI Class Initialized
INFO - 2016-09-08 13:03:20 --> Router Class Initialized
INFO - 2016-09-08 13:03:20 --> Output Class Initialized
INFO - 2016-09-08 13:03:20 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:20 --> Input Class Initialized
INFO - 2016-09-08 13:03:20 --> Language Class Initialized
INFO - 2016-09-08 13:03:20 --> Loader Class Initialized
INFO - 2016-09-08 13:03:20 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:20 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:20 --> Controller Class Initialized
INFO - 2016-09-08 13:03:20 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:20 --> Model Class Initialized
INFO - 2016-09-08 13:03:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:20 --> Config Class Initialized
INFO - 2016-09-08 13:03:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:03:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:03:20 --> Utf8 Class Initialized
INFO - 2016-09-08 13:03:20 --> URI Class Initialized
INFO - 2016-09-08 13:03:20 --> Router Class Initialized
INFO - 2016-09-08 13:03:20 --> Output Class Initialized
INFO - 2016-09-08 13:03:20 --> Security Class Initialized
DEBUG - 2016-09-08 13:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:03:20 --> Input Class Initialized
INFO - 2016-09-08 13:03:20 --> Language Class Initialized
INFO - 2016-09-08 13:03:20 --> Loader Class Initialized
INFO - 2016-09-08 13:03:20 --> Helper loaded: url_helper
INFO - 2016-09-08 13:03:20 --> Helper loaded: language_helper
INFO - 2016-09-08 13:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:03:20 --> Controller Class Initialized
INFO - 2016-09-08 13:03:20 --> Database Driver Class Initialized
INFO - 2016-09-08 13:03:20 --> Model Class Initialized
INFO - 2016-09-08 13:03:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:03:20 --> Helper loaded: form_helper
INFO - 2016-09-08 13:03:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:03:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:03:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:03:20 --> Final output sent to browser
DEBUG - 2016-09-08 13:03:20 --> Total execution time: 0.0636
INFO - 2016-09-08 13:04:55 --> Config Class Initialized
INFO - 2016-09-08 13:04:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:04:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:04:55 --> Utf8 Class Initialized
INFO - 2016-09-08 13:04:55 --> URI Class Initialized
INFO - 2016-09-08 13:04:55 --> Router Class Initialized
INFO - 2016-09-08 13:04:55 --> Output Class Initialized
INFO - 2016-09-08 13:04:55 --> Security Class Initialized
DEBUG - 2016-09-08 13:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:04:55 --> Input Class Initialized
INFO - 2016-09-08 13:04:55 --> Language Class Initialized
INFO - 2016-09-08 13:04:55 --> Loader Class Initialized
INFO - 2016-09-08 13:04:55 --> Helper loaded: url_helper
INFO - 2016-09-08 13:04:55 --> Helper loaded: language_helper
INFO - 2016-09-08 13:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:04:55 --> Controller Class Initialized
INFO - 2016-09-08 13:04:55 --> Database Driver Class Initialized
INFO - 2016-09-08 13:04:55 --> Model Class Initialized
INFO - 2016-09-08 13:04:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:04:55 --> Final output sent to browser
DEBUG - 2016-09-08 13:04:55 --> Total execution time: 0.0623
INFO - 2016-09-08 13:05:24 --> Config Class Initialized
INFO - 2016-09-08 13:05:24 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:05:24 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:05:24 --> Utf8 Class Initialized
INFO - 2016-09-08 13:05:24 --> URI Class Initialized
INFO - 2016-09-08 13:05:24 --> Router Class Initialized
INFO - 2016-09-08 13:05:24 --> Output Class Initialized
INFO - 2016-09-08 13:05:24 --> Security Class Initialized
DEBUG - 2016-09-08 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:05:24 --> Input Class Initialized
INFO - 2016-09-08 13:05:24 --> Language Class Initialized
INFO - 2016-09-08 13:05:24 --> Loader Class Initialized
INFO - 2016-09-08 13:05:24 --> Helper loaded: url_helper
INFO - 2016-09-08 13:05:24 --> Helper loaded: language_helper
INFO - 2016-09-08 13:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:05:24 --> Controller Class Initialized
INFO - 2016-09-08 13:05:24 --> Database Driver Class Initialized
INFO - 2016-09-08 13:05:24 --> Model Class Initialized
INFO - 2016-09-08 13:05:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:05:24 --> Final output sent to browser
DEBUG - 2016-09-08 13:05:24 --> Total execution time: 0.0677
INFO - 2016-09-08 13:05:47 --> Config Class Initialized
INFO - 2016-09-08 13:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:05:47 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:05:47 --> Utf8 Class Initialized
INFO - 2016-09-08 13:05:47 --> URI Class Initialized
INFO - 2016-09-08 13:05:47 --> Router Class Initialized
INFO - 2016-09-08 13:05:47 --> Output Class Initialized
INFO - 2016-09-08 13:05:47 --> Security Class Initialized
DEBUG - 2016-09-08 13:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:05:47 --> Input Class Initialized
INFO - 2016-09-08 13:05:47 --> Language Class Initialized
INFO - 2016-09-08 13:05:47 --> Loader Class Initialized
INFO - 2016-09-08 13:05:47 --> Helper loaded: url_helper
INFO - 2016-09-08 13:05:47 --> Helper loaded: language_helper
INFO - 2016-09-08 13:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:05:47 --> Controller Class Initialized
INFO - 2016-09-08 13:05:47 --> Database Driver Class Initialized
INFO - 2016-09-08 13:05:47 --> Model Class Initialized
INFO - 2016-09-08 13:05:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:05:47 --> Final output sent to browser
DEBUG - 2016-09-08 13:05:47 --> Total execution time: 0.0626
INFO - 2016-09-08 13:06:09 --> Config Class Initialized
INFO - 2016-09-08 13:06:09 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:06:09 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:06:09 --> Utf8 Class Initialized
INFO - 2016-09-08 13:06:09 --> URI Class Initialized
INFO - 2016-09-08 13:06:09 --> Router Class Initialized
INFO - 2016-09-08 13:06:09 --> Output Class Initialized
INFO - 2016-09-08 13:06:09 --> Security Class Initialized
DEBUG - 2016-09-08 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:06:09 --> Input Class Initialized
INFO - 2016-09-08 13:06:09 --> Language Class Initialized
INFO - 2016-09-08 13:06:09 --> Loader Class Initialized
INFO - 2016-09-08 13:06:09 --> Helper loaded: url_helper
INFO - 2016-09-08 13:06:09 --> Helper loaded: language_helper
INFO - 2016-09-08 13:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:06:09 --> Controller Class Initialized
INFO - 2016-09-08 13:06:09 --> Database Driver Class Initialized
INFO - 2016-09-08 13:06:09 --> Model Class Initialized
INFO - 2016-09-08 13:06:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:06:09 --> Final output sent to browser
DEBUG - 2016-09-08 13:06:09 --> Total execution time: 0.0605
INFO - 2016-09-08 13:06:28 --> Config Class Initialized
INFO - 2016-09-08 13:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:06:28 --> Utf8 Class Initialized
INFO - 2016-09-08 13:06:28 --> URI Class Initialized
INFO - 2016-09-08 13:06:28 --> Router Class Initialized
INFO - 2016-09-08 13:06:28 --> Output Class Initialized
INFO - 2016-09-08 13:06:28 --> Security Class Initialized
DEBUG - 2016-09-08 13:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:06:28 --> Input Class Initialized
INFO - 2016-09-08 13:06:28 --> Language Class Initialized
INFO - 2016-09-08 13:06:28 --> Loader Class Initialized
INFO - 2016-09-08 13:06:28 --> Helper loaded: url_helper
INFO - 2016-09-08 13:06:28 --> Helper loaded: language_helper
INFO - 2016-09-08 13:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:06:28 --> Controller Class Initialized
INFO - 2016-09-08 13:06:28 --> Database Driver Class Initialized
INFO - 2016-09-08 13:06:28 --> Model Class Initialized
INFO - 2016-09-08 13:06:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:06:28 --> Config Class Initialized
INFO - 2016-09-08 13:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:06:28 --> Utf8 Class Initialized
INFO - 2016-09-08 13:06:28 --> URI Class Initialized
INFO - 2016-09-08 13:06:28 --> Router Class Initialized
INFO - 2016-09-08 13:06:28 --> Output Class Initialized
INFO - 2016-09-08 13:06:28 --> Security Class Initialized
DEBUG - 2016-09-08 13:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:06:28 --> Input Class Initialized
INFO - 2016-09-08 13:06:28 --> Language Class Initialized
INFO - 2016-09-08 13:06:28 --> Loader Class Initialized
INFO - 2016-09-08 13:06:28 --> Helper loaded: url_helper
INFO - 2016-09-08 13:06:28 --> Helper loaded: language_helper
INFO - 2016-09-08 13:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:06:28 --> Controller Class Initialized
INFO - 2016-09-08 13:06:28 --> Database Driver Class Initialized
INFO - 2016-09-08 13:06:28 --> Model Class Initialized
INFO - 2016-09-08 13:06:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:06:28 --> Final output sent to browser
DEBUG - 2016-09-08 13:06:28 --> Total execution time: 0.0605
INFO - 2016-09-08 13:06:52 --> Config Class Initialized
INFO - 2016-09-08 13:06:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:06:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:06:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:06:52 --> URI Class Initialized
INFO - 2016-09-08 13:06:52 --> Router Class Initialized
INFO - 2016-09-08 13:06:52 --> Output Class Initialized
INFO - 2016-09-08 13:06:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:06:52 --> Input Class Initialized
INFO - 2016-09-08 13:06:52 --> Language Class Initialized
INFO - 2016-09-08 13:06:52 --> Loader Class Initialized
INFO - 2016-09-08 13:06:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:06:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:06:52 --> Controller Class Initialized
INFO - 2016-09-08 13:06:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:06:52 --> Model Class Initialized
INFO - 2016-09-08 13:06:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:06:52 --> Config Class Initialized
INFO - 2016-09-08 13:06:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:06:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:06:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:06:52 --> URI Class Initialized
INFO - 2016-09-08 13:06:52 --> Router Class Initialized
INFO - 2016-09-08 13:06:52 --> Output Class Initialized
INFO - 2016-09-08 13:06:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:06:52 --> Input Class Initialized
INFO - 2016-09-08 13:06:52 --> Language Class Initialized
INFO - 2016-09-08 13:06:52 --> Loader Class Initialized
INFO - 2016-09-08 13:06:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:06:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:06:52 --> Controller Class Initialized
INFO - 2016-09-08 13:06:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:06:52 --> Model Class Initialized
INFO - 2016-09-08 13:06:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:06:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:06:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:06:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:06:52 --> Final output sent to browser
DEBUG - 2016-09-08 13:06:52 --> Total execution time: 0.0737
INFO - 2016-09-08 13:07:14 --> Config Class Initialized
INFO - 2016-09-08 13:07:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:07:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:07:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:07:14 --> URI Class Initialized
INFO - 2016-09-08 13:07:14 --> Router Class Initialized
INFO - 2016-09-08 13:07:14 --> Output Class Initialized
INFO - 2016-09-08 13:07:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:07:14 --> Input Class Initialized
INFO - 2016-09-08 13:07:14 --> Language Class Initialized
INFO - 2016-09-08 13:07:14 --> Loader Class Initialized
INFO - 2016-09-08 13:07:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:07:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:07:14 --> Controller Class Initialized
INFO - 2016-09-08 13:07:14 --> Database Driver Class Initialized
INFO - 2016-09-08 13:07:14 --> Model Class Initialized
INFO - 2016-09-08 13:07:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:07:14 --> Config Class Initialized
INFO - 2016-09-08 13:07:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:07:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:07:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:07:14 --> URI Class Initialized
INFO - 2016-09-08 13:07:14 --> Router Class Initialized
INFO - 2016-09-08 13:07:14 --> Output Class Initialized
INFO - 2016-09-08 13:07:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:07:14 --> Input Class Initialized
INFO - 2016-09-08 13:07:14 --> Language Class Initialized
INFO - 2016-09-08 13:07:14 --> Loader Class Initialized
INFO - 2016-09-08 13:07:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:07:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:07:15 --> Controller Class Initialized
INFO - 2016-09-08 13:07:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:07:15 --> Model Class Initialized
INFO - 2016-09-08 13:07:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:07:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:07:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:07:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:07:15 --> Final output sent to browser
DEBUG - 2016-09-08 13:07:15 --> Total execution time: 0.0766
INFO - 2016-09-08 13:07:41 --> Config Class Initialized
INFO - 2016-09-08 13:07:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:07:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:07:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:07:41 --> URI Class Initialized
INFO - 2016-09-08 13:07:41 --> Router Class Initialized
INFO - 2016-09-08 13:07:41 --> Output Class Initialized
INFO - 2016-09-08 13:07:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:07:41 --> Input Class Initialized
INFO - 2016-09-08 13:07:41 --> Language Class Initialized
INFO - 2016-09-08 13:07:41 --> Loader Class Initialized
INFO - 2016-09-08 13:07:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:07:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:07:41 --> Controller Class Initialized
INFO - 2016-09-08 13:07:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:07:41 --> Model Class Initialized
INFO - 2016-09-08 13:07:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:07:41 --> Config Class Initialized
INFO - 2016-09-08 13:07:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:07:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:07:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:07:41 --> URI Class Initialized
INFO - 2016-09-08 13:07:41 --> Router Class Initialized
INFO - 2016-09-08 13:07:41 --> Output Class Initialized
INFO - 2016-09-08 13:07:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:07:41 --> Input Class Initialized
INFO - 2016-09-08 13:07:41 --> Language Class Initialized
INFO - 2016-09-08 13:07:41 --> Loader Class Initialized
INFO - 2016-09-08 13:07:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:07:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:07:41 --> Controller Class Initialized
INFO - 2016-09-08 13:07:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:07:41 --> Model Class Initialized
INFO - 2016-09-08 13:07:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:07:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:07:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:07:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:07:41 --> Final output sent to browser
DEBUG - 2016-09-08 13:07:41 --> Total execution time: 0.0575
INFO - 2016-09-08 13:08:04 --> Config Class Initialized
INFO - 2016-09-08 13:08:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:08:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:08:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:08:04 --> URI Class Initialized
INFO - 2016-09-08 13:08:04 --> Router Class Initialized
INFO - 2016-09-08 13:08:04 --> Output Class Initialized
INFO - 2016-09-08 13:08:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:08:04 --> Input Class Initialized
INFO - 2016-09-08 13:08:04 --> Language Class Initialized
INFO - 2016-09-08 13:08:04 --> Loader Class Initialized
INFO - 2016-09-08 13:08:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:08:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:08:04 --> Controller Class Initialized
INFO - 2016-09-08 13:08:04 --> Database Driver Class Initialized
INFO - 2016-09-08 13:08:04 --> Model Class Initialized
INFO - 2016-09-08 13:08:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:08:04 --> Config Class Initialized
INFO - 2016-09-08 13:08:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:08:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:08:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:08:04 --> URI Class Initialized
INFO - 2016-09-08 13:08:04 --> Router Class Initialized
INFO - 2016-09-08 13:08:04 --> Output Class Initialized
INFO - 2016-09-08 13:08:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:08:04 --> Input Class Initialized
INFO - 2016-09-08 13:08:04 --> Language Class Initialized
INFO - 2016-09-08 13:08:04 --> Loader Class Initialized
INFO - 2016-09-08 13:08:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:08:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:08:04 --> Controller Class Initialized
INFO - 2016-09-08 13:08:04 --> Database Driver Class Initialized
INFO - 2016-09-08 13:08:04 --> Model Class Initialized
INFO - 2016-09-08 13:08:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:08:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:08:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:08:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:08:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:08:05 --> Total execution time: 0.0594
INFO - 2016-09-08 13:08:35 --> Config Class Initialized
INFO - 2016-09-08 13:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:08:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:08:35 --> Utf8 Class Initialized
INFO - 2016-09-08 13:08:35 --> URI Class Initialized
INFO - 2016-09-08 13:08:35 --> Router Class Initialized
INFO - 2016-09-08 13:08:35 --> Output Class Initialized
INFO - 2016-09-08 13:08:35 --> Security Class Initialized
DEBUG - 2016-09-08 13:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:08:35 --> Input Class Initialized
INFO - 2016-09-08 13:08:35 --> Language Class Initialized
INFO - 2016-09-08 13:08:35 --> Loader Class Initialized
INFO - 2016-09-08 13:08:35 --> Helper loaded: url_helper
INFO - 2016-09-08 13:08:35 --> Helper loaded: language_helper
INFO - 2016-09-08 13:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:08:35 --> Controller Class Initialized
INFO - 2016-09-08 13:08:35 --> Database Driver Class Initialized
INFO - 2016-09-08 13:08:35 --> Model Class Initialized
INFO - 2016-09-08 13:08:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:08:35 --> Config Class Initialized
INFO - 2016-09-08 13:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:08:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:08:35 --> Utf8 Class Initialized
INFO - 2016-09-08 13:08:35 --> URI Class Initialized
INFO - 2016-09-08 13:08:35 --> Router Class Initialized
INFO - 2016-09-08 13:08:35 --> Output Class Initialized
INFO - 2016-09-08 13:08:35 --> Security Class Initialized
DEBUG - 2016-09-08 13:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:08:35 --> Input Class Initialized
INFO - 2016-09-08 13:08:35 --> Language Class Initialized
INFO - 2016-09-08 13:08:35 --> Loader Class Initialized
INFO - 2016-09-08 13:08:35 --> Helper loaded: url_helper
INFO - 2016-09-08 13:08:35 --> Helper loaded: language_helper
INFO - 2016-09-08 13:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:08:35 --> Controller Class Initialized
INFO - 2016-09-08 13:08:35 --> Database Driver Class Initialized
INFO - 2016-09-08 13:08:35 --> Model Class Initialized
INFO - 2016-09-08 13:08:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:08:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:08:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:08:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:08:35 --> Final output sent to browser
DEBUG - 2016-09-08 13:08:35 --> Total execution time: 0.0777
INFO - 2016-09-08 13:09:15 --> Config Class Initialized
INFO - 2016-09-08 13:09:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:15 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:15 --> URI Class Initialized
INFO - 2016-09-08 13:09:15 --> Router Class Initialized
INFO - 2016-09-08 13:09:15 --> Output Class Initialized
INFO - 2016-09-08 13:09:15 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:15 --> Input Class Initialized
INFO - 2016-09-08 13:09:15 --> Language Class Initialized
INFO - 2016-09-08 13:09:15 --> Loader Class Initialized
INFO - 2016-09-08 13:09:15 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:15 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:15 --> Controller Class Initialized
INFO - 2016-09-08 13:09:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:15 --> Model Class Initialized
INFO - 2016-09-08 13:09:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:15 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:15 --> Total execution time: 0.0891
INFO - 2016-09-08 13:09:19 --> Config Class Initialized
INFO - 2016-09-08 13:09:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:19 --> URI Class Initialized
INFO - 2016-09-08 13:09:19 --> Router Class Initialized
INFO - 2016-09-08 13:09:19 --> Output Class Initialized
INFO - 2016-09-08 13:09:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:19 --> Input Class Initialized
INFO - 2016-09-08 13:09:19 --> Language Class Initialized
INFO - 2016-09-08 13:09:19 --> Loader Class Initialized
INFO - 2016-09-08 13:09:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:19 --> Controller Class Initialized
INFO - 2016-09-08 13:09:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:19 --> Model Class Initialized
INFO - 2016-09-08 13:09:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:19 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:19 --> Total execution time: 0.0705
INFO - 2016-09-08 13:09:20 --> Config Class Initialized
INFO - 2016-09-08 13:09:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:21 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:21 --> URI Class Initialized
INFO - 2016-09-08 13:09:21 --> Router Class Initialized
INFO - 2016-09-08 13:09:21 --> Output Class Initialized
INFO - 2016-09-08 13:09:21 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:21 --> Input Class Initialized
INFO - 2016-09-08 13:09:21 --> Language Class Initialized
INFO - 2016-09-08 13:09:21 --> Loader Class Initialized
INFO - 2016-09-08 13:09:21 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:21 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:21 --> Controller Class Initialized
INFO - 2016-09-08 13:09:21 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:21 --> Model Class Initialized
INFO - 2016-09-08 13:09:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:21 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:21 --> Total execution time: 0.0721
INFO - 2016-09-08 13:09:24 --> Config Class Initialized
INFO - 2016-09-08 13:09:24 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:24 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:24 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:24 --> URI Class Initialized
INFO - 2016-09-08 13:09:24 --> Router Class Initialized
INFO - 2016-09-08 13:09:24 --> Output Class Initialized
INFO - 2016-09-08 13:09:24 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:24 --> Input Class Initialized
INFO - 2016-09-08 13:09:24 --> Language Class Initialized
INFO - 2016-09-08 13:09:24 --> Loader Class Initialized
INFO - 2016-09-08 13:09:24 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:24 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:24 --> Controller Class Initialized
INFO - 2016-09-08 13:09:24 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:24 --> Model Class Initialized
INFO - 2016-09-08 13:09:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:24 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:24 --> Total execution time: 0.0687
INFO - 2016-09-08 13:09:26 --> Config Class Initialized
INFO - 2016-09-08 13:09:26 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:26 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:26 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:26 --> URI Class Initialized
INFO - 2016-09-08 13:09:26 --> Router Class Initialized
INFO - 2016-09-08 13:09:26 --> Output Class Initialized
INFO - 2016-09-08 13:09:26 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:26 --> Input Class Initialized
INFO - 2016-09-08 13:09:26 --> Language Class Initialized
INFO - 2016-09-08 13:09:26 --> Loader Class Initialized
INFO - 2016-09-08 13:09:26 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:26 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:26 --> Controller Class Initialized
INFO - 2016-09-08 13:09:26 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:26 --> Model Class Initialized
INFO - 2016-09-08 13:09:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:26 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:26 --> Total execution time: 0.0895
INFO - 2016-09-08 13:09:31 --> Config Class Initialized
INFO - 2016-09-08 13:09:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:31 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:31 --> URI Class Initialized
INFO - 2016-09-08 13:09:31 --> Router Class Initialized
INFO - 2016-09-08 13:09:31 --> Output Class Initialized
INFO - 2016-09-08 13:09:31 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:31 --> Input Class Initialized
INFO - 2016-09-08 13:09:31 --> Language Class Initialized
INFO - 2016-09-08 13:09:31 --> Loader Class Initialized
INFO - 2016-09-08 13:09:31 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:31 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:31 --> Controller Class Initialized
INFO - 2016-09-08 13:09:31 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:31 --> Model Class Initialized
INFO - 2016-09-08 13:09:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:31 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:31 --> Total execution time: 0.0892
INFO - 2016-09-08 13:09:33 --> Config Class Initialized
INFO - 2016-09-08 13:09:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:33 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:33 --> URI Class Initialized
INFO - 2016-09-08 13:09:33 --> Router Class Initialized
INFO - 2016-09-08 13:09:33 --> Output Class Initialized
INFO - 2016-09-08 13:09:33 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:33 --> Input Class Initialized
INFO - 2016-09-08 13:09:33 --> Language Class Initialized
INFO - 2016-09-08 13:09:33 --> Loader Class Initialized
INFO - 2016-09-08 13:09:33 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:33 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:33 --> Controller Class Initialized
INFO - 2016-09-08 13:09:33 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:33 --> Model Class Initialized
INFO - 2016-09-08 13:09:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:33 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:33 --> Total execution time: 0.0726
INFO - 2016-09-08 13:09:37 --> Config Class Initialized
INFO - 2016-09-08 13:09:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:37 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:37 --> URI Class Initialized
INFO - 2016-09-08 13:09:37 --> Router Class Initialized
INFO - 2016-09-08 13:09:37 --> Output Class Initialized
INFO - 2016-09-08 13:09:37 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:37 --> Input Class Initialized
INFO - 2016-09-08 13:09:37 --> Language Class Initialized
INFO - 2016-09-08 13:09:37 --> Loader Class Initialized
INFO - 2016-09-08 13:09:37 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:37 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:37 --> Controller Class Initialized
INFO - 2016-09-08 13:09:37 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:37 --> Model Class Initialized
INFO - 2016-09-08 13:09:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:37 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:37 --> Total execution time: 0.0829
INFO - 2016-09-08 13:09:38 --> Config Class Initialized
INFO - 2016-09-08 13:09:38 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:38 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:38 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:38 --> URI Class Initialized
INFO - 2016-09-08 13:09:38 --> Router Class Initialized
INFO - 2016-09-08 13:09:38 --> Output Class Initialized
INFO - 2016-09-08 13:09:38 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:38 --> Input Class Initialized
INFO - 2016-09-08 13:09:38 --> Language Class Initialized
INFO - 2016-09-08 13:09:38 --> Loader Class Initialized
INFO - 2016-09-08 13:09:38 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:38 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:38 --> Controller Class Initialized
INFO - 2016-09-08 13:09:38 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:38 --> Model Class Initialized
INFO - 2016-09-08 13:09:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:38 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:38 --> Total execution time: 0.0876
INFO - 2016-09-08 13:09:41 --> Config Class Initialized
INFO - 2016-09-08 13:09:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:41 --> URI Class Initialized
INFO - 2016-09-08 13:09:41 --> Router Class Initialized
INFO - 2016-09-08 13:09:41 --> Output Class Initialized
INFO - 2016-09-08 13:09:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:41 --> Input Class Initialized
INFO - 2016-09-08 13:09:42 --> Language Class Initialized
INFO - 2016-09-08 13:09:42 --> Loader Class Initialized
INFO - 2016-09-08 13:09:42 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:42 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:42 --> Controller Class Initialized
INFO - 2016-09-08 13:09:42 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:42 --> Model Class Initialized
INFO - 2016-09-08 13:09:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:42 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:42 --> Total execution time: 0.0733
INFO - 2016-09-08 13:09:43 --> Config Class Initialized
INFO - 2016-09-08 13:09:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:43 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:43 --> URI Class Initialized
INFO - 2016-09-08 13:09:43 --> Router Class Initialized
INFO - 2016-09-08 13:09:43 --> Output Class Initialized
INFO - 2016-09-08 13:09:43 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:43 --> Input Class Initialized
INFO - 2016-09-08 13:09:43 --> Language Class Initialized
INFO - 2016-09-08 13:09:43 --> Loader Class Initialized
INFO - 2016-09-08 13:09:43 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:43 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:43 --> Controller Class Initialized
INFO - 2016-09-08 13:09:43 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:43 --> Model Class Initialized
INFO - 2016-09-08 13:09:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:43 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:43 --> Total execution time: 0.0674
INFO - 2016-09-08 13:09:46 --> Config Class Initialized
INFO - 2016-09-08 13:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:46 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:46 --> URI Class Initialized
INFO - 2016-09-08 13:09:46 --> Router Class Initialized
INFO - 2016-09-08 13:09:46 --> Output Class Initialized
INFO - 2016-09-08 13:09:46 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:46 --> Input Class Initialized
INFO - 2016-09-08 13:09:46 --> Language Class Initialized
INFO - 2016-09-08 13:09:46 --> Loader Class Initialized
INFO - 2016-09-08 13:09:46 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:46 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:46 --> Controller Class Initialized
INFO - 2016-09-08 13:09:46 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:46 --> Model Class Initialized
INFO - 2016-09-08 13:09:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:46 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:46 --> Total execution time: 0.0686
INFO - 2016-09-08 13:09:48 --> Config Class Initialized
INFO - 2016-09-08 13:09:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:48 --> URI Class Initialized
INFO - 2016-09-08 13:09:48 --> Router Class Initialized
INFO - 2016-09-08 13:09:48 --> Output Class Initialized
INFO - 2016-09-08 13:09:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:48 --> Input Class Initialized
INFO - 2016-09-08 13:09:48 --> Language Class Initialized
INFO - 2016-09-08 13:09:48 --> Loader Class Initialized
INFO - 2016-09-08 13:09:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:48 --> Controller Class Initialized
INFO - 2016-09-08 13:09:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:48 --> Model Class Initialized
INFO - 2016-09-08 13:09:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:48 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:48 --> Total execution time: 0.0792
INFO - 2016-09-08 13:09:52 --> Config Class Initialized
INFO - 2016-09-08 13:09:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:52 --> URI Class Initialized
INFO - 2016-09-08 13:09:52 --> Router Class Initialized
INFO - 2016-09-08 13:09:52 --> Output Class Initialized
INFO - 2016-09-08 13:09:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:52 --> Input Class Initialized
INFO - 2016-09-08 13:09:52 --> Language Class Initialized
INFO - 2016-09-08 13:09:52 --> Loader Class Initialized
INFO - 2016-09-08 13:09:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:52 --> Controller Class Initialized
INFO - 2016-09-08 13:09:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:52 --> Model Class Initialized
INFO - 2016-09-08 13:09:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:52 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:52 --> Total execution time: 0.0765
INFO - 2016-09-08 13:09:54 --> Config Class Initialized
INFO - 2016-09-08 13:09:54 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:54 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:54 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:54 --> URI Class Initialized
INFO - 2016-09-08 13:09:54 --> Router Class Initialized
INFO - 2016-09-08 13:09:54 --> Output Class Initialized
INFO - 2016-09-08 13:09:54 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:54 --> Input Class Initialized
INFO - 2016-09-08 13:09:54 --> Language Class Initialized
INFO - 2016-09-08 13:09:54 --> Loader Class Initialized
INFO - 2016-09-08 13:09:54 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:54 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:54 --> Controller Class Initialized
INFO - 2016-09-08 13:09:54 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:54 --> Model Class Initialized
INFO - 2016-09-08 13:09:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:54 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:54 --> Total execution time: 0.0701
INFO - 2016-09-08 13:09:56 --> Config Class Initialized
INFO - 2016-09-08 13:09:56 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:56 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:56 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:56 --> URI Class Initialized
INFO - 2016-09-08 13:09:56 --> Router Class Initialized
INFO - 2016-09-08 13:09:56 --> Output Class Initialized
INFO - 2016-09-08 13:09:56 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:56 --> Input Class Initialized
INFO - 2016-09-08 13:09:56 --> Language Class Initialized
INFO - 2016-09-08 13:09:56 --> Loader Class Initialized
INFO - 2016-09-08 13:09:56 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:56 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:56 --> Controller Class Initialized
INFO - 2016-09-08 13:09:56 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:56 --> Model Class Initialized
INFO - 2016-09-08 13:09:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:56 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:56 --> Total execution time: 0.0627
INFO - 2016-09-08 13:09:58 --> Config Class Initialized
INFO - 2016-09-08 13:09:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:09:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:09:58 --> Utf8 Class Initialized
INFO - 2016-09-08 13:09:58 --> URI Class Initialized
INFO - 2016-09-08 13:09:58 --> Router Class Initialized
INFO - 2016-09-08 13:09:58 --> Output Class Initialized
INFO - 2016-09-08 13:09:58 --> Security Class Initialized
DEBUG - 2016-09-08 13:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:09:58 --> Input Class Initialized
INFO - 2016-09-08 13:09:58 --> Language Class Initialized
INFO - 2016-09-08 13:09:58 --> Loader Class Initialized
INFO - 2016-09-08 13:09:58 --> Helper loaded: url_helper
INFO - 2016-09-08 13:09:58 --> Helper loaded: language_helper
INFO - 2016-09-08 13:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:09:58 --> Controller Class Initialized
INFO - 2016-09-08 13:09:58 --> Database Driver Class Initialized
INFO - 2016-09-08 13:09:58 --> Model Class Initialized
INFO - 2016-09-08 13:09:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:09:58 --> Final output sent to browser
DEBUG - 2016-09-08 13:09:58 --> Total execution time: 0.0668
INFO - 2016-09-08 13:10:00 --> Config Class Initialized
INFO - 2016-09-08 13:10:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:00 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:00 --> URI Class Initialized
INFO - 2016-09-08 13:10:00 --> Router Class Initialized
INFO - 2016-09-08 13:10:00 --> Output Class Initialized
INFO - 2016-09-08 13:10:00 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:00 --> Input Class Initialized
INFO - 2016-09-08 13:10:00 --> Language Class Initialized
INFO - 2016-09-08 13:10:00 --> Loader Class Initialized
INFO - 2016-09-08 13:10:00 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:00 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:00 --> Controller Class Initialized
INFO - 2016-09-08 13:10:00 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:00 --> Model Class Initialized
INFO - 2016-09-08 13:10:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:00 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:00 --> Total execution time: 0.0676
INFO - 2016-09-08 13:10:03 --> Config Class Initialized
INFO - 2016-09-08 13:10:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:03 --> URI Class Initialized
INFO - 2016-09-08 13:10:03 --> Router Class Initialized
INFO - 2016-09-08 13:10:03 --> Output Class Initialized
INFO - 2016-09-08 13:10:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:03 --> Input Class Initialized
INFO - 2016-09-08 13:10:03 --> Language Class Initialized
INFO - 2016-09-08 13:10:03 --> Loader Class Initialized
INFO - 2016-09-08 13:10:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:03 --> Controller Class Initialized
INFO - 2016-09-08 13:10:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:03 --> Model Class Initialized
INFO - 2016-09-08 13:10:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:03 --> Config Class Initialized
INFO - 2016-09-08 13:10:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:03 --> URI Class Initialized
INFO - 2016-09-08 13:10:03 --> Router Class Initialized
INFO - 2016-09-08 13:10:03 --> Output Class Initialized
INFO - 2016-09-08 13:10:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:03 --> Input Class Initialized
INFO - 2016-09-08 13:10:03 --> Language Class Initialized
INFO - 2016-09-08 13:10:03 --> Loader Class Initialized
INFO - 2016-09-08 13:10:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:03 --> Controller Class Initialized
INFO - 2016-09-08 13:10:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:03 --> Model Class Initialized
INFO - 2016-09-08 13:10:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:03 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:03 --> Total execution time: 0.0572
INFO - 2016-09-08 13:10:05 --> Config Class Initialized
INFO - 2016-09-08 13:10:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:05 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:05 --> URI Class Initialized
INFO - 2016-09-08 13:10:05 --> Router Class Initialized
INFO - 2016-09-08 13:10:05 --> Output Class Initialized
INFO - 2016-09-08 13:10:05 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:05 --> Input Class Initialized
INFO - 2016-09-08 13:10:05 --> Language Class Initialized
INFO - 2016-09-08 13:10:05 --> Loader Class Initialized
INFO - 2016-09-08 13:10:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:05 --> Controller Class Initialized
INFO - 2016-09-08 13:10:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:05 --> Model Class Initialized
INFO - 2016-09-08 13:10:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:05 --> Config Class Initialized
INFO - 2016-09-08 13:10:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:05 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:05 --> URI Class Initialized
INFO - 2016-09-08 13:10:05 --> Router Class Initialized
INFO - 2016-09-08 13:10:05 --> Output Class Initialized
INFO - 2016-09-08 13:10:05 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:05 --> Input Class Initialized
INFO - 2016-09-08 13:10:05 --> Language Class Initialized
INFO - 2016-09-08 13:10:05 --> Loader Class Initialized
INFO - 2016-09-08 13:10:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:05 --> Controller Class Initialized
INFO - 2016-09-08 13:10:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:05 --> Model Class Initialized
INFO - 2016-09-08 13:10:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:05 --> Total execution time: 0.0858
INFO - 2016-09-08 13:10:06 --> Config Class Initialized
INFO - 2016-09-08 13:10:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:06 --> URI Class Initialized
INFO - 2016-09-08 13:10:06 --> Router Class Initialized
INFO - 2016-09-08 13:10:06 --> Output Class Initialized
INFO - 2016-09-08 13:10:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:06 --> Input Class Initialized
INFO - 2016-09-08 13:10:06 --> Language Class Initialized
INFO - 2016-09-08 13:10:06 --> Loader Class Initialized
INFO - 2016-09-08 13:10:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:06 --> Controller Class Initialized
INFO - 2016-09-08 13:10:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:06 --> Model Class Initialized
INFO - 2016-09-08 13:10:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:06 --> Config Class Initialized
INFO - 2016-09-08 13:10:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:06 --> URI Class Initialized
INFO - 2016-09-08 13:10:06 --> Router Class Initialized
INFO - 2016-09-08 13:10:06 --> Output Class Initialized
INFO - 2016-09-08 13:10:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:06 --> Input Class Initialized
INFO - 2016-09-08 13:10:06 --> Language Class Initialized
INFO - 2016-09-08 13:10:06 --> Loader Class Initialized
INFO - 2016-09-08 13:10:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:06 --> Controller Class Initialized
INFO - 2016-09-08 13:10:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:06 --> Model Class Initialized
INFO - 2016-09-08 13:10:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:06 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:06 --> Total execution time: 0.0753
INFO - 2016-09-08 13:10:08 --> Config Class Initialized
INFO - 2016-09-08 13:10:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:08 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:08 --> URI Class Initialized
INFO - 2016-09-08 13:10:08 --> Router Class Initialized
INFO - 2016-09-08 13:10:08 --> Output Class Initialized
INFO - 2016-09-08 13:10:08 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:08 --> Input Class Initialized
INFO - 2016-09-08 13:10:08 --> Language Class Initialized
INFO - 2016-09-08 13:10:08 --> Loader Class Initialized
INFO - 2016-09-08 13:10:08 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:08 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:08 --> Controller Class Initialized
INFO - 2016-09-08 13:10:08 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:08 --> Model Class Initialized
INFO - 2016-09-08 13:10:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:08 --> Config Class Initialized
INFO - 2016-09-08 13:10:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:08 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:08 --> URI Class Initialized
INFO - 2016-09-08 13:10:08 --> Router Class Initialized
INFO - 2016-09-08 13:10:08 --> Output Class Initialized
INFO - 2016-09-08 13:10:08 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:08 --> Input Class Initialized
INFO - 2016-09-08 13:10:08 --> Language Class Initialized
INFO - 2016-09-08 13:10:08 --> Loader Class Initialized
INFO - 2016-09-08 13:10:08 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:08 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:08 --> Controller Class Initialized
INFO - 2016-09-08 13:10:08 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:08 --> Model Class Initialized
INFO - 2016-09-08 13:10:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:08 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:08 --> Total execution time: 0.0634
INFO - 2016-09-08 13:10:09 --> Config Class Initialized
INFO - 2016-09-08 13:10:09 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:09 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:09 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:09 --> URI Class Initialized
INFO - 2016-09-08 13:10:09 --> Router Class Initialized
INFO - 2016-09-08 13:10:09 --> Output Class Initialized
INFO - 2016-09-08 13:10:09 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:09 --> Input Class Initialized
INFO - 2016-09-08 13:10:09 --> Language Class Initialized
INFO - 2016-09-08 13:10:09 --> Loader Class Initialized
INFO - 2016-09-08 13:10:09 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:09 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:09 --> Controller Class Initialized
INFO - 2016-09-08 13:10:09 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:09 --> Model Class Initialized
INFO - 2016-09-08 13:10:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:09 --> Config Class Initialized
INFO - 2016-09-08 13:10:09 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:09 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:09 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:10 --> URI Class Initialized
INFO - 2016-09-08 13:10:10 --> Router Class Initialized
INFO - 2016-09-08 13:10:10 --> Output Class Initialized
INFO - 2016-09-08 13:10:10 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:10 --> Input Class Initialized
INFO - 2016-09-08 13:10:10 --> Language Class Initialized
INFO - 2016-09-08 13:10:10 --> Loader Class Initialized
INFO - 2016-09-08 13:10:10 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:10 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:10 --> Controller Class Initialized
INFO - 2016-09-08 13:10:10 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:10 --> Model Class Initialized
INFO - 2016-09-08 13:10:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:10 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:10 --> Total execution time: 0.0719
INFO - 2016-09-08 13:10:11 --> Config Class Initialized
INFO - 2016-09-08 13:10:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:11 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:11 --> URI Class Initialized
INFO - 2016-09-08 13:10:11 --> Router Class Initialized
INFO - 2016-09-08 13:10:11 --> Output Class Initialized
INFO - 2016-09-08 13:10:11 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:11 --> Input Class Initialized
INFO - 2016-09-08 13:10:11 --> Language Class Initialized
INFO - 2016-09-08 13:10:11 --> Loader Class Initialized
INFO - 2016-09-08 13:10:11 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:11 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:11 --> Controller Class Initialized
INFO - 2016-09-08 13:10:11 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:11 --> Model Class Initialized
INFO - 2016-09-08 13:10:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:11 --> Config Class Initialized
INFO - 2016-09-08 13:10:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:11 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:11 --> URI Class Initialized
INFO - 2016-09-08 13:10:11 --> Router Class Initialized
INFO - 2016-09-08 13:10:11 --> Output Class Initialized
INFO - 2016-09-08 13:10:11 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:11 --> Input Class Initialized
INFO - 2016-09-08 13:10:11 --> Language Class Initialized
INFO - 2016-09-08 13:10:11 --> Loader Class Initialized
INFO - 2016-09-08 13:10:11 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:11 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:11 --> Controller Class Initialized
INFO - 2016-09-08 13:10:11 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:11 --> Model Class Initialized
INFO - 2016-09-08 13:10:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:11 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:11 --> Total execution time: 0.0702
INFO - 2016-09-08 13:10:12 --> Config Class Initialized
INFO - 2016-09-08 13:10:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:12 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:12 --> URI Class Initialized
INFO - 2016-09-08 13:10:12 --> Router Class Initialized
INFO - 2016-09-08 13:10:12 --> Output Class Initialized
INFO - 2016-09-08 13:10:12 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:12 --> Input Class Initialized
INFO - 2016-09-08 13:10:12 --> Language Class Initialized
INFO - 2016-09-08 13:10:12 --> Loader Class Initialized
INFO - 2016-09-08 13:10:12 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:12 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:12 --> Controller Class Initialized
INFO - 2016-09-08 13:10:12 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:12 --> Model Class Initialized
INFO - 2016-09-08 13:10:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:13 --> Config Class Initialized
INFO - 2016-09-08 13:10:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:13 --> URI Class Initialized
INFO - 2016-09-08 13:10:13 --> Router Class Initialized
INFO - 2016-09-08 13:10:13 --> Output Class Initialized
INFO - 2016-09-08 13:10:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:13 --> Input Class Initialized
INFO - 2016-09-08 13:10:13 --> Language Class Initialized
INFO - 2016-09-08 13:10:13 --> Loader Class Initialized
INFO - 2016-09-08 13:10:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:13 --> Controller Class Initialized
INFO - 2016-09-08 13:10:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:13 --> Model Class Initialized
INFO - 2016-09-08 13:10:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:13 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:13 --> Total execution time: 0.0659
INFO - 2016-09-08 13:10:14 --> Config Class Initialized
INFO - 2016-09-08 13:10:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:14 --> URI Class Initialized
INFO - 2016-09-08 13:10:14 --> Router Class Initialized
INFO - 2016-09-08 13:10:14 --> Output Class Initialized
INFO - 2016-09-08 13:10:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:14 --> Input Class Initialized
INFO - 2016-09-08 13:10:14 --> Language Class Initialized
INFO - 2016-09-08 13:10:14 --> Loader Class Initialized
INFO - 2016-09-08 13:10:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:14 --> Controller Class Initialized
INFO - 2016-09-08 13:10:14 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:14 --> Model Class Initialized
INFO - 2016-09-08 13:10:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:14 --> Config Class Initialized
INFO - 2016-09-08 13:10:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:14 --> URI Class Initialized
INFO - 2016-09-08 13:10:14 --> Router Class Initialized
INFO - 2016-09-08 13:10:14 --> Output Class Initialized
INFO - 2016-09-08 13:10:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:14 --> Input Class Initialized
INFO - 2016-09-08 13:10:14 --> Language Class Initialized
INFO - 2016-09-08 13:10:14 --> Loader Class Initialized
INFO - 2016-09-08 13:10:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:14 --> Controller Class Initialized
INFO - 2016-09-08 13:10:14 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:14 --> Model Class Initialized
INFO - 2016-09-08 13:10:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:14 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:14 --> Total execution time: 0.0668
INFO - 2016-09-08 13:10:16 --> Config Class Initialized
INFO - 2016-09-08 13:10:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:16 --> URI Class Initialized
INFO - 2016-09-08 13:10:16 --> Router Class Initialized
INFO - 2016-09-08 13:10:16 --> Output Class Initialized
INFO - 2016-09-08 13:10:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:16 --> Input Class Initialized
INFO - 2016-09-08 13:10:16 --> Language Class Initialized
INFO - 2016-09-08 13:10:16 --> Loader Class Initialized
INFO - 2016-09-08 13:10:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:16 --> Controller Class Initialized
INFO - 2016-09-08 13:10:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:16 --> Model Class Initialized
INFO - 2016-09-08 13:10:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:16 --> Config Class Initialized
INFO - 2016-09-08 13:10:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:16 --> URI Class Initialized
INFO - 2016-09-08 13:10:16 --> Router Class Initialized
INFO - 2016-09-08 13:10:16 --> Output Class Initialized
INFO - 2016-09-08 13:10:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:16 --> Input Class Initialized
INFO - 2016-09-08 13:10:16 --> Language Class Initialized
INFO - 2016-09-08 13:10:16 --> Loader Class Initialized
INFO - 2016-09-08 13:10:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:16 --> Controller Class Initialized
INFO - 2016-09-08 13:10:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:16 --> Model Class Initialized
INFO - 2016-09-08 13:10:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:16 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:16 --> Total execution time: 0.0702
INFO - 2016-09-08 13:10:38 --> Config Class Initialized
INFO - 2016-09-08 13:10:38 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:38 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:38 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:38 --> URI Class Initialized
INFO - 2016-09-08 13:10:38 --> Router Class Initialized
INFO - 2016-09-08 13:10:38 --> Output Class Initialized
INFO - 2016-09-08 13:10:38 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:38 --> Input Class Initialized
INFO - 2016-09-08 13:10:38 --> Language Class Initialized
INFO - 2016-09-08 13:10:38 --> Loader Class Initialized
INFO - 2016-09-08 13:10:38 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:38 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:38 --> Controller Class Initialized
INFO - 2016-09-08 13:10:38 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:38 --> Model Class Initialized
INFO - 2016-09-08 13:10:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:38 --> Config Class Initialized
INFO - 2016-09-08 13:10:38 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:38 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:38 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:38 --> URI Class Initialized
INFO - 2016-09-08 13:10:38 --> Router Class Initialized
INFO - 2016-09-08 13:10:38 --> Output Class Initialized
INFO - 2016-09-08 13:10:38 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:38 --> Input Class Initialized
INFO - 2016-09-08 13:10:38 --> Language Class Initialized
INFO - 2016-09-08 13:10:38 --> Loader Class Initialized
INFO - 2016-09-08 13:10:38 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:38 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:38 --> Controller Class Initialized
INFO - 2016-09-08 13:10:38 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:38 --> Model Class Initialized
INFO - 2016-09-08 13:10:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:38 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:38 --> Total execution time: 0.0655
INFO - 2016-09-08 13:10:45 --> Config Class Initialized
INFO - 2016-09-08 13:10:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:45 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:45 --> URI Class Initialized
INFO - 2016-09-08 13:10:45 --> Router Class Initialized
INFO - 2016-09-08 13:10:45 --> Output Class Initialized
INFO - 2016-09-08 13:10:45 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:45 --> Input Class Initialized
INFO - 2016-09-08 13:10:45 --> Language Class Initialized
INFO - 2016-09-08 13:10:45 --> Loader Class Initialized
INFO - 2016-09-08 13:10:45 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:45 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:45 --> Controller Class Initialized
INFO - 2016-09-08 13:10:45 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:45 --> Model Class Initialized
INFO - 2016-09-08 13:10:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:45 --> Config Class Initialized
INFO - 2016-09-08 13:10:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:45 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:45 --> URI Class Initialized
INFO - 2016-09-08 13:10:45 --> Router Class Initialized
INFO - 2016-09-08 13:10:45 --> Output Class Initialized
INFO - 2016-09-08 13:10:45 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:45 --> Input Class Initialized
INFO - 2016-09-08 13:10:45 --> Language Class Initialized
INFO - 2016-09-08 13:10:45 --> Loader Class Initialized
INFO - 2016-09-08 13:10:45 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:45 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:45 --> Controller Class Initialized
INFO - 2016-09-08 13:10:45 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:45 --> Model Class Initialized
INFO - 2016-09-08 13:10:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:45 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:45 --> Total execution time: 0.0595
INFO - 2016-09-08 13:10:50 --> Config Class Initialized
INFO - 2016-09-08 13:10:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:50 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:50 --> URI Class Initialized
INFO - 2016-09-08 13:10:50 --> Router Class Initialized
INFO - 2016-09-08 13:10:50 --> Output Class Initialized
INFO - 2016-09-08 13:10:50 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:50 --> Input Class Initialized
INFO - 2016-09-08 13:10:50 --> Language Class Initialized
INFO - 2016-09-08 13:10:50 --> Loader Class Initialized
INFO - 2016-09-08 13:10:50 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:50 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:50 --> Controller Class Initialized
INFO - 2016-09-08 13:10:50 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:50 --> Model Class Initialized
INFO - 2016-09-08 13:10:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:50 --> Config Class Initialized
INFO - 2016-09-08 13:10:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:50 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:50 --> URI Class Initialized
INFO - 2016-09-08 13:10:50 --> Router Class Initialized
INFO - 2016-09-08 13:10:50 --> Output Class Initialized
INFO - 2016-09-08 13:10:50 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:50 --> Input Class Initialized
INFO - 2016-09-08 13:10:50 --> Language Class Initialized
INFO - 2016-09-08 13:10:50 --> Loader Class Initialized
INFO - 2016-09-08 13:10:50 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:50 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:50 --> Controller Class Initialized
INFO - 2016-09-08 13:10:50 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:50 --> Model Class Initialized
INFO - 2016-09-08 13:10:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:50 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:50 --> Total execution time: 0.0584
INFO - 2016-09-08 13:10:55 --> Config Class Initialized
INFO - 2016-09-08 13:10:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:55 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:55 --> URI Class Initialized
INFO - 2016-09-08 13:10:55 --> Router Class Initialized
INFO - 2016-09-08 13:10:55 --> Output Class Initialized
INFO - 2016-09-08 13:10:55 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:55 --> Input Class Initialized
INFO - 2016-09-08 13:10:55 --> Language Class Initialized
INFO - 2016-09-08 13:10:55 --> Loader Class Initialized
INFO - 2016-09-08 13:10:55 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:55 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:55 --> Controller Class Initialized
INFO - 2016-09-08 13:10:55 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:55 --> Model Class Initialized
INFO - 2016-09-08 13:10:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:55 --> Config Class Initialized
INFO - 2016-09-08 13:10:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:10:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:10:55 --> Utf8 Class Initialized
INFO - 2016-09-08 13:10:55 --> URI Class Initialized
INFO - 2016-09-08 13:10:55 --> Router Class Initialized
INFO - 2016-09-08 13:10:55 --> Output Class Initialized
INFO - 2016-09-08 13:10:55 --> Security Class Initialized
DEBUG - 2016-09-08 13:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:10:55 --> Input Class Initialized
INFO - 2016-09-08 13:10:55 --> Language Class Initialized
INFO - 2016-09-08 13:10:55 --> Loader Class Initialized
INFO - 2016-09-08 13:10:55 --> Helper loaded: url_helper
INFO - 2016-09-08 13:10:55 --> Helper loaded: language_helper
INFO - 2016-09-08 13:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:10:55 --> Controller Class Initialized
INFO - 2016-09-08 13:10:55 --> Database Driver Class Initialized
INFO - 2016-09-08 13:10:55 --> Model Class Initialized
INFO - 2016-09-08 13:10:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:10:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:10:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:10:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:10:55 --> Final output sent to browser
DEBUG - 2016-09-08 13:10:55 --> Total execution time: 0.0575
INFO - 2016-09-08 13:11:01 --> Config Class Initialized
INFO - 2016-09-08 13:11:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:01 --> URI Class Initialized
INFO - 2016-09-08 13:11:01 --> Router Class Initialized
INFO - 2016-09-08 13:11:01 --> Output Class Initialized
INFO - 2016-09-08 13:11:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:01 --> Input Class Initialized
INFO - 2016-09-08 13:11:01 --> Language Class Initialized
INFO - 2016-09-08 13:11:01 --> Loader Class Initialized
INFO - 2016-09-08 13:11:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:01 --> Controller Class Initialized
INFO - 2016-09-08 13:11:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:01 --> Model Class Initialized
INFO - 2016-09-08 13:11:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:01 --> Config Class Initialized
INFO - 2016-09-08 13:11:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:01 --> URI Class Initialized
INFO - 2016-09-08 13:11:01 --> Router Class Initialized
INFO - 2016-09-08 13:11:01 --> Output Class Initialized
INFO - 2016-09-08 13:11:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:01 --> Input Class Initialized
INFO - 2016-09-08 13:11:01 --> Language Class Initialized
INFO - 2016-09-08 13:11:01 --> Loader Class Initialized
INFO - 2016-09-08 13:11:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:01 --> Controller Class Initialized
INFO - 2016-09-08 13:11:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:01 --> Model Class Initialized
INFO - 2016-09-08 13:11:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:11:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:11:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:11:01 --> Final output sent to browser
DEBUG - 2016-09-08 13:11:01 --> Total execution time: 0.0593
INFO - 2016-09-08 13:11:06 --> Config Class Initialized
INFO - 2016-09-08 13:11:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:06 --> URI Class Initialized
INFO - 2016-09-08 13:11:06 --> Router Class Initialized
INFO - 2016-09-08 13:11:06 --> Output Class Initialized
INFO - 2016-09-08 13:11:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:06 --> Input Class Initialized
INFO - 2016-09-08 13:11:06 --> Language Class Initialized
INFO - 2016-09-08 13:11:06 --> Loader Class Initialized
INFO - 2016-09-08 13:11:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:06 --> Controller Class Initialized
INFO - 2016-09-08 13:11:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:06 --> Model Class Initialized
INFO - 2016-09-08 13:11:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:06 --> Config Class Initialized
INFO - 2016-09-08 13:11:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:06 --> URI Class Initialized
INFO - 2016-09-08 13:11:06 --> Router Class Initialized
INFO - 2016-09-08 13:11:06 --> Output Class Initialized
INFO - 2016-09-08 13:11:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:06 --> Input Class Initialized
INFO - 2016-09-08 13:11:06 --> Language Class Initialized
INFO - 2016-09-08 13:11:06 --> Loader Class Initialized
INFO - 2016-09-08 13:11:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:06 --> Controller Class Initialized
INFO - 2016-09-08 13:11:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:06 --> Model Class Initialized
INFO - 2016-09-08 13:11:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:11:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:11:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:11:06 --> Final output sent to browser
DEBUG - 2016-09-08 13:11:06 --> Total execution time: 0.0600
INFO - 2016-09-08 13:11:12 --> Config Class Initialized
INFO - 2016-09-08 13:11:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:12 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:12 --> URI Class Initialized
INFO - 2016-09-08 13:11:12 --> Router Class Initialized
INFO - 2016-09-08 13:11:12 --> Output Class Initialized
INFO - 2016-09-08 13:11:12 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:12 --> Input Class Initialized
INFO - 2016-09-08 13:11:12 --> Language Class Initialized
INFO - 2016-09-08 13:11:12 --> Loader Class Initialized
INFO - 2016-09-08 13:11:12 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:12 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:12 --> Controller Class Initialized
INFO - 2016-09-08 13:11:12 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:12 --> Model Class Initialized
INFO - 2016-09-08 13:11:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:12 --> Config Class Initialized
INFO - 2016-09-08 13:11:12 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:12 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:12 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:12 --> URI Class Initialized
INFO - 2016-09-08 13:11:12 --> Router Class Initialized
INFO - 2016-09-08 13:11:12 --> Output Class Initialized
INFO - 2016-09-08 13:11:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:13 --> Input Class Initialized
INFO - 2016-09-08 13:11:13 --> Language Class Initialized
INFO - 2016-09-08 13:11:13 --> Loader Class Initialized
INFO - 2016-09-08 13:11:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:13 --> Controller Class Initialized
INFO - 2016-09-08 13:11:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:13 --> Model Class Initialized
INFO - 2016-09-08 13:11:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:11:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:11:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:11:13 --> Final output sent to browser
DEBUG - 2016-09-08 13:11:13 --> Total execution time: 0.0615
INFO - 2016-09-08 13:11:19 --> Config Class Initialized
INFO - 2016-09-08 13:11:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:19 --> URI Class Initialized
INFO - 2016-09-08 13:11:19 --> Router Class Initialized
INFO - 2016-09-08 13:11:19 --> Output Class Initialized
INFO - 2016-09-08 13:11:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:19 --> Input Class Initialized
INFO - 2016-09-08 13:11:19 --> Language Class Initialized
INFO - 2016-09-08 13:11:19 --> Loader Class Initialized
INFO - 2016-09-08 13:11:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:19 --> Controller Class Initialized
INFO - 2016-09-08 13:11:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:19 --> Model Class Initialized
INFO - 2016-09-08 13:11:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:19 --> Config Class Initialized
INFO - 2016-09-08 13:11:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:19 --> URI Class Initialized
INFO - 2016-09-08 13:11:19 --> Router Class Initialized
INFO - 2016-09-08 13:11:19 --> Output Class Initialized
INFO - 2016-09-08 13:11:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:19 --> Input Class Initialized
INFO - 2016-09-08 13:11:19 --> Language Class Initialized
INFO - 2016-09-08 13:11:19 --> Loader Class Initialized
INFO - 2016-09-08 13:11:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:19 --> Controller Class Initialized
INFO - 2016-09-08 13:11:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:19 --> Model Class Initialized
INFO - 2016-09-08 13:11:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:11:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:11:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:11:19 --> Final output sent to browser
DEBUG - 2016-09-08 13:11:19 --> Total execution time: 0.0581
INFO - 2016-09-08 13:11:26 --> Config Class Initialized
INFO - 2016-09-08 13:11:26 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:26 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:26 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:26 --> URI Class Initialized
INFO - 2016-09-08 13:11:26 --> Router Class Initialized
INFO - 2016-09-08 13:11:26 --> Output Class Initialized
INFO - 2016-09-08 13:11:26 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:26 --> Input Class Initialized
INFO - 2016-09-08 13:11:26 --> Language Class Initialized
INFO - 2016-09-08 13:11:26 --> Loader Class Initialized
INFO - 2016-09-08 13:11:26 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:26 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:26 --> Controller Class Initialized
INFO - 2016-09-08 13:11:26 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:26 --> Model Class Initialized
INFO - 2016-09-08 13:11:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:26 --> Config Class Initialized
INFO - 2016-09-08 13:11:26 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:26 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:26 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:26 --> URI Class Initialized
INFO - 2016-09-08 13:11:26 --> Router Class Initialized
INFO - 2016-09-08 13:11:26 --> Output Class Initialized
INFO - 2016-09-08 13:11:26 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:26 --> Input Class Initialized
INFO - 2016-09-08 13:11:26 --> Language Class Initialized
INFO - 2016-09-08 13:11:26 --> Loader Class Initialized
INFO - 2016-09-08 13:11:26 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:26 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:26 --> Controller Class Initialized
INFO - 2016-09-08 13:11:26 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:26 --> Model Class Initialized
INFO - 2016-09-08 13:11:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:11:26 --> Final output sent to browser
DEBUG - 2016-09-08 13:11:26 --> Total execution time: 0.0621
INFO - 2016-09-08 13:11:57 --> Config Class Initialized
INFO - 2016-09-08 13:11:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:11:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:11:57 --> Utf8 Class Initialized
INFO - 2016-09-08 13:11:57 --> URI Class Initialized
INFO - 2016-09-08 13:11:57 --> Router Class Initialized
INFO - 2016-09-08 13:11:57 --> Output Class Initialized
INFO - 2016-09-08 13:11:57 --> Security Class Initialized
DEBUG - 2016-09-08 13:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:11:57 --> Input Class Initialized
INFO - 2016-09-08 13:11:57 --> Language Class Initialized
INFO - 2016-09-08 13:11:57 --> Loader Class Initialized
INFO - 2016-09-08 13:11:57 --> Helper loaded: url_helper
INFO - 2016-09-08 13:11:57 --> Helper loaded: language_helper
INFO - 2016-09-08 13:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:11:57 --> Controller Class Initialized
INFO - 2016-09-08 13:11:57 --> Database Driver Class Initialized
INFO - 2016-09-08 13:11:57 --> Model Class Initialized
INFO - 2016-09-08 13:11:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:11:57 --> Final output sent to browser
DEBUG - 2016-09-08 13:11:57 --> Total execution time: 0.0752
INFO - 2016-09-08 13:12:01 --> Config Class Initialized
INFO - 2016-09-08 13:12:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:01 --> URI Class Initialized
INFO - 2016-09-08 13:12:01 --> Router Class Initialized
INFO - 2016-09-08 13:12:01 --> Output Class Initialized
INFO - 2016-09-08 13:12:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:01 --> Input Class Initialized
INFO - 2016-09-08 13:12:01 --> Language Class Initialized
INFO - 2016-09-08 13:12:01 --> Loader Class Initialized
INFO - 2016-09-08 13:12:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:01 --> Controller Class Initialized
INFO - 2016-09-08 13:12:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:01 --> Model Class Initialized
INFO - 2016-09-08 13:12:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:01 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:01 --> Total execution time: 0.0706
INFO - 2016-09-08 13:12:05 --> Config Class Initialized
INFO - 2016-09-08 13:12:05 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:05 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:05 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:05 --> URI Class Initialized
INFO - 2016-09-08 13:12:05 --> Router Class Initialized
INFO - 2016-09-08 13:12:05 --> Output Class Initialized
INFO - 2016-09-08 13:12:05 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:05 --> Input Class Initialized
INFO - 2016-09-08 13:12:05 --> Language Class Initialized
INFO - 2016-09-08 13:12:05 --> Loader Class Initialized
INFO - 2016-09-08 13:12:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:05 --> Controller Class Initialized
INFO - 2016-09-08 13:12:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:05 --> Model Class Initialized
INFO - 2016-09-08 13:12:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:05 --> Total execution time: 0.0632
INFO - 2016-09-08 13:12:13 --> Config Class Initialized
INFO - 2016-09-08 13:12:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:13 --> URI Class Initialized
INFO - 2016-09-08 13:12:13 --> Router Class Initialized
INFO - 2016-09-08 13:12:13 --> Output Class Initialized
INFO - 2016-09-08 13:12:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:13 --> Input Class Initialized
INFO - 2016-09-08 13:12:13 --> Language Class Initialized
INFO - 2016-09-08 13:12:13 --> Loader Class Initialized
INFO - 2016-09-08 13:12:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:13 --> Controller Class Initialized
INFO - 2016-09-08 13:12:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:13 --> Model Class Initialized
INFO - 2016-09-08 13:12:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:13 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:13 --> Total execution time: 0.0616
INFO - 2016-09-08 13:12:19 --> Config Class Initialized
INFO - 2016-09-08 13:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:19 --> URI Class Initialized
INFO - 2016-09-08 13:12:19 --> Router Class Initialized
INFO - 2016-09-08 13:12:19 --> Output Class Initialized
INFO - 2016-09-08 13:12:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:19 --> Input Class Initialized
INFO - 2016-09-08 13:12:19 --> Language Class Initialized
INFO - 2016-09-08 13:12:19 --> Loader Class Initialized
INFO - 2016-09-08 13:12:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:19 --> Controller Class Initialized
INFO - 2016-09-08 13:12:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:19 --> Model Class Initialized
INFO - 2016-09-08 13:12:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:19 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:19 --> Total execution time: 0.0648
INFO - 2016-09-08 13:12:30 --> Config Class Initialized
INFO - 2016-09-08 13:12:30 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:30 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:30 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:30 --> URI Class Initialized
INFO - 2016-09-08 13:12:30 --> Router Class Initialized
INFO - 2016-09-08 13:12:30 --> Output Class Initialized
INFO - 2016-09-08 13:12:30 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:30 --> Input Class Initialized
INFO - 2016-09-08 13:12:30 --> Language Class Initialized
INFO - 2016-09-08 13:12:30 --> Loader Class Initialized
INFO - 2016-09-08 13:12:30 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:30 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:30 --> Controller Class Initialized
INFO - 2016-09-08 13:12:30 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:30 --> Model Class Initialized
INFO - 2016-09-08 13:12:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:30 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:30 --> Total execution time: 0.0619
INFO - 2016-09-08 13:12:45 --> Config Class Initialized
INFO - 2016-09-08 13:12:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:45 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:45 --> URI Class Initialized
INFO - 2016-09-08 13:12:45 --> Router Class Initialized
INFO - 2016-09-08 13:12:45 --> Output Class Initialized
INFO - 2016-09-08 13:12:45 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:45 --> Input Class Initialized
INFO - 2016-09-08 13:12:45 --> Language Class Initialized
INFO - 2016-09-08 13:12:45 --> Loader Class Initialized
INFO - 2016-09-08 13:12:45 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:45 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:45 --> Controller Class Initialized
INFO - 2016-09-08 13:12:45 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:45 --> Model Class Initialized
INFO - 2016-09-08 13:12:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:45 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:45 --> Total execution time: 0.0615
INFO - 2016-09-08 13:12:50 --> Config Class Initialized
INFO - 2016-09-08 13:12:50 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:50 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:50 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:50 --> URI Class Initialized
INFO - 2016-09-08 13:12:50 --> Router Class Initialized
INFO - 2016-09-08 13:12:50 --> Output Class Initialized
INFO - 2016-09-08 13:12:50 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:50 --> Input Class Initialized
INFO - 2016-09-08 13:12:50 --> Language Class Initialized
INFO - 2016-09-08 13:12:50 --> Loader Class Initialized
INFO - 2016-09-08 13:12:50 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:50 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:50 --> Controller Class Initialized
INFO - 2016-09-08 13:12:50 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:50 --> Model Class Initialized
INFO - 2016-09-08 13:12:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:50 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:50 --> Total execution time: 0.0636
INFO - 2016-09-08 13:12:56 --> Config Class Initialized
INFO - 2016-09-08 13:12:56 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:56 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:56 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:56 --> URI Class Initialized
INFO - 2016-09-08 13:12:56 --> Router Class Initialized
INFO - 2016-09-08 13:12:56 --> Output Class Initialized
INFO - 2016-09-08 13:12:56 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:56 --> Input Class Initialized
INFO - 2016-09-08 13:12:56 --> Language Class Initialized
INFO - 2016-09-08 13:12:56 --> Loader Class Initialized
INFO - 2016-09-08 13:12:56 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:56 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:56 --> Controller Class Initialized
INFO - 2016-09-08 13:12:56 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:56 --> Model Class Initialized
INFO - 2016-09-08 13:12:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:56 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:56 --> Total execution time: 0.0685
INFO - 2016-09-08 13:12:58 --> Config Class Initialized
INFO - 2016-09-08 13:12:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:12:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:12:58 --> Utf8 Class Initialized
INFO - 2016-09-08 13:12:58 --> URI Class Initialized
INFO - 2016-09-08 13:12:58 --> Router Class Initialized
INFO - 2016-09-08 13:12:58 --> Output Class Initialized
INFO - 2016-09-08 13:12:58 --> Security Class Initialized
DEBUG - 2016-09-08 13:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:12:58 --> Input Class Initialized
INFO - 2016-09-08 13:12:58 --> Language Class Initialized
INFO - 2016-09-08 13:12:58 --> Loader Class Initialized
INFO - 2016-09-08 13:12:58 --> Helper loaded: url_helper
INFO - 2016-09-08 13:12:58 --> Helper loaded: language_helper
INFO - 2016-09-08 13:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:12:58 --> Controller Class Initialized
INFO - 2016-09-08 13:12:59 --> Database Driver Class Initialized
INFO - 2016-09-08 13:12:59 --> Model Class Initialized
INFO - 2016-09-08 13:12:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:12:59 --> Final output sent to browser
DEBUG - 2016-09-08 13:12:59 --> Total execution time: 0.0609
INFO - 2016-09-08 13:13:00 --> Config Class Initialized
INFO - 2016-09-08 13:13:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:00 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:00 --> URI Class Initialized
INFO - 2016-09-08 13:13:00 --> Router Class Initialized
INFO - 2016-09-08 13:13:00 --> Output Class Initialized
INFO - 2016-09-08 13:13:00 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:00 --> Input Class Initialized
INFO - 2016-09-08 13:13:00 --> Language Class Initialized
INFO - 2016-09-08 13:13:00 --> Loader Class Initialized
INFO - 2016-09-08 13:13:00 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:00 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:00 --> Controller Class Initialized
INFO - 2016-09-08 13:13:00 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:00 --> Model Class Initialized
INFO - 2016-09-08 13:13:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:00 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:00 --> Total execution time: 0.0797
INFO - 2016-09-08 13:13:01 --> Config Class Initialized
INFO - 2016-09-08 13:13:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:01 --> URI Class Initialized
INFO - 2016-09-08 13:13:01 --> Router Class Initialized
INFO - 2016-09-08 13:13:01 --> Output Class Initialized
INFO - 2016-09-08 13:13:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:01 --> Input Class Initialized
INFO - 2016-09-08 13:13:01 --> Language Class Initialized
INFO - 2016-09-08 13:13:01 --> Loader Class Initialized
INFO - 2016-09-08 13:13:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:01 --> Controller Class Initialized
INFO - 2016-09-08 13:13:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:01 --> Model Class Initialized
INFO - 2016-09-08 13:13:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:02 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:02 --> Total execution time: 0.0604
INFO - 2016-09-08 13:13:02 --> Config Class Initialized
INFO - 2016-09-08 13:13:02 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:02 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:02 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:02 --> URI Class Initialized
INFO - 2016-09-08 13:13:02 --> Router Class Initialized
INFO - 2016-09-08 13:13:02 --> Output Class Initialized
INFO - 2016-09-08 13:13:02 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:02 --> Input Class Initialized
INFO - 2016-09-08 13:13:02 --> Language Class Initialized
INFO - 2016-09-08 13:13:02 --> Loader Class Initialized
INFO - 2016-09-08 13:13:02 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:02 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:02 --> Controller Class Initialized
INFO - 2016-09-08 13:13:02 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:02 --> Model Class Initialized
INFO - 2016-09-08 13:13:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:02 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:02 --> Total execution time: 0.0775
INFO - 2016-09-08 13:13:03 --> Config Class Initialized
INFO - 2016-09-08 13:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:03 --> URI Class Initialized
INFO - 2016-09-08 13:13:03 --> Router Class Initialized
INFO - 2016-09-08 13:13:03 --> Output Class Initialized
INFO - 2016-09-08 13:13:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:03 --> Input Class Initialized
INFO - 2016-09-08 13:13:03 --> Language Class Initialized
INFO - 2016-09-08 13:13:03 --> Loader Class Initialized
INFO - 2016-09-08 13:13:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:04 --> Controller Class Initialized
INFO - 2016-09-08 13:13:04 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:04 --> Model Class Initialized
INFO - 2016-09-08 13:13:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:04 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:04 --> Total execution time: 0.0594
INFO - 2016-09-08 13:13:04 --> Config Class Initialized
INFO - 2016-09-08 13:13:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:04 --> URI Class Initialized
INFO - 2016-09-08 13:13:04 --> Router Class Initialized
INFO - 2016-09-08 13:13:04 --> Output Class Initialized
INFO - 2016-09-08 13:13:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:05 --> Input Class Initialized
INFO - 2016-09-08 13:13:05 --> Language Class Initialized
INFO - 2016-09-08 13:13:05 --> Loader Class Initialized
INFO - 2016-09-08 13:13:05 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:05 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:05 --> Controller Class Initialized
INFO - 2016-09-08 13:13:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:05 --> Model Class Initialized
INFO - 2016-09-08 13:13:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:05 --> Total execution time: 0.0608
INFO - 2016-09-08 13:13:07 --> Config Class Initialized
INFO - 2016-09-08 13:13:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:07 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:07 --> URI Class Initialized
INFO - 2016-09-08 13:13:07 --> Router Class Initialized
INFO - 2016-09-08 13:13:07 --> Output Class Initialized
INFO - 2016-09-08 13:13:07 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:07 --> Input Class Initialized
INFO - 2016-09-08 13:13:07 --> Language Class Initialized
INFO - 2016-09-08 13:13:07 --> Loader Class Initialized
INFO - 2016-09-08 13:13:07 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:07 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:07 --> Controller Class Initialized
INFO - 2016-09-08 13:13:07 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:07 --> Model Class Initialized
INFO - 2016-09-08 13:13:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:07 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:07 --> Total execution time: 0.0675
INFO - 2016-09-08 13:13:08 --> Config Class Initialized
INFO - 2016-09-08 13:13:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:08 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:08 --> URI Class Initialized
INFO - 2016-09-08 13:13:08 --> Router Class Initialized
INFO - 2016-09-08 13:13:08 --> Output Class Initialized
INFO - 2016-09-08 13:13:08 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:08 --> Input Class Initialized
INFO - 2016-09-08 13:13:08 --> Language Class Initialized
INFO - 2016-09-08 13:13:08 --> Loader Class Initialized
INFO - 2016-09-08 13:13:08 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:08 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:08 --> Controller Class Initialized
INFO - 2016-09-08 13:13:08 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:08 --> Model Class Initialized
INFO - 2016-09-08 13:13:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:08 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:08 --> Total execution time: 0.0653
INFO - 2016-09-08 13:13:09 --> Config Class Initialized
INFO - 2016-09-08 13:13:09 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:09 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:09 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:09 --> URI Class Initialized
INFO - 2016-09-08 13:13:09 --> Router Class Initialized
INFO - 2016-09-08 13:13:09 --> Output Class Initialized
INFO - 2016-09-08 13:13:09 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:09 --> Input Class Initialized
INFO - 2016-09-08 13:13:09 --> Language Class Initialized
INFO - 2016-09-08 13:13:09 --> Loader Class Initialized
INFO - 2016-09-08 13:13:09 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:09 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:09 --> Controller Class Initialized
INFO - 2016-09-08 13:13:09 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:09 --> Model Class Initialized
INFO - 2016-09-08 13:13:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:09 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:09 --> Total execution time: 0.0587
INFO - 2016-09-08 13:13:14 --> Config Class Initialized
INFO - 2016-09-08 13:13:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:14 --> URI Class Initialized
INFO - 2016-09-08 13:13:14 --> Router Class Initialized
INFO - 2016-09-08 13:13:14 --> Output Class Initialized
INFO - 2016-09-08 13:13:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:14 --> Input Class Initialized
INFO - 2016-09-08 13:13:14 --> Language Class Initialized
INFO - 2016-09-08 13:13:14 --> Loader Class Initialized
INFO - 2016-09-08 13:13:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:14 --> Controller Class Initialized
INFO - 2016-09-08 13:13:14 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:14 --> Model Class Initialized
INFO - 2016-09-08 13:13:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:13:14 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:14 --> Total execution time: 0.0642
INFO - 2016-09-08 13:13:34 --> Config Class Initialized
INFO - 2016-09-08 13:13:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:34 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:34 --> URI Class Initialized
INFO - 2016-09-08 13:13:34 --> Router Class Initialized
INFO - 2016-09-08 13:13:34 --> Output Class Initialized
INFO - 2016-09-08 13:13:34 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:34 --> Input Class Initialized
INFO - 2016-09-08 13:13:34 --> Language Class Initialized
INFO - 2016-09-08 13:13:34 --> Loader Class Initialized
INFO - 2016-09-08 13:13:34 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:34 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:34 --> Controller Class Initialized
INFO - 2016-09-08 13:13:34 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:34 --> Model Class Initialized
INFO - 2016-09-08 13:13:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:34 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:34 --> Total execution time: 0.0718
INFO - 2016-09-08 13:13:36 --> Config Class Initialized
INFO - 2016-09-08 13:13:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:36 --> URI Class Initialized
INFO - 2016-09-08 13:13:36 --> Router Class Initialized
INFO - 2016-09-08 13:13:36 --> Output Class Initialized
INFO - 2016-09-08 13:13:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:36 --> Input Class Initialized
INFO - 2016-09-08 13:13:36 --> Language Class Initialized
INFO - 2016-09-08 13:13:36 --> Loader Class Initialized
INFO - 2016-09-08 13:13:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:36 --> Controller Class Initialized
INFO - 2016-09-08 13:13:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:36 --> Model Class Initialized
INFO - 2016-09-08 13:13:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:36 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:36 --> Total execution time: 0.0713
INFO - 2016-09-08 13:13:38 --> Config Class Initialized
INFO - 2016-09-08 13:13:38 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:38 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:38 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:38 --> URI Class Initialized
INFO - 2016-09-08 13:13:38 --> Router Class Initialized
INFO - 2016-09-08 13:13:38 --> Output Class Initialized
INFO - 2016-09-08 13:13:38 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:38 --> Input Class Initialized
INFO - 2016-09-08 13:13:38 --> Language Class Initialized
INFO - 2016-09-08 13:13:38 --> Loader Class Initialized
INFO - 2016-09-08 13:13:38 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:38 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:38 --> Controller Class Initialized
INFO - 2016-09-08 13:13:38 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:38 --> Model Class Initialized
INFO - 2016-09-08 13:13:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:38 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:38 --> Total execution time: 0.0656
INFO - 2016-09-08 13:13:43 --> Config Class Initialized
INFO - 2016-09-08 13:13:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:43 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:43 --> URI Class Initialized
INFO - 2016-09-08 13:13:43 --> Router Class Initialized
INFO - 2016-09-08 13:13:43 --> Output Class Initialized
INFO - 2016-09-08 13:13:43 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:43 --> Input Class Initialized
INFO - 2016-09-08 13:13:43 --> Language Class Initialized
INFO - 2016-09-08 13:13:43 --> Loader Class Initialized
INFO - 2016-09-08 13:13:43 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:43 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:43 --> Controller Class Initialized
INFO - 2016-09-08 13:13:43 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:43 --> Model Class Initialized
INFO - 2016-09-08 13:13:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:43 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:43 --> Total execution time: 0.0606
INFO - 2016-09-08 13:13:45 --> Config Class Initialized
INFO - 2016-09-08 13:13:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:45 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:45 --> URI Class Initialized
INFO - 2016-09-08 13:13:45 --> Router Class Initialized
INFO - 2016-09-08 13:13:45 --> Output Class Initialized
INFO - 2016-09-08 13:13:45 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:45 --> Input Class Initialized
INFO - 2016-09-08 13:13:45 --> Language Class Initialized
INFO - 2016-09-08 13:13:45 --> Loader Class Initialized
INFO - 2016-09-08 13:13:45 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:45 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:45 --> Controller Class Initialized
INFO - 2016-09-08 13:13:45 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:45 --> Model Class Initialized
INFO - 2016-09-08 13:13:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:45 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:45 --> Total execution time: 0.0634
INFO - 2016-09-08 13:13:46 --> Config Class Initialized
INFO - 2016-09-08 13:13:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:46 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:46 --> URI Class Initialized
INFO - 2016-09-08 13:13:46 --> Router Class Initialized
INFO - 2016-09-08 13:13:46 --> Output Class Initialized
INFO - 2016-09-08 13:13:46 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:46 --> Input Class Initialized
INFO - 2016-09-08 13:13:46 --> Language Class Initialized
INFO - 2016-09-08 13:13:46 --> Loader Class Initialized
INFO - 2016-09-08 13:13:46 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:46 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:46 --> Controller Class Initialized
INFO - 2016-09-08 13:13:46 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:46 --> Model Class Initialized
INFO - 2016-09-08 13:13:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:13:46 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:46 --> Total execution time: 0.0691
INFO - 2016-09-08 13:13:58 --> Config Class Initialized
INFO - 2016-09-08 13:13:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:13:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:13:58 --> Utf8 Class Initialized
INFO - 2016-09-08 13:13:58 --> URI Class Initialized
INFO - 2016-09-08 13:13:58 --> Router Class Initialized
INFO - 2016-09-08 13:13:58 --> Output Class Initialized
INFO - 2016-09-08 13:13:58 --> Security Class Initialized
DEBUG - 2016-09-08 13:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:13:58 --> Input Class Initialized
INFO - 2016-09-08 13:13:58 --> Language Class Initialized
INFO - 2016-09-08 13:13:58 --> Loader Class Initialized
INFO - 2016-09-08 13:13:58 --> Helper loaded: url_helper
INFO - 2016-09-08 13:13:58 --> Helper loaded: language_helper
INFO - 2016-09-08 13:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:13:58 --> Controller Class Initialized
INFO - 2016-09-08 13:13:58 --> Database Driver Class Initialized
INFO - 2016-09-08 13:13:58 --> Model Class Initialized
INFO - 2016-09-08 13:13:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:13:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:13:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:13:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:13:58 --> Final output sent to browser
DEBUG - 2016-09-08 13:13:58 --> Total execution time: 0.0556
INFO - 2016-09-08 13:14:31 --> Config Class Initialized
INFO - 2016-09-08 13:14:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:31 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:31 --> URI Class Initialized
INFO - 2016-09-08 13:14:31 --> Router Class Initialized
INFO - 2016-09-08 13:14:31 --> Output Class Initialized
INFO - 2016-09-08 13:14:31 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:31 --> Input Class Initialized
INFO - 2016-09-08 13:14:31 --> Language Class Initialized
INFO - 2016-09-08 13:14:31 --> Loader Class Initialized
INFO - 2016-09-08 13:14:31 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:31 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:31 --> Controller Class Initialized
INFO - 2016-09-08 13:14:31 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:31 --> Model Class Initialized
INFO - 2016-09-08 13:14:31 --> Model Class Initialized
INFO - 2016-09-08 13:14:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:14:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-08 13:14:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:14:31 --> Final output sent to browser
DEBUG - 2016-09-08 13:14:31 --> Total execution time: 0.0638
INFO - 2016-09-08 13:14:34 --> Config Class Initialized
INFO - 2016-09-08 13:14:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:34 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:34 --> URI Class Initialized
INFO - 2016-09-08 13:14:34 --> Router Class Initialized
INFO - 2016-09-08 13:14:34 --> Output Class Initialized
INFO - 2016-09-08 13:14:34 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:34 --> Input Class Initialized
INFO - 2016-09-08 13:14:34 --> Language Class Initialized
INFO - 2016-09-08 13:14:34 --> Loader Class Initialized
INFO - 2016-09-08 13:14:34 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:34 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:34 --> Controller Class Initialized
INFO - 2016-09-08 13:14:34 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:35 --> Model Class Initialized
INFO - 2016-09-08 13:14:35 --> Model Class Initialized
INFO - 2016-09-08 13:14:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:35 --> Config Class Initialized
INFO - 2016-09-08 13:14:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:35 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:35 --> URI Class Initialized
INFO - 2016-09-08 13:14:35 --> Router Class Initialized
INFO - 2016-09-08 13:14:35 --> Output Class Initialized
INFO - 2016-09-08 13:14:35 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:35 --> Input Class Initialized
INFO - 2016-09-08 13:14:35 --> Language Class Initialized
INFO - 2016-09-08 13:14:35 --> Loader Class Initialized
INFO - 2016-09-08 13:14:35 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:35 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:35 --> Controller Class Initialized
INFO - 2016-09-08 13:14:35 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:35 --> Model Class Initialized
INFO - 2016-09-08 13:14:35 --> Model Class Initialized
INFO - 2016-09-08 13:14:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:14:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-08 13:14:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:14:35 --> Final output sent to browser
DEBUG - 2016-09-08 13:14:35 --> Total execution time: 0.0638
INFO - 2016-09-08 13:14:37 --> Config Class Initialized
INFO - 2016-09-08 13:14:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:37 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:37 --> URI Class Initialized
INFO - 2016-09-08 13:14:37 --> Router Class Initialized
INFO - 2016-09-08 13:14:37 --> Output Class Initialized
INFO - 2016-09-08 13:14:37 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:37 --> Input Class Initialized
INFO - 2016-09-08 13:14:37 --> Language Class Initialized
INFO - 2016-09-08 13:14:37 --> Loader Class Initialized
INFO - 2016-09-08 13:14:37 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:37 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:37 --> Controller Class Initialized
INFO - 2016-09-08 13:14:37 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:37 --> Model Class Initialized
INFO - 2016-09-08 13:14:37 --> Model Class Initialized
INFO - 2016-09-08 13:14:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:37 --> Config Class Initialized
INFO - 2016-09-08 13:14:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:37 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:37 --> URI Class Initialized
INFO - 2016-09-08 13:14:37 --> Router Class Initialized
INFO - 2016-09-08 13:14:37 --> Output Class Initialized
INFO - 2016-09-08 13:14:37 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:37 --> Input Class Initialized
INFO - 2016-09-08 13:14:37 --> Language Class Initialized
INFO - 2016-09-08 13:14:37 --> Loader Class Initialized
INFO - 2016-09-08 13:14:37 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:37 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:37 --> Controller Class Initialized
INFO - 2016-09-08 13:14:37 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:37 --> Model Class Initialized
INFO - 2016-09-08 13:14:37 --> Model Class Initialized
INFO - 2016-09-08 13:14:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:14:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-08 13:14:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:14:37 --> Final output sent to browser
DEBUG - 2016-09-08 13:14:37 --> Total execution time: 0.0623
INFO - 2016-09-08 13:14:42 --> Config Class Initialized
INFO - 2016-09-08 13:14:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:42 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:42 --> URI Class Initialized
INFO - 2016-09-08 13:14:42 --> Router Class Initialized
INFO - 2016-09-08 13:14:42 --> Output Class Initialized
INFO - 2016-09-08 13:14:42 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:42 --> Input Class Initialized
INFO - 2016-09-08 13:14:42 --> Language Class Initialized
INFO - 2016-09-08 13:14:42 --> Loader Class Initialized
INFO - 2016-09-08 13:14:42 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:42 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:42 --> Controller Class Initialized
INFO - 2016-09-08 13:14:42 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:42 --> Model Class Initialized
INFO - 2016-09-08 13:14:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:42 --> Helper loaded: form_helper
INFO - 2016-09-08 13:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:14:42 --> Final output sent to browser
DEBUG - 2016-09-08 13:14:42 --> Total execution time: 0.0967
INFO - 2016-09-08 13:14:48 --> Config Class Initialized
INFO - 2016-09-08 13:14:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:48 --> URI Class Initialized
INFO - 2016-09-08 13:14:48 --> Router Class Initialized
INFO - 2016-09-08 13:14:48 --> Output Class Initialized
INFO - 2016-09-08 13:14:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:48 --> Input Class Initialized
INFO - 2016-09-08 13:14:48 --> Language Class Initialized
INFO - 2016-09-08 13:14:48 --> Loader Class Initialized
INFO - 2016-09-08 13:14:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:48 --> Controller Class Initialized
INFO - 2016-09-08 13:14:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:48 --> Model Class Initialized
INFO - 2016-09-08 13:14:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:48 --> Model Class Initialized
INFO - 2016-09-08 13:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\result_list.php
INFO - 2016-09-08 13:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:14:48 --> Final output sent to browser
DEBUG - 2016-09-08 13:14:48 --> Total execution time: 0.0997
INFO - 2016-09-08 13:14:52 --> Config Class Initialized
INFO - 2016-09-08 13:14:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:14:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:14:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:14:52 --> URI Class Initialized
INFO - 2016-09-08 13:14:52 --> Router Class Initialized
INFO - 2016-09-08 13:14:52 --> Output Class Initialized
INFO - 2016-09-08 13:14:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:14:52 --> Input Class Initialized
INFO - 2016-09-08 13:14:52 --> Language Class Initialized
INFO - 2016-09-08 13:14:52 --> Loader Class Initialized
INFO - 2016-09-08 13:14:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:14:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:14:52 --> Controller Class Initialized
INFO - 2016-09-08 13:14:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:14:52 --> Model Class Initialized
INFO - 2016-09-08 13:14:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:14:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:14:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\level_list.php
INFO - 2016-09-08 13:14:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:14:52 --> Final output sent to browser
DEBUG - 2016-09-08 13:14:52 --> Total execution time: 0.0602
INFO - 2016-09-08 13:15:15 --> Config Class Initialized
INFO - 2016-09-08 13:15:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:15 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:15 --> URI Class Initialized
INFO - 2016-09-08 13:15:15 --> Router Class Initialized
INFO - 2016-09-08 13:15:15 --> Output Class Initialized
INFO - 2016-09-08 13:15:15 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:15 --> Input Class Initialized
INFO - 2016-09-08 13:15:15 --> Language Class Initialized
INFO - 2016-09-08 13:15:15 --> Loader Class Initialized
INFO - 2016-09-08 13:15:15 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:15 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:15 --> Controller Class Initialized
INFO - 2016-09-08 13:15:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:15 --> Model Class Initialized
INFO - 2016-09-08 13:15:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:15 --> Final output sent to browser
DEBUG - 2016-09-08 13:15:15 --> Total execution time: 0.0666
INFO - 2016-09-08 13:15:16 --> Config Class Initialized
INFO - 2016-09-08 13:15:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:16 --> URI Class Initialized
INFO - 2016-09-08 13:15:16 --> Router Class Initialized
INFO - 2016-09-08 13:15:16 --> Output Class Initialized
INFO - 2016-09-08 13:15:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:16 --> Input Class Initialized
INFO - 2016-09-08 13:15:16 --> Language Class Initialized
INFO - 2016-09-08 13:15:16 --> Loader Class Initialized
INFO - 2016-09-08 13:15:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:16 --> Controller Class Initialized
INFO - 2016-09-08 13:15:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:16 --> Model Class Initialized
INFO - 2016-09-08 13:15:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:16 --> Config Class Initialized
INFO - 2016-09-08 13:15:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:16 --> URI Class Initialized
INFO - 2016-09-08 13:15:16 --> Router Class Initialized
INFO - 2016-09-08 13:15:16 --> Output Class Initialized
INFO - 2016-09-08 13:15:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:16 --> Input Class Initialized
INFO - 2016-09-08 13:15:16 --> Language Class Initialized
INFO - 2016-09-08 13:15:16 --> Loader Class Initialized
INFO - 2016-09-08 13:15:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:16 --> Controller Class Initialized
INFO - 2016-09-08 13:15:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:16 --> Model Class Initialized
INFO - 2016-09-08 13:15:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\level_list.php
INFO - 2016-09-08 13:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:15:16 --> Final output sent to browser
DEBUG - 2016-09-08 13:15:16 --> Total execution time: 0.0595
INFO - 2016-09-08 13:15:18 --> Config Class Initialized
INFO - 2016-09-08 13:15:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:18 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:18 --> URI Class Initialized
INFO - 2016-09-08 13:15:18 --> Router Class Initialized
INFO - 2016-09-08 13:15:18 --> Output Class Initialized
INFO - 2016-09-08 13:15:18 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:18 --> Input Class Initialized
INFO - 2016-09-08 13:15:18 --> Language Class Initialized
INFO - 2016-09-08 13:15:18 --> Loader Class Initialized
INFO - 2016-09-08 13:15:18 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:18 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:18 --> Controller Class Initialized
INFO - 2016-09-08 13:15:18 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:18 --> Model Class Initialized
INFO - 2016-09-08 13:15:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:18 --> Config Class Initialized
INFO - 2016-09-08 13:15:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:18 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:18 --> URI Class Initialized
INFO - 2016-09-08 13:15:18 --> Router Class Initialized
INFO - 2016-09-08 13:15:18 --> Output Class Initialized
INFO - 2016-09-08 13:15:18 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:18 --> Input Class Initialized
INFO - 2016-09-08 13:15:18 --> Language Class Initialized
INFO - 2016-09-08 13:15:18 --> Loader Class Initialized
INFO - 2016-09-08 13:15:18 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:18 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:18 --> Controller Class Initialized
INFO - 2016-09-08 13:15:18 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:18 --> Model Class Initialized
INFO - 2016-09-08 13:15:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:15:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\level_list.php
INFO - 2016-09-08 13:15:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:15:18 --> Final output sent to browser
DEBUG - 2016-09-08 13:15:18 --> Total execution time: 0.0607
INFO - 2016-09-08 13:15:22 --> Config Class Initialized
INFO - 2016-09-08 13:15:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:22 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:22 --> URI Class Initialized
INFO - 2016-09-08 13:15:22 --> Router Class Initialized
INFO - 2016-09-08 13:15:22 --> Output Class Initialized
INFO - 2016-09-08 13:15:22 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:22 --> Input Class Initialized
INFO - 2016-09-08 13:15:22 --> Language Class Initialized
INFO - 2016-09-08 13:15:22 --> Loader Class Initialized
INFO - 2016-09-08 13:15:22 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:22 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:22 --> Controller Class Initialized
INFO - 2016-09-08 13:15:22 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:22 --> Model Class Initialized
INFO - 2016-09-08 13:15:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:15:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-08 13:15:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:15:22 --> Final output sent to browser
DEBUG - 2016-09-08 13:15:22 --> Total execution time: 0.0745
INFO - 2016-09-08 13:15:25 --> Config Class Initialized
INFO - 2016-09-08 13:15:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:25 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:25 --> URI Class Initialized
INFO - 2016-09-08 13:15:25 --> Router Class Initialized
INFO - 2016-09-08 13:15:25 --> Output Class Initialized
INFO - 2016-09-08 13:15:25 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:25 --> Input Class Initialized
INFO - 2016-09-08 13:15:25 --> Language Class Initialized
INFO - 2016-09-08 13:15:25 --> Loader Class Initialized
INFO - 2016-09-08 13:15:25 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:25 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:25 --> Controller Class Initialized
INFO - 2016-09-08 13:15:25 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:25 --> Model Class Initialized
INFO - 2016-09-08 13:15:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:15:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\group_list.php
INFO - 2016-09-08 13:15:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:15:25 --> Final output sent to browser
DEBUG - 2016-09-08 13:15:25 --> Total execution time: 0.0697
INFO - 2016-09-08 13:15:37 --> Config Class Initialized
INFO - 2016-09-08 13:15:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:15:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:15:37 --> Utf8 Class Initialized
INFO - 2016-09-08 13:15:37 --> URI Class Initialized
INFO - 2016-09-08 13:15:37 --> Router Class Initialized
INFO - 2016-09-08 13:15:37 --> Output Class Initialized
INFO - 2016-09-08 13:15:37 --> Security Class Initialized
DEBUG - 2016-09-08 13:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:15:37 --> Input Class Initialized
INFO - 2016-09-08 13:15:37 --> Language Class Initialized
INFO - 2016-09-08 13:15:37 --> Loader Class Initialized
INFO - 2016-09-08 13:15:37 --> Helper loaded: url_helper
INFO - 2016-09-08 13:15:37 --> Helper loaded: language_helper
INFO - 2016-09-08 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:15:37 --> Controller Class Initialized
INFO - 2016-09-08 13:15:37 --> Database Driver Class Initialized
INFO - 2016-09-08 13:15:37 --> Model Class Initialized
INFO - 2016-09-08 13:15:37 --> Model Class Initialized
INFO - 2016-09-08 13:15:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:15:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:15:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-08 13:15:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:15:37 --> Final output sent to browser
DEBUG - 2016-09-08 13:15:37 --> Total execution time: 0.0687
INFO - 2016-09-08 13:17:00 --> Config Class Initialized
INFO - 2016-09-08 13:17:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:17:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:17:00 --> Utf8 Class Initialized
INFO - 2016-09-08 13:17:00 --> URI Class Initialized
INFO - 2016-09-08 13:17:00 --> Router Class Initialized
INFO - 2016-09-08 13:17:00 --> Output Class Initialized
INFO - 2016-09-08 13:17:00 --> Security Class Initialized
DEBUG - 2016-09-08 13:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:17:00 --> Input Class Initialized
INFO - 2016-09-08 13:17:00 --> Language Class Initialized
INFO - 2016-09-08 13:17:00 --> Loader Class Initialized
INFO - 2016-09-08 13:17:00 --> Helper loaded: url_helper
INFO - 2016-09-08 13:17:00 --> Helper loaded: language_helper
INFO - 2016-09-08 13:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:17:00 --> Controller Class Initialized
INFO - 2016-09-08 13:17:00 --> Database Driver Class Initialized
INFO - 2016-09-08 13:17:00 --> Model Class Initialized
INFO - 2016-09-08 13:17:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:17:00 --> Final output sent to browser
DEBUG - 2016-09-08 13:17:00 --> Total execution time: 0.0591
INFO - 2016-09-08 13:17:06 --> Config Class Initialized
INFO - 2016-09-08 13:17:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:17:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:17:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:17:06 --> URI Class Initialized
INFO - 2016-09-08 13:17:06 --> Router Class Initialized
INFO - 2016-09-08 13:17:06 --> Output Class Initialized
INFO - 2016-09-08 13:17:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:17:06 --> Input Class Initialized
INFO - 2016-09-08 13:17:06 --> Language Class Initialized
INFO - 2016-09-08 13:17:06 --> Loader Class Initialized
INFO - 2016-09-08 13:17:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:17:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:17:06 --> Controller Class Initialized
INFO - 2016-09-08 13:17:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:17:06 --> Model Class Initialized
INFO - 2016-09-08 13:17:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:17:06 --> Config Class Initialized
INFO - 2016-09-08 13:17:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:17:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:17:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:17:06 --> URI Class Initialized
INFO - 2016-09-08 13:17:06 --> Router Class Initialized
INFO - 2016-09-08 13:17:06 --> Output Class Initialized
INFO - 2016-09-08 13:17:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:17:06 --> Input Class Initialized
INFO - 2016-09-08 13:17:06 --> Language Class Initialized
INFO - 2016-09-08 13:17:06 --> Loader Class Initialized
INFO - 2016-09-08 13:17:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:17:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:17:06 --> Controller Class Initialized
INFO - 2016-09-08 13:17:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:17:06 --> Model Class Initialized
INFO - 2016-09-08 13:17:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:17:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:17:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:17:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:17:06 --> Final output sent to browser
DEBUG - 2016-09-08 13:17:06 --> Total execution time: 0.0660
INFO - 2016-09-08 13:18:42 --> Config Class Initialized
INFO - 2016-09-08 13:18:42 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:18:42 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:18:42 --> Utf8 Class Initialized
INFO - 2016-09-08 13:18:42 --> URI Class Initialized
INFO - 2016-09-08 13:18:42 --> Router Class Initialized
INFO - 2016-09-08 13:18:42 --> Output Class Initialized
INFO - 2016-09-08 13:18:42 --> Security Class Initialized
DEBUG - 2016-09-08 13:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:18:42 --> Input Class Initialized
INFO - 2016-09-08 13:18:42 --> Language Class Initialized
INFO - 2016-09-08 13:18:42 --> Loader Class Initialized
INFO - 2016-09-08 13:18:42 --> Helper loaded: url_helper
INFO - 2016-09-08 13:18:42 --> Helper loaded: language_helper
INFO - 2016-09-08 13:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:18:42 --> Controller Class Initialized
INFO - 2016-09-08 13:18:42 --> Database Driver Class Initialized
INFO - 2016-09-08 13:18:42 --> Model Class Initialized
INFO - 2016-09-08 13:18:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:18:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:18:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:18:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:18:42 --> Final output sent to browser
DEBUG - 2016-09-08 13:18:42 --> Total execution time: 0.0616
INFO - 2016-09-08 13:20:14 --> Config Class Initialized
INFO - 2016-09-08 13:20:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:20:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:20:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:20:14 --> URI Class Initialized
INFO - 2016-09-08 13:20:14 --> Router Class Initialized
INFO - 2016-09-08 13:20:14 --> Output Class Initialized
INFO - 2016-09-08 13:20:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:20:14 --> Input Class Initialized
INFO - 2016-09-08 13:20:14 --> Language Class Initialized
INFO - 2016-09-08 13:20:14 --> Loader Class Initialized
INFO - 2016-09-08 13:20:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:20:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:20:14 --> Controller Class Initialized
INFO - 2016-09-08 13:20:14 --> Database Driver Class Initialized
INFO - 2016-09-08 13:20:14 --> Model Class Initialized
INFO - 2016-09-08 13:20:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:20:14 --> Config Class Initialized
INFO - 2016-09-08 13:20:14 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:20:14 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:20:14 --> Utf8 Class Initialized
INFO - 2016-09-08 13:20:14 --> URI Class Initialized
INFO - 2016-09-08 13:20:14 --> Router Class Initialized
INFO - 2016-09-08 13:20:14 --> Output Class Initialized
INFO - 2016-09-08 13:20:14 --> Security Class Initialized
DEBUG - 2016-09-08 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:20:14 --> Input Class Initialized
INFO - 2016-09-08 13:20:14 --> Language Class Initialized
INFO - 2016-09-08 13:20:14 --> Loader Class Initialized
INFO - 2016-09-08 13:20:14 --> Helper loaded: url_helper
INFO - 2016-09-08 13:20:14 --> Helper loaded: language_helper
INFO - 2016-09-08 13:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:20:14 --> Controller Class Initialized
INFO - 2016-09-08 13:20:14 --> Database Driver Class Initialized
INFO - 2016-09-08 13:20:14 --> Model Class Initialized
INFO - 2016-09-08 13:20:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:20:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:20:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:20:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:20:14 --> Final output sent to browser
DEBUG - 2016-09-08 13:20:14 --> Total execution time: 0.0711
INFO - 2016-09-08 13:20:20 --> Config Class Initialized
INFO - 2016-09-08 13:20:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:20:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:20:20 --> Utf8 Class Initialized
INFO - 2016-09-08 13:20:20 --> URI Class Initialized
INFO - 2016-09-08 13:20:20 --> Router Class Initialized
INFO - 2016-09-08 13:20:20 --> Output Class Initialized
INFO - 2016-09-08 13:20:20 --> Security Class Initialized
DEBUG - 2016-09-08 13:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:20:20 --> Input Class Initialized
INFO - 2016-09-08 13:20:20 --> Language Class Initialized
INFO - 2016-09-08 13:20:20 --> Loader Class Initialized
INFO - 2016-09-08 13:20:20 --> Helper loaded: url_helper
INFO - 2016-09-08 13:20:20 --> Helper loaded: language_helper
INFO - 2016-09-08 13:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:20:20 --> Controller Class Initialized
INFO - 2016-09-08 13:20:20 --> Database Driver Class Initialized
INFO - 2016-09-08 13:20:20 --> Model Class Initialized
INFO - 2016-09-08 13:20:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:20:20 --> Config Class Initialized
INFO - 2016-09-08 13:20:20 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:20:20 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:20:20 --> Utf8 Class Initialized
INFO - 2016-09-08 13:20:20 --> URI Class Initialized
INFO - 2016-09-08 13:20:20 --> Router Class Initialized
INFO - 2016-09-08 13:20:20 --> Output Class Initialized
INFO - 2016-09-08 13:20:20 --> Security Class Initialized
DEBUG - 2016-09-08 13:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:20:20 --> Input Class Initialized
INFO - 2016-09-08 13:20:20 --> Language Class Initialized
INFO - 2016-09-08 13:20:20 --> Loader Class Initialized
INFO - 2016-09-08 13:20:20 --> Helper loaded: url_helper
INFO - 2016-09-08 13:20:20 --> Helper loaded: language_helper
INFO - 2016-09-08 13:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:20:20 --> Controller Class Initialized
INFO - 2016-09-08 13:20:20 --> Database Driver Class Initialized
INFO - 2016-09-08 13:20:20 --> Model Class Initialized
INFO - 2016-09-08 13:20:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:20:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:20:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:20:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:20:20 --> Final output sent to browser
DEBUG - 2016-09-08 13:20:20 --> Total execution time: 0.0919
INFO - 2016-09-08 13:20:59 --> Config Class Initialized
INFO - 2016-09-08 13:20:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:20:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:20:59 --> Utf8 Class Initialized
INFO - 2016-09-08 13:20:59 --> URI Class Initialized
INFO - 2016-09-08 13:20:59 --> Router Class Initialized
INFO - 2016-09-08 13:20:59 --> Output Class Initialized
INFO - 2016-09-08 13:20:59 --> Security Class Initialized
DEBUG - 2016-09-08 13:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:20:59 --> Input Class Initialized
INFO - 2016-09-08 13:20:59 --> Language Class Initialized
INFO - 2016-09-08 13:20:59 --> Loader Class Initialized
INFO - 2016-09-08 13:20:59 --> Helper loaded: url_helper
INFO - 2016-09-08 13:20:59 --> Helper loaded: language_helper
INFO - 2016-09-08 13:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:20:59 --> Controller Class Initialized
INFO - 2016-09-08 13:20:59 --> Database Driver Class Initialized
INFO - 2016-09-08 13:20:59 --> Model Class Initialized
INFO - 2016-09-08 13:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:20:59 --> Config Class Initialized
INFO - 2016-09-08 13:20:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:20:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:20:59 --> Utf8 Class Initialized
INFO - 2016-09-08 13:20:59 --> URI Class Initialized
INFO - 2016-09-08 13:20:59 --> Router Class Initialized
INFO - 2016-09-08 13:20:59 --> Output Class Initialized
INFO - 2016-09-08 13:20:59 --> Security Class Initialized
DEBUG - 2016-09-08 13:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:20:59 --> Input Class Initialized
INFO - 2016-09-08 13:20:59 --> Language Class Initialized
INFO - 2016-09-08 13:20:59 --> Loader Class Initialized
INFO - 2016-09-08 13:20:59 --> Helper loaded: url_helper
INFO - 2016-09-08 13:20:59 --> Helper loaded: language_helper
INFO - 2016-09-08 13:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:20:59 --> Controller Class Initialized
INFO - 2016-09-08 13:20:59 --> Database Driver Class Initialized
INFO - 2016-09-08 13:20:59 --> Model Class Initialized
INFO - 2016-09-08 13:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:20:59 --> Final output sent to browser
DEBUG - 2016-09-08 13:20:59 --> Total execution time: 0.0563
INFO - 2016-09-08 13:21:13 --> Config Class Initialized
INFO - 2016-09-08 13:21:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:21:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:21:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:21:13 --> URI Class Initialized
INFO - 2016-09-08 13:21:13 --> Router Class Initialized
INFO - 2016-09-08 13:21:13 --> Output Class Initialized
INFO - 2016-09-08 13:21:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:21:13 --> Input Class Initialized
INFO - 2016-09-08 13:21:13 --> Language Class Initialized
INFO - 2016-09-08 13:21:13 --> Loader Class Initialized
INFO - 2016-09-08 13:21:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:21:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:21:13 --> Controller Class Initialized
INFO - 2016-09-08 13:21:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:21:13 --> Model Class Initialized
INFO - 2016-09-08 13:21:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:21:13 --> Config Class Initialized
INFO - 2016-09-08 13:21:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:21:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:21:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:21:13 --> URI Class Initialized
INFO - 2016-09-08 13:21:13 --> Router Class Initialized
INFO - 2016-09-08 13:21:13 --> Output Class Initialized
INFO - 2016-09-08 13:21:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:21:13 --> Input Class Initialized
INFO - 2016-09-08 13:21:13 --> Language Class Initialized
INFO - 2016-09-08 13:21:13 --> Loader Class Initialized
INFO - 2016-09-08 13:21:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:21:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:21:13 --> Controller Class Initialized
INFO - 2016-09-08 13:21:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:21:13 --> Model Class Initialized
INFO - 2016-09-08 13:21:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:21:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:21:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:21:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:21:13 --> Final output sent to browser
DEBUG - 2016-09-08 13:21:13 --> Total execution time: 0.0792
INFO - 2016-09-08 13:22:23 --> Config Class Initialized
INFO - 2016-09-08 13:22:23 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:22:23 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:22:23 --> Utf8 Class Initialized
INFO - 2016-09-08 13:22:23 --> URI Class Initialized
INFO - 2016-09-08 13:22:23 --> Router Class Initialized
INFO - 2016-09-08 13:22:23 --> Output Class Initialized
INFO - 2016-09-08 13:22:23 --> Security Class Initialized
DEBUG - 2016-09-08 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:22:23 --> Input Class Initialized
INFO - 2016-09-08 13:22:23 --> Language Class Initialized
INFO - 2016-09-08 13:22:23 --> Loader Class Initialized
INFO - 2016-09-08 13:22:23 --> Helper loaded: url_helper
INFO - 2016-09-08 13:22:23 --> Helper loaded: language_helper
INFO - 2016-09-08 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:22:23 --> Controller Class Initialized
INFO - 2016-09-08 13:22:23 --> Database Driver Class Initialized
INFO - 2016-09-08 13:22:23 --> Model Class Initialized
INFO - 2016-09-08 13:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:22:23 --> Config Class Initialized
INFO - 2016-09-08 13:22:23 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:22:23 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:22:23 --> Utf8 Class Initialized
INFO - 2016-09-08 13:22:23 --> URI Class Initialized
INFO - 2016-09-08 13:22:23 --> Router Class Initialized
INFO - 2016-09-08 13:22:23 --> Output Class Initialized
INFO - 2016-09-08 13:22:23 --> Security Class Initialized
DEBUG - 2016-09-08 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:22:23 --> Input Class Initialized
INFO - 2016-09-08 13:22:23 --> Language Class Initialized
INFO - 2016-09-08 13:22:23 --> Loader Class Initialized
INFO - 2016-09-08 13:22:23 --> Helper loaded: url_helper
INFO - 2016-09-08 13:22:23 --> Helper loaded: language_helper
INFO - 2016-09-08 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:22:23 --> Controller Class Initialized
INFO - 2016-09-08 13:22:23 --> Database Driver Class Initialized
INFO - 2016-09-08 13:22:23 --> Model Class Initialized
INFO - 2016-09-08 13:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:22:23 --> Final output sent to browser
DEBUG - 2016-09-08 13:22:23 --> Total execution time: 0.0564
INFO - 2016-09-08 13:22:25 --> Config Class Initialized
INFO - 2016-09-08 13:22:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:22:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:22:25 --> Utf8 Class Initialized
INFO - 2016-09-08 13:22:25 --> URI Class Initialized
INFO - 2016-09-08 13:22:25 --> Router Class Initialized
INFO - 2016-09-08 13:22:25 --> Output Class Initialized
INFO - 2016-09-08 13:22:25 --> Security Class Initialized
DEBUG - 2016-09-08 13:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:22:25 --> Input Class Initialized
INFO - 2016-09-08 13:22:25 --> Language Class Initialized
INFO - 2016-09-08 13:22:25 --> Loader Class Initialized
INFO - 2016-09-08 13:22:25 --> Helper loaded: url_helper
INFO - 2016-09-08 13:22:25 --> Helper loaded: language_helper
INFO - 2016-09-08 13:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:22:25 --> Controller Class Initialized
INFO - 2016-09-08 13:22:25 --> Database Driver Class Initialized
INFO - 2016-09-08 13:22:25 --> Model Class Initialized
INFO - 2016-09-08 13:22:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:22:25 --> Config Class Initialized
INFO - 2016-09-08 13:22:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:22:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:22:25 --> Utf8 Class Initialized
INFO - 2016-09-08 13:22:25 --> URI Class Initialized
INFO - 2016-09-08 13:22:25 --> Router Class Initialized
INFO - 2016-09-08 13:22:25 --> Output Class Initialized
INFO - 2016-09-08 13:22:25 --> Security Class Initialized
DEBUG - 2016-09-08 13:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:22:25 --> Input Class Initialized
INFO - 2016-09-08 13:22:25 --> Language Class Initialized
INFO - 2016-09-08 13:22:25 --> Loader Class Initialized
INFO - 2016-09-08 13:22:25 --> Helper loaded: url_helper
INFO - 2016-09-08 13:22:25 --> Helper loaded: language_helper
INFO - 2016-09-08 13:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:22:25 --> Controller Class Initialized
INFO - 2016-09-08 13:22:25 --> Database Driver Class Initialized
INFO - 2016-09-08 13:22:25 --> Model Class Initialized
INFO - 2016-09-08 13:22:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:22:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:22:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:22:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:22:25 --> Final output sent to browser
DEBUG - 2016-09-08 13:22:25 --> Total execution time: 0.0699
INFO - 2016-09-08 13:23:37 --> Config Class Initialized
INFO - 2016-09-08 13:23:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:23:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:23:37 --> Utf8 Class Initialized
INFO - 2016-09-08 13:23:37 --> URI Class Initialized
INFO - 2016-09-08 13:23:37 --> Router Class Initialized
INFO - 2016-09-08 13:23:37 --> Output Class Initialized
INFO - 2016-09-08 13:23:37 --> Security Class Initialized
DEBUG - 2016-09-08 13:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:23:37 --> Input Class Initialized
INFO - 2016-09-08 13:23:37 --> Language Class Initialized
INFO - 2016-09-08 13:23:37 --> Loader Class Initialized
INFO - 2016-09-08 13:23:37 --> Helper loaded: url_helper
INFO - 2016-09-08 13:23:37 --> Helper loaded: language_helper
INFO - 2016-09-08 13:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:23:37 --> Controller Class Initialized
INFO - 2016-09-08 13:23:37 --> Database Driver Class Initialized
INFO - 2016-09-08 13:23:37 --> Model Class Initialized
INFO - 2016-09-08 13:23:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:23:37 --> Config Class Initialized
INFO - 2016-09-08 13:23:37 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:23:37 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:23:37 --> Utf8 Class Initialized
INFO - 2016-09-08 13:23:37 --> URI Class Initialized
INFO - 2016-09-08 13:23:37 --> Router Class Initialized
INFO - 2016-09-08 13:23:37 --> Output Class Initialized
INFO - 2016-09-08 13:23:37 --> Security Class Initialized
DEBUG - 2016-09-08 13:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:23:37 --> Input Class Initialized
INFO - 2016-09-08 13:23:37 --> Language Class Initialized
INFO - 2016-09-08 13:23:37 --> Loader Class Initialized
INFO - 2016-09-08 13:23:37 --> Helper loaded: url_helper
INFO - 2016-09-08 13:23:37 --> Helper loaded: language_helper
INFO - 2016-09-08 13:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:23:37 --> Controller Class Initialized
INFO - 2016-09-08 13:23:37 --> Database Driver Class Initialized
INFO - 2016-09-08 13:23:37 --> Model Class Initialized
INFO - 2016-09-08 13:23:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:23:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:23:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:23:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:23:37 --> Final output sent to browser
DEBUG - 2016-09-08 13:23:37 --> Total execution time: 0.0570
INFO - 2016-09-08 13:23:41 --> Config Class Initialized
INFO - 2016-09-08 13:23:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:23:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:23:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:23:41 --> URI Class Initialized
INFO - 2016-09-08 13:23:41 --> Router Class Initialized
INFO - 2016-09-08 13:23:41 --> Output Class Initialized
INFO - 2016-09-08 13:23:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:23:41 --> Input Class Initialized
INFO - 2016-09-08 13:23:41 --> Language Class Initialized
INFO - 2016-09-08 13:23:41 --> Loader Class Initialized
INFO - 2016-09-08 13:23:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:23:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:23:41 --> Controller Class Initialized
INFO - 2016-09-08 13:23:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:23:41 --> Model Class Initialized
INFO - 2016-09-08 13:23:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:23:41 --> Config Class Initialized
INFO - 2016-09-08 13:23:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:23:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:23:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:23:41 --> URI Class Initialized
INFO - 2016-09-08 13:23:41 --> Router Class Initialized
INFO - 2016-09-08 13:23:41 --> Output Class Initialized
INFO - 2016-09-08 13:23:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:23:41 --> Input Class Initialized
INFO - 2016-09-08 13:23:41 --> Language Class Initialized
INFO - 2016-09-08 13:23:41 --> Loader Class Initialized
INFO - 2016-09-08 13:23:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:23:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:23:41 --> Controller Class Initialized
INFO - 2016-09-08 13:23:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:23:41 --> Model Class Initialized
INFO - 2016-09-08 13:23:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:23:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:23:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:23:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:23:41 --> Final output sent to browser
DEBUG - 2016-09-08 13:23:41 --> Total execution time: 0.0578
INFO - 2016-09-08 13:24:16 --> Config Class Initialized
INFO - 2016-09-08 13:24:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:24:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:24:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:24:16 --> URI Class Initialized
INFO - 2016-09-08 13:24:16 --> Router Class Initialized
INFO - 2016-09-08 13:24:16 --> Output Class Initialized
INFO - 2016-09-08 13:24:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:24:16 --> Input Class Initialized
INFO - 2016-09-08 13:24:16 --> Language Class Initialized
INFO - 2016-09-08 13:24:16 --> Loader Class Initialized
INFO - 2016-09-08 13:24:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:24:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:24:16 --> Controller Class Initialized
INFO - 2016-09-08 13:24:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:24:16 --> Model Class Initialized
INFO - 2016-09-08 13:24:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:24:17 --> Config Class Initialized
INFO - 2016-09-08 13:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:24:17 --> Utf8 Class Initialized
INFO - 2016-09-08 13:24:17 --> URI Class Initialized
INFO - 2016-09-08 13:24:17 --> Router Class Initialized
INFO - 2016-09-08 13:24:17 --> Output Class Initialized
INFO - 2016-09-08 13:24:17 --> Security Class Initialized
DEBUG - 2016-09-08 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:24:17 --> Input Class Initialized
INFO - 2016-09-08 13:24:17 --> Language Class Initialized
INFO - 2016-09-08 13:24:17 --> Loader Class Initialized
INFO - 2016-09-08 13:24:17 --> Helper loaded: url_helper
INFO - 2016-09-08 13:24:17 --> Helper loaded: language_helper
INFO - 2016-09-08 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:24:17 --> Controller Class Initialized
INFO - 2016-09-08 13:24:17 --> Database Driver Class Initialized
INFO - 2016-09-08 13:24:17 --> Model Class Initialized
INFO - 2016-09-08 13:24:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:24:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:24:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:24:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:24:17 --> Final output sent to browser
DEBUG - 2016-09-08 13:24:17 --> Total execution time: 0.0619
INFO - 2016-09-08 13:25:29 --> Config Class Initialized
INFO - 2016-09-08 13:25:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:25:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:25:29 --> Utf8 Class Initialized
INFO - 2016-09-08 13:25:29 --> URI Class Initialized
INFO - 2016-09-08 13:25:29 --> Router Class Initialized
INFO - 2016-09-08 13:25:29 --> Output Class Initialized
INFO - 2016-09-08 13:25:29 --> Security Class Initialized
DEBUG - 2016-09-08 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:25:29 --> Input Class Initialized
INFO - 2016-09-08 13:25:29 --> Language Class Initialized
INFO - 2016-09-08 13:25:29 --> Loader Class Initialized
INFO - 2016-09-08 13:25:29 --> Helper loaded: url_helper
INFO - 2016-09-08 13:25:29 --> Helper loaded: language_helper
INFO - 2016-09-08 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:25:29 --> Controller Class Initialized
INFO - 2016-09-08 13:25:29 --> Database Driver Class Initialized
INFO - 2016-09-08 13:25:29 --> Model Class Initialized
INFO - 2016-09-08 13:25:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:25:29 --> Config Class Initialized
INFO - 2016-09-08 13:25:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:25:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:25:29 --> Utf8 Class Initialized
INFO - 2016-09-08 13:25:29 --> URI Class Initialized
INFO - 2016-09-08 13:25:29 --> Router Class Initialized
INFO - 2016-09-08 13:25:29 --> Output Class Initialized
INFO - 2016-09-08 13:25:29 --> Security Class Initialized
DEBUG - 2016-09-08 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:25:29 --> Input Class Initialized
INFO - 2016-09-08 13:25:29 --> Language Class Initialized
INFO - 2016-09-08 13:25:29 --> Loader Class Initialized
INFO - 2016-09-08 13:25:29 --> Helper loaded: url_helper
INFO - 2016-09-08 13:25:29 --> Helper loaded: language_helper
INFO - 2016-09-08 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:25:29 --> Controller Class Initialized
INFO - 2016-09-08 13:25:29 --> Database Driver Class Initialized
INFO - 2016-09-08 13:25:29 --> Model Class Initialized
INFO - 2016-09-08 13:25:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:25:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:25:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:25:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:25:29 --> Final output sent to browser
DEBUG - 2016-09-08 13:25:29 --> Total execution time: 0.0576
INFO - 2016-09-08 13:26:52 --> Config Class Initialized
INFO - 2016-09-08 13:26:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:26:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:26:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:26:52 --> URI Class Initialized
INFO - 2016-09-08 13:26:52 --> Router Class Initialized
INFO - 2016-09-08 13:26:52 --> Output Class Initialized
INFO - 2016-09-08 13:26:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:26:52 --> Input Class Initialized
INFO - 2016-09-08 13:26:52 --> Language Class Initialized
INFO - 2016-09-08 13:26:52 --> Loader Class Initialized
INFO - 2016-09-08 13:26:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:26:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:26:52 --> Controller Class Initialized
INFO - 2016-09-08 13:26:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:26:52 --> Model Class Initialized
INFO - 2016-09-08 13:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:26:52 --> Config Class Initialized
INFO - 2016-09-08 13:26:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:26:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:26:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:26:52 --> URI Class Initialized
INFO - 2016-09-08 13:26:52 --> Router Class Initialized
INFO - 2016-09-08 13:26:52 --> Output Class Initialized
INFO - 2016-09-08 13:26:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:26:52 --> Input Class Initialized
INFO - 2016-09-08 13:26:52 --> Language Class Initialized
INFO - 2016-09-08 13:26:52 --> Loader Class Initialized
INFO - 2016-09-08 13:26:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:26:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:26:52 --> Controller Class Initialized
INFO - 2016-09-08 13:26:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:26:52 --> Model Class Initialized
INFO - 2016-09-08 13:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:26:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:26:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:26:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:26:52 --> Final output sent to browser
DEBUG - 2016-09-08 13:26:52 --> Total execution time: 0.0580
INFO - 2016-09-08 13:26:55 --> Config Class Initialized
INFO - 2016-09-08 13:26:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:26:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:26:55 --> Utf8 Class Initialized
INFO - 2016-09-08 13:26:55 --> URI Class Initialized
INFO - 2016-09-08 13:26:55 --> Router Class Initialized
INFO - 2016-09-08 13:26:55 --> Output Class Initialized
INFO - 2016-09-08 13:26:55 --> Security Class Initialized
DEBUG - 2016-09-08 13:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:26:55 --> Input Class Initialized
INFO - 2016-09-08 13:26:55 --> Language Class Initialized
INFO - 2016-09-08 13:26:55 --> Loader Class Initialized
INFO - 2016-09-08 13:26:55 --> Helper loaded: url_helper
INFO - 2016-09-08 13:26:55 --> Helper loaded: language_helper
INFO - 2016-09-08 13:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:26:55 --> Controller Class Initialized
INFO - 2016-09-08 13:26:55 --> Database Driver Class Initialized
INFO - 2016-09-08 13:26:55 --> Model Class Initialized
INFO - 2016-09-08 13:26:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:26:55 --> Config Class Initialized
INFO - 2016-09-08 13:26:55 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:26:55 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:26:55 --> Utf8 Class Initialized
INFO - 2016-09-08 13:26:55 --> URI Class Initialized
INFO - 2016-09-08 13:26:55 --> Router Class Initialized
INFO - 2016-09-08 13:26:55 --> Output Class Initialized
INFO - 2016-09-08 13:26:55 --> Security Class Initialized
DEBUG - 2016-09-08 13:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:26:55 --> Input Class Initialized
INFO - 2016-09-08 13:26:55 --> Language Class Initialized
INFO - 2016-09-08 13:26:55 --> Loader Class Initialized
INFO - 2016-09-08 13:26:55 --> Helper loaded: url_helper
INFO - 2016-09-08 13:26:55 --> Helper loaded: language_helper
INFO - 2016-09-08 13:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:26:55 --> Controller Class Initialized
INFO - 2016-09-08 13:26:55 --> Database Driver Class Initialized
INFO - 2016-09-08 13:26:55 --> Model Class Initialized
INFO - 2016-09-08 13:26:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:26:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:26:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:26:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:26:55 --> Final output sent to browser
DEBUG - 2016-09-08 13:26:55 --> Total execution time: 0.0614
INFO - 2016-09-08 13:27:33 --> Config Class Initialized
INFO - 2016-09-08 13:27:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:33 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:33 --> URI Class Initialized
INFO - 2016-09-08 13:27:33 --> Router Class Initialized
INFO - 2016-09-08 13:27:33 --> Output Class Initialized
INFO - 2016-09-08 13:27:33 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:33 --> Input Class Initialized
INFO - 2016-09-08 13:27:33 --> Language Class Initialized
INFO - 2016-09-08 13:27:33 --> Loader Class Initialized
INFO - 2016-09-08 13:27:33 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:33 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:33 --> Controller Class Initialized
INFO - 2016-09-08 13:27:33 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:33 --> Model Class Initialized
INFO - 2016-09-08 13:27:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:33 --> Config Class Initialized
INFO - 2016-09-08 13:27:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:33 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:33 --> URI Class Initialized
INFO - 2016-09-08 13:27:33 --> Router Class Initialized
INFO - 2016-09-08 13:27:33 --> Output Class Initialized
INFO - 2016-09-08 13:27:33 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:33 --> Input Class Initialized
INFO - 2016-09-08 13:27:33 --> Language Class Initialized
INFO - 2016-09-08 13:27:33 --> Loader Class Initialized
INFO - 2016-09-08 13:27:33 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:33 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:33 --> Controller Class Initialized
INFO - 2016-09-08 13:27:33 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:33 --> Model Class Initialized
INFO - 2016-09-08 13:27:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:27:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:27:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:27:33 --> Final output sent to browser
DEBUG - 2016-09-08 13:27:33 --> Total execution time: 0.0560
INFO - 2016-09-08 13:27:35 --> Config Class Initialized
INFO - 2016-09-08 13:27:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:35 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:35 --> URI Class Initialized
INFO - 2016-09-08 13:27:35 --> Router Class Initialized
INFO - 2016-09-08 13:27:35 --> Output Class Initialized
INFO - 2016-09-08 13:27:35 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:35 --> Input Class Initialized
INFO - 2016-09-08 13:27:35 --> Language Class Initialized
INFO - 2016-09-08 13:27:35 --> Loader Class Initialized
INFO - 2016-09-08 13:27:35 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:35 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:35 --> Controller Class Initialized
INFO - 2016-09-08 13:27:35 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:35 --> Model Class Initialized
INFO - 2016-09-08 13:27:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:35 --> Config Class Initialized
INFO - 2016-09-08 13:27:35 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:35 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:35 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:35 --> URI Class Initialized
INFO - 2016-09-08 13:27:35 --> Router Class Initialized
INFO - 2016-09-08 13:27:35 --> Output Class Initialized
INFO - 2016-09-08 13:27:35 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:35 --> Input Class Initialized
INFO - 2016-09-08 13:27:35 --> Language Class Initialized
INFO - 2016-09-08 13:27:35 --> Loader Class Initialized
INFO - 2016-09-08 13:27:35 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:35 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:35 --> Controller Class Initialized
INFO - 2016-09-08 13:27:35 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:35 --> Model Class Initialized
INFO - 2016-09-08 13:27:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:27:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:27:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:27:35 --> Final output sent to browser
DEBUG - 2016-09-08 13:27:35 --> Total execution time: 0.0747
INFO - 2016-09-08 13:27:57 --> Config Class Initialized
INFO - 2016-09-08 13:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:57 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:57 --> URI Class Initialized
INFO - 2016-09-08 13:27:57 --> Router Class Initialized
INFO - 2016-09-08 13:27:57 --> Output Class Initialized
INFO - 2016-09-08 13:27:57 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:57 --> Input Class Initialized
INFO - 2016-09-08 13:27:57 --> Language Class Initialized
INFO - 2016-09-08 13:27:57 --> Loader Class Initialized
INFO - 2016-09-08 13:27:57 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:57 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:57 --> Controller Class Initialized
INFO - 2016-09-08 13:27:57 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:57 --> Model Class Initialized
INFO - 2016-09-08 13:27:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:57 --> Config Class Initialized
INFO - 2016-09-08 13:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:57 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:57 --> URI Class Initialized
INFO - 2016-09-08 13:27:57 --> Router Class Initialized
INFO - 2016-09-08 13:27:57 --> Output Class Initialized
INFO - 2016-09-08 13:27:57 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:57 --> Input Class Initialized
INFO - 2016-09-08 13:27:57 --> Language Class Initialized
INFO - 2016-09-08 13:27:57 --> Loader Class Initialized
INFO - 2016-09-08 13:27:57 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:57 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:57 --> Controller Class Initialized
INFO - 2016-09-08 13:27:57 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:57 --> Model Class Initialized
INFO - 2016-09-08 13:27:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:27:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:27:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:27:57 --> Final output sent to browser
DEBUG - 2016-09-08 13:27:57 --> Total execution time: 0.0733
INFO - 2016-09-08 13:27:58 --> Config Class Initialized
INFO - 2016-09-08 13:27:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:58 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:58 --> URI Class Initialized
INFO - 2016-09-08 13:27:58 --> Router Class Initialized
INFO - 2016-09-08 13:27:58 --> Output Class Initialized
INFO - 2016-09-08 13:27:58 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:58 --> Input Class Initialized
INFO - 2016-09-08 13:27:58 --> Language Class Initialized
INFO - 2016-09-08 13:27:58 --> Loader Class Initialized
INFO - 2016-09-08 13:27:58 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:58 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:58 --> Controller Class Initialized
INFO - 2016-09-08 13:27:58 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:59 --> Model Class Initialized
INFO - 2016-09-08 13:27:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:59 --> Config Class Initialized
INFO - 2016-09-08 13:27:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:27:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:27:59 --> Utf8 Class Initialized
INFO - 2016-09-08 13:27:59 --> URI Class Initialized
INFO - 2016-09-08 13:27:59 --> Router Class Initialized
INFO - 2016-09-08 13:27:59 --> Output Class Initialized
INFO - 2016-09-08 13:27:59 --> Security Class Initialized
DEBUG - 2016-09-08 13:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:27:59 --> Input Class Initialized
INFO - 2016-09-08 13:27:59 --> Language Class Initialized
INFO - 2016-09-08 13:27:59 --> Loader Class Initialized
INFO - 2016-09-08 13:27:59 --> Helper loaded: url_helper
INFO - 2016-09-08 13:27:59 --> Helper loaded: language_helper
INFO - 2016-09-08 13:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:27:59 --> Controller Class Initialized
INFO - 2016-09-08 13:27:59 --> Database Driver Class Initialized
INFO - 2016-09-08 13:27:59 --> Model Class Initialized
INFO - 2016-09-08 13:27:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:27:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:27:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:27:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:27:59 --> Final output sent to browser
DEBUG - 2016-09-08 13:27:59 --> Total execution time: 0.0707
INFO - 2016-09-08 13:28:39 --> Config Class Initialized
INFO - 2016-09-08 13:28:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:28:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:28:39 --> Utf8 Class Initialized
INFO - 2016-09-08 13:28:39 --> URI Class Initialized
INFO - 2016-09-08 13:28:39 --> Router Class Initialized
INFO - 2016-09-08 13:28:39 --> Output Class Initialized
INFO - 2016-09-08 13:28:39 --> Security Class Initialized
DEBUG - 2016-09-08 13:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:28:39 --> Input Class Initialized
INFO - 2016-09-08 13:28:39 --> Language Class Initialized
INFO - 2016-09-08 13:28:39 --> Loader Class Initialized
INFO - 2016-09-08 13:28:39 --> Helper loaded: url_helper
INFO - 2016-09-08 13:28:39 --> Helper loaded: language_helper
INFO - 2016-09-08 13:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:28:39 --> Controller Class Initialized
INFO - 2016-09-08 13:28:39 --> Database Driver Class Initialized
INFO - 2016-09-08 13:28:39 --> Model Class Initialized
INFO - 2016-09-08 13:28:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:28:39 --> Config Class Initialized
INFO - 2016-09-08 13:28:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:28:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:28:39 --> Utf8 Class Initialized
INFO - 2016-09-08 13:28:39 --> URI Class Initialized
INFO - 2016-09-08 13:28:39 --> Router Class Initialized
INFO - 2016-09-08 13:28:39 --> Output Class Initialized
INFO - 2016-09-08 13:28:39 --> Security Class Initialized
DEBUG - 2016-09-08 13:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:28:39 --> Input Class Initialized
INFO - 2016-09-08 13:28:39 --> Language Class Initialized
INFO - 2016-09-08 13:28:39 --> Loader Class Initialized
INFO - 2016-09-08 13:28:39 --> Helper loaded: url_helper
INFO - 2016-09-08 13:28:39 --> Helper loaded: language_helper
INFO - 2016-09-08 13:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:28:39 --> Controller Class Initialized
INFO - 2016-09-08 13:28:39 --> Database Driver Class Initialized
INFO - 2016-09-08 13:28:39 --> Model Class Initialized
INFO - 2016-09-08 13:28:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:28:39 --> Final output sent to browser
DEBUG - 2016-09-08 13:28:39 --> Total execution time: 0.0529
INFO - 2016-09-08 13:28:41 --> Config Class Initialized
INFO - 2016-09-08 13:28:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:28:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:28:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:28:41 --> URI Class Initialized
INFO - 2016-09-08 13:28:41 --> Router Class Initialized
INFO - 2016-09-08 13:28:41 --> Output Class Initialized
INFO - 2016-09-08 13:28:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:28:41 --> Input Class Initialized
INFO - 2016-09-08 13:28:41 --> Language Class Initialized
INFO - 2016-09-08 13:28:41 --> Loader Class Initialized
INFO - 2016-09-08 13:28:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:28:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:28:41 --> Controller Class Initialized
INFO - 2016-09-08 13:28:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:28:41 --> Model Class Initialized
INFO - 2016-09-08 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:28:41 --> Config Class Initialized
INFO - 2016-09-08 13:28:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:28:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:28:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:28:41 --> URI Class Initialized
INFO - 2016-09-08 13:28:41 --> Router Class Initialized
INFO - 2016-09-08 13:28:41 --> Output Class Initialized
INFO - 2016-09-08 13:28:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:28:41 --> Input Class Initialized
INFO - 2016-09-08 13:28:41 --> Language Class Initialized
INFO - 2016-09-08 13:28:41 --> Loader Class Initialized
INFO - 2016-09-08 13:28:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:28:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:28:41 --> Controller Class Initialized
INFO - 2016-09-08 13:28:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:28:41 --> Model Class Initialized
INFO - 2016-09-08 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:28:41 --> Final output sent to browser
DEBUG - 2016-09-08 13:28:41 --> Total execution time: 0.0663
INFO - 2016-09-08 13:29:08 --> Config Class Initialized
INFO - 2016-09-08 13:29:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:29:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:29:08 --> Utf8 Class Initialized
INFO - 2016-09-08 13:29:08 --> URI Class Initialized
INFO - 2016-09-08 13:29:08 --> Router Class Initialized
INFO - 2016-09-08 13:29:08 --> Output Class Initialized
INFO - 2016-09-08 13:29:08 --> Security Class Initialized
DEBUG - 2016-09-08 13:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:29:08 --> Input Class Initialized
INFO - 2016-09-08 13:29:08 --> Language Class Initialized
INFO - 2016-09-08 13:29:08 --> Loader Class Initialized
INFO - 2016-09-08 13:29:08 --> Helper loaded: url_helper
INFO - 2016-09-08 13:29:08 --> Helper loaded: language_helper
INFO - 2016-09-08 13:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:29:08 --> Controller Class Initialized
INFO - 2016-09-08 13:29:08 --> Database Driver Class Initialized
INFO - 2016-09-08 13:29:08 --> Model Class Initialized
INFO - 2016-09-08 13:29:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:29:08 --> Config Class Initialized
INFO - 2016-09-08 13:29:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:29:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:29:08 --> Utf8 Class Initialized
INFO - 2016-09-08 13:29:08 --> URI Class Initialized
INFO - 2016-09-08 13:29:08 --> Router Class Initialized
INFO - 2016-09-08 13:29:08 --> Output Class Initialized
INFO - 2016-09-08 13:29:08 --> Security Class Initialized
DEBUG - 2016-09-08 13:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:29:08 --> Input Class Initialized
INFO - 2016-09-08 13:29:08 --> Language Class Initialized
INFO - 2016-09-08 13:29:08 --> Loader Class Initialized
INFO - 2016-09-08 13:29:08 --> Helper loaded: url_helper
INFO - 2016-09-08 13:29:08 --> Helper loaded: language_helper
INFO - 2016-09-08 13:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:29:08 --> Controller Class Initialized
INFO - 2016-09-08 13:29:08 --> Database Driver Class Initialized
INFO - 2016-09-08 13:29:08 --> Model Class Initialized
INFO - 2016-09-08 13:29:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:29:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:29:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:29:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:29:08 --> Final output sent to browser
DEBUG - 2016-09-08 13:29:08 --> Total execution time: 0.0706
INFO - 2016-09-08 13:29:26 --> Config Class Initialized
INFO - 2016-09-08 13:29:26 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:29:26 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:29:26 --> Utf8 Class Initialized
INFO - 2016-09-08 13:29:26 --> URI Class Initialized
INFO - 2016-09-08 13:29:26 --> Router Class Initialized
INFO - 2016-09-08 13:29:26 --> Output Class Initialized
INFO - 2016-09-08 13:29:26 --> Security Class Initialized
DEBUG - 2016-09-08 13:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:29:26 --> Input Class Initialized
INFO - 2016-09-08 13:29:26 --> Language Class Initialized
INFO - 2016-09-08 13:29:26 --> Loader Class Initialized
INFO - 2016-09-08 13:29:26 --> Helper loaded: url_helper
INFO - 2016-09-08 13:29:26 --> Helper loaded: language_helper
INFO - 2016-09-08 13:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:29:26 --> Controller Class Initialized
INFO - 2016-09-08 13:29:26 --> Database Driver Class Initialized
INFO - 2016-09-08 13:29:26 --> Model Class Initialized
INFO - 2016-09-08 13:29:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:29:26 --> Config Class Initialized
INFO - 2016-09-08 13:29:26 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:29:26 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:29:26 --> Utf8 Class Initialized
INFO - 2016-09-08 13:29:26 --> URI Class Initialized
INFO - 2016-09-08 13:29:26 --> Router Class Initialized
INFO - 2016-09-08 13:29:26 --> Output Class Initialized
INFO - 2016-09-08 13:29:26 --> Security Class Initialized
DEBUG - 2016-09-08 13:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:29:26 --> Input Class Initialized
INFO - 2016-09-08 13:29:26 --> Language Class Initialized
INFO - 2016-09-08 13:29:26 --> Loader Class Initialized
INFO - 2016-09-08 13:29:26 --> Helper loaded: url_helper
INFO - 2016-09-08 13:29:26 --> Helper loaded: language_helper
INFO - 2016-09-08 13:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:29:26 --> Controller Class Initialized
INFO - 2016-09-08 13:29:26 --> Database Driver Class Initialized
INFO - 2016-09-08 13:29:26 --> Model Class Initialized
INFO - 2016-09-08 13:29:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:29:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:29:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:29:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:29:26 --> Final output sent to browser
DEBUG - 2016-09-08 13:29:26 --> Total execution time: 0.0577
INFO - 2016-09-08 13:31:13 --> Config Class Initialized
INFO - 2016-09-08 13:31:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:31:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:31:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:31:13 --> URI Class Initialized
INFO - 2016-09-08 13:31:13 --> Router Class Initialized
INFO - 2016-09-08 13:31:13 --> Output Class Initialized
INFO - 2016-09-08 13:31:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:31:13 --> Input Class Initialized
INFO - 2016-09-08 13:31:13 --> Language Class Initialized
INFO - 2016-09-08 13:31:13 --> Loader Class Initialized
INFO - 2016-09-08 13:31:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:31:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:31:13 --> Controller Class Initialized
INFO - 2016-09-08 13:31:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:31:13 --> Model Class Initialized
INFO - 2016-09-08 13:31:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:31:13 --> Config Class Initialized
INFO - 2016-09-08 13:31:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:31:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:31:13 --> Utf8 Class Initialized
INFO - 2016-09-08 13:31:13 --> URI Class Initialized
INFO - 2016-09-08 13:31:13 --> Router Class Initialized
INFO - 2016-09-08 13:31:13 --> Output Class Initialized
INFO - 2016-09-08 13:31:13 --> Security Class Initialized
DEBUG - 2016-09-08 13:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:31:13 --> Input Class Initialized
INFO - 2016-09-08 13:31:13 --> Language Class Initialized
INFO - 2016-09-08 13:31:13 --> Loader Class Initialized
INFO - 2016-09-08 13:31:13 --> Helper loaded: url_helper
INFO - 2016-09-08 13:31:13 --> Helper loaded: language_helper
INFO - 2016-09-08 13:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:31:13 --> Controller Class Initialized
INFO - 2016-09-08 13:31:13 --> Database Driver Class Initialized
INFO - 2016-09-08 13:31:13 --> Model Class Initialized
INFO - 2016-09-08 13:31:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:31:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:31:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:31:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:31:13 --> Final output sent to browser
DEBUG - 2016-09-08 13:31:13 --> Total execution time: 0.0607
INFO - 2016-09-08 13:31:15 --> Config Class Initialized
INFO - 2016-09-08 13:31:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:31:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:31:15 --> Utf8 Class Initialized
INFO - 2016-09-08 13:31:15 --> URI Class Initialized
INFO - 2016-09-08 13:31:15 --> Router Class Initialized
INFO - 2016-09-08 13:31:15 --> Output Class Initialized
INFO - 2016-09-08 13:31:15 --> Security Class Initialized
DEBUG - 2016-09-08 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:31:15 --> Input Class Initialized
INFO - 2016-09-08 13:31:15 --> Language Class Initialized
INFO - 2016-09-08 13:31:15 --> Loader Class Initialized
INFO - 2016-09-08 13:31:15 --> Helper loaded: url_helper
INFO - 2016-09-08 13:31:15 --> Helper loaded: language_helper
INFO - 2016-09-08 13:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:31:15 --> Controller Class Initialized
INFO - 2016-09-08 13:31:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:31:15 --> Model Class Initialized
INFO - 2016-09-08 13:31:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:31:15 --> Config Class Initialized
INFO - 2016-09-08 13:31:15 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:31:15 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:31:15 --> Utf8 Class Initialized
INFO - 2016-09-08 13:31:15 --> URI Class Initialized
INFO - 2016-09-08 13:31:15 --> Router Class Initialized
INFO - 2016-09-08 13:31:15 --> Output Class Initialized
INFO - 2016-09-08 13:31:15 --> Security Class Initialized
DEBUG - 2016-09-08 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:31:15 --> Input Class Initialized
INFO - 2016-09-08 13:31:15 --> Language Class Initialized
INFO - 2016-09-08 13:31:15 --> Loader Class Initialized
INFO - 2016-09-08 13:31:15 --> Helper loaded: url_helper
INFO - 2016-09-08 13:31:15 --> Helper loaded: language_helper
INFO - 2016-09-08 13:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:31:15 --> Controller Class Initialized
INFO - 2016-09-08 13:31:15 --> Database Driver Class Initialized
INFO - 2016-09-08 13:31:15 --> Model Class Initialized
INFO - 2016-09-08 13:31:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:31:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:31:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:31:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:31:15 --> Final output sent to browser
DEBUG - 2016-09-08 13:31:15 --> Total execution time: 0.0736
INFO - 2016-09-08 13:31:58 --> Config Class Initialized
INFO - 2016-09-08 13:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:31:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:31:58 --> Utf8 Class Initialized
INFO - 2016-09-08 13:31:58 --> URI Class Initialized
INFO - 2016-09-08 13:31:58 --> Router Class Initialized
INFO - 2016-09-08 13:31:58 --> Output Class Initialized
INFO - 2016-09-08 13:31:58 --> Security Class Initialized
DEBUG - 2016-09-08 13:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:31:58 --> Input Class Initialized
INFO - 2016-09-08 13:31:58 --> Language Class Initialized
INFO - 2016-09-08 13:31:58 --> Loader Class Initialized
INFO - 2016-09-08 13:31:58 --> Helper loaded: url_helper
INFO - 2016-09-08 13:31:58 --> Helper loaded: language_helper
INFO - 2016-09-08 13:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:31:58 --> Controller Class Initialized
INFO - 2016-09-08 13:31:58 --> Database Driver Class Initialized
INFO - 2016-09-08 13:31:58 --> Model Class Initialized
INFO - 2016-09-08 13:31:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:31:58 --> Config Class Initialized
INFO - 2016-09-08 13:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:31:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:31:58 --> Utf8 Class Initialized
INFO - 2016-09-08 13:31:58 --> URI Class Initialized
INFO - 2016-09-08 13:31:58 --> Router Class Initialized
INFO - 2016-09-08 13:31:58 --> Output Class Initialized
INFO - 2016-09-08 13:31:58 --> Security Class Initialized
DEBUG - 2016-09-08 13:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:31:58 --> Input Class Initialized
INFO - 2016-09-08 13:31:58 --> Language Class Initialized
INFO - 2016-09-08 13:31:58 --> Loader Class Initialized
INFO - 2016-09-08 13:31:58 --> Helper loaded: url_helper
INFO - 2016-09-08 13:31:58 --> Helper loaded: language_helper
INFO - 2016-09-08 13:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:31:58 --> Controller Class Initialized
INFO - 2016-09-08 13:31:58 --> Database Driver Class Initialized
INFO - 2016-09-08 13:31:58 --> Model Class Initialized
INFO - 2016-09-08 13:31:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:31:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:31:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:31:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:31:58 --> Final output sent to browser
DEBUG - 2016-09-08 13:31:58 --> Total execution time: 0.0632
INFO - 2016-09-08 13:32:01 --> Config Class Initialized
INFO - 2016-09-08 13:32:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:32:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:32:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:32:01 --> URI Class Initialized
INFO - 2016-09-08 13:32:01 --> Router Class Initialized
INFO - 2016-09-08 13:32:01 --> Output Class Initialized
INFO - 2016-09-08 13:32:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:32:01 --> Input Class Initialized
INFO - 2016-09-08 13:32:01 --> Language Class Initialized
INFO - 2016-09-08 13:32:01 --> Loader Class Initialized
INFO - 2016-09-08 13:32:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:32:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:32:01 --> Controller Class Initialized
INFO - 2016-09-08 13:32:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:32:01 --> Model Class Initialized
INFO - 2016-09-08 13:32:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:32:01 --> Config Class Initialized
INFO - 2016-09-08 13:32:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:32:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:32:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:32:01 --> URI Class Initialized
INFO - 2016-09-08 13:32:01 --> Router Class Initialized
INFO - 2016-09-08 13:32:01 --> Output Class Initialized
INFO - 2016-09-08 13:32:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:32:01 --> Input Class Initialized
INFO - 2016-09-08 13:32:01 --> Language Class Initialized
INFO - 2016-09-08 13:32:01 --> Loader Class Initialized
INFO - 2016-09-08 13:32:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:32:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:32:01 --> Controller Class Initialized
INFO - 2016-09-08 13:32:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:32:01 --> Model Class Initialized
INFO - 2016-09-08 13:32:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:32:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:32:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:32:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:32:01 --> Final output sent to browser
DEBUG - 2016-09-08 13:32:01 --> Total execution time: 0.0614
INFO - 2016-09-08 13:32:41 --> Config Class Initialized
INFO - 2016-09-08 13:32:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:32:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:32:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:32:41 --> URI Class Initialized
INFO - 2016-09-08 13:32:41 --> Router Class Initialized
INFO - 2016-09-08 13:32:41 --> Output Class Initialized
INFO - 2016-09-08 13:32:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:32:41 --> Input Class Initialized
INFO - 2016-09-08 13:32:41 --> Language Class Initialized
INFO - 2016-09-08 13:32:41 --> Loader Class Initialized
INFO - 2016-09-08 13:32:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:32:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:32:41 --> Controller Class Initialized
INFO - 2016-09-08 13:32:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:32:41 --> Model Class Initialized
INFO - 2016-09-08 13:32:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:32:41 --> Config Class Initialized
INFO - 2016-09-08 13:32:41 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:32:41 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:32:41 --> Utf8 Class Initialized
INFO - 2016-09-08 13:32:41 --> URI Class Initialized
INFO - 2016-09-08 13:32:41 --> Router Class Initialized
INFO - 2016-09-08 13:32:41 --> Output Class Initialized
INFO - 2016-09-08 13:32:41 --> Security Class Initialized
DEBUG - 2016-09-08 13:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:32:41 --> Input Class Initialized
INFO - 2016-09-08 13:32:41 --> Language Class Initialized
INFO - 2016-09-08 13:32:41 --> Loader Class Initialized
INFO - 2016-09-08 13:32:41 --> Helper loaded: url_helper
INFO - 2016-09-08 13:32:41 --> Helper loaded: language_helper
INFO - 2016-09-08 13:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:32:41 --> Controller Class Initialized
INFO - 2016-09-08 13:32:41 --> Database Driver Class Initialized
INFO - 2016-09-08 13:32:41 --> Model Class Initialized
INFO - 2016-09-08 13:32:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:32:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:32:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:32:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:32:41 --> Final output sent to browser
DEBUG - 2016-09-08 13:32:41 --> Total execution time: 0.0552
INFO - 2016-09-08 13:32:43 --> Config Class Initialized
INFO - 2016-09-08 13:32:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:32:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:32:43 --> Utf8 Class Initialized
INFO - 2016-09-08 13:32:43 --> URI Class Initialized
INFO - 2016-09-08 13:32:43 --> Router Class Initialized
INFO - 2016-09-08 13:32:43 --> Output Class Initialized
INFO - 2016-09-08 13:32:43 --> Security Class Initialized
DEBUG - 2016-09-08 13:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:32:43 --> Input Class Initialized
INFO - 2016-09-08 13:32:43 --> Language Class Initialized
INFO - 2016-09-08 13:32:43 --> Loader Class Initialized
INFO - 2016-09-08 13:32:43 --> Helper loaded: url_helper
INFO - 2016-09-08 13:32:43 --> Helper loaded: language_helper
INFO - 2016-09-08 13:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:32:43 --> Controller Class Initialized
INFO - 2016-09-08 13:32:43 --> Database Driver Class Initialized
INFO - 2016-09-08 13:32:43 --> Model Class Initialized
INFO - 2016-09-08 13:32:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:32:43 --> Config Class Initialized
INFO - 2016-09-08 13:32:43 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:32:43 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:32:43 --> Utf8 Class Initialized
INFO - 2016-09-08 13:32:43 --> URI Class Initialized
INFO - 2016-09-08 13:32:43 --> Router Class Initialized
INFO - 2016-09-08 13:32:43 --> Output Class Initialized
INFO - 2016-09-08 13:32:43 --> Security Class Initialized
DEBUG - 2016-09-08 13:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:32:43 --> Input Class Initialized
INFO - 2016-09-08 13:32:43 --> Language Class Initialized
INFO - 2016-09-08 13:32:43 --> Loader Class Initialized
INFO - 2016-09-08 13:32:43 --> Helper loaded: url_helper
INFO - 2016-09-08 13:32:43 --> Helper loaded: language_helper
INFO - 2016-09-08 13:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:32:43 --> Controller Class Initialized
INFO - 2016-09-08 13:32:43 --> Database Driver Class Initialized
INFO - 2016-09-08 13:32:43 --> Model Class Initialized
INFO - 2016-09-08 13:32:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:32:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:32:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:32:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:32:43 --> Final output sent to browser
DEBUG - 2016-09-08 13:32:43 --> Total execution time: 0.0679
INFO - 2016-09-08 13:33:27 --> Config Class Initialized
INFO - 2016-09-08 13:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:33:27 --> Utf8 Class Initialized
INFO - 2016-09-08 13:33:27 --> URI Class Initialized
INFO - 2016-09-08 13:33:28 --> Router Class Initialized
INFO - 2016-09-08 13:33:28 --> Output Class Initialized
INFO - 2016-09-08 13:33:28 --> Security Class Initialized
DEBUG - 2016-09-08 13:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:33:28 --> Input Class Initialized
INFO - 2016-09-08 13:33:28 --> Language Class Initialized
INFO - 2016-09-08 13:33:28 --> Loader Class Initialized
INFO - 2016-09-08 13:33:28 --> Helper loaded: url_helper
INFO - 2016-09-08 13:33:28 --> Helper loaded: language_helper
INFO - 2016-09-08 13:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:33:28 --> Controller Class Initialized
INFO - 2016-09-08 13:33:28 --> Database Driver Class Initialized
INFO - 2016-09-08 13:33:28 --> Model Class Initialized
INFO - 2016-09-08 13:33:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:33:28 --> Config Class Initialized
INFO - 2016-09-08 13:33:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:33:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:33:28 --> Utf8 Class Initialized
INFO - 2016-09-08 13:33:28 --> URI Class Initialized
INFO - 2016-09-08 13:33:28 --> Router Class Initialized
INFO - 2016-09-08 13:33:28 --> Output Class Initialized
INFO - 2016-09-08 13:33:28 --> Security Class Initialized
DEBUG - 2016-09-08 13:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:33:28 --> Input Class Initialized
INFO - 2016-09-08 13:33:28 --> Language Class Initialized
INFO - 2016-09-08 13:33:28 --> Loader Class Initialized
INFO - 2016-09-08 13:33:28 --> Helper loaded: url_helper
INFO - 2016-09-08 13:33:28 --> Helper loaded: language_helper
INFO - 2016-09-08 13:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:33:28 --> Controller Class Initialized
INFO - 2016-09-08 13:33:28 --> Database Driver Class Initialized
INFO - 2016-09-08 13:33:28 --> Model Class Initialized
INFO - 2016-09-08 13:33:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:33:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:33:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:33:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:33:28 --> Final output sent to browser
DEBUG - 2016-09-08 13:33:28 --> Total execution time: 0.0789
INFO - 2016-09-08 13:33:29 --> Config Class Initialized
INFO - 2016-09-08 13:33:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:33:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:33:29 --> Utf8 Class Initialized
INFO - 2016-09-08 13:33:29 --> URI Class Initialized
INFO - 2016-09-08 13:33:29 --> Router Class Initialized
INFO - 2016-09-08 13:33:29 --> Output Class Initialized
INFO - 2016-09-08 13:33:29 --> Security Class Initialized
DEBUG - 2016-09-08 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:33:29 --> Input Class Initialized
INFO - 2016-09-08 13:33:29 --> Language Class Initialized
INFO - 2016-09-08 13:33:29 --> Loader Class Initialized
INFO - 2016-09-08 13:33:29 --> Helper loaded: url_helper
INFO - 2016-09-08 13:33:29 --> Helper loaded: language_helper
INFO - 2016-09-08 13:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:33:29 --> Controller Class Initialized
INFO - 2016-09-08 13:33:29 --> Database Driver Class Initialized
INFO - 2016-09-08 13:33:29 --> Model Class Initialized
INFO - 2016-09-08 13:33:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:33:29 --> Config Class Initialized
INFO - 2016-09-08 13:33:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:33:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:33:29 --> Utf8 Class Initialized
INFO - 2016-09-08 13:33:29 --> URI Class Initialized
INFO - 2016-09-08 13:33:29 --> Router Class Initialized
INFO - 2016-09-08 13:33:29 --> Output Class Initialized
INFO - 2016-09-08 13:33:29 --> Security Class Initialized
DEBUG - 2016-09-08 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:33:29 --> Input Class Initialized
INFO - 2016-09-08 13:33:29 --> Language Class Initialized
INFO - 2016-09-08 13:33:29 --> Loader Class Initialized
INFO - 2016-09-08 13:33:29 --> Helper loaded: url_helper
INFO - 2016-09-08 13:33:29 --> Helper loaded: language_helper
INFO - 2016-09-08 13:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:33:29 --> Controller Class Initialized
INFO - 2016-09-08 13:33:29 --> Database Driver Class Initialized
INFO - 2016-09-08 13:33:29 --> Model Class Initialized
INFO - 2016-09-08 13:33:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:33:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:33:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-08 13:33:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:33:29 --> Final output sent to browser
DEBUG - 2016-09-08 13:33:29 --> Total execution time: 0.0784
INFO - 2016-09-08 13:34:22 --> Config Class Initialized
INFO - 2016-09-08 13:34:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:34:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:34:22 --> Utf8 Class Initialized
INFO - 2016-09-08 13:34:22 --> URI Class Initialized
INFO - 2016-09-08 13:34:22 --> Router Class Initialized
INFO - 2016-09-08 13:34:22 --> Output Class Initialized
INFO - 2016-09-08 13:34:22 --> Security Class Initialized
DEBUG - 2016-09-08 13:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:34:22 --> Input Class Initialized
INFO - 2016-09-08 13:34:22 --> Language Class Initialized
INFO - 2016-09-08 13:34:22 --> Loader Class Initialized
INFO - 2016-09-08 13:34:22 --> Helper loaded: url_helper
INFO - 2016-09-08 13:34:22 --> Helper loaded: language_helper
INFO - 2016-09-08 13:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:34:22 --> Controller Class Initialized
INFO - 2016-09-08 13:34:22 --> Database Driver Class Initialized
INFO - 2016-09-08 13:34:22 --> Model Class Initialized
INFO - 2016-09-08 13:34:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:34:22 --> Config Class Initialized
INFO - 2016-09-08 13:34:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:34:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:34:22 --> Utf8 Class Initialized
INFO - 2016-09-08 13:34:22 --> URI Class Initialized
INFO - 2016-09-08 13:34:22 --> Router Class Initialized
INFO - 2016-09-08 13:34:22 --> Output Class Initialized
INFO - 2016-09-08 13:34:22 --> Security Class Initialized
DEBUG - 2016-09-08 13:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:34:22 --> Input Class Initialized
INFO - 2016-09-08 13:34:22 --> Language Class Initialized
INFO - 2016-09-08 13:34:22 --> Loader Class Initialized
INFO - 2016-09-08 13:34:22 --> Helper loaded: url_helper
INFO - 2016-09-08 13:34:22 --> Helper loaded: language_helper
INFO - 2016-09-08 13:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:34:22 --> Controller Class Initialized
INFO - 2016-09-08 13:34:22 --> Database Driver Class Initialized
INFO - 2016-09-08 13:34:22 --> Model Class Initialized
INFO - 2016-09-08 13:34:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:34:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:34:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:34:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:34:22 --> Final output sent to browser
DEBUG - 2016-09-08 13:34:22 --> Total execution time: 0.0552
INFO - 2016-09-08 13:34:44 --> Config Class Initialized
INFO - 2016-09-08 13:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:34:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:34:44 --> Utf8 Class Initialized
INFO - 2016-09-08 13:34:44 --> URI Class Initialized
INFO - 2016-09-08 13:34:44 --> Router Class Initialized
INFO - 2016-09-08 13:34:44 --> Output Class Initialized
INFO - 2016-09-08 13:34:44 --> Security Class Initialized
DEBUG - 2016-09-08 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:34:44 --> Input Class Initialized
INFO - 2016-09-08 13:34:44 --> Language Class Initialized
INFO - 2016-09-08 13:34:44 --> Loader Class Initialized
INFO - 2016-09-08 13:34:44 --> Helper loaded: url_helper
INFO - 2016-09-08 13:34:44 --> Helper loaded: language_helper
INFO - 2016-09-08 13:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:34:44 --> Controller Class Initialized
INFO - 2016-09-08 13:34:44 --> Database Driver Class Initialized
INFO - 2016-09-08 13:34:44 --> Model Class Initialized
INFO - 2016-09-08 13:34:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:34:44 --> Config Class Initialized
INFO - 2016-09-08 13:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:34:44 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:34:44 --> Utf8 Class Initialized
INFO - 2016-09-08 13:34:44 --> URI Class Initialized
INFO - 2016-09-08 13:34:44 --> Router Class Initialized
INFO - 2016-09-08 13:34:44 --> Output Class Initialized
INFO - 2016-09-08 13:34:44 --> Security Class Initialized
DEBUG - 2016-09-08 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:34:44 --> Input Class Initialized
INFO - 2016-09-08 13:34:44 --> Language Class Initialized
INFO - 2016-09-08 13:34:44 --> Loader Class Initialized
INFO - 2016-09-08 13:34:44 --> Helper loaded: url_helper
INFO - 2016-09-08 13:34:44 --> Helper loaded: language_helper
INFO - 2016-09-08 13:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:34:44 --> Controller Class Initialized
INFO - 2016-09-08 13:34:44 --> Database Driver Class Initialized
INFO - 2016-09-08 13:34:44 --> Model Class Initialized
INFO - 2016-09-08 13:34:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:34:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:34:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:34:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:34:44 --> Final output sent to browser
DEBUG - 2016-09-08 13:34:44 --> Total execution time: 0.0612
INFO - 2016-09-08 13:35:31 --> Config Class Initialized
INFO - 2016-09-08 13:35:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:31 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:31 --> URI Class Initialized
INFO - 2016-09-08 13:35:31 --> Router Class Initialized
INFO - 2016-09-08 13:35:31 --> Output Class Initialized
INFO - 2016-09-08 13:35:31 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:31 --> Input Class Initialized
INFO - 2016-09-08 13:35:31 --> Language Class Initialized
INFO - 2016-09-08 13:35:31 --> Loader Class Initialized
INFO - 2016-09-08 13:35:31 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:31 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:31 --> Controller Class Initialized
INFO - 2016-09-08 13:35:31 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:31 --> Model Class Initialized
INFO - 2016-09-08 13:35:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:31 --> Config Class Initialized
INFO - 2016-09-08 13:35:31 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:31 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:31 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:31 --> URI Class Initialized
INFO - 2016-09-08 13:35:31 --> Router Class Initialized
INFO - 2016-09-08 13:35:31 --> Output Class Initialized
INFO - 2016-09-08 13:35:31 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:31 --> Input Class Initialized
INFO - 2016-09-08 13:35:31 --> Language Class Initialized
INFO - 2016-09-08 13:35:31 --> Loader Class Initialized
INFO - 2016-09-08 13:35:31 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:31 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:31 --> Controller Class Initialized
INFO - 2016-09-08 13:35:31 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:31 --> Model Class Initialized
INFO - 2016-09-08 13:35:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:35:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:35:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:35:31 --> Final output sent to browser
DEBUG - 2016-09-08 13:35:31 --> Total execution time: 0.0586
INFO - 2016-09-08 13:35:36 --> Config Class Initialized
INFO - 2016-09-08 13:35:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:36 --> URI Class Initialized
INFO - 2016-09-08 13:35:36 --> Router Class Initialized
INFO - 2016-09-08 13:35:36 --> Output Class Initialized
INFO - 2016-09-08 13:35:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:36 --> Input Class Initialized
INFO - 2016-09-08 13:35:36 --> Language Class Initialized
INFO - 2016-09-08 13:35:36 --> Loader Class Initialized
INFO - 2016-09-08 13:35:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:36 --> Controller Class Initialized
INFO - 2016-09-08 13:35:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:36 --> Model Class Initialized
INFO - 2016-09-08 13:35:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:36 --> Config Class Initialized
INFO - 2016-09-08 13:35:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:36 --> URI Class Initialized
INFO - 2016-09-08 13:35:36 --> Router Class Initialized
INFO - 2016-09-08 13:35:36 --> Output Class Initialized
INFO - 2016-09-08 13:35:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:36 --> Input Class Initialized
INFO - 2016-09-08 13:35:36 --> Language Class Initialized
INFO - 2016-09-08 13:35:36 --> Loader Class Initialized
INFO - 2016-09-08 13:35:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:36 --> Controller Class Initialized
INFO - 2016-09-08 13:35:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:36 --> Model Class Initialized
INFO - 2016-09-08 13:35:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:35:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:35:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:35:36 --> Final output sent to browser
DEBUG - 2016-09-08 13:35:36 --> Total execution time: 0.0612
INFO - 2016-09-08 13:35:48 --> Config Class Initialized
INFO - 2016-09-08 13:35:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:48 --> URI Class Initialized
INFO - 2016-09-08 13:35:48 --> Router Class Initialized
INFO - 2016-09-08 13:35:48 --> Output Class Initialized
INFO - 2016-09-08 13:35:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:48 --> Input Class Initialized
INFO - 2016-09-08 13:35:48 --> Language Class Initialized
INFO - 2016-09-08 13:35:48 --> Loader Class Initialized
INFO - 2016-09-08 13:35:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:48 --> Controller Class Initialized
INFO - 2016-09-08 13:35:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:48 --> Model Class Initialized
INFO - 2016-09-08 13:35:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:48 --> Config Class Initialized
INFO - 2016-09-08 13:35:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:48 --> URI Class Initialized
INFO - 2016-09-08 13:35:48 --> Router Class Initialized
INFO - 2016-09-08 13:35:48 --> Output Class Initialized
INFO - 2016-09-08 13:35:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:48 --> Input Class Initialized
INFO - 2016-09-08 13:35:48 --> Language Class Initialized
INFO - 2016-09-08 13:35:48 --> Loader Class Initialized
INFO - 2016-09-08 13:35:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:48 --> Controller Class Initialized
INFO - 2016-09-08 13:35:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:48 --> Model Class Initialized
INFO - 2016-09-08 13:35:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:35:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:35:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:35:48 --> Final output sent to browser
DEBUG - 2016-09-08 13:35:48 --> Total execution time: 0.0570
INFO - 2016-09-08 13:35:52 --> Config Class Initialized
INFO - 2016-09-08 13:35:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:52 --> URI Class Initialized
INFO - 2016-09-08 13:35:52 --> Router Class Initialized
INFO - 2016-09-08 13:35:52 --> Output Class Initialized
INFO - 2016-09-08 13:35:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:52 --> Input Class Initialized
INFO - 2016-09-08 13:35:52 --> Language Class Initialized
INFO - 2016-09-08 13:35:52 --> Loader Class Initialized
INFO - 2016-09-08 13:35:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:52 --> Controller Class Initialized
INFO - 2016-09-08 13:35:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:52 --> Model Class Initialized
INFO - 2016-09-08 13:35:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:52 --> Config Class Initialized
INFO - 2016-09-08 13:35:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:35:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:35:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:35:52 --> URI Class Initialized
INFO - 2016-09-08 13:35:52 --> Router Class Initialized
INFO - 2016-09-08 13:35:52 --> Output Class Initialized
INFO - 2016-09-08 13:35:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:35:52 --> Input Class Initialized
INFO - 2016-09-08 13:35:52 --> Language Class Initialized
INFO - 2016-09-08 13:35:52 --> Loader Class Initialized
INFO - 2016-09-08 13:35:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:35:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:35:52 --> Controller Class Initialized
INFO - 2016-09-08 13:35:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:35:52 --> Model Class Initialized
INFO - 2016-09-08 13:35:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:35:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:35:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:35:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:35:52 --> Final output sent to browser
DEBUG - 2016-09-08 13:35:52 --> Total execution time: 0.0587
INFO - 2016-09-08 13:36:04 --> Config Class Initialized
INFO - 2016-09-08 13:36:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:04 --> URI Class Initialized
INFO - 2016-09-08 13:36:04 --> Router Class Initialized
INFO - 2016-09-08 13:36:04 --> Output Class Initialized
INFO - 2016-09-08 13:36:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:04 --> Input Class Initialized
INFO - 2016-09-08 13:36:04 --> Language Class Initialized
INFO - 2016-09-08 13:36:04 --> Loader Class Initialized
INFO - 2016-09-08 13:36:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:04 --> Controller Class Initialized
INFO - 2016-09-08 13:36:04 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:04 --> Model Class Initialized
INFO - 2016-09-08 13:36:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:04 --> Config Class Initialized
INFO - 2016-09-08 13:36:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:04 --> URI Class Initialized
INFO - 2016-09-08 13:36:04 --> Router Class Initialized
INFO - 2016-09-08 13:36:04 --> Output Class Initialized
INFO - 2016-09-08 13:36:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:04 --> Input Class Initialized
INFO - 2016-09-08 13:36:04 --> Language Class Initialized
INFO - 2016-09-08 13:36:04 --> Loader Class Initialized
INFO - 2016-09-08 13:36:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:04 --> Controller Class Initialized
INFO - 2016-09-08 13:36:04 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:04 --> Model Class Initialized
INFO - 2016-09-08 13:36:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:36:04 --> Final output sent to browser
DEBUG - 2016-09-08 13:36:04 --> Total execution time: 0.0568
INFO - 2016-09-08 13:36:07 --> Config Class Initialized
INFO - 2016-09-08 13:36:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:07 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:07 --> URI Class Initialized
INFO - 2016-09-08 13:36:07 --> Router Class Initialized
INFO - 2016-09-08 13:36:07 --> Output Class Initialized
INFO - 2016-09-08 13:36:07 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:07 --> Input Class Initialized
INFO - 2016-09-08 13:36:07 --> Language Class Initialized
INFO - 2016-09-08 13:36:07 --> Loader Class Initialized
INFO - 2016-09-08 13:36:07 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:07 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:07 --> Controller Class Initialized
INFO - 2016-09-08 13:36:07 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:07 --> Model Class Initialized
INFO - 2016-09-08 13:36:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:07 --> Config Class Initialized
INFO - 2016-09-08 13:36:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:07 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:07 --> URI Class Initialized
INFO - 2016-09-08 13:36:07 --> Router Class Initialized
INFO - 2016-09-08 13:36:07 --> Output Class Initialized
INFO - 2016-09-08 13:36:07 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:07 --> Input Class Initialized
INFO - 2016-09-08 13:36:07 --> Language Class Initialized
INFO - 2016-09-08 13:36:07 --> Loader Class Initialized
INFO - 2016-09-08 13:36:07 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:07 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:07 --> Controller Class Initialized
INFO - 2016-09-08 13:36:07 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:07 --> Model Class Initialized
INFO - 2016-09-08 13:36:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:36:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:36:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:36:07 --> Final output sent to browser
DEBUG - 2016-09-08 13:36:07 --> Total execution time: 0.0600
INFO - 2016-09-08 13:36:18 --> Config Class Initialized
INFO - 2016-09-08 13:36:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:18 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:18 --> URI Class Initialized
INFO - 2016-09-08 13:36:18 --> Router Class Initialized
INFO - 2016-09-08 13:36:18 --> Output Class Initialized
INFO - 2016-09-08 13:36:18 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:18 --> Input Class Initialized
INFO - 2016-09-08 13:36:18 --> Language Class Initialized
INFO - 2016-09-08 13:36:18 --> Loader Class Initialized
INFO - 2016-09-08 13:36:18 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:18 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:18 --> Controller Class Initialized
INFO - 2016-09-08 13:36:18 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:18 --> Model Class Initialized
INFO - 2016-09-08 13:36:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:18 --> Config Class Initialized
INFO - 2016-09-08 13:36:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:18 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:18 --> URI Class Initialized
INFO - 2016-09-08 13:36:18 --> Router Class Initialized
INFO - 2016-09-08 13:36:18 --> Output Class Initialized
INFO - 2016-09-08 13:36:18 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:18 --> Input Class Initialized
INFO - 2016-09-08 13:36:18 --> Language Class Initialized
INFO - 2016-09-08 13:36:18 --> Loader Class Initialized
INFO - 2016-09-08 13:36:18 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:18 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:18 --> Controller Class Initialized
INFO - 2016-09-08 13:36:18 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:18 --> Model Class Initialized
INFO - 2016-09-08 13:36:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:36:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:36:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:36:18 --> Final output sent to browser
DEBUG - 2016-09-08 13:36:18 --> Total execution time: 0.0599
INFO - 2016-09-08 13:36:21 --> Config Class Initialized
INFO - 2016-09-08 13:36:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:21 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:21 --> URI Class Initialized
INFO - 2016-09-08 13:36:21 --> Router Class Initialized
INFO - 2016-09-08 13:36:21 --> Output Class Initialized
INFO - 2016-09-08 13:36:21 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:21 --> Input Class Initialized
INFO - 2016-09-08 13:36:21 --> Language Class Initialized
INFO - 2016-09-08 13:36:21 --> Loader Class Initialized
INFO - 2016-09-08 13:36:21 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:21 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:21 --> Controller Class Initialized
INFO - 2016-09-08 13:36:21 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:21 --> Model Class Initialized
INFO - 2016-09-08 13:36:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:21 --> Config Class Initialized
INFO - 2016-09-08 13:36:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:21 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:21 --> URI Class Initialized
INFO - 2016-09-08 13:36:21 --> Router Class Initialized
INFO - 2016-09-08 13:36:21 --> Output Class Initialized
INFO - 2016-09-08 13:36:21 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:21 --> Input Class Initialized
INFO - 2016-09-08 13:36:21 --> Language Class Initialized
INFO - 2016-09-08 13:36:21 --> Loader Class Initialized
INFO - 2016-09-08 13:36:21 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:21 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:21 --> Controller Class Initialized
INFO - 2016-09-08 13:36:21 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:21 --> Model Class Initialized
INFO - 2016-09-08 13:36:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:36:21 --> Final output sent to browser
DEBUG - 2016-09-08 13:36:21 --> Total execution time: 0.0610
INFO - 2016-09-08 13:36:39 --> Config Class Initialized
INFO - 2016-09-08 13:36:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:39 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:39 --> URI Class Initialized
INFO - 2016-09-08 13:36:39 --> Router Class Initialized
INFO - 2016-09-08 13:36:39 --> Output Class Initialized
INFO - 2016-09-08 13:36:39 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:39 --> Input Class Initialized
INFO - 2016-09-08 13:36:39 --> Language Class Initialized
INFO - 2016-09-08 13:36:39 --> Loader Class Initialized
INFO - 2016-09-08 13:36:39 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:39 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:39 --> Controller Class Initialized
INFO - 2016-09-08 13:36:39 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:39 --> Model Class Initialized
INFO - 2016-09-08 13:36:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:40 --> Config Class Initialized
INFO - 2016-09-08 13:36:40 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:40 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:40 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:40 --> URI Class Initialized
INFO - 2016-09-08 13:36:40 --> Router Class Initialized
INFO - 2016-09-08 13:36:40 --> Output Class Initialized
INFO - 2016-09-08 13:36:40 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:40 --> Input Class Initialized
INFO - 2016-09-08 13:36:40 --> Language Class Initialized
INFO - 2016-09-08 13:36:40 --> Loader Class Initialized
INFO - 2016-09-08 13:36:40 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:40 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:40 --> Controller Class Initialized
INFO - 2016-09-08 13:36:40 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:40 --> Model Class Initialized
INFO - 2016-09-08 13:36:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:36:40 --> Final output sent to browser
DEBUG - 2016-09-08 13:36:40 --> Total execution time: 0.0580
INFO - 2016-09-08 13:36:45 --> Config Class Initialized
INFO - 2016-09-08 13:36:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:45 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:45 --> URI Class Initialized
INFO - 2016-09-08 13:36:45 --> Router Class Initialized
INFO - 2016-09-08 13:36:45 --> Output Class Initialized
INFO - 2016-09-08 13:36:45 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:45 --> Input Class Initialized
INFO - 2016-09-08 13:36:45 --> Language Class Initialized
INFO - 2016-09-08 13:36:45 --> Loader Class Initialized
INFO - 2016-09-08 13:36:45 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:45 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:45 --> Controller Class Initialized
INFO - 2016-09-08 13:36:45 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:45 --> Model Class Initialized
INFO - 2016-09-08 13:36:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:45 --> Config Class Initialized
INFO - 2016-09-08 13:36:45 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:36:45 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:36:45 --> Utf8 Class Initialized
INFO - 2016-09-08 13:36:45 --> URI Class Initialized
INFO - 2016-09-08 13:36:45 --> Router Class Initialized
INFO - 2016-09-08 13:36:45 --> Output Class Initialized
INFO - 2016-09-08 13:36:45 --> Security Class Initialized
DEBUG - 2016-09-08 13:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:36:45 --> Input Class Initialized
INFO - 2016-09-08 13:36:45 --> Language Class Initialized
INFO - 2016-09-08 13:36:45 --> Loader Class Initialized
INFO - 2016-09-08 13:36:45 --> Helper loaded: url_helper
INFO - 2016-09-08 13:36:45 --> Helper loaded: language_helper
INFO - 2016-09-08 13:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:36:45 --> Controller Class Initialized
INFO - 2016-09-08 13:36:45 --> Database Driver Class Initialized
INFO - 2016-09-08 13:36:45 --> Model Class Initialized
INFO - 2016-09-08 13:36:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:36:45 --> Final output sent to browser
DEBUG - 2016-09-08 13:36:45 --> Total execution time: 0.0597
INFO - 2016-09-08 13:37:00 --> Config Class Initialized
INFO - 2016-09-08 13:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:00 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:00 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:00 --> URI Class Initialized
INFO - 2016-09-08 13:37:00 --> Router Class Initialized
INFO - 2016-09-08 13:37:00 --> Output Class Initialized
INFO - 2016-09-08 13:37:00 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:00 --> Input Class Initialized
INFO - 2016-09-08 13:37:00 --> Language Class Initialized
INFO - 2016-09-08 13:37:00 --> Loader Class Initialized
INFO - 2016-09-08 13:37:00 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:00 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:00 --> Controller Class Initialized
INFO - 2016-09-08 13:37:00 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:00 --> Model Class Initialized
INFO - 2016-09-08 13:37:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:01 --> Config Class Initialized
INFO - 2016-09-08 13:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:01 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:01 --> URI Class Initialized
INFO - 2016-09-08 13:37:01 --> Router Class Initialized
INFO - 2016-09-08 13:37:01 --> Output Class Initialized
INFO - 2016-09-08 13:37:01 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:01 --> Input Class Initialized
INFO - 2016-09-08 13:37:01 --> Language Class Initialized
INFO - 2016-09-08 13:37:01 --> Loader Class Initialized
INFO - 2016-09-08 13:37:01 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:01 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:01 --> Controller Class Initialized
INFO - 2016-09-08 13:37:01 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:01 --> Model Class Initialized
INFO - 2016-09-08 13:37:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:37:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:01 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:01 --> Total execution time: 0.0554
INFO - 2016-09-08 13:37:04 --> Config Class Initialized
INFO - 2016-09-08 13:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:04 --> URI Class Initialized
INFO - 2016-09-08 13:37:04 --> Router Class Initialized
INFO - 2016-09-08 13:37:04 --> Output Class Initialized
INFO - 2016-09-08 13:37:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:04 --> Input Class Initialized
INFO - 2016-09-08 13:37:04 --> Language Class Initialized
INFO - 2016-09-08 13:37:04 --> Loader Class Initialized
INFO - 2016-09-08 13:37:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:04 --> Controller Class Initialized
INFO - 2016-09-08 13:37:04 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:04 --> Model Class Initialized
INFO - 2016-09-08 13:37:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:04 --> Config Class Initialized
INFO - 2016-09-08 13:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:04 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:04 --> URI Class Initialized
INFO - 2016-09-08 13:37:04 --> Router Class Initialized
INFO - 2016-09-08 13:37:04 --> Output Class Initialized
INFO - 2016-09-08 13:37:04 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:04 --> Input Class Initialized
INFO - 2016-09-08 13:37:04 --> Language Class Initialized
INFO - 2016-09-08 13:37:04 --> Loader Class Initialized
INFO - 2016-09-08 13:37:04 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:04 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:04 --> Controller Class Initialized
INFO - 2016-09-08 13:37:05 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:05 --> Model Class Initialized
INFO - 2016-09-08 13:37:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:37:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:05 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:05 --> Total execution time: 0.0608
INFO - 2016-09-08 13:37:16 --> Config Class Initialized
INFO - 2016-09-08 13:37:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:16 --> URI Class Initialized
INFO - 2016-09-08 13:37:16 --> Router Class Initialized
INFO - 2016-09-08 13:37:16 --> Output Class Initialized
INFO - 2016-09-08 13:37:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:16 --> Input Class Initialized
INFO - 2016-09-08 13:37:16 --> Language Class Initialized
INFO - 2016-09-08 13:37:16 --> Loader Class Initialized
INFO - 2016-09-08 13:37:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:16 --> Controller Class Initialized
INFO - 2016-09-08 13:37:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:16 --> Model Class Initialized
INFO - 2016-09-08 13:37:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:16 --> Config Class Initialized
INFO - 2016-09-08 13:37:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:16 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:16 --> URI Class Initialized
INFO - 2016-09-08 13:37:16 --> Router Class Initialized
INFO - 2016-09-08 13:37:16 --> Output Class Initialized
INFO - 2016-09-08 13:37:16 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:16 --> Input Class Initialized
INFO - 2016-09-08 13:37:16 --> Language Class Initialized
INFO - 2016-09-08 13:37:16 --> Loader Class Initialized
INFO - 2016-09-08 13:37:16 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:16 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:16 --> Controller Class Initialized
INFO - 2016-09-08 13:37:16 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:16 --> Model Class Initialized
INFO - 2016-09-08 13:37:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:16 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:16 --> Total execution time: 0.0563
INFO - 2016-09-08 13:37:19 --> Config Class Initialized
INFO - 2016-09-08 13:37:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:19 --> URI Class Initialized
INFO - 2016-09-08 13:37:19 --> Router Class Initialized
INFO - 2016-09-08 13:37:19 --> Output Class Initialized
INFO - 2016-09-08 13:37:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:19 --> Input Class Initialized
INFO - 2016-09-08 13:37:19 --> Language Class Initialized
INFO - 2016-09-08 13:37:19 --> Loader Class Initialized
INFO - 2016-09-08 13:37:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:19 --> Controller Class Initialized
INFO - 2016-09-08 13:37:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:19 --> Model Class Initialized
INFO - 2016-09-08 13:37:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:19 --> Config Class Initialized
INFO - 2016-09-08 13:37:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:19 --> URI Class Initialized
INFO - 2016-09-08 13:37:19 --> Router Class Initialized
INFO - 2016-09-08 13:37:19 --> Output Class Initialized
INFO - 2016-09-08 13:37:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:19 --> Input Class Initialized
INFO - 2016-09-08 13:37:19 --> Language Class Initialized
INFO - 2016-09-08 13:37:19 --> Loader Class Initialized
INFO - 2016-09-08 13:37:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:20 --> Controller Class Initialized
INFO - 2016-09-08 13:37:20 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:20 --> Model Class Initialized
INFO - 2016-09-08 13:37:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:37:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:20 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:20 --> Total execution time: 0.0596
INFO - 2016-09-08 13:37:32 --> Config Class Initialized
INFO - 2016-09-08 13:37:32 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:32 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:32 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:32 --> URI Class Initialized
INFO - 2016-09-08 13:37:32 --> Router Class Initialized
INFO - 2016-09-08 13:37:32 --> Output Class Initialized
INFO - 2016-09-08 13:37:32 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:32 --> Input Class Initialized
INFO - 2016-09-08 13:37:32 --> Language Class Initialized
INFO - 2016-09-08 13:37:32 --> Loader Class Initialized
INFO - 2016-09-08 13:37:32 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:32 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:32 --> Controller Class Initialized
INFO - 2016-09-08 13:37:32 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:32 --> Model Class Initialized
INFO - 2016-09-08 13:37:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:32 --> Config Class Initialized
INFO - 2016-09-08 13:37:32 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:32 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:32 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:32 --> URI Class Initialized
INFO - 2016-09-08 13:37:32 --> Router Class Initialized
INFO - 2016-09-08 13:37:32 --> Output Class Initialized
INFO - 2016-09-08 13:37:32 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:32 --> Input Class Initialized
INFO - 2016-09-08 13:37:32 --> Language Class Initialized
INFO - 2016-09-08 13:37:32 --> Loader Class Initialized
INFO - 2016-09-08 13:37:32 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:32 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:32 --> Controller Class Initialized
INFO - 2016-09-08 13:37:32 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:32 --> Model Class Initialized
INFO - 2016-09-08 13:37:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:32 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:32 --> Total execution time: 0.0564
INFO - 2016-09-08 13:37:36 --> Config Class Initialized
INFO - 2016-09-08 13:37:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:36 --> URI Class Initialized
INFO - 2016-09-08 13:37:36 --> Router Class Initialized
INFO - 2016-09-08 13:37:36 --> Output Class Initialized
INFO - 2016-09-08 13:37:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:36 --> Input Class Initialized
INFO - 2016-09-08 13:37:36 --> Language Class Initialized
INFO - 2016-09-08 13:37:36 --> Loader Class Initialized
INFO - 2016-09-08 13:37:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:36 --> Controller Class Initialized
INFO - 2016-09-08 13:37:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:36 --> Model Class Initialized
INFO - 2016-09-08 13:37:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:36 --> Config Class Initialized
INFO - 2016-09-08 13:37:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:36 --> URI Class Initialized
INFO - 2016-09-08 13:37:36 --> Router Class Initialized
INFO - 2016-09-08 13:37:36 --> Output Class Initialized
INFO - 2016-09-08 13:37:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:36 --> Input Class Initialized
INFO - 2016-09-08 13:37:36 --> Language Class Initialized
INFO - 2016-09-08 13:37:36 --> Loader Class Initialized
INFO - 2016-09-08 13:37:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:36 --> Controller Class Initialized
INFO - 2016-09-08 13:37:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:36 --> Model Class Initialized
INFO - 2016-09-08 13:37:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:37:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:36 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:36 --> Total execution time: 0.0597
INFO - 2016-09-08 13:37:48 --> Config Class Initialized
INFO - 2016-09-08 13:37:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:48 --> URI Class Initialized
INFO - 2016-09-08 13:37:48 --> Router Class Initialized
INFO - 2016-09-08 13:37:48 --> Output Class Initialized
INFO - 2016-09-08 13:37:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:48 --> Input Class Initialized
INFO - 2016-09-08 13:37:48 --> Language Class Initialized
INFO - 2016-09-08 13:37:48 --> Loader Class Initialized
INFO - 2016-09-08 13:37:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:48 --> Controller Class Initialized
INFO - 2016-09-08 13:37:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:48 --> Model Class Initialized
INFO - 2016-09-08 13:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:48 --> Config Class Initialized
INFO - 2016-09-08 13:37:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:48 --> URI Class Initialized
INFO - 2016-09-08 13:37:48 --> Router Class Initialized
INFO - 2016-09-08 13:37:48 --> Output Class Initialized
INFO - 2016-09-08 13:37:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:48 --> Input Class Initialized
INFO - 2016-09-08 13:37:48 --> Language Class Initialized
INFO - 2016-09-08 13:37:48 --> Loader Class Initialized
INFO - 2016-09-08 13:37:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:48 --> Controller Class Initialized
INFO - 2016-09-08 13:37:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:48 --> Model Class Initialized
INFO - 2016-09-08 13:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:48 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:48 --> Total execution time: 0.0566
INFO - 2016-09-08 13:37:51 --> Config Class Initialized
INFO - 2016-09-08 13:37:51 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:51 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:51 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:51 --> URI Class Initialized
INFO - 2016-09-08 13:37:51 --> Router Class Initialized
INFO - 2016-09-08 13:37:51 --> Output Class Initialized
INFO - 2016-09-08 13:37:51 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:51 --> Input Class Initialized
INFO - 2016-09-08 13:37:51 --> Language Class Initialized
INFO - 2016-09-08 13:37:51 --> Loader Class Initialized
INFO - 2016-09-08 13:37:51 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:51 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:52 --> Controller Class Initialized
INFO - 2016-09-08 13:37:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:52 --> Model Class Initialized
INFO - 2016-09-08 13:37:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:52 --> Config Class Initialized
INFO - 2016-09-08 13:37:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:37:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:37:52 --> Utf8 Class Initialized
INFO - 2016-09-08 13:37:52 --> URI Class Initialized
INFO - 2016-09-08 13:37:52 --> Router Class Initialized
INFO - 2016-09-08 13:37:52 --> Output Class Initialized
INFO - 2016-09-08 13:37:52 --> Security Class Initialized
DEBUG - 2016-09-08 13:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:37:52 --> Input Class Initialized
INFO - 2016-09-08 13:37:52 --> Language Class Initialized
INFO - 2016-09-08 13:37:52 --> Loader Class Initialized
INFO - 2016-09-08 13:37:52 --> Helper loaded: url_helper
INFO - 2016-09-08 13:37:52 --> Helper loaded: language_helper
INFO - 2016-09-08 13:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:37:52 --> Controller Class Initialized
INFO - 2016-09-08 13:37:52 --> Database Driver Class Initialized
INFO - 2016-09-08 13:37:52 --> Model Class Initialized
INFO - 2016-09-08 13:37:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:37:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:37:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:37:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:37:52 --> Final output sent to browser
DEBUG - 2016-09-08 13:37:52 --> Total execution time: 0.0608
INFO - 2016-09-08 13:38:03 --> Config Class Initialized
INFO - 2016-09-08 13:38:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:03 --> URI Class Initialized
INFO - 2016-09-08 13:38:03 --> Router Class Initialized
INFO - 2016-09-08 13:38:03 --> Output Class Initialized
INFO - 2016-09-08 13:38:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:03 --> Input Class Initialized
INFO - 2016-09-08 13:38:03 --> Language Class Initialized
INFO - 2016-09-08 13:38:03 --> Loader Class Initialized
INFO - 2016-09-08 13:38:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:03 --> Controller Class Initialized
INFO - 2016-09-08 13:38:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:03 --> Model Class Initialized
INFO - 2016-09-08 13:38:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:03 --> Config Class Initialized
INFO - 2016-09-08 13:38:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:03 --> URI Class Initialized
INFO - 2016-09-08 13:38:03 --> Router Class Initialized
INFO - 2016-09-08 13:38:03 --> Output Class Initialized
INFO - 2016-09-08 13:38:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:03 --> Input Class Initialized
INFO - 2016-09-08 13:38:03 --> Language Class Initialized
INFO - 2016-09-08 13:38:03 --> Loader Class Initialized
INFO - 2016-09-08 13:38:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:03 --> Controller Class Initialized
INFO - 2016-09-08 13:38:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:03 --> Model Class Initialized
INFO - 2016-09-08 13:38:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:38:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:03 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:03 --> Total execution time: 0.0558
INFO - 2016-09-08 13:38:06 --> Config Class Initialized
INFO - 2016-09-08 13:38:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:06 --> URI Class Initialized
INFO - 2016-09-08 13:38:06 --> Router Class Initialized
INFO - 2016-09-08 13:38:06 --> Output Class Initialized
INFO - 2016-09-08 13:38:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:06 --> Input Class Initialized
INFO - 2016-09-08 13:38:06 --> Language Class Initialized
INFO - 2016-09-08 13:38:06 --> Loader Class Initialized
INFO - 2016-09-08 13:38:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:06 --> Controller Class Initialized
INFO - 2016-09-08 13:38:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:06 --> Model Class Initialized
INFO - 2016-09-08 13:38:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:06 --> Config Class Initialized
INFO - 2016-09-08 13:38:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:06 --> URI Class Initialized
INFO - 2016-09-08 13:38:06 --> Router Class Initialized
INFO - 2016-09-08 13:38:06 --> Output Class Initialized
INFO - 2016-09-08 13:38:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:06 --> Input Class Initialized
INFO - 2016-09-08 13:38:06 --> Language Class Initialized
INFO - 2016-09-08 13:38:06 --> Loader Class Initialized
INFO - 2016-09-08 13:38:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:06 --> Controller Class Initialized
INFO - 2016-09-08 13:38:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:06 --> Model Class Initialized
INFO - 2016-09-08 13:38:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:38:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:06 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:06 --> Total execution time: 0.0601
INFO - 2016-09-08 13:38:17 --> Config Class Initialized
INFO - 2016-09-08 13:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:17 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:17 --> URI Class Initialized
INFO - 2016-09-08 13:38:17 --> Router Class Initialized
INFO - 2016-09-08 13:38:17 --> Output Class Initialized
INFO - 2016-09-08 13:38:17 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:17 --> Input Class Initialized
INFO - 2016-09-08 13:38:17 --> Language Class Initialized
INFO - 2016-09-08 13:38:17 --> Loader Class Initialized
INFO - 2016-09-08 13:38:17 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:17 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:17 --> Controller Class Initialized
INFO - 2016-09-08 13:38:17 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:17 --> Model Class Initialized
INFO - 2016-09-08 13:38:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:17 --> Config Class Initialized
INFO - 2016-09-08 13:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:17 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:17 --> URI Class Initialized
INFO - 2016-09-08 13:38:17 --> Router Class Initialized
INFO - 2016-09-08 13:38:17 --> Output Class Initialized
INFO - 2016-09-08 13:38:17 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:17 --> Input Class Initialized
INFO - 2016-09-08 13:38:17 --> Language Class Initialized
INFO - 2016-09-08 13:38:17 --> Loader Class Initialized
INFO - 2016-09-08 13:38:17 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:17 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:17 --> Controller Class Initialized
INFO - 2016-09-08 13:38:17 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:17 --> Model Class Initialized
INFO - 2016-09-08 13:38:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:38:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:17 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:17 --> Total execution time: 0.0547
INFO - 2016-09-08 13:38:21 --> Config Class Initialized
INFO - 2016-09-08 13:38:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:21 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:21 --> URI Class Initialized
INFO - 2016-09-08 13:38:21 --> Router Class Initialized
INFO - 2016-09-08 13:38:21 --> Output Class Initialized
INFO - 2016-09-08 13:38:21 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:21 --> Input Class Initialized
INFO - 2016-09-08 13:38:21 --> Language Class Initialized
INFO - 2016-09-08 13:38:21 --> Loader Class Initialized
INFO - 2016-09-08 13:38:21 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:21 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:21 --> Controller Class Initialized
INFO - 2016-09-08 13:38:21 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:21 --> Model Class Initialized
INFO - 2016-09-08 13:38:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:21 --> Config Class Initialized
INFO - 2016-09-08 13:38:21 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:21 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:21 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:21 --> URI Class Initialized
INFO - 2016-09-08 13:38:21 --> Router Class Initialized
INFO - 2016-09-08 13:38:21 --> Output Class Initialized
INFO - 2016-09-08 13:38:21 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:21 --> Input Class Initialized
INFO - 2016-09-08 13:38:21 --> Language Class Initialized
INFO - 2016-09-08 13:38:21 --> Loader Class Initialized
INFO - 2016-09-08 13:38:21 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:21 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:21 --> Controller Class Initialized
INFO - 2016-09-08 13:38:21 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:21 --> Model Class Initialized
INFO - 2016-09-08 13:38:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:38:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:21 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:21 --> Total execution time: 0.0600
INFO - 2016-09-08 13:38:33 --> Config Class Initialized
INFO - 2016-09-08 13:38:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:33 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:33 --> URI Class Initialized
INFO - 2016-09-08 13:38:33 --> Router Class Initialized
INFO - 2016-09-08 13:38:33 --> Output Class Initialized
INFO - 2016-09-08 13:38:33 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:33 --> Input Class Initialized
INFO - 2016-09-08 13:38:33 --> Language Class Initialized
INFO - 2016-09-08 13:38:33 --> Loader Class Initialized
INFO - 2016-09-08 13:38:33 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:33 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:33 --> Controller Class Initialized
INFO - 2016-09-08 13:38:33 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:33 --> Model Class Initialized
INFO - 2016-09-08 13:38:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:33 --> Config Class Initialized
INFO - 2016-09-08 13:38:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:33 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:33 --> URI Class Initialized
INFO - 2016-09-08 13:38:33 --> Router Class Initialized
INFO - 2016-09-08 13:38:33 --> Output Class Initialized
INFO - 2016-09-08 13:38:33 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:33 --> Input Class Initialized
INFO - 2016-09-08 13:38:33 --> Language Class Initialized
INFO - 2016-09-08 13:38:33 --> Loader Class Initialized
INFO - 2016-09-08 13:38:33 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:33 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:33 --> Controller Class Initialized
INFO - 2016-09-08 13:38:33 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:33 --> Model Class Initialized
INFO - 2016-09-08 13:38:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:38:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:33 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:33 --> Total execution time: 0.0556
INFO - 2016-09-08 13:38:36 --> Config Class Initialized
INFO - 2016-09-08 13:38:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:36 --> URI Class Initialized
INFO - 2016-09-08 13:38:36 --> Router Class Initialized
INFO - 2016-09-08 13:38:36 --> Output Class Initialized
INFO - 2016-09-08 13:38:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:36 --> Input Class Initialized
INFO - 2016-09-08 13:38:36 --> Language Class Initialized
INFO - 2016-09-08 13:38:36 --> Loader Class Initialized
INFO - 2016-09-08 13:38:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:36 --> Controller Class Initialized
INFO - 2016-09-08 13:38:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:36 --> Model Class Initialized
INFO - 2016-09-08 13:38:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:36 --> Config Class Initialized
INFO - 2016-09-08 13:38:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:36 --> URI Class Initialized
INFO - 2016-09-08 13:38:36 --> Router Class Initialized
INFO - 2016-09-08 13:38:36 --> Output Class Initialized
INFO - 2016-09-08 13:38:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:36 --> Input Class Initialized
INFO - 2016-09-08 13:38:36 --> Language Class Initialized
INFO - 2016-09-08 13:38:36 --> Loader Class Initialized
INFO - 2016-09-08 13:38:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:36 --> Controller Class Initialized
INFO - 2016-09-08 13:38:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:36 --> Model Class Initialized
INFO - 2016-09-08 13:38:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:38:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:36 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:36 --> Total execution time: 0.0586
INFO - 2016-09-08 13:38:46 --> Config Class Initialized
INFO - 2016-09-08 13:38:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:46 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:46 --> URI Class Initialized
INFO - 2016-09-08 13:38:46 --> Router Class Initialized
INFO - 2016-09-08 13:38:46 --> Output Class Initialized
INFO - 2016-09-08 13:38:46 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:46 --> Input Class Initialized
INFO - 2016-09-08 13:38:46 --> Language Class Initialized
INFO - 2016-09-08 13:38:46 --> Loader Class Initialized
INFO - 2016-09-08 13:38:46 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:46 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:46 --> Controller Class Initialized
INFO - 2016-09-08 13:38:46 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:46 --> Model Class Initialized
INFO - 2016-09-08 13:38:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:46 --> Config Class Initialized
INFO - 2016-09-08 13:38:46 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:46 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:46 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:46 --> URI Class Initialized
INFO - 2016-09-08 13:38:46 --> Router Class Initialized
INFO - 2016-09-08 13:38:46 --> Output Class Initialized
INFO - 2016-09-08 13:38:46 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:46 --> Input Class Initialized
INFO - 2016-09-08 13:38:46 --> Language Class Initialized
INFO - 2016-09-08 13:38:46 --> Loader Class Initialized
INFO - 2016-09-08 13:38:46 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:46 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:46 --> Controller Class Initialized
INFO - 2016-09-08 13:38:46 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:46 --> Model Class Initialized
INFO - 2016-09-08 13:38:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:38:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:46 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:46 --> Total execution time: 0.0618
INFO - 2016-09-08 13:38:48 --> Config Class Initialized
INFO - 2016-09-08 13:38:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:48 --> URI Class Initialized
INFO - 2016-09-08 13:38:48 --> Router Class Initialized
INFO - 2016-09-08 13:38:48 --> Output Class Initialized
INFO - 2016-09-08 13:38:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:48 --> Input Class Initialized
INFO - 2016-09-08 13:38:48 --> Language Class Initialized
INFO - 2016-09-08 13:38:48 --> Loader Class Initialized
INFO - 2016-09-08 13:38:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:48 --> Controller Class Initialized
INFO - 2016-09-08 13:38:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:48 --> Model Class Initialized
INFO - 2016-09-08 13:38:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:48 --> Config Class Initialized
INFO - 2016-09-08 13:38:48 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:38:48 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:38:48 --> Utf8 Class Initialized
INFO - 2016-09-08 13:38:48 --> URI Class Initialized
INFO - 2016-09-08 13:38:48 --> Router Class Initialized
INFO - 2016-09-08 13:38:48 --> Output Class Initialized
INFO - 2016-09-08 13:38:48 --> Security Class Initialized
DEBUG - 2016-09-08 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:38:48 --> Input Class Initialized
INFO - 2016-09-08 13:38:48 --> Language Class Initialized
INFO - 2016-09-08 13:38:48 --> Loader Class Initialized
INFO - 2016-09-08 13:38:48 --> Helper loaded: url_helper
INFO - 2016-09-08 13:38:48 --> Helper loaded: language_helper
INFO - 2016-09-08 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:38:48 --> Controller Class Initialized
INFO - 2016-09-08 13:38:48 --> Database Driver Class Initialized
INFO - 2016-09-08 13:38:48 --> Model Class Initialized
INFO - 2016-09-08 13:38:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:38:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:38:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:38:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:38:48 --> Final output sent to browser
DEBUG - 2016-09-08 13:38:48 --> Total execution time: 0.0855
INFO - 2016-09-08 13:39:03 --> Config Class Initialized
INFO - 2016-09-08 13:39:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:03 --> URI Class Initialized
INFO - 2016-09-08 13:39:03 --> Router Class Initialized
INFO - 2016-09-08 13:39:03 --> Output Class Initialized
INFO - 2016-09-08 13:39:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:03 --> Input Class Initialized
INFO - 2016-09-08 13:39:03 --> Language Class Initialized
INFO - 2016-09-08 13:39:03 --> Loader Class Initialized
INFO - 2016-09-08 13:39:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:03 --> Controller Class Initialized
INFO - 2016-09-08 13:39:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:03 --> Model Class Initialized
INFO - 2016-09-08 13:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:03 --> Config Class Initialized
INFO - 2016-09-08 13:39:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:03 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:03 --> URI Class Initialized
INFO - 2016-09-08 13:39:03 --> Router Class Initialized
INFO - 2016-09-08 13:39:03 --> Output Class Initialized
INFO - 2016-09-08 13:39:03 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:03 --> Input Class Initialized
INFO - 2016-09-08 13:39:03 --> Language Class Initialized
INFO - 2016-09-08 13:39:03 --> Loader Class Initialized
INFO - 2016-09-08 13:39:03 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:03 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:03 --> Controller Class Initialized
INFO - 2016-09-08 13:39:03 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:03 --> Model Class Initialized
INFO - 2016-09-08 13:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:39:03 --> Final output sent to browser
DEBUG - 2016-09-08 13:39:03 --> Total execution time: 0.0611
INFO - 2016-09-08 13:39:06 --> Config Class Initialized
INFO - 2016-09-08 13:39:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:06 --> URI Class Initialized
INFO - 2016-09-08 13:39:06 --> Router Class Initialized
INFO - 2016-09-08 13:39:06 --> Output Class Initialized
INFO - 2016-09-08 13:39:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:06 --> Input Class Initialized
INFO - 2016-09-08 13:39:06 --> Language Class Initialized
INFO - 2016-09-08 13:39:06 --> Loader Class Initialized
INFO - 2016-09-08 13:39:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:06 --> Controller Class Initialized
INFO - 2016-09-08 13:39:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:06 --> Model Class Initialized
INFO - 2016-09-08 13:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:06 --> Config Class Initialized
INFO - 2016-09-08 13:39:06 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:06 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:06 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:06 --> URI Class Initialized
INFO - 2016-09-08 13:39:06 --> Router Class Initialized
INFO - 2016-09-08 13:39:06 --> Output Class Initialized
INFO - 2016-09-08 13:39:06 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:06 --> Input Class Initialized
INFO - 2016-09-08 13:39:06 --> Language Class Initialized
INFO - 2016-09-08 13:39:06 --> Loader Class Initialized
INFO - 2016-09-08 13:39:06 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:06 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:06 --> Controller Class Initialized
INFO - 2016-09-08 13:39:06 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:06 --> Model Class Initialized
INFO - 2016-09-08 13:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:39:06 --> Final output sent to browser
DEBUG - 2016-09-08 13:39:06 --> Total execution time: 0.0577
INFO - 2016-09-08 13:39:22 --> Config Class Initialized
INFO - 2016-09-08 13:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:22 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:22 --> URI Class Initialized
INFO - 2016-09-08 13:39:22 --> Router Class Initialized
INFO - 2016-09-08 13:39:22 --> Output Class Initialized
INFO - 2016-09-08 13:39:22 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:22 --> Input Class Initialized
INFO - 2016-09-08 13:39:22 --> Language Class Initialized
INFO - 2016-09-08 13:39:22 --> Loader Class Initialized
INFO - 2016-09-08 13:39:22 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:22 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:22 --> Controller Class Initialized
INFO - 2016-09-08 13:39:22 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:22 --> Model Class Initialized
INFO - 2016-09-08 13:39:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:22 --> Config Class Initialized
INFO - 2016-09-08 13:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:22 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:22 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:22 --> URI Class Initialized
INFO - 2016-09-08 13:39:22 --> Router Class Initialized
INFO - 2016-09-08 13:39:22 --> Output Class Initialized
INFO - 2016-09-08 13:39:22 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:22 --> Input Class Initialized
INFO - 2016-09-08 13:39:22 --> Language Class Initialized
INFO - 2016-09-08 13:39:22 --> Loader Class Initialized
INFO - 2016-09-08 13:39:22 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:22 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:22 --> Controller Class Initialized
INFO - 2016-09-08 13:39:22 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:22 --> Model Class Initialized
INFO - 2016-09-08 13:39:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:39:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:39:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:39:22 --> Final output sent to browser
DEBUG - 2016-09-08 13:39:22 --> Total execution time: 0.0564
INFO - 2016-09-08 13:39:25 --> Config Class Initialized
INFO - 2016-09-08 13:39:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:25 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:25 --> URI Class Initialized
INFO - 2016-09-08 13:39:25 --> Router Class Initialized
INFO - 2016-09-08 13:39:25 --> Output Class Initialized
INFO - 2016-09-08 13:39:25 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:25 --> Input Class Initialized
INFO - 2016-09-08 13:39:25 --> Language Class Initialized
INFO - 2016-09-08 13:39:25 --> Loader Class Initialized
INFO - 2016-09-08 13:39:25 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:25 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:25 --> Controller Class Initialized
INFO - 2016-09-08 13:39:25 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:25 --> Model Class Initialized
INFO - 2016-09-08 13:39:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:25 --> Config Class Initialized
INFO - 2016-09-08 13:39:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:25 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:25 --> URI Class Initialized
INFO - 2016-09-08 13:39:25 --> Router Class Initialized
INFO - 2016-09-08 13:39:25 --> Output Class Initialized
INFO - 2016-09-08 13:39:25 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:25 --> Input Class Initialized
INFO - 2016-09-08 13:39:25 --> Language Class Initialized
INFO - 2016-09-08 13:39:25 --> Loader Class Initialized
INFO - 2016-09-08 13:39:25 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:25 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:25 --> Controller Class Initialized
INFO - 2016-09-08 13:39:25 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:25 --> Model Class Initialized
INFO - 2016-09-08 13:39:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:39:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_4.php
INFO - 2016-09-08 13:39:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:39:25 --> Final output sent to browser
DEBUG - 2016-09-08 13:39:25 --> Total execution time: 0.0585
INFO - 2016-09-08 13:39:36 --> Config Class Initialized
INFO - 2016-09-08 13:39:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:36 --> URI Class Initialized
INFO - 2016-09-08 13:39:36 --> Router Class Initialized
INFO - 2016-09-08 13:39:36 --> Output Class Initialized
INFO - 2016-09-08 13:39:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:36 --> Input Class Initialized
INFO - 2016-09-08 13:39:36 --> Language Class Initialized
INFO - 2016-09-08 13:39:36 --> Loader Class Initialized
INFO - 2016-09-08 13:39:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:36 --> Controller Class Initialized
INFO - 2016-09-08 13:39:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:36 --> Model Class Initialized
INFO - 2016-09-08 13:39:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:36 --> Config Class Initialized
INFO - 2016-09-08 13:39:36 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:39:36 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:39:36 --> Utf8 Class Initialized
INFO - 2016-09-08 13:39:36 --> URI Class Initialized
INFO - 2016-09-08 13:39:36 --> Router Class Initialized
INFO - 2016-09-08 13:39:36 --> Output Class Initialized
INFO - 2016-09-08 13:39:36 --> Security Class Initialized
DEBUG - 2016-09-08 13:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:39:36 --> Input Class Initialized
INFO - 2016-09-08 13:39:36 --> Language Class Initialized
INFO - 2016-09-08 13:39:36 --> Loader Class Initialized
INFO - 2016-09-08 13:39:36 --> Helper loaded: url_helper
INFO - 2016-09-08 13:39:36 --> Helper loaded: language_helper
INFO - 2016-09-08 13:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:39:36 --> Controller Class Initialized
INFO - 2016-09-08 13:39:36 --> Database Driver Class Initialized
INFO - 2016-09-08 13:39:36 --> Model Class Initialized
INFO - 2016-09-08 13:39:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:39:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:39:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:39:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:39:36 --> Final output sent to browser
DEBUG - 2016-09-08 13:39:36 --> Total execution time: 0.0602
INFO - 2016-09-08 13:40:11 --> Config Class Initialized
INFO - 2016-09-08 13:40:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:40:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:40:11 --> Utf8 Class Initialized
INFO - 2016-09-08 13:40:11 --> URI Class Initialized
INFO - 2016-09-08 13:40:11 --> Router Class Initialized
INFO - 2016-09-08 13:40:11 --> Output Class Initialized
INFO - 2016-09-08 13:40:11 --> Security Class Initialized
DEBUG - 2016-09-08 13:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:40:11 --> Input Class Initialized
INFO - 2016-09-08 13:40:11 --> Language Class Initialized
INFO - 2016-09-08 13:40:11 --> Loader Class Initialized
INFO - 2016-09-08 13:40:11 --> Helper loaded: url_helper
INFO - 2016-09-08 13:40:11 --> Helper loaded: language_helper
INFO - 2016-09-08 13:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:40:11 --> Controller Class Initialized
INFO - 2016-09-08 13:40:11 --> Database Driver Class Initialized
INFO - 2016-09-08 13:40:11 --> Model Class Initialized
INFO - 2016-09-08 13:40:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:40:11 --> Config Class Initialized
INFO - 2016-09-08 13:40:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:40:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:40:11 --> Utf8 Class Initialized
INFO - 2016-09-08 13:40:11 --> URI Class Initialized
INFO - 2016-09-08 13:40:11 --> Router Class Initialized
INFO - 2016-09-08 13:40:11 --> Output Class Initialized
INFO - 2016-09-08 13:40:11 --> Security Class Initialized
DEBUG - 2016-09-08 13:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:40:11 --> Input Class Initialized
INFO - 2016-09-08 13:40:11 --> Language Class Initialized
INFO - 2016-09-08 13:40:11 --> Loader Class Initialized
INFO - 2016-09-08 13:40:11 --> Helper loaded: url_helper
INFO - 2016-09-08 13:40:11 --> Helper loaded: language_helper
INFO - 2016-09-08 13:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:40:11 --> Controller Class Initialized
INFO - 2016-09-08 13:40:11 --> Database Driver Class Initialized
INFO - 2016-09-08 13:40:11 --> Model Class Initialized
INFO - 2016-09-08 13:40:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 13:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:40:11 --> Final output sent to browser
DEBUG - 2016-09-08 13:40:11 --> Total execution time: 0.0587
INFO - 2016-09-08 13:41:19 --> Config Class Initialized
INFO - 2016-09-08 13:41:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:41:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:41:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:41:19 --> URI Class Initialized
INFO - 2016-09-08 13:41:19 --> Router Class Initialized
INFO - 2016-09-08 13:41:19 --> Output Class Initialized
INFO - 2016-09-08 13:41:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:41:19 --> Input Class Initialized
INFO - 2016-09-08 13:41:19 --> Language Class Initialized
INFO - 2016-09-08 13:41:19 --> Loader Class Initialized
INFO - 2016-09-08 13:41:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:41:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:41:19 --> Controller Class Initialized
INFO - 2016-09-08 13:41:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:41:19 --> Model Class Initialized
INFO - 2016-09-08 13:41:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:41:19 --> Config Class Initialized
INFO - 2016-09-08 13:41:19 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:41:19 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:41:19 --> Utf8 Class Initialized
INFO - 2016-09-08 13:41:19 --> URI Class Initialized
INFO - 2016-09-08 13:41:19 --> Router Class Initialized
INFO - 2016-09-08 13:41:19 --> Output Class Initialized
INFO - 2016-09-08 13:41:19 --> Security Class Initialized
DEBUG - 2016-09-08 13:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:41:19 --> Input Class Initialized
INFO - 2016-09-08 13:41:19 --> Language Class Initialized
INFO - 2016-09-08 13:41:19 --> Loader Class Initialized
INFO - 2016-09-08 13:41:19 --> Helper loaded: url_helper
INFO - 2016-09-08 13:41:19 --> Helper loaded: language_helper
INFO - 2016-09-08 13:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:41:19 --> Controller Class Initialized
INFO - 2016-09-08 13:41:19 --> Database Driver Class Initialized
INFO - 2016-09-08 13:41:19 --> Model Class Initialized
INFO - 2016-09-08 13:41:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:41:19 --> Final output sent to browser
DEBUG - 2016-09-08 13:41:19 --> Total execution time: 0.0789
INFO - 2016-09-08 13:41:25 --> Config Class Initialized
INFO - 2016-09-08 13:41:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:41:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:41:25 --> Utf8 Class Initialized
INFO - 2016-09-08 13:41:25 --> URI Class Initialized
INFO - 2016-09-08 13:41:25 --> Router Class Initialized
INFO - 2016-09-08 13:41:25 --> Output Class Initialized
INFO - 2016-09-08 13:41:25 --> Security Class Initialized
DEBUG - 2016-09-08 13:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:41:25 --> Input Class Initialized
INFO - 2016-09-08 13:41:25 --> Language Class Initialized
INFO - 2016-09-08 13:41:25 --> Loader Class Initialized
INFO - 2016-09-08 13:41:25 --> Helper loaded: url_helper
INFO - 2016-09-08 13:41:25 --> Helper loaded: language_helper
INFO - 2016-09-08 13:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:41:25 --> Controller Class Initialized
INFO - 2016-09-08 13:41:25 --> Database Driver Class Initialized
INFO - 2016-09-08 13:41:25 --> Model Class Initialized
INFO - 2016-09-08 13:41:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:41:25 --> Helper loaded: form_helper
INFO - 2016-09-08 13:41:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:41:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 13:41:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:41:25 --> Final output sent to browser
DEBUG - 2016-09-08 13:41:25 --> Total execution time: 0.0673
INFO - 2016-09-08 13:41:33 --> Config Class Initialized
INFO - 2016-09-08 13:41:33 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:41:33 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:41:33 --> Utf8 Class Initialized
INFO - 2016-09-08 13:41:33 --> URI Class Initialized
INFO - 2016-09-08 13:41:33 --> Router Class Initialized
INFO - 2016-09-08 13:41:33 --> Output Class Initialized
INFO - 2016-09-08 13:41:33 --> Security Class Initialized
DEBUG - 2016-09-08 13:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:41:33 --> Input Class Initialized
INFO - 2016-09-08 13:41:33 --> Language Class Initialized
INFO - 2016-09-08 13:41:33 --> Loader Class Initialized
INFO - 2016-09-08 13:41:33 --> Helper loaded: url_helper
INFO - 2016-09-08 13:41:33 --> Helper loaded: language_helper
INFO - 2016-09-08 13:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:41:33 --> Controller Class Initialized
INFO - 2016-09-08 13:41:33 --> Database Driver Class Initialized
INFO - 2016-09-08 13:41:33 --> Model Class Initialized
INFO - 2016-09-08 13:41:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:41:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:41:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-08 13:41:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:41:33 --> Final output sent to browser
DEBUG - 2016-09-08 13:41:33 --> Total execution time: 0.0604
INFO - 2016-09-08 13:41:47 --> Config Class Initialized
INFO - 2016-09-08 13:41:47 --> Hooks Class Initialized
DEBUG - 2016-09-08 13:41:47 --> UTF-8 Support Enabled
INFO - 2016-09-08 13:41:47 --> Utf8 Class Initialized
INFO - 2016-09-08 13:41:47 --> URI Class Initialized
INFO - 2016-09-08 13:41:47 --> Router Class Initialized
INFO - 2016-09-08 13:41:47 --> Output Class Initialized
INFO - 2016-09-08 13:41:47 --> Security Class Initialized
DEBUG - 2016-09-08 13:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 13:41:47 --> Input Class Initialized
INFO - 2016-09-08 13:41:47 --> Language Class Initialized
INFO - 2016-09-08 13:41:47 --> Loader Class Initialized
INFO - 2016-09-08 13:41:47 --> Helper loaded: url_helper
INFO - 2016-09-08 13:41:47 --> Helper loaded: language_helper
INFO - 2016-09-08 13:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 13:41:47 --> Controller Class Initialized
INFO - 2016-09-08 13:41:47 --> Database Driver Class Initialized
INFO - 2016-09-08 13:41:47 --> Model Class Initialized
INFO - 2016-09-08 13:41:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 13:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 13:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 13:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 13:41:47 --> Final output sent to browser
DEBUG - 2016-09-08 13:41:47 --> Total execution time: 0.0618
INFO - 2016-09-08 14:04:57 --> Config Class Initialized
INFO - 2016-09-08 14:04:57 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:04:57 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:04:57 --> Utf8 Class Initialized
INFO - 2016-09-08 14:04:57 --> URI Class Initialized
INFO - 2016-09-08 14:04:57 --> Router Class Initialized
INFO - 2016-09-08 14:04:57 --> Output Class Initialized
INFO - 2016-09-08 14:04:57 --> Security Class Initialized
DEBUG - 2016-09-08 14:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:04:57 --> Input Class Initialized
INFO - 2016-09-08 14:04:58 --> Language Class Initialized
INFO - 2016-09-08 14:04:58 --> Loader Class Initialized
INFO - 2016-09-08 14:04:58 --> Helper loaded: url_helper
INFO - 2016-09-08 14:04:58 --> Helper loaded: language_helper
INFO - 2016-09-08 14:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:04:58 --> Controller Class Initialized
INFO - 2016-09-08 14:04:58 --> Database Driver Class Initialized
INFO - 2016-09-08 14:04:58 --> Model Class Initialized
INFO - 2016-09-08 14:04:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:04:58 --> Config Class Initialized
INFO - 2016-09-08 14:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:04:58 --> Utf8 Class Initialized
INFO - 2016-09-08 14:04:58 --> URI Class Initialized
INFO - 2016-09-08 14:04:58 --> Router Class Initialized
INFO - 2016-09-08 14:04:58 --> Output Class Initialized
INFO - 2016-09-08 14:04:58 --> Security Class Initialized
DEBUG - 2016-09-08 14:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:04:58 --> Input Class Initialized
INFO - 2016-09-08 14:04:58 --> Language Class Initialized
INFO - 2016-09-08 14:04:58 --> Loader Class Initialized
INFO - 2016-09-08 14:04:58 --> Helper loaded: url_helper
INFO - 2016-09-08 14:04:58 --> Helper loaded: language_helper
INFO - 2016-09-08 14:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:04:58 --> Controller Class Initialized
INFO - 2016-09-08 14:04:58 --> Database Driver Class Initialized
INFO - 2016-09-08 14:04:58 --> Model Class Initialized
INFO - 2016-09-08 14:04:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:04:58 --> Final output sent to browser
DEBUG - 2016-09-08 14:04:58 --> Total execution time: 0.0605
INFO - 2016-09-08 14:05:59 --> Config Class Initialized
INFO - 2016-09-08 14:05:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:05:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:05:59 --> Utf8 Class Initialized
INFO - 2016-09-08 14:05:59 --> URI Class Initialized
INFO - 2016-09-08 14:05:59 --> Router Class Initialized
INFO - 2016-09-08 14:05:59 --> Output Class Initialized
INFO - 2016-09-08 14:05:59 --> Security Class Initialized
DEBUG - 2016-09-08 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:05:59 --> Input Class Initialized
INFO - 2016-09-08 14:05:59 --> Language Class Initialized
INFO - 2016-09-08 14:05:59 --> Loader Class Initialized
INFO - 2016-09-08 14:05:59 --> Helper loaded: url_helper
INFO - 2016-09-08 14:05:59 --> Helper loaded: language_helper
INFO - 2016-09-08 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:05:59 --> Controller Class Initialized
INFO - 2016-09-08 14:05:59 --> Database Driver Class Initialized
INFO - 2016-09-08 14:05:59 --> Model Class Initialized
INFO - 2016-09-08 14:05:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:05:59 --> Config Class Initialized
INFO - 2016-09-08 14:05:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:05:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:05:59 --> Utf8 Class Initialized
INFO - 2016-09-08 14:05:59 --> URI Class Initialized
INFO - 2016-09-08 14:05:59 --> Router Class Initialized
INFO - 2016-09-08 14:05:59 --> Output Class Initialized
INFO - 2016-09-08 14:05:59 --> Security Class Initialized
DEBUG - 2016-09-08 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:05:59 --> Input Class Initialized
INFO - 2016-09-08 14:05:59 --> Language Class Initialized
INFO - 2016-09-08 14:05:59 --> Loader Class Initialized
INFO - 2016-09-08 14:05:59 --> Helper loaded: url_helper
INFO - 2016-09-08 14:05:59 --> Helper loaded: language_helper
INFO - 2016-09-08 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:05:59 --> Controller Class Initialized
INFO - 2016-09-08 14:05:59 --> Database Driver Class Initialized
INFO - 2016-09-08 14:05:59 --> Model Class Initialized
INFO - 2016-09-08 14:05:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:05:59 --> Final output sent to browser
DEBUG - 2016-09-08 14:05:59 --> Total execution time: 0.0589
INFO - 2016-09-08 14:06:04 --> Config Class Initialized
INFO - 2016-09-08 14:06:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:06:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:06:04 --> Utf8 Class Initialized
INFO - 2016-09-08 14:06:04 --> URI Class Initialized
INFO - 2016-09-08 14:06:04 --> Router Class Initialized
INFO - 2016-09-08 14:06:04 --> Output Class Initialized
INFO - 2016-09-08 14:06:04 --> Security Class Initialized
DEBUG - 2016-09-08 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:06:04 --> Input Class Initialized
INFO - 2016-09-08 14:06:04 --> Language Class Initialized
INFO - 2016-09-08 14:06:04 --> Loader Class Initialized
INFO - 2016-09-08 14:06:04 --> Helper loaded: url_helper
INFO - 2016-09-08 14:06:04 --> Helper loaded: language_helper
INFO - 2016-09-08 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:06:04 --> Controller Class Initialized
INFO - 2016-09-08 14:06:04 --> Database Driver Class Initialized
INFO - 2016-09-08 14:06:04 --> Model Class Initialized
INFO - 2016-09-08 14:06:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:06:04 --> Config Class Initialized
INFO - 2016-09-08 14:06:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:06:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:06:04 --> Utf8 Class Initialized
INFO - 2016-09-08 14:06:04 --> URI Class Initialized
INFO - 2016-09-08 14:06:04 --> Router Class Initialized
INFO - 2016-09-08 14:06:04 --> Output Class Initialized
INFO - 2016-09-08 14:06:04 --> Security Class Initialized
DEBUG - 2016-09-08 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:06:04 --> Input Class Initialized
INFO - 2016-09-08 14:06:04 --> Language Class Initialized
INFO - 2016-09-08 14:06:04 --> Loader Class Initialized
INFO - 2016-09-08 14:06:04 --> Helper loaded: url_helper
INFO - 2016-09-08 14:06:04 --> Helper loaded: language_helper
INFO - 2016-09-08 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:06:04 --> Controller Class Initialized
INFO - 2016-09-08 14:06:04 --> Database Driver Class Initialized
INFO - 2016-09-08 14:06:04 --> Model Class Initialized
INFO - 2016-09-08 14:06:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:06:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:06:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:06:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:06:04 --> Final output sent to browser
DEBUG - 2016-09-08 14:06:04 --> Total execution time: 0.0633
INFO - 2016-09-08 14:07:03 --> Config Class Initialized
INFO - 2016-09-08 14:07:03 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:07:03 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:07:03 --> Utf8 Class Initialized
INFO - 2016-09-08 14:07:03 --> URI Class Initialized
INFO - 2016-09-08 14:07:03 --> Router Class Initialized
INFO - 2016-09-08 14:07:03 --> Output Class Initialized
INFO - 2016-09-08 14:07:03 --> Security Class Initialized
DEBUG - 2016-09-08 14:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:07:03 --> Input Class Initialized
INFO - 2016-09-08 14:07:03 --> Language Class Initialized
INFO - 2016-09-08 14:07:03 --> Loader Class Initialized
INFO - 2016-09-08 14:07:03 --> Helper loaded: url_helper
INFO - 2016-09-08 14:07:03 --> Helper loaded: language_helper
INFO - 2016-09-08 14:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:07:03 --> Controller Class Initialized
INFO - 2016-09-08 14:07:03 --> Database Driver Class Initialized
INFO - 2016-09-08 14:07:03 --> Model Class Initialized
INFO - 2016-09-08 14:07:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:07:04 --> Config Class Initialized
INFO - 2016-09-08 14:07:04 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:07:04 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:07:04 --> Utf8 Class Initialized
INFO - 2016-09-08 14:07:04 --> URI Class Initialized
INFO - 2016-09-08 14:07:04 --> Router Class Initialized
INFO - 2016-09-08 14:07:04 --> Output Class Initialized
INFO - 2016-09-08 14:07:04 --> Security Class Initialized
DEBUG - 2016-09-08 14:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:07:04 --> Input Class Initialized
INFO - 2016-09-08 14:07:04 --> Language Class Initialized
INFO - 2016-09-08 14:07:04 --> Loader Class Initialized
INFO - 2016-09-08 14:07:04 --> Helper loaded: url_helper
INFO - 2016-09-08 14:07:04 --> Helper loaded: language_helper
INFO - 2016-09-08 14:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:07:04 --> Controller Class Initialized
INFO - 2016-09-08 14:07:04 --> Database Driver Class Initialized
INFO - 2016-09-08 14:07:04 --> Model Class Initialized
INFO - 2016-09-08 14:07:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:07:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:07:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:07:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:07:04 --> Final output sent to browser
DEBUG - 2016-09-08 14:07:04 --> Total execution time: 0.0763
INFO - 2016-09-08 14:07:08 --> Config Class Initialized
INFO - 2016-09-08 14:07:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:07:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:07:08 --> Utf8 Class Initialized
INFO - 2016-09-08 14:07:08 --> URI Class Initialized
INFO - 2016-09-08 14:07:08 --> Router Class Initialized
INFO - 2016-09-08 14:07:08 --> Output Class Initialized
INFO - 2016-09-08 14:07:08 --> Security Class Initialized
DEBUG - 2016-09-08 14:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:07:08 --> Input Class Initialized
INFO - 2016-09-08 14:07:08 --> Language Class Initialized
INFO - 2016-09-08 14:07:08 --> Loader Class Initialized
INFO - 2016-09-08 14:07:08 --> Helper loaded: url_helper
INFO - 2016-09-08 14:07:08 --> Helper loaded: language_helper
INFO - 2016-09-08 14:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:07:08 --> Controller Class Initialized
INFO - 2016-09-08 14:07:08 --> Database Driver Class Initialized
INFO - 2016-09-08 14:07:08 --> Model Class Initialized
INFO - 2016-09-08 14:07:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:07:08 --> Config Class Initialized
INFO - 2016-09-08 14:07:08 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:07:08 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:07:08 --> Utf8 Class Initialized
INFO - 2016-09-08 14:07:08 --> URI Class Initialized
INFO - 2016-09-08 14:07:08 --> Router Class Initialized
INFO - 2016-09-08 14:07:08 --> Output Class Initialized
INFO - 2016-09-08 14:07:08 --> Security Class Initialized
DEBUG - 2016-09-08 14:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:07:08 --> Input Class Initialized
INFO - 2016-09-08 14:07:08 --> Language Class Initialized
INFO - 2016-09-08 14:07:08 --> Loader Class Initialized
INFO - 2016-09-08 14:07:08 --> Helper loaded: url_helper
INFO - 2016-09-08 14:07:08 --> Helper loaded: language_helper
INFO - 2016-09-08 14:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:07:08 --> Controller Class Initialized
INFO - 2016-09-08 14:07:08 --> Database Driver Class Initialized
INFO - 2016-09-08 14:07:08 --> Model Class Initialized
INFO - 2016-09-08 14:07:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:07:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:07:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:07:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:07:08 --> Final output sent to browser
DEBUG - 2016-09-08 14:07:08 --> Total execution time: 0.0791
INFO - 2016-09-08 14:08:17 --> Config Class Initialized
INFO - 2016-09-08 14:08:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:08:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:08:17 --> Utf8 Class Initialized
INFO - 2016-09-08 14:08:17 --> URI Class Initialized
INFO - 2016-09-08 14:08:17 --> Router Class Initialized
INFO - 2016-09-08 14:08:17 --> Output Class Initialized
INFO - 2016-09-08 14:08:17 --> Security Class Initialized
DEBUG - 2016-09-08 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:08:17 --> Input Class Initialized
INFO - 2016-09-08 14:08:17 --> Language Class Initialized
INFO - 2016-09-08 14:08:17 --> Loader Class Initialized
INFO - 2016-09-08 14:08:17 --> Helper loaded: url_helper
INFO - 2016-09-08 14:08:17 --> Helper loaded: language_helper
INFO - 2016-09-08 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:08:17 --> Controller Class Initialized
INFO - 2016-09-08 14:08:17 --> Database Driver Class Initialized
INFO - 2016-09-08 14:08:17 --> Model Class Initialized
INFO - 2016-09-08 14:08:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:08:17 --> Config Class Initialized
INFO - 2016-09-08 14:08:17 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:08:17 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:08:17 --> Utf8 Class Initialized
INFO - 2016-09-08 14:08:17 --> URI Class Initialized
INFO - 2016-09-08 14:08:17 --> Router Class Initialized
INFO - 2016-09-08 14:08:17 --> Output Class Initialized
INFO - 2016-09-08 14:08:17 --> Security Class Initialized
DEBUG - 2016-09-08 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:08:17 --> Input Class Initialized
INFO - 2016-09-08 14:08:17 --> Language Class Initialized
INFO - 2016-09-08 14:08:17 --> Loader Class Initialized
INFO - 2016-09-08 14:08:17 --> Helper loaded: url_helper
INFO - 2016-09-08 14:08:17 --> Helper loaded: language_helper
INFO - 2016-09-08 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:08:17 --> Controller Class Initialized
INFO - 2016-09-08 14:08:17 --> Database Driver Class Initialized
INFO - 2016-09-08 14:08:17 --> Model Class Initialized
INFO - 2016-09-08 14:08:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:08:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:08:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:08:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:08:17 --> Final output sent to browser
DEBUG - 2016-09-08 14:08:17 --> Total execution time: 0.0623
INFO - 2016-09-08 14:08:26 --> Config Class Initialized
INFO - 2016-09-08 14:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:08:26 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:08:26 --> Utf8 Class Initialized
INFO - 2016-09-08 14:08:26 --> URI Class Initialized
INFO - 2016-09-08 14:08:26 --> Router Class Initialized
INFO - 2016-09-08 14:08:26 --> Output Class Initialized
INFO - 2016-09-08 14:08:26 --> Security Class Initialized
DEBUG - 2016-09-08 14:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:08:26 --> Input Class Initialized
INFO - 2016-09-08 14:08:26 --> Language Class Initialized
INFO - 2016-09-08 14:08:26 --> Loader Class Initialized
INFO - 2016-09-08 14:08:26 --> Helper loaded: url_helper
INFO - 2016-09-08 14:08:26 --> Helper loaded: language_helper
INFO - 2016-09-08 14:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:08:27 --> Controller Class Initialized
INFO - 2016-09-08 14:08:27 --> Database Driver Class Initialized
INFO - 2016-09-08 14:08:27 --> Model Class Initialized
INFO - 2016-09-08 14:08:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:08:27 --> Config Class Initialized
INFO - 2016-09-08 14:08:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:08:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:08:27 --> Utf8 Class Initialized
INFO - 2016-09-08 14:08:27 --> URI Class Initialized
INFO - 2016-09-08 14:08:27 --> Router Class Initialized
INFO - 2016-09-08 14:08:27 --> Output Class Initialized
INFO - 2016-09-08 14:08:27 --> Security Class Initialized
DEBUG - 2016-09-08 14:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:08:27 --> Input Class Initialized
INFO - 2016-09-08 14:08:27 --> Language Class Initialized
INFO - 2016-09-08 14:08:27 --> Loader Class Initialized
INFO - 2016-09-08 14:08:27 --> Helper loaded: url_helper
INFO - 2016-09-08 14:08:27 --> Helper loaded: language_helper
INFO - 2016-09-08 14:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:08:27 --> Controller Class Initialized
INFO - 2016-09-08 14:08:27 --> Database Driver Class Initialized
INFO - 2016-09-08 14:08:27 --> Model Class Initialized
INFO - 2016-09-08 14:08:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:08:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:08:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:08:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:08:27 --> Final output sent to browser
DEBUG - 2016-09-08 14:08:27 --> Total execution time: 0.0590
INFO - 2016-09-08 14:09:25 --> Config Class Initialized
INFO - 2016-09-08 14:09:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:09:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:09:25 --> Utf8 Class Initialized
INFO - 2016-09-08 14:09:25 --> URI Class Initialized
INFO - 2016-09-08 14:09:25 --> Router Class Initialized
INFO - 2016-09-08 14:09:25 --> Output Class Initialized
INFO - 2016-09-08 14:09:25 --> Security Class Initialized
DEBUG - 2016-09-08 14:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:09:25 --> Input Class Initialized
INFO - 2016-09-08 14:09:25 --> Language Class Initialized
INFO - 2016-09-08 14:09:25 --> Loader Class Initialized
INFO - 2016-09-08 14:09:25 --> Helper loaded: url_helper
INFO - 2016-09-08 14:09:25 --> Helper loaded: language_helper
INFO - 2016-09-08 14:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:09:25 --> Controller Class Initialized
INFO - 2016-09-08 14:09:25 --> Database Driver Class Initialized
INFO - 2016-09-08 14:09:25 --> Model Class Initialized
INFO - 2016-09-08 14:09:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:09:25 --> Config Class Initialized
INFO - 2016-09-08 14:09:25 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:09:25 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:09:25 --> Utf8 Class Initialized
INFO - 2016-09-08 14:09:25 --> URI Class Initialized
INFO - 2016-09-08 14:09:25 --> Router Class Initialized
INFO - 2016-09-08 14:09:25 --> Output Class Initialized
INFO - 2016-09-08 14:09:25 --> Security Class Initialized
DEBUG - 2016-09-08 14:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:09:25 --> Input Class Initialized
INFO - 2016-09-08 14:09:25 --> Language Class Initialized
INFO - 2016-09-08 14:09:25 --> Loader Class Initialized
INFO - 2016-09-08 14:09:25 --> Helper loaded: url_helper
INFO - 2016-09-08 14:09:25 --> Helper loaded: language_helper
INFO - 2016-09-08 14:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:09:25 --> Controller Class Initialized
INFO - 2016-09-08 14:09:25 --> Database Driver Class Initialized
INFO - 2016-09-08 14:09:25 --> Model Class Initialized
INFO - 2016-09-08 14:09:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:09:26 --> Final output sent to browser
DEBUG - 2016-09-08 14:09:26 --> Total execution time: 0.0555
INFO - 2016-09-08 14:09:59 --> Config Class Initialized
INFO - 2016-09-08 14:09:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:09:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:09:59 --> Utf8 Class Initialized
INFO - 2016-09-08 14:09:59 --> URI Class Initialized
INFO - 2016-09-08 14:09:59 --> Router Class Initialized
INFO - 2016-09-08 14:09:59 --> Output Class Initialized
INFO - 2016-09-08 14:09:59 --> Security Class Initialized
DEBUG - 2016-09-08 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:09:59 --> Input Class Initialized
INFO - 2016-09-08 14:09:59 --> Language Class Initialized
INFO - 2016-09-08 14:09:59 --> Loader Class Initialized
INFO - 2016-09-08 14:09:59 --> Helper loaded: url_helper
INFO - 2016-09-08 14:09:59 --> Helper loaded: language_helper
INFO - 2016-09-08 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:09:59 --> Controller Class Initialized
INFO - 2016-09-08 14:09:59 --> Database Driver Class Initialized
INFO - 2016-09-08 14:09:59 --> Model Class Initialized
INFO - 2016-09-08 14:09:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:09:59 --> Config Class Initialized
INFO - 2016-09-08 14:09:59 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:09:59 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:09:59 --> Utf8 Class Initialized
INFO - 2016-09-08 14:09:59 --> URI Class Initialized
INFO - 2016-09-08 14:09:59 --> Router Class Initialized
INFO - 2016-09-08 14:09:59 --> Output Class Initialized
INFO - 2016-09-08 14:09:59 --> Security Class Initialized
DEBUG - 2016-09-08 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:09:59 --> Input Class Initialized
INFO - 2016-09-08 14:09:59 --> Language Class Initialized
INFO - 2016-09-08 14:09:59 --> Loader Class Initialized
INFO - 2016-09-08 14:09:59 --> Helper loaded: url_helper
INFO - 2016-09-08 14:09:59 --> Helper loaded: language_helper
INFO - 2016-09-08 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:09:59 --> Controller Class Initialized
INFO - 2016-09-08 14:09:59 --> Database Driver Class Initialized
INFO - 2016-09-08 14:09:59 --> Model Class Initialized
INFO - 2016-09-08 14:09:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:09:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:09:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:09:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:09:59 --> Final output sent to browser
DEBUG - 2016-09-08 14:09:59 --> Total execution time: 0.0585
INFO - 2016-09-08 14:13:24 --> Config Class Initialized
INFO - 2016-09-08 14:13:24 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:13:24 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:13:24 --> Utf8 Class Initialized
INFO - 2016-09-08 14:13:24 --> URI Class Initialized
INFO - 2016-09-08 14:13:24 --> Router Class Initialized
INFO - 2016-09-08 14:13:24 --> Output Class Initialized
INFO - 2016-09-08 14:13:24 --> Security Class Initialized
DEBUG - 2016-09-08 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:13:24 --> Input Class Initialized
INFO - 2016-09-08 14:13:24 --> Language Class Initialized
INFO - 2016-09-08 14:13:24 --> Loader Class Initialized
INFO - 2016-09-08 14:13:24 --> Helper loaded: url_helper
INFO - 2016-09-08 14:13:24 --> Helper loaded: language_helper
INFO - 2016-09-08 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:13:24 --> Controller Class Initialized
INFO - 2016-09-08 14:13:24 --> Database Driver Class Initialized
INFO - 2016-09-08 14:13:24 --> Model Class Initialized
INFO - 2016-09-08 14:13:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:13:24 --> Config Class Initialized
INFO - 2016-09-08 14:13:24 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:13:24 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:13:24 --> Utf8 Class Initialized
INFO - 2016-09-08 14:13:24 --> URI Class Initialized
INFO - 2016-09-08 14:13:24 --> Router Class Initialized
INFO - 2016-09-08 14:13:24 --> Output Class Initialized
INFO - 2016-09-08 14:13:24 --> Security Class Initialized
DEBUG - 2016-09-08 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:13:24 --> Input Class Initialized
INFO - 2016-09-08 14:13:24 --> Language Class Initialized
INFO - 2016-09-08 14:13:24 --> Loader Class Initialized
INFO - 2016-09-08 14:13:24 --> Helper loaded: url_helper
INFO - 2016-09-08 14:13:24 --> Helper loaded: language_helper
INFO - 2016-09-08 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:13:24 --> Controller Class Initialized
INFO - 2016-09-08 14:13:24 --> Database Driver Class Initialized
INFO - 2016-09-08 14:13:24 --> Model Class Initialized
INFO - 2016-09-08 14:13:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:13:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:13:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:13:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:13:24 --> Final output sent to browser
DEBUG - 2016-09-08 14:13:24 --> Total execution time: 0.0644
INFO - 2016-09-08 14:13:27 --> Config Class Initialized
INFO - 2016-09-08 14:13:27 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:13:27 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:13:27 --> Utf8 Class Initialized
INFO - 2016-09-08 14:13:27 --> URI Class Initialized
INFO - 2016-09-08 14:13:27 --> Router Class Initialized
INFO - 2016-09-08 14:13:27 --> Output Class Initialized
INFO - 2016-09-08 14:13:27 --> Security Class Initialized
DEBUG - 2016-09-08 14:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:13:27 --> Input Class Initialized
INFO - 2016-09-08 14:13:27 --> Language Class Initialized
INFO - 2016-09-08 14:13:27 --> Loader Class Initialized
INFO - 2016-09-08 14:13:27 --> Helper loaded: url_helper
INFO - 2016-09-08 14:13:27 --> Helper loaded: language_helper
INFO - 2016-09-08 14:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:13:27 --> Controller Class Initialized
INFO - 2016-09-08 14:13:27 --> Database Driver Class Initialized
INFO - 2016-09-08 14:13:27 --> Model Class Initialized
INFO - 2016-09-08 14:13:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:13:27 --> Helper loaded: form_helper
INFO - 2016-09-08 14:13:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:13:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-08 14:13:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:13:27 --> Final output sent to browser
DEBUG - 2016-09-08 14:13:27 --> Total execution time: 0.0796
INFO - 2016-09-08 14:13:29 --> Config Class Initialized
INFO - 2016-09-08 14:13:29 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:13:29 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:13:29 --> Utf8 Class Initialized
INFO - 2016-09-08 14:13:29 --> URI Class Initialized
INFO - 2016-09-08 14:13:29 --> Router Class Initialized
INFO - 2016-09-08 14:13:29 --> Output Class Initialized
INFO - 2016-09-08 14:13:29 --> Security Class Initialized
DEBUG - 2016-09-08 14:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:13:29 --> Input Class Initialized
INFO - 2016-09-08 14:13:29 --> Language Class Initialized
INFO - 2016-09-08 14:13:29 --> Loader Class Initialized
INFO - 2016-09-08 14:13:29 --> Helper loaded: url_helper
INFO - 2016-09-08 14:13:29 --> Helper loaded: language_helper
INFO - 2016-09-08 14:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:13:29 --> Controller Class Initialized
INFO - 2016-09-08 14:13:29 --> Database Driver Class Initialized
INFO - 2016-09-08 14:13:29 --> Model Class Initialized
INFO - 2016-09-08 14:13:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:13:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-08 14:13:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:13:30 --> Final output sent to browser
DEBUG - 2016-09-08 14:13:30 --> Total execution time: 0.0646
INFO - 2016-09-08 14:14:07 --> Config Class Initialized
INFO - 2016-09-08 14:14:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:14:07 --> Utf8 Class Initialized
INFO - 2016-09-08 14:14:07 --> URI Class Initialized
INFO - 2016-09-08 14:14:07 --> Router Class Initialized
INFO - 2016-09-08 14:14:07 --> Output Class Initialized
INFO - 2016-09-08 14:14:07 --> Security Class Initialized
DEBUG - 2016-09-08 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:14:07 --> Input Class Initialized
INFO - 2016-09-08 14:14:07 --> Language Class Initialized
INFO - 2016-09-08 14:14:07 --> Loader Class Initialized
INFO - 2016-09-08 14:14:07 --> Helper loaded: url_helper
INFO - 2016-09-08 14:14:07 --> Helper loaded: language_helper
INFO - 2016-09-08 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:14:07 --> Controller Class Initialized
INFO - 2016-09-08 14:14:07 --> Database Driver Class Initialized
INFO - 2016-09-08 14:14:07 --> Model Class Initialized
INFO - 2016-09-08 14:14:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:14:07 --> Config Class Initialized
INFO - 2016-09-08 14:14:07 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:14:07 --> Utf8 Class Initialized
INFO - 2016-09-08 14:14:07 --> URI Class Initialized
INFO - 2016-09-08 14:14:07 --> Router Class Initialized
INFO - 2016-09-08 14:14:07 --> Output Class Initialized
INFO - 2016-09-08 14:14:07 --> Security Class Initialized
DEBUG - 2016-09-08 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:14:07 --> Input Class Initialized
INFO - 2016-09-08 14:14:07 --> Language Class Initialized
INFO - 2016-09-08 14:14:07 --> Loader Class Initialized
INFO - 2016-09-08 14:14:07 --> Helper loaded: url_helper
INFO - 2016-09-08 14:14:07 --> Helper loaded: language_helper
INFO - 2016-09-08 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:14:07 --> Controller Class Initialized
INFO - 2016-09-08 14:14:07 --> Database Driver Class Initialized
INFO - 2016-09-08 14:14:07 --> Model Class Initialized
INFO - 2016-09-08 14:14:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:14:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:14:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-08 14:14:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:14:07 --> Final output sent to browser
DEBUG - 2016-09-08 14:14:07 --> Total execution time: 0.0698
INFO - 2016-09-08 14:14:13 --> Config Class Initialized
INFO - 2016-09-08 14:14:13 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:14:13 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:14:13 --> Utf8 Class Initialized
INFO - 2016-09-08 14:14:13 --> URI Class Initialized
INFO - 2016-09-08 14:14:13 --> Router Class Initialized
INFO - 2016-09-08 14:14:13 --> Output Class Initialized
INFO - 2016-09-08 14:14:13 --> Security Class Initialized
DEBUG - 2016-09-08 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:14:13 --> Input Class Initialized
INFO - 2016-09-08 14:14:13 --> Language Class Initialized
INFO - 2016-09-08 14:14:13 --> Loader Class Initialized
INFO - 2016-09-08 14:14:13 --> Helper loaded: url_helper
INFO - 2016-09-08 14:14:13 --> Helper loaded: language_helper
INFO - 2016-09-08 14:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:14:13 --> Controller Class Initialized
INFO - 2016-09-08 14:14:13 --> Database Driver Class Initialized
INFO - 2016-09-08 14:14:13 --> Model Class Initialized
INFO - 2016-09-08 14:14:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:14:13 --> Final output sent to browser
DEBUG - 2016-09-08 14:14:13 --> Total execution time: 0.0627
INFO - 2016-09-08 14:14:18 --> Config Class Initialized
INFO - 2016-09-08 14:14:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:14:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:14:18 --> Utf8 Class Initialized
INFO - 2016-09-08 14:14:18 --> URI Class Initialized
INFO - 2016-09-08 14:14:18 --> Router Class Initialized
INFO - 2016-09-08 14:14:18 --> Output Class Initialized
INFO - 2016-09-08 14:14:18 --> Security Class Initialized
DEBUG - 2016-09-08 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:14:18 --> Input Class Initialized
INFO - 2016-09-08 14:14:18 --> Language Class Initialized
INFO - 2016-09-08 14:14:18 --> Loader Class Initialized
INFO - 2016-09-08 14:14:18 --> Helper loaded: url_helper
INFO - 2016-09-08 14:14:18 --> Helper loaded: language_helper
INFO - 2016-09-08 14:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:14:18 --> Controller Class Initialized
INFO - 2016-09-08 14:14:18 --> Database Driver Class Initialized
INFO - 2016-09-08 14:14:18 --> Model Class Initialized
INFO - 2016-09-08 14:14:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:14:18 --> Config Class Initialized
INFO - 2016-09-08 14:14:18 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:14:18 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:14:18 --> Utf8 Class Initialized
INFO - 2016-09-08 14:14:18 --> URI Class Initialized
INFO - 2016-09-08 14:14:18 --> Router Class Initialized
INFO - 2016-09-08 14:14:18 --> Output Class Initialized
INFO - 2016-09-08 14:14:18 --> Security Class Initialized
DEBUG - 2016-09-08 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:14:18 --> Input Class Initialized
INFO - 2016-09-08 14:14:18 --> Language Class Initialized
INFO - 2016-09-08 14:14:18 --> Loader Class Initialized
INFO - 2016-09-08 14:14:18 --> Helper loaded: url_helper
INFO - 2016-09-08 14:14:18 --> Helper loaded: language_helper
INFO - 2016-09-08 14:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:14:18 --> Controller Class Initialized
INFO - 2016-09-08 14:14:18 --> Database Driver Class Initialized
INFO - 2016-09-08 14:14:18 --> Model Class Initialized
INFO - 2016-09-08 14:14:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:14:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:14:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:14:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:14:18 --> Final output sent to browser
DEBUG - 2016-09-08 14:14:18 --> Total execution time: 0.0575
INFO - 2016-09-08 14:15:11 --> Config Class Initialized
INFO - 2016-09-08 14:15:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:11 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:11 --> URI Class Initialized
INFO - 2016-09-08 14:15:11 --> Router Class Initialized
INFO - 2016-09-08 14:15:11 --> Output Class Initialized
INFO - 2016-09-08 14:15:11 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:11 --> Input Class Initialized
INFO - 2016-09-08 14:15:11 --> Language Class Initialized
INFO - 2016-09-08 14:15:11 --> Loader Class Initialized
INFO - 2016-09-08 14:15:11 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:11 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:11 --> Controller Class Initialized
INFO - 2016-09-08 14:15:11 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:11 --> Model Class Initialized
INFO - 2016-09-08 14:15:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:11 --> Config Class Initialized
INFO - 2016-09-08 14:15:11 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:11 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:11 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:11 --> URI Class Initialized
INFO - 2016-09-08 14:15:11 --> Router Class Initialized
INFO - 2016-09-08 14:15:11 --> Output Class Initialized
INFO - 2016-09-08 14:15:11 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:11 --> Input Class Initialized
INFO - 2016-09-08 14:15:11 --> Language Class Initialized
INFO - 2016-09-08 14:15:11 --> Loader Class Initialized
INFO - 2016-09-08 14:15:11 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:11 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:11 --> Controller Class Initialized
INFO - 2016-09-08 14:15:11 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:11 --> Model Class Initialized
INFO - 2016-09-08 14:15:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:15:11 --> Final output sent to browser
DEBUG - 2016-09-08 14:15:11 --> Total execution time: 0.0573
INFO - 2016-09-08 14:15:16 --> Config Class Initialized
INFO - 2016-09-08 14:15:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:16 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:16 --> URI Class Initialized
INFO - 2016-09-08 14:15:16 --> Router Class Initialized
INFO - 2016-09-08 14:15:16 --> Output Class Initialized
INFO - 2016-09-08 14:15:16 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:16 --> Input Class Initialized
INFO - 2016-09-08 14:15:16 --> Language Class Initialized
INFO - 2016-09-08 14:15:16 --> Loader Class Initialized
INFO - 2016-09-08 14:15:16 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:16 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:16 --> Controller Class Initialized
INFO - 2016-09-08 14:15:16 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:16 --> Model Class Initialized
INFO - 2016-09-08 14:15:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:16 --> Config Class Initialized
INFO - 2016-09-08 14:15:16 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:16 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:16 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:16 --> URI Class Initialized
INFO - 2016-09-08 14:15:16 --> Router Class Initialized
INFO - 2016-09-08 14:15:16 --> Output Class Initialized
INFO - 2016-09-08 14:15:16 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:16 --> Input Class Initialized
INFO - 2016-09-08 14:15:16 --> Language Class Initialized
INFO - 2016-09-08 14:15:16 --> Loader Class Initialized
INFO - 2016-09-08 14:15:16 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:16 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:16 --> Controller Class Initialized
INFO - 2016-09-08 14:15:16 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:16 --> Model Class Initialized
INFO - 2016-09-08 14:15:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:15:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:15:16 --> Final output sent to browser
DEBUG - 2016-09-08 14:15:16 --> Total execution time: 0.0598
INFO - 2016-09-08 14:15:52 --> Config Class Initialized
INFO - 2016-09-08 14:15:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:52 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:52 --> URI Class Initialized
INFO - 2016-09-08 14:15:52 --> Router Class Initialized
INFO - 2016-09-08 14:15:52 --> Output Class Initialized
INFO - 2016-09-08 14:15:52 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:52 --> Input Class Initialized
INFO - 2016-09-08 14:15:52 --> Language Class Initialized
INFO - 2016-09-08 14:15:52 --> Loader Class Initialized
INFO - 2016-09-08 14:15:52 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:52 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:52 --> Controller Class Initialized
INFO - 2016-09-08 14:15:52 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:52 --> Model Class Initialized
INFO - 2016-09-08 14:15:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:52 --> Config Class Initialized
INFO - 2016-09-08 14:15:52 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:52 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:52 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:52 --> URI Class Initialized
INFO - 2016-09-08 14:15:52 --> Router Class Initialized
INFO - 2016-09-08 14:15:52 --> Output Class Initialized
INFO - 2016-09-08 14:15:52 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:52 --> Input Class Initialized
INFO - 2016-09-08 14:15:52 --> Language Class Initialized
INFO - 2016-09-08 14:15:52 --> Loader Class Initialized
INFO - 2016-09-08 14:15:52 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:52 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:52 --> Controller Class Initialized
INFO - 2016-09-08 14:15:52 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:52 --> Model Class Initialized
INFO - 2016-09-08 14:15:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:15:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:15:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:15:52 --> Final output sent to browser
DEBUG - 2016-09-08 14:15:52 --> Total execution time: 0.0546
INFO - 2016-09-08 14:15:58 --> Config Class Initialized
INFO - 2016-09-08 14:15:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:58 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:58 --> URI Class Initialized
INFO - 2016-09-08 14:15:58 --> Router Class Initialized
INFO - 2016-09-08 14:15:58 --> Output Class Initialized
INFO - 2016-09-08 14:15:58 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:58 --> Input Class Initialized
INFO - 2016-09-08 14:15:58 --> Language Class Initialized
INFO - 2016-09-08 14:15:58 --> Loader Class Initialized
INFO - 2016-09-08 14:15:58 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:58 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:58 --> Controller Class Initialized
INFO - 2016-09-08 14:15:58 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:58 --> Model Class Initialized
INFO - 2016-09-08 14:15:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:58 --> Config Class Initialized
INFO - 2016-09-08 14:15:58 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:15:58 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:15:58 --> Utf8 Class Initialized
INFO - 2016-09-08 14:15:58 --> URI Class Initialized
INFO - 2016-09-08 14:15:58 --> Router Class Initialized
INFO - 2016-09-08 14:15:58 --> Output Class Initialized
INFO - 2016-09-08 14:15:58 --> Security Class Initialized
DEBUG - 2016-09-08 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:15:58 --> Input Class Initialized
INFO - 2016-09-08 14:15:58 --> Language Class Initialized
INFO - 2016-09-08 14:15:58 --> Loader Class Initialized
INFO - 2016-09-08 14:15:58 --> Helper loaded: url_helper
INFO - 2016-09-08 14:15:58 --> Helper loaded: language_helper
INFO - 2016-09-08 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:15:58 --> Controller Class Initialized
INFO - 2016-09-08 14:15:58 --> Database Driver Class Initialized
INFO - 2016-09-08 14:15:58 --> Model Class Initialized
INFO - 2016-09-08 14:15:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:15:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:15:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:15:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:15:58 --> Final output sent to browser
DEBUG - 2016-09-08 14:15:58 --> Total execution time: 0.0716
INFO - 2016-09-08 14:16:34 --> Config Class Initialized
INFO - 2016-09-08 14:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:16:34 --> Utf8 Class Initialized
INFO - 2016-09-08 14:16:34 --> URI Class Initialized
INFO - 2016-09-08 14:16:34 --> Router Class Initialized
INFO - 2016-09-08 14:16:34 --> Output Class Initialized
INFO - 2016-09-08 14:16:34 --> Security Class Initialized
DEBUG - 2016-09-08 14:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:16:34 --> Input Class Initialized
INFO - 2016-09-08 14:16:34 --> Language Class Initialized
INFO - 2016-09-08 14:16:34 --> Loader Class Initialized
INFO - 2016-09-08 14:16:34 --> Helper loaded: url_helper
INFO - 2016-09-08 14:16:34 --> Helper loaded: language_helper
INFO - 2016-09-08 14:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:16:34 --> Controller Class Initialized
INFO - 2016-09-08 14:16:34 --> Database Driver Class Initialized
INFO - 2016-09-08 14:16:34 --> Model Class Initialized
INFO - 2016-09-08 14:16:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:16:34 --> Config Class Initialized
INFO - 2016-09-08 14:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:16:34 --> Utf8 Class Initialized
INFO - 2016-09-08 14:16:34 --> URI Class Initialized
INFO - 2016-09-08 14:16:34 --> Router Class Initialized
INFO - 2016-09-08 14:16:34 --> Output Class Initialized
INFO - 2016-09-08 14:16:34 --> Security Class Initialized
DEBUG - 2016-09-08 14:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:16:34 --> Input Class Initialized
INFO - 2016-09-08 14:16:34 --> Language Class Initialized
INFO - 2016-09-08 14:16:34 --> Loader Class Initialized
INFO - 2016-09-08 14:16:34 --> Helper loaded: url_helper
INFO - 2016-09-08 14:16:34 --> Helper loaded: language_helper
INFO - 2016-09-08 14:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:16:34 --> Controller Class Initialized
INFO - 2016-09-08 14:16:34 --> Database Driver Class Initialized
INFO - 2016-09-08 14:16:34 --> Model Class Initialized
INFO - 2016-09-08 14:16:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:16:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:16:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:16:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:16:34 --> Final output sent to browser
DEBUG - 2016-09-08 14:16:34 --> Total execution time: 0.0605
INFO - 2016-09-08 14:16:39 --> Config Class Initialized
INFO - 2016-09-08 14:16:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:16:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:16:39 --> Utf8 Class Initialized
INFO - 2016-09-08 14:16:39 --> URI Class Initialized
INFO - 2016-09-08 14:16:39 --> Router Class Initialized
INFO - 2016-09-08 14:16:39 --> Output Class Initialized
INFO - 2016-09-08 14:16:39 --> Security Class Initialized
DEBUG - 2016-09-08 14:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:16:39 --> Input Class Initialized
INFO - 2016-09-08 14:16:39 --> Language Class Initialized
INFO - 2016-09-08 14:16:39 --> Loader Class Initialized
INFO - 2016-09-08 14:16:39 --> Helper loaded: url_helper
INFO - 2016-09-08 14:16:39 --> Helper loaded: language_helper
INFO - 2016-09-08 14:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:16:39 --> Controller Class Initialized
INFO - 2016-09-08 14:16:39 --> Database Driver Class Initialized
INFO - 2016-09-08 14:16:39 --> Model Class Initialized
INFO - 2016-09-08 14:16:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:16:39 --> Config Class Initialized
INFO - 2016-09-08 14:16:39 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:16:39 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:16:39 --> Utf8 Class Initialized
INFO - 2016-09-08 14:16:39 --> URI Class Initialized
INFO - 2016-09-08 14:16:39 --> Router Class Initialized
INFO - 2016-09-08 14:16:39 --> Output Class Initialized
INFO - 2016-09-08 14:16:39 --> Security Class Initialized
DEBUG - 2016-09-08 14:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:16:39 --> Input Class Initialized
INFO - 2016-09-08 14:16:39 --> Language Class Initialized
INFO - 2016-09-08 14:16:39 --> Loader Class Initialized
INFO - 2016-09-08 14:16:39 --> Helper loaded: url_helper
INFO - 2016-09-08 14:16:39 --> Helper loaded: language_helper
INFO - 2016-09-08 14:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:16:39 --> Controller Class Initialized
INFO - 2016-09-08 14:16:39 --> Database Driver Class Initialized
INFO - 2016-09-08 14:16:39 --> Model Class Initialized
INFO - 2016-09-08 14:16:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_2.php
INFO - 2016-09-08 14:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:16:39 --> Final output sent to browser
DEBUG - 2016-09-08 14:16:39 --> Total execution time: 0.0650
INFO - 2016-09-08 14:17:28 --> Config Class Initialized
INFO - 2016-09-08 14:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:17:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:17:28 --> Utf8 Class Initialized
INFO - 2016-09-08 14:17:28 --> URI Class Initialized
INFO - 2016-09-08 14:17:28 --> Router Class Initialized
INFO - 2016-09-08 14:17:28 --> Output Class Initialized
INFO - 2016-09-08 14:17:28 --> Security Class Initialized
DEBUG - 2016-09-08 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:17:28 --> Input Class Initialized
INFO - 2016-09-08 14:17:28 --> Language Class Initialized
INFO - 2016-09-08 14:17:28 --> Loader Class Initialized
INFO - 2016-09-08 14:17:28 --> Helper loaded: url_helper
INFO - 2016-09-08 14:17:28 --> Helper loaded: language_helper
INFO - 2016-09-08 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:17:28 --> Controller Class Initialized
INFO - 2016-09-08 14:17:28 --> Database Driver Class Initialized
INFO - 2016-09-08 14:17:28 --> Model Class Initialized
INFO - 2016-09-08 14:17:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:17:28 --> Config Class Initialized
INFO - 2016-09-08 14:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-08 14:17:28 --> UTF-8 Support Enabled
INFO - 2016-09-08 14:17:28 --> Utf8 Class Initialized
INFO - 2016-09-08 14:17:28 --> URI Class Initialized
INFO - 2016-09-08 14:17:28 --> Router Class Initialized
INFO - 2016-09-08 14:17:28 --> Output Class Initialized
INFO - 2016-09-08 14:17:28 --> Security Class Initialized
DEBUG - 2016-09-08 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-08 14:17:28 --> Input Class Initialized
INFO - 2016-09-08 14:17:28 --> Language Class Initialized
INFO - 2016-09-08 14:17:28 --> Loader Class Initialized
INFO - 2016-09-08 14:17:28 --> Helper loaded: url_helper
INFO - 2016-09-08 14:17:28 --> Helper loaded: language_helper
INFO - 2016-09-08 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-08 14:17:28 --> Controller Class Initialized
INFO - 2016-09-08 14:17:28 --> Database Driver Class Initialized
INFO - 2016-09-08 14:17:28 --> Model Class Initialized
INFO - 2016-09-08 14:17:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-08 14:17:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-08 14:17:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-08 14:17:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-08 14:17:28 --> Final output sent to browser
DEBUG - 2016-09-08 14:17:28 --> Total execution time: 0.0538
