<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-09 12:22:33 --> Config Class Initialized
INFO - 2016-09-09 12:22:33 --> Hooks Class Initialized
DEBUG - 2016-09-09 12:22:33 --> UTF-8 Support Enabled
INFO - 2016-09-09 12:22:33 --> Utf8 Class Initialized
INFO - 2016-09-09 12:22:33 --> URI Class Initialized
INFO - 2016-09-09 12:22:33 --> Router Class Initialized
INFO - 2016-09-09 12:22:33 --> Output Class Initialized
INFO - 2016-09-09 12:22:33 --> Security Class Initialized
DEBUG - 2016-09-09 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 12:22:33 --> Input Class Initialized
INFO - 2016-09-09 12:22:33 --> Language Class Initialized
INFO - 2016-09-09 12:22:33 --> Loader Class Initialized
INFO - 2016-09-09 12:22:33 --> Helper loaded: url_helper
INFO - 2016-09-09 12:22:33 --> Helper loaded: language_helper
INFO - 2016-09-09 12:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 12:22:34 --> Controller Class Initialized
INFO - 2016-09-09 12:22:34 --> Database Driver Class Initialized
INFO - 2016-09-09 12:22:34 --> Model Class Initialized
INFO - 2016-09-09 12:22:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 12:22:34 --> Config Class Initialized
INFO - 2016-09-09 12:22:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 12:22:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 12:22:34 --> Utf8 Class Initialized
INFO - 2016-09-09 12:22:34 --> URI Class Initialized
INFO - 2016-09-09 12:22:34 --> Router Class Initialized
INFO - 2016-09-09 12:22:34 --> Output Class Initialized
INFO - 2016-09-09 12:22:34 --> Security Class Initialized
DEBUG - 2016-09-09 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 12:22:34 --> Input Class Initialized
INFO - 2016-09-09 12:22:34 --> Language Class Initialized
INFO - 2016-09-09 12:22:34 --> Loader Class Initialized
INFO - 2016-09-09 12:22:34 --> Helper loaded: url_helper
INFO - 2016-09-09 12:22:34 --> Helper loaded: language_helper
INFO - 2016-09-09 12:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 12:22:34 --> Controller Class Initialized
INFO - 2016-09-09 12:22:34 --> Database Driver Class Initialized
INFO - 2016-09-09 12:22:34 --> Model Class Initialized
INFO - 2016-09-09 12:22:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 12:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-09 12:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-09 12:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-09 12:22:34 --> Final output sent to browser
DEBUG - 2016-09-09 12:22:34 --> Total execution time: 0.2091
INFO - 2016-09-09 13:05:53 --> Config Class Initialized
INFO - 2016-09-09 13:05:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:05:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:05:53 --> Utf8 Class Initialized
INFO - 2016-09-09 13:05:53 --> URI Class Initialized
INFO - 2016-09-09 13:05:53 --> Router Class Initialized
INFO - 2016-09-09 13:05:53 --> Output Class Initialized
INFO - 2016-09-09 13:05:53 --> Security Class Initialized
DEBUG - 2016-09-09 13:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:05:53 --> Input Class Initialized
INFO - 2016-09-09 13:05:53 --> Language Class Initialized
INFO - 2016-09-09 13:05:53 --> Loader Class Initialized
INFO - 2016-09-09 13:05:53 --> Helper loaded: url_helper
INFO - 2016-09-09 13:05:53 --> Helper loaded: language_helper
INFO - 2016-09-09 13:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:05:53 --> Controller Class Initialized
INFO - 2016-09-09 13:05:53 --> Database Driver Class Initialized
INFO - 2016-09-09 13:05:53 --> Model Class Initialized
INFO - 2016-09-09 13:05:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:05:53 --> Config Class Initialized
INFO - 2016-09-09 13:05:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:05:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:05:53 --> Utf8 Class Initialized
INFO - 2016-09-09 13:05:53 --> URI Class Initialized
INFO - 2016-09-09 13:05:53 --> Router Class Initialized
INFO - 2016-09-09 13:05:53 --> Output Class Initialized
INFO - 2016-09-09 13:05:53 --> Security Class Initialized
DEBUG - 2016-09-09 13:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:05:53 --> Input Class Initialized
INFO - 2016-09-09 13:05:53 --> Language Class Initialized
INFO - 2016-09-09 13:05:53 --> Loader Class Initialized
INFO - 2016-09-09 13:05:53 --> Helper loaded: url_helper
INFO - 2016-09-09 13:05:53 --> Helper loaded: language_helper
INFO - 2016-09-09 13:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:05:53 --> Controller Class Initialized
INFO - 2016-09-09 13:05:53 --> Database Driver Class Initialized
INFO - 2016-09-09 13:05:53 --> Model Class Initialized
INFO - 2016-09-09 13:05:53 --> Model Class Initialized
INFO - 2016-09-09 13:05:53 --> Model Class Initialized
INFO - 2016-09-09 13:05:53 --> Model Class Initialized
INFO - 2016-09-09 13:05:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:05:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:05:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-09 13:05:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:05:53 --> Final output sent to browser
DEBUG - 2016-09-09 13:05:53 --> Total execution time: 0.0750
INFO - 2016-09-09 13:18:22 --> Config Class Initialized
INFO - 2016-09-09 13:18:22 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:18:22 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:18:22 --> Utf8 Class Initialized
INFO - 2016-09-09 13:18:22 --> URI Class Initialized
INFO - 2016-09-09 13:18:22 --> Router Class Initialized
INFO - 2016-09-09 13:18:22 --> Output Class Initialized
INFO - 2016-09-09 13:18:22 --> Security Class Initialized
DEBUG - 2016-09-09 13:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:18:22 --> Input Class Initialized
INFO - 2016-09-09 13:18:22 --> Language Class Initialized
INFO - 2016-09-09 13:18:22 --> Loader Class Initialized
INFO - 2016-09-09 13:18:22 --> Helper loaded: url_helper
INFO - 2016-09-09 13:18:22 --> Helper loaded: language_helper
INFO - 2016-09-09 13:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:18:22 --> Controller Class Initialized
INFO - 2016-09-09 13:18:22 --> Database Driver Class Initialized
INFO - 2016-09-09 13:18:22 --> Model Class Initialized
INFO - 2016-09-09 13:18:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:18:22 --> Helper loaded: form_helper
ERROR - 2016-09-09 13:18:22 --> Severity: error --> Exception: Call to undefined method Hasil_model::hasil_list() C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 38
INFO - 2016-09-09 13:18:34 --> Config Class Initialized
INFO - 2016-09-09 13:18:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:18:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:18:34 --> Utf8 Class Initialized
INFO - 2016-09-09 13:18:34 --> URI Class Initialized
INFO - 2016-09-09 13:18:34 --> Router Class Initialized
INFO - 2016-09-09 13:18:34 --> Output Class Initialized
INFO - 2016-09-09 13:18:34 --> Security Class Initialized
DEBUG - 2016-09-09 13:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:18:34 --> Input Class Initialized
INFO - 2016-09-09 13:18:34 --> Language Class Initialized
INFO - 2016-09-09 13:18:34 --> Loader Class Initialized
INFO - 2016-09-09 13:18:34 --> Helper loaded: url_helper
INFO - 2016-09-09 13:18:34 --> Helper loaded: language_helper
INFO - 2016-09-09 13:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:18:34 --> Controller Class Initialized
INFO - 2016-09-09 13:18:34 --> Database Driver Class Initialized
INFO - 2016-09-09 13:18:34 --> Model Class Initialized
INFO - 2016-09-09 13:18:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:18:34 --> Helper loaded: form_helper
INFO - 2016-09-09 13:18:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:18:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-09 13:18:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:18:34 --> Final output sent to browser
DEBUG - 2016-09-09 13:18:34 --> Total execution time: 0.0617
INFO - 2016-09-09 13:19:11 --> Config Class Initialized
INFO - 2016-09-09 13:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:19:11 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:19:11 --> Utf8 Class Initialized
INFO - 2016-09-09 13:19:11 --> URI Class Initialized
INFO - 2016-09-09 13:19:11 --> Router Class Initialized
INFO - 2016-09-09 13:19:11 --> Output Class Initialized
INFO - 2016-09-09 13:19:11 --> Security Class Initialized
DEBUG - 2016-09-09 13:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:19:11 --> Input Class Initialized
INFO - 2016-09-09 13:19:11 --> Language Class Initialized
INFO - 2016-09-09 13:19:11 --> Loader Class Initialized
INFO - 2016-09-09 13:19:11 --> Helper loaded: url_helper
INFO - 2016-09-09 13:19:11 --> Helper loaded: language_helper
INFO - 2016-09-09 13:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:19:11 --> Controller Class Initialized
INFO - 2016-09-09 13:19:11 --> Database Driver Class Initialized
INFO - 2016-09-09 13:19:11 --> Model Class Initialized
INFO - 2016-09-09 13:19:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:19:11 --> Helper loaded: form_helper
INFO - 2016-09-09 13:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-09 13:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:19:11 --> Final output sent to browser
DEBUG - 2016-09-09 13:19:11 --> Total execution time: 0.0599
INFO - 2016-09-09 13:23:20 --> Config Class Initialized
INFO - 2016-09-09 13:23:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:23:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:23:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:23:20 --> URI Class Initialized
INFO - 2016-09-09 13:23:20 --> Router Class Initialized
INFO - 2016-09-09 13:23:20 --> Output Class Initialized
INFO - 2016-09-09 13:23:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:23:20 --> Input Class Initialized
INFO - 2016-09-09 13:23:20 --> Language Class Initialized
INFO - 2016-09-09 13:23:20 --> Loader Class Initialized
INFO - 2016-09-09 13:23:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:23:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:23:20 --> Controller Class Initialized
INFO - 2016-09-09 13:23:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:23:20 --> Model Class Initialized
INFO - 2016-09-09 13:23:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:23:20 --> Helper loaded: form_helper
INFO - 2016-09-09 13:23:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:23:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 13:23:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:23:20 --> Final output sent to browser
DEBUG - 2016-09-09 13:23:20 --> Total execution time: 0.0802
INFO - 2016-09-09 13:24:03 --> Config Class Initialized
INFO - 2016-09-09 13:24:03 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:24:03 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:24:03 --> Utf8 Class Initialized
INFO - 2016-09-09 13:24:03 --> URI Class Initialized
INFO - 2016-09-09 13:24:03 --> Router Class Initialized
INFO - 2016-09-09 13:24:03 --> Output Class Initialized
INFO - 2016-09-09 13:24:03 --> Security Class Initialized
DEBUG - 2016-09-09 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:24:03 --> Input Class Initialized
INFO - 2016-09-09 13:24:03 --> Language Class Initialized
INFO - 2016-09-09 13:24:03 --> Loader Class Initialized
INFO - 2016-09-09 13:24:03 --> Helper loaded: url_helper
INFO - 2016-09-09 13:24:03 --> Helper loaded: language_helper
INFO - 2016-09-09 13:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:24:03 --> Controller Class Initialized
INFO - 2016-09-09 13:24:03 --> Database Driver Class Initialized
INFO - 2016-09-09 13:24:03 --> Model Class Initialized
INFO - 2016-09-09 13:24:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:24:03 --> Final output sent to browser
DEBUG - 2016-09-09 13:24:03 --> Total execution time: 0.0553
INFO - 2016-09-09 13:24:34 --> Config Class Initialized
INFO - 2016-09-09 13:24:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:24:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:24:34 --> Utf8 Class Initialized
INFO - 2016-09-09 13:24:34 --> URI Class Initialized
INFO - 2016-09-09 13:24:34 --> Router Class Initialized
INFO - 2016-09-09 13:24:34 --> Output Class Initialized
INFO - 2016-09-09 13:24:34 --> Security Class Initialized
DEBUG - 2016-09-09 13:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:24:34 --> Input Class Initialized
INFO - 2016-09-09 13:24:34 --> Language Class Initialized
INFO - 2016-09-09 13:24:34 --> Loader Class Initialized
INFO - 2016-09-09 13:24:34 --> Helper loaded: url_helper
INFO - 2016-09-09 13:24:34 --> Helper loaded: language_helper
INFO - 2016-09-09 13:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:24:34 --> Controller Class Initialized
INFO - 2016-09-09 13:24:34 --> Database Driver Class Initialized
INFO - 2016-09-09 13:24:34 --> Model Class Initialized
INFO - 2016-09-09 13:24:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:24:34 --> Config Class Initialized
INFO - 2016-09-09 13:24:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:24:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:24:34 --> Utf8 Class Initialized
INFO - 2016-09-09 13:24:34 --> URI Class Initialized
INFO - 2016-09-09 13:24:34 --> Router Class Initialized
INFO - 2016-09-09 13:24:34 --> Output Class Initialized
INFO - 2016-09-09 13:24:34 --> Security Class Initialized
DEBUG - 2016-09-09 13:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:24:34 --> Input Class Initialized
INFO - 2016-09-09 13:24:34 --> Language Class Initialized
INFO - 2016-09-09 13:24:34 --> Loader Class Initialized
INFO - 2016-09-09 13:24:34 --> Helper loaded: url_helper
INFO - 2016-09-09 13:24:34 --> Helper loaded: language_helper
INFO - 2016-09-09 13:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:24:34 --> Controller Class Initialized
INFO - 2016-09-09 13:24:34 --> Database Driver Class Initialized
INFO - 2016-09-09 13:24:34 --> Model Class Initialized
INFO - 2016-09-09 13:24:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:24:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:24:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:24:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:24:34 --> Final output sent to browser
DEBUG - 2016-09-09 13:24:34 --> Total execution time: 0.0619
INFO - 2016-09-09 13:27:35 --> Config Class Initialized
INFO - 2016-09-09 13:27:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:27:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:27:35 --> Utf8 Class Initialized
INFO - 2016-09-09 13:27:35 --> URI Class Initialized
INFO - 2016-09-09 13:27:35 --> Router Class Initialized
INFO - 2016-09-09 13:27:35 --> Output Class Initialized
INFO - 2016-09-09 13:27:35 --> Security Class Initialized
DEBUG - 2016-09-09 13:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:27:35 --> Input Class Initialized
INFO - 2016-09-09 13:27:35 --> Language Class Initialized
INFO - 2016-09-09 13:27:35 --> Loader Class Initialized
INFO - 2016-09-09 13:27:35 --> Helper loaded: url_helper
INFO - 2016-09-09 13:27:35 --> Helper loaded: language_helper
INFO - 2016-09-09 13:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:27:35 --> Controller Class Initialized
INFO - 2016-09-09 13:27:35 --> Database Driver Class Initialized
INFO - 2016-09-09 13:27:35 --> Model Class Initialized
INFO - 2016-09-09 13:27:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:27:35 --> Config Class Initialized
INFO - 2016-09-09 13:27:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:27:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:27:35 --> Utf8 Class Initialized
INFO - 2016-09-09 13:27:35 --> URI Class Initialized
INFO - 2016-09-09 13:27:35 --> Router Class Initialized
INFO - 2016-09-09 13:27:35 --> Output Class Initialized
INFO - 2016-09-09 13:27:35 --> Security Class Initialized
DEBUG - 2016-09-09 13:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:27:35 --> Input Class Initialized
INFO - 2016-09-09 13:27:35 --> Language Class Initialized
INFO - 2016-09-09 13:27:35 --> Loader Class Initialized
INFO - 2016-09-09 13:27:35 --> Helper loaded: url_helper
INFO - 2016-09-09 13:27:35 --> Helper loaded: language_helper
INFO - 2016-09-09 13:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:27:35 --> Controller Class Initialized
INFO - 2016-09-09 13:27:35 --> Database Driver Class Initialized
INFO - 2016-09-09 13:27:35 --> Model Class Initialized
INFO - 2016-09-09 13:27:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:27:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:27:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:27:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:27:35 --> Final output sent to browser
DEBUG - 2016-09-09 13:27:35 --> Total execution time: 0.0622
INFO - 2016-09-09 13:27:42 --> Config Class Initialized
INFO - 2016-09-09 13:27:42 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:27:42 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:27:42 --> Utf8 Class Initialized
INFO - 2016-09-09 13:27:42 --> URI Class Initialized
INFO - 2016-09-09 13:27:42 --> Router Class Initialized
INFO - 2016-09-09 13:27:42 --> Output Class Initialized
INFO - 2016-09-09 13:27:42 --> Security Class Initialized
DEBUG - 2016-09-09 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:27:42 --> Input Class Initialized
INFO - 2016-09-09 13:27:42 --> Language Class Initialized
INFO - 2016-09-09 13:27:42 --> Loader Class Initialized
INFO - 2016-09-09 13:27:42 --> Helper loaded: url_helper
INFO - 2016-09-09 13:27:42 --> Helper loaded: language_helper
INFO - 2016-09-09 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:27:42 --> Controller Class Initialized
INFO - 2016-09-09 13:27:42 --> Database Driver Class Initialized
INFO - 2016-09-09 13:27:42 --> Model Class Initialized
INFO - 2016-09-09 13:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:27:42 --> Helper loaded: form_helper
INFO - 2016-09-09 13:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 13:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:27:42 --> Final output sent to browser
DEBUG - 2016-09-09 13:27:42 --> Total execution time: 0.0804
INFO - 2016-09-09 13:27:48 --> Config Class Initialized
INFO - 2016-09-09 13:27:48 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:27:48 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:27:48 --> Utf8 Class Initialized
INFO - 2016-09-09 13:27:48 --> URI Class Initialized
INFO - 2016-09-09 13:27:48 --> Router Class Initialized
INFO - 2016-09-09 13:27:48 --> Output Class Initialized
INFO - 2016-09-09 13:27:48 --> Security Class Initialized
DEBUG - 2016-09-09 13:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:27:48 --> Input Class Initialized
INFO - 2016-09-09 13:27:48 --> Language Class Initialized
INFO - 2016-09-09 13:27:48 --> Loader Class Initialized
INFO - 2016-09-09 13:27:48 --> Helper loaded: url_helper
INFO - 2016-09-09 13:27:48 --> Helper loaded: language_helper
INFO - 2016-09-09 13:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:27:48 --> Controller Class Initialized
INFO - 2016-09-09 13:27:48 --> Database Driver Class Initialized
INFO - 2016-09-09 13:27:48 --> Model Class Initialized
INFO - 2016-09-09 13:27:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:27:48 --> Config Class Initialized
INFO - 2016-09-09 13:27:48 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:27:48 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:27:48 --> Utf8 Class Initialized
INFO - 2016-09-09 13:27:48 --> URI Class Initialized
INFO - 2016-09-09 13:27:48 --> Router Class Initialized
INFO - 2016-09-09 13:27:48 --> Output Class Initialized
INFO - 2016-09-09 13:27:48 --> Security Class Initialized
DEBUG - 2016-09-09 13:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:27:48 --> Input Class Initialized
INFO - 2016-09-09 13:27:48 --> Language Class Initialized
INFO - 2016-09-09 13:27:48 --> Loader Class Initialized
INFO - 2016-09-09 13:27:48 --> Helper loaded: url_helper
INFO - 2016-09-09 13:27:48 --> Helper loaded: language_helper
INFO - 2016-09-09 13:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:27:48 --> Controller Class Initialized
INFO - 2016-09-09 13:27:48 --> Database Driver Class Initialized
INFO - 2016-09-09 13:27:48 --> Model Class Initialized
INFO - 2016-09-09 13:27:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:27:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:27:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:27:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:27:48 --> Final output sent to browser
DEBUG - 2016-09-09 13:27:48 --> Total execution time: 0.0596
INFO - 2016-09-09 13:28:46 --> Config Class Initialized
INFO - 2016-09-09 13:28:46 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:28:46 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:28:46 --> Utf8 Class Initialized
INFO - 2016-09-09 13:28:46 --> URI Class Initialized
INFO - 2016-09-09 13:28:46 --> Router Class Initialized
INFO - 2016-09-09 13:28:46 --> Output Class Initialized
INFO - 2016-09-09 13:28:46 --> Security Class Initialized
DEBUG - 2016-09-09 13:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:28:46 --> Input Class Initialized
INFO - 2016-09-09 13:28:46 --> Language Class Initialized
INFO - 2016-09-09 13:28:46 --> Loader Class Initialized
INFO - 2016-09-09 13:28:46 --> Helper loaded: url_helper
INFO - 2016-09-09 13:28:46 --> Helper loaded: language_helper
INFO - 2016-09-09 13:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:28:46 --> Controller Class Initialized
INFO - 2016-09-09 13:28:46 --> Database Driver Class Initialized
INFO - 2016-09-09 13:28:46 --> Model Class Initialized
INFO - 2016-09-09 13:28:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:28:46 --> Config Class Initialized
INFO - 2016-09-09 13:28:46 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:28:46 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:28:46 --> Utf8 Class Initialized
INFO - 2016-09-09 13:28:46 --> URI Class Initialized
INFO - 2016-09-09 13:28:46 --> Router Class Initialized
INFO - 2016-09-09 13:28:46 --> Output Class Initialized
INFO - 2016-09-09 13:28:46 --> Security Class Initialized
DEBUG - 2016-09-09 13:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:28:46 --> Input Class Initialized
INFO - 2016-09-09 13:28:46 --> Language Class Initialized
INFO - 2016-09-09 13:28:46 --> Loader Class Initialized
INFO - 2016-09-09 13:28:46 --> Helper loaded: url_helper
INFO - 2016-09-09 13:28:46 --> Helper loaded: language_helper
INFO - 2016-09-09 13:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:28:46 --> Controller Class Initialized
INFO - 2016-09-09 13:28:46 --> Database Driver Class Initialized
INFO - 2016-09-09 13:28:46 --> Model Class Initialized
INFO - 2016-09-09 13:28:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:28:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:28:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:28:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:28:46 --> Final output sent to browser
DEBUG - 2016-09-09 13:28:46 --> Total execution time: 0.0545
INFO - 2016-09-09 13:28:50 --> Config Class Initialized
INFO - 2016-09-09 13:28:50 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:28:50 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:28:50 --> Utf8 Class Initialized
INFO - 2016-09-09 13:28:50 --> URI Class Initialized
INFO - 2016-09-09 13:28:50 --> Router Class Initialized
INFO - 2016-09-09 13:28:50 --> Output Class Initialized
INFO - 2016-09-09 13:28:50 --> Security Class Initialized
DEBUG - 2016-09-09 13:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:28:50 --> Input Class Initialized
INFO - 2016-09-09 13:28:50 --> Language Class Initialized
INFO - 2016-09-09 13:28:50 --> Loader Class Initialized
INFO - 2016-09-09 13:28:50 --> Helper loaded: url_helper
INFO - 2016-09-09 13:28:50 --> Helper loaded: language_helper
INFO - 2016-09-09 13:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:28:50 --> Controller Class Initialized
INFO - 2016-09-09 13:28:50 --> Database Driver Class Initialized
INFO - 2016-09-09 13:28:50 --> Model Class Initialized
INFO - 2016-09-09 13:28:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:28:50 --> Config Class Initialized
INFO - 2016-09-09 13:28:50 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:28:50 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:28:50 --> Utf8 Class Initialized
INFO - 2016-09-09 13:28:50 --> URI Class Initialized
INFO - 2016-09-09 13:28:50 --> Router Class Initialized
INFO - 2016-09-09 13:28:50 --> Output Class Initialized
INFO - 2016-09-09 13:28:50 --> Security Class Initialized
DEBUG - 2016-09-09 13:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:28:50 --> Input Class Initialized
INFO - 2016-09-09 13:28:50 --> Language Class Initialized
INFO - 2016-09-09 13:28:50 --> Loader Class Initialized
INFO - 2016-09-09 13:28:50 --> Helper loaded: url_helper
INFO - 2016-09-09 13:28:50 --> Helper loaded: language_helper
INFO - 2016-09-09 13:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:28:50 --> Controller Class Initialized
INFO - 2016-09-09 13:28:50 --> Database Driver Class Initialized
INFO - 2016-09-09 13:28:50 --> Model Class Initialized
INFO - 2016-09-09 13:28:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:28:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:28:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:28:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:28:50 --> Final output sent to browser
DEBUG - 2016-09-09 13:28:50 --> Total execution time: 0.0583
INFO - 2016-09-09 13:29:52 --> Config Class Initialized
INFO - 2016-09-09 13:29:52 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:29:52 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:29:52 --> Utf8 Class Initialized
INFO - 2016-09-09 13:29:52 --> URI Class Initialized
INFO - 2016-09-09 13:29:52 --> Router Class Initialized
INFO - 2016-09-09 13:29:52 --> Output Class Initialized
INFO - 2016-09-09 13:29:52 --> Security Class Initialized
DEBUG - 2016-09-09 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:29:52 --> Input Class Initialized
INFO - 2016-09-09 13:29:52 --> Language Class Initialized
INFO - 2016-09-09 13:29:52 --> Loader Class Initialized
INFO - 2016-09-09 13:29:52 --> Helper loaded: url_helper
INFO - 2016-09-09 13:29:52 --> Helper loaded: language_helper
INFO - 2016-09-09 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:29:52 --> Controller Class Initialized
INFO - 2016-09-09 13:29:52 --> Database Driver Class Initialized
INFO - 2016-09-09 13:29:52 --> Model Class Initialized
INFO - 2016-09-09 13:29:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:29:52 --> Config Class Initialized
INFO - 2016-09-09 13:29:52 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:29:52 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:29:52 --> Utf8 Class Initialized
INFO - 2016-09-09 13:29:52 --> URI Class Initialized
INFO - 2016-09-09 13:29:52 --> Router Class Initialized
INFO - 2016-09-09 13:29:52 --> Output Class Initialized
INFO - 2016-09-09 13:29:52 --> Security Class Initialized
DEBUG - 2016-09-09 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:29:52 --> Input Class Initialized
INFO - 2016-09-09 13:29:52 --> Language Class Initialized
INFO - 2016-09-09 13:29:52 --> Loader Class Initialized
INFO - 2016-09-09 13:29:52 --> Helper loaded: url_helper
INFO - 2016-09-09 13:29:52 --> Helper loaded: language_helper
INFO - 2016-09-09 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:29:52 --> Controller Class Initialized
INFO - 2016-09-09 13:29:52 --> Database Driver Class Initialized
INFO - 2016-09-09 13:29:52 --> Model Class Initialized
INFO - 2016-09-09 13:29:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:29:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:29:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:29:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:29:52 --> Final output sent to browser
DEBUG - 2016-09-09 13:29:52 --> Total execution time: 0.0571
INFO - 2016-09-09 13:29:53 --> Config Class Initialized
INFO - 2016-09-09 13:29:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:29:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:29:53 --> Utf8 Class Initialized
INFO - 2016-09-09 13:29:53 --> URI Class Initialized
INFO - 2016-09-09 13:29:53 --> Router Class Initialized
INFO - 2016-09-09 13:29:53 --> Output Class Initialized
INFO - 2016-09-09 13:29:53 --> Security Class Initialized
DEBUG - 2016-09-09 13:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:29:53 --> Input Class Initialized
INFO - 2016-09-09 13:29:53 --> Language Class Initialized
INFO - 2016-09-09 13:29:53 --> Loader Class Initialized
INFO - 2016-09-09 13:29:53 --> Helper loaded: url_helper
INFO - 2016-09-09 13:29:53 --> Helper loaded: language_helper
INFO - 2016-09-09 13:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:29:53 --> Controller Class Initialized
INFO - 2016-09-09 13:29:53 --> Database Driver Class Initialized
INFO - 2016-09-09 13:29:53 --> Model Class Initialized
INFO - 2016-09-09 13:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:29:53 --> Config Class Initialized
INFO - 2016-09-09 13:29:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:29:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:29:53 --> Utf8 Class Initialized
INFO - 2016-09-09 13:29:53 --> URI Class Initialized
INFO - 2016-09-09 13:29:53 --> Router Class Initialized
INFO - 2016-09-09 13:29:53 --> Output Class Initialized
INFO - 2016-09-09 13:29:53 --> Security Class Initialized
DEBUG - 2016-09-09 13:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:29:53 --> Input Class Initialized
INFO - 2016-09-09 13:29:53 --> Language Class Initialized
INFO - 2016-09-09 13:29:53 --> Loader Class Initialized
INFO - 2016-09-09 13:29:53 --> Helper loaded: url_helper
INFO - 2016-09-09 13:29:53 --> Helper loaded: language_helper
INFO - 2016-09-09 13:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:29:53 --> Controller Class Initialized
INFO - 2016-09-09 13:29:53 --> Database Driver Class Initialized
INFO - 2016-09-09 13:29:53 --> Model Class Initialized
INFO - 2016-09-09 13:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:29:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:29:53 --> Final output sent to browser
DEBUG - 2016-09-09 13:29:53 --> Total execution time: 0.0672
INFO - 2016-09-09 13:30:37 --> Config Class Initialized
INFO - 2016-09-09 13:30:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:30:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:30:37 --> Utf8 Class Initialized
INFO - 2016-09-09 13:30:37 --> URI Class Initialized
INFO - 2016-09-09 13:30:37 --> Router Class Initialized
INFO - 2016-09-09 13:30:37 --> Output Class Initialized
INFO - 2016-09-09 13:30:37 --> Security Class Initialized
DEBUG - 2016-09-09 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:30:37 --> Input Class Initialized
INFO - 2016-09-09 13:30:37 --> Language Class Initialized
INFO - 2016-09-09 13:30:37 --> Loader Class Initialized
INFO - 2016-09-09 13:30:37 --> Helper loaded: url_helper
INFO - 2016-09-09 13:30:37 --> Helper loaded: language_helper
INFO - 2016-09-09 13:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:30:37 --> Controller Class Initialized
INFO - 2016-09-09 13:30:37 --> Database Driver Class Initialized
INFO - 2016-09-09 13:30:37 --> Model Class Initialized
INFO - 2016-09-09 13:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:30:37 --> Config Class Initialized
INFO - 2016-09-09 13:30:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:30:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:30:37 --> Utf8 Class Initialized
INFO - 2016-09-09 13:30:37 --> URI Class Initialized
INFO - 2016-09-09 13:30:37 --> Router Class Initialized
INFO - 2016-09-09 13:30:37 --> Output Class Initialized
INFO - 2016-09-09 13:30:37 --> Security Class Initialized
DEBUG - 2016-09-09 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:30:37 --> Input Class Initialized
INFO - 2016-09-09 13:30:37 --> Language Class Initialized
INFO - 2016-09-09 13:30:37 --> Loader Class Initialized
INFO - 2016-09-09 13:30:37 --> Helper loaded: url_helper
INFO - 2016-09-09 13:30:37 --> Helper loaded: language_helper
INFO - 2016-09-09 13:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:30:37 --> Controller Class Initialized
INFO - 2016-09-09 13:30:37 --> Database Driver Class Initialized
INFO - 2016-09-09 13:30:37 --> Model Class Initialized
INFO - 2016-09-09 13:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:30:37 --> Final output sent to browser
DEBUG - 2016-09-09 13:30:37 --> Total execution time: 0.0558
INFO - 2016-09-09 13:30:40 --> Config Class Initialized
INFO - 2016-09-09 13:30:40 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:30:40 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:30:40 --> Utf8 Class Initialized
INFO - 2016-09-09 13:30:40 --> URI Class Initialized
INFO - 2016-09-09 13:30:40 --> Router Class Initialized
INFO - 2016-09-09 13:30:40 --> Output Class Initialized
INFO - 2016-09-09 13:30:40 --> Security Class Initialized
DEBUG - 2016-09-09 13:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:30:40 --> Input Class Initialized
INFO - 2016-09-09 13:30:40 --> Language Class Initialized
INFO - 2016-09-09 13:30:40 --> Loader Class Initialized
INFO - 2016-09-09 13:30:40 --> Helper loaded: url_helper
INFO - 2016-09-09 13:30:40 --> Helper loaded: language_helper
INFO - 2016-09-09 13:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:30:40 --> Controller Class Initialized
INFO - 2016-09-09 13:30:40 --> Database Driver Class Initialized
INFO - 2016-09-09 13:30:40 --> Model Class Initialized
INFO - 2016-09-09 13:30:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:30:40 --> Config Class Initialized
INFO - 2016-09-09 13:30:40 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:30:40 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:30:40 --> Utf8 Class Initialized
INFO - 2016-09-09 13:30:40 --> URI Class Initialized
INFO - 2016-09-09 13:30:40 --> Router Class Initialized
INFO - 2016-09-09 13:30:40 --> Output Class Initialized
INFO - 2016-09-09 13:30:40 --> Security Class Initialized
DEBUG - 2016-09-09 13:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:30:40 --> Input Class Initialized
INFO - 2016-09-09 13:30:40 --> Language Class Initialized
INFO - 2016-09-09 13:30:40 --> Loader Class Initialized
INFO - 2016-09-09 13:30:40 --> Helper loaded: url_helper
INFO - 2016-09-09 13:30:40 --> Helper loaded: language_helper
INFO - 2016-09-09 13:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:30:40 --> Controller Class Initialized
INFO - 2016-09-09 13:30:40 --> Database Driver Class Initialized
INFO - 2016-09-09 13:30:40 --> Model Class Initialized
INFO - 2016-09-09 13:30:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:30:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:30:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:30:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:30:40 --> Final output sent to browser
DEBUG - 2016-09-09 13:30:40 --> Total execution time: 0.0591
INFO - 2016-09-09 13:32:01 --> Config Class Initialized
INFO - 2016-09-09 13:32:01 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:01 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:01 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:01 --> URI Class Initialized
INFO - 2016-09-09 13:32:01 --> Router Class Initialized
INFO - 2016-09-09 13:32:01 --> Output Class Initialized
INFO - 2016-09-09 13:32:01 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:01 --> Input Class Initialized
INFO - 2016-09-09 13:32:01 --> Language Class Initialized
INFO - 2016-09-09 13:32:01 --> Loader Class Initialized
INFO - 2016-09-09 13:32:01 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:01 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:01 --> Controller Class Initialized
INFO - 2016-09-09 13:32:01 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:01 --> Model Class Initialized
INFO - 2016-09-09 13:32:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:01 --> Config Class Initialized
INFO - 2016-09-09 13:32:01 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:01 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:01 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:01 --> URI Class Initialized
INFO - 2016-09-09 13:32:01 --> Router Class Initialized
INFO - 2016-09-09 13:32:01 --> Output Class Initialized
INFO - 2016-09-09 13:32:01 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:01 --> Input Class Initialized
INFO - 2016-09-09 13:32:01 --> Language Class Initialized
INFO - 2016-09-09 13:32:01 --> Loader Class Initialized
INFO - 2016-09-09 13:32:01 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:01 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:01 --> Controller Class Initialized
INFO - 2016-09-09 13:32:01 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:01 --> Model Class Initialized
INFO - 2016-09-09 13:32:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:32:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:32:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:32:01 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:01 --> Total execution time: 0.0534
INFO - 2016-09-09 13:32:05 --> Config Class Initialized
INFO - 2016-09-09 13:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:05 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:05 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:05 --> URI Class Initialized
INFO - 2016-09-09 13:32:05 --> Router Class Initialized
INFO - 2016-09-09 13:32:05 --> Output Class Initialized
INFO - 2016-09-09 13:32:05 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:05 --> Input Class Initialized
INFO - 2016-09-09 13:32:05 --> Language Class Initialized
INFO - 2016-09-09 13:32:05 --> Loader Class Initialized
INFO - 2016-09-09 13:32:05 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:05 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:05 --> Controller Class Initialized
INFO - 2016-09-09 13:32:05 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:05 --> Model Class Initialized
INFO - 2016-09-09 13:32:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:32:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-09 13:32:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:32:05 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:05 --> Total execution time: 0.0679
INFO - 2016-09-09 13:32:24 --> Config Class Initialized
INFO - 2016-09-09 13:32:24 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:24 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:24 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:24 --> URI Class Initialized
INFO - 2016-09-09 13:32:24 --> Router Class Initialized
INFO - 2016-09-09 13:32:24 --> Output Class Initialized
INFO - 2016-09-09 13:32:24 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:24 --> Input Class Initialized
INFO - 2016-09-09 13:32:24 --> Language Class Initialized
INFO - 2016-09-09 13:32:24 --> Loader Class Initialized
INFO - 2016-09-09 13:32:24 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:24 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:24 --> Controller Class Initialized
INFO - 2016-09-09 13:32:24 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:24 --> Model Class Initialized
INFO - 2016-09-09 13:32:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:24 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:24 --> Total execution time: 0.0581
INFO - 2016-09-09 13:32:29 --> Config Class Initialized
INFO - 2016-09-09 13:32:29 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:29 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:29 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:29 --> URI Class Initialized
INFO - 2016-09-09 13:32:29 --> Router Class Initialized
INFO - 2016-09-09 13:32:29 --> Output Class Initialized
INFO - 2016-09-09 13:32:29 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:29 --> Input Class Initialized
INFO - 2016-09-09 13:32:29 --> Language Class Initialized
INFO - 2016-09-09 13:32:29 --> Loader Class Initialized
INFO - 2016-09-09 13:32:29 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:29 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:29 --> Controller Class Initialized
INFO - 2016-09-09 13:32:29 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:29 --> Model Class Initialized
INFO - 2016-09-09 13:32:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:29 --> Config Class Initialized
INFO - 2016-09-09 13:32:29 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:29 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:29 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:29 --> URI Class Initialized
INFO - 2016-09-09 13:32:29 --> Router Class Initialized
INFO - 2016-09-09 13:32:29 --> Output Class Initialized
INFO - 2016-09-09 13:32:29 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:29 --> Input Class Initialized
INFO - 2016-09-09 13:32:29 --> Language Class Initialized
INFO - 2016-09-09 13:32:29 --> Loader Class Initialized
INFO - 2016-09-09 13:32:29 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:29 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:29 --> Controller Class Initialized
INFO - 2016-09-09 13:32:29 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:29 --> Model Class Initialized
INFO - 2016-09-09 13:32:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:32:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-09 13:32:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:32:29 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:29 --> Total execution time: 0.0594
INFO - 2016-09-09 13:32:35 --> Config Class Initialized
INFO - 2016-09-09 13:32:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:35 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:35 --> URI Class Initialized
INFO - 2016-09-09 13:32:35 --> Router Class Initialized
INFO - 2016-09-09 13:32:35 --> Output Class Initialized
INFO - 2016-09-09 13:32:35 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:35 --> Input Class Initialized
INFO - 2016-09-09 13:32:35 --> Language Class Initialized
INFO - 2016-09-09 13:32:35 --> Loader Class Initialized
INFO - 2016-09-09 13:32:35 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:35 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:35 --> Controller Class Initialized
INFO - 2016-09-09 13:32:35 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:35 --> Model Class Initialized
INFO - 2016-09-09 13:32:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:35 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:35 --> Total execution time: 0.0710
INFO - 2016-09-09 13:32:37 --> Config Class Initialized
INFO - 2016-09-09 13:32:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:37 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:37 --> URI Class Initialized
INFO - 2016-09-09 13:32:37 --> Router Class Initialized
INFO - 2016-09-09 13:32:37 --> Output Class Initialized
INFO - 2016-09-09 13:32:37 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:37 --> Input Class Initialized
INFO - 2016-09-09 13:32:37 --> Language Class Initialized
INFO - 2016-09-09 13:32:37 --> Loader Class Initialized
INFO - 2016-09-09 13:32:37 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:37 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:37 --> Controller Class Initialized
INFO - 2016-09-09 13:32:37 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:37 --> Model Class Initialized
INFO - 2016-09-09 13:32:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:37 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:37 --> Total execution time: 0.0602
INFO - 2016-09-09 13:32:40 --> Config Class Initialized
INFO - 2016-09-09 13:32:40 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:32:40 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:32:40 --> Utf8 Class Initialized
INFO - 2016-09-09 13:32:40 --> URI Class Initialized
INFO - 2016-09-09 13:32:40 --> Router Class Initialized
INFO - 2016-09-09 13:32:40 --> Output Class Initialized
INFO - 2016-09-09 13:32:40 --> Security Class Initialized
DEBUG - 2016-09-09 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:32:40 --> Input Class Initialized
INFO - 2016-09-09 13:32:40 --> Language Class Initialized
INFO - 2016-09-09 13:32:40 --> Loader Class Initialized
INFO - 2016-09-09 13:32:40 --> Helper loaded: url_helper
INFO - 2016-09-09 13:32:40 --> Helper loaded: language_helper
INFO - 2016-09-09 13:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:32:40 --> Controller Class Initialized
INFO - 2016-09-09 13:32:40 --> Database Driver Class Initialized
INFO - 2016-09-09 13:32:40 --> Model Class Initialized
INFO - 2016-09-09 13:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:32:40 --> Final output sent to browser
DEBUG - 2016-09-09 13:32:40 --> Total execution time: 0.0588
INFO - 2016-09-09 13:33:05 --> Config Class Initialized
INFO - 2016-09-09 13:33:05 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:05 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:05 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:05 --> URI Class Initialized
INFO - 2016-09-09 13:33:05 --> Router Class Initialized
INFO - 2016-09-09 13:33:05 --> Output Class Initialized
INFO - 2016-09-09 13:33:05 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:05 --> Input Class Initialized
INFO - 2016-09-09 13:33:05 --> Language Class Initialized
INFO - 2016-09-09 13:33:05 --> Loader Class Initialized
INFO - 2016-09-09 13:33:05 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:05 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:05 --> Controller Class Initialized
INFO - 2016-09-09 13:33:05 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:05 --> Model Class Initialized
INFO - 2016-09-09 13:33:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:05 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:05 --> Total execution time: 0.0737
INFO - 2016-09-09 13:33:06 --> Config Class Initialized
INFO - 2016-09-09 13:33:06 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:06 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:06 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:06 --> URI Class Initialized
INFO - 2016-09-09 13:33:06 --> Router Class Initialized
INFO - 2016-09-09 13:33:06 --> Output Class Initialized
INFO - 2016-09-09 13:33:06 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:06 --> Input Class Initialized
INFO - 2016-09-09 13:33:06 --> Language Class Initialized
INFO - 2016-09-09 13:33:06 --> Loader Class Initialized
INFO - 2016-09-09 13:33:06 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:06 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:06 --> Controller Class Initialized
INFO - 2016-09-09 13:33:06 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:06 --> Model Class Initialized
INFO - 2016-09-09 13:33:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:06 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:06 --> Total execution time: 0.0747
INFO - 2016-09-09 13:33:12 --> Config Class Initialized
INFO - 2016-09-09 13:33:12 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:12 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:12 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:12 --> URI Class Initialized
INFO - 2016-09-09 13:33:12 --> Router Class Initialized
INFO - 2016-09-09 13:33:12 --> Output Class Initialized
INFO - 2016-09-09 13:33:12 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:12 --> Input Class Initialized
INFO - 2016-09-09 13:33:12 --> Language Class Initialized
INFO - 2016-09-09 13:33:12 --> Loader Class Initialized
INFO - 2016-09-09 13:33:12 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:12 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:12 --> Controller Class Initialized
INFO - 2016-09-09 13:33:12 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:12 --> Model Class Initialized
INFO - 2016-09-09 13:33:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:12 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:12 --> Total execution time: 0.0676
INFO - 2016-09-09 13:33:23 --> Config Class Initialized
INFO - 2016-09-09 13:33:23 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:23 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:23 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:23 --> URI Class Initialized
INFO - 2016-09-09 13:33:23 --> Router Class Initialized
INFO - 2016-09-09 13:33:23 --> Output Class Initialized
INFO - 2016-09-09 13:33:23 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:23 --> Input Class Initialized
INFO - 2016-09-09 13:33:23 --> Language Class Initialized
INFO - 2016-09-09 13:33:23 --> Loader Class Initialized
INFO - 2016-09-09 13:33:23 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:23 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:23 --> Controller Class Initialized
INFO - 2016-09-09 13:33:23 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:23 --> Model Class Initialized
INFO - 2016-09-09 13:33:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:23 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:23 --> Total execution time: 0.0664
INFO - 2016-09-09 13:33:28 --> Config Class Initialized
INFO - 2016-09-09 13:33:28 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:28 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:28 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:28 --> URI Class Initialized
INFO - 2016-09-09 13:33:28 --> Router Class Initialized
INFO - 2016-09-09 13:33:28 --> Output Class Initialized
INFO - 2016-09-09 13:33:28 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:28 --> Input Class Initialized
INFO - 2016-09-09 13:33:28 --> Language Class Initialized
INFO - 2016-09-09 13:33:28 --> Loader Class Initialized
INFO - 2016-09-09 13:33:28 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:28 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:28 --> Controller Class Initialized
INFO - 2016-09-09 13:33:28 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:28 --> Model Class Initialized
INFO - 2016-09-09 13:33:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:28 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:28 --> Total execution time: 0.0614
INFO - 2016-09-09 13:33:34 --> Config Class Initialized
INFO - 2016-09-09 13:33:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:34 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:34 --> URI Class Initialized
INFO - 2016-09-09 13:33:34 --> Router Class Initialized
INFO - 2016-09-09 13:33:34 --> Output Class Initialized
INFO - 2016-09-09 13:33:34 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:34 --> Input Class Initialized
INFO - 2016-09-09 13:33:34 --> Language Class Initialized
INFO - 2016-09-09 13:33:34 --> Loader Class Initialized
INFO - 2016-09-09 13:33:34 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:34 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:34 --> Controller Class Initialized
INFO - 2016-09-09 13:33:34 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:34 --> Model Class Initialized
INFO - 2016-09-09 13:33:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:33:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-09 13:33:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:33:34 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:34 --> Total execution time: 0.0590
INFO - 2016-09-09 13:33:46 --> Config Class Initialized
INFO - 2016-09-09 13:33:46 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:46 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:46 --> URI Class Initialized
INFO - 2016-09-09 13:33:46 --> Router Class Initialized
INFO - 2016-09-09 13:33:46 --> Output Class Initialized
INFO - 2016-09-09 13:33:46 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:46 --> Input Class Initialized
INFO - 2016-09-09 13:33:46 --> Language Class Initialized
INFO - 2016-09-09 13:33:46 --> Loader Class Initialized
INFO - 2016-09-09 13:33:46 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:46 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:46 --> Controller Class Initialized
INFO - 2016-09-09 13:33:46 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:46 --> Model Class Initialized
INFO - 2016-09-09 13:33:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:46 --> Helper loaded: form_helper
INFO - 2016-09-09 13:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 13:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:33:46 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:46 --> Total execution time: 0.0622
INFO - 2016-09-09 13:33:54 --> Config Class Initialized
INFO - 2016-09-09 13:33:54 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:54 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:54 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:54 --> URI Class Initialized
INFO - 2016-09-09 13:33:54 --> Router Class Initialized
INFO - 2016-09-09 13:33:54 --> Output Class Initialized
INFO - 2016-09-09 13:33:54 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:54 --> Input Class Initialized
INFO - 2016-09-09 13:33:54 --> Language Class Initialized
INFO - 2016-09-09 13:33:54 --> Loader Class Initialized
INFO - 2016-09-09 13:33:54 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:54 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:54 --> Controller Class Initialized
INFO - 2016-09-09 13:33:54 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:54 --> Model Class Initialized
INFO - 2016-09-09 13:33:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:33:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:33:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:33:54 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:54 --> Total execution time: 0.0531
INFO - 2016-09-09 13:33:56 --> Config Class Initialized
INFO - 2016-09-09 13:33:56 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:56 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:56 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:56 --> URI Class Initialized
INFO - 2016-09-09 13:33:56 --> Router Class Initialized
INFO - 2016-09-09 13:33:56 --> Output Class Initialized
INFO - 2016-09-09 13:33:56 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:56 --> Input Class Initialized
INFO - 2016-09-09 13:33:56 --> Language Class Initialized
INFO - 2016-09-09 13:33:56 --> Loader Class Initialized
INFO - 2016-09-09 13:33:56 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:56 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:56 --> Controller Class Initialized
INFO - 2016-09-09 13:33:56 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:56 --> Model Class Initialized
INFO - 2016-09-09 13:33:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:56 --> Config Class Initialized
INFO - 2016-09-09 13:33:56 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:33:56 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:33:56 --> Utf8 Class Initialized
INFO - 2016-09-09 13:33:56 --> URI Class Initialized
INFO - 2016-09-09 13:33:56 --> Router Class Initialized
INFO - 2016-09-09 13:33:56 --> Output Class Initialized
INFO - 2016-09-09 13:33:56 --> Security Class Initialized
DEBUG - 2016-09-09 13:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:33:56 --> Input Class Initialized
INFO - 2016-09-09 13:33:56 --> Language Class Initialized
INFO - 2016-09-09 13:33:56 --> Loader Class Initialized
INFO - 2016-09-09 13:33:56 --> Helper loaded: url_helper
INFO - 2016-09-09 13:33:56 --> Helper loaded: language_helper
INFO - 2016-09-09 13:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:33:56 --> Controller Class Initialized
INFO - 2016-09-09 13:33:56 --> Database Driver Class Initialized
INFO - 2016-09-09 13:33:56 --> Model Class Initialized
INFO - 2016-09-09 13:33:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:33:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:33:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:33:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:33:56 --> Final output sent to browser
DEBUG - 2016-09-09 13:33:56 --> Total execution time: 0.0592
INFO - 2016-09-09 13:35:27 --> Config Class Initialized
INFO - 2016-09-09 13:35:27 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:35:27 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:35:27 --> Utf8 Class Initialized
INFO - 2016-09-09 13:35:27 --> URI Class Initialized
INFO - 2016-09-09 13:35:27 --> Router Class Initialized
INFO - 2016-09-09 13:35:27 --> Output Class Initialized
INFO - 2016-09-09 13:35:27 --> Security Class Initialized
DEBUG - 2016-09-09 13:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:35:27 --> Input Class Initialized
INFO - 2016-09-09 13:35:27 --> Language Class Initialized
INFO - 2016-09-09 13:35:27 --> Loader Class Initialized
INFO - 2016-09-09 13:35:27 --> Helper loaded: url_helper
INFO - 2016-09-09 13:35:27 --> Helper loaded: language_helper
INFO - 2016-09-09 13:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:35:27 --> Controller Class Initialized
INFO - 2016-09-09 13:35:27 --> Database Driver Class Initialized
INFO - 2016-09-09 13:35:27 --> Model Class Initialized
INFO - 2016-09-09 13:35:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:35:27 --> Config Class Initialized
INFO - 2016-09-09 13:35:27 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:35:27 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:35:27 --> Utf8 Class Initialized
INFO - 2016-09-09 13:35:27 --> URI Class Initialized
INFO - 2016-09-09 13:35:27 --> Router Class Initialized
INFO - 2016-09-09 13:35:27 --> Output Class Initialized
INFO - 2016-09-09 13:35:27 --> Security Class Initialized
DEBUG - 2016-09-09 13:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:35:27 --> Input Class Initialized
INFO - 2016-09-09 13:35:27 --> Language Class Initialized
INFO - 2016-09-09 13:35:27 --> Loader Class Initialized
INFO - 2016-09-09 13:35:27 --> Helper loaded: url_helper
INFO - 2016-09-09 13:35:27 --> Helper loaded: language_helper
INFO - 2016-09-09 13:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:35:27 --> Controller Class Initialized
INFO - 2016-09-09 13:35:27 --> Database Driver Class Initialized
INFO - 2016-09-09 13:35:27 --> Model Class Initialized
INFO - 2016-09-09 13:35:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:35:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:35:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:35:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:35:27 --> Final output sent to browser
DEBUG - 2016-09-09 13:35:27 --> Total execution time: 0.0722
INFO - 2016-09-09 13:35:28 --> Config Class Initialized
INFO - 2016-09-09 13:35:28 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:35:28 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:35:28 --> Utf8 Class Initialized
INFO - 2016-09-09 13:35:28 --> URI Class Initialized
INFO - 2016-09-09 13:35:28 --> Router Class Initialized
INFO - 2016-09-09 13:35:28 --> Output Class Initialized
INFO - 2016-09-09 13:35:28 --> Security Class Initialized
DEBUG - 2016-09-09 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:35:28 --> Input Class Initialized
INFO - 2016-09-09 13:35:28 --> Language Class Initialized
INFO - 2016-09-09 13:35:28 --> Loader Class Initialized
INFO - 2016-09-09 13:35:28 --> Helper loaded: url_helper
INFO - 2016-09-09 13:35:28 --> Helper loaded: language_helper
INFO - 2016-09-09 13:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:35:28 --> Controller Class Initialized
INFO - 2016-09-09 13:35:28 --> Database Driver Class Initialized
INFO - 2016-09-09 13:35:28 --> Model Class Initialized
INFO - 2016-09-09 13:35:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:35:28 --> Config Class Initialized
INFO - 2016-09-09 13:35:28 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:35:28 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:35:28 --> Utf8 Class Initialized
INFO - 2016-09-09 13:35:28 --> URI Class Initialized
INFO - 2016-09-09 13:35:28 --> Router Class Initialized
INFO - 2016-09-09 13:35:28 --> Output Class Initialized
INFO - 2016-09-09 13:35:28 --> Security Class Initialized
DEBUG - 2016-09-09 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:35:28 --> Input Class Initialized
INFO - 2016-09-09 13:35:28 --> Language Class Initialized
INFO - 2016-09-09 13:35:28 --> Loader Class Initialized
INFO - 2016-09-09 13:35:28 --> Helper loaded: url_helper
INFO - 2016-09-09 13:35:28 --> Helper loaded: language_helper
INFO - 2016-09-09 13:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:35:28 --> Controller Class Initialized
INFO - 2016-09-09 13:35:28 --> Database Driver Class Initialized
INFO - 2016-09-09 13:35:28 --> Model Class Initialized
INFO - 2016-09-09 13:35:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:35:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:35:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:35:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:35:28 --> Final output sent to browser
DEBUG - 2016-09-09 13:35:28 --> Total execution time: 0.0680
INFO - 2016-09-09 13:36:18 --> Config Class Initialized
INFO - 2016-09-09 13:36:18 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:36:18 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:36:18 --> Utf8 Class Initialized
INFO - 2016-09-09 13:36:18 --> URI Class Initialized
INFO - 2016-09-09 13:36:18 --> Router Class Initialized
INFO - 2016-09-09 13:36:18 --> Output Class Initialized
INFO - 2016-09-09 13:36:18 --> Security Class Initialized
DEBUG - 2016-09-09 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:36:18 --> Input Class Initialized
INFO - 2016-09-09 13:36:18 --> Language Class Initialized
INFO - 2016-09-09 13:36:18 --> Loader Class Initialized
INFO - 2016-09-09 13:36:18 --> Helper loaded: url_helper
INFO - 2016-09-09 13:36:18 --> Helper loaded: language_helper
INFO - 2016-09-09 13:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:36:18 --> Controller Class Initialized
INFO - 2016-09-09 13:36:18 --> Database Driver Class Initialized
INFO - 2016-09-09 13:36:18 --> Model Class Initialized
INFO - 2016-09-09 13:36:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:36:18 --> Config Class Initialized
INFO - 2016-09-09 13:36:18 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:36:18 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:36:18 --> Utf8 Class Initialized
INFO - 2016-09-09 13:36:18 --> URI Class Initialized
INFO - 2016-09-09 13:36:18 --> Router Class Initialized
INFO - 2016-09-09 13:36:18 --> Output Class Initialized
INFO - 2016-09-09 13:36:18 --> Security Class Initialized
DEBUG - 2016-09-09 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:36:18 --> Input Class Initialized
INFO - 2016-09-09 13:36:18 --> Language Class Initialized
INFO - 2016-09-09 13:36:19 --> Loader Class Initialized
INFO - 2016-09-09 13:36:19 --> Helper loaded: url_helper
INFO - 2016-09-09 13:36:19 --> Helper loaded: language_helper
INFO - 2016-09-09 13:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:36:19 --> Controller Class Initialized
INFO - 2016-09-09 13:36:19 --> Database Driver Class Initialized
INFO - 2016-09-09 13:36:19 --> Model Class Initialized
INFO - 2016-09-09 13:36:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:36:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:36:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:36:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:36:19 --> Final output sent to browser
DEBUG - 2016-09-09 13:36:19 --> Total execution time: 0.0618
INFO - 2016-09-09 13:36:20 --> Config Class Initialized
INFO - 2016-09-09 13:36:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:36:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:36:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:36:20 --> URI Class Initialized
INFO - 2016-09-09 13:36:20 --> Router Class Initialized
INFO - 2016-09-09 13:36:20 --> Output Class Initialized
INFO - 2016-09-09 13:36:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:36:20 --> Input Class Initialized
INFO - 2016-09-09 13:36:20 --> Language Class Initialized
INFO - 2016-09-09 13:36:20 --> Loader Class Initialized
INFO - 2016-09-09 13:36:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:36:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:36:20 --> Controller Class Initialized
INFO - 2016-09-09 13:36:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:36:20 --> Model Class Initialized
INFO - 2016-09-09 13:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:36:20 --> Config Class Initialized
INFO - 2016-09-09 13:36:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:36:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:36:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:36:20 --> URI Class Initialized
INFO - 2016-09-09 13:36:20 --> Router Class Initialized
INFO - 2016-09-09 13:36:20 --> Output Class Initialized
INFO - 2016-09-09 13:36:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:36:20 --> Input Class Initialized
INFO - 2016-09-09 13:36:20 --> Language Class Initialized
INFO - 2016-09-09 13:36:20 --> Loader Class Initialized
INFO - 2016-09-09 13:36:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:36:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:36:20 --> Controller Class Initialized
INFO - 2016-09-09 13:36:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:36:20 --> Model Class Initialized
INFO - 2016-09-09 13:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:36:20 --> Final output sent to browser
DEBUG - 2016-09-09 13:36:20 --> Total execution time: 0.0769
INFO - 2016-09-09 13:37:13 --> Config Class Initialized
INFO - 2016-09-09 13:37:13 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:37:13 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:37:13 --> Utf8 Class Initialized
INFO - 2016-09-09 13:37:13 --> URI Class Initialized
INFO - 2016-09-09 13:37:13 --> Router Class Initialized
INFO - 2016-09-09 13:37:13 --> Output Class Initialized
INFO - 2016-09-09 13:37:13 --> Security Class Initialized
DEBUG - 2016-09-09 13:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:37:13 --> Input Class Initialized
INFO - 2016-09-09 13:37:13 --> Language Class Initialized
INFO - 2016-09-09 13:37:13 --> Loader Class Initialized
INFO - 2016-09-09 13:37:13 --> Helper loaded: url_helper
INFO - 2016-09-09 13:37:13 --> Helper loaded: language_helper
INFO - 2016-09-09 13:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:37:13 --> Controller Class Initialized
INFO - 2016-09-09 13:37:13 --> Database Driver Class Initialized
INFO - 2016-09-09 13:37:13 --> Model Class Initialized
INFO - 2016-09-09 13:37:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:37:13 --> Config Class Initialized
INFO - 2016-09-09 13:37:13 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:37:13 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:37:13 --> Utf8 Class Initialized
INFO - 2016-09-09 13:37:13 --> URI Class Initialized
INFO - 2016-09-09 13:37:13 --> Router Class Initialized
INFO - 2016-09-09 13:37:13 --> Output Class Initialized
INFO - 2016-09-09 13:37:13 --> Security Class Initialized
DEBUG - 2016-09-09 13:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:37:13 --> Input Class Initialized
INFO - 2016-09-09 13:37:13 --> Language Class Initialized
INFO - 2016-09-09 13:37:13 --> Loader Class Initialized
INFO - 2016-09-09 13:37:13 --> Helper loaded: url_helper
INFO - 2016-09-09 13:37:13 --> Helper loaded: language_helper
INFO - 2016-09-09 13:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:37:13 --> Controller Class Initialized
INFO - 2016-09-09 13:37:13 --> Database Driver Class Initialized
INFO - 2016-09-09 13:37:13 --> Model Class Initialized
INFO - 2016-09-09 13:37:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:37:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:37:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:37:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:37:13 --> Final output sent to browser
DEBUG - 2016-09-09 13:37:13 --> Total execution time: 0.0581
INFO - 2016-09-09 13:37:15 --> Config Class Initialized
INFO - 2016-09-09 13:37:15 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:37:15 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:37:15 --> Utf8 Class Initialized
INFO - 2016-09-09 13:37:15 --> URI Class Initialized
INFO - 2016-09-09 13:37:15 --> Router Class Initialized
INFO - 2016-09-09 13:37:15 --> Output Class Initialized
INFO - 2016-09-09 13:37:15 --> Security Class Initialized
DEBUG - 2016-09-09 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:37:15 --> Input Class Initialized
INFO - 2016-09-09 13:37:15 --> Language Class Initialized
INFO - 2016-09-09 13:37:15 --> Loader Class Initialized
INFO - 2016-09-09 13:37:15 --> Helper loaded: url_helper
INFO - 2016-09-09 13:37:15 --> Helper loaded: language_helper
INFO - 2016-09-09 13:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:37:15 --> Controller Class Initialized
INFO - 2016-09-09 13:37:15 --> Database Driver Class Initialized
INFO - 2016-09-09 13:37:15 --> Model Class Initialized
INFO - 2016-09-09 13:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:37:15 --> Config Class Initialized
INFO - 2016-09-09 13:37:15 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:37:15 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:37:15 --> Utf8 Class Initialized
INFO - 2016-09-09 13:37:15 --> URI Class Initialized
INFO - 2016-09-09 13:37:15 --> Router Class Initialized
INFO - 2016-09-09 13:37:15 --> Output Class Initialized
INFO - 2016-09-09 13:37:15 --> Security Class Initialized
DEBUG - 2016-09-09 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:37:15 --> Input Class Initialized
INFO - 2016-09-09 13:37:15 --> Language Class Initialized
INFO - 2016-09-09 13:37:15 --> Loader Class Initialized
INFO - 2016-09-09 13:37:15 --> Helper loaded: url_helper
INFO - 2016-09-09 13:37:15 --> Helper loaded: language_helper
INFO - 2016-09-09 13:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:37:15 --> Controller Class Initialized
INFO - 2016-09-09 13:37:15 --> Database Driver Class Initialized
INFO - 2016-09-09 13:37:15 --> Model Class Initialized
INFO - 2016-09-09 13:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:37:15 --> Final output sent to browser
DEBUG - 2016-09-09 13:37:15 --> Total execution time: 0.0664
INFO - 2016-09-09 13:37:31 --> Config Class Initialized
INFO - 2016-09-09 13:37:31 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:37:31 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:37:31 --> Utf8 Class Initialized
INFO - 2016-09-09 13:37:31 --> URI Class Initialized
INFO - 2016-09-09 13:37:31 --> Router Class Initialized
INFO - 2016-09-09 13:37:31 --> Output Class Initialized
INFO - 2016-09-09 13:37:31 --> Security Class Initialized
DEBUG - 2016-09-09 13:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:37:31 --> Input Class Initialized
INFO - 2016-09-09 13:37:31 --> Language Class Initialized
INFO - 2016-09-09 13:37:31 --> Loader Class Initialized
INFO - 2016-09-09 13:37:31 --> Helper loaded: url_helper
INFO - 2016-09-09 13:37:31 --> Helper loaded: language_helper
INFO - 2016-09-09 13:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:37:31 --> Controller Class Initialized
INFO - 2016-09-09 13:37:31 --> Database Driver Class Initialized
INFO - 2016-09-09 13:37:31 --> Model Class Initialized
INFO - 2016-09-09 13:37:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:37:31 --> Helper loaded: form_helper
INFO - 2016-09-09 13:37:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:37:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 13:37:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:37:31 --> Final output sent to browser
DEBUG - 2016-09-09 13:37:31 --> Total execution time: 0.0633
INFO - 2016-09-09 13:38:20 --> Config Class Initialized
INFO - 2016-09-09 13:38:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:38:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:38:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:38:20 --> URI Class Initialized
INFO - 2016-09-09 13:38:20 --> Router Class Initialized
INFO - 2016-09-09 13:38:20 --> Output Class Initialized
INFO - 2016-09-09 13:38:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:38:20 --> Input Class Initialized
INFO - 2016-09-09 13:38:20 --> Language Class Initialized
INFO - 2016-09-09 13:38:20 --> Loader Class Initialized
INFO - 2016-09-09 13:38:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:38:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:38:20 --> Controller Class Initialized
INFO - 2016-09-09 13:38:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:38:20 --> Model Class Initialized
INFO - 2016-09-09 13:38:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:38:20 --> Config Class Initialized
INFO - 2016-09-09 13:38:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:38:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:38:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:38:20 --> URI Class Initialized
INFO - 2016-09-09 13:38:20 --> Router Class Initialized
INFO - 2016-09-09 13:38:20 --> Output Class Initialized
INFO - 2016-09-09 13:38:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:38:20 --> Input Class Initialized
INFO - 2016-09-09 13:38:20 --> Language Class Initialized
INFO - 2016-09-09 13:38:20 --> Loader Class Initialized
INFO - 2016-09-09 13:38:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:38:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:38:20 --> Controller Class Initialized
INFO - 2016-09-09 13:38:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:38:20 --> Model Class Initialized
INFO - 2016-09-09 13:38:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:38:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:38:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:38:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:38:20 --> Final output sent to browser
DEBUG - 2016-09-09 13:38:20 --> Total execution time: 0.0533
INFO - 2016-09-09 13:38:24 --> Config Class Initialized
INFO - 2016-09-09 13:38:24 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:38:24 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:38:24 --> Utf8 Class Initialized
INFO - 2016-09-09 13:38:24 --> URI Class Initialized
INFO - 2016-09-09 13:38:24 --> Router Class Initialized
INFO - 2016-09-09 13:38:24 --> Output Class Initialized
INFO - 2016-09-09 13:38:24 --> Security Class Initialized
DEBUG - 2016-09-09 13:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:38:24 --> Input Class Initialized
INFO - 2016-09-09 13:38:24 --> Language Class Initialized
INFO - 2016-09-09 13:38:24 --> Loader Class Initialized
INFO - 2016-09-09 13:38:24 --> Helper loaded: url_helper
INFO - 2016-09-09 13:38:24 --> Helper loaded: language_helper
INFO - 2016-09-09 13:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:38:25 --> Controller Class Initialized
INFO - 2016-09-09 13:38:25 --> Database Driver Class Initialized
INFO - 2016-09-09 13:38:25 --> Model Class Initialized
INFO - 2016-09-09 13:38:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:38:25 --> Config Class Initialized
INFO - 2016-09-09 13:38:25 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:38:25 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:38:25 --> Utf8 Class Initialized
INFO - 2016-09-09 13:38:25 --> URI Class Initialized
INFO - 2016-09-09 13:38:25 --> Router Class Initialized
INFO - 2016-09-09 13:38:25 --> Output Class Initialized
INFO - 2016-09-09 13:38:25 --> Security Class Initialized
DEBUG - 2016-09-09 13:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:38:25 --> Input Class Initialized
INFO - 2016-09-09 13:38:25 --> Language Class Initialized
INFO - 2016-09-09 13:38:25 --> Loader Class Initialized
INFO - 2016-09-09 13:38:25 --> Helper loaded: url_helper
INFO - 2016-09-09 13:38:25 --> Helper loaded: language_helper
INFO - 2016-09-09 13:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:38:25 --> Controller Class Initialized
INFO - 2016-09-09 13:38:25 --> Database Driver Class Initialized
INFO - 2016-09-09 13:38:25 --> Model Class Initialized
INFO - 2016-09-09 13:38:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:38:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:38:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:38:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:38:25 --> Final output sent to browser
DEBUG - 2016-09-09 13:38:25 --> Total execution time: 0.0557
INFO - 2016-09-09 13:39:21 --> Config Class Initialized
INFO - 2016-09-09 13:39:21 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:39:21 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:39:21 --> Utf8 Class Initialized
INFO - 2016-09-09 13:39:21 --> URI Class Initialized
INFO - 2016-09-09 13:39:21 --> Router Class Initialized
INFO - 2016-09-09 13:39:21 --> Output Class Initialized
INFO - 2016-09-09 13:39:21 --> Security Class Initialized
DEBUG - 2016-09-09 13:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:39:21 --> Input Class Initialized
INFO - 2016-09-09 13:39:21 --> Language Class Initialized
INFO - 2016-09-09 13:39:21 --> Loader Class Initialized
INFO - 2016-09-09 13:39:21 --> Helper loaded: url_helper
INFO - 2016-09-09 13:39:21 --> Helper loaded: language_helper
INFO - 2016-09-09 13:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:39:21 --> Controller Class Initialized
INFO - 2016-09-09 13:39:21 --> Database Driver Class Initialized
INFO - 2016-09-09 13:39:21 --> Model Class Initialized
INFO - 2016-09-09 13:39:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:39:21 --> Config Class Initialized
INFO - 2016-09-09 13:39:21 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:39:21 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:39:21 --> Utf8 Class Initialized
INFO - 2016-09-09 13:39:21 --> URI Class Initialized
INFO - 2016-09-09 13:39:21 --> Router Class Initialized
INFO - 2016-09-09 13:39:21 --> Output Class Initialized
INFO - 2016-09-09 13:39:21 --> Security Class Initialized
DEBUG - 2016-09-09 13:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:39:21 --> Input Class Initialized
INFO - 2016-09-09 13:39:21 --> Language Class Initialized
INFO - 2016-09-09 13:39:21 --> Loader Class Initialized
INFO - 2016-09-09 13:39:21 --> Helper loaded: url_helper
INFO - 2016-09-09 13:39:21 --> Helper loaded: language_helper
INFO - 2016-09-09 13:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:39:21 --> Controller Class Initialized
INFO - 2016-09-09 13:39:21 --> Database Driver Class Initialized
INFO - 2016-09-09 13:39:21 --> Model Class Initialized
INFO - 2016-09-09 13:39:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:39:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:39:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:39:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:39:21 --> Final output sent to browser
DEBUG - 2016-09-09 13:39:21 --> Total execution time: 0.0692
INFO - 2016-09-09 13:39:22 --> Config Class Initialized
INFO - 2016-09-09 13:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:39:22 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:39:22 --> Utf8 Class Initialized
INFO - 2016-09-09 13:39:22 --> URI Class Initialized
INFO - 2016-09-09 13:39:22 --> Router Class Initialized
INFO - 2016-09-09 13:39:22 --> Output Class Initialized
INFO - 2016-09-09 13:39:22 --> Security Class Initialized
DEBUG - 2016-09-09 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:39:22 --> Input Class Initialized
INFO - 2016-09-09 13:39:22 --> Language Class Initialized
INFO - 2016-09-09 13:39:22 --> Loader Class Initialized
INFO - 2016-09-09 13:39:22 --> Helper loaded: url_helper
INFO - 2016-09-09 13:39:22 --> Helper loaded: language_helper
INFO - 2016-09-09 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:39:22 --> Controller Class Initialized
INFO - 2016-09-09 13:39:22 --> Database Driver Class Initialized
INFO - 2016-09-09 13:39:22 --> Model Class Initialized
INFO - 2016-09-09 13:39:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:39:22 --> Config Class Initialized
INFO - 2016-09-09 13:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:39:22 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:39:22 --> Utf8 Class Initialized
INFO - 2016-09-09 13:39:22 --> URI Class Initialized
INFO - 2016-09-09 13:39:22 --> Router Class Initialized
INFO - 2016-09-09 13:39:22 --> Output Class Initialized
INFO - 2016-09-09 13:39:22 --> Security Class Initialized
DEBUG - 2016-09-09 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:39:22 --> Input Class Initialized
INFO - 2016-09-09 13:39:22 --> Language Class Initialized
INFO - 2016-09-09 13:39:22 --> Loader Class Initialized
INFO - 2016-09-09 13:39:22 --> Helper loaded: url_helper
INFO - 2016-09-09 13:39:22 --> Helper loaded: language_helper
INFO - 2016-09-09 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:39:22 --> Controller Class Initialized
INFO - 2016-09-09 13:39:22 --> Database Driver Class Initialized
INFO - 2016-09-09 13:39:22 --> Model Class Initialized
INFO - 2016-09-09 13:39:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:39:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:39:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:39:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:39:23 --> Final output sent to browser
DEBUG - 2016-09-09 13:39:23 --> Total execution time: 0.0659
INFO - 2016-09-09 13:39:59 --> Config Class Initialized
INFO - 2016-09-09 13:39:59 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:39:59 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:39:59 --> Utf8 Class Initialized
INFO - 2016-09-09 13:39:59 --> URI Class Initialized
INFO - 2016-09-09 13:39:59 --> Router Class Initialized
INFO - 2016-09-09 13:39:59 --> Output Class Initialized
INFO - 2016-09-09 13:39:59 --> Security Class Initialized
DEBUG - 2016-09-09 13:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:39:59 --> Input Class Initialized
INFO - 2016-09-09 13:39:59 --> Language Class Initialized
INFO - 2016-09-09 13:39:59 --> Loader Class Initialized
INFO - 2016-09-09 13:39:59 --> Helper loaded: url_helper
INFO - 2016-09-09 13:39:59 --> Helper loaded: language_helper
INFO - 2016-09-09 13:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:39:59 --> Controller Class Initialized
INFO - 2016-09-09 13:39:59 --> Database Driver Class Initialized
INFO - 2016-09-09 13:39:59 --> Model Class Initialized
INFO - 2016-09-09 13:39:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:39:59 --> Config Class Initialized
INFO - 2016-09-09 13:39:59 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:39:59 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:39:59 --> Utf8 Class Initialized
INFO - 2016-09-09 13:39:59 --> URI Class Initialized
INFO - 2016-09-09 13:39:59 --> Router Class Initialized
INFO - 2016-09-09 13:39:59 --> Output Class Initialized
INFO - 2016-09-09 13:39:59 --> Security Class Initialized
DEBUG - 2016-09-09 13:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:39:59 --> Input Class Initialized
INFO - 2016-09-09 13:39:59 --> Language Class Initialized
INFO - 2016-09-09 13:39:59 --> Loader Class Initialized
INFO - 2016-09-09 13:39:59 --> Helper loaded: url_helper
INFO - 2016-09-09 13:39:59 --> Helper loaded: language_helper
INFO - 2016-09-09 13:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:39:59 --> Controller Class Initialized
INFO - 2016-09-09 13:39:59 --> Database Driver Class Initialized
INFO - 2016-09-09 13:39:59 --> Model Class Initialized
INFO - 2016-09-09 13:39:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:39:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:39:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:39:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:39:59 --> Final output sent to browser
DEBUG - 2016-09-09 13:39:59 --> Total execution time: 0.0529
INFO - 2016-09-09 13:40:01 --> Config Class Initialized
INFO - 2016-09-09 13:40:01 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:40:01 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:40:01 --> Utf8 Class Initialized
INFO - 2016-09-09 13:40:01 --> URI Class Initialized
INFO - 2016-09-09 13:40:01 --> Router Class Initialized
INFO - 2016-09-09 13:40:01 --> Output Class Initialized
INFO - 2016-09-09 13:40:01 --> Security Class Initialized
DEBUG - 2016-09-09 13:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:40:01 --> Input Class Initialized
INFO - 2016-09-09 13:40:01 --> Language Class Initialized
INFO - 2016-09-09 13:40:01 --> Loader Class Initialized
INFO - 2016-09-09 13:40:01 --> Helper loaded: url_helper
INFO - 2016-09-09 13:40:01 --> Helper loaded: language_helper
INFO - 2016-09-09 13:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:40:01 --> Controller Class Initialized
INFO - 2016-09-09 13:40:01 --> Database Driver Class Initialized
INFO - 2016-09-09 13:40:01 --> Model Class Initialized
INFO - 2016-09-09 13:40:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:40:01 --> Config Class Initialized
INFO - 2016-09-09 13:40:01 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:40:01 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:40:01 --> Utf8 Class Initialized
INFO - 2016-09-09 13:40:01 --> URI Class Initialized
INFO - 2016-09-09 13:40:01 --> Router Class Initialized
INFO - 2016-09-09 13:40:01 --> Output Class Initialized
INFO - 2016-09-09 13:40:01 --> Security Class Initialized
DEBUG - 2016-09-09 13:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:40:01 --> Input Class Initialized
INFO - 2016-09-09 13:40:01 --> Language Class Initialized
INFO - 2016-09-09 13:40:01 --> Loader Class Initialized
INFO - 2016-09-09 13:40:01 --> Helper loaded: url_helper
INFO - 2016-09-09 13:40:01 --> Helper loaded: language_helper
INFO - 2016-09-09 13:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:40:01 --> Controller Class Initialized
INFO - 2016-09-09 13:40:01 --> Database Driver Class Initialized
INFO - 2016-09-09 13:40:01 --> Model Class Initialized
INFO - 2016-09-09 13:40:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:40:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:40:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:40:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:40:01 --> Final output sent to browser
DEBUG - 2016-09-09 13:40:01 --> Total execution time: 0.0583
INFO - 2016-09-09 13:40:34 --> Config Class Initialized
INFO - 2016-09-09 13:40:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:40:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:40:34 --> Utf8 Class Initialized
INFO - 2016-09-09 13:40:34 --> URI Class Initialized
INFO - 2016-09-09 13:40:34 --> Router Class Initialized
INFO - 2016-09-09 13:40:34 --> Output Class Initialized
INFO - 2016-09-09 13:40:34 --> Security Class Initialized
DEBUG - 2016-09-09 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:40:34 --> Input Class Initialized
INFO - 2016-09-09 13:40:34 --> Language Class Initialized
INFO - 2016-09-09 13:40:34 --> Loader Class Initialized
INFO - 2016-09-09 13:40:34 --> Helper loaded: url_helper
INFO - 2016-09-09 13:40:34 --> Helper loaded: language_helper
INFO - 2016-09-09 13:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:40:34 --> Controller Class Initialized
INFO - 2016-09-09 13:40:34 --> Database Driver Class Initialized
INFO - 2016-09-09 13:40:34 --> Model Class Initialized
INFO - 2016-09-09 13:40:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:40:34 --> Config Class Initialized
INFO - 2016-09-09 13:40:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:40:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:40:34 --> Utf8 Class Initialized
INFO - 2016-09-09 13:40:34 --> URI Class Initialized
INFO - 2016-09-09 13:40:34 --> Router Class Initialized
INFO - 2016-09-09 13:40:34 --> Output Class Initialized
INFO - 2016-09-09 13:40:34 --> Security Class Initialized
DEBUG - 2016-09-09 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:40:34 --> Input Class Initialized
INFO - 2016-09-09 13:40:34 --> Language Class Initialized
INFO - 2016-09-09 13:40:34 --> Loader Class Initialized
INFO - 2016-09-09 13:40:34 --> Helper loaded: url_helper
INFO - 2016-09-09 13:40:34 --> Helper loaded: language_helper
INFO - 2016-09-09 13:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:40:34 --> Controller Class Initialized
INFO - 2016-09-09 13:40:34 --> Database Driver Class Initialized
INFO - 2016-09-09 13:40:34 --> Model Class Initialized
INFO - 2016-09-09 13:40:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:40:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:40:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:40:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:40:34 --> Final output sent to browser
DEBUG - 2016-09-09 13:40:34 --> Total execution time: 0.0599
INFO - 2016-09-09 13:40:35 --> Config Class Initialized
INFO - 2016-09-09 13:40:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:40:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:40:35 --> Utf8 Class Initialized
INFO - 2016-09-09 13:40:35 --> URI Class Initialized
INFO - 2016-09-09 13:40:35 --> Router Class Initialized
INFO - 2016-09-09 13:40:35 --> Output Class Initialized
INFO - 2016-09-09 13:40:35 --> Security Class Initialized
DEBUG - 2016-09-09 13:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:40:35 --> Input Class Initialized
INFO - 2016-09-09 13:40:35 --> Language Class Initialized
INFO - 2016-09-09 13:40:35 --> Loader Class Initialized
INFO - 2016-09-09 13:40:35 --> Helper loaded: url_helper
INFO - 2016-09-09 13:40:35 --> Helper loaded: language_helper
INFO - 2016-09-09 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:40:35 --> Controller Class Initialized
INFO - 2016-09-09 13:40:35 --> Database Driver Class Initialized
INFO - 2016-09-09 13:40:35 --> Model Class Initialized
INFO - 2016-09-09 13:40:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:40:35 --> Config Class Initialized
INFO - 2016-09-09 13:40:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:40:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:40:35 --> Utf8 Class Initialized
INFO - 2016-09-09 13:40:35 --> URI Class Initialized
INFO - 2016-09-09 13:40:35 --> Router Class Initialized
INFO - 2016-09-09 13:40:35 --> Output Class Initialized
INFO - 2016-09-09 13:40:35 --> Security Class Initialized
DEBUG - 2016-09-09 13:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:40:35 --> Input Class Initialized
INFO - 2016-09-09 13:40:35 --> Language Class Initialized
INFO - 2016-09-09 13:40:35 --> Loader Class Initialized
INFO - 2016-09-09 13:40:35 --> Helper loaded: url_helper
INFO - 2016-09-09 13:40:35 --> Helper loaded: language_helper
INFO - 2016-09-09 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:40:35 --> Controller Class Initialized
INFO - 2016-09-09 13:40:35 --> Database Driver Class Initialized
INFO - 2016-09-09 13:40:35 --> Model Class Initialized
INFO - 2016-09-09 13:40:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:40:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:40:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 13:40:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:40:35 --> Final output sent to browser
DEBUG - 2016-09-09 13:40:35 --> Total execution time: 0.0784
INFO - 2016-09-09 13:41:20 --> Config Class Initialized
INFO - 2016-09-09 13:41:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:41:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:41:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:41:20 --> URI Class Initialized
INFO - 2016-09-09 13:41:20 --> Router Class Initialized
INFO - 2016-09-09 13:41:20 --> Output Class Initialized
INFO - 2016-09-09 13:41:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:41:20 --> Input Class Initialized
INFO - 2016-09-09 13:41:20 --> Language Class Initialized
INFO - 2016-09-09 13:41:20 --> Loader Class Initialized
INFO - 2016-09-09 13:41:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:41:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:41:20 --> Controller Class Initialized
INFO - 2016-09-09 13:41:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:41:20 --> Model Class Initialized
INFO - 2016-09-09 13:41:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:41:20 --> Config Class Initialized
INFO - 2016-09-09 13:41:20 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:41:20 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:41:20 --> Utf8 Class Initialized
INFO - 2016-09-09 13:41:20 --> URI Class Initialized
INFO - 2016-09-09 13:41:20 --> Router Class Initialized
INFO - 2016-09-09 13:41:20 --> Output Class Initialized
INFO - 2016-09-09 13:41:20 --> Security Class Initialized
DEBUG - 2016-09-09 13:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:41:20 --> Input Class Initialized
INFO - 2016-09-09 13:41:20 --> Language Class Initialized
INFO - 2016-09-09 13:41:20 --> Loader Class Initialized
INFO - 2016-09-09 13:41:20 --> Helper loaded: url_helper
INFO - 2016-09-09 13:41:20 --> Helper loaded: language_helper
INFO - 2016-09-09 13:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:41:20 --> Controller Class Initialized
INFO - 2016-09-09 13:41:20 --> Database Driver Class Initialized
INFO - 2016-09-09 13:41:20 --> Model Class Initialized
INFO - 2016-09-09 13:41:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:41:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:41:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 13:41:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:41:20 --> Final output sent to browser
DEBUG - 2016-09-09 13:41:20 --> Total execution time: 0.0553
INFO - 2016-09-09 13:41:27 --> Config Class Initialized
INFO - 2016-09-09 13:41:27 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:41:27 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:41:27 --> Utf8 Class Initialized
INFO - 2016-09-09 13:41:27 --> URI Class Initialized
INFO - 2016-09-09 13:41:27 --> Router Class Initialized
INFO - 2016-09-09 13:41:27 --> Output Class Initialized
INFO - 2016-09-09 13:41:27 --> Security Class Initialized
DEBUG - 2016-09-09 13:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:41:27 --> Input Class Initialized
INFO - 2016-09-09 13:41:27 --> Language Class Initialized
INFO - 2016-09-09 13:41:27 --> Loader Class Initialized
INFO - 2016-09-09 13:41:27 --> Helper loaded: url_helper
INFO - 2016-09-09 13:41:27 --> Helper loaded: language_helper
INFO - 2016-09-09 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:41:27 --> Controller Class Initialized
INFO - 2016-09-09 13:41:27 --> Database Driver Class Initialized
INFO - 2016-09-09 13:41:27 --> Model Class Initialized
INFO - 2016-09-09 13:41:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:41:27 --> Helper loaded: form_helper
INFO - 2016-09-09 13:41:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:41:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 13:41:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:41:27 --> Final output sent to browser
DEBUG - 2016-09-09 13:41:27 --> Total execution time: 0.0644
INFO - 2016-09-09 13:41:29 --> Config Class Initialized
INFO - 2016-09-09 13:41:29 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:41:29 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:41:29 --> Utf8 Class Initialized
INFO - 2016-09-09 13:41:29 --> URI Class Initialized
INFO - 2016-09-09 13:41:29 --> Router Class Initialized
INFO - 2016-09-09 13:41:29 --> Output Class Initialized
INFO - 2016-09-09 13:41:29 --> Security Class Initialized
DEBUG - 2016-09-09 13:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:41:29 --> Input Class Initialized
INFO - 2016-09-09 13:41:29 --> Language Class Initialized
INFO - 2016-09-09 13:41:29 --> Loader Class Initialized
INFO - 2016-09-09 13:41:29 --> Helper loaded: url_helper
INFO - 2016-09-09 13:41:29 --> Helper loaded: language_helper
INFO - 2016-09-09 13:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:41:29 --> Controller Class Initialized
INFO - 2016-09-09 13:41:29 --> Database Driver Class Initialized
INFO - 2016-09-09 13:41:29 --> Model Class Initialized
INFO - 2016-09-09 13:41:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-09 13:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:41:29 --> Final output sent to browser
DEBUG - 2016-09-09 13:41:29 --> Total execution time: 0.0612
INFO - 2016-09-09 13:41:38 --> Config Class Initialized
INFO - 2016-09-09 13:41:38 --> Hooks Class Initialized
DEBUG - 2016-09-09 13:41:38 --> UTF-8 Support Enabled
INFO - 2016-09-09 13:41:38 --> Utf8 Class Initialized
INFO - 2016-09-09 13:41:38 --> URI Class Initialized
INFO - 2016-09-09 13:41:38 --> Router Class Initialized
INFO - 2016-09-09 13:41:38 --> Output Class Initialized
INFO - 2016-09-09 13:41:38 --> Security Class Initialized
DEBUG - 2016-09-09 13:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 13:41:38 --> Input Class Initialized
INFO - 2016-09-09 13:41:38 --> Language Class Initialized
INFO - 2016-09-09 13:41:38 --> Loader Class Initialized
INFO - 2016-09-09 13:41:38 --> Helper loaded: url_helper
INFO - 2016-09-09 13:41:38 --> Helper loaded: language_helper
INFO - 2016-09-09 13:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 13:41:38 --> Controller Class Initialized
INFO - 2016-09-09 13:41:38 --> Database Driver Class Initialized
INFO - 2016-09-09 13:41:38 --> Model Class Initialized
INFO - 2016-09-09 13:41:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 13:41:38 --> Helper loaded: form_helper
INFO - 2016-09-09 13:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 13:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 13:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 13:41:38 --> Final output sent to browser
DEBUG - 2016-09-09 13:41:38 --> Total execution time: 0.0658
INFO - 2016-09-09 16:21:53 --> Config Class Initialized
INFO - 2016-09-09 16:21:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:21:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:21:53 --> Utf8 Class Initialized
INFO - 2016-09-09 16:21:53 --> URI Class Initialized
INFO - 2016-09-09 16:21:53 --> Router Class Initialized
INFO - 2016-09-09 16:21:53 --> Output Class Initialized
INFO - 2016-09-09 16:21:53 --> Security Class Initialized
DEBUG - 2016-09-09 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:21:53 --> Input Class Initialized
INFO - 2016-09-09 16:21:53 --> Language Class Initialized
INFO - 2016-09-09 16:21:53 --> Loader Class Initialized
INFO - 2016-09-09 16:21:53 --> Helper loaded: url_helper
INFO - 2016-09-09 16:21:53 --> Helper loaded: language_helper
INFO - 2016-09-09 16:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:21:53 --> Controller Class Initialized
INFO - 2016-09-09 16:21:53 --> Database Driver Class Initialized
INFO - 2016-09-09 16:21:53 --> Model Class Initialized
INFO - 2016-09-09 16:21:53 --> Model Class Initialized
INFO - 2016-09-09 16:21:53 --> Model Class Initialized
INFO - 2016-09-09 16:21:53 --> Model Class Initialized
INFO - 2016-09-09 16:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:21:53 --> Config Class Initialized
INFO - 2016-09-09 16:21:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:21:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:21:53 --> Utf8 Class Initialized
INFO - 2016-09-09 16:21:53 --> URI Class Initialized
INFO - 2016-09-09 16:21:53 --> Router Class Initialized
INFO - 2016-09-09 16:21:53 --> Output Class Initialized
INFO - 2016-09-09 16:21:53 --> Security Class Initialized
DEBUG - 2016-09-09 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:21:53 --> Input Class Initialized
INFO - 2016-09-09 16:21:53 --> Language Class Initialized
INFO - 2016-09-09 16:21:53 --> Loader Class Initialized
INFO - 2016-09-09 16:21:53 --> Helper loaded: url_helper
INFO - 2016-09-09 16:21:53 --> Helper loaded: language_helper
INFO - 2016-09-09 16:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:21:53 --> Controller Class Initialized
INFO - 2016-09-09 16:21:53 --> Database Driver Class Initialized
INFO - 2016-09-09 16:21:53 --> Model Class Initialized
INFO - 2016-09-09 16:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:21:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-09 16:21:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-09 16:21:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-09 16:21:53 --> Final output sent to browser
DEBUG - 2016-09-09 16:21:53 --> Total execution time: 0.0516
INFO - 2016-09-09 16:21:59 --> Config Class Initialized
INFO - 2016-09-09 16:21:59 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:21:59 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:21:59 --> Utf8 Class Initialized
INFO - 2016-09-09 16:21:59 --> URI Class Initialized
INFO - 2016-09-09 16:21:59 --> Router Class Initialized
INFO - 2016-09-09 16:21:59 --> Output Class Initialized
INFO - 2016-09-09 16:21:59 --> Security Class Initialized
DEBUG - 2016-09-09 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:21:59 --> Input Class Initialized
INFO - 2016-09-09 16:21:59 --> Language Class Initialized
INFO - 2016-09-09 16:21:59 --> Loader Class Initialized
INFO - 2016-09-09 16:21:59 --> Helper loaded: url_helper
INFO - 2016-09-09 16:21:59 --> Helper loaded: language_helper
INFO - 2016-09-09 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:21:59 --> Controller Class Initialized
INFO - 2016-09-09 16:21:59 --> Database Driver Class Initialized
INFO - 2016-09-09 16:21:59 --> Model Class Initialized
INFO - 2016-09-09 16:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:21:59 --> Config Class Initialized
INFO - 2016-09-09 16:21:59 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:21:59 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:21:59 --> Utf8 Class Initialized
INFO - 2016-09-09 16:21:59 --> URI Class Initialized
INFO - 2016-09-09 16:21:59 --> Router Class Initialized
INFO - 2016-09-09 16:21:59 --> Output Class Initialized
INFO - 2016-09-09 16:21:59 --> Security Class Initialized
DEBUG - 2016-09-09 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:21:59 --> Input Class Initialized
INFO - 2016-09-09 16:21:59 --> Language Class Initialized
INFO - 2016-09-09 16:21:59 --> Loader Class Initialized
INFO - 2016-09-09 16:21:59 --> Helper loaded: url_helper
INFO - 2016-09-09 16:21:59 --> Helper loaded: language_helper
INFO - 2016-09-09 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:21:59 --> Controller Class Initialized
INFO - 2016-09-09 16:21:59 --> Database Driver Class Initialized
INFO - 2016-09-09 16:21:59 --> Model Class Initialized
INFO - 2016-09-09 16:21:59 --> Model Class Initialized
INFO - 2016-09-09 16:21:59 --> Model Class Initialized
INFO - 2016-09-09 16:21:59 --> Model Class Initialized
INFO - 2016-09-09 16:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-09 16:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:21:59 --> Final output sent to browser
DEBUG - 2016-09-09 16:21:59 --> Total execution time: 0.0709
INFO - 2016-09-09 16:48:37 --> Config Class Initialized
INFO - 2016-09-09 16:48:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:48:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:48:37 --> Utf8 Class Initialized
INFO - 2016-09-09 16:48:37 --> URI Class Initialized
INFO - 2016-09-09 16:48:37 --> Router Class Initialized
INFO - 2016-09-09 16:48:37 --> Output Class Initialized
INFO - 2016-09-09 16:48:37 --> Security Class Initialized
DEBUG - 2016-09-09 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:48:37 --> Input Class Initialized
INFO - 2016-09-09 16:48:37 --> Language Class Initialized
INFO - 2016-09-09 16:48:37 --> Loader Class Initialized
INFO - 2016-09-09 16:48:37 --> Helper loaded: url_helper
INFO - 2016-09-09 16:48:37 --> Helper loaded: language_helper
INFO - 2016-09-09 16:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:48:37 --> Controller Class Initialized
INFO - 2016-09-09 16:48:37 --> Database Driver Class Initialized
INFO - 2016-09-09 16:48:37 --> Model Class Initialized
INFO - 2016-09-09 16:48:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:48:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:48:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 16:48:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:48:37 --> Final output sent to browser
DEBUG - 2016-09-09 16:48:37 --> Total execution time: 0.0568
INFO - 2016-09-09 16:49:32 --> Config Class Initialized
INFO - 2016-09-09 16:49:32 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:49:32 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:49:32 --> Utf8 Class Initialized
INFO - 2016-09-09 16:49:32 --> URI Class Initialized
INFO - 2016-09-09 16:49:32 --> Router Class Initialized
INFO - 2016-09-09 16:49:32 --> Output Class Initialized
INFO - 2016-09-09 16:49:32 --> Security Class Initialized
DEBUG - 2016-09-09 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:49:32 --> Input Class Initialized
INFO - 2016-09-09 16:49:32 --> Language Class Initialized
INFO - 2016-09-09 16:49:32 --> Loader Class Initialized
INFO - 2016-09-09 16:49:32 --> Helper loaded: url_helper
INFO - 2016-09-09 16:49:32 --> Helper loaded: language_helper
INFO - 2016-09-09 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:49:32 --> Controller Class Initialized
INFO - 2016-09-09 16:49:32 --> Database Driver Class Initialized
INFO - 2016-09-09 16:49:32 --> Model Class Initialized
INFO - 2016-09-09 16:49:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:49:32 --> Config Class Initialized
INFO - 2016-09-09 16:49:32 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:49:32 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:49:32 --> Utf8 Class Initialized
INFO - 2016-09-09 16:49:32 --> URI Class Initialized
INFO - 2016-09-09 16:49:32 --> Router Class Initialized
INFO - 2016-09-09 16:49:32 --> Output Class Initialized
INFO - 2016-09-09 16:49:32 --> Security Class Initialized
DEBUG - 2016-09-09 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:49:32 --> Input Class Initialized
INFO - 2016-09-09 16:49:32 --> Language Class Initialized
INFO - 2016-09-09 16:49:32 --> Loader Class Initialized
INFO - 2016-09-09 16:49:32 --> Helper loaded: url_helper
INFO - 2016-09-09 16:49:32 --> Helper loaded: language_helper
INFO - 2016-09-09 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:49:32 --> Controller Class Initialized
INFO - 2016-09-09 16:49:32 --> Database Driver Class Initialized
INFO - 2016-09-09 16:49:32 --> Model Class Initialized
INFO - 2016-09-09 16:49:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:49:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:49:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 16:49:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:49:32 --> Final output sent to browser
DEBUG - 2016-09-09 16:49:32 --> Total execution time: 0.0567
INFO - 2016-09-09 16:50:27 --> Config Class Initialized
INFO - 2016-09-09 16:50:27 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:50:27 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:50:27 --> Utf8 Class Initialized
INFO - 2016-09-09 16:50:27 --> URI Class Initialized
INFO - 2016-09-09 16:50:27 --> Router Class Initialized
INFO - 2016-09-09 16:50:27 --> Output Class Initialized
INFO - 2016-09-09 16:50:27 --> Security Class Initialized
DEBUG - 2016-09-09 16:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:50:27 --> Input Class Initialized
INFO - 2016-09-09 16:50:27 --> Language Class Initialized
INFO - 2016-09-09 16:50:27 --> Loader Class Initialized
INFO - 2016-09-09 16:50:27 --> Helper loaded: url_helper
INFO - 2016-09-09 16:50:27 --> Helper loaded: language_helper
INFO - 2016-09-09 16:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:50:27 --> Controller Class Initialized
INFO - 2016-09-09 16:50:27 --> Database Driver Class Initialized
INFO - 2016-09-09 16:50:27 --> Model Class Initialized
INFO - 2016-09-09 16:50:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:50:27 --> Config Class Initialized
INFO - 2016-09-09 16:50:27 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:50:27 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:50:27 --> Utf8 Class Initialized
INFO - 2016-09-09 16:50:27 --> URI Class Initialized
INFO - 2016-09-09 16:50:27 --> Router Class Initialized
INFO - 2016-09-09 16:50:27 --> Output Class Initialized
INFO - 2016-09-09 16:50:27 --> Security Class Initialized
DEBUG - 2016-09-09 16:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:50:27 --> Input Class Initialized
INFO - 2016-09-09 16:50:27 --> Language Class Initialized
INFO - 2016-09-09 16:50:27 --> Loader Class Initialized
INFO - 2016-09-09 16:50:27 --> Helper loaded: url_helper
INFO - 2016-09-09 16:50:27 --> Helper loaded: language_helper
INFO - 2016-09-09 16:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:50:27 --> Controller Class Initialized
INFO - 2016-09-09 16:50:27 --> Database Driver Class Initialized
INFO - 2016-09-09 16:50:27 --> Model Class Initialized
INFO - 2016-09-09 16:50:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:50:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:50:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 16:50:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:50:27 --> Final output sent to browser
DEBUG - 2016-09-09 16:50:27 --> Total execution time: 0.0670
INFO - 2016-09-09 16:50:28 --> Config Class Initialized
INFO - 2016-09-09 16:50:28 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:50:28 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:50:28 --> Utf8 Class Initialized
INFO - 2016-09-09 16:50:28 --> URI Class Initialized
INFO - 2016-09-09 16:50:28 --> Router Class Initialized
INFO - 2016-09-09 16:50:28 --> Output Class Initialized
INFO - 2016-09-09 16:50:28 --> Security Class Initialized
DEBUG - 2016-09-09 16:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:50:28 --> Input Class Initialized
INFO - 2016-09-09 16:50:28 --> Language Class Initialized
INFO - 2016-09-09 16:50:28 --> Loader Class Initialized
INFO - 2016-09-09 16:50:28 --> Helper loaded: url_helper
INFO - 2016-09-09 16:50:28 --> Helper loaded: language_helper
INFO - 2016-09-09 16:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:50:28 --> Controller Class Initialized
INFO - 2016-09-09 16:50:28 --> Database Driver Class Initialized
INFO - 2016-09-09 16:50:28 --> Model Class Initialized
INFO - 2016-09-09 16:50:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:50:28 --> Config Class Initialized
INFO - 2016-09-09 16:50:28 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:50:28 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:50:28 --> Utf8 Class Initialized
INFO - 2016-09-09 16:50:28 --> URI Class Initialized
INFO - 2016-09-09 16:50:28 --> Router Class Initialized
INFO - 2016-09-09 16:50:28 --> Output Class Initialized
INFO - 2016-09-09 16:50:28 --> Security Class Initialized
DEBUG - 2016-09-09 16:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:50:28 --> Input Class Initialized
INFO - 2016-09-09 16:50:28 --> Language Class Initialized
INFO - 2016-09-09 16:50:28 --> Loader Class Initialized
INFO - 2016-09-09 16:50:28 --> Helper loaded: url_helper
INFO - 2016-09-09 16:50:28 --> Helper loaded: language_helper
INFO - 2016-09-09 16:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:50:28 --> Controller Class Initialized
INFO - 2016-09-09 16:50:28 --> Database Driver Class Initialized
INFO - 2016-09-09 16:50:28 --> Model Class Initialized
INFO - 2016-09-09 16:50:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:50:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:50:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 16:50:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:50:28 --> Final output sent to browser
DEBUG - 2016-09-09 16:50:28 --> Total execution time: 0.0651
INFO - 2016-09-09 16:51:35 --> Config Class Initialized
INFO - 2016-09-09 16:51:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:51:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:51:35 --> Utf8 Class Initialized
INFO - 2016-09-09 16:51:35 --> URI Class Initialized
INFO - 2016-09-09 16:51:35 --> Router Class Initialized
INFO - 2016-09-09 16:51:35 --> Output Class Initialized
INFO - 2016-09-09 16:51:35 --> Security Class Initialized
DEBUG - 2016-09-09 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:51:35 --> Input Class Initialized
INFO - 2016-09-09 16:51:35 --> Language Class Initialized
INFO - 2016-09-09 16:51:35 --> Loader Class Initialized
INFO - 2016-09-09 16:51:35 --> Helper loaded: url_helper
INFO - 2016-09-09 16:51:35 --> Helper loaded: language_helper
INFO - 2016-09-09 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:51:35 --> Controller Class Initialized
INFO - 2016-09-09 16:51:35 --> Database Driver Class Initialized
INFO - 2016-09-09 16:51:35 --> Model Class Initialized
INFO - 2016-09-09 16:51:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:51:35 --> Config Class Initialized
INFO - 2016-09-09 16:51:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:51:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:51:35 --> Utf8 Class Initialized
INFO - 2016-09-09 16:51:35 --> URI Class Initialized
INFO - 2016-09-09 16:51:35 --> Router Class Initialized
INFO - 2016-09-09 16:51:35 --> Output Class Initialized
INFO - 2016-09-09 16:51:35 --> Security Class Initialized
DEBUG - 2016-09-09 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:51:35 --> Input Class Initialized
INFO - 2016-09-09 16:51:35 --> Language Class Initialized
INFO - 2016-09-09 16:51:35 --> Loader Class Initialized
INFO - 2016-09-09 16:51:35 --> Helper loaded: url_helper
INFO - 2016-09-09 16:51:35 --> Helper loaded: language_helper
INFO - 2016-09-09 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:51:35 --> Controller Class Initialized
INFO - 2016-09-09 16:51:35 --> Database Driver Class Initialized
INFO - 2016-09-09 16:51:35 --> Model Class Initialized
INFO - 2016-09-09 16:51:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 16:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:51:35 --> Final output sent to browser
DEBUG - 2016-09-09 16:51:35 --> Total execution time: 0.0563
INFO - 2016-09-09 16:52:24 --> Config Class Initialized
INFO - 2016-09-09 16:52:24 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:52:24 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:52:24 --> Utf8 Class Initialized
INFO - 2016-09-09 16:52:24 --> URI Class Initialized
INFO - 2016-09-09 16:52:24 --> Router Class Initialized
INFO - 2016-09-09 16:52:24 --> Output Class Initialized
INFO - 2016-09-09 16:52:24 --> Security Class Initialized
DEBUG - 2016-09-09 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:52:24 --> Input Class Initialized
INFO - 2016-09-09 16:52:24 --> Language Class Initialized
INFO - 2016-09-09 16:52:24 --> Loader Class Initialized
INFO - 2016-09-09 16:52:24 --> Helper loaded: url_helper
INFO - 2016-09-09 16:52:24 --> Helper loaded: language_helper
INFO - 2016-09-09 16:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:52:24 --> Controller Class Initialized
INFO - 2016-09-09 16:52:24 --> Database Driver Class Initialized
INFO - 2016-09-09 16:52:24 --> Model Class Initialized
INFO - 2016-09-09 16:52:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:52:24 --> Helper loaded: form_helper
INFO - 2016-09-09 16:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 16:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:52:24 --> Final output sent to browser
DEBUG - 2016-09-09 16:52:24 --> Total execution time: 0.0660
INFO - 2016-09-09 16:52:26 --> Config Class Initialized
INFO - 2016-09-09 16:52:26 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:52:26 --> Utf8 Class Initialized
INFO - 2016-09-09 16:52:26 --> URI Class Initialized
INFO - 2016-09-09 16:52:26 --> Router Class Initialized
INFO - 2016-09-09 16:52:26 --> Output Class Initialized
INFO - 2016-09-09 16:52:26 --> Security Class Initialized
DEBUG - 2016-09-09 16:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:52:26 --> Input Class Initialized
INFO - 2016-09-09 16:52:26 --> Language Class Initialized
INFO - 2016-09-09 16:52:26 --> Loader Class Initialized
INFO - 2016-09-09 16:52:26 --> Helper loaded: url_helper
INFO - 2016-09-09 16:52:26 --> Helper loaded: language_helper
INFO - 2016-09-09 16:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:52:26 --> Controller Class Initialized
INFO - 2016-09-09 16:52:26 --> Database Driver Class Initialized
INFO - 2016-09-09 16:52:26 --> Model Class Initialized
INFO - 2016-09-09 16:52:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:52:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:52:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-09 16:52:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:52:26 --> Final output sent to browser
DEBUG - 2016-09-09 16:52:26 --> Total execution time: 0.0680
INFO - 2016-09-09 16:52:35 --> Config Class Initialized
INFO - 2016-09-09 16:52:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:52:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:52:35 --> Utf8 Class Initialized
INFO - 2016-09-09 16:52:35 --> URI Class Initialized
INFO - 2016-09-09 16:52:35 --> Router Class Initialized
INFO - 2016-09-09 16:52:35 --> Output Class Initialized
INFO - 2016-09-09 16:52:35 --> Security Class Initialized
DEBUG - 2016-09-09 16:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:52:35 --> Input Class Initialized
INFO - 2016-09-09 16:52:35 --> Language Class Initialized
INFO - 2016-09-09 16:52:35 --> Loader Class Initialized
INFO - 2016-09-09 16:52:35 --> Helper loaded: url_helper
INFO - 2016-09-09 16:52:35 --> Helper loaded: language_helper
INFO - 2016-09-09 16:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:52:35 --> Controller Class Initialized
INFO - 2016-09-09 16:52:35 --> Database Driver Class Initialized
INFO - 2016-09-09 16:52:35 --> Model Class Initialized
INFO - 2016-09-09 16:52:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:52:35 --> Helper loaded: form_helper
INFO - 2016-09-09 16:52:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:52:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 16:52:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:52:35 --> Final output sent to browser
DEBUG - 2016-09-09 16:52:35 --> Total execution time: 0.0645
INFO - 2016-09-09 16:52:37 --> Config Class Initialized
INFO - 2016-09-09 16:52:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:52:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:52:37 --> Utf8 Class Initialized
INFO - 2016-09-09 16:52:37 --> URI Class Initialized
INFO - 2016-09-09 16:52:37 --> Router Class Initialized
INFO - 2016-09-09 16:52:37 --> Output Class Initialized
INFO - 2016-09-09 16:52:37 --> Security Class Initialized
DEBUG - 2016-09-09 16:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:52:37 --> Input Class Initialized
INFO - 2016-09-09 16:52:37 --> Language Class Initialized
INFO - 2016-09-09 16:52:37 --> Loader Class Initialized
INFO - 2016-09-09 16:52:37 --> Helper loaded: url_helper
INFO - 2016-09-09 16:52:37 --> Helper loaded: language_helper
INFO - 2016-09-09 16:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:52:37 --> Controller Class Initialized
INFO - 2016-09-09 16:52:37 --> Database Driver Class Initialized
INFO - 2016-09-09 16:52:37 --> Model Class Initialized
INFO - 2016-09-09 16:52:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:52:37 --> Config Class Initialized
INFO - 2016-09-09 16:52:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:52:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:52:37 --> Utf8 Class Initialized
INFO - 2016-09-09 16:52:37 --> URI Class Initialized
INFO - 2016-09-09 16:52:37 --> Router Class Initialized
INFO - 2016-09-09 16:52:37 --> Output Class Initialized
INFO - 2016-09-09 16:52:37 --> Security Class Initialized
DEBUG - 2016-09-09 16:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:52:37 --> Input Class Initialized
INFO - 2016-09-09 16:52:37 --> Language Class Initialized
INFO - 2016-09-09 16:52:37 --> Loader Class Initialized
INFO - 2016-09-09 16:52:37 --> Helper loaded: url_helper
INFO - 2016-09-09 16:52:37 --> Helper loaded: language_helper
INFO - 2016-09-09 16:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:52:37 --> Controller Class Initialized
INFO - 2016-09-09 16:52:37 --> Database Driver Class Initialized
INFO - 2016-09-09 16:52:37 --> Model Class Initialized
INFO - 2016-09-09 16:52:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:52:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:52:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 16:52:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:52:37 --> Final output sent to browser
DEBUG - 2016-09-09 16:52:37 --> Total execution time: 0.0577
INFO - 2016-09-09 16:53:12 --> Config Class Initialized
INFO - 2016-09-09 16:53:12 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:12 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:12 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:12 --> URI Class Initialized
INFO - 2016-09-09 16:53:12 --> Router Class Initialized
INFO - 2016-09-09 16:53:12 --> Output Class Initialized
INFO - 2016-09-09 16:53:12 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:12 --> Input Class Initialized
INFO - 2016-09-09 16:53:12 --> Language Class Initialized
INFO - 2016-09-09 16:53:12 --> Loader Class Initialized
INFO - 2016-09-09 16:53:12 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:12 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:12 --> Controller Class Initialized
INFO - 2016-09-09 16:53:12 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:12 --> Model Class Initialized
INFO - 2016-09-09 16:53:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:12 --> Config Class Initialized
INFO - 2016-09-09 16:53:12 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:12 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:12 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:12 --> URI Class Initialized
INFO - 2016-09-09 16:53:12 --> Router Class Initialized
INFO - 2016-09-09 16:53:12 --> Output Class Initialized
INFO - 2016-09-09 16:53:12 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:12 --> Input Class Initialized
INFO - 2016-09-09 16:53:12 --> Language Class Initialized
INFO - 2016-09-09 16:53:12 --> Loader Class Initialized
INFO - 2016-09-09 16:53:12 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:12 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:12 --> Controller Class Initialized
INFO - 2016-09-09 16:53:12 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:12 --> Model Class Initialized
INFO - 2016-09-09 16:53:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:53:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 16:53:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:53:12 --> Final output sent to browser
DEBUG - 2016-09-09 16:53:12 --> Total execution time: 0.0571
INFO - 2016-09-09 16:53:13 --> Config Class Initialized
INFO - 2016-09-09 16:53:13 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:13 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:13 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:13 --> URI Class Initialized
INFO - 2016-09-09 16:53:13 --> Router Class Initialized
INFO - 2016-09-09 16:53:13 --> Output Class Initialized
INFO - 2016-09-09 16:53:13 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:13 --> Input Class Initialized
INFO - 2016-09-09 16:53:13 --> Language Class Initialized
INFO - 2016-09-09 16:53:13 --> Loader Class Initialized
INFO - 2016-09-09 16:53:13 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:13 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:13 --> Controller Class Initialized
INFO - 2016-09-09 16:53:13 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:13 --> Model Class Initialized
INFO - 2016-09-09 16:53:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:13 --> Config Class Initialized
INFO - 2016-09-09 16:53:13 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:13 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:13 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:13 --> URI Class Initialized
INFO - 2016-09-09 16:53:13 --> Router Class Initialized
INFO - 2016-09-09 16:53:13 --> Output Class Initialized
INFO - 2016-09-09 16:53:13 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:13 --> Input Class Initialized
INFO - 2016-09-09 16:53:13 --> Language Class Initialized
INFO - 2016-09-09 16:53:13 --> Loader Class Initialized
INFO - 2016-09-09 16:53:13 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:13 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:13 --> Controller Class Initialized
INFO - 2016-09-09 16:53:13 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:13 --> Model Class Initialized
INFO - 2016-09-09 16:53:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:53:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 16:53:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:53:13 --> Final output sent to browser
DEBUG - 2016-09-09 16:53:13 --> Total execution time: 0.0723
INFO - 2016-09-09 16:53:52 --> Config Class Initialized
INFO - 2016-09-09 16:53:52 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:52 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:52 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:52 --> URI Class Initialized
INFO - 2016-09-09 16:53:52 --> Router Class Initialized
INFO - 2016-09-09 16:53:52 --> Output Class Initialized
INFO - 2016-09-09 16:53:52 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:52 --> Input Class Initialized
INFO - 2016-09-09 16:53:52 --> Language Class Initialized
INFO - 2016-09-09 16:53:52 --> Loader Class Initialized
INFO - 2016-09-09 16:53:52 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:52 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:52 --> Controller Class Initialized
INFO - 2016-09-09 16:53:52 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:52 --> Model Class Initialized
INFO - 2016-09-09 16:53:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:52 --> Config Class Initialized
INFO - 2016-09-09 16:53:52 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:52 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:52 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:52 --> URI Class Initialized
INFO - 2016-09-09 16:53:52 --> Router Class Initialized
INFO - 2016-09-09 16:53:52 --> Output Class Initialized
INFO - 2016-09-09 16:53:52 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:52 --> Input Class Initialized
INFO - 2016-09-09 16:53:52 --> Language Class Initialized
INFO - 2016-09-09 16:53:52 --> Loader Class Initialized
INFO - 2016-09-09 16:53:52 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:52 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:52 --> Controller Class Initialized
INFO - 2016-09-09 16:53:52 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:52 --> Model Class Initialized
INFO - 2016-09-09 16:53:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:53:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 16:53:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:53:52 --> Final output sent to browser
DEBUG - 2016-09-09 16:53:52 --> Total execution time: 0.0536
INFO - 2016-09-09 16:53:54 --> Config Class Initialized
INFO - 2016-09-09 16:53:54 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:54 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:54 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:54 --> URI Class Initialized
INFO - 2016-09-09 16:53:54 --> Router Class Initialized
INFO - 2016-09-09 16:53:54 --> Output Class Initialized
INFO - 2016-09-09 16:53:54 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:54 --> Input Class Initialized
INFO - 2016-09-09 16:53:54 --> Language Class Initialized
INFO - 2016-09-09 16:53:54 --> Loader Class Initialized
INFO - 2016-09-09 16:53:54 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:54 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:54 --> Controller Class Initialized
INFO - 2016-09-09 16:53:54 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:54 --> Model Class Initialized
INFO - 2016-09-09 16:53:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:54 --> Config Class Initialized
INFO - 2016-09-09 16:53:54 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:53:54 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:53:54 --> Utf8 Class Initialized
INFO - 2016-09-09 16:53:54 --> URI Class Initialized
INFO - 2016-09-09 16:53:54 --> Router Class Initialized
INFO - 2016-09-09 16:53:54 --> Output Class Initialized
INFO - 2016-09-09 16:53:54 --> Security Class Initialized
DEBUG - 2016-09-09 16:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:53:54 --> Input Class Initialized
INFO - 2016-09-09 16:53:54 --> Language Class Initialized
INFO - 2016-09-09 16:53:54 --> Loader Class Initialized
INFO - 2016-09-09 16:53:54 --> Helper loaded: url_helper
INFO - 2016-09-09 16:53:54 --> Helper loaded: language_helper
INFO - 2016-09-09 16:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:53:54 --> Controller Class Initialized
INFO - 2016-09-09 16:53:54 --> Database Driver Class Initialized
INFO - 2016-09-09 16:53:54 --> Model Class Initialized
INFO - 2016-09-09 16:53:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:53:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:53:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 16:53:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:53:54 --> Final output sent to browser
DEBUG - 2016-09-09 16:53:54 --> Total execution time: 0.0612
INFO - 2016-09-09 16:54:26 --> Config Class Initialized
INFO - 2016-09-09 16:54:26 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:54:26 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:54:26 --> Utf8 Class Initialized
INFO - 2016-09-09 16:54:26 --> URI Class Initialized
INFO - 2016-09-09 16:54:26 --> Router Class Initialized
INFO - 2016-09-09 16:54:26 --> Output Class Initialized
INFO - 2016-09-09 16:54:26 --> Security Class Initialized
DEBUG - 2016-09-09 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:54:26 --> Input Class Initialized
INFO - 2016-09-09 16:54:26 --> Language Class Initialized
INFO - 2016-09-09 16:54:26 --> Loader Class Initialized
INFO - 2016-09-09 16:54:26 --> Helper loaded: url_helper
INFO - 2016-09-09 16:54:26 --> Helper loaded: language_helper
INFO - 2016-09-09 16:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:54:26 --> Controller Class Initialized
INFO - 2016-09-09 16:54:26 --> Database Driver Class Initialized
INFO - 2016-09-09 16:54:26 --> Model Class Initialized
INFO - 2016-09-09 16:54:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:54:26 --> Config Class Initialized
INFO - 2016-09-09 16:54:26 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:54:26 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:54:26 --> Utf8 Class Initialized
INFO - 2016-09-09 16:54:26 --> URI Class Initialized
INFO - 2016-09-09 16:54:26 --> Router Class Initialized
INFO - 2016-09-09 16:54:26 --> Output Class Initialized
INFO - 2016-09-09 16:54:26 --> Security Class Initialized
DEBUG - 2016-09-09 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:54:26 --> Input Class Initialized
INFO - 2016-09-09 16:54:26 --> Language Class Initialized
INFO - 2016-09-09 16:54:26 --> Loader Class Initialized
INFO - 2016-09-09 16:54:26 --> Helper loaded: url_helper
INFO - 2016-09-09 16:54:26 --> Helper loaded: language_helper
INFO - 2016-09-09 16:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:54:26 --> Controller Class Initialized
INFO - 2016-09-09 16:54:26 --> Database Driver Class Initialized
INFO - 2016-09-09 16:54:26 --> Model Class Initialized
INFO - 2016-09-09 16:54:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:54:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:54:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 16:54:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:54:26 --> Final output sent to browser
DEBUG - 2016-09-09 16:54:26 --> Total execution time: 0.0526
INFO - 2016-09-09 16:54:30 --> Config Class Initialized
INFO - 2016-09-09 16:54:30 --> Hooks Class Initialized
DEBUG - 2016-09-09 16:54:30 --> UTF-8 Support Enabled
INFO - 2016-09-09 16:54:30 --> Utf8 Class Initialized
INFO - 2016-09-09 16:54:30 --> URI Class Initialized
INFO - 2016-09-09 16:54:30 --> Router Class Initialized
INFO - 2016-09-09 16:54:30 --> Output Class Initialized
INFO - 2016-09-09 16:54:31 --> Security Class Initialized
DEBUG - 2016-09-09 16:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 16:54:31 --> Input Class Initialized
INFO - 2016-09-09 16:54:31 --> Language Class Initialized
INFO - 2016-09-09 16:54:31 --> Loader Class Initialized
INFO - 2016-09-09 16:54:31 --> Helper loaded: url_helper
INFO - 2016-09-09 16:54:31 --> Helper loaded: language_helper
INFO - 2016-09-09 16:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 16:54:31 --> Controller Class Initialized
INFO - 2016-09-09 16:54:31 --> Database Driver Class Initialized
INFO - 2016-09-09 16:54:31 --> Model Class Initialized
INFO - 2016-09-09 16:54:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 16:54:31 --> Helper loaded: form_helper
INFO - 2016-09-09 16:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 16:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 16:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 16:54:31 --> Final output sent to browser
DEBUG - 2016-09-09 16:54:31 --> Total execution time: 0.0718
INFO - 2016-09-09 17:18:38 --> Config Class Initialized
INFO - 2016-09-09 17:18:38 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:18:38 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:18:38 --> Utf8 Class Initialized
INFO - 2016-09-09 17:18:38 --> URI Class Initialized
INFO - 2016-09-09 17:18:38 --> Router Class Initialized
INFO - 2016-09-09 17:18:38 --> Output Class Initialized
INFO - 2016-09-09 17:18:38 --> Security Class Initialized
DEBUG - 2016-09-09 17:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:18:38 --> Input Class Initialized
INFO - 2016-09-09 17:18:38 --> Language Class Initialized
INFO - 2016-09-09 17:18:38 --> Loader Class Initialized
INFO - 2016-09-09 17:18:38 --> Helper loaded: url_helper
INFO - 2016-09-09 17:18:38 --> Helper loaded: language_helper
INFO - 2016-09-09 17:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:18:38 --> Controller Class Initialized
INFO - 2016-09-09 17:18:38 --> Database Driver Class Initialized
INFO - 2016-09-09 17:18:38 --> Model Class Initialized
INFO - 2016-09-09 17:18:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:18:38 --> Config Class Initialized
INFO - 2016-09-09 17:18:38 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:18:38 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:18:38 --> Utf8 Class Initialized
INFO - 2016-09-09 17:18:38 --> URI Class Initialized
INFO - 2016-09-09 17:18:38 --> Router Class Initialized
INFO - 2016-09-09 17:18:38 --> Output Class Initialized
INFO - 2016-09-09 17:18:38 --> Security Class Initialized
DEBUG - 2016-09-09 17:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:18:38 --> Input Class Initialized
INFO - 2016-09-09 17:18:38 --> Language Class Initialized
INFO - 2016-09-09 17:18:38 --> Loader Class Initialized
INFO - 2016-09-09 17:18:38 --> Helper loaded: url_helper
INFO - 2016-09-09 17:18:38 --> Helper loaded: language_helper
INFO - 2016-09-09 17:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:18:38 --> Controller Class Initialized
INFO - 2016-09-09 17:18:38 --> Database Driver Class Initialized
INFO - 2016-09-09 17:18:38 --> Model Class Initialized
INFO - 2016-09-09 17:18:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:18:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:18:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 17:18:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:18:38 --> Final output sent to browser
DEBUG - 2016-09-09 17:18:38 --> Total execution time: 0.0620
INFO - 2016-09-09 17:19:35 --> Config Class Initialized
INFO - 2016-09-09 17:19:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:19:35 --> Utf8 Class Initialized
INFO - 2016-09-09 17:19:35 --> URI Class Initialized
INFO - 2016-09-09 17:19:35 --> Router Class Initialized
INFO - 2016-09-09 17:19:35 --> Output Class Initialized
INFO - 2016-09-09 17:19:35 --> Security Class Initialized
DEBUG - 2016-09-09 17:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:19:35 --> Input Class Initialized
INFO - 2016-09-09 17:19:35 --> Language Class Initialized
INFO - 2016-09-09 17:19:35 --> Loader Class Initialized
INFO - 2016-09-09 17:19:35 --> Helper loaded: url_helper
INFO - 2016-09-09 17:19:35 --> Helper loaded: language_helper
INFO - 2016-09-09 17:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:19:35 --> Controller Class Initialized
INFO - 2016-09-09 17:19:35 --> Database Driver Class Initialized
INFO - 2016-09-09 17:19:35 --> Model Class Initialized
INFO - 2016-09-09 17:19:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:19:35 --> Config Class Initialized
INFO - 2016-09-09 17:19:35 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:19:35 --> Utf8 Class Initialized
INFO - 2016-09-09 17:19:35 --> URI Class Initialized
INFO - 2016-09-09 17:19:36 --> Router Class Initialized
INFO - 2016-09-09 17:19:36 --> Output Class Initialized
INFO - 2016-09-09 17:19:36 --> Security Class Initialized
DEBUG - 2016-09-09 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:19:36 --> Input Class Initialized
INFO - 2016-09-09 17:19:36 --> Language Class Initialized
INFO - 2016-09-09 17:19:36 --> Loader Class Initialized
INFO - 2016-09-09 17:19:36 --> Helper loaded: url_helper
INFO - 2016-09-09 17:19:36 --> Helper loaded: language_helper
INFO - 2016-09-09 17:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:19:36 --> Controller Class Initialized
INFO - 2016-09-09 17:19:36 --> Database Driver Class Initialized
INFO - 2016-09-09 17:19:36 --> Model Class Initialized
INFO - 2016-09-09 17:19:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 17:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:19:36 --> Final output sent to browser
DEBUG - 2016-09-09 17:19:36 --> Total execution time: 0.0652
INFO - 2016-09-09 17:19:37 --> Config Class Initialized
INFO - 2016-09-09 17:19:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:19:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:19:37 --> Utf8 Class Initialized
INFO - 2016-09-09 17:19:37 --> URI Class Initialized
INFO - 2016-09-09 17:19:37 --> Router Class Initialized
INFO - 2016-09-09 17:19:37 --> Output Class Initialized
INFO - 2016-09-09 17:19:37 --> Security Class Initialized
DEBUG - 2016-09-09 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:19:37 --> Input Class Initialized
INFO - 2016-09-09 17:19:37 --> Language Class Initialized
INFO - 2016-09-09 17:19:37 --> Loader Class Initialized
INFO - 2016-09-09 17:19:37 --> Helper loaded: url_helper
INFO - 2016-09-09 17:19:37 --> Helper loaded: language_helper
INFO - 2016-09-09 17:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:19:37 --> Controller Class Initialized
INFO - 2016-09-09 17:19:37 --> Database Driver Class Initialized
INFO - 2016-09-09 17:19:37 --> Model Class Initialized
INFO - 2016-09-09 17:19:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:19:37 --> Config Class Initialized
INFO - 2016-09-09 17:19:37 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:19:37 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:19:37 --> Utf8 Class Initialized
INFO - 2016-09-09 17:19:37 --> URI Class Initialized
INFO - 2016-09-09 17:19:37 --> Router Class Initialized
INFO - 2016-09-09 17:19:37 --> Output Class Initialized
INFO - 2016-09-09 17:19:37 --> Security Class Initialized
DEBUG - 2016-09-09 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:19:37 --> Input Class Initialized
INFO - 2016-09-09 17:19:37 --> Language Class Initialized
INFO - 2016-09-09 17:19:37 --> Loader Class Initialized
INFO - 2016-09-09 17:19:37 --> Helper loaded: url_helper
INFO - 2016-09-09 17:19:37 --> Helper loaded: language_helper
INFO - 2016-09-09 17:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:19:37 --> Controller Class Initialized
INFO - 2016-09-09 17:19:37 --> Database Driver Class Initialized
INFO - 2016-09-09 17:19:37 --> Model Class Initialized
INFO - 2016-09-09 17:19:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:19:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:19:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 17:19:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:19:37 --> Final output sent to browser
DEBUG - 2016-09-09 17:19:37 --> Total execution time: 0.0808
INFO - 2016-09-09 17:20:33 --> Config Class Initialized
INFO - 2016-09-09 17:20:33 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:20:33 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:20:33 --> Utf8 Class Initialized
INFO - 2016-09-09 17:20:33 --> URI Class Initialized
INFO - 2016-09-09 17:20:33 --> Router Class Initialized
INFO - 2016-09-09 17:20:33 --> Output Class Initialized
INFO - 2016-09-09 17:20:33 --> Security Class Initialized
DEBUG - 2016-09-09 17:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:20:33 --> Input Class Initialized
INFO - 2016-09-09 17:20:33 --> Language Class Initialized
INFO - 2016-09-09 17:20:33 --> Loader Class Initialized
INFO - 2016-09-09 17:20:33 --> Helper loaded: url_helper
INFO - 2016-09-09 17:20:33 --> Helper loaded: language_helper
INFO - 2016-09-09 17:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:20:33 --> Controller Class Initialized
INFO - 2016-09-09 17:20:33 --> Database Driver Class Initialized
INFO - 2016-09-09 17:20:33 --> Model Class Initialized
INFO - 2016-09-09 17:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:20:33 --> Config Class Initialized
INFO - 2016-09-09 17:20:33 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:20:33 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:20:33 --> Utf8 Class Initialized
INFO - 2016-09-09 17:20:33 --> URI Class Initialized
INFO - 2016-09-09 17:20:33 --> Router Class Initialized
INFO - 2016-09-09 17:20:33 --> Output Class Initialized
INFO - 2016-09-09 17:20:33 --> Security Class Initialized
DEBUG - 2016-09-09 17:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:20:33 --> Input Class Initialized
INFO - 2016-09-09 17:20:33 --> Language Class Initialized
INFO - 2016-09-09 17:20:33 --> Loader Class Initialized
INFO - 2016-09-09 17:20:33 --> Helper loaded: url_helper
INFO - 2016-09-09 17:20:33 --> Helper loaded: language_helper
INFO - 2016-09-09 17:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:20:33 --> Controller Class Initialized
INFO - 2016-09-09 17:20:33 --> Database Driver Class Initialized
INFO - 2016-09-09 17:20:33 --> Model Class Initialized
INFO - 2016-09-09 17:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 17:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:20:33 --> Final output sent to browser
DEBUG - 2016-09-09 17:20:33 --> Total execution time: 0.0543
INFO - 2016-09-09 17:20:34 --> Config Class Initialized
INFO - 2016-09-09 17:20:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:20:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:20:34 --> Utf8 Class Initialized
INFO - 2016-09-09 17:20:34 --> URI Class Initialized
INFO - 2016-09-09 17:20:34 --> Router Class Initialized
INFO - 2016-09-09 17:20:34 --> Output Class Initialized
INFO - 2016-09-09 17:20:34 --> Security Class Initialized
DEBUG - 2016-09-09 17:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:20:34 --> Input Class Initialized
INFO - 2016-09-09 17:20:34 --> Language Class Initialized
INFO - 2016-09-09 17:20:34 --> Loader Class Initialized
INFO - 2016-09-09 17:20:34 --> Helper loaded: url_helper
INFO - 2016-09-09 17:20:34 --> Helper loaded: language_helper
INFO - 2016-09-09 17:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:20:34 --> Controller Class Initialized
INFO - 2016-09-09 17:20:34 --> Database Driver Class Initialized
INFO - 2016-09-09 17:20:34 --> Model Class Initialized
INFO - 2016-09-09 17:20:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:20:34 --> Config Class Initialized
INFO - 2016-09-09 17:20:34 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:20:34 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:20:34 --> Utf8 Class Initialized
INFO - 2016-09-09 17:20:34 --> URI Class Initialized
INFO - 2016-09-09 17:20:34 --> Router Class Initialized
INFO - 2016-09-09 17:20:34 --> Output Class Initialized
INFO - 2016-09-09 17:20:34 --> Security Class Initialized
DEBUG - 2016-09-09 17:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:20:34 --> Input Class Initialized
INFO - 2016-09-09 17:20:34 --> Language Class Initialized
INFO - 2016-09-09 17:20:34 --> Loader Class Initialized
INFO - 2016-09-09 17:20:34 --> Helper loaded: url_helper
INFO - 2016-09-09 17:20:34 --> Helper loaded: language_helper
INFO - 2016-09-09 17:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:20:34 --> Controller Class Initialized
INFO - 2016-09-09 17:20:34 --> Database Driver Class Initialized
INFO - 2016-09-09 17:20:34 --> Model Class Initialized
INFO - 2016-09-09 17:20:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:20:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:20:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 17:20:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:20:34 --> Final output sent to browser
DEBUG - 2016-09-09 17:20:34 --> Total execution time: 0.0567
INFO - 2016-09-09 17:22:57 --> Config Class Initialized
INFO - 2016-09-09 17:22:57 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:22:57 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:22:57 --> Utf8 Class Initialized
INFO - 2016-09-09 17:22:57 --> URI Class Initialized
INFO - 2016-09-09 17:22:57 --> Router Class Initialized
INFO - 2016-09-09 17:22:57 --> Output Class Initialized
INFO - 2016-09-09 17:22:57 --> Security Class Initialized
DEBUG - 2016-09-09 17:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:22:57 --> Input Class Initialized
INFO - 2016-09-09 17:22:57 --> Language Class Initialized
INFO - 2016-09-09 17:22:57 --> Loader Class Initialized
INFO - 2016-09-09 17:22:57 --> Helper loaded: url_helper
INFO - 2016-09-09 17:22:57 --> Helper loaded: language_helper
INFO - 2016-09-09 17:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:22:57 --> Controller Class Initialized
INFO - 2016-09-09 17:22:57 --> Database Driver Class Initialized
INFO - 2016-09-09 17:22:57 --> Model Class Initialized
INFO - 2016-09-09 17:22:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:22:57 --> Config Class Initialized
INFO - 2016-09-09 17:22:57 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:22:57 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:22:57 --> Utf8 Class Initialized
INFO - 2016-09-09 17:22:57 --> URI Class Initialized
INFO - 2016-09-09 17:22:57 --> Router Class Initialized
INFO - 2016-09-09 17:22:57 --> Output Class Initialized
INFO - 2016-09-09 17:22:57 --> Security Class Initialized
DEBUG - 2016-09-09 17:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:22:57 --> Input Class Initialized
INFO - 2016-09-09 17:22:57 --> Language Class Initialized
INFO - 2016-09-09 17:22:57 --> Loader Class Initialized
INFO - 2016-09-09 17:22:57 --> Helper loaded: url_helper
INFO - 2016-09-09 17:22:57 --> Helper loaded: language_helper
INFO - 2016-09-09 17:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:22:57 --> Controller Class Initialized
INFO - 2016-09-09 17:22:57 --> Database Driver Class Initialized
INFO - 2016-09-09 17:22:57 --> Model Class Initialized
INFO - 2016-09-09 17:22:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 17:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:22:57 --> Final output sent to browser
DEBUG - 2016-09-09 17:22:57 --> Total execution time: 0.0547
INFO - 2016-09-09 17:22:58 --> Config Class Initialized
INFO - 2016-09-09 17:22:58 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:22:58 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:22:58 --> Utf8 Class Initialized
INFO - 2016-09-09 17:22:58 --> URI Class Initialized
INFO - 2016-09-09 17:22:58 --> Router Class Initialized
INFO - 2016-09-09 17:22:58 --> Output Class Initialized
INFO - 2016-09-09 17:22:58 --> Security Class Initialized
DEBUG - 2016-09-09 17:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:22:58 --> Input Class Initialized
INFO - 2016-09-09 17:22:58 --> Language Class Initialized
INFO - 2016-09-09 17:22:58 --> Loader Class Initialized
INFO - 2016-09-09 17:22:58 --> Helper loaded: url_helper
INFO - 2016-09-09 17:22:58 --> Helper loaded: language_helper
INFO - 2016-09-09 17:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:22:58 --> Controller Class Initialized
INFO - 2016-09-09 17:22:58 --> Database Driver Class Initialized
INFO - 2016-09-09 17:22:58 --> Model Class Initialized
INFO - 2016-09-09 17:22:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:22:58 --> Config Class Initialized
INFO - 2016-09-09 17:22:58 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:22:58 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:22:58 --> Utf8 Class Initialized
INFO - 2016-09-09 17:22:58 --> URI Class Initialized
INFO - 2016-09-09 17:22:58 --> Router Class Initialized
INFO - 2016-09-09 17:22:58 --> Output Class Initialized
INFO - 2016-09-09 17:22:58 --> Security Class Initialized
DEBUG - 2016-09-09 17:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:22:58 --> Input Class Initialized
INFO - 2016-09-09 17:22:58 --> Language Class Initialized
INFO - 2016-09-09 17:22:58 --> Loader Class Initialized
INFO - 2016-09-09 17:22:58 --> Helper loaded: url_helper
INFO - 2016-09-09 17:22:58 --> Helper loaded: language_helper
INFO - 2016-09-09 17:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:22:58 --> Controller Class Initialized
INFO - 2016-09-09 17:22:58 --> Database Driver Class Initialized
INFO - 2016-09-09 17:22:58 --> Model Class Initialized
INFO - 2016-09-09 17:22:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:22:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:22:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 17:22:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:22:58 --> Final output sent to browser
DEBUG - 2016-09-09 17:22:58 --> Total execution time: 0.0566
INFO - 2016-09-09 17:23:50 --> Config Class Initialized
INFO - 2016-09-09 17:23:50 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:23:50 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:23:50 --> Utf8 Class Initialized
INFO - 2016-09-09 17:23:50 --> URI Class Initialized
INFO - 2016-09-09 17:23:50 --> Router Class Initialized
INFO - 2016-09-09 17:23:50 --> Output Class Initialized
INFO - 2016-09-09 17:23:50 --> Security Class Initialized
DEBUG - 2016-09-09 17:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:23:50 --> Input Class Initialized
INFO - 2016-09-09 17:23:50 --> Language Class Initialized
INFO - 2016-09-09 17:23:50 --> Loader Class Initialized
INFO - 2016-09-09 17:23:50 --> Helper loaded: url_helper
INFO - 2016-09-09 17:23:50 --> Helper loaded: language_helper
INFO - 2016-09-09 17:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:23:50 --> Controller Class Initialized
INFO - 2016-09-09 17:23:50 --> Database Driver Class Initialized
INFO - 2016-09-09 17:23:50 --> Model Class Initialized
INFO - 2016-09-09 17:23:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:23:50 --> Config Class Initialized
INFO - 2016-09-09 17:23:50 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:23:50 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:23:50 --> Utf8 Class Initialized
INFO - 2016-09-09 17:23:50 --> URI Class Initialized
INFO - 2016-09-09 17:23:50 --> Router Class Initialized
INFO - 2016-09-09 17:23:50 --> Output Class Initialized
INFO - 2016-09-09 17:23:50 --> Security Class Initialized
DEBUG - 2016-09-09 17:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:23:50 --> Input Class Initialized
INFO - 2016-09-09 17:23:50 --> Language Class Initialized
INFO - 2016-09-09 17:23:50 --> Loader Class Initialized
INFO - 2016-09-09 17:23:50 --> Helper loaded: url_helper
INFO - 2016-09-09 17:23:50 --> Helper loaded: language_helper
INFO - 2016-09-09 17:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:23:50 --> Controller Class Initialized
INFO - 2016-09-09 17:23:50 --> Database Driver Class Initialized
INFO - 2016-09-09 17:23:50 --> Model Class Initialized
INFO - 2016-09-09 17:23:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 17:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:23:50 --> Final output sent to browser
DEBUG - 2016-09-09 17:23:50 --> Total execution time: 0.0561
INFO - 2016-09-09 17:23:51 --> Config Class Initialized
INFO - 2016-09-09 17:23:51 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:23:51 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:23:51 --> Utf8 Class Initialized
INFO - 2016-09-09 17:23:51 --> URI Class Initialized
INFO - 2016-09-09 17:23:51 --> Router Class Initialized
INFO - 2016-09-09 17:23:51 --> Output Class Initialized
INFO - 2016-09-09 17:23:51 --> Security Class Initialized
DEBUG - 2016-09-09 17:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:23:51 --> Input Class Initialized
INFO - 2016-09-09 17:23:51 --> Language Class Initialized
INFO - 2016-09-09 17:23:51 --> Loader Class Initialized
INFO - 2016-09-09 17:23:51 --> Helper loaded: url_helper
INFO - 2016-09-09 17:23:51 --> Helper loaded: language_helper
INFO - 2016-09-09 17:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:23:51 --> Controller Class Initialized
INFO - 2016-09-09 17:23:51 --> Database Driver Class Initialized
INFO - 2016-09-09 17:23:51 --> Model Class Initialized
INFO - 2016-09-09 17:23:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:23:51 --> Config Class Initialized
INFO - 2016-09-09 17:23:51 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:23:51 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:23:51 --> Utf8 Class Initialized
INFO - 2016-09-09 17:23:51 --> URI Class Initialized
INFO - 2016-09-09 17:23:51 --> Router Class Initialized
INFO - 2016-09-09 17:23:51 --> Output Class Initialized
INFO - 2016-09-09 17:23:51 --> Security Class Initialized
DEBUG - 2016-09-09 17:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:23:51 --> Input Class Initialized
INFO - 2016-09-09 17:23:51 --> Language Class Initialized
INFO - 2016-09-09 17:23:51 --> Loader Class Initialized
INFO - 2016-09-09 17:23:51 --> Helper loaded: url_helper
INFO - 2016-09-09 17:23:51 --> Helper loaded: language_helper
INFO - 2016-09-09 17:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:23:51 --> Controller Class Initialized
INFO - 2016-09-09 17:23:51 --> Database Driver Class Initialized
INFO - 2016-09-09 17:23:51 --> Model Class Initialized
INFO - 2016-09-09 17:23:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:23:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:23:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_1.php
INFO - 2016-09-09 17:23:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:23:51 --> Final output sent to browser
DEBUG - 2016-09-09 17:23:51 --> Total execution time: 0.0635
INFO - 2016-09-09 17:24:43 --> Config Class Initialized
INFO - 2016-09-09 17:24:43 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:24:43 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:24:43 --> Utf8 Class Initialized
INFO - 2016-09-09 17:24:43 --> URI Class Initialized
INFO - 2016-09-09 17:24:43 --> Router Class Initialized
INFO - 2016-09-09 17:24:43 --> Output Class Initialized
INFO - 2016-09-09 17:24:43 --> Security Class Initialized
DEBUG - 2016-09-09 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:24:43 --> Input Class Initialized
INFO - 2016-09-09 17:24:43 --> Language Class Initialized
INFO - 2016-09-09 17:24:43 --> Loader Class Initialized
INFO - 2016-09-09 17:24:43 --> Helper loaded: url_helper
INFO - 2016-09-09 17:24:43 --> Helper loaded: language_helper
INFO - 2016-09-09 17:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:24:43 --> Controller Class Initialized
INFO - 2016-09-09 17:24:43 --> Database Driver Class Initialized
INFO - 2016-09-09 17:24:43 --> Model Class Initialized
INFO - 2016-09-09 17:24:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:24:43 --> Config Class Initialized
INFO - 2016-09-09 17:24:43 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:24:43 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:24:43 --> Utf8 Class Initialized
INFO - 2016-09-09 17:24:43 --> URI Class Initialized
INFO - 2016-09-09 17:24:43 --> Router Class Initialized
INFO - 2016-09-09 17:24:43 --> Output Class Initialized
INFO - 2016-09-09 17:24:43 --> Security Class Initialized
DEBUG - 2016-09-09 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:24:43 --> Input Class Initialized
INFO - 2016-09-09 17:24:43 --> Language Class Initialized
INFO - 2016-09-09 17:24:43 --> Loader Class Initialized
INFO - 2016-09-09 17:24:43 --> Helper loaded: url_helper
INFO - 2016-09-09 17:24:43 --> Helper loaded: language_helper
INFO - 2016-09-09 17:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:24:43 --> Controller Class Initialized
INFO - 2016-09-09 17:24:43 --> Database Driver Class Initialized
INFO - 2016-09-09 17:24:43 --> Model Class Initialized
INFO - 2016-09-09 17:24:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-09-09 17:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:24:43 --> Final output sent to browser
DEBUG - 2016-09-09 17:24:43 --> Total execution time: 0.0546
INFO - 2016-09-09 17:24:47 --> Config Class Initialized
INFO - 2016-09-09 17:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:24:47 --> Utf8 Class Initialized
INFO - 2016-09-09 17:24:47 --> URI Class Initialized
INFO - 2016-09-09 17:24:47 --> Router Class Initialized
INFO - 2016-09-09 17:24:47 --> Output Class Initialized
INFO - 2016-09-09 17:24:47 --> Security Class Initialized
DEBUG - 2016-09-09 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:24:47 --> Input Class Initialized
INFO - 2016-09-09 17:24:47 --> Language Class Initialized
INFO - 2016-09-09 17:24:47 --> Loader Class Initialized
INFO - 2016-09-09 17:24:47 --> Helper loaded: url_helper
INFO - 2016-09-09 17:24:47 --> Helper loaded: language_helper
INFO - 2016-09-09 17:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:24:47 --> Controller Class Initialized
INFO - 2016-09-09 17:24:47 --> Database Driver Class Initialized
INFO - 2016-09-09 17:24:47 --> Model Class Initialized
INFO - 2016-09-09 17:24:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:24:47 --> Helper loaded: form_helper
INFO - 2016-09-09 17:24:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:24:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 17:24:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:24:47 --> Final output sent to browser
DEBUG - 2016-09-09 17:24:47 --> Total execution time: 0.0708
INFO - 2016-09-09 17:24:53 --> Config Class Initialized
INFO - 2016-09-09 17:24:53 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:24:53 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:24:53 --> Utf8 Class Initialized
INFO - 2016-09-09 17:24:53 --> URI Class Initialized
INFO - 2016-09-09 17:24:53 --> Router Class Initialized
INFO - 2016-09-09 17:24:53 --> Output Class Initialized
INFO - 2016-09-09 17:24:53 --> Security Class Initialized
DEBUG - 2016-09-09 17:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:24:53 --> Input Class Initialized
INFO - 2016-09-09 17:24:53 --> Language Class Initialized
INFO - 2016-09-09 17:24:53 --> Loader Class Initialized
INFO - 2016-09-09 17:24:53 --> Helper loaded: url_helper
INFO - 2016-09-09 17:24:53 --> Helper loaded: language_helper
INFO - 2016-09-09 17:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:24:53 --> Controller Class Initialized
INFO - 2016-09-09 17:24:53 --> Database Driver Class Initialized
INFO - 2016-09-09 17:24:53 --> Model Class Initialized
INFO - 2016-09-09 17:24:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:24:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:24:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-09 17:24:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:24:53 --> Final output sent to browser
DEBUG - 2016-09-09 17:24:53 --> Total execution time: 0.0646
INFO - 2016-09-09 17:25:08 --> Config Class Initialized
INFO - 2016-09-09 17:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:25:08 --> Utf8 Class Initialized
INFO - 2016-09-09 17:25:08 --> URI Class Initialized
INFO - 2016-09-09 17:25:08 --> Router Class Initialized
INFO - 2016-09-09 17:25:08 --> Output Class Initialized
INFO - 2016-09-09 17:25:08 --> Security Class Initialized
DEBUG - 2016-09-09 17:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:25:08 --> Input Class Initialized
INFO - 2016-09-09 17:25:08 --> Language Class Initialized
INFO - 2016-09-09 17:25:08 --> Loader Class Initialized
INFO - 2016-09-09 17:25:08 --> Helper loaded: url_helper
INFO - 2016-09-09 17:25:08 --> Helper loaded: language_helper
INFO - 2016-09-09 17:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:25:08 --> Controller Class Initialized
INFO - 2016-09-09 17:25:08 --> Database Driver Class Initialized
INFO - 2016-09-09 17:25:08 --> Model Class Initialized
INFO - 2016-09-09 17:25:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:25:08 --> Config Class Initialized
INFO - 2016-09-09 17:25:08 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:25:08 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:25:08 --> Utf8 Class Initialized
INFO - 2016-09-09 17:25:08 --> URI Class Initialized
INFO - 2016-09-09 17:25:08 --> Router Class Initialized
INFO - 2016-09-09 17:25:08 --> Output Class Initialized
INFO - 2016-09-09 17:25:08 --> Security Class Initialized
DEBUG - 2016-09-09 17:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:25:08 --> Input Class Initialized
INFO - 2016-09-09 17:25:08 --> Language Class Initialized
INFO - 2016-09-09 17:25:08 --> Loader Class Initialized
INFO - 2016-09-09 17:25:08 --> Helper loaded: url_helper
INFO - 2016-09-09 17:25:08 --> Helper loaded: language_helper
INFO - 2016-09-09 17:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:25:08 --> Controller Class Initialized
INFO - 2016-09-09 17:25:08 --> Database Driver Class Initialized
INFO - 2016-09-09 17:25:08 --> Model Class Initialized
INFO - 2016-09-09 17:25:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-09 17:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:25:08 --> Final output sent to browser
DEBUG - 2016-09-09 17:25:08 --> Total execution time: 0.0636
INFO - 2016-09-09 17:25:11 --> Config Class Initialized
INFO - 2016-09-09 17:25:11 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:25:11 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:25:11 --> Utf8 Class Initialized
INFO - 2016-09-09 17:25:11 --> URI Class Initialized
INFO - 2016-09-09 17:25:11 --> Router Class Initialized
INFO - 2016-09-09 17:25:11 --> Output Class Initialized
INFO - 2016-09-09 17:25:11 --> Security Class Initialized
DEBUG - 2016-09-09 17:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:25:11 --> Input Class Initialized
INFO - 2016-09-09 17:25:11 --> Language Class Initialized
INFO - 2016-09-09 17:25:11 --> Loader Class Initialized
INFO - 2016-09-09 17:25:11 --> Helper loaded: url_helper
INFO - 2016-09-09 17:25:11 --> Helper loaded: language_helper
INFO - 2016-09-09 17:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:25:11 --> Controller Class Initialized
INFO - 2016-09-09 17:25:11 --> Database Driver Class Initialized
INFO - 2016-09-09 17:25:12 --> Model Class Initialized
INFO - 2016-09-09 17:25:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:25:12 --> Helper loaded: form_helper
INFO - 2016-09-09 17:25:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:25:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 17:25:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:25:12 --> Final output sent to browser
DEBUG - 2016-09-09 17:25:12 --> Total execution time: 0.0668
INFO - 2016-09-09 17:25:21 --> Config Class Initialized
INFO - 2016-09-09 17:25:21 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:25:21 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:25:21 --> Utf8 Class Initialized
INFO - 2016-09-09 17:25:21 --> URI Class Initialized
INFO - 2016-09-09 17:25:21 --> Router Class Initialized
INFO - 2016-09-09 17:25:21 --> Output Class Initialized
INFO - 2016-09-09 17:25:21 --> Security Class Initialized
DEBUG - 2016-09-09 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:25:21 --> Input Class Initialized
INFO - 2016-09-09 17:25:21 --> Language Class Initialized
INFO - 2016-09-09 17:25:21 --> Loader Class Initialized
INFO - 2016-09-09 17:25:21 --> Helper loaded: url_helper
INFO - 2016-09-09 17:25:21 --> Helper loaded: language_helper
INFO - 2016-09-09 17:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:25:21 --> Controller Class Initialized
INFO - 2016-09-09 17:25:21 --> Database Driver Class Initialized
INFO - 2016-09-09 17:25:21 --> Model Class Initialized
INFO - 2016-09-09 17:25:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-09 17:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:25:21 --> Final output sent to browser
DEBUG - 2016-09-09 17:25:21 --> Total execution time: 0.0621
INFO - 2016-09-09 17:25:32 --> Config Class Initialized
INFO - 2016-09-09 17:25:32 --> Hooks Class Initialized
DEBUG - 2016-09-09 17:25:32 --> UTF-8 Support Enabled
INFO - 2016-09-09 17:25:32 --> Utf8 Class Initialized
INFO - 2016-09-09 17:25:32 --> URI Class Initialized
INFO - 2016-09-09 17:25:32 --> Router Class Initialized
INFO - 2016-09-09 17:25:32 --> Output Class Initialized
INFO - 2016-09-09 17:25:32 --> Security Class Initialized
DEBUG - 2016-09-09 17:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-09 17:25:32 --> Input Class Initialized
INFO - 2016-09-09 17:25:32 --> Language Class Initialized
INFO - 2016-09-09 17:25:32 --> Loader Class Initialized
INFO - 2016-09-09 17:25:32 --> Helper loaded: url_helper
INFO - 2016-09-09 17:25:32 --> Helper loaded: language_helper
INFO - 2016-09-09 17:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-09 17:25:32 --> Controller Class Initialized
INFO - 2016-09-09 17:25:32 --> Database Driver Class Initialized
INFO - 2016-09-09 17:25:32 --> Model Class Initialized
INFO - 2016-09-09 17:25:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-09 17:25:32 --> Helper loaded: form_helper
INFO - 2016-09-09 17:25:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-09 17:25:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-09 17:25:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-09 17:25:32 --> Final output sent to browser
DEBUG - 2016-09-09 17:25:32 --> Total execution time: 0.0651
