<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-15 08:00:06 --> Config Class Initialized
INFO - 2016-09-15 08:00:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 08:00:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 08:00:06 --> Utf8 Class Initialized
INFO - 2016-09-15 08:00:06 --> URI Class Initialized
INFO - 2016-09-15 08:00:06 --> Router Class Initialized
INFO - 2016-09-15 08:00:06 --> Output Class Initialized
INFO - 2016-09-15 08:00:06 --> Security Class Initialized
DEBUG - 2016-09-15 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 08:00:06 --> Input Class Initialized
INFO - 2016-09-15 08:00:06 --> Language Class Initialized
INFO - 2016-09-15 08:00:06 --> Loader Class Initialized
INFO - 2016-09-15 08:00:06 --> Helper loaded: url_helper
INFO - 2016-09-15 08:00:06 --> Helper loaded: language_helper
INFO - 2016-09-15 08:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 08:00:06 --> Controller Class Initialized
INFO - 2016-09-15 08:00:06 --> Database Driver Class Initialized
INFO - 2016-09-15 08:00:06 --> Model Class Initialized
INFO - 2016-09-15 08:00:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 08:00:06 --> Config Class Initialized
INFO - 2016-09-15 08:00:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 08:00:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 08:00:06 --> Utf8 Class Initialized
INFO - 2016-09-15 08:00:06 --> URI Class Initialized
INFO - 2016-09-15 08:00:06 --> Router Class Initialized
INFO - 2016-09-15 08:00:06 --> Output Class Initialized
INFO - 2016-09-15 08:00:06 --> Security Class Initialized
DEBUG - 2016-09-15 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 08:00:06 --> Input Class Initialized
INFO - 2016-09-15 08:00:06 --> Language Class Initialized
INFO - 2016-09-15 08:00:06 --> Loader Class Initialized
INFO - 2016-09-15 08:00:06 --> Helper loaded: url_helper
INFO - 2016-09-15 08:00:06 --> Helper loaded: language_helper
INFO - 2016-09-15 08:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 08:00:06 --> Controller Class Initialized
INFO - 2016-09-15 08:00:06 --> Database Driver Class Initialized
INFO - 2016-09-15 08:00:06 --> Model Class Initialized
INFO - 2016-09-15 08:00:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 08:00:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-15 08:00:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-15 08:00:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-15 08:00:06 --> Final output sent to browser
DEBUG - 2016-09-15 08:00:06 --> Total execution time: 0.0798
INFO - 2016-09-15 08:00:08 --> Config Class Initialized
INFO - 2016-09-15 08:00:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 08:00:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 08:00:08 --> Utf8 Class Initialized
INFO - 2016-09-15 08:00:08 --> URI Class Initialized
INFO - 2016-09-15 08:00:08 --> Router Class Initialized
INFO - 2016-09-15 08:00:08 --> Output Class Initialized
INFO - 2016-09-15 08:00:08 --> Security Class Initialized
DEBUG - 2016-09-15 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 08:00:08 --> Input Class Initialized
INFO - 2016-09-15 08:00:08 --> Language Class Initialized
INFO - 2016-09-15 08:00:08 --> Loader Class Initialized
INFO - 2016-09-15 08:00:08 --> Helper loaded: url_helper
INFO - 2016-09-15 08:00:08 --> Helper loaded: language_helper
INFO - 2016-09-15 08:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 08:00:08 --> Controller Class Initialized
INFO - 2016-09-15 08:00:08 --> Database Driver Class Initialized
INFO - 2016-09-15 08:00:08 --> Model Class Initialized
INFO - 2016-09-15 08:00:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 08:00:08 --> Config Class Initialized
INFO - 2016-09-15 08:00:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 08:00:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 08:00:08 --> Utf8 Class Initialized
INFO - 2016-09-15 08:00:08 --> URI Class Initialized
INFO - 2016-09-15 08:00:08 --> Router Class Initialized
INFO - 2016-09-15 08:00:08 --> Output Class Initialized
INFO - 2016-09-15 08:00:08 --> Security Class Initialized
DEBUG - 2016-09-15 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 08:00:08 --> Input Class Initialized
INFO - 2016-09-15 08:00:08 --> Language Class Initialized
INFO - 2016-09-15 08:00:08 --> Loader Class Initialized
INFO - 2016-09-15 08:00:08 --> Helper loaded: url_helper
INFO - 2016-09-15 08:00:08 --> Helper loaded: language_helper
INFO - 2016-09-15 08:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 08:00:08 --> Controller Class Initialized
INFO - 2016-09-15 08:00:08 --> Database Driver Class Initialized
INFO - 2016-09-15 08:00:08 --> Model Class Initialized
INFO - 2016-09-15 08:00:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 08:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-15 08:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-15 08:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-15 08:00:08 --> Final output sent to browser
DEBUG - 2016-09-15 08:00:08 --> Total execution time: 0.0910
INFO - 2016-09-15 09:28:54 --> Config Class Initialized
INFO - 2016-09-15 09:28:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:28:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:28:54 --> Utf8 Class Initialized
INFO - 2016-09-15 09:28:54 --> URI Class Initialized
INFO - 2016-09-15 09:28:54 --> Router Class Initialized
INFO - 2016-09-15 09:28:54 --> Output Class Initialized
INFO - 2016-09-15 09:28:54 --> Security Class Initialized
DEBUG - 2016-09-15 09:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:28:54 --> Input Class Initialized
INFO - 2016-09-15 09:28:54 --> Language Class Initialized
INFO - 2016-09-15 09:28:54 --> Loader Class Initialized
INFO - 2016-09-15 09:28:54 --> Helper loaded: url_helper
INFO - 2016-09-15 09:28:54 --> Helper loaded: language_helper
INFO - 2016-09-15 09:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:28:54 --> Controller Class Initialized
INFO - 2016-09-15 09:28:54 --> Database Driver Class Initialized
INFO - 2016-09-15 09:28:54 --> Model Class Initialized
INFO - 2016-09-15 09:28:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:28:54 --> Config Class Initialized
INFO - 2016-09-15 09:28:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:28:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:28:54 --> Utf8 Class Initialized
INFO - 2016-09-15 09:28:54 --> URI Class Initialized
INFO - 2016-09-15 09:28:54 --> Router Class Initialized
INFO - 2016-09-15 09:28:54 --> Output Class Initialized
INFO - 2016-09-15 09:28:54 --> Security Class Initialized
DEBUG - 2016-09-15 09:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:28:54 --> Input Class Initialized
INFO - 2016-09-15 09:28:54 --> Language Class Initialized
INFO - 2016-09-15 09:28:54 --> Loader Class Initialized
INFO - 2016-09-15 09:28:54 --> Helper loaded: url_helper
INFO - 2016-09-15 09:28:54 --> Helper loaded: language_helper
INFO - 2016-09-15 09:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:28:54 --> Controller Class Initialized
INFO - 2016-09-15 09:28:54 --> Database Driver Class Initialized
INFO - 2016-09-15 09:28:54 --> Model Class Initialized
INFO - 2016-09-15 09:28:54 --> Model Class Initialized
INFO - 2016-09-15 09:28:54 --> Model Class Initialized
INFO - 2016-09-15 09:28:54 --> Model Class Initialized
INFO - 2016-09-15 09:28:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:28:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:28:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-15 09:28:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:28:54 --> Final output sent to browser
DEBUG - 2016-09-15 09:28:54 --> Total execution time: 0.0876
INFO - 2016-09-15 09:28:58 --> Config Class Initialized
INFO - 2016-09-15 09:28:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:28:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:28:58 --> Utf8 Class Initialized
INFO - 2016-09-15 09:28:58 --> URI Class Initialized
INFO - 2016-09-15 09:28:58 --> Router Class Initialized
INFO - 2016-09-15 09:28:58 --> Output Class Initialized
INFO - 2016-09-15 09:28:58 --> Security Class Initialized
DEBUG - 2016-09-15 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:28:58 --> Input Class Initialized
INFO - 2016-09-15 09:28:58 --> Language Class Initialized
INFO - 2016-09-15 09:28:58 --> Loader Class Initialized
INFO - 2016-09-15 09:28:58 --> Helper loaded: url_helper
INFO - 2016-09-15 09:28:58 --> Helper loaded: language_helper
INFO - 2016-09-15 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:28:58 --> Controller Class Initialized
INFO - 2016-09-15 09:28:58 --> Database Driver Class Initialized
INFO - 2016-09-15 09:28:58 --> Model Class Initialized
INFO - 2016-09-15 09:28:58 --> Model Class Initialized
INFO - 2016-09-15 09:28:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:28:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:28:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 09:28:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:28:58 --> Final output sent to browser
DEBUG - 2016-09-15 09:28:58 --> Total execution time: 0.0618
INFO - 2016-09-15 09:29:01 --> Config Class Initialized
INFO - 2016-09-15 09:29:01 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:29:01 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:29:01 --> Utf8 Class Initialized
INFO - 2016-09-15 09:29:01 --> URI Class Initialized
INFO - 2016-09-15 09:29:01 --> Router Class Initialized
INFO - 2016-09-15 09:29:01 --> Output Class Initialized
INFO - 2016-09-15 09:29:01 --> Security Class Initialized
DEBUG - 2016-09-15 09:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:29:01 --> Input Class Initialized
INFO - 2016-09-15 09:29:01 --> Language Class Initialized
INFO - 2016-09-15 09:29:01 --> Loader Class Initialized
INFO - 2016-09-15 09:29:01 --> Helper loaded: url_helper
INFO - 2016-09-15 09:29:01 --> Helper loaded: language_helper
INFO - 2016-09-15 09:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:29:01 --> Controller Class Initialized
INFO - 2016-09-15 09:29:01 --> Database Driver Class Initialized
INFO - 2016-09-15 09:29:01 --> Model Class Initialized
INFO - 2016-09-15 09:29:01 --> Model Class Initialized
INFO - 2016-09-15 09:29:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:29:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:29:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 09:29:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:29:01 --> Final output sent to browser
DEBUG - 2016-09-15 09:29:01 --> Total execution time: 0.0741
INFO - 2016-09-15 09:29:58 --> Config Class Initialized
INFO - 2016-09-15 09:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:29:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:29:58 --> Utf8 Class Initialized
INFO - 2016-09-15 09:29:58 --> URI Class Initialized
INFO - 2016-09-15 09:29:58 --> Router Class Initialized
INFO - 2016-09-15 09:29:58 --> Output Class Initialized
INFO - 2016-09-15 09:29:58 --> Security Class Initialized
DEBUG - 2016-09-15 09:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:29:58 --> Input Class Initialized
INFO - 2016-09-15 09:29:58 --> Language Class Initialized
INFO - 2016-09-15 09:29:58 --> Loader Class Initialized
INFO - 2016-09-15 09:29:58 --> Helper loaded: url_helper
INFO - 2016-09-15 09:29:58 --> Helper loaded: language_helper
INFO - 2016-09-15 09:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:29:58 --> Controller Class Initialized
INFO - 2016-09-15 09:29:58 --> Database Driver Class Initialized
INFO - 2016-09-15 09:29:58 --> Model Class Initialized
INFO - 2016-09-15 09:29:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:29:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:29:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-15 09:29:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:29:58 --> Final output sent to browser
DEBUG - 2016-09-15 09:29:58 --> Total execution time: 0.0654
INFO - 2016-09-15 09:30:14 --> Config Class Initialized
INFO - 2016-09-15 09:30:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:14 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:14 --> URI Class Initialized
INFO - 2016-09-15 09:30:14 --> Router Class Initialized
INFO - 2016-09-15 09:30:14 --> Output Class Initialized
INFO - 2016-09-15 09:30:14 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:14 --> Input Class Initialized
INFO - 2016-09-15 09:30:14 --> Language Class Initialized
INFO - 2016-09-15 09:30:14 --> Loader Class Initialized
INFO - 2016-09-15 09:30:14 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:14 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:14 --> Controller Class Initialized
INFO - 2016-09-15 09:30:14 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:14 --> Model Class Initialized
INFO - 2016-09-15 09:30:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:14 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:14 --> Total execution time: 0.1117
INFO - 2016-09-15 09:30:20 --> Config Class Initialized
INFO - 2016-09-15 09:30:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:20 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:20 --> URI Class Initialized
INFO - 2016-09-15 09:30:20 --> Router Class Initialized
INFO - 2016-09-15 09:30:20 --> Output Class Initialized
INFO - 2016-09-15 09:30:20 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:20 --> Input Class Initialized
INFO - 2016-09-15 09:30:20 --> Language Class Initialized
INFO - 2016-09-15 09:30:20 --> Loader Class Initialized
INFO - 2016-09-15 09:30:20 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:20 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:20 --> Controller Class Initialized
INFO - 2016-09-15 09:30:20 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:20 --> Model Class Initialized
INFO - 2016-09-15 09:30:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:20 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:20 --> Total execution time: 0.0866
INFO - 2016-09-15 09:30:22 --> Config Class Initialized
INFO - 2016-09-15 09:30:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:22 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:22 --> URI Class Initialized
INFO - 2016-09-15 09:30:22 --> Router Class Initialized
INFO - 2016-09-15 09:30:22 --> Output Class Initialized
INFO - 2016-09-15 09:30:22 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:22 --> Input Class Initialized
INFO - 2016-09-15 09:30:22 --> Language Class Initialized
INFO - 2016-09-15 09:30:22 --> Loader Class Initialized
INFO - 2016-09-15 09:30:22 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:22 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:22 --> Controller Class Initialized
INFO - 2016-09-15 09:30:22 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:22 --> Model Class Initialized
INFO - 2016-09-15 09:30:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:22 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:22 --> Total execution time: 0.0944
INFO - 2016-09-15 09:30:24 --> Config Class Initialized
INFO - 2016-09-15 09:30:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:24 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:24 --> URI Class Initialized
INFO - 2016-09-15 09:30:24 --> Router Class Initialized
INFO - 2016-09-15 09:30:24 --> Output Class Initialized
INFO - 2016-09-15 09:30:24 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:24 --> Input Class Initialized
INFO - 2016-09-15 09:30:24 --> Language Class Initialized
INFO - 2016-09-15 09:30:24 --> Loader Class Initialized
INFO - 2016-09-15 09:30:24 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:24 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:24 --> Controller Class Initialized
INFO - 2016-09-15 09:30:24 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:24 --> Model Class Initialized
INFO - 2016-09-15 09:30:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:24 --> Helper loaded: form_helper
INFO - 2016-09-15 09:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:30:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:30:25 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:25 --> Total execution time: 0.1041
INFO - 2016-09-15 09:30:37 --> Config Class Initialized
INFO - 2016-09-15 09:30:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:37 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:37 --> URI Class Initialized
INFO - 2016-09-15 09:30:37 --> Router Class Initialized
INFO - 2016-09-15 09:30:37 --> Output Class Initialized
INFO - 2016-09-15 09:30:37 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:37 --> Input Class Initialized
INFO - 2016-09-15 09:30:37 --> Language Class Initialized
INFO - 2016-09-15 09:30:37 --> Loader Class Initialized
INFO - 2016-09-15 09:30:37 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:37 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:37 --> Controller Class Initialized
INFO - 2016-09-15 09:30:37 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:37 --> Model Class Initialized
INFO - 2016-09-15 09:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:37 --> Config Class Initialized
INFO - 2016-09-15 09:30:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:37 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:37 --> URI Class Initialized
INFO - 2016-09-15 09:30:37 --> Router Class Initialized
INFO - 2016-09-15 09:30:37 --> Output Class Initialized
INFO - 2016-09-15 09:30:37 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:37 --> Input Class Initialized
INFO - 2016-09-15 09:30:37 --> Language Class Initialized
INFO - 2016-09-15 09:30:37 --> Loader Class Initialized
INFO - 2016-09-15 09:30:37 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:37 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:37 --> Controller Class Initialized
INFO - 2016-09-15 09:30:37 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:37 --> Model Class Initialized
INFO - 2016-09-15 09:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:37 --> Helper loaded: form_helper
INFO - 2016-09-15 09:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:30:37 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:37 --> Total execution time: 0.0696
INFO - 2016-09-15 09:30:44 --> Config Class Initialized
INFO - 2016-09-15 09:30:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:44 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:44 --> URI Class Initialized
INFO - 2016-09-15 09:30:44 --> Router Class Initialized
INFO - 2016-09-15 09:30:44 --> Output Class Initialized
INFO - 2016-09-15 09:30:44 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:44 --> Input Class Initialized
INFO - 2016-09-15 09:30:44 --> Language Class Initialized
INFO - 2016-09-15 09:30:44 --> Loader Class Initialized
INFO - 2016-09-15 09:30:44 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:44 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:44 --> Controller Class Initialized
INFO - 2016-09-15 09:30:44 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:44 --> Model Class Initialized
INFO - 2016-09-15 09:30:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:44 --> Config Class Initialized
INFO - 2016-09-15 09:30:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:44 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:44 --> URI Class Initialized
INFO - 2016-09-15 09:30:44 --> Router Class Initialized
INFO - 2016-09-15 09:30:44 --> Output Class Initialized
INFO - 2016-09-15 09:30:44 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:44 --> Input Class Initialized
INFO - 2016-09-15 09:30:44 --> Language Class Initialized
INFO - 2016-09-15 09:30:44 --> Loader Class Initialized
INFO - 2016-09-15 09:30:44 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:44 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:44 --> Controller Class Initialized
INFO - 2016-09-15 09:30:44 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:44 --> Model Class Initialized
INFO - 2016-09-15 09:30:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:44 --> Helper loaded: form_helper
INFO - 2016-09-15 09:30:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:30:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:30:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:30:44 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:44 --> Total execution time: 0.0707
INFO - 2016-09-15 09:30:49 --> Config Class Initialized
INFO - 2016-09-15 09:30:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:49 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:49 --> URI Class Initialized
INFO - 2016-09-15 09:30:49 --> Router Class Initialized
INFO - 2016-09-15 09:30:49 --> Output Class Initialized
INFO - 2016-09-15 09:30:49 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:49 --> Input Class Initialized
INFO - 2016-09-15 09:30:49 --> Language Class Initialized
INFO - 2016-09-15 09:30:49 --> Loader Class Initialized
INFO - 2016-09-15 09:30:49 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:49 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:49 --> Controller Class Initialized
INFO - 2016-09-15 09:30:49 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:49 --> Model Class Initialized
INFO - 2016-09-15 09:30:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:49 --> Config Class Initialized
INFO - 2016-09-15 09:30:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:49 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:49 --> URI Class Initialized
INFO - 2016-09-15 09:30:49 --> Router Class Initialized
INFO - 2016-09-15 09:30:49 --> Output Class Initialized
INFO - 2016-09-15 09:30:49 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:49 --> Input Class Initialized
INFO - 2016-09-15 09:30:49 --> Language Class Initialized
INFO - 2016-09-15 09:30:49 --> Loader Class Initialized
INFO - 2016-09-15 09:30:49 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:49 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:49 --> Controller Class Initialized
INFO - 2016-09-15 09:30:49 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:49 --> Model Class Initialized
INFO - 2016-09-15 09:30:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:49 --> Helper loaded: form_helper
INFO - 2016-09-15 09:30:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:30:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:30:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:30:49 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:49 --> Total execution time: 0.0721
INFO - 2016-09-15 09:30:57 --> Config Class Initialized
INFO - 2016-09-15 09:30:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:57 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:57 --> URI Class Initialized
INFO - 2016-09-15 09:30:57 --> Router Class Initialized
INFO - 2016-09-15 09:30:57 --> Output Class Initialized
INFO - 2016-09-15 09:30:57 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:57 --> Input Class Initialized
INFO - 2016-09-15 09:30:57 --> Language Class Initialized
INFO - 2016-09-15 09:30:57 --> Loader Class Initialized
INFO - 2016-09-15 09:30:57 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:57 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:57 --> Controller Class Initialized
INFO - 2016-09-15 09:30:57 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:57 --> Model Class Initialized
INFO - 2016-09-15 09:30:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:57 --> Config Class Initialized
INFO - 2016-09-15 09:30:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:30:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:30:57 --> Utf8 Class Initialized
INFO - 2016-09-15 09:30:57 --> URI Class Initialized
INFO - 2016-09-15 09:30:57 --> Router Class Initialized
INFO - 2016-09-15 09:30:57 --> Output Class Initialized
INFO - 2016-09-15 09:30:57 --> Security Class Initialized
DEBUG - 2016-09-15 09:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:30:57 --> Input Class Initialized
INFO - 2016-09-15 09:30:57 --> Language Class Initialized
INFO - 2016-09-15 09:30:57 --> Loader Class Initialized
INFO - 2016-09-15 09:30:57 --> Helper loaded: url_helper
INFO - 2016-09-15 09:30:57 --> Helper loaded: language_helper
INFO - 2016-09-15 09:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:30:57 --> Controller Class Initialized
INFO - 2016-09-15 09:30:57 --> Database Driver Class Initialized
INFO - 2016-09-15 09:30:57 --> Model Class Initialized
INFO - 2016-09-15 09:30:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:30:57 --> Helper loaded: form_helper
INFO - 2016-09-15 09:30:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:30:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:30:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:30:57 --> Final output sent to browser
DEBUG - 2016-09-15 09:30:57 --> Total execution time: 0.0691
INFO - 2016-09-15 09:31:03 --> Config Class Initialized
INFO - 2016-09-15 09:31:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:03 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:03 --> URI Class Initialized
INFO - 2016-09-15 09:31:03 --> Router Class Initialized
INFO - 2016-09-15 09:31:03 --> Output Class Initialized
INFO - 2016-09-15 09:31:03 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:03 --> Input Class Initialized
INFO - 2016-09-15 09:31:03 --> Language Class Initialized
INFO - 2016-09-15 09:31:03 --> Loader Class Initialized
INFO - 2016-09-15 09:31:03 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:03 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:03 --> Controller Class Initialized
INFO - 2016-09-15 09:31:03 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:03 --> Model Class Initialized
INFO - 2016-09-15 09:31:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:03 --> Config Class Initialized
INFO - 2016-09-15 09:31:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:03 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:03 --> URI Class Initialized
INFO - 2016-09-15 09:31:03 --> Router Class Initialized
INFO - 2016-09-15 09:31:03 --> Output Class Initialized
INFO - 2016-09-15 09:31:03 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:03 --> Input Class Initialized
INFO - 2016-09-15 09:31:03 --> Language Class Initialized
INFO - 2016-09-15 09:31:03 --> Loader Class Initialized
INFO - 2016-09-15 09:31:03 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:03 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:03 --> Controller Class Initialized
INFO - 2016-09-15 09:31:03 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:03 --> Model Class Initialized
INFO - 2016-09-15 09:31:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:03 --> Helper loaded: form_helper
INFO - 2016-09-15 09:31:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:31:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:04 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:04 --> Total execution time: 0.0711
INFO - 2016-09-15 09:31:08 --> Config Class Initialized
INFO - 2016-09-15 09:31:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:08 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:08 --> URI Class Initialized
INFO - 2016-09-15 09:31:08 --> Router Class Initialized
INFO - 2016-09-15 09:31:08 --> Output Class Initialized
INFO - 2016-09-15 09:31:08 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:08 --> Input Class Initialized
INFO - 2016-09-15 09:31:08 --> Language Class Initialized
INFO - 2016-09-15 09:31:08 --> Loader Class Initialized
INFO - 2016-09-15 09:31:08 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:08 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:08 --> Controller Class Initialized
INFO - 2016-09-15 09:31:08 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:08 --> Model Class Initialized
INFO - 2016-09-15 09:31:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:08 --> Config Class Initialized
INFO - 2016-09-15 09:31:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:08 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:08 --> URI Class Initialized
INFO - 2016-09-15 09:31:08 --> Router Class Initialized
INFO - 2016-09-15 09:31:08 --> Output Class Initialized
INFO - 2016-09-15 09:31:08 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:08 --> Input Class Initialized
INFO - 2016-09-15 09:31:08 --> Language Class Initialized
INFO - 2016-09-15 09:31:08 --> Loader Class Initialized
INFO - 2016-09-15 09:31:08 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:08 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:08 --> Controller Class Initialized
INFO - 2016-09-15 09:31:08 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:08 --> Model Class Initialized
INFO - 2016-09-15 09:31:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:08 --> Helper loaded: form_helper
INFO - 2016-09-15 09:31:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:31:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:08 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:08 --> Total execution time: 0.0675
INFO - 2016-09-15 09:31:13 --> Config Class Initialized
INFO - 2016-09-15 09:31:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:13 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:13 --> URI Class Initialized
INFO - 2016-09-15 09:31:13 --> Router Class Initialized
INFO - 2016-09-15 09:31:13 --> Output Class Initialized
INFO - 2016-09-15 09:31:13 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:13 --> Input Class Initialized
INFO - 2016-09-15 09:31:13 --> Language Class Initialized
INFO - 2016-09-15 09:31:13 --> Loader Class Initialized
INFO - 2016-09-15 09:31:13 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:13 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:13 --> Controller Class Initialized
INFO - 2016-09-15 09:31:13 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:13 --> Model Class Initialized
INFO - 2016-09-15 09:31:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:13 --> Config Class Initialized
INFO - 2016-09-15 09:31:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:13 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:13 --> URI Class Initialized
INFO - 2016-09-15 09:31:13 --> Router Class Initialized
INFO - 2016-09-15 09:31:13 --> Output Class Initialized
INFO - 2016-09-15 09:31:13 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:13 --> Input Class Initialized
INFO - 2016-09-15 09:31:13 --> Language Class Initialized
INFO - 2016-09-15 09:31:13 --> Loader Class Initialized
INFO - 2016-09-15 09:31:13 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:13 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:13 --> Controller Class Initialized
INFO - 2016-09-15 09:31:13 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:13 --> Model Class Initialized
INFO - 2016-09-15 09:31:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:13 --> Helper loaded: form_helper
INFO - 2016-09-15 09:31:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:31:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:13 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:13 --> Total execution time: 0.0773
INFO - 2016-09-15 09:31:19 --> Config Class Initialized
INFO - 2016-09-15 09:31:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:19 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:19 --> URI Class Initialized
INFO - 2016-09-15 09:31:19 --> Router Class Initialized
INFO - 2016-09-15 09:31:19 --> Output Class Initialized
INFO - 2016-09-15 09:31:19 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:19 --> Input Class Initialized
INFO - 2016-09-15 09:31:19 --> Language Class Initialized
INFO - 2016-09-15 09:31:19 --> Loader Class Initialized
INFO - 2016-09-15 09:31:19 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:19 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:19 --> Controller Class Initialized
INFO - 2016-09-15 09:31:19 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:19 --> Model Class Initialized
INFO - 2016-09-15 09:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:19 --> Config Class Initialized
INFO - 2016-09-15 09:31:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:19 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:19 --> URI Class Initialized
INFO - 2016-09-15 09:31:19 --> Router Class Initialized
INFO - 2016-09-15 09:31:19 --> Output Class Initialized
INFO - 2016-09-15 09:31:19 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:19 --> Input Class Initialized
INFO - 2016-09-15 09:31:19 --> Language Class Initialized
INFO - 2016-09-15 09:31:19 --> Loader Class Initialized
INFO - 2016-09-15 09:31:19 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:19 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:19 --> Controller Class Initialized
INFO - 2016-09-15 09:31:19 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:19 --> Model Class Initialized
INFO - 2016-09-15 09:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:19 --> Helper loaded: form_helper
INFO - 2016-09-15 09:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:19 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:19 --> Total execution time: 0.0642
INFO - 2016-09-15 09:31:29 --> Config Class Initialized
INFO - 2016-09-15 09:31:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:29 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:29 --> URI Class Initialized
INFO - 2016-09-15 09:31:29 --> Router Class Initialized
INFO - 2016-09-15 09:31:29 --> Output Class Initialized
INFO - 2016-09-15 09:31:29 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:29 --> Input Class Initialized
INFO - 2016-09-15 09:31:29 --> Language Class Initialized
INFO - 2016-09-15 09:31:29 --> Loader Class Initialized
INFO - 2016-09-15 09:31:29 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:29 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:29 --> Controller Class Initialized
INFO - 2016-09-15 09:31:29 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:29 --> Model Class Initialized
INFO - 2016-09-15 09:31:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-15 09:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:29 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:29 --> Total execution time: 0.0596
INFO - 2016-09-15 09:31:37 --> Config Class Initialized
INFO - 2016-09-15 09:31:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:37 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:37 --> URI Class Initialized
INFO - 2016-09-15 09:31:37 --> Router Class Initialized
INFO - 2016-09-15 09:31:37 --> Output Class Initialized
INFO - 2016-09-15 09:31:37 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:37 --> Input Class Initialized
INFO - 2016-09-15 09:31:37 --> Language Class Initialized
INFO - 2016-09-15 09:31:37 --> Loader Class Initialized
INFO - 2016-09-15 09:31:37 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:37 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:37 --> Controller Class Initialized
INFO - 2016-09-15 09:31:37 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:37 --> Model Class Initialized
INFO - 2016-09-15 09:31:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:37 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:37 --> Total execution time: 0.0659
INFO - 2016-09-15 09:31:39 --> Config Class Initialized
INFO - 2016-09-15 09:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:39 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:39 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:39 --> URI Class Initialized
INFO - 2016-09-15 09:31:39 --> Router Class Initialized
INFO - 2016-09-15 09:31:39 --> Output Class Initialized
INFO - 2016-09-15 09:31:39 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:39 --> Input Class Initialized
INFO - 2016-09-15 09:31:39 --> Language Class Initialized
INFO - 2016-09-15 09:31:39 --> Loader Class Initialized
INFO - 2016-09-15 09:31:39 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:39 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:39 --> Controller Class Initialized
INFO - 2016-09-15 09:31:39 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:39 --> Model Class Initialized
INFO - 2016-09-15 09:31:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:39 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:39 --> Total execution time: 0.0749
INFO - 2016-09-15 09:31:40 --> Config Class Initialized
INFO - 2016-09-15 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:40 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:40 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:40 --> URI Class Initialized
INFO - 2016-09-15 09:31:40 --> Router Class Initialized
INFO - 2016-09-15 09:31:40 --> Output Class Initialized
INFO - 2016-09-15 09:31:40 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:40 --> Input Class Initialized
INFO - 2016-09-15 09:31:40 --> Language Class Initialized
INFO - 2016-09-15 09:31:40 --> Loader Class Initialized
INFO - 2016-09-15 09:31:40 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:40 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:40 --> Controller Class Initialized
INFO - 2016-09-15 09:31:40 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:40 --> Model Class Initialized
INFO - 2016-09-15 09:31:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:40 --> Config Class Initialized
INFO - 2016-09-15 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:40 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:40 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:40 --> URI Class Initialized
INFO - 2016-09-15 09:31:40 --> Router Class Initialized
INFO - 2016-09-15 09:31:40 --> Output Class Initialized
INFO - 2016-09-15 09:31:40 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:40 --> Input Class Initialized
INFO - 2016-09-15 09:31:40 --> Language Class Initialized
INFO - 2016-09-15 09:31:40 --> Loader Class Initialized
INFO - 2016-09-15 09:31:40 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:40 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:40 --> Controller Class Initialized
INFO - 2016-09-15 09:31:40 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:40 --> Model Class Initialized
INFO - 2016-09-15 09:31:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-15 09:31:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:40 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:40 --> Total execution time: 0.0594
INFO - 2016-09-15 09:31:48 --> Config Class Initialized
INFO - 2016-09-15 09:31:48 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:31:48 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:31:48 --> Utf8 Class Initialized
INFO - 2016-09-15 09:31:48 --> URI Class Initialized
INFO - 2016-09-15 09:31:48 --> Router Class Initialized
INFO - 2016-09-15 09:31:48 --> Output Class Initialized
INFO - 2016-09-15 09:31:48 --> Security Class Initialized
DEBUG - 2016-09-15 09:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:31:48 --> Input Class Initialized
INFO - 2016-09-15 09:31:48 --> Language Class Initialized
INFO - 2016-09-15 09:31:48 --> Loader Class Initialized
INFO - 2016-09-15 09:31:48 --> Helper loaded: url_helper
INFO - 2016-09-15 09:31:48 --> Helper loaded: language_helper
INFO - 2016-09-15 09:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:31:48 --> Controller Class Initialized
INFO - 2016-09-15 09:31:48 --> Database Driver Class Initialized
INFO - 2016-09-15 09:31:48 --> Model Class Initialized
INFO - 2016-09-15 09:31:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:31:48 --> Helper loaded: form_helper
INFO - 2016-09-15 09:31:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:31:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 09:31:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:31:48 --> Final output sent to browser
DEBUG - 2016-09-15 09:31:48 --> Total execution time: 0.0655
INFO - 2016-09-15 09:32:04 --> Config Class Initialized
INFO - 2016-09-15 09:32:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:32:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:32:04 --> Utf8 Class Initialized
INFO - 2016-09-15 09:32:04 --> URI Class Initialized
INFO - 2016-09-15 09:32:04 --> Router Class Initialized
INFO - 2016-09-15 09:32:04 --> Output Class Initialized
INFO - 2016-09-15 09:32:04 --> Security Class Initialized
DEBUG - 2016-09-15 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:32:04 --> Input Class Initialized
INFO - 2016-09-15 09:32:04 --> Language Class Initialized
INFO - 2016-09-15 09:32:04 --> Loader Class Initialized
INFO - 2016-09-15 09:32:04 --> Helper loaded: url_helper
INFO - 2016-09-15 09:32:04 --> Helper loaded: language_helper
INFO - 2016-09-15 09:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:32:04 --> Controller Class Initialized
INFO - 2016-09-15 09:32:04 --> Database Driver Class Initialized
INFO - 2016-09-15 09:32:04 --> Model Class Initialized
INFO - 2016-09-15 09:32:04 --> Model Class Initialized
INFO - 2016-09-15 09:32:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:32:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:32:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 09:32:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:32:04 --> Final output sent to browser
DEBUG - 2016-09-15 09:32:04 --> Total execution time: 0.0614
INFO - 2016-09-15 09:32:49 --> Config Class Initialized
INFO - 2016-09-15 09:32:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:32:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:32:49 --> Utf8 Class Initialized
INFO - 2016-09-15 09:32:49 --> URI Class Initialized
INFO - 2016-09-15 09:32:49 --> Router Class Initialized
INFO - 2016-09-15 09:32:49 --> Output Class Initialized
INFO - 2016-09-15 09:32:49 --> Security Class Initialized
DEBUG - 2016-09-15 09:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:32:49 --> Input Class Initialized
INFO - 2016-09-15 09:32:49 --> Language Class Initialized
INFO - 2016-09-15 09:32:49 --> Loader Class Initialized
INFO - 2016-09-15 09:32:49 --> Helper loaded: url_helper
INFO - 2016-09-15 09:32:49 --> Helper loaded: language_helper
INFO - 2016-09-15 09:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:32:49 --> Controller Class Initialized
INFO - 2016-09-15 09:32:49 --> Database Driver Class Initialized
INFO - 2016-09-15 09:32:49 --> Model Class Initialized
INFO - 2016-09-15 09:32:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:32:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:32:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-15 09:32:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:32:49 --> Final output sent to browser
DEBUG - 2016-09-15 09:32:49 --> Total execution time: 0.0631
INFO - 2016-09-15 09:33:00 --> Config Class Initialized
INFO - 2016-09-15 09:33:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:33:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:33:00 --> Utf8 Class Initialized
INFO - 2016-09-15 09:33:00 --> URI Class Initialized
INFO - 2016-09-15 09:33:00 --> Router Class Initialized
INFO - 2016-09-15 09:33:00 --> Output Class Initialized
INFO - 2016-09-15 09:33:00 --> Security Class Initialized
DEBUG - 2016-09-15 09:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:33:00 --> Input Class Initialized
INFO - 2016-09-15 09:33:00 --> Language Class Initialized
INFO - 2016-09-15 09:33:00 --> Loader Class Initialized
INFO - 2016-09-15 09:33:00 --> Helper loaded: url_helper
INFO - 2016-09-15 09:33:00 --> Helper loaded: language_helper
INFO - 2016-09-15 09:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:33:00 --> Controller Class Initialized
INFO - 2016-09-15 09:33:00 --> Database Driver Class Initialized
INFO - 2016-09-15 09:33:00 --> Model Class Initialized
INFO - 2016-09-15 09:33:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:33:00 --> Final output sent to browser
DEBUG - 2016-09-15 09:33:00 --> Total execution time: 0.0753
INFO - 2016-09-15 09:38:12 --> Config Class Initialized
INFO - 2016-09-15 09:38:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:12 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:12 --> URI Class Initialized
INFO - 2016-09-15 09:38:12 --> Router Class Initialized
INFO - 2016-09-15 09:38:12 --> Output Class Initialized
INFO - 2016-09-15 09:38:12 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:12 --> Input Class Initialized
INFO - 2016-09-15 09:38:12 --> Language Class Initialized
INFO - 2016-09-15 09:38:12 --> Loader Class Initialized
INFO - 2016-09-15 09:38:12 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:12 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:12 --> Controller Class Initialized
INFO - 2016-09-15 09:38:12 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:12 --> Model Class Initialized
INFO - 2016-09-15 09:38:12 --> Model Class Initialized
INFO - 2016-09-15 09:38:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:12 --> Helper loaded: form_helper
INFO - 2016-09-15 09:38:12 --> Form Validation Class Initialized
INFO - 2016-09-15 09:38:12 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:38:12 --> Config Class Initialized
INFO - 2016-09-15 09:38:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:12 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:12 --> URI Class Initialized
INFO - 2016-09-15 09:38:12 --> Router Class Initialized
INFO - 2016-09-15 09:38:12 --> Output Class Initialized
INFO - 2016-09-15 09:38:12 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:12 --> Input Class Initialized
INFO - 2016-09-15 09:38:12 --> Language Class Initialized
INFO - 2016-09-15 09:38:12 --> Loader Class Initialized
INFO - 2016-09-15 09:38:12 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:12 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:12 --> Controller Class Initialized
INFO - 2016-09-15 09:38:12 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:12 --> Model Class Initialized
INFO - 2016-09-15 09:38:12 --> Model Class Initialized
INFO - 2016-09-15 09:38:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:12 --> Model Class Initialized
INFO - 2016-09-15 09:38:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:38:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:38:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:38:12 --> Final output sent to browser
DEBUG - 2016-09-15 09:38:12 --> Total execution time: 0.0746
INFO - 2016-09-15 09:38:22 --> Config Class Initialized
INFO - 2016-09-15 09:38:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:22 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:22 --> URI Class Initialized
INFO - 2016-09-15 09:38:22 --> Router Class Initialized
INFO - 2016-09-15 09:38:22 --> Output Class Initialized
INFO - 2016-09-15 09:38:22 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:22 --> Input Class Initialized
INFO - 2016-09-15 09:38:22 --> Language Class Initialized
INFO - 2016-09-15 09:38:22 --> Loader Class Initialized
INFO - 2016-09-15 09:38:22 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:22 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:22 --> Controller Class Initialized
INFO - 2016-09-15 09:38:22 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:22 --> Model Class Initialized
INFO - 2016-09-15 09:38:22 --> Model Class Initialized
INFO - 2016-09-15 09:38:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:22 --> Final output sent to browser
DEBUG - 2016-09-15 09:38:22 --> Total execution time: 0.0527
INFO - 2016-09-15 09:38:26 --> Config Class Initialized
INFO - 2016-09-15 09:38:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:26 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:26 --> URI Class Initialized
INFO - 2016-09-15 09:38:26 --> Router Class Initialized
INFO - 2016-09-15 09:38:26 --> Output Class Initialized
INFO - 2016-09-15 09:38:26 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:26 --> Input Class Initialized
INFO - 2016-09-15 09:38:26 --> Language Class Initialized
INFO - 2016-09-15 09:38:26 --> Loader Class Initialized
INFO - 2016-09-15 09:38:26 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:26 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:26 --> Controller Class Initialized
INFO - 2016-09-15 09:38:26 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:26 --> Model Class Initialized
INFO - 2016-09-15 09:38:26 --> Model Class Initialized
INFO - 2016-09-15 09:38:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:26 --> Helper loaded: form_helper
INFO - 2016-09-15 09:38:26 --> Form Validation Class Initialized
INFO - 2016-09-15 09:38:26 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:38:26 --> Config Class Initialized
INFO - 2016-09-15 09:38:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:26 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:26 --> URI Class Initialized
INFO - 2016-09-15 09:38:26 --> Router Class Initialized
INFO - 2016-09-15 09:38:26 --> Output Class Initialized
INFO - 2016-09-15 09:38:26 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:26 --> Input Class Initialized
INFO - 2016-09-15 09:38:26 --> Language Class Initialized
INFO - 2016-09-15 09:38:26 --> Loader Class Initialized
INFO - 2016-09-15 09:38:26 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:26 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:26 --> Controller Class Initialized
INFO - 2016-09-15 09:38:26 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:26 --> Model Class Initialized
INFO - 2016-09-15 09:38:26 --> Model Class Initialized
INFO - 2016-09-15 09:38:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:26 --> Model Class Initialized
INFO - 2016-09-15 09:38:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:38:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:38:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:38:26 --> Final output sent to browser
DEBUG - 2016-09-15 09:38:26 --> Total execution time: 0.0696
INFO - 2016-09-15 09:38:43 --> Config Class Initialized
INFO - 2016-09-15 09:38:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:43 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:43 --> URI Class Initialized
INFO - 2016-09-15 09:38:43 --> Router Class Initialized
INFO - 2016-09-15 09:38:43 --> Output Class Initialized
INFO - 2016-09-15 09:38:43 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:43 --> Input Class Initialized
INFO - 2016-09-15 09:38:43 --> Language Class Initialized
INFO - 2016-09-15 09:38:43 --> Loader Class Initialized
INFO - 2016-09-15 09:38:43 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:43 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:43 --> Controller Class Initialized
INFO - 2016-09-15 09:38:43 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:43 --> Model Class Initialized
INFO - 2016-09-15 09:38:43 --> Model Class Initialized
INFO - 2016-09-15 09:38:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:38:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 09:38:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:38:43 --> Final output sent to browser
DEBUG - 2016-09-15 09:38:43 --> Total execution time: 0.0601
INFO - 2016-09-15 09:38:46 --> Config Class Initialized
INFO - 2016-09-15 09:38:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:38:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:38:46 --> Utf8 Class Initialized
INFO - 2016-09-15 09:38:46 --> URI Class Initialized
INFO - 2016-09-15 09:38:46 --> Router Class Initialized
INFO - 2016-09-15 09:38:46 --> Output Class Initialized
INFO - 2016-09-15 09:38:46 --> Security Class Initialized
DEBUG - 2016-09-15 09:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:38:46 --> Input Class Initialized
INFO - 2016-09-15 09:38:46 --> Language Class Initialized
INFO - 2016-09-15 09:38:46 --> Loader Class Initialized
INFO - 2016-09-15 09:38:46 --> Helper loaded: url_helper
INFO - 2016-09-15 09:38:46 --> Helper loaded: language_helper
INFO - 2016-09-15 09:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:38:46 --> Controller Class Initialized
INFO - 2016-09-15 09:38:46 --> Database Driver Class Initialized
INFO - 2016-09-15 09:38:46 --> Model Class Initialized
INFO - 2016-09-15 09:38:46 --> Model Class Initialized
INFO - 2016-09-15 09:38:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:38:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:38:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 09:38:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:38:46 --> Final output sent to browser
DEBUG - 2016-09-15 09:38:46 --> Total execution time: 0.0613
INFO - 2016-09-15 09:43:50 --> Config Class Initialized
INFO - 2016-09-15 09:43:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:43:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:43:50 --> Utf8 Class Initialized
INFO - 2016-09-15 09:43:50 --> URI Class Initialized
INFO - 2016-09-15 09:43:50 --> Router Class Initialized
INFO - 2016-09-15 09:43:50 --> Output Class Initialized
INFO - 2016-09-15 09:43:50 --> Security Class Initialized
DEBUG - 2016-09-15 09:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:43:50 --> Input Class Initialized
INFO - 2016-09-15 09:43:50 --> Language Class Initialized
INFO - 2016-09-15 09:43:50 --> Loader Class Initialized
INFO - 2016-09-15 09:43:50 --> Helper loaded: url_helper
INFO - 2016-09-15 09:43:50 --> Helper loaded: language_helper
INFO - 2016-09-15 09:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:43:50 --> Controller Class Initialized
INFO - 2016-09-15 09:43:50 --> Database Driver Class Initialized
INFO - 2016-09-15 09:43:50 --> Model Class Initialized
INFO - 2016-09-15 09:43:50 --> Model Class Initialized
INFO - 2016-09-15 09:43:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:43:50 --> Helper loaded: form_helper
INFO - 2016-09-15 09:43:50 --> Form Validation Class Initialized
INFO - 2016-09-15 09:43:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:43:50 --> Config Class Initialized
INFO - 2016-09-15 09:43:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:43:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:43:50 --> Utf8 Class Initialized
INFO - 2016-09-15 09:43:50 --> URI Class Initialized
INFO - 2016-09-15 09:43:50 --> Router Class Initialized
INFO - 2016-09-15 09:43:50 --> Output Class Initialized
INFO - 2016-09-15 09:43:50 --> Security Class Initialized
DEBUG - 2016-09-15 09:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:43:50 --> Input Class Initialized
INFO - 2016-09-15 09:43:50 --> Language Class Initialized
INFO - 2016-09-15 09:43:50 --> Loader Class Initialized
INFO - 2016-09-15 09:43:50 --> Helper loaded: url_helper
INFO - 2016-09-15 09:43:50 --> Helper loaded: language_helper
INFO - 2016-09-15 09:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:43:50 --> Controller Class Initialized
INFO - 2016-09-15 09:43:50 --> Database Driver Class Initialized
INFO - 2016-09-15 09:43:50 --> Model Class Initialized
INFO - 2016-09-15 09:43:50 --> Model Class Initialized
INFO - 2016-09-15 09:43:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:43:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:43:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:43:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:43:50 --> Final output sent to browser
DEBUG - 2016-09-15 09:43:50 --> Total execution time: 0.0691
INFO - 2016-09-15 09:44:08 --> Config Class Initialized
INFO - 2016-09-15 09:44:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:44:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:44:08 --> Utf8 Class Initialized
INFO - 2016-09-15 09:44:08 --> URI Class Initialized
INFO - 2016-09-15 09:44:08 --> Router Class Initialized
INFO - 2016-09-15 09:44:08 --> Output Class Initialized
INFO - 2016-09-15 09:44:08 --> Security Class Initialized
DEBUG - 2016-09-15 09:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:44:08 --> Input Class Initialized
INFO - 2016-09-15 09:44:08 --> Language Class Initialized
INFO - 2016-09-15 09:44:08 --> Loader Class Initialized
INFO - 2016-09-15 09:44:08 --> Helper loaded: url_helper
INFO - 2016-09-15 09:44:08 --> Helper loaded: language_helper
INFO - 2016-09-15 09:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:44:08 --> Controller Class Initialized
INFO - 2016-09-15 09:44:08 --> Database Driver Class Initialized
INFO - 2016-09-15 09:44:08 --> Model Class Initialized
INFO - 2016-09-15 09:44:08 --> Model Class Initialized
INFO - 2016-09-15 09:44:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:44:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:44:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 09:44:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:44:08 --> Final output sent to browser
DEBUG - 2016-09-15 09:44:08 --> Total execution time: 0.0606
INFO - 2016-09-15 09:44:16 --> Config Class Initialized
INFO - 2016-09-15 09:44:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:44:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:44:16 --> Utf8 Class Initialized
INFO - 2016-09-15 09:44:16 --> URI Class Initialized
INFO - 2016-09-15 09:44:16 --> Router Class Initialized
INFO - 2016-09-15 09:44:16 --> Output Class Initialized
INFO - 2016-09-15 09:44:16 --> Security Class Initialized
DEBUG - 2016-09-15 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:44:16 --> Input Class Initialized
INFO - 2016-09-15 09:44:16 --> Language Class Initialized
INFO - 2016-09-15 09:44:16 --> Loader Class Initialized
INFO - 2016-09-15 09:44:16 --> Helper loaded: url_helper
INFO - 2016-09-15 09:44:16 --> Helper loaded: language_helper
INFO - 2016-09-15 09:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:44:16 --> Controller Class Initialized
INFO - 2016-09-15 09:44:16 --> Database Driver Class Initialized
INFO - 2016-09-15 09:44:16 --> Model Class Initialized
INFO - 2016-09-15 09:44:16 --> Model Class Initialized
INFO - 2016-09-15 09:44:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:44:16 --> Config Class Initialized
INFO - 2016-09-15 09:44:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:44:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:44:16 --> Utf8 Class Initialized
INFO - 2016-09-15 09:44:16 --> URI Class Initialized
INFO - 2016-09-15 09:44:16 --> Router Class Initialized
INFO - 2016-09-15 09:44:16 --> Output Class Initialized
INFO - 2016-09-15 09:44:16 --> Security Class Initialized
DEBUG - 2016-09-15 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:44:16 --> Input Class Initialized
INFO - 2016-09-15 09:44:16 --> Language Class Initialized
INFO - 2016-09-15 09:44:16 --> Loader Class Initialized
INFO - 2016-09-15 09:44:16 --> Helper loaded: url_helper
INFO - 2016-09-15 09:44:16 --> Helper loaded: language_helper
INFO - 2016-09-15 09:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:44:16 --> Controller Class Initialized
INFO - 2016-09-15 09:44:16 --> Database Driver Class Initialized
INFO - 2016-09-15 09:44:16 --> Model Class Initialized
INFO - 2016-09-15 09:44:16 --> Model Class Initialized
INFO - 2016-09-15 09:44:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:44:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:44:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 09:44:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:44:16 --> Final output sent to browser
DEBUG - 2016-09-15 09:44:16 --> Total execution time: 0.0613
INFO - 2016-09-15 09:44:25 --> Config Class Initialized
INFO - 2016-09-15 09:44:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:44:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:44:25 --> Utf8 Class Initialized
INFO - 2016-09-15 09:44:25 --> URI Class Initialized
INFO - 2016-09-15 09:44:25 --> Router Class Initialized
INFO - 2016-09-15 09:44:25 --> Output Class Initialized
INFO - 2016-09-15 09:44:25 --> Security Class Initialized
DEBUG - 2016-09-15 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:44:25 --> Input Class Initialized
INFO - 2016-09-15 09:44:25 --> Language Class Initialized
INFO - 2016-09-15 09:44:25 --> Loader Class Initialized
INFO - 2016-09-15 09:44:25 --> Helper loaded: url_helper
INFO - 2016-09-15 09:44:25 --> Helper loaded: language_helper
INFO - 2016-09-15 09:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:44:25 --> Controller Class Initialized
INFO - 2016-09-15 09:44:25 --> Database Driver Class Initialized
INFO - 2016-09-15 09:44:25 --> Model Class Initialized
INFO - 2016-09-15 09:44:25 --> Model Class Initialized
INFO - 2016-09-15 09:44:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:44:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:44:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 09:44:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:44:25 --> Final output sent to browser
DEBUG - 2016-09-15 09:44:25 --> Total execution time: 0.0627
INFO - 2016-09-15 09:48:25 --> Config Class Initialized
INFO - 2016-09-15 09:48:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:48:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:48:25 --> Utf8 Class Initialized
INFO - 2016-09-15 09:48:25 --> URI Class Initialized
INFO - 2016-09-15 09:48:25 --> Router Class Initialized
INFO - 2016-09-15 09:48:25 --> Output Class Initialized
INFO - 2016-09-15 09:48:25 --> Security Class Initialized
DEBUG - 2016-09-15 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:48:25 --> Input Class Initialized
INFO - 2016-09-15 09:48:25 --> Language Class Initialized
INFO - 2016-09-15 09:48:25 --> Loader Class Initialized
INFO - 2016-09-15 09:48:25 --> Helper loaded: url_helper
INFO - 2016-09-15 09:48:25 --> Helper loaded: language_helper
INFO - 2016-09-15 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:48:25 --> Controller Class Initialized
INFO - 2016-09-15 09:48:25 --> Database Driver Class Initialized
INFO - 2016-09-15 09:48:25 --> Model Class Initialized
INFO - 2016-09-15 09:48:25 --> Model Class Initialized
INFO - 2016-09-15 09:48:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:48:25 --> Helper loaded: form_helper
INFO - 2016-09-15 09:48:25 --> Form Validation Class Initialized
INFO - 2016-09-15 09:48:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:48:25 --> Config Class Initialized
INFO - 2016-09-15 09:48:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:48:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:48:25 --> Utf8 Class Initialized
INFO - 2016-09-15 09:48:25 --> URI Class Initialized
INFO - 2016-09-15 09:48:25 --> Router Class Initialized
INFO - 2016-09-15 09:48:25 --> Output Class Initialized
INFO - 2016-09-15 09:48:25 --> Security Class Initialized
DEBUG - 2016-09-15 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:48:25 --> Input Class Initialized
INFO - 2016-09-15 09:48:25 --> Language Class Initialized
INFO - 2016-09-15 09:48:25 --> Loader Class Initialized
INFO - 2016-09-15 09:48:25 --> Helper loaded: url_helper
INFO - 2016-09-15 09:48:25 --> Helper loaded: language_helper
INFO - 2016-09-15 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:48:25 --> Controller Class Initialized
INFO - 2016-09-15 09:48:25 --> Database Driver Class Initialized
INFO - 2016-09-15 09:48:25 --> Model Class Initialized
INFO - 2016-09-15 09:48:25 --> Model Class Initialized
INFO - 2016-09-15 09:48:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:48:26 --> Model Class Initialized
INFO - 2016-09-15 09:48:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:48:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:48:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:48:26 --> Final output sent to browser
DEBUG - 2016-09-15 09:48:26 --> Total execution time: 0.0686
INFO - 2016-09-15 09:48:37 --> Config Class Initialized
INFO - 2016-09-15 09:48:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:48:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:48:37 --> Utf8 Class Initialized
INFO - 2016-09-15 09:48:37 --> URI Class Initialized
INFO - 2016-09-15 09:48:37 --> Router Class Initialized
INFO - 2016-09-15 09:48:37 --> Output Class Initialized
INFO - 2016-09-15 09:48:37 --> Security Class Initialized
DEBUG - 2016-09-15 09:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:48:37 --> Input Class Initialized
INFO - 2016-09-15 09:48:37 --> Language Class Initialized
INFO - 2016-09-15 09:48:37 --> Loader Class Initialized
INFO - 2016-09-15 09:48:37 --> Helper loaded: url_helper
INFO - 2016-09-15 09:48:37 --> Helper loaded: language_helper
INFO - 2016-09-15 09:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:48:37 --> Controller Class Initialized
INFO - 2016-09-15 09:48:37 --> Database Driver Class Initialized
INFO - 2016-09-15 09:48:37 --> Model Class Initialized
INFO - 2016-09-15 09:48:37 --> Model Class Initialized
INFO - 2016-09-15 09:48:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:48:37 --> Final output sent to browser
DEBUG - 2016-09-15 09:48:37 --> Total execution time: 0.0525
INFO - 2016-09-15 09:48:42 --> Config Class Initialized
INFO - 2016-09-15 09:48:42 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:48:42 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:48:42 --> Utf8 Class Initialized
INFO - 2016-09-15 09:48:42 --> URI Class Initialized
INFO - 2016-09-15 09:48:42 --> Router Class Initialized
INFO - 2016-09-15 09:48:42 --> Output Class Initialized
INFO - 2016-09-15 09:48:42 --> Security Class Initialized
DEBUG - 2016-09-15 09:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:48:42 --> Input Class Initialized
INFO - 2016-09-15 09:48:42 --> Language Class Initialized
INFO - 2016-09-15 09:48:42 --> Loader Class Initialized
INFO - 2016-09-15 09:48:42 --> Helper loaded: url_helper
INFO - 2016-09-15 09:48:42 --> Helper loaded: language_helper
INFO - 2016-09-15 09:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:48:42 --> Controller Class Initialized
INFO - 2016-09-15 09:48:42 --> Database Driver Class Initialized
INFO - 2016-09-15 09:48:42 --> Model Class Initialized
INFO - 2016-09-15 09:48:42 --> Model Class Initialized
INFO - 2016-09-15 09:48:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:48:42 --> Helper loaded: form_helper
INFO - 2016-09-15 09:48:42 --> Form Validation Class Initialized
INFO - 2016-09-15 09:48:42 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:48:42 --> Config Class Initialized
INFO - 2016-09-15 09:48:42 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:48:42 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:48:42 --> Utf8 Class Initialized
INFO - 2016-09-15 09:48:42 --> URI Class Initialized
INFO - 2016-09-15 09:48:42 --> Router Class Initialized
INFO - 2016-09-15 09:48:42 --> Output Class Initialized
INFO - 2016-09-15 09:48:42 --> Security Class Initialized
DEBUG - 2016-09-15 09:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:48:42 --> Input Class Initialized
INFO - 2016-09-15 09:48:42 --> Language Class Initialized
INFO - 2016-09-15 09:48:42 --> Loader Class Initialized
INFO - 2016-09-15 09:48:42 --> Helper loaded: url_helper
INFO - 2016-09-15 09:48:42 --> Helper loaded: language_helper
INFO - 2016-09-15 09:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:48:42 --> Controller Class Initialized
INFO - 2016-09-15 09:48:42 --> Database Driver Class Initialized
INFO - 2016-09-15 09:48:42 --> Model Class Initialized
INFO - 2016-09-15 09:48:42 --> Model Class Initialized
INFO - 2016-09-15 09:48:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:48:42 --> Model Class Initialized
INFO - 2016-09-15 09:48:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:48:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:48:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:48:42 --> Final output sent to browser
DEBUG - 2016-09-15 09:48:42 --> Total execution time: 0.0718
INFO - 2016-09-15 09:48:46 --> Config Class Initialized
INFO - 2016-09-15 09:48:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:48:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:48:46 --> Utf8 Class Initialized
INFO - 2016-09-15 09:48:46 --> URI Class Initialized
INFO - 2016-09-15 09:48:46 --> Router Class Initialized
INFO - 2016-09-15 09:48:46 --> Output Class Initialized
INFO - 2016-09-15 09:48:46 --> Security Class Initialized
DEBUG - 2016-09-15 09:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:48:46 --> Input Class Initialized
INFO - 2016-09-15 09:48:46 --> Language Class Initialized
INFO - 2016-09-15 09:48:46 --> Loader Class Initialized
INFO - 2016-09-15 09:48:46 --> Helper loaded: url_helper
INFO - 2016-09-15 09:48:46 --> Helper loaded: language_helper
INFO - 2016-09-15 09:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:48:46 --> Controller Class Initialized
INFO - 2016-09-15 09:48:46 --> Database Driver Class Initialized
INFO - 2016-09-15 09:48:46 --> Model Class Initialized
INFO - 2016-09-15 09:48:46 --> Model Class Initialized
INFO - 2016-09-15 09:48:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:48:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:48:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 09:48:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:48:46 --> Final output sent to browser
DEBUG - 2016-09-15 09:48:46 --> Total execution time: 0.0633
INFO - 2016-09-15 09:49:18 --> Config Class Initialized
INFO - 2016-09-15 09:49:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:49:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:49:18 --> Utf8 Class Initialized
INFO - 2016-09-15 09:49:18 --> URI Class Initialized
INFO - 2016-09-15 09:49:18 --> Router Class Initialized
INFO - 2016-09-15 09:49:18 --> Output Class Initialized
INFO - 2016-09-15 09:49:18 --> Security Class Initialized
DEBUG - 2016-09-15 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:49:18 --> Input Class Initialized
INFO - 2016-09-15 09:49:18 --> Language Class Initialized
INFO - 2016-09-15 09:49:18 --> Loader Class Initialized
INFO - 2016-09-15 09:49:18 --> Helper loaded: url_helper
INFO - 2016-09-15 09:49:18 --> Helper loaded: language_helper
INFO - 2016-09-15 09:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:49:18 --> Controller Class Initialized
INFO - 2016-09-15 09:49:18 --> Database Driver Class Initialized
INFO - 2016-09-15 09:49:18 --> Model Class Initialized
INFO - 2016-09-15 09:49:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:49:18 --> Final output sent to browser
DEBUG - 2016-09-15 09:49:18 --> Total execution time: 0.0703
INFO - 2016-09-15 09:54:49 --> Config Class Initialized
INFO - 2016-09-15 09:54:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:54:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:54:49 --> Utf8 Class Initialized
INFO - 2016-09-15 09:54:49 --> URI Class Initialized
INFO - 2016-09-15 09:54:49 --> Router Class Initialized
INFO - 2016-09-15 09:54:49 --> Output Class Initialized
INFO - 2016-09-15 09:54:49 --> Security Class Initialized
DEBUG - 2016-09-15 09:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:54:49 --> Input Class Initialized
INFO - 2016-09-15 09:54:49 --> Language Class Initialized
INFO - 2016-09-15 09:54:49 --> Loader Class Initialized
INFO - 2016-09-15 09:54:49 --> Helper loaded: url_helper
INFO - 2016-09-15 09:54:49 --> Helper loaded: language_helper
INFO - 2016-09-15 09:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:54:49 --> Controller Class Initialized
INFO - 2016-09-15 09:54:49 --> Database Driver Class Initialized
INFO - 2016-09-15 09:54:49 --> Model Class Initialized
INFO - 2016-09-15 09:54:49 --> Model Class Initialized
INFO - 2016-09-15 09:54:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:54:50 --> Helper loaded: form_helper
INFO - 2016-09-15 09:54:50 --> Form Validation Class Initialized
INFO - 2016-09-15 09:54:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:54:50 --> Config Class Initialized
INFO - 2016-09-15 09:54:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:54:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:54:50 --> Utf8 Class Initialized
INFO - 2016-09-15 09:54:50 --> URI Class Initialized
INFO - 2016-09-15 09:54:50 --> Router Class Initialized
INFO - 2016-09-15 09:54:50 --> Output Class Initialized
INFO - 2016-09-15 09:54:50 --> Security Class Initialized
DEBUG - 2016-09-15 09:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:54:50 --> Input Class Initialized
INFO - 2016-09-15 09:54:50 --> Language Class Initialized
INFO - 2016-09-15 09:54:50 --> Loader Class Initialized
INFO - 2016-09-15 09:54:50 --> Helper loaded: url_helper
INFO - 2016-09-15 09:54:50 --> Helper loaded: language_helper
INFO - 2016-09-15 09:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:54:50 --> Controller Class Initialized
INFO - 2016-09-15 09:54:50 --> Database Driver Class Initialized
INFO - 2016-09-15 09:54:50 --> Model Class Initialized
INFO - 2016-09-15 09:54:50 --> Model Class Initialized
INFO - 2016-09-15 09:54:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:54:50 --> Model Class Initialized
INFO - 2016-09-15 09:54:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:54:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:54:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:54:50 --> Final output sent to browser
DEBUG - 2016-09-15 09:54:50 --> Total execution time: 0.0746
INFO - 2016-09-15 09:54:56 --> Config Class Initialized
INFO - 2016-09-15 09:54:56 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:54:56 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:54:56 --> Utf8 Class Initialized
INFO - 2016-09-15 09:54:56 --> URI Class Initialized
INFO - 2016-09-15 09:54:56 --> Router Class Initialized
INFO - 2016-09-15 09:54:56 --> Output Class Initialized
INFO - 2016-09-15 09:54:56 --> Security Class Initialized
DEBUG - 2016-09-15 09:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:54:56 --> Input Class Initialized
INFO - 2016-09-15 09:54:56 --> Language Class Initialized
INFO - 2016-09-15 09:54:56 --> Loader Class Initialized
INFO - 2016-09-15 09:54:56 --> Helper loaded: url_helper
INFO - 2016-09-15 09:54:56 --> Helper loaded: language_helper
INFO - 2016-09-15 09:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:54:56 --> Controller Class Initialized
INFO - 2016-09-15 09:54:56 --> Database Driver Class Initialized
INFO - 2016-09-15 09:54:56 --> Model Class Initialized
INFO - 2016-09-15 09:54:56 --> Model Class Initialized
INFO - 2016-09-15 09:54:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:54:56 --> Final output sent to browser
DEBUG - 2016-09-15 09:54:56 --> Total execution time: 0.0525
INFO - 2016-09-15 09:54:59 --> Config Class Initialized
INFO - 2016-09-15 09:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:54:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:54:59 --> Utf8 Class Initialized
INFO - 2016-09-15 09:54:59 --> URI Class Initialized
INFO - 2016-09-15 09:54:59 --> Router Class Initialized
INFO - 2016-09-15 09:54:59 --> Output Class Initialized
INFO - 2016-09-15 09:54:59 --> Security Class Initialized
DEBUG - 2016-09-15 09:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:54:59 --> Input Class Initialized
INFO - 2016-09-15 09:54:59 --> Language Class Initialized
INFO - 2016-09-15 09:54:59 --> Loader Class Initialized
INFO - 2016-09-15 09:54:59 --> Helper loaded: url_helper
INFO - 2016-09-15 09:54:59 --> Helper loaded: language_helper
INFO - 2016-09-15 09:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:54:59 --> Controller Class Initialized
INFO - 2016-09-15 09:54:59 --> Database Driver Class Initialized
INFO - 2016-09-15 09:54:59 --> Model Class Initialized
INFO - 2016-09-15 09:54:59 --> Model Class Initialized
INFO - 2016-09-15 09:54:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:54:59 --> Helper loaded: form_helper
INFO - 2016-09-15 09:54:59 --> Form Validation Class Initialized
INFO - 2016-09-15 09:54:59 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:54:59 --> Config Class Initialized
INFO - 2016-09-15 09:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:54:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:54:59 --> Utf8 Class Initialized
INFO - 2016-09-15 09:54:59 --> URI Class Initialized
INFO - 2016-09-15 09:54:59 --> Router Class Initialized
INFO - 2016-09-15 09:54:59 --> Output Class Initialized
INFO - 2016-09-15 09:54:59 --> Security Class Initialized
DEBUG - 2016-09-15 09:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:54:59 --> Input Class Initialized
INFO - 2016-09-15 09:54:59 --> Language Class Initialized
INFO - 2016-09-15 09:54:59 --> Loader Class Initialized
INFO - 2016-09-15 09:54:59 --> Helper loaded: url_helper
INFO - 2016-09-15 09:54:59 --> Helper loaded: language_helper
INFO - 2016-09-15 09:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:54:59 --> Controller Class Initialized
INFO - 2016-09-15 09:54:59 --> Database Driver Class Initialized
INFO - 2016-09-15 09:54:59 --> Model Class Initialized
INFO - 2016-09-15 09:54:59 --> Model Class Initialized
INFO - 2016-09-15 09:54:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:54:59 --> Model Class Initialized
INFO - 2016-09-15 09:54:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:54:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:54:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:54:59 --> Final output sent to browser
DEBUG - 2016-09-15 09:54:59 --> Total execution time: 0.0673
INFO - 2016-09-15 09:55:03 --> Config Class Initialized
INFO - 2016-09-15 09:55:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:55:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:55:03 --> Utf8 Class Initialized
INFO - 2016-09-15 09:55:03 --> URI Class Initialized
INFO - 2016-09-15 09:55:03 --> Router Class Initialized
INFO - 2016-09-15 09:55:03 --> Output Class Initialized
INFO - 2016-09-15 09:55:03 --> Security Class Initialized
DEBUG - 2016-09-15 09:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:55:03 --> Input Class Initialized
INFO - 2016-09-15 09:55:03 --> Language Class Initialized
INFO - 2016-09-15 09:55:03 --> Loader Class Initialized
INFO - 2016-09-15 09:55:03 --> Helper loaded: url_helper
INFO - 2016-09-15 09:55:03 --> Helper loaded: language_helper
INFO - 2016-09-15 09:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:55:03 --> Controller Class Initialized
INFO - 2016-09-15 09:55:03 --> Database Driver Class Initialized
INFO - 2016-09-15 09:55:03 --> Model Class Initialized
INFO - 2016-09-15 09:55:03 --> Model Class Initialized
INFO - 2016-09-15 09:55:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:55:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:55:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 09:55:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:55:03 --> Final output sent to browser
DEBUG - 2016-09-15 09:55:03 --> Total execution time: 0.0607
INFO - 2016-09-15 09:55:12 --> Config Class Initialized
INFO - 2016-09-15 09:55:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:55:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:55:12 --> Utf8 Class Initialized
INFO - 2016-09-15 09:55:12 --> URI Class Initialized
INFO - 2016-09-15 09:55:12 --> Router Class Initialized
INFO - 2016-09-15 09:55:12 --> Output Class Initialized
INFO - 2016-09-15 09:55:12 --> Security Class Initialized
DEBUG - 2016-09-15 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:55:12 --> Input Class Initialized
INFO - 2016-09-15 09:55:12 --> Language Class Initialized
INFO - 2016-09-15 09:55:12 --> Loader Class Initialized
INFO - 2016-09-15 09:55:12 --> Helper loaded: url_helper
INFO - 2016-09-15 09:55:12 --> Helper loaded: language_helper
INFO - 2016-09-15 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:55:12 --> Controller Class Initialized
INFO - 2016-09-15 09:55:12 --> Database Driver Class Initialized
INFO - 2016-09-15 09:55:12 --> Model Class Initialized
INFO - 2016-09-15 09:55:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:55:12 --> Final output sent to browser
DEBUG - 2016-09-15 09:55:12 --> Total execution time: 0.0695
INFO - 2016-09-15 09:59:34 --> Config Class Initialized
INFO - 2016-09-15 09:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:59:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:59:34 --> Utf8 Class Initialized
INFO - 2016-09-15 09:59:34 --> URI Class Initialized
INFO - 2016-09-15 09:59:34 --> Router Class Initialized
INFO - 2016-09-15 09:59:34 --> Output Class Initialized
INFO - 2016-09-15 09:59:34 --> Security Class Initialized
DEBUG - 2016-09-15 09:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:59:34 --> Input Class Initialized
INFO - 2016-09-15 09:59:34 --> Language Class Initialized
INFO - 2016-09-15 09:59:34 --> Loader Class Initialized
INFO - 2016-09-15 09:59:34 --> Helper loaded: url_helper
INFO - 2016-09-15 09:59:34 --> Helper loaded: language_helper
INFO - 2016-09-15 09:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:59:34 --> Controller Class Initialized
INFO - 2016-09-15 09:59:34 --> Database Driver Class Initialized
INFO - 2016-09-15 09:59:34 --> Model Class Initialized
INFO - 2016-09-15 09:59:34 --> Model Class Initialized
INFO - 2016-09-15 09:59:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:59:34 --> Helper loaded: form_helper
INFO - 2016-09-15 09:59:34 --> Form Validation Class Initialized
INFO - 2016-09-15 09:59:34 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 09:59:34 --> Config Class Initialized
INFO - 2016-09-15 09:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:59:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:59:34 --> Utf8 Class Initialized
INFO - 2016-09-15 09:59:34 --> URI Class Initialized
INFO - 2016-09-15 09:59:34 --> Router Class Initialized
INFO - 2016-09-15 09:59:34 --> Output Class Initialized
INFO - 2016-09-15 09:59:34 --> Security Class Initialized
DEBUG - 2016-09-15 09:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:59:34 --> Input Class Initialized
INFO - 2016-09-15 09:59:34 --> Language Class Initialized
INFO - 2016-09-15 09:59:34 --> Loader Class Initialized
INFO - 2016-09-15 09:59:34 --> Helper loaded: url_helper
INFO - 2016-09-15 09:59:34 --> Helper loaded: language_helper
INFO - 2016-09-15 09:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:59:34 --> Controller Class Initialized
INFO - 2016-09-15 09:59:34 --> Database Driver Class Initialized
INFO - 2016-09-15 09:59:34 --> Model Class Initialized
INFO - 2016-09-15 09:59:34 --> Model Class Initialized
INFO - 2016-09-15 09:59:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:59:35 --> Model Class Initialized
INFO - 2016-09-15 09:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 09:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 09:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 09:59:35 --> Final output sent to browser
DEBUG - 2016-09-15 09:59:35 --> Total execution time: 0.0679
INFO - 2016-09-15 09:59:44 --> Config Class Initialized
INFO - 2016-09-15 09:59:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 09:59:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 09:59:44 --> Utf8 Class Initialized
INFO - 2016-09-15 09:59:44 --> URI Class Initialized
INFO - 2016-09-15 09:59:44 --> Router Class Initialized
INFO - 2016-09-15 09:59:44 --> Output Class Initialized
INFO - 2016-09-15 09:59:44 --> Security Class Initialized
DEBUG - 2016-09-15 09:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 09:59:44 --> Input Class Initialized
INFO - 2016-09-15 09:59:44 --> Language Class Initialized
INFO - 2016-09-15 09:59:44 --> Loader Class Initialized
INFO - 2016-09-15 09:59:44 --> Helper loaded: url_helper
INFO - 2016-09-15 09:59:44 --> Helper loaded: language_helper
INFO - 2016-09-15 09:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 09:59:44 --> Controller Class Initialized
INFO - 2016-09-15 09:59:44 --> Database Driver Class Initialized
INFO - 2016-09-15 09:59:44 --> Model Class Initialized
INFO - 2016-09-15 09:59:44 --> Model Class Initialized
INFO - 2016-09-15 09:59:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 09:59:44 --> Final output sent to browser
DEBUG - 2016-09-15 09:59:44 --> Total execution time: 0.0519
INFO - 2016-09-15 10:00:13 --> Config Class Initialized
INFO - 2016-09-15 10:00:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:00:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:00:13 --> Utf8 Class Initialized
INFO - 2016-09-15 10:00:13 --> URI Class Initialized
INFO - 2016-09-15 10:00:13 --> Router Class Initialized
INFO - 2016-09-15 10:00:13 --> Output Class Initialized
INFO - 2016-09-15 10:00:13 --> Security Class Initialized
DEBUG - 2016-09-15 10:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:00:13 --> Input Class Initialized
INFO - 2016-09-15 10:00:13 --> Language Class Initialized
INFO - 2016-09-15 10:00:13 --> Loader Class Initialized
INFO - 2016-09-15 10:00:13 --> Helper loaded: url_helper
INFO - 2016-09-15 10:00:13 --> Helper loaded: language_helper
INFO - 2016-09-15 10:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:00:13 --> Controller Class Initialized
INFO - 2016-09-15 10:00:13 --> Database Driver Class Initialized
INFO - 2016-09-15 10:00:13 --> Model Class Initialized
INFO - 2016-09-15 10:00:13 --> Model Class Initialized
INFO - 2016-09-15 10:00:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:00:13 --> Helper loaded: form_helper
INFO - 2016-09-15 10:00:13 --> Form Validation Class Initialized
INFO - 2016-09-15 10:00:13 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 10:00:13 --> Config Class Initialized
INFO - 2016-09-15 10:00:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:00:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:00:13 --> Utf8 Class Initialized
INFO - 2016-09-15 10:00:13 --> URI Class Initialized
INFO - 2016-09-15 10:00:13 --> Router Class Initialized
INFO - 2016-09-15 10:00:13 --> Output Class Initialized
INFO - 2016-09-15 10:00:13 --> Security Class Initialized
DEBUG - 2016-09-15 10:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:00:13 --> Input Class Initialized
INFO - 2016-09-15 10:00:13 --> Language Class Initialized
INFO - 2016-09-15 10:00:13 --> Loader Class Initialized
INFO - 2016-09-15 10:00:13 --> Helper loaded: url_helper
INFO - 2016-09-15 10:00:13 --> Helper loaded: language_helper
INFO - 2016-09-15 10:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:00:13 --> Controller Class Initialized
INFO - 2016-09-15 10:00:13 --> Database Driver Class Initialized
INFO - 2016-09-15 10:00:13 --> Model Class Initialized
INFO - 2016-09-15 10:00:13 --> Model Class Initialized
INFO - 2016-09-15 10:00:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:00:13 --> Model Class Initialized
INFO - 2016-09-15 10:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 10:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:00:13 --> Final output sent to browser
DEBUG - 2016-09-15 10:00:13 --> Total execution time: 0.0689
INFO - 2016-09-15 10:00:18 --> Config Class Initialized
INFO - 2016-09-15 10:00:18 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:00:18 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:00:18 --> Utf8 Class Initialized
INFO - 2016-09-15 10:00:18 --> URI Class Initialized
INFO - 2016-09-15 10:00:18 --> Router Class Initialized
INFO - 2016-09-15 10:00:18 --> Output Class Initialized
INFO - 2016-09-15 10:00:18 --> Security Class Initialized
DEBUG - 2016-09-15 10:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:00:18 --> Input Class Initialized
INFO - 2016-09-15 10:00:18 --> Language Class Initialized
INFO - 2016-09-15 10:00:18 --> Loader Class Initialized
INFO - 2016-09-15 10:00:18 --> Helper loaded: url_helper
INFO - 2016-09-15 10:00:18 --> Helper loaded: language_helper
INFO - 2016-09-15 10:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:00:18 --> Controller Class Initialized
INFO - 2016-09-15 10:00:18 --> Database Driver Class Initialized
INFO - 2016-09-15 10:00:18 --> Model Class Initialized
INFO - 2016-09-15 10:00:18 --> Model Class Initialized
INFO - 2016-09-15 10:00:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:00:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:00:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 10:00:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:00:18 --> Final output sent to browser
DEBUG - 2016-09-15 10:00:18 --> Total execution time: 0.0602
INFO - 2016-09-15 10:00:26 --> Config Class Initialized
INFO - 2016-09-15 10:00:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:00:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:00:27 --> Utf8 Class Initialized
INFO - 2016-09-15 10:00:27 --> URI Class Initialized
INFO - 2016-09-15 10:00:27 --> Router Class Initialized
INFO - 2016-09-15 10:00:27 --> Output Class Initialized
INFO - 2016-09-15 10:00:27 --> Security Class Initialized
DEBUG - 2016-09-15 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:00:27 --> Input Class Initialized
INFO - 2016-09-15 10:00:27 --> Language Class Initialized
INFO - 2016-09-15 10:00:27 --> Loader Class Initialized
INFO - 2016-09-15 10:00:27 --> Helper loaded: url_helper
INFO - 2016-09-15 10:00:27 --> Helper loaded: language_helper
INFO - 2016-09-15 10:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:00:27 --> Controller Class Initialized
INFO - 2016-09-15 10:00:27 --> Database Driver Class Initialized
INFO - 2016-09-15 10:00:27 --> Model Class Initialized
INFO - 2016-09-15 10:00:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:00:27 --> Final output sent to browser
DEBUG - 2016-09-15 10:00:27 --> Total execution time: 0.0712
INFO - 2016-09-15 10:04:57 --> Config Class Initialized
INFO - 2016-09-15 10:04:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:04:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:04:57 --> Utf8 Class Initialized
INFO - 2016-09-15 10:04:57 --> URI Class Initialized
INFO - 2016-09-15 10:04:57 --> Router Class Initialized
INFO - 2016-09-15 10:04:57 --> Output Class Initialized
INFO - 2016-09-15 10:04:57 --> Security Class Initialized
DEBUG - 2016-09-15 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:04:57 --> Input Class Initialized
INFO - 2016-09-15 10:04:57 --> Language Class Initialized
INFO - 2016-09-15 10:04:57 --> Loader Class Initialized
INFO - 2016-09-15 10:04:57 --> Helper loaded: url_helper
INFO - 2016-09-15 10:04:57 --> Helper loaded: language_helper
INFO - 2016-09-15 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:04:57 --> Controller Class Initialized
INFO - 2016-09-15 10:04:57 --> Database Driver Class Initialized
INFO - 2016-09-15 10:04:57 --> Model Class Initialized
INFO - 2016-09-15 10:04:57 --> Model Class Initialized
INFO - 2016-09-15 10:04:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:04:57 --> Helper loaded: form_helper
INFO - 2016-09-15 10:04:57 --> Form Validation Class Initialized
INFO - 2016-09-15 10:04:57 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 10:04:57 --> Config Class Initialized
INFO - 2016-09-15 10:04:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:04:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:04:57 --> Utf8 Class Initialized
INFO - 2016-09-15 10:04:57 --> URI Class Initialized
INFO - 2016-09-15 10:04:57 --> Router Class Initialized
INFO - 2016-09-15 10:04:57 --> Output Class Initialized
INFO - 2016-09-15 10:04:57 --> Security Class Initialized
DEBUG - 2016-09-15 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:04:57 --> Input Class Initialized
INFO - 2016-09-15 10:04:57 --> Language Class Initialized
INFO - 2016-09-15 10:04:57 --> Loader Class Initialized
INFO - 2016-09-15 10:04:57 --> Helper loaded: url_helper
INFO - 2016-09-15 10:04:57 --> Helper loaded: language_helper
INFO - 2016-09-15 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:04:57 --> Controller Class Initialized
INFO - 2016-09-15 10:04:57 --> Database Driver Class Initialized
INFO - 2016-09-15 10:04:57 --> Model Class Initialized
INFO - 2016-09-15 10:04:57 --> Model Class Initialized
INFO - 2016-09-15 10:04:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:04:57 --> Model Class Initialized
INFO - 2016-09-15 10:04:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:04:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 10:04:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:04:57 --> Final output sent to browser
DEBUG - 2016-09-15 10:04:57 --> Total execution time: 0.0689
INFO - 2016-09-15 10:05:06 --> Config Class Initialized
INFO - 2016-09-15 10:05:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:05:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:05:06 --> Utf8 Class Initialized
INFO - 2016-09-15 10:05:06 --> URI Class Initialized
INFO - 2016-09-15 10:05:06 --> Router Class Initialized
INFO - 2016-09-15 10:05:06 --> Output Class Initialized
INFO - 2016-09-15 10:05:06 --> Security Class Initialized
DEBUG - 2016-09-15 10:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:05:06 --> Input Class Initialized
INFO - 2016-09-15 10:05:06 --> Language Class Initialized
INFO - 2016-09-15 10:05:06 --> Loader Class Initialized
INFO - 2016-09-15 10:05:06 --> Helper loaded: url_helper
INFO - 2016-09-15 10:05:06 --> Helper loaded: language_helper
INFO - 2016-09-15 10:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:05:06 --> Controller Class Initialized
INFO - 2016-09-15 10:05:06 --> Database Driver Class Initialized
INFO - 2016-09-15 10:05:06 --> Model Class Initialized
INFO - 2016-09-15 10:05:06 --> Model Class Initialized
INFO - 2016-09-15 10:05:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:05:06 --> Final output sent to browser
DEBUG - 2016-09-15 10:05:06 --> Total execution time: 0.0530
INFO - 2016-09-15 10:05:09 --> Config Class Initialized
INFO - 2016-09-15 10:05:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:05:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:05:09 --> Utf8 Class Initialized
INFO - 2016-09-15 10:05:09 --> URI Class Initialized
INFO - 2016-09-15 10:05:09 --> Router Class Initialized
INFO - 2016-09-15 10:05:09 --> Output Class Initialized
INFO - 2016-09-15 10:05:09 --> Security Class Initialized
DEBUG - 2016-09-15 10:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:05:09 --> Input Class Initialized
INFO - 2016-09-15 10:05:09 --> Language Class Initialized
INFO - 2016-09-15 10:05:09 --> Loader Class Initialized
INFO - 2016-09-15 10:05:09 --> Helper loaded: url_helper
INFO - 2016-09-15 10:05:09 --> Helper loaded: language_helper
INFO - 2016-09-15 10:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:05:09 --> Controller Class Initialized
INFO - 2016-09-15 10:05:09 --> Database Driver Class Initialized
INFO - 2016-09-15 10:05:09 --> Model Class Initialized
INFO - 2016-09-15 10:05:09 --> Model Class Initialized
INFO - 2016-09-15 10:05:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:05:09 --> Helper loaded: form_helper
INFO - 2016-09-15 10:05:09 --> Form Validation Class Initialized
INFO - 2016-09-15 10:05:09 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 10:05:09 --> Config Class Initialized
INFO - 2016-09-15 10:05:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:05:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:05:09 --> Utf8 Class Initialized
INFO - 2016-09-15 10:05:09 --> URI Class Initialized
INFO - 2016-09-15 10:05:09 --> Router Class Initialized
INFO - 2016-09-15 10:05:09 --> Output Class Initialized
INFO - 2016-09-15 10:05:09 --> Security Class Initialized
DEBUG - 2016-09-15 10:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:05:09 --> Input Class Initialized
INFO - 2016-09-15 10:05:09 --> Language Class Initialized
INFO - 2016-09-15 10:05:09 --> Loader Class Initialized
INFO - 2016-09-15 10:05:09 --> Helper loaded: url_helper
INFO - 2016-09-15 10:05:09 --> Helper loaded: language_helper
INFO - 2016-09-15 10:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:05:09 --> Controller Class Initialized
INFO - 2016-09-15 10:05:09 --> Database Driver Class Initialized
INFO - 2016-09-15 10:05:09 --> Model Class Initialized
INFO - 2016-09-15 10:05:09 --> Model Class Initialized
INFO - 2016-09-15 10:05:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:05:09 --> Model Class Initialized
INFO - 2016-09-15 10:05:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:05:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 10:05:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:05:09 --> Final output sent to browser
DEBUG - 2016-09-15 10:05:09 --> Total execution time: 0.0703
INFO - 2016-09-15 10:05:13 --> Config Class Initialized
INFO - 2016-09-15 10:05:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:05:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:05:13 --> Utf8 Class Initialized
INFO - 2016-09-15 10:05:13 --> URI Class Initialized
INFO - 2016-09-15 10:05:13 --> Router Class Initialized
INFO - 2016-09-15 10:05:13 --> Output Class Initialized
INFO - 2016-09-15 10:05:13 --> Security Class Initialized
DEBUG - 2016-09-15 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:05:13 --> Input Class Initialized
INFO - 2016-09-15 10:05:13 --> Language Class Initialized
INFO - 2016-09-15 10:05:13 --> Loader Class Initialized
INFO - 2016-09-15 10:05:13 --> Helper loaded: url_helper
INFO - 2016-09-15 10:05:13 --> Helper loaded: language_helper
INFO - 2016-09-15 10:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:05:13 --> Controller Class Initialized
INFO - 2016-09-15 10:05:13 --> Database Driver Class Initialized
INFO - 2016-09-15 10:05:13 --> Model Class Initialized
INFO - 2016-09-15 10:05:13 --> Model Class Initialized
INFO - 2016-09-15 10:05:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 10:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:05:13 --> Final output sent to browser
DEBUG - 2016-09-15 10:05:13 --> Total execution time: 0.0611
INFO - 2016-09-15 10:05:34 --> Config Class Initialized
INFO - 2016-09-15 10:05:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:05:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:05:34 --> Utf8 Class Initialized
INFO - 2016-09-15 10:05:34 --> URI Class Initialized
INFO - 2016-09-15 10:05:34 --> Router Class Initialized
INFO - 2016-09-15 10:05:34 --> Output Class Initialized
INFO - 2016-09-15 10:05:34 --> Security Class Initialized
DEBUG - 2016-09-15 10:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:05:34 --> Input Class Initialized
INFO - 2016-09-15 10:05:34 --> Language Class Initialized
INFO - 2016-09-15 10:05:34 --> Loader Class Initialized
INFO - 2016-09-15 10:05:34 --> Helper loaded: url_helper
INFO - 2016-09-15 10:05:34 --> Helper loaded: language_helper
INFO - 2016-09-15 10:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:05:34 --> Controller Class Initialized
INFO - 2016-09-15 10:05:34 --> Database Driver Class Initialized
INFO - 2016-09-15 10:05:34 --> Model Class Initialized
INFO - 2016-09-15 10:05:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:05:34 --> Final output sent to browser
DEBUG - 2016-09-15 10:05:34 --> Total execution time: 0.0656
INFO - 2016-09-15 10:10:12 --> Config Class Initialized
INFO - 2016-09-15 10:10:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:10:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:10:12 --> Utf8 Class Initialized
INFO - 2016-09-15 10:10:12 --> URI Class Initialized
INFO - 2016-09-15 10:10:12 --> Router Class Initialized
INFO - 2016-09-15 10:10:12 --> Output Class Initialized
INFO - 2016-09-15 10:10:12 --> Security Class Initialized
DEBUG - 2016-09-15 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:10:12 --> Input Class Initialized
INFO - 2016-09-15 10:10:12 --> Language Class Initialized
INFO - 2016-09-15 10:10:12 --> Loader Class Initialized
INFO - 2016-09-15 10:10:12 --> Helper loaded: url_helper
INFO - 2016-09-15 10:10:12 --> Helper loaded: language_helper
INFO - 2016-09-15 10:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:10:12 --> Controller Class Initialized
INFO - 2016-09-15 10:10:12 --> Database Driver Class Initialized
INFO - 2016-09-15 10:10:12 --> Model Class Initialized
INFO - 2016-09-15 10:10:12 --> Model Class Initialized
INFO - 2016-09-15 10:10:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:10:12 --> Helper loaded: form_helper
INFO - 2016-09-15 10:10:12 --> Form Validation Class Initialized
INFO - 2016-09-15 10:10:12 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 10:10:12 --> Config Class Initialized
INFO - 2016-09-15 10:10:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:10:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:10:12 --> Utf8 Class Initialized
INFO - 2016-09-15 10:10:12 --> URI Class Initialized
INFO - 2016-09-15 10:10:12 --> Router Class Initialized
INFO - 2016-09-15 10:10:12 --> Output Class Initialized
INFO - 2016-09-15 10:10:12 --> Security Class Initialized
DEBUG - 2016-09-15 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:10:12 --> Input Class Initialized
INFO - 2016-09-15 10:10:12 --> Language Class Initialized
INFO - 2016-09-15 10:10:12 --> Loader Class Initialized
INFO - 2016-09-15 10:10:12 --> Helper loaded: url_helper
INFO - 2016-09-15 10:10:12 --> Helper loaded: language_helper
INFO - 2016-09-15 10:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:10:12 --> Controller Class Initialized
INFO - 2016-09-15 10:10:12 --> Database Driver Class Initialized
INFO - 2016-09-15 10:10:12 --> Model Class Initialized
INFO - 2016-09-15 10:10:12 --> Model Class Initialized
INFO - 2016-09-15 10:10:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:10:12 --> Model Class Initialized
INFO - 2016-09-15 10:10:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:10:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 10:10:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:10:12 --> Final output sent to browser
DEBUG - 2016-09-15 10:10:12 --> Total execution time: 0.0852
INFO - 2016-09-15 10:10:21 --> Config Class Initialized
INFO - 2016-09-15 10:10:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:10:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:10:21 --> Utf8 Class Initialized
INFO - 2016-09-15 10:10:21 --> URI Class Initialized
INFO - 2016-09-15 10:10:21 --> Router Class Initialized
INFO - 2016-09-15 10:10:21 --> Output Class Initialized
INFO - 2016-09-15 10:10:21 --> Security Class Initialized
DEBUG - 2016-09-15 10:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:10:21 --> Input Class Initialized
INFO - 2016-09-15 10:10:21 --> Language Class Initialized
INFO - 2016-09-15 10:10:21 --> Loader Class Initialized
INFO - 2016-09-15 10:10:21 --> Helper loaded: url_helper
INFO - 2016-09-15 10:10:21 --> Helper loaded: language_helper
INFO - 2016-09-15 10:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:10:21 --> Controller Class Initialized
INFO - 2016-09-15 10:10:21 --> Database Driver Class Initialized
INFO - 2016-09-15 10:10:21 --> Model Class Initialized
INFO - 2016-09-15 10:10:21 --> Model Class Initialized
INFO - 2016-09-15 10:10:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:10:21 --> Final output sent to browser
DEBUG - 2016-09-15 10:10:21 --> Total execution time: 0.0552
INFO - 2016-09-15 10:10:24 --> Config Class Initialized
INFO - 2016-09-15 10:10:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:10:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:10:24 --> Utf8 Class Initialized
INFO - 2016-09-15 10:10:24 --> URI Class Initialized
INFO - 2016-09-15 10:10:24 --> Router Class Initialized
INFO - 2016-09-15 10:10:24 --> Output Class Initialized
INFO - 2016-09-15 10:10:24 --> Security Class Initialized
DEBUG - 2016-09-15 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:10:24 --> Input Class Initialized
INFO - 2016-09-15 10:10:24 --> Language Class Initialized
INFO - 2016-09-15 10:10:24 --> Loader Class Initialized
INFO - 2016-09-15 10:10:24 --> Helper loaded: url_helper
INFO - 2016-09-15 10:10:24 --> Helper loaded: language_helper
INFO - 2016-09-15 10:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:10:24 --> Controller Class Initialized
INFO - 2016-09-15 10:10:24 --> Database Driver Class Initialized
INFO - 2016-09-15 10:10:24 --> Model Class Initialized
INFO - 2016-09-15 10:10:24 --> Model Class Initialized
INFO - 2016-09-15 10:10:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:10:24 --> Helper loaded: form_helper
INFO - 2016-09-15 10:10:24 --> Form Validation Class Initialized
INFO - 2016-09-15 10:10:24 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 10:10:24 --> Config Class Initialized
INFO - 2016-09-15 10:10:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:10:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:10:24 --> Utf8 Class Initialized
INFO - 2016-09-15 10:10:24 --> URI Class Initialized
INFO - 2016-09-15 10:10:24 --> Router Class Initialized
INFO - 2016-09-15 10:10:24 --> Output Class Initialized
INFO - 2016-09-15 10:10:24 --> Security Class Initialized
DEBUG - 2016-09-15 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:10:24 --> Input Class Initialized
INFO - 2016-09-15 10:10:24 --> Language Class Initialized
INFO - 2016-09-15 10:10:24 --> Loader Class Initialized
INFO - 2016-09-15 10:10:24 --> Helper loaded: url_helper
INFO - 2016-09-15 10:10:24 --> Helper loaded: language_helper
INFO - 2016-09-15 10:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:10:24 --> Controller Class Initialized
INFO - 2016-09-15 10:10:24 --> Database Driver Class Initialized
INFO - 2016-09-15 10:10:24 --> Model Class Initialized
INFO - 2016-09-15 10:10:24 --> Model Class Initialized
INFO - 2016-09-15 10:10:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:10:24 --> Model Class Initialized
INFO - 2016-09-15 10:10:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:10:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 10:10:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:10:24 --> Final output sent to browser
DEBUG - 2016-09-15 10:10:24 --> Total execution time: 0.0709
INFO - 2016-09-15 10:10:51 --> Config Class Initialized
INFO - 2016-09-15 10:10:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:10:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:10:51 --> Utf8 Class Initialized
INFO - 2016-09-15 10:10:51 --> URI Class Initialized
INFO - 2016-09-15 10:10:51 --> Router Class Initialized
INFO - 2016-09-15 10:10:51 --> Output Class Initialized
INFO - 2016-09-15 10:10:51 --> Security Class Initialized
DEBUG - 2016-09-15 10:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:10:51 --> Input Class Initialized
INFO - 2016-09-15 10:10:51 --> Language Class Initialized
INFO - 2016-09-15 10:10:51 --> Loader Class Initialized
INFO - 2016-09-15 10:10:51 --> Helper loaded: url_helper
INFO - 2016-09-15 10:10:51 --> Helper loaded: language_helper
INFO - 2016-09-15 10:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:10:51 --> Controller Class Initialized
INFO - 2016-09-15 10:10:51 --> Database Driver Class Initialized
INFO - 2016-09-15 10:10:51 --> Model Class Initialized
INFO - 2016-09-15 10:10:51 --> Model Class Initialized
INFO - 2016-09-15 10:10:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:10:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 10:10:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 10:10:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 10:10:51 --> Final output sent to browser
DEBUG - 2016-09-15 10:10:51 --> Total execution time: 0.0589
INFO - 2016-09-15 10:11:00 --> Config Class Initialized
INFO - 2016-09-15 10:11:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 10:11:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 10:11:00 --> Utf8 Class Initialized
INFO - 2016-09-15 10:11:00 --> URI Class Initialized
INFO - 2016-09-15 10:11:00 --> Router Class Initialized
INFO - 2016-09-15 10:11:00 --> Output Class Initialized
INFO - 2016-09-15 10:11:00 --> Security Class Initialized
DEBUG - 2016-09-15 10:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 10:11:00 --> Input Class Initialized
INFO - 2016-09-15 10:11:00 --> Language Class Initialized
INFO - 2016-09-15 10:11:00 --> Loader Class Initialized
INFO - 2016-09-15 10:11:00 --> Helper loaded: url_helper
INFO - 2016-09-15 10:11:00 --> Helper loaded: language_helper
INFO - 2016-09-15 10:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 10:11:00 --> Controller Class Initialized
INFO - 2016-09-15 10:11:00 --> Database Driver Class Initialized
INFO - 2016-09-15 10:11:00 --> Model Class Initialized
INFO - 2016-09-15 10:11:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 10:11:00 --> Final output sent to browser
DEBUG - 2016-09-15 10:11:00 --> Total execution time: 0.0668
INFO - 2016-09-15 12:08:06 --> Config Class Initialized
INFO - 2016-09-15 12:08:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:08:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:08:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:08:06 --> URI Class Initialized
INFO - 2016-09-15 12:08:06 --> Router Class Initialized
INFO - 2016-09-15 12:08:06 --> Output Class Initialized
INFO - 2016-09-15 12:08:06 --> Security Class Initialized
DEBUG - 2016-09-15 12:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:08:06 --> Input Class Initialized
INFO - 2016-09-15 12:08:06 --> Language Class Initialized
INFO - 2016-09-15 12:08:06 --> Loader Class Initialized
INFO - 2016-09-15 12:08:06 --> Helper loaded: url_helper
INFO - 2016-09-15 12:08:06 --> Helper loaded: language_helper
INFO - 2016-09-15 12:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:08:06 --> Controller Class Initialized
INFO - 2016-09-15 12:08:06 --> Database Driver Class Initialized
INFO - 2016-09-15 12:08:06 --> Model Class Initialized
INFO - 2016-09-15 12:08:06 --> Model Class Initialized
INFO - 2016-09-15 12:08:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:08:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:08:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 12:08:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:08:06 --> Final output sent to browser
DEBUG - 2016-09-15 12:08:06 --> Total execution time: 0.2486
INFO - 2016-09-15 12:08:08 --> Config Class Initialized
INFO - 2016-09-15 12:08:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:08:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:08:08 --> Utf8 Class Initialized
INFO - 2016-09-15 12:08:08 --> URI Class Initialized
INFO - 2016-09-15 12:08:08 --> Router Class Initialized
INFO - 2016-09-15 12:08:08 --> Output Class Initialized
INFO - 2016-09-15 12:08:08 --> Security Class Initialized
DEBUG - 2016-09-15 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:08:08 --> Input Class Initialized
INFO - 2016-09-15 12:08:08 --> Language Class Initialized
INFO - 2016-09-15 12:08:08 --> Loader Class Initialized
INFO - 2016-09-15 12:08:08 --> Helper loaded: url_helper
INFO - 2016-09-15 12:08:08 --> Helper loaded: language_helper
INFO - 2016-09-15 12:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:08:08 --> Controller Class Initialized
INFO - 2016-09-15 12:08:08 --> Database Driver Class Initialized
INFO - 2016-09-15 12:08:08 --> Model Class Initialized
INFO - 2016-09-15 12:08:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2016-09-15 12:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:08:08 --> Final output sent to browser
DEBUG - 2016-09-15 12:08:08 --> Total execution time: 0.0681
INFO - 2016-09-15 12:18:54 --> Config Class Initialized
INFO - 2016-09-15 12:18:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:18:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:18:54 --> Utf8 Class Initialized
INFO - 2016-09-15 12:18:54 --> URI Class Initialized
INFO - 2016-09-15 12:18:54 --> Router Class Initialized
INFO - 2016-09-15 12:18:54 --> Output Class Initialized
INFO - 2016-09-15 12:18:54 --> Security Class Initialized
DEBUG - 2016-09-15 12:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:18:54 --> Input Class Initialized
INFO - 2016-09-15 12:18:54 --> Language Class Initialized
INFO - 2016-09-15 12:18:54 --> Loader Class Initialized
INFO - 2016-09-15 12:18:54 --> Helper loaded: url_helper
INFO - 2016-09-15 12:18:54 --> Helper loaded: language_helper
INFO - 2016-09-15 12:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:18:54 --> Controller Class Initialized
INFO - 2016-09-15 12:18:54 --> Database Driver Class Initialized
INFO - 2016-09-15 12:18:54 --> Model Class Initialized
INFO - 2016-09-15 12:18:54 --> Model Class Initialized
INFO - 2016-09-15 12:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:18:54 --> Helper loaded: form_helper
INFO - 2016-09-15 12:18:54 --> Form Validation Class Initialized
INFO - 2016-09-15 12:18:54 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:18:54 --> Config Class Initialized
INFO - 2016-09-15 12:18:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:18:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:18:54 --> Utf8 Class Initialized
INFO - 2016-09-15 12:18:54 --> URI Class Initialized
INFO - 2016-09-15 12:18:54 --> Router Class Initialized
INFO - 2016-09-15 12:18:54 --> Output Class Initialized
INFO - 2016-09-15 12:18:54 --> Security Class Initialized
DEBUG - 2016-09-15 12:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:18:54 --> Input Class Initialized
INFO - 2016-09-15 12:18:54 --> Language Class Initialized
INFO - 2016-09-15 12:18:54 --> Loader Class Initialized
INFO - 2016-09-15 12:18:54 --> Helper loaded: url_helper
INFO - 2016-09-15 12:18:54 --> Helper loaded: language_helper
INFO - 2016-09-15 12:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:18:54 --> Controller Class Initialized
INFO - 2016-09-15 12:18:54 --> Database Driver Class Initialized
INFO - 2016-09-15 12:18:54 --> Model Class Initialized
INFO - 2016-09-15 12:18:54 --> Model Class Initialized
INFO - 2016-09-15 12:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:18:54 --> Model Class Initialized
INFO - 2016-09-15 12:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:18:54 --> Final output sent to browser
DEBUG - 2016-09-15 12:18:54 --> Total execution time: 0.0762
INFO - 2016-09-15 12:18:54 --> Config Class Initialized
INFO - 2016-09-15 12:18:54 --> Hooks Class Initialized
INFO - 2016-09-15 12:18:55 --> Config Class Initialized
INFO - 2016-09-15 12:18:55 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:18:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:18:55 --> Utf8 Class Initialized
DEBUG - 2016-09-15 12:18:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:18:55 --> URI Class Initialized
INFO - 2016-09-15 12:18:55 --> Utf8 Class Initialized
INFO - 2016-09-15 12:18:55 --> URI Class Initialized
INFO - 2016-09-15 12:18:55 --> Router Class Initialized
INFO - 2016-09-15 12:18:55 --> Router Class Initialized
INFO - 2016-09-15 12:18:55 --> Output Class Initialized
INFO - 2016-09-15 12:18:55 --> Output Class Initialized
INFO - 2016-09-15 12:18:55 --> Security Class Initialized
INFO - 2016-09-15 12:18:55 --> Security Class Initialized
DEBUG - 2016-09-15 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:18:55 --> Input Class Initialized
DEBUG - 2016-09-15 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:18:55 --> Language Class Initialized
INFO - 2016-09-15 12:18:55 --> Input Class Initialized
INFO - 2016-09-15 12:18:55 --> Language Class Initialized
ERROR - 2016-09-15 12:18:55 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
ERROR - 2016-09-15 12:18:55 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
INFO - 2016-09-15 12:19:02 --> Config Class Initialized
INFO - 2016-09-15 12:19:02 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:19:02 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:02 --> Utf8 Class Initialized
INFO - 2016-09-15 12:19:02 --> URI Class Initialized
INFO - 2016-09-15 12:19:02 --> Router Class Initialized
INFO - 2016-09-15 12:19:02 --> Output Class Initialized
INFO - 2016-09-15 12:19:02 --> Security Class Initialized
DEBUG - 2016-09-15 12:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:02 --> Input Class Initialized
INFO - 2016-09-15 12:19:02 --> Language Class Initialized
INFO - 2016-09-15 12:19:02 --> Loader Class Initialized
INFO - 2016-09-15 12:19:02 --> Helper loaded: url_helper
INFO - 2016-09-15 12:19:02 --> Helper loaded: language_helper
INFO - 2016-09-15 12:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:19:02 --> Controller Class Initialized
INFO - 2016-09-15 12:19:02 --> Database Driver Class Initialized
INFO - 2016-09-15 12:19:03 --> Model Class Initialized
INFO - 2016-09-15 12:19:03 --> Model Class Initialized
INFO - 2016-09-15 12:19:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:19:03 --> Final output sent to browser
DEBUG - 2016-09-15 12:19:03 --> Total execution time: 0.0551
INFO - 2016-09-15 12:19:07 --> Config Class Initialized
INFO - 2016-09-15 12:19:07 --> Hooks Class Initialized
INFO - 2016-09-15 12:19:07 --> Config Class Initialized
INFO - 2016-09-15 12:19:07 --> Hooks Class Initialized
INFO - 2016-09-15 12:19:07 --> Config Class Initialized
DEBUG - 2016-09-15 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:07 --> Hooks Class Initialized
INFO - 2016-09-15 12:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-15 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:19:07 --> URI Class Initialized
INFO - 2016-09-15 12:19:07 --> URI Class Initialized
DEBUG - 2016-09-15 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:07 --> Router Class Initialized
INFO - 2016-09-15 12:19:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:19:07 --> Router Class Initialized
INFO - 2016-09-15 12:19:07 --> URI Class Initialized
INFO - 2016-09-15 12:19:07 --> Router Class Initialized
INFO - 2016-09-15 12:19:07 --> Output Class Initialized
INFO - 2016-09-15 12:19:07 --> Output Class Initialized
INFO - 2016-09-15 12:19:07 --> Output Class Initialized
INFO - 2016-09-15 12:19:07 --> Security Class Initialized
INFO - 2016-09-15 12:19:07 --> Security Class Initialized
INFO - 2016-09-15 12:19:07 --> Security Class Initialized
DEBUG - 2016-09-15 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:07 --> Input Class Initialized
DEBUG - 2016-09-15 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:07 --> Input Class Initialized
INFO - 2016-09-15 12:19:07 --> Language Class Initialized
DEBUG - 2016-09-15 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:07 --> Language Class Initialized
INFO - 2016-09-15 12:19:07 --> Input Class Initialized
ERROR - 2016-09-15 12:19:07 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
INFO - 2016-09-15 12:19:07 --> Language Class Initialized
ERROR - 2016-09-15 12:19:07 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
INFO - 2016-09-15 12:19:07 --> Loader Class Initialized
INFO - 2016-09-15 12:19:07 --> Helper loaded: url_helper
INFO - 2016-09-15 12:19:07 --> Helper loaded: language_helper
INFO - 2016-09-15 12:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:19:07 --> Controller Class Initialized
INFO - 2016-09-15 12:19:07 --> Database Driver Class Initialized
INFO - 2016-09-15 12:19:07 --> Model Class Initialized
INFO - 2016-09-15 12:19:07 --> Model Class Initialized
INFO - 2016-09-15 12:19:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:19:07 --> Helper loaded: form_helper
INFO - 2016-09-15 12:19:07 --> Form Validation Class Initialized
INFO - 2016-09-15 12:19:07 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:19:07 --> Config Class Initialized
INFO - 2016-09-15 12:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:19:07 --> URI Class Initialized
INFO - 2016-09-15 12:19:07 --> Router Class Initialized
INFO - 2016-09-15 12:19:07 --> Output Class Initialized
INFO - 2016-09-15 12:19:07 --> Security Class Initialized
DEBUG - 2016-09-15 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:07 --> Input Class Initialized
INFO - 2016-09-15 12:19:07 --> Language Class Initialized
INFO - 2016-09-15 12:19:07 --> Loader Class Initialized
INFO - 2016-09-15 12:19:07 --> Helper loaded: url_helper
INFO - 2016-09-15 12:19:07 --> Helper loaded: language_helper
INFO - 2016-09-15 12:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:19:07 --> Controller Class Initialized
INFO - 2016-09-15 12:19:07 --> Database Driver Class Initialized
INFO - 2016-09-15 12:19:07 --> Model Class Initialized
INFO - 2016-09-15 12:19:07 --> Model Class Initialized
INFO - 2016-09-15 12:19:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:19:07 --> Model Class Initialized
INFO - 2016-09-15 12:19:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:19:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:19:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:19:07 --> Final output sent to browser
DEBUG - 2016-09-15 12:19:07 --> Total execution time: 0.0747
INFO - 2016-09-15 12:19:07 --> Config Class Initialized
INFO - 2016-09-15 12:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:07 --> Config Class Initialized
INFO - 2016-09-15 12:19:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:19:07 --> Hooks Class Initialized
INFO - 2016-09-15 12:19:07 --> URI Class Initialized
DEBUG - 2016-09-15 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:19:07 --> Router Class Initialized
INFO - 2016-09-15 12:19:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:19:07 --> URI Class Initialized
INFO - 2016-09-15 12:19:07 --> Output Class Initialized
INFO - 2016-09-15 12:19:07 --> Router Class Initialized
INFO - 2016-09-15 12:19:07 --> Security Class Initialized
DEBUG - 2016-09-15 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:07 --> Input Class Initialized
INFO - 2016-09-15 12:19:07 --> Output Class Initialized
INFO - 2016-09-15 12:19:07 --> Language Class Initialized
INFO - 2016-09-15 12:19:07 --> Security Class Initialized
ERROR - 2016-09-15 12:19:07 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
DEBUG - 2016-09-15 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:19:07 --> Input Class Initialized
INFO - 2016-09-15 12:19:07 --> Language Class Initialized
ERROR - 2016-09-15 12:19:07 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
INFO - 2016-09-15 12:28:57 --> Config Class Initialized
INFO - 2016-09-15 12:28:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:28:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:28:57 --> Utf8 Class Initialized
INFO - 2016-09-15 12:28:57 --> URI Class Initialized
INFO - 2016-09-15 12:28:57 --> Router Class Initialized
INFO - 2016-09-15 12:28:57 --> Output Class Initialized
INFO - 2016-09-15 12:28:57 --> Security Class Initialized
DEBUG - 2016-09-15 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:28:57 --> Input Class Initialized
INFO - 2016-09-15 12:28:57 --> Language Class Initialized
INFO - 2016-09-15 12:28:57 --> Loader Class Initialized
INFO - 2016-09-15 12:28:57 --> Helper loaded: url_helper
INFO - 2016-09-15 12:28:57 --> Helper loaded: language_helper
INFO - 2016-09-15 12:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:28:57 --> Controller Class Initialized
INFO - 2016-09-15 12:28:57 --> Database Driver Class Initialized
INFO - 2016-09-15 12:28:57 --> Model Class Initialized
INFO - 2016-09-15 12:28:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:28:57 --> Helper loaded: form_helper
INFO - 2016-09-15 12:28:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:28:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 12:28:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:28:57 --> Final output sent to browser
DEBUG - 2016-09-15 12:28:57 --> Total execution time: 0.0730
INFO - 2016-09-15 12:29:04 --> Config Class Initialized
INFO - 2016-09-15 12:29:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:04 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:04 --> URI Class Initialized
INFO - 2016-09-15 12:29:04 --> Router Class Initialized
INFO - 2016-09-15 12:29:04 --> Output Class Initialized
INFO - 2016-09-15 12:29:04 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:04 --> Input Class Initialized
INFO - 2016-09-15 12:29:04 --> Language Class Initialized
INFO - 2016-09-15 12:29:04 --> Loader Class Initialized
INFO - 2016-09-15 12:29:04 --> Helper loaded: url_helper
INFO - 2016-09-15 12:29:04 --> Helper loaded: language_helper
INFO - 2016-09-15 12:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:29:04 --> Controller Class Initialized
INFO - 2016-09-15 12:29:04 --> Database Driver Class Initialized
INFO - 2016-09-15 12:29:04 --> Model Class Initialized
INFO - 2016-09-15 12:29:04 --> Model Class Initialized
INFO - 2016-09-15 12:29:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:29:04 --> Final output sent to browser
DEBUG - 2016-09-15 12:29:04 --> Total execution time: 0.0765
INFO - 2016-09-15 12:29:06 --> Config Class Initialized
INFO - 2016-09-15 12:29:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:06 --> URI Class Initialized
INFO - 2016-09-15 12:29:06 --> Router Class Initialized
INFO - 2016-09-15 12:29:06 --> Output Class Initialized
INFO - 2016-09-15 12:29:06 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:06 --> Input Class Initialized
INFO - 2016-09-15 12:29:06 --> Language Class Initialized
INFO - 2016-09-15 12:29:06 --> Loader Class Initialized
INFO - 2016-09-15 12:29:06 --> Helper loaded: url_helper
INFO - 2016-09-15 12:29:06 --> Helper loaded: language_helper
INFO - 2016-09-15 12:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:29:06 --> Controller Class Initialized
INFO - 2016-09-15 12:29:06 --> Database Driver Class Initialized
INFO - 2016-09-15 12:29:06 --> Model Class Initialized
INFO - 2016-09-15 12:29:06 --> Model Class Initialized
INFO - 2016-09-15 12:29:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:29:06 --> Model Class Initialized
INFO - 2016-09-15 12:29:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:29:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:29:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:29:06 --> Final output sent to browser
DEBUG - 2016-09-15 12:29:06 --> Total execution time: 0.0721
INFO - 2016-09-15 12:29:06 --> Config Class Initialized
INFO - 2016-09-15 12:29:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:06 --> URI Class Initialized
INFO - 2016-09-15 12:29:06 --> Router Class Initialized
INFO - 2016-09-15 12:29:06 --> Config Class Initialized
INFO - 2016-09-15 12:29:06 --> Hooks Class Initialized
INFO - 2016-09-15 12:29:06 --> Output Class Initialized
INFO - 2016-09-15 12:29:06 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:06 --> Input Class Initialized
INFO - 2016-09-15 12:29:06 --> URI Class Initialized
INFO - 2016-09-15 12:29:06 --> Language Class Initialized
ERROR - 2016-09-15 12:29:06 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
INFO - 2016-09-15 12:29:06 --> Router Class Initialized
INFO - 2016-09-15 12:29:06 --> Output Class Initialized
INFO - 2016-09-15 12:29:06 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:06 --> Input Class Initialized
INFO - 2016-09-15 12:29:06 --> Language Class Initialized
ERROR - 2016-09-15 12:29:06 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
INFO - 2016-09-15 12:29:09 --> Config Class Initialized
INFO - 2016-09-15 12:29:09 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:09 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:09 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:09 --> URI Class Initialized
INFO - 2016-09-15 12:29:09 --> Router Class Initialized
INFO - 2016-09-15 12:29:09 --> Output Class Initialized
INFO - 2016-09-15 12:29:09 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:09 --> Input Class Initialized
INFO - 2016-09-15 12:29:09 --> Language Class Initialized
INFO - 2016-09-15 12:29:09 --> Loader Class Initialized
INFO - 2016-09-15 12:29:09 --> Helper loaded: url_helper
INFO - 2016-09-15 12:29:09 --> Helper loaded: language_helper
INFO - 2016-09-15 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:29:09 --> Controller Class Initialized
INFO - 2016-09-15 12:29:09 --> Database Driver Class Initialized
INFO - 2016-09-15 12:29:09 --> Model Class Initialized
INFO - 2016-09-15 12:29:09 --> Model Class Initialized
INFO - 2016-09-15 12:29:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:29:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:29:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:29:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:29:09 --> Final output sent to browser
DEBUG - 2016-09-15 12:29:09 --> Total execution time: 0.0614
INFO - 2016-09-15 12:29:11 --> Config Class Initialized
INFO - 2016-09-15 12:29:11 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:11 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:11 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:11 --> URI Class Initialized
INFO - 2016-09-15 12:29:11 --> Router Class Initialized
INFO - 2016-09-15 12:29:11 --> Output Class Initialized
INFO - 2016-09-15 12:29:11 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:11 --> Input Class Initialized
INFO - 2016-09-15 12:29:11 --> Language Class Initialized
INFO - 2016-09-15 12:29:11 --> Loader Class Initialized
INFO - 2016-09-15 12:29:11 --> Helper loaded: url_helper
INFO - 2016-09-15 12:29:11 --> Helper loaded: language_helper
INFO - 2016-09-15 12:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:29:11 --> Controller Class Initialized
INFO - 2016-09-15 12:29:11 --> Database Driver Class Initialized
INFO - 2016-09-15 12:29:11 --> Model Class Initialized
INFO - 2016-09-15 12:29:11 --> Model Class Initialized
INFO - 2016-09-15 12:29:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:29:11 --> Model Class Initialized
INFO - 2016-09-15 12:29:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:29:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:29:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:29:11 --> Final output sent to browser
DEBUG - 2016-09-15 12:29:11 --> Total execution time: 0.0729
INFO - 2016-09-15 12:29:22 --> Config Class Initialized
INFO - 2016-09-15 12:29:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:22 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:22 --> URI Class Initialized
INFO - 2016-09-15 12:29:22 --> Router Class Initialized
INFO - 2016-09-15 12:29:22 --> Output Class Initialized
INFO - 2016-09-15 12:29:22 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:22 --> Input Class Initialized
INFO - 2016-09-15 12:29:22 --> Language Class Initialized
INFO - 2016-09-15 12:29:22 --> Loader Class Initialized
INFO - 2016-09-15 12:29:22 --> Helper loaded: url_helper
INFO - 2016-09-15 12:29:22 --> Helper loaded: language_helper
INFO - 2016-09-15 12:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:29:22 --> Controller Class Initialized
INFO - 2016-09-15 12:29:22 --> Database Driver Class Initialized
INFO - 2016-09-15 12:29:22 --> Model Class Initialized
INFO - 2016-09-15 12:29:22 --> Model Class Initialized
INFO - 2016-09-15 12:29:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:29:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:29:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:29:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:29:22 --> Final output sent to browser
DEBUG - 2016-09-15 12:29:22 --> Total execution time: 0.0597
INFO - 2016-09-15 12:29:24 --> Config Class Initialized
INFO - 2016-09-15 12:29:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:24 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:24 --> URI Class Initialized
INFO - 2016-09-15 12:29:24 --> Router Class Initialized
INFO - 2016-09-15 12:29:24 --> Output Class Initialized
INFO - 2016-09-15 12:29:24 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:24 --> Input Class Initialized
INFO - 2016-09-15 12:29:24 --> Language Class Initialized
INFO - 2016-09-15 12:29:24 --> Loader Class Initialized
INFO - 2016-09-15 12:29:24 --> Helper loaded: url_helper
INFO - 2016-09-15 12:29:24 --> Helper loaded: language_helper
INFO - 2016-09-15 12:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:29:24 --> Controller Class Initialized
INFO - 2016-09-15 12:29:24 --> Database Driver Class Initialized
INFO - 2016-09-15 12:29:24 --> Model Class Initialized
INFO - 2016-09-15 12:29:24 --> Model Class Initialized
INFO - 2016-09-15 12:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:29:24 --> Model Class Initialized
INFO - 2016-09-15 12:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:29:24 --> Final output sent to browser
DEBUG - 2016-09-15 12:29:24 --> Total execution time: 0.0716
INFO - 2016-09-15 12:29:24 --> Config Class Initialized
INFO - 2016-09-15 12:29:24 --> Hooks Class Initialized
INFO - 2016-09-15 12:29:24 --> Config Class Initialized
INFO - 2016-09-15 12:29:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 12:29:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:24 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:24 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:24 --> URI Class Initialized
INFO - 2016-09-15 12:29:24 --> URI Class Initialized
INFO - 2016-09-15 12:29:24 --> Router Class Initialized
INFO - 2016-09-15 12:29:24 --> Router Class Initialized
INFO - 2016-09-15 12:29:24 --> Output Class Initialized
INFO - 2016-09-15 12:29:24 --> Output Class Initialized
INFO - 2016-09-15 12:29:24 --> Security Class Initialized
INFO - 2016-09-15 12:29:24 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-15 12:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:24 --> Input Class Initialized
INFO - 2016-09-15 12:29:24 --> Input Class Initialized
INFO - 2016-09-15 12:29:24 --> Language Class Initialized
INFO - 2016-09-15 12:29:24 --> Language Class Initialized
ERROR - 2016-09-15 12:29:24 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
ERROR - 2016-09-15 12:29:24 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
INFO - 2016-09-15 12:29:43 --> Config Class Initialized
INFO - 2016-09-15 12:29:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:29:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:29:43 --> Utf8 Class Initialized
INFO - 2016-09-15 12:29:43 --> URI Class Initialized
INFO - 2016-09-15 12:29:43 --> Router Class Initialized
INFO - 2016-09-15 12:29:43 --> Output Class Initialized
INFO - 2016-09-15 12:29:43 --> Security Class Initialized
DEBUG - 2016-09-15 12:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:29:43 --> Input Class Initialized
INFO - 2016-09-15 12:29:43 --> Language Class Initialized
ERROR - 2016-09-15 12:29:43 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
INFO - 2016-09-15 12:30:43 --> Config Class Initialized
INFO - 2016-09-15 12:30:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:30:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:30:43 --> Utf8 Class Initialized
INFO - 2016-09-15 12:30:43 --> URI Class Initialized
INFO - 2016-09-15 12:30:43 --> Router Class Initialized
INFO - 2016-09-15 12:30:43 --> Output Class Initialized
INFO - 2016-09-15 12:30:43 --> Security Class Initialized
DEBUG - 2016-09-15 12:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:30:43 --> Input Class Initialized
INFO - 2016-09-15 12:30:43 --> Language Class Initialized
INFO - 2016-09-15 12:30:43 --> Loader Class Initialized
INFO - 2016-09-15 12:30:43 --> Helper loaded: url_helper
INFO - 2016-09-15 12:30:43 --> Helper loaded: language_helper
INFO - 2016-09-15 12:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:30:43 --> Controller Class Initialized
INFO - 2016-09-15 12:30:43 --> Database Driver Class Initialized
INFO - 2016-09-15 12:30:43 --> Model Class Initialized
INFO - 2016-09-15 12:30:43 --> Model Class Initialized
INFO - 2016-09-15 12:30:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:30:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:30:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 12:30:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:30:43 --> Final output sent to browser
DEBUG - 2016-09-15 12:30:43 --> Total execution time: 0.0709
INFO - 2016-09-15 12:36:20 --> Config Class Initialized
INFO - 2016-09-15 12:36:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:36:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:36:20 --> Utf8 Class Initialized
INFO - 2016-09-15 12:36:20 --> URI Class Initialized
INFO - 2016-09-15 12:36:20 --> Router Class Initialized
INFO - 2016-09-15 12:36:20 --> Output Class Initialized
INFO - 2016-09-15 12:36:20 --> Security Class Initialized
DEBUG - 2016-09-15 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:36:20 --> Input Class Initialized
INFO - 2016-09-15 12:36:20 --> Language Class Initialized
INFO - 2016-09-15 12:36:20 --> Loader Class Initialized
INFO - 2016-09-15 12:36:20 --> Helper loaded: url_helper
INFO - 2016-09-15 12:36:20 --> Helper loaded: language_helper
INFO - 2016-09-15 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:36:20 --> Controller Class Initialized
INFO - 2016-09-15 12:36:20 --> Database Driver Class Initialized
INFO - 2016-09-15 12:36:20 --> Model Class Initialized
INFO - 2016-09-15 12:36:20 --> Model Class Initialized
INFO - 2016-09-15 12:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:36:20 --> Helper loaded: form_helper
INFO - 2016-09-15 12:36:20 --> Form Validation Class Initialized
INFO - 2016-09-15 12:36:20 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:36:20 --> Config Class Initialized
INFO - 2016-09-15 12:36:20 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:36:20 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:36:20 --> Utf8 Class Initialized
INFO - 2016-09-15 12:36:20 --> URI Class Initialized
INFO - 2016-09-15 12:36:20 --> Router Class Initialized
INFO - 2016-09-15 12:36:20 --> Output Class Initialized
INFO - 2016-09-15 12:36:20 --> Security Class Initialized
DEBUG - 2016-09-15 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:36:20 --> Input Class Initialized
INFO - 2016-09-15 12:36:20 --> Language Class Initialized
INFO - 2016-09-15 12:36:20 --> Loader Class Initialized
INFO - 2016-09-15 12:36:20 --> Helper loaded: url_helper
INFO - 2016-09-15 12:36:20 --> Helper loaded: language_helper
INFO - 2016-09-15 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:36:20 --> Controller Class Initialized
INFO - 2016-09-15 12:36:20 --> Database Driver Class Initialized
INFO - 2016-09-15 12:36:20 --> Model Class Initialized
INFO - 2016-09-15 12:36:20 --> Model Class Initialized
INFO - 2016-09-15 12:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:36:20 --> Model Class Initialized
INFO - 2016-09-15 12:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:36:20 --> Final output sent to browser
DEBUG - 2016-09-15 12:36:20 --> Total execution time: 0.0735
INFO - 2016-09-15 12:36:21 --> Config Class Initialized
INFO - 2016-09-15 12:36:21 --> Hooks Class Initialized
INFO - 2016-09-15 12:36:21 --> Config Class Initialized
INFO - 2016-09-15 12:36:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:36:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:36:21 --> Utf8 Class Initialized
DEBUG - 2016-09-15 12:36:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:36:21 --> Utf8 Class Initialized
INFO - 2016-09-15 12:36:21 --> URI Class Initialized
INFO - 2016-09-15 12:36:21 --> URI Class Initialized
INFO - 2016-09-15 12:36:21 --> Router Class Initialized
INFO - 2016-09-15 12:36:21 --> Output Class Initialized
INFO - 2016-09-15 12:36:21 --> Router Class Initialized
INFO - 2016-09-15 12:36:21 --> Security Class Initialized
INFO - 2016-09-15 12:36:21 --> Output Class Initialized
DEBUG - 2016-09-15 12:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:36:21 --> Input Class Initialized
INFO - 2016-09-15 12:36:21 --> Language Class Initialized
INFO - 2016-09-15 12:36:21 --> Security Class Initialized
ERROR - 2016-09-15 12:36:21 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
DEBUG - 2016-09-15 12:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:36:21 --> Input Class Initialized
INFO - 2016-09-15 12:36:21 --> Language Class Initialized
ERROR - 2016-09-15 12:36:21 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 12:36:38 --> Config Class Initialized
INFO - 2016-09-15 12:36:38 --> Config Class Initialized
INFO - 2016-09-15 12:36:38 --> Hooks Class Initialized
INFO - 2016-09-15 12:36:38 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:36:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 12:36:38 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:36:38 --> Utf8 Class Initialized
INFO - 2016-09-15 12:36:38 --> Utf8 Class Initialized
INFO - 2016-09-15 12:36:38 --> URI Class Initialized
INFO - 2016-09-15 12:36:38 --> URI Class Initialized
INFO - 2016-09-15 12:36:38 --> Router Class Initialized
INFO - 2016-09-15 12:36:38 --> Router Class Initialized
INFO - 2016-09-15 12:36:38 --> Output Class Initialized
INFO - 2016-09-15 12:36:38 --> Output Class Initialized
INFO - 2016-09-15 12:36:38 --> Security Class Initialized
INFO - 2016-09-15 12:36:38 --> Security Class Initialized
DEBUG - 2016-09-15 12:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-15 12:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:36:38 --> Input Class Initialized
INFO - 2016-09-15 12:36:38 --> Input Class Initialized
INFO - 2016-09-15 12:36:38 --> Language Class Initialized
INFO - 2016-09-15 12:36:38 --> Language Class Initialized
ERROR - 2016-09-15 12:36:38 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
ERROR - 2016-09-15 12:36:38 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 12:44:51 --> Config Class Initialized
INFO - 2016-09-15 12:44:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:44:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:51 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:51 --> URI Class Initialized
INFO - 2016-09-15 12:44:51 --> Router Class Initialized
INFO - 2016-09-15 12:44:51 --> Output Class Initialized
INFO - 2016-09-15 12:44:51 --> Security Class Initialized
DEBUG - 2016-09-15 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:51 --> Input Class Initialized
INFO - 2016-09-15 12:44:51 --> Language Class Initialized
INFO - 2016-09-15 12:44:51 --> Loader Class Initialized
INFO - 2016-09-15 12:44:51 --> Helper loaded: url_helper
INFO - 2016-09-15 12:44:51 --> Helper loaded: language_helper
INFO - 2016-09-15 12:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:44:51 --> Controller Class Initialized
INFO - 2016-09-15 12:44:51 --> Database Driver Class Initialized
INFO - 2016-09-15 12:44:51 --> Model Class Initialized
INFO - 2016-09-15 12:44:51 --> Model Class Initialized
INFO - 2016-09-15 12:44:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:44:51 --> Final output sent to browser
DEBUG - 2016-09-15 12:44:51 --> Total execution time: 0.0601
INFO - 2016-09-15 12:44:53 --> Config Class Initialized
INFO - 2016-09-15 12:44:53 --> Hooks Class Initialized
INFO - 2016-09-15 12:44:53 --> Config Class Initialized
INFO - 2016-09-15 12:44:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:44:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:53 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:53 --> URI Class Initialized
DEBUG - 2016-09-15 12:44:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:53 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:53 --> Router Class Initialized
INFO - 2016-09-15 12:44:53 --> URI Class Initialized
INFO - 2016-09-15 12:44:53 --> Output Class Initialized
INFO - 2016-09-15 12:44:53 --> Router Class Initialized
INFO - 2016-09-15 12:44:53 --> Security Class Initialized
INFO - 2016-09-15 12:44:53 --> Output Class Initialized
DEBUG - 2016-09-15 12:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:53 --> Input Class Initialized
INFO - 2016-09-15 12:44:53 --> Language Class Initialized
INFO - 2016-09-15 12:44:53 --> Security Class Initialized
INFO - 2016-09-15 12:44:53 --> Config Class Initialized
INFO - 2016-09-15 12:44:53 --> Hooks Class Initialized
ERROR - 2016-09-15 12:44:53 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
DEBUG - 2016-09-15 12:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:53 --> Input Class Initialized
INFO - 2016-09-15 12:44:53 --> Language Class Initialized
DEBUG - 2016-09-15 12:44:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:53 --> Utf8 Class Initialized
ERROR - 2016-09-15 12:44:53 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 12:44:53 --> URI Class Initialized
INFO - 2016-09-15 12:44:53 --> Router Class Initialized
INFO - 2016-09-15 12:44:53 --> Output Class Initialized
INFO - 2016-09-15 12:44:53 --> Security Class Initialized
DEBUG - 2016-09-15 12:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:53 --> Input Class Initialized
INFO - 2016-09-15 12:44:53 --> Language Class Initialized
INFO - 2016-09-15 12:44:53 --> Loader Class Initialized
INFO - 2016-09-15 12:44:53 --> Helper loaded: url_helper
INFO - 2016-09-15 12:44:53 --> Helper loaded: language_helper
INFO - 2016-09-15 12:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:44:53 --> Controller Class Initialized
INFO - 2016-09-15 12:44:53 --> Database Driver Class Initialized
INFO - 2016-09-15 12:44:53 --> Model Class Initialized
INFO - 2016-09-15 12:44:53 --> Model Class Initialized
INFO - 2016-09-15 12:44:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:44:53 --> Helper loaded: form_helper
INFO - 2016-09-15 12:44:53 --> Form Validation Class Initialized
INFO - 2016-09-15 12:44:53 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:44:53 --> Config Class Initialized
INFO - 2016-09-15 12:44:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:44:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:53 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:53 --> URI Class Initialized
INFO - 2016-09-15 12:44:53 --> Router Class Initialized
INFO - 2016-09-15 12:44:53 --> Output Class Initialized
INFO - 2016-09-15 12:44:53 --> Security Class Initialized
DEBUG - 2016-09-15 12:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:53 --> Input Class Initialized
INFO - 2016-09-15 12:44:53 --> Language Class Initialized
INFO - 2016-09-15 12:44:53 --> Loader Class Initialized
INFO - 2016-09-15 12:44:53 --> Helper loaded: url_helper
INFO - 2016-09-15 12:44:53 --> Helper loaded: language_helper
INFO - 2016-09-15 12:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:44:53 --> Controller Class Initialized
INFO - 2016-09-15 12:44:53 --> Database Driver Class Initialized
INFO - 2016-09-15 12:44:53 --> Model Class Initialized
INFO - 2016-09-15 12:44:53 --> Model Class Initialized
INFO - 2016-09-15 12:44:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:44:53 --> Model Class Initialized
INFO - 2016-09-15 12:44:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:44:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:44:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:44:53 --> Final output sent to browser
DEBUG - 2016-09-15 12:44:53 --> Total execution time: 0.0654
INFO - 2016-09-15 12:44:54 --> Config Class Initialized
INFO - 2016-09-15 12:44:54 --> Hooks Class Initialized
INFO - 2016-09-15 12:44:54 --> Config Class Initialized
INFO - 2016-09-15 12:44:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:44:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:54 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:54 --> URI Class Initialized
DEBUG - 2016-09-15 12:44:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:54 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:54 --> Router Class Initialized
INFO - 2016-09-15 12:44:54 --> URI Class Initialized
INFO - 2016-09-15 12:44:54 --> Output Class Initialized
INFO - 2016-09-15 12:44:54 --> Router Class Initialized
INFO - 2016-09-15 12:44:54 --> Security Class Initialized
DEBUG - 2016-09-15 12:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:54 --> Input Class Initialized
INFO - 2016-09-15 12:44:54 --> Output Class Initialized
INFO - 2016-09-15 12:44:54 --> Language Class Initialized
ERROR - 2016-09-15 12:44:54 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 12:44:54 --> Security Class Initialized
DEBUG - 2016-09-15 12:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:54 --> Input Class Initialized
INFO - 2016-09-15 12:44:54 --> Language Class Initialized
ERROR - 2016-09-15 12:44:54 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
INFO - 2016-09-15 12:44:58 --> Config Class Initialized
INFO - 2016-09-15 12:44:58 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:44:58 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:44:58 --> Utf8 Class Initialized
INFO - 2016-09-15 12:44:58 --> URI Class Initialized
INFO - 2016-09-15 12:44:58 --> Router Class Initialized
INFO - 2016-09-15 12:44:58 --> Output Class Initialized
INFO - 2016-09-15 12:44:58 --> Security Class Initialized
DEBUG - 2016-09-15 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:44:58 --> Input Class Initialized
INFO - 2016-09-15 12:44:58 --> Language Class Initialized
INFO - 2016-09-15 12:44:58 --> Loader Class Initialized
INFO - 2016-09-15 12:44:58 --> Helper loaded: url_helper
INFO - 2016-09-15 12:44:58 --> Helper loaded: language_helper
INFO - 2016-09-15 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:44:58 --> Controller Class Initialized
INFO - 2016-09-15 12:44:58 --> Database Driver Class Initialized
INFO - 2016-09-15 12:44:58 --> Model Class Initialized
INFO - 2016-09-15 12:44:58 --> Model Class Initialized
INFO - 2016-09-15 12:44:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:44:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:44:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-09-15 12:44:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:44:58 --> Final output sent to browser
DEBUG - 2016-09-15 12:44:58 --> Total execution time: 0.0620
INFO - 2016-09-15 12:45:07 --> Config Class Initialized
INFO - 2016-09-15 12:45:07 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:45:07 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:45:07 --> Utf8 Class Initialized
INFO - 2016-09-15 12:45:07 --> URI Class Initialized
INFO - 2016-09-15 12:45:07 --> Router Class Initialized
INFO - 2016-09-15 12:45:07 --> Output Class Initialized
INFO - 2016-09-15 12:45:07 --> Security Class Initialized
DEBUG - 2016-09-15 12:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:45:07 --> Input Class Initialized
INFO - 2016-09-15 12:45:07 --> Language Class Initialized
INFO - 2016-09-15 12:45:07 --> Loader Class Initialized
INFO - 2016-09-15 12:45:07 --> Helper loaded: url_helper
INFO - 2016-09-15 12:45:07 --> Helper loaded: language_helper
INFO - 2016-09-15 12:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:45:07 --> Controller Class Initialized
INFO - 2016-09-15 12:45:07 --> Database Driver Class Initialized
INFO - 2016-09-15 12:45:07 --> Model Class Initialized
INFO - 2016-09-15 12:45:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:45:07 --> Final output sent to browser
DEBUG - 2016-09-15 12:45:07 --> Total execution time: 0.0713
INFO - 2016-09-15 12:50:00 --> Config Class Initialized
INFO - 2016-09-15 12:50:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:00 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:00 --> URI Class Initialized
INFO - 2016-09-15 12:50:00 --> Router Class Initialized
INFO - 2016-09-15 12:50:00 --> Output Class Initialized
INFO - 2016-09-15 12:50:00 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:00 --> Input Class Initialized
INFO - 2016-09-15 12:50:00 --> Language Class Initialized
INFO - 2016-09-15 12:50:00 --> Loader Class Initialized
INFO - 2016-09-15 12:50:00 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:00 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:00 --> Controller Class Initialized
INFO - 2016-09-15 12:50:00 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:00 --> Model Class Initialized
INFO - 2016-09-15 12:50:00 --> Model Class Initialized
INFO - 2016-09-15 12:50:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:00 --> Helper loaded: form_helper
INFO - 2016-09-15 12:50:00 --> Form Validation Class Initialized
INFO - 2016-09-15 12:50:00 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:50:00 --> Config Class Initialized
INFO - 2016-09-15 12:50:00 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:00 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:00 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:00 --> URI Class Initialized
INFO - 2016-09-15 12:50:00 --> Router Class Initialized
INFO - 2016-09-15 12:50:00 --> Output Class Initialized
INFO - 2016-09-15 12:50:00 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:00 --> Input Class Initialized
INFO - 2016-09-15 12:50:00 --> Language Class Initialized
INFO - 2016-09-15 12:50:00 --> Loader Class Initialized
INFO - 2016-09-15 12:50:00 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:00 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:00 --> Controller Class Initialized
INFO - 2016-09-15 12:50:00 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:00 --> Model Class Initialized
INFO - 2016-09-15 12:50:00 --> Model Class Initialized
INFO - 2016-09-15 12:50:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:00 --> Model Class Initialized
INFO - 2016-09-15 12:50:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:50:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:50:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:50:00 --> Final output sent to browser
DEBUG - 2016-09-15 12:50:00 --> Total execution time: 0.0706
INFO - 2016-09-15 12:50:06 --> Config Class Initialized
INFO - 2016-09-15 12:50:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:06 --> URI Class Initialized
INFO - 2016-09-15 12:50:06 --> Router Class Initialized
INFO - 2016-09-15 12:50:06 --> Output Class Initialized
INFO - 2016-09-15 12:50:06 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:06 --> Input Class Initialized
INFO - 2016-09-15 12:50:06 --> Language Class Initialized
INFO - 2016-09-15 12:50:06 --> Loader Class Initialized
INFO - 2016-09-15 12:50:06 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:06 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:06 --> Controller Class Initialized
INFO - 2016-09-15 12:50:06 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:06 --> Model Class Initialized
INFO - 2016-09-15 12:50:06 --> Model Class Initialized
INFO - 2016-09-15 12:50:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:06 --> Final output sent to browser
DEBUG - 2016-09-15 12:50:06 --> Total execution time: 0.0675
INFO - 2016-09-15 12:50:08 --> Config Class Initialized
INFO - 2016-09-15 12:50:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:08 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:08 --> URI Class Initialized
INFO - 2016-09-15 12:50:08 --> Router Class Initialized
INFO - 2016-09-15 12:50:08 --> Output Class Initialized
INFO - 2016-09-15 12:50:08 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:08 --> Input Class Initialized
INFO - 2016-09-15 12:50:08 --> Language Class Initialized
INFO - 2016-09-15 12:50:08 --> Loader Class Initialized
INFO - 2016-09-15 12:50:08 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:08 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:08 --> Controller Class Initialized
INFO - 2016-09-15 12:50:08 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:08 --> Model Class Initialized
INFO - 2016-09-15 12:50:08 --> Model Class Initialized
INFO - 2016-09-15 12:50:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:08 --> Helper loaded: form_helper
INFO - 2016-09-15 12:50:08 --> Form Validation Class Initialized
INFO - 2016-09-15 12:50:08 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:50:08 --> Config Class Initialized
INFO - 2016-09-15 12:50:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:08 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:08 --> URI Class Initialized
INFO - 2016-09-15 12:50:08 --> Router Class Initialized
INFO - 2016-09-15 12:50:08 --> Output Class Initialized
INFO - 2016-09-15 12:50:08 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:08 --> Input Class Initialized
INFO - 2016-09-15 12:50:08 --> Language Class Initialized
INFO - 2016-09-15 12:50:08 --> Loader Class Initialized
INFO - 2016-09-15 12:50:08 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:08 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:08 --> Controller Class Initialized
INFO - 2016-09-15 12:50:08 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:08 --> Model Class Initialized
INFO - 2016-09-15 12:50:09 --> Model Class Initialized
INFO - 2016-09-15 12:50:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:09 --> Model Class Initialized
INFO - 2016-09-15 12:50:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:50:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:50:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:50:09 --> Final output sent to browser
DEBUG - 2016-09-15 12:50:09 --> Total execution time: 0.0709
INFO - 2016-09-15 12:50:12 --> Config Class Initialized
INFO - 2016-09-15 12:50:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:12 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:12 --> URI Class Initialized
INFO - 2016-09-15 12:50:12 --> Router Class Initialized
INFO - 2016-09-15 12:50:12 --> Output Class Initialized
INFO - 2016-09-15 12:50:12 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:12 --> Input Class Initialized
INFO - 2016-09-15 12:50:12 --> Language Class Initialized
INFO - 2016-09-15 12:50:12 --> Loader Class Initialized
INFO - 2016-09-15 12:50:12 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:12 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:12 --> Controller Class Initialized
INFO - 2016-09-15 12:50:12 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:12 --> Model Class Initialized
INFO - 2016-09-15 12:50:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:12 --> Final output sent to browser
DEBUG - 2016-09-15 12:50:12 --> Total execution time: 0.0698
INFO - 2016-09-15 12:50:14 --> Config Class Initialized
INFO - 2016-09-15 12:50:14 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:50:14 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:50:14 --> Utf8 Class Initialized
INFO - 2016-09-15 12:50:14 --> URI Class Initialized
INFO - 2016-09-15 12:50:14 --> Router Class Initialized
INFO - 2016-09-15 12:50:14 --> Output Class Initialized
INFO - 2016-09-15 12:50:14 --> Security Class Initialized
DEBUG - 2016-09-15 12:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:50:14 --> Input Class Initialized
INFO - 2016-09-15 12:50:14 --> Language Class Initialized
INFO - 2016-09-15 12:50:14 --> Loader Class Initialized
INFO - 2016-09-15 12:50:14 --> Helper loaded: url_helper
INFO - 2016-09-15 12:50:14 --> Helper loaded: language_helper
INFO - 2016-09-15 12:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:50:14 --> Controller Class Initialized
INFO - 2016-09-15 12:50:15 --> Database Driver Class Initialized
INFO - 2016-09-15 12:50:15 --> Model Class Initialized
INFO - 2016-09-15 12:50:15 --> Model Class Initialized
INFO - 2016-09-15 12:50:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:50:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:50:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:50:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:50:15 --> Final output sent to browser
DEBUG - 2016-09-15 12:50:15 --> Total execution time: 0.0598
INFO - 2016-09-15 12:59:06 --> Config Class Initialized
INFO - 2016-09-15 12:59:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:06 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:06 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:06 --> URI Class Initialized
INFO - 2016-09-15 12:59:06 --> Router Class Initialized
INFO - 2016-09-15 12:59:06 --> Output Class Initialized
INFO - 2016-09-15 12:59:06 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:06 --> Input Class Initialized
INFO - 2016-09-15 12:59:06 --> Language Class Initialized
INFO - 2016-09-15 12:59:06 --> Loader Class Initialized
INFO - 2016-09-15 12:59:06 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:06 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:06 --> Controller Class Initialized
INFO - 2016-09-15 12:59:06 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:06 --> Model Class Initialized
INFO - 2016-09-15 12:59:06 --> Model Class Initialized
INFO - 2016-09-15 12:59:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:06 --> Model Class Initialized
INFO - 2016-09-15 12:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:06 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:06 --> Total execution time: 0.0932
INFO - 2016-09-15 12:59:10 --> Config Class Initialized
INFO - 2016-09-15 12:59:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:10 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:10 --> URI Class Initialized
INFO - 2016-09-15 12:59:10 --> Router Class Initialized
INFO - 2016-09-15 12:59:10 --> Output Class Initialized
INFO - 2016-09-15 12:59:10 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:10 --> Input Class Initialized
INFO - 2016-09-15 12:59:10 --> Language Class Initialized
INFO - 2016-09-15 12:59:10 --> Loader Class Initialized
INFO - 2016-09-15 12:59:10 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:10 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:10 --> Controller Class Initialized
INFO - 2016-09-15 12:59:10 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:10 --> Model Class Initialized
INFO - 2016-09-15 12:59:10 --> Model Class Initialized
INFO - 2016-09-15 12:59:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:10 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:10 --> Total execution time: 0.0709
INFO - 2016-09-15 12:59:12 --> Config Class Initialized
INFO - 2016-09-15 12:59:12 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:12 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:12 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:12 --> URI Class Initialized
INFO - 2016-09-15 12:59:12 --> Router Class Initialized
INFO - 2016-09-15 12:59:12 --> Output Class Initialized
INFO - 2016-09-15 12:59:12 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:12 --> Input Class Initialized
INFO - 2016-09-15 12:59:12 --> Language Class Initialized
INFO - 2016-09-15 12:59:12 --> Loader Class Initialized
INFO - 2016-09-15 12:59:12 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:12 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:12 --> Controller Class Initialized
INFO - 2016-09-15 12:59:12 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:12 --> Model Class Initialized
INFO - 2016-09-15 12:59:12 --> Model Class Initialized
INFO - 2016-09-15 12:59:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:12 --> Model Class Initialized
INFO - 2016-09-15 12:59:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:12 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:12 --> Total execution time: 0.0821
INFO - 2016-09-15 12:59:16 --> Config Class Initialized
INFO - 2016-09-15 12:59:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:16 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:16 --> URI Class Initialized
INFO - 2016-09-15 12:59:16 --> Router Class Initialized
INFO - 2016-09-15 12:59:16 --> Output Class Initialized
INFO - 2016-09-15 12:59:16 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:16 --> Input Class Initialized
INFO - 2016-09-15 12:59:16 --> Language Class Initialized
INFO - 2016-09-15 12:59:16 --> Loader Class Initialized
INFO - 2016-09-15 12:59:16 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:16 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:16 --> Controller Class Initialized
INFO - 2016-09-15 12:59:16 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:16 --> Model Class Initialized
INFO - 2016-09-15 12:59:16 --> Model Class Initialized
INFO - 2016-09-15 12:59:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:59:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:16 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:16 --> Total execution time: 0.0635
INFO - 2016-09-15 12:59:19 --> Config Class Initialized
INFO - 2016-09-15 12:59:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:19 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:19 --> URI Class Initialized
INFO - 2016-09-15 12:59:19 --> Router Class Initialized
INFO - 2016-09-15 12:59:19 --> Output Class Initialized
INFO - 2016-09-15 12:59:19 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:19 --> Input Class Initialized
INFO - 2016-09-15 12:59:19 --> Language Class Initialized
INFO - 2016-09-15 12:59:19 --> Loader Class Initialized
INFO - 2016-09-15 12:59:19 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:19 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:19 --> Controller Class Initialized
INFO - 2016-09-15 12:59:19 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:19 --> Model Class Initialized
INFO - 2016-09-15 12:59:19 --> Model Class Initialized
INFO - 2016-09-15 12:59:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:19 --> Model Class Initialized
INFO - 2016-09-15 12:59:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:19 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:19 --> Total execution time: 0.0719
INFO - 2016-09-15 12:59:22 --> Config Class Initialized
INFO - 2016-09-15 12:59:22 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:22 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:22 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:22 --> URI Class Initialized
INFO - 2016-09-15 12:59:22 --> Router Class Initialized
INFO - 2016-09-15 12:59:22 --> Output Class Initialized
INFO - 2016-09-15 12:59:22 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:22 --> Input Class Initialized
INFO - 2016-09-15 12:59:22 --> Language Class Initialized
INFO - 2016-09-15 12:59:22 --> Loader Class Initialized
INFO - 2016-09-15 12:59:22 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:22 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:22 --> Controller Class Initialized
INFO - 2016-09-15 12:59:22 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:22 --> Model Class Initialized
INFO - 2016-09-15 12:59:22 --> Model Class Initialized
INFO - 2016-09-15 12:59:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:59:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:22 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:22 --> Total execution time: 0.0608
INFO - 2016-09-15 12:59:26 --> Config Class Initialized
INFO - 2016-09-15 12:59:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:26 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:26 --> URI Class Initialized
INFO - 2016-09-15 12:59:26 --> Router Class Initialized
INFO - 2016-09-15 12:59:26 --> Output Class Initialized
INFO - 2016-09-15 12:59:26 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:26 --> Input Class Initialized
INFO - 2016-09-15 12:59:26 --> Language Class Initialized
INFO - 2016-09-15 12:59:26 --> Loader Class Initialized
INFO - 2016-09-15 12:59:26 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:26 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:26 --> Controller Class Initialized
INFO - 2016-09-15 12:59:26 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:26 --> Model Class Initialized
INFO - 2016-09-15 12:59:26 --> Model Class Initialized
INFO - 2016-09-15 12:59:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:26 --> Model Class Initialized
INFO - 2016-09-15 12:59:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:26 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:26 --> Total execution time: 0.0698
INFO - 2016-09-15 12:59:29 --> Config Class Initialized
INFO - 2016-09-15 12:59:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:29 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:29 --> URI Class Initialized
INFO - 2016-09-15 12:59:29 --> Router Class Initialized
INFO - 2016-09-15 12:59:29 --> Output Class Initialized
INFO - 2016-09-15 12:59:29 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:29 --> Input Class Initialized
INFO - 2016-09-15 12:59:29 --> Language Class Initialized
INFO - 2016-09-15 12:59:29 --> Loader Class Initialized
INFO - 2016-09-15 12:59:29 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:29 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:29 --> Controller Class Initialized
INFO - 2016-09-15 12:59:29 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:29 --> Model Class Initialized
INFO - 2016-09-15 12:59:29 --> Model Class Initialized
INFO - 2016-09-15 12:59:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:59:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:29 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:29 --> Total execution time: 0.0631
INFO - 2016-09-15 12:59:31 --> Config Class Initialized
INFO - 2016-09-15 12:59:31 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:31 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:31 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:31 --> URI Class Initialized
INFO - 2016-09-15 12:59:31 --> Router Class Initialized
INFO - 2016-09-15 12:59:31 --> Output Class Initialized
INFO - 2016-09-15 12:59:31 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:31 --> Input Class Initialized
INFO - 2016-09-15 12:59:31 --> Language Class Initialized
INFO - 2016-09-15 12:59:31 --> Loader Class Initialized
INFO - 2016-09-15 12:59:31 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:31 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:31 --> Controller Class Initialized
INFO - 2016-09-15 12:59:31 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:31 --> Model Class Initialized
INFO - 2016-09-15 12:59:31 --> Model Class Initialized
INFO - 2016-09-15 12:59:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:31 --> Model Class Initialized
INFO - 2016-09-15 12:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:31 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:31 --> Total execution time: 0.0682
INFO - 2016-09-15 12:59:37 --> Config Class Initialized
INFO - 2016-09-15 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:37 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:37 --> URI Class Initialized
INFO - 2016-09-15 12:59:37 --> Router Class Initialized
INFO - 2016-09-15 12:59:37 --> Output Class Initialized
INFO - 2016-09-15 12:59:37 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:37 --> Input Class Initialized
INFO - 2016-09-15 12:59:37 --> Language Class Initialized
INFO - 2016-09-15 12:59:37 --> Loader Class Initialized
INFO - 2016-09-15 12:59:37 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:37 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:37 --> Controller Class Initialized
INFO - 2016-09-15 12:59:37 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:37 --> Model Class Initialized
INFO - 2016-09-15 12:59:37 --> Model Class Initialized
INFO - 2016-09-15 12:59:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:37 --> Helper loaded: form_helper
INFO - 2016-09-15 12:59:37 --> Form Validation Class Initialized
INFO - 2016-09-15 12:59:37 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:59:37 --> Config Class Initialized
INFO - 2016-09-15 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:37 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:37 --> URI Class Initialized
INFO - 2016-09-15 12:59:37 --> Router Class Initialized
INFO - 2016-09-15 12:59:38 --> Output Class Initialized
INFO - 2016-09-15 12:59:38 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:38 --> Input Class Initialized
INFO - 2016-09-15 12:59:38 --> Language Class Initialized
INFO - 2016-09-15 12:59:38 --> Loader Class Initialized
INFO - 2016-09-15 12:59:38 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:38 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:38 --> Controller Class Initialized
INFO - 2016-09-15 12:59:38 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:38 --> Model Class Initialized
INFO - 2016-09-15 12:59:38 --> Model Class Initialized
INFO - 2016-09-15 12:59:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:38 --> Model Class Initialized
INFO - 2016-09-15 12:59:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:38 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:38 --> Total execution time: 0.0638
INFO - 2016-09-15 12:59:41 --> Config Class Initialized
INFO - 2016-09-15 12:59:41 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:41 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:41 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:41 --> URI Class Initialized
INFO - 2016-09-15 12:59:41 --> Router Class Initialized
INFO - 2016-09-15 12:59:41 --> Output Class Initialized
INFO - 2016-09-15 12:59:41 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:41 --> Input Class Initialized
INFO - 2016-09-15 12:59:41 --> Language Class Initialized
INFO - 2016-09-15 12:59:41 --> Loader Class Initialized
INFO - 2016-09-15 12:59:41 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:41 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:41 --> Controller Class Initialized
INFO - 2016-09-15 12:59:41 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:41 --> Model Class Initialized
INFO - 2016-09-15 12:59:41 --> Model Class Initialized
INFO - 2016-09-15 12:59:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:59:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:42 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:42 --> Total execution time: 0.0702
INFO - 2016-09-15 12:59:44 --> Config Class Initialized
INFO - 2016-09-15 12:59:44 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:44 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:44 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:44 --> URI Class Initialized
INFO - 2016-09-15 12:59:44 --> Router Class Initialized
INFO - 2016-09-15 12:59:44 --> Output Class Initialized
INFO - 2016-09-15 12:59:44 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:44 --> Input Class Initialized
INFO - 2016-09-15 12:59:44 --> Language Class Initialized
INFO - 2016-09-15 12:59:44 --> Loader Class Initialized
INFO - 2016-09-15 12:59:44 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:44 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:44 --> Controller Class Initialized
INFO - 2016-09-15 12:59:44 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:44 --> Model Class Initialized
INFO - 2016-09-15 12:59:44 --> Model Class Initialized
INFO - 2016-09-15 12:59:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:44 --> Model Class Initialized
INFO - 2016-09-15 12:59:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:44 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:44 --> Total execution time: 0.0657
INFO - 2016-09-15 12:59:53 --> Config Class Initialized
INFO - 2016-09-15 12:59:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:53 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:53 --> URI Class Initialized
INFO - 2016-09-15 12:59:53 --> Router Class Initialized
INFO - 2016-09-15 12:59:53 --> Output Class Initialized
INFO - 2016-09-15 12:59:53 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:53 --> Input Class Initialized
INFO - 2016-09-15 12:59:53 --> Language Class Initialized
INFO - 2016-09-15 12:59:53 --> Loader Class Initialized
INFO - 2016-09-15 12:59:53 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:53 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:53 --> Controller Class Initialized
INFO - 2016-09-15 12:59:53 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:53 --> Model Class Initialized
INFO - 2016-09-15 12:59:53 --> Model Class Initialized
INFO - 2016-09-15 12:59:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:53 --> Helper loaded: form_helper
INFO - 2016-09-15 12:59:53 --> Form Validation Class Initialized
INFO - 2016-09-15 12:59:53 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 12:59:53 --> Config Class Initialized
INFO - 2016-09-15 12:59:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:53 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:53 --> URI Class Initialized
INFO - 2016-09-15 12:59:53 --> Router Class Initialized
INFO - 2016-09-15 12:59:53 --> Output Class Initialized
INFO - 2016-09-15 12:59:53 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:53 --> Input Class Initialized
INFO - 2016-09-15 12:59:53 --> Language Class Initialized
INFO - 2016-09-15 12:59:53 --> Loader Class Initialized
INFO - 2016-09-15 12:59:53 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:53 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:53 --> Controller Class Initialized
INFO - 2016-09-15 12:59:53 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:53 --> Model Class Initialized
INFO - 2016-09-15 12:59:53 --> Model Class Initialized
INFO - 2016-09-15 12:59:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:53 --> Model Class Initialized
INFO - 2016-09-15 12:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 12:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:53 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:53 --> Total execution time: 0.0640
INFO - 2016-09-15 12:59:57 --> Config Class Initialized
INFO - 2016-09-15 12:59:57 --> Hooks Class Initialized
DEBUG - 2016-09-15 12:59:57 --> UTF-8 Support Enabled
INFO - 2016-09-15 12:59:57 --> Utf8 Class Initialized
INFO - 2016-09-15 12:59:57 --> URI Class Initialized
INFO - 2016-09-15 12:59:57 --> Router Class Initialized
INFO - 2016-09-15 12:59:57 --> Output Class Initialized
INFO - 2016-09-15 12:59:57 --> Security Class Initialized
DEBUG - 2016-09-15 12:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 12:59:57 --> Input Class Initialized
INFO - 2016-09-15 12:59:57 --> Language Class Initialized
INFO - 2016-09-15 12:59:57 --> Loader Class Initialized
INFO - 2016-09-15 12:59:57 --> Helper loaded: url_helper
INFO - 2016-09-15 12:59:57 --> Helper loaded: language_helper
INFO - 2016-09-15 12:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 12:59:57 --> Controller Class Initialized
INFO - 2016-09-15 12:59:57 --> Database Driver Class Initialized
INFO - 2016-09-15 12:59:57 --> Model Class Initialized
INFO - 2016-09-15 12:59:57 --> Model Class Initialized
INFO - 2016-09-15 12:59:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 12:59:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 12:59:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 12:59:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 12:59:58 --> Final output sent to browser
DEBUG - 2016-09-15 12:59:58 --> Total execution time: 0.0604
INFO - 2016-09-15 13:00:03 --> Config Class Initialized
INFO - 2016-09-15 13:00:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:03 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:03 --> URI Class Initialized
INFO - 2016-09-15 13:00:03 --> Router Class Initialized
INFO - 2016-09-15 13:00:03 --> Output Class Initialized
INFO - 2016-09-15 13:00:03 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:03 --> Input Class Initialized
INFO - 2016-09-15 13:00:03 --> Language Class Initialized
INFO - 2016-09-15 13:00:03 --> Loader Class Initialized
INFO - 2016-09-15 13:00:03 --> Helper loaded: url_helper
INFO - 2016-09-15 13:00:03 --> Helper loaded: language_helper
INFO - 2016-09-15 13:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:00:03 --> Controller Class Initialized
INFO - 2016-09-15 13:00:03 --> Database Driver Class Initialized
INFO - 2016-09-15 13:00:03 --> Model Class Initialized
INFO - 2016-09-15 13:00:03 --> Model Class Initialized
INFO - 2016-09-15 13:00:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:00:03 --> Final output sent to browser
DEBUG - 2016-09-15 13:00:03 --> Total execution time: 0.0599
INFO - 2016-09-15 13:00:08 --> Config Class Initialized
INFO - 2016-09-15 13:00:08 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:08 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:08 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:08 --> URI Class Initialized
INFO - 2016-09-15 13:00:08 --> Router Class Initialized
INFO - 2016-09-15 13:00:08 --> Output Class Initialized
INFO - 2016-09-15 13:00:08 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:08 --> Input Class Initialized
INFO - 2016-09-15 13:00:08 --> Language Class Initialized
INFO - 2016-09-15 13:00:08 --> Loader Class Initialized
INFO - 2016-09-15 13:00:08 --> Helper loaded: url_helper
INFO - 2016-09-15 13:00:08 --> Helper loaded: language_helper
INFO - 2016-09-15 13:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:00:08 --> Controller Class Initialized
INFO - 2016-09-15 13:00:08 --> Database Driver Class Initialized
INFO - 2016-09-15 13:00:08 --> Model Class Initialized
INFO - 2016-09-15 13:00:08 --> Model Class Initialized
INFO - 2016-09-15 13:00:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:00:08 --> Final output sent to browser
DEBUG - 2016-09-15 13:00:08 --> Total execution time: 0.0603
INFO - 2016-09-15 13:00:10 --> Config Class Initialized
INFO - 2016-09-15 13:00:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:10 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:10 --> URI Class Initialized
INFO - 2016-09-15 13:00:10 --> Router Class Initialized
INFO - 2016-09-15 13:00:10 --> Output Class Initialized
INFO - 2016-09-15 13:00:10 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:10 --> Input Class Initialized
INFO - 2016-09-15 13:00:10 --> Language Class Initialized
INFO - 2016-09-15 13:00:10 --> Loader Class Initialized
INFO - 2016-09-15 13:00:10 --> Helper loaded: url_helper
INFO - 2016-09-15 13:00:10 --> Helper loaded: language_helper
INFO - 2016-09-15 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:00:10 --> Controller Class Initialized
INFO - 2016-09-15 13:00:10 --> Database Driver Class Initialized
INFO - 2016-09-15 13:00:10 --> Model Class Initialized
INFO - 2016-09-15 13:00:10 --> Model Class Initialized
INFO - 2016-09-15 13:00:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:00:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:00:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:00:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:00:10 --> Final output sent to browser
DEBUG - 2016-09-15 13:00:10 --> Total execution time: 0.0587
INFO - 2016-09-15 13:00:10 --> Config Class Initialized
INFO - 2016-09-15 13:00:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:10 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:10 --> URI Class Initialized
INFO - 2016-09-15 13:00:10 --> Router Class Initialized
INFO - 2016-09-15 13:00:10 --> Output Class Initialized
INFO - 2016-09-15 13:00:10 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:10 --> Input Class Initialized
INFO - 2016-09-15 13:00:10 --> Language Class Initialized
ERROR - 2016-09-15 13:00:10 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
INFO - 2016-09-15 13:00:10 --> Config Class Initialized
INFO - 2016-09-15 13:00:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:10 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:10 --> URI Class Initialized
INFO - 2016-09-15 13:00:10 --> Router Class Initialized
INFO - 2016-09-15 13:00:10 --> Output Class Initialized
INFO - 2016-09-15 13:00:10 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:10 --> Input Class Initialized
INFO - 2016-09-15 13:00:10 --> Language Class Initialized
ERROR - 2016-09-15 13:00:10 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 13:00:26 --> Config Class Initialized
INFO - 2016-09-15 13:00:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:26 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:26 --> URI Class Initialized
INFO - 2016-09-15 13:00:26 --> Router Class Initialized
INFO - 2016-09-15 13:00:26 --> Output Class Initialized
INFO - 2016-09-15 13:00:26 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:26 --> Input Class Initialized
INFO - 2016-09-15 13:00:26 --> Language Class Initialized
INFO - 2016-09-15 13:00:26 --> Loader Class Initialized
INFO - 2016-09-15 13:00:26 --> Helper loaded: url_helper
INFO - 2016-09-15 13:00:26 --> Helper loaded: language_helper
INFO - 2016-09-15 13:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:00:26 --> Controller Class Initialized
INFO - 2016-09-15 13:00:26 --> Database Driver Class Initialized
INFO - 2016-09-15 13:00:26 --> Model Class Initialized
INFO - 2016-09-15 13:00:26 --> Model Class Initialized
INFO - 2016-09-15 13:00:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:00:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:00:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:00:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:00:26 --> Final output sent to browser
DEBUG - 2016-09-15 13:00:26 --> Total execution time: 0.0734
INFO - 2016-09-15 13:00:51 --> Config Class Initialized
INFO - 2016-09-15 13:00:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:51 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:51 --> URI Class Initialized
INFO - 2016-09-15 13:00:51 --> Router Class Initialized
INFO - 2016-09-15 13:00:51 --> Output Class Initialized
INFO - 2016-09-15 13:00:51 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:51 --> Input Class Initialized
INFO - 2016-09-15 13:00:51 --> Language Class Initialized
INFO - 2016-09-15 13:00:51 --> Loader Class Initialized
INFO - 2016-09-15 13:00:51 --> Helper loaded: url_helper
INFO - 2016-09-15 13:00:51 --> Helper loaded: language_helper
INFO - 2016-09-15 13:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:00:51 --> Controller Class Initialized
INFO - 2016-09-15 13:00:51 --> Database Driver Class Initialized
INFO - 2016-09-15 13:00:51 --> Model Class Initialized
INFO - 2016-09-15 13:00:51 --> Model Class Initialized
INFO - 2016-09-15 13:00:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:00:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:00:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:00:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:00:51 --> Final output sent to browser
DEBUG - 2016-09-15 13:00:51 --> Total execution time: 0.0602
INFO - 2016-09-15 13:00:51 --> Config Class Initialized
INFO - 2016-09-15 13:00:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:51 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:51 --> URI Class Initialized
INFO - 2016-09-15 13:00:51 --> Router Class Initialized
INFO - 2016-09-15 13:00:51 --> Output Class Initialized
INFO - 2016-09-15 13:00:51 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:51 --> Input Class Initialized
INFO - 2016-09-15 13:00:51 --> Language Class Initialized
ERROR - 2016-09-15 13:00:51 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
INFO - 2016-09-15 13:00:51 --> Config Class Initialized
INFO - 2016-09-15 13:00:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:00:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:00:51 --> Utf8 Class Initialized
INFO - 2016-09-15 13:00:51 --> URI Class Initialized
INFO - 2016-09-15 13:00:51 --> Router Class Initialized
INFO - 2016-09-15 13:00:51 --> Output Class Initialized
INFO - 2016-09-15 13:00:51 --> Security Class Initialized
DEBUG - 2016-09-15 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:00:51 --> Input Class Initialized
INFO - 2016-09-15 13:00:51 --> Language Class Initialized
ERROR - 2016-09-15 13:00:51 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
INFO - 2016-09-15 13:01:04 --> Config Class Initialized
INFO - 2016-09-15 13:01:04 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:01:04 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:01:04 --> Utf8 Class Initialized
INFO - 2016-09-15 13:01:04 --> URI Class Initialized
INFO - 2016-09-15 13:01:04 --> Router Class Initialized
INFO - 2016-09-15 13:01:04 --> Output Class Initialized
INFO - 2016-09-15 13:01:04 --> Security Class Initialized
DEBUG - 2016-09-15 13:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:01:04 --> Input Class Initialized
INFO - 2016-09-15 13:01:04 --> Language Class Initialized
INFO - 2016-09-15 13:01:04 --> Loader Class Initialized
INFO - 2016-09-15 13:01:04 --> Helper loaded: url_helper
INFO - 2016-09-15 13:01:04 --> Helper loaded: language_helper
INFO - 2016-09-15 13:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:01:04 --> Controller Class Initialized
INFO - 2016-09-15 13:01:04 --> Database Driver Class Initialized
INFO - 2016-09-15 13:01:04 --> Model Class Initialized
INFO - 2016-09-15 13:01:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:01:04 --> Helper loaded: form_helper
INFO - 2016-09-15 13:01:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:01:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:01:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:01:04 --> Final output sent to browser
DEBUG - 2016-09-15 13:01:04 --> Total execution time: 0.0941
INFO - 2016-09-15 13:01:10 --> Config Class Initialized
INFO - 2016-09-15 13:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:01:10 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:01:10 --> Utf8 Class Initialized
INFO - 2016-09-15 13:01:10 --> URI Class Initialized
INFO - 2016-09-15 13:01:10 --> Router Class Initialized
INFO - 2016-09-15 13:01:10 --> Output Class Initialized
INFO - 2016-09-15 13:01:10 --> Security Class Initialized
DEBUG - 2016-09-15 13:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:01:10 --> Input Class Initialized
INFO - 2016-09-15 13:01:10 --> Language Class Initialized
INFO - 2016-09-15 13:01:10 --> Loader Class Initialized
INFO - 2016-09-15 13:01:10 --> Helper loaded: url_helper
INFO - 2016-09-15 13:01:10 --> Helper loaded: language_helper
INFO - 2016-09-15 13:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:01:10 --> Controller Class Initialized
INFO - 2016-09-15 13:01:10 --> Database Driver Class Initialized
INFO - 2016-09-15 13:01:10 --> Model Class Initialized
INFO - 2016-09-15 13:01:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:01:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:01:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-15 13:01:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:01:10 --> Final output sent to browser
DEBUG - 2016-09-15 13:01:10 --> Total execution time: 0.0668
INFO - 2016-09-15 13:01:51 --> Config Class Initialized
INFO - 2016-09-15 13:01:51 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:01:51 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:01:51 --> Utf8 Class Initialized
INFO - 2016-09-15 13:01:51 --> URI Class Initialized
INFO - 2016-09-15 13:01:51 --> Router Class Initialized
INFO - 2016-09-15 13:01:51 --> Output Class Initialized
INFO - 2016-09-15 13:01:51 --> Security Class Initialized
DEBUG - 2016-09-15 13:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:01:51 --> Input Class Initialized
INFO - 2016-09-15 13:01:51 --> Language Class Initialized
INFO - 2016-09-15 13:01:51 --> Loader Class Initialized
INFO - 2016-09-15 13:01:51 --> Helper loaded: url_helper
INFO - 2016-09-15 13:01:51 --> Helper loaded: language_helper
INFO - 2016-09-15 13:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:01:51 --> Controller Class Initialized
INFO - 2016-09-15 13:01:51 --> Database Driver Class Initialized
INFO - 2016-09-15 13:01:51 --> Model Class Initialized
INFO - 2016-09-15 13:01:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:01:51 --> Helper loaded: form_helper
INFO - 2016-09-15 13:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:01:51 --> Final output sent to browser
DEBUG - 2016-09-15 13:01:51 --> Total execution time: 0.0705
INFO - 2016-09-15 13:06:46 --> Config Class Initialized
INFO - 2016-09-15 13:06:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:06:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:06:46 --> Utf8 Class Initialized
INFO - 2016-09-15 13:06:46 --> URI Class Initialized
INFO - 2016-09-15 13:06:46 --> Router Class Initialized
INFO - 2016-09-15 13:06:46 --> Output Class Initialized
INFO - 2016-09-15 13:06:46 --> Security Class Initialized
DEBUG - 2016-09-15 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:06:46 --> Input Class Initialized
INFO - 2016-09-15 13:06:46 --> Language Class Initialized
INFO - 2016-09-15 13:06:46 --> Loader Class Initialized
INFO - 2016-09-15 13:06:46 --> Helper loaded: url_helper
INFO - 2016-09-15 13:06:46 --> Helper loaded: language_helper
INFO - 2016-09-15 13:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:06:46 --> Controller Class Initialized
INFO - 2016-09-15 13:06:46 --> Database Driver Class Initialized
INFO - 2016-09-15 13:06:46 --> Model Class Initialized
INFO - 2016-09-15 13:06:46 --> Model Class Initialized
INFO - 2016-09-15 13:06:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:06:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:06:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:06:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:06:46 --> Final output sent to browser
DEBUG - 2016-09-15 13:06:46 --> Total execution time: 0.0733
INFO - 2016-09-15 13:09:26 --> Config Class Initialized
INFO - 2016-09-15 13:09:26 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:09:26 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:09:26 --> Utf8 Class Initialized
INFO - 2016-09-15 13:09:26 --> URI Class Initialized
INFO - 2016-09-15 13:09:26 --> Router Class Initialized
INFO - 2016-09-15 13:09:26 --> Output Class Initialized
INFO - 2016-09-15 13:09:26 --> Security Class Initialized
DEBUG - 2016-09-15 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:09:26 --> Input Class Initialized
INFO - 2016-09-15 13:09:26 --> Language Class Initialized
INFO - 2016-09-15 13:09:26 --> Loader Class Initialized
INFO - 2016-09-15 13:09:26 --> Helper loaded: url_helper
INFO - 2016-09-15 13:09:26 --> Helper loaded: language_helper
INFO - 2016-09-15 13:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:09:26 --> Controller Class Initialized
INFO - 2016-09-15 13:09:26 --> Database Driver Class Initialized
INFO - 2016-09-15 13:09:26 --> Model Class Initialized
INFO - 2016-09-15 13:09:26 --> Model Class Initialized
INFO - 2016-09-15 13:09:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:09:26 --> Final output sent to browser
DEBUG - 2016-09-15 13:09:26 --> Total execution time: 0.0711
INFO - 2016-09-15 13:09:42 --> Config Class Initialized
INFO - 2016-09-15 13:09:42 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:09:42 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:09:42 --> Utf8 Class Initialized
INFO - 2016-09-15 13:09:42 --> URI Class Initialized
INFO - 2016-09-15 13:09:42 --> Router Class Initialized
INFO - 2016-09-15 13:09:42 --> Output Class Initialized
INFO - 2016-09-15 13:09:42 --> Security Class Initialized
DEBUG - 2016-09-15 13:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:09:42 --> Input Class Initialized
INFO - 2016-09-15 13:09:42 --> Language Class Initialized
INFO - 2016-09-15 13:09:42 --> Loader Class Initialized
INFO - 2016-09-15 13:09:42 --> Helper loaded: url_helper
INFO - 2016-09-15 13:09:42 --> Helper loaded: language_helper
INFO - 2016-09-15 13:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:09:42 --> Controller Class Initialized
INFO - 2016-09-15 13:09:42 --> Database Driver Class Initialized
INFO - 2016-09-15 13:09:42 --> Model Class Initialized
INFO - 2016-09-15 13:09:42 --> Model Class Initialized
INFO - 2016-09-15 13:09:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:09:43 --> Config Class Initialized
INFO - 2016-09-15 13:09:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:09:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:09:43 --> Utf8 Class Initialized
INFO - 2016-09-15 13:09:43 --> URI Class Initialized
INFO - 2016-09-15 13:09:43 --> Router Class Initialized
INFO - 2016-09-15 13:09:43 --> Output Class Initialized
INFO - 2016-09-15 13:09:43 --> Security Class Initialized
DEBUG - 2016-09-15 13:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:09:43 --> Input Class Initialized
INFO - 2016-09-15 13:09:43 --> Language Class Initialized
INFO - 2016-09-15 13:09:43 --> Loader Class Initialized
INFO - 2016-09-15 13:09:43 --> Helper loaded: url_helper
INFO - 2016-09-15 13:09:43 --> Helper loaded: language_helper
INFO - 2016-09-15 13:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:09:43 --> Controller Class Initialized
INFO - 2016-09-15 13:09:43 --> Database Driver Class Initialized
INFO - 2016-09-15 13:09:43 --> Model Class Initialized
INFO - 2016-09-15 13:09:43 --> Model Class Initialized
INFO - 2016-09-15 13:09:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-15 13:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:09:43 --> Final output sent to browser
DEBUG - 2016-09-15 13:09:43 --> Total execution time: 0.0862
INFO - 2016-09-15 13:09:43 --> Config Class Initialized
INFO - 2016-09-15 13:09:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:09:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:09:43 --> Utf8 Class Initialized
INFO - 2016-09-15 13:09:43 --> URI Class Initialized
INFO - 2016-09-15 13:09:43 --> Router Class Initialized
INFO - 2016-09-15 13:09:43 --> Config Class Initialized
INFO - 2016-09-15 13:09:43 --> Hooks Class Initialized
INFO - 2016-09-15 13:09:43 --> Output Class Initialized
INFO - 2016-09-15 13:09:43 --> Security Class Initialized
DEBUG - 2016-09-15 13:09:43 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:09:43 --> Utf8 Class Initialized
DEBUG - 2016-09-15 13:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:09:43 --> Input Class Initialized
INFO - 2016-09-15 13:09:43 --> URI Class Initialized
INFO - 2016-09-15 13:09:43 --> Language Class Initialized
INFO - 2016-09-15 13:09:43 --> Router Class Initialized
INFO - 2016-09-15 13:09:43 --> Output Class Initialized
INFO - 2016-09-15 13:09:43 --> Loader Class Initialized
INFO - 2016-09-15 13:09:43 --> Helper loaded: url_helper
INFO - 2016-09-15 13:09:43 --> Security Class Initialized
INFO - 2016-09-15 13:09:43 --> Helper loaded: language_helper
DEBUG - 2016-09-15 13:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:09:43 --> Input Class Initialized
INFO - 2016-09-15 13:09:43 --> Language Class Initialized
INFO - 2016-09-15 13:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:09:43 --> Controller Class Initialized
INFO - 2016-09-15 13:09:43 --> Loader Class Initialized
INFO - 2016-09-15 13:09:43 --> Helper loaded: url_helper
INFO - 2016-09-15 13:09:43 --> Helper loaded: language_helper
INFO - 2016-09-15 13:09:43 --> Database Driver Class Initialized
INFO - 2016-09-15 13:09:43 --> Model Class Initialized
INFO - 2016-09-15 13:09:43 --> Model Class Initialized
INFO - 2016-09-15 13:09:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:09:43 --> Final output sent to browser
DEBUG - 2016-09-15 13:09:43 --> Total execution time: 0.0921
INFO - 2016-09-15 13:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:09:43 --> Controller Class Initialized
INFO - 2016-09-15 13:09:43 --> Database Driver Class Initialized
INFO - 2016-09-15 13:09:43 --> Model Class Initialized
INFO - 2016-09-15 13:09:43 --> Model Class Initialized
INFO - 2016-09-15 13:09:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-15 13:09:43 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
ERROR - 2016-09-15 13:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
INFO - 2016-09-15 13:09:43 --> Final output sent to browser
DEBUG - 2016-09-15 13:09:43 --> Total execution time: 0.1230
INFO - 2016-09-15 13:09:59 --> Config Class Initialized
INFO - 2016-09-15 13:09:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:09:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:09:59 --> Utf8 Class Initialized
INFO - 2016-09-15 13:09:59 --> URI Class Initialized
INFO - 2016-09-15 13:09:59 --> Router Class Initialized
INFO - 2016-09-15 13:09:59 --> Output Class Initialized
INFO - 2016-09-15 13:09:59 --> Security Class Initialized
DEBUG - 2016-09-15 13:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:09:59 --> Input Class Initialized
INFO - 2016-09-15 13:09:59 --> Language Class Initialized
INFO - 2016-09-15 13:09:59 --> Loader Class Initialized
INFO - 2016-09-15 13:09:59 --> Helper loaded: url_helper
INFO - 2016-09-15 13:09:59 --> Helper loaded: language_helper
INFO - 2016-09-15 13:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:09:59 --> Controller Class Initialized
INFO - 2016-09-15 13:09:59 --> Database Driver Class Initialized
INFO - 2016-09-15 13:09:59 --> Model Class Initialized
INFO - 2016-09-15 13:09:59 --> Model Class Initialized
INFO - 2016-09-15 13:09:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:09:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:09:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:09:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:09:59 --> Final output sent to browser
DEBUG - 2016-09-15 13:09:59 --> Total execution time: 0.0737
INFO - 2016-09-15 13:10:29 --> Config Class Initialized
INFO - 2016-09-15 13:10:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:10:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:10:29 --> Utf8 Class Initialized
INFO - 2016-09-15 13:10:29 --> URI Class Initialized
INFO - 2016-09-15 13:10:29 --> Router Class Initialized
INFO - 2016-09-15 13:10:29 --> Output Class Initialized
INFO - 2016-09-15 13:10:29 --> Security Class Initialized
DEBUG - 2016-09-15 13:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:10:29 --> Input Class Initialized
INFO - 2016-09-15 13:10:29 --> Language Class Initialized
INFO - 2016-09-15 13:10:29 --> Loader Class Initialized
INFO - 2016-09-15 13:10:29 --> Helper loaded: url_helper
INFO - 2016-09-15 13:10:29 --> Helper loaded: language_helper
INFO - 2016-09-15 13:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:10:29 --> Controller Class Initialized
INFO - 2016-09-15 13:10:29 --> Database Driver Class Initialized
INFO - 2016-09-15 13:10:29 --> Model Class Initialized
INFO - 2016-09-15 13:10:29 --> Model Class Initialized
INFO - 2016-09-15 13:10:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:10:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:10:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-09-15 13:10:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:10:29 --> Final output sent to browser
DEBUG - 2016-09-15 13:10:29 --> Total execution time: 0.0886
INFO - 2016-09-15 13:13:47 --> Config Class Initialized
INFO - 2016-09-15 13:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:13:47 --> Utf8 Class Initialized
INFO - 2016-09-15 13:13:47 --> URI Class Initialized
INFO - 2016-09-15 13:13:47 --> Router Class Initialized
INFO - 2016-09-15 13:13:47 --> Output Class Initialized
INFO - 2016-09-15 13:13:47 --> Security Class Initialized
DEBUG - 2016-09-15 13:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:13:47 --> Input Class Initialized
INFO - 2016-09-15 13:13:47 --> Language Class Initialized
INFO - 2016-09-15 13:13:47 --> Loader Class Initialized
INFO - 2016-09-15 13:13:47 --> Helper loaded: url_helper
INFO - 2016-09-15 13:13:47 --> Helper loaded: language_helper
INFO - 2016-09-15 13:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:13:47 --> Controller Class Initialized
INFO - 2016-09-15 13:13:47 --> Database Driver Class Initialized
INFO - 2016-09-15 13:13:47 --> Model Class Initialized
INFO - 2016-09-15 13:13:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:13:47 --> Helper loaded: form_helper
INFO - 2016-09-15 13:13:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:13:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:13:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:13:47 --> Final output sent to browser
DEBUG - 2016-09-15 13:13:47 --> Total execution time: 0.0844
INFO - 2016-09-15 13:14:13 --> Config Class Initialized
INFO - 2016-09-15 13:14:13 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:13 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:13 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:13 --> URI Class Initialized
INFO - 2016-09-15 13:14:13 --> Router Class Initialized
INFO - 2016-09-15 13:14:13 --> Output Class Initialized
INFO - 2016-09-15 13:14:13 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:13 --> Input Class Initialized
INFO - 2016-09-15 13:14:13 --> Language Class Initialized
INFO - 2016-09-15 13:14:13 --> Loader Class Initialized
INFO - 2016-09-15 13:14:13 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:13 --> Helper loaded: language_helper
INFO - 2016-09-15 13:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:14:13 --> Controller Class Initialized
INFO - 2016-09-15 13:14:13 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:13 --> Model Class Initialized
INFO - 2016-09-15 13:14:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:14:13 --> Helper loaded: form_helper
INFO - 2016-09-15 13:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:14:13 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:13 --> Total execution time: 0.0862
INFO - 2016-09-15 13:14:27 --> Config Class Initialized
INFO - 2016-09-15 13:14:27 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:27 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:27 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:27 --> URI Class Initialized
INFO - 2016-09-15 13:14:27 --> Router Class Initialized
INFO - 2016-09-15 13:14:27 --> Output Class Initialized
INFO - 2016-09-15 13:14:27 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:27 --> Input Class Initialized
INFO - 2016-09-15 13:14:27 --> Language Class Initialized
INFO - 2016-09-15 13:14:27 --> Loader Class Initialized
INFO - 2016-09-15 13:14:27 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:27 --> Helper loaded: language_helper
INFO - 2016-09-15 13:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:14:27 --> Controller Class Initialized
INFO - 2016-09-15 13:14:27 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:27 --> Model Class Initialized
INFO - 2016-09-15 13:14:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:14:27 --> Helper loaded: form_helper
INFO - 2016-09-15 13:14:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:14:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:14:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:14:27 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:27 --> Total execution time: 0.0749
INFO - 2016-09-15 13:14:29 --> Config Class Initialized
INFO - 2016-09-15 13:14:29 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:29 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:29 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:29 --> URI Class Initialized
INFO - 2016-09-15 13:14:29 --> Router Class Initialized
INFO - 2016-09-15 13:14:29 --> Output Class Initialized
INFO - 2016-09-15 13:14:29 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:29 --> Input Class Initialized
INFO - 2016-09-15 13:14:29 --> Language Class Initialized
INFO - 2016-09-15 13:14:29 --> Loader Class Initialized
INFO - 2016-09-15 13:14:29 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:29 --> Helper loaded: language_helper
INFO - 2016-09-15 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:14:29 --> Controller Class Initialized
INFO - 2016-09-15 13:14:29 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:29 --> Model Class Initialized
INFO - 2016-09-15 13:14:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:14:29 --> Helper loaded: form_helper
INFO - 2016-09-15 13:14:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:14:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:14:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:14:29 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:29 --> Total execution time: 0.0804
INFO - 2016-09-15 13:14:32 --> Config Class Initialized
INFO - 2016-09-15 13:14:32 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:32 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:32 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:32 --> URI Class Initialized
INFO - 2016-09-15 13:14:32 --> Router Class Initialized
INFO - 2016-09-15 13:14:32 --> Output Class Initialized
INFO - 2016-09-15 13:14:32 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:32 --> Input Class Initialized
INFO - 2016-09-15 13:14:32 --> Language Class Initialized
INFO - 2016-09-15 13:14:32 --> Loader Class Initialized
INFO - 2016-09-15 13:14:32 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:32 --> Helper loaded: language_helper
INFO - 2016-09-15 13:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:14:32 --> Controller Class Initialized
INFO - 2016-09-15 13:14:32 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:32 --> Model Class Initialized
INFO - 2016-09-15 13:14:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:14:32 --> Helper loaded: form_helper
INFO - 2016-09-15 13:14:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:14:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:14:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:14:32 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:32 --> Total execution time: 0.0768
INFO - 2016-09-15 13:14:55 --> Config Class Initialized
INFO - 2016-09-15 13:14:55 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:14:55 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:14:55 --> Utf8 Class Initialized
INFO - 2016-09-15 13:14:56 --> URI Class Initialized
INFO - 2016-09-15 13:14:56 --> Router Class Initialized
INFO - 2016-09-15 13:14:56 --> Output Class Initialized
INFO - 2016-09-15 13:14:56 --> Security Class Initialized
DEBUG - 2016-09-15 13:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:14:56 --> Input Class Initialized
INFO - 2016-09-15 13:14:56 --> Language Class Initialized
INFO - 2016-09-15 13:14:56 --> Loader Class Initialized
INFO - 2016-09-15 13:14:56 --> Helper loaded: url_helper
INFO - 2016-09-15 13:14:56 --> Helper loaded: language_helper
INFO - 2016-09-15 13:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:14:56 --> Controller Class Initialized
INFO - 2016-09-15 13:14:56 --> Database Driver Class Initialized
INFO - 2016-09-15 13:14:56 --> Model Class Initialized
INFO - 2016-09-15 13:14:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:14:56 --> Helper loaded: form_helper
INFO - 2016-09-15 13:14:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:14:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-15 13:14:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:14:56 --> Final output sent to browser
DEBUG - 2016-09-15 13:14:56 --> Total execution time: 0.1036
INFO - 2016-09-15 13:15:50 --> Config Class Initialized
INFO - 2016-09-15 13:15:50 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:15:50 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:15:50 --> Utf8 Class Initialized
INFO - 2016-09-15 13:15:50 --> URI Class Initialized
INFO - 2016-09-15 13:15:50 --> Router Class Initialized
INFO - 2016-09-15 13:15:50 --> Output Class Initialized
INFO - 2016-09-15 13:15:50 --> Security Class Initialized
DEBUG - 2016-09-15 13:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:15:50 --> Input Class Initialized
INFO - 2016-09-15 13:15:50 --> Language Class Initialized
INFO - 2016-09-15 13:15:50 --> Loader Class Initialized
INFO - 2016-09-15 13:15:50 --> Helper loaded: url_helper
INFO - 2016-09-15 13:15:50 --> Helper loaded: language_helper
INFO - 2016-09-15 13:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:15:50 --> Controller Class Initialized
INFO - 2016-09-15 13:15:50 --> Database Driver Class Initialized
INFO - 2016-09-15 13:15:50 --> Model Class Initialized
INFO - 2016-09-15 13:15:50 --> Model Class Initialized
INFO - 2016-09-15 13:15:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:15:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:15:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:15:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:15:50 --> Final output sent to browser
DEBUG - 2016-09-15 13:15:50 --> Total execution time: 0.0712
INFO - 2016-09-15 13:15:53 --> Config Class Initialized
INFO - 2016-09-15 13:15:53 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:15:53 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:15:53 --> Utf8 Class Initialized
INFO - 2016-09-15 13:15:53 --> URI Class Initialized
INFO - 2016-09-15 13:15:53 --> Router Class Initialized
INFO - 2016-09-15 13:15:53 --> Output Class Initialized
INFO - 2016-09-15 13:15:53 --> Security Class Initialized
DEBUG - 2016-09-15 13:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:15:53 --> Input Class Initialized
INFO - 2016-09-15 13:15:53 --> Language Class Initialized
INFO - 2016-09-15 13:15:53 --> Loader Class Initialized
INFO - 2016-09-15 13:15:53 --> Helper loaded: url_helper
INFO - 2016-09-15 13:15:53 --> Helper loaded: language_helper
INFO - 2016-09-15 13:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:15:53 --> Controller Class Initialized
INFO - 2016-09-15 13:15:53 --> Database Driver Class Initialized
INFO - 2016-09-15 13:15:53 --> Model Class Initialized
INFO - 2016-09-15 13:15:53 --> Model Class Initialized
INFO - 2016-09-15 13:15:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:15:53 --> Model Class Initialized
INFO - 2016-09-15 13:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 13:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:15:53 --> Final output sent to browser
DEBUG - 2016-09-15 13:15:53 --> Total execution time: 0.0869
INFO - 2016-09-15 13:15:54 --> Config Class Initialized
INFO - 2016-09-15 13:15:54 --> Config Class Initialized
INFO - 2016-09-15 13:15:54 --> Hooks Class Initialized
INFO - 2016-09-15 13:15:54 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:15:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 13:15:54 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:15:54 --> Utf8 Class Initialized
INFO - 2016-09-15 13:15:54 --> Utf8 Class Initialized
INFO - 2016-09-15 13:15:54 --> URI Class Initialized
INFO - 2016-09-15 13:15:54 --> URI Class Initialized
INFO - 2016-09-15 13:15:54 --> Router Class Initialized
INFO - 2016-09-15 13:15:54 --> Router Class Initialized
INFO - 2016-09-15 13:15:54 --> Output Class Initialized
INFO - 2016-09-15 13:15:54 --> Output Class Initialized
INFO - 2016-09-15 13:15:54 --> Security Class Initialized
INFO - 2016-09-15 13:15:54 --> Security Class Initialized
DEBUG - 2016-09-15 13:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:15:54 --> Input Class Initialized
INFO - 2016-09-15 13:15:54 --> Language Class Initialized
DEBUG - 2016-09-15 13:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:15:54 --> Input Class Initialized
INFO - 2016-09-15 13:15:54 --> Language Class Initialized
ERROR - 2016-09-15 13:15:54 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
ERROR - 2016-09-15 13:15:54 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 13:16:28 --> Config Class Initialized
INFO - 2016-09-15 13:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:28 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:28 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:28 --> URI Class Initialized
INFO - 2016-09-15 13:16:28 --> Router Class Initialized
INFO - 2016-09-15 13:16:28 --> Output Class Initialized
INFO - 2016-09-15 13:16:28 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:28 --> Input Class Initialized
INFO - 2016-09-15 13:16:28 --> Language Class Initialized
INFO - 2016-09-15 13:16:28 --> Loader Class Initialized
INFO - 2016-09-15 13:16:28 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:28 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:28 --> Controller Class Initialized
INFO - 2016-09-15 13:16:28 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:28 --> Model Class Initialized
INFO - 2016-09-15 13:16:28 --> Model Class Initialized
INFO - 2016-09-15 13:16:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:16:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:16:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:16:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:16:28 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:28 --> Total execution time: 0.0751
INFO - 2016-09-15 13:16:34 --> Config Class Initialized
INFO - 2016-09-15 13:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:34 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:34 --> URI Class Initialized
INFO - 2016-09-15 13:16:34 --> Router Class Initialized
INFO - 2016-09-15 13:16:34 --> Output Class Initialized
INFO - 2016-09-15 13:16:34 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:34 --> Input Class Initialized
INFO - 2016-09-15 13:16:34 --> Language Class Initialized
INFO - 2016-09-15 13:16:34 --> Loader Class Initialized
INFO - 2016-09-15 13:16:34 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:34 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:34 --> Controller Class Initialized
INFO - 2016-09-15 13:16:34 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:34 --> Model Class Initialized
INFO - 2016-09-15 13:16:34 --> Model Class Initialized
INFO - 2016-09-15 13:16:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:16:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:16:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:16:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:16:34 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:34 --> Total execution time: 0.0687
INFO - 2016-09-15 13:16:34 --> Config Class Initialized
INFO - 2016-09-15 13:16:34 --> Hooks Class Initialized
INFO - 2016-09-15 13:16:34 --> Config Class Initialized
INFO - 2016-09-15 13:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 13:16:34 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:34 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:34 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:34 --> URI Class Initialized
INFO - 2016-09-15 13:16:34 --> URI Class Initialized
INFO - 2016-09-15 13:16:34 --> Router Class Initialized
INFO - 2016-09-15 13:16:34 --> Router Class Initialized
INFO - 2016-09-15 13:16:34 --> Output Class Initialized
INFO - 2016-09-15 13:16:34 --> Output Class Initialized
INFO - 2016-09-15 13:16:34 --> Security Class Initialized
INFO - 2016-09-15 13:16:34 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:34 --> Input Class Initialized
DEBUG - 2016-09-15 13:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:34 --> Input Class Initialized
INFO - 2016-09-15 13:16:34 --> Language Class Initialized
INFO - 2016-09-15 13:16:34 --> Language Class Initialized
ERROR - 2016-09-15 13:16:34 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
ERROR - 2016-09-15 13:16:34 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
INFO - 2016-09-15 13:16:36 --> Config Class Initialized
INFO - 2016-09-15 13:16:36 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:36 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:36 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:36 --> URI Class Initialized
INFO - 2016-09-15 13:16:36 --> Router Class Initialized
INFO - 2016-09-15 13:16:36 --> Output Class Initialized
INFO - 2016-09-15 13:16:36 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:36 --> Input Class Initialized
INFO - 2016-09-15 13:16:36 --> Language Class Initialized
INFO - 2016-09-15 13:16:36 --> Loader Class Initialized
INFO - 2016-09-15 13:16:36 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:36 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:36 --> Controller Class Initialized
INFO - 2016-09-15 13:16:36 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:16:36 --> Config Class Initialized
INFO - 2016-09-15 13:16:36 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:36 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:36 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:36 --> URI Class Initialized
INFO - 2016-09-15 13:16:36 --> Router Class Initialized
INFO - 2016-09-15 13:16:36 --> Output Class Initialized
INFO - 2016-09-15 13:16:36 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:36 --> Input Class Initialized
INFO - 2016-09-15 13:16:36 --> Language Class Initialized
INFO - 2016-09-15 13:16:36 --> Loader Class Initialized
INFO - 2016-09-15 13:16:36 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:36 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:36 --> Controller Class Initialized
INFO - 2016-09-15 13:16:36 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:16:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:16:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-15 13:16:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:16:36 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:36 --> Total execution time: 0.0749
INFO - 2016-09-15 13:16:36 --> Config Class Initialized
INFO - 2016-09-15 13:16:36 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:36 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:36 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:36 --> Config Class Initialized
INFO - 2016-09-15 13:16:36 --> Hooks Class Initialized
INFO - 2016-09-15 13:16:36 --> URI Class Initialized
INFO - 2016-09-15 13:16:36 --> Router Class Initialized
DEBUG - 2016-09-15 13:16:36 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:36 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:36 --> Output Class Initialized
INFO - 2016-09-15 13:16:36 --> URI Class Initialized
INFO - 2016-09-15 13:16:36 --> Security Class Initialized
INFO - 2016-09-15 13:16:36 --> Router Class Initialized
DEBUG - 2016-09-15 13:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:36 --> Input Class Initialized
INFO - 2016-09-15 13:16:36 --> Output Class Initialized
INFO - 2016-09-15 13:16:36 --> Language Class Initialized
INFO - 2016-09-15 13:16:36 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:36 --> Loader Class Initialized
INFO - 2016-09-15 13:16:36 --> Input Class Initialized
INFO - 2016-09-15 13:16:36 --> Language Class Initialized
INFO - 2016-09-15 13:16:36 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:36 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:36 --> Loader Class Initialized
INFO - 2016-09-15 13:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:36 --> Controller Class Initialized
INFO - 2016-09-15 13:16:36 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:36 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:36 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:16:36 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:36 --> Total execution time: 0.0918
INFO - 2016-09-15 13:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:36 --> Controller Class Initialized
INFO - 2016-09-15 13:16:36 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Model Class Initialized
INFO - 2016-09-15 13:16:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-15 13:16:36 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
ERROR - 2016-09-15 13:16:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
INFO - 2016-09-15 13:16:36 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:36 --> Total execution time: 0.1214
INFO - 2016-09-15 13:16:56 --> Config Class Initialized
INFO - 2016-09-15 13:16:56 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:16:56 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:16:56 --> Utf8 Class Initialized
INFO - 2016-09-15 13:16:56 --> URI Class Initialized
INFO - 2016-09-15 13:16:56 --> Router Class Initialized
INFO - 2016-09-15 13:16:56 --> Output Class Initialized
INFO - 2016-09-15 13:16:56 --> Security Class Initialized
DEBUG - 2016-09-15 13:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:16:56 --> Input Class Initialized
INFO - 2016-09-15 13:16:56 --> Language Class Initialized
INFO - 2016-09-15 13:16:56 --> Loader Class Initialized
INFO - 2016-09-15 13:16:56 --> Helper loaded: url_helper
INFO - 2016-09-15 13:16:56 --> Helper loaded: language_helper
INFO - 2016-09-15 13:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:16:56 --> Controller Class Initialized
INFO - 2016-09-15 13:16:56 --> Database Driver Class Initialized
INFO - 2016-09-15 13:16:56 --> Model Class Initialized
INFO - 2016-09-15 13:16:56 --> Model Class Initialized
INFO - 2016-09-15 13:16:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:16:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:16:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:16:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:16:56 --> Final output sent to browser
DEBUG - 2016-09-15 13:16:56 --> Total execution time: 0.0832
INFO - 2016-09-15 13:17:03 --> Config Class Initialized
INFO - 2016-09-15 13:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:03 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:03 --> URI Class Initialized
INFO - 2016-09-15 13:17:03 --> Router Class Initialized
INFO - 2016-09-15 13:17:03 --> Output Class Initialized
INFO - 2016-09-15 13:17:03 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:03 --> Input Class Initialized
INFO - 2016-09-15 13:17:03 --> Language Class Initialized
INFO - 2016-09-15 13:17:03 --> Loader Class Initialized
INFO - 2016-09-15 13:17:03 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:03 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:03 --> Controller Class Initialized
INFO - 2016-09-15 13:17:03 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:03 --> Model Class Initialized
INFO - 2016-09-15 13:17:03 --> Model Class Initialized
INFO - 2016-09-15 13:17:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:17:03 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:03 --> Total execution time: 0.0690
INFO - 2016-09-15 13:17:03 --> Config Class Initialized
INFO - 2016-09-15 13:17:03 --> Hooks Class Initialized
INFO - 2016-09-15 13:17:03 --> Config Class Initialized
INFO - 2016-09-15 13:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-15 13:17:03 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:03 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:03 --> URI Class Initialized
INFO - 2016-09-15 13:17:03 --> Router Class Initialized
INFO - 2016-09-15 13:17:03 --> URI Class Initialized
INFO - 2016-09-15 13:17:03 --> Output Class Initialized
INFO - 2016-09-15 13:17:03 --> Router Class Initialized
INFO - 2016-09-15 13:17:03 --> Security Class Initialized
INFO - 2016-09-15 13:17:03 --> Output Class Initialized
DEBUG - 2016-09-15 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:03 --> Input Class Initialized
INFO - 2016-09-15 13:17:03 --> Security Class Initialized
INFO - 2016-09-15 13:17:03 --> Language Class Initialized
DEBUG - 2016-09-15 13:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-15 13:17:03 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
INFO - 2016-09-15 13:17:03 --> Input Class Initialized
INFO - 2016-09-15 13:17:03 --> Language Class Initialized
ERROR - 2016-09-15 13:17:03 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
INFO - 2016-09-15 13:17:21 --> Config Class Initialized
INFO - 2016-09-15 13:17:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:21 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:21 --> URI Class Initialized
INFO - 2016-09-15 13:17:21 --> Router Class Initialized
INFO - 2016-09-15 13:17:21 --> Output Class Initialized
INFO - 2016-09-15 13:17:21 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:21 --> Input Class Initialized
INFO - 2016-09-15 13:17:21 --> Language Class Initialized
INFO - 2016-09-15 13:17:21 --> Loader Class Initialized
INFO - 2016-09-15 13:17:21 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:21 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:21 --> Controller Class Initialized
INFO - 2016-09-15 13:17:21 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:21 --> Model Class Initialized
INFO - 2016-09-15 13:17:21 --> Model Class Initialized
INFO - 2016-09-15 13:17:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:17:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:17:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:17:21 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:21 --> Total execution time: 0.0718
INFO - 2016-09-15 13:17:24 --> Config Class Initialized
INFO - 2016-09-15 13:17:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:24 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:24 --> URI Class Initialized
INFO - 2016-09-15 13:17:24 --> Router Class Initialized
INFO - 2016-09-15 13:17:24 --> Output Class Initialized
INFO - 2016-09-15 13:17:24 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:24 --> Input Class Initialized
INFO - 2016-09-15 13:17:24 --> Language Class Initialized
INFO - 2016-09-15 13:17:24 --> Loader Class Initialized
INFO - 2016-09-15 13:17:24 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:24 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:24 --> Controller Class Initialized
INFO - 2016-09-15 13:17:24 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:24 --> Model Class Initialized
INFO - 2016-09-15 13:17:24 --> Model Class Initialized
INFO - 2016-09-15 13:17:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:24 --> Model Class Initialized
INFO - 2016-09-15 13:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 13:17:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:17:24 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:24 --> Total execution time: 0.0774
INFO - 2016-09-15 13:17:25 --> Config Class Initialized
INFO - 2016-09-15 13:17:25 --> Config Class Initialized
INFO - 2016-09-15 13:17:25 --> Hooks Class Initialized
INFO - 2016-09-15 13:17:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:25 --> Utf8 Class Initialized
DEBUG - 2016-09-15 13:17:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:25 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:25 --> URI Class Initialized
INFO - 2016-09-15 13:17:25 --> URI Class Initialized
INFO - 2016-09-15 13:17:25 --> Router Class Initialized
INFO - 2016-09-15 13:17:25 --> Router Class Initialized
INFO - 2016-09-15 13:17:25 --> Output Class Initialized
INFO - 2016-09-15 13:17:25 --> Output Class Initialized
INFO - 2016-09-15 13:17:25 --> Security Class Initialized
INFO - 2016-09-15 13:17:25 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-15 13:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:25 --> Input Class Initialized
INFO - 2016-09-15 13:17:25 --> Input Class Initialized
INFO - 2016-09-15 13:17:25 --> Language Class Initialized
INFO - 2016-09-15 13:17:25 --> Language Class Initialized
ERROR - 2016-09-15 13:17:25 --> 404 Page Not Found: Upload/ffd8f45283d2279487b726076c63ef2e.jpg
ERROR - 2016-09-15 13:17:25 --> 404 Page Not Found: Upload/d2729782959b0a8edbf00f5aa46be333.jpg
INFO - 2016-09-15 13:17:49 --> Config Class Initialized
INFO - 2016-09-15 13:17:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:49 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:49 --> URI Class Initialized
INFO - 2016-09-15 13:17:49 --> Router Class Initialized
INFO - 2016-09-15 13:17:49 --> Output Class Initialized
INFO - 2016-09-15 13:17:49 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:49 --> Input Class Initialized
INFO - 2016-09-15 13:17:49 --> Language Class Initialized
INFO - 2016-09-15 13:17:49 --> Loader Class Initialized
INFO - 2016-09-15 13:17:49 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:49 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:49 --> Controller Class Initialized
INFO - 2016-09-15 13:17:49 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:49 --> Model Class Initialized
INFO - 2016-09-15 13:17:49 --> Model Class Initialized
INFO - 2016-09-15 13:17:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:49 --> Helper loaded: form_helper
INFO - 2016-09-15 13:17:49 --> Form Validation Class Initialized
INFO - 2016-09-15 13:17:49 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 13:17:49 --> Config Class Initialized
INFO - 2016-09-15 13:17:49 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:49 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:49 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:49 --> URI Class Initialized
INFO - 2016-09-15 13:17:49 --> Router Class Initialized
INFO - 2016-09-15 13:17:49 --> Output Class Initialized
INFO - 2016-09-15 13:17:49 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:49 --> Input Class Initialized
INFO - 2016-09-15 13:17:49 --> Language Class Initialized
INFO - 2016-09-15 13:17:49 --> Loader Class Initialized
INFO - 2016-09-15 13:17:49 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:49 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:49 --> Controller Class Initialized
INFO - 2016-09-15 13:17:49 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:49 --> Model Class Initialized
INFO - 2016-09-15 13:17:49 --> Model Class Initialized
INFO - 2016-09-15 13:17:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:49 --> Model Class Initialized
INFO - 2016-09-15 13:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 13:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:17:49 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:49 --> Total execution time: 0.0801
INFO - 2016-09-15 13:17:56 --> Config Class Initialized
INFO - 2016-09-15 13:17:56 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:56 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:56 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:56 --> URI Class Initialized
INFO - 2016-09-15 13:17:56 --> Router Class Initialized
INFO - 2016-09-15 13:17:56 --> Output Class Initialized
INFO - 2016-09-15 13:17:56 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:56 --> Input Class Initialized
INFO - 2016-09-15 13:17:56 --> Language Class Initialized
INFO - 2016-09-15 13:17:56 --> Loader Class Initialized
INFO - 2016-09-15 13:17:56 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:56 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:56 --> Controller Class Initialized
INFO - 2016-09-15 13:17:56 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:56 --> Model Class Initialized
INFO - 2016-09-15 13:17:56 --> Model Class Initialized
INFO - 2016-09-15 13:17:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:17:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:17:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:17:56 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:56 --> Total execution time: 0.0701
INFO - 2016-09-15 13:17:59 --> Config Class Initialized
INFO - 2016-09-15 13:17:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:59 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:59 --> URI Class Initialized
INFO - 2016-09-15 13:17:59 --> Router Class Initialized
INFO - 2016-09-15 13:17:59 --> Output Class Initialized
INFO - 2016-09-15 13:17:59 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:59 --> Input Class Initialized
INFO - 2016-09-15 13:17:59 --> Language Class Initialized
INFO - 2016-09-15 13:17:59 --> Loader Class Initialized
INFO - 2016-09-15 13:17:59 --> Helper loaded: url_helper
INFO - 2016-09-15 13:17:59 --> Helper loaded: language_helper
INFO - 2016-09-15 13:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:17:59 --> Controller Class Initialized
INFO - 2016-09-15 13:17:59 --> Database Driver Class Initialized
INFO - 2016-09-15 13:17:59 --> Model Class Initialized
INFO - 2016-09-15 13:17:59 --> Model Class Initialized
INFO - 2016-09-15 13:17:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:17:59 --> Model Class Initialized
INFO - 2016-09-15 13:17:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:17:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 13:17:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:17:59 --> Final output sent to browser
DEBUG - 2016-09-15 13:17:59 --> Total execution time: 0.0762
INFO - 2016-09-15 13:17:59 --> Config Class Initialized
INFO - 2016-09-15 13:17:59 --> Hooks Class Initialized
INFO - 2016-09-15 13:17:59 --> Config Class Initialized
INFO - 2016-09-15 13:17:59 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 13:17:59 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:17:59 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:59 --> Utf8 Class Initialized
INFO - 2016-09-15 13:17:59 --> URI Class Initialized
INFO - 2016-09-15 13:17:59 --> URI Class Initialized
INFO - 2016-09-15 13:17:59 --> Router Class Initialized
INFO - 2016-09-15 13:17:59 --> Router Class Initialized
INFO - 2016-09-15 13:17:59 --> Output Class Initialized
INFO - 2016-09-15 13:17:59 --> Output Class Initialized
INFO - 2016-09-15 13:17:59 --> Security Class Initialized
INFO - 2016-09-15 13:17:59 --> Security Class Initialized
DEBUG - 2016-09-15 13:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-15 13:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:17:59 --> Input Class Initialized
INFO - 2016-09-15 13:17:59 --> Input Class Initialized
INFO - 2016-09-15 13:17:59 --> Language Class Initialized
INFO - 2016-09-15 13:17:59 --> Language Class Initialized
ERROR - 2016-09-15 13:17:59 --> 404 Page Not Found: Upload/8b85147b2d3b70cf133d7c51a5b7ef1e.jpg
ERROR - 2016-09-15 13:17:59 --> 404 Page Not Found: Upload/b7888d1a399d9c5fc9ab5800d7e1d334.jpg
INFO - 2016-09-15 13:18:19 --> Config Class Initialized
INFO - 2016-09-15 13:18:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:18:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:18:19 --> Utf8 Class Initialized
INFO - 2016-09-15 13:18:19 --> URI Class Initialized
INFO - 2016-09-15 13:18:19 --> Router Class Initialized
INFO - 2016-09-15 13:18:19 --> Output Class Initialized
INFO - 2016-09-15 13:18:19 --> Security Class Initialized
DEBUG - 2016-09-15 13:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:18:19 --> Input Class Initialized
INFO - 2016-09-15 13:18:19 --> Language Class Initialized
INFO - 2016-09-15 13:18:19 --> Loader Class Initialized
INFO - 2016-09-15 13:18:19 --> Helper loaded: url_helper
INFO - 2016-09-15 13:18:19 --> Helper loaded: language_helper
INFO - 2016-09-15 13:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:18:19 --> Controller Class Initialized
INFO - 2016-09-15 13:18:19 --> Database Driver Class Initialized
INFO - 2016-09-15 13:18:19 --> Model Class Initialized
INFO - 2016-09-15 13:18:19 --> Model Class Initialized
INFO - 2016-09-15 13:18:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:18:19 --> Helper loaded: form_helper
INFO - 2016-09-15 13:18:19 --> Form Validation Class Initialized
INFO - 2016-09-15 13:18:19 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-09-15 13:18:19 --> Config Class Initialized
INFO - 2016-09-15 13:18:19 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:18:19 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:18:19 --> Utf8 Class Initialized
INFO - 2016-09-15 13:18:19 --> URI Class Initialized
INFO - 2016-09-15 13:18:20 --> Router Class Initialized
INFO - 2016-09-15 13:18:20 --> Output Class Initialized
INFO - 2016-09-15 13:18:20 --> Security Class Initialized
DEBUG - 2016-09-15 13:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:18:20 --> Input Class Initialized
INFO - 2016-09-15 13:18:20 --> Language Class Initialized
INFO - 2016-09-15 13:18:20 --> Loader Class Initialized
INFO - 2016-09-15 13:18:20 --> Helper loaded: url_helper
INFO - 2016-09-15 13:18:20 --> Helper loaded: language_helper
INFO - 2016-09-15 13:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:18:20 --> Controller Class Initialized
INFO - 2016-09-15 13:18:20 --> Database Driver Class Initialized
INFO - 2016-09-15 13:18:20 --> Model Class Initialized
INFO - 2016-09-15 13:18:20 --> Model Class Initialized
INFO - 2016-09-15 13:18:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:18:20 --> Model Class Initialized
INFO - 2016-09-15 13:18:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:18:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-09-15 13:18:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:18:20 --> Final output sent to browser
DEBUG - 2016-09-15 13:18:20 --> Total execution time: 0.0805
INFO - 2016-09-15 13:18:25 --> Config Class Initialized
INFO - 2016-09-15 13:18:25 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:18:25 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:18:25 --> Utf8 Class Initialized
INFO - 2016-09-15 13:18:25 --> URI Class Initialized
INFO - 2016-09-15 13:18:25 --> Router Class Initialized
INFO - 2016-09-15 13:18:25 --> Output Class Initialized
INFO - 2016-09-15 13:18:25 --> Security Class Initialized
DEBUG - 2016-09-15 13:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:18:25 --> Input Class Initialized
INFO - 2016-09-15 13:18:25 --> Language Class Initialized
INFO - 2016-09-15 13:18:25 --> Loader Class Initialized
INFO - 2016-09-15 13:18:25 --> Helper loaded: url_helper
INFO - 2016-09-15 13:18:25 --> Helper loaded: language_helper
INFO - 2016-09-15 13:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:18:25 --> Controller Class Initialized
INFO - 2016-09-15 13:18:25 --> Database Driver Class Initialized
INFO - 2016-09-15 13:18:25 --> Model Class Initialized
INFO - 2016-09-15 13:18:25 --> Model Class Initialized
INFO - 2016-09-15 13:18:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:18:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:18:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:18:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:18:25 --> Final output sent to browser
DEBUG - 2016-09-15 13:18:25 --> Total execution time: 0.0702
INFO - 2016-09-15 13:18:28 --> Config Class Initialized
INFO - 2016-09-15 13:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:18:28 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:18:28 --> Utf8 Class Initialized
INFO - 2016-09-15 13:18:28 --> URI Class Initialized
INFO - 2016-09-15 13:18:28 --> Router Class Initialized
INFO - 2016-09-15 13:18:28 --> Output Class Initialized
INFO - 2016-09-15 13:18:28 --> Security Class Initialized
DEBUG - 2016-09-15 13:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:18:28 --> Input Class Initialized
INFO - 2016-09-15 13:18:28 --> Language Class Initialized
INFO - 2016-09-15 13:18:28 --> Loader Class Initialized
INFO - 2016-09-15 13:18:28 --> Helper loaded: url_helper
INFO - 2016-09-15 13:18:28 --> Helper loaded: language_helper
INFO - 2016-09-15 13:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:18:28 --> Controller Class Initialized
INFO - 2016-09-15 13:18:28 --> Database Driver Class Initialized
INFO - 2016-09-15 13:18:28 --> Model Class Initialized
INFO - 2016-09-15 13:18:28 --> Model Class Initialized
INFO - 2016-09-15 13:18:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:18:28 --> Final output sent to browser
DEBUG - 2016-09-15 13:18:28 --> Total execution time: 0.0688
INFO - 2016-09-15 13:20:37 --> Config Class Initialized
INFO - 2016-09-15 13:20:37 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:20:37 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:20:37 --> Utf8 Class Initialized
INFO - 2016-09-15 13:20:37 --> URI Class Initialized
INFO - 2016-09-15 13:20:37 --> Router Class Initialized
INFO - 2016-09-15 13:20:37 --> Output Class Initialized
INFO - 2016-09-15 13:20:37 --> Security Class Initialized
DEBUG - 2016-09-15 13:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:20:37 --> Input Class Initialized
INFO - 2016-09-15 13:20:37 --> Language Class Initialized
INFO - 2016-09-15 13:20:37 --> Loader Class Initialized
INFO - 2016-09-15 13:20:37 --> Helper loaded: url_helper
INFO - 2016-09-15 13:20:37 --> Helper loaded: language_helper
INFO - 2016-09-15 13:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:20:37 --> Controller Class Initialized
INFO - 2016-09-15 13:20:37 --> Database Driver Class Initialized
INFO - 2016-09-15 13:20:37 --> Model Class Initialized
INFO - 2016-09-15 13:20:37 --> Model Class Initialized
INFO - 2016-09-15 13:20:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-15 13:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:20:37 --> Final output sent to browser
DEBUG - 2016-09-15 13:20:37 --> Total execution time: 0.0812
INFO - 2016-09-15 13:22:45 --> Config Class Initialized
INFO - 2016-09-15 13:22:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:22:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:22:45 --> Utf8 Class Initialized
INFO - 2016-09-15 13:22:45 --> URI Class Initialized
INFO - 2016-09-15 13:22:45 --> Router Class Initialized
INFO - 2016-09-15 13:22:45 --> Output Class Initialized
INFO - 2016-09-15 13:22:45 --> Security Class Initialized
DEBUG - 2016-09-15 13:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:22:45 --> Input Class Initialized
INFO - 2016-09-15 13:22:45 --> Language Class Initialized
INFO - 2016-09-15 13:22:45 --> Loader Class Initialized
INFO - 2016-09-15 13:22:45 --> Helper loaded: url_helper
INFO - 2016-09-15 13:22:45 --> Helper loaded: language_helper
INFO - 2016-09-15 13:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:22:45 --> Controller Class Initialized
INFO - 2016-09-15 13:22:45 --> Database Driver Class Initialized
INFO - 2016-09-15 13:22:45 --> Model Class Initialized
INFO - 2016-09-15 13:22:45 --> Model Class Initialized
INFO - 2016-09-15 13:22:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:22:45 --> Config Class Initialized
INFO - 2016-09-15 13:22:45 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:22:45 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:22:45 --> Utf8 Class Initialized
INFO - 2016-09-15 13:22:45 --> URI Class Initialized
INFO - 2016-09-15 13:22:45 --> Router Class Initialized
INFO - 2016-09-15 13:22:45 --> Output Class Initialized
INFO - 2016-09-15 13:22:45 --> Security Class Initialized
DEBUG - 2016-09-15 13:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:22:45 --> Input Class Initialized
INFO - 2016-09-15 13:22:45 --> Language Class Initialized
INFO - 2016-09-15 13:22:45 --> Loader Class Initialized
INFO - 2016-09-15 13:22:45 --> Helper loaded: url_helper
INFO - 2016-09-15 13:22:45 --> Helper loaded: language_helper
INFO - 2016-09-15 13:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:22:45 --> Controller Class Initialized
INFO - 2016-09-15 13:22:45 --> Database Driver Class Initialized
INFO - 2016-09-15 13:22:46 --> Model Class Initialized
INFO - 2016-09-15 13:22:46 --> Model Class Initialized
INFO - 2016-09-15 13:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-15 13:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:22:46 --> Final output sent to browser
DEBUG - 2016-09-15 13:22:46 --> Total execution time: 0.1102
INFO - 2016-09-15 13:22:46 --> Config Class Initialized
INFO - 2016-09-15 13:22:46 --> Hooks Class Initialized
INFO - 2016-09-15 13:22:46 --> Config Class Initialized
INFO - 2016-09-15 13:22:46 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:22:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:22:46 --> Utf8 Class Initialized
INFO - 2016-09-15 13:22:46 --> URI Class Initialized
DEBUG - 2016-09-15 13:22:46 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:22:46 --> Router Class Initialized
INFO - 2016-09-15 13:22:46 --> Utf8 Class Initialized
INFO - 2016-09-15 13:22:46 --> Output Class Initialized
INFO - 2016-09-15 13:22:46 --> URI Class Initialized
INFO - 2016-09-15 13:22:46 --> Security Class Initialized
INFO - 2016-09-15 13:22:46 --> Router Class Initialized
DEBUG - 2016-09-15 13:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:22:46 --> Input Class Initialized
INFO - 2016-09-15 13:22:46 --> Output Class Initialized
INFO - 2016-09-15 13:22:46 --> Language Class Initialized
INFO - 2016-09-15 13:22:46 --> Security Class Initialized
DEBUG - 2016-09-15 13:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:22:46 --> Input Class Initialized
INFO - 2016-09-15 13:22:46 --> Loader Class Initialized
INFO - 2016-09-15 13:22:46 --> Language Class Initialized
INFO - 2016-09-15 13:22:46 --> Helper loaded: url_helper
INFO - 2016-09-15 13:22:46 --> Helper loaded: language_helper
INFO - 2016-09-15 13:22:46 --> Loader Class Initialized
INFO - 2016-09-15 13:22:46 --> Helper loaded: url_helper
INFO - 2016-09-15 13:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:22:46 --> Helper loaded: language_helper
INFO - 2016-09-15 13:22:46 --> Controller Class Initialized
INFO - 2016-09-15 13:22:46 --> Database Driver Class Initialized
INFO - 2016-09-15 13:22:46 --> Model Class Initialized
INFO - 2016-09-15 13:22:46 --> Model Class Initialized
INFO - 2016-09-15 13:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:22:46 --> Final output sent to browser
DEBUG - 2016-09-15 13:22:46 --> Total execution time: 0.0957
INFO - 2016-09-15 13:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:22:46 --> Controller Class Initialized
INFO - 2016-09-15 13:22:46 --> Database Driver Class Initialized
INFO - 2016-09-15 13:22:46 --> Model Class Initialized
INFO - 2016-09-15 13:22:46 --> Model Class Initialized
INFO - 2016-09-15 13:22:46 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-15 13:22:46 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
ERROR - 2016-09-15 13:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 687
INFO - 2016-09-15 13:22:46 --> Final output sent to browser
DEBUG - 2016-09-15 13:22:46 --> Total execution time: 0.1419
INFO - 2016-09-15 13:23:16 --> Config Class Initialized
INFO - 2016-09-15 13:23:16 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:23:16 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:23:16 --> Utf8 Class Initialized
INFO - 2016-09-15 13:23:16 --> URI Class Initialized
INFO - 2016-09-15 13:23:16 --> Router Class Initialized
INFO - 2016-09-15 13:23:16 --> Output Class Initialized
INFO - 2016-09-15 13:23:16 --> Security Class Initialized
DEBUG - 2016-09-15 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:23:16 --> Input Class Initialized
INFO - 2016-09-15 13:23:16 --> Language Class Initialized
INFO - 2016-09-15 13:23:16 --> Loader Class Initialized
INFO - 2016-09-15 13:23:16 --> Helper loaded: url_helper
INFO - 2016-09-15 13:23:16 --> Helper loaded: language_helper
INFO - 2016-09-15 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:23:16 --> Controller Class Initialized
INFO - 2016-09-15 13:23:16 --> Database Driver Class Initialized
INFO - 2016-09-15 13:23:16 --> Model Class Initialized
INFO - 2016-09-15 13:23:16 --> Model Class Initialized
INFO - 2016-09-15 13:23:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:23:16 --> Final output sent to browser
DEBUG - 2016-09-15 13:23:16 --> Total execution time: 0.0837
INFO - 2016-09-15 13:23:21 --> Config Class Initialized
INFO - 2016-09-15 13:23:21 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:23:21 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:23:21 --> Utf8 Class Initialized
INFO - 2016-09-15 13:23:21 --> URI Class Initialized
INFO - 2016-09-15 13:23:21 --> Router Class Initialized
INFO - 2016-09-15 13:23:21 --> Output Class Initialized
INFO - 2016-09-15 13:23:21 --> Security Class Initialized
DEBUG - 2016-09-15 13:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:23:21 --> Input Class Initialized
INFO - 2016-09-15 13:23:21 --> Language Class Initialized
INFO - 2016-09-15 13:23:21 --> Loader Class Initialized
INFO - 2016-09-15 13:23:21 --> Helper loaded: url_helper
INFO - 2016-09-15 13:23:21 --> Helper loaded: language_helper
INFO - 2016-09-15 13:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:23:21 --> Controller Class Initialized
INFO - 2016-09-15 13:23:21 --> Database Driver Class Initialized
INFO - 2016-09-15 13:23:21 --> Model Class Initialized
INFO - 2016-09-15 13:23:21 --> Model Class Initialized
INFO - 2016-09-15 13:23:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-15 13:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-15 13:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-15 13:23:21 --> Final output sent to browser
DEBUG - 2016-09-15 13:23:21 --> Total execution time: 0.0814
INFO - 2016-09-15 13:25:24 --> Config Class Initialized
INFO - 2016-09-15 13:25:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:25:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:25:24 --> Utf8 Class Initialized
INFO - 2016-09-15 13:25:24 --> URI Class Initialized
INFO - 2016-09-15 13:25:24 --> Router Class Initialized
INFO - 2016-09-15 13:25:24 --> Output Class Initialized
INFO - 2016-09-15 13:25:24 --> Security Class Initialized
DEBUG - 2016-09-15 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:25:24 --> Input Class Initialized
INFO - 2016-09-15 13:25:24 --> Language Class Initialized
INFO - 2016-09-15 13:25:24 --> Loader Class Initialized
INFO - 2016-09-15 13:25:24 --> Helper loaded: url_helper
INFO - 2016-09-15 13:25:24 --> Helper loaded: language_helper
INFO - 2016-09-15 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:25:24 --> Controller Class Initialized
INFO - 2016-09-15 13:25:24 --> Database Driver Class Initialized
INFO - 2016-09-15 13:25:24 --> Model Class Initialized
INFO - 2016-09-15 13:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:25:24 --> Config Class Initialized
INFO - 2016-09-15 13:25:24 --> Hooks Class Initialized
DEBUG - 2016-09-15 13:25:24 --> UTF-8 Support Enabled
INFO - 2016-09-15 13:25:24 --> Utf8 Class Initialized
INFO - 2016-09-15 13:25:24 --> URI Class Initialized
INFO - 2016-09-15 13:25:24 --> Router Class Initialized
INFO - 2016-09-15 13:25:24 --> Output Class Initialized
INFO - 2016-09-15 13:25:24 --> Security Class Initialized
DEBUG - 2016-09-15 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-15 13:25:24 --> Input Class Initialized
INFO - 2016-09-15 13:25:24 --> Language Class Initialized
INFO - 2016-09-15 13:25:24 --> Loader Class Initialized
INFO - 2016-09-15 13:25:24 --> Helper loaded: url_helper
INFO - 2016-09-15 13:25:24 --> Helper loaded: language_helper
INFO - 2016-09-15 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-15 13:25:24 --> Controller Class Initialized
INFO - 2016-09-15 13:25:24 --> Database Driver Class Initialized
INFO - 2016-09-15 13:25:24 --> Model Class Initialized
INFO - 2016-09-15 13:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-15 13:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-15 13:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-15 13:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-15 13:25:24 --> Final output sent to browser
DEBUG - 2016-09-15 13:25:24 --> Total execution time: 0.0636
