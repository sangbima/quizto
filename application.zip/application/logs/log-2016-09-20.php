<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-20 15:18:09 --> Config Class Initialized
INFO - 2016-09-20 15:18:09 --> Hooks Class Initialized
DEBUG - 2016-09-20 15:18:09 --> UTF-8 Support Enabled
INFO - 2016-09-20 15:18:09 --> Utf8 Class Initialized
INFO - 2016-09-20 15:18:09 --> URI Class Initialized
INFO - 2016-09-20 15:18:09 --> Router Class Initialized
INFO - 2016-09-20 15:18:09 --> Output Class Initialized
INFO - 2016-09-20 15:18:09 --> Security Class Initialized
DEBUG - 2016-09-20 15:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-20 15:18:09 --> Input Class Initialized
INFO - 2016-09-20 15:18:09 --> Language Class Initialized
INFO - 2016-09-20 15:18:09 --> Loader Class Initialized
INFO - 2016-09-20 15:18:09 --> Helper loaded: url_helper
INFO - 2016-09-20 15:18:09 --> Helper loaded: language_helper
INFO - 2016-09-20 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-20 15:18:09 --> Controller Class Initialized
INFO - 2016-09-20 15:18:09 --> Database Driver Class Initialized
INFO - 2016-09-20 15:18:09 --> Model Class Initialized
INFO - 2016-09-20 15:18:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-20 15:18:09 --> Config Class Initialized
INFO - 2016-09-20 15:18:09 --> Hooks Class Initialized
DEBUG - 2016-09-20 15:18:09 --> UTF-8 Support Enabled
INFO - 2016-09-20 15:18:09 --> Utf8 Class Initialized
INFO - 2016-09-20 15:18:10 --> URI Class Initialized
INFO - 2016-09-20 15:18:10 --> Router Class Initialized
INFO - 2016-09-20 15:18:10 --> Output Class Initialized
INFO - 2016-09-20 15:18:10 --> Security Class Initialized
DEBUG - 2016-09-20 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-20 15:18:10 --> Input Class Initialized
INFO - 2016-09-20 15:18:10 --> Language Class Initialized
INFO - 2016-09-20 15:18:10 --> Loader Class Initialized
INFO - 2016-09-20 15:18:10 --> Helper loaded: url_helper
INFO - 2016-09-20 15:18:10 --> Helper loaded: language_helper
INFO - 2016-09-20 15:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-20 15:18:10 --> Controller Class Initialized
INFO - 2016-09-20 15:18:10 --> Database Driver Class Initialized
INFO - 2016-09-20 15:18:10 --> Model Class Initialized
INFO - 2016-09-20 15:18:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-20 15:18:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-20 15:18:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-20 15:18:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-20 15:18:10 --> Final output sent to browser
DEBUG - 2016-09-20 15:18:10 --> Total execution time: 0.0551
