<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-21 07:42:09 --> Config Class Initialized
INFO - 2016-09-21 07:42:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 07:42:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 07:42:09 --> Utf8 Class Initialized
INFO - 2016-09-21 07:42:09 --> URI Class Initialized
INFO - 2016-09-21 07:42:09 --> Router Class Initialized
INFO - 2016-09-21 07:42:09 --> Output Class Initialized
INFO - 2016-09-21 07:42:09 --> Security Class Initialized
DEBUG - 2016-09-21 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 07:42:09 --> Input Class Initialized
INFO - 2016-09-21 07:42:09 --> Language Class Initialized
INFO - 2016-09-21 07:42:09 --> Loader Class Initialized
INFO - 2016-09-21 07:42:09 --> Helper loaded: url_helper
INFO - 2016-09-21 07:42:09 --> Helper loaded: language_helper
INFO - 2016-09-21 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 07:42:09 --> Controller Class Initialized
INFO - 2016-09-21 07:42:09 --> Database Driver Class Initialized
INFO - 2016-09-21 07:42:09 --> Model Class Initialized
INFO - 2016-09-21 07:42:09 --> Model Class Initialized
INFO - 2016-09-21 07:42:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 07:42:09 --> Config Class Initialized
INFO - 2016-09-21 07:42:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 07:42:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 07:42:09 --> Utf8 Class Initialized
INFO - 2016-09-21 07:42:09 --> URI Class Initialized
INFO - 2016-09-21 07:42:09 --> Router Class Initialized
INFO - 2016-09-21 07:42:09 --> Output Class Initialized
INFO - 2016-09-21 07:42:09 --> Security Class Initialized
DEBUG - 2016-09-21 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 07:42:09 --> Input Class Initialized
INFO - 2016-09-21 07:42:09 --> Language Class Initialized
INFO - 2016-09-21 07:42:09 --> Loader Class Initialized
INFO - 2016-09-21 07:42:09 --> Helper loaded: url_helper
INFO - 2016-09-21 07:42:09 --> Helper loaded: language_helper
INFO - 2016-09-21 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 07:42:09 --> Controller Class Initialized
INFO - 2016-09-21 07:42:09 --> Database Driver Class Initialized
INFO - 2016-09-21 07:42:09 --> Model Class Initialized
INFO - 2016-09-21 07:42:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 07:42:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-21 07:42:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-21 07:42:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-21 07:42:09 --> Final output sent to browser
DEBUG - 2016-09-21 07:42:09 --> Total execution time: 0.0569
INFO - 2016-09-21 07:42:14 --> Config Class Initialized
INFO - 2016-09-21 07:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 07:42:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 07:42:14 --> Utf8 Class Initialized
INFO - 2016-09-21 07:42:14 --> URI Class Initialized
INFO - 2016-09-21 07:42:14 --> Router Class Initialized
INFO - 2016-09-21 07:42:14 --> Output Class Initialized
INFO - 2016-09-21 07:42:14 --> Security Class Initialized
DEBUG - 2016-09-21 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 07:42:14 --> Input Class Initialized
INFO - 2016-09-21 07:42:14 --> Language Class Initialized
INFO - 2016-09-21 07:42:14 --> Loader Class Initialized
INFO - 2016-09-21 07:42:14 --> Helper loaded: url_helper
INFO - 2016-09-21 07:42:14 --> Helper loaded: language_helper
INFO - 2016-09-21 07:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 07:42:14 --> Controller Class Initialized
INFO - 2016-09-21 07:42:14 --> Database Driver Class Initialized
INFO - 2016-09-21 07:42:14 --> Model Class Initialized
INFO - 2016-09-21 07:42:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 07:42:14 --> Config Class Initialized
INFO - 2016-09-21 07:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 07:42:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 07:42:14 --> Utf8 Class Initialized
INFO - 2016-09-21 07:42:14 --> URI Class Initialized
INFO - 2016-09-21 07:42:14 --> Router Class Initialized
INFO - 2016-09-21 07:42:14 --> Output Class Initialized
INFO - 2016-09-21 07:42:14 --> Security Class Initialized
DEBUG - 2016-09-21 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 07:42:14 --> Input Class Initialized
INFO - 2016-09-21 07:42:14 --> Language Class Initialized
INFO - 2016-09-21 07:42:14 --> Loader Class Initialized
INFO - 2016-09-21 07:42:14 --> Helper loaded: url_helper
INFO - 2016-09-21 07:42:14 --> Helper loaded: language_helper
INFO - 2016-09-21 07:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 07:42:14 --> Controller Class Initialized
INFO - 2016-09-21 07:42:14 --> Database Driver Class Initialized
INFO - 2016-09-21 07:42:14 --> Model Class Initialized
INFO - 2016-09-21 07:42:14 --> Model Class Initialized
INFO - 2016-09-21 07:42:14 --> Model Class Initialized
INFO - 2016-09-21 07:42:14 --> Model Class Initialized
INFO - 2016-09-21 07:42:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 07:42:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 07:42:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-21 07:42:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 07:42:14 --> Final output sent to browser
DEBUG - 2016-09-21 07:42:14 --> Total execution time: 0.0735
INFO - 2016-09-21 07:42:18 --> Config Class Initialized
INFO - 2016-09-21 07:42:18 --> Hooks Class Initialized
DEBUG - 2016-09-21 07:42:18 --> UTF-8 Support Enabled
INFO - 2016-09-21 07:42:18 --> Utf8 Class Initialized
INFO - 2016-09-21 07:42:18 --> URI Class Initialized
INFO - 2016-09-21 07:42:18 --> Router Class Initialized
INFO - 2016-09-21 07:42:18 --> Output Class Initialized
INFO - 2016-09-21 07:42:18 --> Security Class Initialized
DEBUG - 2016-09-21 07:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 07:42:18 --> Input Class Initialized
INFO - 2016-09-21 07:42:18 --> Language Class Initialized
INFO - 2016-09-21 07:42:18 --> Loader Class Initialized
INFO - 2016-09-21 07:42:18 --> Helper loaded: url_helper
INFO - 2016-09-21 07:42:18 --> Helper loaded: language_helper
INFO - 2016-09-21 07:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 07:42:18 --> Controller Class Initialized
INFO - 2016-09-21 07:42:18 --> Database Driver Class Initialized
INFO - 2016-09-21 07:42:18 --> Model Class Initialized
INFO - 2016-09-21 07:42:18 --> Model Class Initialized
INFO - 2016-09-21 07:42:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 07:42:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 07:42:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-21 07:42:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 07:42:18 --> Final output sent to browser
DEBUG - 2016-09-21 07:42:18 --> Total execution time: 0.0637
INFO - 2016-09-21 08:21:20 --> Config Class Initialized
INFO - 2016-09-21 08:21:20 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:21:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:21:20 --> Utf8 Class Initialized
INFO - 2016-09-21 08:21:20 --> URI Class Initialized
INFO - 2016-09-21 08:21:20 --> Router Class Initialized
INFO - 2016-09-21 08:21:20 --> Output Class Initialized
INFO - 2016-09-21 08:21:20 --> Security Class Initialized
DEBUG - 2016-09-21 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:21:20 --> Input Class Initialized
INFO - 2016-09-21 08:21:20 --> Language Class Initialized
INFO - 2016-09-21 08:21:20 --> Loader Class Initialized
INFO - 2016-09-21 08:21:20 --> Helper loaded: url_helper
INFO - 2016-09-21 08:21:20 --> Helper loaded: language_helper
INFO - 2016-09-21 08:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:21:20 --> Controller Class Initialized
INFO - 2016-09-21 08:21:20 --> Database Driver Class Initialized
INFO - 2016-09-21 08:21:20 --> Model Class Initialized
INFO - 2016-09-21 08:21:20 --> Model Class Initialized
INFO - 2016-09-21 08:21:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:21:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:21:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-21 08:21:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:21:20 --> Final output sent to browser
DEBUG - 2016-09-21 08:21:20 --> Total execution time: 0.0715
INFO - 2016-09-21 08:21:27 --> Config Class Initialized
INFO - 2016-09-21 08:21:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:21:27 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:21:27 --> Utf8 Class Initialized
INFO - 2016-09-21 08:21:27 --> URI Class Initialized
INFO - 2016-09-21 08:21:27 --> Router Class Initialized
INFO - 2016-09-21 08:21:27 --> Output Class Initialized
INFO - 2016-09-21 08:21:27 --> Security Class Initialized
DEBUG - 2016-09-21 08:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:21:27 --> Input Class Initialized
INFO - 2016-09-21 08:21:27 --> Language Class Initialized
INFO - 2016-09-21 08:21:27 --> Loader Class Initialized
INFO - 2016-09-21 08:21:27 --> Helper loaded: url_helper
INFO - 2016-09-21 08:21:27 --> Helper loaded: language_helper
INFO - 2016-09-21 08:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:21:27 --> Controller Class Initialized
INFO - 2016-09-21 08:21:27 --> Database Driver Class Initialized
INFO - 2016-09-21 08:21:27 --> Model Class Initialized
INFO - 2016-09-21 08:21:27 --> Model Class Initialized
INFO - 2016-09-21 08:21:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:21:27 --> Config Class Initialized
INFO - 2016-09-21 08:21:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:21:27 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:21:27 --> Utf8 Class Initialized
INFO - 2016-09-21 08:21:27 --> URI Class Initialized
INFO - 2016-09-21 08:21:27 --> Router Class Initialized
INFO - 2016-09-21 08:21:27 --> Output Class Initialized
INFO - 2016-09-21 08:21:27 --> Security Class Initialized
DEBUG - 2016-09-21 08:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:21:27 --> Input Class Initialized
INFO - 2016-09-21 08:21:27 --> Language Class Initialized
INFO - 2016-09-21 08:21:27 --> Loader Class Initialized
INFO - 2016-09-21 08:21:27 --> Helper loaded: url_helper
INFO - 2016-09-21 08:21:27 --> Helper loaded: language_helper
INFO - 2016-09-21 08:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:21:27 --> Controller Class Initialized
INFO - 2016-09-21 08:21:27 --> Database Driver Class Initialized
INFO - 2016-09-21 08:21:27 --> Model Class Initialized
INFO - 2016-09-21 08:21:27 --> Model Class Initialized
INFO - 2016-09-21 08:21:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-21 08:21:27 --> Severity: Notice --> Undefined variable: quid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 112
INFO - 2016-09-21 08:21:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:21:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:21:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:21:27 --> Final output sent to browser
DEBUG - 2016-09-21 08:21:27 --> Total execution time: 0.0609
INFO - 2016-09-21 08:22:34 --> Config Class Initialized
INFO - 2016-09-21 08:22:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:22:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:22:34 --> Utf8 Class Initialized
INFO - 2016-09-21 08:22:34 --> URI Class Initialized
INFO - 2016-09-21 08:22:34 --> Router Class Initialized
INFO - 2016-09-21 08:22:34 --> Output Class Initialized
INFO - 2016-09-21 08:22:34 --> Security Class Initialized
DEBUG - 2016-09-21 08:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:22:34 --> Input Class Initialized
INFO - 2016-09-21 08:22:34 --> Language Class Initialized
INFO - 2016-09-21 08:22:34 --> Loader Class Initialized
INFO - 2016-09-21 08:22:34 --> Helper loaded: url_helper
INFO - 2016-09-21 08:22:34 --> Helper loaded: language_helper
INFO - 2016-09-21 08:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:22:34 --> Controller Class Initialized
INFO - 2016-09-21 08:22:34 --> Database Driver Class Initialized
INFO - 2016-09-21 08:22:34 --> Model Class Initialized
INFO - 2016-09-21 08:22:34 --> Model Class Initialized
INFO - 2016-09-21 08:22:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-21 08:22:34 --> Severity: Notice --> Undefined variable: qid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 111
INFO - 2016-09-21 08:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:22:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:22:34 --> Final output sent to browser
DEBUG - 2016-09-21 08:22:34 --> Total execution time: 0.0844
INFO - 2016-09-21 08:22:44 --> Config Class Initialized
INFO - 2016-09-21 08:22:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:22:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:22:44 --> Utf8 Class Initialized
INFO - 2016-09-21 08:22:44 --> URI Class Initialized
INFO - 2016-09-21 08:22:44 --> Router Class Initialized
INFO - 2016-09-21 08:22:44 --> Output Class Initialized
INFO - 2016-09-21 08:22:44 --> Security Class Initialized
DEBUG - 2016-09-21 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:22:44 --> Input Class Initialized
INFO - 2016-09-21 08:22:44 --> Language Class Initialized
INFO - 2016-09-21 08:22:44 --> Loader Class Initialized
INFO - 2016-09-21 08:22:44 --> Helper loaded: url_helper
INFO - 2016-09-21 08:22:44 --> Helper loaded: language_helper
INFO - 2016-09-21 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:22:44 --> Controller Class Initialized
INFO - 2016-09-21 08:22:44 --> Database Driver Class Initialized
INFO - 2016-09-21 08:22:44 --> Model Class Initialized
INFO - 2016-09-21 08:22:44 --> Model Class Initialized
INFO - 2016-09-21 08:22:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:22:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:22:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:22:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:22:44 --> Final output sent to browser
DEBUG - 2016-09-21 08:22:44 --> Total execution time: 0.0594
INFO - 2016-09-21 08:25:48 --> Config Class Initialized
INFO - 2016-09-21 08:25:48 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:25:48 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:25:48 --> Utf8 Class Initialized
INFO - 2016-09-21 08:25:48 --> URI Class Initialized
INFO - 2016-09-21 08:25:48 --> Router Class Initialized
INFO - 2016-09-21 08:25:48 --> Output Class Initialized
INFO - 2016-09-21 08:25:48 --> Security Class Initialized
DEBUG - 2016-09-21 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:25:48 --> Input Class Initialized
INFO - 2016-09-21 08:25:48 --> Language Class Initialized
INFO - 2016-09-21 08:25:48 --> Loader Class Initialized
INFO - 2016-09-21 08:25:48 --> Helper loaded: url_helper
INFO - 2016-09-21 08:25:48 --> Helper loaded: language_helper
INFO - 2016-09-21 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:25:48 --> Controller Class Initialized
INFO - 2016-09-21 08:25:48 --> Database Driver Class Initialized
INFO - 2016-09-21 08:25:48 --> Model Class Initialized
INFO - 2016-09-21 08:25:48 --> Model Class Initialized
INFO - 2016-09-21 08:25:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:25:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:25:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:25:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:25:48 --> Final output sent to browser
DEBUG - 2016-09-21 08:25:48 --> Total execution time: 0.0756
INFO - 2016-09-21 08:26:05 --> Config Class Initialized
INFO - 2016-09-21 08:26:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:26:05 --> Utf8 Class Initialized
INFO - 2016-09-21 08:26:05 --> URI Class Initialized
INFO - 2016-09-21 08:26:05 --> Router Class Initialized
INFO - 2016-09-21 08:26:05 --> Output Class Initialized
INFO - 2016-09-21 08:26:05 --> Security Class Initialized
DEBUG - 2016-09-21 08:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:26:05 --> Input Class Initialized
INFO - 2016-09-21 08:26:05 --> Language Class Initialized
INFO - 2016-09-21 08:26:05 --> Loader Class Initialized
INFO - 2016-09-21 08:26:05 --> Helper loaded: url_helper
INFO - 2016-09-21 08:26:05 --> Helper loaded: language_helper
INFO - 2016-09-21 08:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:26:05 --> Controller Class Initialized
INFO - 2016-09-21 08:26:05 --> Database Driver Class Initialized
INFO - 2016-09-21 08:26:05 --> Model Class Initialized
INFO - 2016-09-21 08:26:05 --> Model Class Initialized
INFO - 2016-09-21 08:26:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:26:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:26:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:26:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:26:05 --> Final output sent to browser
DEBUG - 2016-09-21 08:26:05 --> Total execution time: 0.0604
INFO - 2016-09-21 08:27:21 --> Config Class Initialized
INFO - 2016-09-21 08:27:21 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:27:21 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:27:21 --> Utf8 Class Initialized
INFO - 2016-09-21 08:27:21 --> URI Class Initialized
INFO - 2016-09-21 08:27:21 --> Router Class Initialized
INFO - 2016-09-21 08:27:21 --> Output Class Initialized
INFO - 2016-09-21 08:27:21 --> Security Class Initialized
DEBUG - 2016-09-21 08:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:27:21 --> Input Class Initialized
INFO - 2016-09-21 08:27:21 --> Language Class Initialized
INFO - 2016-09-21 08:27:21 --> Loader Class Initialized
INFO - 2016-09-21 08:27:21 --> Helper loaded: url_helper
INFO - 2016-09-21 08:27:21 --> Helper loaded: language_helper
INFO - 2016-09-21 08:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:27:21 --> Controller Class Initialized
INFO - 2016-09-21 08:27:21 --> Database Driver Class Initialized
INFO - 2016-09-21 08:27:21 --> Model Class Initialized
INFO - 2016-09-21 08:27:21 --> Model Class Initialized
INFO - 2016-09-21 08:27:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:27:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:27:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:27:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:27:21 --> Final output sent to browser
DEBUG - 2016-09-21 08:27:21 --> Total execution time: 0.0681
INFO - 2016-09-21 08:28:25 --> Config Class Initialized
INFO - 2016-09-21 08:28:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:28:25 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:28:25 --> Utf8 Class Initialized
INFO - 2016-09-21 08:28:25 --> URI Class Initialized
INFO - 2016-09-21 08:28:25 --> Router Class Initialized
INFO - 2016-09-21 08:28:25 --> Output Class Initialized
INFO - 2016-09-21 08:28:25 --> Security Class Initialized
DEBUG - 2016-09-21 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:28:25 --> Input Class Initialized
INFO - 2016-09-21 08:28:25 --> Language Class Initialized
INFO - 2016-09-21 08:28:25 --> Loader Class Initialized
INFO - 2016-09-21 08:28:25 --> Helper loaded: url_helper
INFO - 2016-09-21 08:28:25 --> Helper loaded: language_helper
INFO - 2016-09-21 08:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:28:25 --> Controller Class Initialized
INFO - 2016-09-21 08:28:25 --> Database Driver Class Initialized
INFO - 2016-09-21 08:28:25 --> Model Class Initialized
INFO - 2016-09-21 08:28:25 --> Model Class Initialized
INFO - 2016-09-21 08:28:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:28:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:28:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-21 08:28:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:28:25 --> Final output sent to browser
DEBUG - 2016-09-21 08:28:25 --> Total execution time: 0.0606
INFO - 2016-09-21 08:28:27 --> Config Class Initialized
INFO - 2016-09-21 08:28:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:28:27 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:28:27 --> Utf8 Class Initialized
INFO - 2016-09-21 08:28:27 --> URI Class Initialized
INFO - 2016-09-21 08:28:27 --> Router Class Initialized
INFO - 2016-09-21 08:28:27 --> Output Class Initialized
INFO - 2016-09-21 08:28:27 --> Security Class Initialized
DEBUG - 2016-09-21 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:28:27 --> Input Class Initialized
INFO - 2016-09-21 08:28:27 --> Language Class Initialized
INFO - 2016-09-21 08:28:27 --> Loader Class Initialized
INFO - 2016-09-21 08:28:27 --> Helper loaded: url_helper
INFO - 2016-09-21 08:28:27 --> Helper loaded: language_helper
INFO - 2016-09-21 08:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:28:27 --> Controller Class Initialized
INFO - 2016-09-21 08:28:27 --> Database Driver Class Initialized
INFO - 2016-09-21 08:28:27 --> Model Class Initialized
INFO - 2016-09-21 08:28:27 --> Model Class Initialized
INFO - 2016-09-21 08:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:28:27 --> Config Class Initialized
INFO - 2016-09-21 08:28:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:28:27 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:28:27 --> Utf8 Class Initialized
INFO - 2016-09-21 08:28:27 --> URI Class Initialized
INFO - 2016-09-21 08:28:27 --> Router Class Initialized
INFO - 2016-09-21 08:28:27 --> Output Class Initialized
INFO - 2016-09-21 08:28:27 --> Security Class Initialized
DEBUG - 2016-09-21 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:28:27 --> Input Class Initialized
INFO - 2016-09-21 08:28:27 --> Language Class Initialized
INFO - 2016-09-21 08:28:27 --> Loader Class Initialized
INFO - 2016-09-21 08:28:27 --> Helper loaded: url_helper
INFO - 2016-09-21 08:28:27 --> Helper loaded: language_helper
INFO - 2016-09-21 08:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:28:27 --> Controller Class Initialized
INFO - 2016-09-21 08:28:27 --> Database Driver Class Initialized
INFO - 2016-09-21 08:28:27 --> Model Class Initialized
INFO - 2016-09-21 08:28:27 --> Model Class Initialized
INFO - 2016-09-21 08:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:28:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:28:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:28:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:28:27 --> Final output sent to browser
DEBUG - 2016-09-21 08:28:27 --> Total execution time: 0.0567
INFO - 2016-09-21 08:28:45 --> Config Class Initialized
INFO - 2016-09-21 08:28:45 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:28:45 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:28:45 --> Utf8 Class Initialized
INFO - 2016-09-21 08:28:45 --> URI Class Initialized
INFO - 2016-09-21 08:28:45 --> Router Class Initialized
INFO - 2016-09-21 08:28:45 --> Output Class Initialized
INFO - 2016-09-21 08:28:45 --> Security Class Initialized
DEBUG - 2016-09-21 08:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:28:45 --> Input Class Initialized
INFO - 2016-09-21 08:28:45 --> Language Class Initialized
INFO - 2016-09-21 08:28:45 --> Loader Class Initialized
INFO - 2016-09-21 08:28:45 --> Helper loaded: url_helper
INFO - 2016-09-21 08:28:45 --> Helper loaded: language_helper
INFO - 2016-09-21 08:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:28:45 --> Controller Class Initialized
INFO - 2016-09-21 08:28:45 --> Database Driver Class Initialized
INFO - 2016-09-21 08:28:45 --> Model Class Initialized
INFO - 2016-09-21 08:28:45 --> Model Class Initialized
INFO - 2016-09-21 08:28:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:28:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:28:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:28:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:28:45 --> Final output sent to browser
DEBUG - 2016-09-21 08:28:45 --> Total execution time: 0.0587
INFO - 2016-09-21 08:29:28 --> Config Class Initialized
INFO - 2016-09-21 08:29:28 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:29:28 --> Utf8 Class Initialized
INFO - 2016-09-21 08:29:28 --> URI Class Initialized
INFO - 2016-09-21 08:29:28 --> Router Class Initialized
INFO - 2016-09-21 08:29:28 --> Output Class Initialized
INFO - 2016-09-21 08:29:28 --> Security Class Initialized
DEBUG - 2016-09-21 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:29:28 --> Input Class Initialized
INFO - 2016-09-21 08:29:28 --> Language Class Initialized
INFO - 2016-09-21 08:29:28 --> Loader Class Initialized
INFO - 2016-09-21 08:29:28 --> Helper loaded: url_helper
INFO - 2016-09-21 08:29:28 --> Helper loaded: language_helper
INFO - 2016-09-21 08:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:29:28 --> Controller Class Initialized
INFO - 2016-09-21 08:29:28 --> Database Driver Class Initialized
INFO - 2016-09-21 08:29:28 --> Model Class Initialized
INFO - 2016-09-21 08:29:28 --> Model Class Initialized
INFO - 2016-09-21 08:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:29:28 --> Final output sent to browser
DEBUG - 2016-09-21 08:29:28 --> Total execution time: 0.0694
INFO - 2016-09-21 08:29:46 --> Config Class Initialized
INFO - 2016-09-21 08:29:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:29:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:29:46 --> Utf8 Class Initialized
INFO - 2016-09-21 08:29:46 --> URI Class Initialized
INFO - 2016-09-21 08:29:46 --> Router Class Initialized
INFO - 2016-09-21 08:29:46 --> Output Class Initialized
INFO - 2016-09-21 08:29:46 --> Security Class Initialized
DEBUG - 2016-09-21 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:29:46 --> Input Class Initialized
INFO - 2016-09-21 08:29:46 --> Language Class Initialized
ERROR - 2016-09-21 08:29:46 --> 404 Page Not Found: Quiz/validate_quiz
INFO - 2016-09-21 08:29:49 --> Config Class Initialized
INFO - 2016-09-21 08:29:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:29:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:29:49 --> Utf8 Class Initialized
INFO - 2016-09-21 08:29:49 --> URI Class Initialized
INFO - 2016-09-21 08:29:49 --> Router Class Initialized
INFO - 2016-09-21 08:29:49 --> Output Class Initialized
INFO - 2016-09-21 08:29:49 --> Security Class Initialized
DEBUG - 2016-09-21 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:29:49 --> Input Class Initialized
INFO - 2016-09-21 08:29:49 --> Language Class Initialized
INFO - 2016-09-21 08:29:49 --> Loader Class Initialized
INFO - 2016-09-21 08:29:49 --> Helper loaded: url_helper
INFO - 2016-09-21 08:29:49 --> Helper loaded: language_helper
INFO - 2016-09-21 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:29:49 --> Controller Class Initialized
INFO - 2016-09-21 08:29:49 --> Database Driver Class Initialized
INFO - 2016-09-21 08:29:49 --> Model Class Initialized
INFO - 2016-09-21 08:29:49 --> Model Class Initialized
INFO - 2016-09-21 08:29:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:29:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:29:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:29:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:29:49 --> Final output sent to browser
DEBUG - 2016-09-21 08:29:49 --> Total execution time: 0.0608
INFO - 2016-09-21 08:31:15 --> Config Class Initialized
INFO - 2016-09-21 08:31:15 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:31:15 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:31:15 --> Utf8 Class Initialized
INFO - 2016-09-21 08:31:15 --> URI Class Initialized
INFO - 2016-09-21 08:31:15 --> Router Class Initialized
INFO - 2016-09-21 08:31:15 --> Output Class Initialized
INFO - 2016-09-21 08:31:15 --> Security Class Initialized
DEBUG - 2016-09-21 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:31:15 --> Input Class Initialized
INFO - 2016-09-21 08:31:15 --> Language Class Initialized
INFO - 2016-09-21 08:31:15 --> Loader Class Initialized
INFO - 2016-09-21 08:31:15 --> Helper loaded: url_helper
INFO - 2016-09-21 08:31:15 --> Helper loaded: language_helper
INFO - 2016-09-21 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:31:15 --> Controller Class Initialized
INFO - 2016-09-21 08:31:15 --> Database Driver Class Initialized
INFO - 2016-09-21 08:31:15 --> Model Class Initialized
INFO - 2016-09-21 08:31:15 --> Model Class Initialized
INFO - 2016-09-21 08:31:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:31:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:31:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:31:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:31:15 --> Final output sent to browser
DEBUG - 2016-09-21 08:31:15 --> Total execution time: 0.0615
INFO - 2016-09-21 08:31:17 --> Config Class Initialized
INFO - 2016-09-21 08:31:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:31:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:31:17 --> Utf8 Class Initialized
INFO - 2016-09-21 08:31:17 --> URI Class Initialized
INFO - 2016-09-21 08:31:17 --> Router Class Initialized
INFO - 2016-09-21 08:31:17 --> Output Class Initialized
INFO - 2016-09-21 08:31:17 --> Security Class Initialized
DEBUG - 2016-09-21 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:31:17 --> Input Class Initialized
INFO - 2016-09-21 08:31:17 --> Language Class Initialized
ERROR - 2016-09-21 08:31:17 --> 404 Page Not Found: Quiz/validate_quiz
INFO - 2016-09-21 08:32:14 --> Config Class Initialized
INFO - 2016-09-21 08:32:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:32:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:32:14 --> Utf8 Class Initialized
INFO - 2016-09-21 08:32:14 --> URI Class Initialized
INFO - 2016-09-21 08:32:14 --> Router Class Initialized
INFO - 2016-09-21 08:32:14 --> Output Class Initialized
INFO - 2016-09-21 08:32:14 --> Security Class Initialized
DEBUG - 2016-09-21 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:32:14 --> Input Class Initialized
INFO - 2016-09-21 08:32:14 --> Language Class Initialized
INFO - 2016-09-21 08:32:14 --> Loader Class Initialized
INFO - 2016-09-21 08:32:14 --> Helper loaded: url_helper
INFO - 2016-09-21 08:32:14 --> Helper loaded: language_helper
INFO - 2016-09-21 08:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:32:14 --> Controller Class Initialized
INFO - 2016-09-21 08:32:14 --> Database Driver Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:32:14 --> Config Class Initialized
INFO - 2016-09-21 08:32:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:32:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:32:14 --> Utf8 Class Initialized
INFO - 2016-09-21 08:32:14 --> URI Class Initialized
INFO - 2016-09-21 08:32:14 --> Router Class Initialized
INFO - 2016-09-21 08:32:14 --> Output Class Initialized
INFO - 2016-09-21 08:32:14 --> Security Class Initialized
DEBUG - 2016-09-21 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:32:14 --> Input Class Initialized
INFO - 2016-09-21 08:32:14 --> Language Class Initialized
INFO - 2016-09-21 08:32:14 --> Loader Class Initialized
INFO - 2016-09-21 08:32:14 --> Helper loaded: url_helper
INFO - 2016-09-21 08:32:14 --> Helper loaded: language_helper
INFO - 2016-09-21 08:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:32:14 --> Controller Class Initialized
INFO - 2016-09-21 08:32:14 --> Database Driver Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:32:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:32:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-21 08:32:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:32:14 --> Final output sent to browser
DEBUG - 2016-09-21 08:32:14 --> Total execution time: 0.0769
INFO - 2016-09-21 08:32:14 --> Config Class Initialized
INFO - 2016-09-21 08:32:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:32:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:32:14 --> Config Class Initialized
INFO - 2016-09-21 08:32:14 --> Utf8 Class Initialized
INFO - 2016-09-21 08:32:14 --> Hooks Class Initialized
INFO - 2016-09-21 08:32:14 --> URI Class Initialized
INFO - 2016-09-21 08:32:14 --> Router Class Initialized
DEBUG - 2016-09-21 08:32:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:32:14 --> Utf8 Class Initialized
INFO - 2016-09-21 08:32:14 --> URI Class Initialized
INFO - 2016-09-21 08:32:14 --> Output Class Initialized
INFO - 2016-09-21 08:32:14 --> Security Class Initialized
INFO - 2016-09-21 08:32:14 --> Router Class Initialized
DEBUG - 2016-09-21 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:32:14 --> Input Class Initialized
INFO - 2016-09-21 08:32:14 --> Language Class Initialized
INFO - 2016-09-21 08:32:14 --> Output Class Initialized
INFO - 2016-09-21 08:32:14 --> Security Class Initialized
INFO - 2016-09-21 08:32:14 --> Loader Class Initialized
DEBUG - 2016-09-21 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:32:14 --> Input Class Initialized
INFO - 2016-09-21 08:32:14 --> Helper loaded: url_helper
INFO - 2016-09-21 08:32:14 --> Language Class Initialized
INFO - 2016-09-21 08:32:14 --> Helper loaded: language_helper
INFO - 2016-09-21 08:32:14 --> Loader Class Initialized
INFO - 2016-09-21 08:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:32:14 --> Controller Class Initialized
INFO - 2016-09-21 08:32:14 --> Helper loaded: url_helper
INFO - 2016-09-21 08:32:14 --> Helper loaded: language_helper
INFO - 2016-09-21 08:32:14 --> Database Driver Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:32:14 --> Final output sent to browser
DEBUG - 2016-09-21 08:32:14 --> Total execution time: 0.0758
INFO - 2016-09-21 08:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:32:14 --> Controller Class Initialized
INFO - 2016-09-21 08:32:14 --> Database Driver Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Model Class Initialized
INFO - 2016-09-21 08:32:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-21 08:32:14 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-21 08:32:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-21 08:32:14 --> Final output sent to browser
DEBUG - 2016-09-21 08:32:14 --> Total execution time: 0.1099
INFO - 2016-09-21 08:32:44 --> Config Class Initialized
INFO - 2016-09-21 08:32:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:32:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:32:44 --> Utf8 Class Initialized
INFO - 2016-09-21 08:32:44 --> URI Class Initialized
INFO - 2016-09-21 08:32:44 --> Router Class Initialized
INFO - 2016-09-21 08:32:44 --> Output Class Initialized
INFO - 2016-09-21 08:32:44 --> Security Class Initialized
DEBUG - 2016-09-21 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:32:44 --> Input Class Initialized
INFO - 2016-09-21 08:32:44 --> Language Class Initialized
INFO - 2016-09-21 08:32:44 --> Loader Class Initialized
INFO - 2016-09-21 08:32:44 --> Helper loaded: url_helper
INFO - 2016-09-21 08:32:44 --> Helper loaded: language_helper
INFO - 2016-09-21 08:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:32:44 --> Controller Class Initialized
INFO - 2016-09-21 08:32:44 --> Database Driver Class Initialized
INFO - 2016-09-21 08:32:44 --> Model Class Initialized
INFO - 2016-09-21 08:32:44 --> Model Class Initialized
INFO - 2016-09-21 08:32:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:32:44 --> Final output sent to browser
DEBUG - 2016-09-21 08:32:44 --> Total execution time: 0.0555
INFO - 2016-09-21 08:33:14 --> Config Class Initialized
INFO - 2016-09-21 08:33:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:33:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:33:14 --> Utf8 Class Initialized
INFO - 2016-09-21 08:33:14 --> URI Class Initialized
INFO - 2016-09-21 08:33:14 --> Router Class Initialized
INFO - 2016-09-21 08:33:14 --> Output Class Initialized
INFO - 2016-09-21 08:33:14 --> Security Class Initialized
DEBUG - 2016-09-21 08:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:33:14 --> Input Class Initialized
INFO - 2016-09-21 08:33:14 --> Language Class Initialized
INFO - 2016-09-21 08:33:14 --> Loader Class Initialized
INFO - 2016-09-21 08:33:14 --> Helper loaded: url_helper
INFO - 2016-09-21 08:33:14 --> Helper loaded: language_helper
INFO - 2016-09-21 08:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:33:14 --> Controller Class Initialized
INFO - 2016-09-21 08:33:14 --> Database Driver Class Initialized
INFO - 2016-09-21 08:33:14 --> Model Class Initialized
INFO - 2016-09-21 08:33:14 --> Model Class Initialized
INFO - 2016-09-21 08:33:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:33:14 --> Final output sent to browser
DEBUG - 2016-09-21 08:33:14 --> Total execution time: 0.0597
INFO - 2016-09-21 08:33:44 --> Config Class Initialized
INFO - 2016-09-21 08:33:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:33:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:33:44 --> Utf8 Class Initialized
INFO - 2016-09-21 08:33:44 --> URI Class Initialized
INFO - 2016-09-21 08:33:44 --> Router Class Initialized
INFO - 2016-09-21 08:33:44 --> Output Class Initialized
INFO - 2016-09-21 08:33:44 --> Security Class Initialized
DEBUG - 2016-09-21 08:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:33:44 --> Input Class Initialized
INFO - 2016-09-21 08:33:44 --> Language Class Initialized
INFO - 2016-09-21 08:33:44 --> Loader Class Initialized
INFO - 2016-09-21 08:33:44 --> Helper loaded: url_helper
INFO - 2016-09-21 08:33:44 --> Helper loaded: language_helper
INFO - 2016-09-21 08:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:33:44 --> Controller Class Initialized
INFO - 2016-09-21 08:33:44 --> Database Driver Class Initialized
INFO - 2016-09-21 08:33:44 --> Model Class Initialized
INFO - 2016-09-21 08:33:44 --> Model Class Initialized
INFO - 2016-09-21 08:33:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:33:44 --> Final output sent to browser
DEBUG - 2016-09-21 08:33:44 --> Total execution time: 0.0576
INFO - 2016-09-21 08:34:10 --> Config Class Initialized
INFO - 2016-09-21 08:34:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:34:10 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:34:10 --> Utf8 Class Initialized
INFO - 2016-09-21 08:34:10 --> URI Class Initialized
INFO - 2016-09-21 08:34:10 --> Router Class Initialized
INFO - 2016-09-21 08:34:10 --> Output Class Initialized
INFO - 2016-09-21 08:34:10 --> Security Class Initialized
DEBUG - 2016-09-21 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:34:10 --> Input Class Initialized
INFO - 2016-09-21 08:34:10 --> Language Class Initialized
INFO - 2016-09-21 08:34:10 --> Loader Class Initialized
INFO - 2016-09-21 08:34:10 --> Helper loaded: url_helper
INFO - 2016-09-21 08:34:10 --> Helper loaded: language_helper
INFO - 2016-09-21 08:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:34:10 --> Controller Class Initialized
INFO - 2016-09-21 08:34:10 --> Database Driver Class Initialized
INFO - 2016-09-21 08:34:10 --> Model Class Initialized
INFO - 2016-09-21 08:34:10 --> Model Class Initialized
INFO - 2016-09-21 08:34:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:34:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:34:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:34:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:34:10 --> Final output sent to browser
DEBUG - 2016-09-21 08:34:10 --> Total execution time: 0.0608
INFO - 2016-09-21 08:34:21 --> Config Class Initialized
INFO - 2016-09-21 08:34:21 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:34:21 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:34:21 --> Utf8 Class Initialized
INFO - 2016-09-21 08:34:21 --> URI Class Initialized
INFO - 2016-09-21 08:34:21 --> Router Class Initialized
INFO - 2016-09-21 08:34:21 --> Output Class Initialized
INFO - 2016-09-21 08:34:21 --> Security Class Initialized
DEBUG - 2016-09-21 08:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:34:21 --> Input Class Initialized
INFO - 2016-09-21 08:34:21 --> Language Class Initialized
INFO - 2016-09-21 08:34:21 --> Loader Class Initialized
INFO - 2016-09-21 08:34:21 --> Helper loaded: url_helper
INFO - 2016-09-21 08:34:21 --> Helper loaded: language_helper
INFO - 2016-09-21 08:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:34:21 --> Controller Class Initialized
INFO - 2016-09-21 08:34:21 --> Database Driver Class Initialized
INFO - 2016-09-21 08:34:21 --> Model Class Initialized
INFO - 2016-09-21 08:34:21 --> Model Class Initialized
INFO - 2016-09-21 08:34:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:34:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:34:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:34:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:34:21 --> Final output sent to browser
DEBUG - 2016-09-21 08:34:21 --> Total execution time: 0.0577
INFO - 2016-09-21 08:34:33 --> Config Class Initialized
INFO - 2016-09-21 08:34:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:34:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:34:33 --> Utf8 Class Initialized
INFO - 2016-09-21 08:34:33 --> URI Class Initialized
INFO - 2016-09-21 08:34:33 --> Router Class Initialized
INFO - 2016-09-21 08:34:33 --> Output Class Initialized
INFO - 2016-09-21 08:34:33 --> Security Class Initialized
DEBUG - 2016-09-21 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:34:33 --> Input Class Initialized
INFO - 2016-09-21 08:34:33 --> Language Class Initialized
INFO - 2016-09-21 08:34:33 --> Loader Class Initialized
INFO - 2016-09-21 08:34:33 --> Helper loaded: url_helper
INFO - 2016-09-21 08:34:33 --> Helper loaded: language_helper
INFO - 2016-09-21 08:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:34:33 --> Controller Class Initialized
INFO - 2016-09-21 08:34:33 --> Database Driver Class Initialized
INFO - 2016-09-21 08:34:33 --> Model Class Initialized
INFO - 2016-09-21 08:34:33 --> Model Class Initialized
INFO - 2016-09-21 08:34:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:34:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:34:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:34:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:34:33 --> Final output sent to browser
DEBUG - 2016-09-21 08:34:33 --> Total execution time: 0.0586
INFO - 2016-09-21 08:34:38 --> Config Class Initialized
INFO - 2016-09-21 08:34:38 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:34:38 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:34:38 --> Utf8 Class Initialized
INFO - 2016-09-21 08:34:38 --> URI Class Initialized
INFO - 2016-09-21 08:34:38 --> Router Class Initialized
INFO - 2016-09-21 08:34:38 --> Output Class Initialized
INFO - 2016-09-21 08:34:38 --> Security Class Initialized
DEBUG - 2016-09-21 08:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:34:38 --> Input Class Initialized
INFO - 2016-09-21 08:34:38 --> Language Class Initialized
INFO - 2016-09-21 08:34:38 --> Loader Class Initialized
INFO - 2016-09-21 08:34:38 --> Helper loaded: url_helper
INFO - 2016-09-21 08:34:38 --> Helper loaded: language_helper
INFO - 2016-09-21 08:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:34:38 --> Controller Class Initialized
INFO - 2016-09-21 08:34:38 --> Database Driver Class Initialized
INFO - 2016-09-21 08:34:38 --> Model Class Initialized
INFO - 2016-09-21 08:34:38 --> Model Class Initialized
INFO - 2016-09-21 08:34:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:34:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:34:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:34:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:34:38 --> Final output sent to browser
DEBUG - 2016-09-21 08:34:38 --> Total execution time: 0.0671
INFO - 2016-09-21 08:34:45 --> Config Class Initialized
INFO - 2016-09-21 08:34:45 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:34:45 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:34:45 --> Utf8 Class Initialized
INFO - 2016-09-21 08:34:45 --> URI Class Initialized
INFO - 2016-09-21 08:34:45 --> Router Class Initialized
INFO - 2016-09-21 08:34:45 --> Output Class Initialized
INFO - 2016-09-21 08:34:45 --> Security Class Initialized
DEBUG - 2016-09-21 08:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:34:45 --> Input Class Initialized
INFO - 2016-09-21 08:34:45 --> Language Class Initialized
INFO - 2016-09-21 08:34:45 --> Loader Class Initialized
INFO - 2016-09-21 08:34:45 --> Helper loaded: url_helper
INFO - 2016-09-21 08:34:45 --> Helper loaded: language_helper
INFO - 2016-09-21 08:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:34:45 --> Controller Class Initialized
INFO - 2016-09-21 08:34:45 --> Database Driver Class Initialized
INFO - 2016-09-21 08:34:45 --> Model Class Initialized
INFO - 2016-09-21 08:34:45 --> Model Class Initialized
INFO - 2016-09-21 08:34:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:34:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:34:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:34:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:34:45 --> Final output sent to browser
DEBUG - 2016-09-21 08:34:45 --> Total execution time: 0.0564
INFO - 2016-09-21 08:35:09 --> Config Class Initialized
INFO - 2016-09-21 08:35:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:35:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:35:09 --> Utf8 Class Initialized
INFO - 2016-09-21 08:35:09 --> URI Class Initialized
INFO - 2016-09-21 08:35:09 --> Router Class Initialized
INFO - 2016-09-21 08:35:09 --> Output Class Initialized
INFO - 2016-09-21 08:35:09 --> Security Class Initialized
DEBUG - 2016-09-21 08:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:35:09 --> Input Class Initialized
INFO - 2016-09-21 08:35:09 --> Language Class Initialized
INFO - 2016-09-21 08:35:09 --> Loader Class Initialized
INFO - 2016-09-21 08:35:09 --> Helper loaded: url_helper
INFO - 2016-09-21 08:35:09 --> Helper loaded: language_helper
INFO - 2016-09-21 08:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:35:09 --> Controller Class Initialized
INFO - 2016-09-21 08:35:09 --> Database Driver Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:35:09 --> Config Class Initialized
INFO - 2016-09-21 08:35:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:35:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:35:09 --> Utf8 Class Initialized
INFO - 2016-09-21 08:35:09 --> URI Class Initialized
INFO - 2016-09-21 08:35:09 --> Router Class Initialized
INFO - 2016-09-21 08:35:09 --> Output Class Initialized
INFO - 2016-09-21 08:35:09 --> Security Class Initialized
DEBUG - 2016-09-21 08:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:35:09 --> Input Class Initialized
INFO - 2016-09-21 08:35:09 --> Language Class Initialized
INFO - 2016-09-21 08:35:09 --> Loader Class Initialized
INFO - 2016-09-21 08:35:09 --> Helper loaded: url_helper
INFO - 2016-09-21 08:35:09 --> Helper loaded: language_helper
INFO - 2016-09-21 08:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:35:09 --> Controller Class Initialized
INFO - 2016-09-21 08:35:09 --> Database Driver Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:35:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:35:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-21 08:35:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:35:09 --> Final output sent to browser
DEBUG - 2016-09-21 08:35:09 --> Total execution time: 0.0662
INFO - 2016-09-21 08:35:09 --> Config Class Initialized
INFO - 2016-09-21 08:35:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:35:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:35:09 --> Config Class Initialized
INFO - 2016-09-21 08:35:09 --> Utf8 Class Initialized
INFO - 2016-09-21 08:35:09 --> Hooks Class Initialized
INFO - 2016-09-21 08:35:09 --> URI Class Initialized
DEBUG - 2016-09-21 08:35:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:35:09 --> Router Class Initialized
INFO - 2016-09-21 08:35:09 --> Utf8 Class Initialized
INFO - 2016-09-21 08:35:09 --> URI Class Initialized
INFO - 2016-09-21 08:35:09 --> Output Class Initialized
INFO - 2016-09-21 08:35:09 --> Router Class Initialized
INFO - 2016-09-21 08:35:09 --> Security Class Initialized
DEBUG - 2016-09-21 08:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:35:09 --> Input Class Initialized
INFO - 2016-09-21 08:35:09 --> Output Class Initialized
INFO - 2016-09-21 08:35:09 --> Language Class Initialized
INFO - 2016-09-21 08:35:09 --> Security Class Initialized
DEBUG - 2016-09-21 08:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:35:09 --> Input Class Initialized
INFO - 2016-09-21 08:35:09 --> Loader Class Initialized
INFO - 2016-09-21 08:35:09 --> Language Class Initialized
INFO - 2016-09-21 08:35:09 --> Helper loaded: url_helper
INFO - 2016-09-21 08:35:09 --> Loader Class Initialized
INFO - 2016-09-21 08:35:09 --> Helper loaded: language_helper
INFO - 2016-09-21 08:35:09 --> Helper loaded: url_helper
INFO - 2016-09-21 08:35:09 --> Helper loaded: language_helper
INFO - 2016-09-21 08:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:35:09 --> Controller Class Initialized
INFO - 2016-09-21 08:35:09 --> Database Driver Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:35:09 --> Final output sent to browser
DEBUG - 2016-09-21 08:35:09 --> Total execution time: 0.0786
INFO - 2016-09-21 08:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:35:09 --> Controller Class Initialized
INFO - 2016-09-21 08:35:09 --> Database Driver Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Model Class Initialized
INFO - 2016-09-21 08:35:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-21 08:35:09 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-21 08:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-21 08:35:09 --> Final output sent to browser
DEBUG - 2016-09-21 08:35:09 --> Total execution time: 0.1082
INFO - 2016-09-21 08:35:13 --> Config Class Initialized
INFO - 2016-09-21 08:35:13 --> Hooks Class Initialized
DEBUG - 2016-09-21 08:35:13 --> UTF-8 Support Enabled
INFO - 2016-09-21 08:35:13 --> Utf8 Class Initialized
INFO - 2016-09-21 08:35:13 --> URI Class Initialized
INFO - 2016-09-21 08:35:13 --> Router Class Initialized
INFO - 2016-09-21 08:35:13 --> Output Class Initialized
INFO - 2016-09-21 08:35:13 --> Security Class Initialized
DEBUG - 2016-09-21 08:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 08:35:13 --> Input Class Initialized
INFO - 2016-09-21 08:35:13 --> Language Class Initialized
INFO - 2016-09-21 08:35:13 --> Loader Class Initialized
INFO - 2016-09-21 08:35:13 --> Helper loaded: url_helper
INFO - 2016-09-21 08:35:13 --> Helper loaded: language_helper
INFO - 2016-09-21 08:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-21 08:35:13 --> Controller Class Initialized
INFO - 2016-09-21 08:35:13 --> Database Driver Class Initialized
INFO - 2016-09-21 08:35:13 --> Model Class Initialized
INFO - 2016-09-21 08:35:13 --> Model Class Initialized
INFO - 2016-09-21 08:35:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-21 08:35:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-21 08:35:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-21 08:35:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-21 08:35:13 --> Final output sent to browser
DEBUG - 2016-09-21 08:35:13 --> Total execution time: 0.0635
