<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-22 09:23:45 --> Config Class Initialized
INFO - 2016-09-22 09:23:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:23:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:23:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:23:45 --> URI Class Initialized
INFO - 2016-09-22 09:23:45 --> Router Class Initialized
INFO - 2016-09-22 09:23:45 --> Output Class Initialized
INFO - 2016-09-22 09:23:45 --> Security Class Initialized
DEBUG - 2016-09-22 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:23:45 --> Input Class Initialized
INFO - 2016-09-22 09:23:45 --> Language Class Initialized
INFO - 2016-09-22 09:23:45 --> Loader Class Initialized
INFO - 2016-09-22 09:23:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:23:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:23:45 --> Controller Class Initialized
INFO - 2016-09-22 09:23:45 --> Database Driver Class Initialized
INFO - 2016-09-22 09:23:45 --> Model Class Initialized
INFO - 2016-09-22 09:23:45 --> Model Class Initialized
INFO - 2016-09-22 09:23:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:23:45 --> Config Class Initialized
INFO - 2016-09-22 09:23:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:23:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:23:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:23:45 --> URI Class Initialized
INFO - 2016-09-22 09:23:45 --> Router Class Initialized
INFO - 2016-09-22 09:23:45 --> Output Class Initialized
INFO - 2016-09-22 09:23:45 --> Security Class Initialized
DEBUG - 2016-09-22 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:23:45 --> Input Class Initialized
INFO - 2016-09-22 09:23:45 --> Language Class Initialized
INFO - 2016-09-22 09:23:45 --> Loader Class Initialized
INFO - 2016-09-22 09:23:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:23:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:23:45 --> Controller Class Initialized
INFO - 2016-09-22 09:23:45 --> Database Driver Class Initialized
INFO - 2016-09-22 09:23:45 --> Model Class Initialized
INFO - 2016-09-22 09:23:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-22 09:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-22 09:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-22 09:23:45 --> Final output sent to browser
DEBUG - 2016-09-22 09:23:45 --> Total execution time: 0.0562
INFO - 2016-09-22 09:23:52 --> Config Class Initialized
INFO - 2016-09-22 09:23:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:23:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:23:52 --> Utf8 Class Initialized
INFO - 2016-09-22 09:23:52 --> URI Class Initialized
INFO - 2016-09-22 09:23:52 --> Router Class Initialized
INFO - 2016-09-22 09:23:52 --> Output Class Initialized
INFO - 2016-09-22 09:23:52 --> Security Class Initialized
DEBUG - 2016-09-22 09:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:23:52 --> Input Class Initialized
INFO - 2016-09-22 09:23:52 --> Language Class Initialized
INFO - 2016-09-22 09:23:52 --> Loader Class Initialized
INFO - 2016-09-22 09:23:52 --> Helper loaded: url_helper
INFO - 2016-09-22 09:23:52 --> Helper loaded: language_helper
INFO - 2016-09-22 09:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:23:52 --> Controller Class Initialized
INFO - 2016-09-22 09:23:52 --> Database Driver Class Initialized
INFO - 2016-09-22 09:23:52 --> Model Class Initialized
INFO - 2016-09-22 09:23:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:23:52 --> Config Class Initialized
INFO - 2016-09-22 09:23:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:23:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:23:52 --> Utf8 Class Initialized
INFO - 2016-09-22 09:23:52 --> URI Class Initialized
INFO - 2016-09-22 09:23:52 --> Router Class Initialized
INFO - 2016-09-22 09:23:52 --> Output Class Initialized
INFO - 2016-09-22 09:23:52 --> Security Class Initialized
DEBUG - 2016-09-22 09:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:23:52 --> Input Class Initialized
INFO - 2016-09-22 09:23:52 --> Language Class Initialized
INFO - 2016-09-22 09:23:52 --> Loader Class Initialized
INFO - 2016-09-22 09:23:52 --> Helper loaded: url_helper
INFO - 2016-09-22 09:23:52 --> Helper loaded: language_helper
INFO - 2016-09-22 09:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:23:52 --> Controller Class Initialized
INFO - 2016-09-22 09:23:52 --> Database Driver Class Initialized
INFO - 2016-09-22 09:23:52 --> Model Class Initialized
INFO - 2016-09-22 09:23:52 --> Model Class Initialized
INFO - 2016-09-22 09:23:52 --> Model Class Initialized
INFO - 2016-09-22 09:23:52 --> Model Class Initialized
INFO - 2016-09-22 09:23:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:23:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:23:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-22 09:23:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:23:52 --> Final output sent to browser
DEBUG - 2016-09-22 09:23:52 --> Total execution time: 0.0802
INFO - 2016-09-22 09:23:56 --> Config Class Initialized
INFO - 2016-09-22 09:23:56 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:23:56 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:23:56 --> Utf8 Class Initialized
INFO - 2016-09-22 09:23:56 --> URI Class Initialized
INFO - 2016-09-22 09:23:56 --> Router Class Initialized
INFO - 2016-09-22 09:23:56 --> Output Class Initialized
INFO - 2016-09-22 09:23:56 --> Security Class Initialized
DEBUG - 2016-09-22 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:23:56 --> Input Class Initialized
INFO - 2016-09-22 09:23:56 --> Language Class Initialized
INFO - 2016-09-22 09:23:56 --> Loader Class Initialized
INFO - 2016-09-22 09:23:56 --> Helper loaded: url_helper
INFO - 2016-09-22 09:23:56 --> Helper loaded: language_helper
INFO - 2016-09-22 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:23:56 --> Controller Class Initialized
INFO - 2016-09-22 09:23:56 --> Database Driver Class Initialized
INFO - 2016-09-22 09:23:56 --> Model Class Initialized
INFO - 2016-09-22 09:23:56 --> Model Class Initialized
INFO - 2016-09-22 09:23:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 09:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:23:56 --> Final output sent to browser
DEBUG - 2016-09-22 09:23:56 --> Total execution time: 0.0610
INFO - 2016-09-22 09:24:02 --> Config Class Initialized
INFO - 2016-09-22 09:24:02 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:24:02 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:24:02 --> Utf8 Class Initialized
INFO - 2016-09-22 09:24:02 --> URI Class Initialized
INFO - 2016-09-22 09:24:02 --> Router Class Initialized
INFO - 2016-09-22 09:24:02 --> Output Class Initialized
INFO - 2016-09-22 09:24:02 --> Security Class Initialized
DEBUG - 2016-09-22 09:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:24:02 --> Input Class Initialized
INFO - 2016-09-22 09:24:02 --> Language Class Initialized
INFO - 2016-09-22 09:24:02 --> Loader Class Initialized
INFO - 2016-09-22 09:24:02 --> Helper loaded: url_helper
INFO - 2016-09-22 09:24:02 --> Helper loaded: language_helper
INFO - 2016-09-22 09:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:24:02 --> Controller Class Initialized
INFO - 2016-09-22 09:24:02 --> Database Driver Class Initialized
INFO - 2016-09-22 09:24:02 --> Model Class Initialized
INFO - 2016-09-22 09:24:02 --> Model Class Initialized
INFO - 2016-09-22 09:24:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:24:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:24:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:24:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:24:02 --> Final output sent to browser
DEBUG - 2016-09-22 09:24:02 --> Total execution time: 0.0607
INFO - 2016-09-22 09:24:07 --> Config Class Initialized
INFO - 2016-09-22 09:24:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:24:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:24:07 --> Utf8 Class Initialized
INFO - 2016-09-22 09:24:07 --> URI Class Initialized
INFO - 2016-09-22 09:24:07 --> Router Class Initialized
INFO - 2016-09-22 09:24:07 --> Output Class Initialized
INFO - 2016-09-22 09:24:07 --> Security Class Initialized
DEBUG - 2016-09-22 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:24:07 --> Input Class Initialized
INFO - 2016-09-22 09:24:07 --> Language Class Initialized
INFO - 2016-09-22 09:24:07 --> Loader Class Initialized
INFO - 2016-09-22 09:24:07 --> Helper loaded: url_helper
INFO - 2016-09-22 09:24:07 --> Helper loaded: language_helper
INFO - 2016-09-22 09:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:24:07 --> Controller Class Initialized
INFO - 2016-09-22 09:24:07 --> Database Driver Class Initialized
INFO - 2016-09-22 09:24:07 --> Model Class Initialized
INFO - 2016-09-22 09:24:07 --> Model Class Initialized
INFO - 2016-09-22 09:24:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:24:07 --> Config Class Initialized
INFO - 2016-09-22 09:24:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:24:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:24:07 --> Utf8 Class Initialized
INFO - 2016-09-22 09:24:07 --> URI Class Initialized
INFO - 2016-09-22 09:24:07 --> Router Class Initialized
INFO - 2016-09-22 09:24:07 --> Output Class Initialized
INFO - 2016-09-22 09:24:07 --> Security Class Initialized
DEBUG - 2016-09-22 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:24:07 --> Input Class Initialized
INFO - 2016-09-22 09:24:07 --> Language Class Initialized
INFO - 2016-09-22 09:24:07 --> Loader Class Initialized
INFO - 2016-09-22 09:24:07 --> Helper loaded: url_helper
INFO - 2016-09-22 09:24:07 --> Helper loaded: language_helper
INFO - 2016-09-22 09:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:24:07 --> Controller Class Initialized
INFO - 2016-09-22 09:24:07 --> Database Driver Class Initialized
INFO - 2016-09-22 09:24:07 --> Model Class Initialized
INFO - 2016-09-22 09:24:07 --> Model Class Initialized
INFO - 2016-09-22 09:24:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:24:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:24:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 09:24:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:24:07 --> Final output sent to browser
DEBUG - 2016-09-22 09:24:07 --> Total execution time: 0.0574
INFO - 2016-09-22 09:29:16 --> Config Class Initialized
INFO - 2016-09-22 09:29:16 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:29:16 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:29:16 --> Utf8 Class Initialized
INFO - 2016-09-22 09:29:16 --> URI Class Initialized
INFO - 2016-09-22 09:29:16 --> Config Class Initialized
INFO - 2016-09-22 09:29:16 --> Hooks Class Initialized
INFO - 2016-09-22 09:29:16 --> Router Class Initialized
INFO - 2016-09-22 09:29:16 --> Output Class Initialized
DEBUG - 2016-09-22 09:29:16 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:29:16 --> Utf8 Class Initialized
INFO - 2016-09-22 09:29:16 --> Security Class Initialized
INFO - 2016-09-22 09:29:16 --> URI Class Initialized
DEBUG - 2016-09-22 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:29:16 --> Input Class Initialized
INFO - 2016-09-22 09:29:16 --> Language Class Initialized
INFO - 2016-09-22 09:29:16 --> Router Class Initialized
INFO - 2016-09-22 09:29:16 --> Output Class Initialized
INFO - 2016-09-22 09:29:16 --> Loader Class Initialized
INFO - 2016-09-22 09:29:16 --> Security Class Initialized
INFO - 2016-09-22 09:29:16 --> Helper loaded: url_helper
DEBUG - 2016-09-22 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:29:16 --> Helper loaded: language_helper
INFO - 2016-09-22 09:29:16 --> Input Class Initialized
INFO - 2016-09-22 09:29:16 --> Language Class Initialized
INFO - 2016-09-22 09:29:16 --> Loader Class Initialized
INFO - 2016-09-22 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:29:16 --> Controller Class Initialized
INFO - 2016-09-22 09:29:16 --> Helper loaded: url_helper
INFO - 2016-09-22 09:29:16 --> Helper loaded: language_helper
INFO - 2016-09-22 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:29:16 --> Controller Class Initialized
INFO - 2016-09-22 09:29:16 --> Database Driver Class Initialized
INFO - 2016-09-22 09:29:16 --> Model Class Initialized
INFO - 2016-09-22 09:29:16 --> Model Class Initialized
INFO - 2016-09-22 09:29:16 --> Database Driver Class Initialized
INFO - 2016-09-22 09:29:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:29:16 --> Model Class Initialized
INFO - 2016-09-22 09:29:16 --> Model Class Initialized
INFO - 2016-09-22 09:29:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:29:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:29:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:29:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:29:16 --> Final output sent to browser
DEBUG - 2016-09-22 09:29:16 --> Total execution time: 0.1044
INFO - 2016-09-22 09:29:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:29:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:29:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:29:16 --> Final output sent to browser
DEBUG - 2016-09-22 09:29:16 --> Total execution time: 0.0927
INFO - 2016-09-22 09:29:18 --> Config Class Initialized
INFO - 2016-09-22 09:29:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:29:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:29:18 --> Utf8 Class Initialized
INFO - 2016-09-22 09:29:18 --> URI Class Initialized
INFO - 2016-09-22 09:29:18 --> Router Class Initialized
INFO - 2016-09-22 09:29:18 --> Output Class Initialized
INFO - 2016-09-22 09:29:18 --> Security Class Initialized
DEBUG - 2016-09-22 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:29:18 --> Input Class Initialized
INFO - 2016-09-22 09:29:18 --> Language Class Initialized
INFO - 2016-09-22 09:29:18 --> Loader Class Initialized
INFO - 2016-09-22 09:29:18 --> Helper loaded: url_helper
INFO - 2016-09-22 09:29:18 --> Helper loaded: language_helper
INFO - 2016-09-22 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:29:18 --> Controller Class Initialized
INFO - 2016-09-22 09:29:18 --> Database Driver Class Initialized
INFO - 2016-09-22 09:29:18 --> Model Class Initialized
INFO - 2016-09-22 09:29:18 --> Model Class Initialized
INFO - 2016-09-22 09:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:29:18 --> Final output sent to browser
DEBUG - 2016-09-22 09:29:18 --> Total execution time: 0.0577
INFO - 2016-09-22 09:29:19 --> Config Class Initialized
INFO - 2016-09-22 09:29:19 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:29:19 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:29:19 --> Utf8 Class Initialized
INFO - 2016-09-22 09:29:19 --> URI Class Initialized
INFO - 2016-09-22 09:29:19 --> Router Class Initialized
INFO - 2016-09-22 09:29:19 --> Output Class Initialized
INFO - 2016-09-22 09:29:19 --> Security Class Initialized
DEBUG - 2016-09-22 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:29:19 --> Input Class Initialized
INFO - 2016-09-22 09:29:19 --> Language Class Initialized
INFO - 2016-09-22 09:29:19 --> Loader Class Initialized
INFO - 2016-09-22 09:29:19 --> Helper loaded: url_helper
INFO - 2016-09-22 09:29:19 --> Helper loaded: language_helper
INFO - 2016-09-22 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:29:19 --> Controller Class Initialized
INFO - 2016-09-22 09:29:19 --> Database Driver Class Initialized
INFO - 2016-09-22 09:29:19 --> Model Class Initialized
INFO - 2016-09-22 09:29:19 --> Model Class Initialized
INFO - 2016-09-22 09:29:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:29:19 --> Config Class Initialized
INFO - 2016-09-22 09:29:19 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:29:19 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:29:19 --> Utf8 Class Initialized
INFO - 2016-09-22 09:29:19 --> URI Class Initialized
INFO - 2016-09-22 09:29:19 --> Router Class Initialized
INFO - 2016-09-22 09:29:19 --> Output Class Initialized
INFO - 2016-09-22 09:29:19 --> Security Class Initialized
DEBUG - 2016-09-22 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:29:19 --> Input Class Initialized
INFO - 2016-09-22 09:29:19 --> Language Class Initialized
INFO - 2016-09-22 09:29:19 --> Loader Class Initialized
INFO - 2016-09-22 09:29:19 --> Helper loaded: url_helper
INFO - 2016-09-22 09:29:19 --> Helper loaded: language_helper
INFO - 2016-09-22 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:29:19 --> Controller Class Initialized
INFO - 2016-09-22 09:29:19 --> Database Driver Class Initialized
INFO - 2016-09-22 09:29:19 --> Model Class Initialized
INFO - 2016-09-22 09:29:19 --> Model Class Initialized
INFO - 2016-09-22 09:29:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:29:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:29:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 09:29:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:29:19 --> Final output sent to browser
DEBUG - 2016-09-22 09:29:19 --> Total execution time: 0.0677
INFO - 2016-09-22 09:30:30 --> Config Class Initialized
INFO - 2016-09-22 09:30:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:30:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:30:30 --> Utf8 Class Initialized
INFO - 2016-09-22 09:30:30 --> URI Class Initialized
INFO - 2016-09-22 09:30:30 --> Router Class Initialized
INFO - 2016-09-22 09:30:30 --> Output Class Initialized
INFO - 2016-09-22 09:30:30 --> Security Class Initialized
DEBUG - 2016-09-22 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:30:30 --> Input Class Initialized
INFO - 2016-09-22 09:30:30 --> Language Class Initialized
INFO - 2016-09-22 09:30:30 --> Loader Class Initialized
INFO - 2016-09-22 09:30:30 --> Helper loaded: url_helper
INFO - 2016-09-22 09:30:30 --> Helper loaded: language_helper
INFO - 2016-09-22 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:30:30 --> Controller Class Initialized
INFO - 2016-09-22 09:30:30 --> Database Driver Class Initialized
INFO - 2016-09-22 09:30:30 --> Model Class Initialized
INFO - 2016-09-22 09:30:30 --> Model Class Initialized
INFO - 2016-09-22 09:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:30:30 --> Final output sent to browser
DEBUG - 2016-09-22 09:30:30 --> Total execution time: 0.0607
INFO - 2016-09-22 09:30:54 --> Config Class Initialized
INFO - 2016-09-22 09:30:54 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:30:54 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:30:54 --> Utf8 Class Initialized
INFO - 2016-09-22 09:30:54 --> URI Class Initialized
INFO - 2016-09-22 09:30:54 --> Router Class Initialized
INFO - 2016-09-22 09:30:54 --> Output Class Initialized
INFO - 2016-09-22 09:30:54 --> Security Class Initialized
DEBUG - 2016-09-22 09:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:30:54 --> Input Class Initialized
INFO - 2016-09-22 09:30:54 --> Language Class Initialized
INFO - 2016-09-22 09:30:54 --> Loader Class Initialized
INFO - 2016-09-22 09:30:54 --> Helper loaded: url_helper
INFO - 2016-09-22 09:30:54 --> Helper loaded: language_helper
INFO - 2016-09-22 09:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:30:54 --> Controller Class Initialized
INFO - 2016-09-22 09:30:54 --> Database Driver Class Initialized
INFO - 2016-09-22 09:30:54 --> Model Class Initialized
INFO - 2016-09-22 09:30:54 --> Model Class Initialized
INFO - 2016-09-22 09:30:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:30:54 --> Config Class Initialized
INFO - 2016-09-22 09:30:54 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:30:54 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:30:54 --> Utf8 Class Initialized
INFO - 2016-09-22 09:30:54 --> URI Class Initialized
INFO - 2016-09-22 09:30:54 --> Router Class Initialized
INFO - 2016-09-22 09:30:54 --> Output Class Initialized
INFO - 2016-09-22 09:30:54 --> Security Class Initialized
DEBUG - 2016-09-22 09:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:30:54 --> Input Class Initialized
INFO - 2016-09-22 09:30:54 --> Language Class Initialized
INFO - 2016-09-22 09:30:54 --> Loader Class Initialized
INFO - 2016-09-22 09:30:54 --> Helper loaded: url_helper
INFO - 2016-09-22 09:30:54 --> Helper loaded: language_helper
INFO - 2016-09-22 09:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:30:54 --> Controller Class Initialized
INFO - 2016-09-22 09:30:54 --> Database Driver Class Initialized
INFO - 2016-09-22 09:30:54 --> Model Class Initialized
INFO - 2016-09-22 09:30:54 --> Model Class Initialized
INFO - 2016-09-22 09:30:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:30:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:30:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 09:30:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:30:54 --> Final output sent to browser
DEBUG - 2016-09-22 09:30:54 --> Total execution time: 0.0681
INFO - 2016-09-22 09:31:14 --> Config Class Initialized
INFO - 2016-09-22 09:31:14 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:31:14 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:31:14 --> Utf8 Class Initialized
INFO - 2016-09-22 09:31:14 --> URI Class Initialized
INFO - 2016-09-22 09:31:14 --> Router Class Initialized
INFO - 2016-09-22 09:31:14 --> Output Class Initialized
INFO - 2016-09-22 09:31:14 --> Security Class Initialized
DEBUG - 2016-09-22 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:31:14 --> Input Class Initialized
INFO - 2016-09-22 09:31:14 --> Language Class Initialized
INFO - 2016-09-22 09:31:14 --> Loader Class Initialized
INFO - 2016-09-22 09:31:14 --> Helper loaded: url_helper
INFO - 2016-09-22 09:31:14 --> Helper loaded: language_helper
INFO - 2016-09-22 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:31:14 --> Controller Class Initialized
INFO - 2016-09-22 09:31:14 --> Database Driver Class Initialized
INFO - 2016-09-22 09:31:14 --> Model Class Initialized
INFO - 2016-09-22 09:31:14 --> Model Class Initialized
INFO - 2016-09-22 09:31:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:31:14 --> Config Class Initialized
INFO - 2016-09-22 09:31:14 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:31:14 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:31:14 --> Utf8 Class Initialized
INFO - 2016-09-22 09:31:14 --> URI Class Initialized
INFO - 2016-09-22 09:31:14 --> Router Class Initialized
INFO - 2016-09-22 09:31:14 --> Output Class Initialized
INFO - 2016-09-22 09:31:14 --> Security Class Initialized
DEBUG - 2016-09-22 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:31:14 --> Input Class Initialized
INFO - 2016-09-22 09:31:14 --> Language Class Initialized
INFO - 2016-09-22 09:31:14 --> Loader Class Initialized
INFO - 2016-09-22 09:31:14 --> Helper loaded: url_helper
INFO - 2016-09-22 09:31:14 --> Helper loaded: language_helper
INFO - 2016-09-22 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:31:14 --> Controller Class Initialized
INFO - 2016-09-22 09:31:14 --> Database Driver Class Initialized
INFO - 2016-09-22 09:31:14 --> Model Class Initialized
INFO - 2016-09-22 09:31:14 --> Model Class Initialized
INFO - 2016-09-22 09:31:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:31:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:31:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-22 09:31:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:31:14 --> Final output sent to browser
DEBUG - 2016-09-22 09:31:14 --> Total execution time: 0.0719
INFO - 2016-09-22 09:31:15 --> Config Class Initialized
INFO - 2016-09-22 09:31:15 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:31:15 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:31:15 --> Utf8 Class Initialized
INFO - 2016-09-22 09:31:15 --> Config Class Initialized
INFO - 2016-09-22 09:31:15 --> URI Class Initialized
INFO - 2016-09-22 09:31:15 --> Hooks Class Initialized
INFO - 2016-09-22 09:31:15 --> Router Class Initialized
DEBUG - 2016-09-22 09:31:15 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:31:15 --> Utf8 Class Initialized
INFO - 2016-09-22 09:31:15 --> Output Class Initialized
INFO - 2016-09-22 09:31:15 --> URI Class Initialized
INFO - 2016-09-22 09:31:15 --> Security Class Initialized
INFO - 2016-09-22 09:31:15 --> Router Class Initialized
DEBUG - 2016-09-22 09:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:31:15 --> Input Class Initialized
INFO - 2016-09-22 09:31:15 --> Language Class Initialized
INFO - 2016-09-22 09:31:15 --> Output Class Initialized
INFO - 2016-09-22 09:31:15 --> Security Class Initialized
INFO - 2016-09-22 09:31:15 --> Loader Class Initialized
DEBUG - 2016-09-22 09:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:31:15 --> Input Class Initialized
INFO - 2016-09-22 09:31:15 --> Helper loaded: url_helper
INFO - 2016-09-22 09:31:15 --> Language Class Initialized
INFO - 2016-09-22 09:31:15 --> Helper loaded: language_helper
INFO - 2016-09-22 09:31:15 --> Loader Class Initialized
INFO - 2016-09-22 09:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:31:15 --> Controller Class Initialized
INFO - 2016-09-22 09:31:15 --> Helper loaded: url_helper
INFO - 2016-09-22 09:31:15 --> Helper loaded: language_helper
INFO - 2016-09-22 09:31:15 --> Database Driver Class Initialized
INFO - 2016-09-22 09:31:15 --> Model Class Initialized
INFO - 2016-09-22 09:31:15 --> Model Class Initialized
INFO - 2016-09-22 09:31:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:31:15 --> Final output sent to browser
DEBUG - 2016-09-22 09:31:15 --> Total execution time: 0.0717
INFO - 2016-09-22 09:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:31:15 --> Controller Class Initialized
INFO - 2016-09-22 09:31:15 --> Database Driver Class Initialized
INFO - 2016-09-22 09:31:15 --> Model Class Initialized
INFO - 2016-09-22 09:31:15 --> Model Class Initialized
INFO - 2016-09-22 09:31:15 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 09:31:15 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 09:31:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-22 09:31:15 --> Final output sent to browser
DEBUG - 2016-09-22 09:31:15 --> Total execution time: 0.1042
INFO - 2016-09-22 09:31:22 --> Config Class Initialized
INFO - 2016-09-22 09:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:31:22 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:31:22 --> Utf8 Class Initialized
INFO - 2016-09-22 09:31:22 --> URI Class Initialized
INFO - 2016-09-22 09:31:22 --> Router Class Initialized
INFO - 2016-09-22 09:31:22 --> Output Class Initialized
INFO - 2016-09-22 09:31:22 --> Security Class Initialized
DEBUG - 2016-09-22 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:31:22 --> Input Class Initialized
INFO - 2016-09-22 09:31:22 --> Language Class Initialized
INFO - 2016-09-22 09:31:22 --> Loader Class Initialized
INFO - 2016-09-22 09:31:22 --> Helper loaded: url_helper
INFO - 2016-09-22 09:31:22 --> Helper loaded: language_helper
INFO - 2016-09-22 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:31:22 --> Controller Class Initialized
INFO - 2016-09-22 09:31:22 --> Database Driver Class Initialized
INFO - 2016-09-22 09:31:22 --> Model Class Initialized
INFO - 2016-09-22 09:31:22 --> Model Class Initialized
INFO - 2016-09-22 09:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:31:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:31:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:31:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:31:22 --> Final output sent to browser
DEBUG - 2016-09-22 09:31:22 --> Total execution time: 0.0578
INFO - 2016-09-22 09:41:38 --> Config Class Initialized
INFO - 2016-09-22 09:41:38 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:41:38 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:41:38 --> Utf8 Class Initialized
INFO - 2016-09-22 09:41:38 --> URI Class Initialized
INFO - 2016-09-22 09:41:38 --> Router Class Initialized
INFO - 2016-09-22 09:41:38 --> Output Class Initialized
INFO - 2016-09-22 09:41:38 --> Security Class Initialized
DEBUG - 2016-09-22 09:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:41:38 --> Input Class Initialized
INFO - 2016-09-22 09:41:38 --> Language Class Initialized
INFO - 2016-09-22 09:41:38 --> Loader Class Initialized
INFO - 2016-09-22 09:41:38 --> Helper loaded: url_helper
INFO - 2016-09-22 09:41:38 --> Helper loaded: language_helper
INFO - 2016-09-22 09:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:41:38 --> Controller Class Initialized
INFO - 2016-09-22 09:41:38 --> Database Driver Class Initialized
INFO - 2016-09-22 09:41:38 --> Model Class Initialized
INFO - 2016-09-22 09:41:38 --> Model Class Initialized
INFO - 2016-09-22 09:41:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:41:38 --> Final output sent to browser
DEBUG - 2016-09-22 09:41:38 --> Total execution time: 0.0622
INFO - 2016-09-22 09:41:58 --> Config Class Initialized
INFO - 2016-09-22 09:41:58 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:41:58 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:41:58 --> Utf8 Class Initialized
INFO - 2016-09-22 09:41:58 --> URI Class Initialized
INFO - 2016-09-22 09:41:58 --> Router Class Initialized
INFO - 2016-09-22 09:41:58 --> Output Class Initialized
INFO - 2016-09-22 09:41:58 --> Security Class Initialized
DEBUG - 2016-09-22 09:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:41:58 --> Input Class Initialized
INFO - 2016-09-22 09:41:58 --> Language Class Initialized
INFO - 2016-09-22 09:41:58 --> Loader Class Initialized
INFO - 2016-09-22 09:41:58 --> Helper loaded: url_helper
INFO - 2016-09-22 09:41:58 --> Helper loaded: language_helper
INFO - 2016-09-22 09:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:41:58 --> Controller Class Initialized
INFO - 2016-09-22 09:41:58 --> Database Driver Class Initialized
INFO - 2016-09-22 09:41:58 --> Model Class Initialized
INFO - 2016-09-22 09:41:58 --> Model Class Initialized
INFO - 2016-09-22 09:41:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:41:58 --> Config Class Initialized
INFO - 2016-09-22 09:41:58 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:41:58 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:41:58 --> Utf8 Class Initialized
INFO - 2016-09-22 09:41:58 --> URI Class Initialized
INFO - 2016-09-22 09:41:58 --> Router Class Initialized
INFO - 2016-09-22 09:41:58 --> Output Class Initialized
INFO - 2016-09-22 09:41:58 --> Security Class Initialized
DEBUG - 2016-09-22 09:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:41:58 --> Input Class Initialized
INFO - 2016-09-22 09:41:58 --> Language Class Initialized
INFO - 2016-09-22 09:41:58 --> Loader Class Initialized
INFO - 2016-09-22 09:41:58 --> Helper loaded: url_helper
INFO - 2016-09-22 09:41:58 --> Helper loaded: language_helper
INFO - 2016-09-22 09:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:41:58 --> Controller Class Initialized
INFO - 2016-09-22 09:41:58 --> Database Driver Class Initialized
INFO - 2016-09-22 09:41:58 --> Model Class Initialized
INFO - 2016-09-22 09:41:58 --> Model Class Initialized
INFO - 2016-09-22 09:41:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:41:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:41:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 09:41:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:41:58 --> Final output sent to browser
DEBUG - 2016-09-22 09:41:58 --> Total execution time: 0.0578
INFO - 2016-09-22 09:42:02 --> Config Class Initialized
INFO - 2016-09-22 09:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:42:02 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:42:02 --> Utf8 Class Initialized
INFO - 2016-09-22 09:42:02 --> URI Class Initialized
INFO - 2016-09-22 09:42:02 --> Router Class Initialized
INFO - 2016-09-22 09:42:02 --> Output Class Initialized
INFO - 2016-09-22 09:42:02 --> Security Class Initialized
DEBUG - 2016-09-22 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:42:02 --> Input Class Initialized
INFO - 2016-09-22 09:42:02 --> Language Class Initialized
INFO - 2016-09-22 09:42:02 --> Loader Class Initialized
INFO - 2016-09-22 09:42:02 --> Helper loaded: url_helper
INFO - 2016-09-22 09:42:02 --> Helper loaded: language_helper
INFO - 2016-09-22 09:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:42:02 --> Controller Class Initialized
INFO - 2016-09-22 09:42:02 --> Database Driver Class Initialized
INFO - 2016-09-22 09:42:02 --> Model Class Initialized
INFO - 2016-09-22 09:42:02 --> Model Class Initialized
INFO - 2016-09-22 09:42:02 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 09:42:02 --> Severity: Notice --> Undefined property: Ujian::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 115
ERROR - 2016-09-22 09:42:02 --> Severity: error --> Exception: Call to a member function open_result() on null C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 115
INFO - 2016-09-22 09:43:17 --> Config Class Initialized
INFO - 2016-09-22 09:43:17 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:43:17 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:43:17 --> Utf8 Class Initialized
INFO - 2016-09-22 09:43:17 --> URI Class Initialized
INFO - 2016-09-22 09:43:17 --> Router Class Initialized
INFO - 2016-09-22 09:43:17 --> Output Class Initialized
INFO - 2016-09-22 09:43:17 --> Security Class Initialized
DEBUG - 2016-09-22 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:43:17 --> Input Class Initialized
INFO - 2016-09-22 09:43:17 --> Language Class Initialized
INFO - 2016-09-22 09:43:17 --> Loader Class Initialized
INFO - 2016-09-22 09:43:17 --> Helper loaded: url_helper
INFO - 2016-09-22 09:43:17 --> Helper loaded: language_helper
INFO - 2016-09-22 09:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:43:17 --> Controller Class Initialized
INFO - 2016-09-22 09:43:17 --> Database Driver Class Initialized
INFO - 2016-09-22 09:43:17 --> Model Class Initialized
INFO - 2016-09-22 09:43:17 --> Model Class Initialized
INFO - 2016-09-22 09:43:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:43:17 --> Config Class Initialized
INFO - 2016-09-22 09:43:17 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:43:17 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:43:17 --> Utf8 Class Initialized
INFO - 2016-09-22 09:43:17 --> URI Class Initialized
INFO - 2016-09-22 09:43:17 --> Router Class Initialized
INFO - 2016-09-22 09:43:17 --> Output Class Initialized
INFO - 2016-09-22 09:43:17 --> Security Class Initialized
DEBUG - 2016-09-22 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:43:17 --> Input Class Initialized
INFO - 2016-09-22 09:43:17 --> Language Class Initialized
ERROR - 2016-09-22 09:43:17 --> 404 Page Not Found: Ujian/attempt
INFO - 2016-09-22 09:45:12 --> Config Class Initialized
INFO - 2016-09-22 09:45:12 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:45:12 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:45:12 --> Utf8 Class Initialized
INFO - 2016-09-22 09:45:12 --> URI Class Initialized
INFO - 2016-09-22 09:45:12 --> Router Class Initialized
INFO - 2016-09-22 09:45:12 --> Output Class Initialized
INFO - 2016-09-22 09:45:12 --> Security Class Initialized
DEBUG - 2016-09-22 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:45:12 --> Input Class Initialized
INFO - 2016-09-22 09:45:12 --> Language Class Initialized
INFO - 2016-09-22 09:45:12 --> Loader Class Initialized
INFO - 2016-09-22 09:45:12 --> Helper loaded: url_helper
INFO - 2016-09-22 09:45:12 --> Helper loaded: language_helper
INFO - 2016-09-22 09:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:45:12 --> Controller Class Initialized
INFO - 2016-09-22 09:45:12 --> Database Driver Class Initialized
INFO - 2016-09-22 09:45:12 --> Model Class Initialized
INFO - 2016-09-22 09:45:12 --> Model Class Initialized
INFO - 2016-09-22 09:45:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 09:45:12 --> Severity: Notice --> Undefined property: Ujian::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 276
ERROR - 2016-09-22 09:45:12 --> Severity: error --> Exception: Call to a member function quiz_result() on null C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 276
INFO - 2016-09-22 09:46:40 --> Config Class Initialized
INFO - 2016-09-22 09:46:40 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:46:40 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:46:40 --> Utf8 Class Initialized
INFO - 2016-09-22 09:46:40 --> URI Class Initialized
INFO - 2016-09-22 09:46:40 --> Router Class Initialized
INFO - 2016-09-22 09:46:40 --> Output Class Initialized
INFO - 2016-09-22 09:46:40 --> Security Class Initialized
DEBUG - 2016-09-22 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:46:40 --> Input Class Initialized
INFO - 2016-09-22 09:46:40 --> Language Class Initialized
INFO - 2016-09-22 09:46:40 --> Loader Class Initialized
INFO - 2016-09-22 09:46:40 --> Helper loaded: url_helper
INFO - 2016-09-22 09:46:40 --> Helper loaded: language_helper
INFO - 2016-09-22 09:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:46:40 --> Controller Class Initialized
INFO - 2016-09-22 09:46:40 --> Database Driver Class Initialized
INFO - 2016-09-22 09:46:40 --> Model Class Initialized
INFO - 2016-09-22 09:46:40 --> Model Class Initialized
INFO - 2016-09-22 09:46:40 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 09:46:40 --> Severity: Notice --> Undefined property: Ujian::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 297
ERROR - 2016-09-22 09:46:40 --> Severity: error --> Exception: Call to a member function get_questions() on null C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 297
INFO - 2016-09-22 09:48:45 --> Config Class Initialized
INFO - 2016-09-22 09:48:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:48:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:48:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:48:45 --> URI Class Initialized
INFO - 2016-09-22 09:48:45 --> Router Class Initialized
INFO - 2016-09-22 09:48:45 --> Output Class Initialized
INFO - 2016-09-22 09:48:45 --> Security Class Initialized
DEBUG - 2016-09-22 09:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:48:45 --> Input Class Initialized
INFO - 2016-09-22 09:48:45 --> Language Class Initialized
INFO - 2016-09-22 09:48:45 --> Loader Class Initialized
INFO - 2016-09-22 09:48:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:48:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:48:45 --> Controller Class Initialized
INFO - 2016-09-22 09:48:45 --> Database Driver Class Initialized
INFO - 2016-09-22 09:48:45 --> Model Class Initialized
INFO - 2016-09-22 09:48:45 --> Model Class Initialized
INFO - 2016-09-22 09:48:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:48:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:48:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_attempt.php
INFO - 2016-09-22 09:48:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:48:45 --> Final output sent to browser
DEBUG - 2016-09-22 09:48:45 --> Total execution time: 0.0862
INFO - 2016-09-22 09:48:45 --> Config Class Initialized
INFO - 2016-09-22 09:48:45 --> Hooks Class Initialized
INFO - 2016-09-22 09:48:45 --> Config Class Initialized
INFO - 2016-09-22 09:48:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:48:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:48:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:48:45 --> URI Class Initialized
DEBUG - 2016-09-22 09:48:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:48:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:48:45 --> Router Class Initialized
INFO - 2016-09-22 09:48:45 --> URI Class Initialized
INFO - 2016-09-22 09:48:45 --> Output Class Initialized
INFO - 2016-09-22 09:48:45 --> Router Class Initialized
INFO - 2016-09-22 09:48:45 --> Security Class Initialized
INFO - 2016-09-22 09:48:45 --> Output Class Initialized
DEBUG - 2016-09-22 09:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:48:45 --> Input Class Initialized
INFO - 2016-09-22 09:48:45 --> Security Class Initialized
INFO - 2016-09-22 09:48:45 --> Language Class Initialized
DEBUG - 2016-09-22 09:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:48:45 --> Input Class Initialized
INFO - 2016-09-22 09:48:45 --> Language Class Initialized
INFO - 2016-09-22 09:48:45 --> Loader Class Initialized
INFO - 2016-09-22 09:48:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:48:45 --> Loader Class Initialized
INFO - 2016-09-22 09:48:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:48:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:48:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:48:45 --> Controller Class Initialized
INFO - 2016-09-22 09:48:46 --> Database Driver Class Initialized
INFO - 2016-09-22 09:48:46 --> Model Class Initialized
INFO - 2016-09-22 09:48:46 --> Model Class Initialized
INFO - 2016-09-22 09:48:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:48:46 --> Final output sent to browser
DEBUG - 2016-09-22 09:48:46 --> Total execution time: 0.0810
INFO - 2016-09-22 09:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:48:46 --> Controller Class Initialized
INFO - 2016-09-22 09:48:46 --> Database Driver Class Initialized
INFO - 2016-09-22 09:48:46 --> Model Class Initialized
INFO - 2016-09-22 09:48:46 --> Model Class Initialized
INFO - 2016-09-22 09:48:46 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 09:48:46 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 09:48:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-22 09:48:46 --> Final output sent to browser
DEBUG - 2016-09-22 09:48:46 --> Total execution time: 0.1111
INFO - 2016-09-22 09:49:15 --> Config Class Initialized
INFO - 2016-09-22 09:49:15 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:49:15 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:49:15 --> Utf8 Class Initialized
INFO - 2016-09-22 09:49:15 --> URI Class Initialized
INFO - 2016-09-22 09:49:15 --> Router Class Initialized
INFO - 2016-09-22 09:49:15 --> Output Class Initialized
INFO - 2016-09-22 09:49:15 --> Security Class Initialized
DEBUG - 2016-09-22 09:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:49:15 --> Input Class Initialized
INFO - 2016-09-22 09:49:15 --> Language Class Initialized
INFO - 2016-09-22 09:49:15 --> Loader Class Initialized
INFO - 2016-09-22 09:49:15 --> Helper loaded: url_helper
INFO - 2016-09-22 09:49:15 --> Helper loaded: language_helper
INFO - 2016-09-22 09:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:49:15 --> Controller Class Initialized
INFO - 2016-09-22 09:49:16 --> Database Driver Class Initialized
INFO - 2016-09-22 09:49:16 --> Model Class Initialized
INFO - 2016-09-22 09:49:16 --> Model Class Initialized
INFO - 2016-09-22 09:49:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:49:16 --> Final output sent to browser
DEBUG - 2016-09-22 09:49:16 --> Total execution time: 0.0557
INFO - 2016-09-22 09:49:45 --> Config Class Initialized
INFO - 2016-09-22 09:49:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:49:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:49:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:49:45 --> URI Class Initialized
INFO - 2016-09-22 09:49:45 --> Router Class Initialized
INFO - 2016-09-22 09:49:45 --> Output Class Initialized
INFO - 2016-09-22 09:49:45 --> Security Class Initialized
DEBUG - 2016-09-22 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:49:45 --> Input Class Initialized
INFO - 2016-09-22 09:49:45 --> Language Class Initialized
INFO - 2016-09-22 09:49:45 --> Loader Class Initialized
INFO - 2016-09-22 09:49:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:49:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:49:45 --> Controller Class Initialized
INFO - 2016-09-22 09:49:45 --> Database Driver Class Initialized
INFO - 2016-09-22 09:49:45 --> Model Class Initialized
INFO - 2016-09-22 09:49:45 --> Model Class Initialized
INFO - 2016-09-22 09:49:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:49:45 --> Final output sent to browser
DEBUG - 2016-09-22 09:49:45 --> Total execution time: 0.0505
INFO - 2016-09-22 09:50:15 --> Config Class Initialized
INFO - 2016-09-22 09:50:15 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:50:15 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:50:15 --> Utf8 Class Initialized
INFO - 2016-09-22 09:50:15 --> URI Class Initialized
INFO - 2016-09-22 09:50:15 --> Router Class Initialized
INFO - 2016-09-22 09:50:15 --> Output Class Initialized
INFO - 2016-09-22 09:50:15 --> Security Class Initialized
DEBUG - 2016-09-22 09:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:50:15 --> Input Class Initialized
INFO - 2016-09-22 09:50:15 --> Language Class Initialized
INFO - 2016-09-22 09:50:15 --> Loader Class Initialized
INFO - 2016-09-22 09:50:15 --> Helper loaded: url_helper
INFO - 2016-09-22 09:50:15 --> Helper loaded: language_helper
INFO - 2016-09-22 09:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:50:15 --> Controller Class Initialized
INFO - 2016-09-22 09:50:15 --> Database Driver Class Initialized
INFO - 2016-09-22 09:50:15 --> Model Class Initialized
INFO - 2016-09-22 09:50:15 --> Model Class Initialized
INFO - 2016-09-22 09:50:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:50:16 --> Final output sent to browser
DEBUG - 2016-09-22 09:50:16 --> Total execution time: 0.0563
INFO - 2016-09-22 09:50:45 --> Config Class Initialized
INFO - 2016-09-22 09:50:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:50:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:50:45 --> Utf8 Class Initialized
INFO - 2016-09-22 09:50:45 --> URI Class Initialized
INFO - 2016-09-22 09:50:45 --> Router Class Initialized
INFO - 2016-09-22 09:50:45 --> Output Class Initialized
INFO - 2016-09-22 09:50:45 --> Security Class Initialized
DEBUG - 2016-09-22 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:50:45 --> Input Class Initialized
INFO - 2016-09-22 09:50:45 --> Language Class Initialized
INFO - 2016-09-22 09:50:45 --> Loader Class Initialized
INFO - 2016-09-22 09:50:45 --> Helper loaded: url_helper
INFO - 2016-09-22 09:50:45 --> Helper loaded: language_helper
INFO - 2016-09-22 09:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:50:45 --> Controller Class Initialized
INFO - 2016-09-22 09:50:45 --> Database Driver Class Initialized
INFO - 2016-09-22 09:50:45 --> Model Class Initialized
INFO - 2016-09-22 09:50:45 --> Model Class Initialized
INFO - 2016-09-22 09:50:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:50:45 --> Final output sent to browser
DEBUG - 2016-09-22 09:50:45 --> Total execution time: 0.0519
INFO - 2016-09-22 09:51:15 --> Config Class Initialized
INFO - 2016-09-22 09:51:15 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:51:15 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:51:15 --> Utf8 Class Initialized
INFO - 2016-09-22 09:51:15 --> URI Class Initialized
INFO - 2016-09-22 09:51:15 --> Router Class Initialized
INFO - 2016-09-22 09:51:15 --> Output Class Initialized
INFO - 2016-09-22 09:51:15 --> Security Class Initialized
DEBUG - 2016-09-22 09:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:51:15 --> Input Class Initialized
INFO - 2016-09-22 09:51:15 --> Language Class Initialized
INFO - 2016-09-22 09:51:15 --> Loader Class Initialized
INFO - 2016-09-22 09:51:15 --> Helper loaded: url_helper
INFO - 2016-09-22 09:51:15 --> Helper loaded: language_helper
INFO - 2016-09-22 09:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:51:15 --> Controller Class Initialized
INFO - 2016-09-22 09:51:15 --> Database Driver Class Initialized
INFO - 2016-09-22 09:51:15 --> Model Class Initialized
INFO - 2016-09-22 09:51:15 --> Model Class Initialized
INFO - 2016-09-22 09:51:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:51:16 --> Final output sent to browser
DEBUG - 2016-09-22 09:51:16 --> Total execution time: 0.0532
INFO - 2016-09-22 09:51:20 --> Config Class Initialized
INFO - 2016-09-22 09:51:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:51:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:51:20 --> Utf8 Class Initialized
INFO - 2016-09-22 09:51:20 --> URI Class Initialized
INFO - 2016-09-22 09:51:20 --> Router Class Initialized
INFO - 2016-09-22 09:51:20 --> Output Class Initialized
INFO - 2016-09-22 09:51:20 --> Security Class Initialized
DEBUG - 2016-09-22 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:51:20 --> Input Class Initialized
INFO - 2016-09-22 09:51:20 --> Language Class Initialized
INFO - 2016-09-22 09:51:20 --> Loader Class Initialized
INFO - 2016-09-22 09:51:20 --> Helper loaded: url_helper
INFO - 2016-09-22 09:51:20 --> Helper loaded: language_helper
INFO - 2016-09-22 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:51:20 --> Controller Class Initialized
INFO - 2016-09-22 09:51:20 --> Database Driver Class Initialized
INFO - 2016-09-22 09:51:20 --> Model Class Initialized
INFO - 2016-09-22 09:51:20 --> Model Class Initialized
INFO - 2016-09-22 09:51:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:51:21 --> Final output sent to browser
DEBUG - 2016-09-22 09:51:21 --> Total execution time: 0.0614
INFO - 2016-09-22 09:52:07 --> Config Class Initialized
INFO - 2016-09-22 09:52:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:07 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:07 --> URI Class Initialized
INFO - 2016-09-22 09:52:07 --> Router Class Initialized
INFO - 2016-09-22 09:52:07 --> Output Class Initialized
INFO - 2016-09-22 09:52:07 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:07 --> Input Class Initialized
INFO - 2016-09-22 09:52:07 --> Language Class Initialized
INFO - 2016-09-22 09:52:07 --> Loader Class Initialized
INFO - 2016-09-22 09:52:07 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:07 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:07 --> Controller Class Initialized
INFO - 2016-09-22 09:52:07 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:07 --> Model Class Initialized
INFO - 2016-09-22 09:52:07 --> Model Class Initialized
INFO - 2016-09-22 09:52:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:07 --> Config Class Initialized
INFO - 2016-09-22 09:52:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:07 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:07 --> URI Class Initialized
INFO - 2016-09-22 09:52:07 --> Router Class Initialized
INFO - 2016-09-22 09:52:07 --> Output Class Initialized
INFO - 2016-09-22 09:52:07 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:07 --> Input Class Initialized
INFO - 2016-09-22 09:52:07 --> Language Class Initialized
INFO - 2016-09-22 09:52:07 --> Loader Class Initialized
INFO - 2016-09-22 09:52:07 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:07 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:07 --> Controller Class Initialized
INFO - 2016-09-22 09:52:07 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:07 --> Model Class Initialized
INFO - 2016-09-22 09:52:07 --> Model Class Initialized
INFO - 2016-09-22 09:52:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 09:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:52:07 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:07 --> Total execution time: 0.0559
INFO - 2016-09-22 09:52:10 --> Config Class Initialized
INFO - 2016-09-22 09:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:10 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:10 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:10 --> URI Class Initialized
INFO - 2016-09-22 09:52:10 --> Router Class Initialized
INFO - 2016-09-22 09:52:10 --> Output Class Initialized
INFO - 2016-09-22 09:52:10 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:10 --> Input Class Initialized
INFO - 2016-09-22 09:52:10 --> Language Class Initialized
INFO - 2016-09-22 09:52:10 --> Loader Class Initialized
INFO - 2016-09-22 09:52:10 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:10 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:10 --> Controller Class Initialized
INFO - 2016-09-22 09:52:10 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:10 --> Model Class Initialized
INFO - 2016-09-22 09:52:10 --> Model Class Initialized
INFO - 2016-09-22 09:52:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:10 --> Config Class Initialized
INFO - 2016-09-22 09:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:10 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:10 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:10 --> URI Class Initialized
INFO - 2016-09-22 09:52:10 --> Router Class Initialized
INFO - 2016-09-22 09:52:10 --> Output Class Initialized
INFO - 2016-09-22 09:52:10 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:11 --> Input Class Initialized
INFO - 2016-09-22 09:52:11 --> Language Class Initialized
INFO - 2016-09-22 09:52:11 --> Loader Class Initialized
INFO - 2016-09-22 09:52:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:11 --> Controller Class Initialized
INFO - 2016-09-22 09:52:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:11 --> Model Class Initialized
INFO - 2016-09-22 09:52:11 --> Model Class Initialized
INFO - 2016-09-22 09:52:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_attempt.php
INFO - 2016-09-22 09:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:52:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:11 --> Total execution time: 0.0979
INFO - 2016-09-22 09:52:11 --> Config Class Initialized
INFO - 2016-09-22 09:52:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:11 --> URI Class Initialized
INFO - 2016-09-22 09:52:11 --> Config Class Initialized
INFO - 2016-09-22 09:52:11 --> Hooks Class Initialized
INFO - 2016-09-22 09:52:11 --> Router Class Initialized
INFO - 2016-09-22 09:52:11 --> Output Class Initialized
INFO - 2016-09-22 09:52:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:11 --> Utf8 Class Initialized
DEBUG - 2016-09-22 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:11 --> URI Class Initialized
INFO - 2016-09-22 09:52:11 --> Input Class Initialized
INFO - 2016-09-22 09:52:11 --> Language Class Initialized
INFO - 2016-09-22 09:52:11 --> Router Class Initialized
INFO - 2016-09-22 09:52:11 --> Output Class Initialized
INFO - 2016-09-22 09:52:11 --> Loader Class Initialized
INFO - 2016-09-22 09:52:11 --> Security Class Initialized
INFO - 2016-09-22 09:52:11 --> Helper loaded: url_helper
DEBUG - 2016-09-22 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:11 --> Input Class Initialized
INFO - 2016-09-22 09:52:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:11 --> Language Class Initialized
INFO - 2016-09-22 09:52:11 --> Loader Class Initialized
INFO - 2016-09-22 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:11 --> Controller Class Initialized
INFO - 2016-09-22 09:52:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:11 --> Model Class Initialized
INFO - 2016-09-22 09:52:11 --> Model Class Initialized
INFO - 2016-09-22 09:52:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:11 --> Total execution time: 0.0741
INFO - 2016-09-22 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:11 --> Controller Class Initialized
INFO - 2016-09-22 09:52:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:11 --> Model Class Initialized
INFO - 2016-09-22 09:52:11 --> Model Class Initialized
INFO - 2016-09-22 09:52:11 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 09:52:11 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 09:52:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-22 09:52:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:11 --> Total execution time: 0.0985
INFO - 2016-09-22 09:52:21 --> Config Class Initialized
INFO - 2016-09-22 09:52:21 --> Hooks Class Initialized
INFO - 2016-09-22 09:52:21 --> Config Class Initialized
INFO - 2016-09-22 09:52:21 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:21 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:21 --> Utf8 Class Initialized
DEBUG - 2016-09-22 09:52:21 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:21 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:21 --> URI Class Initialized
INFO - 2016-09-22 09:52:21 --> URI Class Initialized
INFO - 2016-09-22 09:52:21 --> Router Class Initialized
INFO - 2016-09-22 09:52:21 --> Router Class Initialized
INFO - 2016-09-22 09:52:21 --> Output Class Initialized
INFO - 2016-09-22 09:52:21 --> Output Class Initialized
INFO - 2016-09-22 09:52:21 --> Security Class Initialized
INFO - 2016-09-22 09:52:21 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:21 --> Input Class Initialized
INFO - 2016-09-22 09:52:21 --> Language Class Initialized
DEBUG - 2016-09-22 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:21 --> Input Class Initialized
INFO - 2016-09-22 09:52:21 --> Language Class Initialized
INFO - 2016-09-22 09:52:21 --> Loader Class Initialized
INFO - 2016-09-22 09:52:21 --> Loader Class Initialized
INFO - 2016-09-22 09:52:21 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:21 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:21 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:21 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:21 --> Controller Class Initialized
INFO - 2016-09-22 09:52:21 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:21 --> Model Class Initialized
INFO - 2016-09-22 09:52:21 --> Model Class Initialized
INFO - 2016-09-22 09:52:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:21 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:21 --> Total execution time: 0.0661
INFO - 2016-09-22 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:21 --> Controller Class Initialized
INFO - 2016-09-22 09:52:21 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:21 --> Model Class Initialized
INFO - 2016-09-22 09:52:21 --> Model Class Initialized
INFO - 2016-09-22 09:52:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:21 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:21 --> Total execution time: 0.0880
INFO - 2016-09-22 09:52:33 --> Config Class Initialized
INFO - 2016-09-22 09:52:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:33 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:33 --> URI Class Initialized
INFO - 2016-09-22 09:52:33 --> Router Class Initialized
INFO - 2016-09-22 09:52:33 --> Output Class Initialized
INFO - 2016-09-22 09:52:33 --> Config Class Initialized
INFO - 2016-09-22 09:52:33 --> Hooks Class Initialized
INFO - 2016-09-22 09:52:33 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:33 --> Input Class Initialized
DEBUG - 2016-09-22 09:52:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:33 --> Language Class Initialized
INFO - 2016-09-22 09:52:33 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:33 --> URI Class Initialized
INFO - 2016-09-22 09:52:33 --> Router Class Initialized
INFO - 2016-09-22 09:52:33 --> Loader Class Initialized
INFO - 2016-09-22 09:52:33 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:33 --> Output Class Initialized
INFO - 2016-09-22 09:52:33 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:33 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:33 --> Input Class Initialized
INFO - 2016-09-22 09:52:33 --> Language Class Initialized
INFO - 2016-09-22 09:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:33 --> Controller Class Initialized
INFO - 2016-09-22 09:52:33 --> Loader Class Initialized
INFO - 2016-09-22 09:52:33 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:33 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:33 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:33 --> Model Class Initialized
INFO - 2016-09-22 09:52:33 --> Model Class Initialized
INFO - 2016-09-22 09:52:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:33 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:33 --> Total execution time: 0.0846
INFO - 2016-09-22 09:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:33 --> Controller Class Initialized
INFO - 2016-09-22 09:52:33 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:33 --> Model Class Initialized
INFO - 2016-09-22 09:52:33 --> Model Class Initialized
INFO - 2016-09-22 09:52:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:33 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:33 --> Total execution time: 0.1060
INFO - 2016-09-22 09:52:41 --> Config Class Initialized
INFO - 2016-09-22 09:52:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:41 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:41 --> URI Class Initialized
INFO - 2016-09-22 09:52:41 --> Router Class Initialized
INFO - 2016-09-22 09:52:41 --> Output Class Initialized
INFO - 2016-09-22 09:52:41 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:41 --> Input Class Initialized
INFO - 2016-09-22 09:52:41 --> Language Class Initialized
INFO - 2016-09-22 09:52:41 --> Loader Class Initialized
INFO - 2016-09-22 09:52:41 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:41 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:41 --> Controller Class Initialized
INFO - 2016-09-22 09:52:41 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:41 --> Model Class Initialized
INFO - 2016-09-22 09:52:41 --> Model Class Initialized
INFO - 2016-09-22 09:52:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:41 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:41 --> Total execution time: 0.0599
INFO - 2016-09-22 09:52:50 --> Config Class Initialized
INFO - 2016-09-22 09:52:50 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:52:50 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:52:50 --> Utf8 Class Initialized
INFO - 2016-09-22 09:52:50 --> URI Class Initialized
INFO - 2016-09-22 09:52:50 --> Router Class Initialized
INFO - 2016-09-22 09:52:50 --> Output Class Initialized
INFO - 2016-09-22 09:52:50 --> Security Class Initialized
DEBUG - 2016-09-22 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:52:50 --> Input Class Initialized
INFO - 2016-09-22 09:52:50 --> Language Class Initialized
INFO - 2016-09-22 09:52:50 --> Loader Class Initialized
INFO - 2016-09-22 09:52:50 --> Helper loaded: url_helper
INFO - 2016-09-22 09:52:50 --> Helper loaded: language_helper
INFO - 2016-09-22 09:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:52:50 --> Controller Class Initialized
INFO - 2016-09-22 09:52:50 --> Database Driver Class Initialized
INFO - 2016-09-22 09:52:50 --> Model Class Initialized
INFO - 2016-09-22 09:52:50 --> Model Class Initialized
INFO - 2016-09-22 09:52:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:52:51 --> Final output sent to browser
DEBUG - 2016-09-22 09:52:51 --> Total execution time: 0.0777
INFO - 2016-09-22 09:53:11 --> Config Class Initialized
INFO - 2016-09-22 09:53:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:53:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:53:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:53:11 --> URI Class Initialized
INFO - 2016-09-22 09:53:11 --> Router Class Initialized
INFO - 2016-09-22 09:53:11 --> Output Class Initialized
INFO - 2016-09-22 09:53:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:53:11 --> Input Class Initialized
INFO - 2016-09-22 09:53:11 --> Language Class Initialized
INFO - 2016-09-22 09:53:11 --> Loader Class Initialized
INFO - 2016-09-22 09:53:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:53:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:53:11 --> Controller Class Initialized
INFO - 2016-09-22 09:53:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:53:11 --> Model Class Initialized
INFO - 2016-09-22 09:53:11 --> Model Class Initialized
INFO - 2016-09-22 09:53:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:53:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:53:11 --> Total execution time: 0.0655
INFO - 2016-09-22 09:53:41 --> Config Class Initialized
INFO - 2016-09-22 09:53:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:53:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:53:41 --> Utf8 Class Initialized
INFO - 2016-09-22 09:53:41 --> URI Class Initialized
INFO - 2016-09-22 09:53:41 --> Router Class Initialized
INFO - 2016-09-22 09:53:41 --> Output Class Initialized
INFO - 2016-09-22 09:53:41 --> Security Class Initialized
DEBUG - 2016-09-22 09:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:53:41 --> Input Class Initialized
INFO - 2016-09-22 09:53:41 --> Language Class Initialized
INFO - 2016-09-22 09:53:41 --> Loader Class Initialized
INFO - 2016-09-22 09:53:41 --> Helper loaded: url_helper
INFO - 2016-09-22 09:53:41 --> Helper loaded: language_helper
INFO - 2016-09-22 09:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:53:41 --> Controller Class Initialized
INFO - 2016-09-22 09:53:41 --> Database Driver Class Initialized
INFO - 2016-09-22 09:53:41 --> Model Class Initialized
INFO - 2016-09-22 09:53:41 --> Model Class Initialized
INFO - 2016-09-22 09:53:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:53:41 --> Final output sent to browser
DEBUG - 2016-09-22 09:53:41 --> Total execution time: 0.0606
INFO - 2016-09-22 09:54:11 --> Config Class Initialized
INFO - 2016-09-22 09:54:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:54:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:54:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:54:11 --> URI Class Initialized
INFO - 2016-09-22 09:54:11 --> Router Class Initialized
INFO - 2016-09-22 09:54:11 --> Output Class Initialized
INFO - 2016-09-22 09:54:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:54:11 --> Input Class Initialized
INFO - 2016-09-22 09:54:11 --> Language Class Initialized
INFO - 2016-09-22 09:54:11 --> Loader Class Initialized
INFO - 2016-09-22 09:54:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:54:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:54:11 --> Controller Class Initialized
INFO - 2016-09-22 09:54:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:54:11 --> Model Class Initialized
INFO - 2016-09-22 09:54:11 --> Model Class Initialized
INFO - 2016-09-22 09:54:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:54:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:54:11 --> Total execution time: 0.0536
INFO - 2016-09-22 09:54:41 --> Config Class Initialized
INFO - 2016-09-22 09:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:54:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:54:41 --> Utf8 Class Initialized
INFO - 2016-09-22 09:54:41 --> URI Class Initialized
INFO - 2016-09-22 09:54:41 --> Router Class Initialized
INFO - 2016-09-22 09:54:41 --> Output Class Initialized
INFO - 2016-09-22 09:54:41 --> Security Class Initialized
DEBUG - 2016-09-22 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:54:41 --> Input Class Initialized
INFO - 2016-09-22 09:54:41 --> Language Class Initialized
INFO - 2016-09-22 09:54:41 --> Loader Class Initialized
INFO - 2016-09-22 09:54:41 --> Helper loaded: url_helper
INFO - 2016-09-22 09:54:41 --> Helper loaded: language_helper
INFO - 2016-09-22 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:54:41 --> Controller Class Initialized
INFO - 2016-09-22 09:54:41 --> Database Driver Class Initialized
INFO - 2016-09-22 09:54:41 --> Model Class Initialized
INFO - 2016-09-22 09:54:41 --> Model Class Initialized
INFO - 2016-09-22 09:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:54:41 --> Final output sent to browser
DEBUG - 2016-09-22 09:54:41 --> Total execution time: 0.0524
INFO - 2016-09-22 09:55:11 --> Config Class Initialized
INFO - 2016-09-22 09:55:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:55:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:55:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:55:11 --> URI Class Initialized
INFO - 2016-09-22 09:55:11 --> Router Class Initialized
INFO - 2016-09-22 09:55:11 --> Output Class Initialized
INFO - 2016-09-22 09:55:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:55:11 --> Input Class Initialized
INFO - 2016-09-22 09:55:11 --> Language Class Initialized
INFO - 2016-09-22 09:55:11 --> Loader Class Initialized
INFO - 2016-09-22 09:55:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:55:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:55:11 --> Controller Class Initialized
INFO - 2016-09-22 09:55:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:55:11 --> Model Class Initialized
INFO - 2016-09-22 09:55:11 --> Model Class Initialized
INFO - 2016-09-22 09:55:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:55:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:55:11 --> Total execution time: 0.0534
INFO - 2016-09-22 09:55:41 --> Config Class Initialized
INFO - 2016-09-22 09:55:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:55:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:55:41 --> Utf8 Class Initialized
INFO - 2016-09-22 09:55:41 --> URI Class Initialized
INFO - 2016-09-22 09:55:41 --> Router Class Initialized
INFO - 2016-09-22 09:55:41 --> Output Class Initialized
INFO - 2016-09-22 09:55:41 --> Security Class Initialized
DEBUG - 2016-09-22 09:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:55:41 --> Input Class Initialized
INFO - 2016-09-22 09:55:41 --> Language Class Initialized
INFO - 2016-09-22 09:55:41 --> Loader Class Initialized
INFO - 2016-09-22 09:55:41 --> Helper loaded: url_helper
INFO - 2016-09-22 09:55:41 --> Helper loaded: language_helper
INFO - 2016-09-22 09:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:55:41 --> Controller Class Initialized
INFO - 2016-09-22 09:55:41 --> Database Driver Class Initialized
INFO - 2016-09-22 09:55:41 --> Model Class Initialized
INFO - 2016-09-22 09:55:41 --> Model Class Initialized
INFO - 2016-09-22 09:55:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:55:41 --> Final output sent to browser
DEBUG - 2016-09-22 09:55:41 --> Total execution time: 0.0523
INFO - 2016-09-22 09:56:11 --> Config Class Initialized
INFO - 2016-09-22 09:56:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:56:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:56:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:56:11 --> URI Class Initialized
INFO - 2016-09-22 09:56:11 --> Router Class Initialized
INFO - 2016-09-22 09:56:11 --> Output Class Initialized
INFO - 2016-09-22 09:56:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:56:11 --> Input Class Initialized
INFO - 2016-09-22 09:56:11 --> Language Class Initialized
INFO - 2016-09-22 09:56:11 --> Loader Class Initialized
INFO - 2016-09-22 09:56:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:56:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:56:11 --> Controller Class Initialized
INFO - 2016-09-22 09:56:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:56:11 --> Model Class Initialized
INFO - 2016-09-22 09:56:11 --> Model Class Initialized
INFO - 2016-09-22 09:56:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:56:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:56:11 --> Total execution time: 0.0521
INFO - 2016-09-22 09:56:28 --> Config Class Initialized
INFO - 2016-09-22 09:56:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:56:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:56:28 --> Utf8 Class Initialized
INFO - 2016-09-22 09:56:28 --> URI Class Initialized
INFO - 2016-09-22 09:56:28 --> Router Class Initialized
INFO - 2016-09-22 09:56:28 --> Output Class Initialized
INFO - 2016-09-22 09:56:28 --> Security Class Initialized
DEBUG - 2016-09-22 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:56:28 --> Input Class Initialized
INFO - 2016-09-22 09:56:28 --> Language Class Initialized
INFO - 2016-09-22 09:56:28 --> Loader Class Initialized
INFO - 2016-09-22 09:56:28 --> Helper loaded: url_helper
INFO - 2016-09-22 09:56:28 --> Helper loaded: language_helper
INFO - 2016-09-22 09:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:56:28 --> Controller Class Initialized
INFO - 2016-09-22 09:56:28 --> Database Driver Class Initialized
INFO - 2016-09-22 09:56:28 --> Model Class Initialized
INFO - 2016-09-22 09:56:28 --> Model Class Initialized
INFO - 2016-09-22 09:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:56:28 --> Final output sent to browser
DEBUG - 2016-09-22 09:56:28 --> Total execution time: 0.0928
INFO - 2016-09-22 09:56:41 --> Config Class Initialized
INFO - 2016-09-22 09:56:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:56:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:56:41 --> Utf8 Class Initialized
INFO - 2016-09-22 09:56:41 --> URI Class Initialized
INFO - 2016-09-22 09:56:41 --> Router Class Initialized
INFO - 2016-09-22 09:56:41 --> Output Class Initialized
INFO - 2016-09-22 09:56:41 --> Security Class Initialized
DEBUG - 2016-09-22 09:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:56:41 --> Input Class Initialized
INFO - 2016-09-22 09:56:41 --> Language Class Initialized
INFO - 2016-09-22 09:56:41 --> Loader Class Initialized
INFO - 2016-09-22 09:56:41 --> Helper loaded: url_helper
INFO - 2016-09-22 09:56:41 --> Helper loaded: language_helper
INFO - 2016-09-22 09:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:56:41 --> Controller Class Initialized
INFO - 2016-09-22 09:56:41 --> Database Driver Class Initialized
INFO - 2016-09-22 09:56:41 --> Model Class Initialized
INFO - 2016-09-22 09:56:41 --> Model Class Initialized
INFO - 2016-09-22 09:56:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:56:41 --> Final output sent to browser
DEBUG - 2016-09-22 09:56:41 --> Total execution time: 0.0517
INFO - 2016-09-22 09:57:11 --> Config Class Initialized
INFO - 2016-09-22 09:57:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:57:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:57:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:57:11 --> URI Class Initialized
INFO - 2016-09-22 09:57:11 --> Router Class Initialized
INFO - 2016-09-22 09:57:11 --> Output Class Initialized
INFO - 2016-09-22 09:57:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:57:11 --> Input Class Initialized
INFO - 2016-09-22 09:57:11 --> Language Class Initialized
INFO - 2016-09-22 09:57:11 --> Loader Class Initialized
INFO - 2016-09-22 09:57:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:57:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:57:11 --> Controller Class Initialized
INFO - 2016-09-22 09:57:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:57:11 --> Model Class Initialized
INFO - 2016-09-22 09:57:11 --> Model Class Initialized
INFO - 2016-09-22 09:57:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:57:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:57:11 --> Total execution time: 0.0541
INFO - 2016-09-22 09:57:41 --> Config Class Initialized
INFO - 2016-09-22 09:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:57:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:57:41 --> Utf8 Class Initialized
INFO - 2016-09-22 09:57:41 --> URI Class Initialized
INFO - 2016-09-22 09:57:41 --> Router Class Initialized
INFO - 2016-09-22 09:57:41 --> Output Class Initialized
INFO - 2016-09-22 09:57:41 --> Security Class Initialized
DEBUG - 2016-09-22 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:57:41 --> Input Class Initialized
INFO - 2016-09-22 09:57:41 --> Language Class Initialized
INFO - 2016-09-22 09:57:41 --> Loader Class Initialized
INFO - 2016-09-22 09:57:41 --> Helper loaded: url_helper
INFO - 2016-09-22 09:57:41 --> Helper loaded: language_helper
INFO - 2016-09-22 09:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:57:41 --> Controller Class Initialized
INFO - 2016-09-22 09:57:41 --> Database Driver Class Initialized
INFO - 2016-09-22 09:57:41 --> Model Class Initialized
INFO - 2016-09-22 09:57:41 --> Model Class Initialized
INFO - 2016-09-22 09:57:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:57:41 --> Final output sent to browser
DEBUG - 2016-09-22 09:57:41 --> Total execution time: 0.0527
INFO - 2016-09-22 09:58:11 --> Config Class Initialized
INFO - 2016-09-22 09:58:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:58:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:58:11 --> Utf8 Class Initialized
INFO - 2016-09-22 09:58:11 --> URI Class Initialized
INFO - 2016-09-22 09:58:11 --> Router Class Initialized
INFO - 2016-09-22 09:58:11 --> Output Class Initialized
INFO - 2016-09-22 09:58:11 --> Security Class Initialized
DEBUG - 2016-09-22 09:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:58:11 --> Input Class Initialized
INFO - 2016-09-22 09:58:11 --> Language Class Initialized
INFO - 2016-09-22 09:58:11 --> Loader Class Initialized
INFO - 2016-09-22 09:58:11 --> Helper loaded: url_helper
INFO - 2016-09-22 09:58:11 --> Helper loaded: language_helper
INFO - 2016-09-22 09:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:58:11 --> Controller Class Initialized
INFO - 2016-09-22 09:58:11 --> Database Driver Class Initialized
INFO - 2016-09-22 09:58:11 --> Model Class Initialized
INFO - 2016-09-22 09:58:11 --> Model Class Initialized
INFO - 2016-09-22 09:58:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:58:11 --> Final output sent to browser
DEBUG - 2016-09-22 09:58:11 --> Total execution time: 0.0616
INFO - 2016-09-22 09:58:12 --> Config Class Initialized
INFO - 2016-09-22 09:58:12 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:58:12 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:58:12 --> Utf8 Class Initialized
INFO - 2016-09-22 09:58:12 --> URI Class Initialized
INFO - 2016-09-22 09:58:12 --> Router Class Initialized
INFO - 2016-09-22 09:58:12 --> Output Class Initialized
INFO - 2016-09-22 09:58:12 --> Security Class Initialized
DEBUG - 2016-09-22 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:58:12 --> Input Class Initialized
INFO - 2016-09-22 09:58:12 --> Language Class Initialized
INFO - 2016-09-22 09:58:12 --> Loader Class Initialized
INFO - 2016-09-22 09:58:12 --> Helper loaded: url_helper
INFO - 2016-09-22 09:58:12 --> Helper loaded: language_helper
INFO - 2016-09-22 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:58:12 --> Controller Class Initialized
INFO - 2016-09-22 09:58:12 --> Database Driver Class Initialized
INFO - 2016-09-22 09:58:12 --> Model Class Initialized
INFO - 2016-09-22 09:58:12 --> Model Class Initialized
INFO - 2016-09-22 09:58:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:58:12 --> Final output sent to browser
DEBUG - 2016-09-22 09:58:12 --> Total execution time: 0.0674
INFO - 2016-09-22 09:58:12 --> Config Class Initialized
INFO - 2016-09-22 09:58:12 --> Hooks Class Initialized
DEBUG - 2016-09-22 09:58:12 --> UTF-8 Support Enabled
INFO - 2016-09-22 09:58:12 --> Utf8 Class Initialized
INFO - 2016-09-22 09:58:12 --> URI Class Initialized
INFO - 2016-09-22 09:58:12 --> Router Class Initialized
INFO - 2016-09-22 09:58:12 --> Output Class Initialized
INFO - 2016-09-22 09:58:12 --> Security Class Initialized
DEBUG - 2016-09-22 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 09:58:12 --> Input Class Initialized
INFO - 2016-09-22 09:58:12 --> Language Class Initialized
INFO - 2016-09-22 09:58:12 --> Loader Class Initialized
INFO - 2016-09-22 09:58:12 --> Helper loaded: url_helper
INFO - 2016-09-22 09:58:12 --> Helper loaded: language_helper
INFO - 2016-09-22 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 09:58:12 --> Controller Class Initialized
INFO - 2016-09-22 09:58:12 --> Database Driver Class Initialized
INFO - 2016-09-22 09:58:12 --> Model Class Initialized
INFO - 2016-09-22 09:58:12 --> Model Class Initialized
INFO - 2016-09-22 09:58:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 09:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 09:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 09:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 09:58:12 --> Final output sent to browser
DEBUG - 2016-09-22 09:58:12 --> Total execution time: 0.0653
INFO - 2016-09-22 10:01:20 --> Config Class Initialized
INFO - 2016-09-22 10:01:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:01:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:01:20 --> Utf8 Class Initialized
INFO - 2016-09-22 10:01:20 --> URI Class Initialized
INFO - 2016-09-22 10:01:20 --> Router Class Initialized
INFO - 2016-09-22 10:01:20 --> Output Class Initialized
INFO - 2016-09-22 10:01:20 --> Security Class Initialized
DEBUG - 2016-09-22 10:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:01:20 --> Input Class Initialized
INFO - 2016-09-22 10:01:20 --> Language Class Initialized
INFO - 2016-09-22 10:01:20 --> Loader Class Initialized
INFO - 2016-09-22 10:01:20 --> Helper loaded: url_helper
INFO - 2016-09-22 10:01:20 --> Helper loaded: language_helper
INFO - 2016-09-22 10:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:01:20 --> Controller Class Initialized
INFO - 2016-09-22 10:01:20 --> Database Driver Class Initialized
INFO - 2016-09-22 10:01:20 --> Model Class Initialized
INFO - 2016-09-22 10:01:20 --> Model Class Initialized
INFO - 2016-09-22 10:01:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:02:02 --> Config Class Initialized
INFO - 2016-09-22 10:02:02 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:02:02 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:02:02 --> Utf8 Class Initialized
INFO - 2016-09-22 10:02:02 --> URI Class Initialized
INFO - 2016-09-22 10:02:02 --> Router Class Initialized
INFO - 2016-09-22 10:02:02 --> Output Class Initialized
INFO - 2016-09-22 10:02:02 --> Security Class Initialized
DEBUG - 2016-09-22 10:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:02:02 --> Input Class Initialized
INFO - 2016-09-22 10:02:02 --> Language Class Initialized
INFO - 2016-09-22 10:02:02 --> Loader Class Initialized
INFO - 2016-09-22 10:02:02 --> Helper loaded: url_helper
INFO - 2016-09-22 10:02:02 --> Helper loaded: language_helper
INFO - 2016-09-22 10:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:02:02 --> Controller Class Initialized
INFO - 2016-09-22 10:02:02 --> Database Driver Class Initialized
INFO - 2016-09-22 10:02:02 --> Model Class Initialized
INFO - 2016-09-22 10:02:02 --> Model Class Initialized
INFO - 2016-09-22 10:02:02 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 10:02:02 --> Severity: Notice --> Undefined index: quid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 32
INFO - 2016-09-22 10:02:10 --> Config Class Initialized
INFO - 2016-09-22 10:02:10 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:02:10 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:02:10 --> Utf8 Class Initialized
INFO - 2016-09-22 10:02:10 --> URI Class Initialized
INFO - 2016-09-22 10:02:10 --> Router Class Initialized
INFO - 2016-09-22 10:02:10 --> Output Class Initialized
INFO - 2016-09-22 10:02:10 --> Security Class Initialized
DEBUG - 2016-09-22 10:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:02:10 --> Input Class Initialized
INFO - 2016-09-22 10:02:10 --> Language Class Initialized
INFO - 2016-09-22 10:02:10 --> Loader Class Initialized
INFO - 2016-09-22 10:02:10 --> Helper loaded: url_helper
INFO - 2016-09-22 10:02:10 --> Helper loaded: language_helper
INFO - 2016-09-22 10:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:02:10 --> Controller Class Initialized
INFO - 2016-09-22 10:02:10 --> Database Driver Class Initialized
INFO - 2016-09-22 10:02:10 --> Model Class Initialized
INFO - 2016-09-22 10:02:10 --> Model Class Initialized
INFO - 2016-09-22 10:02:10 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 10:02:10 --> Severity: Notice --> Undefined index: quid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 32
INFO - 2016-09-22 10:02:52 --> Config Class Initialized
INFO - 2016-09-22 10:02:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:02:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:02:52 --> Utf8 Class Initialized
INFO - 2016-09-22 10:02:52 --> URI Class Initialized
INFO - 2016-09-22 10:02:52 --> Router Class Initialized
INFO - 2016-09-22 10:02:52 --> Output Class Initialized
INFO - 2016-09-22 10:02:52 --> Security Class Initialized
DEBUG - 2016-09-22 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:02:52 --> Input Class Initialized
INFO - 2016-09-22 10:02:52 --> Language Class Initialized
INFO - 2016-09-22 10:02:52 --> Loader Class Initialized
INFO - 2016-09-22 10:02:52 --> Helper loaded: url_helper
INFO - 2016-09-22 10:02:52 --> Helper loaded: language_helper
INFO - 2016-09-22 10:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:02:52 --> Controller Class Initialized
INFO - 2016-09-22 10:02:52 --> Database Driver Class Initialized
INFO - 2016-09-22 10:02:52 --> Model Class Initialized
INFO - 2016-09-22 10:02:52 --> Model Class Initialized
INFO - 2016-09-22 10:02:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:03:02 --> Config Class Initialized
INFO - 2016-09-22 10:03:02 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:03:02 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:03:02 --> Utf8 Class Initialized
INFO - 2016-09-22 10:03:02 --> URI Class Initialized
INFO - 2016-09-22 10:03:02 --> Router Class Initialized
INFO - 2016-09-22 10:03:02 --> Output Class Initialized
INFO - 2016-09-22 10:03:02 --> Security Class Initialized
DEBUG - 2016-09-22 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:03:02 --> Input Class Initialized
INFO - 2016-09-22 10:03:02 --> Language Class Initialized
INFO - 2016-09-22 10:03:02 --> Loader Class Initialized
INFO - 2016-09-22 10:03:02 --> Helper loaded: url_helper
INFO - 2016-09-22 10:03:02 --> Helper loaded: language_helper
INFO - 2016-09-22 10:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:03:02 --> Controller Class Initialized
INFO - 2016-09-22 10:03:02 --> Database Driver Class Initialized
INFO - 2016-09-22 10:03:02 --> Model Class Initialized
INFO - 2016-09-22 10:03:02 --> Model Class Initialized
INFO - 2016-09-22 10:03:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:03:59 --> Config Class Initialized
INFO - 2016-09-22 10:03:59 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:03:59 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:03:59 --> Utf8 Class Initialized
INFO - 2016-09-22 10:03:59 --> URI Class Initialized
INFO - 2016-09-22 10:03:59 --> Router Class Initialized
INFO - 2016-09-22 10:03:59 --> Output Class Initialized
INFO - 2016-09-22 10:03:59 --> Security Class Initialized
DEBUG - 2016-09-22 10:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:03:59 --> Input Class Initialized
INFO - 2016-09-22 10:03:59 --> Language Class Initialized
INFO - 2016-09-22 10:03:59 --> Loader Class Initialized
INFO - 2016-09-22 10:03:59 --> Helper loaded: url_helper
INFO - 2016-09-22 10:03:59 --> Helper loaded: language_helper
INFO - 2016-09-22 10:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:03:59 --> Controller Class Initialized
INFO - 2016-09-22 10:03:59 --> Database Driver Class Initialized
INFO - 2016-09-22 10:03:59 --> Model Class Initialized
INFO - 2016-09-22 10:03:59 --> Model Class Initialized
INFO - 2016-09-22 10:03:59 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 5 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 6 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 7 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
ERROR - 2016-09-22 10:03:59 --> Severity: Notice --> Undefined offset: 8 C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 34
INFO - 2016-09-22 10:04:09 --> Config Class Initialized
INFO - 2016-09-22 10:04:09 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:04:09 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:04:09 --> Utf8 Class Initialized
INFO - 2016-09-22 10:04:09 --> URI Class Initialized
INFO - 2016-09-22 10:04:09 --> Router Class Initialized
INFO - 2016-09-22 10:04:09 --> Output Class Initialized
INFO - 2016-09-22 10:04:09 --> Security Class Initialized
DEBUG - 2016-09-22 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:04:09 --> Input Class Initialized
INFO - 2016-09-22 10:04:09 --> Language Class Initialized
INFO - 2016-09-22 10:04:09 --> Loader Class Initialized
INFO - 2016-09-22 10:04:09 --> Helper loaded: url_helper
INFO - 2016-09-22 10:04:09 --> Helper loaded: language_helper
INFO - 2016-09-22 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:04:09 --> Controller Class Initialized
INFO - 2016-09-22 10:04:09 --> Database Driver Class Initialized
INFO - 2016-09-22 10:04:09 --> Model Class Initialized
INFO - 2016-09-22 10:04:09 --> Model Class Initialized
INFO - 2016-09-22 10:04:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:04:29 --> Config Class Initialized
INFO - 2016-09-22 10:04:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:04:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:04:29 --> Utf8 Class Initialized
INFO - 2016-09-22 10:04:29 --> URI Class Initialized
INFO - 2016-09-22 10:04:29 --> Router Class Initialized
INFO - 2016-09-22 10:04:29 --> Output Class Initialized
INFO - 2016-09-22 10:04:29 --> Security Class Initialized
DEBUG - 2016-09-22 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:04:29 --> Input Class Initialized
INFO - 2016-09-22 10:04:29 --> Language Class Initialized
INFO - 2016-09-22 10:04:29 --> Loader Class Initialized
INFO - 2016-09-22 10:04:29 --> Helper loaded: url_helper
INFO - 2016-09-22 10:04:29 --> Helper loaded: language_helper
INFO - 2016-09-22 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:04:29 --> Controller Class Initialized
INFO - 2016-09-22 10:04:29 --> Database Driver Class Initialized
INFO - 2016-09-22 10:04:29 --> Model Class Initialized
INFO - 2016-09-22 10:04:29 --> Model Class Initialized
INFO - 2016-09-22 10:04:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:04:54 --> Config Class Initialized
INFO - 2016-09-22 10:04:54 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:04:54 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:04:54 --> Utf8 Class Initialized
INFO - 2016-09-22 10:04:54 --> URI Class Initialized
INFO - 2016-09-22 10:04:54 --> Router Class Initialized
INFO - 2016-09-22 10:04:54 --> Output Class Initialized
INFO - 2016-09-22 10:04:54 --> Security Class Initialized
DEBUG - 2016-09-22 10:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:04:54 --> Input Class Initialized
INFO - 2016-09-22 10:04:54 --> Language Class Initialized
INFO - 2016-09-22 10:04:54 --> Loader Class Initialized
INFO - 2016-09-22 10:04:54 --> Helper loaded: url_helper
INFO - 2016-09-22 10:04:54 --> Helper loaded: language_helper
INFO - 2016-09-22 10:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:04:54 --> Controller Class Initialized
INFO - 2016-09-22 10:04:54 --> Database Driver Class Initialized
INFO - 2016-09-22 10:04:54 --> Model Class Initialized
INFO - 2016-09-22 10:04:54 --> Model Class Initialized
INFO - 2016-09-22 10:04:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:05:11 --> Config Class Initialized
INFO - 2016-09-22 10:05:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:05:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:05:11 --> Utf8 Class Initialized
INFO - 2016-09-22 10:05:11 --> URI Class Initialized
INFO - 2016-09-22 10:05:11 --> Router Class Initialized
INFO - 2016-09-22 10:05:11 --> Output Class Initialized
INFO - 2016-09-22 10:05:11 --> Security Class Initialized
DEBUG - 2016-09-22 10:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:05:11 --> Input Class Initialized
INFO - 2016-09-22 10:05:11 --> Language Class Initialized
INFO - 2016-09-22 10:05:11 --> Loader Class Initialized
INFO - 2016-09-22 10:05:11 --> Helper loaded: url_helper
INFO - 2016-09-22 10:05:11 --> Helper loaded: language_helper
INFO - 2016-09-22 10:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:05:11 --> Controller Class Initialized
INFO - 2016-09-22 10:05:11 --> Database Driver Class Initialized
INFO - 2016-09-22 10:05:11 --> Model Class Initialized
INFO - 2016-09-22 10:05:11 --> Model Class Initialized
INFO - 2016-09-22 10:05:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:05:42 --> Config Class Initialized
INFO - 2016-09-22 10:05:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:05:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:05:42 --> Utf8 Class Initialized
INFO - 2016-09-22 10:05:42 --> URI Class Initialized
INFO - 2016-09-22 10:05:42 --> Router Class Initialized
INFO - 2016-09-22 10:05:42 --> Output Class Initialized
INFO - 2016-09-22 10:05:42 --> Security Class Initialized
DEBUG - 2016-09-22 10:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:05:42 --> Input Class Initialized
INFO - 2016-09-22 10:05:42 --> Language Class Initialized
INFO - 2016-09-22 10:05:42 --> Loader Class Initialized
INFO - 2016-09-22 10:05:42 --> Helper loaded: url_helper
INFO - 2016-09-22 10:05:42 --> Helper loaded: language_helper
INFO - 2016-09-22 10:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:05:42 --> Controller Class Initialized
INFO - 2016-09-22 10:05:42 --> Database Driver Class Initialized
INFO - 2016-09-22 10:05:42 --> Model Class Initialized
INFO - 2016-09-22 10:05:42 --> Model Class Initialized
INFO - 2016-09-22 10:05:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:05:42 --> Final output sent to browser
DEBUG - 2016-09-22 10:05:42 --> Total execution time: 0.0582
INFO - 2016-09-22 10:06:18 --> Config Class Initialized
INFO - 2016-09-22 10:06:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:06:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:06:18 --> Utf8 Class Initialized
INFO - 2016-09-22 10:06:18 --> URI Class Initialized
INFO - 2016-09-22 10:06:18 --> Router Class Initialized
INFO - 2016-09-22 10:06:18 --> Output Class Initialized
INFO - 2016-09-22 10:06:18 --> Security Class Initialized
DEBUG - 2016-09-22 10:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:06:18 --> Input Class Initialized
INFO - 2016-09-22 10:06:18 --> Language Class Initialized
INFO - 2016-09-22 10:06:18 --> Loader Class Initialized
INFO - 2016-09-22 10:06:18 --> Helper loaded: url_helper
INFO - 2016-09-22 10:06:18 --> Helper loaded: language_helper
INFO - 2016-09-22 10:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:06:18 --> Controller Class Initialized
INFO - 2016-09-22 10:06:18 --> Database Driver Class Initialized
INFO - 2016-09-22 10:06:18 --> Model Class Initialized
INFO - 2016-09-22 10:06:18 --> Model Class Initialized
INFO - 2016-09-22 10:06:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:06:18 --> Final output sent to browser
DEBUG - 2016-09-22 10:06:18 --> Total execution time: 0.0706
INFO - 2016-09-22 10:06:20 --> Config Class Initialized
INFO - 2016-09-22 10:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:06:20 --> Utf8 Class Initialized
INFO - 2016-09-22 10:06:20 --> URI Class Initialized
INFO - 2016-09-22 10:06:20 --> Router Class Initialized
INFO - 2016-09-22 10:06:20 --> Output Class Initialized
INFO - 2016-09-22 10:06:20 --> Security Class Initialized
DEBUG - 2016-09-22 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:06:20 --> Input Class Initialized
INFO - 2016-09-22 10:06:20 --> Language Class Initialized
INFO - 2016-09-22 10:06:20 --> Loader Class Initialized
INFO - 2016-09-22 10:06:20 --> Helper loaded: url_helper
INFO - 2016-09-22 10:06:20 --> Helper loaded: language_helper
INFO - 2016-09-22 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:06:20 --> Controller Class Initialized
INFO - 2016-09-22 10:06:20 --> Database Driver Class Initialized
INFO - 2016-09-22 10:06:20 --> Model Class Initialized
INFO - 2016-09-22 10:06:20 --> Model Class Initialized
INFO - 2016-09-22 10:06:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:06:20 --> Config Class Initialized
INFO - 2016-09-22 10:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:06:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:06:20 --> Utf8 Class Initialized
INFO - 2016-09-22 10:06:20 --> URI Class Initialized
INFO - 2016-09-22 10:06:20 --> Router Class Initialized
INFO - 2016-09-22 10:06:20 --> Output Class Initialized
INFO - 2016-09-22 10:06:20 --> Security Class Initialized
DEBUG - 2016-09-22 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:06:20 --> Input Class Initialized
INFO - 2016-09-22 10:06:20 --> Language Class Initialized
INFO - 2016-09-22 10:06:20 --> Loader Class Initialized
INFO - 2016-09-22 10:06:20 --> Helper loaded: url_helper
INFO - 2016-09-22 10:06:20 --> Helper loaded: language_helper
INFO - 2016-09-22 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:06:20 --> Controller Class Initialized
INFO - 2016-09-22 10:06:20 --> Database Driver Class Initialized
INFO - 2016-09-22 10:06:20 --> Model Class Initialized
INFO - 2016-09-22 10:06:20 --> Model Class Initialized
INFO - 2016-09-22 10:06:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:06:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:06:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 10:06:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:06:20 --> Final output sent to browser
DEBUG - 2016-09-22 10:06:20 --> Total execution time: 0.0688
INFO - 2016-09-22 10:06:24 --> Config Class Initialized
INFO - 2016-09-22 10:06:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:06:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:06:24 --> Utf8 Class Initialized
INFO - 2016-09-22 10:06:24 --> URI Class Initialized
INFO - 2016-09-22 10:06:24 --> Router Class Initialized
INFO - 2016-09-22 10:06:24 --> Output Class Initialized
INFO - 2016-09-22 10:06:24 --> Security Class Initialized
DEBUG - 2016-09-22 10:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:06:24 --> Input Class Initialized
INFO - 2016-09-22 10:06:24 --> Language Class Initialized
INFO - 2016-09-22 10:06:24 --> Loader Class Initialized
INFO - 2016-09-22 10:06:24 --> Helper loaded: url_helper
INFO - 2016-09-22 10:06:24 --> Helper loaded: language_helper
INFO - 2016-09-22 10:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:06:24 --> Controller Class Initialized
INFO - 2016-09-22 10:06:24 --> Database Driver Class Initialized
INFO - 2016-09-22 10:06:24 --> Model Class Initialized
INFO - 2016-09-22 10:06:24 --> Model Class Initialized
INFO - 2016-09-22 10:06:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:06:24 --> Final output sent to browser
DEBUG - 2016-09-22 10:06:24 --> Total execution time: 0.0619
INFO - 2016-09-22 10:07:52 --> Config Class Initialized
INFO - 2016-09-22 10:07:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:07:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:07:52 --> Utf8 Class Initialized
INFO - 2016-09-22 10:07:52 --> URI Class Initialized
INFO - 2016-09-22 10:07:52 --> Router Class Initialized
INFO - 2016-09-22 10:07:52 --> Output Class Initialized
INFO - 2016-09-22 10:07:52 --> Security Class Initialized
DEBUG - 2016-09-22 10:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:07:52 --> Input Class Initialized
INFO - 2016-09-22 10:07:52 --> Language Class Initialized
INFO - 2016-09-22 10:07:52 --> Loader Class Initialized
INFO - 2016-09-22 10:07:52 --> Helper loaded: url_helper
INFO - 2016-09-22 10:07:52 --> Helper loaded: language_helper
INFO - 2016-09-22 10:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:07:52 --> Controller Class Initialized
INFO - 2016-09-22 10:07:52 --> Database Driver Class Initialized
INFO - 2016-09-22 10:07:52 --> Model Class Initialized
INFO - 2016-09-22 10:07:52 --> Model Class Initialized
INFO - 2016-09-22 10:07:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:07:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:07:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:07:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:07:52 --> Final output sent to browser
DEBUG - 2016-09-22 10:07:52 --> Total execution time: 0.0608
INFO - 2016-09-22 10:09:45 --> Config Class Initialized
INFO - 2016-09-22 10:09:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:09:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:09:45 --> Utf8 Class Initialized
INFO - 2016-09-22 10:09:45 --> URI Class Initialized
INFO - 2016-09-22 10:09:45 --> Router Class Initialized
INFO - 2016-09-22 10:09:45 --> Output Class Initialized
INFO - 2016-09-22 10:09:45 --> Security Class Initialized
DEBUG - 2016-09-22 10:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:09:45 --> Input Class Initialized
INFO - 2016-09-22 10:09:45 --> Language Class Initialized
INFO - 2016-09-22 10:09:45 --> Loader Class Initialized
INFO - 2016-09-22 10:09:45 --> Helper loaded: url_helper
INFO - 2016-09-22 10:09:45 --> Helper loaded: language_helper
INFO - 2016-09-22 10:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:09:45 --> Controller Class Initialized
INFO - 2016-09-22 10:09:45 --> Database Driver Class Initialized
INFO - 2016-09-22 10:09:45 --> Model Class Initialized
INFO - 2016-09-22 10:09:45 --> Model Class Initialized
INFO - 2016-09-22 10:09:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:09:45 --> Final output sent to browser
DEBUG - 2016-09-22 10:09:45 --> Total execution time: 0.0636
INFO - 2016-09-22 10:09:46 --> Config Class Initialized
INFO - 2016-09-22 10:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:09:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:09:46 --> Utf8 Class Initialized
INFO - 2016-09-22 10:09:46 --> URI Class Initialized
INFO - 2016-09-22 10:09:46 --> Router Class Initialized
INFO - 2016-09-22 10:09:46 --> Output Class Initialized
INFO - 2016-09-22 10:09:46 --> Security Class Initialized
DEBUG - 2016-09-22 10:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:09:46 --> Input Class Initialized
INFO - 2016-09-22 10:09:46 --> Language Class Initialized
INFO - 2016-09-22 10:09:46 --> Loader Class Initialized
INFO - 2016-09-22 10:09:46 --> Helper loaded: url_helper
INFO - 2016-09-22 10:09:46 --> Helper loaded: language_helper
INFO - 2016-09-22 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:09:46 --> Controller Class Initialized
INFO - 2016-09-22 10:09:46 --> Database Driver Class Initialized
INFO - 2016-09-22 10:09:46 --> Model Class Initialized
INFO - 2016-09-22 10:09:46 --> Model Class Initialized
INFO - 2016-09-22 10:09:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:09:46 --> Config Class Initialized
INFO - 2016-09-22 10:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:09:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:09:46 --> Utf8 Class Initialized
INFO - 2016-09-22 10:09:46 --> URI Class Initialized
INFO - 2016-09-22 10:09:46 --> Router Class Initialized
INFO - 2016-09-22 10:09:46 --> Output Class Initialized
INFO - 2016-09-22 10:09:46 --> Security Class Initialized
DEBUG - 2016-09-22 10:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:09:46 --> Input Class Initialized
INFO - 2016-09-22 10:09:46 --> Language Class Initialized
INFO - 2016-09-22 10:09:46 --> Loader Class Initialized
INFO - 2016-09-22 10:09:46 --> Helper loaded: url_helper
INFO - 2016-09-22 10:09:46 --> Helper loaded: language_helper
INFO - 2016-09-22 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:09:46 --> Controller Class Initialized
INFO - 2016-09-22 10:09:46 --> Database Driver Class Initialized
INFO - 2016-09-22 10:09:46 --> Model Class Initialized
INFO - 2016-09-22 10:09:46 --> Model Class Initialized
INFO - 2016-09-22 10:09:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:09:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:09:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 10:09:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:09:46 --> Final output sent to browser
DEBUG - 2016-09-22 10:09:46 --> Total execution time: 0.0667
INFO - 2016-09-22 10:10:39 --> Config Class Initialized
INFO - 2016-09-22 10:10:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:10:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:10:39 --> Utf8 Class Initialized
INFO - 2016-09-22 10:10:39 --> URI Class Initialized
INFO - 2016-09-22 10:10:39 --> Router Class Initialized
INFO - 2016-09-22 10:10:39 --> Output Class Initialized
INFO - 2016-09-22 10:10:39 --> Security Class Initialized
DEBUG - 2016-09-22 10:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:10:39 --> Input Class Initialized
INFO - 2016-09-22 10:10:39 --> Language Class Initialized
INFO - 2016-09-22 10:10:39 --> Loader Class Initialized
INFO - 2016-09-22 10:10:39 --> Helper loaded: url_helper
INFO - 2016-09-22 10:10:39 --> Helper loaded: language_helper
INFO - 2016-09-22 10:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:10:39 --> Controller Class Initialized
INFO - 2016-09-22 10:10:40 --> Database Driver Class Initialized
INFO - 2016-09-22 10:10:40 --> Model Class Initialized
INFO - 2016-09-22 10:10:40 --> Model Class Initialized
INFO - 2016-09-22 10:10:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:10:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:10:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 10:10:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:10:40 --> Final output sent to browser
DEBUG - 2016-09-22 10:10:40 --> Total execution time: 0.0595
INFO - 2016-09-22 10:10:41 --> Config Class Initialized
INFO - 2016-09-22 10:10:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:10:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:10:41 --> Utf8 Class Initialized
INFO - 2016-09-22 10:10:41 --> URI Class Initialized
INFO - 2016-09-22 10:10:41 --> Router Class Initialized
INFO - 2016-09-22 10:10:41 --> Output Class Initialized
INFO - 2016-09-22 10:10:41 --> Security Class Initialized
DEBUG - 2016-09-22 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:10:41 --> Input Class Initialized
INFO - 2016-09-22 10:10:41 --> Language Class Initialized
INFO - 2016-09-22 10:10:41 --> Loader Class Initialized
INFO - 2016-09-22 10:10:41 --> Helper loaded: url_helper
INFO - 2016-09-22 10:10:41 --> Helper loaded: language_helper
INFO - 2016-09-22 10:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:10:41 --> Controller Class Initialized
INFO - 2016-09-22 10:10:41 --> Database Driver Class Initialized
INFO - 2016-09-22 10:10:41 --> Model Class Initialized
INFO - 2016-09-22 10:10:41 --> Model Class Initialized
INFO - 2016-09-22 10:10:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:10:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:10:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 10:10:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:10:41 --> Final output sent to browser
DEBUG - 2016-09-22 10:10:41 --> Total execution time: 0.0676
INFO - 2016-09-22 10:13:46 --> Config Class Initialized
INFO - 2016-09-22 10:13:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:13:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:13:46 --> Utf8 Class Initialized
INFO - 2016-09-22 10:13:46 --> URI Class Initialized
INFO - 2016-09-22 10:13:46 --> Router Class Initialized
INFO - 2016-09-22 10:13:46 --> Output Class Initialized
INFO - 2016-09-22 10:13:46 --> Security Class Initialized
DEBUG - 2016-09-22 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:13:46 --> Input Class Initialized
INFO - 2016-09-22 10:13:46 --> Language Class Initialized
INFO - 2016-09-22 10:13:46 --> Loader Class Initialized
INFO - 2016-09-22 10:13:46 --> Helper loaded: url_helper
INFO - 2016-09-22 10:13:46 --> Helper loaded: language_helper
INFO - 2016-09-22 10:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:13:46 --> Controller Class Initialized
INFO - 2016-09-22 10:13:46 --> Database Driver Class Initialized
INFO - 2016-09-22 10:13:46 --> Model Class Initialized
INFO - 2016-09-22 10:13:46 --> Model Class Initialized
INFO - 2016-09-22 10:13:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 10:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:13:46 --> Final output sent to browser
DEBUG - 2016-09-22 10:13:46 --> Total execution time: 0.0605
INFO - 2016-09-22 10:13:53 --> Config Class Initialized
INFO - 2016-09-22 10:13:53 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:13:53 --> Utf8 Class Initialized
INFO - 2016-09-22 10:13:53 --> URI Class Initialized
INFO - 2016-09-22 10:13:53 --> Router Class Initialized
INFO - 2016-09-22 10:13:53 --> Output Class Initialized
INFO - 2016-09-22 10:13:53 --> Security Class Initialized
DEBUG - 2016-09-22 10:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:13:53 --> Input Class Initialized
INFO - 2016-09-22 10:13:53 --> Language Class Initialized
INFO - 2016-09-22 10:13:53 --> Loader Class Initialized
INFO - 2016-09-22 10:13:53 --> Helper loaded: url_helper
INFO - 2016-09-22 10:13:53 --> Helper loaded: language_helper
INFO - 2016-09-22 10:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:13:53 --> Controller Class Initialized
INFO - 2016-09-22 10:13:53 --> Database Driver Class Initialized
INFO - 2016-09-22 10:13:53 --> Model Class Initialized
INFO - 2016-09-22 10:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:13:53 --> Config Class Initialized
INFO - 2016-09-22 10:13:53 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:13:53 --> Utf8 Class Initialized
INFO - 2016-09-22 10:13:53 --> URI Class Initialized
INFO - 2016-09-22 10:13:53 --> Router Class Initialized
INFO - 2016-09-22 10:13:53 --> Output Class Initialized
INFO - 2016-09-22 10:13:53 --> Security Class Initialized
DEBUG - 2016-09-22 10:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:13:53 --> Input Class Initialized
INFO - 2016-09-22 10:13:53 --> Language Class Initialized
INFO - 2016-09-22 10:13:53 --> Loader Class Initialized
INFO - 2016-09-22 10:13:53 --> Helper loaded: url_helper
INFO - 2016-09-22 10:13:53 --> Helper loaded: language_helper
INFO - 2016-09-22 10:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:13:53 --> Controller Class Initialized
INFO - 2016-09-22 10:13:53 --> Database Driver Class Initialized
INFO - 2016-09-22 10:13:53 --> Model Class Initialized
INFO - 2016-09-22 10:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:13:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-22 10:13:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-22 10:13:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-22 10:13:53 --> Final output sent to browser
DEBUG - 2016-09-22 10:13:53 --> Total execution time: 0.0506
INFO - 2016-09-22 10:13:58 --> Config Class Initialized
INFO - 2016-09-22 10:13:58 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:13:58 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:13:58 --> Utf8 Class Initialized
INFO - 2016-09-22 10:13:58 --> URI Class Initialized
INFO - 2016-09-22 10:13:58 --> Router Class Initialized
INFO - 2016-09-22 10:13:58 --> Output Class Initialized
INFO - 2016-09-22 10:13:58 --> Security Class Initialized
DEBUG - 2016-09-22 10:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:13:58 --> Input Class Initialized
INFO - 2016-09-22 10:13:58 --> Language Class Initialized
INFO - 2016-09-22 10:13:58 --> Loader Class Initialized
INFO - 2016-09-22 10:13:58 --> Helper loaded: url_helper
INFO - 2016-09-22 10:13:58 --> Helper loaded: language_helper
INFO - 2016-09-22 10:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:13:58 --> Controller Class Initialized
INFO - 2016-09-22 10:13:58 --> Database Driver Class Initialized
INFO - 2016-09-22 10:13:58 --> Model Class Initialized
INFO - 2016-09-22 10:13:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:13:59 --> Config Class Initialized
INFO - 2016-09-22 10:13:59 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:13:59 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:13:59 --> Utf8 Class Initialized
INFO - 2016-09-22 10:13:59 --> URI Class Initialized
INFO - 2016-09-22 10:13:59 --> Router Class Initialized
INFO - 2016-09-22 10:13:59 --> Output Class Initialized
INFO - 2016-09-22 10:13:59 --> Security Class Initialized
DEBUG - 2016-09-22 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:13:59 --> Input Class Initialized
INFO - 2016-09-22 10:13:59 --> Language Class Initialized
INFO - 2016-09-22 10:13:59 --> Loader Class Initialized
INFO - 2016-09-22 10:13:59 --> Helper loaded: url_helper
INFO - 2016-09-22 10:13:59 --> Helper loaded: language_helper
INFO - 2016-09-22 10:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:13:59 --> Controller Class Initialized
INFO - 2016-09-22 10:13:59 --> Database Driver Class Initialized
INFO - 2016-09-22 10:13:59 --> Model Class Initialized
INFO - 2016-09-22 10:13:59 --> Model Class Initialized
INFO - 2016-09-22 10:13:59 --> Model Class Initialized
INFO - 2016-09-22 10:13:59 --> Model Class Initialized
INFO - 2016-09-22 10:13:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:13:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:13:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-22 10:13:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:13:59 --> Final output sent to browser
DEBUG - 2016-09-22 10:13:59 --> Total execution time: 0.0667
INFO - 2016-09-22 10:14:00 --> Config Class Initialized
INFO - 2016-09-22 10:14:00 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:14:00 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:14:00 --> Utf8 Class Initialized
INFO - 2016-09-22 10:14:00 --> URI Class Initialized
INFO - 2016-09-22 10:14:00 --> Router Class Initialized
INFO - 2016-09-22 10:14:00 --> Output Class Initialized
INFO - 2016-09-22 10:14:00 --> Security Class Initialized
DEBUG - 2016-09-22 10:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:14:00 --> Input Class Initialized
INFO - 2016-09-22 10:14:00 --> Language Class Initialized
INFO - 2016-09-22 10:14:00 --> Loader Class Initialized
INFO - 2016-09-22 10:14:00 --> Helper loaded: url_helper
INFO - 2016-09-22 10:14:00 --> Helper loaded: language_helper
INFO - 2016-09-22 10:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:14:00 --> Controller Class Initialized
INFO - 2016-09-22 10:14:00 --> Database Driver Class Initialized
INFO - 2016-09-22 10:14:00 --> Model Class Initialized
INFO - 2016-09-22 10:14:00 --> Model Class Initialized
INFO - 2016-09-22 10:14:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:14:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:14:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 10:14:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:14:00 --> Final output sent to browser
DEBUG - 2016-09-22 10:14:00 --> Total execution time: 0.0693
INFO - 2016-09-22 10:14:04 --> Config Class Initialized
INFO - 2016-09-22 10:14:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:14:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:14:04 --> Utf8 Class Initialized
INFO - 2016-09-22 10:14:04 --> URI Class Initialized
INFO - 2016-09-22 10:14:04 --> Router Class Initialized
INFO - 2016-09-22 10:14:04 --> Output Class Initialized
INFO - 2016-09-22 10:14:04 --> Security Class Initialized
DEBUG - 2016-09-22 10:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:14:04 --> Input Class Initialized
INFO - 2016-09-22 10:14:04 --> Language Class Initialized
INFO - 2016-09-22 10:14:04 --> Loader Class Initialized
INFO - 2016-09-22 10:14:04 --> Helper loaded: url_helper
INFO - 2016-09-22 10:14:04 --> Helper loaded: language_helper
INFO - 2016-09-22 10:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:14:04 --> Controller Class Initialized
INFO - 2016-09-22 10:14:04 --> Database Driver Class Initialized
INFO - 2016-09-22 10:14:04 --> Model Class Initialized
INFO - 2016-09-22 10:14:04 --> Model Class Initialized
INFO - 2016-09-22 10:14:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:14:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:14:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:14:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:14:04 --> Final output sent to browser
DEBUG - 2016-09-22 10:14:04 --> Total execution time: 0.0571
INFO - 2016-09-22 10:14:07 --> Config Class Initialized
INFO - 2016-09-22 10:14:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:14:07 --> Utf8 Class Initialized
INFO - 2016-09-22 10:14:07 --> URI Class Initialized
INFO - 2016-09-22 10:14:07 --> Router Class Initialized
INFO - 2016-09-22 10:14:07 --> Output Class Initialized
INFO - 2016-09-22 10:14:07 --> Security Class Initialized
DEBUG - 2016-09-22 10:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:14:07 --> Input Class Initialized
INFO - 2016-09-22 10:14:07 --> Language Class Initialized
INFO - 2016-09-22 10:14:07 --> Loader Class Initialized
INFO - 2016-09-22 10:14:07 --> Helper loaded: url_helper
INFO - 2016-09-22 10:14:07 --> Helper loaded: language_helper
INFO - 2016-09-22 10:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:14:07 --> Controller Class Initialized
INFO - 2016-09-22 10:14:07 --> Database Driver Class Initialized
INFO - 2016-09-22 10:14:07 --> Model Class Initialized
INFO - 2016-09-22 10:14:07 --> Model Class Initialized
INFO - 2016-09-22 10:14:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:14:07 --> Config Class Initialized
INFO - 2016-09-22 10:14:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:14:07 --> Utf8 Class Initialized
INFO - 2016-09-22 10:14:07 --> URI Class Initialized
INFO - 2016-09-22 10:14:07 --> Router Class Initialized
INFO - 2016-09-22 10:14:07 --> Output Class Initialized
INFO - 2016-09-22 10:14:07 --> Security Class Initialized
DEBUG - 2016-09-22 10:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:14:07 --> Input Class Initialized
INFO - 2016-09-22 10:14:07 --> Language Class Initialized
INFO - 2016-09-22 10:14:07 --> Loader Class Initialized
INFO - 2016-09-22 10:14:07 --> Helper loaded: url_helper
INFO - 2016-09-22 10:14:07 --> Helper loaded: language_helper
INFO - 2016-09-22 10:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:14:07 --> Controller Class Initialized
INFO - 2016-09-22 10:14:07 --> Database Driver Class Initialized
INFO - 2016-09-22 10:14:07 --> Model Class Initialized
INFO - 2016-09-22 10:14:07 --> Model Class Initialized
INFO - 2016-09-22 10:14:07 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 10:14:07 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\database\DB_query_builder.php 669
ERROR - 2016-09-22 10:14:07 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `savsoft_quiz`
WHERE `quid` = `Array`
INFO - 2016-09-22 10:14:07 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 10:15:00 --> Config Class Initialized
INFO - 2016-09-22 10:15:00 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:15:00 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:15:00 --> Utf8 Class Initialized
INFO - 2016-09-22 10:15:00 --> URI Class Initialized
INFO - 2016-09-22 10:15:00 --> Router Class Initialized
INFO - 2016-09-22 10:15:00 --> Output Class Initialized
INFO - 2016-09-22 10:15:00 --> Security Class Initialized
DEBUG - 2016-09-22 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:15:00 --> Input Class Initialized
INFO - 2016-09-22 10:15:00 --> Language Class Initialized
INFO - 2016-09-22 10:15:00 --> Loader Class Initialized
INFO - 2016-09-22 10:15:00 --> Helper loaded: url_helper
INFO - 2016-09-22 10:15:00 --> Helper loaded: language_helper
INFO - 2016-09-22 10:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:15:00 --> Controller Class Initialized
INFO - 2016-09-22 10:15:00 --> Database Driver Class Initialized
INFO - 2016-09-22 10:15:00 --> Model Class Initialized
INFO - 2016-09-22 10:15:00 --> Model Class Initialized
INFO - 2016-09-22 10:15:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:15:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:15:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 10:15:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:15:00 --> Final output sent to browser
DEBUG - 2016-09-22 10:15:00 --> Total execution time: 0.0763
INFO - 2016-09-22 10:16:21 --> Config Class Initialized
INFO - 2016-09-22 10:16:21 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:16:21 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:16:21 --> Utf8 Class Initialized
INFO - 2016-09-22 10:16:21 --> URI Class Initialized
INFO - 2016-09-22 10:16:21 --> Router Class Initialized
INFO - 2016-09-22 10:16:21 --> Output Class Initialized
INFO - 2016-09-22 10:16:21 --> Security Class Initialized
DEBUG - 2016-09-22 10:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:16:21 --> Input Class Initialized
INFO - 2016-09-22 10:16:21 --> Language Class Initialized
INFO - 2016-09-22 10:16:21 --> Loader Class Initialized
INFO - 2016-09-22 10:16:21 --> Helper loaded: url_helper
INFO - 2016-09-22 10:16:21 --> Helper loaded: language_helper
INFO - 2016-09-22 10:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:16:21 --> Controller Class Initialized
INFO - 2016-09-22 10:16:21 --> Database Driver Class Initialized
INFO - 2016-09-22 10:16:21 --> Model Class Initialized
INFO - 2016-09-22 10:16:21 --> Model Class Initialized
INFO - 2016-09-22 10:16:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 10:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:16:21 --> Final output sent to browser
DEBUG - 2016-09-22 10:16:21 --> Total execution time: 0.0670
INFO - 2016-09-22 10:17:37 --> Config Class Initialized
INFO - 2016-09-22 10:17:37 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:17:37 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:17:37 --> Utf8 Class Initialized
INFO - 2016-09-22 10:17:37 --> URI Class Initialized
INFO - 2016-09-22 10:17:37 --> Router Class Initialized
INFO - 2016-09-22 10:17:37 --> Output Class Initialized
INFO - 2016-09-22 10:17:37 --> Security Class Initialized
DEBUG - 2016-09-22 10:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:17:37 --> Input Class Initialized
INFO - 2016-09-22 10:17:37 --> Language Class Initialized
INFO - 2016-09-22 10:17:37 --> Loader Class Initialized
INFO - 2016-09-22 10:17:37 --> Helper loaded: url_helper
INFO - 2016-09-22 10:17:37 --> Helper loaded: language_helper
INFO - 2016-09-22 10:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:17:37 --> Controller Class Initialized
INFO - 2016-09-22 10:17:37 --> Database Driver Class Initialized
INFO - 2016-09-22 10:17:37 --> Model Class Initialized
INFO - 2016-09-22 10:17:37 --> Model Class Initialized
INFO - 2016-09-22 10:17:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-22 10:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:17:37 --> Final output sent to browser
DEBUG - 2016-09-22 10:17:37 --> Total execution time: 0.0584
INFO - 2016-09-22 10:17:44 --> Config Class Initialized
INFO - 2016-09-22 10:17:44 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:17:44 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:17:44 --> Utf8 Class Initialized
INFO - 2016-09-22 10:17:44 --> URI Class Initialized
INFO - 2016-09-22 10:17:44 --> Router Class Initialized
INFO - 2016-09-22 10:17:44 --> Output Class Initialized
INFO - 2016-09-22 10:17:44 --> Security Class Initialized
DEBUG - 2016-09-22 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:17:44 --> Input Class Initialized
INFO - 2016-09-22 10:17:44 --> Language Class Initialized
INFO - 2016-09-22 10:17:44 --> Loader Class Initialized
INFO - 2016-09-22 10:17:44 --> Helper loaded: url_helper
INFO - 2016-09-22 10:17:44 --> Helper loaded: language_helper
INFO - 2016-09-22 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:17:44 --> Controller Class Initialized
INFO - 2016-09-22 10:17:44 --> Database Driver Class Initialized
INFO - 2016-09-22 10:17:44 --> Model Class Initialized
INFO - 2016-09-22 10:17:44 --> Model Class Initialized
INFO - 2016-09-22 10:17:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:17:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:17:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-09-22 10:17:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:17:44 --> Final output sent to browser
DEBUG - 2016-09-22 10:17:44 --> Total execution time: 0.0574
INFO - 2016-09-22 10:17:53 --> Config Class Initialized
INFO - 2016-09-22 10:17:53 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:17:53 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:17:53 --> Utf8 Class Initialized
INFO - 2016-09-22 10:17:53 --> URI Class Initialized
INFO - 2016-09-22 10:17:53 --> Router Class Initialized
INFO - 2016-09-22 10:17:53 --> Output Class Initialized
INFO - 2016-09-22 10:17:53 --> Security Class Initialized
DEBUG - 2016-09-22 10:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:17:53 --> Input Class Initialized
INFO - 2016-09-22 10:17:53 --> Language Class Initialized
INFO - 2016-09-22 10:17:53 --> Loader Class Initialized
INFO - 2016-09-22 10:17:53 --> Helper loaded: url_helper
INFO - 2016-09-22 10:17:53 --> Helper loaded: language_helper
INFO - 2016-09-22 10:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:17:53 --> Controller Class Initialized
INFO - 2016-09-22 10:17:53 --> Database Driver Class Initialized
INFO - 2016-09-22 10:17:53 --> Model Class Initialized
INFO - 2016-09-22 10:17:53 --> Model Class Initialized
INFO - 2016-09-22 10:17:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:17:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:17:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2016-09-22 10:17:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:17:53 --> Final output sent to browser
DEBUG - 2016-09-22 10:17:53 --> Total execution time: 0.0613
INFO - 2016-09-22 10:18:00 --> Config Class Initialized
INFO - 2016-09-22 10:18:00 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:18:00 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:18:00 --> Utf8 Class Initialized
INFO - 2016-09-22 10:18:00 --> URI Class Initialized
INFO - 2016-09-22 10:18:00 --> Router Class Initialized
INFO - 2016-09-22 10:18:00 --> Output Class Initialized
INFO - 2016-09-22 10:18:00 --> Security Class Initialized
DEBUG - 2016-09-22 10:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:18:00 --> Input Class Initialized
INFO - 2016-09-22 10:18:00 --> Language Class Initialized
INFO - 2016-09-22 10:18:00 --> Loader Class Initialized
INFO - 2016-09-22 10:18:00 --> Helper loaded: url_helper
INFO - 2016-09-22 10:18:00 --> Helper loaded: language_helper
INFO - 2016-09-22 10:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:18:00 --> Controller Class Initialized
INFO - 2016-09-22 10:18:00 --> Database Driver Class Initialized
INFO - 2016-09-22 10:18:00 --> Model Class Initialized
INFO - 2016-09-22 10:18:00 --> Model Class Initialized
INFO - 2016-09-22 10:18:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:18:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:18:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2016-09-22 10:18:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:18:00 --> Final output sent to browser
DEBUG - 2016-09-22 10:18:00 --> Total execution time: 0.0606
INFO - 2016-09-22 10:18:03 --> Config Class Initialized
INFO - 2016-09-22 10:18:03 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:18:03 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:18:03 --> Utf8 Class Initialized
INFO - 2016-09-22 10:18:03 --> URI Class Initialized
INFO - 2016-09-22 10:18:03 --> Router Class Initialized
INFO - 2016-09-22 10:18:03 --> Output Class Initialized
INFO - 2016-09-22 10:18:03 --> Security Class Initialized
DEBUG - 2016-09-22 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:18:03 --> Input Class Initialized
INFO - 2016-09-22 10:18:03 --> Language Class Initialized
INFO - 2016-09-22 10:18:03 --> Loader Class Initialized
INFO - 2016-09-22 10:18:03 --> Helper loaded: url_helper
INFO - 2016-09-22 10:18:03 --> Helper loaded: language_helper
INFO - 2016-09-22 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:18:03 --> Controller Class Initialized
INFO - 2016-09-22 10:18:03 --> Database Driver Class Initialized
INFO - 2016-09-22 10:18:03 --> Model Class Initialized
INFO - 2016-09-22 10:18:03 --> Model Class Initialized
INFO - 2016-09-22 10:18:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:18:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:18:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 10:18:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:18:03 --> Final output sent to browser
DEBUG - 2016-09-22 10:18:03 --> Total execution time: 0.0552
INFO - 2016-09-22 10:18:04 --> Config Class Initialized
INFO - 2016-09-22 10:18:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:18:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:18:04 --> Utf8 Class Initialized
INFO - 2016-09-22 10:18:04 --> URI Class Initialized
INFO - 2016-09-22 10:18:04 --> Router Class Initialized
INFO - 2016-09-22 10:18:04 --> Output Class Initialized
INFO - 2016-09-22 10:18:04 --> Security Class Initialized
DEBUG - 2016-09-22 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:18:04 --> Input Class Initialized
INFO - 2016-09-22 10:18:04 --> Language Class Initialized
INFO - 2016-09-22 10:18:04 --> Loader Class Initialized
INFO - 2016-09-22 10:18:04 --> Helper loaded: url_helper
INFO - 2016-09-22 10:18:04 --> Helper loaded: language_helper
INFO - 2016-09-22 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:18:04 --> Controller Class Initialized
INFO - 2016-09-22 10:18:04 --> Database Driver Class Initialized
INFO - 2016-09-22 10:18:04 --> Model Class Initialized
INFO - 2016-09-22 10:18:04 --> Model Class Initialized
INFO - 2016-09-22 10:18:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:18:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:18:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2016-09-22 10:18:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:18:04 --> Final output sent to browser
DEBUG - 2016-09-22 10:18:04 --> Total execution time: 0.0668
INFO - 2016-09-22 10:18:11 --> Config Class Initialized
INFO - 2016-09-22 10:18:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:18:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:18:11 --> Utf8 Class Initialized
INFO - 2016-09-22 10:18:11 --> URI Class Initialized
INFO - 2016-09-22 10:18:11 --> Router Class Initialized
INFO - 2016-09-22 10:18:11 --> Output Class Initialized
INFO - 2016-09-22 10:18:11 --> Security Class Initialized
DEBUG - 2016-09-22 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:18:11 --> Input Class Initialized
INFO - 2016-09-22 10:18:11 --> Language Class Initialized
INFO - 2016-09-22 10:18:11 --> Loader Class Initialized
INFO - 2016-09-22 10:18:11 --> Helper loaded: url_helper
INFO - 2016-09-22 10:18:11 --> Helper loaded: language_helper
INFO - 2016-09-22 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:18:11 --> Controller Class Initialized
INFO - 2016-09-22 10:18:11 --> Database Driver Class Initialized
INFO - 2016-09-22 10:18:11 --> Model Class Initialized
INFO - 2016-09-22 10:18:11 --> Model Class Initialized
INFO - 2016-09-22 10:18:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2016-09-22 10:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:18:11 --> Final output sent to browser
DEBUG - 2016-09-22 10:18:11 --> Total execution time: 0.0629
INFO - 2016-09-22 10:18:16 --> Config Class Initialized
INFO - 2016-09-22 10:18:16 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:18:16 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:18:16 --> Utf8 Class Initialized
INFO - 2016-09-22 10:18:16 --> URI Class Initialized
INFO - 2016-09-22 10:18:16 --> Router Class Initialized
INFO - 2016-09-22 10:18:16 --> Output Class Initialized
INFO - 2016-09-22 10:18:16 --> Security Class Initialized
DEBUG - 2016-09-22 10:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:18:16 --> Input Class Initialized
INFO - 2016-09-22 10:18:16 --> Language Class Initialized
INFO - 2016-09-22 10:18:16 --> Loader Class Initialized
INFO - 2016-09-22 10:18:16 --> Helper loaded: url_helper
INFO - 2016-09-22 10:18:16 --> Helper loaded: language_helper
INFO - 2016-09-22 10:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:18:16 --> Controller Class Initialized
INFO - 2016-09-22 10:18:16 --> Database Driver Class Initialized
INFO - 2016-09-22 10:18:16 --> Model Class Initialized
INFO - 2016-09-22 10:18:16 --> Model Class Initialized
INFO - 2016-09-22 10:18:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2016-09-22 10:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:18:16 --> Final output sent to browser
DEBUG - 2016-09-22 10:18:16 --> Total execution time: 0.0610
INFO - 2016-09-22 10:18:24 --> Config Class Initialized
INFO - 2016-09-22 10:18:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 10:18:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 10:18:24 --> Utf8 Class Initialized
INFO - 2016-09-22 10:18:24 --> URI Class Initialized
INFO - 2016-09-22 10:18:24 --> Router Class Initialized
INFO - 2016-09-22 10:18:24 --> Output Class Initialized
INFO - 2016-09-22 10:18:24 --> Security Class Initialized
DEBUG - 2016-09-22 10:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 10:18:24 --> Input Class Initialized
INFO - 2016-09-22 10:18:24 --> Language Class Initialized
INFO - 2016-09-22 10:18:24 --> Loader Class Initialized
INFO - 2016-09-22 10:18:24 --> Helper loaded: url_helper
INFO - 2016-09-22 10:18:24 --> Helper loaded: language_helper
INFO - 2016-09-22 10:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 10:18:24 --> Controller Class Initialized
INFO - 2016-09-22 10:18:24 --> Database Driver Class Initialized
INFO - 2016-09-22 10:18:24 --> Model Class Initialized
INFO - 2016-09-22 10:18:24 --> Model Class Initialized
INFO - 2016-09-22 10:18:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 10:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 10:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-22 10:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 10:18:24 --> Final output sent to browser
DEBUG - 2016-09-22 10:18:24 --> Total execution time: 0.0640
INFO - 2016-09-22 11:33:09 --> Config Class Initialized
INFO - 2016-09-22 11:33:09 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:33:09 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:33:09 --> Utf8 Class Initialized
INFO - 2016-09-22 11:33:09 --> URI Class Initialized
INFO - 2016-09-22 11:33:09 --> Router Class Initialized
INFO - 2016-09-22 11:33:09 --> Output Class Initialized
INFO - 2016-09-22 11:33:09 --> Security Class Initialized
DEBUG - 2016-09-22 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:33:09 --> Input Class Initialized
INFO - 2016-09-22 11:33:09 --> Language Class Initialized
INFO - 2016-09-22 11:33:09 --> Loader Class Initialized
INFO - 2016-09-22 11:33:09 --> Helper loaded: url_helper
INFO - 2016-09-22 11:33:09 --> Helper loaded: language_helper
INFO - 2016-09-22 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:33:09 --> Controller Class Initialized
INFO - 2016-09-22 11:33:09 --> Database Driver Class Initialized
INFO - 2016-09-22 11:33:09 --> Model Class Initialized
INFO - 2016-09-22 11:33:09 --> Model Class Initialized
INFO - 2016-09-22 11:33:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:33:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 11:33:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 11:33:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:33:09 --> Final output sent to browser
DEBUG - 2016-09-22 11:33:09 --> Total execution time: 0.0656
INFO - 2016-09-22 11:36:21 --> Config Class Initialized
INFO - 2016-09-22 11:36:21 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:36:21 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:36:21 --> Utf8 Class Initialized
INFO - 2016-09-22 11:36:21 --> URI Class Initialized
INFO - 2016-09-22 11:36:21 --> Router Class Initialized
INFO - 2016-09-22 11:36:21 --> Output Class Initialized
INFO - 2016-09-22 11:36:21 --> Security Class Initialized
DEBUG - 2016-09-22 11:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:36:21 --> Input Class Initialized
INFO - 2016-09-22 11:36:21 --> Language Class Initialized
INFO - 2016-09-22 11:36:21 --> Loader Class Initialized
INFO - 2016-09-22 11:36:21 --> Helper loaded: url_helper
INFO - 2016-09-22 11:36:21 --> Helper loaded: language_helper
INFO - 2016-09-22 11:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:36:21 --> Controller Class Initialized
INFO - 2016-09-22 11:36:21 --> Database Driver Class Initialized
INFO - 2016-09-22 11:36:21 --> Model Class Initialized
INFO - 2016-09-22 11:36:21 --> Model Class Initialized
INFO - 2016-09-22 11:36:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 11:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:36:21 --> Final output sent to browser
DEBUG - 2016-09-22 11:36:21 --> Total execution time: 0.0655
INFO - 2016-09-22 11:36:24 --> Config Class Initialized
INFO - 2016-09-22 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:36:24 --> Utf8 Class Initialized
INFO - 2016-09-22 11:36:24 --> URI Class Initialized
INFO - 2016-09-22 11:36:24 --> Router Class Initialized
INFO - 2016-09-22 11:36:24 --> Output Class Initialized
INFO - 2016-09-22 11:36:24 --> Security Class Initialized
DEBUG - 2016-09-22 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:36:24 --> Input Class Initialized
INFO - 2016-09-22 11:36:24 --> Language Class Initialized
INFO - 2016-09-22 11:36:24 --> Loader Class Initialized
INFO - 2016-09-22 11:36:24 --> Helper loaded: url_helper
INFO - 2016-09-22 11:36:24 --> Helper loaded: language_helper
INFO - 2016-09-22 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:36:24 --> Controller Class Initialized
INFO - 2016-09-22 11:36:24 --> Database Driver Class Initialized
INFO - 2016-09-22 11:36:24 --> Model Class Initialized
INFO - 2016-09-22 11:36:24 --> Model Class Initialized
INFO - 2016-09-22 11:36:24 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:36:24 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:36:24 --> Final output sent to browser
DEBUG - 2016-09-22 11:36:24 --> Total execution time: 0.0605
INFO - 2016-09-22 11:36:27 --> Config Class Initialized
INFO - 2016-09-22 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:36:27 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:36:27 --> Utf8 Class Initialized
INFO - 2016-09-22 11:36:27 --> URI Class Initialized
INFO - 2016-09-22 11:36:27 --> Router Class Initialized
INFO - 2016-09-22 11:36:27 --> Output Class Initialized
INFO - 2016-09-22 11:36:27 --> Security Class Initialized
DEBUG - 2016-09-22 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:36:27 --> Input Class Initialized
INFO - 2016-09-22 11:36:27 --> Language Class Initialized
INFO - 2016-09-22 11:36:27 --> Loader Class Initialized
INFO - 2016-09-22 11:36:27 --> Helper loaded: url_helper
INFO - 2016-09-22 11:36:27 --> Helper loaded: language_helper
INFO - 2016-09-22 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:36:27 --> Controller Class Initialized
INFO - 2016-09-22 11:36:27 --> Database Driver Class Initialized
INFO - 2016-09-22 11:36:27 --> Model Class Initialized
INFO - 2016-09-22 11:36:27 --> Model Class Initialized
INFO - 2016-09-22 11:36:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:36:27 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:36:27 --> Final output sent to browser
DEBUG - 2016-09-22 11:36:27 --> Total execution time: 0.0538
INFO - 2016-09-22 11:37:23 --> Config Class Initialized
INFO - 2016-09-22 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:37:23 --> Utf8 Class Initialized
INFO - 2016-09-22 11:37:23 --> URI Class Initialized
INFO - 2016-09-22 11:37:23 --> Router Class Initialized
INFO - 2016-09-22 11:37:23 --> Output Class Initialized
INFO - 2016-09-22 11:37:23 --> Security Class Initialized
DEBUG - 2016-09-22 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:37:23 --> Input Class Initialized
INFO - 2016-09-22 11:37:23 --> Language Class Initialized
INFO - 2016-09-22 11:37:23 --> Loader Class Initialized
INFO - 2016-09-22 11:37:23 --> Helper loaded: url_helper
INFO - 2016-09-22 11:37:23 --> Helper loaded: language_helper
INFO - 2016-09-22 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:37:23 --> Controller Class Initialized
INFO - 2016-09-22 11:37:23 --> Database Driver Class Initialized
INFO - 2016-09-22 11:37:23 --> Model Class Initialized
INFO - 2016-09-22 11:37:23 --> Model Class Initialized
INFO - 2016-09-22 11:37:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:37:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:37:23 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 38
ERROR - 2016-09-22 11:37:23 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 39
INFO - 2016-09-22 11:37:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:37:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:37:23 --> Final output sent to browser
DEBUG - 2016-09-22 11:37:23 --> Total execution time: 0.0637
INFO - 2016-09-22 11:37:25 --> Config Class Initialized
INFO - 2016-09-22 11:37:25 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:37:25 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:37:25 --> Utf8 Class Initialized
INFO - 2016-09-22 11:37:25 --> URI Class Initialized
INFO - 2016-09-22 11:37:25 --> Router Class Initialized
INFO - 2016-09-22 11:37:25 --> Output Class Initialized
INFO - 2016-09-22 11:37:25 --> Security Class Initialized
DEBUG - 2016-09-22 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:37:25 --> Input Class Initialized
INFO - 2016-09-22 11:37:25 --> Language Class Initialized
INFO - 2016-09-22 11:37:25 --> Loader Class Initialized
INFO - 2016-09-22 11:37:25 --> Helper loaded: url_helper
INFO - 2016-09-22 11:37:25 --> Helper loaded: language_helper
INFO - 2016-09-22 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:37:25 --> Controller Class Initialized
INFO - 2016-09-22 11:37:25 --> Database Driver Class Initialized
INFO - 2016-09-22 11:37:25 --> Model Class Initialized
INFO - 2016-09-22 11:37:25 --> Model Class Initialized
INFO - 2016-09-22 11:37:25 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:37:25 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:37:25 --> Final output sent to browser
DEBUG - 2016-09-22 11:37:25 --> Total execution time: 0.0620
INFO - 2016-09-22 11:37:29 --> Config Class Initialized
INFO - 2016-09-22 11:37:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:37:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:37:29 --> Utf8 Class Initialized
INFO - 2016-09-22 11:37:29 --> URI Class Initialized
INFO - 2016-09-22 11:37:29 --> Router Class Initialized
INFO - 2016-09-22 11:37:29 --> Output Class Initialized
INFO - 2016-09-22 11:37:29 --> Security Class Initialized
DEBUG - 2016-09-22 11:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:37:29 --> Input Class Initialized
INFO - 2016-09-22 11:37:29 --> Language Class Initialized
INFO - 2016-09-22 11:37:29 --> Loader Class Initialized
INFO - 2016-09-22 11:37:29 --> Helper loaded: url_helper
INFO - 2016-09-22 11:37:29 --> Helper loaded: language_helper
INFO - 2016-09-22 11:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:37:29 --> Controller Class Initialized
INFO - 2016-09-22 11:37:29 --> Database Driver Class Initialized
INFO - 2016-09-22 11:37:29 --> Model Class Initialized
INFO - 2016-09-22 11:37:29 --> Model Class Initialized
INFO - 2016-09-22 11:37:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:37:29 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:37:29 --> Final output sent to browser
DEBUG - 2016-09-22 11:37:29 --> Total execution time: 0.0542
INFO - 2016-09-22 11:38:38 --> Config Class Initialized
INFO - 2016-09-22 11:38:38 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:38:38 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:38:38 --> Utf8 Class Initialized
INFO - 2016-09-22 11:38:38 --> URI Class Initialized
INFO - 2016-09-22 11:38:38 --> Router Class Initialized
INFO - 2016-09-22 11:38:38 --> Output Class Initialized
INFO - 2016-09-22 11:38:38 --> Security Class Initialized
DEBUG - 2016-09-22 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:38:38 --> Input Class Initialized
INFO - 2016-09-22 11:38:38 --> Language Class Initialized
INFO - 2016-09-22 11:38:38 --> Loader Class Initialized
INFO - 2016-09-22 11:38:38 --> Helper loaded: url_helper
INFO - 2016-09-22 11:38:38 --> Helper loaded: language_helper
INFO - 2016-09-22 11:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:38:38 --> Controller Class Initialized
INFO - 2016-09-22 11:38:38 --> Database Driver Class Initialized
INFO - 2016-09-22 11:38:38 --> Model Class Initialized
INFO - 2016-09-22 11:38:38 --> Model Class Initialized
INFO - 2016-09-22 11:38:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:38:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:38:38 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 38
ERROR - 2016-09-22 11:38:38 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 39
ERROR - 2016-09-22 11:38:38 --> Severity: Notice --> Undefined variable: quiz C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 11:38:38 --> Severity: Notice --> Undefined variable: quiz C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 58
ERROR - 2016-09-22 11:38:38 --> Severity: Notice --> Undefined variable: quiz C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
INFO - 2016-09-22 11:38:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:38:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:38:38 --> Final output sent to browser
DEBUG - 2016-09-22 11:38:38 --> Total execution time: 0.0708
INFO - 2016-09-22 11:38:40 --> Config Class Initialized
INFO - 2016-09-22 11:38:40 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:38:40 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:38:40 --> Utf8 Class Initialized
INFO - 2016-09-22 11:38:40 --> URI Class Initialized
INFO - 2016-09-22 11:38:40 --> Router Class Initialized
INFO - 2016-09-22 11:38:40 --> Output Class Initialized
INFO - 2016-09-22 11:38:40 --> Security Class Initialized
DEBUG - 2016-09-22 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:38:40 --> Input Class Initialized
INFO - 2016-09-22 11:38:40 --> Language Class Initialized
INFO - 2016-09-22 11:38:40 --> Loader Class Initialized
INFO - 2016-09-22 11:38:40 --> Helper loaded: url_helper
INFO - 2016-09-22 11:38:40 --> Helper loaded: language_helper
INFO - 2016-09-22 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:38:40 --> Controller Class Initialized
INFO - 2016-09-22 11:38:40 --> Database Driver Class Initialized
INFO - 2016-09-22 11:38:40 --> Model Class Initialized
INFO - 2016-09-22 11:38:40 --> Model Class Initialized
INFO - 2016-09-22 11:38:40 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:38:40 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:38:40 --> Final output sent to browser
DEBUG - 2016-09-22 11:38:40 --> Total execution time: 0.0726
INFO - 2016-09-22 11:38:42 --> Config Class Initialized
INFO - 2016-09-22 11:38:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:38:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:38:42 --> Utf8 Class Initialized
INFO - 2016-09-22 11:38:42 --> URI Class Initialized
INFO - 2016-09-22 11:38:42 --> Router Class Initialized
INFO - 2016-09-22 11:38:42 --> Output Class Initialized
INFO - 2016-09-22 11:38:42 --> Security Class Initialized
DEBUG - 2016-09-22 11:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:38:42 --> Input Class Initialized
INFO - 2016-09-22 11:38:42 --> Language Class Initialized
INFO - 2016-09-22 11:38:42 --> Loader Class Initialized
INFO - 2016-09-22 11:38:42 --> Helper loaded: url_helper
INFO - 2016-09-22 11:38:42 --> Helper loaded: language_helper
INFO - 2016-09-22 11:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:38:42 --> Controller Class Initialized
INFO - 2016-09-22 11:38:42 --> Database Driver Class Initialized
INFO - 2016-09-22 11:38:42 --> Model Class Initialized
INFO - 2016-09-22 11:38:42 --> Model Class Initialized
INFO - 2016-09-22 11:38:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:38:42 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:38:42 --> Final output sent to browser
DEBUG - 2016-09-22 11:38:42 --> Total execution time: 0.0681
INFO - 2016-09-22 11:40:08 --> Config Class Initialized
INFO - 2016-09-22 11:40:08 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:08 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:08 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:08 --> URI Class Initialized
INFO - 2016-09-22 11:40:08 --> Router Class Initialized
INFO - 2016-09-22 11:40:08 --> Output Class Initialized
INFO - 2016-09-22 11:40:08 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:08 --> Input Class Initialized
INFO - 2016-09-22 11:40:08 --> Language Class Initialized
INFO - 2016-09-22 11:40:08 --> Loader Class Initialized
INFO - 2016-09-22 11:40:08 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:08 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:08 --> Controller Class Initialized
INFO - 2016-09-22 11:40:08 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:08 --> Model Class Initialized
INFO - 2016-09-22 11:40:08 --> Model Class Initialized
INFO - 2016-09-22 11:40:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:40:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 38
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 39
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:40:08 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
INFO - 2016-09-22 11:40:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:40:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:40:08 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:08 --> Total execution time: 0.0704
INFO - 2016-09-22 11:40:10 --> Config Class Initialized
INFO - 2016-09-22 11:40:10 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:10 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:10 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:10 --> URI Class Initialized
INFO - 2016-09-22 11:40:10 --> Router Class Initialized
INFO - 2016-09-22 11:40:10 --> Output Class Initialized
INFO - 2016-09-22 11:40:10 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:10 --> Input Class Initialized
INFO - 2016-09-22 11:40:10 --> Language Class Initialized
INFO - 2016-09-22 11:40:10 --> Loader Class Initialized
INFO - 2016-09-22 11:40:10 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:10 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:10 --> Controller Class Initialized
INFO - 2016-09-22 11:40:10 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:10 --> Model Class Initialized
INFO - 2016-09-22 11:40:10 --> Model Class Initialized
INFO - 2016-09-22 11:40:10 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:40:10 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:40:10 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:10 --> Total execution time: 0.0588
INFO - 2016-09-22 11:40:11 --> Config Class Initialized
INFO - 2016-09-22 11:40:11 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:11 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:11 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:11 --> URI Class Initialized
INFO - 2016-09-22 11:40:11 --> Router Class Initialized
INFO - 2016-09-22 11:40:11 --> Output Class Initialized
INFO - 2016-09-22 11:40:11 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:11 --> Input Class Initialized
INFO - 2016-09-22 11:40:11 --> Language Class Initialized
INFO - 2016-09-22 11:40:11 --> Loader Class Initialized
INFO - 2016-09-22 11:40:11 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:11 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:11 --> Controller Class Initialized
INFO - 2016-09-22 11:40:12 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:12 --> Model Class Initialized
INFO - 2016-09-22 11:40:12 --> Model Class Initialized
INFO - 2016-09-22 11:40:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:40:12 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:40:12 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:12 --> Total execution time: 0.0610
INFO - 2016-09-22 11:40:20 --> Config Class Initialized
INFO - 2016-09-22 11:40:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:20 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:20 --> URI Class Initialized
INFO - 2016-09-22 11:40:20 --> Router Class Initialized
INFO - 2016-09-22 11:40:20 --> Output Class Initialized
INFO - 2016-09-22 11:40:20 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:20 --> Input Class Initialized
INFO - 2016-09-22 11:40:20 --> Language Class Initialized
INFO - 2016-09-22 11:40:20 --> Loader Class Initialized
INFO - 2016-09-22 11:40:20 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:20 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:21 --> Controller Class Initialized
INFO - 2016-09-22 11:40:21 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:21 --> Model Class Initialized
INFO - 2016-09-22 11:40:21 --> Model Class Initialized
INFO - 2016-09-22 11:40:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:40:21 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:40:21 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:21 --> Total execution time: 0.0562
INFO - 2016-09-22 11:40:27 --> Config Class Initialized
INFO - 2016-09-22 11:40:27 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:27 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:27 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:27 --> URI Class Initialized
INFO - 2016-09-22 11:40:27 --> Router Class Initialized
INFO - 2016-09-22 11:40:27 --> Output Class Initialized
INFO - 2016-09-22 11:40:27 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:27 --> Input Class Initialized
INFO - 2016-09-22 11:40:27 --> Language Class Initialized
INFO - 2016-09-22 11:40:27 --> Loader Class Initialized
INFO - 2016-09-22 11:40:27 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:27 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:27 --> Controller Class Initialized
INFO - 2016-09-22 11:40:27 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:27 --> Model Class Initialized
INFO - 2016-09-22 11:40:27 --> Model Class Initialized
INFO - 2016-09-22 11:40:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 38
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 39
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:40:27 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
INFO - 2016-09-22 11:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:40:27 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:27 --> Total execution time: 0.0716
INFO - 2016-09-22 11:40:28 --> Config Class Initialized
INFO - 2016-09-22 11:40:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:28 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:28 --> URI Class Initialized
INFO - 2016-09-22 11:40:28 --> Router Class Initialized
INFO - 2016-09-22 11:40:28 --> Output Class Initialized
INFO - 2016-09-22 11:40:28 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:28 --> Input Class Initialized
INFO - 2016-09-22 11:40:28 --> Language Class Initialized
INFO - 2016-09-22 11:40:28 --> Loader Class Initialized
INFO - 2016-09-22 11:40:28 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:28 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:28 --> Controller Class Initialized
INFO - 2016-09-22 11:40:28 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:28 --> Model Class Initialized
INFO - 2016-09-22 11:40:28 --> Model Class Initialized
INFO - 2016-09-22 11:40:28 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:40:28 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:40:28 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:28 --> Total execution time: 0.0672
INFO - 2016-09-22 11:40:30 --> Config Class Initialized
INFO - 2016-09-22 11:40:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:40:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:40:30 --> Utf8 Class Initialized
INFO - 2016-09-22 11:40:30 --> URI Class Initialized
INFO - 2016-09-22 11:40:30 --> Router Class Initialized
INFO - 2016-09-22 11:40:30 --> Output Class Initialized
INFO - 2016-09-22 11:40:30 --> Security Class Initialized
DEBUG - 2016-09-22 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:40:30 --> Input Class Initialized
INFO - 2016-09-22 11:40:30 --> Language Class Initialized
INFO - 2016-09-22 11:40:30 --> Loader Class Initialized
INFO - 2016-09-22 11:40:30 --> Helper loaded: url_helper
INFO - 2016-09-22 11:40:30 --> Helper loaded: language_helper
INFO - 2016-09-22 11:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:40:30 --> Controller Class Initialized
INFO - 2016-09-22 11:40:30 --> Database Driver Class Initialized
INFO - 2016-09-22 11:40:30 --> Model Class Initialized
INFO - 2016-09-22 11:40:30 --> Model Class Initialized
INFO - 2016-09-22 11:40:30 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:40:30 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 11:40:30 --> Final output sent to browser
DEBUG - 2016-09-22 11:40:30 --> Total execution time: 0.0600
INFO - 2016-09-22 11:43:31 --> Config Class Initialized
INFO - 2016-09-22 11:43:31 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:43:31 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:43:31 --> Utf8 Class Initialized
INFO - 2016-09-22 11:43:31 --> URI Class Initialized
INFO - 2016-09-22 11:43:31 --> Router Class Initialized
INFO - 2016-09-22 11:43:31 --> Output Class Initialized
INFO - 2016-09-22 11:43:31 --> Security Class Initialized
DEBUG - 2016-09-22 11:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:43:31 --> Input Class Initialized
INFO - 2016-09-22 11:43:31 --> Language Class Initialized
INFO - 2016-09-22 11:43:31 --> Loader Class Initialized
INFO - 2016-09-22 11:43:31 --> Helper loaded: url_helper
INFO - 2016-09-22 11:43:31 --> Helper loaded: language_helper
INFO - 2016-09-22 11:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:43:31 --> Controller Class Initialized
INFO - 2016-09-22 11:43:31 --> Database Driver Class Initialized
INFO - 2016-09-22 11:43:31 --> Model Class Initialized
INFO - 2016-09-22 11:43:31 --> Model Class Initialized
INFO - 2016-09-22 11:43:31 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined index: start_time C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 174
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined index: r_qids C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 176
INFO - 2016-09-22 11:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:43:31 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
INFO - 2016-09-22 11:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:43:31 --> Final output sent to browser
DEBUG - 2016-09-22 11:43:31 --> Total execution time: 0.1011
INFO - 2016-09-22 11:43:34 --> Config Class Initialized
INFO - 2016-09-22 11:43:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:43:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:43:34 --> Utf8 Class Initialized
INFO - 2016-09-22 11:43:34 --> URI Class Initialized
INFO - 2016-09-22 11:43:34 --> Router Class Initialized
INFO - 2016-09-22 11:43:34 --> Output Class Initialized
INFO - 2016-09-22 11:43:34 --> Security Class Initialized
DEBUG - 2016-09-22 11:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:43:34 --> Input Class Initialized
INFO - 2016-09-22 11:43:34 --> Language Class Initialized
INFO - 2016-09-22 11:43:34 --> Loader Class Initialized
INFO - 2016-09-22 11:43:34 --> Helper loaded: url_helper
INFO - 2016-09-22 11:43:34 --> Helper loaded: language_helper
INFO - 2016-09-22 11:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:43:34 --> Controller Class Initialized
INFO - 2016-09-22 11:43:34 --> Database Driver Class Initialized
INFO - 2016-09-22 11:43:34 --> Model Class Initialized
INFO - 2016-09-22 11:43:34 --> Model Class Initialized
INFO - 2016-09-22 11:43:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:43:34 --> Severity: Notice --> Undefined property: Ujian::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 441
ERROR - 2016-09-22 11:43:34 --> Severity: error --> Exception: Call to a member function submit_result() on null C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 441
INFO - 2016-09-22 11:44:19 --> Config Class Initialized
INFO - 2016-09-22 11:44:19 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:19 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:19 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:19 --> URI Class Initialized
INFO - 2016-09-22 11:44:19 --> Router Class Initialized
INFO - 2016-09-22 11:44:19 --> Output Class Initialized
INFO - 2016-09-22 11:44:19 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:19 --> Input Class Initialized
INFO - 2016-09-22 11:44:19 --> Language Class Initialized
INFO - 2016-09-22 11:44:19 --> Loader Class Initialized
INFO - 2016-09-22 11:44:19 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:19 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:19 --> Controller Class Initialized
INFO - 2016-09-22 11:44:19 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:19 --> Model Class Initialized
INFO - 2016-09-22 11:44:19 --> Model Class Initialized
INFO - 2016-09-22 11:44:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:44:19 --> Config Class Initialized
INFO - 2016-09-22 11:44:19 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:19 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:19 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:19 --> URI Class Initialized
INFO - 2016-09-22 11:44:19 --> Router Class Initialized
INFO - 2016-09-22 11:44:19 --> Output Class Initialized
INFO - 2016-09-22 11:44:19 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:19 --> Input Class Initialized
INFO - 2016-09-22 11:44:19 --> Language Class Initialized
INFO - 2016-09-22 11:44:19 --> Loader Class Initialized
INFO - 2016-09-22 11:44:19 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:19 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:19 --> Controller Class Initialized
INFO - 2016-09-22 11:44:19 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:19 --> Model Class Initialized
INFO - 2016-09-22 11:44:19 --> Model Class Initialized
INFO - 2016-09-22 11:44:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:44:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 11:44:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-22 11:44:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:44:19 --> Final output sent to browser
DEBUG - 2016-09-22 11:44:19 --> Total execution time: 0.0657
INFO - 2016-09-22 11:44:24 --> Config Class Initialized
INFO - 2016-09-22 11:44:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:24 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:24 --> URI Class Initialized
INFO - 2016-09-22 11:44:24 --> Router Class Initialized
INFO - 2016-09-22 11:44:24 --> Output Class Initialized
INFO - 2016-09-22 11:44:24 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:24 --> Input Class Initialized
INFO - 2016-09-22 11:44:24 --> Language Class Initialized
INFO - 2016-09-22 11:44:24 --> Loader Class Initialized
INFO - 2016-09-22 11:44:24 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:24 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:24 --> Controller Class Initialized
INFO - 2016-09-22 11:44:24 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:24 --> Model Class Initialized
INFO - 2016-09-22 11:44:24 --> Model Class Initialized
INFO - 2016-09-22 11:44:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:44:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 11:44:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 11:44:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:44:24 --> Final output sent to browser
DEBUG - 2016-09-22 11:44:24 --> Total execution time: 0.0690
INFO - 2016-09-22 11:44:29 --> Config Class Initialized
INFO - 2016-09-22 11:44:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:29 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:29 --> URI Class Initialized
INFO - 2016-09-22 11:44:29 --> Router Class Initialized
INFO - 2016-09-22 11:44:29 --> Output Class Initialized
INFO - 2016-09-22 11:44:29 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:29 --> Input Class Initialized
INFO - 2016-09-22 11:44:29 --> Language Class Initialized
INFO - 2016-09-22 11:44:29 --> Loader Class Initialized
INFO - 2016-09-22 11:44:29 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:29 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:29 --> Controller Class Initialized
INFO - 2016-09-22 11:44:29 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:29 --> Model Class Initialized
INFO - 2016-09-22 11:44:29 --> Model Class Initialized
INFO - 2016-09-22 11:44:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined index: start_time C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 174
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined index: r_qids C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 176
INFO - 2016-09-22 11:44:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:44:29 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
INFO - 2016-09-22 11:44:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:44:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:44:29 --> Final output sent to browser
DEBUG - 2016-09-22 11:44:29 --> Total execution time: 0.0748
INFO - 2016-09-22 11:44:31 --> Config Class Initialized
INFO - 2016-09-22 11:44:31 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:31 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:31 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:31 --> URI Class Initialized
INFO - 2016-09-22 11:44:31 --> Router Class Initialized
INFO - 2016-09-22 11:44:31 --> Output Class Initialized
INFO - 2016-09-22 11:44:31 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:31 --> Input Class Initialized
INFO - 2016-09-22 11:44:31 --> Language Class Initialized
INFO - 2016-09-22 11:44:31 --> Loader Class Initialized
INFO - 2016-09-22 11:44:31 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:31 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:31 --> Controller Class Initialized
INFO - 2016-09-22 11:44:31 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:31 --> Model Class Initialized
INFO - 2016-09-22 11:44:31 --> Model Class Initialized
INFO - 2016-09-22 11:44:31 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:44:31 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 11:44:31 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474524871, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 11:44:31 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 11:44:36 --> Config Class Initialized
INFO - 2016-09-22 11:44:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:36 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:36 --> URI Class Initialized
INFO - 2016-09-22 11:44:36 --> Router Class Initialized
INFO - 2016-09-22 11:44:36 --> Output Class Initialized
INFO - 2016-09-22 11:44:36 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:36 --> Input Class Initialized
INFO - 2016-09-22 11:44:36 --> Language Class Initialized
INFO - 2016-09-22 11:44:36 --> Loader Class Initialized
INFO - 2016-09-22 11:44:36 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:36 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:36 --> Controller Class Initialized
INFO - 2016-09-22 11:44:36 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:36 --> Model Class Initialized
INFO - 2016-09-22 11:44:36 --> Model Class Initialized
INFO - 2016-09-22 11:44:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:44:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 11:44:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 11:44:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:44:36 --> Final output sent to browser
DEBUG - 2016-09-22 11:44:36 --> Total execution time: 0.0589
INFO - 2016-09-22 11:44:36 --> Config Class Initialized
INFO - 2016-09-22 11:44:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:36 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:36 --> URI Class Initialized
INFO - 2016-09-22 11:44:36 --> Router Class Initialized
INFO - 2016-09-22 11:44:36 --> Output Class Initialized
INFO - 2016-09-22 11:44:36 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:36 --> Input Class Initialized
INFO - 2016-09-22 11:44:36 --> Language Class Initialized
INFO - 2016-09-22 11:44:36 --> Loader Class Initialized
INFO - 2016-09-22 11:44:36 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:36 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:36 --> Controller Class Initialized
INFO - 2016-09-22 11:44:36 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:36 --> Model Class Initialized
INFO - 2016-09-22 11:44:36 --> Model Class Initialized
INFO - 2016-09-22 11:44:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 11:44:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 11:44:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 11:44:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:44:37 --> Final output sent to browser
DEBUG - 2016-09-22 11:44:37 --> Total execution time: 0.0626
INFO - 2016-09-22 11:44:40 --> Config Class Initialized
INFO - 2016-09-22 11:44:40 --> Hooks Class Initialized
DEBUG - 2016-09-22 11:44:40 --> UTF-8 Support Enabled
INFO - 2016-09-22 11:44:40 --> Utf8 Class Initialized
INFO - 2016-09-22 11:44:40 --> URI Class Initialized
INFO - 2016-09-22 11:44:40 --> Router Class Initialized
INFO - 2016-09-22 11:44:40 --> Output Class Initialized
INFO - 2016-09-22 11:44:40 --> Security Class Initialized
DEBUG - 2016-09-22 11:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 11:44:40 --> Input Class Initialized
INFO - 2016-09-22 11:44:40 --> Language Class Initialized
INFO - 2016-09-22 11:44:40 --> Loader Class Initialized
INFO - 2016-09-22 11:44:40 --> Helper loaded: url_helper
INFO - 2016-09-22 11:44:40 --> Helper loaded: language_helper
INFO - 2016-09-22 11:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 11:44:40 --> Controller Class Initialized
INFO - 2016-09-22 11:44:40 --> Database Driver Class Initialized
INFO - 2016-09-22 11:44:40 --> Model Class Initialized
INFO - 2016-09-22 11:44:40 --> Model Class Initialized
INFO - 2016-09-22 11:44:40 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined index: start_time C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 174
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined index: r_qids C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 176
INFO - 2016-09-22 11:44:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
ERROR - 2016-09-22 11:44:40 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 60
INFO - 2016-09-22 11:44:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 11:44:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 11:44:40 --> Final output sent to browser
DEBUG - 2016-09-22 11:44:40 --> Total execution time: 0.0759
INFO - 2016-09-22 12:03:24 --> Config Class Initialized
INFO - 2016-09-22 12:03:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:03:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:03:24 --> Utf8 Class Initialized
INFO - 2016-09-22 12:03:24 --> URI Class Initialized
INFO - 2016-09-22 12:03:24 --> Router Class Initialized
INFO - 2016-09-22 12:03:24 --> Output Class Initialized
INFO - 2016-09-22 12:03:24 --> Security Class Initialized
DEBUG - 2016-09-22 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:03:24 --> Input Class Initialized
INFO - 2016-09-22 12:03:24 --> Language Class Initialized
INFO - 2016-09-22 12:03:24 --> Loader Class Initialized
INFO - 2016-09-22 12:03:24 --> Helper loaded: url_helper
INFO - 2016-09-22 12:03:24 --> Helper loaded: language_helper
INFO - 2016-09-22 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:03:24 --> Controller Class Initialized
INFO - 2016-09-22 12:03:24 --> Database Driver Class Initialized
INFO - 2016-09-22 12:03:24 --> Model Class Initialized
INFO - 2016-09-22 12:03:24 --> Model Class Initialized
INFO - 2016-09-22 12:03:24 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:03:24 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:03:24 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526004, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:03:24 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:03:30 --> Config Class Initialized
INFO - 2016-09-22 12:03:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:03:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:03:30 --> Utf8 Class Initialized
INFO - 2016-09-22 12:03:30 --> URI Class Initialized
INFO - 2016-09-22 12:03:30 --> Router Class Initialized
INFO - 2016-09-22 12:03:30 --> Output Class Initialized
INFO - 2016-09-22 12:03:30 --> Security Class Initialized
DEBUG - 2016-09-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:03:30 --> Input Class Initialized
INFO - 2016-09-22 12:03:30 --> Language Class Initialized
INFO - 2016-09-22 12:03:30 --> Loader Class Initialized
INFO - 2016-09-22 12:03:30 --> Helper loaded: url_helper
INFO - 2016-09-22 12:03:30 --> Helper loaded: language_helper
INFO - 2016-09-22 12:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:03:30 --> Controller Class Initialized
INFO - 2016-09-22 12:03:30 --> Database Driver Class Initialized
INFO - 2016-09-22 12:03:30 --> Model Class Initialized
INFO - 2016-09-22 12:03:30 --> Model Class Initialized
INFO - 2016-09-22 12:03:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:03:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:03:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:03:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:03:30 --> Final output sent to browser
DEBUG - 2016-09-22 12:03:30 --> Total execution time: 0.0595
INFO - 2016-09-22 12:03:34 --> Config Class Initialized
INFO - 2016-09-22 12:03:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:03:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:03:34 --> Utf8 Class Initialized
INFO - 2016-09-22 12:03:34 --> URI Class Initialized
INFO - 2016-09-22 12:03:34 --> Router Class Initialized
INFO - 2016-09-22 12:03:34 --> Output Class Initialized
INFO - 2016-09-22 12:03:34 --> Security Class Initialized
DEBUG - 2016-09-22 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:03:34 --> Input Class Initialized
INFO - 2016-09-22 12:03:34 --> Language Class Initialized
INFO - 2016-09-22 12:03:34 --> Loader Class Initialized
INFO - 2016-09-22 12:03:34 --> Helper loaded: url_helper
INFO - 2016-09-22 12:03:34 --> Helper loaded: language_helper
INFO - 2016-09-22 12:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:03:34 --> Controller Class Initialized
INFO - 2016-09-22 12:03:34 --> Database Driver Class Initialized
INFO - 2016-09-22 12:03:34 --> Model Class Initialized
INFO - 2016-09-22 12:03:34 --> Model Class Initialized
INFO - 2016-09-22 12:03:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:03:34 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 184
ERROR - 2016-09-22 12:03:34 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 188
ERROR - 2016-09-22 12:03:34 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 199
ERROR - 2016-09-22 12:03:34 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 200
ERROR - 2016-09-22 12:03:34 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 204
ERROR - 2016-09-22 12:03:34 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:03:34 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526014, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:03:34 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:03:49 --> Config Class Initialized
INFO - 2016-09-22 12:03:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:03:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:03:49 --> Utf8 Class Initialized
INFO - 2016-09-22 12:03:49 --> URI Class Initialized
INFO - 2016-09-22 12:03:49 --> Router Class Initialized
INFO - 2016-09-22 12:03:49 --> Output Class Initialized
INFO - 2016-09-22 12:03:49 --> Security Class Initialized
DEBUG - 2016-09-22 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:03:49 --> Input Class Initialized
INFO - 2016-09-22 12:03:49 --> Language Class Initialized
INFO - 2016-09-22 12:03:49 --> Loader Class Initialized
INFO - 2016-09-22 12:03:49 --> Helper loaded: url_helper
INFO - 2016-09-22 12:03:49 --> Helper loaded: language_helper
INFO - 2016-09-22 12:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:03:49 --> Controller Class Initialized
INFO - 2016-09-22 12:03:49 --> Database Driver Class Initialized
INFO - 2016-09-22 12:03:49 --> Model Class Initialized
INFO - 2016-09-22 12:03:49 --> Model Class Initialized
INFO - 2016-09-22 12:03:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:03:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:03:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:03:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:03:49 --> Final output sent to browser
DEBUG - 2016-09-22 12:03:49 --> Total execution time: 0.0673
INFO - 2016-09-22 12:04:23 --> Config Class Initialized
INFO - 2016-09-22 12:04:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:04:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:04:23 --> Utf8 Class Initialized
INFO - 2016-09-22 12:04:23 --> URI Class Initialized
INFO - 2016-09-22 12:04:23 --> Router Class Initialized
INFO - 2016-09-22 12:04:23 --> Output Class Initialized
INFO - 2016-09-22 12:04:23 --> Security Class Initialized
DEBUG - 2016-09-22 12:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:04:23 --> Input Class Initialized
INFO - 2016-09-22 12:04:23 --> Language Class Initialized
INFO - 2016-09-22 12:04:23 --> Loader Class Initialized
INFO - 2016-09-22 12:04:23 --> Helper loaded: url_helper
INFO - 2016-09-22 12:04:23 --> Helper loaded: language_helper
INFO - 2016-09-22 12:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:04:23 --> Controller Class Initialized
INFO - 2016-09-22 12:04:23 --> Database Driver Class Initialized
INFO - 2016-09-22 12:04:24 --> Model Class Initialized
INFO - 2016-09-22 12:04:24 --> Model Class Initialized
INFO - 2016-09-22 12:04:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:04:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:04:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:04:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:04:24 --> Final output sent to browser
DEBUG - 2016-09-22 12:04:24 --> Total execution time: 0.0627
INFO - 2016-09-22 12:04:31 --> Config Class Initialized
INFO - 2016-09-22 12:04:31 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:04:31 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:04:31 --> Utf8 Class Initialized
INFO - 2016-09-22 12:04:31 --> URI Class Initialized
INFO - 2016-09-22 12:04:31 --> Router Class Initialized
INFO - 2016-09-22 12:04:31 --> Output Class Initialized
INFO - 2016-09-22 12:04:31 --> Security Class Initialized
DEBUG - 2016-09-22 12:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:04:31 --> Input Class Initialized
INFO - 2016-09-22 12:04:31 --> Language Class Initialized
INFO - 2016-09-22 12:04:31 --> Loader Class Initialized
INFO - 2016-09-22 12:04:31 --> Helper loaded: url_helper
INFO - 2016-09-22 12:04:31 --> Helper loaded: language_helper
INFO - 2016-09-22 12:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:04:31 --> Controller Class Initialized
INFO - 2016-09-22 12:04:31 --> Database Driver Class Initialized
INFO - 2016-09-22 12:04:31 --> Model Class Initialized
INFO - 2016-09-22 12:04:31 --> Model Class Initialized
INFO - 2016-09-22 12:04:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:04:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 12:04:31 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 38
ERROR - 2016-09-22 12:04:31 --> Severity: Notice --> Undefined variable: seconds C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 39
ERROR - 2016-09-22 12:04:31 --> Severity: Notice --> Undefined variable: quiz C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 57
ERROR - 2016-09-22 12:04:31 --> Severity: Notice --> Undefined variable: quiz C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 58
ERROR - 2016-09-22 12:04:31 --> Severity: Notice --> Undefined variable: quiz C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
INFO - 2016-09-22 12:04:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:04:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:04:31 --> Final output sent to browser
DEBUG - 2016-09-22 12:04:31 --> Total execution time: 0.0647
INFO - 2016-09-22 12:04:45 --> Config Class Initialized
INFO - 2016-09-22 12:04:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:04:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:04:45 --> Utf8 Class Initialized
INFO - 2016-09-22 12:04:45 --> URI Class Initialized
INFO - 2016-09-22 12:04:45 --> Router Class Initialized
INFO - 2016-09-22 12:04:45 --> Output Class Initialized
INFO - 2016-09-22 12:04:45 --> Security Class Initialized
DEBUG - 2016-09-22 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:04:45 --> Input Class Initialized
INFO - 2016-09-22 12:04:45 --> Language Class Initialized
INFO - 2016-09-22 12:04:45 --> Loader Class Initialized
INFO - 2016-09-22 12:04:45 --> Helper loaded: url_helper
INFO - 2016-09-22 12:04:45 --> Helper loaded: language_helper
INFO - 2016-09-22 12:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:04:45 --> Controller Class Initialized
INFO - 2016-09-22 12:04:45 --> Database Driver Class Initialized
INFO - 2016-09-22 12:04:45 --> Model Class Initialized
INFO - 2016-09-22 12:04:45 --> Model Class Initialized
INFO - 2016-09-22 12:04:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:04:45 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
ERROR - 2016-09-22 12:04:45 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 12:04:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 12:04:45 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 12:04:45 --> Final output sent to browser
DEBUG - 2016-09-22 12:04:45 --> Total execution time: 0.0693
INFO - 2016-09-22 12:04:47 --> Config Class Initialized
INFO - 2016-09-22 12:04:47 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:04:47 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:04:47 --> Utf8 Class Initialized
INFO - 2016-09-22 12:04:47 --> URI Class Initialized
INFO - 2016-09-22 12:04:47 --> Router Class Initialized
INFO - 2016-09-22 12:04:47 --> Output Class Initialized
INFO - 2016-09-22 12:04:47 --> Security Class Initialized
DEBUG - 2016-09-22 12:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:04:47 --> Input Class Initialized
INFO - 2016-09-22 12:04:47 --> Language Class Initialized
INFO - 2016-09-22 12:04:47 --> Loader Class Initialized
INFO - 2016-09-22 12:04:47 --> Helper loaded: url_helper
INFO - 2016-09-22 12:04:47 --> Helper loaded: language_helper
INFO - 2016-09-22 12:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:04:47 --> Controller Class Initialized
INFO - 2016-09-22 12:04:47 --> Database Driver Class Initialized
INFO - 2016-09-22 12:04:47 --> Model Class Initialized
INFO - 2016-09-22 12:04:47 --> Model Class Initialized
INFO - 2016-09-22 12:04:47 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:04:47 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
ERROR - 2016-09-22 12:04:47 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 12:04:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 12:04:47 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 12:04:47 --> Final output sent to browser
DEBUG - 2016-09-22 12:04:47 --> Total execution time: 0.0800
INFO - 2016-09-22 12:08:26 --> Config Class Initialized
INFO - 2016-09-22 12:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:08:26 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:08:26 --> Utf8 Class Initialized
INFO - 2016-09-22 12:08:26 --> URI Class Initialized
INFO - 2016-09-22 12:08:26 --> Router Class Initialized
INFO - 2016-09-22 12:08:26 --> Output Class Initialized
INFO - 2016-09-22 12:08:26 --> Security Class Initialized
DEBUG - 2016-09-22 12:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:08:26 --> Input Class Initialized
INFO - 2016-09-22 12:08:26 --> Language Class Initialized
INFO - 2016-09-22 12:08:26 --> Loader Class Initialized
INFO - 2016-09-22 12:08:26 --> Helper loaded: url_helper
INFO - 2016-09-22 12:08:26 --> Helper loaded: language_helper
INFO - 2016-09-22 12:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:08:26 --> Controller Class Initialized
INFO - 2016-09-22 12:08:27 --> Database Driver Class Initialized
INFO - 2016-09-22 12:08:27 --> Model Class Initialized
INFO - 2016-09-22 12:08:27 --> Model Class Initialized
INFO - 2016-09-22 12:08:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:08:27 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 188
ERROR - 2016-09-22 12:08:27 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 199
ERROR - 2016-09-22 12:08:27 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 200
ERROR - 2016-09-22 12:08:27 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 204
ERROR - 2016-09-22 12:08:27 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:08:27 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526307, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:08:27 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:09:10 --> Config Class Initialized
INFO - 2016-09-22 12:09:10 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:09:10 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:09:10 --> Utf8 Class Initialized
INFO - 2016-09-22 12:09:10 --> URI Class Initialized
INFO - 2016-09-22 12:09:10 --> Router Class Initialized
INFO - 2016-09-22 12:09:10 --> Output Class Initialized
INFO - 2016-09-22 12:09:10 --> Security Class Initialized
DEBUG - 2016-09-22 12:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:09:10 --> Input Class Initialized
INFO - 2016-09-22 12:09:10 --> Language Class Initialized
INFO - 2016-09-22 12:09:10 --> Loader Class Initialized
INFO - 2016-09-22 12:09:10 --> Helper loaded: url_helper
INFO - 2016-09-22 12:09:10 --> Helper loaded: language_helper
INFO - 2016-09-22 12:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:09:10 --> Controller Class Initialized
INFO - 2016-09-22 12:09:10 --> Database Driver Class Initialized
INFO - 2016-09-22 12:09:10 --> Model Class Initialized
INFO - 2016-09-22 12:09:10 --> Model Class Initialized
INFO - 2016-09-22 12:09:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 12:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:09:10 --> Final output sent to browser
DEBUG - 2016-09-22 12:09:10 --> Total execution time: 0.0590
INFO - 2016-09-22 12:09:13 --> Config Class Initialized
INFO - 2016-09-22 12:09:13 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:09:13 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:09:13 --> Utf8 Class Initialized
INFO - 2016-09-22 12:09:13 --> URI Class Initialized
INFO - 2016-09-22 12:09:13 --> Router Class Initialized
INFO - 2016-09-22 12:09:13 --> Output Class Initialized
INFO - 2016-09-22 12:09:13 --> Security Class Initialized
DEBUG - 2016-09-22 12:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:09:13 --> Input Class Initialized
INFO - 2016-09-22 12:09:13 --> Language Class Initialized
INFO - 2016-09-22 12:09:13 --> Loader Class Initialized
INFO - 2016-09-22 12:09:13 --> Helper loaded: url_helper
INFO - 2016-09-22 12:09:13 --> Helper loaded: language_helper
INFO - 2016-09-22 12:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:09:13 --> Controller Class Initialized
INFO - 2016-09-22 12:09:13 --> Database Driver Class Initialized
INFO - 2016-09-22 12:09:13 --> Model Class Initialized
INFO - 2016-09-22 12:09:13 --> Model Class Initialized
INFO - 2016-09-22 12:09:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:09:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:09:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-22 12:09:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:09:13 --> Final output sent to browser
DEBUG - 2016-09-22 12:09:13 --> Total execution time: 0.0572
INFO - 2016-09-22 12:10:28 --> Config Class Initialized
INFO - 2016-09-22 12:10:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:10:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:10:28 --> Utf8 Class Initialized
INFO - 2016-09-22 12:10:28 --> URI Class Initialized
INFO - 2016-09-22 12:10:28 --> Router Class Initialized
INFO - 2016-09-22 12:10:28 --> Output Class Initialized
INFO - 2016-09-22 12:10:28 --> Security Class Initialized
DEBUG - 2016-09-22 12:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:10:28 --> Input Class Initialized
INFO - 2016-09-22 12:10:28 --> Language Class Initialized
INFO - 2016-09-22 12:10:28 --> Loader Class Initialized
INFO - 2016-09-22 12:10:28 --> Helper loaded: url_helper
INFO - 2016-09-22 12:10:28 --> Helper loaded: language_helper
INFO - 2016-09-22 12:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:10:28 --> Controller Class Initialized
INFO - 2016-09-22 12:10:28 --> Database Driver Class Initialized
INFO - 2016-09-22 12:10:28 --> Model Class Initialized
INFO - 2016-09-22 12:10:28 --> Model Class Initialized
INFO - 2016-09-22 12:10:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:10:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:10:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 12:10:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:10:28 --> Final output sent to browser
DEBUG - 2016-09-22 12:10:28 --> Total execution time: 0.0591
INFO - 2016-09-22 12:10:34 --> Config Class Initialized
INFO - 2016-09-22 12:10:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:10:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:10:34 --> Utf8 Class Initialized
INFO - 2016-09-22 12:10:34 --> URI Class Initialized
INFO - 2016-09-22 12:10:34 --> Router Class Initialized
INFO - 2016-09-22 12:10:34 --> Output Class Initialized
INFO - 2016-09-22 12:10:34 --> Security Class Initialized
DEBUG - 2016-09-22 12:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:10:34 --> Input Class Initialized
INFO - 2016-09-22 12:10:34 --> Language Class Initialized
INFO - 2016-09-22 12:10:34 --> Loader Class Initialized
INFO - 2016-09-22 12:10:34 --> Helper loaded: url_helper
INFO - 2016-09-22 12:10:34 --> Helper loaded: language_helper
INFO - 2016-09-22 12:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:10:34 --> Controller Class Initialized
INFO - 2016-09-22 12:10:34 --> Database Driver Class Initialized
INFO - 2016-09-22 12:10:34 --> Model Class Initialized
INFO - 2016-09-22 12:10:34 --> Model Class Initialized
INFO - 2016-09-22 12:10:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:10:34 --> Config Class Initialized
INFO - 2016-09-22 12:10:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:10:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:10:34 --> Utf8 Class Initialized
INFO - 2016-09-22 12:10:34 --> URI Class Initialized
INFO - 2016-09-22 12:10:34 --> Router Class Initialized
INFO - 2016-09-22 12:10:34 --> Output Class Initialized
INFO - 2016-09-22 12:10:34 --> Security Class Initialized
DEBUG - 2016-09-22 12:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:10:34 --> Input Class Initialized
INFO - 2016-09-22 12:10:34 --> Language Class Initialized
INFO - 2016-09-22 12:10:34 --> Loader Class Initialized
INFO - 2016-09-22 12:10:34 --> Helper loaded: url_helper
INFO - 2016-09-22 12:10:34 --> Helper loaded: language_helper
INFO - 2016-09-22 12:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:10:34 --> Controller Class Initialized
INFO - 2016-09-22 12:10:34 --> Database Driver Class Initialized
INFO - 2016-09-22 12:10:34 --> Model Class Initialized
INFO - 2016-09-22 12:10:34 --> Model Class Initialized
INFO - 2016-09-22 12:10:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:10:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:10:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:10:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:10:34 --> Final output sent to browser
DEBUG - 2016-09-22 12:10:34 --> Total execution time: 0.0566
INFO - 2016-09-22 12:17:05 --> Config Class Initialized
INFO - 2016-09-22 12:17:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:17:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:17:05 --> Utf8 Class Initialized
INFO - 2016-09-22 12:17:05 --> URI Class Initialized
INFO - 2016-09-22 12:17:05 --> Router Class Initialized
INFO - 2016-09-22 12:17:05 --> Output Class Initialized
INFO - 2016-09-22 12:17:05 --> Security Class Initialized
DEBUG - 2016-09-22 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:17:05 --> Input Class Initialized
INFO - 2016-09-22 12:17:05 --> Language Class Initialized
INFO - 2016-09-22 12:17:05 --> Loader Class Initialized
INFO - 2016-09-22 12:17:05 --> Helper loaded: url_helper
INFO - 2016-09-22 12:17:05 --> Helper loaded: language_helper
INFO - 2016-09-22 12:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:17:05 --> Controller Class Initialized
INFO - 2016-09-22 12:17:05 --> Database Driver Class Initialized
INFO - 2016-09-22 12:17:05 --> Model Class Initialized
INFO - 2016-09-22 12:17:05 --> Model Class Initialized
INFO - 2016-09-22 12:17:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:17:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:17:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:17:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:17:05 --> Final output sent to browser
DEBUG - 2016-09-22 12:17:05 --> Total execution time: 0.0741
INFO - 2016-09-22 12:17:09 --> Config Class Initialized
INFO - 2016-09-22 12:17:09 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:17:09 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:17:09 --> Utf8 Class Initialized
INFO - 2016-09-22 12:17:09 --> URI Class Initialized
INFO - 2016-09-22 12:17:09 --> Router Class Initialized
INFO - 2016-09-22 12:17:09 --> Output Class Initialized
INFO - 2016-09-22 12:17:09 --> Security Class Initialized
DEBUG - 2016-09-22 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:17:09 --> Input Class Initialized
INFO - 2016-09-22 12:17:09 --> Language Class Initialized
INFO - 2016-09-22 12:17:09 --> Loader Class Initialized
INFO - 2016-09-22 12:17:09 --> Helper loaded: url_helper
INFO - 2016-09-22 12:17:09 --> Helper loaded: language_helper
INFO - 2016-09-22 12:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:17:09 --> Controller Class Initialized
INFO - 2016-09-22 12:17:09 --> Database Driver Class Initialized
INFO - 2016-09-22 12:17:09 --> Model Class Initialized
INFO - 2016-09-22 12:17:09 --> Model Class Initialized
INFO - 2016-09-22 12:17:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:17:09 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 747
ERROR - 2016-09-22 12:17:09 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 758
ERROR - 2016-09-22 12:17:09 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:17:09 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 763
ERROR - 2016-09-22 12:17:09 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:17:09 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526829, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:17:09 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:17:45 --> Config Class Initialized
INFO - 2016-09-22 12:17:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:17:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:17:45 --> Utf8 Class Initialized
INFO - 2016-09-22 12:17:45 --> URI Class Initialized
INFO - 2016-09-22 12:17:45 --> Router Class Initialized
INFO - 2016-09-22 12:17:45 --> Output Class Initialized
INFO - 2016-09-22 12:17:45 --> Security Class Initialized
DEBUG - 2016-09-22 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:17:45 --> Input Class Initialized
INFO - 2016-09-22 12:17:45 --> Language Class Initialized
INFO - 2016-09-22 12:17:45 --> Loader Class Initialized
INFO - 2016-09-22 12:17:45 --> Helper loaded: url_helper
INFO - 2016-09-22 12:17:45 --> Helper loaded: language_helper
INFO - 2016-09-22 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:17:45 --> Controller Class Initialized
INFO - 2016-09-22 12:17:45 --> Database Driver Class Initialized
INFO - 2016-09-22 12:17:45 --> Model Class Initialized
INFO - 2016-09-22 12:17:45 --> Model Class Initialized
INFO - 2016-09-22 12:17:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:17:45 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 743
ERROR - 2016-09-22 12:17:45 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 747
ERROR - 2016-09-22 12:17:45 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 758
ERROR - 2016-09-22 12:17:45 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:17:45 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 763
ERROR - 2016-09-22 12:17:45 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:17:45 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526865, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:17:45 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:18:16 --> Config Class Initialized
INFO - 2016-09-22 12:18:16 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:18:16 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:18:16 --> Utf8 Class Initialized
INFO - 2016-09-22 12:18:16 --> URI Class Initialized
INFO - 2016-09-22 12:18:16 --> Router Class Initialized
INFO - 2016-09-22 12:18:16 --> Output Class Initialized
INFO - 2016-09-22 12:18:16 --> Security Class Initialized
DEBUG - 2016-09-22 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:18:16 --> Input Class Initialized
INFO - 2016-09-22 12:18:16 --> Language Class Initialized
INFO - 2016-09-22 12:18:16 --> Loader Class Initialized
INFO - 2016-09-22 12:18:16 --> Helper loaded: url_helper
INFO - 2016-09-22 12:18:16 --> Helper loaded: language_helper
INFO - 2016-09-22 12:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:18:16 --> Controller Class Initialized
INFO - 2016-09-22 12:18:16 --> Database Driver Class Initialized
INFO - 2016-09-22 12:18:16 --> Model Class Initialized
INFO - 2016-09-22 12:18:16 --> Model Class Initialized
INFO - 2016-09-22 12:18:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:18:16 --> Final output sent to browser
DEBUG - 2016-09-22 12:18:16 --> Total execution time: 0.0609
INFO - 2016-09-22 12:18:17 --> Config Class Initialized
INFO - 2016-09-22 12:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:18:17 --> Utf8 Class Initialized
INFO - 2016-09-22 12:18:17 --> URI Class Initialized
INFO - 2016-09-22 12:18:17 --> Router Class Initialized
INFO - 2016-09-22 12:18:17 --> Output Class Initialized
INFO - 2016-09-22 12:18:17 --> Security Class Initialized
DEBUG - 2016-09-22 12:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:18:17 --> Input Class Initialized
INFO - 2016-09-22 12:18:17 --> Language Class Initialized
INFO - 2016-09-22 12:18:17 --> Loader Class Initialized
INFO - 2016-09-22 12:18:17 --> Helper loaded: url_helper
INFO - 2016-09-22 12:18:17 --> Helper loaded: language_helper
INFO - 2016-09-22 12:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:18:17 --> Controller Class Initialized
INFO - 2016-09-22 12:18:17 --> Database Driver Class Initialized
INFO - 2016-09-22 12:18:17 --> Model Class Initialized
INFO - 2016-09-22 12:18:17 --> Model Class Initialized
INFO - 2016-09-22 12:18:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:18:17 --> Final output sent to browser
DEBUG - 2016-09-22 12:18:17 --> Total execution time: 0.0852
INFO - 2016-09-22 12:18:18 --> Config Class Initialized
INFO - 2016-09-22 12:18:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:18:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:18:18 --> Utf8 Class Initialized
INFO - 2016-09-22 12:18:18 --> URI Class Initialized
INFO - 2016-09-22 12:18:18 --> Router Class Initialized
INFO - 2016-09-22 12:18:18 --> Output Class Initialized
INFO - 2016-09-22 12:18:18 --> Security Class Initialized
DEBUG - 2016-09-22 12:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:18:18 --> Input Class Initialized
INFO - 2016-09-22 12:18:18 --> Language Class Initialized
INFO - 2016-09-22 12:18:18 --> Loader Class Initialized
INFO - 2016-09-22 12:18:18 --> Helper loaded: url_helper
INFO - 2016-09-22 12:18:18 --> Helper loaded: language_helper
INFO - 2016-09-22 12:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:18:18 --> Controller Class Initialized
INFO - 2016-09-22 12:18:18 --> Database Driver Class Initialized
INFO - 2016-09-22 12:18:18 --> Model Class Initialized
INFO - 2016-09-22 12:18:18 --> Model Class Initialized
INFO - 2016-09-22 12:18:18 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:18:18 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 743
ERROR - 2016-09-22 12:18:18 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 747
ERROR - 2016-09-22 12:18:18 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 758
ERROR - 2016-09-22 12:18:18 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:18:18 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 763
ERROR - 2016-09-22 12:18:18 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:18:18 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526898, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:18:18 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:19:51 --> Config Class Initialized
INFO - 2016-09-22 12:19:51 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:19:51 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:19:51 --> Utf8 Class Initialized
INFO - 2016-09-22 12:19:51 --> URI Class Initialized
INFO - 2016-09-22 12:19:51 --> Router Class Initialized
INFO - 2016-09-22 12:19:51 --> Output Class Initialized
INFO - 2016-09-22 12:19:51 --> Security Class Initialized
DEBUG - 2016-09-22 12:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:19:51 --> Input Class Initialized
INFO - 2016-09-22 12:19:51 --> Language Class Initialized
INFO - 2016-09-22 12:19:51 --> Loader Class Initialized
INFO - 2016-09-22 12:19:51 --> Helper loaded: url_helper
INFO - 2016-09-22 12:19:51 --> Helper loaded: language_helper
INFO - 2016-09-22 12:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:19:51 --> Controller Class Initialized
INFO - 2016-09-22 12:19:51 --> Database Driver Class Initialized
INFO - 2016-09-22 12:19:51 --> Model Class Initialized
INFO - 2016-09-22 12:19:51 --> Model Class Initialized
INFO - 2016-09-22 12:19:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:19:51 --> Final output sent to browser
DEBUG - 2016-09-22 12:19:51 --> Total execution time: 0.0552
INFO - 2016-09-22 12:19:51 --> Config Class Initialized
INFO - 2016-09-22 12:19:51 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:19:51 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:19:51 --> Utf8 Class Initialized
INFO - 2016-09-22 12:19:51 --> URI Class Initialized
INFO - 2016-09-22 12:19:51 --> Router Class Initialized
INFO - 2016-09-22 12:19:51 --> Output Class Initialized
INFO - 2016-09-22 12:19:51 --> Security Class Initialized
DEBUG - 2016-09-22 12:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:19:51 --> Input Class Initialized
INFO - 2016-09-22 12:19:51 --> Language Class Initialized
INFO - 2016-09-22 12:19:51 --> Loader Class Initialized
INFO - 2016-09-22 12:19:51 --> Helper loaded: url_helper
INFO - 2016-09-22 12:19:51 --> Helper loaded: language_helper
INFO - 2016-09-22 12:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:19:51 --> Controller Class Initialized
INFO - 2016-09-22 12:19:51 --> Database Driver Class Initialized
INFO - 2016-09-22 12:19:51 --> Model Class Initialized
INFO - 2016-09-22 12:19:51 --> Model Class Initialized
INFO - 2016-09-22 12:19:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:19:51 --> Final output sent to browser
DEBUG - 2016-09-22 12:19:51 --> Total execution time: 0.0649
INFO - 2016-09-22 12:19:56 --> Config Class Initialized
INFO - 2016-09-22 12:19:56 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:19:56 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:19:56 --> Utf8 Class Initialized
INFO - 2016-09-22 12:19:56 --> URI Class Initialized
INFO - 2016-09-22 12:19:56 --> Router Class Initialized
INFO - 2016-09-22 12:19:56 --> Output Class Initialized
INFO - 2016-09-22 12:19:56 --> Security Class Initialized
DEBUG - 2016-09-22 12:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:19:56 --> Input Class Initialized
INFO - 2016-09-22 12:19:56 --> Language Class Initialized
INFO - 2016-09-22 12:19:56 --> Loader Class Initialized
INFO - 2016-09-22 12:19:56 --> Helper loaded: url_helper
INFO - 2016-09-22 12:19:56 --> Helper loaded: language_helper
INFO - 2016-09-22 12:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:19:56 --> Controller Class Initialized
INFO - 2016-09-22 12:19:56 --> Database Driver Class Initialized
INFO - 2016-09-22 12:19:56 --> Model Class Initialized
INFO - 2016-09-22 12:19:56 --> Model Class Initialized
INFO - 2016-09-22 12:19:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:19:56 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 743
ERROR - 2016-09-22 12:19:56 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 747
ERROR - 2016-09-22 12:19:56 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 758
ERROR - 2016-09-22 12:19:56 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:19:56 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 763
ERROR - 2016-09-22 12:19:56 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:19:56 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474526996, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:19:56 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:20:35 --> Config Class Initialized
INFO - 2016-09-22 12:20:35 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:20:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:20:35 --> Utf8 Class Initialized
INFO - 2016-09-22 12:20:35 --> URI Class Initialized
INFO - 2016-09-22 12:20:35 --> Router Class Initialized
INFO - 2016-09-22 12:20:35 --> Output Class Initialized
INFO - 2016-09-22 12:20:35 --> Security Class Initialized
DEBUG - 2016-09-22 12:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:20:35 --> Input Class Initialized
INFO - 2016-09-22 12:20:35 --> Language Class Initialized
INFO - 2016-09-22 12:20:35 --> Loader Class Initialized
INFO - 2016-09-22 12:20:35 --> Helper loaded: url_helper
INFO - 2016-09-22 12:20:35 --> Helper loaded: language_helper
INFO - 2016-09-22 12:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:20:35 --> Controller Class Initialized
INFO - 2016-09-22 12:20:35 --> Database Driver Class Initialized
INFO - 2016-09-22 12:20:35 --> Model Class Initialized
INFO - 2016-09-22 12:20:35 --> Model Class Initialized
INFO - 2016-09-22 12:20:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:20:35 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 744
ERROR - 2016-09-22 12:20:35 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 748
ERROR - 2016-09-22 12:20:35 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:20:35 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 760
ERROR - 2016-09-22 12:20:35 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 764
ERROR - 2016-09-22 12:20:35 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:20:35 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474527035, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:20:35 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:20:49 --> Config Class Initialized
INFO - 2016-09-22 12:20:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:20:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:20:49 --> Utf8 Class Initialized
INFO - 2016-09-22 12:20:49 --> URI Class Initialized
INFO - 2016-09-22 12:20:49 --> Router Class Initialized
INFO - 2016-09-22 12:20:49 --> Output Class Initialized
INFO - 2016-09-22 12:20:49 --> Security Class Initialized
DEBUG - 2016-09-22 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:20:49 --> Input Class Initialized
INFO - 2016-09-22 12:20:49 --> Language Class Initialized
INFO - 2016-09-22 12:20:49 --> Loader Class Initialized
INFO - 2016-09-22 12:20:49 --> Helper loaded: url_helper
INFO - 2016-09-22 12:20:49 --> Helper loaded: language_helper
INFO - 2016-09-22 12:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:20:49 --> Controller Class Initialized
INFO - 2016-09-22 12:20:49 --> Database Driver Class Initialized
INFO - 2016-09-22 12:20:49 --> Model Class Initialized
INFO - 2016-09-22 12:20:49 --> Model Class Initialized
INFO - 2016-09-22 12:20:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:20:49 --> Config Class Initialized
INFO - 2016-09-22 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:20:49 --> Hooks Class Initialized
INFO - 2016-09-22 12:20:49 --> Final output sent to browser
DEBUG - 2016-09-22 12:20:49 --> Total execution time: 0.0699
DEBUG - 2016-09-22 12:20:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:20:49 --> Utf8 Class Initialized
INFO - 2016-09-22 12:20:49 --> URI Class Initialized
INFO - 2016-09-22 12:20:49 --> Router Class Initialized
INFO - 2016-09-22 12:20:49 --> Output Class Initialized
INFO - 2016-09-22 12:20:49 --> Security Class Initialized
DEBUG - 2016-09-22 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:20:49 --> Input Class Initialized
INFO - 2016-09-22 12:20:49 --> Language Class Initialized
INFO - 2016-09-22 12:20:49 --> Loader Class Initialized
INFO - 2016-09-22 12:20:49 --> Helper loaded: url_helper
INFO - 2016-09-22 12:20:49 --> Helper loaded: language_helper
INFO - 2016-09-22 12:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:20:49 --> Controller Class Initialized
INFO - 2016-09-22 12:20:49 --> Database Driver Class Initialized
INFO - 2016-09-22 12:20:49 --> Model Class Initialized
INFO - 2016-09-22 12:20:49 --> Model Class Initialized
INFO - 2016-09-22 12:20:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:20:49 --> Final output sent to browser
DEBUG - 2016-09-22 12:20:49 --> Total execution time: 0.0654
INFO - 2016-09-22 12:20:52 --> Config Class Initialized
INFO - 2016-09-22 12:20:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:20:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:20:52 --> Utf8 Class Initialized
INFO - 2016-09-22 12:20:52 --> URI Class Initialized
INFO - 2016-09-22 12:20:52 --> Router Class Initialized
INFO - 2016-09-22 12:20:52 --> Output Class Initialized
INFO - 2016-09-22 12:20:52 --> Security Class Initialized
DEBUG - 2016-09-22 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:20:52 --> Input Class Initialized
INFO - 2016-09-22 12:20:52 --> Language Class Initialized
INFO - 2016-09-22 12:20:52 --> Loader Class Initialized
INFO - 2016-09-22 12:20:52 --> Helper loaded: url_helper
INFO - 2016-09-22 12:20:52 --> Helper loaded: language_helper
INFO - 2016-09-22 12:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:20:52 --> Controller Class Initialized
INFO - 2016-09-22 12:20:52 --> Database Driver Class Initialized
INFO - 2016-09-22 12:20:52 --> Model Class Initialized
INFO - 2016-09-22 12:20:52 --> Model Class Initialized
INFO - 2016-09-22 12:20:52 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:20:52 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 744
ERROR - 2016-09-22 12:20:52 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 748
ERROR - 2016-09-22 12:20:52 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:20:52 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 760
ERROR - 2016-09-22 12:20:52 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 764
ERROR - 2016-09-22 12:20:52 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:20:52 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474527052, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:20:52 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:22:21 --> Config Class Initialized
INFO - 2016-09-22 12:22:21 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:22:21 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:22:21 --> Utf8 Class Initialized
INFO - 2016-09-22 12:22:21 --> URI Class Initialized
INFO - 2016-09-22 12:22:21 --> Router Class Initialized
INFO - 2016-09-22 12:22:21 --> Output Class Initialized
INFO - 2016-09-22 12:22:21 --> Security Class Initialized
DEBUG - 2016-09-22 12:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:22:21 --> Input Class Initialized
INFO - 2016-09-22 12:22:21 --> Language Class Initialized
INFO - 2016-09-22 12:22:21 --> Loader Class Initialized
INFO - 2016-09-22 12:22:21 --> Helper loaded: url_helper
INFO - 2016-09-22 12:22:21 --> Helper loaded: language_helper
INFO - 2016-09-22 12:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:22:21 --> Controller Class Initialized
INFO - 2016-09-22 12:22:21 --> Database Driver Class Initialized
INFO - 2016-09-22 12:22:21 --> Model Class Initialized
INFO - 2016-09-22 12:22:21 --> Model Class Initialized
INFO - 2016-09-22 12:22:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:22:21 --> Severity: Warning --> Missing argument 1 for Ujian::se_attempt(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 744
ERROR - 2016-09-22 12:22:21 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 748
ERROR - 2016-09-22 12:22:21 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 759
ERROR - 2016-09-22 12:22:21 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 760
ERROR - 2016-09-22 12:22:21 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 764
ERROR - 2016-09-22 12:22:21 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-22 12:22:21 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474527141, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-09-22 12:22:21 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-22 12:24:48 --> Config Class Initialized
INFO - 2016-09-22 12:24:48 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:24:48 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:24:48 --> Utf8 Class Initialized
INFO - 2016-09-22 12:24:48 --> URI Class Initialized
INFO - 2016-09-22 12:24:48 --> Router Class Initialized
INFO - 2016-09-22 12:24:48 --> Output Class Initialized
INFO - 2016-09-22 12:24:48 --> Security Class Initialized
DEBUG - 2016-09-22 12:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:24:48 --> Input Class Initialized
INFO - 2016-09-22 12:24:48 --> Language Class Initialized
INFO - 2016-09-22 12:24:48 --> Loader Class Initialized
INFO - 2016-09-22 12:24:48 --> Helper loaded: url_helper
INFO - 2016-09-22 12:24:48 --> Helper loaded: language_helper
INFO - 2016-09-22 12:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:24:48 --> Controller Class Initialized
INFO - 2016-09-22 12:24:48 --> Database Driver Class Initialized
INFO - 2016-09-22 12:24:48 --> Model Class Initialized
INFO - 2016-09-22 12:24:48 --> Model Class Initialized
INFO - 2016-09-22 12:24:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:24:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:24:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:24:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:24:48 --> Final output sent to browser
DEBUG - 2016-09-22 12:24:48 --> Total execution time: 0.0556
INFO - 2016-09-22 12:24:49 --> Config Class Initialized
INFO - 2016-09-22 12:24:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:24:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:24:49 --> Utf8 Class Initialized
INFO - 2016-09-22 12:24:49 --> URI Class Initialized
INFO - 2016-09-22 12:24:49 --> Router Class Initialized
INFO - 2016-09-22 12:24:49 --> Output Class Initialized
INFO - 2016-09-22 12:24:49 --> Security Class Initialized
DEBUG - 2016-09-22 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:24:49 --> Input Class Initialized
INFO - 2016-09-22 12:24:49 --> Language Class Initialized
INFO - 2016-09-22 12:24:49 --> Loader Class Initialized
INFO - 2016-09-22 12:24:49 --> Helper loaded: url_helper
INFO - 2016-09-22 12:24:49 --> Helper loaded: language_helper
INFO - 2016-09-22 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:24:49 --> Controller Class Initialized
INFO - 2016-09-22 12:24:49 --> Database Driver Class Initialized
INFO - 2016-09-22 12:24:49 --> Model Class Initialized
INFO - 2016-09-22 12:24:49 --> Model Class Initialized
INFO - 2016-09-22 12:24:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:24:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:24:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 12:24:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:24:49 --> Final output sent to browser
DEBUG - 2016-09-22 12:24:49 --> Total execution time: 0.0645
INFO - 2016-09-22 12:25:04 --> Config Class Initialized
INFO - 2016-09-22 12:25:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:25:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:25:04 --> Utf8 Class Initialized
INFO - 2016-09-22 12:25:04 --> URI Class Initialized
INFO - 2016-09-22 12:25:04 --> Router Class Initialized
INFO - 2016-09-22 12:25:04 --> Output Class Initialized
INFO - 2016-09-22 12:25:04 --> Security Class Initialized
DEBUG - 2016-09-22 12:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:25:04 --> Input Class Initialized
INFO - 2016-09-22 12:25:04 --> Language Class Initialized
INFO - 2016-09-22 12:25:04 --> Loader Class Initialized
INFO - 2016-09-22 12:25:04 --> Helper loaded: url_helper
INFO - 2016-09-22 12:25:04 --> Helper loaded: language_helper
INFO - 2016-09-22 12:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:25:04 --> Controller Class Initialized
INFO - 2016-09-22 12:25:04 --> Database Driver Class Initialized
INFO - 2016-09-22 12:25:04 --> Model Class Initialized
INFO - 2016-09-22 12:25:04 --> Model Class Initialized
INFO - 2016-09-22 12:25:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:25:04 --> Config Class Initialized
INFO - 2016-09-22 12:25:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:25:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:25:04 --> Utf8 Class Initialized
INFO - 2016-09-22 12:25:04 --> URI Class Initialized
INFO - 2016-09-22 12:25:04 --> Router Class Initialized
INFO - 2016-09-22 12:25:04 --> Output Class Initialized
INFO - 2016-09-22 12:25:04 --> Security Class Initialized
DEBUG - 2016-09-22 12:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:25:04 --> Input Class Initialized
INFO - 2016-09-22 12:25:04 --> Language Class Initialized
INFO - 2016-09-22 12:25:04 --> Loader Class Initialized
INFO - 2016-09-22 12:25:04 --> Helper loaded: url_helper
INFO - 2016-09-22 12:25:04 --> Helper loaded: language_helper
INFO - 2016-09-22 12:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:25:04 --> Controller Class Initialized
INFO - 2016-09-22 12:25:04 --> Database Driver Class Initialized
INFO - 2016-09-22 12:25:04 --> Model Class Initialized
INFO - 2016-09-22 12:25:04 --> Model Class Initialized
INFO - 2016-09-22 12:25:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:25:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:25:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:25:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:25:04 --> Final output sent to browser
DEBUG - 2016-09-22 12:25:04 --> Total execution time: 0.0572
INFO - 2016-09-22 12:29:07 --> Config Class Initialized
INFO - 2016-09-22 12:29:07 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:07 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:07 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:07 --> URI Class Initialized
INFO - 2016-09-22 12:29:07 --> Router Class Initialized
INFO - 2016-09-22 12:29:07 --> Output Class Initialized
INFO - 2016-09-22 12:29:07 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:07 --> Input Class Initialized
INFO - 2016-09-22 12:29:07 --> Language Class Initialized
INFO - 2016-09-22 12:29:07 --> Loader Class Initialized
INFO - 2016-09-22 12:29:07 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:07 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:07 --> Controller Class Initialized
INFO - 2016-09-22 12:29:07 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:07 --> Model Class Initialized
INFO - 2016-09-22 12:29:07 --> Model Class Initialized
INFO - 2016-09-22 12:29:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:29:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:29:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:29:07 --> Final output sent to browser
DEBUG - 2016-09-22 12:29:07 --> Total execution time: 0.0704
INFO - 2016-09-22 12:29:18 --> Config Class Initialized
INFO - 2016-09-22 12:29:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:18 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:18 --> URI Class Initialized
INFO - 2016-09-22 12:29:18 --> Router Class Initialized
INFO - 2016-09-22 12:29:18 --> Output Class Initialized
INFO - 2016-09-22 12:29:18 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:18 --> Input Class Initialized
INFO - 2016-09-22 12:29:18 --> Language Class Initialized
INFO - 2016-09-22 12:29:18 --> Loader Class Initialized
INFO - 2016-09-22 12:29:18 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:18 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:18 --> Controller Class Initialized
INFO - 2016-09-22 12:29:18 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:18 --> Model Class Initialized
INFO - 2016-09-22 12:29:18 --> Model Class Initialized
INFO - 2016-09-22 12:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:18 --> Config Class Initialized
INFO - 2016-09-22 12:29:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:18 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:18 --> URI Class Initialized
INFO - 2016-09-22 12:29:18 --> Router Class Initialized
INFO - 2016-09-22 12:29:18 --> Output Class Initialized
INFO - 2016-09-22 12:29:18 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:18 --> Input Class Initialized
INFO - 2016-09-22 12:29:18 --> Language Class Initialized
INFO - 2016-09-22 12:29:18 --> Loader Class Initialized
INFO - 2016-09-22 12:29:18 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:18 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:18 --> Controller Class Initialized
INFO - 2016-09-22 12:29:18 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:18 --> Model Class Initialized
INFO - 2016-09-22 12:29:18 --> Model Class Initialized
INFO - 2016-09-22 12:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 12:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:29:18 --> Final output sent to browser
DEBUG - 2016-09-22 12:29:18 --> Total execution time: 0.0605
INFO - 2016-09-22 12:29:40 --> Config Class Initialized
INFO - 2016-09-22 12:29:40 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:40 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:40 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:40 --> URI Class Initialized
INFO - 2016-09-22 12:29:40 --> Router Class Initialized
INFO - 2016-09-22 12:29:40 --> Output Class Initialized
INFO - 2016-09-22 12:29:40 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:40 --> Input Class Initialized
INFO - 2016-09-22 12:29:40 --> Language Class Initialized
INFO - 2016-09-22 12:29:40 --> Loader Class Initialized
INFO - 2016-09-22 12:29:40 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:40 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:40 --> Controller Class Initialized
INFO - 2016-09-22 12:29:40 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:40 --> Model Class Initialized
INFO - 2016-09-22 12:29:40 --> Model Class Initialized
INFO - 2016-09-22 12:29:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:29:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 12:29:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:29:40 --> Final output sent to browser
DEBUG - 2016-09-22 12:29:40 --> Total execution time: 0.0586
INFO - 2016-09-22 12:29:42 --> Config Class Initialized
INFO - 2016-09-22 12:29:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:42 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:42 --> URI Class Initialized
INFO - 2016-09-22 12:29:42 --> Router Class Initialized
INFO - 2016-09-22 12:29:42 --> Output Class Initialized
INFO - 2016-09-22 12:29:42 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:42 --> Input Class Initialized
INFO - 2016-09-22 12:29:42 --> Language Class Initialized
INFO - 2016-09-22 12:29:42 --> Loader Class Initialized
INFO - 2016-09-22 12:29:42 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:42 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:42 --> Controller Class Initialized
INFO - 2016-09-22 12:29:42 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:42 --> Model Class Initialized
INFO - 2016-09-22 12:29:42 --> Model Class Initialized
INFO - 2016-09-22 12:29:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:42 --> Config Class Initialized
INFO - 2016-09-22 12:29:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:42 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:42 --> URI Class Initialized
INFO - 2016-09-22 12:29:42 --> Router Class Initialized
INFO - 2016-09-22 12:29:42 --> Output Class Initialized
INFO - 2016-09-22 12:29:42 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:42 --> Input Class Initialized
INFO - 2016-09-22 12:29:42 --> Language Class Initialized
INFO - 2016-09-22 12:29:42 --> Loader Class Initialized
INFO - 2016-09-22 12:29:42 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:42 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:42 --> Controller Class Initialized
INFO - 2016-09-22 12:29:42 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:42 --> Model Class Initialized
INFO - 2016-09-22 12:29:42 --> Model Class Initialized
INFO - 2016-09-22 12:29:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:29:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:29:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:29:42 --> Final output sent to browser
DEBUG - 2016-09-22 12:29:42 --> Total execution time: 0.0649
INFO - 2016-09-22 12:29:46 --> Config Class Initialized
INFO - 2016-09-22 12:29:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:46 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:46 --> URI Class Initialized
INFO - 2016-09-22 12:29:46 --> Router Class Initialized
INFO - 2016-09-22 12:29:46 --> Output Class Initialized
INFO - 2016-09-22 12:29:46 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:46 --> Input Class Initialized
INFO - 2016-09-22 12:29:46 --> Language Class Initialized
INFO - 2016-09-22 12:29:46 --> Loader Class Initialized
INFO - 2016-09-22 12:29:46 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:46 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:46 --> Controller Class Initialized
INFO - 2016-09-22 12:29:46 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:46 --> Model Class Initialized
INFO - 2016-09-22 12:29:46 --> Model Class Initialized
INFO - 2016-09-22 12:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:46 --> Config Class Initialized
INFO - 2016-09-22 12:29:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:29:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:29:46 --> Utf8 Class Initialized
INFO - 2016-09-22 12:29:46 --> URI Class Initialized
INFO - 2016-09-22 12:29:46 --> Router Class Initialized
INFO - 2016-09-22 12:29:46 --> Output Class Initialized
INFO - 2016-09-22 12:29:46 --> Security Class Initialized
DEBUG - 2016-09-22 12:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:29:46 --> Input Class Initialized
INFO - 2016-09-22 12:29:46 --> Language Class Initialized
INFO - 2016-09-22 12:29:46 --> Loader Class Initialized
INFO - 2016-09-22 12:29:46 --> Helper loaded: url_helper
INFO - 2016-09-22 12:29:46 --> Helper loaded: language_helper
INFO - 2016-09-22 12:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:29:46 --> Controller Class Initialized
INFO - 2016-09-22 12:29:46 --> Database Driver Class Initialized
INFO - 2016-09-22 12:29:46 --> Model Class Initialized
INFO - 2016-09-22 12:29:46 --> Model Class Initialized
INFO - 2016-09-22 12:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:29:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:29:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 12:29:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:29:46 --> Final output sent to browser
DEBUG - 2016-09-22 12:29:46 --> Total execution time: 0.0638
INFO - 2016-09-22 12:31:30 --> Config Class Initialized
INFO - 2016-09-22 12:31:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:31:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:31:30 --> Utf8 Class Initialized
INFO - 2016-09-22 12:31:30 --> URI Class Initialized
INFO - 2016-09-22 12:31:30 --> Router Class Initialized
INFO - 2016-09-22 12:31:30 --> Output Class Initialized
INFO - 2016-09-22 12:31:30 --> Security Class Initialized
DEBUG - 2016-09-22 12:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:31:30 --> Input Class Initialized
INFO - 2016-09-22 12:31:30 --> Language Class Initialized
INFO - 2016-09-22 12:31:30 --> Loader Class Initialized
INFO - 2016-09-22 12:31:30 --> Helper loaded: url_helper
INFO - 2016-09-22 12:31:30 --> Helper loaded: language_helper
INFO - 2016-09-22 12:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:31:30 --> Controller Class Initialized
INFO - 2016-09-22 12:31:30 --> Database Driver Class Initialized
INFO - 2016-09-22 12:31:30 --> Config Class Initialized
INFO - 2016-09-22 12:31:30 --> Hooks Class Initialized
INFO - 2016-09-22 12:31:30 --> Model Class Initialized
INFO - 2016-09-22 12:31:30 --> Model Class Initialized
INFO - 2016-09-22 12:31:30 --> Language file loaded: language/indonesia/basic_lang.php
DEBUG - 2016-09-22 12:31:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:31:30 --> Utf8 Class Initialized
INFO - 2016-09-22 12:31:30 --> URI Class Initialized
INFO - 2016-09-22 12:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:31:30 --> Router Class Initialized
ERROR - 2016-09-22 12:31:30 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\wamp64\www\savsoftquiz\application\views\ujian_list.php 26
INFO - 2016-09-22 12:31:30 --> Output Class Initialized
INFO - 2016-09-22 12:31:30 --> Security Class Initialized
DEBUG - 2016-09-22 12:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:31:30 --> Input Class Initialized
INFO - 2016-09-22 12:31:30 --> Language Class Initialized
INFO - 2016-09-22 12:31:30 --> Loader Class Initialized
INFO - 2016-09-22 12:31:30 --> Helper loaded: url_helper
INFO - 2016-09-22 12:31:30 --> Helper loaded: language_helper
INFO - 2016-09-22 12:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:31:30 --> Controller Class Initialized
INFO - 2016-09-22 12:31:30 --> Database Driver Class Initialized
INFO - 2016-09-22 12:31:30 --> Model Class Initialized
INFO - 2016-09-22 12:31:30 --> Model Class Initialized
INFO - 2016-09-22 12:31:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 12:31:30 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\wamp64\www\savsoftquiz\application\views\ujian_list.php 26
INFO - 2016-09-22 12:31:41 --> Config Class Initialized
INFO - 2016-09-22 12:31:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:31:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:31:41 --> Utf8 Class Initialized
INFO - 2016-09-22 12:31:41 --> URI Class Initialized
INFO - 2016-09-22 12:31:41 --> Router Class Initialized
INFO - 2016-09-22 12:31:41 --> Output Class Initialized
INFO - 2016-09-22 12:31:41 --> Security Class Initialized
DEBUG - 2016-09-22 12:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:31:41 --> Input Class Initialized
INFO - 2016-09-22 12:31:41 --> Language Class Initialized
INFO - 2016-09-22 12:31:41 --> Loader Class Initialized
INFO - 2016-09-22 12:31:41 --> Helper loaded: url_helper
INFO - 2016-09-22 12:31:41 --> Helper loaded: language_helper
INFO - 2016-09-22 12:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:31:41 --> Controller Class Initialized
INFO - 2016-09-22 12:31:41 --> Database Driver Class Initialized
INFO - 2016-09-22 12:31:41 --> Model Class Initialized
INFO - 2016-09-22 12:31:41 --> Model Class Initialized
INFO - 2016-09-22 12:31:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:31:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:31:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 12:31:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:31:41 --> Final output sent to browser
DEBUG - 2016-09-22 12:31:41 --> Total execution time: 0.0613
INFO - 2016-09-22 12:31:45 --> Config Class Initialized
INFO - 2016-09-22 12:31:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:31:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:31:45 --> Utf8 Class Initialized
INFO - 2016-09-22 12:31:45 --> URI Class Initialized
INFO - 2016-09-22 12:31:45 --> Router Class Initialized
INFO - 2016-09-22 12:31:45 --> Output Class Initialized
INFO - 2016-09-22 12:31:45 --> Security Class Initialized
DEBUG - 2016-09-22 12:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:31:45 --> Input Class Initialized
INFO - 2016-09-22 12:31:45 --> Language Class Initialized
INFO - 2016-09-22 12:31:45 --> Loader Class Initialized
INFO - 2016-09-22 12:31:45 --> Helper loaded: url_helper
INFO - 2016-09-22 12:31:45 --> Helper loaded: language_helper
INFO - 2016-09-22 12:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:31:45 --> Controller Class Initialized
INFO - 2016-09-22 12:31:45 --> Database Driver Class Initialized
INFO - 2016-09-22 12:31:45 --> Model Class Initialized
INFO - 2016-09-22 12:31:45 --> Model Class Initialized
INFO - 2016-09-22 12:31:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:31:45 --> Final output sent to browser
DEBUG - 2016-09-22 12:31:45 --> Total execution time: 0.0655
INFO - 2016-09-22 12:31:49 --> Config Class Initialized
INFO - 2016-09-22 12:31:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:31:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:31:49 --> Utf8 Class Initialized
INFO - 2016-09-22 12:31:49 --> URI Class Initialized
INFO - 2016-09-22 12:31:49 --> Router Class Initialized
INFO - 2016-09-22 12:31:49 --> Output Class Initialized
INFO - 2016-09-22 12:31:49 --> Security Class Initialized
DEBUG - 2016-09-22 12:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:31:49 --> Input Class Initialized
INFO - 2016-09-22 12:31:49 --> Language Class Initialized
INFO - 2016-09-22 12:31:49 --> Loader Class Initialized
INFO - 2016-09-22 12:31:49 --> Helper loaded: url_helper
INFO - 2016-09-22 12:31:49 --> Helper loaded: language_helper
INFO - 2016-09-22 12:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:31:49 --> Controller Class Initialized
INFO - 2016-09-22 12:31:49 --> Database Driver Class Initialized
INFO - 2016-09-22 12:31:49 --> Model Class Initialized
INFO - 2016-09-22 12:31:49 --> Model Class Initialized
INFO - 2016-09-22 12:31:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:31:49 --> Config Class Initialized
INFO - 2016-09-22 12:31:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:31:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:31:49 --> Utf8 Class Initialized
INFO - 2016-09-22 12:31:49 --> URI Class Initialized
INFO - 2016-09-22 12:31:49 --> Router Class Initialized
INFO - 2016-09-22 12:31:49 --> Output Class Initialized
INFO - 2016-09-22 12:31:49 --> Security Class Initialized
DEBUG - 2016-09-22 12:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:31:49 --> Input Class Initialized
INFO - 2016-09-22 12:31:49 --> Language Class Initialized
INFO - 2016-09-22 12:31:49 --> Loader Class Initialized
INFO - 2016-09-22 12:31:49 --> Helper loaded: url_helper
INFO - 2016-09-22 12:31:49 --> Helper loaded: language_helper
INFO - 2016-09-22 12:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:31:49 --> Controller Class Initialized
INFO - 2016-09-22 12:31:49 --> Database Driver Class Initialized
INFO - 2016-09-22 12:31:49 --> Model Class Initialized
INFO - 2016-09-22 12:31:49 --> Model Class Initialized
INFO - 2016-09-22 12:31:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:31:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:31:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 12:31:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:31:49 --> Final output sent to browser
DEBUG - 2016-09-22 12:31:49 --> Total execution time: 0.0589
INFO - 2016-09-22 12:32:23 --> Config Class Initialized
INFO - 2016-09-22 12:32:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:23 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:23 --> URI Class Initialized
INFO - 2016-09-22 12:32:23 --> Router Class Initialized
INFO - 2016-09-22 12:32:23 --> Output Class Initialized
INFO - 2016-09-22 12:32:23 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:23 --> Input Class Initialized
INFO - 2016-09-22 12:32:23 --> Language Class Initialized
INFO - 2016-09-22 12:32:23 --> Loader Class Initialized
INFO - 2016-09-22 12:32:23 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:23 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:23 --> Controller Class Initialized
INFO - 2016-09-22 12:32:23 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:23 --> Model Class Initialized
INFO - 2016-09-22 12:32:23 --> Model Class Initialized
INFO - 2016-09-22 12:32:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 12:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:23 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:23 --> Total execution time: 0.0555
INFO - 2016-09-22 12:32:23 --> Config Class Initialized
INFO - 2016-09-22 12:32:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:23 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:23 --> URI Class Initialized
INFO - 2016-09-22 12:32:23 --> Router Class Initialized
INFO - 2016-09-22 12:32:23 --> Output Class Initialized
INFO - 2016-09-22 12:32:23 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:23 --> Input Class Initialized
INFO - 2016-09-22 12:32:23 --> Language Class Initialized
INFO - 2016-09-22 12:32:23 --> Loader Class Initialized
INFO - 2016-09-22 12:32:23 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:23 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:23 --> Controller Class Initialized
INFO - 2016-09-22 12:32:23 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:23 --> Model Class Initialized
INFO - 2016-09-22 12:32:23 --> Model Class Initialized
INFO - 2016-09-22 12:32:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 12:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:23 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:23 --> Total execution time: 0.0630
INFO - 2016-09-22 12:32:25 --> Config Class Initialized
INFO - 2016-09-22 12:32:25 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:25 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:25 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:25 --> URI Class Initialized
INFO - 2016-09-22 12:32:25 --> Router Class Initialized
INFO - 2016-09-22 12:32:25 --> Output Class Initialized
INFO - 2016-09-22 12:32:25 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:25 --> Input Class Initialized
INFO - 2016-09-22 12:32:25 --> Language Class Initialized
INFO - 2016-09-22 12:32:25 --> Loader Class Initialized
INFO - 2016-09-22 12:32:25 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:25 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:25 --> Controller Class Initialized
INFO - 2016-09-22 12:32:25 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:25 --> Model Class Initialized
INFO - 2016-09-22 12:32:25 --> Model Class Initialized
INFO - 2016-09-22 12:32:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:32:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:25 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:25 --> Total execution time: 0.0674
INFO - 2016-09-22 12:32:29 --> Config Class Initialized
INFO - 2016-09-22 12:32:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:29 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:29 --> URI Class Initialized
INFO - 2016-09-22 12:32:29 --> Router Class Initialized
INFO - 2016-09-22 12:32:29 --> Output Class Initialized
INFO - 2016-09-22 12:32:29 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:29 --> Input Class Initialized
INFO - 2016-09-22 12:32:29 --> Language Class Initialized
INFO - 2016-09-22 12:32:29 --> Loader Class Initialized
INFO - 2016-09-22 12:32:29 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:29 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:29 --> Controller Class Initialized
INFO - 2016-09-22 12:32:29 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:29 --> Model Class Initialized
INFO - 2016-09-22 12:32:29 --> Model Class Initialized
INFO - 2016-09-22 12:32:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:29 --> Config Class Initialized
INFO - 2016-09-22 12:32:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:29 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:29 --> URI Class Initialized
INFO - 2016-09-22 12:32:29 --> Router Class Initialized
INFO - 2016-09-22 12:32:29 --> Output Class Initialized
INFO - 2016-09-22 12:32:29 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:29 --> Input Class Initialized
INFO - 2016-09-22 12:32:29 --> Language Class Initialized
INFO - 2016-09-22 12:32:29 --> Loader Class Initialized
INFO - 2016-09-22 12:32:29 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:29 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:29 --> Controller Class Initialized
INFO - 2016-09-22 12:32:29 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:29 --> Model Class Initialized
INFO - 2016-09-22 12:32:29 --> Model Class Initialized
INFO - 2016-09-22 12:32:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:32:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:29 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:29 --> Total execution time: 0.0769
INFO - 2016-09-22 12:32:36 --> Config Class Initialized
INFO - 2016-09-22 12:32:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:36 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:36 --> URI Class Initialized
INFO - 2016-09-22 12:32:36 --> Router Class Initialized
INFO - 2016-09-22 12:32:36 --> Output Class Initialized
INFO - 2016-09-22 12:32:36 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:36 --> Input Class Initialized
INFO - 2016-09-22 12:32:36 --> Language Class Initialized
INFO - 2016-09-22 12:32:36 --> Loader Class Initialized
INFO - 2016-09-22 12:32:36 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:36 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:36 --> Controller Class Initialized
INFO - 2016-09-22 12:32:36 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:36 --> Model Class Initialized
INFO - 2016-09-22 12:32:36 --> Model Class Initialized
INFO - 2016-09-22 12:32:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:36 --> Config Class Initialized
INFO - 2016-09-22 12:32:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:36 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:36 --> URI Class Initialized
INFO - 2016-09-22 12:32:36 --> Router Class Initialized
INFO - 2016-09-22 12:32:36 --> Output Class Initialized
INFO - 2016-09-22 12:32:36 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:36 --> Input Class Initialized
INFO - 2016-09-22 12:32:36 --> Language Class Initialized
INFO - 2016-09-22 12:32:36 --> Loader Class Initialized
INFO - 2016-09-22 12:32:36 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:36 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:36 --> Controller Class Initialized
INFO - 2016-09-22 12:32:36 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:36 --> Model Class Initialized
INFO - 2016-09-22 12:32:36 --> Model Class Initialized
INFO - 2016-09-22 12:32:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:32:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:36 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:36 --> Total execution time: 0.0585
INFO - 2016-09-22 12:32:45 --> Config Class Initialized
INFO - 2016-09-22 12:32:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:45 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:45 --> URI Class Initialized
INFO - 2016-09-22 12:32:45 --> Router Class Initialized
INFO - 2016-09-22 12:32:45 --> Output Class Initialized
INFO - 2016-09-22 12:32:45 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:45 --> Input Class Initialized
INFO - 2016-09-22 12:32:45 --> Language Class Initialized
INFO - 2016-09-22 12:32:45 --> Loader Class Initialized
INFO - 2016-09-22 12:32:45 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:45 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:45 --> Controller Class Initialized
INFO - 2016-09-22 12:32:45 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:45 --> Model Class Initialized
INFO - 2016-09-22 12:32:45 --> Model Class Initialized
INFO - 2016-09-22 12:32:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:45 --> Config Class Initialized
INFO - 2016-09-22 12:32:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:45 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:45 --> URI Class Initialized
INFO - 2016-09-22 12:32:45 --> Router Class Initialized
INFO - 2016-09-22 12:32:45 --> Output Class Initialized
INFO - 2016-09-22 12:32:45 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:45 --> Input Class Initialized
INFO - 2016-09-22 12:32:45 --> Language Class Initialized
INFO - 2016-09-22 12:32:45 --> Loader Class Initialized
INFO - 2016-09-22 12:32:45 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:45 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:45 --> Controller Class Initialized
INFO - 2016-09-22 12:32:45 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:45 --> Model Class Initialized
INFO - 2016-09-22 12:32:45 --> Model Class Initialized
INFO - 2016-09-22 12:32:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:32:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:45 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:45 --> Total execution time: 0.0572
INFO - 2016-09-22 12:32:52 --> Config Class Initialized
INFO - 2016-09-22 12:32:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:52 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:52 --> URI Class Initialized
INFO - 2016-09-22 12:32:52 --> Router Class Initialized
INFO - 2016-09-22 12:32:52 --> Output Class Initialized
INFO - 2016-09-22 12:32:52 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:52 --> Input Class Initialized
INFO - 2016-09-22 12:32:52 --> Language Class Initialized
INFO - 2016-09-22 12:32:52 --> Loader Class Initialized
INFO - 2016-09-22 12:32:52 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:52 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:52 --> Controller Class Initialized
INFO - 2016-09-22 12:32:52 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:52 --> Model Class Initialized
INFO - 2016-09-22 12:32:52 --> Model Class Initialized
INFO - 2016-09-22 12:32:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:52 --> Config Class Initialized
INFO - 2016-09-22 12:32:52 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:32:52 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:32:52 --> Utf8 Class Initialized
INFO - 2016-09-22 12:32:52 --> URI Class Initialized
INFO - 2016-09-22 12:32:52 --> Router Class Initialized
INFO - 2016-09-22 12:32:52 --> Output Class Initialized
INFO - 2016-09-22 12:32:52 --> Security Class Initialized
DEBUG - 2016-09-22 12:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:32:52 --> Input Class Initialized
INFO - 2016-09-22 12:32:52 --> Language Class Initialized
INFO - 2016-09-22 12:32:52 --> Loader Class Initialized
INFO - 2016-09-22 12:32:52 --> Helper loaded: url_helper
INFO - 2016-09-22 12:32:52 --> Helper loaded: language_helper
INFO - 2016-09-22 12:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:32:52 --> Controller Class Initialized
INFO - 2016-09-22 12:32:52 --> Database Driver Class Initialized
INFO - 2016-09-22 12:32:52 --> Model Class Initialized
INFO - 2016-09-22 12:32:52 --> Model Class Initialized
INFO - 2016-09-22 12:32:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:32:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:32:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:32:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:32:52 --> Final output sent to browser
DEBUG - 2016-09-22 12:32:52 --> Total execution time: 0.0603
INFO - 2016-09-22 12:34:18 --> Config Class Initialized
INFO - 2016-09-22 12:34:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:34:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:34:18 --> Utf8 Class Initialized
INFO - 2016-09-22 12:34:18 --> URI Class Initialized
INFO - 2016-09-22 12:34:18 --> Router Class Initialized
INFO - 2016-09-22 12:34:18 --> Output Class Initialized
INFO - 2016-09-22 12:34:18 --> Security Class Initialized
DEBUG - 2016-09-22 12:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:34:18 --> Input Class Initialized
INFO - 2016-09-22 12:34:18 --> Language Class Initialized
INFO - 2016-09-22 12:34:18 --> Loader Class Initialized
INFO - 2016-09-22 12:34:18 --> Helper loaded: url_helper
INFO - 2016-09-22 12:34:18 --> Helper loaded: language_helper
INFO - 2016-09-22 12:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:34:18 --> Controller Class Initialized
INFO - 2016-09-22 12:34:18 --> Database Driver Class Initialized
INFO - 2016-09-22 12:34:18 --> Model Class Initialized
INFO - 2016-09-22 12:34:18 --> Model Class Initialized
INFO - 2016-09-22 12:34:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:34:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:34:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 12:34:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:34:18 --> Final output sent to browser
DEBUG - 2016-09-22 12:34:18 --> Total execution time: 0.0640
INFO - 2016-09-22 12:34:23 --> Config Class Initialized
INFO - 2016-09-22 12:34:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:34:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:34:23 --> Utf8 Class Initialized
INFO - 2016-09-22 12:34:23 --> URI Class Initialized
INFO - 2016-09-22 12:34:23 --> Router Class Initialized
INFO - 2016-09-22 12:34:23 --> Output Class Initialized
INFO - 2016-09-22 12:34:23 --> Security Class Initialized
DEBUG - 2016-09-22 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:34:23 --> Input Class Initialized
INFO - 2016-09-22 12:34:23 --> Language Class Initialized
INFO - 2016-09-22 12:34:23 --> Loader Class Initialized
INFO - 2016-09-22 12:34:23 --> Helper loaded: url_helper
INFO - 2016-09-22 12:34:23 --> Helper loaded: language_helper
INFO - 2016-09-22 12:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:34:23 --> Controller Class Initialized
INFO - 2016-09-22 12:34:23 --> Database Driver Class Initialized
INFO - 2016-09-22 12:34:23 --> Model Class Initialized
INFO - 2016-09-22 12:34:23 --> Model Class Initialized
INFO - 2016-09-22 12:34:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:34:23 --> Config Class Initialized
INFO - 2016-09-22 12:34:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:34:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:34:23 --> Utf8 Class Initialized
INFO - 2016-09-22 12:34:23 --> URI Class Initialized
INFO - 2016-09-22 12:34:23 --> Router Class Initialized
INFO - 2016-09-22 12:34:23 --> Output Class Initialized
INFO - 2016-09-22 12:34:23 --> Security Class Initialized
DEBUG - 2016-09-22 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:34:23 --> Input Class Initialized
INFO - 2016-09-22 12:34:23 --> Language Class Initialized
INFO - 2016-09-22 12:34:23 --> Loader Class Initialized
INFO - 2016-09-22 12:34:23 --> Helper loaded: url_helper
INFO - 2016-09-22 12:34:23 --> Helper loaded: language_helper
INFO - 2016-09-22 12:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:34:23 --> Controller Class Initialized
INFO - 2016-09-22 12:34:23 --> Database Driver Class Initialized
INFO - 2016-09-22 12:34:23 --> Model Class Initialized
INFO - 2016-09-22 12:34:23 --> Model Class Initialized
INFO - 2016-09-22 12:34:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:34:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:34:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:34:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:34:23 --> Final output sent to browser
DEBUG - 2016-09-22 12:34:23 --> Total execution time: 0.0594
INFO - 2016-09-22 12:36:42 --> Config Class Initialized
INFO - 2016-09-22 12:36:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:36:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:36:42 --> Utf8 Class Initialized
INFO - 2016-09-22 12:36:42 --> URI Class Initialized
INFO - 2016-09-22 12:36:42 --> Router Class Initialized
INFO - 2016-09-22 12:36:42 --> Output Class Initialized
INFO - 2016-09-22 12:36:42 --> Security Class Initialized
DEBUG - 2016-09-22 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:36:42 --> Input Class Initialized
INFO - 2016-09-22 12:36:42 --> Language Class Initialized
INFO - 2016-09-22 12:36:42 --> Loader Class Initialized
INFO - 2016-09-22 12:36:42 --> Helper loaded: url_helper
INFO - 2016-09-22 12:36:42 --> Helper loaded: language_helper
INFO - 2016-09-22 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:36:42 --> Controller Class Initialized
INFO - 2016-09-22 12:36:42 --> Database Driver Class Initialized
INFO - 2016-09-22 12:36:42 --> Model Class Initialized
INFO - 2016-09-22 12:36:42 --> Model Class Initialized
INFO - 2016-09-22 12:36:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:36:42 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:36:42 --> Final output sent to browser
DEBUG - 2016-09-22 12:36:42 --> Total execution time: 0.0558
INFO - 2016-09-22 12:36:44 --> Config Class Initialized
INFO - 2016-09-22 12:36:44 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:36:44 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:36:44 --> Utf8 Class Initialized
INFO - 2016-09-22 12:36:44 --> URI Class Initialized
INFO - 2016-09-22 12:36:44 --> Router Class Initialized
INFO - 2016-09-22 12:36:44 --> Output Class Initialized
INFO - 2016-09-22 12:36:44 --> Security Class Initialized
DEBUG - 2016-09-22 12:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:36:44 --> Input Class Initialized
INFO - 2016-09-22 12:36:44 --> Language Class Initialized
INFO - 2016-09-22 12:36:44 --> Loader Class Initialized
INFO - 2016-09-22 12:36:44 --> Helper loaded: url_helper
INFO - 2016-09-22 12:36:44 --> Helper loaded: language_helper
INFO - 2016-09-22 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:36:44 --> Controller Class Initialized
INFO - 2016-09-22 12:36:44 --> Database Driver Class Initialized
INFO - 2016-09-22 12:36:44 --> Model Class Initialized
INFO - 2016-09-22 12:36:44 --> Model Class Initialized
INFO - 2016-09-22 12:36:44 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:36:44 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:36:44 --> Final output sent to browser
DEBUG - 2016-09-22 12:36:44 --> Total execution time: 0.0538
INFO - 2016-09-22 12:37:01 --> Config Class Initialized
INFO - 2016-09-22 12:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:37:01 --> Utf8 Class Initialized
INFO - 2016-09-22 12:37:01 --> URI Class Initialized
INFO - 2016-09-22 12:37:01 --> Router Class Initialized
INFO - 2016-09-22 12:37:01 --> Output Class Initialized
INFO - 2016-09-22 12:37:01 --> Security Class Initialized
DEBUG - 2016-09-22 12:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:37:01 --> Input Class Initialized
INFO - 2016-09-22 12:37:01 --> Language Class Initialized
INFO - 2016-09-22 12:37:01 --> Loader Class Initialized
INFO - 2016-09-22 12:37:01 --> Helper loaded: url_helper
INFO - 2016-09-22 12:37:01 --> Helper loaded: language_helper
INFO - 2016-09-22 12:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:37:01 --> Controller Class Initialized
INFO - 2016-09-22 12:37:01 --> Database Driver Class Initialized
INFO - 2016-09-22 12:37:01 --> Model Class Initialized
INFO - 2016-09-22 12:37:01 --> Model Class Initialized
INFO - 2016-09-22 12:37:01 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:37:01 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:37:01 --> Final output sent to browser
DEBUG - 2016-09-22 12:37:01 --> Total execution time: 0.0703
INFO - 2016-09-22 12:37:03 --> Config Class Initialized
INFO - 2016-09-22 12:37:03 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:37:03 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:37:03 --> Utf8 Class Initialized
INFO - 2016-09-22 12:37:03 --> URI Class Initialized
INFO - 2016-09-22 12:37:03 --> Router Class Initialized
INFO - 2016-09-22 12:37:03 --> Output Class Initialized
INFO - 2016-09-22 12:37:03 --> Security Class Initialized
DEBUG - 2016-09-22 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:37:03 --> Input Class Initialized
INFO - 2016-09-22 12:37:03 --> Language Class Initialized
INFO - 2016-09-22 12:37:03 --> Loader Class Initialized
INFO - 2016-09-22 12:37:03 --> Helper loaded: url_helper
INFO - 2016-09-22 12:37:03 --> Helper loaded: language_helper
INFO - 2016-09-22 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:37:03 --> Controller Class Initialized
INFO - 2016-09-22 12:37:03 --> Database Driver Class Initialized
INFO - 2016-09-22 12:37:03 --> Model Class Initialized
INFO - 2016-09-22 12:37:03 --> Model Class Initialized
INFO - 2016-09-22 12:37:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:37:03 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:37:03 --> Final output sent to browser
DEBUG - 2016-09-22 12:37:03 --> Total execution time: 0.0653
INFO - 2016-09-22 12:37:04 --> Config Class Initialized
INFO - 2016-09-22 12:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:37:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:37:04 --> Utf8 Class Initialized
INFO - 2016-09-22 12:37:04 --> URI Class Initialized
INFO - 2016-09-22 12:37:04 --> Router Class Initialized
INFO - 2016-09-22 12:37:04 --> Output Class Initialized
INFO - 2016-09-22 12:37:04 --> Security Class Initialized
DEBUG - 2016-09-22 12:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:37:04 --> Input Class Initialized
INFO - 2016-09-22 12:37:04 --> Language Class Initialized
INFO - 2016-09-22 12:37:04 --> Loader Class Initialized
INFO - 2016-09-22 12:37:04 --> Helper loaded: url_helper
INFO - 2016-09-22 12:37:04 --> Helper loaded: language_helper
INFO - 2016-09-22 12:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:37:04 --> Controller Class Initialized
INFO - 2016-09-22 12:37:04 --> Database Driver Class Initialized
INFO - 2016-09-22 12:37:04 --> Model Class Initialized
INFO - 2016-09-22 12:37:04 --> Model Class Initialized
INFO - 2016-09-22 12:37:04 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:37:04 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:37:04 --> Final output sent to browser
DEBUG - 2016-09-22 12:37:04 --> Total execution time: 0.0554
INFO - 2016-09-22 12:37:14 --> Config Class Initialized
INFO - 2016-09-22 12:37:14 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:37:14 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:37:14 --> Utf8 Class Initialized
INFO - 2016-09-22 12:37:14 --> URI Class Initialized
INFO - 2016-09-22 12:37:14 --> Router Class Initialized
INFO - 2016-09-22 12:37:14 --> Output Class Initialized
INFO - 2016-09-22 12:37:14 --> Security Class Initialized
DEBUG - 2016-09-22 12:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:37:14 --> Input Class Initialized
INFO - 2016-09-22 12:37:14 --> Language Class Initialized
INFO - 2016-09-22 12:37:14 --> Loader Class Initialized
INFO - 2016-09-22 12:37:14 --> Helper loaded: url_helper
INFO - 2016-09-22 12:37:14 --> Helper loaded: language_helper
INFO - 2016-09-22 12:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:37:14 --> Controller Class Initialized
INFO - 2016-09-22 12:37:14 --> Database Driver Class Initialized
INFO - 2016-09-22 12:37:14 --> Model Class Initialized
INFO - 2016-09-22 12:37:14 --> Model Class Initialized
INFO - 2016-09-22 12:37:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:37:14 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:37:14 --> Final output sent to browser
DEBUG - 2016-09-22 12:37:14 --> Total execution time: 0.0561
INFO - 2016-09-22 12:39:27 --> Config Class Initialized
INFO - 2016-09-22 12:39:27 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:39:27 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:39:27 --> Utf8 Class Initialized
INFO - 2016-09-22 12:39:27 --> URI Class Initialized
INFO - 2016-09-22 12:39:27 --> Router Class Initialized
INFO - 2016-09-22 12:39:27 --> Output Class Initialized
INFO - 2016-09-22 12:39:27 --> Security Class Initialized
DEBUG - 2016-09-22 12:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:39:27 --> Input Class Initialized
INFO - 2016-09-22 12:39:27 --> Language Class Initialized
INFO - 2016-09-22 12:39:27 --> Loader Class Initialized
INFO - 2016-09-22 12:39:27 --> Helper loaded: url_helper
INFO - 2016-09-22 12:39:27 --> Helper loaded: language_helper
INFO - 2016-09-22 12:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:39:27 --> Controller Class Initialized
INFO - 2016-09-22 12:39:27 --> Database Driver Class Initialized
INFO - 2016-09-22 12:39:27 --> Model Class Initialized
INFO - 2016-09-22 12:39:27 --> Model Class Initialized
INFO - 2016-09-22 12:39:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:39:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:39:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:39:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:39:27 --> Final output sent to browser
DEBUG - 2016-09-22 12:39:27 --> Total execution time: 0.0814
INFO - 2016-09-22 12:39:29 --> Config Class Initialized
INFO - 2016-09-22 12:39:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:39:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:39:29 --> Utf8 Class Initialized
INFO - 2016-09-22 12:39:29 --> URI Class Initialized
INFO - 2016-09-22 12:39:29 --> Router Class Initialized
INFO - 2016-09-22 12:39:29 --> Output Class Initialized
INFO - 2016-09-22 12:39:29 --> Security Class Initialized
DEBUG - 2016-09-22 12:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:39:29 --> Input Class Initialized
INFO - 2016-09-22 12:39:29 --> Language Class Initialized
INFO - 2016-09-22 12:39:29 --> Loader Class Initialized
INFO - 2016-09-22 12:39:29 --> Helper loaded: url_helper
INFO - 2016-09-22 12:39:29 --> Helper loaded: language_helper
INFO - 2016-09-22 12:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:39:29 --> Controller Class Initialized
INFO - 2016-09-22 12:39:29 --> Database Driver Class Initialized
INFO - 2016-09-22 12:39:29 --> Model Class Initialized
INFO - 2016-09-22 12:39:29 --> Model Class Initialized
INFO - 2016-09-22 12:39:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:39:29 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:39:29 --> Final output sent to browser
DEBUG - 2016-09-22 12:39:29 --> Total execution time: 0.0644
INFO - 2016-09-22 12:39:33 --> Config Class Initialized
INFO - 2016-09-22 12:39:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:39:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:39:33 --> Utf8 Class Initialized
INFO - 2016-09-22 12:39:33 --> URI Class Initialized
INFO - 2016-09-22 12:39:33 --> Router Class Initialized
INFO - 2016-09-22 12:39:33 --> Output Class Initialized
INFO - 2016-09-22 12:39:33 --> Security Class Initialized
DEBUG - 2016-09-22 12:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:39:33 --> Input Class Initialized
INFO - 2016-09-22 12:39:33 --> Language Class Initialized
INFO - 2016-09-22 12:39:33 --> Loader Class Initialized
INFO - 2016-09-22 12:39:33 --> Helper loaded: url_helper
INFO - 2016-09-22 12:39:33 --> Helper loaded: language_helper
INFO - 2016-09-22 12:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:39:33 --> Controller Class Initialized
INFO - 2016-09-22 12:39:33 --> Database Driver Class Initialized
INFO - 2016-09-22 12:39:33 --> Model Class Initialized
INFO - 2016-09-22 12:39:33 --> Model Class Initialized
INFO - 2016-09-22 12:39:33 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:39:33 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:39:33 --> Final output sent to browser
DEBUG - 2016-09-22 12:39:33 --> Total execution time: 0.0577
INFO - 2016-09-22 12:50:03 --> Config Class Initialized
INFO - 2016-09-22 12:50:03 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:50:03 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:50:03 --> Utf8 Class Initialized
INFO - 2016-09-22 12:50:03 --> URI Class Initialized
INFO - 2016-09-22 12:50:03 --> Router Class Initialized
INFO - 2016-09-22 12:50:03 --> Output Class Initialized
INFO - 2016-09-22 12:50:03 --> Security Class Initialized
DEBUG - 2016-09-22 12:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:50:03 --> Input Class Initialized
INFO - 2016-09-22 12:50:03 --> Language Class Initialized
INFO - 2016-09-22 12:50:03 --> Loader Class Initialized
INFO - 2016-09-22 12:50:03 --> Helper loaded: url_helper
INFO - 2016-09-22 12:50:03 --> Helper loaded: language_helper
INFO - 2016-09-22 12:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:50:03 --> Controller Class Initialized
INFO - 2016-09-22 12:50:03 --> Database Driver Class Initialized
INFO - 2016-09-22 12:50:03 --> Model Class Initialized
INFO - 2016-09-22 12:50:03 --> Model Class Initialized
INFO - 2016-09-22 12:50:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:50:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:50:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:50:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:50:03 --> Final output sent to browser
DEBUG - 2016-09-22 12:50:03 --> Total execution time: 0.0841
INFO - 2016-09-22 12:50:05 --> Config Class Initialized
INFO - 2016-09-22 12:50:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:50:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:50:05 --> Utf8 Class Initialized
INFO - 2016-09-22 12:50:05 --> URI Class Initialized
INFO - 2016-09-22 12:50:05 --> Router Class Initialized
INFO - 2016-09-22 12:50:05 --> Output Class Initialized
INFO - 2016-09-22 12:50:05 --> Security Class Initialized
DEBUG - 2016-09-22 12:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:50:05 --> Input Class Initialized
INFO - 2016-09-22 12:50:05 --> Language Class Initialized
INFO - 2016-09-22 12:50:05 --> Loader Class Initialized
INFO - 2016-09-22 12:50:05 --> Helper loaded: url_helper
INFO - 2016-09-22 12:50:05 --> Helper loaded: language_helper
INFO - 2016-09-22 12:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:50:05 --> Controller Class Initialized
INFO - 2016-09-22 12:50:05 --> Database Driver Class Initialized
INFO - 2016-09-22 12:50:05 --> Model Class Initialized
INFO - 2016-09-22 12:50:05 --> Model Class Initialized
INFO - 2016-09-22 12:50:05 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:50:05 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:50:05 --> Final output sent to browser
DEBUG - 2016-09-22 12:50:05 --> Total execution time: 0.0686
INFO - 2016-09-22 12:50:28 --> Config Class Initialized
INFO - 2016-09-22 12:50:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:50:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:50:28 --> Utf8 Class Initialized
INFO - 2016-09-22 12:50:28 --> URI Class Initialized
INFO - 2016-09-22 12:50:28 --> Router Class Initialized
INFO - 2016-09-22 12:50:28 --> Output Class Initialized
INFO - 2016-09-22 12:50:28 --> Security Class Initialized
DEBUG - 2016-09-22 12:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:50:28 --> Input Class Initialized
INFO - 2016-09-22 12:50:28 --> Language Class Initialized
INFO - 2016-09-22 12:50:28 --> Loader Class Initialized
INFO - 2016-09-22 12:50:28 --> Helper loaded: url_helper
INFO - 2016-09-22 12:50:28 --> Helper loaded: language_helper
INFO - 2016-09-22 12:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:50:28 --> Controller Class Initialized
INFO - 2016-09-22 12:50:28 --> Database Driver Class Initialized
INFO - 2016-09-22 12:50:28 --> Model Class Initialized
INFO - 2016-09-22 12:50:28 --> Model Class Initialized
INFO - 2016-09-22 12:50:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:50:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:50:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:50:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:50:28 --> Final output sent to browser
DEBUG - 2016-09-22 12:50:28 --> Total execution time: 0.0810
INFO - 2016-09-22 12:50:29 --> Config Class Initialized
INFO - 2016-09-22 12:50:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:50:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:50:29 --> Utf8 Class Initialized
INFO - 2016-09-22 12:50:29 --> URI Class Initialized
INFO - 2016-09-22 12:50:29 --> Router Class Initialized
INFO - 2016-09-22 12:50:29 --> Output Class Initialized
INFO - 2016-09-22 12:50:29 --> Security Class Initialized
DEBUG - 2016-09-22 12:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:50:29 --> Input Class Initialized
INFO - 2016-09-22 12:50:29 --> Language Class Initialized
INFO - 2016-09-22 12:50:29 --> Loader Class Initialized
INFO - 2016-09-22 12:50:29 --> Helper loaded: url_helper
INFO - 2016-09-22 12:50:29 --> Helper loaded: language_helper
INFO - 2016-09-22 12:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:50:29 --> Controller Class Initialized
INFO - 2016-09-22 12:50:29 --> Database Driver Class Initialized
INFO - 2016-09-22 12:50:29 --> Model Class Initialized
INFO - 2016-09-22 12:50:29 --> Model Class Initialized
INFO - 2016-09-22 12:50:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:50:29 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:50:29 --> Final output sent to browser
DEBUG - 2016-09-22 12:50:29 --> Total execution time: 0.0785
INFO - 2016-09-22 12:55:05 --> Config Class Initialized
INFO - 2016-09-22 12:55:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:55:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:55:05 --> Utf8 Class Initialized
INFO - 2016-09-22 12:55:05 --> URI Class Initialized
INFO - 2016-09-22 12:55:05 --> Router Class Initialized
INFO - 2016-09-22 12:55:05 --> Output Class Initialized
INFO - 2016-09-22 12:55:05 --> Security Class Initialized
DEBUG - 2016-09-22 12:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:55:05 --> Input Class Initialized
INFO - 2016-09-22 12:55:05 --> Language Class Initialized
INFO - 2016-09-22 12:55:05 --> Loader Class Initialized
INFO - 2016-09-22 12:55:05 --> Helper loaded: url_helper
INFO - 2016-09-22 12:55:05 --> Helper loaded: language_helper
INFO - 2016-09-22 12:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:55:05 --> Controller Class Initialized
INFO - 2016-09-22 12:55:05 --> Database Driver Class Initialized
INFO - 2016-09-22 12:55:05 --> Model Class Initialized
INFO - 2016-09-22 12:55:05 --> Model Class Initialized
INFO - 2016-09-22 12:55:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:55:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:55:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:55:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:55:05 --> Final output sent to browser
DEBUG - 2016-09-22 12:55:05 --> Total execution time: 0.0832
INFO - 2016-09-22 12:57:08 --> Config Class Initialized
INFO - 2016-09-22 12:57:08 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:57:08 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:57:08 --> Utf8 Class Initialized
INFO - 2016-09-22 12:57:08 --> URI Class Initialized
INFO - 2016-09-22 12:57:08 --> Router Class Initialized
INFO - 2016-09-22 12:57:08 --> Output Class Initialized
INFO - 2016-09-22 12:57:08 --> Security Class Initialized
DEBUG - 2016-09-22 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:57:08 --> Input Class Initialized
INFO - 2016-09-22 12:57:08 --> Language Class Initialized
INFO - 2016-09-22 12:57:08 --> Loader Class Initialized
INFO - 2016-09-22 12:57:08 --> Helper loaded: url_helper
INFO - 2016-09-22 12:57:08 --> Helper loaded: language_helper
INFO - 2016-09-22 12:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:57:08 --> Controller Class Initialized
INFO - 2016-09-22 12:57:08 --> Database Driver Class Initialized
INFO - 2016-09-22 12:57:08 --> Model Class Initialized
INFO - 2016-09-22 12:57:08 --> Model Class Initialized
INFO - 2016-09-22 12:57:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:57:08 --> Final output sent to browser
DEBUG - 2016-09-22 12:57:08 --> Total execution time: 0.0682
INFO - 2016-09-22 12:57:09 --> Config Class Initialized
INFO - 2016-09-22 12:57:09 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:57:09 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:57:09 --> Utf8 Class Initialized
INFO - 2016-09-22 12:57:09 --> URI Class Initialized
INFO - 2016-09-22 12:57:09 --> Router Class Initialized
INFO - 2016-09-22 12:57:09 --> Output Class Initialized
INFO - 2016-09-22 12:57:09 --> Security Class Initialized
DEBUG - 2016-09-22 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:57:09 --> Input Class Initialized
INFO - 2016-09-22 12:57:09 --> Language Class Initialized
INFO - 2016-09-22 12:57:09 --> Loader Class Initialized
INFO - 2016-09-22 12:57:09 --> Helper loaded: url_helper
INFO - 2016-09-22 12:57:09 --> Helper loaded: language_helper
INFO - 2016-09-22 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:57:09 --> Controller Class Initialized
INFO - 2016-09-22 12:57:09 --> Database Driver Class Initialized
INFO - 2016-09-22 12:57:09 --> Model Class Initialized
INFO - 2016-09-22 12:57:09 --> Model Class Initialized
INFO - 2016-09-22 12:57:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:57:09 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:57:09 --> Final output sent to browser
DEBUG - 2016-09-22 12:57:09 --> Total execution time: 0.0808
INFO - 2016-09-22 12:57:28 --> Config Class Initialized
INFO - 2016-09-22 12:57:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:57:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:57:28 --> Utf8 Class Initialized
INFO - 2016-09-22 12:57:28 --> URI Class Initialized
INFO - 2016-09-22 12:57:28 --> Router Class Initialized
INFO - 2016-09-22 12:57:28 --> Output Class Initialized
INFO - 2016-09-22 12:57:28 --> Security Class Initialized
DEBUG - 2016-09-22 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:57:28 --> Input Class Initialized
INFO - 2016-09-22 12:57:28 --> Language Class Initialized
INFO - 2016-09-22 12:57:28 --> Loader Class Initialized
INFO - 2016-09-22 12:57:28 --> Helper loaded: url_helper
INFO - 2016-09-22 12:57:28 --> Helper loaded: language_helper
INFO - 2016-09-22 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:57:28 --> Controller Class Initialized
INFO - 2016-09-22 12:57:28 --> Database Driver Class Initialized
INFO - 2016-09-22 12:57:28 --> Model Class Initialized
INFO - 2016-09-22 12:57:28 --> Model Class Initialized
INFO - 2016-09-22 12:57:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:57:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:57:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:57:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:57:28 --> Final output sent to browser
DEBUG - 2016-09-22 12:57:28 --> Total execution time: 0.0718
INFO - 2016-09-22 12:57:30 --> Config Class Initialized
INFO - 2016-09-22 12:57:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:57:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:57:30 --> Utf8 Class Initialized
INFO - 2016-09-22 12:57:30 --> URI Class Initialized
INFO - 2016-09-22 12:57:30 --> Router Class Initialized
INFO - 2016-09-22 12:57:30 --> Output Class Initialized
INFO - 2016-09-22 12:57:30 --> Security Class Initialized
DEBUG - 2016-09-22 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:57:30 --> Input Class Initialized
INFO - 2016-09-22 12:57:30 --> Language Class Initialized
INFO - 2016-09-22 12:57:30 --> Loader Class Initialized
INFO - 2016-09-22 12:57:30 --> Helper loaded: url_helper
INFO - 2016-09-22 12:57:30 --> Helper loaded: language_helper
INFO - 2016-09-22 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:57:30 --> Controller Class Initialized
INFO - 2016-09-22 12:57:30 --> Database Driver Class Initialized
INFO - 2016-09-22 12:57:30 --> Model Class Initialized
INFO - 2016-09-22 12:57:30 --> Model Class Initialized
INFO - 2016-09-22 12:57:30 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:57:30 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:57:30 --> Final output sent to browser
DEBUG - 2016-09-22 12:57:30 --> Total execution time: 0.0738
INFO - 2016-09-22 12:58:02 --> Config Class Initialized
INFO - 2016-09-22 12:58:02 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:58:02 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:58:02 --> Utf8 Class Initialized
INFO - 2016-09-22 12:58:02 --> URI Class Initialized
INFO - 2016-09-22 12:58:02 --> Router Class Initialized
INFO - 2016-09-22 12:58:02 --> Output Class Initialized
INFO - 2016-09-22 12:58:02 --> Security Class Initialized
DEBUG - 2016-09-22 12:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:58:02 --> Input Class Initialized
INFO - 2016-09-22 12:58:02 --> Language Class Initialized
INFO - 2016-09-22 12:58:02 --> Loader Class Initialized
INFO - 2016-09-22 12:58:02 --> Helper loaded: url_helper
INFO - 2016-09-22 12:58:02 --> Helper loaded: language_helper
INFO - 2016-09-22 12:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:58:02 --> Controller Class Initialized
INFO - 2016-09-22 12:58:02 --> Database Driver Class Initialized
INFO - 2016-09-22 12:58:02 --> Model Class Initialized
INFO - 2016-09-22 12:58:02 --> Model Class Initialized
INFO - 2016-09-22 12:58:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 12:58:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 12:58:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 12:58:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 12:58:02 --> Final output sent to browser
DEBUG - 2016-09-22 12:58:02 --> Total execution time: 0.0781
INFO - 2016-09-22 12:58:04 --> Config Class Initialized
INFO - 2016-09-22 12:58:04 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:58:04 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:58:04 --> Utf8 Class Initialized
INFO - 2016-09-22 12:58:04 --> URI Class Initialized
INFO - 2016-09-22 12:58:04 --> Router Class Initialized
INFO - 2016-09-22 12:58:04 --> Output Class Initialized
INFO - 2016-09-22 12:58:04 --> Security Class Initialized
DEBUG - 2016-09-22 12:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:58:04 --> Input Class Initialized
INFO - 2016-09-22 12:58:04 --> Language Class Initialized
INFO - 2016-09-22 12:58:04 --> Loader Class Initialized
INFO - 2016-09-22 12:58:04 --> Helper loaded: url_helper
INFO - 2016-09-22 12:58:04 --> Helper loaded: language_helper
INFO - 2016-09-22 12:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:58:04 --> Controller Class Initialized
INFO - 2016-09-22 12:58:04 --> Database Driver Class Initialized
INFO - 2016-09-22 12:58:04 --> Model Class Initialized
INFO - 2016-09-22 12:58:04 --> Model Class Initialized
INFO - 2016-09-22 12:58:04 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:58:04 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 577
INFO - 2016-09-22 12:58:04 --> Final output sent to browser
DEBUG - 2016-09-22 12:58:04 --> Total execution time: 0.0655
INFO - 2016-09-22 12:58:05 --> Config Class Initialized
INFO - 2016-09-22 12:58:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 12:58:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 12:58:05 --> Utf8 Class Initialized
INFO - 2016-09-22 12:58:05 --> URI Class Initialized
INFO - 2016-09-22 12:58:05 --> Router Class Initialized
INFO - 2016-09-22 12:58:05 --> Output Class Initialized
INFO - 2016-09-22 12:58:05 --> Security Class Initialized
DEBUG - 2016-09-22 12:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 12:58:05 --> Input Class Initialized
INFO - 2016-09-22 12:58:05 --> Language Class Initialized
INFO - 2016-09-22 12:58:05 --> Loader Class Initialized
INFO - 2016-09-22 12:58:05 --> Helper loaded: url_helper
INFO - 2016-09-22 12:58:05 --> Helper loaded: language_helper
INFO - 2016-09-22 12:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 12:58:05 --> Controller Class Initialized
INFO - 2016-09-22 12:58:05 --> Database Driver Class Initialized
INFO - 2016-09-22 12:58:05 --> Model Class Initialized
INFO - 2016-09-22 12:58:05 --> Model Class Initialized
INFO - 2016-09-22 12:58:05 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 12:58:05 --> Severity: Notice --> Undefined index: rid C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 277
INFO - 2016-09-22 12:58:05 --> Final output sent to browser
DEBUG - 2016-09-22 12:58:05 --> Total execution time: 0.0639
INFO - 2016-09-22 13:00:40 --> Config Class Initialized
INFO - 2016-09-22 13:00:40 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:00:40 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:00:40 --> Utf8 Class Initialized
INFO - 2016-09-22 13:00:40 --> URI Class Initialized
INFO - 2016-09-22 13:00:40 --> Router Class Initialized
INFO - 2016-09-22 13:00:40 --> Output Class Initialized
INFO - 2016-09-22 13:00:40 --> Security Class Initialized
DEBUG - 2016-09-22 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:00:40 --> Input Class Initialized
INFO - 2016-09-22 13:00:40 --> Language Class Initialized
INFO - 2016-09-22 13:00:40 --> Loader Class Initialized
INFO - 2016-09-22 13:00:40 --> Helper loaded: url_helper
INFO - 2016-09-22 13:00:40 --> Helper loaded: language_helper
INFO - 2016-09-22 13:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:00:40 --> Controller Class Initialized
INFO - 2016-09-22 13:00:40 --> Database Driver Class Initialized
INFO - 2016-09-22 13:00:40 --> Model Class Initialized
INFO - 2016-09-22 13:00:40 --> Model Class Initialized
INFO - 2016-09-22 13:00:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:00:41 --> Final output sent to browser
DEBUG - 2016-09-22 13:00:41 --> Total execution time: 0.0894
INFO - 2016-09-22 13:00:42 --> Config Class Initialized
INFO - 2016-09-22 13:00:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:00:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:00:42 --> Utf8 Class Initialized
INFO - 2016-09-22 13:00:42 --> URI Class Initialized
INFO - 2016-09-22 13:00:42 --> Router Class Initialized
INFO - 2016-09-22 13:00:42 --> Output Class Initialized
INFO - 2016-09-22 13:00:42 --> Security Class Initialized
DEBUG - 2016-09-22 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:00:42 --> Input Class Initialized
INFO - 2016-09-22 13:00:42 --> Language Class Initialized
INFO - 2016-09-22 13:00:42 --> Loader Class Initialized
INFO - 2016-09-22 13:00:42 --> Helper loaded: url_helper
INFO - 2016-09-22 13:00:42 --> Helper loaded: language_helper
INFO - 2016-09-22 13:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:00:42 --> Controller Class Initialized
INFO - 2016-09-22 13:00:42 --> Database Driver Class Initialized
INFO - 2016-09-22 13:00:42 --> Model Class Initialized
INFO - 2016-09-22 13:00:42 --> Model Class Initialized
INFO - 2016-09-22 13:00:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:00:42 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:00:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:00:42 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:00:42 --> Final output sent to browser
DEBUG - 2016-09-22 13:00:42 --> Total execution time: 0.0872
INFO - 2016-09-22 13:00:43 --> Config Class Initialized
INFO - 2016-09-22 13:00:43 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:00:43 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:00:43 --> Utf8 Class Initialized
INFO - 2016-09-22 13:00:43 --> URI Class Initialized
INFO - 2016-09-22 13:00:43 --> Router Class Initialized
INFO - 2016-09-22 13:00:43 --> Output Class Initialized
INFO - 2016-09-22 13:00:43 --> Security Class Initialized
DEBUG - 2016-09-22 13:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:00:43 --> Input Class Initialized
INFO - 2016-09-22 13:00:43 --> Language Class Initialized
INFO - 2016-09-22 13:00:44 --> Loader Class Initialized
INFO - 2016-09-22 13:00:44 --> Helper loaded: url_helper
INFO - 2016-09-22 13:00:44 --> Helper loaded: language_helper
INFO - 2016-09-22 13:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:00:44 --> Controller Class Initialized
INFO - 2016-09-22 13:00:44 --> Database Driver Class Initialized
INFO - 2016-09-22 13:00:44 --> Model Class Initialized
INFO - 2016-09-22 13:00:44 --> Model Class Initialized
INFO - 2016-09-22 13:00:44 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:00:44 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 296
ERROR - 2016-09-22 13:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 296
ERROR - 2016-09-22 13:00:44 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 483
INFO - 2016-09-22 13:00:44 --> Final output sent to browser
DEBUG - 2016-09-22 13:00:44 --> Total execution time: 0.0853
INFO - 2016-09-22 13:01:28 --> Config Class Initialized
INFO - 2016-09-22 13:01:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:01:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:01:28 --> Utf8 Class Initialized
INFO - 2016-09-22 13:01:28 --> URI Class Initialized
INFO - 2016-09-22 13:01:28 --> Router Class Initialized
INFO - 2016-09-22 13:01:28 --> Output Class Initialized
INFO - 2016-09-22 13:01:28 --> Security Class Initialized
DEBUG - 2016-09-22 13:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:01:28 --> Input Class Initialized
INFO - 2016-09-22 13:01:28 --> Language Class Initialized
INFO - 2016-09-22 13:01:28 --> Loader Class Initialized
INFO - 2016-09-22 13:01:28 --> Helper loaded: url_helper
INFO - 2016-09-22 13:01:28 --> Helper loaded: language_helper
INFO - 2016-09-22 13:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:01:28 --> Controller Class Initialized
INFO - 2016-09-22 13:01:28 --> Database Driver Class Initialized
INFO - 2016-09-22 13:01:28 --> Model Class Initialized
INFO - 2016-09-22 13:01:28 --> Model Class Initialized
INFO - 2016-09-22 13:01:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:01:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 13:01:28 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
ERROR - 2016-09-22 13:01:28 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
ERROR - 2016-09-22 13:01:28 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
ERROR - 2016-09-22 13:01:28 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
INFO - 2016-09-22 13:01:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:01:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:01:28 --> Final output sent to browser
DEBUG - 2016-09-22 13:01:28 --> Total execution time: 0.0889
INFO - 2016-09-22 13:01:29 --> Config Class Initialized
INFO - 2016-09-22 13:01:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:01:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:01:29 --> Utf8 Class Initialized
INFO - 2016-09-22 13:01:29 --> URI Class Initialized
INFO - 2016-09-22 13:01:29 --> Router Class Initialized
INFO - 2016-09-22 13:01:29 --> Output Class Initialized
INFO - 2016-09-22 13:01:29 --> Security Class Initialized
DEBUG - 2016-09-22 13:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:01:29 --> Input Class Initialized
INFO - 2016-09-22 13:01:29 --> Language Class Initialized
INFO - 2016-09-22 13:01:29 --> Loader Class Initialized
INFO - 2016-09-22 13:01:29 --> Helper loaded: url_helper
INFO - 2016-09-22 13:01:29 --> Helper loaded: language_helper
INFO - 2016-09-22 13:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:01:29 --> Controller Class Initialized
INFO - 2016-09-22 13:01:29 --> Database Driver Class Initialized
INFO - 2016-09-22 13:01:29 --> Model Class Initialized
INFO - 2016-09-22 13:01:29 --> Model Class Initialized
INFO - 2016-09-22 13:01:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:01:29 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:01:29 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:01:29 --> Final output sent to browser
DEBUG - 2016-09-22 13:01:29 --> Total execution time: 0.0879
INFO - 2016-09-22 13:01:30 --> Config Class Initialized
INFO - 2016-09-22 13:01:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:01:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:01:30 --> Utf8 Class Initialized
INFO - 2016-09-22 13:01:30 --> URI Class Initialized
INFO - 2016-09-22 13:01:30 --> Router Class Initialized
INFO - 2016-09-22 13:01:30 --> Output Class Initialized
INFO - 2016-09-22 13:01:30 --> Security Class Initialized
DEBUG - 2016-09-22 13:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:01:30 --> Input Class Initialized
INFO - 2016-09-22 13:01:30 --> Language Class Initialized
INFO - 2016-09-22 13:01:30 --> Loader Class Initialized
INFO - 2016-09-22 13:01:30 --> Helper loaded: url_helper
INFO - 2016-09-22 13:01:30 --> Helper loaded: language_helper
INFO - 2016-09-22 13:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:01:30 --> Controller Class Initialized
INFO - 2016-09-22 13:01:30 --> Database Driver Class Initialized
INFO - 2016-09-22 13:01:30 --> Model Class Initialized
INFO - 2016-09-22 13:01:30 --> Model Class Initialized
INFO - 2016-09-22 13:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:01:30 --> Final output sent to browser
DEBUG - 2016-09-22 13:01:30 --> Total execution time: 0.0570
INFO - 2016-09-22 13:01:39 --> Config Class Initialized
INFO - 2016-09-22 13:01:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:01:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:01:39 --> Utf8 Class Initialized
INFO - 2016-09-22 13:01:39 --> URI Class Initialized
INFO - 2016-09-22 13:01:39 --> Router Class Initialized
INFO - 2016-09-22 13:01:39 --> Output Class Initialized
INFO - 2016-09-22 13:01:39 --> Security Class Initialized
DEBUG - 2016-09-22 13:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:01:39 --> Input Class Initialized
INFO - 2016-09-22 13:01:39 --> Language Class Initialized
INFO - 2016-09-22 13:01:39 --> Loader Class Initialized
INFO - 2016-09-22 13:01:39 --> Helper loaded: url_helper
INFO - 2016-09-22 13:01:39 --> Helper loaded: language_helper
INFO - 2016-09-22 13:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:01:39 --> Controller Class Initialized
INFO - 2016-09-22 13:01:39 --> Database Driver Class Initialized
INFO - 2016-09-22 13:01:39 --> Model Class Initialized
INFO - 2016-09-22 13:01:39 --> Model Class Initialized
INFO - 2016-09-22 13:01:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:01:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 13:01:39 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
ERROR - 2016-09-22 13:01:39 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
ERROR - 2016-09-22 13:01:39 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
ERROR - 2016-09-22 13:01:39 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 64
INFO - 2016-09-22 13:01:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:01:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:01:39 --> Final output sent to browser
DEBUG - 2016-09-22 13:01:39 --> Total execution time: 0.0722
INFO - 2016-09-22 13:01:41 --> Config Class Initialized
INFO - 2016-09-22 13:01:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:01:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:01:41 --> Utf8 Class Initialized
INFO - 2016-09-22 13:01:41 --> URI Class Initialized
INFO - 2016-09-22 13:01:41 --> Router Class Initialized
INFO - 2016-09-22 13:01:41 --> Output Class Initialized
INFO - 2016-09-22 13:01:41 --> Security Class Initialized
DEBUG - 2016-09-22 13:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:01:41 --> Input Class Initialized
INFO - 2016-09-22 13:01:41 --> Language Class Initialized
INFO - 2016-09-22 13:01:41 --> Loader Class Initialized
INFO - 2016-09-22 13:01:41 --> Helper loaded: url_helper
INFO - 2016-09-22 13:01:41 --> Helper loaded: language_helper
INFO - 2016-09-22 13:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:01:41 --> Controller Class Initialized
INFO - 2016-09-22 13:01:41 --> Database Driver Class Initialized
INFO - 2016-09-22 13:01:41 --> Model Class Initialized
INFO - 2016-09-22 13:01:41 --> Model Class Initialized
INFO - 2016-09-22 13:01:41 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:01:41 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:01:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:01:41 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:01:41 --> Final output sent to browser
DEBUG - 2016-09-22 13:01:41 --> Total execution time: 0.0866
INFO - 2016-09-22 13:01:42 --> Config Class Initialized
INFO - 2016-09-22 13:01:42 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:01:42 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:01:42 --> Utf8 Class Initialized
INFO - 2016-09-22 13:01:42 --> URI Class Initialized
INFO - 2016-09-22 13:01:42 --> Router Class Initialized
INFO - 2016-09-22 13:01:42 --> Output Class Initialized
INFO - 2016-09-22 13:01:42 --> Security Class Initialized
DEBUG - 2016-09-22 13:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:01:42 --> Input Class Initialized
INFO - 2016-09-22 13:01:42 --> Language Class Initialized
INFO - 2016-09-22 13:01:42 --> Loader Class Initialized
INFO - 2016-09-22 13:01:42 --> Helper loaded: url_helper
INFO - 2016-09-22 13:01:42 --> Helper loaded: language_helper
INFO - 2016-09-22 13:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:01:42 --> Controller Class Initialized
INFO - 2016-09-22 13:01:42 --> Database Driver Class Initialized
INFO - 2016-09-22 13:01:42 --> Model Class Initialized
INFO - 2016-09-22 13:01:42 --> Model Class Initialized
INFO - 2016-09-22 13:01:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:01:42 --> Final output sent to browser
DEBUG - 2016-09-22 13:01:42 --> Total execution time: 0.0541
INFO - 2016-09-22 13:03:26 --> Config Class Initialized
INFO - 2016-09-22 13:03:26 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:03:26 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:03:26 --> Utf8 Class Initialized
INFO - 2016-09-22 13:03:26 --> URI Class Initialized
INFO - 2016-09-22 13:03:26 --> Router Class Initialized
INFO - 2016-09-22 13:03:26 --> Output Class Initialized
INFO - 2016-09-22 13:03:26 --> Security Class Initialized
DEBUG - 2016-09-22 13:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:03:26 --> Input Class Initialized
INFO - 2016-09-22 13:03:26 --> Language Class Initialized
INFO - 2016-09-22 13:03:26 --> Loader Class Initialized
INFO - 2016-09-22 13:03:26 --> Helper loaded: url_helper
INFO - 2016-09-22 13:03:26 --> Helper loaded: language_helper
INFO - 2016-09-22 13:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:03:26 --> Controller Class Initialized
INFO - 2016-09-22 13:03:26 --> Database Driver Class Initialized
INFO - 2016-09-22 13:03:26 --> Model Class Initialized
INFO - 2016-09-22 13:03:26 --> Model Class Initialized
INFO - 2016-09-22 13:03:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:03:26 --> Final output sent to browser
DEBUG - 2016-09-22 13:03:26 --> Total execution time: 0.0587
INFO - 2016-09-22 13:09:55 --> Config Class Initialized
INFO - 2016-09-22 13:09:55 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:09:55 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:09:55 --> Utf8 Class Initialized
INFO - 2016-09-22 13:09:55 --> URI Class Initialized
INFO - 2016-09-22 13:09:55 --> Router Class Initialized
INFO - 2016-09-22 13:09:55 --> Output Class Initialized
INFO - 2016-09-22 13:09:55 --> Security Class Initialized
DEBUG - 2016-09-22 13:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:09:55 --> Input Class Initialized
INFO - 2016-09-22 13:09:55 --> Language Class Initialized
INFO - 2016-09-22 13:09:55 --> Loader Class Initialized
INFO - 2016-09-22 13:09:55 --> Helper loaded: url_helper
INFO - 2016-09-22 13:09:55 --> Helper loaded: language_helper
INFO - 2016-09-22 13:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:09:55 --> Controller Class Initialized
INFO - 2016-09-22 13:09:55 --> Database Driver Class Initialized
INFO - 2016-09-22 13:09:55 --> Model Class Initialized
INFO - 2016-09-22 13:09:55 --> Model Class Initialized
INFO - 2016-09-22 13:09:55 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:09:55 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:09:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:09:55 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:09:55 --> Final output sent to browser
DEBUG - 2016-09-22 13:09:55 --> Total execution time: 0.0598
INFO - 2016-09-22 13:10:06 --> Config Class Initialized
INFO - 2016-09-22 13:10:06 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:10:06 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:10:06 --> Utf8 Class Initialized
INFO - 2016-09-22 13:10:06 --> URI Class Initialized
INFO - 2016-09-22 13:10:06 --> Router Class Initialized
INFO - 2016-09-22 13:10:06 --> Output Class Initialized
INFO - 2016-09-22 13:10:06 --> Security Class Initialized
DEBUG - 2016-09-22 13:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:10:06 --> Input Class Initialized
INFO - 2016-09-22 13:10:06 --> Language Class Initialized
INFO - 2016-09-22 13:10:06 --> Loader Class Initialized
INFO - 2016-09-22 13:10:06 --> Helper loaded: url_helper
INFO - 2016-09-22 13:10:06 --> Helper loaded: language_helper
INFO - 2016-09-22 13:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:10:06 --> Controller Class Initialized
INFO - 2016-09-22 13:10:06 --> Database Driver Class Initialized
INFO - 2016-09-22 13:10:06 --> Model Class Initialized
INFO - 2016-09-22 13:10:06 --> Model Class Initialized
INFO - 2016-09-22 13:10:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:10:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 13:10:06 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:10:06 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:10:06 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:10:06 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
INFO - 2016-09-22 13:10:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:10:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:10:06 --> Final output sent to browser
DEBUG - 2016-09-22 13:10:06 --> Total execution time: 0.0740
INFO - 2016-09-22 13:10:09 --> Config Class Initialized
INFO - 2016-09-22 13:10:09 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:10:09 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:10:09 --> Utf8 Class Initialized
INFO - 2016-09-22 13:10:09 --> URI Class Initialized
INFO - 2016-09-22 13:10:09 --> Router Class Initialized
INFO - 2016-09-22 13:10:09 --> Output Class Initialized
INFO - 2016-09-22 13:10:09 --> Security Class Initialized
DEBUG - 2016-09-22 13:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:10:09 --> Input Class Initialized
INFO - 2016-09-22 13:10:09 --> Language Class Initialized
INFO - 2016-09-22 13:10:09 --> Loader Class Initialized
INFO - 2016-09-22 13:10:09 --> Helper loaded: url_helper
INFO - 2016-09-22 13:10:09 --> Helper loaded: language_helper
INFO - 2016-09-22 13:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:10:09 --> Controller Class Initialized
INFO - 2016-09-22 13:10:09 --> Database Driver Class Initialized
INFO - 2016-09-22 13:10:09 --> Model Class Initialized
INFO - 2016-09-22 13:10:09 --> Model Class Initialized
INFO - 2016-09-22 13:10:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:10:09 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:10:09 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:10:09 --> Final output sent to browser
DEBUG - 2016-09-22 13:10:09 --> Total execution time: 0.0650
INFO - 2016-09-22 13:10:27 --> Config Class Initialized
INFO - 2016-09-22 13:10:27 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:10:27 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:10:27 --> Utf8 Class Initialized
INFO - 2016-09-22 13:10:27 --> URI Class Initialized
INFO - 2016-09-22 13:10:27 --> Router Class Initialized
INFO - 2016-09-22 13:10:27 --> Output Class Initialized
INFO - 2016-09-22 13:10:27 --> Security Class Initialized
DEBUG - 2016-09-22 13:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:10:27 --> Input Class Initialized
INFO - 2016-09-22 13:10:27 --> Language Class Initialized
INFO - 2016-09-22 13:10:27 --> Loader Class Initialized
INFO - 2016-09-22 13:10:27 --> Helper loaded: url_helper
INFO - 2016-09-22 13:10:27 --> Helper loaded: language_helper
INFO - 2016-09-22 13:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:10:27 --> Controller Class Initialized
INFO - 2016-09-22 13:10:27 --> Database Driver Class Initialized
INFO - 2016-09-22 13:10:27 --> Model Class Initialized
INFO - 2016-09-22 13:10:27 --> Model Class Initialized
INFO - 2016-09-22 13:10:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:10:27 --> Final output sent to browser
DEBUG - 2016-09-22 13:10:27 --> Total execution time: 0.0585
INFO - 2016-09-22 13:11:27 --> Config Class Initialized
INFO - 2016-09-22 13:11:27 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:11:27 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:11:27 --> Utf8 Class Initialized
INFO - 2016-09-22 13:11:27 --> URI Class Initialized
INFO - 2016-09-22 13:11:27 --> Router Class Initialized
INFO - 2016-09-22 13:11:27 --> Output Class Initialized
INFO - 2016-09-22 13:11:27 --> Security Class Initialized
DEBUG - 2016-09-22 13:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:11:27 --> Input Class Initialized
INFO - 2016-09-22 13:11:27 --> Language Class Initialized
INFO - 2016-09-22 13:11:27 --> Loader Class Initialized
INFO - 2016-09-22 13:11:27 --> Helper loaded: url_helper
INFO - 2016-09-22 13:11:27 --> Helper loaded: language_helper
INFO - 2016-09-22 13:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:11:27 --> Controller Class Initialized
INFO - 2016-09-22 13:11:27 --> Database Driver Class Initialized
INFO - 2016-09-22 13:11:27 --> Model Class Initialized
INFO - 2016-09-22 13:11:27 --> Model Class Initialized
INFO - 2016-09-22 13:11:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:11:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 13:11:27 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:11:27 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:11:27 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:11:27 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
INFO - 2016-09-22 13:11:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:11:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:11:27 --> Final output sent to browser
DEBUG - 2016-09-22 13:11:27 --> Total execution time: 0.0920
INFO - 2016-09-22 13:11:29 --> Config Class Initialized
INFO - 2016-09-22 13:11:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:11:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:11:29 --> Utf8 Class Initialized
INFO - 2016-09-22 13:11:29 --> URI Class Initialized
INFO - 2016-09-22 13:11:29 --> Router Class Initialized
INFO - 2016-09-22 13:11:29 --> Output Class Initialized
INFO - 2016-09-22 13:11:29 --> Security Class Initialized
DEBUG - 2016-09-22 13:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:11:29 --> Input Class Initialized
INFO - 2016-09-22 13:11:29 --> Language Class Initialized
INFO - 2016-09-22 13:11:29 --> Loader Class Initialized
INFO - 2016-09-22 13:11:29 --> Helper loaded: url_helper
INFO - 2016-09-22 13:11:29 --> Helper loaded: language_helper
INFO - 2016-09-22 13:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:11:29 --> Controller Class Initialized
INFO - 2016-09-22 13:11:29 --> Database Driver Class Initialized
INFO - 2016-09-22 13:11:29 --> Model Class Initialized
INFO - 2016-09-22 13:11:29 --> Model Class Initialized
INFO - 2016-09-22 13:11:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:11:29 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:11:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:11:29 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:11:29 --> Final output sent to browser
DEBUG - 2016-09-22 13:11:29 --> Total execution time: 0.0851
INFO - 2016-09-22 13:11:34 --> Config Class Initialized
INFO - 2016-09-22 13:11:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:11:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:11:34 --> Utf8 Class Initialized
INFO - 2016-09-22 13:11:34 --> URI Class Initialized
INFO - 2016-09-22 13:11:34 --> Router Class Initialized
INFO - 2016-09-22 13:11:34 --> Output Class Initialized
INFO - 2016-09-22 13:11:34 --> Security Class Initialized
DEBUG - 2016-09-22 13:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:11:34 --> Input Class Initialized
INFO - 2016-09-22 13:11:34 --> Language Class Initialized
INFO - 2016-09-22 13:11:34 --> Loader Class Initialized
INFO - 2016-09-22 13:11:34 --> Helper loaded: url_helper
INFO - 2016-09-22 13:11:34 --> Helper loaded: language_helper
INFO - 2016-09-22 13:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:11:34 --> Controller Class Initialized
INFO - 2016-09-22 13:11:34 --> Database Driver Class Initialized
INFO - 2016-09-22 13:11:34 --> Model Class Initialized
INFO - 2016-09-22 13:11:34 --> Model Class Initialized
INFO - 2016-09-22 13:11:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:11:34 --> Final output sent to browser
DEBUG - 2016-09-22 13:11:34 --> Total execution time: 0.0616
INFO - 2016-09-22 13:12:29 --> Config Class Initialized
INFO - 2016-09-22 13:12:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:12:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:12:29 --> Utf8 Class Initialized
INFO - 2016-09-22 13:12:29 --> URI Class Initialized
INFO - 2016-09-22 13:12:29 --> Router Class Initialized
INFO - 2016-09-22 13:12:29 --> Output Class Initialized
INFO - 2016-09-22 13:12:29 --> Security Class Initialized
DEBUG - 2016-09-22 13:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:12:30 --> Input Class Initialized
INFO - 2016-09-22 13:12:30 --> Language Class Initialized
INFO - 2016-09-22 13:12:30 --> Loader Class Initialized
INFO - 2016-09-22 13:12:30 --> Helper loaded: url_helper
INFO - 2016-09-22 13:12:30 --> Helper loaded: language_helper
INFO - 2016-09-22 13:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:12:30 --> Controller Class Initialized
INFO - 2016-09-22 13:12:30 --> Database Driver Class Initialized
INFO - 2016-09-22 13:12:30 --> Model Class Initialized
INFO - 2016-09-22 13:12:30 --> Model Class Initialized
INFO - 2016-09-22 13:12:30 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:12:30 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:12:30 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:12:30 --> Final output sent to browser
DEBUG - 2016-09-22 13:12:30 --> Total execution time: 0.0735
INFO - 2016-09-22 13:12:30 --> Config Class Initialized
INFO - 2016-09-22 13:12:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:12:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:12:30 --> Utf8 Class Initialized
INFO - 2016-09-22 13:12:30 --> URI Class Initialized
INFO - 2016-09-22 13:12:30 --> Router Class Initialized
INFO - 2016-09-22 13:12:30 --> Output Class Initialized
INFO - 2016-09-22 13:12:30 --> Security Class Initialized
DEBUG - 2016-09-22 13:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:12:30 --> Input Class Initialized
INFO - 2016-09-22 13:12:30 --> Language Class Initialized
INFO - 2016-09-22 13:12:30 --> Loader Class Initialized
INFO - 2016-09-22 13:12:30 --> Helper loaded: url_helper
INFO - 2016-09-22 13:12:30 --> Helper loaded: language_helper
INFO - 2016-09-22 13:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:12:30 --> Controller Class Initialized
INFO - 2016-09-22 13:12:30 --> Database Driver Class Initialized
INFO - 2016-09-22 13:12:30 --> Model Class Initialized
INFO - 2016-09-22 13:12:30 --> Model Class Initialized
INFO - 2016-09-22 13:12:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:12:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 13:12:30 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:12:30 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:12:30 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
ERROR - 2016-09-22 13:12:30 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 66
INFO - 2016-09-22 13:12:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:12:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:12:30 --> Final output sent to browser
DEBUG - 2016-09-22 13:12:30 --> Total execution time: 0.0805
INFO - 2016-09-22 13:12:33 --> Config Class Initialized
INFO - 2016-09-22 13:12:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:12:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:12:33 --> Utf8 Class Initialized
INFO - 2016-09-22 13:12:33 --> URI Class Initialized
INFO - 2016-09-22 13:12:33 --> Router Class Initialized
INFO - 2016-09-22 13:12:33 --> Output Class Initialized
INFO - 2016-09-22 13:12:33 --> Security Class Initialized
DEBUG - 2016-09-22 13:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:12:33 --> Input Class Initialized
INFO - 2016-09-22 13:12:33 --> Language Class Initialized
INFO - 2016-09-22 13:12:33 --> Loader Class Initialized
INFO - 2016-09-22 13:12:33 --> Helper loaded: url_helper
INFO - 2016-09-22 13:12:33 --> Helper loaded: language_helper
INFO - 2016-09-22 13:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:12:33 --> Controller Class Initialized
INFO - 2016-09-22 13:12:33 --> Database Driver Class Initialized
INFO - 2016-09-22 13:12:33 --> Model Class Initialized
INFO - 2016-09-22 13:12:33 --> Model Class Initialized
INFO - 2016-09-22 13:12:33 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:12:33 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:12:33 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:12:33 --> Final output sent to browser
DEBUG - 2016-09-22 13:12:33 --> Total execution time: 0.0796
INFO - 2016-09-22 13:12:36 --> Config Class Initialized
INFO - 2016-09-22 13:12:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:12:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:12:36 --> Utf8 Class Initialized
INFO - 2016-09-22 13:12:36 --> URI Class Initialized
INFO - 2016-09-22 13:12:36 --> Router Class Initialized
INFO - 2016-09-22 13:12:36 --> Output Class Initialized
INFO - 2016-09-22 13:12:36 --> Security Class Initialized
DEBUG - 2016-09-22 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:12:36 --> Input Class Initialized
INFO - 2016-09-22 13:12:36 --> Language Class Initialized
INFO - 2016-09-22 13:12:36 --> Loader Class Initialized
INFO - 2016-09-22 13:12:36 --> Helper loaded: url_helper
INFO - 2016-09-22 13:12:36 --> Helper loaded: language_helper
INFO - 2016-09-22 13:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:12:36 --> Controller Class Initialized
INFO - 2016-09-22 13:12:36 --> Database Driver Class Initialized
INFO - 2016-09-22 13:12:36 --> Model Class Initialized
INFO - 2016-09-22 13:12:36 --> Model Class Initialized
INFO - 2016-09-22 13:12:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:12:36 --> Final output sent to browser
DEBUG - 2016-09-22 13:12:36 --> Total execution time: 0.0637
INFO - 2016-09-22 13:14:36 --> Config Class Initialized
INFO - 2016-09-22 13:14:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:14:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:14:36 --> Utf8 Class Initialized
INFO - 2016-09-22 13:14:36 --> URI Class Initialized
INFO - 2016-09-22 13:14:36 --> Router Class Initialized
INFO - 2016-09-22 13:14:36 --> Output Class Initialized
INFO - 2016-09-22 13:14:36 --> Security Class Initialized
DEBUG - 2016-09-22 13:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:14:36 --> Input Class Initialized
INFO - 2016-09-22 13:14:36 --> Language Class Initialized
INFO - 2016-09-22 13:14:36 --> Loader Class Initialized
INFO - 2016-09-22 13:14:36 --> Helper loaded: url_helper
INFO - 2016-09-22 13:14:36 --> Helper loaded: language_helper
INFO - 2016-09-22 13:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:14:36 --> Controller Class Initialized
INFO - 2016-09-22 13:14:36 --> Database Driver Class Initialized
INFO - 2016-09-22 13:14:36 --> Model Class Initialized
INFO - 2016-09-22 13:14:36 --> Model Class Initialized
INFO - 2016-09-22 13:14:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:14:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:14:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:14:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:14:36 --> Final output sent to browser
DEBUG - 2016-09-22 13:14:36 --> Total execution time: 0.0754
INFO - 2016-09-22 13:14:37 --> Config Class Initialized
INFO - 2016-09-22 13:14:37 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:14:37 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:14:37 --> Utf8 Class Initialized
INFO - 2016-09-22 13:14:37 --> URI Class Initialized
INFO - 2016-09-22 13:14:37 --> Router Class Initialized
INFO - 2016-09-22 13:14:37 --> Output Class Initialized
INFO - 2016-09-22 13:14:37 --> Security Class Initialized
DEBUG - 2016-09-22 13:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:14:37 --> Input Class Initialized
INFO - 2016-09-22 13:14:37 --> Language Class Initialized
INFO - 2016-09-22 13:14:37 --> Loader Class Initialized
INFO - 2016-09-22 13:14:37 --> Helper loaded: url_helper
INFO - 2016-09-22 13:14:37 --> Helper loaded: language_helper
INFO - 2016-09-22 13:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:14:37 --> Controller Class Initialized
INFO - 2016-09-22 13:14:37 --> Database Driver Class Initialized
INFO - 2016-09-22 13:14:37 --> Model Class Initialized
INFO - 2016-09-22 13:14:37 --> Model Class Initialized
INFO - 2016-09-22 13:14:37 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:14:37 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:14:37 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:14:37 --> Final output sent to browser
DEBUG - 2016-09-22 13:14:37 --> Total execution time: 0.0756
INFO - 2016-09-22 13:14:38 --> Config Class Initialized
INFO - 2016-09-22 13:14:38 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:14:38 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:14:38 --> Utf8 Class Initialized
INFO - 2016-09-22 13:14:38 --> URI Class Initialized
INFO - 2016-09-22 13:14:38 --> Router Class Initialized
INFO - 2016-09-22 13:14:38 --> Output Class Initialized
INFO - 2016-09-22 13:14:38 --> Security Class Initialized
DEBUG - 2016-09-22 13:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:14:38 --> Input Class Initialized
INFO - 2016-09-22 13:14:38 --> Language Class Initialized
INFO - 2016-09-22 13:14:38 --> Loader Class Initialized
INFO - 2016-09-22 13:14:38 --> Helper loaded: url_helper
INFO - 2016-09-22 13:14:38 --> Helper loaded: language_helper
INFO - 2016-09-22 13:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:14:38 --> Controller Class Initialized
INFO - 2016-09-22 13:14:38 --> Database Driver Class Initialized
INFO - 2016-09-22 13:14:38 --> Model Class Initialized
INFO - 2016-09-22 13:14:38 --> Model Class Initialized
INFO - 2016-09-22 13:14:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:14:38 --> Final output sent to browser
DEBUG - 2016-09-22 13:14:38 --> Total execution time: 0.0497
INFO - 2016-09-22 13:14:44 --> Config Class Initialized
INFO - 2016-09-22 13:14:44 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:14:44 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:14:44 --> Utf8 Class Initialized
INFO - 2016-09-22 13:14:44 --> URI Class Initialized
INFO - 2016-09-22 13:14:44 --> Router Class Initialized
INFO - 2016-09-22 13:14:44 --> Output Class Initialized
INFO - 2016-09-22 13:14:44 --> Security Class Initialized
DEBUG - 2016-09-22 13:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:14:44 --> Input Class Initialized
INFO - 2016-09-22 13:14:44 --> Language Class Initialized
INFO - 2016-09-22 13:14:44 --> Loader Class Initialized
INFO - 2016-09-22 13:14:44 --> Helper loaded: url_helper
INFO - 2016-09-22 13:14:44 --> Helper loaded: language_helper
INFO - 2016-09-22 13:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:14:44 --> Controller Class Initialized
INFO - 2016-09-22 13:14:44 --> Database Driver Class Initialized
INFO - 2016-09-22 13:14:44 --> Model Class Initialized
INFO - 2016-09-22 13:14:44 --> Model Class Initialized
INFO - 2016-09-22 13:14:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:14:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:14:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:14:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:14:44 --> Final output sent to browser
DEBUG - 2016-09-22 13:14:44 --> Total execution time: 0.0646
INFO - 2016-09-22 13:14:45 --> Config Class Initialized
INFO - 2016-09-22 13:14:45 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:14:45 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:14:45 --> Utf8 Class Initialized
INFO - 2016-09-22 13:14:45 --> URI Class Initialized
INFO - 2016-09-22 13:14:45 --> Router Class Initialized
INFO - 2016-09-22 13:14:45 --> Output Class Initialized
INFO - 2016-09-22 13:14:45 --> Security Class Initialized
DEBUG - 2016-09-22 13:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:14:45 --> Input Class Initialized
INFO - 2016-09-22 13:14:45 --> Language Class Initialized
INFO - 2016-09-22 13:14:45 --> Loader Class Initialized
INFO - 2016-09-22 13:14:45 --> Helper loaded: url_helper
INFO - 2016-09-22 13:14:45 --> Helper loaded: language_helper
INFO - 2016-09-22 13:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:14:45 --> Controller Class Initialized
INFO - 2016-09-22 13:14:45 --> Database Driver Class Initialized
INFO - 2016-09-22 13:14:45 --> Model Class Initialized
INFO - 2016-09-22 13:14:45 --> Model Class Initialized
INFO - 2016-09-22 13:14:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:14:45 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:14:45 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:14:45 --> Final output sent to browser
DEBUG - 2016-09-22 13:14:45 --> Total execution time: 0.0930
INFO - 2016-09-22 13:14:46 --> Config Class Initialized
INFO - 2016-09-22 13:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:14:46 --> Utf8 Class Initialized
INFO - 2016-09-22 13:14:46 --> URI Class Initialized
INFO - 2016-09-22 13:14:46 --> Router Class Initialized
INFO - 2016-09-22 13:14:46 --> Output Class Initialized
INFO - 2016-09-22 13:14:46 --> Security Class Initialized
DEBUG - 2016-09-22 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:14:46 --> Input Class Initialized
INFO - 2016-09-22 13:14:46 --> Language Class Initialized
INFO - 2016-09-22 13:14:46 --> Loader Class Initialized
INFO - 2016-09-22 13:14:46 --> Helper loaded: url_helper
INFO - 2016-09-22 13:14:46 --> Helper loaded: language_helper
INFO - 2016-09-22 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:14:46 --> Controller Class Initialized
INFO - 2016-09-22 13:14:46 --> Database Driver Class Initialized
INFO - 2016-09-22 13:14:46 --> Model Class Initialized
INFO - 2016-09-22 13:14:46 --> Model Class Initialized
INFO - 2016-09-22 13:14:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:14:46 --> Final output sent to browser
DEBUG - 2016-09-22 13:14:46 --> Total execution time: 0.0518
INFO - 2016-09-22 13:18:19 --> Config Class Initialized
INFO - 2016-09-22 13:18:19 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:18:19 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:18:19 --> Utf8 Class Initialized
INFO - 2016-09-22 13:18:19 --> URI Class Initialized
INFO - 2016-09-22 13:18:19 --> Router Class Initialized
INFO - 2016-09-22 13:18:19 --> Output Class Initialized
INFO - 2016-09-22 13:18:19 --> Security Class Initialized
DEBUG - 2016-09-22 13:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:18:19 --> Input Class Initialized
INFO - 2016-09-22 13:18:19 --> Language Class Initialized
INFO - 2016-09-22 13:18:19 --> Loader Class Initialized
INFO - 2016-09-22 13:18:19 --> Helper loaded: url_helper
INFO - 2016-09-22 13:18:19 --> Helper loaded: language_helper
INFO - 2016-09-22 13:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:18:19 --> Controller Class Initialized
INFO - 2016-09-22 13:18:19 --> Database Driver Class Initialized
INFO - 2016-09-22 13:18:19 --> Model Class Initialized
INFO - 2016-09-22 13:18:19 --> Model Class Initialized
INFO - 2016-09-22 13:18:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:18:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-22 13:18:19 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php 67
INFO - 2016-09-22 13:18:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:18:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:18:19 --> Final output sent to browser
DEBUG - 2016-09-22 13:18:19 --> Total execution time: 0.0782
INFO - 2016-09-22 13:18:29 --> Config Class Initialized
INFO - 2016-09-22 13:18:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:18:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:18:29 --> Utf8 Class Initialized
INFO - 2016-09-22 13:18:29 --> URI Class Initialized
INFO - 2016-09-22 13:18:29 --> Router Class Initialized
INFO - 2016-09-22 13:18:29 --> Output Class Initialized
INFO - 2016-09-22 13:18:29 --> Security Class Initialized
DEBUG - 2016-09-22 13:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:18:29 --> Input Class Initialized
INFO - 2016-09-22 13:18:29 --> Language Class Initialized
INFO - 2016-09-22 13:18:29 --> Loader Class Initialized
INFO - 2016-09-22 13:18:29 --> Helper loaded: url_helper
INFO - 2016-09-22 13:18:29 --> Helper loaded: language_helper
INFO - 2016-09-22 13:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:18:29 --> Controller Class Initialized
INFO - 2016-09-22 13:18:29 --> Database Driver Class Initialized
INFO - 2016-09-22 13:18:29 --> Model Class Initialized
INFO - 2016-09-22 13:18:29 --> Model Class Initialized
INFO - 2016-09-22 13:18:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:18:29 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:18:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:18:29 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:18:29 --> Final output sent to browser
DEBUG - 2016-09-22 13:18:29 --> Total execution time: 0.0652
INFO - 2016-09-22 13:18:30 --> Config Class Initialized
INFO - 2016-09-22 13:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:18:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:18:30 --> Utf8 Class Initialized
INFO - 2016-09-22 13:18:30 --> URI Class Initialized
INFO - 2016-09-22 13:18:30 --> Router Class Initialized
INFO - 2016-09-22 13:18:30 --> Output Class Initialized
INFO - 2016-09-22 13:18:30 --> Security Class Initialized
DEBUG - 2016-09-22 13:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:18:30 --> Input Class Initialized
INFO - 2016-09-22 13:18:30 --> Language Class Initialized
INFO - 2016-09-22 13:18:30 --> Loader Class Initialized
INFO - 2016-09-22 13:18:30 --> Helper loaded: url_helper
INFO - 2016-09-22 13:18:30 --> Helper loaded: language_helper
INFO - 2016-09-22 13:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:18:30 --> Controller Class Initialized
INFO - 2016-09-22 13:18:30 --> Database Driver Class Initialized
INFO - 2016-09-22 13:18:30 --> Model Class Initialized
INFO - 2016-09-22 13:18:30 --> Model Class Initialized
INFO - 2016-09-22 13:18:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:18:30 --> Final output sent to browser
DEBUG - 2016-09-22 13:18:30 --> Total execution time: 0.0619
INFO - 2016-09-22 13:18:57 --> Config Class Initialized
INFO - 2016-09-22 13:18:57 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:18:57 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:18:57 --> Utf8 Class Initialized
INFO - 2016-09-22 13:18:57 --> URI Class Initialized
INFO - 2016-09-22 13:18:57 --> Router Class Initialized
INFO - 2016-09-22 13:18:57 --> Output Class Initialized
INFO - 2016-09-22 13:18:57 --> Security Class Initialized
DEBUG - 2016-09-22 13:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:18:57 --> Input Class Initialized
INFO - 2016-09-22 13:18:57 --> Language Class Initialized
INFO - 2016-09-22 13:18:57 --> Loader Class Initialized
INFO - 2016-09-22 13:18:57 --> Helper loaded: url_helper
INFO - 2016-09-22 13:18:57 --> Helper loaded: language_helper
INFO - 2016-09-22 13:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:18:57 --> Controller Class Initialized
INFO - 2016-09-22 13:18:57 --> Database Driver Class Initialized
INFO - 2016-09-22 13:18:57 --> Model Class Initialized
INFO - 2016-09-22 13:18:57 --> Model Class Initialized
INFO - 2016-09-22 13:18:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:18:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:18:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:18:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:18:57 --> Final output sent to browser
DEBUG - 2016-09-22 13:18:57 --> Total execution time: 0.0673
INFO - 2016-09-22 13:18:59 --> Config Class Initialized
INFO - 2016-09-22 13:18:59 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:18:59 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:18:59 --> Utf8 Class Initialized
INFO - 2016-09-22 13:18:59 --> URI Class Initialized
INFO - 2016-09-22 13:18:59 --> Router Class Initialized
INFO - 2016-09-22 13:18:59 --> Output Class Initialized
INFO - 2016-09-22 13:18:59 --> Security Class Initialized
DEBUG - 2016-09-22 13:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:18:59 --> Input Class Initialized
INFO - 2016-09-22 13:18:59 --> Language Class Initialized
INFO - 2016-09-22 13:18:59 --> Loader Class Initialized
INFO - 2016-09-22 13:18:59 --> Helper loaded: url_helper
INFO - 2016-09-22 13:18:59 --> Helper loaded: language_helper
INFO - 2016-09-22 13:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:18:59 --> Controller Class Initialized
INFO - 2016-09-22 13:18:59 --> Database Driver Class Initialized
INFO - 2016-09-22 13:18:59 --> Model Class Initialized
INFO - 2016-09-22 13:18:59 --> Model Class Initialized
INFO - 2016-09-22 13:18:59 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:18:59 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:18:59 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:18:59 --> Final output sent to browser
DEBUG - 2016-09-22 13:18:59 --> Total execution time: 0.0650
INFO - 2016-09-22 13:19:01 --> Config Class Initialized
INFO - 2016-09-22 13:19:01 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:01 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:01 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:01 --> URI Class Initialized
INFO - 2016-09-22 13:19:01 --> Router Class Initialized
INFO - 2016-09-22 13:19:01 --> Output Class Initialized
INFO - 2016-09-22 13:19:01 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:01 --> Input Class Initialized
INFO - 2016-09-22 13:19:01 --> Language Class Initialized
INFO - 2016-09-22 13:19:01 --> Loader Class Initialized
INFO - 2016-09-22 13:19:01 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:01 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:01 --> Controller Class Initialized
INFO - 2016-09-22 13:19:01 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:01 --> Model Class Initialized
INFO - 2016-09-22 13:19:01 --> Model Class Initialized
INFO - 2016-09-22 13:19:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:01 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:01 --> Total execution time: 0.0585
INFO - 2016-09-22 13:19:30 --> Config Class Initialized
INFO - 2016-09-22 13:19:30 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:30 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:30 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:30 --> URI Class Initialized
INFO - 2016-09-22 13:19:30 --> Router Class Initialized
INFO - 2016-09-22 13:19:30 --> Output Class Initialized
INFO - 2016-09-22 13:19:30 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:30 --> Input Class Initialized
INFO - 2016-09-22 13:19:30 --> Language Class Initialized
INFO - 2016-09-22 13:19:30 --> Loader Class Initialized
INFO - 2016-09-22 13:19:30 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:30 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:30 --> Controller Class Initialized
INFO - 2016-09-22 13:19:30 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:30 --> Model Class Initialized
INFO - 2016-09-22 13:19:30 --> Model Class Initialized
INFO - 2016-09-22 13:19:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:19:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 13:19:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:19:30 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:30 --> Total execution time: 0.0588
INFO - 2016-09-22 13:19:32 --> Config Class Initialized
INFO - 2016-09-22 13:19:32 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:32 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:32 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:32 --> URI Class Initialized
INFO - 2016-09-22 13:19:32 --> Router Class Initialized
INFO - 2016-09-22 13:19:32 --> Output Class Initialized
INFO - 2016-09-22 13:19:32 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:32 --> Input Class Initialized
INFO - 2016-09-22 13:19:32 --> Language Class Initialized
INFO - 2016-09-22 13:19:32 --> Loader Class Initialized
INFO - 2016-09-22 13:19:32 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:32 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:32 --> Controller Class Initialized
INFO - 2016-09-22 13:19:32 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:32 --> Model Class Initialized
INFO - 2016-09-22 13:19:32 --> Model Class Initialized
INFO - 2016-09-22 13:19:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_detail.php
INFO - 2016-09-22 13:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:19:32 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:32 --> Total execution time: 0.0680
INFO - 2016-09-22 13:19:35 --> Config Class Initialized
INFO - 2016-09-22 13:19:35 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:35 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:35 --> URI Class Initialized
INFO - 2016-09-22 13:19:35 --> Router Class Initialized
INFO - 2016-09-22 13:19:35 --> Output Class Initialized
INFO - 2016-09-22 13:19:35 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:35 --> Input Class Initialized
INFO - 2016-09-22 13:19:35 --> Language Class Initialized
INFO - 2016-09-22 13:19:35 --> Loader Class Initialized
INFO - 2016-09-22 13:19:35 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:35 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:35 --> Controller Class Initialized
INFO - 2016-09-22 13:19:35 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:35 --> Config Class Initialized
INFO - 2016-09-22 13:19:35 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:35 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:35 --> URI Class Initialized
INFO - 2016-09-22 13:19:35 --> Router Class Initialized
INFO - 2016-09-22 13:19:35 --> Output Class Initialized
INFO - 2016-09-22 13:19:35 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:35 --> Input Class Initialized
INFO - 2016-09-22 13:19:35 --> Language Class Initialized
INFO - 2016-09-22 13:19:35 --> Loader Class Initialized
INFO - 2016-09-22 13:19:35 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:35 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:35 --> Controller Class Initialized
INFO - 2016-09-22 13:19:35 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:19:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-22 13:19:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:19:35 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:35 --> Total execution time: 0.0618
INFO - 2016-09-22 13:19:35 --> Config Class Initialized
INFO - 2016-09-22 13:19:35 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:35 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:35 --> Config Class Initialized
INFO - 2016-09-22 13:19:35 --> Hooks Class Initialized
INFO - 2016-09-22 13:19:35 --> URI Class Initialized
INFO - 2016-09-22 13:19:35 --> Router Class Initialized
DEBUG - 2016-09-22 13:19:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:35 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:35 --> Output Class Initialized
INFO - 2016-09-22 13:19:35 --> URI Class Initialized
INFO - 2016-09-22 13:19:35 --> Security Class Initialized
INFO - 2016-09-22 13:19:35 --> Router Class Initialized
DEBUG - 2016-09-22 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:35 --> Input Class Initialized
INFO - 2016-09-22 13:19:35 --> Language Class Initialized
INFO - 2016-09-22 13:19:35 --> Output Class Initialized
INFO - 2016-09-22 13:19:35 --> Security Class Initialized
INFO - 2016-09-22 13:19:35 --> Loader Class Initialized
DEBUG - 2016-09-22 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:35 --> Input Class Initialized
INFO - 2016-09-22 13:19:35 --> Language Class Initialized
INFO - 2016-09-22 13:19:35 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:35 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:35 --> Loader Class Initialized
INFO - 2016-09-22 13:19:35 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:35 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:35 --> Controller Class Initialized
INFO - 2016-09-22 13:19:35 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:35 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:35 --> Total execution time: 0.0835
INFO - 2016-09-22 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:35 --> Controller Class Initialized
INFO - 2016-09-22 13:19:35 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Model Class Initialized
INFO - 2016-09-22 13:19:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:19:35 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-22 13:19:35 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:35 --> Total execution time: 0.1084
INFO - 2016-09-22 13:19:39 --> Config Class Initialized
INFO - 2016-09-22 13:19:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:39 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:39 --> URI Class Initialized
INFO - 2016-09-22 13:19:39 --> Router Class Initialized
INFO - 2016-09-22 13:19:39 --> Output Class Initialized
INFO - 2016-09-22 13:19:39 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:39 --> Input Class Initialized
INFO - 2016-09-22 13:19:39 --> Language Class Initialized
INFO - 2016-09-22 13:19:39 --> Loader Class Initialized
INFO - 2016-09-22 13:19:39 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:39 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:39 --> Controller Class Initialized
INFO - 2016-09-22 13:19:39 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:39 --> Model Class Initialized
INFO - 2016-09-22 13:19:39 --> Model Class Initialized
INFO - 2016-09-22 13:19:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:39 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:39 --> Total execution time: 0.0698
INFO - 2016-09-22 13:19:41 --> Config Class Initialized
INFO - 2016-09-22 13:19:41 --> Hooks Class Initialized
INFO - 2016-09-22 13:19:41 --> Config Class Initialized
INFO - 2016-09-22 13:19:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:41 --> Utf8 Class Initialized
DEBUG - 2016-09-22 13:19:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:41 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:41 --> URI Class Initialized
INFO - 2016-09-22 13:19:41 --> URI Class Initialized
INFO - 2016-09-22 13:19:41 --> Router Class Initialized
INFO - 2016-09-22 13:19:41 --> Router Class Initialized
INFO - 2016-09-22 13:19:41 --> Output Class Initialized
INFO - 2016-09-22 13:19:41 --> Output Class Initialized
INFO - 2016-09-22 13:19:41 --> Security Class Initialized
INFO - 2016-09-22 13:19:41 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:41 --> Input Class Initialized
DEBUG - 2016-09-22 13:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:41 --> Language Class Initialized
INFO - 2016-09-22 13:19:41 --> Input Class Initialized
INFO - 2016-09-22 13:19:41 --> Language Class Initialized
INFO - 2016-09-22 13:19:41 --> Loader Class Initialized
INFO - 2016-09-22 13:19:41 --> Loader Class Initialized
INFO - 2016-09-22 13:19:41 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:41 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:41 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:41 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:41 --> Controller Class Initialized
INFO - 2016-09-22 13:19:41 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:41 --> Model Class Initialized
INFO - 2016-09-22 13:19:41 --> Model Class Initialized
INFO - 2016-09-22 13:19:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:41 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:41 --> Total execution time: 0.0788
INFO - 2016-09-22 13:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:41 --> Controller Class Initialized
INFO - 2016-09-22 13:19:41 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:41 --> Model Class Initialized
INFO - 2016-09-22 13:19:41 --> Model Class Initialized
INFO - 2016-09-22 13:19:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:41 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:41 --> Total execution time: 0.0999
INFO - 2016-09-22 13:19:44 --> Config Class Initialized
INFO - 2016-09-22 13:19:44 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:44 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:44 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:44 --> URI Class Initialized
INFO - 2016-09-22 13:19:44 --> Router Class Initialized
INFO - 2016-09-22 13:19:44 --> Output Class Initialized
INFO - 2016-09-22 13:19:44 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:44 --> Input Class Initialized
INFO - 2016-09-22 13:19:44 --> Language Class Initialized
INFO - 2016-09-22 13:19:44 --> Loader Class Initialized
INFO - 2016-09-22 13:19:44 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:44 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:44 --> Controller Class Initialized
INFO - 2016-09-22 13:19:44 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:44 --> Model Class Initialized
INFO - 2016-09-22 13:19:44 --> Model Class Initialized
INFO - 2016-09-22 13:19:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:44 --> Config Class Initialized
INFO - 2016-09-22 13:19:44 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:19:44 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:19:44 --> Utf8 Class Initialized
INFO - 2016-09-22 13:19:44 --> URI Class Initialized
INFO - 2016-09-22 13:19:44 --> Router Class Initialized
INFO - 2016-09-22 13:19:44 --> Output Class Initialized
INFO - 2016-09-22 13:19:44 --> Security Class Initialized
DEBUG - 2016-09-22 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:19:44 --> Input Class Initialized
INFO - 2016-09-22 13:19:44 --> Language Class Initialized
INFO - 2016-09-22 13:19:44 --> Loader Class Initialized
INFO - 2016-09-22 13:19:44 --> Helper loaded: url_helper
INFO - 2016-09-22 13:19:44 --> Helper loaded: language_helper
INFO - 2016-09-22 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:19:44 --> Controller Class Initialized
INFO - 2016-09-22 13:19:44 --> Database Driver Class Initialized
INFO - 2016-09-22 13:19:44 --> Model Class Initialized
INFO - 2016-09-22 13:19:44 --> Model Class Initialized
INFO - 2016-09-22 13:19:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:19:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:19:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-22 13:19:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:19:44 --> Final output sent to browser
DEBUG - 2016-09-22 13:19:44 --> Total execution time: 0.0596
INFO - 2016-09-22 13:20:03 --> Config Class Initialized
INFO - 2016-09-22 13:20:03 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:20:03 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:20:03 --> Utf8 Class Initialized
INFO - 2016-09-22 13:20:03 --> URI Class Initialized
INFO - 2016-09-22 13:20:03 --> Router Class Initialized
INFO - 2016-09-22 13:20:03 --> Output Class Initialized
INFO - 2016-09-22 13:20:03 --> Security Class Initialized
DEBUG - 2016-09-22 13:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:20:03 --> Input Class Initialized
INFO - 2016-09-22 13:20:03 --> Language Class Initialized
INFO - 2016-09-22 13:20:03 --> Loader Class Initialized
INFO - 2016-09-22 13:20:03 --> Helper loaded: url_helper
INFO - 2016-09-22 13:20:03 --> Helper loaded: language_helper
INFO - 2016-09-22 13:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:20:03 --> Controller Class Initialized
INFO - 2016-09-22 13:20:03 --> Database Driver Class Initialized
INFO - 2016-09-22 13:20:03 --> Model Class Initialized
INFO - 2016-09-22 13:20:03 --> Model Class Initialized
INFO - 2016-09-22 13:20:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 13:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:20:03 --> Final output sent to browser
DEBUG - 2016-09-22 13:20:03 --> Total execution time: 0.0629
INFO - 2016-09-22 13:20:05 --> Config Class Initialized
INFO - 2016-09-22 13:20:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:20:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:20:05 --> Utf8 Class Initialized
INFO - 2016-09-22 13:20:05 --> URI Class Initialized
INFO - 2016-09-22 13:20:05 --> Router Class Initialized
INFO - 2016-09-22 13:20:05 --> Output Class Initialized
INFO - 2016-09-22 13:20:05 --> Security Class Initialized
DEBUG - 2016-09-22 13:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:20:05 --> Input Class Initialized
INFO - 2016-09-22 13:20:05 --> Language Class Initialized
INFO - 2016-09-22 13:20:05 --> Loader Class Initialized
INFO - 2016-09-22 13:20:05 --> Helper loaded: url_helper
INFO - 2016-09-22 13:20:05 --> Helper loaded: language_helper
INFO - 2016-09-22 13:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:20:05 --> Controller Class Initialized
INFO - 2016-09-22 13:20:05 --> Database Driver Class Initialized
INFO - 2016-09-22 13:20:05 --> Model Class Initialized
INFO - 2016-09-22 13:20:05 --> Model Class Initialized
INFO - 2016-09-22 13:20:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:20:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:20:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 13:20:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:20:05 --> Final output sent to browser
DEBUG - 2016-09-22 13:20:05 --> Total execution time: 0.0582
INFO - 2016-09-22 13:20:12 --> Config Class Initialized
INFO - 2016-09-22 13:20:12 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:20:12 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:20:12 --> Utf8 Class Initialized
INFO - 2016-09-22 13:20:12 --> URI Class Initialized
INFO - 2016-09-22 13:20:12 --> Router Class Initialized
INFO - 2016-09-22 13:20:12 --> Output Class Initialized
INFO - 2016-09-22 13:20:12 --> Security Class Initialized
DEBUG - 2016-09-22 13:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:20:12 --> Input Class Initialized
INFO - 2016-09-22 13:20:12 --> Language Class Initialized
INFO - 2016-09-22 13:20:12 --> Loader Class Initialized
INFO - 2016-09-22 13:20:12 --> Helper loaded: url_helper
INFO - 2016-09-22 13:20:12 --> Helper loaded: language_helper
INFO - 2016-09-22 13:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:20:12 --> Controller Class Initialized
INFO - 2016-09-22 13:20:12 --> Database Driver Class Initialized
INFO - 2016-09-22 13:20:12 --> Model Class Initialized
INFO - 2016-09-22 13:20:12 --> Model Class Initialized
INFO - 2016-09-22 13:20:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:20:12 --> Config Class Initialized
INFO - 2016-09-22 13:20:12 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:20:12 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:20:12 --> Utf8 Class Initialized
INFO - 2016-09-22 13:20:12 --> URI Class Initialized
INFO - 2016-09-22 13:20:12 --> Router Class Initialized
INFO - 2016-09-22 13:20:12 --> Output Class Initialized
INFO - 2016-09-22 13:20:12 --> Security Class Initialized
DEBUG - 2016-09-22 13:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:20:12 --> Input Class Initialized
INFO - 2016-09-22 13:20:12 --> Language Class Initialized
INFO - 2016-09-22 13:20:12 --> Loader Class Initialized
INFO - 2016-09-22 13:20:12 --> Helper loaded: url_helper
INFO - 2016-09-22 13:20:12 --> Helper loaded: language_helper
INFO - 2016-09-22 13:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:20:12 --> Controller Class Initialized
INFO - 2016-09-22 13:20:12 --> Database Driver Class Initialized
INFO - 2016-09-22 13:20:12 --> Model Class Initialized
INFO - 2016-09-22 13:20:12 --> Model Class Initialized
INFO - 2016-09-22 13:20:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:20:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:20:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:20:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:20:13 --> Final output sent to browser
DEBUG - 2016-09-22 13:20:13 --> Total execution time: 0.0683
INFO - 2016-09-22 13:20:20 --> Config Class Initialized
INFO - 2016-09-22 13:20:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:20:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:20:20 --> Utf8 Class Initialized
INFO - 2016-09-22 13:20:20 --> URI Class Initialized
INFO - 2016-09-22 13:20:20 --> Router Class Initialized
INFO - 2016-09-22 13:20:20 --> Output Class Initialized
INFO - 2016-09-22 13:20:20 --> Security Class Initialized
DEBUG - 2016-09-22 13:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:20:20 --> Input Class Initialized
INFO - 2016-09-22 13:20:20 --> Language Class Initialized
INFO - 2016-09-22 13:20:20 --> Loader Class Initialized
INFO - 2016-09-22 13:20:20 --> Helper loaded: url_helper
INFO - 2016-09-22 13:20:20 --> Helper loaded: language_helper
INFO - 2016-09-22 13:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:20:20 --> Controller Class Initialized
INFO - 2016-09-22 13:20:20 --> Database Driver Class Initialized
INFO - 2016-09-22 13:20:20 --> Model Class Initialized
INFO - 2016-09-22 13:20:20 --> Model Class Initialized
INFO - 2016-09-22 13:20:20 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:20:20 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:20:20 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:20:20 --> Final output sent to browser
DEBUG - 2016-09-22 13:20:20 --> Total execution time: 0.0705
INFO - 2016-09-22 13:20:22 --> Config Class Initialized
INFO - 2016-09-22 13:20:22 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:20:22 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:20:22 --> Utf8 Class Initialized
INFO - 2016-09-22 13:20:22 --> URI Class Initialized
INFO - 2016-09-22 13:20:22 --> Router Class Initialized
INFO - 2016-09-22 13:20:22 --> Output Class Initialized
INFO - 2016-09-22 13:20:22 --> Security Class Initialized
DEBUG - 2016-09-22 13:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:20:22 --> Input Class Initialized
INFO - 2016-09-22 13:20:22 --> Language Class Initialized
INFO - 2016-09-22 13:20:22 --> Loader Class Initialized
INFO - 2016-09-22 13:20:22 --> Helper loaded: url_helper
INFO - 2016-09-22 13:20:22 --> Helper loaded: language_helper
INFO - 2016-09-22 13:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:20:22 --> Controller Class Initialized
INFO - 2016-09-22 13:20:22 --> Database Driver Class Initialized
INFO - 2016-09-22 13:20:22 --> Model Class Initialized
INFO - 2016-09-22 13:20:22 --> Model Class Initialized
INFO - 2016-09-22 13:20:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:20:22 --> Final output sent to browser
DEBUG - 2016-09-22 13:20:22 --> Total execution time: 0.0573
INFO - 2016-09-22 13:21:36 --> Config Class Initialized
INFO - 2016-09-22 13:21:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:21:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:21:36 --> Utf8 Class Initialized
INFO - 2016-09-22 13:21:36 --> URI Class Initialized
INFO - 2016-09-22 13:21:36 --> Router Class Initialized
INFO - 2016-09-22 13:21:36 --> Output Class Initialized
INFO - 2016-09-22 13:21:36 --> Security Class Initialized
DEBUG - 2016-09-22 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:21:36 --> Input Class Initialized
INFO - 2016-09-22 13:21:36 --> Language Class Initialized
INFO - 2016-09-22 13:21:36 --> Loader Class Initialized
INFO - 2016-09-22 13:21:36 --> Helper loaded: url_helper
INFO - 2016-09-22 13:21:36 --> Helper loaded: language_helper
INFO - 2016-09-22 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:21:36 --> Controller Class Initialized
INFO - 2016-09-22 13:21:36 --> Database Driver Class Initialized
INFO - 2016-09-22 13:21:36 --> Model Class Initialized
INFO - 2016-09-22 13:21:36 --> Model Class Initialized
INFO - 2016-09-22 13:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:21:36 --> Final output sent to browser
DEBUG - 2016-09-22 13:21:36 --> Total execution time: 0.0647
INFO - 2016-09-22 13:21:38 --> Config Class Initialized
INFO - 2016-09-22 13:21:38 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:21:38 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:21:38 --> Utf8 Class Initialized
INFO - 2016-09-22 13:21:38 --> URI Class Initialized
INFO - 2016-09-22 13:21:38 --> Router Class Initialized
INFO - 2016-09-22 13:21:38 --> Output Class Initialized
INFO - 2016-09-22 13:21:38 --> Security Class Initialized
DEBUG - 2016-09-22 13:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:21:38 --> Input Class Initialized
INFO - 2016-09-22 13:21:38 --> Language Class Initialized
INFO - 2016-09-22 13:21:38 --> Loader Class Initialized
INFO - 2016-09-22 13:21:38 --> Helper loaded: url_helper
INFO - 2016-09-22 13:21:38 --> Helper loaded: language_helper
INFO - 2016-09-22 13:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:21:38 --> Controller Class Initialized
INFO - 2016-09-22 13:21:38 --> Database Driver Class Initialized
INFO - 2016-09-22 13:21:38 --> Model Class Initialized
INFO - 2016-09-22 13:21:38 --> Model Class Initialized
INFO - 2016-09-22 13:21:38 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:21:38 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:21:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:21:38 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:21:38 --> Final output sent to browser
DEBUG - 2016-09-22 13:21:38 --> Total execution time: 0.0701
INFO - 2016-09-22 13:21:39 --> Config Class Initialized
INFO - 2016-09-22 13:21:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:21:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:21:39 --> Utf8 Class Initialized
INFO - 2016-09-22 13:21:39 --> URI Class Initialized
INFO - 2016-09-22 13:21:39 --> Router Class Initialized
INFO - 2016-09-22 13:21:39 --> Output Class Initialized
INFO - 2016-09-22 13:21:39 --> Security Class Initialized
DEBUG - 2016-09-22 13:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:21:39 --> Input Class Initialized
INFO - 2016-09-22 13:21:39 --> Language Class Initialized
INFO - 2016-09-22 13:21:39 --> Loader Class Initialized
INFO - 2016-09-22 13:21:39 --> Helper loaded: url_helper
INFO - 2016-09-22 13:21:39 --> Helper loaded: language_helper
INFO - 2016-09-22 13:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:21:39 --> Controller Class Initialized
INFO - 2016-09-22 13:21:39 --> Database Driver Class Initialized
INFO - 2016-09-22 13:21:39 --> Model Class Initialized
INFO - 2016-09-22 13:21:39 --> Model Class Initialized
INFO - 2016-09-22 13:21:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:21:39 --> Final output sent to browser
DEBUG - 2016-09-22 13:21:39 --> Total execution time: 0.0640
INFO - 2016-09-22 13:22:32 --> Config Class Initialized
INFO - 2016-09-22 13:22:32 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:22:32 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:22:32 --> Utf8 Class Initialized
INFO - 2016-09-22 13:22:32 --> URI Class Initialized
INFO - 2016-09-22 13:22:32 --> Router Class Initialized
INFO - 2016-09-22 13:22:32 --> Output Class Initialized
INFO - 2016-09-22 13:22:32 --> Security Class Initialized
DEBUG - 2016-09-22 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:22:32 --> Input Class Initialized
INFO - 2016-09-22 13:22:32 --> Language Class Initialized
INFO - 2016-09-22 13:22:32 --> Loader Class Initialized
INFO - 2016-09-22 13:22:32 --> Helper loaded: url_helper
INFO - 2016-09-22 13:22:32 --> Helper loaded: language_helper
INFO - 2016-09-22 13:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:22:32 --> Controller Class Initialized
INFO - 2016-09-22 13:22:32 --> Database Driver Class Initialized
INFO - 2016-09-22 13:22:32 --> Model Class Initialized
INFO - 2016-09-22 13:22:32 --> Model Class Initialized
INFO - 2016-09-22 13:22:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:22:32 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:22:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:22:32 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:22:32 --> Final output sent to browser
DEBUG - 2016-09-22 13:22:32 --> Total execution time: 0.0637
INFO - 2016-09-22 13:22:33 --> Config Class Initialized
INFO - 2016-09-22 13:22:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:22:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:22:33 --> Utf8 Class Initialized
INFO - 2016-09-22 13:22:33 --> URI Class Initialized
INFO - 2016-09-22 13:22:33 --> Router Class Initialized
INFO - 2016-09-22 13:22:33 --> Output Class Initialized
INFO - 2016-09-22 13:22:33 --> Security Class Initialized
DEBUG - 2016-09-22 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:22:33 --> Input Class Initialized
INFO - 2016-09-22 13:22:33 --> Language Class Initialized
INFO - 2016-09-22 13:22:33 --> Loader Class Initialized
INFO - 2016-09-22 13:22:33 --> Helper loaded: url_helper
INFO - 2016-09-22 13:22:33 --> Helper loaded: language_helper
INFO - 2016-09-22 13:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:22:33 --> Controller Class Initialized
INFO - 2016-09-22 13:22:33 --> Database Driver Class Initialized
INFO - 2016-09-22 13:22:33 --> Model Class Initialized
INFO - 2016-09-22 13:22:33 --> Model Class Initialized
INFO - 2016-09-22 13:22:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:22:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:22:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:22:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:22:33 --> Final output sent to browser
DEBUG - 2016-09-22 13:22:33 --> Total execution time: 0.0838
INFO - 2016-09-22 13:22:35 --> Config Class Initialized
INFO - 2016-09-22 13:22:35 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:22:35 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:22:35 --> Utf8 Class Initialized
INFO - 2016-09-22 13:22:35 --> URI Class Initialized
INFO - 2016-09-22 13:22:35 --> Router Class Initialized
INFO - 2016-09-22 13:22:35 --> Output Class Initialized
INFO - 2016-09-22 13:22:35 --> Security Class Initialized
DEBUG - 2016-09-22 13:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:22:35 --> Input Class Initialized
INFO - 2016-09-22 13:22:35 --> Language Class Initialized
INFO - 2016-09-22 13:22:35 --> Loader Class Initialized
INFO - 2016-09-22 13:22:35 --> Helper loaded: url_helper
INFO - 2016-09-22 13:22:35 --> Helper loaded: language_helper
INFO - 2016-09-22 13:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:22:35 --> Controller Class Initialized
INFO - 2016-09-22 13:22:35 --> Database Driver Class Initialized
INFO - 2016-09-22 13:22:35 --> Model Class Initialized
INFO - 2016-09-22 13:22:35 --> Model Class Initialized
INFO - 2016-09-22 13:22:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:22:35 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:22:35 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:22:35 --> Final output sent to browser
DEBUG - 2016-09-22 13:22:35 --> Total execution time: 0.0763
INFO - 2016-09-22 13:22:36 --> Config Class Initialized
INFO - 2016-09-22 13:22:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:22:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:22:36 --> Utf8 Class Initialized
INFO - 2016-09-22 13:22:36 --> URI Class Initialized
INFO - 2016-09-22 13:22:36 --> Router Class Initialized
INFO - 2016-09-22 13:22:36 --> Output Class Initialized
INFO - 2016-09-22 13:22:36 --> Security Class Initialized
DEBUG - 2016-09-22 13:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:22:36 --> Input Class Initialized
INFO - 2016-09-22 13:22:36 --> Language Class Initialized
INFO - 2016-09-22 13:22:36 --> Loader Class Initialized
INFO - 2016-09-22 13:22:36 --> Helper loaded: url_helper
INFO - 2016-09-22 13:22:36 --> Helper loaded: language_helper
INFO - 2016-09-22 13:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:22:36 --> Controller Class Initialized
INFO - 2016-09-22 13:22:36 --> Database Driver Class Initialized
INFO - 2016-09-22 13:22:36 --> Model Class Initialized
INFO - 2016-09-22 13:22:36 --> Model Class Initialized
INFO - 2016-09-22 13:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:22:36 --> Config Class Initialized
INFO - 2016-09-22 13:22:36 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:22:36 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:22:36 --> Utf8 Class Initialized
INFO - 2016-09-22 13:22:36 --> URI Class Initialized
INFO - 2016-09-22 13:22:36 --> Router Class Initialized
INFO - 2016-09-22 13:22:36 --> Output Class Initialized
INFO - 2016-09-22 13:22:36 --> Security Class Initialized
DEBUG - 2016-09-22 13:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:22:36 --> Input Class Initialized
INFO - 2016-09-22 13:22:36 --> Language Class Initialized
INFO - 2016-09-22 13:22:36 --> Loader Class Initialized
INFO - 2016-09-22 13:22:36 --> Helper loaded: url_helper
INFO - 2016-09-22 13:22:36 --> Helper loaded: language_helper
INFO - 2016-09-22 13:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:22:36 --> Controller Class Initialized
INFO - 2016-09-22 13:22:36 --> Database Driver Class Initialized
INFO - 2016-09-22 13:22:36 --> Model Class Initialized
INFO - 2016-09-22 13:22:36 --> Model Class Initialized
INFO - 2016-09-22 13:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:22:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:22:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-22 13:22:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:22:36 --> Final output sent to browser
DEBUG - 2016-09-22 13:22:36 --> Total execution time: 0.0723
INFO - 2016-09-22 13:23:53 --> Config Class Initialized
INFO - 2016-09-22 13:23:53 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:23:53 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:23:53 --> Utf8 Class Initialized
INFO - 2016-09-22 13:23:53 --> URI Class Initialized
INFO - 2016-09-22 13:23:53 --> Router Class Initialized
INFO - 2016-09-22 13:23:53 --> Output Class Initialized
INFO - 2016-09-22 13:23:53 --> Security Class Initialized
DEBUG - 2016-09-22 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:23:53 --> Input Class Initialized
INFO - 2016-09-22 13:23:53 --> Language Class Initialized
INFO - 2016-09-22 13:23:53 --> Loader Class Initialized
INFO - 2016-09-22 13:23:53 --> Helper loaded: url_helper
INFO - 2016-09-22 13:23:53 --> Helper loaded: language_helper
INFO - 2016-09-22 13:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:23:53 --> Controller Class Initialized
INFO - 2016-09-22 13:23:53 --> Database Driver Class Initialized
INFO - 2016-09-22 13:23:53 --> Model Class Initialized
INFO - 2016-09-22 13:23:53 --> Model Class Initialized
INFO - 2016-09-22 13:23:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:23:53 --> Final output sent to browser
DEBUG - 2016-09-22 13:23:53 --> Total execution time: 0.0572
INFO - 2016-09-22 13:23:53 --> Config Class Initialized
INFO - 2016-09-22 13:23:53 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:23:53 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:23:53 --> Utf8 Class Initialized
INFO - 2016-09-22 13:23:53 --> URI Class Initialized
INFO - 2016-09-22 13:23:53 --> Router Class Initialized
INFO - 2016-09-22 13:23:53 --> Output Class Initialized
INFO - 2016-09-22 13:23:53 --> Security Class Initialized
DEBUG - 2016-09-22 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:23:53 --> Input Class Initialized
INFO - 2016-09-22 13:23:53 --> Language Class Initialized
INFO - 2016-09-22 13:23:53 --> Loader Class Initialized
INFO - 2016-09-22 13:23:53 --> Helper loaded: url_helper
INFO - 2016-09-22 13:23:53 --> Helper loaded: language_helper
INFO - 2016-09-22 13:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:23:53 --> Controller Class Initialized
INFO - 2016-09-22 13:23:53 --> Database Driver Class Initialized
INFO - 2016-09-22 13:23:53 --> Model Class Initialized
INFO - 2016-09-22 13:23:53 --> Model Class Initialized
INFO - 2016-09-22 13:23:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:23:53 --> Final output sent to browser
DEBUG - 2016-09-22 13:23:53 --> Total execution time: 0.0608
INFO - 2016-09-22 13:23:55 --> Config Class Initialized
INFO - 2016-09-22 13:23:55 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:23:55 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:23:55 --> Utf8 Class Initialized
INFO - 2016-09-22 13:23:55 --> URI Class Initialized
INFO - 2016-09-22 13:23:55 --> Router Class Initialized
INFO - 2016-09-22 13:23:55 --> Output Class Initialized
INFO - 2016-09-22 13:23:55 --> Security Class Initialized
DEBUG - 2016-09-22 13:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:23:55 --> Input Class Initialized
INFO - 2016-09-22 13:23:55 --> Language Class Initialized
INFO - 2016-09-22 13:23:55 --> Loader Class Initialized
INFO - 2016-09-22 13:23:55 --> Helper loaded: url_helper
INFO - 2016-09-22 13:23:55 --> Helper loaded: language_helper
INFO - 2016-09-22 13:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:23:55 --> Controller Class Initialized
INFO - 2016-09-22 13:23:55 --> Database Driver Class Initialized
INFO - 2016-09-22 13:23:55 --> Model Class Initialized
INFO - 2016-09-22 13:23:55 --> Model Class Initialized
INFO - 2016-09-22 13:23:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:23:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:23:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 13:23:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:23:55 --> Final output sent to browser
DEBUG - 2016-09-22 13:23:55 --> Total execution time: 0.0718
INFO - 2016-09-22 13:23:58 --> Config Class Initialized
INFO - 2016-09-22 13:23:58 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:23:58 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:23:58 --> Utf8 Class Initialized
INFO - 2016-09-22 13:23:58 --> URI Class Initialized
INFO - 2016-09-22 13:23:58 --> Router Class Initialized
INFO - 2016-09-22 13:23:58 --> Output Class Initialized
INFO - 2016-09-22 13:23:58 --> Security Class Initialized
DEBUG - 2016-09-22 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:23:58 --> Input Class Initialized
INFO - 2016-09-22 13:23:58 --> Language Class Initialized
INFO - 2016-09-22 13:23:58 --> Loader Class Initialized
INFO - 2016-09-22 13:23:58 --> Helper loaded: url_helper
INFO - 2016-09-22 13:23:58 --> Helper loaded: language_helper
INFO - 2016-09-22 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:23:58 --> Controller Class Initialized
INFO - 2016-09-22 13:23:58 --> Database Driver Class Initialized
INFO - 2016-09-22 13:23:58 --> Model Class Initialized
INFO - 2016-09-22 13:23:58 --> Model Class Initialized
INFO - 2016-09-22 13:23:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:23:58 --> Config Class Initialized
INFO - 2016-09-22 13:23:58 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:23:58 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:23:58 --> Utf8 Class Initialized
INFO - 2016-09-22 13:23:58 --> URI Class Initialized
INFO - 2016-09-22 13:23:58 --> Router Class Initialized
INFO - 2016-09-22 13:23:58 --> Output Class Initialized
INFO - 2016-09-22 13:23:58 --> Security Class Initialized
DEBUG - 2016-09-22 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:23:58 --> Input Class Initialized
INFO - 2016-09-22 13:23:58 --> Language Class Initialized
INFO - 2016-09-22 13:23:58 --> Loader Class Initialized
INFO - 2016-09-22 13:23:58 --> Helper loaded: url_helper
INFO - 2016-09-22 13:23:58 --> Helper loaded: language_helper
INFO - 2016-09-22 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:23:58 --> Controller Class Initialized
INFO - 2016-09-22 13:23:58 --> Database Driver Class Initialized
INFO - 2016-09-22 13:23:58 --> Model Class Initialized
INFO - 2016-09-22 13:23:58 --> Model Class Initialized
INFO - 2016-09-22 13:23:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:23:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:23:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:23:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:23:58 --> Final output sent to browser
DEBUG - 2016-09-22 13:23:58 --> Total execution time: 0.0605
INFO - 2016-09-22 13:24:00 --> Config Class Initialized
INFO - 2016-09-22 13:24:00 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:00 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:00 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:00 --> URI Class Initialized
INFO - 2016-09-22 13:24:00 --> Router Class Initialized
INFO - 2016-09-22 13:24:00 --> Output Class Initialized
INFO - 2016-09-22 13:24:00 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:00 --> Input Class Initialized
INFO - 2016-09-22 13:24:00 --> Language Class Initialized
INFO - 2016-09-22 13:24:00 --> Loader Class Initialized
INFO - 2016-09-22 13:24:00 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:00 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:00 --> Controller Class Initialized
INFO - 2016-09-22 13:24:00 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:00 --> Model Class Initialized
INFO - 2016-09-22 13:24:00 --> Model Class Initialized
INFO - 2016-09-22 13:24:00 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:24:00 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:24:00 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:24:00 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:00 --> Total execution time: 0.0707
INFO - 2016-09-22 13:24:05 --> Config Class Initialized
INFO - 2016-09-22 13:24:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:05 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:05 --> URI Class Initialized
INFO - 2016-09-22 13:24:05 --> Router Class Initialized
INFO - 2016-09-22 13:24:05 --> Config Class Initialized
INFO - 2016-09-22 13:24:05 --> Hooks Class Initialized
INFO - 2016-09-22 13:24:05 --> Output Class Initialized
INFO - 2016-09-22 13:24:05 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:05 --> Utf8 Class Initialized
DEBUG - 2016-09-22 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:05 --> Input Class Initialized
INFO - 2016-09-22 13:24:05 --> URI Class Initialized
INFO - 2016-09-22 13:24:05 --> Language Class Initialized
INFO - 2016-09-22 13:24:05 --> Router Class Initialized
INFO - 2016-09-22 13:24:05 --> Loader Class Initialized
INFO - 2016-09-22 13:24:05 --> Output Class Initialized
INFO - 2016-09-22 13:24:05 --> Security Class Initialized
INFO - 2016-09-22 13:24:05 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:05 --> Helper loaded: language_helper
DEBUG - 2016-09-22 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:05 --> Input Class Initialized
INFO - 2016-09-22 13:24:05 --> Language Class Initialized
INFO - 2016-09-22 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:05 --> Controller Class Initialized
INFO - 2016-09-22 13:24:05 --> Loader Class Initialized
INFO - 2016-09-22 13:24:05 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:05 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:05 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:05 --> Model Class Initialized
INFO - 2016-09-22 13:24:05 --> Model Class Initialized
INFO - 2016-09-22 13:24:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:05 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:05 --> Total execution time: 0.0697
INFO - 2016-09-22 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:05 --> Controller Class Initialized
INFO - 2016-09-22 13:24:05 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:05 --> Model Class Initialized
INFO - 2016-09-22 13:24:05 --> Model Class Initialized
INFO - 2016-09-22 13:24:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:05 --> Config Class Initialized
INFO - 2016-09-22 13:24:05 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:05 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:05 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:05 --> URI Class Initialized
INFO - 2016-09-22 13:24:05 --> Router Class Initialized
INFO - 2016-09-22 13:24:05 --> Output Class Initialized
INFO - 2016-09-22 13:24:05 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:05 --> Input Class Initialized
INFO - 2016-09-22 13:24:05 --> Language Class Initialized
INFO - 2016-09-22 13:24:05 --> Loader Class Initialized
INFO - 2016-09-22 13:24:05 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:05 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:05 --> Controller Class Initialized
INFO - 2016-09-22 13:24:05 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:05 --> Model Class Initialized
INFO - 2016-09-22 13:24:05 --> Model Class Initialized
INFO - 2016-09-22 13:24:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:24:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-22 13:24:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:24:05 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:05 --> Total execution time: 0.0586
INFO - 2016-09-22 13:24:37 --> Config Class Initialized
INFO - 2016-09-22 13:24:37 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:37 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:37 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:37 --> URI Class Initialized
INFO - 2016-09-22 13:24:37 --> Router Class Initialized
INFO - 2016-09-22 13:24:37 --> Output Class Initialized
INFO - 2016-09-22 13:24:37 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:37 --> Input Class Initialized
INFO - 2016-09-22 13:24:37 --> Language Class Initialized
INFO - 2016-09-22 13:24:37 --> Loader Class Initialized
INFO - 2016-09-22 13:24:37 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:37 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:37 --> Controller Class Initialized
INFO - 2016-09-22 13:24:37 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:37 --> Model Class Initialized
INFO - 2016-09-22 13:24:37 --> Model Class Initialized
INFO - 2016-09-22 13:24:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:24:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 13:24:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:24:37 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:37 --> Total execution time: 0.0597
INFO - 2016-09-22 13:24:38 --> Config Class Initialized
INFO - 2016-09-22 13:24:38 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:38 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:38 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:38 --> URI Class Initialized
INFO - 2016-09-22 13:24:38 --> Router Class Initialized
INFO - 2016-09-22 13:24:38 --> Output Class Initialized
INFO - 2016-09-22 13:24:38 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:38 --> Input Class Initialized
INFO - 2016-09-22 13:24:38 --> Language Class Initialized
INFO - 2016-09-22 13:24:38 --> Loader Class Initialized
INFO - 2016-09-22 13:24:38 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:38 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:38 --> Controller Class Initialized
INFO - 2016-09-22 13:24:38 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:38 --> Model Class Initialized
INFO - 2016-09-22 13:24:38 --> Model Class Initialized
INFO - 2016-09-22 13:24:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 13:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:24:38 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:38 --> Total execution time: 0.0682
INFO - 2016-09-22 13:24:41 --> Config Class Initialized
INFO - 2016-09-22 13:24:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:41 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:41 --> URI Class Initialized
INFO - 2016-09-22 13:24:41 --> Router Class Initialized
INFO - 2016-09-22 13:24:41 --> Output Class Initialized
INFO - 2016-09-22 13:24:41 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:41 --> Input Class Initialized
INFO - 2016-09-22 13:24:41 --> Language Class Initialized
INFO - 2016-09-22 13:24:41 --> Loader Class Initialized
INFO - 2016-09-22 13:24:41 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:41 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:41 --> Controller Class Initialized
INFO - 2016-09-22 13:24:41 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:41 --> Model Class Initialized
INFO - 2016-09-22 13:24:41 --> Model Class Initialized
INFO - 2016-09-22 13:24:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:41 --> Config Class Initialized
INFO - 2016-09-22 13:24:41 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:41 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:41 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:41 --> URI Class Initialized
INFO - 2016-09-22 13:24:41 --> Router Class Initialized
INFO - 2016-09-22 13:24:41 --> Output Class Initialized
INFO - 2016-09-22 13:24:41 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:41 --> Input Class Initialized
INFO - 2016-09-22 13:24:41 --> Language Class Initialized
INFO - 2016-09-22 13:24:41 --> Loader Class Initialized
INFO - 2016-09-22 13:24:41 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:41 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:41 --> Controller Class Initialized
INFO - 2016-09-22 13:24:41 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:41 --> Model Class Initialized
INFO - 2016-09-22 13:24:41 --> Model Class Initialized
INFO - 2016-09-22 13:24:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:24:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:24:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:24:41 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:41 --> Total execution time: 0.0592
INFO - 2016-09-22 13:24:43 --> Config Class Initialized
INFO - 2016-09-22 13:24:43 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:43 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:43 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:43 --> URI Class Initialized
INFO - 2016-09-22 13:24:43 --> Router Class Initialized
INFO - 2016-09-22 13:24:43 --> Output Class Initialized
INFO - 2016-09-22 13:24:43 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:43 --> Input Class Initialized
INFO - 2016-09-22 13:24:43 --> Language Class Initialized
INFO - 2016-09-22 13:24:43 --> Loader Class Initialized
INFO - 2016-09-22 13:24:43 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:43 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:43 --> Controller Class Initialized
INFO - 2016-09-22 13:24:43 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:43 --> Model Class Initialized
INFO - 2016-09-22 13:24:43 --> Model Class Initialized
INFO - 2016-09-22 13:24:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:24:43 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:24:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:24:43 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:24:43 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:43 --> Total execution time: 0.0788
INFO - 2016-09-22 13:24:44 --> Config Class Initialized
INFO - 2016-09-22 13:24:44 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:24:44 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:24:44 --> Utf8 Class Initialized
INFO - 2016-09-22 13:24:44 --> URI Class Initialized
INFO - 2016-09-22 13:24:44 --> Router Class Initialized
INFO - 2016-09-22 13:24:44 --> Output Class Initialized
INFO - 2016-09-22 13:24:44 --> Security Class Initialized
DEBUG - 2016-09-22 13:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:24:44 --> Input Class Initialized
INFO - 2016-09-22 13:24:44 --> Language Class Initialized
INFO - 2016-09-22 13:24:44 --> Loader Class Initialized
INFO - 2016-09-22 13:24:44 --> Helper loaded: url_helper
INFO - 2016-09-22 13:24:44 --> Helper loaded: language_helper
INFO - 2016-09-22 13:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:24:44 --> Controller Class Initialized
INFO - 2016-09-22 13:24:44 --> Database Driver Class Initialized
INFO - 2016-09-22 13:24:44 --> Model Class Initialized
INFO - 2016-09-22 13:24:44 --> Model Class Initialized
INFO - 2016-09-22 13:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:24:44 --> Final output sent to browser
DEBUG - 2016-09-22 13:24:44 --> Total execution time: 0.0580
INFO - 2016-09-22 13:25:26 --> Config Class Initialized
INFO - 2016-09-22 13:25:26 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:25:26 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:25:26 --> Utf8 Class Initialized
INFO - 2016-09-22 13:25:26 --> URI Class Initialized
INFO - 2016-09-22 13:25:26 --> Router Class Initialized
INFO - 2016-09-22 13:25:26 --> Output Class Initialized
INFO - 2016-09-22 13:25:26 --> Security Class Initialized
DEBUG - 2016-09-22 13:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:25:26 --> Input Class Initialized
INFO - 2016-09-22 13:25:26 --> Language Class Initialized
INFO - 2016-09-22 13:25:26 --> Loader Class Initialized
INFO - 2016-09-22 13:25:26 --> Helper loaded: url_helper
INFO - 2016-09-22 13:25:26 --> Helper loaded: language_helper
INFO - 2016-09-22 13:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:25:26 --> Controller Class Initialized
INFO - 2016-09-22 13:25:26 --> Database Driver Class Initialized
INFO - 2016-09-22 13:25:26 --> Model Class Initialized
INFO - 2016-09-22 13:25:26 --> Model Class Initialized
INFO - 2016-09-22 13:25:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:25:26 --> Final output sent to browser
DEBUG - 2016-09-22 13:25:26 --> Total execution time: 0.0584
INFO - 2016-09-22 13:25:28 --> Config Class Initialized
INFO - 2016-09-22 13:25:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:25:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:25:28 --> Utf8 Class Initialized
INFO - 2016-09-22 13:25:28 --> URI Class Initialized
INFO - 2016-09-22 13:25:28 --> Router Class Initialized
INFO - 2016-09-22 13:25:28 --> Output Class Initialized
INFO - 2016-09-22 13:25:28 --> Security Class Initialized
DEBUG - 2016-09-22 13:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:25:28 --> Input Class Initialized
INFO - 2016-09-22 13:25:28 --> Language Class Initialized
INFO - 2016-09-22 13:25:28 --> Loader Class Initialized
INFO - 2016-09-22 13:25:28 --> Helper loaded: url_helper
INFO - 2016-09-22 13:25:28 --> Helper loaded: language_helper
INFO - 2016-09-22 13:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:25:28 --> Controller Class Initialized
INFO - 2016-09-22 13:25:28 --> Database Driver Class Initialized
INFO - 2016-09-22 13:25:28 --> Model Class Initialized
INFO - 2016-09-22 13:25:28 --> Model Class Initialized
INFO - 2016-09-22 13:25:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 13:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:25:28 --> Final output sent to browser
DEBUG - 2016-09-22 13:25:28 --> Total execution time: 0.0617
INFO - 2016-09-22 13:25:31 --> Config Class Initialized
INFO - 2016-09-22 13:25:31 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:25:31 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:25:31 --> Utf8 Class Initialized
INFO - 2016-09-22 13:25:31 --> URI Class Initialized
INFO - 2016-09-22 13:25:31 --> Router Class Initialized
INFO - 2016-09-22 13:25:31 --> Output Class Initialized
INFO - 2016-09-22 13:25:31 --> Security Class Initialized
DEBUG - 2016-09-22 13:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:25:31 --> Input Class Initialized
INFO - 2016-09-22 13:25:31 --> Language Class Initialized
INFO - 2016-09-22 13:25:31 --> Loader Class Initialized
INFO - 2016-09-22 13:25:31 --> Helper loaded: url_helper
INFO - 2016-09-22 13:25:31 --> Helper loaded: language_helper
INFO - 2016-09-22 13:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:25:31 --> Controller Class Initialized
INFO - 2016-09-22 13:25:31 --> Database Driver Class Initialized
INFO - 2016-09-22 13:25:31 --> Model Class Initialized
INFO - 2016-09-22 13:25:31 --> Model Class Initialized
INFO - 2016-09-22 13:25:31 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 13:25:31 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 13:25:31 --> Severity: Notice --> Undefined index: individual_time C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 783
INFO - 2016-09-22 13:25:31 --> Final output sent to browser
DEBUG - 2016-09-22 13:25:31 --> Total execution time: 0.0674
INFO - 2016-09-22 13:25:34 --> Config Class Initialized
INFO - 2016-09-22 13:25:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:25:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:25:34 --> Utf8 Class Initialized
INFO - 2016-09-22 13:25:34 --> URI Class Initialized
INFO - 2016-09-22 13:25:34 --> Router Class Initialized
INFO - 2016-09-22 13:25:34 --> Output Class Initialized
INFO - 2016-09-22 13:25:34 --> Security Class Initialized
DEBUG - 2016-09-22 13:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:25:34 --> Input Class Initialized
INFO - 2016-09-22 13:25:34 --> Language Class Initialized
INFO - 2016-09-22 13:25:34 --> Loader Class Initialized
INFO - 2016-09-22 13:25:34 --> Helper loaded: url_helper
INFO - 2016-09-22 13:25:34 --> Helper loaded: language_helper
INFO - 2016-09-22 13:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:25:34 --> Controller Class Initialized
INFO - 2016-09-22 13:25:34 --> Database Driver Class Initialized
INFO - 2016-09-22 13:25:34 --> Model Class Initialized
INFO - 2016-09-22 13:25:34 --> Model Class Initialized
INFO - 2016-09-22 13:25:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:25:34 --> Config Class Initialized
INFO - 2016-09-22 13:25:34 --> Hooks Class Initialized
DEBUG - 2016-09-22 13:25:34 --> UTF-8 Support Enabled
INFO - 2016-09-22 13:25:34 --> Utf8 Class Initialized
INFO - 2016-09-22 13:25:34 --> URI Class Initialized
INFO - 2016-09-22 13:25:34 --> Router Class Initialized
INFO - 2016-09-22 13:25:34 --> Output Class Initialized
INFO - 2016-09-22 13:25:34 --> Security Class Initialized
DEBUG - 2016-09-22 13:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 13:25:34 --> Input Class Initialized
INFO - 2016-09-22 13:25:34 --> Language Class Initialized
INFO - 2016-09-22 13:25:34 --> Loader Class Initialized
INFO - 2016-09-22 13:25:34 --> Helper loaded: url_helper
INFO - 2016-09-22 13:25:34 --> Helper loaded: language_helper
INFO - 2016-09-22 13:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 13:25:34 --> Controller Class Initialized
INFO - 2016-09-22 13:25:34 --> Database Driver Class Initialized
INFO - 2016-09-22 13:25:34 --> Model Class Initialized
INFO - 2016-09-22 13:25:34 --> Model Class Initialized
INFO - 2016-09-22 13:25:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 13:25:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 13:25:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-22 13:25:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 13:25:34 --> Final output sent to browser
DEBUG - 2016-09-22 13:25:34 --> Total execution time: 0.0586
INFO - 2016-09-22 19:59:17 --> Config Class Initialized
INFO - 2016-09-22 19:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-22 19:59:17 --> UTF-8 Support Enabled
INFO - 2016-09-22 19:59:17 --> Utf8 Class Initialized
INFO - 2016-09-22 19:59:17 --> URI Class Initialized
INFO - 2016-09-22 19:59:17 --> Router Class Initialized
INFO - 2016-09-22 19:59:17 --> Output Class Initialized
INFO - 2016-09-22 19:59:17 --> Security Class Initialized
DEBUG - 2016-09-22 19:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 19:59:17 --> Input Class Initialized
INFO - 2016-09-22 19:59:17 --> Language Class Initialized
INFO - 2016-09-22 19:59:17 --> Loader Class Initialized
INFO - 2016-09-22 19:59:17 --> Helper loaded: url_helper
INFO - 2016-09-22 19:59:17 --> Helper loaded: language_helper
INFO - 2016-09-22 19:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 19:59:17 --> Controller Class Initialized
INFO - 2016-09-22 19:59:17 --> Database Driver Class Initialized
INFO - 2016-09-22 19:59:17 --> Model Class Initialized
INFO - 2016-09-22 19:59:17 --> Model Class Initialized
INFO - 2016-09-22 19:59:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 19:59:18 --> Config Class Initialized
INFO - 2016-09-22 19:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 19:59:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 19:59:18 --> Utf8 Class Initialized
INFO - 2016-09-22 19:59:18 --> URI Class Initialized
INFO - 2016-09-22 19:59:18 --> Router Class Initialized
INFO - 2016-09-22 19:59:18 --> Output Class Initialized
INFO - 2016-09-22 19:59:18 --> Security Class Initialized
DEBUG - 2016-09-22 19:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 19:59:18 --> Input Class Initialized
INFO - 2016-09-22 19:59:18 --> Language Class Initialized
INFO - 2016-09-22 19:59:18 --> Loader Class Initialized
INFO - 2016-09-22 19:59:18 --> Helper loaded: url_helper
INFO - 2016-09-22 19:59:18 --> Helper loaded: language_helper
INFO - 2016-09-22 19:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 19:59:18 --> Controller Class Initialized
INFO - 2016-09-22 19:59:18 --> Database Driver Class Initialized
INFO - 2016-09-22 19:59:18 --> Model Class Initialized
INFO - 2016-09-22 19:59:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 19:59:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-22 19:59:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-22 19:59:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-22 19:59:18 --> Final output sent to browser
DEBUG - 2016-09-22 19:59:18 --> Total execution time: 0.0528
INFO - 2016-09-22 19:59:18 --> Config Class Initialized
INFO - 2016-09-22 19:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 19:59:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 19:59:18 --> Utf8 Class Initialized
INFO - 2016-09-22 19:59:18 --> URI Class Initialized
INFO - 2016-09-22 19:59:18 --> Router Class Initialized
INFO - 2016-09-22 19:59:18 --> Output Class Initialized
INFO - 2016-09-22 19:59:18 --> Security Class Initialized
DEBUG - 2016-09-22 19:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 19:59:18 --> Input Class Initialized
INFO - 2016-09-22 19:59:18 --> Language Class Initialized
INFO - 2016-09-22 19:59:18 --> Loader Class Initialized
INFO - 2016-09-22 19:59:18 --> Helper loaded: url_helper
INFO - 2016-09-22 19:59:18 --> Helper loaded: language_helper
INFO - 2016-09-22 19:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 19:59:18 --> Controller Class Initialized
INFO - 2016-09-22 19:59:18 --> Database Driver Class Initialized
INFO - 2016-09-22 19:59:18 --> Model Class Initialized
INFO - 2016-09-22 19:59:18 --> Model Class Initialized
INFO - 2016-09-22 19:59:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 19:59:18 --> Config Class Initialized
INFO - 2016-09-22 19:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-22 19:59:18 --> UTF-8 Support Enabled
INFO - 2016-09-22 19:59:18 --> Utf8 Class Initialized
INFO - 2016-09-22 19:59:18 --> URI Class Initialized
INFO - 2016-09-22 19:59:18 --> Router Class Initialized
INFO - 2016-09-22 19:59:18 --> Output Class Initialized
INFO - 2016-09-22 19:59:18 --> Security Class Initialized
DEBUG - 2016-09-22 19:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 19:59:18 --> Input Class Initialized
INFO - 2016-09-22 19:59:18 --> Language Class Initialized
INFO - 2016-09-22 19:59:18 --> Loader Class Initialized
INFO - 2016-09-22 19:59:18 --> Helper loaded: url_helper
INFO - 2016-09-22 19:59:18 --> Helper loaded: language_helper
INFO - 2016-09-22 19:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 19:59:18 --> Controller Class Initialized
INFO - 2016-09-22 19:59:18 --> Database Driver Class Initialized
INFO - 2016-09-22 19:59:18 --> Model Class Initialized
INFO - 2016-09-22 19:59:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 19:59:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-22 19:59:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-22 19:59:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-22 19:59:18 --> Final output sent to browser
DEBUG - 2016-09-22 19:59:18 --> Total execution time: 0.0560
INFO - 2016-09-22 19:59:23 --> Config Class Initialized
INFO - 2016-09-22 19:59:23 --> Hooks Class Initialized
DEBUG - 2016-09-22 19:59:23 --> UTF-8 Support Enabled
INFO - 2016-09-22 19:59:23 --> Utf8 Class Initialized
INFO - 2016-09-22 19:59:23 --> URI Class Initialized
INFO - 2016-09-22 19:59:23 --> Router Class Initialized
INFO - 2016-09-22 19:59:23 --> Output Class Initialized
INFO - 2016-09-22 19:59:23 --> Security Class Initialized
DEBUG - 2016-09-22 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 19:59:23 --> Input Class Initialized
INFO - 2016-09-22 19:59:23 --> Language Class Initialized
INFO - 2016-09-22 19:59:24 --> Loader Class Initialized
INFO - 2016-09-22 19:59:24 --> Helper loaded: url_helper
INFO - 2016-09-22 19:59:24 --> Helper loaded: language_helper
INFO - 2016-09-22 19:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 19:59:24 --> Controller Class Initialized
INFO - 2016-09-22 19:59:24 --> Database Driver Class Initialized
INFO - 2016-09-22 19:59:24 --> Model Class Initialized
INFO - 2016-09-22 19:59:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 19:59:24 --> Config Class Initialized
INFO - 2016-09-22 19:59:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 19:59:24 --> UTF-8 Support Enabled
INFO - 2016-09-22 19:59:24 --> Utf8 Class Initialized
INFO - 2016-09-22 19:59:24 --> URI Class Initialized
INFO - 2016-09-22 19:59:24 --> Router Class Initialized
INFO - 2016-09-22 19:59:24 --> Output Class Initialized
INFO - 2016-09-22 19:59:24 --> Security Class Initialized
DEBUG - 2016-09-22 19:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 19:59:24 --> Input Class Initialized
INFO - 2016-09-22 19:59:24 --> Language Class Initialized
INFO - 2016-09-22 19:59:24 --> Loader Class Initialized
INFO - 2016-09-22 19:59:24 --> Helper loaded: url_helper
INFO - 2016-09-22 19:59:24 --> Helper loaded: language_helper
INFO - 2016-09-22 19:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 19:59:24 --> Controller Class Initialized
INFO - 2016-09-22 19:59:24 --> Database Driver Class Initialized
INFO - 2016-09-22 19:59:24 --> Model Class Initialized
INFO - 2016-09-22 19:59:24 --> Model Class Initialized
INFO - 2016-09-22 19:59:24 --> Model Class Initialized
INFO - 2016-09-22 19:59:24 --> Model Class Initialized
INFO - 2016-09-22 19:59:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 19:59:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 19:59:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-22 19:59:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 19:59:24 --> Final output sent to browser
DEBUG - 2016-09-22 19:59:24 --> Total execution time: 0.0741
INFO - 2016-09-22 20:00:24 --> Config Class Initialized
INFO - 2016-09-22 20:00:24 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:00:25 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:25 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:25 --> URI Class Initialized
INFO - 2016-09-22 20:00:25 --> Router Class Initialized
INFO - 2016-09-22 20:00:25 --> Output Class Initialized
INFO - 2016-09-22 20:00:25 --> Security Class Initialized
DEBUG - 2016-09-22 20:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:25 --> Input Class Initialized
INFO - 2016-09-22 20:00:25 --> Language Class Initialized
INFO - 2016-09-22 20:00:25 --> Loader Class Initialized
INFO - 2016-09-22 20:00:25 --> Helper loaded: url_helper
INFO - 2016-09-22 20:00:25 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:25 --> Controller Class Initialized
INFO - 2016-09-22 20:00:25 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:25 --> Model Class Initialized
INFO - 2016-09-22 20:00:25 --> Model Class Initialized
INFO - 2016-09-22 20:00:25 --> Model Class Initialized
INFO - 2016-09-22 20:00:25 --> Model Class Initialized
INFO - 2016-09-22 20:00:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 20:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-22 20:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 20:00:25 --> Final output sent to browser
DEBUG - 2016-09-22 20:00:25 --> Total execution time: 0.0704
INFO - 2016-09-22 20:00:28 --> Config Class Initialized
INFO - 2016-09-22 20:00:28 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:00:28 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:28 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:28 --> URI Class Initialized
INFO - 2016-09-22 20:00:28 --> Router Class Initialized
INFO - 2016-09-22 20:00:28 --> Output Class Initialized
INFO - 2016-09-22 20:00:28 --> Security Class Initialized
DEBUG - 2016-09-22 20:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:28 --> Input Class Initialized
INFO - 2016-09-22 20:00:28 --> Language Class Initialized
INFO - 2016-09-22 20:00:28 --> Loader Class Initialized
INFO - 2016-09-22 20:00:28 --> Helper loaded: url_helper
INFO - 2016-09-22 20:00:28 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:28 --> Controller Class Initialized
INFO - 2016-09-22 20:00:28 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:28 --> Model Class Initialized
INFO - 2016-09-22 20:00:28 --> Model Class Initialized
INFO - 2016-09-22 20:00:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:00:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 20:00:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-22 20:00:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 20:00:28 --> Final output sent to browser
DEBUG - 2016-09-22 20:00:28 --> Total execution time: 0.0583
INFO - 2016-09-22 20:00:29 --> Config Class Initialized
INFO - 2016-09-22 20:00:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:00:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:29 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:29 --> URI Class Initialized
INFO - 2016-09-22 20:00:29 --> Router Class Initialized
INFO - 2016-09-22 20:00:29 --> Output Class Initialized
INFO - 2016-09-22 20:00:29 --> Security Class Initialized
DEBUG - 2016-09-22 20:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:29 --> Input Class Initialized
INFO - 2016-09-22 20:00:29 --> Language Class Initialized
INFO - 2016-09-22 20:00:30 --> Loader Class Initialized
INFO - 2016-09-22 20:00:30 --> Helper loaded: url_helper
INFO - 2016-09-22 20:00:30 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:30 --> Controller Class Initialized
INFO - 2016-09-22 20:00:30 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:30 --> Model Class Initialized
INFO - 2016-09-22 20:00:30 --> Model Class Initialized
INFO - 2016-09-22 20:00:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:00:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 20:00:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-22 20:00:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 20:00:30 --> Final output sent to browser
DEBUG - 2016-09-22 20:00:30 --> Total execution time: 0.0715
INFO - 2016-09-22 20:00:33 --> Config Class Initialized
INFO - 2016-09-22 20:00:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:00:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:33 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:33 --> URI Class Initialized
INFO - 2016-09-22 20:00:33 --> Router Class Initialized
INFO - 2016-09-22 20:00:33 --> Output Class Initialized
INFO - 2016-09-22 20:00:33 --> Security Class Initialized
DEBUG - 2016-09-22 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:33 --> Input Class Initialized
INFO - 2016-09-22 20:00:33 --> Language Class Initialized
INFO - 2016-09-22 20:00:33 --> Loader Class Initialized
INFO - 2016-09-22 20:00:33 --> Helper loaded: url_helper
INFO - 2016-09-22 20:00:33 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:33 --> Controller Class Initialized
INFO - 2016-09-22 20:00:33 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:00:33 --> Config Class Initialized
INFO - 2016-09-22 20:00:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:00:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:33 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:33 --> URI Class Initialized
INFO - 2016-09-22 20:00:33 --> Router Class Initialized
INFO - 2016-09-22 20:00:33 --> Output Class Initialized
INFO - 2016-09-22 20:00:33 --> Security Class Initialized
DEBUG - 2016-09-22 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:33 --> Input Class Initialized
INFO - 2016-09-22 20:00:33 --> Language Class Initialized
INFO - 2016-09-22 20:00:33 --> Loader Class Initialized
INFO - 2016-09-22 20:00:33 --> Helper loaded: url_helper
INFO - 2016-09-22 20:00:33 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:33 --> Controller Class Initialized
INFO - 2016-09-22 20:00:33 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:00:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 20:00:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 20:00:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 20:00:33 --> Final output sent to browser
DEBUG - 2016-09-22 20:00:33 --> Total execution time: 0.0612
INFO - 2016-09-22 20:00:33 --> Config Class Initialized
INFO - 2016-09-22 20:00:33 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:00:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:33 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:33 --> URI Class Initialized
INFO - 2016-09-22 20:00:33 --> Config Class Initialized
INFO - 2016-09-22 20:00:33 --> Hooks Class Initialized
INFO - 2016-09-22 20:00:33 --> Router Class Initialized
INFO - 2016-09-22 20:00:33 --> Output Class Initialized
DEBUG - 2016-09-22 20:00:33 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:00:33 --> Security Class Initialized
INFO - 2016-09-22 20:00:33 --> Utf8 Class Initialized
INFO - 2016-09-22 20:00:33 --> URI Class Initialized
DEBUG - 2016-09-22 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:33 --> Input Class Initialized
INFO - 2016-09-22 20:00:33 --> Language Class Initialized
INFO - 2016-09-22 20:00:33 --> Router Class Initialized
INFO - 2016-09-22 20:00:33 --> Output Class Initialized
INFO - 2016-09-22 20:00:33 --> Loader Class Initialized
INFO - 2016-09-22 20:00:33 --> Security Class Initialized
INFO - 2016-09-22 20:00:33 --> Helper loaded: url_helper
DEBUG - 2016-09-22 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:00:33 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:33 --> Input Class Initialized
INFO - 2016-09-22 20:00:33 --> Language Class Initialized
INFO - 2016-09-22 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:33 --> Controller Class Initialized
INFO - 2016-09-22 20:00:33 --> Loader Class Initialized
INFO - 2016-09-22 20:00:33 --> Helper loaded: url_helper
INFO - 2016-09-22 20:00:33 --> Helper loaded: language_helper
INFO - 2016-09-22 20:00:33 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:00:33 --> Final output sent to browser
DEBUG - 2016-09-22 20:00:33 --> Total execution time: 0.0823
INFO - 2016-09-22 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:00:33 --> Controller Class Initialized
INFO - 2016-09-22 20:00:33 --> Database Driver Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Model Class Initialized
INFO - 2016-09-22 20:00:33 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 20:00:33 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 20:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-22 20:00:33 --> Final output sent to browser
DEBUG - 2016-09-22 20:00:33 --> Total execution time: 0.1079
INFO - 2016-09-22 20:01:03 --> Config Class Initialized
INFO - 2016-09-22 20:01:03 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:03 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:03 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:03 --> URI Class Initialized
INFO - 2016-09-22 20:01:03 --> Router Class Initialized
INFO - 2016-09-22 20:01:03 --> Output Class Initialized
INFO - 2016-09-22 20:01:03 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:03 --> Input Class Initialized
INFO - 2016-09-22 20:01:03 --> Language Class Initialized
ERROR - 2016-09-22 20:01:03 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-22 20:01:13 --> Config Class Initialized
INFO - 2016-09-22 20:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:13 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:13 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:13 --> URI Class Initialized
INFO - 2016-09-22 20:01:13 --> Router Class Initialized
INFO - 2016-09-22 20:01:13 --> Output Class Initialized
INFO - 2016-09-22 20:01:13 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:13 --> Input Class Initialized
INFO - 2016-09-22 20:01:13 --> Language Class Initialized
INFO - 2016-09-22 20:01:13 --> Loader Class Initialized
INFO - 2016-09-22 20:01:13 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:13 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:13 --> Controller Class Initialized
INFO - 2016-09-22 20:01:13 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:13 --> Model Class Initialized
INFO - 2016-09-22 20:01:13 --> Model Class Initialized
INFO - 2016-09-22 20:01:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 20:01:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-22 20:01:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 20:01:13 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:13 --> Total execution time: 0.0717
INFO - 2016-09-22 20:01:13 --> Config Class Initialized
INFO - 2016-09-22 20:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:13 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:13 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:13 --> URI Class Initialized
INFO - 2016-09-22 20:01:13 --> Config Class Initialized
INFO - 2016-09-22 20:01:13 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:13 --> Router Class Initialized
INFO - 2016-09-22 20:01:13 --> Output Class Initialized
DEBUG - 2016-09-22 20:01:13 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:13 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:13 --> Security Class Initialized
INFO - 2016-09-22 20:01:13 --> URI Class Initialized
DEBUG - 2016-09-22 20:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:13 --> Input Class Initialized
INFO - 2016-09-22 20:01:13 --> Router Class Initialized
INFO - 2016-09-22 20:01:13 --> Language Class Initialized
INFO - 2016-09-22 20:01:13 --> Output Class Initialized
INFO - 2016-09-22 20:01:13 --> Loader Class Initialized
INFO - 2016-09-22 20:01:13 --> Security Class Initialized
INFO - 2016-09-22 20:01:13 --> Helper loaded: url_helper
DEBUG - 2016-09-22 20:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:13 --> Input Class Initialized
INFO - 2016-09-22 20:01:13 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:13 --> Language Class Initialized
INFO - 2016-09-22 20:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:13 --> Loader Class Initialized
INFO - 2016-09-22 20:01:13 --> Controller Class Initialized
INFO - 2016-09-22 20:01:13 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:13 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:13 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:13 --> Model Class Initialized
INFO - 2016-09-22 20:01:13 --> Model Class Initialized
INFO - 2016-09-22 20:01:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:13 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:13 --> Total execution time: 0.0814
INFO - 2016-09-22 20:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:13 --> Controller Class Initialized
INFO - 2016-09-22 20:01:13 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:13 --> Model Class Initialized
INFO - 2016-09-22 20:01:13 --> Model Class Initialized
INFO - 2016-09-22 20:01:13 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-22 20:01:14 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-22 20:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-22 20:01:14 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:14 --> Total execution time: 0.1117
INFO - 2016-09-22 20:01:20 --> Config Class Initialized
INFO - 2016-09-22 20:01:20 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:20 --> Config Class Initialized
INFO - 2016-09-22 20:01:20 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:20 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:20 --> URI Class Initialized
DEBUG - 2016-09-22 20:01:20 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:20 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:20 --> Router Class Initialized
INFO - 2016-09-22 20:01:20 --> URI Class Initialized
INFO - 2016-09-22 20:01:20 --> Output Class Initialized
INFO - 2016-09-22 20:01:20 --> Router Class Initialized
INFO - 2016-09-22 20:01:20 --> Security Class Initialized
INFO - 2016-09-22 20:01:20 --> Output Class Initialized
DEBUG - 2016-09-22 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:20 --> Input Class Initialized
INFO - 2016-09-22 20:01:20 --> Security Class Initialized
INFO - 2016-09-22 20:01:20 --> Language Class Initialized
DEBUG - 2016-09-22 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:20 --> Input Class Initialized
INFO - 2016-09-22 20:01:20 --> Language Class Initialized
INFO - 2016-09-22 20:01:20 --> Loader Class Initialized
INFO - 2016-09-22 20:01:20 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:20 --> Loader Class Initialized
INFO - 2016-09-22 20:01:20 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:20 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:20 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:20 --> Controller Class Initialized
INFO - 2016-09-22 20:01:20 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:20 --> Model Class Initialized
INFO - 2016-09-22 20:01:20 --> Model Class Initialized
INFO - 2016-09-22 20:01:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:20 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:20 --> Total execution time: 0.0641
INFO - 2016-09-22 20:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:20 --> Controller Class Initialized
INFO - 2016-09-22 20:01:20 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:20 --> Model Class Initialized
INFO - 2016-09-22 20:01:20 --> Model Class Initialized
INFO - 2016-09-22 20:01:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:20 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:20 --> Total execution time: 0.0865
INFO - 2016-09-22 20:01:29 --> Config Class Initialized
INFO - 2016-09-22 20:01:29 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:29 --> Config Class Initialized
INFO - 2016-09-22 20:01:29 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:29 --> Utf8 Class Initialized
DEBUG - 2016-09-22 20:01:29 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:29 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:29 --> URI Class Initialized
INFO - 2016-09-22 20:01:29 --> URI Class Initialized
INFO - 2016-09-22 20:01:29 --> Router Class Initialized
INFO - 2016-09-22 20:01:29 --> Router Class Initialized
INFO - 2016-09-22 20:01:29 --> Output Class Initialized
INFO - 2016-09-22 20:01:29 --> Output Class Initialized
INFO - 2016-09-22 20:01:29 --> Security Class Initialized
INFO - 2016-09-22 20:01:29 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:29 --> Input Class Initialized
INFO - 2016-09-22 20:01:29 --> Language Class Initialized
DEBUG - 2016-09-22 20:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:29 --> Input Class Initialized
INFO - 2016-09-22 20:01:29 --> Language Class Initialized
INFO - 2016-09-22 20:01:29 --> Loader Class Initialized
INFO - 2016-09-22 20:01:29 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:29 --> Loader Class Initialized
INFO - 2016-09-22 20:01:29 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:29 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:29 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:29 --> Controller Class Initialized
INFO - 2016-09-22 20:01:29 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:29 --> Model Class Initialized
INFO - 2016-09-22 20:01:29 --> Model Class Initialized
INFO - 2016-09-22 20:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:29 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:29 --> Total execution time: 0.0714
INFO - 2016-09-22 20:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:29 --> Controller Class Initialized
INFO - 2016-09-22 20:01:29 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:29 --> Model Class Initialized
INFO - 2016-09-22 20:01:29 --> Model Class Initialized
INFO - 2016-09-22 20:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:29 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:29 --> Total execution time: 0.1029
INFO - 2016-09-22 20:01:39 --> Config Class Initialized
INFO - 2016-09-22 20:01:39 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:39 --> Config Class Initialized
INFO - 2016-09-22 20:01:39 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:39 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:39 --> URI Class Initialized
DEBUG - 2016-09-22 20:01:39 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:39 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:39 --> Router Class Initialized
INFO - 2016-09-22 20:01:39 --> URI Class Initialized
INFO - 2016-09-22 20:01:39 --> Router Class Initialized
INFO - 2016-09-22 20:01:39 --> Output Class Initialized
INFO - 2016-09-22 20:01:39 --> Output Class Initialized
INFO - 2016-09-22 20:01:39 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:39 --> Security Class Initialized
INFO - 2016-09-22 20:01:39 --> Input Class Initialized
INFO - 2016-09-22 20:01:39 --> Language Class Initialized
DEBUG - 2016-09-22 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:39 --> Input Class Initialized
INFO - 2016-09-22 20:01:39 --> Language Class Initialized
INFO - 2016-09-22 20:01:39 --> Loader Class Initialized
INFO - 2016-09-22 20:01:39 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:39 --> Loader Class Initialized
INFO - 2016-09-22 20:01:39 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:39 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:39 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:39 --> Controller Class Initialized
INFO - 2016-09-22 20:01:39 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:39 --> Model Class Initialized
INFO - 2016-09-22 20:01:39 --> Model Class Initialized
INFO - 2016-09-22 20:01:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:39 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:39 --> Total execution time: 0.0759
INFO - 2016-09-22 20:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:39 --> Controller Class Initialized
INFO - 2016-09-22 20:01:39 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:39 --> Model Class Initialized
INFO - 2016-09-22 20:01:39 --> Model Class Initialized
INFO - 2016-09-22 20:01:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:39 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:39 --> Total execution time: 0.1109
INFO - 2016-09-22 20:01:43 --> Config Class Initialized
INFO - 2016-09-22 20:01:43 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:43 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:43 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:43 --> URI Class Initialized
INFO - 2016-09-22 20:01:43 --> Router Class Initialized
INFO - 2016-09-22 20:01:43 --> Config Class Initialized
INFO - 2016-09-22 20:01:43 --> Output Class Initialized
INFO - 2016-09-22 20:01:43 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:43 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-22 20:01:43 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:43 --> Input Class Initialized
INFO - 2016-09-22 20:01:43 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:43 --> Language Class Initialized
INFO - 2016-09-22 20:01:43 --> URI Class Initialized
INFO - 2016-09-22 20:01:43 --> Router Class Initialized
INFO - 2016-09-22 20:01:43 --> Loader Class Initialized
INFO - 2016-09-22 20:01:43 --> Output Class Initialized
INFO - 2016-09-22 20:01:43 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:43 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:43 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:43 --> Input Class Initialized
INFO - 2016-09-22 20:01:43 --> Language Class Initialized
INFO - 2016-09-22 20:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:43 --> Controller Class Initialized
INFO - 2016-09-22 20:01:43 --> Loader Class Initialized
INFO - 2016-09-22 20:01:43 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:43 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:43 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:43 --> Model Class Initialized
INFO - 2016-09-22 20:01:43 --> Model Class Initialized
INFO - 2016-09-22 20:01:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:43 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:43 --> Total execution time: 0.0739
INFO - 2016-09-22 20:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:43 --> Controller Class Initialized
INFO - 2016-09-22 20:01:43 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:43 --> Model Class Initialized
INFO - 2016-09-22 20:01:43 --> Model Class Initialized
INFO - 2016-09-22 20:01:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:43 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:43 --> Total execution time: 0.1004
INFO - 2016-09-22 20:01:43 --> Config Class Initialized
INFO - 2016-09-22 20:01:43 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:43 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:43 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:43 --> URI Class Initialized
INFO - 2016-09-22 20:01:43 --> Router Class Initialized
INFO - 2016-09-22 20:01:43 --> Output Class Initialized
INFO - 2016-09-22 20:01:43 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:43 --> Input Class Initialized
INFO - 2016-09-22 20:01:43 --> Language Class Initialized
ERROR - 2016-09-22 20:01:43 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-22 20:01:49 --> Config Class Initialized
INFO - 2016-09-22 20:01:49 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:49 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:49 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:49 --> URI Class Initialized
INFO - 2016-09-22 20:01:49 --> Router Class Initialized
INFO - 2016-09-22 20:01:49 --> Output Class Initialized
INFO - 2016-09-22 20:01:49 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:49 --> Input Class Initialized
INFO - 2016-09-22 20:01:49 --> Language Class Initialized
INFO - 2016-09-22 20:01:49 --> Loader Class Initialized
INFO - 2016-09-22 20:01:49 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:49 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:49 --> Controller Class Initialized
INFO - 2016-09-22 20:01:49 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:49 --> Model Class Initialized
INFO - 2016-09-22 20:01:49 --> Model Class Initialized
INFO - 2016-09-22 20:01:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:49 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:49 --> Total execution time: 0.0810
INFO - 2016-09-22 20:01:50 --> Config Class Initialized
INFO - 2016-09-22 20:01:50 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:50 --> Config Class Initialized
INFO - 2016-09-22 20:01:50 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:50 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:50 --> Utf8 Class Initialized
DEBUG - 2016-09-22 20:01:50 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:50 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:50 --> URI Class Initialized
INFO - 2016-09-22 20:01:50 --> URI Class Initialized
INFO - 2016-09-22 20:01:50 --> Router Class Initialized
INFO - 2016-09-22 20:01:50 --> Router Class Initialized
INFO - 2016-09-22 20:01:50 --> Output Class Initialized
INFO - 2016-09-22 20:01:50 --> Output Class Initialized
INFO - 2016-09-22 20:01:50 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:50 --> Input Class Initialized
INFO - 2016-09-22 20:01:50 --> Language Class Initialized
INFO - 2016-09-22 20:01:50 --> Security Class Initialized
INFO - 2016-09-22 20:01:50 --> Loader Class Initialized
DEBUG - 2016-09-22 20:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:50 --> Input Class Initialized
INFO - 2016-09-22 20:01:50 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:50 --> Config Class Initialized
INFO - 2016-09-22 20:01:50 --> Language Class Initialized
INFO - 2016-09-22 20:01:50 --> Hooks Class Initialized
INFO - 2016-09-22 20:01:50 --> Helper loaded: language_helper
ERROR - 2016-09-22 20:01:50 --> 404 Page Not Found: Ujian/set_ind_time
DEBUG - 2016-09-22 20:01:51 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:51 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:51 --> Controller Class Initialized
INFO - 2016-09-22 20:01:51 --> URI Class Initialized
INFO - 2016-09-22 20:01:51 --> Router Class Initialized
INFO - 2016-09-22 20:01:51 --> Output Class Initialized
INFO - 2016-09-22 20:01:51 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:51 --> Security Class Initialized
INFO - 2016-09-22 20:01:51 --> Model Class Initialized
DEBUG - 2016-09-22 20:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:51 --> Input Class Initialized
INFO - 2016-09-22 20:01:51 --> Model Class Initialized
INFO - 2016-09-22 20:01:51 --> Language Class Initialized
INFO - 2016-09-22 20:01:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:51 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:51 --> Total execution time: 0.0854
INFO - 2016-09-22 20:01:51 --> Loader Class Initialized
INFO - 2016-09-22 20:01:51 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:51 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:51 --> Controller Class Initialized
INFO - 2016-09-22 20:01:51 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:51 --> Model Class Initialized
INFO - 2016-09-22 20:01:51 --> Model Class Initialized
INFO - 2016-09-22 20:01:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:51 --> Config Class Initialized
INFO - 2016-09-22 20:01:51 --> Hooks Class Initialized
DEBUG - 2016-09-22 20:01:51 --> UTF-8 Support Enabled
INFO - 2016-09-22 20:01:51 --> Utf8 Class Initialized
INFO - 2016-09-22 20:01:51 --> URI Class Initialized
INFO - 2016-09-22 20:01:51 --> Router Class Initialized
INFO - 2016-09-22 20:01:51 --> Output Class Initialized
INFO - 2016-09-22 20:01:51 --> Security Class Initialized
DEBUG - 2016-09-22 20:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-22 20:01:51 --> Input Class Initialized
INFO - 2016-09-22 20:01:51 --> Language Class Initialized
INFO - 2016-09-22 20:01:51 --> Loader Class Initialized
INFO - 2016-09-22 20:01:51 --> Helper loaded: url_helper
INFO - 2016-09-22 20:01:51 --> Helper loaded: language_helper
INFO - 2016-09-22 20:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-22 20:01:51 --> Controller Class Initialized
INFO - 2016-09-22 20:01:51 --> Database Driver Class Initialized
INFO - 2016-09-22 20:01:51 --> Model Class Initialized
INFO - 2016-09-22 20:01:51 --> Model Class Initialized
INFO - 2016-09-22 20:01:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-22 20:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-22 20:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-22 20:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-22 20:01:51 --> Final output sent to browser
DEBUG - 2016-09-22 20:01:51 --> Total execution time: 0.0778
