<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-23 18:53:40 --> Config Class Initialized
INFO - 2016-09-23 18:53:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:53:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:53:40 --> Utf8 Class Initialized
INFO - 2016-09-23 18:53:40 --> URI Class Initialized
INFO - 2016-09-23 18:53:40 --> Router Class Initialized
INFO - 2016-09-23 18:53:40 --> Output Class Initialized
INFO - 2016-09-23 18:53:40 --> Security Class Initialized
DEBUG - 2016-09-23 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:53:40 --> Input Class Initialized
INFO - 2016-09-23 18:53:40 --> Language Class Initialized
INFO - 2016-09-23 18:53:40 --> Loader Class Initialized
INFO - 2016-09-23 18:53:40 --> Helper loaded: url_helper
INFO - 2016-09-23 18:53:40 --> Helper loaded: language_helper
INFO - 2016-09-23 18:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:53:40 --> Controller Class Initialized
INFO - 2016-09-23 18:53:40 --> Database Driver Class Initialized
INFO - 2016-09-23 18:53:40 --> Model Class Initialized
INFO - 2016-09-23 18:53:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:53:40 --> Config Class Initialized
INFO - 2016-09-23 18:53:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:53:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:53:40 --> Utf8 Class Initialized
INFO - 2016-09-23 18:53:40 --> URI Class Initialized
INFO - 2016-09-23 18:53:40 --> Router Class Initialized
INFO - 2016-09-23 18:53:40 --> Output Class Initialized
INFO - 2016-09-23 18:53:40 --> Security Class Initialized
DEBUG - 2016-09-23 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:53:40 --> Input Class Initialized
INFO - 2016-09-23 18:53:40 --> Language Class Initialized
INFO - 2016-09-23 18:53:40 --> Loader Class Initialized
INFO - 2016-09-23 18:53:40 --> Helper loaded: url_helper
INFO - 2016-09-23 18:53:40 --> Helper loaded: language_helper
INFO - 2016-09-23 18:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:53:40 --> Controller Class Initialized
INFO - 2016-09-23 18:53:40 --> Database Driver Class Initialized
INFO - 2016-09-23 18:53:40 --> Model Class Initialized
INFO - 2016-09-23 18:53:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:53:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-23 18:53:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-23 18:53:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-23 18:53:40 --> Final output sent to browser
DEBUG - 2016-09-23 18:53:40 --> Total execution time: 0.0591
INFO - 2016-09-23 18:53:44 --> Config Class Initialized
INFO - 2016-09-23 18:53:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:53:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:53:44 --> Utf8 Class Initialized
INFO - 2016-09-23 18:53:44 --> URI Class Initialized
INFO - 2016-09-23 18:53:44 --> Router Class Initialized
INFO - 2016-09-23 18:53:44 --> Output Class Initialized
INFO - 2016-09-23 18:53:44 --> Security Class Initialized
DEBUG - 2016-09-23 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:53:44 --> Input Class Initialized
INFO - 2016-09-23 18:53:44 --> Language Class Initialized
INFO - 2016-09-23 18:53:44 --> Loader Class Initialized
INFO - 2016-09-23 18:53:44 --> Helper loaded: url_helper
INFO - 2016-09-23 18:53:44 --> Helper loaded: language_helper
INFO - 2016-09-23 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:53:44 --> Controller Class Initialized
INFO - 2016-09-23 18:53:44 --> Database Driver Class Initialized
INFO - 2016-09-23 18:53:44 --> Model Class Initialized
INFO - 2016-09-23 18:53:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:53:44 --> Config Class Initialized
INFO - 2016-09-23 18:53:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:53:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:53:44 --> Utf8 Class Initialized
INFO - 2016-09-23 18:53:44 --> URI Class Initialized
INFO - 2016-09-23 18:53:44 --> Router Class Initialized
INFO - 2016-09-23 18:53:44 --> Output Class Initialized
INFO - 2016-09-23 18:53:44 --> Security Class Initialized
DEBUG - 2016-09-23 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:53:44 --> Input Class Initialized
INFO - 2016-09-23 18:53:44 --> Language Class Initialized
INFO - 2016-09-23 18:53:44 --> Loader Class Initialized
INFO - 2016-09-23 18:53:44 --> Helper loaded: url_helper
INFO - 2016-09-23 18:53:44 --> Helper loaded: language_helper
INFO - 2016-09-23 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:53:44 --> Controller Class Initialized
INFO - 2016-09-23 18:53:44 --> Database Driver Class Initialized
INFO - 2016-09-23 18:53:44 --> Model Class Initialized
INFO - 2016-09-23 18:53:44 --> Model Class Initialized
INFO - 2016-09-23 18:53:44 --> Model Class Initialized
INFO - 2016-09-23 18:53:44 --> Model Class Initialized
INFO - 2016-09-23 18:53:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:53:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:53:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-23 18:53:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:53:44 --> Final output sent to browser
DEBUG - 2016-09-23 18:53:44 --> Total execution time: 0.0781
INFO - 2016-09-23 18:53:49 --> Config Class Initialized
INFO - 2016-09-23 18:53:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:53:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:53:49 --> Utf8 Class Initialized
INFO - 2016-09-23 18:53:49 --> URI Class Initialized
INFO - 2016-09-23 18:53:49 --> Router Class Initialized
INFO - 2016-09-23 18:53:49 --> Output Class Initialized
INFO - 2016-09-23 18:53:49 --> Security Class Initialized
DEBUG - 2016-09-23 18:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:53:49 --> Input Class Initialized
INFO - 2016-09-23 18:53:49 --> Language Class Initialized
INFO - 2016-09-23 18:53:49 --> Loader Class Initialized
INFO - 2016-09-23 18:53:49 --> Helper loaded: url_helper
INFO - 2016-09-23 18:53:49 --> Helper loaded: language_helper
INFO - 2016-09-23 18:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:53:49 --> Controller Class Initialized
INFO - 2016-09-23 18:53:49 --> Database Driver Class Initialized
INFO - 2016-09-23 18:53:49 --> Model Class Initialized
INFO - 2016-09-23 18:53:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:53:49 --> Helper loaded: form_helper
INFO - 2016-09-23 18:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 18:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:53:49 --> Final output sent to browser
DEBUG - 2016-09-23 18:53:49 --> Total execution time: 0.0883
INFO - 2016-09-23 18:54:00 --> Config Class Initialized
INFO - 2016-09-23 18:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:00 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:00 --> URI Class Initialized
INFO - 2016-09-23 18:54:00 --> Router Class Initialized
INFO - 2016-09-23 18:54:00 --> Output Class Initialized
INFO - 2016-09-23 18:54:00 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:00 --> Input Class Initialized
INFO - 2016-09-23 18:54:00 --> Language Class Initialized
INFO - 2016-09-23 18:54:00 --> Loader Class Initialized
INFO - 2016-09-23 18:54:00 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:00 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:00 --> Controller Class Initialized
INFO - 2016-09-23 18:54:00 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:00 --> Model Class Initialized
INFO - 2016-09-23 18:54:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:00 --> Config Class Initialized
INFO - 2016-09-23 18:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:00 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:00 --> URI Class Initialized
INFO - 2016-09-23 18:54:00 --> Router Class Initialized
INFO - 2016-09-23 18:54:00 --> Output Class Initialized
INFO - 2016-09-23 18:54:00 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:00 --> Input Class Initialized
INFO - 2016-09-23 18:54:00 --> Language Class Initialized
INFO - 2016-09-23 18:54:00 --> Loader Class Initialized
INFO - 2016-09-23 18:54:00 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:00 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:00 --> Controller Class Initialized
INFO - 2016-09-23 18:54:00 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:00 --> Model Class Initialized
INFO - 2016-09-23 18:54:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:00 --> Helper loaded: form_helper
INFO - 2016-09-23 18:54:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 18:54:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:00 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:00 --> Total execution time: 0.0662
INFO - 2016-09-23 18:54:09 --> Config Class Initialized
INFO - 2016-09-23 18:54:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:09 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:09 --> URI Class Initialized
INFO - 2016-09-23 18:54:09 --> Router Class Initialized
INFO - 2016-09-23 18:54:09 --> Output Class Initialized
INFO - 2016-09-23 18:54:09 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:09 --> Input Class Initialized
INFO - 2016-09-23 18:54:09 --> Language Class Initialized
INFO - 2016-09-23 18:54:09 --> Loader Class Initialized
INFO - 2016-09-23 18:54:09 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:09 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:09 --> Controller Class Initialized
INFO - 2016-09-23 18:54:09 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:09 --> Model Class Initialized
INFO - 2016-09-23 18:54:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:09 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:09 --> Total execution time: 0.0644
INFO - 2016-09-23 18:54:10 --> Config Class Initialized
INFO - 2016-09-23 18:54:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:10 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:10 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:10 --> URI Class Initialized
INFO - 2016-09-23 18:54:10 --> Router Class Initialized
INFO - 2016-09-23 18:54:10 --> Output Class Initialized
INFO - 2016-09-23 18:54:10 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:10 --> Input Class Initialized
INFO - 2016-09-23 18:54:10 --> Language Class Initialized
INFO - 2016-09-23 18:54:10 --> Loader Class Initialized
INFO - 2016-09-23 18:54:10 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:10 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:10 --> Controller Class Initialized
INFO - 2016-09-23 18:54:10 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:10 --> Model Class Initialized
INFO - 2016-09-23 18:54:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:10 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:10 --> Total execution time: 0.0881
INFO - 2016-09-23 18:54:11 --> Config Class Initialized
INFO - 2016-09-23 18:54:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:11 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:11 --> URI Class Initialized
INFO - 2016-09-23 18:54:11 --> Router Class Initialized
INFO - 2016-09-23 18:54:11 --> Output Class Initialized
INFO - 2016-09-23 18:54:11 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:11 --> Input Class Initialized
INFO - 2016-09-23 18:54:11 --> Language Class Initialized
INFO - 2016-09-23 18:54:11 --> Loader Class Initialized
INFO - 2016-09-23 18:54:11 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:11 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:11 --> Controller Class Initialized
INFO - 2016-09-23 18:54:11 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:11 --> Model Class Initialized
INFO - 2016-09-23 18:54:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:11 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:11 --> Total execution time: 0.0791
INFO - 2016-09-23 18:54:12 --> Config Class Initialized
INFO - 2016-09-23 18:54:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:13 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:13 --> URI Class Initialized
INFO - 2016-09-23 18:54:13 --> Router Class Initialized
INFO - 2016-09-23 18:54:13 --> Output Class Initialized
INFO - 2016-09-23 18:54:13 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:13 --> Input Class Initialized
INFO - 2016-09-23 18:54:13 --> Language Class Initialized
INFO - 2016-09-23 18:54:13 --> Loader Class Initialized
INFO - 2016-09-23 18:54:13 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:13 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:13 --> Controller Class Initialized
INFO - 2016-09-23 18:54:13 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:13 --> Model Class Initialized
INFO - 2016-09-23 18:54:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:13 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:13 --> Total execution time: 0.0786
INFO - 2016-09-23 18:54:14 --> Config Class Initialized
INFO - 2016-09-23 18:54:14 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:14 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:14 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:14 --> URI Class Initialized
INFO - 2016-09-23 18:54:14 --> Router Class Initialized
INFO - 2016-09-23 18:54:14 --> Output Class Initialized
INFO - 2016-09-23 18:54:14 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:14 --> Input Class Initialized
INFO - 2016-09-23 18:54:14 --> Language Class Initialized
INFO - 2016-09-23 18:54:14 --> Loader Class Initialized
INFO - 2016-09-23 18:54:14 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:14 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:14 --> Controller Class Initialized
INFO - 2016-09-23 18:54:14 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:14 --> Model Class Initialized
INFO - 2016-09-23 18:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:14 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:14 --> Total execution time: 0.0799
INFO - 2016-09-23 18:54:30 --> Config Class Initialized
INFO - 2016-09-23 18:54:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:30 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:30 --> URI Class Initialized
INFO - 2016-09-23 18:54:30 --> Router Class Initialized
INFO - 2016-09-23 18:54:30 --> Output Class Initialized
INFO - 2016-09-23 18:54:30 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:30 --> Input Class Initialized
INFO - 2016-09-23 18:54:30 --> Language Class Initialized
INFO - 2016-09-23 18:54:30 --> Loader Class Initialized
INFO - 2016-09-23 18:54:30 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:30 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:30 --> Controller Class Initialized
INFO - 2016-09-23 18:54:30 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:30 --> Model Class Initialized
INFO - 2016-09-23 18:54:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:31 --> Config Class Initialized
INFO - 2016-09-23 18:54:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:31 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:31 --> URI Class Initialized
INFO - 2016-09-23 18:54:31 --> Router Class Initialized
INFO - 2016-09-23 18:54:31 --> Output Class Initialized
INFO - 2016-09-23 18:54:31 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:31 --> Input Class Initialized
INFO - 2016-09-23 18:54:31 --> Language Class Initialized
INFO - 2016-09-23 18:54:31 --> Loader Class Initialized
INFO - 2016-09-23 18:54:31 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:31 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:31 --> Controller Class Initialized
INFO - 2016-09-23 18:54:31 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:31 --> Model Class Initialized
INFO - 2016-09-23 18:54:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:31 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:31 --> Total execution time: 0.0670
INFO - 2016-09-23 18:54:44 --> Config Class Initialized
INFO - 2016-09-23 18:54:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:44 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:44 --> URI Class Initialized
INFO - 2016-09-23 18:54:44 --> Router Class Initialized
INFO - 2016-09-23 18:54:44 --> Output Class Initialized
INFO - 2016-09-23 18:54:44 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:44 --> Input Class Initialized
INFO - 2016-09-23 18:54:44 --> Language Class Initialized
INFO - 2016-09-23 18:54:44 --> Loader Class Initialized
INFO - 2016-09-23 18:54:44 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:44 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:44 --> Controller Class Initialized
INFO - 2016-09-23 18:54:44 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:44 --> Model Class Initialized
INFO - 2016-09-23 18:54:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:44 --> Config Class Initialized
INFO - 2016-09-23 18:54:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:44 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:44 --> URI Class Initialized
INFO - 2016-09-23 18:54:44 --> Router Class Initialized
INFO - 2016-09-23 18:54:44 --> Output Class Initialized
INFO - 2016-09-23 18:54:44 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:44 --> Input Class Initialized
INFO - 2016-09-23 18:54:44 --> Language Class Initialized
INFO - 2016-09-23 18:54:44 --> Loader Class Initialized
INFO - 2016-09-23 18:54:44 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:44 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:44 --> Controller Class Initialized
INFO - 2016-09-23 18:54:44 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:44 --> Model Class Initialized
INFO - 2016-09-23 18:54:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:44 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:44 --> Total execution time: 0.0628
INFO - 2016-09-23 18:54:57 --> Config Class Initialized
INFO - 2016-09-23 18:54:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:57 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:57 --> URI Class Initialized
INFO - 2016-09-23 18:54:57 --> Router Class Initialized
INFO - 2016-09-23 18:54:57 --> Output Class Initialized
INFO - 2016-09-23 18:54:57 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:57 --> Input Class Initialized
INFO - 2016-09-23 18:54:57 --> Language Class Initialized
INFO - 2016-09-23 18:54:57 --> Loader Class Initialized
INFO - 2016-09-23 18:54:57 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:57 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:57 --> Controller Class Initialized
INFO - 2016-09-23 18:54:57 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:57 --> Model Class Initialized
INFO - 2016-09-23 18:54:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:57 --> Config Class Initialized
INFO - 2016-09-23 18:54:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:54:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:54:57 --> Utf8 Class Initialized
INFO - 2016-09-23 18:54:57 --> URI Class Initialized
INFO - 2016-09-23 18:54:57 --> Router Class Initialized
INFO - 2016-09-23 18:54:57 --> Output Class Initialized
INFO - 2016-09-23 18:54:57 --> Security Class Initialized
DEBUG - 2016-09-23 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:54:57 --> Input Class Initialized
INFO - 2016-09-23 18:54:57 --> Language Class Initialized
INFO - 2016-09-23 18:54:57 --> Loader Class Initialized
INFO - 2016-09-23 18:54:57 --> Helper loaded: url_helper
INFO - 2016-09-23 18:54:57 --> Helper loaded: language_helper
INFO - 2016-09-23 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:54:57 --> Controller Class Initialized
INFO - 2016-09-23 18:54:57 --> Database Driver Class Initialized
INFO - 2016-09-23 18:54:57 --> Model Class Initialized
INFO - 2016-09-23 18:54:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:54:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:54:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:54:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:54:57 --> Final output sent to browser
DEBUG - 2016-09-23 18:54:57 --> Total execution time: 0.0610
INFO - 2016-09-23 18:55:17 --> Config Class Initialized
INFO - 2016-09-23 18:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:17 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:17 --> URI Class Initialized
INFO - 2016-09-23 18:55:17 --> Router Class Initialized
INFO - 2016-09-23 18:55:17 --> Output Class Initialized
INFO - 2016-09-23 18:55:17 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:17 --> Input Class Initialized
INFO - 2016-09-23 18:55:17 --> Language Class Initialized
INFO - 2016-09-23 18:55:17 --> Loader Class Initialized
INFO - 2016-09-23 18:55:17 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:17 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:17 --> Controller Class Initialized
INFO - 2016-09-23 18:55:17 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:17 --> Model Class Initialized
INFO - 2016-09-23 18:55:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:17 --> Config Class Initialized
INFO - 2016-09-23 18:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:17 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:17 --> URI Class Initialized
INFO - 2016-09-23 18:55:17 --> Router Class Initialized
INFO - 2016-09-23 18:55:17 --> Output Class Initialized
INFO - 2016-09-23 18:55:17 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:17 --> Input Class Initialized
INFO - 2016-09-23 18:55:17 --> Language Class Initialized
INFO - 2016-09-23 18:55:17 --> Loader Class Initialized
INFO - 2016-09-23 18:55:17 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:17 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:17 --> Controller Class Initialized
INFO - 2016-09-23 18:55:17 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:17 --> Model Class Initialized
INFO - 2016-09-23 18:55:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:17 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:17 --> Total execution time: 0.0821
INFO - 2016-09-23 18:55:36 --> Config Class Initialized
INFO - 2016-09-23 18:55:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:36 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:36 --> URI Class Initialized
INFO - 2016-09-23 18:55:36 --> Router Class Initialized
INFO - 2016-09-23 18:55:36 --> Output Class Initialized
INFO - 2016-09-23 18:55:36 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:36 --> Input Class Initialized
INFO - 2016-09-23 18:55:36 --> Language Class Initialized
INFO - 2016-09-23 18:55:36 --> Loader Class Initialized
INFO - 2016-09-23 18:55:36 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:36 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:36 --> Controller Class Initialized
INFO - 2016-09-23 18:55:36 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:36 --> Model Class Initialized
INFO - 2016-09-23 18:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:36 --> Config Class Initialized
INFO - 2016-09-23 18:55:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:36 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:36 --> URI Class Initialized
INFO - 2016-09-23 18:55:36 --> Router Class Initialized
INFO - 2016-09-23 18:55:36 --> Output Class Initialized
INFO - 2016-09-23 18:55:36 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:36 --> Input Class Initialized
INFO - 2016-09-23 18:55:36 --> Language Class Initialized
INFO - 2016-09-23 18:55:36 --> Loader Class Initialized
INFO - 2016-09-23 18:55:36 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:36 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:36 --> Controller Class Initialized
INFO - 2016-09-23 18:55:36 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:36 --> Model Class Initialized
INFO - 2016-09-23 18:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:36 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:36 --> Total execution time: 0.0617
INFO - 2016-09-23 18:55:40 --> Config Class Initialized
INFO - 2016-09-23 18:55:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:40 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:40 --> URI Class Initialized
INFO - 2016-09-23 18:55:40 --> Router Class Initialized
INFO - 2016-09-23 18:55:40 --> Output Class Initialized
INFO - 2016-09-23 18:55:40 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:40 --> Input Class Initialized
INFO - 2016-09-23 18:55:40 --> Language Class Initialized
INFO - 2016-09-23 18:55:40 --> Loader Class Initialized
INFO - 2016-09-23 18:55:40 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:40 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:40 --> Controller Class Initialized
INFO - 2016-09-23 18:55:40 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:40 --> Model Class Initialized
INFO - 2016-09-23 18:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:40 --> Config Class Initialized
INFO - 2016-09-23 18:55:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:40 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:40 --> URI Class Initialized
INFO - 2016-09-23 18:55:40 --> Router Class Initialized
INFO - 2016-09-23 18:55:40 --> Output Class Initialized
INFO - 2016-09-23 18:55:40 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:40 --> Input Class Initialized
INFO - 2016-09-23 18:55:40 --> Language Class Initialized
INFO - 2016-09-23 18:55:40 --> Loader Class Initialized
INFO - 2016-09-23 18:55:40 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:40 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:40 --> Controller Class Initialized
INFO - 2016-09-23 18:55:40 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:40 --> Model Class Initialized
INFO - 2016-09-23 18:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:40 --> Helper loaded: form_helper
INFO - 2016-09-23 18:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 18:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:40 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:40 --> Total execution time: 0.0642
INFO - 2016-09-23 18:55:45 --> Config Class Initialized
INFO - 2016-09-23 18:55:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:45 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:45 --> URI Class Initialized
INFO - 2016-09-23 18:55:45 --> Router Class Initialized
INFO - 2016-09-23 18:55:45 --> Output Class Initialized
INFO - 2016-09-23 18:55:45 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:45 --> Input Class Initialized
INFO - 2016-09-23 18:55:45 --> Language Class Initialized
INFO - 2016-09-23 18:55:45 --> Loader Class Initialized
INFO - 2016-09-23 18:55:45 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:45 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:45 --> Controller Class Initialized
INFO - 2016-09-23 18:55:45 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:45 --> Model Class Initialized
INFO - 2016-09-23 18:55:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:45 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:45 --> Total execution time: 0.0687
INFO - 2016-09-23 18:55:46 --> Config Class Initialized
INFO - 2016-09-23 18:55:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:46 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:46 --> URI Class Initialized
INFO - 2016-09-23 18:55:46 --> Router Class Initialized
INFO - 2016-09-23 18:55:46 --> Output Class Initialized
INFO - 2016-09-23 18:55:46 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:46 --> Input Class Initialized
INFO - 2016-09-23 18:55:46 --> Language Class Initialized
INFO - 2016-09-23 18:55:46 --> Loader Class Initialized
INFO - 2016-09-23 18:55:46 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:46 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:46 --> Controller Class Initialized
INFO - 2016-09-23 18:55:46 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:46 --> Model Class Initialized
INFO - 2016-09-23 18:55:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:46 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:46 --> Total execution time: 0.0785
INFO - 2016-09-23 18:55:48 --> Config Class Initialized
INFO - 2016-09-23 18:55:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:48 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:48 --> URI Class Initialized
INFO - 2016-09-23 18:55:48 --> Router Class Initialized
INFO - 2016-09-23 18:55:48 --> Output Class Initialized
INFO - 2016-09-23 18:55:48 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:48 --> Input Class Initialized
INFO - 2016-09-23 18:55:48 --> Language Class Initialized
INFO - 2016-09-23 18:55:48 --> Loader Class Initialized
INFO - 2016-09-23 18:55:48 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:48 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:48 --> Controller Class Initialized
INFO - 2016-09-23 18:55:48 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:48 --> Model Class Initialized
INFO - 2016-09-23 18:55:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:48 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:48 --> Total execution time: 0.0762
INFO - 2016-09-23 18:55:49 --> Config Class Initialized
INFO - 2016-09-23 18:55:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:49 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:49 --> URI Class Initialized
INFO - 2016-09-23 18:55:49 --> Router Class Initialized
INFO - 2016-09-23 18:55:49 --> Output Class Initialized
INFO - 2016-09-23 18:55:49 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:49 --> Input Class Initialized
INFO - 2016-09-23 18:55:49 --> Language Class Initialized
INFO - 2016-09-23 18:55:49 --> Loader Class Initialized
INFO - 2016-09-23 18:55:49 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:49 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:49 --> Controller Class Initialized
INFO - 2016-09-23 18:55:49 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:49 --> Model Class Initialized
INFO - 2016-09-23 18:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:49 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:49 --> Total execution time: 0.0725
INFO - 2016-09-23 18:55:51 --> Config Class Initialized
INFO - 2016-09-23 18:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:55:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:55:51 --> Utf8 Class Initialized
INFO - 2016-09-23 18:55:51 --> URI Class Initialized
INFO - 2016-09-23 18:55:51 --> Router Class Initialized
INFO - 2016-09-23 18:55:51 --> Output Class Initialized
INFO - 2016-09-23 18:55:51 --> Security Class Initialized
DEBUG - 2016-09-23 18:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:55:51 --> Input Class Initialized
INFO - 2016-09-23 18:55:51 --> Language Class Initialized
INFO - 2016-09-23 18:55:51 --> Loader Class Initialized
INFO - 2016-09-23 18:55:51 --> Helper loaded: url_helper
INFO - 2016-09-23 18:55:51 --> Helper loaded: language_helper
INFO - 2016-09-23 18:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:55:51 --> Controller Class Initialized
INFO - 2016-09-23 18:55:51 --> Database Driver Class Initialized
INFO - 2016-09-23 18:55:51 --> Model Class Initialized
INFO - 2016-09-23 18:55:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:55:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:55:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:55:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:55:51 --> Final output sent to browser
DEBUG - 2016-09-23 18:55:51 --> Total execution time: 0.0686
INFO - 2016-09-23 18:56:06 --> Config Class Initialized
INFO - 2016-09-23 18:56:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:06 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:06 --> URI Class Initialized
INFO - 2016-09-23 18:56:06 --> Router Class Initialized
INFO - 2016-09-23 18:56:06 --> Output Class Initialized
INFO - 2016-09-23 18:56:06 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:06 --> Input Class Initialized
INFO - 2016-09-23 18:56:06 --> Language Class Initialized
INFO - 2016-09-23 18:56:06 --> Loader Class Initialized
INFO - 2016-09-23 18:56:06 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:06 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:06 --> Controller Class Initialized
INFO - 2016-09-23 18:56:06 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:06 --> Model Class Initialized
INFO - 2016-09-23 18:56:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:06 --> Config Class Initialized
INFO - 2016-09-23 18:56:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:06 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:06 --> URI Class Initialized
INFO - 2016-09-23 18:56:06 --> Router Class Initialized
INFO - 2016-09-23 18:56:06 --> Output Class Initialized
INFO - 2016-09-23 18:56:06 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:06 --> Input Class Initialized
INFO - 2016-09-23 18:56:06 --> Language Class Initialized
INFO - 2016-09-23 18:56:06 --> Loader Class Initialized
INFO - 2016-09-23 18:56:06 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:06 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:06 --> Controller Class Initialized
INFO - 2016-09-23 18:56:06 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:06 --> Model Class Initialized
INFO - 2016-09-23 18:56:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:56:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:56:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:56:06 --> Final output sent to browser
DEBUG - 2016-09-23 18:56:06 --> Total execution time: 0.0613
INFO - 2016-09-23 18:56:17 --> Config Class Initialized
INFO - 2016-09-23 18:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:17 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:17 --> URI Class Initialized
INFO - 2016-09-23 18:56:17 --> Router Class Initialized
INFO - 2016-09-23 18:56:17 --> Output Class Initialized
INFO - 2016-09-23 18:56:17 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:17 --> Input Class Initialized
INFO - 2016-09-23 18:56:17 --> Language Class Initialized
INFO - 2016-09-23 18:56:17 --> Loader Class Initialized
INFO - 2016-09-23 18:56:17 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:17 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:17 --> Controller Class Initialized
INFO - 2016-09-23 18:56:17 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:17 --> Model Class Initialized
INFO - 2016-09-23 18:56:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:17 --> Config Class Initialized
INFO - 2016-09-23 18:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:17 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:17 --> URI Class Initialized
INFO - 2016-09-23 18:56:17 --> Router Class Initialized
INFO - 2016-09-23 18:56:17 --> Output Class Initialized
INFO - 2016-09-23 18:56:17 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:17 --> Input Class Initialized
INFO - 2016-09-23 18:56:17 --> Language Class Initialized
INFO - 2016-09-23 18:56:17 --> Loader Class Initialized
INFO - 2016-09-23 18:56:17 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:17 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:17 --> Controller Class Initialized
INFO - 2016-09-23 18:56:17 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:17 --> Model Class Initialized
INFO - 2016-09-23 18:56:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:56:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:56:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:56:17 --> Final output sent to browser
DEBUG - 2016-09-23 18:56:17 --> Total execution time: 0.0651
INFO - 2016-09-23 18:56:31 --> Config Class Initialized
INFO - 2016-09-23 18:56:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:31 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:31 --> URI Class Initialized
INFO - 2016-09-23 18:56:31 --> Router Class Initialized
INFO - 2016-09-23 18:56:31 --> Output Class Initialized
INFO - 2016-09-23 18:56:31 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:31 --> Input Class Initialized
INFO - 2016-09-23 18:56:31 --> Language Class Initialized
INFO - 2016-09-23 18:56:31 --> Loader Class Initialized
INFO - 2016-09-23 18:56:31 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:31 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:31 --> Controller Class Initialized
INFO - 2016-09-23 18:56:31 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:31 --> Model Class Initialized
INFO - 2016-09-23 18:56:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:31 --> Config Class Initialized
INFO - 2016-09-23 18:56:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:31 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:31 --> URI Class Initialized
INFO - 2016-09-23 18:56:31 --> Router Class Initialized
INFO - 2016-09-23 18:56:31 --> Output Class Initialized
INFO - 2016-09-23 18:56:31 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:31 --> Input Class Initialized
INFO - 2016-09-23 18:56:31 --> Language Class Initialized
INFO - 2016-09-23 18:56:31 --> Loader Class Initialized
INFO - 2016-09-23 18:56:31 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:31 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:31 --> Controller Class Initialized
INFO - 2016-09-23 18:56:31 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:31 --> Model Class Initialized
INFO - 2016-09-23 18:56:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:56:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:56:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:56:31 --> Final output sent to browser
DEBUG - 2016-09-23 18:56:31 --> Total execution time: 0.0629
INFO - 2016-09-23 18:56:45 --> Config Class Initialized
INFO - 2016-09-23 18:56:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:45 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:45 --> URI Class Initialized
INFO - 2016-09-23 18:56:45 --> Router Class Initialized
INFO - 2016-09-23 18:56:45 --> Output Class Initialized
INFO - 2016-09-23 18:56:45 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:45 --> Input Class Initialized
INFO - 2016-09-23 18:56:45 --> Language Class Initialized
INFO - 2016-09-23 18:56:45 --> Loader Class Initialized
INFO - 2016-09-23 18:56:45 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:45 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:45 --> Controller Class Initialized
INFO - 2016-09-23 18:56:45 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:45 --> Model Class Initialized
INFO - 2016-09-23 18:56:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:45 --> Config Class Initialized
INFO - 2016-09-23 18:56:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:45 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:45 --> URI Class Initialized
INFO - 2016-09-23 18:56:45 --> Router Class Initialized
INFO - 2016-09-23 18:56:45 --> Output Class Initialized
INFO - 2016-09-23 18:56:45 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:45 --> Input Class Initialized
INFO - 2016-09-23 18:56:45 --> Language Class Initialized
INFO - 2016-09-23 18:56:46 --> Loader Class Initialized
INFO - 2016-09-23 18:56:46 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:46 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:46 --> Controller Class Initialized
INFO - 2016-09-23 18:56:46 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:46 --> Model Class Initialized
INFO - 2016-09-23 18:56:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:56:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:56:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:56:46 --> Final output sent to browser
DEBUG - 2016-09-23 18:56:46 --> Total execution time: 0.0719
INFO - 2016-09-23 18:56:57 --> Config Class Initialized
INFO - 2016-09-23 18:56:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:57 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:57 --> URI Class Initialized
INFO - 2016-09-23 18:56:57 --> Router Class Initialized
INFO - 2016-09-23 18:56:57 --> Output Class Initialized
INFO - 2016-09-23 18:56:57 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:57 --> Input Class Initialized
INFO - 2016-09-23 18:56:57 --> Language Class Initialized
INFO - 2016-09-23 18:56:57 --> Loader Class Initialized
INFO - 2016-09-23 18:56:57 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:57 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:57 --> Controller Class Initialized
INFO - 2016-09-23 18:56:57 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:57 --> Model Class Initialized
INFO - 2016-09-23 18:56:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:57 --> Config Class Initialized
INFO - 2016-09-23 18:56:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:56:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:56:57 --> Utf8 Class Initialized
INFO - 2016-09-23 18:56:57 --> URI Class Initialized
INFO - 2016-09-23 18:56:57 --> Router Class Initialized
INFO - 2016-09-23 18:56:57 --> Output Class Initialized
INFO - 2016-09-23 18:56:57 --> Security Class Initialized
DEBUG - 2016-09-23 18:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:56:57 --> Input Class Initialized
INFO - 2016-09-23 18:56:57 --> Language Class Initialized
INFO - 2016-09-23 18:56:57 --> Loader Class Initialized
INFO - 2016-09-23 18:56:57 --> Helper loaded: url_helper
INFO - 2016-09-23 18:56:57 --> Helper loaded: language_helper
INFO - 2016-09-23 18:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:56:57 --> Controller Class Initialized
INFO - 2016-09-23 18:56:57 --> Database Driver Class Initialized
INFO - 2016-09-23 18:56:57 --> Model Class Initialized
INFO - 2016-09-23 18:56:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:56:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:56:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:56:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:56:57 --> Final output sent to browser
DEBUG - 2016-09-23 18:56:57 --> Total execution time: 0.0619
INFO - 2016-09-23 18:57:03 --> Config Class Initialized
INFO - 2016-09-23 18:57:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:03 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:03 --> URI Class Initialized
INFO - 2016-09-23 18:57:03 --> Router Class Initialized
INFO - 2016-09-23 18:57:03 --> Output Class Initialized
INFO - 2016-09-23 18:57:03 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:03 --> Input Class Initialized
INFO - 2016-09-23 18:57:03 --> Language Class Initialized
INFO - 2016-09-23 18:57:03 --> Loader Class Initialized
INFO - 2016-09-23 18:57:03 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:03 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:03 --> Controller Class Initialized
INFO - 2016-09-23 18:57:03 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:03 --> Model Class Initialized
INFO - 2016-09-23 18:57:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:03 --> Config Class Initialized
INFO - 2016-09-23 18:57:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:03 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:03 --> URI Class Initialized
INFO - 2016-09-23 18:57:03 --> Router Class Initialized
INFO - 2016-09-23 18:57:03 --> Output Class Initialized
INFO - 2016-09-23 18:57:03 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:03 --> Input Class Initialized
INFO - 2016-09-23 18:57:03 --> Language Class Initialized
INFO - 2016-09-23 18:57:03 --> Loader Class Initialized
INFO - 2016-09-23 18:57:03 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:03 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:03 --> Controller Class Initialized
INFO - 2016-09-23 18:57:03 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:03 --> Model Class Initialized
INFO - 2016-09-23 18:57:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:03 --> Helper loaded: form_helper
INFO - 2016-09-23 18:57:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 18:57:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:03 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:03 --> Total execution time: 0.0654
INFO - 2016-09-23 18:57:14 --> Config Class Initialized
INFO - 2016-09-23 18:57:14 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:14 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:14 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:14 --> URI Class Initialized
INFO - 2016-09-23 18:57:14 --> Router Class Initialized
INFO - 2016-09-23 18:57:14 --> Output Class Initialized
INFO - 2016-09-23 18:57:14 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:14 --> Input Class Initialized
INFO - 2016-09-23 18:57:14 --> Language Class Initialized
INFO - 2016-09-23 18:57:14 --> Loader Class Initialized
INFO - 2016-09-23 18:57:14 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:14 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:14 --> Controller Class Initialized
INFO - 2016-09-23 18:57:14 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:14 --> Model Class Initialized
INFO - 2016-09-23 18:57:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:14 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:14 --> Total execution time: 0.0621
INFO - 2016-09-23 18:57:16 --> Config Class Initialized
INFO - 2016-09-23 18:57:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:16 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:16 --> URI Class Initialized
INFO - 2016-09-23 18:57:16 --> Router Class Initialized
INFO - 2016-09-23 18:57:16 --> Output Class Initialized
INFO - 2016-09-23 18:57:16 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:16 --> Input Class Initialized
INFO - 2016-09-23 18:57:16 --> Language Class Initialized
INFO - 2016-09-23 18:57:16 --> Loader Class Initialized
INFO - 2016-09-23 18:57:16 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:16 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:16 --> Controller Class Initialized
INFO - 2016-09-23 18:57:16 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:16 --> Model Class Initialized
INFO - 2016-09-23 18:57:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:16 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:16 --> Total execution time: 0.0782
INFO - 2016-09-23 18:57:17 --> Config Class Initialized
INFO - 2016-09-23 18:57:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:17 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:17 --> URI Class Initialized
INFO - 2016-09-23 18:57:17 --> Router Class Initialized
INFO - 2016-09-23 18:57:17 --> Output Class Initialized
INFO - 2016-09-23 18:57:17 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:17 --> Input Class Initialized
INFO - 2016-09-23 18:57:17 --> Language Class Initialized
INFO - 2016-09-23 18:57:17 --> Loader Class Initialized
INFO - 2016-09-23 18:57:17 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:17 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:17 --> Controller Class Initialized
INFO - 2016-09-23 18:57:17 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:17 --> Model Class Initialized
INFO - 2016-09-23 18:57:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:17 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:17 --> Total execution time: 0.0712
INFO - 2016-09-23 18:57:19 --> Config Class Initialized
INFO - 2016-09-23 18:57:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:19 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:19 --> URI Class Initialized
INFO - 2016-09-23 18:57:19 --> Router Class Initialized
INFO - 2016-09-23 18:57:19 --> Output Class Initialized
INFO - 2016-09-23 18:57:19 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:19 --> Input Class Initialized
INFO - 2016-09-23 18:57:19 --> Language Class Initialized
INFO - 2016-09-23 18:57:19 --> Loader Class Initialized
INFO - 2016-09-23 18:57:19 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:19 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:19 --> Controller Class Initialized
INFO - 2016-09-23 18:57:19 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:19 --> Model Class Initialized
INFO - 2016-09-23 18:57:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:19 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:19 --> Total execution time: 0.0744
INFO - 2016-09-23 18:57:21 --> Config Class Initialized
INFO - 2016-09-23 18:57:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:21 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:21 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:21 --> URI Class Initialized
INFO - 2016-09-23 18:57:21 --> Router Class Initialized
INFO - 2016-09-23 18:57:21 --> Output Class Initialized
INFO - 2016-09-23 18:57:21 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:21 --> Input Class Initialized
INFO - 2016-09-23 18:57:21 --> Language Class Initialized
INFO - 2016-09-23 18:57:21 --> Loader Class Initialized
INFO - 2016-09-23 18:57:21 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:21 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:21 --> Controller Class Initialized
INFO - 2016-09-23 18:57:21 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:21 --> Model Class Initialized
INFO - 2016-09-23 18:57:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:21 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:21 --> Total execution time: 0.0734
INFO - 2016-09-23 18:57:31 --> Config Class Initialized
INFO - 2016-09-23 18:57:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:31 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:31 --> URI Class Initialized
INFO - 2016-09-23 18:57:31 --> Router Class Initialized
INFO - 2016-09-23 18:57:31 --> Output Class Initialized
INFO - 2016-09-23 18:57:31 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:31 --> Input Class Initialized
INFO - 2016-09-23 18:57:31 --> Language Class Initialized
INFO - 2016-09-23 18:57:31 --> Loader Class Initialized
INFO - 2016-09-23 18:57:31 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:31 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:31 --> Controller Class Initialized
INFO - 2016-09-23 18:57:31 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:31 --> Model Class Initialized
INFO - 2016-09-23 18:57:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:31 --> Config Class Initialized
INFO - 2016-09-23 18:57:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:31 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:31 --> URI Class Initialized
INFO - 2016-09-23 18:57:31 --> Router Class Initialized
INFO - 2016-09-23 18:57:31 --> Output Class Initialized
INFO - 2016-09-23 18:57:31 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:31 --> Input Class Initialized
INFO - 2016-09-23 18:57:31 --> Language Class Initialized
INFO - 2016-09-23 18:57:31 --> Loader Class Initialized
INFO - 2016-09-23 18:57:31 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:31 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:31 --> Controller Class Initialized
INFO - 2016-09-23 18:57:31 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:31 --> Model Class Initialized
INFO - 2016-09-23 18:57:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:31 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:31 --> Total execution time: 0.0622
INFO - 2016-09-23 18:57:41 --> Config Class Initialized
INFO - 2016-09-23 18:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:41 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:41 --> URI Class Initialized
INFO - 2016-09-23 18:57:41 --> Router Class Initialized
INFO - 2016-09-23 18:57:41 --> Output Class Initialized
INFO - 2016-09-23 18:57:41 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:41 --> Input Class Initialized
INFO - 2016-09-23 18:57:41 --> Language Class Initialized
INFO - 2016-09-23 18:57:41 --> Loader Class Initialized
INFO - 2016-09-23 18:57:41 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:41 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:41 --> Controller Class Initialized
INFO - 2016-09-23 18:57:41 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:41 --> Model Class Initialized
INFO - 2016-09-23 18:57:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:41 --> Config Class Initialized
INFO - 2016-09-23 18:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:41 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:41 --> URI Class Initialized
INFO - 2016-09-23 18:57:41 --> Router Class Initialized
INFO - 2016-09-23 18:57:41 --> Output Class Initialized
INFO - 2016-09-23 18:57:41 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:41 --> Input Class Initialized
INFO - 2016-09-23 18:57:41 --> Language Class Initialized
INFO - 2016-09-23 18:57:41 --> Loader Class Initialized
INFO - 2016-09-23 18:57:41 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:41 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:41 --> Controller Class Initialized
INFO - 2016-09-23 18:57:41 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:41 --> Model Class Initialized
INFO - 2016-09-23 18:57:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:41 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:41 --> Total execution time: 0.0617
INFO - 2016-09-23 18:57:54 --> Config Class Initialized
INFO - 2016-09-23 18:57:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:54 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:54 --> URI Class Initialized
INFO - 2016-09-23 18:57:54 --> Router Class Initialized
INFO - 2016-09-23 18:57:54 --> Output Class Initialized
INFO - 2016-09-23 18:57:54 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:54 --> Input Class Initialized
INFO - 2016-09-23 18:57:54 --> Language Class Initialized
INFO - 2016-09-23 18:57:54 --> Loader Class Initialized
INFO - 2016-09-23 18:57:54 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:54 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:54 --> Controller Class Initialized
INFO - 2016-09-23 18:57:54 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:54 --> Model Class Initialized
INFO - 2016-09-23 18:57:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:54 --> Config Class Initialized
INFO - 2016-09-23 18:57:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:57:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:57:54 --> Utf8 Class Initialized
INFO - 2016-09-23 18:57:54 --> URI Class Initialized
INFO - 2016-09-23 18:57:54 --> Router Class Initialized
INFO - 2016-09-23 18:57:54 --> Output Class Initialized
INFO - 2016-09-23 18:57:54 --> Security Class Initialized
DEBUG - 2016-09-23 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:57:54 --> Input Class Initialized
INFO - 2016-09-23 18:57:54 --> Language Class Initialized
INFO - 2016-09-23 18:57:54 --> Loader Class Initialized
INFO - 2016-09-23 18:57:54 --> Helper loaded: url_helper
INFO - 2016-09-23 18:57:54 --> Helper loaded: language_helper
INFO - 2016-09-23 18:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:57:54 --> Controller Class Initialized
INFO - 2016-09-23 18:57:54 --> Database Driver Class Initialized
INFO - 2016-09-23 18:57:54 --> Model Class Initialized
INFO - 2016-09-23 18:57:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:57:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:57:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:57:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:57:54 --> Final output sent to browser
DEBUG - 2016-09-23 18:57:54 --> Total execution time: 0.0651
INFO - 2016-09-23 18:58:07 --> Config Class Initialized
INFO - 2016-09-23 18:58:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:07 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:07 --> URI Class Initialized
INFO - 2016-09-23 18:58:07 --> Router Class Initialized
INFO - 2016-09-23 18:58:07 --> Output Class Initialized
INFO - 2016-09-23 18:58:07 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:07 --> Input Class Initialized
INFO - 2016-09-23 18:58:07 --> Language Class Initialized
INFO - 2016-09-23 18:58:07 --> Loader Class Initialized
INFO - 2016-09-23 18:58:07 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:07 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:07 --> Controller Class Initialized
INFO - 2016-09-23 18:58:07 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:07 --> Model Class Initialized
INFO - 2016-09-23 18:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:07 --> Config Class Initialized
INFO - 2016-09-23 18:58:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:07 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:07 --> URI Class Initialized
INFO - 2016-09-23 18:58:07 --> Router Class Initialized
INFO - 2016-09-23 18:58:07 --> Output Class Initialized
INFO - 2016-09-23 18:58:07 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:07 --> Input Class Initialized
INFO - 2016-09-23 18:58:07 --> Language Class Initialized
INFO - 2016-09-23 18:58:07 --> Loader Class Initialized
INFO - 2016-09-23 18:58:07 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:07 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:07 --> Controller Class Initialized
INFO - 2016-09-23 18:58:07 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:07 --> Model Class Initialized
INFO - 2016-09-23 18:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:58:07 --> Final output sent to browser
DEBUG - 2016-09-23 18:58:07 --> Total execution time: 0.0617
INFO - 2016-09-23 18:58:27 --> Config Class Initialized
INFO - 2016-09-23 18:58:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:27 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:27 --> URI Class Initialized
INFO - 2016-09-23 18:58:27 --> Router Class Initialized
INFO - 2016-09-23 18:58:27 --> Output Class Initialized
INFO - 2016-09-23 18:58:27 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:27 --> Input Class Initialized
INFO - 2016-09-23 18:58:27 --> Language Class Initialized
INFO - 2016-09-23 18:58:27 --> Loader Class Initialized
INFO - 2016-09-23 18:58:27 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:27 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:27 --> Controller Class Initialized
INFO - 2016-09-23 18:58:27 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:27 --> Model Class Initialized
INFO - 2016-09-23 18:58:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:27 --> Config Class Initialized
INFO - 2016-09-23 18:58:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:27 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:27 --> URI Class Initialized
INFO - 2016-09-23 18:58:27 --> Router Class Initialized
INFO - 2016-09-23 18:58:27 --> Output Class Initialized
INFO - 2016-09-23 18:58:27 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:27 --> Input Class Initialized
INFO - 2016-09-23 18:58:27 --> Language Class Initialized
INFO - 2016-09-23 18:58:27 --> Loader Class Initialized
INFO - 2016-09-23 18:58:27 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:27 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:27 --> Controller Class Initialized
INFO - 2016-09-23 18:58:27 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:27 --> Model Class Initialized
INFO - 2016-09-23 18:58:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:58:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 18:58:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:58:27 --> Final output sent to browser
DEBUG - 2016-09-23 18:58:27 --> Total execution time: 0.0602
INFO - 2016-09-23 18:58:34 --> Config Class Initialized
INFO - 2016-09-23 18:58:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:34 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:34 --> URI Class Initialized
INFO - 2016-09-23 18:58:34 --> Router Class Initialized
INFO - 2016-09-23 18:58:34 --> Output Class Initialized
INFO - 2016-09-23 18:58:34 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:34 --> Input Class Initialized
INFO - 2016-09-23 18:58:34 --> Language Class Initialized
INFO - 2016-09-23 18:58:34 --> Loader Class Initialized
INFO - 2016-09-23 18:58:34 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:34 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:34 --> Controller Class Initialized
INFO - 2016-09-23 18:58:34 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:34 --> Model Class Initialized
INFO - 2016-09-23 18:58:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:34 --> Config Class Initialized
INFO - 2016-09-23 18:58:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:34 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:34 --> URI Class Initialized
INFO - 2016-09-23 18:58:34 --> Router Class Initialized
INFO - 2016-09-23 18:58:34 --> Output Class Initialized
INFO - 2016-09-23 18:58:34 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:34 --> Input Class Initialized
INFO - 2016-09-23 18:58:34 --> Language Class Initialized
INFO - 2016-09-23 18:58:34 --> Loader Class Initialized
INFO - 2016-09-23 18:58:34 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:34 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:34 --> Controller Class Initialized
INFO - 2016-09-23 18:58:34 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:34 --> Model Class Initialized
INFO - 2016-09-23 18:58:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:34 --> Helper loaded: form_helper
INFO - 2016-09-23 18:58:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:58:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 18:58:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:58:34 --> Final output sent to browser
DEBUG - 2016-09-23 18:58:34 --> Total execution time: 0.0635
INFO - 2016-09-23 18:58:43 --> Config Class Initialized
INFO - 2016-09-23 18:58:43 --> Hooks Class Initialized
DEBUG - 2016-09-23 18:58:43 --> UTF-8 Support Enabled
INFO - 2016-09-23 18:58:43 --> Utf8 Class Initialized
INFO - 2016-09-23 18:58:43 --> URI Class Initialized
INFO - 2016-09-23 18:58:43 --> Router Class Initialized
INFO - 2016-09-23 18:58:43 --> Output Class Initialized
INFO - 2016-09-23 18:58:43 --> Security Class Initialized
DEBUG - 2016-09-23 18:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 18:58:43 --> Input Class Initialized
INFO - 2016-09-23 18:58:43 --> Language Class Initialized
INFO - 2016-09-23 18:58:43 --> Loader Class Initialized
INFO - 2016-09-23 18:58:43 --> Helper loaded: url_helper
INFO - 2016-09-23 18:58:43 --> Helper loaded: language_helper
INFO - 2016-09-23 18:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 18:58:43 --> Controller Class Initialized
INFO - 2016-09-23 18:58:43 --> Database Driver Class Initialized
INFO - 2016-09-23 18:58:43 --> Model Class Initialized
INFO - 2016-09-23 18:58:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 18:58:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 18:58:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 18:58:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 18:58:43 --> Final output sent to browser
DEBUG - 2016-09-23 18:58:43 --> Total execution time: 0.0644
INFO - 2016-09-23 19:09:06 --> Config Class Initialized
INFO - 2016-09-23 19:09:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:06 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:06 --> URI Class Initialized
INFO - 2016-09-23 19:09:06 --> Router Class Initialized
INFO - 2016-09-23 19:09:06 --> Output Class Initialized
INFO - 2016-09-23 19:09:06 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:06 --> Input Class Initialized
INFO - 2016-09-23 19:09:06 --> Language Class Initialized
INFO - 2016-09-23 19:09:06 --> Loader Class Initialized
INFO - 2016-09-23 19:09:06 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:06 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:06 --> Controller Class Initialized
INFO - 2016-09-23 19:09:06 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:06 --> Model Class Initialized
INFO - 2016-09-23 19:09:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:06 --> Config Class Initialized
INFO - 2016-09-23 19:09:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:06 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:06 --> URI Class Initialized
INFO - 2016-09-23 19:09:06 --> Router Class Initialized
INFO - 2016-09-23 19:09:06 --> Output Class Initialized
INFO - 2016-09-23 19:09:06 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:06 --> Input Class Initialized
INFO - 2016-09-23 19:09:06 --> Language Class Initialized
INFO - 2016-09-23 19:09:06 --> Loader Class Initialized
INFO - 2016-09-23 19:09:06 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:06 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:06 --> Controller Class Initialized
INFO - 2016-09-23 19:09:06 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:06 --> Model Class Initialized
INFO - 2016-09-23 19:09:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:06 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:06 --> Total execution time: 0.0605
INFO - 2016-09-23 19:09:11 --> Config Class Initialized
INFO - 2016-09-23 19:09:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:11 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:11 --> URI Class Initialized
INFO - 2016-09-23 19:09:11 --> Router Class Initialized
INFO - 2016-09-23 19:09:11 --> Output Class Initialized
INFO - 2016-09-23 19:09:11 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:11 --> Input Class Initialized
INFO - 2016-09-23 19:09:11 --> Language Class Initialized
INFO - 2016-09-23 19:09:11 --> Loader Class Initialized
INFO - 2016-09-23 19:09:11 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:11 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:11 --> Controller Class Initialized
INFO - 2016-09-23 19:09:11 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:11 --> Model Class Initialized
INFO - 2016-09-23 19:09:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:11 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:11 --> Total execution time: 0.0659
INFO - 2016-09-23 19:09:13 --> Config Class Initialized
INFO - 2016-09-23 19:09:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:13 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:13 --> URI Class Initialized
INFO - 2016-09-23 19:09:13 --> Router Class Initialized
INFO - 2016-09-23 19:09:13 --> Output Class Initialized
INFO - 2016-09-23 19:09:13 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:13 --> Input Class Initialized
INFO - 2016-09-23 19:09:13 --> Language Class Initialized
INFO - 2016-09-23 19:09:13 --> Loader Class Initialized
INFO - 2016-09-23 19:09:13 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:13 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:13 --> Controller Class Initialized
INFO - 2016-09-23 19:09:13 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:13 --> Model Class Initialized
INFO - 2016-09-23 19:09:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:13 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:13 --> Total execution time: 0.0734
INFO - 2016-09-23 19:09:14 --> Config Class Initialized
INFO - 2016-09-23 19:09:14 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:14 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:14 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:14 --> URI Class Initialized
INFO - 2016-09-23 19:09:14 --> Router Class Initialized
INFO - 2016-09-23 19:09:14 --> Output Class Initialized
INFO - 2016-09-23 19:09:14 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:14 --> Input Class Initialized
INFO - 2016-09-23 19:09:14 --> Language Class Initialized
INFO - 2016-09-23 19:09:14 --> Loader Class Initialized
INFO - 2016-09-23 19:09:14 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:14 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:14 --> Controller Class Initialized
INFO - 2016-09-23 19:09:14 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:14 --> Model Class Initialized
INFO - 2016-09-23 19:09:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:14 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:14 --> Total execution time: 0.0759
INFO - 2016-09-23 19:09:16 --> Config Class Initialized
INFO - 2016-09-23 19:09:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:16 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:16 --> URI Class Initialized
INFO - 2016-09-23 19:09:16 --> Router Class Initialized
INFO - 2016-09-23 19:09:16 --> Output Class Initialized
INFO - 2016-09-23 19:09:16 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:16 --> Input Class Initialized
INFO - 2016-09-23 19:09:16 --> Language Class Initialized
INFO - 2016-09-23 19:09:16 --> Loader Class Initialized
INFO - 2016-09-23 19:09:16 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:16 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:16 --> Controller Class Initialized
INFO - 2016-09-23 19:09:16 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:16 --> Model Class Initialized
INFO - 2016-09-23 19:09:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:16 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:16 --> Total execution time: 0.0776
INFO - 2016-09-23 19:09:17 --> Config Class Initialized
INFO - 2016-09-23 19:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:17 --> URI Class Initialized
INFO - 2016-09-23 19:09:17 --> Router Class Initialized
INFO - 2016-09-23 19:09:17 --> Output Class Initialized
INFO - 2016-09-23 19:09:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:17 --> Input Class Initialized
INFO - 2016-09-23 19:09:17 --> Language Class Initialized
INFO - 2016-09-23 19:09:17 --> Loader Class Initialized
INFO - 2016-09-23 19:09:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:17 --> Controller Class Initialized
INFO - 2016-09-23 19:09:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:17 --> Model Class Initialized
INFO - 2016-09-23 19:09:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:17 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:17 --> Total execution time: 0.0672
INFO - 2016-09-23 19:09:19 --> Config Class Initialized
INFO - 2016-09-23 19:09:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:19 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:19 --> URI Class Initialized
INFO - 2016-09-23 19:09:19 --> Router Class Initialized
INFO - 2016-09-23 19:09:19 --> Output Class Initialized
INFO - 2016-09-23 19:09:19 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:19 --> Input Class Initialized
INFO - 2016-09-23 19:09:19 --> Language Class Initialized
INFO - 2016-09-23 19:09:19 --> Loader Class Initialized
INFO - 2016-09-23 19:09:19 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:19 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:19 --> Controller Class Initialized
INFO - 2016-09-23 19:09:19 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:19 --> Model Class Initialized
INFO - 2016-09-23 19:09:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:19 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:19 --> Total execution time: 0.0677
INFO - 2016-09-23 19:09:31 --> Config Class Initialized
INFO - 2016-09-23 19:09:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:31 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:31 --> URI Class Initialized
INFO - 2016-09-23 19:09:31 --> Router Class Initialized
INFO - 2016-09-23 19:09:31 --> Output Class Initialized
INFO - 2016-09-23 19:09:31 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:31 --> Input Class Initialized
INFO - 2016-09-23 19:09:31 --> Language Class Initialized
INFO - 2016-09-23 19:09:31 --> Loader Class Initialized
INFO - 2016-09-23 19:09:31 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:31 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:31 --> Controller Class Initialized
INFO - 2016-09-23 19:09:31 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:31 --> Model Class Initialized
INFO - 2016-09-23 19:09:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:31 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:31 --> Total execution time: 0.0653
INFO - 2016-09-23 19:09:32 --> Config Class Initialized
INFO - 2016-09-23 19:09:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:32 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:32 --> URI Class Initialized
INFO - 2016-09-23 19:09:32 --> Router Class Initialized
INFO - 2016-09-23 19:09:32 --> Output Class Initialized
INFO - 2016-09-23 19:09:32 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:32 --> Input Class Initialized
INFO - 2016-09-23 19:09:32 --> Language Class Initialized
INFO - 2016-09-23 19:09:32 --> Loader Class Initialized
INFO - 2016-09-23 19:09:32 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:32 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:32 --> Controller Class Initialized
INFO - 2016-09-23 19:09:32 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:32 --> Model Class Initialized
INFO - 2016-09-23 19:09:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:32 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:32 --> Total execution time: 0.0762
INFO - 2016-09-23 19:09:33 --> Config Class Initialized
INFO - 2016-09-23 19:09:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:33 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:33 --> URI Class Initialized
INFO - 2016-09-23 19:09:33 --> Router Class Initialized
INFO - 2016-09-23 19:09:33 --> Output Class Initialized
INFO - 2016-09-23 19:09:33 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:33 --> Input Class Initialized
INFO - 2016-09-23 19:09:33 --> Language Class Initialized
INFO - 2016-09-23 19:09:33 --> Loader Class Initialized
INFO - 2016-09-23 19:09:33 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:33 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:33 --> Controller Class Initialized
INFO - 2016-09-23 19:09:33 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:33 --> Model Class Initialized
INFO - 2016-09-23 19:09:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:33 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:33 --> Total execution time: 0.0740
INFO - 2016-09-23 19:09:34 --> Config Class Initialized
INFO - 2016-09-23 19:09:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:34 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:34 --> URI Class Initialized
INFO - 2016-09-23 19:09:34 --> Router Class Initialized
INFO - 2016-09-23 19:09:34 --> Output Class Initialized
INFO - 2016-09-23 19:09:34 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:34 --> Input Class Initialized
INFO - 2016-09-23 19:09:34 --> Language Class Initialized
INFO - 2016-09-23 19:09:34 --> Loader Class Initialized
INFO - 2016-09-23 19:09:34 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:34 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:34 --> Controller Class Initialized
INFO - 2016-09-23 19:09:34 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:34 --> Model Class Initialized
INFO - 2016-09-23 19:09:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:34 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:34 --> Total execution time: 0.0670
INFO - 2016-09-23 19:09:36 --> Config Class Initialized
INFO - 2016-09-23 19:09:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:36 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:36 --> URI Class Initialized
INFO - 2016-09-23 19:09:36 --> Router Class Initialized
INFO - 2016-09-23 19:09:36 --> Output Class Initialized
INFO - 2016-09-23 19:09:36 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:36 --> Input Class Initialized
INFO - 2016-09-23 19:09:36 --> Language Class Initialized
INFO - 2016-09-23 19:09:36 --> Loader Class Initialized
INFO - 2016-09-23 19:09:36 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:36 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:36 --> Controller Class Initialized
INFO - 2016-09-23 19:09:36 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:36 --> Model Class Initialized
INFO - 2016-09-23 19:09:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:36 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:36 --> Total execution time: 0.0754
INFO - 2016-09-23 19:09:37 --> Config Class Initialized
INFO - 2016-09-23 19:09:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:37 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:37 --> URI Class Initialized
INFO - 2016-09-23 19:09:37 --> Router Class Initialized
INFO - 2016-09-23 19:09:37 --> Output Class Initialized
INFO - 2016-09-23 19:09:37 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:37 --> Input Class Initialized
INFO - 2016-09-23 19:09:37 --> Language Class Initialized
INFO - 2016-09-23 19:09:37 --> Loader Class Initialized
INFO - 2016-09-23 19:09:37 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:37 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:37 --> Controller Class Initialized
INFO - 2016-09-23 19:09:37 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:37 --> Model Class Initialized
INFO - 2016-09-23 19:09:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:37 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:37 --> Total execution time: 0.0766
INFO - 2016-09-23 19:09:41 --> Config Class Initialized
INFO - 2016-09-23 19:09:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:41 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:41 --> URI Class Initialized
INFO - 2016-09-23 19:09:41 --> Router Class Initialized
INFO - 2016-09-23 19:09:41 --> Output Class Initialized
INFO - 2016-09-23 19:09:41 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:41 --> Input Class Initialized
INFO - 2016-09-23 19:09:41 --> Language Class Initialized
INFO - 2016-09-23 19:09:41 --> Loader Class Initialized
INFO - 2016-09-23 19:09:41 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:41 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:41 --> Controller Class Initialized
INFO - 2016-09-23 19:09:41 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:41 --> Model Class Initialized
INFO - 2016-09-23 19:09:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:41 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:41 --> Total execution time: 0.0606
INFO - 2016-09-23 19:09:45 --> Config Class Initialized
INFO - 2016-09-23 19:09:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:45 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:45 --> URI Class Initialized
INFO - 2016-09-23 19:09:45 --> Router Class Initialized
INFO - 2016-09-23 19:09:45 --> Output Class Initialized
INFO - 2016-09-23 19:09:45 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:45 --> Input Class Initialized
INFO - 2016-09-23 19:09:45 --> Language Class Initialized
INFO - 2016-09-23 19:09:45 --> Loader Class Initialized
INFO - 2016-09-23 19:09:45 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:45 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:45 --> Controller Class Initialized
INFO - 2016-09-23 19:09:45 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:45 --> Model Class Initialized
INFO - 2016-09-23 19:09:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:45 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:45 --> Total execution time: 0.0655
INFO - 2016-09-23 19:09:46 --> Config Class Initialized
INFO - 2016-09-23 19:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:09:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:09:46 --> Utf8 Class Initialized
INFO - 2016-09-23 19:09:46 --> URI Class Initialized
INFO - 2016-09-23 19:09:46 --> Router Class Initialized
INFO - 2016-09-23 19:09:46 --> Output Class Initialized
INFO - 2016-09-23 19:09:46 --> Security Class Initialized
DEBUG - 2016-09-23 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:09:46 --> Input Class Initialized
INFO - 2016-09-23 19:09:46 --> Language Class Initialized
INFO - 2016-09-23 19:09:46 --> Loader Class Initialized
INFO - 2016-09-23 19:09:46 --> Helper loaded: url_helper
INFO - 2016-09-23 19:09:46 --> Helper loaded: language_helper
INFO - 2016-09-23 19:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:09:46 --> Controller Class Initialized
INFO - 2016-09-23 19:09:46 --> Database Driver Class Initialized
INFO - 2016-09-23 19:09:46 --> Model Class Initialized
INFO - 2016-09-23 19:09:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:09:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:09:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:09:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:09:46 --> Final output sent to browser
DEBUG - 2016-09-23 19:09:46 --> Total execution time: 0.0740
INFO - 2016-09-23 19:10:17 --> Config Class Initialized
INFO - 2016-09-23 19:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:10:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:10:17 --> URI Class Initialized
INFO - 2016-09-23 19:10:17 --> Router Class Initialized
INFO - 2016-09-23 19:10:17 --> Output Class Initialized
INFO - 2016-09-23 19:10:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:10:17 --> Input Class Initialized
INFO - 2016-09-23 19:10:17 --> Language Class Initialized
INFO - 2016-09-23 19:10:17 --> Loader Class Initialized
INFO - 2016-09-23 19:10:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:10:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:10:17 --> Controller Class Initialized
INFO - 2016-09-23 19:10:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:10:17 --> Model Class Initialized
INFO - 2016-09-23 19:10:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:10:17 --> Config Class Initialized
INFO - 2016-09-23 19:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:10:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:10:17 --> URI Class Initialized
INFO - 2016-09-23 19:10:17 --> Router Class Initialized
INFO - 2016-09-23 19:10:17 --> Output Class Initialized
INFO - 2016-09-23 19:10:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:10:17 --> Input Class Initialized
INFO - 2016-09-23 19:10:17 --> Language Class Initialized
INFO - 2016-09-23 19:10:17 --> Loader Class Initialized
INFO - 2016-09-23 19:10:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:10:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:10:17 --> Controller Class Initialized
INFO - 2016-09-23 19:10:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:10:17 --> Model Class Initialized
INFO - 2016-09-23 19:10:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:10:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:10:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:10:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:10:17 --> Final output sent to browser
DEBUG - 2016-09-23 19:10:17 --> Total execution time: 0.0603
INFO - 2016-09-23 19:11:11 --> Config Class Initialized
INFO - 2016-09-23 19:11:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:11:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:11:11 --> Utf8 Class Initialized
INFO - 2016-09-23 19:11:11 --> URI Class Initialized
INFO - 2016-09-23 19:11:11 --> Router Class Initialized
INFO - 2016-09-23 19:11:11 --> Output Class Initialized
INFO - 2016-09-23 19:11:11 --> Security Class Initialized
DEBUG - 2016-09-23 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:11:11 --> Input Class Initialized
INFO - 2016-09-23 19:11:11 --> Language Class Initialized
INFO - 2016-09-23 19:11:11 --> Loader Class Initialized
INFO - 2016-09-23 19:11:11 --> Helper loaded: url_helper
INFO - 2016-09-23 19:11:11 --> Helper loaded: language_helper
INFO - 2016-09-23 19:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:11:11 --> Controller Class Initialized
INFO - 2016-09-23 19:11:11 --> Database Driver Class Initialized
INFO - 2016-09-23 19:11:11 --> Model Class Initialized
INFO - 2016-09-23 19:11:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:11:11 --> Config Class Initialized
INFO - 2016-09-23 19:11:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:11:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:11:11 --> Utf8 Class Initialized
INFO - 2016-09-23 19:11:11 --> URI Class Initialized
INFO - 2016-09-23 19:11:11 --> Router Class Initialized
INFO - 2016-09-23 19:11:11 --> Output Class Initialized
INFO - 2016-09-23 19:11:11 --> Security Class Initialized
DEBUG - 2016-09-23 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:11:11 --> Input Class Initialized
INFO - 2016-09-23 19:11:11 --> Language Class Initialized
INFO - 2016-09-23 19:11:11 --> Loader Class Initialized
INFO - 2016-09-23 19:11:11 --> Helper loaded: url_helper
INFO - 2016-09-23 19:11:11 --> Helper loaded: language_helper
INFO - 2016-09-23 19:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:11:11 --> Controller Class Initialized
INFO - 2016-09-23 19:11:11 --> Database Driver Class Initialized
INFO - 2016-09-23 19:11:11 --> Model Class Initialized
INFO - 2016-09-23 19:11:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:11:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:11:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:11:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:11:11 --> Final output sent to browser
DEBUG - 2016-09-23 19:11:11 --> Total execution time: 0.0716
INFO - 2016-09-23 19:11:48 --> Config Class Initialized
INFO - 2016-09-23 19:11:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:11:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:11:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:11:48 --> URI Class Initialized
INFO - 2016-09-23 19:11:48 --> Router Class Initialized
INFO - 2016-09-23 19:11:48 --> Output Class Initialized
INFO - 2016-09-23 19:11:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:11:48 --> Input Class Initialized
INFO - 2016-09-23 19:11:48 --> Language Class Initialized
INFO - 2016-09-23 19:11:48 --> Loader Class Initialized
INFO - 2016-09-23 19:11:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:11:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:11:48 --> Controller Class Initialized
INFO - 2016-09-23 19:11:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:11:48 --> Model Class Initialized
INFO - 2016-09-23 19:11:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:11:48 --> Config Class Initialized
INFO - 2016-09-23 19:11:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:11:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:11:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:11:48 --> URI Class Initialized
INFO - 2016-09-23 19:11:48 --> Router Class Initialized
INFO - 2016-09-23 19:11:48 --> Output Class Initialized
INFO - 2016-09-23 19:11:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:11:48 --> Input Class Initialized
INFO - 2016-09-23 19:11:48 --> Language Class Initialized
INFO - 2016-09-23 19:11:48 --> Loader Class Initialized
INFO - 2016-09-23 19:11:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:11:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:11:48 --> Controller Class Initialized
INFO - 2016-09-23 19:11:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:11:48 --> Model Class Initialized
INFO - 2016-09-23 19:11:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:11:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:11:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:11:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:11:48 --> Final output sent to browser
DEBUG - 2016-09-23 19:11:48 --> Total execution time: 0.0612
INFO - 2016-09-23 19:12:18 --> Config Class Initialized
INFO - 2016-09-23 19:12:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:12:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:12:18 --> Utf8 Class Initialized
INFO - 2016-09-23 19:12:18 --> URI Class Initialized
INFO - 2016-09-23 19:12:18 --> Router Class Initialized
INFO - 2016-09-23 19:12:18 --> Output Class Initialized
INFO - 2016-09-23 19:12:18 --> Security Class Initialized
DEBUG - 2016-09-23 19:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:12:18 --> Input Class Initialized
INFO - 2016-09-23 19:12:18 --> Language Class Initialized
INFO - 2016-09-23 19:12:18 --> Loader Class Initialized
INFO - 2016-09-23 19:12:18 --> Helper loaded: url_helper
INFO - 2016-09-23 19:12:18 --> Helper loaded: language_helper
INFO - 2016-09-23 19:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:12:18 --> Controller Class Initialized
INFO - 2016-09-23 19:12:18 --> Database Driver Class Initialized
INFO - 2016-09-23 19:12:18 --> Model Class Initialized
INFO - 2016-09-23 19:12:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:12:18 --> Config Class Initialized
INFO - 2016-09-23 19:12:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:12:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:12:18 --> Utf8 Class Initialized
INFO - 2016-09-23 19:12:18 --> URI Class Initialized
INFO - 2016-09-23 19:12:18 --> Router Class Initialized
INFO - 2016-09-23 19:12:18 --> Output Class Initialized
INFO - 2016-09-23 19:12:18 --> Security Class Initialized
DEBUG - 2016-09-23 19:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:12:18 --> Input Class Initialized
INFO - 2016-09-23 19:12:18 --> Language Class Initialized
INFO - 2016-09-23 19:12:18 --> Loader Class Initialized
INFO - 2016-09-23 19:12:18 --> Helper loaded: url_helper
INFO - 2016-09-23 19:12:18 --> Helper loaded: language_helper
INFO - 2016-09-23 19:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:12:18 --> Controller Class Initialized
INFO - 2016-09-23 19:12:18 --> Database Driver Class Initialized
INFO - 2016-09-23 19:12:18 --> Model Class Initialized
INFO - 2016-09-23 19:12:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:12:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:12:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:12:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:12:18 --> Final output sent to browser
DEBUG - 2016-09-23 19:12:18 --> Total execution time: 0.0584
INFO - 2016-09-23 19:12:41 --> Config Class Initialized
INFO - 2016-09-23 19:12:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:12:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:12:41 --> Utf8 Class Initialized
INFO - 2016-09-23 19:12:41 --> URI Class Initialized
INFO - 2016-09-23 19:12:41 --> Router Class Initialized
INFO - 2016-09-23 19:12:41 --> Output Class Initialized
INFO - 2016-09-23 19:12:41 --> Security Class Initialized
DEBUG - 2016-09-23 19:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:12:41 --> Input Class Initialized
INFO - 2016-09-23 19:12:41 --> Language Class Initialized
INFO - 2016-09-23 19:12:41 --> Loader Class Initialized
INFO - 2016-09-23 19:12:41 --> Helper loaded: url_helper
INFO - 2016-09-23 19:12:41 --> Helper loaded: language_helper
INFO - 2016-09-23 19:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:12:41 --> Controller Class Initialized
INFO - 2016-09-23 19:12:41 --> Database Driver Class Initialized
INFO - 2016-09-23 19:12:41 --> Model Class Initialized
INFO - 2016-09-23 19:12:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:12:41 --> Config Class Initialized
INFO - 2016-09-23 19:12:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:12:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:12:41 --> Utf8 Class Initialized
INFO - 2016-09-23 19:12:41 --> URI Class Initialized
INFO - 2016-09-23 19:12:41 --> Router Class Initialized
INFO - 2016-09-23 19:12:41 --> Output Class Initialized
INFO - 2016-09-23 19:12:41 --> Security Class Initialized
DEBUG - 2016-09-23 19:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:12:41 --> Input Class Initialized
INFO - 2016-09-23 19:12:41 --> Language Class Initialized
INFO - 2016-09-23 19:12:41 --> Loader Class Initialized
INFO - 2016-09-23 19:12:41 --> Helper loaded: url_helper
INFO - 2016-09-23 19:12:41 --> Helper loaded: language_helper
INFO - 2016-09-23 19:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:12:41 --> Controller Class Initialized
INFO - 2016-09-23 19:12:41 --> Database Driver Class Initialized
INFO - 2016-09-23 19:12:41 --> Model Class Initialized
INFO - 2016-09-23 19:12:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:12:41 --> Final output sent to browser
DEBUG - 2016-09-23 19:12:41 --> Total execution time: 0.0753
INFO - 2016-09-23 19:13:07 --> Config Class Initialized
INFO - 2016-09-23 19:13:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:13:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:13:07 --> Utf8 Class Initialized
INFO - 2016-09-23 19:13:07 --> URI Class Initialized
INFO - 2016-09-23 19:13:07 --> Router Class Initialized
INFO - 2016-09-23 19:13:07 --> Output Class Initialized
INFO - 2016-09-23 19:13:07 --> Security Class Initialized
DEBUG - 2016-09-23 19:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:13:07 --> Input Class Initialized
INFO - 2016-09-23 19:13:07 --> Language Class Initialized
INFO - 2016-09-23 19:13:07 --> Loader Class Initialized
INFO - 2016-09-23 19:13:07 --> Helper loaded: url_helper
INFO - 2016-09-23 19:13:07 --> Helper loaded: language_helper
INFO - 2016-09-23 19:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:13:07 --> Controller Class Initialized
INFO - 2016-09-23 19:13:07 --> Database Driver Class Initialized
INFO - 2016-09-23 19:13:07 --> Model Class Initialized
INFO - 2016-09-23 19:13:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:13:07 --> Config Class Initialized
INFO - 2016-09-23 19:13:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:13:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:13:07 --> Utf8 Class Initialized
INFO - 2016-09-23 19:13:07 --> URI Class Initialized
INFO - 2016-09-23 19:13:07 --> Router Class Initialized
INFO - 2016-09-23 19:13:08 --> Output Class Initialized
INFO - 2016-09-23 19:13:08 --> Security Class Initialized
DEBUG - 2016-09-23 19:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:13:08 --> Input Class Initialized
INFO - 2016-09-23 19:13:08 --> Language Class Initialized
INFO - 2016-09-23 19:13:08 --> Loader Class Initialized
INFO - 2016-09-23 19:13:08 --> Helper loaded: url_helper
INFO - 2016-09-23 19:13:08 --> Helper loaded: language_helper
INFO - 2016-09-23 19:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:13:08 --> Controller Class Initialized
INFO - 2016-09-23 19:13:08 --> Database Driver Class Initialized
INFO - 2016-09-23 19:13:08 --> Model Class Initialized
INFO - 2016-09-23 19:13:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:13:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:13:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:13:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:13:08 --> Final output sent to browser
DEBUG - 2016-09-23 19:13:08 --> Total execution time: 0.0697
INFO - 2016-09-23 19:13:44 --> Config Class Initialized
INFO - 2016-09-23 19:13:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:13:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:13:44 --> Utf8 Class Initialized
INFO - 2016-09-23 19:13:44 --> URI Class Initialized
INFO - 2016-09-23 19:13:44 --> Router Class Initialized
INFO - 2016-09-23 19:13:44 --> Output Class Initialized
INFO - 2016-09-23 19:13:44 --> Security Class Initialized
DEBUG - 2016-09-23 19:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:13:44 --> Input Class Initialized
INFO - 2016-09-23 19:13:44 --> Language Class Initialized
INFO - 2016-09-23 19:13:44 --> Loader Class Initialized
INFO - 2016-09-23 19:13:44 --> Helper loaded: url_helper
INFO - 2016-09-23 19:13:44 --> Helper loaded: language_helper
INFO - 2016-09-23 19:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:13:44 --> Controller Class Initialized
INFO - 2016-09-23 19:13:44 --> Database Driver Class Initialized
INFO - 2016-09-23 19:13:44 --> Model Class Initialized
INFO - 2016-09-23 19:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:13:44 --> Config Class Initialized
INFO - 2016-09-23 19:13:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:13:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:13:44 --> Utf8 Class Initialized
INFO - 2016-09-23 19:13:44 --> URI Class Initialized
INFO - 2016-09-23 19:13:44 --> Router Class Initialized
INFO - 2016-09-23 19:13:44 --> Output Class Initialized
INFO - 2016-09-23 19:13:44 --> Security Class Initialized
DEBUG - 2016-09-23 19:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:13:44 --> Input Class Initialized
INFO - 2016-09-23 19:13:44 --> Language Class Initialized
INFO - 2016-09-23 19:13:44 --> Loader Class Initialized
INFO - 2016-09-23 19:13:44 --> Helper loaded: url_helper
INFO - 2016-09-23 19:13:44 --> Helper loaded: language_helper
INFO - 2016-09-23 19:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:13:44 --> Controller Class Initialized
INFO - 2016-09-23 19:13:44 --> Database Driver Class Initialized
INFO - 2016-09-23 19:13:44 --> Model Class Initialized
INFO - 2016-09-23 19:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:13:44 --> Final output sent to browser
DEBUG - 2016-09-23 19:13:44 --> Total execution time: 0.0756
INFO - 2016-09-23 19:13:57 --> Config Class Initialized
INFO - 2016-09-23 19:13:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:13:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:13:57 --> Utf8 Class Initialized
INFO - 2016-09-23 19:13:57 --> URI Class Initialized
INFO - 2016-09-23 19:13:57 --> Router Class Initialized
INFO - 2016-09-23 19:13:57 --> Output Class Initialized
INFO - 2016-09-23 19:13:57 --> Security Class Initialized
DEBUG - 2016-09-23 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:13:57 --> Input Class Initialized
INFO - 2016-09-23 19:13:57 --> Language Class Initialized
INFO - 2016-09-23 19:13:57 --> Loader Class Initialized
INFO - 2016-09-23 19:13:57 --> Helper loaded: url_helper
INFO - 2016-09-23 19:13:57 --> Helper loaded: language_helper
INFO - 2016-09-23 19:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:13:57 --> Controller Class Initialized
INFO - 2016-09-23 19:13:57 --> Database Driver Class Initialized
INFO - 2016-09-23 19:13:57 --> Model Class Initialized
INFO - 2016-09-23 19:13:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:13:57 --> Config Class Initialized
INFO - 2016-09-23 19:13:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:13:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:13:57 --> Utf8 Class Initialized
INFO - 2016-09-23 19:13:57 --> URI Class Initialized
INFO - 2016-09-23 19:13:57 --> Router Class Initialized
INFO - 2016-09-23 19:13:57 --> Output Class Initialized
INFO - 2016-09-23 19:13:57 --> Security Class Initialized
DEBUG - 2016-09-23 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:13:57 --> Input Class Initialized
INFO - 2016-09-23 19:13:57 --> Language Class Initialized
INFO - 2016-09-23 19:13:57 --> Loader Class Initialized
INFO - 2016-09-23 19:13:57 --> Helper loaded: url_helper
INFO - 2016-09-23 19:13:57 --> Helper loaded: language_helper
INFO - 2016-09-23 19:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:13:57 --> Controller Class Initialized
INFO - 2016-09-23 19:13:57 --> Database Driver Class Initialized
INFO - 2016-09-23 19:13:57 --> Model Class Initialized
INFO - 2016-09-23 19:13:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:13:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:13:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:13:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:13:57 --> Final output sent to browser
DEBUG - 2016-09-23 19:13:57 --> Total execution time: 0.0608
INFO - 2016-09-23 19:14:29 --> Config Class Initialized
INFO - 2016-09-23 19:14:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:14:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:14:29 --> Utf8 Class Initialized
INFO - 2016-09-23 19:14:29 --> URI Class Initialized
INFO - 2016-09-23 19:14:29 --> Router Class Initialized
INFO - 2016-09-23 19:14:29 --> Output Class Initialized
INFO - 2016-09-23 19:14:29 --> Security Class Initialized
DEBUG - 2016-09-23 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:14:29 --> Input Class Initialized
INFO - 2016-09-23 19:14:29 --> Language Class Initialized
INFO - 2016-09-23 19:14:29 --> Loader Class Initialized
INFO - 2016-09-23 19:14:29 --> Helper loaded: url_helper
INFO - 2016-09-23 19:14:29 --> Helper loaded: language_helper
INFO - 2016-09-23 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:14:29 --> Controller Class Initialized
INFO - 2016-09-23 19:14:29 --> Database Driver Class Initialized
INFO - 2016-09-23 19:14:29 --> Model Class Initialized
INFO - 2016-09-23 19:14:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:14:29 --> Config Class Initialized
INFO - 2016-09-23 19:14:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:14:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:14:29 --> Utf8 Class Initialized
INFO - 2016-09-23 19:14:29 --> URI Class Initialized
INFO - 2016-09-23 19:14:29 --> Router Class Initialized
INFO - 2016-09-23 19:14:29 --> Output Class Initialized
INFO - 2016-09-23 19:14:29 --> Security Class Initialized
DEBUG - 2016-09-23 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:14:29 --> Input Class Initialized
INFO - 2016-09-23 19:14:29 --> Language Class Initialized
INFO - 2016-09-23 19:14:29 --> Loader Class Initialized
INFO - 2016-09-23 19:14:29 --> Helper loaded: url_helper
INFO - 2016-09-23 19:14:29 --> Helper loaded: language_helper
INFO - 2016-09-23 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:14:29 --> Controller Class Initialized
INFO - 2016-09-23 19:14:29 --> Database Driver Class Initialized
INFO - 2016-09-23 19:14:29 --> Model Class Initialized
INFO - 2016-09-23 19:14:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:14:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:14:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:14:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:14:29 --> Final output sent to browser
DEBUG - 2016-09-23 19:14:29 --> Total execution time: 0.0617
INFO - 2016-09-23 19:14:48 --> Config Class Initialized
INFO - 2016-09-23 19:14:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:14:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:14:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:14:48 --> URI Class Initialized
INFO - 2016-09-23 19:14:48 --> Router Class Initialized
INFO - 2016-09-23 19:14:48 --> Output Class Initialized
INFO - 2016-09-23 19:14:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:14:48 --> Input Class Initialized
INFO - 2016-09-23 19:14:48 --> Language Class Initialized
INFO - 2016-09-23 19:14:48 --> Loader Class Initialized
INFO - 2016-09-23 19:14:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:14:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:14:48 --> Controller Class Initialized
INFO - 2016-09-23 19:14:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:14:48 --> Model Class Initialized
INFO - 2016-09-23 19:14:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:14:48 --> Config Class Initialized
INFO - 2016-09-23 19:14:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:14:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:14:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:14:48 --> URI Class Initialized
INFO - 2016-09-23 19:14:48 --> Router Class Initialized
INFO - 2016-09-23 19:14:48 --> Output Class Initialized
INFO - 2016-09-23 19:14:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:14:48 --> Input Class Initialized
INFO - 2016-09-23 19:14:48 --> Language Class Initialized
INFO - 2016-09-23 19:14:48 --> Loader Class Initialized
INFO - 2016-09-23 19:14:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:14:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:14:48 --> Controller Class Initialized
INFO - 2016-09-23 19:14:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:14:48 --> Model Class Initialized
INFO - 2016-09-23 19:14:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:14:48 --> Final output sent to browser
DEBUG - 2016-09-23 19:14:48 --> Total execution time: 0.0629
INFO - 2016-09-23 19:15:11 --> Config Class Initialized
INFO - 2016-09-23 19:15:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:15:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:15:11 --> Utf8 Class Initialized
INFO - 2016-09-23 19:15:11 --> URI Class Initialized
INFO - 2016-09-23 19:15:11 --> Router Class Initialized
INFO - 2016-09-23 19:15:11 --> Output Class Initialized
INFO - 2016-09-23 19:15:11 --> Security Class Initialized
DEBUG - 2016-09-23 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:15:11 --> Input Class Initialized
INFO - 2016-09-23 19:15:11 --> Language Class Initialized
INFO - 2016-09-23 19:15:11 --> Loader Class Initialized
INFO - 2016-09-23 19:15:11 --> Helper loaded: url_helper
INFO - 2016-09-23 19:15:11 --> Helper loaded: language_helper
INFO - 2016-09-23 19:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:15:11 --> Controller Class Initialized
INFO - 2016-09-23 19:15:11 --> Database Driver Class Initialized
INFO - 2016-09-23 19:15:11 --> Model Class Initialized
INFO - 2016-09-23 19:15:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:15:11 --> Config Class Initialized
INFO - 2016-09-23 19:15:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:15:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:15:11 --> Utf8 Class Initialized
INFO - 2016-09-23 19:15:11 --> URI Class Initialized
INFO - 2016-09-23 19:15:11 --> Router Class Initialized
INFO - 2016-09-23 19:15:11 --> Output Class Initialized
INFO - 2016-09-23 19:15:11 --> Security Class Initialized
DEBUG - 2016-09-23 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:15:11 --> Input Class Initialized
INFO - 2016-09-23 19:15:11 --> Language Class Initialized
INFO - 2016-09-23 19:15:11 --> Loader Class Initialized
INFO - 2016-09-23 19:15:11 --> Helper loaded: url_helper
INFO - 2016-09-23 19:15:11 --> Helper loaded: language_helper
INFO - 2016-09-23 19:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:15:11 --> Controller Class Initialized
INFO - 2016-09-23 19:15:11 --> Database Driver Class Initialized
INFO - 2016-09-23 19:15:11 --> Model Class Initialized
INFO - 2016-09-23 19:15:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:15:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:15:11 --> Final output sent to browser
DEBUG - 2016-09-23 19:15:11 --> Total execution time: 0.0641
INFO - 2016-09-23 19:15:28 --> Config Class Initialized
INFO - 2016-09-23 19:15:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:15:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:15:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:15:28 --> URI Class Initialized
INFO - 2016-09-23 19:15:28 --> Router Class Initialized
INFO - 2016-09-23 19:15:28 --> Output Class Initialized
INFO - 2016-09-23 19:15:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:15:28 --> Input Class Initialized
INFO - 2016-09-23 19:15:28 --> Language Class Initialized
INFO - 2016-09-23 19:15:28 --> Loader Class Initialized
INFO - 2016-09-23 19:15:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:15:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:15:28 --> Controller Class Initialized
INFO - 2016-09-23 19:15:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:15:28 --> Model Class Initialized
INFO - 2016-09-23 19:15:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:15:28 --> Config Class Initialized
INFO - 2016-09-23 19:15:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:15:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:15:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:15:28 --> URI Class Initialized
INFO - 2016-09-23 19:15:28 --> Router Class Initialized
INFO - 2016-09-23 19:15:28 --> Output Class Initialized
INFO - 2016-09-23 19:15:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:15:28 --> Input Class Initialized
INFO - 2016-09-23 19:15:28 --> Language Class Initialized
INFO - 2016-09-23 19:15:28 --> Loader Class Initialized
INFO - 2016-09-23 19:15:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:15:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:15:28 --> Controller Class Initialized
INFO - 2016-09-23 19:15:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:15:28 --> Model Class Initialized
INFO - 2016-09-23 19:15:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:15:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:15:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:15:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:15:28 --> Final output sent to browser
DEBUG - 2016-09-23 19:15:28 --> Total execution time: 0.0621
INFO - 2016-09-23 19:15:49 --> Config Class Initialized
INFO - 2016-09-23 19:15:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:15:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:15:49 --> Utf8 Class Initialized
INFO - 2016-09-23 19:15:49 --> URI Class Initialized
INFO - 2016-09-23 19:15:49 --> Router Class Initialized
INFO - 2016-09-23 19:15:49 --> Output Class Initialized
INFO - 2016-09-23 19:15:49 --> Security Class Initialized
DEBUG - 2016-09-23 19:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:15:49 --> Input Class Initialized
INFO - 2016-09-23 19:15:49 --> Language Class Initialized
INFO - 2016-09-23 19:15:49 --> Loader Class Initialized
INFO - 2016-09-23 19:15:49 --> Helper loaded: url_helper
INFO - 2016-09-23 19:15:49 --> Helper loaded: language_helper
INFO - 2016-09-23 19:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:15:49 --> Controller Class Initialized
INFO - 2016-09-23 19:15:49 --> Database Driver Class Initialized
INFO - 2016-09-23 19:15:49 --> Model Class Initialized
INFO - 2016-09-23 19:15:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:15:49 --> Config Class Initialized
INFO - 2016-09-23 19:15:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:15:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:15:49 --> Utf8 Class Initialized
INFO - 2016-09-23 19:15:49 --> URI Class Initialized
INFO - 2016-09-23 19:15:49 --> Router Class Initialized
INFO - 2016-09-23 19:15:49 --> Output Class Initialized
INFO - 2016-09-23 19:15:49 --> Security Class Initialized
DEBUG - 2016-09-23 19:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:15:49 --> Input Class Initialized
INFO - 2016-09-23 19:15:49 --> Language Class Initialized
INFO - 2016-09-23 19:15:49 --> Loader Class Initialized
INFO - 2016-09-23 19:15:49 --> Helper loaded: url_helper
INFO - 2016-09-23 19:15:49 --> Helper loaded: language_helper
INFO - 2016-09-23 19:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:15:49 --> Controller Class Initialized
INFO - 2016-09-23 19:15:49 --> Database Driver Class Initialized
INFO - 2016-09-23 19:15:49 --> Model Class Initialized
INFO - 2016-09-23 19:15:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:15:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:15:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:15:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:15:49 --> Final output sent to browser
DEBUG - 2016-09-23 19:15:49 --> Total execution time: 0.0602
INFO - 2016-09-23 19:16:06 --> Config Class Initialized
INFO - 2016-09-23 19:16:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:06 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:06 --> URI Class Initialized
INFO - 2016-09-23 19:16:06 --> Router Class Initialized
INFO - 2016-09-23 19:16:06 --> Output Class Initialized
INFO - 2016-09-23 19:16:06 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:06 --> Input Class Initialized
INFO - 2016-09-23 19:16:06 --> Language Class Initialized
INFO - 2016-09-23 19:16:06 --> Loader Class Initialized
INFO - 2016-09-23 19:16:06 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:06 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:06 --> Controller Class Initialized
INFO - 2016-09-23 19:16:06 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:06 --> Model Class Initialized
INFO - 2016-09-23 19:16:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:06 --> Config Class Initialized
INFO - 2016-09-23 19:16:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:06 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:06 --> URI Class Initialized
INFO - 2016-09-23 19:16:06 --> Router Class Initialized
INFO - 2016-09-23 19:16:06 --> Output Class Initialized
INFO - 2016-09-23 19:16:06 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:06 --> Input Class Initialized
INFO - 2016-09-23 19:16:06 --> Language Class Initialized
INFO - 2016-09-23 19:16:06 --> Loader Class Initialized
INFO - 2016-09-23 19:16:06 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:06 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:06 --> Controller Class Initialized
INFO - 2016-09-23 19:16:06 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:06 --> Model Class Initialized
INFO - 2016-09-23 19:16:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:16:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:06 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:06 --> Total execution time: 0.0770
INFO - 2016-09-23 19:16:28 --> Config Class Initialized
INFO - 2016-09-23 19:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:28 --> URI Class Initialized
INFO - 2016-09-23 19:16:28 --> Router Class Initialized
INFO - 2016-09-23 19:16:28 --> Output Class Initialized
INFO - 2016-09-23 19:16:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:28 --> Input Class Initialized
INFO - 2016-09-23 19:16:28 --> Language Class Initialized
INFO - 2016-09-23 19:16:28 --> Loader Class Initialized
INFO - 2016-09-23 19:16:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:28 --> Controller Class Initialized
INFO - 2016-09-23 19:16:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:28 --> Model Class Initialized
INFO - 2016-09-23 19:16:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:28 --> Config Class Initialized
INFO - 2016-09-23 19:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:28 --> URI Class Initialized
INFO - 2016-09-23 19:16:28 --> Router Class Initialized
INFO - 2016-09-23 19:16:28 --> Output Class Initialized
INFO - 2016-09-23 19:16:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:28 --> Input Class Initialized
INFO - 2016-09-23 19:16:28 --> Language Class Initialized
INFO - 2016-09-23 19:16:28 --> Loader Class Initialized
INFO - 2016-09-23 19:16:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:28 --> Controller Class Initialized
INFO - 2016-09-23 19:16:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:28 --> Model Class Initialized
INFO - 2016-09-23 19:16:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:16:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:28 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:28 --> Total execution time: 0.0632
INFO - 2016-09-23 19:16:33 --> Config Class Initialized
INFO - 2016-09-23 19:16:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:33 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:33 --> URI Class Initialized
INFO - 2016-09-23 19:16:33 --> Router Class Initialized
INFO - 2016-09-23 19:16:33 --> Output Class Initialized
INFO - 2016-09-23 19:16:33 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:33 --> Input Class Initialized
INFO - 2016-09-23 19:16:33 --> Language Class Initialized
INFO - 2016-09-23 19:16:33 --> Loader Class Initialized
INFO - 2016-09-23 19:16:33 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:33 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:33 --> Controller Class Initialized
INFO - 2016-09-23 19:16:33 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:33 --> Model Class Initialized
INFO - 2016-09-23 19:16:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_4.php
INFO - 2016-09-23 19:16:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:33 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:33 --> Total execution time: 0.0703
INFO - 2016-09-23 19:16:53 --> Config Class Initialized
INFO - 2016-09-23 19:16:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:53 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:53 --> URI Class Initialized
INFO - 2016-09-23 19:16:53 --> Router Class Initialized
INFO - 2016-09-23 19:16:53 --> Output Class Initialized
INFO - 2016-09-23 19:16:53 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:53 --> Input Class Initialized
INFO - 2016-09-23 19:16:53 --> Language Class Initialized
INFO - 2016-09-23 19:16:53 --> Loader Class Initialized
INFO - 2016-09-23 19:16:53 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:53 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:53 --> Controller Class Initialized
INFO - 2016-09-23 19:16:53 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:53 --> Model Class Initialized
INFO - 2016-09-23 19:16:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:53 --> Config Class Initialized
INFO - 2016-09-23 19:16:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:53 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:53 --> URI Class Initialized
INFO - 2016-09-23 19:16:53 --> Router Class Initialized
INFO - 2016-09-23 19:16:53 --> Output Class Initialized
INFO - 2016-09-23 19:16:53 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:53 --> Input Class Initialized
INFO - 2016-09-23 19:16:53 --> Language Class Initialized
INFO - 2016-09-23 19:16:53 --> Loader Class Initialized
INFO - 2016-09-23 19:16:53 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:53 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:53 --> Controller Class Initialized
INFO - 2016-09-23 19:16:53 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:53 --> Model Class Initialized
INFO - 2016-09-23 19:16:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:53 --> Helper loaded: form_helper
INFO - 2016-09-23 19:16:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 19:16:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:53 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:53 --> Total execution time: 0.0632
INFO - 2016-09-23 19:16:56 --> Config Class Initialized
INFO - 2016-09-23 19:16:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:56 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:56 --> URI Class Initialized
INFO - 2016-09-23 19:16:56 --> Router Class Initialized
INFO - 2016-09-23 19:16:56 --> Output Class Initialized
INFO - 2016-09-23 19:16:56 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:56 --> Input Class Initialized
INFO - 2016-09-23 19:16:56 --> Language Class Initialized
INFO - 2016-09-23 19:16:56 --> Loader Class Initialized
INFO - 2016-09-23 19:16:56 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:56 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:56 --> Controller Class Initialized
INFO - 2016-09-23 19:16:56 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:56 --> Model Class Initialized
INFO - 2016-09-23 19:16:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:16:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:56 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:56 --> Total execution time: 0.0652
INFO - 2016-09-23 19:16:58 --> Config Class Initialized
INFO - 2016-09-23 19:16:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:58 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:58 --> URI Class Initialized
INFO - 2016-09-23 19:16:58 --> Router Class Initialized
INFO - 2016-09-23 19:16:58 --> Output Class Initialized
INFO - 2016-09-23 19:16:58 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:58 --> Input Class Initialized
INFO - 2016-09-23 19:16:58 --> Language Class Initialized
INFO - 2016-09-23 19:16:58 --> Loader Class Initialized
INFO - 2016-09-23 19:16:58 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:58 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:58 --> Controller Class Initialized
INFO - 2016-09-23 19:16:58 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:58 --> Model Class Initialized
INFO - 2016-09-23 19:16:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:16:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:58 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:58 --> Total execution time: 0.0817
INFO - 2016-09-23 19:16:59 --> Config Class Initialized
INFO - 2016-09-23 19:16:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:16:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:16:59 --> Utf8 Class Initialized
INFO - 2016-09-23 19:16:59 --> URI Class Initialized
INFO - 2016-09-23 19:16:59 --> Router Class Initialized
INFO - 2016-09-23 19:16:59 --> Output Class Initialized
INFO - 2016-09-23 19:16:59 --> Security Class Initialized
DEBUG - 2016-09-23 19:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:16:59 --> Input Class Initialized
INFO - 2016-09-23 19:16:59 --> Language Class Initialized
INFO - 2016-09-23 19:16:59 --> Loader Class Initialized
INFO - 2016-09-23 19:16:59 --> Helper loaded: url_helper
INFO - 2016-09-23 19:16:59 --> Helper loaded: language_helper
INFO - 2016-09-23 19:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:16:59 --> Controller Class Initialized
INFO - 2016-09-23 19:16:59 --> Database Driver Class Initialized
INFO - 2016-09-23 19:16:59 --> Model Class Initialized
INFO - 2016-09-23 19:16:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:16:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:16:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:16:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:16:59 --> Final output sent to browser
DEBUG - 2016-09-23 19:16:59 --> Total execution time: 0.0795
INFO - 2016-09-23 19:17:01 --> Config Class Initialized
INFO - 2016-09-23 19:17:01 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:01 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:01 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:01 --> URI Class Initialized
INFO - 2016-09-23 19:17:01 --> Router Class Initialized
INFO - 2016-09-23 19:17:01 --> Output Class Initialized
INFO - 2016-09-23 19:17:01 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:01 --> Input Class Initialized
INFO - 2016-09-23 19:17:01 --> Language Class Initialized
INFO - 2016-09-23 19:17:01 --> Loader Class Initialized
INFO - 2016-09-23 19:17:01 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:01 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:01 --> Controller Class Initialized
INFO - 2016-09-23 19:17:01 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:01 --> Model Class Initialized
INFO - 2016-09-23 19:17:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:17:01 --> Final output sent to browser
DEBUG - 2016-09-23 19:17:01 --> Total execution time: 0.0756
INFO - 2016-09-23 19:17:03 --> Config Class Initialized
INFO - 2016-09-23 19:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:03 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:03 --> URI Class Initialized
INFO - 2016-09-23 19:17:03 --> Router Class Initialized
INFO - 2016-09-23 19:17:03 --> Output Class Initialized
INFO - 2016-09-23 19:17:03 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:03 --> Input Class Initialized
INFO - 2016-09-23 19:17:03 --> Language Class Initialized
INFO - 2016-09-23 19:17:03 --> Loader Class Initialized
INFO - 2016-09-23 19:17:03 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:03 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:03 --> Controller Class Initialized
INFO - 2016-09-23 19:17:03 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:03 --> Model Class Initialized
INFO - 2016-09-23 19:17:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:17:03 --> Final output sent to browser
DEBUG - 2016-09-23 19:17:03 --> Total execution time: 0.0762
INFO - 2016-09-23 19:17:22 --> Config Class Initialized
INFO - 2016-09-23 19:17:22 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:22 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:22 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:22 --> URI Class Initialized
INFO - 2016-09-23 19:17:22 --> Router Class Initialized
INFO - 2016-09-23 19:17:22 --> Output Class Initialized
INFO - 2016-09-23 19:17:22 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:22 --> Input Class Initialized
INFO - 2016-09-23 19:17:22 --> Language Class Initialized
INFO - 2016-09-23 19:17:22 --> Loader Class Initialized
INFO - 2016-09-23 19:17:22 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:22 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:22 --> Controller Class Initialized
INFO - 2016-09-23 19:17:22 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:22 --> Model Class Initialized
INFO - 2016-09-23 19:17:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:22 --> Config Class Initialized
INFO - 2016-09-23 19:17:22 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:22 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:22 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:22 --> URI Class Initialized
INFO - 2016-09-23 19:17:22 --> Router Class Initialized
INFO - 2016-09-23 19:17:22 --> Output Class Initialized
INFO - 2016-09-23 19:17:22 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:22 --> Input Class Initialized
INFO - 2016-09-23 19:17:22 --> Language Class Initialized
INFO - 2016-09-23 19:17:22 --> Loader Class Initialized
INFO - 2016-09-23 19:17:22 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:22 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:22 --> Controller Class Initialized
INFO - 2016-09-23 19:17:22 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:22 --> Model Class Initialized
INFO - 2016-09-23 19:17:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:17:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:17:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:17:22 --> Final output sent to browser
DEBUG - 2016-09-23 19:17:22 --> Total execution time: 0.0639
INFO - 2016-09-23 19:17:37 --> Config Class Initialized
INFO - 2016-09-23 19:17:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:37 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:37 --> URI Class Initialized
INFO - 2016-09-23 19:17:37 --> Router Class Initialized
INFO - 2016-09-23 19:17:37 --> Output Class Initialized
INFO - 2016-09-23 19:17:37 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:37 --> Input Class Initialized
INFO - 2016-09-23 19:17:37 --> Language Class Initialized
INFO - 2016-09-23 19:17:37 --> Loader Class Initialized
INFO - 2016-09-23 19:17:37 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:37 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:37 --> Controller Class Initialized
INFO - 2016-09-23 19:17:37 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:37 --> Model Class Initialized
INFO - 2016-09-23 19:17:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:37 --> Config Class Initialized
INFO - 2016-09-23 19:17:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:37 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:37 --> URI Class Initialized
INFO - 2016-09-23 19:17:37 --> Router Class Initialized
INFO - 2016-09-23 19:17:37 --> Output Class Initialized
INFO - 2016-09-23 19:17:37 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:37 --> Input Class Initialized
INFO - 2016-09-23 19:17:37 --> Language Class Initialized
INFO - 2016-09-23 19:17:37 --> Loader Class Initialized
INFO - 2016-09-23 19:17:37 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:37 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:37 --> Controller Class Initialized
INFO - 2016-09-23 19:17:37 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:37 --> Model Class Initialized
INFO - 2016-09-23 19:17:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:17:37 --> Final output sent to browser
DEBUG - 2016-09-23 19:17:37 --> Total execution time: 0.0594
INFO - 2016-09-23 19:17:50 --> Config Class Initialized
INFO - 2016-09-23 19:17:50 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:50 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:50 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:50 --> URI Class Initialized
INFO - 2016-09-23 19:17:50 --> Router Class Initialized
INFO - 2016-09-23 19:17:50 --> Output Class Initialized
INFO - 2016-09-23 19:17:50 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:50 --> Input Class Initialized
INFO - 2016-09-23 19:17:50 --> Language Class Initialized
INFO - 2016-09-23 19:17:50 --> Loader Class Initialized
INFO - 2016-09-23 19:17:50 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:50 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:50 --> Controller Class Initialized
INFO - 2016-09-23 19:17:50 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:50 --> Model Class Initialized
INFO - 2016-09-23 19:17:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:50 --> Config Class Initialized
INFO - 2016-09-23 19:17:50 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:17:50 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:17:50 --> Utf8 Class Initialized
INFO - 2016-09-23 19:17:50 --> URI Class Initialized
INFO - 2016-09-23 19:17:50 --> Router Class Initialized
INFO - 2016-09-23 19:17:50 --> Output Class Initialized
INFO - 2016-09-23 19:17:50 --> Security Class Initialized
DEBUG - 2016-09-23 19:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:17:50 --> Input Class Initialized
INFO - 2016-09-23 19:17:50 --> Language Class Initialized
INFO - 2016-09-23 19:17:50 --> Loader Class Initialized
INFO - 2016-09-23 19:17:50 --> Helper loaded: url_helper
INFO - 2016-09-23 19:17:50 --> Helper loaded: language_helper
INFO - 2016-09-23 19:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:17:50 --> Controller Class Initialized
INFO - 2016-09-23 19:17:50 --> Database Driver Class Initialized
INFO - 2016-09-23 19:17:50 --> Model Class Initialized
INFO - 2016-09-23 19:17:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:17:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:17:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:17:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:17:50 --> Final output sent to browser
DEBUG - 2016-09-23 19:17:50 --> Total execution time: 0.0614
INFO - 2016-09-23 19:18:06 --> Config Class Initialized
INFO - 2016-09-23 19:18:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:06 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:06 --> URI Class Initialized
INFO - 2016-09-23 19:18:06 --> Router Class Initialized
INFO - 2016-09-23 19:18:06 --> Output Class Initialized
INFO - 2016-09-23 19:18:06 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:06 --> Input Class Initialized
INFO - 2016-09-23 19:18:06 --> Language Class Initialized
INFO - 2016-09-23 19:18:06 --> Loader Class Initialized
INFO - 2016-09-23 19:18:06 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:06 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:07 --> Controller Class Initialized
INFO - 2016-09-23 19:18:07 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:07 --> Model Class Initialized
INFO - 2016-09-23 19:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:07 --> Config Class Initialized
INFO - 2016-09-23 19:18:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:07 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:07 --> URI Class Initialized
INFO - 2016-09-23 19:18:07 --> Router Class Initialized
INFO - 2016-09-23 19:18:07 --> Output Class Initialized
INFO - 2016-09-23 19:18:07 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:07 --> Input Class Initialized
INFO - 2016-09-23 19:18:07 --> Language Class Initialized
INFO - 2016-09-23 19:18:07 --> Loader Class Initialized
INFO - 2016-09-23 19:18:07 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:07 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:07 --> Controller Class Initialized
INFO - 2016-09-23 19:18:07 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:07 --> Model Class Initialized
INFO - 2016-09-23 19:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:07 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:07 --> Total execution time: 0.0661
INFO - 2016-09-23 19:18:17 --> Config Class Initialized
INFO - 2016-09-23 19:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:17 --> URI Class Initialized
INFO - 2016-09-23 19:18:17 --> Router Class Initialized
INFO - 2016-09-23 19:18:17 --> Output Class Initialized
INFO - 2016-09-23 19:18:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:17 --> Input Class Initialized
INFO - 2016-09-23 19:18:17 --> Language Class Initialized
INFO - 2016-09-23 19:18:17 --> Loader Class Initialized
INFO - 2016-09-23 19:18:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:17 --> Controller Class Initialized
INFO - 2016-09-23 19:18:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:17 --> Model Class Initialized
INFO - 2016-09-23 19:18:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:17 --> Config Class Initialized
INFO - 2016-09-23 19:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:17 --> URI Class Initialized
INFO - 2016-09-23 19:18:17 --> Router Class Initialized
INFO - 2016-09-23 19:18:17 --> Output Class Initialized
INFO - 2016-09-23 19:18:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:17 --> Input Class Initialized
INFO - 2016-09-23 19:18:17 --> Language Class Initialized
INFO - 2016-09-23 19:18:17 --> Loader Class Initialized
INFO - 2016-09-23 19:18:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:17 --> Controller Class Initialized
INFO - 2016-09-23 19:18:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:17 --> Model Class Initialized
INFO - 2016-09-23 19:18:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:17 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:17 --> Total execution time: 0.0621
INFO - 2016-09-23 19:18:24 --> Config Class Initialized
INFO - 2016-09-23 19:18:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:24 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:24 --> URI Class Initialized
INFO - 2016-09-23 19:18:24 --> Router Class Initialized
INFO - 2016-09-23 19:18:24 --> Output Class Initialized
INFO - 2016-09-23 19:18:24 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:24 --> Input Class Initialized
INFO - 2016-09-23 19:18:24 --> Language Class Initialized
INFO - 2016-09-23 19:18:24 --> Loader Class Initialized
INFO - 2016-09-23 19:18:24 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:24 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:24 --> Controller Class Initialized
INFO - 2016-09-23 19:18:24 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:24 --> Model Class Initialized
INFO - 2016-09-23 19:18:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:24 --> Config Class Initialized
INFO - 2016-09-23 19:18:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:24 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:24 --> URI Class Initialized
INFO - 2016-09-23 19:18:24 --> Router Class Initialized
INFO - 2016-09-23 19:18:24 --> Output Class Initialized
INFO - 2016-09-23 19:18:24 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:24 --> Input Class Initialized
INFO - 2016-09-23 19:18:24 --> Language Class Initialized
INFO - 2016-09-23 19:18:24 --> Loader Class Initialized
INFO - 2016-09-23 19:18:24 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:24 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:24 --> Controller Class Initialized
INFO - 2016-09-23 19:18:24 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:24 --> Model Class Initialized
INFO - 2016-09-23 19:18:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:24 --> Helper loaded: form_helper
INFO - 2016-09-23 19:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 19:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:24 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:24 --> Total execution time: 0.0617
INFO - 2016-09-23 19:18:28 --> Config Class Initialized
INFO - 2016-09-23 19:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:28 --> URI Class Initialized
INFO - 2016-09-23 19:18:28 --> Router Class Initialized
INFO - 2016-09-23 19:18:28 --> Output Class Initialized
INFO - 2016-09-23 19:18:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:28 --> Input Class Initialized
INFO - 2016-09-23 19:18:28 --> Language Class Initialized
INFO - 2016-09-23 19:18:28 --> Loader Class Initialized
INFO - 2016-09-23 19:18:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:28 --> Controller Class Initialized
INFO - 2016-09-23 19:18:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:28 --> Model Class Initialized
INFO - 2016-09-23 19:18:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:28 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:28 --> Total execution time: 0.0621
INFO - 2016-09-23 19:18:29 --> Config Class Initialized
INFO - 2016-09-23 19:18:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:29 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:29 --> URI Class Initialized
INFO - 2016-09-23 19:18:29 --> Router Class Initialized
INFO - 2016-09-23 19:18:29 --> Output Class Initialized
INFO - 2016-09-23 19:18:29 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:29 --> Input Class Initialized
INFO - 2016-09-23 19:18:29 --> Language Class Initialized
INFO - 2016-09-23 19:18:29 --> Loader Class Initialized
INFO - 2016-09-23 19:18:29 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:29 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:29 --> Controller Class Initialized
INFO - 2016-09-23 19:18:29 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:29 --> Model Class Initialized
INFO - 2016-09-23 19:18:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:29 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:29 --> Total execution time: 0.0746
INFO - 2016-09-23 19:18:30 --> Config Class Initialized
INFO - 2016-09-23 19:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:30 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:30 --> URI Class Initialized
INFO - 2016-09-23 19:18:30 --> Router Class Initialized
INFO - 2016-09-23 19:18:30 --> Output Class Initialized
INFO - 2016-09-23 19:18:30 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:31 --> Input Class Initialized
INFO - 2016-09-23 19:18:31 --> Language Class Initialized
INFO - 2016-09-23 19:18:31 --> Loader Class Initialized
INFO - 2016-09-23 19:18:31 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:31 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:31 --> Controller Class Initialized
INFO - 2016-09-23 19:18:31 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:31 --> Model Class Initialized
INFO - 2016-09-23 19:18:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:31 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:31 --> Total execution time: 0.0863
INFO - 2016-09-23 19:18:32 --> Config Class Initialized
INFO - 2016-09-23 19:18:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:32 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:32 --> URI Class Initialized
INFO - 2016-09-23 19:18:32 --> Router Class Initialized
INFO - 2016-09-23 19:18:32 --> Output Class Initialized
INFO - 2016-09-23 19:18:32 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:32 --> Input Class Initialized
INFO - 2016-09-23 19:18:32 --> Language Class Initialized
INFO - 2016-09-23 19:18:32 --> Loader Class Initialized
INFO - 2016-09-23 19:18:32 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:32 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:32 --> Controller Class Initialized
INFO - 2016-09-23 19:18:32 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:32 --> Model Class Initialized
INFO - 2016-09-23 19:18:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:32 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:32 --> Total execution time: 0.0729
INFO - 2016-09-23 19:18:33 --> Config Class Initialized
INFO - 2016-09-23 19:18:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:33 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:33 --> URI Class Initialized
INFO - 2016-09-23 19:18:33 --> Router Class Initialized
INFO - 2016-09-23 19:18:33 --> Output Class Initialized
INFO - 2016-09-23 19:18:33 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:33 --> Input Class Initialized
INFO - 2016-09-23 19:18:33 --> Language Class Initialized
INFO - 2016-09-23 19:18:34 --> Loader Class Initialized
INFO - 2016-09-23 19:18:34 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:34 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:34 --> Controller Class Initialized
INFO - 2016-09-23 19:18:34 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:34 --> Model Class Initialized
INFO - 2016-09-23 19:18:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:34 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:34 --> Total execution time: 0.0841
INFO - 2016-09-23 19:18:51 --> Config Class Initialized
INFO - 2016-09-23 19:18:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:51 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:51 --> URI Class Initialized
INFO - 2016-09-23 19:18:51 --> Router Class Initialized
INFO - 2016-09-23 19:18:51 --> Output Class Initialized
INFO - 2016-09-23 19:18:51 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:51 --> Input Class Initialized
INFO - 2016-09-23 19:18:51 --> Language Class Initialized
INFO - 2016-09-23 19:18:51 --> Loader Class Initialized
INFO - 2016-09-23 19:18:51 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:51 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:51 --> Controller Class Initialized
INFO - 2016-09-23 19:18:51 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:51 --> Model Class Initialized
INFO - 2016-09-23 19:18:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:51 --> Config Class Initialized
INFO - 2016-09-23 19:18:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:18:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:18:51 --> Utf8 Class Initialized
INFO - 2016-09-23 19:18:51 --> URI Class Initialized
INFO - 2016-09-23 19:18:51 --> Router Class Initialized
INFO - 2016-09-23 19:18:51 --> Output Class Initialized
INFO - 2016-09-23 19:18:51 --> Security Class Initialized
DEBUG - 2016-09-23 19:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:18:51 --> Input Class Initialized
INFO - 2016-09-23 19:18:51 --> Language Class Initialized
INFO - 2016-09-23 19:18:51 --> Loader Class Initialized
INFO - 2016-09-23 19:18:51 --> Helper loaded: url_helper
INFO - 2016-09-23 19:18:51 --> Helper loaded: language_helper
INFO - 2016-09-23 19:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:18:51 --> Controller Class Initialized
INFO - 2016-09-23 19:18:51 --> Database Driver Class Initialized
INFO - 2016-09-23 19:18:51 --> Model Class Initialized
INFO - 2016-09-23 19:18:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:18:51 --> Final output sent to browser
DEBUG - 2016-09-23 19:18:51 --> Total execution time: 0.0624
INFO - 2016-09-23 19:19:04 --> Config Class Initialized
INFO - 2016-09-23 19:19:04 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:04 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:04 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:04 --> URI Class Initialized
INFO - 2016-09-23 19:19:04 --> Router Class Initialized
INFO - 2016-09-23 19:19:04 --> Output Class Initialized
INFO - 2016-09-23 19:19:04 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:04 --> Input Class Initialized
INFO - 2016-09-23 19:19:04 --> Language Class Initialized
INFO - 2016-09-23 19:19:04 --> Loader Class Initialized
INFO - 2016-09-23 19:19:04 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:04 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:04 --> Controller Class Initialized
INFO - 2016-09-23 19:19:04 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:04 --> Model Class Initialized
INFO - 2016-09-23 19:19:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:04 --> Config Class Initialized
INFO - 2016-09-23 19:19:04 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:04 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:04 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:04 --> URI Class Initialized
INFO - 2016-09-23 19:19:04 --> Router Class Initialized
INFO - 2016-09-23 19:19:04 --> Output Class Initialized
INFO - 2016-09-23 19:19:04 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:04 --> Input Class Initialized
INFO - 2016-09-23 19:19:04 --> Language Class Initialized
INFO - 2016-09-23 19:19:04 --> Loader Class Initialized
INFO - 2016-09-23 19:19:04 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:04 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:04 --> Controller Class Initialized
INFO - 2016-09-23 19:19:04 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:04 --> Model Class Initialized
INFO - 2016-09-23 19:19:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:04 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:04 --> Total execution time: 0.0613
INFO - 2016-09-23 19:19:17 --> Config Class Initialized
INFO - 2016-09-23 19:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:17 --> URI Class Initialized
INFO - 2016-09-23 19:19:17 --> Router Class Initialized
INFO - 2016-09-23 19:19:17 --> Output Class Initialized
INFO - 2016-09-23 19:19:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:17 --> Input Class Initialized
INFO - 2016-09-23 19:19:17 --> Language Class Initialized
INFO - 2016-09-23 19:19:17 --> Loader Class Initialized
INFO - 2016-09-23 19:19:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:17 --> Controller Class Initialized
INFO - 2016-09-23 19:19:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:17 --> Model Class Initialized
INFO - 2016-09-23 19:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:17 --> Config Class Initialized
INFO - 2016-09-23 19:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:17 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:17 --> URI Class Initialized
INFO - 2016-09-23 19:19:17 --> Router Class Initialized
INFO - 2016-09-23 19:19:17 --> Output Class Initialized
INFO - 2016-09-23 19:19:17 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:17 --> Input Class Initialized
INFO - 2016-09-23 19:19:17 --> Language Class Initialized
INFO - 2016-09-23 19:19:17 --> Loader Class Initialized
INFO - 2016-09-23 19:19:17 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:17 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:17 --> Controller Class Initialized
INFO - 2016-09-23 19:19:17 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:17 --> Model Class Initialized
INFO - 2016-09-23 19:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:17 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:17 --> Total execution time: 0.0795
INFO - 2016-09-23 19:19:29 --> Config Class Initialized
INFO - 2016-09-23 19:19:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:29 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:29 --> URI Class Initialized
INFO - 2016-09-23 19:19:29 --> Router Class Initialized
INFO - 2016-09-23 19:19:29 --> Output Class Initialized
INFO - 2016-09-23 19:19:29 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:29 --> Input Class Initialized
INFO - 2016-09-23 19:19:29 --> Language Class Initialized
INFO - 2016-09-23 19:19:29 --> Loader Class Initialized
INFO - 2016-09-23 19:19:29 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:29 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:29 --> Controller Class Initialized
INFO - 2016-09-23 19:19:29 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:29 --> Model Class Initialized
INFO - 2016-09-23 19:19:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:29 --> Config Class Initialized
INFO - 2016-09-23 19:19:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:29 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:29 --> URI Class Initialized
INFO - 2016-09-23 19:19:29 --> Router Class Initialized
INFO - 2016-09-23 19:19:29 --> Output Class Initialized
INFO - 2016-09-23 19:19:29 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:29 --> Input Class Initialized
INFO - 2016-09-23 19:19:29 --> Language Class Initialized
INFO - 2016-09-23 19:19:29 --> Loader Class Initialized
INFO - 2016-09-23 19:19:29 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:29 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:29 --> Controller Class Initialized
INFO - 2016-09-23 19:19:29 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:29 --> Model Class Initialized
INFO - 2016-09-23 19:19:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:29 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:29 --> Total execution time: 0.0626
INFO - 2016-09-23 19:19:41 --> Config Class Initialized
INFO - 2016-09-23 19:19:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:41 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:41 --> URI Class Initialized
INFO - 2016-09-23 19:19:41 --> Router Class Initialized
INFO - 2016-09-23 19:19:41 --> Output Class Initialized
INFO - 2016-09-23 19:19:41 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:41 --> Input Class Initialized
INFO - 2016-09-23 19:19:41 --> Language Class Initialized
INFO - 2016-09-23 19:19:41 --> Loader Class Initialized
INFO - 2016-09-23 19:19:41 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:41 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:41 --> Controller Class Initialized
INFO - 2016-09-23 19:19:41 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:41 --> Model Class Initialized
INFO - 2016-09-23 19:19:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:41 --> Config Class Initialized
INFO - 2016-09-23 19:19:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:41 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:41 --> URI Class Initialized
INFO - 2016-09-23 19:19:41 --> Router Class Initialized
INFO - 2016-09-23 19:19:41 --> Output Class Initialized
INFO - 2016-09-23 19:19:41 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:41 --> Input Class Initialized
INFO - 2016-09-23 19:19:41 --> Language Class Initialized
INFO - 2016-09-23 19:19:41 --> Loader Class Initialized
INFO - 2016-09-23 19:19:41 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:41 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:41 --> Controller Class Initialized
INFO - 2016-09-23 19:19:41 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:41 --> Model Class Initialized
INFO - 2016-09-23 19:19:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_2.php
INFO - 2016-09-23 19:19:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:41 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:41 --> Total execution time: 0.0590
INFO - 2016-09-23 19:19:49 --> Config Class Initialized
INFO - 2016-09-23 19:19:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:49 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:49 --> URI Class Initialized
INFO - 2016-09-23 19:19:49 --> Router Class Initialized
INFO - 2016-09-23 19:19:49 --> Output Class Initialized
INFO - 2016-09-23 19:19:49 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:49 --> Input Class Initialized
INFO - 2016-09-23 19:19:49 --> Language Class Initialized
INFO - 2016-09-23 19:19:49 --> Loader Class Initialized
INFO - 2016-09-23 19:19:49 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:49 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:50 --> Controller Class Initialized
INFO - 2016-09-23 19:19:50 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:50 --> Model Class Initialized
INFO - 2016-09-23 19:19:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:50 --> Config Class Initialized
INFO - 2016-09-23 19:19:50 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:50 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:50 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:50 --> URI Class Initialized
INFO - 2016-09-23 19:19:50 --> Router Class Initialized
INFO - 2016-09-23 19:19:50 --> Output Class Initialized
INFO - 2016-09-23 19:19:50 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:50 --> Input Class Initialized
INFO - 2016-09-23 19:19:50 --> Language Class Initialized
INFO - 2016-09-23 19:19:50 --> Loader Class Initialized
INFO - 2016-09-23 19:19:50 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:50 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:50 --> Controller Class Initialized
INFO - 2016-09-23 19:19:50 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:50 --> Model Class Initialized
INFO - 2016-09-23 19:19:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:50 --> Helper loaded: form_helper
INFO - 2016-09-23 19:19:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 19:19:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:50 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:50 --> Total execution time: 0.0715
INFO - 2016-09-23 19:19:55 --> Config Class Initialized
INFO - 2016-09-23 19:19:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:55 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:55 --> URI Class Initialized
INFO - 2016-09-23 19:19:55 --> Router Class Initialized
INFO - 2016-09-23 19:19:55 --> Output Class Initialized
INFO - 2016-09-23 19:19:55 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:55 --> Input Class Initialized
INFO - 2016-09-23 19:19:55 --> Language Class Initialized
INFO - 2016-09-23 19:19:55 --> Loader Class Initialized
INFO - 2016-09-23 19:19:55 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:55 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:55 --> Controller Class Initialized
INFO - 2016-09-23 19:19:55 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:55 --> Model Class Initialized
INFO - 2016-09-23 19:19:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:19:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:55 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:55 --> Total execution time: 0.0609
INFO - 2016-09-23 19:19:56 --> Config Class Initialized
INFO - 2016-09-23 19:19:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:56 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:56 --> URI Class Initialized
INFO - 2016-09-23 19:19:56 --> Router Class Initialized
INFO - 2016-09-23 19:19:56 --> Output Class Initialized
INFO - 2016-09-23 19:19:56 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:56 --> Input Class Initialized
INFO - 2016-09-23 19:19:56 --> Language Class Initialized
INFO - 2016-09-23 19:19:56 --> Loader Class Initialized
INFO - 2016-09-23 19:19:56 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:56 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:56 --> Controller Class Initialized
INFO - 2016-09-23 19:19:56 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:56 --> Model Class Initialized
INFO - 2016-09-23 19:19:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:19:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:56 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:56 --> Total execution time: 0.0763
INFO - 2016-09-23 19:19:58 --> Config Class Initialized
INFO - 2016-09-23 19:19:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:58 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:58 --> URI Class Initialized
INFO - 2016-09-23 19:19:58 --> Router Class Initialized
INFO - 2016-09-23 19:19:58 --> Output Class Initialized
INFO - 2016-09-23 19:19:58 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:58 --> Input Class Initialized
INFO - 2016-09-23 19:19:58 --> Language Class Initialized
INFO - 2016-09-23 19:19:58 --> Loader Class Initialized
INFO - 2016-09-23 19:19:58 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:58 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:58 --> Controller Class Initialized
INFO - 2016-09-23 19:19:58 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:58 --> Model Class Initialized
INFO - 2016-09-23 19:19:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:19:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:58 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:58 --> Total execution time: 0.0973
INFO - 2016-09-23 19:19:59 --> Config Class Initialized
INFO - 2016-09-23 19:19:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:19:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:19:59 --> Utf8 Class Initialized
INFO - 2016-09-23 19:19:59 --> URI Class Initialized
INFO - 2016-09-23 19:19:59 --> Router Class Initialized
INFO - 2016-09-23 19:19:59 --> Output Class Initialized
INFO - 2016-09-23 19:19:59 --> Security Class Initialized
DEBUG - 2016-09-23 19:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:19:59 --> Input Class Initialized
INFO - 2016-09-23 19:19:59 --> Language Class Initialized
INFO - 2016-09-23 19:19:59 --> Loader Class Initialized
INFO - 2016-09-23 19:19:59 --> Helper loaded: url_helper
INFO - 2016-09-23 19:19:59 --> Helper loaded: language_helper
INFO - 2016-09-23 19:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:19:59 --> Controller Class Initialized
INFO - 2016-09-23 19:19:59 --> Database Driver Class Initialized
INFO - 2016-09-23 19:19:59 --> Model Class Initialized
INFO - 2016-09-23 19:19:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:19:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:19:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:19:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:19:59 --> Final output sent to browser
DEBUG - 2016-09-23 19:19:59 --> Total execution time: 0.0830
INFO - 2016-09-23 19:20:00 --> Config Class Initialized
INFO - 2016-09-23 19:20:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:00 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:00 --> URI Class Initialized
INFO - 2016-09-23 19:20:00 --> Router Class Initialized
INFO - 2016-09-23 19:20:00 --> Output Class Initialized
INFO - 2016-09-23 19:20:00 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:00 --> Input Class Initialized
INFO - 2016-09-23 19:20:00 --> Language Class Initialized
INFO - 2016-09-23 19:20:00 --> Loader Class Initialized
INFO - 2016-09-23 19:20:00 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:00 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:00 --> Controller Class Initialized
INFO - 2016-09-23 19:20:00 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:00 --> Model Class Initialized
INFO - 2016-09-23 19:20:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:00 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:00 --> Total execution time: 0.0825
INFO - 2016-09-23 19:20:15 --> Config Class Initialized
INFO - 2016-09-23 19:20:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:15 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:15 --> URI Class Initialized
INFO - 2016-09-23 19:20:15 --> Router Class Initialized
INFO - 2016-09-23 19:20:15 --> Output Class Initialized
INFO - 2016-09-23 19:20:15 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:15 --> Input Class Initialized
INFO - 2016-09-23 19:20:15 --> Language Class Initialized
INFO - 2016-09-23 19:20:15 --> Loader Class Initialized
INFO - 2016-09-23 19:20:15 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:15 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:15 --> Controller Class Initialized
INFO - 2016-09-23 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:15 --> Model Class Initialized
INFO - 2016-09-23 19:20:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:15 --> Config Class Initialized
INFO - 2016-09-23 19:20:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:15 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:15 --> URI Class Initialized
INFO - 2016-09-23 19:20:15 --> Router Class Initialized
INFO - 2016-09-23 19:20:15 --> Output Class Initialized
INFO - 2016-09-23 19:20:15 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:15 --> Input Class Initialized
INFO - 2016-09-23 19:20:15 --> Language Class Initialized
INFO - 2016-09-23 19:20:15 --> Loader Class Initialized
INFO - 2016-09-23 19:20:15 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:15 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:15 --> Controller Class Initialized
INFO - 2016-09-23 19:20:15 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:15 --> Model Class Initialized
INFO - 2016-09-23 19:20:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:15 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:15 --> Total execution time: 0.0629
INFO - 2016-09-23 19:20:23 --> Config Class Initialized
INFO - 2016-09-23 19:20:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:23 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:23 --> URI Class Initialized
INFO - 2016-09-23 19:20:23 --> Router Class Initialized
INFO - 2016-09-23 19:20:23 --> Output Class Initialized
INFO - 2016-09-23 19:20:23 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:23 --> Input Class Initialized
INFO - 2016-09-23 19:20:23 --> Language Class Initialized
INFO - 2016-09-23 19:20:23 --> Loader Class Initialized
INFO - 2016-09-23 19:20:23 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:23 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:23 --> Controller Class Initialized
INFO - 2016-09-23 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:23 --> Model Class Initialized
INFO - 2016-09-23 19:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:23 --> Config Class Initialized
INFO - 2016-09-23 19:20:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:23 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:23 --> URI Class Initialized
INFO - 2016-09-23 19:20:23 --> Router Class Initialized
INFO - 2016-09-23 19:20:23 --> Output Class Initialized
INFO - 2016-09-23 19:20:23 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:23 --> Input Class Initialized
INFO - 2016-09-23 19:20:23 --> Language Class Initialized
INFO - 2016-09-23 19:20:23 --> Loader Class Initialized
INFO - 2016-09-23 19:20:23 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:23 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:23 --> Controller Class Initialized
INFO - 2016-09-23 19:20:23 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:23 --> Model Class Initialized
INFO - 2016-09-23 19:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:23 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:23 --> Total execution time: 0.0618
INFO - 2016-09-23 19:20:48 --> Config Class Initialized
INFO - 2016-09-23 19:20:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:48 --> URI Class Initialized
INFO - 2016-09-23 19:20:48 --> Router Class Initialized
INFO - 2016-09-23 19:20:48 --> Output Class Initialized
INFO - 2016-09-23 19:20:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:48 --> Input Class Initialized
INFO - 2016-09-23 19:20:48 --> Language Class Initialized
INFO - 2016-09-23 19:20:48 --> Loader Class Initialized
INFO - 2016-09-23 19:20:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:48 --> Controller Class Initialized
INFO - 2016-09-23 19:20:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:48 --> Model Class Initialized
INFO - 2016-09-23 19:20:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:48 --> Config Class Initialized
INFO - 2016-09-23 19:20:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:48 --> URI Class Initialized
INFO - 2016-09-23 19:20:48 --> Router Class Initialized
INFO - 2016-09-23 19:20:48 --> Output Class Initialized
INFO - 2016-09-23 19:20:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:48 --> Input Class Initialized
INFO - 2016-09-23 19:20:48 --> Language Class Initialized
INFO - 2016-09-23 19:20:48 --> Loader Class Initialized
INFO - 2016-09-23 19:20:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:48 --> Controller Class Initialized
INFO - 2016-09-23 19:20:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:48 --> Model Class Initialized
INFO - 2016-09-23 19:20:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:48 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:48 --> Total execution time: 0.0620
INFO - 2016-09-23 19:20:54 --> Config Class Initialized
INFO - 2016-09-23 19:20:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:54 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:54 --> URI Class Initialized
INFO - 2016-09-23 19:20:54 --> Router Class Initialized
INFO - 2016-09-23 19:20:54 --> Output Class Initialized
INFO - 2016-09-23 19:20:54 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:54 --> Input Class Initialized
INFO - 2016-09-23 19:20:54 --> Language Class Initialized
INFO - 2016-09-23 19:20:54 --> Loader Class Initialized
INFO - 2016-09-23 19:20:54 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:54 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:54 --> Controller Class Initialized
INFO - 2016-09-23 19:20:54 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:54 --> Model Class Initialized
INFO - 2016-09-23 19:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:54 --> Config Class Initialized
INFO - 2016-09-23 19:20:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:54 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:54 --> URI Class Initialized
INFO - 2016-09-23 19:20:54 --> Router Class Initialized
INFO - 2016-09-23 19:20:54 --> Output Class Initialized
INFO - 2016-09-23 19:20:54 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:54 --> Input Class Initialized
INFO - 2016-09-23 19:20:54 --> Language Class Initialized
INFO - 2016-09-23 19:20:54 --> Loader Class Initialized
INFO - 2016-09-23 19:20:54 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:54 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:54 --> Controller Class Initialized
INFO - 2016-09-23 19:20:54 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:54 --> Model Class Initialized
INFO - 2016-09-23 19:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:54 --> Helper loaded: form_helper
INFO - 2016-09-23 19:20:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 19:20:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:54 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:54 --> Total execution time: 0.0627
INFO - 2016-09-23 19:20:57 --> Config Class Initialized
INFO - 2016-09-23 19:20:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:57 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:57 --> URI Class Initialized
INFO - 2016-09-23 19:20:57 --> Router Class Initialized
INFO - 2016-09-23 19:20:57 --> Output Class Initialized
INFO - 2016-09-23 19:20:57 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:57 --> Input Class Initialized
INFO - 2016-09-23 19:20:57 --> Language Class Initialized
INFO - 2016-09-23 19:20:57 --> Loader Class Initialized
INFO - 2016-09-23 19:20:57 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:57 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:57 --> Controller Class Initialized
INFO - 2016-09-23 19:20:57 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:57 --> Model Class Initialized
INFO - 2016-09-23 19:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:57 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:57 --> Total execution time: 0.0662
INFO - 2016-09-23 19:20:58 --> Config Class Initialized
INFO - 2016-09-23 19:20:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:58 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:58 --> URI Class Initialized
INFO - 2016-09-23 19:20:58 --> Router Class Initialized
INFO - 2016-09-23 19:20:58 --> Output Class Initialized
INFO - 2016-09-23 19:20:58 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:58 --> Input Class Initialized
INFO - 2016-09-23 19:20:58 --> Language Class Initialized
INFO - 2016-09-23 19:20:58 --> Loader Class Initialized
INFO - 2016-09-23 19:20:58 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:58 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:58 --> Controller Class Initialized
INFO - 2016-09-23 19:20:58 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:58 --> Model Class Initialized
INFO - 2016-09-23 19:20:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:58 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:58 --> Total execution time: 0.0754
INFO - 2016-09-23 19:20:59 --> Config Class Initialized
INFO - 2016-09-23 19:20:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:20:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:20:59 --> Utf8 Class Initialized
INFO - 2016-09-23 19:20:59 --> URI Class Initialized
INFO - 2016-09-23 19:20:59 --> Router Class Initialized
INFO - 2016-09-23 19:20:59 --> Output Class Initialized
INFO - 2016-09-23 19:20:59 --> Security Class Initialized
DEBUG - 2016-09-23 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:20:59 --> Input Class Initialized
INFO - 2016-09-23 19:20:59 --> Language Class Initialized
INFO - 2016-09-23 19:20:59 --> Loader Class Initialized
INFO - 2016-09-23 19:20:59 --> Helper loaded: url_helper
INFO - 2016-09-23 19:20:59 --> Helper loaded: language_helper
INFO - 2016-09-23 19:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:20:59 --> Controller Class Initialized
INFO - 2016-09-23 19:20:59 --> Database Driver Class Initialized
INFO - 2016-09-23 19:20:59 --> Model Class Initialized
INFO - 2016-09-23 19:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:20:59 --> Final output sent to browser
DEBUG - 2016-09-23 19:20:59 --> Total execution time: 0.0752
INFO - 2016-09-23 19:21:00 --> Config Class Initialized
INFO - 2016-09-23 19:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:00 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:00 --> URI Class Initialized
INFO - 2016-09-23 19:21:00 --> Router Class Initialized
INFO - 2016-09-23 19:21:00 --> Output Class Initialized
INFO - 2016-09-23 19:21:00 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:00 --> Input Class Initialized
INFO - 2016-09-23 19:21:00 --> Language Class Initialized
INFO - 2016-09-23 19:21:00 --> Loader Class Initialized
INFO - 2016-09-23 19:21:00 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:00 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:00 --> Controller Class Initialized
INFO - 2016-09-23 19:21:01 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:01 --> Model Class Initialized
INFO - 2016-09-23 19:21:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:01 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:01 --> Total execution time: 0.0803
INFO - 2016-09-23 19:21:02 --> Config Class Initialized
INFO - 2016-09-23 19:21:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:02 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:02 --> URI Class Initialized
INFO - 2016-09-23 19:21:02 --> Router Class Initialized
INFO - 2016-09-23 19:21:02 --> Output Class Initialized
INFO - 2016-09-23 19:21:02 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:02 --> Input Class Initialized
INFO - 2016-09-23 19:21:02 --> Language Class Initialized
INFO - 2016-09-23 19:21:02 --> Loader Class Initialized
INFO - 2016-09-23 19:21:02 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:02 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:02 --> Controller Class Initialized
INFO - 2016-09-23 19:21:02 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:02 --> Model Class Initialized
INFO - 2016-09-23 19:21:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:02 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:02 --> Total execution time: 0.0777
INFO - 2016-09-23 19:21:18 --> Config Class Initialized
INFO - 2016-09-23 19:21:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:18 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:18 --> URI Class Initialized
INFO - 2016-09-23 19:21:18 --> Router Class Initialized
INFO - 2016-09-23 19:21:18 --> Output Class Initialized
INFO - 2016-09-23 19:21:18 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:18 --> Input Class Initialized
INFO - 2016-09-23 19:21:18 --> Language Class Initialized
INFO - 2016-09-23 19:21:18 --> Loader Class Initialized
INFO - 2016-09-23 19:21:18 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:18 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:18 --> Controller Class Initialized
INFO - 2016-09-23 19:21:18 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:18 --> Model Class Initialized
INFO - 2016-09-23 19:21:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:18 --> Config Class Initialized
INFO - 2016-09-23 19:21:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:18 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:18 --> URI Class Initialized
INFO - 2016-09-23 19:21:18 --> Router Class Initialized
INFO - 2016-09-23 19:21:19 --> Output Class Initialized
INFO - 2016-09-23 19:21:19 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:19 --> Input Class Initialized
INFO - 2016-09-23 19:21:19 --> Language Class Initialized
INFO - 2016-09-23 19:21:19 --> Loader Class Initialized
INFO - 2016-09-23 19:21:19 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:19 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:19 --> Controller Class Initialized
INFO - 2016-09-23 19:21:19 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:19 --> Model Class Initialized
INFO - 2016-09-23 19:21:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:19 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:19 --> Total execution time: 0.0626
INFO - 2016-09-23 19:21:31 --> Config Class Initialized
INFO - 2016-09-23 19:21:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:31 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:31 --> URI Class Initialized
INFO - 2016-09-23 19:21:31 --> Router Class Initialized
INFO - 2016-09-23 19:21:31 --> Output Class Initialized
INFO - 2016-09-23 19:21:31 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:31 --> Input Class Initialized
INFO - 2016-09-23 19:21:31 --> Language Class Initialized
INFO - 2016-09-23 19:21:31 --> Loader Class Initialized
INFO - 2016-09-23 19:21:31 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:31 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:31 --> Controller Class Initialized
INFO - 2016-09-23 19:21:31 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:31 --> Model Class Initialized
INFO - 2016-09-23 19:21:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:31 --> Config Class Initialized
INFO - 2016-09-23 19:21:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:31 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:31 --> URI Class Initialized
INFO - 2016-09-23 19:21:31 --> Router Class Initialized
INFO - 2016-09-23 19:21:31 --> Output Class Initialized
INFO - 2016-09-23 19:21:31 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:31 --> Input Class Initialized
INFO - 2016-09-23 19:21:31 --> Language Class Initialized
INFO - 2016-09-23 19:21:31 --> Loader Class Initialized
INFO - 2016-09-23 19:21:31 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:31 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:31 --> Controller Class Initialized
INFO - 2016-09-23 19:21:31 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:31 --> Model Class Initialized
INFO - 2016-09-23 19:21:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:31 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:31 --> Total execution time: 0.0672
INFO - 2016-09-23 19:21:37 --> Config Class Initialized
INFO - 2016-09-23 19:21:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:37 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:37 --> URI Class Initialized
INFO - 2016-09-23 19:21:37 --> Router Class Initialized
INFO - 2016-09-23 19:21:37 --> Output Class Initialized
INFO - 2016-09-23 19:21:37 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:37 --> Input Class Initialized
INFO - 2016-09-23 19:21:37 --> Language Class Initialized
INFO - 2016-09-23 19:21:37 --> Loader Class Initialized
INFO - 2016-09-23 19:21:37 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:37 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:37 --> Controller Class Initialized
INFO - 2016-09-23 19:21:37 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:37 --> Model Class Initialized
INFO - 2016-09-23 19:21:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:37 --> Config Class Initialized
INFO - 2016-09-23 19:21:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:37 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:37 --> URI Class Initialized
INFO - 2016-09-23 19:21:37 --> Router Class Initialized
INFO - 2016-09-23 19:21:37 --> Output Class Initialized
INFO - 2016-09-23 19:21:37 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:37 --> Input Class Initialized
INFO - 2016-09-23 19:21:37 --> Language Class Initialized
INFO - 2016-09-23 19:21:37 --> Loader Class Initialized
INFO - 2016-09-23 19:21:37 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:37 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:37 --> Controller Class Initialized
INFO - 2016-09-23 19:21:37 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:37 --> Model Class Initialized
INFO - 2016-09-23 19:21:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:37 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:37 --> Total execution time: 0.0652
INFO - 2016-09-23 19:21:48 --> Config Class Initialized
INFO - 2016-09-23 19:21:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:48 --> URI Class Initialized
INFO - 2016-09-23 19:21:48 --> Router Class Initialized
INFO - 2016-09-23 19:21:48 --> Output Class Initialized
INFO - 2016-09-23 19:21:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:48 --> Input Class Initialized
INFO - 2016-09-23 19:21:48 --> Language Class Initialized
INFO - 2016-09-23 19:21:48 --> Loader Class Initialized
INFO - 2016-09-23 19:21:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:48 --> Controller Class Initialized
INFO - 2016-09-23 19:21:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:48 --> Model Class Initialized
INFO - 2016-09-23 19:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:48 --> Config Class Initialized
INFO - 2016-09-23 19:21:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:48 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:48 --> URI Class Initialized
INFO - 2016-09-23 19:21:48 --> Router Class Initialized
INFO - 2016-09-23 19:21:48 --> Output Class Initialized
INFO - 2016-09-23 19:21:48 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:48 --> Input Class Initialized
INFO - 2016-09-23 19:21:48 --> Language Class Initialized
INFO - 2016-09-23 19:21:48 --> Loader Class Initialized
INFO - 2016-09-23 19:21:48 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:48 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:48 --> Controller Class Initialized
INFO - 2016-09-23 19:21:48 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:48 --> Model Class Initialized
INFO - 2016-09-23 19:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:48 --> Helper loaded: form_helper
INFO - 2016-09-23 19:21:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-09-23 19:21:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:48 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:48 --> Total execution time: 0.0621
INFO - 2016-09-23 19:21:55 --> Config Class Initialized
INFO - 2016-09-23 19:21:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:55 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:55 --> URI Class Initialized
INFO - 2016-09-23 19:21:55 --> Router Class Initialized
INFO - 2016-09-23 19:21:55 --> Output Class Initialized
INFO - 2016-09-23 19:21:55 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:55 --> Input Class Initialized
INFO - 2016-09-23 19:21:55 --> Language Class Initialized
INFO - 2016-09-23 19:21:55 --> Loader Class Initialized
INFO - 2016-09-23 19:21:55 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:55 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:55 --> Controller Class Initialized
INFO - 2016-09-23 19:21:55 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:55 --> Model Class Initialized
INFO - 2016-09-23 19:21:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:55 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:55 --> Total execution time: 0.0644
INFO - 2016-09-23 19:21:56 --> Config Class Initialized
INFO - 2016-09-23 19:21:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:56 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:56 --> URI Class Initialized
INFO - 2016-09-23 19:21:56 --> Router Class Initialized
INFO - 2016-09-23 19:21:56 --> Output Class Initialized
INFO - 2016-09-23 19:21:56 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:56 --> Input Class Initialized
INFO - 2016-09-23 19:21:56 --> Language Class Initialized
INFO - 2016-09-23 19:21:56 --> Loader Class Initialized
INFO - 2016-09-23 19:21:56 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:56 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:56 --> Controller Class Initialized
INFO - 2016-09-23 19:21:56 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:56 --> Model Class Initialized
INFO - 2016-09-23 19:21:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:56 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:56 --> Total execution time: 0.0696
INFO - 2016-09-23 19:21:57 --> Config Class Initialized
INFO - 2016-09-23 19:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:57 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:57 --> URI Class Initialized
INFO - 2016-09-23 19:21:57 --> Router Class Initialized
INFO - 2016-09-23 19:21:57 --> Output Class Initialized
INFO - 2016-09-23 19:21:57 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:57 --> Input Class Initialized
INFO - 2016-09-23 19:21:57 --> Language Class Initialized
INFO - 2016-09-23 19:21:57 --> Loader Class Initialized
INFO - 2016-09-23 19:21:57 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:57 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:57 --> Controller Class Initialized
INFO - 2016-09-23 19:21:57 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:57 --> Model Class Initialized
INFO - 2016-09-23 19:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:57 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:57 --> Total execution time: 0.0807
INFO - 2016-09-23 19:21:59 --> Config Class Initialized
INFO - 2016-09-23 19:21:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:21:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:21:59 --> Utf8 Class Initialized
INFO - 2016-09-23 19:21:59 --> URI Class Initialized
INFO - 2016-09-23 19:21:59 --> Router Class Initialized
INFO - 2016-09-23 19:21:59 --> Output Class Initialized
INFO - 2016-09-23 19:21:59 --> Security Class Initialized
DEBUG - 2016-09-23 19:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:21:59 --> Input Class Initialized
INFO - 2016-09-23 19:21:59 --> Language Class Initialized
INFO - 2016-09-23 19:21:59 --> Loader Class Initialized
INFO - 2016-09-23 19:21:59 --> Helper loaded: url_helper
INFO - 2016-09-23 19:21:59 --> Helper loaded: language_helper
INFO - 2016-09-23 19:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:21:59 --> Controller Class Initialized
INFO - 2016-09-23 19:21:59 --> Database Driver Class Initialized
INFO - 2016-09-23 19:21:59 --> Model Class Initialized
INFO - 2016-09-23 19:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:21:59 --> Final output sent to browser
DEBUG - 2016-09-23 19:21:59 --> Total execution time: 0.0946
INFO - 2016-09-23 19:22:00 --> Config Class Initialized
INFO - 2016-09-23 19:22:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:00 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:00 --> URI Class Initialized
INFO - 2016-09-23 19:22:00 --> Router Class Initialized
INFO - 2016-09-23 19:22:00 --> Output Class Initialized
INFO - 2016-09-23 19:22:00 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:00 --> Input Class Initialized
INFO - 2016-09-23 19:22:00 --> Language Class Initialized
INFO - 2016-09-23 19:22:00 --> Loader Class Initialized
INFO - 2016-09-23 19:22:00 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:00 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:00 --> Controller Class Initialized
INFO - 2016-09-23 19:22:00 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:00 --> Model Class Initialized
INFO - 2016-09-23 19:22:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:22:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:22:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:22:01 --> Final output sent to browser
DEBUG - 2016-09-23 19:22:01 --> Total execution time: 0.0834
INFO - 2016-09-23 19:22:18 --> Config Class Initialized
INFO - 2016-09-23 19:22:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:18 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:18 --> URI Class Initialized
INFO - 2016-09-23 19:22:18 --> Router Class Initialized
INFO - 2016-09-23 19:22:18 --> Output Class Initialized
INFO - 2016-09-23 19:22:18 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:18 --> Input Class Initialized
INFO - 2016-09-23 19:22:18 --> Language Class Initialized
INFO - 2016-09-23 19:22:18 --> Loader Class Initialized
INFO - 2016-09-23 19:22:18 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:18 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:18 --> Controller Class Initialized
INFO - 2016-09-23 19:22:18 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:18 --> Model Class Initialized
INFO - 2016-09-23 19:22:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:18 --> Config Class Initialized
INFO - 2016-09-23 19:22:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:18 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:18 --> URI Class Initialized
INFO - 2016-09-23 19:22:18 --> Router Class Initialized
INFO - 2016-09-23 19:22:18 --> Output Class Initialized
INFO - 2016-09-23 19:22:18 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:18 --> Input Class Initialized
INFO - 2016-09-23 19:22:18 --> Language Class Initialized
INFO - 2016-09-23 19:22:18 --> Loader Class Initialized
INFO - 2016-09-23 19:22:18 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:18 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:18 --> Controller Class Initialized
INFO - 2016-09-23 19:22:18 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:18 --> Model Class Initialized
INFO - 2016-09-23 19:22:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:22:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:22:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:22:18 --> Final output sent to browser
DEBUG - 2016-09-23 19:22:18 --> Total execution time: 0.0680
INFO - 2016-09-23 19:22:28 --> Config Class Initialized
INFO - 2016-09-23 19:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:28 --> URI Class Initialized
INFO - 2016-09-23 19:22:28 --> Router Class Initialized
INFO - 2016-09-23 19:22:28 --> Output Class Initialized
INFO - 2016-09-23 19:22:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:28 --> Input Class Initialized
INFO - 2016-09-23 19:22:28 --> Language Class Initialized
INFO - 2016-09-23 19:22:28 --> Loader Class Initialized
INFO - 2016-09-23 19:22:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:28 --> Controller Class Initialized
INFO - 2016-09-23 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:28 --> Model Class Initialized
INFO - 2016-09-23 19:22:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:28 --> Config Class Initialized
INFO - 2016-09-23 19:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:28 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:28 --> URI Class Initialized
INFO - 2016-09-23 19:22:28 --> Router Class Initialized
INFO - 2016-09-23 19:22:28 --> Output Class Initialized
INFO - 2016-09-23 19:22:28 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:28 --> Input Class Initialized
INFO - 2016-09-23 19:22:28 --> Language Class Initialized
INFO - 2016-09-23 19:22:28 --> Loader Class Initialized
INFO - 2016-09-23 19:22:28 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:28 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:28 --> Controller Class Initialized
INFO - 2016-09-23 19:22:28 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:28 --> Model Class Initialized
INFO - 2016-09-23 19:22:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:22:28 --> Final output sent to browser
DEBUG - 2016-09-23 19:22:28 --> Total execution time: 0.0620
INFO - 2016-09-23 19:22:40 --> Config Class Initialized
INFO - 2016-09-23 19:22:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:40 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:40 --> URI Class Initialized
INFO - 2016-09-23 19:22:40 --> Router Class Initialized
INFO - 2016-09-23 19:22:40 --> Output Class Initialized
INFO - 2016-09-23 19:22:40 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:40 --> Input Class Initialized
INFO - 2016-09-23 19:22:40 --> Language Class Initialized
INFO - 2016-09-23 19:22:40 --> Loader Class Initialized
INFO - 2016-09-23 19:22:40 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:40 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:40 --> Controller Class Initialized
INFO - 2016-09-23 19:22:40 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:40 --> Model Class Initialized
INFO - 2016-09-23 19:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:40 --> Config Class Initialized
INFO - 2016-09-23 19:22:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:40 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:40 --> URI Class Initialized
INFO - 2016-09-23 19:22:40 --> Router Class Initialized
INFO - 2016-09-23 19:22:40 --> Output Class Initialized
INFO - 2016-09-23 19:22:40 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:40 --> Input Class Initialized
INFO - 2016-09-23 19:22:40 --> Language Class Initialized
INFO - 2016-09-23 19:22:40 --> Loader Class Initialized
INFO - 2016-09-23 19:22:40 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:40 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:40 --> Controller Class Initialized
INFO - 2016-09-23 19:22:40 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:40 --> Model Class Initialized
INFO - 2016-09-23 19:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:22:40 --> Final output sent to browser
DEBUG - 2016-09-23 19:22:40 --> Total execution time: 0.0609
INFO - 2016-09-23 19:22:56 --> Config Class Initialized
INFO - 2016-09-23 19:22:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:56 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:56 --> URI Class Initialized
INFO - 2016-09-23 19:22:56 --> Router Class Initialized
INFO - 2016-09-23 19:22:56 --> Output Class Initialized
INFO - 2016-09-23 19:22:56 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:56 --> Input Class Initialized
INFO - 2016-09-23 19:22:56 --> Language Class Initialized
INFO - 2016-09-23 19:22:56 --> Loader Class Initialized
INFO - 2016-09-23 19:22:56 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:56 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:56 --> Controller Class Initialized
INFO - 2016-09-23 19:22:56 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:56 --> Model Class Initialized
INFO - 2016-09-23 19:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:56 --> Config Class Initialized
INFO - 2016-09-23 19:22:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 19:22:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 19:22:56 --> Utf8 Class Initialized
INFO - 2016-09-23 19:22:56 --> URI Class Initialized
INFO - 2016-09-23 19:22:56 --> Router Class Initialized
INFO - 2016-09-23 19:22:56 --> Output Class Initialized
INFO - 2016-09-23 19:22:56 --> Security Class Initialized
DEBUG - 2016-09-23 19:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 19:22:56 --> Input Class Initialized
INFO - 2016-09-23 19:22:56 --> Language Class Initialized
INFO - 2016-09-23 19:22:56 --> Loader Class Initialized
INFO - 2016-09-23 19:22:56 --> Helper loaded: url_helper
INFO - 2016-09-23 19:22:56 --> Helper loaded: language_helper
INFO - 2016-09-23 19:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 19:22:56 --> Controller Class Initialized
INFO - 2016-09-23 19:22:56 --> Database Driver Class Initialized
INFO - 2016-09-23 19:22:56 --> Model Class Initialized
INFO - 2016-09-23 19:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 19:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 19:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2016-09-23 19:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 19:22:56 --> Final output sent to browser
DEBUG - 2016-09-23 19:22:56 --> Total execution time: 0.0580
INFO - 2016-09-23 22:24:02 --> Config Class Initialized
INFO - 2016-09-23 22:24:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:24:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:24:02 --> Utf8 Class Initialized
INFO - 2016-09-23 22:24:02 --> URI Class Initialized
INFO - 2016-09-23 22:24:02 --> Router Class Initialized
INFO - 2016-09-23 22:24:02 --> Output Class Initialized
INFO - 2016-09-23 22:24:02 --> Security Class Initialized
DEBUG - 2016-09-23 22:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:24:02 --> Input Class Initialized
INFO - 2016-09-23 22:24:02 --> Language Class Initialized
INFO - 2016-09-23 22:24:02 --> Loader Class Initialized
INFO - 2016-09-23 22:24:02 --> Helper loaded: url_helper
INFO - 2016-09-23 22:24:02 --> Helper loaded: language_helper
INFO - 2016-09-23 22:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:24:02 --> Controller Class Initialized
INFO - 2016-09-23 22:24:02 --> Database Driver Class Initialized
INFO - 2016-09-23 22:24:02 --> Model Class Initialized
INFO - 2016-09-23 22:24:02 --> Model Class Initialized
INFO - 2016-09-23 22:24:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:24:02 --> Config Class Initialized
INFO - 2016-09-23 22:24:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:24:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:24:02 --> Utf8 Class Initialized
INFO - 2016-09-23 22:24:02 --> URI Class Initialized
INFO - 2016-09-23 22:24:02 --> Router Class Initialized
INFO - 2016-09-23 22:24:02 --> Output Class Initialized
INFO - 2016-09-23 22:24:02 --> Security Class Initialized
DEBUG - 2016-09-23 22:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:24:02 --> Input Class Initialized
INFO - 2016-09-23 22:24:02 --> Language Class Initialized
INFO - 2016-09-23 22:24:02 --> Loader Class Initialized
INFO - 2016-09-23 22:24:02 --> Helper loaded: url_helper
INFO - 2016-09-23 22:24:02 --> Helper loaded: language_helper
INFO - 2016-09-23 22:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:24:02 --> Controller Class Initialized
INFO - 2016-09-23 22:24:02 --> Database Driver Class Initialized
INFO - 2016-09-23 22:24:02 --> Model Class Initialized
INFO - 2016-09-23 22:24:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:24:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-23 22:24:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-23 22:24:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-23 22:24:02 --> Final output sent to browser
DEBUG - 2016-09-23 22:24:02 --> Total execution time: 0.0567
INFO - 2016-09-23 22:27:24 --> Config Class Initialized
INFO - 2016-09-23 22:27:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:24 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:24 --> URI Class Initialized
INFO - 2016-09-23 22:27:24 --> Router Class Initialized
INFO - 2016-09-23 22:27:24 --> Output Class Initialized
INFO - 2016-09-23 22:27:24 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:24 --> Input Class Initialized
INFO - 2016-09-23 22:27:24 --> Language Class Initialized
INFO - 2016-09-23 22:27:24 --> Loader Class Initialized
INFO - 2016-09-23 22:27:24 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:24 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:24 --> Controller Class Initialized
INFO - 2016-09-23 22:27:24 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:24 --> Model Class Initialized
INFO - 2016-09-23 22:27:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:24 --> Config Class Initialized
INFO - 2016-09-23 22:27:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:24 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:24 --> URI Class Initialized
INFO - 2016-09-23 22:27:24 --> Router Class Initialized
INFO - 2016-09-23 22:27:24 --> Output Class Initialized
INFO - 2016-09-23 22:27:24 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:24 --> Input Class Initialized
INFO - 2016-09-23 22:27:24 --> Language Class Initialized
INFO - 2016-09-23 22:27:24 --> Loader Class Initialized
INFO - 2016-09-23 22:27:24 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:24 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:24 --> Controller Class Initialized
INFO - 2016-09-23 22:27:24 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:24 --> Model Class Initialized
INFO - 2016-09-23 22:27:24 --> Model Class Initialized
INFO - 2016-09-23 22:27:24 --> Model Class Initialized
INFO - 2016-09-23 22:27:24 --> Model Class Initialized
INFO - 2016-09-23 22:27:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:27:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-23 22:27:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:27:24 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:24 --> Total execution time: 0.0799
INFO - 2016-09-23 22:27:29 --> Config Class Initialized
INFO - 2016-09-23 22:27:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:29 --> URI Class Initialized
INFO - 2016-09-23 22:27:29 --> Router Class Initialized
INFO - 2016-09-23 22:27:29 --> Output Class Initialized
INFO - 2016-09-23 22:27:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:29 --> Input Class Initialized
INFO - 2016-09-23 22:27:29 --> Language Class Initialized
INFO - 2016-09-23 22:27:29 --> Loader Class Initialized
INFO - 2016-09-23 22:27:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:29 --> Controller Class Initialized
INFO - 2016-09-23 22:27:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:29 --> Model Class Initialized
INFO - 2016-09-23 22:27:29 --> Model Class Initialized
INFO - 2016-09-23 22:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:27:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:27:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:27:29 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:29 --> Total execution time: 0.0596
INFO - 2016-09-23 22:27:29 --> Config Class Initialized
INFO - 2016-09-23 22:27:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:29 --> URI Class Initialized
INFO - 2016-09-23 22:27:29 --> Router Class Initialized
INFO - 2016-09-23 22:27:29 --> Output Class Initialized
INFO - 2016-09-23 22:27:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:29 --> Input Class Initialized
INFO - 2016-09-23 22:27:29 --> Language Class Initialized
INFO - 2016-09-23 22:27:29 --> Loader Class Initialized
INFO - 2016-09-23 22:27:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:29 --> Controller Class Initialized
INFO - 2016-09-23 22:27:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:29 --> Model Class Initialized
INFO - 2016-09-23 22:27:29 --> Model Class Initialized
INFO - 2016-09-23 22:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:27:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:27:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:27:29 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:29 --> Total execution time: 0.0659
INFO - 2016-09-23 22:27:34 --> Config Class Initialized
INFO - 2016-09-23 22:27:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:34 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:34 --> URI Class Initialized
INFO - 2016-09-23 22:27:34 --> Router Class Initialized
INFO - 2016-09-23 22:27:34 --> Output Class Initialized
INFO - 2016-09-23 22:27:34 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:34 --> Input Class Initialized
INFO - 2016-09-23 22:27:34 --> Language Class Initialized
INFO - 2016-09-23 22:27:34 --> Loader Class Initialized
INFO - 2016-09-23 22:27:34 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:34 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:34 --> Controller Class Initialized
INFO - 2016-09-23 22:27:34 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:34 --> Model Class Initialized
INFO - 2016-09-23 22:27:34 --> Model Class Initialized
INFO - 2016-09-23 22:27:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:27:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 22:27:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:27:34 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:34 --> Total execution time: 0.0628
INFO - 2016-09-23 22:27:37 --> Config Class Initialized
INFO - 2016-09-23 22:27:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:37 --> URI Class Initialized
INFO - 2016-09-23 22:27:37 --> Router Class Initialized
INFO - 2016-09-23 22:27:37 --> Output Class Initialized
INFO - 2016-09-23 22:27:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:37 --> Input Class Initialized
INFO - 2016-09-23 22:27:37 --> Language Class Initialized
INFO - 2016-09-23 22:27:37 --> Loader Class Initialized
INFO - 2016-09-23 22:27:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:37 --> Controller Class Initialized
INFO - 2016-09-23 22:27:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:37 --> Config Class Initialized
INFO - 2016-09-23 22:27:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:37 --> URI Class Initialized
INFO - 2016-09-23 22:27:37 --> Router Class Initialized
INFO - 2016-09-23 22:27:37 --> Output Class Initialized
INFO - 2016-09-23 22:27:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:37 --> Input Class Initialized
INFO - 2016-09-23 22:27:37 --> Language Class Initialized
INFO - 2016-09-23 22:27:37 --> Loader Class Initialized
INFO - 2016-09-23 22:27:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:37 --> Controller Class Initialized
INFO - 2016-09-23 22:27:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:27:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 22:27:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:27:37 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:37 --> Total execution time: 0.0678
INFO - 2016-09-23 22:27:37 --> Config Class Initialized
INFO - 2016-09-23 22:27:37 --> Hooks Class Initialized
INFO - 2016-09-23 22:27:37 --> Config Class Initialized
INFO - 2016-09-23 22:27:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:37 --> URI Class Initialized
DEBUG - 2016-09-23 22:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:37 --> Router Class Initialized
INFO - 2016-09-23 22:27:37 --> URI Class Initialized
INFO - 2016-09-23 22:27:37 --> Output Class Initialized
INFO - 2016-09-23 22:27:37 --> Router Class Initialized
INFO - 2016-09-23 22:27:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:37 --> Output Class Initialized
INFO - 2016-09-23 22:27:37 --> Input Class Initialized
INFO - 2016-09-23 22:27:37 --> Language Class Initialized
INFO - 2016-09-23 22:27:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:37 --> Input Class Initialized
INFO - 2016-09-23 22:27:37 --> Loader Class Initialized
INFO - 2016-09-23 22:27:37 --> Language Class Initialized
INFO - 2016-09-23 22:27:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:37 --> Loader Class Initialized
INFO - 2016-09-23 22:27:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:37 --> Controller Class Initialized
INFO - 2016-09-23 22:27:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:37 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:37 --> Total execution time: 0.0806
INFO - 2016-09-23 22:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:37 --> Controller Class Initialized
INFO - 2016-09-23 22:27:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Model Class Initialized
INFO - 2016-09-23 22:27:37 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:27:37 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:27:37 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:37 --> Total execution time: 0.1209
INFO - 2016-09-23 22:27:45 --> Config Class Initialized
INFO - 2016-09-23 22:27:45 --> Hooks Class Initialized
INFO - 2016-09-23 22:27:45 --> Config Class Initialized
INFO - 2016-09-23 22:27:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:27:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:45 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:45 --> URI Class Initialized
DEBUG - 2016-09-23 22:27:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:27:45 --> Utf8 Class Initialized
INFO - 2016-09-23 22:27:45 --> Router Class Initialized
INFO - 2016-09-23 22:27:45 --> URI Class Initialized
INFO - 2016-09-23 22:27:45 --> Output Class Initialized
INFO - 2016-09-23 22:27:45 --> Router Class Initialized
INFO - 2016-09-23 22:27:45 --> Security Class Initialized
INFO - 2016-09-23 22:27:45 --> Output Class Initialized
DEBUG - 2016-09-23 22:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:45 --> Input Class Initialized
INFO - 2016-09-23 22:27:45 --> Security Class Initialized
INFO - 2016-09-23 22:27:45 --> Language Class Initialized
DEBUG - 2016-09-23 22:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:27:45 --> Input Class Initialized
INFO - 2016-09-23 22:27:45 --> Language Class Initialized
INFO - 2016-09-23 22:27:45 --> Loader Class Initialized
INFO - 2016-09-23 22:27:45 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:45 --> Loader Class Initialized
INFO - 2016-09-23 22:27:45 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:45 --> Helper loaded: url_helper
INFO - 2016-09-23 22:27:45 --> Helper loaded: language_helper
INFO - 2016-09-23 22:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:45 --> Controller Class Initialized
INFO - 2016-09-23 22:27:45 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:45 --> Model Class Initialized
INFO - 2016-09-23 22:27:45 --> Model Class Initialized
INFO - 2016-09-23 22:27:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:45 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:45 --> Total execution time: 0.0708
INFO - 2016-09-23 22:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:27:45 --> Controller Class Initialized
INFO - 2016-09-23 22:27:45 --> Database Driver Class Initialized
INFO - 2016-09-23 22:27:45 --> Model Class Initialized
INFO - 2016-09-23 22:27:45 --> Model Class Initialized
INFO - 2016-09-23 22:27:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:27:45 --> Final output sent to browser
DEBUG - 2016-09-23 22:27:45 --> Total execution time: 0.0887
INFO - 2016-09-23 22:28:08 --> Config Class Initialized
INFO - 2016-09-23 22:28:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:28:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:28:08 --> Utf8 Class Initialized
INFO - 2016-09-23 22:28:08 --> URI Class Initialized
INFO - 2016-09-23 22:28:08 --> Router Class Initialized
INFO - 2016-09-23 22:28:08 --> Output Class Initialized
INFO - 2016-09-23 22:28:08 --> Security Class Initialized
DEBUG - 2016-09-23 22:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:28:08 --> Input Class Initialized
INFO - 2016-09-23 22:28:08 --> Language Class Initialized
ERROR - 2016-09-23 22:28:08 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:28:38 --> Config Class Initialized
INFO - 2016-09-23 22:28:38 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:28:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:28:38 --> Utf8 Class Initialized
INFO - 2016-09-23 22:28:38 --> URI Class Initialized
INFO - 2016-09-23 22:28:38 --> Router Class Initialized
INFO - 2016-09-23 22:28:38 --> Output Class Initialized
INFO - 2016-09-23 22:28:38 --> Security Class Initialized
DEBUG - 2016-09-23 22:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:28:38 --> Input Class Initialized
INFO - 2016-09-23 22:28:38 --> Language Class Initialized
ERROR - 2016-09-23 22:28:38 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:28:48 --> Config Class Initialized
INFO - 2016-09-23 22:28:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:28:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:28:48 --> Utf8 Class Initialized
INFO - 2016-09-23 22:28:48 --> URI Class Initialized
INFO - 2016-09-23 22:28:48 --> Router Class Initialized
INFO - 2016-09-23 22:28:48 --> Config Class Initialized
INFO - 2016-09-23 22:28:48 --> Hooks Class Initialized
INFO - 2016-09-23 22:28:48 --> Output Class Initialized
INFO - 2016-09-23 22:28:48 --> Security Class Initialized
DEBUG - 2016-09-23 22:28:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 22:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:28:48 --> Utf8 Class Initialized
INFO - 2016-09-23 22:28:48 --> Input Class Initialized
INFO - 2016-09-23 22:28:48 --> Language Class Initialized
INFO - 2016-09-23 22:28:48 --> URI Class Initialized
INFO - 2016-09-23 22:28:48 --> Router Class Initialized
INFO - 2016-09-23 22:28:48 --> Loader Class Initialized
INFO - 2016-09-23 22:28:48 --> Output Class Initialized
INFO - 2016-09-23 22:28:48 --> Helper loaded: url_helper
INFO - 2016-09-23 22:28:48 --> Helper loaded: language_helper
INFO - 2016-09-23 22:28:48 --> Security Class Initialized
DEBUG - 2016-09-23 22:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:28:48 --> Input Class Initialized
INFO - 2016-09-23 22:28:48 --> Language Class Initialized
INFO - 2016-09-23 22:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:28:48 --> Controller Class Initialized
INFO - 2016-09-23 22:28:48 --> Loader Class Initialized
INFO - 2016-09-23 22:28:48 --> Helper loaded: url_helper
INFO - 2016-09-23 22:28:48 --> Helper loaded: language_helper
INFO - 2016-09-23 22:28:48 --> Database Driver Class Initialized
INFO - 2016-09-23 22:28:48 --> Model Class Initialized
INFO - 2016-09-23 22:28:48 --> Model Class Initialized
INFO - 2016-09-23 22:28:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:28:48 --> Final output sent to browser
DEBUG - 2016-09-23 22:28:48 --> Total execution time: 0.0774
INFO - 2016-09-23 22:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:28:48 --> Controller Class Initialized
INFO - 2016-09-23 22:28:48 --> Database Driver Class Initialized
INFO - 2016-09-23 22:28:48 --> Model Class Initialized
INFO - 2016-09-23 22:28:48 --> Model Class Initialized
INFO - 2016-09-23 22:28:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:28:48 --> Final output sent to browser
DEBUG - 2016-09-23 22:28:48 --> Total execution time: 0.0969
INFO - 2016-09-23 22:29:03 --> Config Class Initialized
INFO - 2016-09-23 22:29:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:03 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:03 --> URI Class Initialized
INFO - 2016-09-23 22:29:03 --> Config Class Initialized
INFO - 2016-09-23 22:29:03 --> Hooks Class Initialized
INFO - 2016-09-23 22:29:03 --> Router Class Initialized
INFO - 2016-09-23 22:29:03 --> Output Class Initialized
DEBUG - 2016-09-23 22:29:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:03 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:03 --> Security Class Initialized
INFO - 2016-09-23 22:29:03 --> URI Class Initialized
DEBUG - 2016-09-23 22:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:03 --> Input Class Initialized
INFO - 2016-09-23 22:29:03 --> Router Class Initialized
INFO - 2016-09-23 22:29:03 --> Language Class Initialized
INFO - 2016-09-23 22:29:03 --> Output Class Initialized
INFO - 2016-09-23 22:29:03 --> Loader Class Initialized
INFO - 2016-09-23 22:29:03 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:03 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:03 --> Input Class Initialized
INFO - 2016-09-23 22:29:03 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:03 --> Language Class Initialized
INFO - 2016-09-23 22:29:03 --> Loader Class Initialized
INFO - 2016-09-23 22:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:03 --> Controller Class Initialized
INFO - 2016-09-23 22:29:03 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:03 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:03 --> Model Class Initialized
INFO - 2016-09-23 22:29:03 --> Model Class Initialized
INFO - 2016-09-23 22:29:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:03 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:03 --> Total execution time: 0.0942
INFO - 2016-09-23 22:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:03 --> Controller Class Initialized
INFO - 2016-09-23 22:29:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:03 --> Model Class Initialized
INFO - 2016-09-23 22:29:03 --> Model Class Initialized
INFO - 2016-09-23 22:29:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:03 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:03 --> Total execution time: 0.2122
INFO - 2016-09-23 22:29:06 --> Config Class Initialized
INFO - 2016-09-23 22:29:06 --> Config Class Initialized
INFO - 2016-09-23 22:29:06 --> Hooks Class Initialized
INFO - 2016-09-23 22:29:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 22:29:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:06 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:06 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:06 --> URI Class Initialized
INFO - 2016-09-23 22:29:06 --> URI Class Initialized
INFO - 2016-09-23 22:29:06 --> Router Class Initialized
INFO - 2016-09-23 22:29:06 --> Router Class Initialized
INFO - 2016-09-23 22:29:06 --> Output Class Initialized
INFO - 2016-09-23 22:29:06 --> Output Class Initialized
INFO - 2016-09-23 22:29:06 --> Security Class Initialized
INFO - 2016-09-23 22:29:06 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:06 --> Input Class Initialized
DEBUG - 2016-09-23 22:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:06 --> Input Class Initialized
INFO - 2016-09-23 22:29:06 --> Language Class Initialized
INFO - 2016-09-23 22:29:06 --> Language Class Initialized
INFO - 2016-09-23 22:29:06 --> Loader Class Initialized
INFO - 2016-09-23 22:29:06 --> Loader Class Initialized
INFO - 2016-09-23 22:29:06 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:06 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:06 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:06 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:06 --> Controller Class Initialized
INFO - 2016-09-23 22:29:06 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:06 --> Model Class Initialized
INFO - 2016-09-23 22:29:06 --> Model Class Initialized
INFO - 2016-09-23 22:29:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:06 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:06 --> Total execution time: 0.0727
INFO - 2016-09-23 22:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:06 --> Controller Class Initialized
INFO - 2016-09-23 22:29:06 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:06 --> Model Class Initialized
INFO - 2016-09-23 22:29:06 --> Model Class Initialized
INFO - 2016-09-23 22:29:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:06 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:06 --> Total execution time: 0.1196
INFO - 2016-09-23 22:29:07 --> Config Class Initialized
INFO - 2016-09-23 22:29:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:07 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:07 --> URI Class Initialized
INFO - 2016-09-23 22:29:07 --> Router Class Initialized
INFO - 2016-09-23 22:29:07 --> Output Class Initialized
INFO - 2016-09-23 22:29:07 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:07 --> Input Class Initialized
INFO - 2016-09-23 22:29:07 --> Language Class Initialized
ERROR - 2016-09-23 22:29:07 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:29:12 --> Config Class Initialized
INFO - 2016-09-23 22:29:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:12 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:12 --> URI Class Initialized
INFO - 2016-09-23 22:29:12 --> Router Class Initialized
INFO - 2016-09-23 22:29:12 --> Output Class Initialized
INFO - 2016-09-23 22:29:12 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:12 --> Input Class Initialized
INFO - 2016-09-23 22:29:12 --> Language Class Initialized
INFO - 2016-09-23 22:29:12 --> Loader Class Initialized
INFO - 2016-09-23 22:29:12 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:12 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:12 --> Controller Class Initialized
INFO - 2016-09-23 22:29:12 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:12 --> Model Class Initialized
INFO - 2016-09-23 22:29:12 --> Model Class Initialized
INFO - 2016-09-23 22:29:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:12 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:12 --> Total execution time: 0.0859
INFO - 2016-09-23 22:29:13 --> Config Class Initialized
INFO - 2016-09-23 22:29:13 --> Hooks Class Initialized
INFO - 2016-09-23 22:29:13 --> Config Class Initialized
INFO - 2016-09-23 22:29:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:13 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:29:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:13 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:13 --> URI Class Initialized
INFO - 2016-09-23 22:29:13 --> URI Class Initialized
INFO - 2016-09-23 22:29:13 --> Router Class Initialized
INFO - 2016-09-23 22:29:13 --> Router Class Initialized
INFO - 2016-09-23 22:29:13 --> Output Class Initialized
INFO - 2016-09-23 22:29:13 --> Output Class Initialized
INFO - 2016-09-23 22:29:13 --> Security Class Initialized
INFO - 2016-09-23 22:29:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:13 --> Input Class Initialized
INFO - 2016-09-23 22:29:13 --> Config Class Initialized
INFO - 2016-09-23 22:29:13 --> Language Class Initialized
INFO - 2016-09-23 22:29:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:13 --> Input Class Initialized
INFO - 2016-09-23 22:29:13 --> Language Class Initialized
DEBUG - 2016-09-23 22:29:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:13 --> Utf8 Class Initialized
ERROR - 2016-09-23 22:29:13 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:29:13 --> URI Class Initialized
INFO - 2016-09-23 22:29:13 --> Loader Class Initialized
INFO - 2016-09-23 22:29:13 --> Router Class Initialized
INFO - 2016-09-23 22:29:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:13 --> Output Class Initialized
INFO - 2016-09-23 22:29:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:13 --> Input Class Initialized
INFO - 2016-09-23 22:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:13 --> Controller Class Initialized
INFO - 2016-09-23 22:29:13 --> Language Class Initialized
INFO - 2016-09-23 22:29:13 --> Loader Class Initialized
INFO - 2016-09-23 22:29:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:13 --> Model Class Initialized
INFO - 2016-09-23 22:29:13 --> Model Class Initialized
INFO - 2016-09-23 22:29:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:13 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:13 --> Total execution time: 0.1227
INFO - 2016-09-23 22:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:13 --> Controller Class Initialized
INFO - 2016-09-23 22:29:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:13 --> Model Class Initialized
INFO - 2016-09-23 22:29:13 --> Model Class Initialized
INFO - 2016-09-23 22:29:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:13 --> Config Class Initialized
INFO - 2016-09-23 22:29:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:13 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:13 --> URI Class Initialized
INFO - 2016-09-23 22:29:13 --> Router Class Initialized
INFO - 2016-09-23 22:29:13 --> Output Class Initialized
INFO - 2016-09-23 22:29:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:13 --> Input Class Initialized
INFO - 2016-09-23 22:29:13 --> Language Class Initialized
INFO - 2016-09-23 22:29:13 --> Loader Class Initialized
INFO - 2016-09-23 22:29:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:13 --> Controller Class Initialized
INFO - 2016-09-23 22:29:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:13 --> Model Class Initialized
INFO - 2016-09-23 22:29:13 --> Model Class Initialized
INFO - 2016-09-23 22:29:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:29:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:29:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:29:13 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:13 --> Total execution time: 0.0791
INFO - 2016-09-23 22:29:35 --> Config Class Initialized
INFO - 2016-09-23 22:29:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:35 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:35 --> URI Class Initialized
INFO - 2016-09-23 22:29:35 --> Router Class Initialized
INFO - 2016-09-23 22:29:35 --> Output Class Initialized
INFO - 2016-09-23 22:29:35 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:35 --> Input Class Initialized
INFO - 2016-09-23 22:29:35 --> Language Class Initialized
INFO - 2016-09-23 22:29:35 --> Loader Class Initialized
INFO - 2016-09-23 22:29:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:35 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:35 --> Controller Class Initialized
INFO - 2016-09-23 22:29:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:35 --> Config Class Initialized
INFO - 2016-09-23 22:29:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:35 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:35 --> URI Class Initialized
INFO - 2016-09-23 22:29:35 --> Router Class Initialized
INFO - 2016-09-23 22:29:35 --> Output Class Initialized
INFO - 2016-09-23 22:29:35 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:35 --> Input Class Initialized
INFO - 2016-09-23 22:29:35 --> Language Class Initialized
INFO - 2016-09-23 22:29:35 --> Loader Class Initialized
INFO - 2016-09-23 22:29:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:35 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:35 --> Controller Class Initialized
INFO - 2016-09-23 22:29:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:29:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-23 22:29:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:29:35 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:35 --> Total execution time: 0.0643
INFO - 2016-09-23 22:29:35 --> Config Class Initialized
INFO - 2016-09-23 22:29:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:35 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:35 --> URI Class Initialized
INFO - 2016-09-23 22:29:35 --> Router Class Initialized
INFO - 2016-09-23 22:29:35 --> Output Class Initialized
INFO - 2016-09-23 22:29:35 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:35 --> Input Class Initialized
INFO - 2016-09-23 22:29:35 --> Language Class Initialized
INFO - 2016-09-23 22:29:35 --> Loader Class Initialized
INFO - 2016-09-23 22:29:35 --> Config Class Initialized
INFO - 2016-09-23 22:29:35 --> Hooks Class Initialized
INFO - 2016-09-23 22:29:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:35 --> Helper loaded: language_helper
DEBUG - 2016-09-23 22:29:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:35 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:35 --> URI Class Initialized
INFO - 2016-09-23 22:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:35 --> Controller Class Initialized
INFO - 2016-09-23 22:29:35 --> Router Class Initialized
INFO - 2016-09-23 22:29:35 --> Output Class Initialized
INFO - 2016-09-23 22:29:35 --> Security Class Initialized
DEBUG - 2016-09-23 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:35 --> Input Class Initialized
INFO - 2016-09-23 22:29:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:35 --> Language Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Loader Class Initialized
INFO - 2016-09-23 22:29:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:35 --> Final output sent to browser
INFO - 2016-09-23 22:29:35 --> Helper loaded: language_helper
DEBUG - 2016-09-23 22:29:35 --> Total execution time: 0.0855
INFO - 2016-09-23 22:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:35 --> Controller Class Initialized
INFO - 2016-09-23 22:29:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Model Class Initialized
INFO - 2016-09-23 22:29:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:29:35 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:29:35 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:35 --> Total execution time: 0.1014
INFO - 2016-09-23 22:29:47 --> Config Class Initialized
INFO - 2016-09-23 22:29:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:47 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:47 --> URI Class Initialized
INFO - 2016-09-23 22:29:47 --> Config Class Initialized
INFO - 2016-09-23 22:29:47 --> Hooks Class Initialized
INFO - 2016-09-23 22:29:47 --> Router Class Initialized
DEBUG - 2016-09-23 22:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:29:47 --> Utf8 Class Initialized
INFO - 2016-09-23 22:29:47 --> URI Class Initialized
INFO - 2016-09-23 22:29:47 --> Output Class Initialized
INFO - 2016-09-23 22:29:47 --> Router Class Initialized
INFO - 2016-09-23 22:29:47 --> Security Class Initialized
INFO - 2016-09-23 22:29:47 --> Output Class Initialized
DEBUG - 2016-09-23 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:47 --> Input Class Initialized
INFO - 2016-09-23 22:29:47 --> Security Class Initialized
INFO - 2016-09-23 22:29:47 --> Language Class Initialized
DEBUG - 2016-09-23 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:29:47 --> Input Class Initialized
INFO - 2016-09-23 22:29:47 --> Language Class Initialized
INFO - 2016-09-23 22:29:47 --> Loader Class Initialized
INFO - 2016-09-23 22:29:47 --> Loader Class Initialized
INFO - 2016-09-23 22:29:47 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:47 --> Helper loaded: url_helper
INFO - 2016-09-23 22:29:47 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:47 --> Helper loaded: language_helper
INFO - 2016-09-23 22:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:47 --> Controller Class Initialized
INFO - 2016-09-23 22:29:47 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:47 --> Model Class Initialized
INFO - 2016-09-23 22:29:47 --> Model Class Initialized
INFO - 2016-09-23 22:29:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:47 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:47 --> Total execution time: 0.0837
INFO - 2016-09-23 22:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:29:47 --> Controller Class Initialized
INFO - 2016-09-23 22:29:47 --> Database Driver Class Initialized
INFO - 2016-09-23 22:29:47 --> Model Class Initialized
INFO - 2016-09-23 22:29:47 --> Model Class Initialized
INFO - 2016-09-23 22:29:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:29:47 --> Final output sent to browser
DEBUG - 2016-09-23 22:29:47 --> Total execution time: 0.1078
INFO - 2016-09-23 22:30:05 --> Config Class Initialized
INFO - 2016-09-23 22:30:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:05 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:05 --> URI Class Initialized
INFO - 2016-09-23 22:30:05 --> Router Class Initialized
INFO - 2016-09-23 22:30:05 --> Output Class Initialized
INFO - 2016-09-23 22:30:05 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:05 --> Input Class Initialized
INFO - 2016-09-23 22:30:05 --> Language Class Initialized
INFO - 2016-09-23 22:30:05 --> Loader Class Initialized
INFO - 2016-09-23 22:30:05 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:05 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:05 --> Controller Class Initialized
INFO - 2016-09-23 22:30:05 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:05 --> Model Class Initialized
INFO - 2016-09-23 22:30:05 --> Model Class Initialized
INFO - 2016-09-23 22:30:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:05 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:05 --> Total execution time: 0.0785
INFO - 2016-09-23 22:30:11 --> Config Class Initialized
INFO - 2016-09-23 22:30:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:11 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:11 --> URI Class Initialized
INFO - 2016-09-23 22:30:11 --> Config Class Initialized
INFO - 2016-09-23 22:30:11 --> Hooks Class Initialized
INFO - 2016-09-23 22:30:11 --> Router Class Initialized
INFO - 2016-09-23 22:30:11 --> Output Class Initialized
DEBUG - 2016-09-23 22:30:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:11 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:11 --> Security Class Initialized
INFO - 2016-09-23 22:30:11 --> URI Class Initialized
DEBUG - 2016-09-23 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:11 --> Input Class Initialized
INFO - 2016-09-23 22:30:11 --> Router Class Initialized
INFO - 2016-09-23 22:30:11 --> Language Class Initialized
INFO - 2016-09-23 22:30:11 --> Output Class Initialized
INFO - 2016-09-23 22:30:11 --> Security Class Initialized
INFO - 2016-09-23 22:30:11 --> Loader Class Initialized
DEBUG - 2016-09-23 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:11 --> Input Class Initialized
INFO - 2016-09-23 22:30:11 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:11 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:11 --> Language Class Initialized
INFO - 2016-09-23 22:30:11 --> Loader Class Initialized
INFO - 2016-09-23 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:11 --> Controller Class Initialized
INFO - 2016-09-23 22:30:11 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:11 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:11 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:11 --> Model Class Initialized
INFO - 2016-09-23 22:30:11 --> Model Class Initialized
INFO - 2016-09-23 22:30:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:11 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:11 --> Total execution time: 0.0752
INFO - 2016-09-23 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:11 --> Controller Class Initialized
INFO - 2016-09-23 22:30:11 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:11 --> Model Class Initialized
INFO - 2016-09-23 22:30:11 --> Model Class Initialized
INFO - 2016-09-23 22:30:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:11 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:11 --> Total execution time: 0.1045
INFO - 2016-09-23 22:30:27 --> Config Class Initialized
INFO - 2016-09-23 22:30:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:27 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:27 --> URI Class Initialized
INFO - 2016-09-23 22:30:27 --> Config Class Initialized
INFO - 2016-09-23 22:30:27 --> Router Class Initialized
INFO - 2016-09-23 22:30:27 --> Hooks Class Initialized
INFO - 2016-09-23 22:30:27 --> Output Class Initialized
INFO - 2016-09-23 22:30:27 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:27 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:27 --> URI Class Initialized
DEBUG - 2016-09-23 22:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:27 --> Input Class Initialized
INFO - 2016-09-23 22:30:27 --> Language Class Initialized
INFO - 2016-09-23 22:30:27 --> Router Class Initialized
INFO - 2016-09-23 22:30:27 --> Output Class Initialized
INFO - 2016-09-23 22:30:27 --> Loader Class Initialized
INFO - 2016-09-23 22:30:27 --> Security Class Initialized
INFO - 2016-09-23 22:30:27 --> Helper loaded: url_helper
DEBUG - 2016-09-23 22:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:27 --> Input Class Initialized
INFO - 2016-09-23 22:30:27 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:27 --> Language Class Initialized
INFO - 2016-09-23 22:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:27 --> Controller Class Initialized
INFO - 2016-09-23 22:30:27 --> Loader Class Initialized
INFO - 2016-09-23 22:30:27 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:27 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:27 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:27 --> Model Class Initialized
INFO - 2016-09-23 22:30:27 --> Model Class Initialized
INFO - 2016-09-23 22:30:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:27 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:27 --> Total execution time: 0.0924
INFO - 2016-09-23 22:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:27 --> Controller Class Initialized
INFO - 2016-09-23 22:30:27 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:27 --> Model Class Initialized
INFO - 2016-09-23 22:30:27 --> Model Class Initialized
INFO - 2016-09-23 22:30:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:27 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:27 --> Total execution time: 0.1060
INFO - 2016-09-23 22:30:30 --> Config Class Initialized
INFO - 2016-09-23 22:30:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:30 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:30 --> URI Class Initialized
INFO - 2016-09-23 22:30:30 --> Config Class Initialized
INFO - 2016-09-23 22:30:30 --> Hooks Class Initialized
INFO - 2016-09-23 22:30:30 --> Router Class Initialized
INFO - 2016-09-23 22:30:30 --> Output Class Initialized
DEBUG - 2016-09-23 22:30:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:30 --> Security Class Initialized
INFO - 2016-09-23 22:30:30 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:30 --> URI Class Initialized
DEBUG - 2016-09-23 22:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:30 --> Input Class Initialized
INFO - 2016-09-23 22:30:30 --> Language Class Initialized
INFO - 2016-09-23 22:30:30 --> Router Class Initialized
INFO - 2016-09-23 22:30:30 --> Output Class Initialized
INFO - 2016-09-23 22:30:30 --> Loader Class Initialized
INFO - 2016-09-23 22:30:30 --> Security Class Initialized
INFO - 2016-09-23 22:30:30 --> Helper loaded: url_helper
DEBUG - 2016-09-23 22:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:30 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:30 --> Input Class Initialized
INFO - 2016-09-23 22:30:30 --> Language Class Initialized
INFO - 2016-09-23 22:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:30 --> Controller Class Initialized
INFO - 2016-09-23 22:30:30 --> Loader Class Initialized
INFO - 2016-09-23 22:30:30 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:30 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:30 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:30 --> Model Class Initialized
INFO - 2016-09-23 22:30:30 --> Model Class Initialized
INFO - 2016-09-23 22:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:30 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:30 --> Total execution time: 0.0868
INFO - 2016-09-23 22:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:30 --> Controller Class Initialized
INFO - 2016-09-23 22:30:30 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:30 --> Model Class Initialized
INFO - 2016-09-23 22:30:30 --> Model Class Initialized
INFO - 2016-09-23 22:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:30 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:30 --> Total execution time: 0.1136
INFO - 2016-09-23 22:30:33 --> Config Class Initialized
INFO - 2016-09-23 22:30:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:33 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:33 --> URI Class Initialized
INFO - 2016-09-23 22:30:33 --> Router Class Initialized
INFO - 2016-09-23 22:30:33 --> Output Class Initialized
INFO - 2016-09-23 22:30:33 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:33 --> Input Class Initialized
INFO - 2016-09-23 22:30:33 --> Language Class Initialized
INFO - 2016-09-23 22:30:33 --> Loader Class Initialized
INFO - 2016-09-23 22:30:33 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:33 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:33 --> Controller Class Initialized
INFO - 2016-09-23 22:30:33 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:33 --> Model Class Initialized
INFO - 2016-09-23 22:30:33 --> Model Class Initialized
INFO - 2016-09-23 22:30:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:33 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:33 --> Total execution time: 0.0836
INFO - 2016-09-23 22:30:35 --> Config Class Initialized
INFO - 2016-09-23 22:30:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:35 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:35 --> URI Class Initialized
INFO - 2016-09-23 22:30:35 --> Router Class Initialized
INFO - 2016-09-23 22:30:35 --> Config Class Initialized
INFO - 2016-09-23 22:30:35 --> Hooks Class Initialized
INFO - 2016-09-23 22:30:35 --> Output Class Initialized
INFO - 2016-09-23 22:30:35 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:35 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:35 --> Input Class Initialized
INFO - 2016-09-23 22:30:35 --> URI Class Initialized
INFO - 2016-09-23 22:30:35 --> Language Class Initialized
INFO - 2016-09-23 22:30:35 --> Router Class Initialized
INFO - 2016-09-23 22:30:35 --> Loader Class Initialized
INFO - 2016-09-23 22:30:35 --> Output Class Initialized
INFO - 2016-09-23 22:30:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:35 --> Security Class Initialized
INFO - 2016-09-23 22:30:35 --> Helper loaded: language_helper
DEBUG - 2016-09-23 22:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:35 --> Input Class Initialized
INFO - 2016-09-23 22:30:35 --> Language Class Initialized
INFO - 2016-09-23 22:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:35 --> Controller Class Initialized
INFO - 2016-09-23 22:30:35 --> Loader Class Initialized
INFO - 2016-09-23 22:30:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:35 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:35 --> Model Class Initialized
INFO - 2016-09-23 22:30:35 --> Model Class Initialized
INFO - 2016-09-23 22:30:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:35 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:35 --> Total execution time: 0.0756
INFO - 2016-09-23 22:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:35 --> Controller Class Initialized
INFO - 2016-09-23 22:30:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:35 --> Model Class Initialized
INFO - 2016-09-23 22:30:35 --> Model Class Initialized
INFO - 2016-09-23 22:30:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:35 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:35 --> Total execution time: 0.1245
INFO - 2016-09-23 22:30:35 --> Config Class Initialized
INFO - 2016-09-23 22:30:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:35 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:35 --> URI Class Initialized
INFO - 2016-09-23 22:30:35 --> Router Class Initialized
INFO - 2016-09-23 22:30:35 --> Output Class Initialized
INFO - 2016-09-23 22:30:35 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:35 --> Input Class Initialized
INFO - 2016-09-23 22:30:35 --> Language Class Initialized
INFO - 2016-09-23 22:30:35 --> Loader Class Initialized
INFO - 2016-09-23 22:30:35 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:35 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:35 --> Controller Class Initialized
INFO - 2016-09-23 22:30:35 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:35 --> Model Class Initialized
INFO - 2016-09-23 22:30:35 --> Model Class Initialized
INFO - 2016-09-23 22:30:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:35 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:35 --> Total execution time: 0.0700
INFO - 2016-09-23 22:30:38 --> Config Class Initialized
INFO - 2016-09-23 22:30:38 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:38 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:38 --> URI Class Initialized
INFO - 2016-09-23 22:30:38 --> Router Class Initialized
INFO - 2016-09-23 22:30:38 --> Output Class Initialized
INFO - 2016-09-23 22:30:38 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:38 --> Input Class Initialized
INFO - 2016-09-23 22:30:38 --> Language Class Initialized
INFO - 2016-09-23 22:30:38 --> Loader Class Initialized
INFO - 2016-09-23 22:30:38 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:38 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:38 --> Controller Class Initialized
INFO - 2016-09-23 22:30:38 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:38 --> Model Class Initialized
INFO - 2016-09-23 22:30:38 --> Model Class Initialized
INFO - 2016-09-23 22:30:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:38 --> Config Class Initialized
INFO - 2016-09-23 22:30:38 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:30:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:30:38 --> Utf8 Class Initialized
INFO - 2016-09-23 22:30:38 --> URI Class Initialized
INFO - 2016-09-23 22:30:38 --> Router Class Initialized
INFO - 2016-09-23 22:30:38 --> Output Class Initialized
INFO - 2016-09-23 22:30:38 --> Security Class Initialized
DEBUG - 2016-09-23 22:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:30:38 --> Input Class Initialized
INFO - 2016-09-23 22:30:38 --> Language Class Initialized
INFO - 2016-09-23 22:30:38 --> Loader Class Initialized
INFO - 2016-09-23 22:30:38 --> Helper loaded: url_helper
INFO - 2016-09-23 22:30:38 --> Helper loaded: language_helper
INFO - 2016-09-23 22:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:30:38 --> Controller Class Initialized
INFO - 2016-09-23 22:30:38 --> Database Driver Class Initialized
INFO - 2016-09-23 22:30:38 --> Model Class Initialized
INFO - 2016-09-23 22:30:38 --> Model Class Initialized
INFO - 2016-09-23 22:30:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:30:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:30:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-23 22:30:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:30:38 --> Final output sent to browser
DEBUG - 2016-09-23 22:30:38 --> Total execution time: 0.0618
INFO - 2016-09-23 22:40:06 --> Config Class Initialized
INFO - 2016-09-23 22:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:06 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:06 --> URI Class Initialized
INFO - 2016-09-23 22:40:06 --> Router Class Initialized
INFO - 2016-09-23 22:40:06 --> Output Class Initialized
INFO - 2016-09-23 22:40:06 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:06 --> Input Class Initialized
INFO - 2016-09-23 22:40:06 --> Language Class Initialized
INFO - 2016-09-23 22:40:06 --> Loader Class Initialized
INFO - 2016-09-23 22:40:06 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:06 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:06 --> Controller Class Initialized
INFO - 2016-09-23 22:40:06 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:06 --> Model Class Initialized
INFO - 2016-09-23 22:40:06 --> Model Class Initialized
INFO - 2016-09-23 22:40:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:40:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:40:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:40:06 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:06 --> Total execution time: 0.0619
INFO - 2016-09-23 22:40:06 --> Config Class Initialized
INFO - 2016-09-23 22:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:06 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:06 --> URI Class Initialized
INFO - 2016-09-23 22:40:06 --> Router Class Initialized
INFO - 2016-09-23 22:40:06 --> Output Class Initialized
INFO - 2016-09-23 22:40:06 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:06 --> Input Class Initialized
INFO - 2016-09-23 22:40:06 --> Language Class Initialized
INFO - 2016-09-23 22:40:06 --> Loader Class Initialized
INFO - 2016-09-23 22:40:06 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:06 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:06 --> Controller Class Initialized
INFO - 2016-09-23 22:40:06 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:06 --> Model Class Initialized
INFO - 2016-09-23 22:40:06 --> Model Class Initialized
INFO - 2016-09-23 22:40:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:40:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:40:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:40:06 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:06 --> Total execution time: 0.0755
INFO - 2016-09-23 22:40:08 --> Config Class Initialized
INFO - 2016-09-23 22:40:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:08 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:08 --> URI Class Initialized
INFO - 2016-09-23 22:40:08 --> Router Class Initialized
INFO - 2016-09-23 22:40:08 --> Output Class Initialized
INFO - 2016-09-23 22:40:08 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:08 --> Input Class Initialized
INFO - 2016-09-23 22:40:08 --> Language Class Initialized
INFO - 2016-09-23 22:40:08 --> Loader Class Initialized
INFO - 2016-09-23 22:40:08 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:08 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:08 --> Controller Class Initialized
INFO - 2016-09-23 22:40:08 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:08 --> Model Class Initialized
INFO - 2016-09-23 22:40:08 --> Model Class Initialized
INFO - 2016-09-23 22:40:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:40:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 22:40:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:40:08 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:08 --> Total execution time: 0.0743
INFO - 2016-09-23 22:40:11 --> Config Class Initialized
INFO - 2016-09-23 22:40:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:11 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:11 --> URI Class Initialized
INFO - 2016-09-23 22:40:11 --> Router Class Initialized
INFO - 2016-09-23 22:40:11 --> Output Class Initialized
INFO - 2016-09-23 22:40:11 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:11 --> Input Class Initialized
INFO - 2016-09-23 22:40:11 --> Language Class Initialized
INFO - 2016-09-23 22:40:11 --> Loader Class Initialized
INFO - 2016-09-23 22:40:11 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:11 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:11 --> Controller Class Initialized
INFO - 2016-09-23 22:40:11 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:11 --> Model Class Initialized
INFO - 2016-09-23 22:40:11 --> Model Class Initialized
INFO - 2016-09-23 22:40:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:11 --> Config Class Initialized
INFO - 2016-09-23 22:40:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:11 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:11 --> URI Class Initialized
INFO - 2016-09-23 22:40:11 --> Router Class Initialized
INFO - 2016-09-23 22:40:11 --> Output Class Initialized
INFO - 2016-09-23 22:40:11 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:11 --> Input Class Initialized
INFO - 2016-09-23 22:40:11 --> Language Class Initialized
INFO - 2016-09-23 22:40:11 --> Loader Class Initialized
INFO - 2016-09-23 22:40:11 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:11 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:11 --> Controller Class Initialized
INFO - 2016-09-23 22:40:11 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:11 --> Model Class Initialized
INFO - 2016-09-23 22:40:11 --> Model Class Initialized
INFO - 2016-09-23 22:40:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 22:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:40:11 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:11 --> Total execution time: 0.0683
INFO - 2016-09-23 22:40:12 --> Config Class Initialized
INFO - 2016-09-23 22:40:12 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:12 --> Config Class Initialized
INFO - 2016-09-23 22:40:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:12 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:12 --> URI Class Initialized
DEBUG - 2016-09-23 22:40:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:12 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:12 --> Router Class Initialized
INFO - 2016-09-23 22:40:12 --> URI Class Initialized
INFO - 2016-09-23 22:40:12 --> Router Class Initialized
INFO - 2016-09-23 22:40:12 --> Output Class Initialized
INFO - 2016-09-23 22:40:12 --> Output Class Initialized
INFO - 2016-09-23 22:40:12 --> Security Class Initialized
INFO - 2016-09-23 22:40:12 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:12 --> Input Class Initialized
DEBUG - 2016-09-23 22:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:12 --> Input Class Initialized
INFO - 2016-09-23 22:40:12 --> Language Class Initialized
INFO - 2016-09-23 22:40:12 --> Language Class Initialized
INFO - 2016-09-23 22:40:12 --> Loader Class Initialized
INFO - 2016-09-23 22:40:12 --> Loader Class Initialized
INFO - 2016-09-23 22:40:12 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:12 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:12 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:12 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:12 --> Controller Class Initialized
INFO - 2016-09-23 22:40:12 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:12 --> Model Class Initialized
INFO - 2016-09-23 22:40:12 --> Model Class Initialized
INFO - 2016-09-23 22:40:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:12 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:12 --> Total execution time: 0.0875
INFO - 2016-09-23 22:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:12 --> Controller Class Initialized
INFO - 2016-09-23 22:40:12 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:12 --> Model Class Initialized
INFO - 2016-09-23 22:40:12 --> Model Class Initialized
INFO - 2016-09-23 22:40:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:40:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:40:12 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:12 --> Total execution time: 0.1156
INFO - 2016-09-23 22:40:19 --> Config Class Initialized
INFO - 2016-09-23 22:40:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:19 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:19 --> URI Class Initialized
INFO - 2016-09-23 22:40:19 --> Router Class Initialized
INFO - 2016-09-23 22:40:19 --> Output Class Initialized
INFO - 2016-09-23 22:40:19 --> Security Class Initialized
INFO - 2016-09-23 22:40:19 --> Config Class Initialized
INFO - 2016-09-23 22:40:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:19 --> Input Class Initialized
INFO - 2016-09-23 22:40:19 --> Language Class Initialized
DEBUG - 2016-09-23 22:40:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:19 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:19 --> Loader Class Initialized
INFO - 2016-09-23 22:40:19 --> URI Class Initialized
INFO - 2016-09-23 22:40:19 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:19 --> Router Class Initialized
INFO - 2016-09-23 22:40:19 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:19 --> Output Class Initialized
INFO - 2016-09-23 22:40:19 --> Security Class Initialized
INFO - 2016-09-23 22:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:19 --> Controller Class Initialized
DEBUG - 2016-09-23 22:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:19 --> Input Class Initialized
INFO - 2016-09-23 22:40:19 --> Language Class Initialized
INFO - 2016-09-23 22:40:19 --> Loader Class Initialized
INFO - 2016-09-23 22:40:19 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:19 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:19 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:19 --> Model Class Initialized
INFO - 2016-09-23 22:40:19 --> Model Class Initialized
INFO - 2016-09-23 22:40:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:19 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:19 --> Total execution time: 0.0809
INFO - 2016-09-23 22:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:19 --> Controller Class Initialized
INFO - 2016-09-23 22:40:19 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:19 --> Model Class Initialized
INFO - 2016-09-23 22:40:19 --> Model Class Initialized
INFO - 2016-09-23 22:40:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:19 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:19 --> Total execution time: 0.0925
INFO - 2016-09-23 22:40:22 --> Config Class Initialized
INFO - 2016-09-23 22:40:22 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:22 --> Config Class Initialized
INFO - 2016-09-23 22:40:22 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:22 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:22 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:22 --> URI Class Initialized
DEBUG - 2016-09-23 22:40:22 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:22 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:22 --> Router Class Initialized
INFO - 2016-09-23 22:40:22 --> URI Class Initialized
INFO - 2016-09-23 22:40:22 --> Output Class Initialized
INFO - 2016-09-23 22:40:22 --> Router Class Initialized
INFO - 2016-09-23 22:40:22 --> Output Class Initialized
INFO - 2016-09-23 22:40:22 --> Security Class Initialized
INFO - 2016-09-23 22:40:22 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:22 --> Input Class Initialized
INFO - 2016-09-23 22:40:22 --> Language Class Initialized
DEBUG - 2016-09-23 22:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:22 --> Input Class Initialized
INFO - 2016-09-23 22:40:22 --> Language Class Initialized
INFO - 2016-09-23 22:40:22 --> Loader Class Initialized
INFO - 2016-09-23 22:40:22 --> Loader Class Initialized
INFO - 2016-09-23 22:40:22 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:22 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:22 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:22 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:22 --> Controller Class Initialized
INFO - 2016-09-23 22:40:22 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:22 --> Model Class Initialized
INFO - 2016-09-23 22:40:22 --> Model Class Initialized
INFO - 2016-09-23 22:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:22 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:22 --> Total execution time: 0.0756
INFO - 2016-09-23 22:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:22 --> Controller Class Initialized
INFO - 2016-09-23 22:40:22 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:22 --> Model Class Initialized
INFO - 2016-09-23 22:40:22 --> Model Class Initialized
INFO - 2016-09-23 22:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:22 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:22 --> Total execution time: 0.1054
INFO - 2016-09-23 22:40:24 --> Config Class Initialized
INFO - 2016-09-23 22:40:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:24 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:24 --> URI Class Initialized
INFO - 2016-09-23 22:40:24 --> Router Class Initialized
INFO - 2016-09-23 22:40:24 --> Output Class Initialized
INFO - 2016-09-23 22:40:24 --> Security Class Initialized
INFO - 2016-09-23 22:40:24 --> Config Class Initialized
INFO - 2016-09-23 22:40:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:24 --> Input Class Initialized
INFO - 2016-09-23 22:40:24 --> Language Class Initialized
DEBUG - 2016-09-23 22:40:24 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:24 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:24 --> URI Class Initialized
INFO - 2016-09-23 22:40:24 --> Loader Class Initialized
INFO - 2016-09-23 22:40:24 --> Router Class Initialized
INFO - 2016-09-23 22:40:24 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:25 --> Output Class Initialized
INFO - 2016-09-23 22:40:25 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:25 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:25 --> Input Class Initialized
INFO - 2016-09-23 22:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:25 --> Language Class Initialized
INFO - 2016-09-23 22:40:25 --> Controller Class Initialized
INFO - 2016-09-23 22:40:25 --> Loader Class Initialized
INFO - 2016-09-23 22:40:25 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:25 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:25 --> Model Class Initialized
INFO - 2016-09-23 22:40:25 --> Model Class Initialized
INFO - 2016-09-23 22:40:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:25 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:25 --> Total execution time: 0.0735
INFO - 2016-09-23 22:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:25 --> Controller Class Initialized
INFO - 2016-09-23 22:40:25 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:25 --> Model Class Initialized
INFO - 2016-09-23 22:40:25 --> Model Class Initialized
INFO - 2016-09-23 22:40:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:25 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:25 --> Total execution time: 0.1065
INFO - 2016-09-23 22:40:27 --> Config Class Initialized
INFO - 2016-09-23 22:40:27 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:27 --> Config Class Initialized
INFO - 2016-09-23 22:40:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:27 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:40:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:27 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:27 --> URI Class Initialized
INFO - 2016-09-23 22:40:27 --> URI Class Initialized
INFO - 2016-09-23 22:40:27 --> Router Class Initialized
INFO - 2016-09-23 22:40:27 --> Router Class Initialized
INFO - 2016-09-23 22:40:27 --> Output Class Initialized
INFO - 2016-09-23 22:40:27 --> Output Class Initialized
INFO - 2016-09-23 22:40:27 --> Security Class Initialized
INFO - 2016-09-23 22:40:27 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:27 --> Input Class Initialized
DEBUG - 2016-09-23 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:27 --> Input Class Initialized
INFO - 2016-09-23 22:40:27 --> Language Class Initialized
INFO - 2016-09-23 22:40:27 --> Language Class Initialized
INFO - 2016-09-23 22:40:27 --> Loader Class Initialized
INFO - 2016-09-23 22:40:27 --> Loader Class Initialized
INFO - 2016-09-23 22:40:27 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:27 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:27 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:27 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:27 --> Controller Class Initialized
INFO - 2016-09-23 22:40:27 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:27 --> Model Class Initialized
INFO - 2016-09-23 22:40:27 --> Model Class Initialized
INFO - 2016-09-23 22:40:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:27 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:27 --> Total execution time: 0.0756
INFO - 2016-09-23 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:27 --> Controller Class Initialized
INFO - 2016-09-23 22:40:27 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:27 --> Model Class Initialized
INFO - 2016-09-23 22:40:27 --> Model Class Initialized
INFO - 2016-09-23 22:40:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:27 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:27 --> Total execution time: 0.1192
INFO - 2016-09-23 22:40:30 --> Config Class Initialized
INFO - 2016-09-23 22:40:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:30 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:30 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:30 --> URI Class Initialized
INFO - 2016-09-23 22:40:30 --> Router Class Initialized
INFO - 2016-09-23 22:40:30 --> Output Class Initialized
INFO - 2016-09-23 22:40:30 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:30 --> Input Class Initialized
INFO - 2016-09-23 22:40:30 --> Language Class Initialized
INFO - 2016-09-23 22:40:30 --> Loader Class Initialized
INFO - 2016-09-23 22:40:30 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:30 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:30 --> Controller Class Initialized
INFO - 2016-09-23 22:40:30 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:30 --> Model Class Initialized
INFO - 2016-09-23 22:40:30 --> Model Class Initialized
INFO - 2016-09-23 22:40:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:30 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:30 --> Total execution time: 0.0886
INFO - 2016-09-23 22:40:32 --> Config Class Initialized
INFO - 2016-09-23 22:40:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:32 --> URI Class Initialized
INFO - 2016-09-23 22:40:32 --> Router Class Initialized
INFO - 2016-09-23 22:40:32 --> Config Class Initialized
INFO - 2016-09-23 22:40:32 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:32 --> Output Class Initialized
INFO - 2016-09-23 22:40:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:32 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:32 --> Input Class Initialized
INFO - 2016-09-23 22:40:32 --> URI Class Initialized
INFO - 2016-09-23 22:40:32 --> Language Class Initialized
INFO - 2016-09-23 22:40:32 --> Router Class Initialized
INFO - 2016-09-23 22:40:32 --> Config Class Initialized
INFO - 2016-09-23 22:40:32 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:32 --> Output Class Initialized
INFO - 2016-09-23 22:40:32 --> Loader Class Initialized
INFO - 2016-09-23 22:40:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:32 --> Helper loaded: url_helper
DEBUG - 2016-09-23 22:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:32 --> Input Class Initialized
INFO - 2016-09-23 22:40:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:32 --> URI Class Initialized
INFO - 2016-09-23 22:40:32 --> Language Class Initialized
INFO - 2016-09-23 22:40:32 --> Router Class Initialized
INFO - 2016-09-23 22:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:32 --> Controller Class Initialized
INFO - 2016-09-23 22:40:32 --> Output Class Initialized
INFO - 2016-09-23 22:40:32 --> Loader Class Initialized
INFO - 2016-09-23 22:40:32 --> Security Class Initialized
INFO - 2016-09-23 22:40:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:32 --> Helper loaded: language_helper
DEBUG - 2016-09-23 22:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:32 --> Input Class Initialized
INFO - 2016-09-23 22:40:32 --> Language Class Initialized
ERROR - 2016-09-23 22:40:32 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:40:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:32 --> Model Class Initialized
INFO - 2016-09-23 22:40:32 --> Model Class Initialized
INFO - 2016-09-23 22:40:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:32 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:32 --> Total execution time: 0.1130
INFO - 2016-09-23 22:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:32 --> Controller Class Initialized
INFO - 2016-09-23 22:40:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:32 --> Model Class Initialized
INFO - 2016-09-23 22:40:32 --> Model Class Initialized
INFO - 2016-09-23 22:40:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:32 --> Config Class Initialized
INFO - 2016-09-23 22:40:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:32 --> URI Class Initialized
INFO - 2016-09-23 22:40:32 --> Router Class Initialized
INFO - 2016-09-23 22:40:32 --> Output Class Initialized
INFO - 2016-09-23 22:40:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:32 --> Input Class Initialized
INFO - 2016-09-23 22:40:32 --> Language Class Initialized
INFO - 2016-09-23 22:40:32 --> Loader Class Initialized
INFO - 2016-09-23 22:40:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:32 --> Controller Class Initialized
INFO - 2016-09-23 22:40:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:32 --> Model Class Initialized
INFO - 2016-09-23 22:40:32 --> Model Class Initialized
INFO - 2016-09-23 22:40:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:40:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:40:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:40:32 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:32 --> Total execution time: 0.0864
INFO - 2016-09-23 22:40:36 --> Config Class Initialized
INFO - 2016-09-23 22:40:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:36 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:36 --> URI Class Initialized
INFO - 2016-09-23 22:40:36 --> Router Class Initialized
INFO - 2016-09-23 22:40:36 --> Output Class Initialized
INFO - 2016-09-23 22:40:36 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:36 --> Input Class Initialized
INFO - 2016-09-23 22:40:36 --> Language Class Initialized
INFO - 2016-09-23 22:40:36 --> Loader Class Initialized
INFO - 2016-09-23 22:40:36 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:36 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:36 --> Controller Class Initialized
INFO - 2016-09-23 22:40:36 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:36 --> Model Class Initialized
INFO - 2016-09-23 22:40:36 --> Model Class Initialized
INFO - 2016-09-23 22:40:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:36 --> Config Class Initialized
INFO - 2016-09-23 22:40:36 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:36 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:36 --> URI Class Initialized
INFO - 2016-09-23 22:40:36 --> Router Class Initialized
INFO - 2016-09-23 22:40:36 --> Output Class Initialized
INFO - 2016-09-23 22:40:36 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:36 --> Input Class Initialized
INFO - 2016-09-23 22:40:36 --> Language Class Initialized
INFO - 2016-09-23 22:40:36 --> Loader Class Initialized
INFO - 2016-09-23 22:40:36 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:36 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:36 --> Controller Class Initialized
INFO - 2016-09-23 22:40:36 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:36 --> Model Class Initialized
INFO - 2016-09-23 22:40:36 --> Model Class Initialized
INFO - 2016-09-23 22:40:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:40:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-23 22:40:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:40:36 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:36 --> Total execution time: 0.0616
INFO - 2016-09-23 22:40:37 --> Config Class Initialized
INFO - 2016-09-23 22:40:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:37 --> URI Class Initialized
INFO - 2016-09-23 22:40:37 --> Config Class Initialized
INFO - 2016-09-23 22:40:37 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:37 --> Router Class Initialized
INFO - 2016-09-23 22:40:37 --> Output Class Initialized
DEBUG - 2016-09-23 22:40:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:37 --> URI Class Initialized
INFO - 2016-09-23 22:40:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:37 --> Input Class Initialized
INFO - 2016-09-23 22:40:37 --> Router Class Initialized
INFO - 2016-09-23 22:40:37 --> Language Class Initialized
INFO - 2016-09-23 22:40:37 --> Output Class Initialized
INFO - 2016-09-23 22:40:37 --> Security Class Initialized
INFO - 2016-09-23 22:40:37 --> Loader Class Initialized
DEBUG - 2016-09-23 22:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:37 --> Input Class Initialized
INFO - 2016-09-23 22:40:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:37 --> Language Class Initialized
INFO - 2016-09-23 22:40:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:37 --> Loader Class Initialized
INFO - 2016-09-23 22:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:37 --> Controller Class Initialized
INFO - 2016-09-23 22:40:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:37 --> Model Class Initialized
INFO - 2016-09-23 22:40:37 --> Model Class Initialized
INFO - 2016-09-23 22:40:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:37 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:37 --> Total execution time: 0.0893
INFO - 2016-09-23 22:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:37 --> Controller Class Initialized
INFO - 2016-09-23 22:40:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:37 --> Model Class Initialized
INFO - 2016-09-23 22:40:37 --> Model Class Initialized
INFO - 2016-09-23 22:40:37 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:40:37 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:40:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:40:37 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:37 --> Total execution time: 0.1179
INFO - 2016-09-23 22:40:41 --> Config Class Initialized
INFO - 2016-09-23 22:40:41 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:41 --> Config Class Initialized
INFO - 2016-09-23 22:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:41 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:41 --> URI Class Initialized
DEBUG - 2016-09-23 22:40:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:41 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:41 --> Router Class Initialized
INFO - 2016-09-23 22:40:41 --> URI Class Initialized
INFO - 2016-09-23 22:40:41 --> Router Class Initialized
INFO - 2016-09-23 22:40:41 --> Output Class Initialized
INFO - 2016-09-23 22:40:41 --> Security Class Initialized
INFO - 2016-09-23 22:40:41 --> Output Class Initialized
DEBUG - 2016-09-23 22:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:41 --> Input Class Initialized
INFO - 2016-09-23 22:40:41 --> Security Class Initialized
INFO - 2016-09-23 22:40:41 --> Language Class Initialized
DEBUG - 2016-09-23 22:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:41 --> Input Class Initialized
INFO - 2016-09-23 22:40:41 --> Language Class Initialized
INFO - 2016-09-23 22:40:41 --> Loader Class Initialized
INFO - 2016-09-23 22:40:41 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:41 --> Loader Class Initialized
INFO - 2016-09-23 22:40:41 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:41 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:41 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:41 --> Controller Class Initialized
INFO - 2016-09-23 22:40:41 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:41 --> Model Class Initialized
INFO - 2016-09-23 22:40:41 --> Model Class Initialized
INFO - 2016-09-23 22:40:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:41 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:41 --> Total execution time: 0.0763
INFO - 2016-09-23 22:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:41 --> Controller Class Initialized
INFO - 2016-09-23 22:40:41 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:41 --> Model Class Initialized
INFO - 2016-09-23 22:40:41 --> Model Class Initialized
INFO - 2016-09-23 22:40:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:41 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:41 --> Total execution time: 0.1039
INFO - 2016-09-23 22:40:42 --> Config Class Initialized
INFO - 2016-09-23 22:40:42 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:42 --> Config Class Initialized
INFO - 2016-09-23 22:40:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 22:40:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:42 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:43 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:43 --> URI Class Initialized
INFO - 2016-09-23 22:40:43 --> URI Class Initialized
INFO - 2016-09-23 22:40:43 --> Router Class Initialized
INFO - 2016-09-23 22:40:43 --> Router Class Initialized
INFO - 2016-09-23 22:40:43 --> Output Class Initialized
INFO - 2016-09-23 22:40:43 --> Output Class Initialized
INFO - 2016-09-23 22:40:43 --> Security Class Initialized
INFO - 2016-09-23 22:40:43 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-23 22:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:43 --> Input Class Initialized
INFO - 2016-09-23 22:40:43 --> Input Class Initialized
INFO - 2016-09-23 22:40:43 --> Language Class Initialized
INFO - 2016-09-23 22:40:43 --> Language Class Initialized
INFO - 2016-09-23 22:40:43 --> Loader Class Initialized
INFO - 2016-09-23 22:40:43 --> Loader Class Initialized
INFO - 2016-09-23 22:40:43 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:43 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:43 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:43 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:43 --> Controller Class Initialized
INFO - 2016-09-23 22:40:43 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:43 --> Model Class Initialized
INFO - 2016-09-23 22:40:43 --> Model Class Initialized
INFO - 2016-09-23 22:40:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:43 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:43 --> Total execution time: 0.0971
INFO - 2016-09-23 22:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:43 --> Controller Class Initialized
INFO - 2016-09-23 22:40:43 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:43 --> Model Class Initialized
INFO - 2016-09-23 22:40:43 --> Model Class Initialized
INFO - 2016-09-23 22:40:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:43 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:43 --> Total execution time: 0.1302
INFO - 2016-09-23 22:40:44 --> Config Class Initialized
INFO - 2016-09-23 22:40:44 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:44 --> Config Class Initialized
INFO - 2016-09-23 22:40:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:44 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:44 --> URI Class Initialized
DEBUG - 2016-09-23 22:40:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:44 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:44 --> Router Class Initialized
INFO - 2016-09-23 22:40:44 --> URI Class Initialized
INFO - 2016-09-23 22:40:44 --> Output Class Initialized
INFO - 2016-09-23 22:40:44 --> Router Class Initialized
INFO - 2016-09-23 22:40:44 --> Output Class Initialized
INFO - 2016-09-23 22:40:44 --> Security Class Initialized
INFO - 2016-09-23 22:40:44 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:44 --> Input Class Initialized
INFO - 2016-09-23 22:40:44 --> Language Class Initialized
DEBUG - 2016-09-23 22:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:44 --> Input Class Initialized
INFO - 2016-09-23 22:40:44 --> Language Class Initialized
INFO - 2016-09-23 22:40:44 --> Loader Class Initialized
INFO - 2016-09-23 22:40:44 --> Loader Class Initialized
INFO - 2016-09-23 22:40:44 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:44 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:44 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:44 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:44 --> Controller Class Initialized
INFO - 2016-09-23 22:40:44 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:44 --> Model Class Initialized
INFO - 2016-09-23 22:40:44 --> Model Class Initialized
INFO - 2016-09-23 22:40:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:44 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:44 --> Total execution time: 0.0800
INFO - 2016-09-23 22:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:44 --> Controller Class Initialized
INFO - 2016-09-23 22:40:44 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:44 --> Model Class Initialized
INFO - 2016-09-23 22:40:44 --> Model Class Initialized
INFO - 2016-09-23 22:40:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:44 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:44 --> Total execution time: 0.1086
INFO - 2016-09-23 22:40:46 --> Config Class Initialized
INFO - 2016-09-23 22:40:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:46 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:46 --> URI Class Initialized
INFO - 2016-09-23 22:40:46 --> Config Class Initialized
INFO - 2016-09-23 22:40:46 --> Router Class Initialized
INFO - 2016-09-23 22:40:46 --> Hooks Class Initialized
INFO - 2016-09-23 22:40:46 --> Output Class Initialized
INFO - 2016-09-23 22:40:46 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:46 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:46 --> URI Class Initialized
DEBUG - 2016-09-23 22:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:46 --> Input Class Initialized
INFO - 2016-09-23 22:40:46 --> Language Class Initialized
INFO - 2016-09-23 22:40:46 --> Router Class Initialized
INFO - 2016-09-23 22:40:46 --> Output Class Initialized
INFO - 2016-09-23 22:40:46 --> Loader Class Initialized
INFO - 2016-09-23 22:40:46 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:46 --> Input Class Initialized
INFO - 2016-09-23 22:40:46 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:46 --> Language Class Initialized
INFO - 2016-09-23 22:40:46 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:46 --> Loader Class Initialized
INFO - 2016-09-23 22:40:46 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:46 --> Controller Class Initialized
INFO - 2016-09-23 22:40:46 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:46 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:46 --> Model Class Initialized
INFO - 2016-09-23 22:40:46 --> Model Class Initialized
INFO - 2016-09-23 22:40:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:46 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:46 --> Total execution time: 0.0920
INFO - 2016-09-23 22:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:46 --> Controller Class Initialized
INFO - 2016-09-23 22:40:46 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:46 --> Model Class Initialized
INFO - 2016-09-23 22:40:46 --> Model Class Initialized
INFO - 2016-09-23 22:40:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:46 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:46 --> Total execution time: 0.1070
INFO - 2016-09-23 22:40:55 --> Config Class Initialized
INFO - 2016-09-23 22:40:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:40:55 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:40:55 --> Utf8 Class Initialized
INFO - 2016-09-23 22:40:55 --> URI Class Initialized
INFO - 2016-09-23 22:40:55 --> Router Class Initialized
INFO - 2016-09-23 22:40:55 --> Output Class Initialized
INFO - 2016-09-23 22:40:55 --> Security Class Initialized
DEBUG - 2016-09-23 22:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:40:55 --> Input Class Initialized
INFO - 2016-09-23 22:40:55 --> Language Class Initialized
INFO - 2016-09-23 22:40:55 --> Loader Class Initialized
INFO - 2016-09-23 22:40:55 --> Helper loaded: url_helper
INFO - 2016-09-23 22:40:55 --> Helper loaded: language_helper
INFO - 2016-09-23 22:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:40:55 --> Controller Class Initialized
INFO - 2016-09-23 22:40:55 --> Database Driver Class Initialized
INFO - 2016-09-23 22:40:55 --> Model Class Initialized
INFO - 2016-09-23 22:40:55 --> Model Class Initialized
INFO - 2016-09-23 22:40:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:40:55 --> Final output sent to browser
DEBUG - 2016-09-23 22:40:55 --> Total execution time: 0.0815
INFO - 2016-09-23 22:41:00 --> Config Class Initialized
INFO - 2016-09-23 22:41:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:41:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:41:00 --> Utf8 Class Initialized
INFO - 2016-09-23 22:41:00 --> URI Class Initialized
INFO - 2016-09-23 22:41:00 --> Router Class Initialized
INFO - 2016-09-23 22:41:00 --> Config Class Initialized
INFO - 2016-09-23 22:41:00 --> Hooks Class Initialized
INFO - 2016-09-23 22:41:00 --> Output Class Initialized
INFO - 2016-09-23 22:41:00 --> Security Class Initialized
DEBUG - 2016-09-23 22:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 22:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:41:00 --> Input Class Initialized
INFO - 2016-09-23 22:41:00 --> Utf8 Class Initialized
INFO - 2016-09-23 22:41:00 --> Language Class Initialized
INFO - 2016-09-23 22:41:00 --> URI Class Initialized
INFO - 2016-09-23 22:41:00 --> Router Class Initialized
INFO - 2016-09-23 22:41:00 --> Loader Class Initialized
INFO - 2016-09-23 22:41:00 --> Output Class Initialized
INFO - 2016-09-23 22:41:00 --> Helper loaded: url_helper
INFO - 2016-09-23 22:41:00 --> Helper loaded: language_helper
INFO - 2016-09-23 22:41:00 --> Security Class Initialized
DEBUG - 2016-09-23 22:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:41:00 --> Input Class Initialized
INFO - 2016-09-23 22:41:00 --> Language Class Initialized
INFO - 2016-09-23 22:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:41:00 --> Controller Class Initialized
INFO - 2016-09-23 22:41:00 --> Loader Class Initialized
INFO - 2016-09-23 22:41:00 --> Helper loaded: url_helper
INFO - 2016-09-23 22:41:00 --> Helper loaded: language_helper
INFO - 2016-09-23 22:41:00 --> Database Driver Class Initialized
INFO - 2016-09-23 22:41:00 --> Model Class Initialized
INFO - 2016-09-23 22:41:00 --> Model Class Initialized
INFO - 2016-09-23 22:41:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:41:00 --> Final output sent to browser
DEBUG - 2016-09-23 22:41:00 --> Total execution time: 0.0870
INFO - 2016-09-23 22:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:41:00 --> Controller Class Initialized
INFO - 2016-09-23 22:41:00 --> Database Driver Class Initialized
INFO - 2016-09-23 22:41:00 --> Model Class Initialized
INFO - 2016-09-23 22:41:00 --> Model Class Initialized
INFO - 2016-09-23 22:41:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:41:00 --> Final output sent to browser
DEBUG - 2016-09-23 22:41:00 --> Total execution time: 0.0965
INFO - 2016-09-23 22:41:03 --> Config Class Initialized
INFO - 2016-09-23 22:41:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:41:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:41:03 --> Utf8 Class Initialized
INFO - 2016-09-23 22:41:03 --> URI Class Initialized
INFO - 2016-09-23 22:41:03 --> Router Class Initialized
INFO - 2016-09-23 22:41:03 --> Output Class Initialized
INFO - 2016-09-23 22:41:03 --> Security Class Initialized
DEBUG - 2016-09-23 22:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:41:03 --> Input Class Initialized
INFO - 2016-09-23 22:41:03 --> Language Class Initialized
INFO - 2016-09-23 22:41:03 --> Loader Class Initialized
INFO - 2016-09-23 22:41:03 --> Helper loaded: url_helper
INFO - 2016-09-23 22:41:03 --> Helper loaded: language_helper
INFO - 2016-09-23 22:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:41:03 --> Controller Class Initialized
INFO - 2016-09-23 22:41:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:41:03 --> Model Class Initialized
INFO - 2016-09-23 22:41:03 --> Model Class Initialized
INFO - 2016-09-23 22:41:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:41:03 --> Config Class Initialized
INFO - 2016-09-23 22:41:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:41:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:41:03 --> Utf8 Class Initialized
INFO - 2016-09-23 22:41:03 --> URI Class Initialized
INFO - 2016-09-23 22:41:03 --> Router Class Initialized
INFO - 2016-09-23 22:41:03 --> Output Class Initialized
INFO - 2016-09-23 22:41:03 --> Security Class Initialized
DEBUG - 2016-09-23 22:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:41:03 --> Input Class Initialized
INFO - 2016-09-23 22:41:03 --> Language Class Initialized
INFO - 2016-09-23 22:41:03 --> Loader Class Initialized
INFO - 2016-09-23 22:41:03 --> Helper loaded: url_helper
INFO - 2016-09-23 22:41:03 --> Helper loaded: language_helper
INFO - 2016-09-23 22:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:41:03 --> Controller Class Initialized
INFO - 2016-09-23 22:41:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:41:03 --> Model Class Initialized
INFO - 2016-09-23 22:41:03 --> Model Class Initialized
INFO - 2016-09-23 22:41:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:41:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:41:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-23 22:41:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:41:03 --> Final output sent to browser
DEBUG - 2016-09-23 22:41:03 --> Total execution time: 0.0612
INFO - 2016-09-23 22:42:46 --> Config Class Initialized
INFO - 2016-09-23 22:42:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:42:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:42:46 --> Utf8 Class Initialized
INFO - 2016-09-23 22:42:46 --> URI Class Initialized
INFO - 2016-09-23 22:42:46 --> Router Class Initialized
INFO - 2016-09-23 22:42:46 --> Output Class Initialized
INFO - 2016-09-23 22:42:46 --> Security Class Initialized
DEBUG - 2016-09-23 22:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:42:46 --> Input Class Initialized
INFO - 2016-09-23 22:42:46 --> Language Class Initialized
INFO - 2016-09-23 22:42:46 --> Loader Class Initialized
INFO - 2016-09-23 22:42:46 --> Helper loaded: url_helper
INFO - 2016-09-23 22:42:46 --> Helper loaded: language_helper
INFO - 2016-09-23 22:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:42:46 --> Controller Class Initialized
INFO - 2016-09-23 22:42:46 --> Database Driver Class Initialized
INFO - 2016-09-23 22:42:46 --> Model Class Initialized
INFO - 2016-09-23 22:42:46 --> Model Class Initialized
INFO - 2016-09-23 22:42:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:42:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:42:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:42:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:42:46 --> Final output sent to browser
DEBUG - 2016-09-23 22:42:46 --> Total execution time: 0.0581
INFO - 2016-09-23 22:42:51 --> Config Class Initialized
INFO - 2016-09-23 22:42:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:42:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:42:51 --> Utf8 Class Initialized
INFO - 2016-09-23 22:42:51 --> URI Class Initialized
INFO - 2016-09-23 22:42:51 --> Router Class Initialized
INFO - 2016-09-23 22:42:51 --> Output Class Initialized
INFO - 2016-09-23 22:42:51 --> Security Class Initialized
DEBUG - 2016-09-23 22:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:42:51 --> Input Class Initialized
INFO - 2016-09-23 22:42:51 --> Language Class Initialized
INFO - 2016-09-23 22:42:51 --> Loader Class Initialized
INFO - 2016-09-23 22:42:51 --> Helper loaded: url_helper
INFO - 2016-09-23 22:42:51 --> Helper loaded: language_helper
INFO - 2016-09-23 22:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:42:51 --> Controller Class Initialized
INFO - 2016-09-23 22:42:51 --> Database Driver Class Initialized
INFO - 2016-09-23 22:42:51 --> Model Class Initialized
INFO - 2016-09-23 22:42:51 --> Model Class Initialized
INFO - 2016-09-23 22:42:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:42:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:42:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-09-23 22:42:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:42:51 --> Final output sent to browser
DEBUG - 2016-09-23 22:42:51 --> Total execution time: 0.0726
INFO - 2016-09-23 22:44:15 --> Config Class Initialized
INFO - 2016-09-23 22:44:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:15 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:15 --> URI Class Initialized
INFO - 2016-09-23 22:44:15 --> Router Class Initialized
INFO - 2016-09-23 22:44:15 --> Output Class Initialized
INFO - 2016-09-23 22:44:15 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:15 --> Input Class Initialized
INFO - 2016-09-23 22:44:15 --> Language Class Initialized
INFO - 2016-09-23 22:44:15 --> Loader Class Initialized
INFO - 2016-09-23 22:44:15 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:15 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:15 --> Controller Class Initialized
INFO - 2016-09-23 22:44:15 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:15 --> Config Class Initialized
INFO - 2016-09-23 22:44:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:15 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:15 --> URI Class Initialized
INFO - 2016-09-23 22:44:15 --> Router Class Initialized
INFO - 2016-09-23 22:44:15 --> Output Class Initialized
INFO - 2016-09-23 22:44:15 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:15 --> Input Class Initialized
INFO - 2016-09-23 22:44:15 --> Language Class Initialized
INFO - 2016-09-23 22:44:15 --> Loader Class Initialized
INFO - 2016-09-23 22:44:15 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:15 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:15 --> Controller Class Initialized
INFO - 2016-09-23 22:44:15 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:44:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-23 22:44:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:44:15 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:15 --> Total execution time: 0.0618
INFO - 2016-09-23 22:44:15 --> Config Class Initialized
INFO - 2016-09-23 22:44:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:15 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:15 --> URI Class Initialized
INFO - 2016-09-23 22:44:15 --> Config Class Initialized
INFO - 2016-09-23 22:44:15 --> Hooks Class Initialized
INFO - 2016-09-23 22:44:15 --> Router Class Initialized
INFO - 2016-09-23 22:44:15 --> Output Class Initialized
DEBUG - 2016-09-23 22:44:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:15 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:15 --> Security Class Initialized
INFO - 2016-09-23 22:44:15 --> URI Class Initialized
DEBUG - 2016-09-23 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:15 --> Input Class Initialized
INFO - 2016-09-23 22:44:15 --> Router Class Initialized
INFO - 2016-09-23 22:44:15 --> Language Class Initialized
INFO - 2016-09-23 22:44:15 --> Output Class Initialized
INFO - 2016-09-23 22:44:15 --> Security Class Initialized
INFO - 2016-09-23 22:44:15 --> Loader Class Initialized
DEBUG - 2016-09-23 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:15 --> Input Class Initialized
INFO - 2016-09-23 22:44:15 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:15 --> Language Class Initialized
INFO - 2016-09-23 22:44:15 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:15 --> Loader Class Initialized
INFO - 2016-09-23 22:44:15 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:15 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:15 --> Controller Class Initialized
INFO - 2016-09-23 22:44:15 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:15 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:15 --> Total execution time: 0.0884
INFO - 2016-09-23 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:15 --> Controller Class Initialized
INFO - 2016-09-23 22:44:15 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Model Class Initialized
INFO - 2016-09-23 22:44:15 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:44:15 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:44:15 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:15 --> Total execution time: 0.1141
INFO - 2016-09-23 22:44:19 --> Config Class Initialized
INFO - 2016-09-23 22:44:19 --> Hooks Class Initialized
INFO - 2016-09-23 22:44:19 --> Config Class Initialized
INFO - 2016-09-23 22:44:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:19 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:19 --> URI Class Initialized
DEBUG - 2016-09-23 22:44:19 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:19 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:19 --> Router Class Initialized
INFO - 2016-09-23 22:44:19 --> URI Class Initialized
INFO - 2016-09-23 22:44:19 --> Router Class Initialized
INFO - 2016-09-23 22:44:19 --> Output Class Initialized
INFO - 2016-09-23 22:44:19 --> Output Class Initialized
INFO - 2016-09-23 22:44:19 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:19 --> Input Class Initialized
INFO - 2016-09-23 22:44:19 --> Security Class Initialized
INFO - 2016-09-23 22:44:19 --> Language Class Initialized
DEBUG - 2016-09-23 22:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:19 --> Input Class Initialized
INFO - 2016-09-23 22:44:19 --> Language Class Initialized
INFO - 2016-09-23 22:44:19 --> Loader Class Initialized
INFO - 2016-09-23 22:44:19 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:19 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:19 --> Loader Class Initialized
INFO - 2016-09-23 22:44:19 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:19 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:19 --> Controller Class Initialized
INFO - 2016-09-23 22:44:19 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:19 --> Model Class Initialized
INFO - 2016-09-23 22:44:19 --> Model Class Initialized
INFO - 2016-09-23 22:44:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:19 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:19 --> Total execution time: 0.0742
INFO - 2016-09-23 22:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:19 --> Controller Class Initialized
INFO - 2016-09-23 22:44:19 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:19 --> Model Class Initialized
INFO - 2016-09-23 22:44:19 --> Model Class Initialized
INFO - 2016-09-23 22:44:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:19 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:19 --> Total execution time: 0.1037
INFO - 2016-09-23 22:44:23 --> Config Class Initialized
INFO - 2016-09-23 22:44:23 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:23 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:23 --> URI Class Initialized
INFO - 2016-09-23 22:44:23 --> Config Class Initialized
INFO - 2016-09-23 22:44:23 --> Hooks Class Initialized
INFO - 2016-09-23 22:44:23 --> Router Class Initialized
INFO - 2016-09-23 22:44:23 --> Output Class Initialized
DEBUG - 2016-09-23 22:44:23 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:23 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:23 --> URI Class Initialized
INFO - 2016-09-23 22:44:23 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:23 --> Router Class Initialized
INFO - 2016-09-23 22:44:23 --> Input Class Initialized
INFO - 2016-09-23 22:44:23 --> Language Class Initialized
INFO - 2016-09-23 22:44:23 --> Output Class Initialized
INFO - 2016-09-23 22:44:23 --> Security Class Initialized
INFO - 2016-09-23 22:44:23 --> Loader Class Initialized
DEBUG - 2016-09-23 22:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:23 --> Input Class Initialized
INFO - 2016-09-23 22:44:23 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:23 --> Language Class Initialized
INFO - 2016-09-23 22:44:23 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:23 --> Loader Class Initialized
INFO - 2016-09-23 22:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:23 --> Controller Class Initialized
INFO - 2016-09-23 22:44:23 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:23 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:23 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:23 --> Model Class Initialized
INFO - 2016-09-23 22:44:23 --> Model Class Initialized
INFO - 2016-09-23 22:44:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:23 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:23 --> Total execution time: 0.0822
INFO - 2016-09-23 22:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:23 --> Controller Class Initialized
INFO - 2016-09-23 22:44:23 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:23 --> Model Class Initialized
INFO - 2016-09-23 22:44:23 --> Model Class Initialized
INFO - 2016-09-23 22:44:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:23 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:23 --> Total execution time: 0.0982
INFO - 2016-09-23 22:44:29 --> Config Class Initialized
INFO - 2016-09-23 22:44:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:29 --> URI Class Initialized
INFO - 2016-09-23 22:44:29 --> Router Class Initialized
INFO - 2016-09-23 22:44:29 --> Config Class Initialized
INFO - 2016-09-23 22:44:29 --> Hooks Class Initialized
INFO - 2016-09-23 22:44:29 --> Output Class Initialized
INFO - 2016-09-23 22:44:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:29 --> Input Class Initialized
DEBUG - 2016-09-23 22:44:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:29 --> Language Class Initialized
INFO - 2016-09-23 22:44:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:29 --> URI Class Initialized
INFO - 2016-09-23 22:44:29 --> Loader Class Initialized
INFO - 2016-09-23 22:44:29 --> Router Class Initialized
INFO - 2016-09-23 22:44:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:29 --> Output Class Initialized
INFO - 2016-09-23 22:44:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:29 --> Input Class Initialized
INFO - 2016-09-23 22:44:29 --> Language Class Initialized
INFO - 2016-09-23 22:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:29 --> Controller Class Initialized
INFO - 2016-09-23 22:44:29 --> Loader Class Initialized
INFO - 2016-09-23 22:44:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:29 --> Model Class Initialized
INFO - 2016-09-23 22:44:29 --> Model Class Initialized
INFO - 2016-09-23 22:44:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:29 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:29 --> Total execution time: 0.0970
INFO - 2016-09-23 22:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:29 --> Controller Class Initialized
INFO - 2016-09-23 22:44:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:29 --> Model Class Initialized
INFO - 2016-09-23 22:44:29 --> Model Class Initialized
INFO - 2016-09-23 22:44:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:29 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:29 --> Total execution time: 0.1076
INFO - 2016-09-23 22:44:32 --> Config Class Initialized
INFO - 2016-09-23 22:44:32 --> Hooks Class Initialized
INFO - 2016-09-23 22:44:32 --> Config Class Initialized
INFO - 2016-09-23 22:44:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 22:44:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:32 --> URI Class Initialized
INFO - 2016-09-23 22:44:32 --> URI Class Initialized
INFO - 2016-09-23 22:44:32 --> Router Class Initialized
INFO - 2016-09-23 22:44:32 --> Router Class Initialized
INFO - 2016-09-23 22:44:32 --> Output Class Initialized
INFO - 2016-09-23 22:44:32 --> Output Class Initialized
INFO - 2016-09-23 22:44:32 --> Security Class Initialized
INFO - 2016-09-23 22:44:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-23 22:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:32 --> Input Class Initialized
INFO - 2016-09-23 22:44:32 --> Input Class Initialized
INFO - 2016-09-23 22:44:32 --> Language Class Initialized
INFO - 2016-09-23 22:44:32 --> Language Class Initialized
INFO - 2016-09-23 22:44:32 --> Loader Class Initialized
INFO - 2016-09-23 22:44:32 --> Loader Class Initialized
INFO - 2016-09-23 22:44:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:32 --> Controller Class Initialized
INFO - 2016-09-23 22:44:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:32 --> Model Class Initialized
INFO - 2016-09-23 22:44:32 --> Model Class Initialized
INFO - 2016-09-23 22:44:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:32 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:32 --> Total execution time: 0.0755
INFO - 2016-09-23 22:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:32 --> Controller Class Initialized
INFO - 2016-09-23 22:44:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:32 --> Model Class Initialized
INFO - 2016-09-23 22:44:32 --> Model Class Initialized
INFO - 2016-09-23 22:44:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:32 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:32 --> Total execution time: 0.1162
INFO - 2016-09-23 22:44:46 --> Config Class Initialized
INFO - 2016-09-23 22:44:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:46 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:46 --> URI Class Initialized
INFO - 2016-09-23 22:44:46 --> Router Class Initialized
INFO - 2016-09-23 22:44:46 --> Output Class Initialized
INFO - 2016-09-23 22:44:46 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:46 --> Input Class Initialized
INFO - 2016-09-23 22:44:46 --> Language Class Initialized
INFO - 2016-09-23 22:44:46 --> Loader Class Initialized
INFO - 2016-09-23 22:44:46 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:46 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:46 --> Controller Class Initialized
INFO - 2016-09-23 22:44:46 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:46 --> Model Class Initialized
INFO - 2016-09-23 22:44:46 --> Model Class Initialized
INFO - 2016-09-23 22:44:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:46 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:46 --> Total execution time: 0.0636
INFO - 2016-09-23 22:44:57 --> Config Class Initialized
INFO - 2016-09-23 22:44:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:57 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:57 --> URI Class Initialized
INFO - 2016-09-23 22:44:57 --> Router Class Initialized
INFO - 2016-09-23 22:44:57 --> Output Class Initialized
INFO - 2016-09-23 22:44:57 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:57 --> Input Class Initialized
INFO - 2016-09-23 22:44:57 --> Language Class Initialized
INFO - 2016-09-23 22:44:57 --> Loader Class Initialized
INFO - 2016-09-23 22:44:57 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:57 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:57 --> Controller Class Initialized
INFO - 2016-09-23 22:44:57 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:57 --> Model Class Initialized
INFO - 2016-09-23 22:44:57 --> Model Class Initialized
INFO - 2016-09-23 22:44:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:58 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:58 --> Total execution time: 0.0878
INFO - 2016-09-23 22:44:59 --> Config Class Initialized
INFO - 2016-09-23 22:44:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:44:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:59 --> Utf8 Class Initialized
INFO - 2016-09-23 22:44:59 --> URI Class Initialized
INFO - 2016-09-23 22:44:59 --> Config Class Initialized
INFO - 2016-09-23 22:44:59 --> Router Class Initialized
INFO - 2016-09-23 22:44:59 --> Hooks Class Initialized
INFO - 2016-09-23 22:44:59 --> Output Class Initialized
DEBUG - 2016-09-23 22:44:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:44:59 --> Security Class Initialized
INFO - 2016-09-23 22:44:59 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:59 --> URI Class Initialized
INFO - 2016-09-23 22:44:59 --> Input Class Initialized
INFO - 2016-09-23 22:44:59 --> Language Class Initialized
INFO - 2016-09-23 22:44:59 --> Router Class Initialized
INFO - 2016-09-23 22:44:59 --> Output Class Initialized
INFO - 2016-09-23 22:44:59 --> Loader Class Initialized
INFO - 2016-09-23 22:44:59 --> Security Class Initialized
DEBUG - 2016-09-23 22:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:44:59 --> Input Class Initialized
INFO - 2016-09-23 22:44:59 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:59 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:59 --> Language Class Initialized
INFO - 2016-09-23 22:44:59 --> Loader Class Initialized
INFO - 2016-09-23 22:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:59 --> Controller Class Initialized
INFO - 2016-09-23 22:44:59 --> Helper loaded: url_helper
INFO - 2016-09-23 22:44:59 --> Helper loaded: language_helper
INFO - 2016-09-23 22:44:59 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:59 --> Model Class Initialized
INFO - 2016-09-23 22:44:59 --> Model Class Initialized
INFO - 2016-09-23 22:44:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:59 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:59 --> Total execution time: 0.0951
INFO - 2016-09-23 22:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:44:59 --> Controller Class Initialized
INFO - 2016-09-23 22:44:59 --> Database Driver Class Initialized
INFO - 2016-09-23 22:44:59 --> Model Class Initialized
INFO - 2016-09-23 22:44:59 --> Model Class Initialized
INFO - 2016-09-23 22:44:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:44:59 --> Final output sent to browser
DEBUG - 2016-09-23 22:44:59 --> Total execution time: 0.1079
INFO - 2016-09-23 22:45:02 --> Config Class Initialized
INFO - 2016-09-23 22:45:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:02 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:02 --> URI Class Initialized
INFO - 2016-09-23 22:45:02 --> Router Class Initialized
INFO - 2016-09-23 22:45:02 --> Output Class Initialized
INFO - 2016-09-23 22:45:02 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:02 --> Input Class Initialized
INFO - 2016-09-23 22:45:02 --> Language Class Initialized
INFO - 2016-09-23 22:45:02 --> Loader Class Initialized
INFO - 2016-09-23 22:45:02 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:02 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:02 --> Controller Class Initialized
INFO - 2016-09-23 22:45:02 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:02 --> Model Class Initialized
INFO - 2016-09-23 22:45:02 --> Model Class Initialized
INFO - 2016-09-23 22:45:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:02 --> Config Class Initialized
INFO - 2016-09-23 22:45:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:02 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:02 --> URI Class Initialized
INFO - 2016-09-23 22:45:02 --> Router Class Initialized
INFO - 2016-09-23 22:45:02 --> Output Class Initialized
INFO - 2016-09-23 22:45:02 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:02 --> Input Class Initialized
INFO - 2016-09-23 22:45:02 --> Language Class Initialized
INFO - 2016-09-23 22:45:02 --> Loader Class Initialized
INFO - 2016-09-23 22:45:02 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:02 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:02 --> Controller Class Initialized
INFO - 2016-09-23 22:45:02 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:02 --> Model Class Initialized
INFO - 2016-09-23 22:45:02 --> Model Class Initialized
INFO - 2016-09-23 22:45:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:45:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-23 22:45:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:45:02 --> Final output sent to browser
DEBUG - 2016-09-23 22:45:02 --> Total execution time: 0.0606
INFO - 2016-09-23 22:45:13 --> Config Class Initialized
INFO - 2016-09-23 22:45:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:13 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:13 --> URI Class Initialized
INFO - 2016-09-23 22:45:13 --> Router Class Initialized
INFO - 2016-09-23 22:45:13 --> Output Class Initialized
INFO - 2016-09-23 22:45:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:13 --> Input Class Initialized
INFO - 2016-09-23 22:45:13 --> Language Class Initialized
INFO - 2016-09-23 22:45:13 --> Loader Class Initialized
INFO - 2016-09-23 22:45:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:13 --> Controller Class Initialized
INFO - 2016-09-23 22:45:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:13 --> Model Class Initialized
INFO - 2016-09-23 22:45:13 --> Model Class Initialized
INFO - 2016-09-23 22:45:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:45:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-09-23 22:45:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:45:13 --> Final output sent to browser
DEBUG - 2016-09-23 22:45:13 --> Total execution time: 0.0698
INFO - 2016-09-23 22:45:17 --> Config Class Initialized
INFO - 2016-09-23 22:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:17 --> URI Class Initialized
INFO - 2016-09-23 22:45:17 --> Router Class Initialized
INFO - 2016-09-23 22:45:17 --> Output Class Initialized
INFO - 2016-09-23 22:45:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:17 --> Input Class Initialized
INFO - 2016-09-23 22:45:17 --> Language Class Initialized
INFO - 2016-09-23 22:45:17 --> Loader Class Initialized
INFO - 2016-09-23 22:45:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:17 --> Controller Class Initialized
INFO - 2016-09-23 22:45:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:17 --> Config Class Initialized
INFO - 2016-09-23 22:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:17 --> URI Class Initialized
INFO - 2016-09-23 22:45:17 --> Router Class Initialized
INFO - 2016-09-23 22:45:17 --> Output Class Initialized
INFO - 2016-09-23 22:45:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:17 --> Input Class Initialized
INFO - 2016-09-23 22:45:17 --> Language Class Initialized
INFO - 2016-09-23 22:45:17 --> Loader Class Initialized
INFO - 2016-09-23 22:45:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:17 --> Controller Class Initialized
INFO - 2016-09-23 22:45:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:45:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_attempt.php
INFO - 2016-09-23 22:45:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:45:17 --> Final output sent to browser
DEBUG - 2016-09-23 22:45:17 --> Total execution time: 0.0787
INFO - 2016-09-23 22:45:17 --> Config Class Initialized
INFO - 2016-09-23 22:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:17 --> URI Class Initialized
INFO - 2016-09-23 22:45:17 --> Router Class Initialized
INFO - 2016-09-23 22:45:17 --> Output Class Initialized
INFO - 2016-09-23 22:45:17 --> Config Class Initialized
INFO - 2016-09-23 22:45:17 --> Hooks Class Initialized
INFO - 2016-09-23 22:45:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:17 --> Input Class Initialized
DEBUG - 2016-09-23 22:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:17 --> Language Class Initialized
INFO - 2016-09-23 22:45:17 --> URI Class Initialized
INFO - 2016-09-23 22:45:17 --> Router Class Initialized
INFO - 2016-09-23 22:45:17 --> Loader Class Initialized
INFO - 2016-09-23 22:45:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:17 --> Output Class Initialized
INFO - 2016-09-23 22:45:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:17 --> Input Class Initialized
INFO - 2016-09-23 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:17 --> Controller Class Initialized
INFO - 2016-09-23 22:45:17 --> Language Class Initialized
INFO - 2016-09-23 22:45:17 --> Loader Class Initialized
INFO - 2016-09-23 22:45:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:17 --> Final output sent to browser
DEBUG - 2016-09-23 22:45:17 --> Total execution time: 0.0832
INFO - 2016-09-23 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:17 --> Controller Class Initialized
INFO - 2016-09-23 22:45:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Model Class Initialized
INFO - 2016-09-23 22:45:17 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:45:17 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:45:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:45:17 --> Final output sent to browser
DEBUG - 2016-09-23 22:45:17 --> Total execution time: 0.1089
INFO - 2016-09-23 22:45:47 --> Config Class Initialized
INFO - 2016-09-23 22:45:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:45:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:45:47 --> Utf8 Class Initialized
INFO - 2016-09-23 22:45:47 --> URI Class Initialized
INFO - 2016-09-23 22:45:47 --> Router Class Initialized
INFO - 2016-09-23 22:45:47 --> Output Class Initialized
INFO - 2016-09-23 22:45:47 --> Security Class Initialized
DEBUG - 2016-09-23 22:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:45:47 --> Input Class Initialized
INFO - 2016-09-23 22:45:47 --> Language Class Initialized
INFO - 2016-09-23 22:45:47 --> Loader Class Initialized
INFO - 2016-09-23 22:45:47 --> Helper loaded: url_helper
INFO - 2016-09-23 22:45:47 --> Helper loaded: language_helper
INFO - 2016-09-23 22:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:45:47 --> Controller Class Initialized
INFO - 2016-09-23 22:45:47 --> Database Driver Class Initialized
INFO - 2016-09-23 22:45:47 --> Model Class Initialized
INFO - 2016-09-23 22:45:47 --> Model Class Initialized
INFO - 2016-09-23 22:45:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:45:47 --> Final output sent to browser
DEBUG - 2016-09-23 22:45:47 --> Total execution time: 0.0615
INFO - 2016-09-23 22:46:17 --> Config Class Initialized
INFO - 2016-09-23 22:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:46:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:46:17 --> URI Class Initialized
INFO - 2016-09-23 22:46:17 --> Router Class Initialized
INFO - 2016-09-23 22:46:17 --> Output Class Initialized
INFO - 2016-09-23 22:46:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:46:17 --> Input Class Initialized
INFO - 2016-09-23 22:46:17 --> Language Class Initialized
INFO - 2016-09-23 22:46:17 --> Loader Class Initialized
INFO - 2016-09-23 22:46:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:46:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:46:17 --> Controller Class Initialized
INFO - 2016-09-23 22:46:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:46:17 --> Model Class Initialized
INFO - 2016-09-23 22:46:17 --> Model Class Initialized
INFO - 2016-09-23 22:46:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:46:17 --> Final output sent to browser
DEBUG - 2016-09-23 22:46:17 --> Total execution time: 0.0603
INFO - 2016-09-23 22:46:47 --> Config Class Initialized
INFO - 2016-09-23 22:46:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:46:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:46:47 --> Utf8 Class Initialized
INFO - 2016-09-23 22:46:47 --> URI Class Initialized
INFO - 2016-09-23 22:46:47 --> Router Class Initialized
INFO - 2016-09-23 22:46:47 --> Output Class Initialized
INFO - 2016-09-23 22:46:47 --> Security Class Initialized
DEBUG - 2016-09-23 22:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:46:47 --> Input Class Initialized
INFO - 2016-09-23 22:46:47 --> Language Class Initialized
INFO - 2016-09-23 22:46:47 --> Loader Class Initialized
INFO - 2016-09-23 22:46:47 --> Helper loaded: url_helper
INFO - 2016-09-23 22:46:47 --> Helper loaded: language_helper
INFO - 2016-09-23 22:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:46:47 --> Controller Class Initialized
INFO - 2016-09-23 22:46:47 --> Database Driver Class Initialized
INFO - 2016-09-23 22:46:47 --> Model Class Initialized
INFO - 2016-09-23 22:46:47 --> Model Class Initialized
INFO - 2016-09-23 22:46:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:46:47 --> Final output sent to browser
DEBUG - 2016-09-23 22:46:47 --> Total execution time: 0.0635
INFO - 2016-09-23 22:47:17 --> Config Class Initialized
INFO - 2016-09-23 22:47:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:47:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:47:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:47:17 --> URI Class Initialized
INFO - 2016-09-23 22:47:17 --> Router Class Initialized
INFO - 2016-09-23 22:47:17 --> Output Class Initialized
INFO - 2016-09-23 22:47:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:47:17 --> Input Class Initialized
INFO - 2016-09-23 22:47:17 --> Language Class Initialized
INFO - 2016-09-23 22:47:17 --> Loader Class Initialized
INFO - 2016-09-23 22:47:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:47:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:47:17 --> Controller Class Initialized
INFO - 2016-09-23 22:47:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:47:17 --> Model Class Initialized
INFO - 2016-09-23 22:47:17 --> Model Class Initialized
INFO - 2016-09-23 22:47:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:47:17 --> Final output sent to browser
DEBUG - 2016-09-23 22:47:17 --> Total execution time: 0.0602
INFO - 2016-09-23 22:47:47 --> Config Class Initialized
INFO - 2016-09-23 22:47:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:47:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:47:47 --> Utf8 Class Initialized
INFO - 2016-09-23 22:47:47 --> URI Class Initialized
INFO - 2016-09-23 22:47:47 --> Router Class Initialized
INFO - 2016-09-23 22:47:47 --> Output Class Initialized
INFO - 2016-09-23 22:47:47 --> Security Class Initialized
DEBUG - 2016-09-23 22:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:47:47 --> Input Class Initialized
INFO - 2016-09-23 22:47:47 --> Language Class Initialized
INFO - 2016-09-23 22:47:47 --> Loader Class Initialized
INFO - 2016-09-23 22:47:47 --> Helper loaded: url_helper
INFO - 2016-09-23 22:47:47 --> Helper loaded: language_helper
INFO - 2016-09-23 22:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:47:47 --> Controller Class Initialized
INFO - 2016-09-23 22:47:47 --> Database Driver Class Initialized
INFO - 2016-09-23 22:47:47 --> Model Class Initialized
INFO - 2016-09-23 22:47:47 --> Model Class Initialized
INFO - 2016-09-23 22:47:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:47:47 --> Final output sent to browser
DEBUG - 2016-09-23 22:47:47 --> Total execution time: 0.0709
INFO - 2016-09-23 22:48:17 --> Config Class Initialized
INFO - 2016-09-23 22:48:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:48:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:48:17 --> Utf8 Class Initialized
INFO - 2016-09-23 22:48:17 --> URI Class Initialized
INFO - 2016-09-23 22:48:17 --> Router Class Initialized
INFO - 2016-09-23 22:48:17 --> Output Class Initialized
INFO - 2016-09-23 22:48:17 --> Security Class Initialized
DEBUG - 2016-09-23 22:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:48:17 --> Input Class Initialized
INFO - 2016-09-23 22:48:17 --> Language Class Initialized
INFO - 2016-09-23 22:48:17 --> Loader Class Initialized
INFO - 2016-09-23 22:48:17 --> Helper loaded: url_helper
INFO - 2016-09-23 22:48:17 --> Helper loaded: language_helper
INFO - 2016-09-23 22:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:48:17 --> Controller Class Initialized
INFO - 2016-09-23 22:48:17 --> Database Driver Class Initialized
INFO - 2016-09-23 22:48:17 --> Model Class Initialized
INFO - 2016-09-23 22:48:17 --> Model Class Initialized
INFO - 2016-09-23 22:48:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:48:17 --> Final output sent to browser
DEBUG - 2016-09-23 22:48:17 --> Total execution time: 0.0716
INFO - 2016-09-23 22:48:47 --> Config Class Initialized
INFO - 2016-09-23 22:48:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:48:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:48:47 --> Utf8 Class Initialized
INFO - 2016-09-23 22:48:47 --> URI Class Initialized
INFO - 2016-09-23 22:48:47 --> Router Class Initialized
INFO - 2016-09-23 22:48:47 --> Output Class Initialized
INFO - 2016-09-23 22:48:47 --> Security Class Initialized
DEBUG - 2016-09-23 22:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:48:47 --> Input Class Initialized
INFO - 2016-09-23 22:48:47 --> Language Class Initialized
INFO - 2016-09-23 22:48:47 --> Loader Class Initialized
INFO - 2016-09-23 22:48:47 --> Helper loaded: url_helper
INFO - 2016-09-23 22:48:47 --> Helper loaded: language_helper
INFO - 2016-09-23 22:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:48:47 --> Controller Class Initialized
INFO - 2016-09-23 22:48:47 --> Database Driver Class Initialized
INFO - 2016-09-23 22:48:47 --> Model Class Initialized
INFO - 2016-09-23 22:48:47 --> Model Class Initialized
INFO - 2016-09-23 22:48:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:48:47 --> Final output sent to browser
DEBUG - 2016-09-23 22:48:47 --> Total execution time: 0.0595
INFO - 2016-09-23 22:49:05 --> Config Class Initialized
INFO - 2016-09-23 22:49:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:05 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:05 --> URI Class Initialized
INFO - 2016-09-23 22:49:05 --> Router Class Initialized
INFO - 2016-09-23 22:49:05 --> Output Class Initialized
INFO - 2016-09-23 22:49:05 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:05 --> Input Class Initialized
INFO - 2016-09-23 22:49:05 --> Language Class Initialized
INFO - 2016-09-23 22:49:05 --> Loader Class Initialized
INFO - 2016-09-23 22:49:05 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:05 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:05 --> Controller Class Initialized
INFO - 2016-09-23 22:49:05 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:05 --> Model Class Initialized
INFO - 2016-09-23 22:49:05 --> Model Class Initialized
INFO - 2016-09-23 22:49:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:49:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:49:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:49:05 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:05 --> Total execution time: 0.0692
INFO - 2016-09-23 22:49:08 --> Config Class Initialized
INFO - 2016-09-23 22:49:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:08 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:08 --> URI Class Initialized
INFO - 2016-09-23 22:49:08 --> Router Class Initialized
INFO - 2016-09-23 22:49:08 --> Output Class Initialized
INFO - 2016-09-23 22:49:08 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:08 --> Input Class Initialized
INFO - 2016-09-23 22:49:08 --> Language Class Initialized
INFO - 2016-09-23 22:49:08 --> Loader Class Initialized
INFO - 2016-09-23 22:49:08 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:08 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:08 --> Controller Class Initialized
INFO - 2016-09-23 22:49:08 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:08 --> Model Class Initialized
INFO - 2016-09-23 22:49:08 --> Model Class Initialized
INFO - 2016-09-23 22:49:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:49:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 22:49:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:49:08 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:08 --> Total execution time: 0.0704
INFO - 2016-09-23 22:49:11 --> Config Class Initialized
INFO - 2016-09-23 22:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:11 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:11 --> URI Class Initialized
INFO - 2016-09-23 22:49:11 --> Router Class Initialized
INFO - 2016-09-23 22:49:11 --> Output Class Initialized
INFO - 2016-09-23 22:49:11 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:11 --> Input Class Initialized
INFO - 2016-09-23 22:49:11 --> Language Class Initialized
INFO - 2016-09-23 22:49:11 --> Loader Class Initialized
INFO - 2016-09-23 22:49:11 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:11 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:11 --> Controller Class Initialized
INFO - 2016-09-23 22:49:11 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:11 --> Model Class Initialized
INFO - 2016-09-23 22:49:11 --> Model Class Initialized
INFO - 2016-09-23 22:49:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:11 --> Config Class Initialized
INFO - 2016-09-23 22:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:11 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:11 --> URI Class Initialized
INFO - 2016-09-23 22:49:11 --> Router Class Initialized
INFO - 2016-09-23 22:49:11 --> Output Class Initialized
INFO - 2016-09-23 22:49:11 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:11 --> Input Class Initialized
INFO - 2016-09-23 22:49:11 --> Language Class Initialized
INFO - 2016-09-23 22:49:11 --> Loader Class Initialized
INFO - 2016-09-23 22:49:11 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:11 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:11 --> Controller Class Initialized
INFO - 2016-09-23 22:49:11 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:11 --> Model Class Initialized
INFO - 2016-09-23 22:49:11 --> Model Class Initialized
INFO - 2016-09-23 22:49:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:49:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 22:49:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:49:12 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:12 --> Total execution time: 0.0638
INFO - 2016-09-23 22:49:12 --> Config Class Initialized
INFO - 2016-09-23 22:49:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:12 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:12 --> URI Class Initialized
INFO - 2016-09-23 22:49:12 --> Config Class Initialized
INFO - 2016-09-23 22:49:12 --> Hooks Class Initialized
INFO - 2016-09-23 22:49:12 --> Router Class Initialized
INFO - 2016-09-23 22:49:12 --> Output Class Initialized
DEBUG - 2016-09-23 22:49:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:12 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:12 --> URI Class Initialized
INFO - 2016-09-23 22:49:12 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:12 --> Input Class Initialized
INFO - 2016-09-23 22:49:12 --> Router Class Initialized
INFO - 2016-09-23 22:49:12 --> Language Class Initialized
INFO - 2016-09-23 22:49:12 --> Output Class Initialized
INFO - 2016-09-23 22:49:12 --> Security Class Initialized
INFO - 2016-09-23 22:49:12 --> Loader Class Initialized
INFO - 2016-09-23 22:49:12 --> Helper loaded: url_helper
DEBUG - 2016-09-23 22:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:12 --> Input Class Initialized
INFO - 2016-09-23 22:49:12 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:12 --> Language Class Initialized
INFO - 2016-09-23 22:49:12 --> Loader Class Initialized
INFO - 2016-09-23 22:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:12 --> Controller Class Initialized
INFO - 2016-09-23 22:49:12 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:12 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:12 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:12 --> Model Class Initialized
INFO - 2016-09-23 22:49:12 --> Model Class Initialized
INFO - 2016-09-23 22:49:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:12 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:12 --> Total execution time: 0.0792
INFO - 2016-09-23 22:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:12 --> Controller Class Initialized
INFO - 2016-09-23 22:49:12 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:12 --> Model Class Initialized
INFO - 2016-09-23 22:49:12 --> Model Class Initialized
INFO - 2016-09-23 22:49:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:49:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:49:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:49:12 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:12 --> Total execution time: 0.1065
INFO - 2016-09-23 22:49:43 --> Config Class Initialized
INFO - 2016-09-23 22:49:43 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:43 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:43 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:43 --> URI Class Initialized
INFO - 2016-09-23 22:49:43 --> Router Class Initialized
INFO - 2016-09-23 22:49:43 --> Output Class Initialized
INFO - 2016-09-23 22:49:43 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:43 --> Input Class Initialized
INFO - 2016-09-23 22:49:43 --> Language Class Initialized
ERROR - 2016-09-23 22:49:43 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:49:49 --> Config Class Initialized
INFO - 2016-09-23 22:49:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:49 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:49 --> URI Class Initialized
INFO - 2016-09-23 22:49:49 --> Config Class Initialized
INFO - 2016-09-23 22:49:49 --> Hooks Class Initialized
INFO - 2016-09-23 22:49:49 --> Router Class Initialized
INFO - 2016-09-23 22:49:49 --> Output Class Initialized
DEBUG - 2016-09-23 22:49:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:49 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:49 --> Security Class Initialized
INFO - 2016-09-23 22:49:49 --> URI Class Initialized
DEBUG - 2016-09-23 22:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:49 --> Input Class Initialized
INFO - 2016-09-23 22:49:49 --> Router Class Initialized
INFO - 2016-09-23 22:49:49 --> Language Class Initialized
INFO - 2016-09-23 22:49:49 --> Output Class Initialized
INFO - 2016-09-23 22:49:49 --> Loader Class Initialized
INFO - 2016-09-23 22:49:49 --> Security Class Initialized
INFO - 2016-09-23 22:49:49 --> Helper loaded: url_helper
DEBUG - 2016-09-23 22:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:49 --> Input Class Initialized
INFO - 2016-09-23 22:49:49 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:49 --> Language Class Initialized
INFO - 2016-09-23 22:49:49 --> Loader Class Initialized
INFO - 2016-09-23 22:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:49 --> Controller Class Initialized
INFO - 2016-09-23 22:49:49 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:49 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:49 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:49 --> Model Class Initialized
INFO - 2016-09-23 22:49:49 --> Model Class Initialized
INFO - 2016-09-23 22:49:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:49 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:49 --> Total execution time: 0.0832
INFO - 2016-09-23 22:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:49 --> Controller Class Initialized
INFO - 2016-09-23 22:49:49 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:49 --> Model Class Initialized
INFO - 2016-09-23 22:49:49 --> Model Class Initialized
INFO - 2016-09-23 22:49:49 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:49:49 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 641
ERROR - 2016-09-23 22:49:49 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 651
ERROR - 2016-09-23 22:49:49 --> Query error: Column 'score_u' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('49', '', '1', '646', NULL)
INFO - 2016-09-23 22:49:49 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:49:52 --> Config Class Initialized
INFO - 2016-09-23 22:49:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:52 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:52 --> Config Class Initialized
INFO - 2016-09-23 22:49:52 --> Hooks Class Initialized
INFO - 2016-09-23 22:49:52 --> URI Class Initialized
INFO - 2016-09-23 22:49:52 --> Router Class Initialized
INFO - 2016-09-23 22:49:52 --> Output Class Initialized
DEBUG - 2016-09-23 22:49:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:52 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:52 --> Security Class Initialized
INFO - 2016-09-23 22:49:52 --> URI Class Initialized
DEBUG - 2016-09-23 22:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:52 --> Input Class Initialized
INFO - 2016-09-23 22:49:52 --> Router Class Initialized
INFO - 2016-09-23 22:49:52 --> Language Class Initialized
INFO - 2016-09-23 22:49:52 --> Output Class Initialized
INFO - 2016-09-23 22:49:52 --> Security Class Initialized
INFO - 2016-09-23 22:49:52 --> Loader Class Initialized
DEBUG - 2016-09-23 22:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:52 --> Input Class Initialized
INFO - 2016-09-23 22:49:52 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:52 --> Language Class Initialized
INFO - 2016-09-23 22:49:52 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:52 --> Loader Class Initialized
INFO - 2016-09-23 22:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:52 --> Controller Class Initialized
INFO - 2016-09-23 22:49:52 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:52 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:52 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:52 --> Model Class Initialized
INFO - 2016-09-23 22:49:52 --> Model Class Initialized
INFO - 2016-09-23 22:49:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:52 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:52 --> Total execution time: 0.0736
INFO - 2016-09-23 22:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:52 --> Controller Class Initialized
INFO - 2016-09-23 22:49:52 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:52 --> Model Class Initialized
INFO - 2016-09-23 22:49:52 --> Model Class Initialized
INFO - 2016-09-23 22:49:52 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:49:52 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 641
ERROR - 2016-09-23 22:49:52 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 651
ERROR - 2016-09-23 22:49:52 --> Query error: Column 'score_u' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('49', '', '1', '646', NULL)
INFO - 2016-09-23 22:49:52 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:49:54 --> Config Class Initialized
INFO - 2016-09-23 22:49:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:54 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:54 --> URI Class Initialized
INFO - 2016-09-23 22:49:54 --> Router Class Initialized
INFO - 2016-09-23 22:49:54 --> Config Class Initialized
INFO - 2016-09-23 22:49:54 --> Output Class Initialized
INFO - 2016-09-23 22:49:54 --> Hooks Class Initialized
INFO - 2016-09-23 22:49:54 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:54 --> Input Class Initialized
DEBUG - 2016-09-23 22:49:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:54 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:54 --> Language Class Initialized
INFO - 2016-09-23 22:49:54 --> URI Class Initialized
INFO - 2016-09-23 22:49:54 --> Router Class Initialized
INFO - 2016-09-23 22:49:54 --> Loader Class Initialized
INFO - 2016-09-23 22:49:54 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:54 --> Output Class Initialized
INFO - 2016-09-23 22:49:54 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:54 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:54 --> Input Class Initialized
INFO - 2016-09-23 22:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:54 --> Language Class Initialized
INFO - 2016-09-23 22:49:54 --> Controller Class Initialized
INFO - 2016-09-23 22:49:54 --> Loader Class Initialized
INFO - 2016-09-23 22:49:54 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:54 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:54 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:54 --> Model Class Initialized
INFO - 2016-09-23 22:49:54 --> Model Class Initialized
INFO - 2016-09-23 22:49:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:54 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:54 --> Total execution time: 0.0796
INFO - 2016-09-23 22:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:54 --> Controller Class Initialized
INFO - 2016-09-23 22:49:54 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:54 --> Model Class Initialized
INFO - 2016-09-23 22:49:54 --> Model Class Initialized
INFO - 2016-09-23 22:49:54 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:49:54 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 641
ERROR - 2016-09-23 22:49:54 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 651
ERROR - 2016-09-23 22:49:54 --> Query error: Column 'score_u' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('49', '', '1', '646', NULL)
INFO - 2016-09-23 22:49:54 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:49:58 --> Config Class Initialized
INFO - 2016-09-23 22:49:58 --> Hooks Class Initialized
INFO - 2016-09-23 22:49:58 --> Config Class Initialized
INFO - 2016-09-23 22:49:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:49:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:58 --> Utf8 Class Initialized
INFO - 2016-09-23 22:49:58 --> URI Class Initialized
INFO - 2016-09-23 22:49:58 --> Router Class Initialized
INFO - 2016-09-23 22:49:58 --> Output Class Initialized
INFO - 2016-09-23 22:49:58 --> Security Class Initialized
DEBUG - 2016-09-23 22:49:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:49:58 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:58 --> Input Class Initialized
INFO - 2016-09-23 22:49:58 --> URI Class Initialized
INFO - 2016-09-23 22:49:58 --> Language Class Initialized
INFO - 2016-09-23 22:49:58 --> Router Class Initialized
INFO - 2016-09-23 22:49:58 --> Loader Class Initialized
INFO - 2016-09-23 22:49:58 --> Output Class Initialized
INFO - 2016-09-23 22:49:58 --> Security Class Initialized
INFO - 2016-09-23 22:49:58 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:58 --> Helper loaded: language_helper
DEBUG - 2016-09-23 22:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:49:58 --> Input Class Initialized
INFO - 2016-09-23 22:49:58 --> Language Class Initialized
INFO - 2016-09-23 22:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:58 --> Controller Class Initialized
INFO - 2016-09-23 22:49:58 --> Loader Class Initialized
INFO - 2016-09-23 22:49:58 --> Helper loaded: url_helper
INFO - 2016-09-23 22:49:58 --> Helper loaded: language_helper
INFO - 2016-09-23 22:49:58 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:58 --> Model Class Initialized
INFO - 2016-09-23 22:49:58 --> Model Class Initialized
INFO - 2016-09-23 22:49:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:49:58 --> Final output sent to browser
DEBUG - 2016-09-23 22:49:58 --> Total execution time: 0.0712
INFO - 2016-09-23 22:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:49:58 --> Controller Class Initialized
INFO - 2016-09-23 22:49:58 --> Database Driver Class Initialized
INFO - 2016-09-23 22:49:58 --> Model Class Initialized
INFO - 2016-09-23 22:49:58 --> Model Class Initialized
INFO - 2016-09-23 22:49:58 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:49:58 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 641
ERROR - 2016-09-23 22:49:58 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 651
ERROR - 2016-09-23 22:49:58 --> Query error: Column 'score_u' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('49', '', '1', '646', NULL)
INFO - 2016-09-23 22:49:58 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:50:01 --> Config Class Initialized
INFO - 2016-09-23 22:50:01 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:50:01 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:50:01 --> Utf8 Class Initialized
INFO - 2016-09-23 22:50:01 --> URI Class Initialized
INFO - 2016-09-23 22:50:01 --> Router Class Initialized
INFO - 2016-09-23 22:50:01 --> Output Class Initialized
INFO - 2016-09-23 22:50:01 --> Security Class Initialized
DEBUG - 2016-09-23 22:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:50:01 --> Input Class Initialized
INFO - 2016-09-23 22:50:01 --> Language Class Initialized
INFO - 2016-09-23 22:50:01 --> Loader Class Initialized
INFO - 2016-09-23 22:50:01 --> Helper loaded: url_helper
INFO - 2016-09-23 22:50:01 --> Helper loaded: language_helper
INFO - 2016-09-23 22:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:50:01 --> Controller Class Initialized
INFO - 2016-09-23 22:50:01 --> Database Driver Class Initialized
INFO - 2016-09-23 22:50:01 --> Model Class Initialized
INFO - 2016-09-23 22:50:01 --> Model Class Initialized
INFO - 2016-09-23 22:50:01 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:50:01 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 641
ERROR - 2016-09-23 22:50:01 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 651
ERROR - 2016-09-23 22:50:01 --> Query error: Column 'score_u' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('49', '', '1', '646', NULL)
INFO - 2016-09-23 22:50:01 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:50:02 --> Config Class Initialized
INFO - 2016-09-23 22:50:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:50:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:50:02 --> Utf8 Class Initialized
INFO - 2016-09-23 22:50:02 --> URI Class Initialized
INFO - 2016-09-23 22:50:02 --> Router Class Initialized
INFO - 2016-09-23 22:50:02 --> Output Class Initialized
INFO - 2016-09-23 22:50:02 --> Security Class Initialized
DEBUG - 2016-09-23 22:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:50:02 --> Config Class Initialized
INFO - 2016-09-23 22:50:02 --> Config Class Initialized
INFO - 2016-09-23 22:50:02 --> Input Class Initialized
INFO - 2016-09-23 22:50:02 --> Hooks Class Initialized
INFO - 2016-09-23 22:50:02 --> Hooks Class Initialized
INFO - 2016-09-23 22:50:02 --> Language Class Initialized
DEBUG - 2016-09-23 22:50:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:50:02 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:50:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:50:02 --> Utf8 Class Initialized
ERROR - 2016-09-23 22:50:02 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:50:02 --> URI Class Initialized
INFO - 2016-09-23 22:50:02 --> URI Class Initialized
INFO - 2016-09-23 22:50:02 --> Router Class Initialized
INFO - 2016-09-23 22:50:02 --> Router Class Initialized
INFO - 2016-09-23 22:50:02 --> Output Class Initialized
INFO - 2016-09-23 22:50:02 --> Output Class Initialized
INFO - 2016-09-23 22:50:02 --> Security Class Initialized
INFO - 2016-09-23 22:50:02 --> Security Class Initialized
DEBUG - 2016-09-23 22:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:50:02 --> Input Class Initialized
INFO - 2016-09-23 22:50:02 --> Language Class Initialized
DEBUG - 2016-09-23 22:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:50:02 --> Input Class Initialized
INFO - 2016-09-23 22:50:02 --> Language Class Initialized
INFO - 2016-09-23 22:50:02 --> Loader Class Initialized
INFO - 2016-09-23 22:50:02 --> Helper loaded: url_helper
INFO - 2016-09-23 22:50:02 --> Loader Class Initialized
INFO - 2016-09-23 22:50:02 --> Helper loaded: language_helper
INFO - 2016-09-23 22:50:02 --> Helper loaded: url_helper
INFO - 2016-09-23 22:50:02 --> Helper loaded: language_helper
INFO - 2016-09-23 22:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:50:02 --> Controller Class Initialized
INFO - 2016-09-23 22:50:02 --> Database Driver Class Initialized
INFO - 2016-09-23 22:50:02 --> Model Class Initialized
INFO - 2016-09-23 22:50:02 --> Model Class Initialized
INFO - 2016-09-23 22:50:02 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:50:02 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
ERROR - 2016-09-23 22:50:02 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474651202, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` = 49
INFO - 2016-09-23 22:50:02 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:50:02 --> Controller Class Initialized
INFO - 2016-09-23 22:50:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:50:03 --> Model Class Initialized
INFO - 2016-09-23 22:50:03 --> Model Class Initialized
INFO - 2016-09-23 22:50:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:50:03 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 341
ERROR - 2016-09-23 22:50:03 --> Severity: Notice --> Undefined offset: 646 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 351
ERROR - 2016-09-23 22:50:03 --> Query error: Column 'score_u' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('49', '', '1', '646', NULL)
INFO - 2016-09-23 22:50:03 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-23 22:51:29 --> Config Class Initialized
INFO - 2016-09-23 22:51:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:29 --> URI Class Initialized
INFO - 2016-09-23 22:51:29 --> Router Class Initialized
INFO - 2016-09-23 22:51:29 --> Output Class Initialized
INFO - 2016-09-23 22:51:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:29 --> Input Class Initialized
INFO - 2016-09-23 22:51:29 --> Language Class Initialized
INFO - 2016-09-23 22:51:29 --> Loader Class Initialized
INFO - 2016-09-23 22:51:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:29 --> Controller Class Initialized
INFO - 2016-09-23 22:51:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:29 --> Model Class Initialized
INFO - 2016-09-23 22:51:29 --> Model Class Initialized
INFO - 2016-09-23 22:51:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:51:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:51:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:51:29 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:29 --> Total execution time: 0.0716
INFO - 2016-09-23 22:51:42 --> Config Class Initialized
INFO - 2016-09-23 22:51:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:42 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:42 --> URI Class Initialized
INFO - 2016-09-23 22:51:42 --> Router Class Initialized
INFO - 2016-09-23 22:51:42 --> Output Class Initialized
INFO - 2016-09-23 22:51:42 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:42 --> Input Class Initialized
INFO - 2016-09-23 22:51:42 --> Language Class Initialized
INFO - 2016-09-23 22:51:42 --> Loader Class Initialized
INFO - 2016-09-23 22:51:42 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:42 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:42 --> Controller Class Initialized
INFO - 2016-09-23 22:51:42 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:42 --> Model Class Initialized
INFO - 2016-09-23 22:51:42 --> Model Class Initialized
INFO - 2016-09-23 22:51:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:51:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 22:51:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:51:42 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:42 --> Total execution time: 0.0673
INFO - 2016-09-23 22:51:45 --> Config Class Initialized
INFO - 2016-09-23 22:51:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:45 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:45 --> URI Class Initialized
INFO - 2016-09-23 22:51:45 --> Router Class Initialized
INFO - 2016-09-23 22:51:45 --> Output Class Initialized
INFO - 2016-09-23 22:51:45 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:45 --> Input Class Initialized
INFO - 2016-09-23 22:51:45 --> Language Class Initialized
INFO - 2016-09-23 22:51:45 --> Loader Class Initialized
INFO - 2016-09-23 22:51:45 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:45 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:45 --> Controller Class Initialized
INFO - 2016-09-23 22:51:45 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:45 --> Config Class Initialized
INFO - 2016-09-23 22:51:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:45 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:45 --> URI Class Initialized
INFO - 2016-09-23 22:51:45 --> Router Class Initialized
INFO - 2016-09-23 22:51:45 --> Output Class Initialized
INFO - 2016-09-23 22:51:45 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:45 --> Input Class Initialized
INFO - 2016-09-23 22:51:45 --> Language Class Initialized
INFO - 2016-09-23 22:51:45 --> Loader Class Initialized
INFO - 2016-09-23 22:51:45 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:45 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:45 --> Controller Class Initialized
INFO - 2016-09-23 22:51:45 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:51:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 22:51:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:51:45 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:45 --> Total execution time: 0.0624
INFO - 2016-09-23 22:51:45 --> Config Class Initialized
INFO - 2016-09-23 22:51:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:45 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:45 --> Config Class Initialized
INFO - 2016-09-23 22:51:45 --> URI Class Initialized
INFO - 2016-09-23 22:51:45 --> Hooks Class Initialized
INFO - 2016-09-23 22:51:45 --> Router Class Initialized
DEBUG - 2016-09-23 22:51:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:45 --> Output Class Initialized
INFO - 2016-09-23 22:51:45 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:45 --> URI Class Initialized
INFO - 2016-09-23 22:51:45 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:45 --> Input Class Initialized
INFO - 2016-09-23 22:51:45 --> Router Class Initialized
INFO - 2016-09-23 22:51:45 --> Language Class Initialized
INFO - 2016-09-23 22:51:45 --> Output Class Initialized
INFO - 2016-09-23 22:51:45 --> Loader Class Initialized
INFO - 2016-09-23 22:51:45 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:45 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:45 --> Input Class Initialized
INFO - 2016-09-23 22:51:45 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:45 --> Language Class Initialized
INFO - 2016-09-23 22:51:45 --> Loader Class Initialized
INFO - 2016-09-23 22:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:45 --> Controller Class Initialized
INFO - 2016-09-23 22:51:45 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:45 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:45 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:45 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:45 --> Total execution time: 0.0787
INFO - 2016-09-23 22:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:45 --> Controller Class Initialized
INFO - 2016-09-23 22:51:45 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Model Class Initialized
INFO - 2016-09-23 22:51:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:51:45 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 22:51:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 22:51:46 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:46 --> Total execution time: 0.1088
INFO - 2016-09-23 22:51:49 --> Config Class Initialized
INFO - 2016-09-23 22:51:49 --> Config Class Initialized
INFO - 2016-09-23 22:51:49 --> Hooks Class Initialized
INFO - 2016-09-23 22:51:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:49 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:51:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:49 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:49 --> URI Class Initialized
INFO - 2016-09-23 22:51:49 --> URI Class Initialized
INFO - 2016-09-23 22:51:49 --> Router Class Initialized
INFO - 2016-09-23 22:51:49 --> Router Class Initialized
INFO - 2016-09-23 22:51:49 --> Output Class Initialized
INFO - 2016-09-23 22:51:49 --> Output Class Initialized
INFO - 2016-09-23 22:51:49 --> Security Class Initialized
INFO - 2016-09-23 22:51:49 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:49 --> Input Class Initialized
INFO - 2016-09-23 22:51:49 --> Language Class Initialized
DEBUG - 2016-09-23 22:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:49 --> Input Class Initialized
INFO - 2016-09-23 22:51:49 --> Language Class Initialized
INFO - 2016-09-23 22:51:49 --> Loader Class Initialized
INFO - 2016-09-23 22:51:49 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:49 --> Loader Class Initialized
INFO - 2016-09-23 22:51:49 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:49 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:49 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:49 --> Controller Class Initialized
INFO - 2016-09-23 22:51:49 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:49 --> Model Class Initialized
INFO - 2016-09-23 22:51:49 --> Model Class Initialized
INFO - 2016-09-23 22:51:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:49 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:49 --> Total execution time: 0.0755
INFO - 2016-09-23 22:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:49 --> Controller Class Initialized
INFO - 2016-09-23 22:51:49 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:49 --> Model Class Initialized
INFO - 2016-09-23 22:51:49 --> Model Class Initialized
INFO - 2016-09-23 22:51:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:49 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:49 --> Total execution time: 0.1036
INFO - 2016-09-23 22:51:56 --> Config Class Initialized
INFO - 2016-09-23 22:51:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:56 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:56 --> Config Class Initialized
INFO - 2016-09-23 22:51:56 --> Hooks Class Initialized
INFO - 2016-09-23 22:51:56 --> URI Class Initialized
INFO - 2016-09-23 22:51:56 --> Router Class Initialized
DEBUG - 2016-09-23 22:51:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:56 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:56 --> Output Class Initialized
INFO - 2016-09-23 22:51:56 --> URI Class Initialized
INFO - 2016-09-23 22:51:56 --> Security Class Initialized
INFO - 2016-09-23 22:51:56 --> Router Class Initialized
DEBUG - 2016-09-23 22:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:56 --> Input Class Initialized
INFO - 2016-09-23 22:51:56 --> Output Class Initialized
INFO - 2016-09-23 22:51:56 --> Language Class Initialized
INFO - 2016-09-23 22:51:56 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:56 --> Loader Class Initialized
INFO - 2016-09-23 22:51:56 --> Input Class Initialized
INFO - 2016-09-23 22:51:56 --> Language Class Initialized
INFO - 2016-09-23 22:51:56 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:56 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:56 --> Loader Class Initialized
INFO - 2016-09-23 22:51:56 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:56 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:56 --> Controller Class Initialized
INFO - 2016-09-23 22:51:56 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:56 --> Model Class Initialized
INFO - 2016-09-23 22:51:56 --> Model Class Initialized
INFO - 2016-09-23 22:51:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:56 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:56 --> Total execution time: 0.0832
INFO - 2016-09-23 22:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:56 --> Controller Class Initialized
INFO - 2016-09-23 22:51:56 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:56 --> Model Class Initialized
INFO - 2016-09-23 22:51:56 --> Model Class Initialized
INFO - 2016-09-23 22:51:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:56 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:56 --> Total execution time: 0.0965
INFO - 2016-09-23 22:51:59 --> Config Class Initialized
INFO - 2016-09-23 22:51:59 --> Hooks Class Initialized
INFO - 2016-09-23 22:51:59 --> Config Class Initialized
INFO - 2016-09-23 22:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:51:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:59 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:59 --> URI Class Initialized
DEBUG - 2016-09-23 22:51:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:51:59 --> Router Class Initialized
INFO - 2016-09-23 22:51:59 --> Utf8 Class Initialized
INFO - 2016-09-23 22:51:59 --> URI Class Initialized
INFO - 2016-09-23 22:51:59 --> Output Class Initialized
INFO - 2016-09-23 22:51:59 --> Router Class Initialized
INFO - 2016-09-23 22:51:59 --> Security Class Initialized
INFO - 2016-09-23 22:51:59 --> Output Class Initialized
DEBUG - 2016-09-23 22:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:59 --> Input Class Initialized
INFO - 2016-09-23 22:51:59 --> Language Class Initialized
INFO - 2016-09-23 22:51:59 --> Security Class Initialized
DEBUG - 2016-09-23 22:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:51:59 --> Input Class Initialized
INFO - 2016-09-23 22:51:59 --> Language Class Initialized
INFO - 2016-09-23 22:51:59 --> Loader Class Initialized
INFO - 2016-09-23 22:51:59 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:59 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:59 --> Loader Class Initialized
INFO - 2016-09-23 22:51:59 --> Helper loaded: url_helper
INFO - 2016-09-23 22:51:59 --> Helper loaded: language_helper
INFO - 2016-09-23 22:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:59 --> Controller Class Initialized
INFO - 2016-09-23 22:51:59 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:59 --> Model Class Initialized
INFO - 2016-09-23 22:51:59 --> Model Class Initialized
INFO - 2016-09-23 22:51:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:59 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:59 --> Total execution time: 0.0737
INFO - 2016-09-23 22:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:51:59 --> Controller Class Initialized
INFO - 2016-09-23 22:51:59 --> Database Driver Class Initialized
INFO - 2016-09-23 22:51:59 --> Model Class Initialized
INFO - 2016-09-23 22:51:59 --> Model Class Initialized
INFO - 2016-09-23 22:51:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:51:59 --> Final output sent to browser
DEBUG - 2016-09-23 22:51:59 --> Total execution time: 0.1080
INFO - 2016-09-23 22:52:03 --> Config Class Initialized
INFO - 2016-09-23 22:52:03 --> Hooks Class Initialized
INFO - 2016-09-23 22:52:03 --> Config Class Initialized
INFO - 2016-09-23 22:52:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:03 --> Utf8 Class Initialized
DEBUG - 2016-09-23 22:52:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:03 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:03 --> URI Class Initialized
INFO - 2016-09-23 22:52:03 --> URI Class Initialized
INFO - 2016-09-23 22:52:03 --> Router Class Initialized
INFO - 2016-09-23 22:52:03 --> Router Class Initialized
INFO - 2016-09-23 22:52:03 --> Output Class Initialized
INFO - 2016-09-23 22:52:03 --> Output Class Initialized
INFO - 2016-09-23 22:52:03 --> Security Class Initialized
INFO - 2016-09-23 22:52:03 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:03 --> Input Class Initialized
INFO - 2016-09-23 22:52:03 --> Language Class Initialized
DEBUG - 2016-09-23 22:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:03 --> Input Class Initialized
INFO - 2016-09-23 22:52:03 --> Language Class Initialized
INFO - 2016-09-23 22:52:03 --> Loader Class Initialized
INFO - 2016-09-23 22:52:03 --> Loader Class Initialized
INFO - 2016-09-23 22:52:03 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:03 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:03 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:03 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:03 --> Controller Class Initialized
INFO - 2016-09-23 22:52:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:03 --> Model Class Initialized
INFO - 2016-09-23 22:52:03 --> Model Class Initialized
INFO - 2016-09-23 22:52:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:03 --> Final output sent to browser
DEBUG - 2016-09-23 22:52:03 --> Total execution time: 0.0953
INFO - 2016-09-23 22:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:03 --> Controller Class Initialized
INFO - 2016-09-23 22:52:03 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:03 --> Model Class Initialized
INFO - 2016-09-23 22:52:03 --> Model Class Initialized
INFO - 2016-09-23 22:52:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:03 --> Final output sent to browser
DEBUG - 2016-09-23 22:52:03 --> Total execution time: 0.1248
INFO - 2016-09-23 22:52:06 --> Config Class Initialized
INFO - 2016-09-23 22:52:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:06 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:06 --> URI Class Initialized
INFO - 2016-09-23 22:52:06 --> Router Class Initialized
INFO - 2016-09-23 22:52:06 --> Output Class Initialized
INFO - 2016-09-23 22:52:06 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:06 --> Input Class Initialized
INFO - 2016-09-23 22:52:06 --> Language Class Initialized
INFO - 2016-09-23 22:52:06 --> Loader Class Initialized
INFO - 2016-09-23 22:52:06 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:06 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:06 --> Controller Class Initialized
INFO - 2016-09-23 22:52:06 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:06 --> Model Class Initialized
INFO - 2016-09-23 22:52:06 --> Model Class Initialized
INFO - 2016-09-23 22:52:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:06 --> Final output sent to browser
DEBUG - 2016-09-23 22:52:06 --> Total execution time: 0.0907
INFO - 2016-09-23 22:52:07 --> Config Class Initialized
INFO - 2016-09-23 22:52:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:07 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:07 --> URI Class Initialized
INFO - 2016-09-23 22:52:07 --> Router Class Initialized
INFO - 2016-09-23 22:52:07 --> Output Class Initialized
INFO - 2016-09-23 22:52:07 --> Security Class Initialized
INFO - 2016-09-23 22:52:07 --> Config Class Initialized
INFO - 2016-09-23 22:52:07 --> Hooks Class Initialized
INFO - 2016-09-23 22:52:07 --> Config Class Initialized
DEBUG - 2016-09-23 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:07 --> Hooks Class Initialized
INFO - 2016-09-23 22:52:07 --> Input Class Initialized
INFO - 2016-09-23 22:52:07 --> Language Class Initialized
DEBUG - 2016-09-23 22:52:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:07 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:07 --> URI Class Initialized
DEBUG - 2016-09-23 22:52:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:07 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:07 --> URI Class Initialized
ERROR - 2016-09-23 22:52:07 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 22:52:07 --> Router Class Initialized
INFO - 2016-09-23 22:52:07 --> Router Class Initialized
INFO - 2016-09-23 22:52:07 --> Output Class Initialized
INFO - 2016-09-23 22:52:07 --> Output Class Initialized
INFO - 2016-09-23 22:52:07 --> Security Class Initialized
INFO - 2016-09-23 22:52:07 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:07 --> Input Class Initialized
DEBUG - 2016-09-23 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:07 --> Input Class Initialized
INFO - 2016-09-23 22:52:07 --> Language Class Initialized
INFO - 2016-09-23 22:52:07 --> Language Class Initialized
INFO - 2016-09-23 22:52:07 --> Loader Class Initialized
INFO - 2016-09-23 22:52:07 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:07 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:07 --> Loader Class Initialized
INFO - 2016-09-23 22:52:07 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:07 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:07 --> Controller Class Initialized
INFO - 2016-09-23 22:52:07 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:07 --> Model Class Initialized
INFO - 2016-09-23 22:52:07 --> Model Class Initialized
INFO - 2016-09-23 22:52:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:07 --> Final output sent to browser
DEBUG - 2016-09-23 22:52:07 --> Total execution time: 0.1124
INFO - 2016-09-23 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:07 --> Controller Class Initialized
INFO - 2016-09-23 22:52:07 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:07 --> Model Class Initialized
INFO - 2016-09-23 22:52:07 --> Model Class Initialized
INFO - 2016-09-23 22:52:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:07 --> Config Class Initialized
INFO - 2016-09-23 22:52:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:07 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:07 --> URI Class Initialized
INFO - 2016-09-23 22:52:07 --> Router Class Initialized
INFO - 2016-09-23 22:52:07 --> Output Class Initialized
INFO - 2016-09-23 22:52:07 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:07 --> Input Class Initialized
INFO - 2016-09-23 22:52:07 --> Language Class Initialized
INFO - 2016-09-23 22:52:07 --> Loader Class Initialized
INFO - 2016-09-23 22:52:07 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:07 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:07 --> Controller Class Initialized
INFO - 2016-09-23 22:52:07 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:07 --> Model Class Initialized
INFO - 2016-09-23 22:52:07 --> Model Class Initialized
INFO - 2016-09-23 22:52:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:52:07 --> Final output sent to browser
DEBUG - 2016-09-23 22:52:07 --> Total execution time: 0.0826
INFO - 2016-09-23 22:52:13 --> Config Class Initialized
INFO - 2016-09-23 22:52:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:13 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:13 --> URI Class Initialized
INFO - 2016-09-23 22:52:13 --> Router Class Initialized
INFO - 2016-09-23 22:52:13 --> Output Class Initialized
INFO - 2016-09-23 22:52:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:13 --> Input Class Initialized
INFO - 2016-09-23 22:52:13 --> Language Class Initialized
INFO - 2016-09-23 22:52:13 --> Loader Class Initialized
INFO - 2016-09-23 22:52:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:13 --> Controller Class Initialized
INFO - 2016-09-23 22:52:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:13 --> Model Class Initialized
INFO - 2016-09-23 22:52:13 --> Model Class Initialized
INFO - 2016-09-23 22:52:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:13 --> Config Class Initialized
INFO - 2016-09-23 22:52:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:13 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:13 --> URI Class Initialized
INFO - 2016-09-23 22:52:13 --> Router Class Initialized
INFO - 2016-09-23 22:52:13 --> Output Class Initialized
INFO - 2016-09-23 22:52:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:13 --> Input Class Initialized
INFO - 2016-09-23 22:52:13 --> Language Class Initialized
INFO - 2016-09-23 22:52:13 --> Loader Class Initialized
INFO - 2016-09-23 22:52:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:13 --> Controller Class Initialized
INFO - 2016-09-23 22:52:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:13 --> Model Class Initialized
INFO - 2016-09-23 22:52:13 --> Model Class Initialized
INFO - 2016-09-23 22:52:13 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:52:13 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 493
INFO - 2016-09-23 22:52:13 --> Config Class Initialized
INFO - 2016-09-23 22:52:13 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:52:13 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:52:13 --> Utf8 Class Initialized
INFO - 2016-09-23 22:52:13 --> URI Class Initialized
INFO - 2016-09-23 22:52:13 --> Router Class Initialized
INFO - 2016-09-23 22:52:13 --> Output Class Initialized
INFO - 2016-09-23 22:52:13 --> Security Class Initialized
DEBUG - 2016-09-23 22:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:52:13 --> Input Class Initialized
INFO - 2016-09-23 22:52:13 --> Language Class Initialized
INFO - 2016-09-23 22:52:13 --> Loader Class Initialized
INFO - 2016-09-23 22:52:13 --> Helper loaded: url_helper
INFO - 2016-09-23 22:52:13 --> Helper loaded: language_helper
INFO - 2016-09-23 22:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:52:13 --> Controller Class Initialized
INFO - 2016-09-23 22:52:13 --> Database Driver Class Initialized
INFO - 2016-09-23 22:52:13 --> Model Class Initialized
INFO - 2016-09-23 22:52:13 --> Model Class Initialized
INFO - 2016-09-23 22:52:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:52:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:52:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:52:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:52:13 --> Final output sent to browser
DEBUG - 2016-09-23 22:52:13 --> Total execution time: 0.0722
INFO - 2016-09-23 22:53:26 --> Config Class Initialized
INFO - 2016-09-23 22:53:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:53:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:53:26 --> Utf8 Class Initialized
INFO - 2016-09-23 22:53:26 --> URI Class Initialized
INFO - 2016-09-23 22:53:26 --> Router Class Initialized
INFO - 2016-09-23 22:53:26 --> Output Class Initialized
INFO - 2016-09-23 22:53:26 --> Security Class Initialized
DEBUG - 2016-09-23 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:53:26 --> Input Class Initialized
INFO - 2016-09-23 22:53:26 --> Language Class Initialized
INFO - 2016-09-23 22:53:26 --> Loader Class Initialized
INFO - 2016-09-23 22:53:26 --> Helper loaded: url_helper
INFO - 2016-09-23 22:53:26 --> Helper loaded: language_helper
INFO - 2016-09-23 22:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:53:26 --> Controller Class Initialized
INFO - 2016-09-23 22:53:26 --> Database Driver Class Initialized
INFO - 2016-09-23 22:53:26 --> Model Class Initialized
INFO - 2016-09-23 22:53:26 --> Model Class Initialized
INFO - 2016-09-23 22:53:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:53:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:53:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:53:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:53:26 --> Final output sent to browser
DEBUG - 2016-09-23 22:53:26 --> Total execution time: 0.0697
INFO - 2016-09-23 22:53:29 --> Config Class Initialized
INFO - 2016-09-23 22:53:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:53:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:53:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:53:29 --> URI Class Initialized
INFO - 2016-09-23 22:53:29 --> Router Class Initialized
INFO - 2016-09-23 22:53:29 --> Output Class Initialized
INFO - 2016-09-23 22:53:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:53:29 --> Input Class Initialized
INFO - 2016-09-23 22:53:29 --> Language Class Initialized
INFO - 2016-09-23 22:53:29 --> Loader Class Initialized
INFO - 2016-09-23 22:53:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:53:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:53:29 --> Controller Class Initialized
INFO - 2016-09-23 22:53:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:53:29 --> Model Class Initialized
INFO - 2016-09-23 22:53:29 --> Model Class Initialized
INFO - 2016-09-23 22:53:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:53:29 --> Config Class Initialized
INFO - 2016-09-23 22:53:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:53:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:53:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:53:29 --> URI Class Initialized
INFO - 2016-09-23 22:53:29 --> Router Class Initialized
INFO - 2016-09-23 22:53:29 --> Output Class Initialized
INFO - 2016-09-23 22:53:29 --> Security Class Initialized
DEBUG - 2016-09-23 22:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:53:29 --> Input Class Initialized
INFO - 2016-09-23 22:53:29 --> Language Class Initialized
INFO - 2016-09-23 22:53:29 --> Loader Class Initialized
INFO - 2016-09-23 22:53:29 --> Helper loaded: url_helper
INFO - 2016-09-23 22:53:29 --> Helper loaded: language_helper
INFO - 2016-09-23 22:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:53:29 --> Controller Class Initialized
INFO - 2016-09-23 22:53:29 --> Database Driver Class Initialized
INFO - 2016-09-23 22:53:29 --> Model Class Initialized
INFO - 2016-09-23 22:53:29 --> Model Class Initialized
INFO - 2016-09-23 22:53:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:53:29 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 493
INFO - 2016-09-23 22:53:29 --> Config Class Initialized
INFO - 2016-09-23 22:53:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:53:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:53:29 --> Utf8 Class Initialized
INFO - 2016-09-23 22:53:29 --> URI Class Initialized
INFO - 2016-09-23 22:53:29 --> Router Class Initialized
INFO - 2016-09-23 22:53:30 --> Output Class Initialized
INFO - 2016-09-23 22:53:30 --> Security Class Initialized
DEBUG - 2016-09-23 22:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:53:30 --> Input Class Initialized
INFO - 2016-09-23 22:53:30 --> Language Class Initialized
INFO - 2016-09-23 22:53:30 --> Loader Class Initialized
INFO - 2016-09-23 22:53:30 --> Helper loaded: url_helper
INFO - 2016-09-23 22:53:30 --> Helper loaded: language_helper
INFO - 2016-09-23 22:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:53:30 --> Controller Class Initialized
INFO - 2016-09-23 22:53:30 --> Database Driver Class Initialized
INFO - 2016-09-23 22:53:30 --> Model Class Initialized
INFO - 2016-09-23 22:53:30 --> Model Class Initialized
INFO - 2016-09-23 22:53:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:53:30 --> Final output sent to browser
DEBUG - 2016-09-23 22:53:30 --> Total execution time: 0.0722
INFO - 2016-09-23 22:54:27 --> Config Class Initialized
INFO - 2016-09-23 22:54:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:54:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:54:27 --> Utf8 Class Initialized
INFO - 2016-09-23 22:54:27 --> URI Class Initialized
INFO - 2016-09-23 22:54:27 --> Router Class Initialized
INFO - 2016-09-23 22:54:27 --> Output Class Initialized
INFO - 2016-09-23 22:54:27 --> Security Class Initialized
DEBUG - 2016-09-23 22:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:54:27 --> Input Class Initialized
INFO - 2016-09-23 22:54:27 --> Language Class Initialized
INFO - 2016-09-23 22:54:27 --> Loader Class Initialized
INFO - 2016-09-23 22:54:27 --> Helper loaded: url_helper
INFO - 2016-09-23 22:54:27 --> Helper loaded: language_helper
INFO - 2016-09-23 22:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:54:27 --> Controller Class Initialized
INFO - 2016-09-23 22:54:27 --> Database Driver Class Initialized
INFO - 2016-09-23 22:54:27 --> Model Class Initialized
INFO - 2016-09-23 22:54:27 --> Model Class Initialized
INFO - 2016-09-23 22:54:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:54:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:54:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:54:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:54:27 --> Final output sent to browser
DEBUG - 2016-09-23 22:54:27 --> Total execution time: 0.0829
INFO - 2016-09-23 22:54:32 --> Config Class Initialized
INFO - 2016-09-23 22:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:54:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:54:32 --> URI Class Initialized
INFO - 2016-09-23 22:54:32 --> Router Class Initialized
INFO - 2016-09-23 22:54:32 --> Output Class Initialized
INFO - 2016-09-23 22:54:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:54:32 --> Input Class Initialized
INFO - 2016-09-23 22:54:32 --> Language Class Initialized
INFO - 2016-09-23 22:54:32 --> Loader Class Initialized
INFO - 2016-09-23 22:54:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:54:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:54:32 --> Controller Class Initialized
INFO - 2016-09-23 22:54:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:54:32 --> Model Class Initialized
INFO - 2016-09-23 22:54:32 --> Model Class Initialized
INFO - 2016-09-23 22:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:54:32 --> Config Class Initialized
INFO - 2016-09-23 22:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:54:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:54:32 --> URI Class Initialized
INFO - 2016-09-23 22:54:32 --> Router Class Initialized
INFO - 2016-09-23 22:54:32 --> Output Class Initialized
INFO - 2016-09-23 22:54:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:54:32 --> Input Class Initialized
INFO - 2016-09-23 22:54:32 --> Language Class Initialized
INFO - 2016-09-23 22:54:32 --> Loader Class Initialized
INFO - 2016-09-23 22:54:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:54:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:54:32 --> Controller Class Initialized
INFO - 2016-09-23 22:54:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:54:32 --> Model Class Initialized
INFO - 2016-09-23 22:54:32 --> Model Class Initialized
INFO - 2016-09-23 22:54:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:54:32 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 493
INFO - 2016-09-23 22:54:32 --> Config Class Initialized
INFO - 2016-09-23 22:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:54:32 --> Utf8 Class Initialized
INFO - 2016-09-23 22:54:32 --> URI Class Initialized
INFO - 2016-09-23 22:54:32 --> Router Class Initialized
INFO - 2016-09-23 22:54:32 --> Output Class Initialized
INFO - 2016-09-23 22:54:32 --> Security Class Initialized
DEBUG - 2016-09-23 22:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:54:32 --> Input Class Initialized
INFO - 2016-09-23 22:54:32 --> Language Class Initialized
INFO - 2016-09-23 22:54:32 --> Loader Class Initialized
INFO - 2016-09-23 22:54:32 --> Helper loaded: url_helper
INFO - 2016-09-23 22:54:32 --> Helper loaded: language_helper
INFO - 2016-09-23 22:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:54:32 --> Controller Class Initialized
INFO - 2016-09-23 22:54:32 --> Database Driver Class Initialized
INFO - 2016-09-23 22:54:32 --> Model Class Initialized
INFO - 2016-09-23 22:54:32 --> Model Class Initialized
INFO - 2016-09-23 22:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:54:32 --> Final output sent to browser
DEBUG - 2016-09-23 22:54:32 --> Total execution time: 0.0953
INFO - 2016-09-23 22:54:41 --> Config Class Initialized
INFO - 2016-09-23 22:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:54:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:54:41 --> Utf8 Class Initialized
INFO - 2016-09-23 22:54:41 --> URI Class Initialized
INFO - 2016-09-23 22:54:41 --> Router Class Initialized
INFO - 2016-09-23 22:54:41 --> Output Class Initialized
INFO - 2016-09-23 22:54:41 --> Security Class Initialized
DEBUG - 2016-09-23 22:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:54:41 --> Input Class Initialized
INFO - 2016-09-23 22:54:41 --> Language Class Initialized
INFO - 2016-09-23 22:54:41 --> Loader Class Initialized
INFO - 2016-09-23 22:54:41 --> Helper loaded: url_helper
INFO - 2016-09-23 22:54:41 --> Helper loaded: language_helper
INFO - 2016-09-23 22:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:54:41 --> Controller Class Initialized
INFO - 2016-09-23 22:54:41 --> Database Driver Class Initialized
INFO - 2016-09-23 22:54:41 --> Model Class Initialized
INFO - 2016-09-23 22:54:41 --> Model Class Initialized
INFO - 2016-09-23 22:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:54:41 --> Final output sent to browser
DEBUG - 2016-09-23 22:54:41 --> Total execution time: 0.0574
INFO - 2016-09-23 22:54:41 --> Config Class Initialized
INFO - 2016-09-23 22:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:54:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:54:41 --> Utf8 Class Initialized
INFO - 2016-09-23 22:54:41 --> URI Class Initialized
INFO - 2016-09-23 22:54:41 --> Router Class Initialized
INFO - 2016-09-23 22:54:41 --> Output Class Initialized
INFO - 2016-09-23 22:54:41 --> Security Class Initialized
DEBUG - 2016-09-23 22:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:54:41 --> Input Class Initialized
INFO - 2016-09-23 22:54:41 --> Language Class Initialized
INFO - 2016-09-23 22:54:41 --> Loader Class Initialized
INFO - 2016-09-23 22:54:41 --> Helper loaded: url_helper
INFO - 2016-09-23 22:54:41 --> Helper loaded: language_helper
INFO - 2016-09-23 22:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:54:41 --> Controller Class Initialized
INFO - 2016-09-23 22:54:41 --> Database Driver Class Initialized
INFO - 2016-09-23 22:54:41 --> Model Class Initialized
INFO - 2016-09-23 22:54:41 --> Model Class Initialized
INFO - 2016-09-23 22:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:54:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:54:41 --> Final output sent to browser
DEBUG - 2016-09-23 22:54:41 --> Total execution time: 0.0759
INFO - 2016-09-23 22:55:28 --> Config Class Initialized
INFO - 2016-09-23 22:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:55:28 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:55:28 --> Utf8 Class Initialized
INFO - 2016-09-23 22:55:28 --> URI Class Initialized
INFO - 2016-09-23 22:55:28 --> Router Class Initialized
INFO - 2016-09-23 22:55:28 --> Output Class Initialized
INFO - 2016-09-23 22:55:28 --> Security Class Initialized
DEBUG - 2016-09-23 22:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:55:28 --> Input Class Initialized
INFO - 2016-09-23 22:55:28 --> Language Class Initialized
INFO - 2016-09-23 22:55:28 --> Loader Class Initialized
INFO - 2016-09-23 22:55:28 --> Helper loaded: url_helper
INFO - 2016-09-23 22:55:28 --> Helper loaded: language_helper
INFO - 2016-09-23 22:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:55:28 --> Controller Class Initialized
INFO - 2016-09-23 22:55:28 --> Database Driver Class Initialized
INFO - 2016-09-23 22:55:28 --> Model Class Initialized
INFO - 2016-09-23 22:55:28 --> Model Class Initialized
INFO - 2016-09-23 22:55:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:56:37 --> Config Class Initialized
INFO - 2016-09-23 22:56:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:56:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:56:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:56:37 --> URI Class Initialized
INFO - 2016-09-23 22:56:38 --> Router Class Initialized
INFO - 2016-09-23 22:56:38 --> Output Class Initialized
INFO - 2016-09-23 22:56:38 --> Security Class Initialized
DEBUG - 2016-09-23 22:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:56:38 --> Input Class Initialized
INFO - 2016-09-23 22:56:38 --> Language Class Initialized
INFO - 2016-09-23 22:56:38 --> Loader Class Initialized
INFO - 2016-09-23 22:56:38 --> Helper loaded: url_helper
INFO - 2016-09-23 22:56:38 --> Helper loaded: language_helper
INFO - 2016-09-23 22:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:56:38 --> Controller Class Initialized
INFO - 2016-09-23 22:56:38 --> Database Driver Class Initialized
INFO - 2016-09-23 22:56:38 --> Model Class Initialized
INFO - 2016-09-23 22:56:38 --> Model Class Initialized
INFO - 2016-09-23 22:56:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:56:57 --> Config Class Initialized
INFO - 2016-09-23 22:56:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:56:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:56:57 --> Utf8 Class Initialized
INFO - 2016-09-23 22:56:57 --> URI Class Initialized
INFO - 2016-09-23 22:56:57 --> Router Class Initialized
INFO - 2016-09-23 22:56:57 --> Output Class Initialized
INFO - 2016-09-23 22:56:57 --> Security Class Initialized
DEBUG - 2016-09-23 22:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:56:57 --> Input Class Initialized
INFO - 2016-09-23 22:56:57 --> Language Class Initialized
INFO - 2016-09-23 22:56:57 --> Loader Class Initialized
INFO - 2016-09-23 22:56:57 --> Helper loaded: url_helper
INFO - 2016-09-23 22:56:57 --> Helper loaded: language_helper
INFO - 2016-09-23 22:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:56:57 --> Controller Class Initialized
INFO - 2016-09-23 22:56:57 --> Database Driver Class Initialized
INFO - 2016-09-23 22:56:57 --> Model Class Initialized
INFO - 2016-09-23 22:56:57 --> Model Class Initialized
INFO - 2016-09-23 22:56:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:58:37 --> Config Class Initialized
INFO - 2016-09-23 22:58:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:58:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:58:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:58:37 --> URI Class Initialized
INFO - 2016-09-23 22:58:37 --> Router Class Initialized
INFO - 2016-09-23 22:58:37 --> Output Class Initialized
INFO - 2016-09-23 22:58:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:58:37 --> Input Class Initialized
INFO - 2016-09-23 22:58:37 --> Language Class Initialized
INFO - 2016-09-23 22:58:37 --> Loader Class Initialized
INFO - 2016-09-23 22:58:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:58:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:58:37 --> Controller Class Initialized
INFO - 2016-09-23 22:58:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:58:37 --> Model Class Initialized
INFO - 2016-09-23 22:58:37 --> Model Class Initialized
INFO - 2016-09-23 22:58:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:58:37 --> Config Class Initialized
INFO - 2016-09-23 22:58:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:58:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:58:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:58:37 --> URI Class Initialized
INFO - 2016-09-23 22:58:37 --> Router Class Initialized
INFO - 2016-09-23 22:58:37 --> Output Class Initialized
INFO - 2016-09-23 22:58:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:58:37 --> Input Class Initialized
INFO - 2016-09-23 22:58:37 --> Language Class Initialized
INFO - 2016-09-23 22:58:37 --> Loader Class Initialized
INFO - 2016-09-23 22:58:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:58:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:58:37 --> Controller Class Initialized
INFO - 2016-09-23 22:58:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:58:37 --> Model Class Initialized
INFO - 2016-09-23 22:58:37 --> Model Class Initialized
INFO - 2016-09-23 22:58:37 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 22:58:37 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 496
INFO - 2016-09-23 22:58:37 --> Config Class Initialized
INFO - 2016-09-23 22:58:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:58:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:58:37 --> Utf8 Class Initialized
INFO - 2016-09-23 22:58:37 --> URI Class Initialized
INFO - 2016-09-23 22:58:37 --> Router Class Initialized
INFO - 2016-09-23 22:58:37 --> Output Class Initialized
INFO - 2016-09-23 22:58:37 --> Security Class Initialized
DEBUG - 2016-09-23 22:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:58:37 --> Input Class Initialized
INFO - 2016-09-23 22:58:37 --> Language Class Initialized
INFO - 2016-09-23 22:58:37 --> Loader Class Initialized
INFO - 2016-09-23 22:58:37 --> Helper loaded: url_helper
INFO - 2016-09-23 22:58:37 --> Helper loaded: language_helper
INFO - 2016-09-23 22:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:58:37 --> Controller Class Initialized
INFO - 2016-09-23 22:58:37 --> Database Driver Class Initialized
INFO - 2016-09-23 22:58:37 --> Model Class Initialized
INFO - 2016-09-23 22:58:37 --> Model Class Initialized
INFO - 2016-09-23 22:58:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:58:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:58:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 22:58:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:58:37 --> Final output sent to browser
DEBUG - 2016-09-23 22:58:37 --> Total execution time: 0.0662
INFO - 2016-09-23 22:59:59 --> Config Class Initialized
INFO - 2016-09-23 22:59:59 --> Hooks Class Initialized
DEBUG - 2016-09-23 22:59:59 --> UTF-8 Support Enabled
INFO - 2016-09-23 22:59:59 --> Utf8 Class Initialized
INFO - 2016-09-23 22:59:59 --> URI Class Initialized
INFO - 2016-09-23 22:59:59 --> Router Class Initialized
INFO - 2016-09-23 22:59:59 --> Output Class Initialized
INFO - 2016-09-23 22:59:59 --> Security Class Initialized
DEBUG - 2016-09-23 22:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 22:59:59 --> Input Class Initialized
INFO - 2016-09-23 22:59:59 --> Language Class Initialized
INFO - 2016-09-23 22:59:59 --> Loader Class Initialized
INFO - 2016-09-23 22:59:59 --> Helper loaded: url_helper
INFO - 2016-09-23 22:59:59 --> Helper loaded: language_helper
INFO - 2016-09-23 22:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 22:59:59 --> Controller Class Initialized
INFO - 2016-09-23 22:59:59 --> Database Driver Class Initialized
INFO - 2016-09-23 22:59:59 --> Model Class Initialized
INFO - 2016-09-23 22:59:59 --> Model Class Initialized
INFO - 2016-09-23 22:59:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 22:59:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 22:59:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 22:59:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 22:59:59 --> Final output sent to browser
DEBUG - 2016-09-23 22:59:59 --> Total execution time: 0.0607
INFO - 2016-09-23 23:00:06 --> Config Class Initialized
INFO - 2016-09-23 23:00:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:06 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:06 --> URI Class Initialized
INFO - 2016-09-23 23:00:06 --> Router Class Initialized
INFO - 2016-09-23 23:00:06 --> Output Class Initialized
INFO - 2016-09-23 23:00:06 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:06 --> Input Class Initialized
INFO - 2016-09-23 23:00:06 --> Language Class Initialized
INFO - 2016-09-23 23:00:06 --> Loader Class Initialized
INFO - 2016-09-23 23:00:06 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:06 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:06 --> Controller Class Initialized
INFO - 2016-09-23 23:00:06 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:06 --> Model Class Initialized
INFO - 2016-09-23 23:00:06 --> Model Class Initialized
INFO - 2016-09-23 23:00:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-09-23 23:00:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:06 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:06 --> Total execution time: 0.0643
INFO - 2016-09-23 23:00:09 --> Config Class Initialized
INFO - 2016-09-23 23:00:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:09 --> URI Class Initialized
INFO - 2016-09-23 23:00:09 --> Router Class Initialized
INFO - 2016-09-23 23:00:09 --> Output Class Initialized
INFO - 2016-09-23 23:00:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:09 --> Input Class Initialized
INFO - 2016-09-23 23:00:09 --> Language Class Initialized
INFO - 2016-09-23 23:00:09 --> Loader Class Initialized
INFO - 2016-09-23 23:00:09 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:09 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:09 --> Controller Class Initialized
INFO - 2016-09-23 23:00:09 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:09 --> Model Class Initialized
INFO - 2016-09-23 23:00:09 --> Model Class Initialized
INFO - 2016-09-23 23:00:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:09 --> Config Class Initialized
INFO - 2016-09-23 23:00:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:09 --> URI Class Initialized
INFO - 2016-09-23 23:00:09 --> Router Class Initialized
INFO - 2016-09-23 23:00:09 --> Output Class Initialized
INFO - 2016-09-23 23:00:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:09 --> Input Class Initialized
INFO - 2016-09-23 23:00:09 --> Language Class Initialized
INFO - 2016-09-23 23:00:09 --> Loader Class Initialized
INFO - 2016-09-23 23:00:09 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:09 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:09 --> Controller Class Initialized
INFO - 2016-09-23 23:00:09 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:09 --> Model Class Initialized
INFO - 2016-09-23 23:00:09 --> Model Class Initialized
INFO - 2016-09-23 23:00:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:00:09 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 556
INFO - 2016-09-23 23:00:09 --> Config Class Initialized
INFO - 2016-09-23 23:00:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:09 --> URI Class Initialized
INFO - 2016-09-23 23:00:09 --> Router Class Initialized
INFO - 2016-09-23 23:00:09 --> Output Class Initialized
INFO - 2016-09-23 23:00:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:09 --> Input Class Initialized
INFO - 2016-09-23 23:00:09 --> Language Class Initialized
INFO - 2016-09-23 23:00:09 --> Loader Class Initialized
INFO - 2016-09-23 23:00:09 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:09 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:09 --> Controller Class Initialized
INFO - 2016-09-23 23:00:09 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:09 --> Model Class Initialized
INFO - 2016-09-23 23:00:09 --> Model Class Initialized
INFO - 2016-09-23 23:00:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 23:00:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:09 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:09 --> Total execution time: 0.0645
INFO - 2016-09-23 23:00:15 --> Config Class Initialized
INFO - 2016-09-23 23:00:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:15 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:15 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:15 --> URI Class Initialized
INFO - 2016-09-23 23:00:15 --> Router Class Initialized
INFO - 2016-09-23 23:00:15 --> Output Class Initialized
INFO - 2016-09-23 23:00:15 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:15 --> Input Class Initialized
INFO - 2016-09-23 23:00:15 --> Language Class Initialized
INFO - 2016-09-23 23:00:15 --> Loader Class Initialized
INFO - 2016-09-23 23:00:15 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:15 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:15 --> Controller Class Initialized
INFO - 2016-09-23 23:00:15 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:15 --> Model Class Initialized
INFO - 2016-09-23 23:00:15 --> Model Class Initialized
INFO - 2016-09-23 23:00:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:00:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:15 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:15 --> Total execution time: 0.0570
INFO - 2016-09-23 23:00:16 --> Config Class Initialized
INFO - 2016-09-23 23:00:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:16 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:16 --> URI Class Initialized
INFO - 2016-09-23 23:00:16 --> Router Class Initialized
INFO - 2016-09-23 23:00:16 --> Output Class Initialized
INFO - 2016-09-23 23:00:16 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:16 --> Input Class Initialized
INFO - 2016-09-23 23:00:16 --> Language Class Initialized
INFO - 2016-09-23 23:00:16 --> Loader Class Initialized
INFO - 2016-09-23 23:00:16 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:16 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:16 --> Controller Class Initialized
INFO - 2016-09-23 23:00:16 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:16 --> Model Class Initialized
INFO - 2016-09-23 23:00:16 --> Model Class Initialized
INFO - 2016-09-23 23:00:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:16 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:16 --> Total execution time: 0.0613
INFO - 2016-09-23 23:00:48 --> Config Class Initialized
INFO - 2016-09-23 23:00:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:48 --> URI Class Initialized
INFO - 2016-09-23 23:00:48 --> Router Class Initialized
INFO - 2016-09-23 23:00:48 --> Output Class Initialized
INFO - 2016-09-23 23:00:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:48 --> Input Class Initialized
INFO - 2016-09-23 23:00:48 --> Language Class Initialized
INFO - 2016-09-23 23:00:48 --> Loader Class Initialized
INFO - 2016-09-23 23:00:48 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:48 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:48 --> Controller Class Initialized
INFO - 2016-09-23 23:00:48 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:48 --> Model Class Initialized
INFO - 2016-09-23 23:00:48 --> Model Class Initialized
INFO - 2016-09-23 23:00:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 23:00:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:48 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:48 --> Total execution time: 0.0561
INFO - 2016-09-23 23:00:49 --> Config Class Initialized
INFO - 2016-09-23 23:00:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:49 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:49 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:49 --> URI Class Initialized
INFO - 2016-09-23 23:00:49 --> Router Class Initialized
INFO - 2016-09-23 23:00:49 --> Output Class Initialized
INFO - 2016-09-23 23:00:49 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:49 --> Input Class Initialized
INFO - 2016-09-23 23:00:49 --> Language Class Initialized
INFO - 2016-09-23 23:00:49 --> Loader Class Initialized
INFO - 2016-09-23 23:00:49 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:49 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:49 --> Controller Class Initialized
INFO - 2016-09-23 23:00:49 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:49 --> Model Class Initialized
INFO - 2016-09-23 23:00:49 --> Model Class Initialized
INFO - 2016-09-23 23:00:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 23:00:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:49 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:49 --> Total execution time: 0.0769
INFO - 2016-09-23 23:00:52 --> Config Class Initialized
INFO - 2016-09-23 23:00:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:52 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:52 --> URI Class Initialized
INFO - 2016-09-23 23:00:52 --> Router Class Initialized
INFO - 2016-09-23 23:00:52 --> Output Class Initialized
INFO - 2016-09-23 23:00:52 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:52 --> Input Class Initialized
INFO - 2016-09-23 23:00:52 --> Language Class Initialized
INFO - 2016-09-23 23:00:52 --> Loader Class Initialized
INFO - 2016-09-23 23:00:52 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:52 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:52 --> Controller Class Initialized
INFO - 2016-09-23 23:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:52 --> Config Class Initialized
INFO - 2016-09-23 23:00:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:52 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:52 --> URI Class Initialized
INFO - 2016-09-23 23:00:52 --> Router Class Initialized
INFO - 2016-09-23 23:00:52 --> Output Class Initialized
INFO - 2016-09-23 23:00:52 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:52 --> Input Class Initialized
INFO - 2016-09-23 23:00:52 --> Language Class Initialized
INFO - 2016-09-23 23:00:52 --> Loader Class Initialized
INFO - 2016-09-23 23:00:52 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:52 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:52 --> Controller Class Initialized
INFO - 2016-09-23 23:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 23:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:52 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:52 --> Total execution time: 0.0606
INFO - 2016-09-23 23:00:52 --> Config Class Initialized
INFO - 2016-09-23 23:00:52 --> Hooks Class Initialized
INFO - 2016-09-23 23:00:52 --> Config Class Initialized
INFO - 2016-09-23 23:00:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:52 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:00:52 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:52 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:52 --> URI Class Initialized
INFO - 2016-09-23 23:00:52 --> Router Class Initialized
INFO - 2016-09-23 23:00:52 --> URI Class Initialized
INFO - 2016-09-23 23:00:52 --> Output Class Initialized
INFO - 2016-09-23 23:00:52 --> Router Class Initialized
INFO - 2016-09-23 23:00:52 --> Output Class Initialized
INFO - 2016-09-23 23:00:52 --> Security Class Initialized
INFO - 2016-09-23 23:00:52 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-23 23:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:52 --> Input Class Initialized
INFO - 2016-09-23 23:00:52 --> Input Class Initialized
INFO - 2016-09-23 23:00:52 --> Language Class Initialized
INFO - 2016-09-23 23:00:52 --> Language Class Initialized
INFO - 2016-09-23 23:00:52 --> Loader Class Initialized
INFO - 2016-09-23 23:00:52 --> Loader Class Initialized
INFO - 2016-09-23 23:00:52 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:52 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:52 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:52 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:52 --> Controller Class Initialized
INFO - 2016-09-23 23:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:52 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:52 --> Total execution time: 0.0925
INFO - 2016-09-23 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:52 --> Controller Class Initialized
INFO - 2016-09-23 23:00:52 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Model Class Initialized
INFO - 2016-09-23 23:00:52 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:00:52 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 23:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 23:00:52 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:52 --> Total execution time: 0.1205
INFO - 2016-09-23 23:00:57 --> Config Class Initialized
INFO - 2016-09-23 23:00:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:00:57 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:00:57 --> Utf8 Class Initialized
INFO - 2016-09-23 23:00:57 --> URI Class Initialized
INFO - 2016-09-23 23:00:57 --> Router Class Initialized
INFO - 2016-09-23 23:00:57 --> Output Class Initialized
INFO - 2016-09-23 23:00:57 --> Security Class Initialized
DEBUG - 2016-09-23 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:00:57 --> Input Class Initialized
INFO - 2016-09-23 23:00:57 --> Language Class Initialized
INFO - 2016-09-23 23:00:57 --> Loader Class Initialized
INFO - 2016-09-23 23:00:57 --> Helper loaded: url_helper
INFO - 2016-09-23 23:00:57 --> Helper loaded: language_helper
INFO - 2016-09-23 23:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:00:57 --> Controller Class Initialized
INFO - 2016-09-23 23:00:57 --> Database Driver Class Initialized
INFO - 2016-09-23 23:00:57 --> Model Class Initialized
INFO - 2016-09-23 23:00:57 --> Model Class Initialized
INFO - 2016-09-23 23:00:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:00:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:00:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:00:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:00:57 --> Final output sent to browser
DEBUG - 2016-09-23 23:00:57 --> Total execution time: 0.0592
INFO - 2016-09-23 23:01:00 --> Config Class Initialized
INFO - 2016-09-23 23:01:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:01:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:01:00 --> Utf8 Class Initialized
INFO - 2016-09-23 23:01:00 --> URI Class Initialized
INFO - 2016-09-23 23:01:00 --> Router Class Initialized
INFO - 2016-09-23 23:01:00 --> Output Class Initialized
INFO - 2016-09-23 23:01:00 --> Security Class Initialized
DEBUG - 2016-09-23 23:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:01:00 --> Input Class Initialized
INFO - 2016-09-23 23:01:00 --> Language Class Initialized
INFO - 2016-09-23 23:01:01 --> Loader Class Initialized
INFO - 2016-09-23 23:01:01 --> Helper loaded: url_helper
INFO - 2016-09-23 23:01:01 --> Helper loaded: language_helper
INFO - 2016-09-23 23:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:01:01 --> Controller Class Initialized
INFO - 2016-09-23 23:01:01 --> Database Driver Class Initialized
INFO - 2016-09-23 23:01:01 --> Model Class Initialized
INFO - 2016-09-23 23:01:01 --> Model Class Initialized
INFO - 2016-09-23 23:01:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:01:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:01:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:01:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:01:01 --> Final output sent to browser
DEBUG - 2016-09-23 23:01:01 --> Total execution time: 0.0740
INFO - 2016-09-23 23:01:04 --> Config Class Initialized
INFO - 2016-09-23 23:01:04 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:01:04 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:01:04 --> Utf8 Class Initialized
INFO - 2016-09-23 23:01:04 --> URI Class Initialized
INFO - 2016-09-23 23:01:04 --> Router Class Initialized
INFO - 2016-09-23 23:01:04 --> Output Class Initialized
INFO - 2016-09-23 23:01:04 --> Security Class Initialized
DEBUG - 2016-09-23 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:01:04 --> Input Class Initialized
INFO - 2016-09-23 23:01:04 --> Language Class Initialized
INFO - 2016-09-23 23:01:04 --> Loader Class Initialized
INFO - 2016-09-23 23:01:04 --> Helper loaded: url_helper
INFO - 2016-09-23 23:01:04 --> Helper loaded: language_helper
INFO - 2016-09-23 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:01:04 --> Controller Class Initialized
INFO - 2016-09-23 23:01:04 --> Database Driver Class Initialized
INFO - 2016-09-23 23:01:04 --> Model Class Initialized
INFO - 2016-09-23 23:01:04 --> Model Class Initialized
INFO - 2016-09-23 23:01:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:01:58 --> Config Class Initialized
INFO - 2016-09-23 23:01:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:01:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:01:58 --> Utf8 Class Initialized
INFO - 2016-09-23 23:01:58 --> URI Class Initialized
INFO - 2016-09-23 23:01:58 --> Router Class Initialized
INFO - 2016-09-23 23:01:58 --> Output Class Initialized
INFO - 2016-09-23 23:01:58 --> Security Class Initialized
DEBUG - 2016-09-23 23:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:01:58 --> Input Class Initialized
INFO - 2016-09-23 23:01:58 --> Language Class Initialized
INFO - 2016-09-23 23:01:58 --> Loader Class Initialized
INFO - 2016-09-23 23:01:58 --> Helper loaded: url_helper
INFO - 2016-09-23 23:01:58 --> Helper loaded: language_helper
INFO - 2016-09-23 23:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:01:58 --> Controller Class Initialized
INFO - 2016-09-23 23:01:58 --> Database Driver Class Initialized
INFO - 2016-09-23 23:01:58 --> Model Class Initialized
INFO - 2016-09-23 23:01:58 --> Model Class Initialized
INFO - 2016-09-23 23:01:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:03 --> Config Class Initialized
INFO - 2016-09-23 23:02:03 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:03 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:03 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:03 --> URI Class Initialized
INFO - 2016-09-23 23:02:03 --> Router Class Initialized
INFO - 2016-09-23 23:02:03 --> Output Class Initialized
INFO - 2016-09-23 23:02:03 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:03 --> Input Class Initialized
INFO - 2016-09-23 23:02:03 --> Language Class Initialized
INFO - 2016-09-23 23:02:03 --> Loader Class Initialized
INFO - 2016-09-23 23:02:03 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:03 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:03 --> Controller Class Initialized
INFO - 2016-09-23 23:02:03 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:03 --> Model Class Initialized
INFO - 2016-09-23 23:02:03 --> Model Class Initialized
INFO - 2016-09-23 23:02:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:18 --> Config Class Initialized
INFO - 2016-09-23 23:02:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:18 --> URI Class Initialized
INFO - 2016-09-23 23:02:18 --> Router Class Initialized
INFO - 2016-09-23 23:02:18 --> Output Class Initialized
INFO - 2016-09-23 23:02:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:18 --> Input Class Initialized
INFO - 2016-09-23 23:02:18 --> Language Class Initialized
INFO - 2016-09-23 23:02:18 --> Loader Class Initialized
INFO - 2016-09-23 23:02:18 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:18 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:18 --> Controller Class Initialized
INFO - 2016-09-23 23:02:18 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:18 --> Model Class Initialized
INFO - 2016-09-23 23:02:18 --> Model Class Initialized
INFO - 2016-09-23 23:02:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:35 --> Config Class Initialized
INFO - 2016-09-23 23:02:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:35 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:35 --> URI Class Initialized
INFO - 2016-09-23 23:02:35 --> Router Class Initialized
INFO - 2016-09-23 23:02:35 --> Output Class Initialized
INFO - 2016-09-23 23:02:35 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:35 --> Input Class Initialized
INFO - 2016-09-23 23:02:35 --> Language Class Initialized
INFO - 2016-09-23 23:02:35 --> Loader Class Initialized
INFO - 2016-09-23 23:02:35 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:35 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:35 --> Controller Class Initialized
INFO - 2016-09-23 23:02:35 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:35 --> Model Class Initialized
INFO - 2016-09-23 23:02:35 --> Model Class Initialized
INFO - 2016-09-23 23:02:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:35 --> Config Class Initialized
INFO - 2016-09-23 23:02:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:35 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:35 --> URI Class Initialized
INFO - 2016-09-23 23:02:35 --> Router Class Initialized
INFO - 2016-09-23 23:02:35 --> Output Class Initialized
INFO - 2016-09-23 23:02:35 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:35 --> Input Class Initialized
INFO - 2016-09-23 23:02:35 --> Language Class Initialized
INFO - 2016-09-23 23:02:35 --> Loader Class Initialized
INFO - 2016-09-23 23:02:35 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:35 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:35 --> Controller Class Initialized
INFO - 2016-09-23 23:02:35 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:35 --> Model Class Initialized
INFO - 2016-09-23 23:02:35 --> Model Class Initialized
INFO - 2016-09-23 23:02:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:02:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 23:02:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:02:35 --> Final output sent to browser
DEBUG - 2016-09-23 23:02:35 --> Total execution time: 0.0635
INFO - 2016-09-23 23:02:35 --> Config Class Initialized
INFO - 2016-09-23 23:02:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:35 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:35 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:35 --> Config Class Initialized
INFO - 2016-09-23 23:02:35 --> Hooks Class Initialized
INFO - 2016-09-23 23:02:35 --> URI Class Initialized
INFO - 2016-09-23 23:02:35 --> Router Class Initialized
DEBUG - 2016-09-23 23:02:36 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:36 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:36 --> Output Class Initialized
INFO - 2016-09-23 23:02:36 --> URI Class Initialized
INFO - 2016-09-23 23:02:36 --> Security Class Initialized
INFO - 2016-09-23 23:02:36 --> Router Class Initialized
DEBUG - 2016-09-23 23:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:36 --> Input Class Initialized
INFO - 2016-09-23 23:02:36 --> Language Class Initialized
INFO - 2016-09-23 23:02:36 --> Output Class Initialized
INFO - 2016-09-23 23:02:36 --> Security Class Initialized
INFO - 2016-09-23 23:02:36 --> Loader Class Initialized
DEBUG - 2016-09-23 23:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:36 --> Input Class Initialized
INFO - 2016-09-23 23:02:36 --> Language Class Initialized
INFO - 2016-09-23 23:02:36 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:36 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:36 --> Loader Class Initialized
INFO - 2016-09-23 23:02:36 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:36 --> Controller Class Initialized
INFO - 2016-09-23 23:02:36 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:36 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:36 --> Model Class Initialized
INFO - 2016-09-23 23:02:36 --> Model Class Initialized
INFO - 2016-09-23 23:02:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:36 --> Final output sent to browser
DEBUG - 2016-09-23 23:02:36 --> Total execution time: 0.0849
INFO - 2016-09-23 23:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:36 --> Controller Class Initialized
INFO - 2016-09-23 23:02:36 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:36 --> Model Class Initialized
INFO - 2016-09-23 23:02:36 --> Model Class Initialized
INFO - 2016-09-23 23:02:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:02:36 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 23:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 23:02:36 --> Final output sent to browser
DEBUG - 2016-09-23 23:02:36 --> Total execution time: 0.1174
INFO - 2016-09-23 23:02:47 --> Config Class Initialized
INFO - 2016-09-23 23:02:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:47 --> URI Class Initialized
INFO - 2016-09-23 23:02:47 --> Router Class Initialized
INFO - 2016-09-23 23:02:47 --> Output Class Initialized
INFO - 2016-09-23 23:02:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:47 --> Input Class Initialized
INFO - 2016-09-23 23:02:47 --> Language Class Initialized
INFO - 2016-09-23 23:02:47 --> Loader Class Initialized
INFO - 2016-09-23 23:02:47 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:47 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:47 --> Controller Class Initialized
INFO - 2016-09-23 23:02:47 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:47 --> Model Class Initialized
INFO - 2016-09-23 23:02:47 --> Model Class Initialized
INFO - 2016-09-23 23:02:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:51 --> Config Class Initialized
INFO - 2016-09-23 23:02:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:51 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:51 --> URI Class Initialized
INFO - 2016-09-23 23:02:51 --> Router Class Initialized
INFO - 2016-09-23 23:02:51 --> Output Class Initialized
INFO - 2016-09-23 23:02:51 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:51 --> Input Class Initialized
INFO - 2016-09-23 23:02:51 --> Language Class Initialized
INFO - 2016-09-23 23:02:51 --> Loader Class Initialized
INFO - 2016-09-23 23:02:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:51 --> Controller Class Initialized
INFO - 2016-09-23 23:02:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:51 --> Model Class Initialized
INFO - 2016-09-23 23:02:51 --> Model Class Initialized
INFO - 2016-09-23 23:02:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:02:54 --> Config Class Initialized
INFO - 2016-09-23 23:02:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:02:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:02:54 --> Utf8 Class Initialized
INFO - 2016-09-23 23:02:54 --> URI Class Initialized
INFO - 2016-09-23 23:02:54 --> Router Class Initialized
INFO - 2016-09-23 23:02:54 --> Output Class Initialized
INFO - 2016-09-23 23:02:54 --> Security Class Initialized
DEBUG - 2016-09-23 23:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:02:54 --> Input Class Initialized
INFO - 2016-09-23 23:02:54 --> Language Class Initialized
INFO - 2016-09-23 23:02:54 --> Loader Class Initialized
INFO - 2016-09-23 23:02:54 --> Helper loaded: url_helper
INFO - 2016-09-23 23:02:54 --> Helper loaded: language_helper
INFO - 2016-09-23 23:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:02:54 --> Controller Class Initialized
INFO - 2016-09-23 23:02:54 --> Database Driver Class Initialized
INFO - 2016-09-23 23:02:54 --> Model Class Initialized
INFO - 2016-09-23 23:02:54 --> Model Class Initialized
INFO - 2016-09-23 23:02:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:03:06 --> Config Class Initialized
INFO - 2016-09-23 23:03:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:03:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:03:06 --> Utf8 Class Initialized
INFO - 2016-09-23 23:03:06 --> URI Class Initialized
INFO - 2016-09-23 23:03:06 --> Router Class Initialized
INFO - 2016-09-23 23:03:06 --> Output Class Initialized
INFO - 2016-09-23 23:03:06 --> Security Class Initialized
DEBUG - 2016-09-23 23:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:03:06 --> Input Class Initialized
INFO - 2016-09-23 23:03:06 --> Language Class Initialized
INFO - 2016-09-23 23:03:06 --> Loader Class Initialized
INFO - 2016-09-23 23:03:06 --> Helper loaded: url_helper
INFO - 2016-09-23 23:03:06 --> Helper loaded: language_helper
INFO - 2016-09-23 23:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:03:06 --> Controller Class Initialized
INFO - 2016-09-23 23:03:06 --> Database Driver Class Initialized
INFO - 2016-09-23 23:03:06 --> Model Class Initialized
INFO - 2016-09-23 23:03:06 --> Model Class Initialized
INFO - 2016-09-23 23:03:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:03:40 --> Config Class Initialized
INFO - 2016-09-23 23:03:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:03:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:03:40 --> Utf8 Class Initialized
INFO - 2016-09-23 23:03:40 --> URI Class Initialized
INFO - 2016-09-23 23:03:40 --> Router Class Initialized
INFO - 2016-09-23 23:03:40 --> Output Class Initialized
INFO - 2016-09-23 23:03:40 --> Security Class Initialized
DEBUG - 2016-09-23 23:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:03:40 --> Input Class Initialized
INFO - 2016-09-23 23:03:40 --> Language Class Initialized
INFO - 2016-09-23 23:03:40 --> Loader Class Initialized
INFO - 2016-09-23 23:03:40 --> Helper loaded: url_helper
INFO - 2016-09-23 23:03:40 --> Helper loaded: language_helper
INFO - 2016-09-23 23:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:03:40 --> Controller Class Initialized
INFO - 2016-09-23 23:03:40 --> Database Driver Class Initialized
INFO - 2016-09-23 23:03:40 --> Model Class Initialized
INFO - 2016-09-23 23:03:40 --> Model Class Initialized
INFO - 2016-09-23 23:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:03:44 --> Config Class Initialized
INFO - 2016-09-23 23:03:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:03:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:03:44 --> Utf8 Class Initialized
INFO - 2016-09-23 23:03:44 --> URI Class Initialized
INFO - 2016-09-23 23:03:44 --> Router Class Initialized
INFO - 2016-09-23 23:03:44 --> Output Class Initialized
INFO - 2016-09-23 23:03:44 --> Security Class Initialized
DEBUG - 2016-09-23 23:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:03:44 --> Input Class Initialized
INFO - 2016-09-23 23:03:45 --> Language Class Initialized
INFO - 2016-09-23 23:03:45 --> Loader Class Initialized
INFO - 2016-09-23 23:03:45 --> Helper loaded: url_helper
INFO - 2016-09-23 23:03:45 --> Helper loaded: language_helper
INFO - 2016-09-23 23:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:03:45 --> Controller Class Initialized
INFO - 2016-09-23 23:03:45 --> Database Driver Class Initialized
INFO - 2016-09-23 23:03:45 --> Model Class Initialized
INFO - 2016-09-23 23:03:45 --> Model Class Initialized
INFO - 2016-09-23 23:03:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:04:05 --> Config Class Initialized
INFO - 2016-09-23 23:04:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:04:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:04:05 --> Utf8 Class Initialized
INFO - 2016-09-23 23:04:05 --> URI Class Initialized
INFO - 2016-09-23 23:04:05 --> Router Class Initialized
INFO - 2016-09-23 23:04:05 --> Output Class Initialized
INFO - 2016-09-23 23:04:05 --> Security Class Initialized
DEBUG - 2016-09-23 23:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:04:05 --> Input Class Initialized
INFO - 2016-09-23 23:04:05 --> Language Class Initialized
INFO - 2016-09-23 23:04:05 --> Loader Class Initialized
INFO - 2016-09-23 23:04:05 --> Helper loaded: url_helper
INFO - 2016-09-23 23:04:05 --> Helper loaded: language_helper
INFO - 2016-09-23 23:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:04:05 --> Controller Class Initialized
INFO - 2016-09-23 23:04:05 --> Database Driver Class Initialized
INFO - 2016-09-23 23:04:05 --> Model Class Initialized
INFO - 2016-09-23 23:04:05 --> Model Class Initialized
INFO - 2016-09-23 23:04:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:05:04 --> Config Class Initialized
INFO - 2016-09-23 23:05:04 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:05:04 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:05:04 --> Utf8 Class Initialized
INFO - 2016-09-23 23:05:04 --> URI Class Initialized
INFO - 2016-09-23 23:05:04 --> Router Class Initialized
INFO - 2016-09-23 23:05:04 --> Output Class Initialized
INFO - 2016-09-23 23:05:04 --> Security Class Initialized
DEBUG - 2016-09-23 23:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:05:04 --> Input Class Initialized
INFO - 2016-09-23 23:05:04 --> Language Class Initialized
INFO - 2016-09-23 23:05:04 --> Loader Class Initialized
INFO - 2016-09-23 23:05:04 --> Helper loaded: url_helper
INFO - 2016-09-23 23:05:04 --> Helper loaded: language_helper
INFO - 2016-09-23 23:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:05:04 --> Controller Class Initialized
INFO - 2016-09-23 23:05:04 --> Database Driver Class Initialized
INFO - 2016-09-23 23:05:04 --> Model Class Initialized
INFO - 2016-09-23 23:05:04 --> Model Class Initialized
INFO - 2016-09-23 23:05:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:05:17 --> Config Class Initialized
INFO - 2016-09-23 23:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:05:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:05:17 --> URI Class Initialized
INFO - 2016-09-23 23:05:17 --> Router Class Initialized
INFO - 2016-09-23 23:05:17 --> Output Class Initialized
INFO - 2016-09-23 23:05:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:05:17 --> Input Class Initialized
INFO - 2016-09-23 23:05:17 --> Language Class Initialized
INFO - 2016-09-23 23:05:17 --> Loader Class Initialized
INFO - 2016-09-23 23:05:17 --> Helper loaded: url_helper
INFO - 2016-09-23 23:05:17 --> Helper loaded: language_helper
INFO - 2016-09-23 23:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:05:17 --> Controller Class Initialized
INFO - 2016-09-23 23:05:17 --> Database Driver Class Initialized
INFO - 2016-09-23 23:05:17 --> Model Class Initialized
INFO - 2016-09-23 23:05:17 --> Model Class Initialized
INFO - 2016-09-23 23:05:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:05:25 --> Config Class Initialized
INFO - 2016-09-23 23:05:25 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:05:26 --> Utf8 Class Initialized
INFO - 2016-09-23 23:05:26 --> URI Class Initialized
INFO - 2016-09-23 23:05:26 --> Router Class Initialized
INFO - 2016-09-23 23:05:26 --> Output Class Initialized
INFO - 2016-09-23 23:05:26 --> Security Class Initialized
DEBUG - 2016-09-23 23:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:05:26 --> Input Class Initialized
INFO - 2016-09-23 23:05:26 --> Language Class Initialized
INFO - 2016-09-23 23:05:26 --> Loader Class Initialized
INFO - 2016-09-23 23:05:26 --> Helper loaded: url_helper
INFO - 2016-09-23 23:05:26 --> Helper loaded: language_helper
INFO - 2016-09-23 23:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:05:26 --> Controller Class Initialized
INFO - 2016-09-23 23:05:26 --> Database Driver Class Initialized
INFO - 2016-09-23 23:05:26 --> Model Class Initialized
INFO - 2016-09-23 23:05:26 --> Model Class Initialized
INFO - 2016-09-23 23:05:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:05:26 --> Config Class Initialized
INFO - 2016-09-23 23:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:05:26 --> Utf8 Class Initialized
INFO - 2016-09-23 23:05:26 --> URI Class Initialized
INFO - 2016-09-23 23:05:26 --> Router Class Initialized
INFO - 2016-09-23 23:05:26 --> Output Class Initialized
INFO - 2016-09-23 23:05:26 --> Security Class Initialized
DEBUG - 2016-09-23 23:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:05:26 --> Input Class Initialized
INFO - 2016-09-23 23:05:26 --> Language Class Initialized
INFO - 2016-09-23 23:05:26 --> Loader Class Initialized
INFO - 2016-09-23 23:05:26 --> Helper loaded: url_helper
INFO - 2016-09-23 23:05:26 --> Helper loaded: language_helper
INFO - 2016-09-23 23:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:05:26 --> Controller Class Initialized
INFO - 2016-09-23 23:05:26 --> Database Driver Class Initialized
INFO - 2016-09-23 23:05:26 --> Model Class Initialized
INFO - 2016-09-23 23:05:26 --> Model Class Initialized
INFO - 2016-09-23 23:05:26 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:05:26 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 498
INFO - 2016-09-23 23:05:26 --> Config Class Initialized
INFO - 2016-09-23 23:05:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:05:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:05:26 --> Utf8 Class Initialized
INFO - 2016-09-23 23:05:26 --> URI Class Initialized
INFO - 2016-09-23 23:05:26 --> Router Class Initialized
INFO - 2016-09-23 23:05:26 --> Output Class Initialized
INFO - 2016-09-23 23:05:26 --> Security Class Initialized
DEBUG - 2016-09-23 23:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:05:26 --> Input Class Initialized
INFO - 2016-09-23 23:05:26 --> Language Class Initialized
INFO - 2016-09-23 23:05:26 --> Loader Class Initialized
INFO - 2016-09-23 23:05:26 --> Helper loaded: url_helper
INFO - 2016-09-23 23:05:26 --> Helper loaded: language_helper
INFO - 2016-09-23 23:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:05:26 --> Controller Class Initialized
INFO - 2016-09-23 23:05:26 --> Database Driver Class Initialized
INFO - 2016-09-23 23:05:26 --> Model Class Initialized
INFO - 2016-09-23 23:05:26 --> Model Class Initialized
INFO - 2016-09-23 23:05:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:05:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:05:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 23:05:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:05:26 --> Final output sent to browser
DEBUG - 2016-09-23 23:05:26 --> Total execution time: 0.0617
INFO - 2016-09-23 23:06:53 --> Config Class Initialized
INFO - 2016-09-23 23:06:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:06:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:06:53 --> Utf8 Class Initialized
INFO - 2016-09-23 23:06:53 --> URI Class Initialized
INFO - 2016-09-23 23:06:53 --> Router Class Initialized
INFO - 2016-09-23 23:06:53 --> Output Class Initialized
INFO - 2016-09-23 23:06:53 --> Security Class Initialized
DEBUG - 2016-09-23 23:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:06:53 --> Input Class Initialized
INFO - 2016-09-23 23:06:53 --> Language Class Initialized
INFO - 2016-09-23 23:06:53 --> Loader Class Initialized
INFO - 2016-09-23 23:06:53 --> Helper loaded: url_helper
INFO - 2016-09-23 23:06:53 --> Helper loaded: language_helper
INFO - 2016-09-23 23:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:06:53 --> Controller Class Initialized
INFO - 2016-09-23 23:06:53 --> Database Driver Class Initialized
INFO - 2016-09-23 23:06:53 --> Model Class Initialized
INFO - 2016-09-23 23:06:53 --> Model Class Initialized
INFO - 2016-09-23 23:06:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:06:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:06:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:06:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:06:53 --> Final output sent to browser
DEBUG - 2016-09-23 23:06:53 --> Total execution time: 0.0592
INFO - 2016-09-23 23:06:54 --> Config Class Initialized
INFO - 2016-09-23 23:06:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:06:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:06:54 --> Utf8 Class Initialized
INFO - 2016-09-23 23:06:54 --> URI Class Initialized
INFO - 2016-09-23 23:06:54 --> Router Class Initialized
INFO - 2016-09-23 23:06:54 --> Output Class Initialized
INFO - 2016-09-23 23:06:54 --> Security Class Initialized
DEBUG - 2016-09-23 23:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:06:54 --> Input Class Initialized
INFO - 2016-09-23 23:06:54 --> Language Class Initialized
INFO - 2016-09-23 23:06:54 --> Loader Class Initialized
INFO - 2016-09-23 23:06:54 --> Helper loaded: url_helper
INFO - 2016-09-23 23:06:54 --> Helper loaded: language_helper
INFO - 2016-09-23 23:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:06:54 --> Controller Class Initialized
INFO - 2016-09-23 23:06:54 --> Database Driver Class Initialized
INFO - 2016-09-23 23:06:54 --> Model Class Initialized
INFO - 2016-09-23 23:06:54 --> Model Class Initialized
INFO - 2016-09-23 23:06:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:06:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:06:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:06:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:06:54 --> Final output sent to browser
DEBUG - 2016-09-23 23:06:54 --> Total execution time: 0.0669
INFO - 2016-09-23 23:07:02 --> Config Class Initialized
INFO - 2016-09-23 23:07:02 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:07:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:07:02 --> Utf8 Class Initialized
INFO - 2016-09-23 23:07:02 --> URI Class Initialized
INFO - 2016-09-23 23:07:02 --> Router Class Initialized
INFO - 2016-09-23 23:07:02 --> Output Class Initialized
INFO - 2016-09-23 23:07:02 --> Security Class Initialized
DEBUG - 2016-09-23 23:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:07:02 --> Input Class Initialized
INFO - 2016-09-23 23:07:02 --> Language Class Initialized
INFO - 2016-09-23 23:07:02 --> Loader Class Initialized
INFO - 2016-09-23 23:07:02 --> Helper loaded: url_helper
INFO - 2016-09-23 23:07:02 --> Helper loaded: language_helper
INFO - 2016-09-23 23:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:07:02 --> Controller Class Initialized
INFO - 2016-09-23 23:07:02 --> Database Driver Class Initialized
INFO - 2016-09-23 23:07:02 --> Model Class Initialized
INFO - 2016-09-23 23:07:02 --> Model Class Initialized
INFO - 2016-09-23 23:07:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:07:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:07:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-23 23:07:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:07:02 --> Final output sent to browser
DEBUG - 2016-09-23 23:07:02 --> Total execution time: 0.0781
INFO - 2016-09-23 23:07:07 --> Config Class Initialized
INFO - 2016-09-23 23:07:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:07:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:07:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:07:07 --> URI Class Initialized
INFO - 2016-09-23 23:07:07 --> Router Class Initialized
INFO - 2016-09-23 23:07:07 --> Output Class Initialized
INFO - 2016-09-23 23:07:07 --> Security Class Initialized
DEBUG - 2016-09-23 23:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:07:07 --> Input Class Initialized
INFO - 2016-09-23 23:07:07 --> Language Class Initialized
INFO - 2016-09-23 23:07:07 --> Loader Class Initialized
INFO - 2016-09-23 23:07:07 --> Helper loaded: url_helper
INFO - 2016-09-23 23:07:07 --> Helper loaded: language_helper
INFO - 2016-09-23 23:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:07:07 --> Controller Class Initialized
INFO - 2016-09-23 23:07:07 --> Database Driver Class Initialized
INFO - 2016-09-23 23:07:07 --> Model Class Initialized
INFO - 2016-09-23 23:07:07 --> Model Class Initialized
INFO - 2016-09-23 23:07:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:07:07 --> Config Class Initialized
INFO - 2016-09-23 23:07:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:07:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:07:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:07:07 --> URI Class Initialized
INFO - 2016-09-23 23:07:07 --> Router Class Initialized
INFO - 2016-09-23 23:07:07 --> Output Class Initialized
INFO - 2016-09-23 23:07:07 --> Security Class Initialized
DEBUG - 2016-09-23 23:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:07:07 --> Input Class Initialized
INFO - 2016-09-23 23:07:07 --> Language Class Initialized
INFO - 2016-09-23 23:07:07 --> Loader Class Initialized
INFO - 2016-09-23 23:07:07 --> Helper loaded: url_helper
INFO - 2016-09-23 23:07:07 --> Helper loaded: language_helper
INFO - 2016-09-23 23:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:07:07 --> Controller Class Initialized
INFO - 2016-09-23 23:07:07 --> Database Driver Class Initialized
INFO - 2016-09-23 23:07:07 --> Model Class Initialized
INFO - 2016-09-23 23:07:07 --> Model Class Initialized
INFO - 2016-09-23 23:07:07 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:07:07 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 917
INFO - 2016-09-23 23:07:07 --> Config Class Initialized
INFO - 2016-09-23 23:07:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:07:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:07:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:07:07 --> URI Class Initialized
INFO - 2016-09-23 23:07:07 --> Router Class Initialized
INFO - 2016-09-23 23:07:07 --> Output Class Initialized
INFO - 2016-09-23 23:07:07 --> Security Class Initialized
DEBUG - 2016-09-23 23:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:07:07 --> Input Class Initialized
INFO - 2016-09-23 23:07:07 --> Language Class Initialized
INFO - 2016-09-23 23:07:07 --> Loader Class Initialized
INFO - 2016-09-23 23:07:07 --> Helper loaded: url_helper
INFO - 2016-09-23 23:07:07 --> Helper loaded: language_helper
INFO - 2016-09-23 23:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:07:07 --> Controller Class Initialized
INFO - 2016-09-23 23:07:07 --> Database Driver Class Initialized
INFO - 2016-09-23 23:07:07 --> Model Class Initialized
INFO - 2016-09-23 23:07:07 --> Model Class Initialized
INFO - 2016-09-23 23:07:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:07:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:07:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 23:07:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:07:07 --> Final output sent to browser
DEBUG - 2016-09-23 23:07:07 --> Total execution time: 0.0591
INFO - 2016-09-23 23:07:27 --> Config Class Initialized
INFO - 2016-09-23 23:07:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:07:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:07:27 --> Utf8 Class Initialized
INFO - 2016-09-23 23:07:27 --> URI Class Initialized
INFO - 2016-09-23 23:07:27 --> Router Class Initialized
INFO - 2016-09-23 23:07:27 --> Output Class Initialized
INFO - 2016-09-23 23:07:27 --> Security Class Initialized
DEBUG - 2016-09-23 23:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:07:27 --> Input Class Initialized
INFO - 2016-09-23 23:07:27 --> Language Class Initialized
INFO - 2016-09-23 23:07:27 --> Loader Class Initialized
INFO - 2016-09-23 23:07:27 --> Helper loaded: url_helper
INFO - 2016-09-23 23:07:27 --> Helper loaded: language_helper
INFO - 2016-09-23 23:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:07:27 --> Controller Class Initialized
INFO - 2016-09-23 23:07:27 --> Database Driver Class Initialized
INFO - 2016-09-23 23:07:27 --> Model Class Initialized
INFO - 2016-09-23 23:07:27 --> Model Class Initialized
INFO - 2016-09-23 23:07:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:07:27 --> Final output sent to browser
DEBUG - 2016-09-23 23:07:27 --> Total execution time: 0.0590
INFO - 2016-09-23 23:07:27 --> Config Class Initialized
INFO - 2016-09-23 23:07:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:07:27 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:07:27 --> Utf8 Class Initialized
INFO - 2016-09-23 23:07:27 --> URI Class Initialized
INFO - 2016-09-23 23:07:27 --> Router Class Initialized
INFO - 2016-09-23 23:07:27 --> Output Class Initialized
INFO - 2016-09-23 23:07:27 --> Security Class Initialized
DEBUG - 2016-09-23 23:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:07:27 --> Input Class Initialized
INFO - 2016-09-23 23:07:27 --> Language Class Initialized
INFO - 2016-09-23 23:07:27 --> Loader Class Initialized
INFO - 2016-09-23 23:07:27 --> Helper loaded: url_helper
INFO - 2016-09-23 23:07:27 --> Helper loaded: language_helper
INFO - 2016-09-23 23:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:07:27 --> Controller Class Initialized
INFO - 2016-09-23 23:07:27 --> Database Driver Class Initialized
INFO - 2016-09-23 23:07:27 --> Model Class Initialized
INFO - 2016-09-23 23:07:27 --> Model Class Initialized
INFO - 2016-09-23 23:07:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:07:27 --> Final output sent to browser
DEBUG - 2016-09-23 23:07:27 --> Total execution time: 0.0667
INFO - 2016-09-23 23:08:18 --> Config Class Initialized
INFO - 2016-09-23 23:08:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:08:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:08:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:08:18 --> URI Class Initialized
INFO - 2016-09-23 23:08:18 --> Router Class Initialized
INFO - 2016-09-23 23:08:18 --> Output Class Initialized
INFO - 2016-09-23 23:08:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:08:18 --> Input Class Initialized
INFO - 2016-09-23 23:08:18 --> Language Class Initialized
INFO - 2016-09-23 23:08:18 --> Loader Class Initialized
INFO - 2016-09-23 23:08:18 --> Helper loaded: url_helper
INFO - 2016-09-23 23:08:18 --> Helper loaded: language_helper
INFO - 2016-09-23 23:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:08:18 --> Controller Class Initialized
INFO - 2016-09-23 23:08:18 --> Database Driver Class Initialized
INFO - 2016-09-23 23:08:18 --> Model Class Initialized
INFO - 2016-09-23 23:08:18 --> Model Class Initialized
INFO - 2016-09-23 23:08:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:08:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:08:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:08:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:08:18 --> Final output sent to browser
DEBUG - 2016-09-23 23:08:18 --> Total execution time: 0.0624
INFO - 2016-09-23 23:08:20 --> Config Class Initialized
INFO - 2016-09-23 23:08:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:08:20 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:08:20 --> Utf8 Class Initialized
INFO - 2016-09-23 23:08:20 --> URI Class Initialized
INFO - 2016-09-23 23:08:20 --> Router Class Initialized
INFO - 2016-09-23 23:08:20 --> Output Class Initialized
INFO - 2016-09-23 23:08:20 --> Security Class Initialized
DEBUG - 2016-09-23 23:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:08:20 --> Input Class Initialized
INFO - 2016-09-23 23:08:20 --> Language Class Initialized
INFO - 2016-09-23 23:08:20 --> Loader Class Initialized
INFO - 2016-09-23 23:08:20 --> Helper loaded: url_helper
INFO - 2016-09-23 23:08:20 --> Helper loaded: language_helper
INFO - 2016-09-23 23:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:08:20 --> Controller Class Initialized
INFO - 2016-09-23 23:08:20 --> Database Driver Class Initialized
INFO - 2016-09-23 23:08:20 --> Model Class Initialized
INFO - 2016-09-23 23:08:20 --> Model Class Initialized
INFO - 2016-09-23 23:08:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:08:37 --> Config Class Initialized
INFO - 2016-09-23 23:08:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:08:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:08:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:08:37 --> URI Class Initialized
INFO - 2016-09-23 23:08:37 --> Router Class Initialized
INFO - 2016-09-23 23:08:37 --> Output Class Initialized
INFO - 2016-09-23 23:08:37 --> Security Class Initialized
DEBUG - 2016-09-23 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:08:37 --> Input Class Initialized
INFO - 2016-09-23 23:08:37 --> Language Class Initialized
INFO - 2016-09-23 23:08:37 --> Loader Class Initialized
INFO - 2016-09-23 23:08:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:08:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:08:37 --> Controller Class Initialized
INFO - 2016-09-23 23:08:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:08:37 --> Model Class Initialized
INFO - 2016-09-23 23:08:37 --> Model Class Initialized
INFO - 2016-09-23 23:08:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:08:37 --> Config Class Initialized
INFO - 2016-09-23 23:08:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:08:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:08:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:08:37 --> URI Class Initialized
INFO - 2016-09-23 23:08:37 --> Router Class Initialized
INFO - 2016-09-23 23:08:37 --> Output Class Initialized
INFO - 2016-09-23 23:08:37 --> Security Class Initialized
DEBUG - 2016-09-23 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:08:37 --> Input Class Initialized
INFO - 2016-09-23 23:08:37 --> Language Class Initialized
INFO - 2016-09-23 23:08:37 --> Loader Class Initialized
INFO - 2016-09-23 23:08:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:08:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:08:37 --> Controller Class Initialized
INFO - 2016-09-23 23:08:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:08:37 --> Model Class Initialized
INFO - 2016-09-23 23:08:37 --> Model Class Initialized
INFO - 2016-09-23 23:08:37 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:08:37 --> Severity: Notice --> Undefined variable: rid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 498
INFO - 2016-09-23 23:08:37 --> Config Class Initialized
INFO - 2016-09-23 23:08:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:08:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:08:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:08:37 --> URI Class Initialized
INFO - 2016-09-23 23:08:37 --> Router Class Initialized
INFO - 2016-09-23 23:08:37 --> Output Class Initialized
INFO - 2016-09-23 23:08:37 --> Security Class Initialized
DEBUG - 2016-09-23 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:08:37 --> Input Class Initialized
INFO - 2016-09-23 23:08:37 --> Language Class Initialized
INFO - 2016-09-23 23:08:37 --> Loader Class Initialized
INFO - 2016-09-23 23:08:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:08:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:08:37 --> Controller Class Initialized
INFO - 2016-09-23 23:08:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:08:37 --> Model Class Initialized
INFO - 2016-09-23 23:08:37 --> Model Class Initialized
INFO - 2016-09-23 23:08:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:08:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:08:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 23:08:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:08:37 --> Final output sent to browser
DEBUG - 2016-09-23 23:08:37 --> Total execution time: 0.0622
INFO - 2016-09-23 23:10:50 --> Config Class Initialized
INFO - 2016-09-23 23:10:50 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:10:50 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:10:50 --> Utf8 Class Initialized
INFO - 2016-09-23 23:10:50 --> URI Class Initialized
INFO - 2016-09-23 23:10:50 --> Router Class Initialized
INFO - 2016-09-23 23:10:50 --> Output Class Initialized
INFO - 2016-09-23 23:10:50 --> Security Class Initialized
DEBUG - 2016-09-23 23:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:10:50 --> Input Class Initialized
INFO - 2016-09-23 23:10:50 --> Language Class Initialized
INFO - 2016-09-23 23:10:50 --> Loader Class Initialized
INFO - 2016-09-23 23:10:50 --> Helper loaded: url_helper
INFO - 2016-09-23 23:10:50 --> Helper loaded: language_helper
INFO - 2016-09-23 23:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:10:50 --> Controller Class Initialized
INFO - 2016-09-23 23:10:50 --> Database Driver Class Initialized
INFO - 2016-09-23 23:10:50 --> Model Class Initialized
INFO - 2016-09-23 23:10:50 --> Model Class Initialized
INFO - 2016-09-23 23:10:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:10:50 --> Final output sent to browser
DEBUG - 2016-09-23 23:10:50 --> Total execution time: 0.0561
INFO - 2016-09-23 23:10:50 --> Config Class Initialized
INFO - 2016-09-23 23:10:50 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:10:50 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:10:50 --> Utf8 Class Initialized
INFO - 2016-09-23 23:10:50 --> URI Class Initialized
INFO - 2016-09-23 23:10:50 --> Router Class Initialized
INFO - 2016-09-23 23:10:50 --> Output Class Initialized
INFO - 2016-09-23 23:10:50 --> Security Class Initialized
DEBUG - 2016-09-23 23:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:10:50 --> Input Class Initialized
INFO - 2016-09-23 23:10:50 --> Language Class Initialized
INFO - 2016-09-23 23:10:50 --> Loader Class Initialized
INFO - 2016-09-23 23:10:50 --> Helper loaded: url_helper
INFO - 2016-09-23 23:10:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:10:51 --> Controller Class Initialized
INFO - 2016-09-23 23:10:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:10:51 --> Model Class Initialized
INFO - 2016-09-23 23:10:51 --> Model Class Initialized
INFO - 2016-09-23 23:10:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:10:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:10:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:10:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:10:51 --> Final output sent to browser
DEBUG - 2016-09-23 23:10:51 --> Total execution time: 0.0635
INFO - 2016-09-23 23:10:54 --> Config Class Initialized
INFO - 2016-09-23 23:10:54 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:10:54 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:10:54 --> Utf8 Class Initialized
INFO - 2016-09-23 23:10:54 --> URI Class Initialized
INFO - 2016-09-23 23:10:54 --> Router Class Initialized
INFO - 2016-09-23 23:10:54 --> Output Class Initialized
INFO - 2016-09-23 23:10:54 --> Security Class Initialized
DEBUG - 2016-09-23 23:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:10:54 --> Input Class Initialized
INFO - 2016-09-23 23:10:54 --> Language Class Initialized
INFO - 2016-09-23 23:10:54 --> Loader Class Initialized
INFO - 2016-09-23 23:10:54 --> Helper loaded: url_helper
INFO - 2016-09-23 23:10:54 --> Helper loaded: language_helper
INFO - 2016-09-23 23:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:10:54 --> Controller Class Initialized
INFO - 2016-09-23 23:10:54 --> Database Driver Class Initialized
INFO - 2016-09-23 23:10:54 --> Model Class Initialized
INFO - 2016-09-23 23:10:54 --> Model Class Initialized
INFO - 2016-09-23 23:10:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:10:54 --> Final output sent to browser
DEBUG - 2016-09-23 23:10:54 --> Total execution time: 0.0622
INFO - 2016-09-23 23:12:51 --> Config Class Initialized
INFO - 2016-09-23 23:12:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:12:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:12:51 --> Utf8 Class Initialized
INFO - 2016-09-23 23:12:51 --> URI Class Initialized
INFO - 2016-09-23 23:12:51 --> Router Class Initialized
INFO - 2016-09-23 23:12:51 --> Output Class Initialized
INFO - 2016-09-23 23:12:51 --> Security Class Initialized
DEBUG - 2016-09-23 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:12:51 --> Input Class Initialized
INFO - 2016-09-23 23:12:51 --> Language Class Initialized
INFO - 2016-09-23 23:12:51 --> Loader Class Initialized
INFO - 2016-09-23 23:12:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:12:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:12:51 --> Controller Class Initialized
INFO - 2016-09-23 23:12:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:12:51 --> Config Class Initialized
INFO - 2016-09-23 23:12:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:12:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:12:51 --> Utf8 Class Initialized
INFO - 2016-09-23 23:12:51 --> URI Class Initialized
INFO - 2016-09-23 23:12:51 --> Router Class Initialized
INFO - 2016-09-23 23:12:51 --> Output Class Initialized
INFO - 2016-09-23 23:12:51 --> Security Class Initialized
DEBUG - 2016-09-23 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:12:51 --> Input Class Initialized
INFO - 2016-09-23 23:12:51 --> Language Class Initialized
INFO - 2016-09-23 23:12:51 --> Loader Class Initialized
INFO - 2016-09-23 23:12:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:12:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:12:51 --> Controller Class Initialized
INFO - 2016-09-23 23:12:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:12:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:12:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2016-09-23 23:12:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:12:51 --> Final output sent to browser
DEBUG - 2016-09-23 23:12:51 --> Total execution time: 0.0651
INFO - 2016-09-23 23:12:51 --> Config Class Initialized
INFO - 2016-09-23 23:12:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:12:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:12:51 --> Utf8 Class Initialized
INFO - 2016-09-23 23:12:51 --> URI Class Initialized
INFO - 2016-09-23 23:12:51 --> Router Class Initialized
INFO - 2016-09-23 23:12:51 --> Config Class Initialized
INFO - 2016-09-23 23:12:51 --> Hooks Class Initialized
INFO - 2016-09-23 23:12:51 --> Output Class Initialized
INFO - 2016-09-23 23:12:51 --> Security Class Initialized
DEBUG - 2016-09-23 23:12:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:12:51 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:12:51 --> URI Class Initialized
INFO - 2016-09-23 23:12:51 --> Input Class Initialized
INFO - 2016-09-23 23:12:51 --> Language Class Initialized
INFO - 2016-09-23 23:12:51 --> Router Class Initialized
INFO - 2016-09-23 23:12:51 --> Output Class Initialized
INFO - 2016-09-23 23:12:51 --> Loader Class Initialized
INFO - 2016-09-23 23:12:51 --> Security Class Initialized
INFO - 2016-09-23 23:12:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:12:51 --> Helper loaded: language_helper
DEBUG - 2016-09-23 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:12:51 --> Input Class Initialized
INFO - 2016-09-23 23:12:51 --> Language Class Initialized
INFO - 2016-09-23 23:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:12:51 --> Controller Class Initialized
INFO - 2016-09-23 23:12:51 --> Loader Class Initialized
INFO - 2016-09-23 23:12:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:12:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:12:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:12:51 --> Final output sent to browser
DEBUG - 2016-09-23 23:12:51 --> Total execution time: 0.0855
INFO - 2016-09-23 23:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:12:51 --> Controller Class Initialized
INFO - 2016-09-23 23:12:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Model Class Initialized
INFO - 2016-09-23 23:12:51 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:12:51 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 23:12:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 23:12:51 --> Final output sent to browser
DEBUG - 2016-09-23 23:12:51 --> Total execution time: 0.1126
INFO - 2016-09-23 23:13:00 --> Config Class Initialized
INFO - 2016-09-23 23:13:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:00 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:01 --> URI Class Initialized
INFO - 2016-09-23 23:13:01 --> Router Class Initialized
INFO - 2016-09-23 23:13:01 --> Output Class Initialized
INFO - 2016-09-23 23:13:01 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:01 --> Input Class Initialized
INFO - 2016-09-23 23:13:01 --> Language Class Initialized
INFO - 2016-09-23 23:13:01 --> Loader Class Initialized
INFO - 2016-09-23 23:13:01 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:01 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:01 --> Controller Class Initialized
INFO - 2016-09-23 23:13:01 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:01 --> Model Class Initialized
INFO - 2016-09-23 23:13:01 --> Model Class Initialized
INFO - 2016-09-23 23:13:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:13:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-23 23:13:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:13:01 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:01 --> Total execution time: 0.0628
INFO - 2016-09-23 23:13:29 --> Config Class Initialized
INFO - 2016-09-23 23:13:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:29 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:29 --> URI Class Initialized
INFO - 2016-09-23 23:13:29 --> Router Class Initialized
INFO - 2016-09-23 23:13:29 --> Output Class Initialized
INFO - 2016-09-23 23:13:29 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:29 --> Input Class Initialized
INFO - 2016-09-23 23:13:29 --> Language Class Initialized
INFO - 2016-09-23 23:13:29 --> Loader Class Initialized
INFO - 2016-09-23 23:13:29 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:29 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:29 --> Controller Class Initialized
INFO - 2016-09-23 23:13:29 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:29 --> Model Class Initialized
INFO - 2016-09-23 23:13:29 --> Model Class Initialized
INFO - 2016-09-23 23:13:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-09-23 23:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:13:29 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:29 --> Total execution time: 0.0600
INFO - 2016-09-23 23:13:33 --> Config Class Initialized
INFO - 2016-09-23 23:13:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:33 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:33 --> URI Class Initialized
INFO - 2016-09-23 23:13:33 --> Router Class Initialized
INFO - 2016-09-23 23:13:33 --> Output Class Initialized
INFO - 2016-09-23 23:13:33 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:33 --> Input Class Initialized
INFO - 2016-09-23 23:13:33 --> Language Class Initialized
INFO - 2016-09-23 23:13:33 --> Loader Class Initialized
INFO - 2016-09-23 23:13:33 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:33 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:33 --> Controller Class Initialized
INFO - 2016-09-23 23:13:33 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:33 --> Model Class Initialized
INFO - 2016-09-23 23:13:33 --> Model Class Initialized
INFO - 2016-09-23 23:13:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:33 --> Config Class Initialized
INFO - 2016-09-23 23:13:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:33 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:34 --> URI Class Initialized
INFO - 2016-09-23 23:13:34 --> Router Class Initialized
INFO - 2016-09-23 23:13:34 --> Output Class Initialized
INFO - 2016-09-23 23:13:34 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:34 --> Input Class Initialized
INFO - 2016-09-23 23:13:34 --> Language Class Initialized
INFO - 2016-09-23 23:13:34 --> Loader Class Initialized
INFO - 2016-09-23 23:13:34 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:34 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:34 --> Controller Class Initialized
INFO - 2016-09-23 23:13:34 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:34 --> Model Class Initialized
INFO - 2016-09-23 23:13:34 --> Model Class Initialized
INFO - 2016-09-23 23:13:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:13:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-09-23 23:13:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:13:34 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:34 --> Total execution time: 0.0643
INFO - 2016-09-23 23:13:34 --> Config Class Initialized
INFO - 2016-09-23 23:13:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:34 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:34 --> URI Class Initialized
INFO - 2016-09-23 23:13:34 --> Router Class Initialized
INFO - 2016-09-23 23:13:34 --> Output Class Initialized
INFO - 2016-09-23 23:13:34 --> Security Class Initialized
INFO - 2016-09-23 23:13:34 --> Config Class Initialized
INFO - 2016-09-23 23:13:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:34 --> Input Class Initialized
INFO - 2016-09-23 23:13:34 --> Language Class Initialized
DEBUG - 2016-09-23 23:13:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:34 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:34 --> URI Class Initialized
INFO - 2016-09-23 23:13:34 --> Loader Class Initialized
INFO - 2016-09-23 23:13:34 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:34 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:34 --> Router Class Initialized
INFO - 2016-09-23 23:13:34 --> Output Class Initialized
INFO - 2016-09-23 23:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:34 --> Controller Class Initialized
INFO - 2016-09-23 23:13:34 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:34 --> Input Class Initialized
INFO - 2016-09-23 23:13:34 --> Language Class Initialized
INFO - 2016-09-23 23:13:34 --> Loader Class Initialized
INFO - 2016-09-23 23:13:34 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:34 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:34 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:34 --> Model Class Initialized
INFO - 2016-09-23 23:13:34 --> Model Class Initialized
INFO - 2016-09-23 23:13:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:34 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:34 --> Total execution time: 0.0893
INFO - 2016-09-23 23:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:34 --> Controller Class Initialized
INFO - 2016-09-23 23:13:34 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:34 --> Model Class Initialized
INFO - 2016-09-23 23:13:34 --> Model Class Initialized
INFO - 2016-09-23 23:13:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:13:34 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 23:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 23:13:34 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:34 --> Total execution time: 0.1140
INFO - 2016-09-23 23:13:37 --> Config Class Initialized
INFO - 2016-09-23 23:13:37 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:37 --> Config Class Initialized
INFO - 2016-09-23 23:13:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:37 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:13:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:37 --> URI Class Initialized
INFO - 2016-09-23 23:13:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:37 --> URI Class Initialized
INFO - 2016-09-23 23:13:37 --> Router Class Initialized
INFO - 2016-09-23 23:13:37 --> Router Class Initialized
INFO - 2016-09-23 23:13:37 --> Output Class Initialized
INFO - 2016-09-23 23:13:37 --> Security Class Initialized
INFO - 2016-09-23 23:13:37 --> Output Class Initialized
DEBUG - 2016-09-23 23:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:37 --> Security Class Initialized
INFO - 2016-09-23 23:13:37 --> Input Class Initialized
INFO - 2016-09-23 23:13:37 --> Language Class Initialized
DEBUG - 2016-09-23 23:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:37 --> Input Class Initialized
INFO - 2016-09-23 23:13:37 --> Language Class Initialized
INFO - 2016-09-23 23:13:37 --> Loader Class Initialized
INFO - 2016-09-23 23:13:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:37 --> Loader Class Initialized
INFO - 2016-09-23 23:13:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:37 --> Controller Class Initialized
INFO - 2016-09-23 23:13:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:37 --> Model Class Initialized
INFO - 2016-09-23 23:13:37 --> Model Class Initialized
INFO - 2016-09-23 23:13:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:37 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:37 --> Total execution time: 0.0717
INFO - 2016-09-23 23:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:37 --> Controller Class Initialized
INFO - 2016-09-23 23:13:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:37 --> Model Class Initialized
INFO - 2016-09-23 23:13:37 --> Model Class Initialized
INFO - 2016-09-23 23:13:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:37 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:37 --> Total execution time: 0.0939
INFO - 2016-09-23 23:13:40 --> Config Class Initialized
INFO - 2016-09-23 23:13:40 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:40 --> Config Class Initialized
INFO - 2016-09-23 23:13:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:40 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:13:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:40 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:40 --> URI Class Initialized
INFO - 2016-09-23 23:13:40 --> URI Class Initialized
INFO - 2016-09-23 23:13:40 --> Router Class Initialized
INFO - 2016-09-23 23:13:40 --> Router Class Initialized
INFO - 2016-09-23 23:13:40 --> Output Class Initialized
INFO - 2016-09-23 23:13:40 --> Security Class Initialized
INFO - 2016-09-23 23:13:40 --> Output Class Initialized
DEBUG - 2016-09-23 23:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:40 --> Security Class Initialized
INFO - 2016-09-23 23:13:40 --> Input Class Initialized
INFO - 2016-09-23 23:13:40 --> Language Class Initialized
DEBUG - 2016-09-23 23:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:40 --> Input Class Initialized
INFO - 2016-09-23 23:13:40 --> Language Class Initialized
INFO - 2016-09-23 23:13:40 --> Loader Class Initialized
INFO - 2016-09-23 23:13:40 --> Loader Class Initialized
INFO - 2016-09-23 23:13:40 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:40 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:40 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:40 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:40 --> Controller Class Initialized
INFO - 2016-09-23 23:13:40 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:40 --> Model Class Initialized
INFO - 2016-09-23 23:13:40 --> Model Class Initialized
INFO - 2016-09-23 23:13:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:40 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:40 --> Total execution time: 0.0861
INFO - 2016-09-23 23:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:40 --> Controller Class Initialized
INFO - 2016-09-23 23:13:40 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:40 --> Model Class Initialized
INFO - 2016-09-23 23:13:40 --> Model Class Initialized
INFO - 2016-09-23 23:13:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:40 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:40 --> Total execution time: 0.1058
INFO - 2016-09-23 23:13:42 --> Config Class Initialized
INFO - 2016-09-23 23:13:42 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:42 --> Config Class Initialized
INFO - 2016-09-23 23:13:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:42 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:42 --> URI Class Initialized
DEBUG - 2016-09-23 23:13:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:42 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:42 --> URI Class Initialized
INFO - 2016-09-23 23:13:42 --> Router Class Initialized
INFO - 2016-09-23 23:13:42 --> Output Class Initialized
INFO - 2016-09-23 23:13:42 --> Router Class Initialized
INFO - 2016-09-23 23:13:42 --> Security Class Initialized
INFO - 2016-09-23 23:13:42 --> Output Class Initialized
DEBUG - 2016-09-23 23:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:42 --> Security Class Initialized
INFO - 2016-09-23 23:13:42 --> Input Class Initialized
INFO - 2016-09-23 23:13:42 --> Language Class Initialized
DEBUG - 2016-09-23 23:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:42 --> Input Class Initialized
INFO - 2016-09-23 23:13:42 --> Language Class Initialized
INFO - 2016-09-23 23:13:42 --> Loader Class Initialized
INFO - 2016-09-23 23:13:42 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:42 --> Loader Class Initialized
INFO - 2016-09-23 23:13:42 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:42 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:42 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:42 --> Controller Class Initialized
INFO - 2016-09-23 23:13:42 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:42 --> Model Class Initialized
INFO - 2016-09-23 23:13:42 --> Model Class Initialized
INFO - 2016-09-23 23:13:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:42 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:42 --> Total execution time: 0.0743
INFO - 2016-09-23 23:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:42 --> Controller Class Initialized
INFO - 2016-09-23 23:13:42 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:42 --> Model Class Initialized
INFO - 2016-09-23 23:13:42 --> Model Class Initialized
INFO - 2016-09-23 23:13:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:42 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:42 --> Total execution time: 0.0958
INFO - 2016-09-23 23:13:44 --> Config Class Initialized
INFO - 2016-09-23 23:13:44 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:44 --> Config Class Initialized
INFO - 2016-09-23 23:13:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:44 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:44 --> URI Class Initialized
DEBUG - 2016-09-23 23:13:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:44 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:44 --> Router Class Initialized
INFO - 2016-09-23 23:13:44 --> URI Class Initialized
INFO - 2016-09-23 23:13:44 --> Output Class Initialized
INFO - 2016-09-23 23:13:44 --> Router Class Initialized
INFO - 2016-09-23 23:13:44 --> Security Class Initialized
INFO - 2016-09-23 23:13:44 --> Output Class Initialized
DEBUG - 2016-09-23 23:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:44 --> Input Class Initialized
INFO - 2016-09-23 23:13:44 --> Security Class Initialized
INFO - 2016-09-23 23:13:44 --> Language Class Initialized
DEBUG - 2016-09-23 23:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:44 --> Input Class Initialized
INFO - 2016-09-23 23:13:44 --> Language Class Initialized
INFO - 2016-09-23 23:13:44 --> Loader Class Initialized
INFO - 2016-09-23 23:13:44 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:44 --> Loader Class Initialized
INFO - 2016-09-23 23:13:44 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:44 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:44 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:44 --> Controller Class Initialized
INFO - 2016-09-23 23:13:44 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:44 --> Model Class Initialized
INFO - 2016-09-23 23:13:44 --> Model Class Initialized
INFO - 2016-09-23 23:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:44 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:44 --> Total execution time: 0.0758
INFO - 2016-09-23 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:44 --> Controller Class Initialized
INFO - 2016-09-23 23:13:44 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:44 --> Model Class Initialized
INFO - 2016-09-23 23:13:44 --> Model Class Initialized
INFO - 2016-09-23 23:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:44 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:44 --> Total execution time: 0.1058
INFO - 2016-09-23 23:13:47 --> Config Class Initialized
INFO - 2016-09-23 23:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:47 --> URI Class Initialized
INFO - 2016-09-23 23:13:47 --> Router Class Initialized
INFO - 2016-09-23 23:13:47 --> Output Class Initialized
INFO - 2016-09-23 23:13:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:47 --> Input Class Initialized
INFO - 2016-09-23 23:13:47 --> Language Class Initialized
INFO - 2016-09-23 23:13:47 --> Loader Class Initialized
INFO - 2016-09-23 23:13:47 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:47 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:47 --> Controller Class Initialized
INFO - 2016-09-23 23:13:47 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:47 --> Model Class Initialized
INFO - 2016-09-23 23:13:47 --> Model Class Initialized
INFO - 2016-09-23 23:13:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:47 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:47 --> Total execution time: 0.0938
INFO - 2016-09-23 23:13:48 --> Config Class Initialized
INFO - 2016-09-23 23:13:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:48 --> URI Class Initialized
INFO - 2016-09-23 23:13:48 --> Router Class Initialized
INFO - 2016-09-23 23:13:48 --> Output Class Initialized
INFO - 2016-09-23 23:13:48 --> Config Class Initialized
INFO - 2016-09-23 23:13:48 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:48 --> Config Class Initialized
INFO - 2016-09-23 23:13:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:48 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:48 --> URI Class Initialized
INFO - 2016-09-23 23:13:48 --> Router Class Initialized
DEBUG - 2016-09-23 23:13:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 23:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:48 --> Input Class Initialized
INFO - 2016-09-23 23:13:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:48 --> Language Class Initialized
INFO - 2016-09-23 23:13:48 --> URI Class Initialized
INFO - 2016-09-23 23:13:48 --> Output Class Initialized
INFO - 2016-09-23 23:13:48 --> Router Class Initialized
INFO - 2016-09-23 23:13:48 --> Security Class Initialized
INFO - 2016-09-23 23:13:48 --> Loader Class Initialized
INFO - 2016-09-23 23:13:48 --> Output Class Initialized
DEBUG - 2016-09-23 23:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:48 --> Input Class Initialized
INFO - 2016-09-23 23:13:48 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:48 --> Security Class Initialized
INFO - 2016-09-23 23:13:48 --> Language Class Initialized
INFO - 2016-09-23 23:13:48 --> Helper loaded: language_helper
DEBUG - 2016-09-23 23:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:48 --> Input Class Initialized
INFO - 2016-09-23 23:13:48 --> Language Class Initialized
INFO - 2016-09-23 23:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:48 --> Controller Class Initialized
ERROR - 2016-09-23 23:13:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:13:48 --> Loader Class Initialized
INFO - 2016-09-23 23:13:48 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:48 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:48 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:48 --> Model Class Initialized
INFO - 2016-09-23 23:13:48 --> Model Class Initialized
INFO - 2016-09-23 23:13:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:48 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:48 --> Total execution time: 0.1356
INFO - 2016-09-23 23:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:48 --> Controller Class Initialized
INFO - 2016-09-23 23:13:48 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:48 --> Model Class Initialized
INFO - 2016-09-23 23:13:48 --> Model Class Initialized
INFO - 2016-09-23 23:13:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:48 --> Config Class Initialized
INFO - 2016-09-23 23:13:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:48 --> URI Class Initialized
INFO - 2016-09-23 23:13:48 --> Router Class Initialized
INFO - 2016-09-23 23:13:48 --> Output Class Initialized
INFO - 2016-09-23 23:13:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:48 --> Input Class Initialized
INFO - 2016-09-23 23:13:48 --> Language Class Initialized
INFO - 2016-09-23 23:13:48 --> Loader Class Initialized
INFO - 2016-09-23 23:13:48 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:48 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:48 --> Controller Class Initialized
INFO - 2016-09-23 23:13:48 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:48 --> Model Class Initialized
INFO - 2016-09-23 23:13:48 --> Model Class Initialized
INFO - 2016-09-23 23:13:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:13:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-23 23:13:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:13:48 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:48 --> Total execution time: 0.0811
INFO - 2016-09-23 23:13:53 --> Config Class Initialized
INFO - 2016-09-23 23:13:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:53 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:53 --> URI Class Initialized
INFO - 2016-09-23 23:13:53 --> Router Class Initialized
INFO - 2016-09-23 23:13:53 --> Output Class Initialized
INFO - 2016-09-23 23:13:53 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:53 --> Input Class Initialized
INFO - 2016-09-23 23:13:53 --> Language Class Initialized
INFO - 2016-09-23 23:13:53 --> Loader Class Initialized
INFO - 2016-09-23 23:13:53 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:53 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:53 --> Controller Class Initialized
INFO - 2016-09-23 23:13:53 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:53 --> Config Class Initialized
INFO - 2016-09-23 23:13:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:53 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:53 --> URI Class Initialized
INFO - 2016-09-23 23:13:53 --> Router Class Initialized
INFO - 2016-09-23 23:13:53 --> Output Class Initialized
INFO - 2016-09-23 23:13:53 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:53 --> Input Class Initialized
INFO - 2016-09-23 23:13:53 --> Language Class Initialized
INFO - 2016-09-23 23:13:53 --> Loader Class Initialized
INFO - 2016-09-23 23:13:53 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:53 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:53 --> Controller Class Initialized
INFO - 2016-09-23 23:13:53 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:13:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2016-09-23 23:13:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:13:53 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:53 --> Total execution time: 0.0600
INFO - 2016-09-23 23:13:53 --> Config Class Initialized
INFO - 2016-09-23 23:13:53 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:53 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:53 --> Config Class Initialized
INFO - 2016-09-23 23:13:53 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:53 --> URI Class Initialized
INFO - 2016-09-23 23:13:53 --> Router Class Initialized
DEBUG - 2016-09-23 23:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:53 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:53 --> URI Class Initialized
INFO - 2016-09-23 23:13:53 --> Output Class Initialized
INFO - 2016-09-23 23:13:53 --> Router Class Initialized
INFO - 2016-09-23 23:13:53 --> Security Class Initialized
INFO - 2016-09-23 23:13:53 --> Output Class Initialized
DEBUG - 2016-09-23 23:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:53 --> Input Class Initialized
INFO - 2016-09-23 23:13:53 --> Language Class Initialized
INFO - 2016-09-23 23:13:53 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:53 --> Input Class Initialized
INFO - 2016-09-23 23:13:53 --> Language Class Initialized
INFO - 2016-09-23 23:13:53 --> Loader Class Initialized
INFO - 2016-09-23 23:13:53 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:53 --> Loader Class Initialized
INFO - 2016-09-23 23:13:53 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:53 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:53 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:53 --> Controller Class Initialized
INFO - 2016-09-23 23:13:53 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:53 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:53 --> Total execution time: 0.0828
INFO - 2016-09-23 23:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:53 --> Controller Class Initialized
INFO - 2016-09-23 23:13:53 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Model Class Initialized
INFO - 2016-09-23 23:13:53 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:13:53 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 23:13:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 23:13:53 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:53 --> Total execution time: 0.1102
INFO - 2016-09-23 23:13:56 --> Config Class Initialized
INFO - 2016-09-23 23:13:56 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:56 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:56 --> URI Class Initialized
INFO - 2016-09-23 23:13:56 --> Router Class Initialized
INFO - 2016-09-23 23:13:56 --> Config Class Initialized
INFO - 2016-09-23 23:13:56 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:56 --> Output Class Initialized
INFO - 2016-09-23 23:13:56 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:56 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:56 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:56 --> Input Class Initialized
INFO - 2016-09-23 23:13:56 --> URI Class Initialized
INFO - 2016-09-23 23:13:56 --> Language Class Initialized
INFO - 2016-09-23 23:13:56 --> Router Class Initialized
INFO - 2016-09-23 23:13:56 --> Output Class Initialized
INFO - 2016-09-23 23:13:56 --> Loader Class Initialized
INFO - 2016-09-23 23:13:56 --> Security Class Initialized
INFO - 2016-09-23 23:13:56 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:56 --> Helper loaded: language_helper
DEBUG - 2016-09-23 23:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:56 --> Input Class Initialized
INFO - 2016-09-23 23:13:56 --> Language Class Initialized
INFO - 2016-09-23 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:56 --> Controller Class Initialized
INFO - 2016-09-23 23:13:56 --> Loader Class Initialized
INFO - 2016-09-23 23:13:56 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:56 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:56 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:56 --> Model Class Initialized
INFO - 2016-09-23 23:13:56 --> Model Class Initialized
INFO - 2016-09-23 23:13:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:56 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:56 --> Total execution time: 0.0636
INFO - 2016-09-23 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:56 --> Controller Class Initialized
INFO - 2016-09-23 23:13:56 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:56 --> Model Class Initialized
INFO - 2016-09-23 23:13:56 --> Model Class Initialized
INFO - 2016-09-23 23:13:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:56 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:56 --> Total execution time: 0.0881
INFO - 2016-09-23 23:13:58 --> Config Class Initialized
INFO - 2016-09-23 23:13:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:13:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:58 --> Config Class Initialized
INFO - 2016-09-23 23:13:58 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:58 --> Hooks Class Initialized
INFO - 2016-09-23 23:13:58 --> URI Class Initialized
INFO - 2016-09-23 23:13:58 --> Router Class Initialized
DEBUG - 2016-09-23 23:13:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:13:58 --> Utf8 Class Initialized
INFO - 2016-09-23 23:13:58 --> Output Class Initialized
INFO - 2016-09-23 23:13:58 --> URI Class Initialized
INFO - 2016-09-23 23:13:58 --> Security Class Initialized
INFO - 2016-09-23 23:13:58 --> Router Class Initialized
DEBUG - 2016-09-23 23:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:58 --> Input Class Initialized
INFO - 2016-09-23 23:13:58 --> Output Class Initialized
INFO - 2016-09-23 23:13:58 --> Language Class Initialized
INFO - 2016-09-23 23:13:58 --> Security Class Initialized
DEBUG - 2016-09-23 23:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:13:58 --> Input Class Initialized
INFO - 2016-09-23 23:13:58 --> Loader Class Initialized
INFO - 2016-09-23 23:13:58 --> Language Class Initialized
INFO - 2016-09-23 23:13:58 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:58 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:58 --> Loader Class Initialized
INFO - 2016-09-23 23:13:58 --> Helper loaded: url_helper
INFO - 2016-09-23 23:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:58 --> Controller Class Initialized
INFO - 2016-09-23 23:13:58 --> Helper loaded: language_helper
INFO - 2016-09-23 23:13:58 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:58 --> Model Class Initialized
INFO - 2016-09-23 23:13:58 --> Model Class Initialized
INFO - 2016-09-23 23:13:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:58 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:58 --> Total execution time: 0.0644
INFO - 2016-09-23 23:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:13:58 --> Controller Class Initialized
INFO - 2016-09-23 23:13:58 --> Database Driver Class Initialized
INFO - 2016-09-23 23:13:58 --> Model Class Initialized
INFO - 2016-09-23 23:13:58 --> Model Class Initialized
INFO - 2016-09-23 23:13:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:13:59 --> Final output sent to browser
DEBUG - 2016-09-23 23:13:59 --> Total execution time: 0.0866
INFO - 2016-09-23 23:14:00 --> Config Class Initialized
INFO - 2016-09-23 23:14:00 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:00 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:00 --> URI Class Initialized
INFO - 2016-09-23 23:14:00 --> Config Class Initialized
INFO - 2016-09-23 23:14:00 --> Router Class Initialized
INFO - 2016-09-23 23:14:00 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:00 --> Output Class Initialized
DEBUG - 2016-09-23 23:14:00 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:00 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:00 --> Security Class Initialized
INFO - 2016-09-23 23:14:00 --> URI Class Initialized
DEBUG - 2016-09-23 23:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:00 --> Input Class Initialized
INFO - 2016-09-23 23:14:00 --> Language Class Initialized
INFO - 2016-09-23 23:14:00 --> Router Class Initialized
INFO - 2016-09-23 23:14:00 --> Output Class Initialized
INFO - 2016-09-23 23:14:00 --> Security Class Initialized
INFO - 2016-09-23 23:14:00 --> Loader Class Initialized
DEBUG - 2016-09-23 23:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:00 --> Input Class Initialized
INFO - 2016-09-23 23:14:00 --> Language Class Initialized
INFO - 2016-09-23 23:14:00 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:00 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:00 --> Loader Class Initialized
INFO - 2016-09-23 23:14:00 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:00 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:00 --> Controller Class Initialized
INFO - 2016-09-23 23:14:00 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:00 --> Model Class Initialized
INFO - 2016-09-23 23:14:00 --> Model Class Initialized
INFO - 2016-09-23 23:14:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:00 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:00 --> Total execution time: 0.0823
INFO - 2016-09-23 23:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:00 --> Controller Class Initialized
INFO - 2016-09-23 23:14:00 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:00 --> Model Class Initialized
INFO - 2016-09-23 23:14:01 --> Model Class Initialized
INFO - 2016-09-23 23:14:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:01 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:01 --> Total execution time: 0.1085
INFO - 2016-09-23 23:14:02 --> Config Class Initialized
INFO - 2016-09-23 23:14:02 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:02 --> Config Class Initialized
DEBUG - 2016-09-23 23:14:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:02 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:02 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:02 --> URI Class Initialized
INFO - 2016-09-23 23:14:02 --> Router Class Initialized
DEBUG - 2016-09-23 23:14:02 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:02 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:02 --> Output Class Initialized
INFO - 2016-09-23 23:14:02 --> URI Class Initialized
INFO - 2016-09-23 23:14:02 --> Security Class Initialized
INFO - 2016-09-23 23:14:02 --> Router Class Initialized
DEBUG - 2016-09-23 23:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:02 --> Input Class Initialized
INFO - 2016-09-23 23:14:02 --> Output Class Initialized
INFO - 2016-09-23 23:14:02 --> Language Class Initialized
INFO - 2016-09-23 23:14:02 --> Security Class Initialized
INFO - 2016-09-23 23:14:02 --> Loader Class Initialized
DEBUG - 2016-09-23 23:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:02 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:02 --> Input Class Initialized
INFO - 2016-09-23 23:14:02 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:02 --> Language Class Initialized
INFO - 2016-09-23 23:14:02 --> Loader Class Initialized
INFO - 2016-09-23 23:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:02 --> Controller Class Initialized
INFO - 2016-09-23 23:14:02 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:02 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:02 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:02 --> Model Class Initialized
INFO - 2016-09-23 23:14:02 --> Model Class Initialized
INFO - 2016-09-23 23:14:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:02 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:02 --> Total execution time: 0.0753
INFO - 2016-09-23 23:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:02 --> Controller Class Initialized
INFO - 2016-09-23 23:14:02 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:02 --> Model Class Initialized
INFO - 2016-09-23 23:14:02 --> Model Class Initialized
INFO - 2016-09-23 23:14:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:03 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:03 --> Total execution time: 0.1139
INFO - 2016-09-23 23:14:05 --> Config Class Initialized
INFO - 2016-09-23 23:14:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:05 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:05 --> URI Class Initialized
INFO - 2016-09-23 23:14:05 --> Router Class Initialized
INFO - 2016-09-23 23:14:05 --> Output Class Initialized
INFO - 2016-09-23 23:14:05 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:05 --> Input Class Initialized
INFO - 2016-09-23 23:14:05 --> Language Class Initialized
INFO - 2016-09-23 23:14:05 --> Loader Class Initialized
INFO - 2016-09-23 23:14:05 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:05 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:05 --> Controller Class Initialized
INFO - 2016-09-23 23:14:05 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:05 --> Model Class Initialized
INFO - 2016-09-23 23:14:05 --> Model Class Initialized
INFO - 2016-09-23 23:14:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:05 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:05 --> Total execution time: 0.0865
INFO - 2016-09-23 23:14:07 --> Config Class Initialized
INFO - 2016-09-23 23:14:07 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:07 --> Config Class Initialized
INFO - 2016-09-23 23:14:07 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:07 --> Config Class Initialized
DEBUG - 2016-09-23 23:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:07 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:07 --> URI Class Initialized
DEBUG - 2016-09-23 23:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:07 --> Router Class Initialized
INFO - 2016-09-23 23:14:07 --> URI Class Initialized
INFO - 2016-09-23 23:14:07 --> Output Class Initialized
INFO - 2016-09-23 23:14:07 --> Router Class Initialized
INFO - 2016-09-23 23:14:07 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:07 --> Output Class Initialized
DEBUG - 2016-09-23 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:07 --> Input Class Initialized
INFO - 2016-09-23 23:14:07 --> URI Class Initialized
INFO - 2016-09-23 23:14:07 --> Security Class Initialized
INFO - 2016-09-23 23:14:07 --> Language Class Initialized
DEBUG - 2016-09-23 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:07 --> Input Class Initialized
INFO - 2016-09-23 23:14:07 --> Router Class Initialized
INFO - 2016-09-23 23:14:07 --> Language Class Initialized
INFO - 2016-09-23 23:14:07 --> Output Class Initialized
ERROR - 2016-09-23 23:14:07 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:14:07 --> Security Class Initialized
INFO - 2016-09-23 23:14:07 --> Loader Class Initialized
DEBUG - 2016-09-23 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:07 --> Input Class Initialized
INFO - 2016-09-23 23:14:07 --> Language Class Initialized
INFO - 2016-09-23 23:14:07 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:07 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:07 --> Loader Class Initialized
INFO - 2016-09-23 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:07 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:07 --> Controller Class Initialized
INFO - 2016-09-23 23:14:07 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:07 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:07 --> Model Class Initialized
INFO - 2016-09-23 23:14:07 --> Model Class Initialized
INFO - 2016-09-23 23:14:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:07 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:07 --> Total execution time: 0.1140
INFO - 2016-09-23 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:07 --> Controller Class Initialized
INFO - 2016-09-23 23:14:07 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:07 --> Model Class Initialized
INFO - 2016-09-23 23:14:07 --> Model Class Initialized
INFO - 2016-09-23 23:14:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:07 --> Config Class Initialized
INFO - 2016-09-23 23:14:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:07 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:07 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:07 --> URI Class Initialized
INFO - 2016-09-23 23:14:07 --> Router Class Initialized
INFO - 2016-09-23 23:14:07 --> Output Class Initialized
INFO - 2016-09-23 23:14:07 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:07 --> Input Class Initialized
INFO - 2016-09-23 23:14:07 --> Language Class Initialized
INFO - 2016-09-23 23:14:07 --> Loader Class Initialized
INFO - 2016-09-23 23:14:07 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:07 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:07 --> Controller Class Initialized
INFO - 2016-09-23 23:14:07 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:07 --> Model Class Initialized
INFO - 2016-09-23 23:14:07 --> Model Class Initialized
INFO - 2016-09-23 23:14:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:14:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-09-23 23:14:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:14:07 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:07 --> Total execution time: 0.0750
INFO - 2016-09-23 23:14:12 --> Config Class Initialized
INFO - 2016-09-23 23:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:12 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:12 --> URI Class Initialized
INFO - 2016-09-23 23:14:12 --> Router Class Initialized
INFO - 2016-09-23 23:14:12 --> Output Class Initialized
INFO - 2016-09-23 23:14:12 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:12 --> Input Class Initialized
INFO - 2016-09-23 23:14:12 --> Language Class Initialized
INFO - 2016-09-23 23:14:12 --> Loader Class Initialized
INFO - 2016-09-23 23:14:12 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:12 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:12 --> Controller Class Initialized
INFO - 2016-09-23 23:14:12 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:12 --> Config Class Initialized
INFO - 2016-09-23 23:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:12 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:12 --> URI Class Initialized
INFO - 2016-09-23 23:14:12 --> Router Class Initialized
INFO - 2016-09-23 23:14:12 --> Output Class Initialized
INFO - 2016-09-23 23:14:12 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:12 --> Input Class Initialized
INFO - 2016-09-23 23:14:12 --> Language Class Initialized
INFO - 2016-09-23 23:14:12 --> Loader Class Initialized
INFO - 2016-09-23 23:14:12 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:12 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:12 --> Controller Class Initialized
INFO - 2016-09-23 23:14:12 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:14:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2016-09-23 23:14:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:14:12 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:12 --> Total execution time: 0.0630
INFO - 2016-09-23 23:14:12 --> Config Class Initialized
INFO - 2016-09-23 23:14:12 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:12 --> Config Class Initialized
INFO - 2016-09-23 23:14:12 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:12 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:12 --> URI Class Initialized
DEBUG - 2016-09-23 23:14:12 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:12 --> Router Class Initialized
INFO - 2016-09-23 23:14:12 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:12 --> URI Class Initialized
INFO - 2016-09-23 23:14:12 --> Output Class Initialized
INFO - 2016-09-23 23:14:12 --> Router Class Initialized
INFO - 2016-09-23 23:14:12 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:12 --> Output Class Initialized
INFO - 2016-09-23 23:14:12 --> Input Class Initialized
INFO - 2016-09-23 23:14:12 --> Language Class Initialized
INFO - 2016-09-23 23:14:12 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:12 --> Loader Class Initialized
INFO - 2016-09-23 23:14:12 --> Input Class Initialized
INFO - 2016-09-23 23:14:12 --> Language Class Initialized
INFO - 2016-09-23 23:14:12 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:12 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:12 --> Loader Class Initialized
INFO - 2016-09-23 23:14:12 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:12 --> Controller Class Initialized
INFO - 2016-09-23 23:14:12 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:12 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:12 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:12 --> Total execution time: 0.0818
INFO - 2016-09-23 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:12 --> Controller Class Initialized
INFO - 2016-09-23 23:14:12 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Model Class Initialized
INFO - 2016-09-23 23:14:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-23 23:14:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-23 23:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-23 23:14:12 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:12 --> Total execution time: 0.1160
INFO - 2016-09-23 23:14:16 --> Config Class Initialized
INFO - 2016-09-23 23:14:16 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:16 --> Config Class Initialized
INFO - 2016-09-23 23:14:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 23:14:16 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:16 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:16 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:16 --> URI Class Initialized
INFO - 2016-09-23 23:14:16 --> URI Class Initialized
INFO - 2016-09-23 23:14:16 --> Router Class Initialized
INFO - 2016-09-23 23:14:16 --> Router Class Initialized
INFO - 2016-09-23 23:14:16 --> Output Class Initialized
INFO - 2016-09-23 23:14:16 --> Output Class Initialized
INFO - 2016-09-23 23:14:16 --> Security Class Initialized
INFO - 2016-09-23 23:14:16 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:16 --> Input Class Initialized
INFO - 2016-09-23 23:14:16 --> Language Class Initialized
DEBUG - 2016-09-23 23:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:16 --> Input Class Initialized
INFO - 2016-09-23 23:14:16 --> Language Class Initialized
INFO - 2016-09-23 23:14:16 --> Loader Class Initialized
INFO - 2016-09-23 23:14:16 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:16 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:16 --> Loader Class Initialized
INFO - 2016-09-23 23:14:16 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:16 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:16 --> Controller Class Initialized
INFO - 2016-09-23 23:14:16 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:16 --> Model Class Initialized
INFO - 2016-09-23 23:14:16 --> Model Class Initialized
INFO - 2016-09-23 23:14:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:16 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:16 --> Total execution time: 0.0832
INFO - 2016-09-23 23:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:16 --> Controller Class Initialized
INFO - 2016-09-23 23:14:16 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:16 --> Model Class Initialized
INFO - 2016-09-23 23:14:16 --> Model Class Initialized
INFO - 2016-09-23 23:14:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:16 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:16 --> Total execution time: 0.1091
INFO - 2016-09-23 23:14:31 --> Config Class Initialized
INFO - 2016-09-23 23:14:31 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:31 --> Config Class Initialized
INFO - 2016-09-23 23:14:31 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:31 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:31 --> URI Class Initialized
DEBUG - 2016-09-23 23:14:31 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:31 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:31 --> Router Class Initialized
INFO - 2016-09-23 23:14:31 --> URI Class Initialized
INFO - 2016-09-23 23:14:31 --> Output Class Initialized
INFO - 2016-09-23 23:14:31 --> Router Class Initialized
INFO - 2016-09-23 23:14:31 --> Security Class Initialized
INFO - 2016-09-23 23:14:31 --> Output Class Initialized
DEBUG - 2016-09-23 23:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:31 --> Input Class Initialized
INFO - 2016-09-23 23:14:31 --> Security Class Initialized
INFO - 2016-09-23 23:14:31 --> Language Class Initialized
DEBUG - 2016-09-23 23:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:31 --> Input Class Initialized
INFO - 2016-09-23 23:14:31 --> Loader Class Initialized
INFO - 2016-09-23 23:14:31 --> Language Class Initialized
INFO - 2016-09-23 23:14:31 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:31 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:31 --> Loader Class Initialized
INFO - 2016-09-23 23:14:31 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:31 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:31 --> Controller Class Initialized
INFO - 2016-09-23 23:14:31 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:31 --> Model Class Initialized
INFO - 2016-09-23 23:14:31 --> Model Class Initialized
INFO - 2016-09-23 23:14:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:32 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:32 --> Total execution time: 0.0855
INFO - 2016-09-23 23:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:32 --> Controller Class Initialized
INFO - 2016-09-23 23:14:32 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:32 --> Model Class Initialized
INFO - 2016-09-23 23:14:32 --> Model Class Initialized
INFO - 2016-09-23 23:14:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:32 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:32 --> Total execution time: 0.1051
INFO - 2016-09-23 23:14:34 --> Config Class Initialized
INFO - 2016-09-23 23:14:34 --> Config Class Initialized
INFO - 2016-09-23 23:14:34 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:34 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:14:34 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:34 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:34 --> URI Class Initialized
INFO - 2016-09-23 23:14:34 --> URI Class Initialized
INFO - 2016-09-23 23:14:34 --> Router Class Initialized
INFO - 2016-09-23 23:14:34 --> Router Class Initialized
INFO - 2016-09-23 23:14:34 --> Output Class Initialized
INFO - 2016-09-23 23:14:34 --> Output Class Initialized
INFO - 2016-09-23 23:14:34 --> Security Class Initialized
INFO - 2016-09-23 23:14:34 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:34 --> Input Class Initialized
DEBUG - 2016-09-23 23:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:34 --> Input Class Initialized
INFO - 2016-09-23 23:14:34 --> Language Class Initialized
INFO - 2016-09-23 23:14:34 --> Language Class Initialized
INFO - 2016-09-23 23:14:34 --> Loader Class Initialized
INFO - 2016-09-23 23:14:34 --> Loader Class Initialized
INFO - 2016-09-23 23:14:34 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:34 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:34 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:34 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:34 --> Controller Class Initialized
INFO - 2016-09-23 23:14:34 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:34 --> Model Class Initialized
INFO - 2016-09-23 23:14:34 --> Model Class Initialized
INFO - 2016-09-23 23:14:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:34 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:34 --> Total execution time: 0.0747
INFO - 2016-09-23 23:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:34 --> Controller Class Initialized
INFO - 2016-09-23 23:14:34 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:34 --> Model Class Initialized
INFO - 2016-09-23 23:14:34 --> Model Class Initialized
INFO - 2016-09-23 23:14:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:34 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:34 --> Total execution time: 0.0963
INFO - 2016-09-23 23:14:37 --> Config Class Initialized
INFO - 2016-09-23 23:14:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:37 --> URI Class Initialized
INFO - 2016-09-23 23:14:37 --> Config Class Initialized
INFO - 2016-09-23 23:14:37 --> Router Class Initialized
INFO - 2016-09-23 23:14:37 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:37 --> Output Class Initialized
DEBUG - 2016-09-23 23:14:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:37 --> Security Class Initialized
INFO - 2016-09-23 23:14:37 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:37 --> URI Class Initialized
INFO - 2016-09-23 23:14:37 --> Input Class Initialized
INFO - 2016-09-23 23:14:37 --> Language Class Initialized
INFO - 2016-09-23 23:14:37 --> Router Class Initialized
INFO - 2016-09-23 23:14:37 --> Output Class Initialized
INFO - 2016-09-23 23:14:37 --> Loader Class Initialized
INFO - 2016-09-23 23:14:37 --> Security Class Initialized
INFO - 2016-09-23 23:14:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:37 --> Helper loaded: language_helper
DEBUG - 2016-09-23 23:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:37 --> Input Class Initialized
INFO - 2016-09-23 23:14:37 --> Language Class Initialized
INFO - 2016-09-23 23:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:37 --> Controller Class Initialized
INFO - 2016-09-23 23:14:37 --> Loader Class Initialized
INFO - 2016-09-23 23:14:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:37 --> Model Class Initialized
INFO - 2016-09-23 23:14:37 --> Model Class Initialized
INFO - 2016-09-23 23:14:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:37 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:37 --> Total execution time: 0.0862
INFO - 2016-09-23 23:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:37 --> Controller Class Initialized
INFO - 2016-09-23 23:14:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:37 --> Model Class Initialized
INFO - 2016-09-23 23:14:37 --> Model Class Initialized
INFO - 2016-09-23 23:14:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:37 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:37 --> Total execution time: 0.1164
INFO - 2016-09-23 23:14:40 --> Config Class Initialized
INFO - 2016-09-23 23:14:40 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:40 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:40 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:40 --> URI Class Initialized
INFO - 2016-09-23 23:14:40 --> Router Class Initialized
INFO - 2016-09-23 23:14:40 --> Output Class Initialized
INFO - 2016-09-23 23:14:40 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:40 --> Input Class Initialized
INFO - 2016-09-23 23:14:40 --> Language Class Initialized
INFO - 2016-09-23 23:14:40 --> Loader Class Initialized
INFO - 2016-09-23 23:14:40 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:40 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:40 --> Controller Class Initialized
INFO - 2016-09-23 23:14:40 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:40 --> Model Class Initialized
INFO - 2016-09-23 23:14:40 --> Model Class Initialized
INFO - 2016-09-23 23:14:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:40 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:40 --> Total execution time: 0.0960
INFO - 2016-09-23 23:14:41 --> Config Class Initialized
INFO - 2016-09-23 23:14:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:41 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:41 --> URI Class Initialized
INFO - 2016-09-23 23:14:41 --> Router Class Initialized
INFO - 2016-09-23 23:14:41 --> Config Class Initialized
INFO - 2016-09-23 23:14:41 --> Output Class Initialized
INFO - 2016-09-23 23:14:41 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:41 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-23 23:14:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:41 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:41 --> Input Class Initialized
INFO - 2016-09-23 23:14:41 --> Config Class Initialized
INFO - 2016-09-23 23:14:41 --> Hooks Class Initialized
INFO - 2016-09-23 23:14:41 --> URI Class Initialized
INFO - 2016-09-23 23:14:41 --> Language Class Initialized
INFO - 2016-09-23 23:14:41 --> Router Class Initialized
DEBUG - 2016-09-23 23:14:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:41 --> Utf8 Class Initialized
ERROR - 2016-09-23 23:14:41 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:14:41 --> URI Class Initialized
INFO - 2016-09-23 23:14:41 --> Output Class Initialized
INFO - 2016-09-23 23:14:41 --> Security Class Initialized
INFO - 2016-09-23 23:14:41 --> Router Class Initialized
DEBUG - 2016-09-23 23:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:41 --> Input Class Initialized
INFO - 2016-09-23 23:14:41 --> Language Class Initialized
INFO - 2016-09-23 23:14:41 --> Output Class Initialized
INFO - 2016-09-23 23:14:41 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:41 --> Input Class Initialized
INFO - 2016-09-23 23:14:41 --> Language Class Initialized
INFO - 2016-09-23 23:14:41 --> Loader Class Initialized
INFO - 2016-09-23 23:14:41 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:41 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:41 --> Loader Class Initialized
INFO - 2016-09-23 23:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:41 --> Controller Class Initialized
INFO - 2016-09-23 23:14:41 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:41 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:41 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:41 --> Model Class Initialized
INFO - 2016-09-23 23:14:41 --> Model Class Initialized
INFO - 2016-09-23 23:14:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:41 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:41 --> Total execution time: 0.1336
INFO - 2016-09-23 23:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:41 --> Controller Class Initialized
INFO - 2016-09-23 23:14:41 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:41 --> Model Class Initialized
INFO - 2016-09-23 23:14:41 --> Model Class Initialized
INFO - 2016-09-23 23:14:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:41 --> Config Class Initialized
INFO - 2016-09-23 23:14:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:41 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:41 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:41 --> URI Class Initialized
INFO - 2016-09-23 23:14:41 --> Router Class Initialized
INFO - 2016-09-23 23:14:41 --> Output Class Initialized
INFO - 2016-09-23 23:14:41 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:41 --> Input Class Initialized
INFO - 2016-09-23 23:14:41 --> Language Class Initialized
INFO - 2016-09-23 23:14:41 --> Loader Class Initialized
INFO - 2016-09-23 23:14:41 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:41 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:41 --> Controller Class Initialized
INFO - 2016-09-23 23:14:41 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:41 --> Model Class Initialized
INFO - 2016-09-23 23:14:42 --> Model Class Initialized
INFO - 2016-09-23 23:14:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2016-09-23 23:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:14:42 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:42 --> Total execution time: 0.0817
INFO - 2016-09-23 23:14:46 --> Config Class Initialized
INFO - 2016-09-23 23:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:46 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:46 --> URI Class Initialized
INFO - 2016-09-23 23:14:46 --> Router Class Initialized
INFO - 2016-09-23 23:14:46 --> Output Class Initialized
INFO - 2016-09-23 23:14:46 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:46 --> Input Class Initialized
INFO - 2016-09-23 23:14:46 --> Language Class Initialized
INFO - 2016-09-23 23:14:46 --> Loader Class Initialized
INFO - 2016-09-23 23:14:46 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:46 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:46 --> Controller Class Initialized
INFO - 2016-09-23 23:14:46 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:47 --> Model Class Initialized
INFO - 2016-09-23 23:14:47 --> Model Class Initialized
INFO - 2016-09-23 23:14:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:47 --> Config Class Initialized
INFO - 2016-09-23 23:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:14:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:14:47 --> URI Class Initialized
INFO - 2016-09-23 23:14:47 --> Router Class Initialized
INFO - 2016-09-23 23:14:47 --> Output Class Initialized
INFO - 2016-09-23 23:14:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:14:47 --> Input Class Initialized
INFO - 2016-09-23 23:14:47 --> Language Class Initialized
INFO - 2016-09-23 23:14:47 --> Loader Class Initialized
INFO - 2016-09-23 23:14:47 --> Helper loaded: url_helper
INFO - 2016-09-23 23:14:47 --> Helper loaded: language_helper
INFO - 2016-09-23 23:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:14:47 --> Controller Class Initialized
INFO - 2016-09-23 23:14:47 --> Database Driver Class Initialized
INFO - 2016-09-23 23:14:47 --> Model Class Initialized
INFO - 2016-09-23 23:14:47 --> Model Class Initialized
INFO - 2016-09-23 23:14:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 5 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 6 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 7 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 8 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 10 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 11 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 12 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 13 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 14 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
ERROR - 2016-09-23 23:14:47 --> Severity: Notice --> Undefined offset: 15 C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php 426
INFO - 2016-09-23 23:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-23 23:14:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:14:47 --> Final output sent to browser
DEBUG - 2016-09-23 23:14:47 --> Total execution time: 0.0808
INFO - 2016-09-23 23:16:46 --> Config Class Initialized
INFO - 2016-09-23 23:16:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:16:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:16:46 --> Utf8 Class Initialized
INFO - 2016-09-23 23:16:46 --> URI Class Initialized
INFO - 2016-09-23 23:16:46 --> Router Class Initialized
INFO - 2016-09-23 23:16:46 --> Output Class Initialized
INFO - 2016-09-23 23:16:46 --> Security Class Initialized
DEBUG - 2016-09-23 23:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:16:46 --> Input Class Initialized
INFO - 2016-09-23 23:16:46 --> Language Class Initialized
INFO - 2016-09-23 23:16:46 --> Loader Class Initialized
INFO - 2016-09-23 23:16:46 --> Helper loaded: url_helper
INFO - 2016-09-23 23:16:46 --> Helper loaded: language_helper
INFO - 2016-09-23 23:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:16:46 --> Controller Class Initialized
INFO - 2016-09-23 23:16:46 --> Database Driver Class Initialized
INFO - 2016-09-23 23:16:46 --> Model Class Initialized
INFO - 2016-09-23 23:16:46 --> Model Class Initialized
INFO - 2016-09-23 23:16:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:16:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:16:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-23 23:16:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:16:46 --> Final output sent to browser
DEBUG - 2016-09-23 23:16:46 --> Total execution time: 0.0705
INFO - 2016-09-23 23:16:47 --> Config Class Initialized
INFO - 2016-09-23 23:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:16:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:16:47 --> URI Class Initialized
INFO - 2016-09-23 23:16:47 --> Config Class Initialized
INFO - 2016-09-23 23:16:47 --> Hooks Class Initialized
INFO - 2016-09-23 23:16:47 --> Router Class Initialized
DEBUG - 2016-09-23 23:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:16:47 --> Output Class Initialized
INFO - 2016-09-23 23:16:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:16:47 --> URI Class Initialized
INFO - 2016-09-23 23:16:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:16:47 --> Router Class Initialized
INFO - 2016-09-23 23:16:47 --> Input Class Initialized
INFO - 2016-09-23 23:16:47 --> Language Class Initialized
INFO - 2016-09-23 23:16:47 --> Output Class Initialized
INFO - 2016-09-23 23:16:47 --> Security Class Initialized
INFO - 2016-09-23 23:16:47 --> Loader Class Initialized
DEBUG - 2016-09-23 23:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:16:47 --> Input Class Initialized
INFO - 2016-09-23 23:16:47 --> Helper loaded: url_helper
INFO - 2016-09-23 23:16:47 --> Language Class Initialized
INFO - 2016-09-23 23:16:47 --> Helper loaded: language_helper
INFO - 2016-09-23 23:16:47 --> Loader Class Initialized
INFO - 2016-09-23 23:16:47 --> Helper loaded: url_helper
INFO - 2016-09-23 23:16:47 --> Helper loaded: language_helper
INFO - 2016-09-23 23:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:16:47 --> Controller Class Initialized
INFO - 2016-09-23 23:16:47 --> Database Driver Class Initialized
INFO - 2016-09-23 23:16:47 --> Model Class Initialized
INFO - 2016-09-23 23:16:47 --> Model Class Initialized
INFO - 2016-09-23 23:16:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:16:47 --> Final output sent to browser
DEBUG - 2016-09-23 23:16:47 --> Total execution time: 0.0955
INFO - 2016-09-23 23:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:16:47 --> Controller Class Initialized
INFO - 2016-09-23 23:16:47 --> Database Driver Class Initialized
INFO - 2016-09-23 23:16:47 --> Model Class Initialized
INFO - 2016-09-23 23:16:47 --> Model Class Initialized
INFO - 2016-09-23 23:16:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:16:47 --> Final output sent to browser
DEBUG - 2016-09-23 23:16:47 --> Total execution time: 0.1416
INFO - 2016-09-23 23:17:17 --> Config Class Initialized
INFO - 2016-09-23 23:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:17:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:17:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:17:17 --> URI Class Initialized
INFO - 2016-09-23 23:17:17 --> Router Class Initialized
INFO - 2016-09-23 23:17:17 --> Output Class Initialized
INFO - 2016-09-23 23:17:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:17:17 --> Input Class Initialized
INFO - 2016-09-23 23:17:17 --> Language Class Initialized
ERROR - 2016-09-23 23:17:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:17:47 --> Config Class Initialized
INFO - 2016-09-23 23:17:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:17:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:17:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:17:47 --> URI Class Initialized
INFO - 2016-09-23 23:17:47 --> Router Class Initialized
INFO - 2016-09-23 23:17:47 --> Output Class Initialized
INFO - 2016-09-23 23:17:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:17:47 --> Input Class Initialized
INFO - 2016-09-23 23:17:47 --> Language Class Initialized
ERROR - 2016-09-23 23:17:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:18:17 --> Config Class Initialized
INFO - 2016-09-23 23:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:18:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:18:17 --> URI Class Initialized
INFO - 2016-09-23 23:18:17 --> Router Class Initialized
INFO - 2016-09-23 23:18:17 --> Output Class Initialized
INFO - 2016-09-23 23:18:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:18:17 --> Input Class Initialized
INFO - 2016-09-23 23:18:17 --> Language Class Initialized
ERROR - 2016-09-23 23:18:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:18:47 --> Config Class Initialized
INFO - 2016-09-23 23:18:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:18:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:18:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:18:47 --> URI Class Initialized
INFO - 2016-09-23 23:18:47 --> Router Class Initialized
INFO - 2016-09-23 23:18:47 --> Output Class Initialized
INFO - 2016-09-23 23:18:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:18:47 --> Input Class Initialized
INFO - 2016-09-23 23:18:47 --> Language Class Initialized
ERROR - 2016-09-23 23:18:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:19:17 --> Config Class Initialized
INFO - 2016-09-23 23:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:19:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:19:17 --> URI Class Initialized
INFO - 2016-09-23 23:19:17 --> Router Class Initialized
INFO - 2016-09-23 23:19:17 --> Output Class Initialized
INFO - 2016-09-23 23:19:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:19:17 --> Input Class Initialized
INFO - 2016-09-23 23:19:17 --> Language Class Initialized
ERROR - 2016-09-23 23:19:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:19:47 --> Config Class Initialized
INFO - 2016-09-23 23:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:19:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:19:47 --> URI Class Initialized
INFO - 2016-09-23 23:19:47 --> Router Class Initialized
INFO - 2016-09-23 23:19:47 --> Output Class Initialized
INFO - 2016-09-23 23:19:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:19:47 --> Input Class Initialized
INFO - 2016-09-23 23:19:47 --> Language Class Initialized
ERROR - 2016-09-23 23:19:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:19:58 --> Config Class Initialized
INFO - 2016-09-23 23:19:58 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:19:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:19:58 --> Utf8 Class Initialized
INFO - 2016-09-23 23:19:58 --> Config Class Initialized
INFO - 2016-09-23 23:19:58 --> URI Class Initialized
INFO - 2016-09-23 23:19:58 --> Hooks Class Initialized
INFO - 2016-09-23 23:19:58 --> Router Class Initialized
DEBUG - 2016-09-23 23:19:58 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:19:58 --> Utf8 Class Initialized
INFO - 2016-09-23 23:19:58 --> Output Class Initialized
INFO - 2016-09-23 23:19:58 --> URI Class Initialized
INFO - 2016-09-23 23:19:58 --> Security Class Initialized
INFO - 2016-09-23 23:19:58 --> Router Class Initialized
DEBUG - 2016-09-23 23:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:19:58 --> Input Class Initialized
INFO - 2016-09-23 23:19:58 --> Output Class Initialized
INFO - 2016-09-23 23:19:58 --> Language Class Initialized
INFO - 2016-09-23 23:19:58 --> Security Class Initialized
DEBUG - 2016-09-23 23:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:19:58 --> Loader Class Initialized
INFO - 2016-09-23 23:19:58 --> Input Class Initialized
INFO - 2016-09-23 23:19:58 --> Language Class Initialized
INFO - 2016-09-23 23:19:58 --> Helper loaded: url_helper
INFO - 2016-09-23 23:19:58 --> Helper loaded: language_helper
INFO - 2016-09-23 23:19:58 --> Loader Class Initialized
INFO - 2016-09-23 23:19:58 --> Helper loaded: url_helper
INFO - 2016-09-23 23:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:19:58 --> Helper loaded: language_helper
INFO - 2016-09-23 23:19:58 --> Controller Class Initialized
INFO - 2016-09-23 23:19:58 --> Database Driver Class Initialized
INFO - 2016-09-23 23:19:58 --> Model Class Initialized
INFO - 2016-09-23 23:19:58 --> Model Class Initialized
INFO - 2016-09-23 23:19:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:19:58 --> Final output sent to browser
DEBUG - 2016-09-23 23:19:58 --> Total execution time: 0.0895
INFO - 2016-09-23 23:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:19:58 --> Controller Class Initialized
INFO - 2016-09-23 23:19:58 --> Database Driver Class Initialized
INFO - 2016-09-23 23:19:58 --> Model Class Initialized
INFO - 2016-09-23 23:19:58 --> Model Class Initialized
INFO - 2016-09-23 23:19:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:19:58 --> Final output sent to browser
DEBUG - 2016-09-23 23:19:58 --> Total execution time: 0.1095
INFO - 2016-09-23 23:20:18 --> Config Class Initialized
INFO - 2016-09-23 23:20:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:20:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:20:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:20:18 --> URI Class Initialized
INFO - 2016-09-23 23:20:18 --> Router Class Initialized
INFO - 2016-09-23 23:20:18 --> Output Class Initialized
INFO - 2016-09-23 23:20:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:20:18 --> Input Class Initialized
INFO - 2016-09-23 23:20:18 --> Language Class Initialized
ERROR - 2016-09-23 23:20:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:20:48 --> Config Class Initialized
INFO - 2016-09-23 23:20:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:20:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:20:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:20:48 --> URI Class Initialized
INFO - 2016-09-23 23:20:48 --> Router Class Initialized
INFO - 2016-09-23 23:20:48 --> Output Class Initialized
INFO - 2016-09-23 23:20:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:20:48 --> Input Class Initialized
INFO - 2016-09-23 23:20:48 --> Language Class Initialized
ERROR - 2016-09-23 23:20:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:21:17 --> Config Class Initialized
INFO - 2016-09-23 23:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:21:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:21:17 --> URI Class Initialized
INFO - 2016-09-23 23:21:17 --> Router Class Initialized
INFO - 2016-09-23 23:21:17 --> Output Class Initialized
INFO - 2016-09-23 23:21:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:21:17 --> Input Class Initialized
INFO - 2016-09-23 23:21:17 --> Language Class Initialized
ERROR - 2016-09-23 23:21:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:21:17 --> Config Class Initialized
INFO - 2016-09-23 23:21:17 --> Hooks Class Initialized
INFO - 2016-09-23 23:21:17 --> Config Class Initialized
INFO - 2016-09-23 23:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:21:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:21:17 --> URI Class Initialized
DEBUG - 2016-09-23 23:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:21:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:21:17 --> Router Class Initialized
INFO - 2016-09-23 23:21:17 --> URI Class Initialized
INFO - 2016-09-23 23:21:17 --> Router Class Initialized
INFO - 2016-09-23 23:21:17 --> Output Class Initialized
INFO - 2016-09-23 23:21:17 --> Security Class Initialized
INFO - 2016-09-23 23:21:17 --> Output Class Initialized
INFO - 2016-09-23 23:21:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:21:17 --> Input Class Initialized
INFO - 2016-09-23 23:21:17 --> Language Class Initialized
DEBUG - 2016-09-23 23:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:21:17 --> Input Class Initialized
INFO - 2016-09-23 23:21:17 --> Language Class Initialized
INFO - 2016-09-23 23:21:17 --> Loader Class Initialized
INFO - 2016-09-23 23:21:17 --> Helper loaded: url_helper
INFO - 2016-09-23 23:21:17 --> Loader Class Initialized
INFO - 2016-09-23 23:21:17 --> Helper loaded: language_helper
INFO - 2016-09-23 23:21:17 --> Helper loaded: url_helper
INFO - 2016-09-23 23:21:17 --> Helper loaded: language_helper
INFO - 2016-09-23 23:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:21:17 --> Controller Class Initialized
INFO - 2016-09-23 23:21:17 --> Database Driver Class Initialized
INFO - 2016-09-23 23:21:17 --> Model Class Initialized
INFO - 2016-09-23 23:21:17 --> Model Class Initialized
INFO - 2016-09-23 23:21:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:21:17 --> Final output sent to browser
DEBUG - 2016-09-23 23:21:17 --> Total execution time: 0.0693
INFO - 2016-09-23 23:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:21:17 --> Controller Class Initialized
INFO - 2016-09-23 23:21:17 --> Database Driver Class Initialized
INFO - 2016-09-23 23:21:17 --> Model Class Initialized
INFO - 2016-09-23 23:21:17 --> Model Class Initialized
INFO - 2016-09-23 23:21:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:21:17 --> Final output sent to browser
DEBUG - 2016-09-23 23:21:17 --> Total execution time: 0.1091
INFO - 2016-09-23 23:21:29 --> Config Class Initialized
INFO - 2016-09-23 23:21:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:21:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:21:29 --> Utf8 Class Initialized
INFO - 2016-09-23 23:21:29 --> URI Class Initialized
INFO - 2016-09-23 23:21:29 --> Config Class Initialized
INFO - 2016-09-23 23:21:29 --> Router Class Initialized
INFO - 2016-09-23 23:21:29 --> Hooks Class Initialized
INFO - 2016-09-23 23:21:29 --> Output Class Initialized
DEBUG - 2016-09-23 23:21:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:21:29 --> Security Class Initialized
INFO - 2016-09-23 23:21:29 --> Utf8 Class Initialized
INFO - 2016-09-23 23:21:29 --> URI Class Initialized
DEBUG - 2016-09-23 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:21:29 --> Input Class Initialized
INFO - 2016-09-23 23:21:29 --> Language Class Initialized
INFO - 2016-09-23 23:21:29 --> Router Class Initialized
INFO - 2016-09-23 23:21:29 --> Output Class Initialized
INFO - 2016-09-23 23:21:29 --> Security Class Initialized
INFO - 2016-09-23 23:21:29 --> Loader Class Initialized
DEBUG - 2016-09-23 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:21:29 --> Helper loaded: url_helper
INFO - 2016-09-23 23:21:29 --> Input Class Initialized
INFO - 2016-09-23 23:21:29 --> Helper loaded: language_helper
INFO - 2016-09-23 23:21:29 --> Language Class Initialized
INFO - 2016-09-23 23:21:29 --> Loader Class Initialized
INFO - 2016-09-23 23:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:21:29 --> Controller Class Initialized
INFO - 2016-09-23 23:21:29 --> Helper loaded: url_helper
INFO - 2016-09-23 23:21:29 --> Helper loaded: language_helper
INFO - 2016-09-23 23:21:29 --> Database Driver Class Initialized
INFO - 2016-09-23 23:21:29 --> Model Class Initialized
INFO - 2016-09-23 23:21:29 --> Model Class Initialized
INFO - 2016-09-23 23:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:21:29 --> Final output sent to browser
DEBUG - 2016-09-23 23:21:29 --> Total execution time: 0.0985
INFO - 2016-09-23 23:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:21:29 --> Controller Class Initialized
INFO - 2016-09-23 23:21:29 --> Database Driver Class Initialized
INFO - 2016-09-23 23:21:29 --> Model Class Initialized
INFO - 2016-09-23 23:21:29 --> Model Class Initialized
INFO - 2016-09-23 23:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:21:29 --> Final output sent to browser
DEBUG - 2016-09-23 23:21:29 --> Total execution time: 0.1124
INFO - 2016-09-23 23:21:48 --> Config Class Initialized
INFO - 2016-09-23 23:21:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:21:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:21:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:21:48 --> URI Class Initialized
INFO - 2016-09-23 23:21:48 --> Router Class Initialized
INFO - 2016-09-23 23:21:48 --> Output Class Initialized
INFO - 2016-09-23 23:21:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:21:48 --> Input Class Initialized
INFO - 2016-09-23 23:21:48 --> Language Class Initialized
ERROR - 2016-09-23 23:21:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:22:18 --> Config Class Initialized
INFO - 2016-09-23 23:22:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:22:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:22:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:22:18 --> URI Class Initialized
INFO - 2016-09-23 23:22:18 --> Router Class Initialized
INFO - 2016-09-23 23:22:18 --> Output Class Initialized
INFO - 2016-09-23 23:22:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:22:18 --> Input Class Initialized
INFO - 2016-09-23 23:22:18 --> Language Class Initialized
ERROR - 2016-09-23 23:22:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:22:48 --> Config Class Initialized
INFO - 2016-09-23 23:22:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:22:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:22:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:22:48 --> URI Class Initialized
INFO - 2016-09-23 23:22:48 --> Router Class Initialized
INFO - 2016-09-23 23:22:48 --> Output Class Initialized
INFO - 2016-09-23 23:22:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:22:48 --> Input Class Initialized
INFO - 2016-09-23 23:22:48 --> Language Class Initialized
ERROR - 2016-09-23 23:22:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:23:18 --> Config Class Initialized
INFO - 2016-09-23 23:23:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:23:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:23:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:23:18 --> URI Class Initialized
INFO - 2016-09-23 23:23:18 --> Router Class Initialized
INFO - 2016-09-23 23:23:18 --> Output Class Initialized
INFO - 2016-09-23 23:23:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:23:18 --> Input Class Initialized
INFO - 2016-09-23 23:23:18 --> Language Class Initialized
ERROR - 2016-09-23 23:23:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:23:48 --> Config Class Initialized
INFO - 2016-09-23 23:23:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:23:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:23:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:23:48 --> URI Class Initialized
INFO - 2016-09-23 23:23:48 --> Router Class Initialized
INFO - 2016-09-23 23:23:48 --> Output Class Initialized
INFO - 2016-09-23 23:23:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:23:48 --> Input Class Initialized
INFO - 2016-09-23 23:23:48 --> Language Class Initialized
ERROR - 2016-09-23 23:23:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:24:17 --> Config Class Initialized
INFO - 2016-09-23 23:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:24:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:24:17 --> URI Class Initialized
INFO - 2016-09-23 23:24:17 --> Router Class Initialized
INFO - 2016-09-23 23:24:17 --> Output Class Initialized
INFO - 2016-09-23 23:24:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:24:17 --> Input Class Initialized
INFO - 2016-09-23 23:24:17 --> Language Class Initialized
ERROR - 2016-09-23 23:24:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:24:29 --> Config Class Initialized
INFO - 2016-09-23 23:24:29 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:24:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:24:29 --> Utf8 Class Initialized
INFO - 2016-09-23 23:24:29 --> Config Class Initialized
INFO - 2016-09-23 23:24:29 --> Hooks Class Initialized
INFO - 2016-09-23 23:24:29 --> URI Class Initialized
INFO - 2016-09-23 23:24:29 --> Router Class Initialized
DEBUG - 2016-09-23 23:24:29 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:24:29 --> Utf8 Class Initialized
INFO - 2016-09-23 23:24:29 --> Output Class Initialized
INFO - 2016-09-23 23:24:29 --> URI Class Initialized
INFO - 2016-09-23 23:24:29 --> Security Class Initialized
INFO - 2016-09-23 23:24:29 --> Router Class Initialized
DEBUG - 2016-09-23 23:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:24:29 --> Input Class Initialized
INFO - 2016-09-23 23:24:29 --> Output Class Initialized
INFO - 2016-09-23 23:24:29 --> Language Class Initialized
INFO - 2016-09-23 23:24:29 --> Security Class Initialized
DEBUG - 2016-09-23 23:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:24:29 --> Input Class Initialized
INFO - 2016-09-23 23:24:29 --> Loader Class Initialized
INFO - 2016-09-23 23:24:29 --> Language Class Initialized
INFO - 2016-09-23 23:24:29 --> Helper loaded: url_helper
INFO - 2016-09-23 23:24:29 --> Helper loaded: language_helper
INFO - 2016-09-23 23:24:29 --> Loader Class Initialized
INFO - 2016-09-23 23:24:29 --> Helper loaded: url_helper
INFO - 2016-09-23 23:24:29 --> Helper loaded: language_helper
INFO - 2016-09-23 23:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:24:29 --> Controller Class Initialized
INFO - 2016-09-23 23:24:29 --> Database Driver Class Initialized
INFO - 2016-09-23 23:24:29 --> Model Class Initialized
INFO - 2016-09-23 23:24:29 --> Model Class Initialized
INFO - 2016-09-23 23:24:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:24:29 --> Final output sent to browser
DEBUG - 2016-09-23 23:24:29 --> Total execution time: 0.1036
INFO - 2016-09-23 23:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:24:29 --> Controller Class Initialized
INFO - 2016-09-23 23:24:29 --> Database Driver Class Initialized
INFO - 2016-09-23 23:24:29 --> Model Class Initialized
INFO - 2016-09-23 23:24:29 --> Model Class Initialized
INFO - 2016-09-23 23:24:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:24:29 --> Final output sent to browser
DEBUG - 2016-09-23 23:24:29 --> Total execution time: 0.1248
INFO - 2016-09-23 23:24:47 --> Config Class Initialized
INFO - 2016-09-23 23:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:24:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:24:47 --> URI Class Initialized
INFO - 2016-09-23 23:24:47 --> Router Class Initialized
INFO - 2016-09-23 23:24:47 --> Output Class Initialized
INFO - 2016-09-23 23:24:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:24:47 --> Input Class Initialized
INFO - 2016-09-23 23:24:47 --> Language Class Initialized
ERROR - 2016-09-23 23:24:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:25:17 --> Config Class Initialized
INFO - 2016-09-23 23:25:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:25:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:25:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:25:17 --> URI Class Initialized
INFO - 2016-09-23 23:25:17 --> Router Class Initialized
INFO - 2016-09-23 23:25:17 --> Output Class Initialized
INFO - 2016-09-23 23:25:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:25:17 --> Input Class Initialized
INFO - 2016-09-23 23:25:17 --> Language Class Initialized
ERROR - 2016-09-23 23:25:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:25:37 --> Config Class Initialized
INFO - 2016-09-23 23:25:37 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:25:37 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:25:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:25:37 --> URI Class Initialized
INFO - 2016-09-23 23:25:37 --> Router Class Initialized
INFO - 2016-09-23 23:25:37 --> Output Class Initialized
INFO - 2016-09-23 23:25:37 --> Config Class Initialized
INFO - 2016-09-23 23:25:37 --> Hooks Class Initialized
INFO - 2016-09-23 23:25:37 --> Security Class Initialized
DEBUG - 2016-09-23 23:25:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 23:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:25:37 --> Utf8 Class Initialized
INFO - 2016-09-23 23:25:37 --> Input Class Initialized
INFO - 2016-09-23 23:25:37 --> Language Class Initialized
INFO - 2016-09-23 23:25:37 --> URI Class Initialized
INFO - 2016-09-23 23:25:37 --> Router Class Initialized
INFO - 2016-09-23 23:25:37 --> Loader Class Initialized
INFO - 2016-09-23 23:25:37 --> Output Class Initialized
INFO - 2016-09-23 23:25:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:25:37 --> Security Class Initialized
INFO - 2016-09-23 23:25:37 --> Helper loaded: language_helper
DEBUG - 2016-09-23 23:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:25:37 --> Input Class Initialized
INFO - 2016-09-23 23:25:37 --> Language Class Initialized
INFO - 2016-09-23 23:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:25:37 --> Controller Class Initialized
INFO - 2016-09-23 23:25:37 --> Loader Class Initialized
INFO - 2016-09-23 23:25:37 --> Helper loaded: url_helper
INFO - 2016-09-23 23:25:37 --> Helper loaded: language_helper
INFO - 2016-09-23 23:25:37 --> Database Driver Class Initialized
INFO - 2016-09-23 23:25:37 --> Model Class Initialized
INFO - 2016-09-23 23:25:37 --> Model Class Initialized
INFO - 2016-09-23 23:25:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:25:38 --> Final output sent to browser
DEBUG - 2016-09-23 23:25:38 --> Total execution time: 0.1243
INFO - 2016-09-23 23:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:25:38 --> Controller Class Initialized
INFO - 2016-09-23 23:25:38 --> Database Driver Class Initialized
INFO - 2016-09-23 23:25:38 --> Model Class Initialized
INFO - 2016-09-23 23:25:38 --> Model Class Initialized
INFO - 2016-09-23 23:25:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:25:38 --> Final output sent to browser
DEBUG - 2016-09-23 23:25:38 --> Total execution time: 0.1357
INFO - 2016-09-23 23:25:47 --> Config Class Initialized
INFO - 2016-09-23 23:25:47 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:25:47 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:25:47 --> Utf8 Class Initialized
INFO - 2016-09-23 23:25:47 --> URI Class Initialized
INFO - 2016-09-23 23:25:47 --> Router Class Initialized
INFO - 2016-09-23 23:25:47 --> Output Class Initialized
INFO - 2016-09-23 23:25:47 --> Security Class Initialized
DEBUG - 2016-09-23 23:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:25:47 --> Input Class Initialized
INFO - 2016-09-23 23:25:47 --> Language Class Initialized
ERROR - 2016-09-23 23:25:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:26:17 --> Config Class Initialized
INFO - 2016-09-23 23:26:17 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:26:17 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:26:17 --> Utf8 Class Initialized
INFO - 2016-09-23 23:26:17 --> URI Class Initialized
INFO - 2016-09-23 23:26:17 --> Router Class Initialized
INFO - 2016-09-23 23:26:17 --> Output Class Initialized
INFO - 2016-09-23 23:26:17 --> Security Class Initialized
DEBUG - 2016-09-23 23:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:26:17 --> Input Class Initialized
INFO - 2016-09-23 23:26:17 --> Language Class Initialized
ERROR - 2016-09-23 23:26:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:26:48 --> Config Class Initialized
INFO - 2016-09-23 23:26:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:26:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:26:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:26:48 --> URI Class Initialized
INFO - 2016-09-23 23:26:48 --> Router Class Initialized
INFO - 2016-09-23 23:26:48 --> Output Class Initialized
INFO - 2016-09-23 23:26:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:26:48 --> Input Class Initialized
INFO - 2016-09-23 23:26:48 --> Language Class Initialized
ERROR - 2016-09-23 23:26:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:27:18 --> Config Class Initialized
INFO - 2016-09-23 23:27:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:27:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:27:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:27:18 --> URI Class Initialized
INFO - 2016-09-23 23:27:18 --> Router Class Initialized
INFO - 2016-09-23 23:27:18 --> Output Class Initialized
INFO - 2016-09-23 23:27:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:27:18 --> Input Class Initialized
INFO - 2016-09-23 23:27:18 --> Language Class Initialized
ERROR - 2016-09-23 23:27:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:27:48 --> Config Class Initialized
INFO - 2016-09-23 23:27:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:27:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:27:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:27:48 --> URI Class Initialized
INFO - 2016-09-23 23:27:48 --> Router Class Initialized
INFO - 2016-09-23 23:27:48 --> Output Class Initialized
INFO - 2016-09-23 23:27:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:27:48 --> Input Class Initialized
INFO - 2016-09-23 23:27:48 --> Language Class Initialized
ERROR - 2016-09-23 23:27:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:28:18 --> Config Class Initialized
INFO - 2016-09-23 23:28:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:28:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:28:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:28:18 --> URI Class Initialized
INFO - 2016-09-23 23:28:18 --> Router Class Initialized
INFO - 2016-09-23 23:28:18 --> Output Class Initialized
INFO - 2016-09-23 23:28:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:28:18 --> Input Class Initialized
INFO - 2016-09-23 23:28:18 --> Language Class Initialized
ERROR - 2016-09-23 23:28:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:28:48 --> Config Class Initialized
INFO - 2016-09-23 23:28:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:28:48 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:28:48 --> Utf8 Class Initialized
INFO - 2016-09-23 23:28:48 --> URI Class Initialized
INFO - 2016-09-23 23:28:48 --> Router Class Initialized
INFO - 2016-09-23 23:28:48 --> Output Class Initialized
INFO - 2016-09-23 23:28:48 --> Security Class Initialized
DEBUG - 2016-09-23 23:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:28:48 --> Input Class Initialized
INFO - 2016-09-23 23:28:48 --> Language Class Initialized
ERROR - 2016-09-23 23:28:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:29:18 --> Config Class Initialized
INFO - 2016-09-23 23:29:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:18 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:18 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:18 --> URI Class Initialized
INFO - 2016-09-23 23:29:18 --> Router Class Initialized
INFO - 2016-09-23 23:29:18 --> Output Class Initialized
INFO - 2016-09-23 23:29:18 --> Security Class Initialized
DEBUG - 2016-09-23 23:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:18 --> Input Class Initialized
INFO - 2016-09-23 23:29:18 --> Language Class Initialized
ERROR - 2016-09-23 23:29:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:29:38 --> Config Class Initialized
INFO - 2016-09-23 23:29:38 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:38 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:38 --> URI Class Initialized
INFO - 2016-09-23 23:29:38 --> Router Class Initialized
INFO - 2016-09-23 23:29:38 --> Output Class Initialized
INFO - 2016-09-23 23:29:38 --> Security Class Initialized
DEBUG - 2016-09-23 23:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:38 --> Input Class Initialized
INFO - 2016-09-23 23:29:38 --> Language Class Initialized
INFO - 2016-09-23 23:29:38 --> Loader Class Initialized
INFO - 2016-09-23 23:29:38 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:38 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:38 --> Controller Class Initialized
INFO - 2016-09-23 23:29:38 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:38 --> Model Class Initialized
INFO - 2016-09-23 23:29:38 --> Model Class Initialized
INFO - 2016-09-23 23:29:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-23 23:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-23 23:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-23 23:29:38 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:38 --> Total execution time: 0.0890
INFO - 2016-09-23 23:29:38 --> Config Class Initialized
INFO - 2016-09-23 23:29:38 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:38 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:38 --> URI Class Initialized
INFO - 2016-09-23 23:29:38 --> Config Class Initialized
INFO - 2016-09-23 23:29:38 --> Hooks Class Initialized
INFO - 2016-09-23 23:29:38 --> Router Class Initialized
DEBUG - 2016-09-23 23:29:38 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:38 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:38 --> Output Class Initialized
INFO - 2016-09-23 23:29:38 --> URI Class Initialized
INFO - 2016-09-23 23:29:38 --> Security Class Initialized
INFO - 2016-09-23 23:29:38 --> Router Class Initialized
DEBUG - 2016-09-23 23:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:38 --> Input Class Initialized
INFO - 2016-09-23 23:29:38 --> Language Class Initialized
INFO - 2016-09-23 23:29:38 --> Output Class Initialized
INFO - 2016-09-23 23:29:38 --> Security Class Initialized
INFO - 2016-09-23 23:29:38 --> Loader Class Initialized
DEBUG - 2016-09-23 23:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:38 --> Input Class Initialized
INFO - 2016-09-23 23:29:38 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:38 --> Language Class Initialized
INFO - 2016-09-23 23:29:38 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:38 --> Loader Class Initialized
INFO - 2016-09-23 23:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:38 --> Controller Class Initialized
INFO - 2016-09-23 23:29:38 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:38 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:38 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:38 --> Model Class Initialized
INFO - 2016-09-23 23:29:38 --> Model Class Initialized
INFO - 2016-09-23 23:29:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:38 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:38 --> Total execution time: 0.0821
INFO - 2016-09-23 23:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:38 --> Controller Class Initialized
INFO - 2016-09-23 23:29:38 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:38 --> Model Class Initialized
INFO - 2016-09-23 23:29:38 --> Model Class Initialized
INFO - 2016-09-23 23:29:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:38 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:38 --> Total execution time: 0.1457
INFO - 2016-09-23 23:29:42 --> Config Class Initialized
INFO - 2016-09-23 23:29:42 --> Hooks Class Initialized
INFO - 2016-09-23 23:29:42 --> Config Class Initialized
INFO - 2016-09-23 23:29:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:42 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:29:42 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:42 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:42 --> URI Class Initialized
INFO - 2016-09-23 23:29:42 --> URI Class Initialized
INFO - 2016-09-23 23:29:42 --> Router Class Initialized
INFO - 2016-09-23 23:29:42 --> Router Class Initialized
INFO - 2016-09-23 23:29:42 --> Output Class Initialized
INFO - 2016-09-23 23:29:42 --> Output Class Initialized
INFO - 2016-09-23 23:29:42 --> Security Class Initialized
INFO - 2016-09-23 23:29:42 --> Security Class Initialized
DEBUG - 2016-09-23 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:42 --> Input Class Initialized
INFO - 2016-09-23 23:29:42 --> Language Class Initialized
DEBUG - 2016-09-23 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:42 --> Input Class Initialized
INFO - 2016-09-23 23:29:42 --> Language Class Initialized
INFO - 2016-09-23 23:29:42 --> Loader Class Initialized
INFO - 2016-09-23 23:29:42 --> Loader Class Initialized
INFO - 2016-09-23 23:29:42 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:42 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:42 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:42 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:42 --> Controller Class Initialized
INFO - 2016-09-23 23:29:42 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:42 --> Model Class Initialized
INFO - 2016-09-23 23:29:42 --> Model Class Initialized
INFO - 2016-09-23 23:29:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:42 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:42 --> Total execution time: 0.1029
INFO - 2016-09-23 23:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:42 --> Controller Class Initialized
INFO - 2016-09-23 23:29:42 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:42 --> Model Class Initialized
INFO - 2016-09-23 23:29:42 --> Model Class Initialized
INFO - 2016-09-23 23:29:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:42 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:42 --> Total execution time: 0.1301
INFO - 2016-09-23 23:29:43 --> Config Class Initialized
INFO - 2016-09-23 23:29:43 --> Hooks Class Initialized
INFO - 2016-09-23 23:29:43 --> Config Class Initialized
INFO - 2016-09-23 23:29:43 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:43 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:43 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:29:43 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:43 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:43 --> URI Class Initialized
INFO - 2016-09-23 23:29:43 --> URI Class Initialized
INFO - 2016-09-23 23:29:43 --> Router Class Initialized
INFO - 2016-09-23 23:29:43 --> Router Class Initialized
INFO - 2016-09-23 23:29:43 --> Output Class Initialized
INFO - 2016-09-23 23:29:43 --> Output Class Initialized
INFO - 2016-09-23 23:29:43 --> Security Class Initialized
INFO - 2016-09-23 23:29:43 --> Security Class Initialized
DEBUG - 2016-09-23 23:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:43 --> Input Class Initialized
INFO - 2016-09-23 23:29:43 --> Language Class Initialized
DEBUG - 2016-09-23 23:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:43 --> Input Class Initialized
INFO - 2016-09-23 23:29:43 --> Language Class Initialized
INFO - 2016-09-23 23:29:43 --> Loader Class Initialized
INFO - 2016-09-23 23:29:43 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:43 --> Loader Class Initialized
INFO - 2016-09-23 23:29:43 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:43 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:43 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:43 --> Controller Class Initialized
INFO - 2016-09-23 23:29:43 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:43 --> Model Class Initialized
INFO - 2016-09-23 23:29:43 --> Model Class Initialized
INFO - 2016-09-23 23:29:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:43 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:43 --> Total execution time: 0.0672
INFO - 2016-09-23 23:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:43 --> Controller Class Initialized
INFO - 2016-09-23 23:29:43 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:43 --> Model Class Initialized
INFO - 2016-09-23 23:29:43 --> Model Class Initialized
INFO - 2016-09-23 23:29:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:43 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:43 --> Total execution time: 0.1170
INFO - 2016-09-23 23:29:44 --> Config Class Initialized
INFO - 2016-09-23 23:29:44 --> Hooks Class Initialized
INFO - 2016-09-23 23:29:44 --> Config Class Initialized
INFO - 2016-09-23 23:29:44 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:44 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:29:44 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:44 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:44 --> URI Class Initialized
INFO - 2016-09-23 23:29:44 --> URI Class Initialized
INFO - 2016-09-23 23:29:44 --> Router Class Initialized
INFO - 2016-09-23 23:29:44 --> Router Class Initialized
INFO - 2016-09-23 23:29:44 --> Output Class Initialized
INFO - 2016-09-23 23:29:44 --> Output Class Initialized
INFO - 2016-09-23 23:29:44 --> Security Class Initialized
INFO - 2016-09-23 23:29:44 --> Security Class Initialized
DEBUG - 2016-09-23 23:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:44 --> Input Class Initialized
INFO - 2016-09-23 23:29:44 --> Language Class Initialized
DEBUG - 2016-09-23 23:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:44 --> Input Class Initialized
INFO - 2016-09-23 23:29:44 --> Language Class Initialized
INFO - 2016-09-23 23:29:44 --> Loader Class Initialized
INFO - 2016-09-23 23:29:44 --> Loader Class Initialized
INFO - 2016-09-23 23:29:44 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:44 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:44 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:44 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:44 --> Controller Class Initialized
INFO - 2016-09-23 23:29:44 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:44 --> Model Class Initialized
INFO - 2016-09-23 23:29:44 --> Model Class Initialized
INFO - 2016-09-23 23:29:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:44 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:44 --> Total execution time: 0.0735
INFO - 2016-09-23 23:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:44 --> Controller Class Initialized
INFO - 2016-09-23 23:29:44 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:44 --> Model Class Initialized
INFO - 2016-09-23 23:29:44 --> Model Class Initialized
INFO - 2016-09-23 23:29:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:44 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:44 --> Total execution time: 0.1344
INFO - 2016-09-23 23:29:45 --> Config Class Initialized
INFO - 2016-09-23 23:29:45 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:45 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:45 --> URI Class Initialized
INFO - 2016-09-23 23:29:45 --> Config Class Initialized
INFO - 2016-09-23 23:29:45 --> Hooks Class Initialized
INFO - 2016-09-23 23:29:45 --> Router Class Initialized
INFO - 2016-09-23 23:29:45 --> Output Class Initialized
DEBUG - 2016-09-23 23:29:45 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:45 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:45 --> Security Class Initialized
INFO - 2016-09-23 23:29:45 --> URI Class Initialized
INFO - 2016-09-23 23:29:45 --> Router Class Initialized
DEBUG - 2016-09-23 23:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:45 --> Input Class Initialized
INFO - 2016-09-23 23:29:45 --> Language Class Initialized
INFO - 2016-09-23 23:29:45 --> Output Class Initialized
INFO - 2016-09-23 23:29:45 --> Loader Class Initialized
INFO - 2016-09-23 23:29:45 --> Security Class Initialized
DEBUG - 2016-09-23 23:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:45 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:45 --> Input Class Initialized
INFO - 2016-09-23 23:29:45 --> Language Class Initialized
INFO - 2016-09-23 23:29:45 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:45 --> Loader Class Initialized
INFO - 2016-09-23 23:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:45 --> Controller Class Initialized
INFO - 2016-09-23 23:29:45 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:45 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:45 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:45 --> Model Class Initialized
INFO - 2016-09-23 23:29:45 --> Model Class Initialized
INFO - 2016-09-23 23:29:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:45 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:45 --> Total execution time: 0.1046
INFO - 2016-09-23 23:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:45 --> Controller Class Initialized
INFO - 2016-09-23 23:29:45 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:45 --> Model Class Initialized
INFO - 2016-09-23 23:29:45 --> Model Class Initialized
INFO - 2016-09-23 23:29:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:45 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:45 --> Total execution time: 0.1384
INFO - 2016-09-23 23:29:46 --> Config Class Initialized
INFO - 2016-09-23 23:29:46 --> Hooks Class Initialized
INFO - 2016-09-23 23:29:46 --> Config Class Initialized
INFO - 2016-09-23 23:29:46 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:29:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:46 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:46 --> URI Class Initialized
DEBUG - 2016-09-23 23:29:46 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:29:46 --> Utf8 Class Initialized
INFO - 2016-09-23 23:29:46 --> Router Class Initialized
INFO - 2016-09-23 23:29:46 --> URI Class Initialized
INFO - 2016-09-23 23:29:46 --> Output Class Initialized
INFO - 2016-09-23 23:29:46 --> Router Class Initialized
INFO - 2016-09-23 23:29:46 --> Security Class Initialized
INFO - 2016-09-23 23:29:46 --> Output Class Initialized
DEBUG - 2016-09-23 23:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:46 --> Input Class Initialized
INFO - 2016-09-23 23:29:46 --> Security Class Initialized
INFO - 2016-09-23 23:29:46 --> Language Class Initialized
DEBUG - 2016-09-23 23:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:29:46 --> Input Class Initialized
INFO - 2016-09-23 23:29:46 --> Loader Class Initialized
INFO - 2016-09-23 23:29:46 --> Language Class Initialized
INFO - 2016-09-23 23:29:46 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:46 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:46 --> Loader Class Initialized
INFO - 2016-09-23 23:29:46 --> Helper loaded: url_helper
INFO - 2016-09-23 23:29:46 --> Helper loaded: language_helper
INFO - 2016-09-23 23:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:46 --> Controller Class Initialized
INFO - 2016-09-23 23:29:46 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:46 --> Model Class Initialized
INFO - 2016-09-23 23:29:46 --> Model Class Initialized
INFO - 2016-09-23 23:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:46 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:46 --> Total execution time: 0.0675
INFO - 2016-09-23 23:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:29:46 --> Controller Class Initialized
INFO - 2016-09-23 23:29:46 --> Database Driver Class Initialized
INFO - 2016-09-23 23:29:46 --> Model Class Initialized
INFO - 2016-09-23 23:29:46 --> Model Class Initialized
INFO - 2016-09-23 23:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:29:46 --> Final output sent to browser
DEBUG - 2016-09-23 23:29:46 --> Total execution time: 0.1114
INFO - 2016-09-23 23:30:05 --> Config Class Initialized
INFO - 2016-09-23 23:30:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:30:05 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:30:05 --> Utf8 Class Initialized
INFO - 2016-09-23 23:30:05 --> URI Class Initialized
INFO - 2016-09-23 23:30:05 --> Router Class Initialized
INFO - 2016-09-23 23:30:05 --> Config Class Initialized
INFO - 2016-09-23 23:30:05 --> Output Class Initialized
INFO - 2016-09-23 23:30:05 --> Hooks Class Initialized
INFO - 2016-09-23 23:30:06 --> Security Class Initialized
DEBUG - 2016-09-23 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:30:06 --> Input Class Initialized
DEBUG - 2016-09-23 23:30:06 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:30:06 --> Utf8 Class Initialized
INFO - 2016-09-23 23:30:06 --> Language Class Initialized
INFO - 2016-09-23 23:30:06 --> URI Class Initialized
INFO - 2016-09-23 23:30:06 --> Router Class Initialized
INFO - 2016-09-23 23:30:06 --> Loader Class Initialized
INFO - 2016-09-23 23:30:06 --> Output Class Initialized
INFO - 2016-09-23 23:30:06 --> Helper loaded: url_helper
INFO - 2016-09-23 23:30:06 --> Helper loaded: language_helper
INFO - 2016-09-23 23:30:06 --> Security Class Initialized
DEBUG - 2016-09-23 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:30:06 --> Input Class Initialized
INFO - 2016-09-23 23:30:06 --> Language Class Initialized
INFO - 2016-09-23 23:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:30:06 --> Controller Class Initialized
INFO - 2016-09-23 23:30:06 --> Loader Class Initialized
INFO - 2016-09-23 23:30:06 --> Helper loaded: url_helper
INFO - 2016-09-23 23:30:06 --> Helper loaded: language_helper
INFO - 2016-09-23 23:30:06 --> Database Driver Class Initialized
INFO - 2016-09-23 23:30:06 --> Model Class Initialized
INFO - 2016-09-23 23:30:06 --> Model Class Initialized
INFO - 2016-09-23 23:30:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:30:06 --> Final output sent to browser
DEBUG - 2016-09-23 23:30:06 --> Total execution time: 0.0730
INFO - 2016-09-23 23:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:30:06 --> Controller Class Initialized
INFO - 2016-09-23 23:30:06 --> Database Driver Class Initialized
INFO - 2016-09-23 23:30:06 --> Model Class Initialized
INFO - 2016-09-23 23:30:06 --> Model Class Initialized
INFO - 2016-09-23 23:30:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:30:06 --> Final output sent to browser
DEBUG - 2016-09-23 23:30:06 --> Total execution time: 0.1211
INFO - 2016-09-23 23:30:08 --> Config Class Initialized
INFO - 2016-09-23 23:30:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:30:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:30:08 --> Utf8 Class Initialized
INFO - 2016-09-23 23:30:08 --> URI Class Initialized
INFO - 2016-09-23 23:30:08 --> Router Class Initialized
INFO - 2016-09-23 23:30:08 --> Output Class Initialized
INFO - 2016-09-23 23:30:08 --> Security Class Initialized
DEBUG - 2016-09-23 23:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:30:08 --> Input Class Initialized
INFO - 2016-09-23 23:30:08 --> Language Class Initialized
ERROR - 2016-09-23 23:30:08 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:30:11 --> Config Class Initialized
INFO - 2016-09-23 23:30:11 --> Config Class Initialized
INFO - 2016-09-23 23:30:11 --> Hooks Class Initialized
INFO - 2016-09-23 23:30:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:30:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 23:30:11 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:30:11 --> Utf8 Class Initialized
INFO - 2016-09-23 23:30:11 --> Utf8 Class Initialized
INFO - 2016-09-23 23:30:11 --> URI Class Initialized
INFO - 2016-09-23 23:30:11 --> URI Class Initialized
INFO - 2016-09-23 23:30:11 --> Router Class Initialized
INFO - 2016-09-23 23:30:11 --> Router Class Initialized
INFO - 2016-09-23 23:30:11 --> Output Class Initialized
INFO - 2016-09-23 23:30:11 --> Output Class Initialized
INFO - 2016-09-23 23:30:11 --> Security Class Initialized
INFO - 2016-09-23 23:30:11 --> Security Class Initialized
DEBUG - 2016-09-23 23:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:30:11 --> Input Class Initialized
DEBUG - 2016-09-23 23:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:30:11 --> Input Class Initialized
INFO - 2016-09-23 23:30:11 --> Language Class Initialized
INFO - 2016-09-23 23:30:11 --> Language Class Initialized
INFO - 2016-09-23 23:30:11 --> Loader Class Initialized
INFO - 2016-09-23 23:30:11 --> Loader Class Initialized
INFO - 2016-09-23 23:30:11 --> Helper loaded: url_helper
INFO - 2016-09-23 23:30:11 --> Helper loaded: language_helper
INFO - 2016-09-23 23:30:11 --> Helper loaded: url_helper
INFO - 2016-09-23 23:30:11 --> Helper loaded: language_helper
INFO - 2016-09-23 23:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:30:11 --> Controller Class Initialized
INFO - 2016-09-23 23:30:11 --> Database Driver Class Initialized
INFO - 2016-09-23 23:30:11 --> Model Class Initialized
INFO - 2016-09-23 23:30:11 --> Model Class Initialized
INFO - 2016-09-23 23:30:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:30:11 --> Final output sent to browser
DEBUG - 2016-09-23 23:30:11 --> Total execution time: 0.0675
INFO - 2016-09-23 23:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:30:11 --> Controller Class Initialized
INFO - 2016-09-23 23:30:11 --> Database Driver Class Initialized
INFO - 2016-09-23 23:30:11 --> Model Class Initialized
INFO - 2016-09-23 23:30:11 --> Model Class Initialized
INFO - 2016-09-23 23:30:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:30:12 --> Final output sent to browser
DEBUG - 2016-09-23 23:30:12 --> Total execution time: 0.1248
INFO - 2016-09-23 23:30:39 --> Config Class Initialized
INFO - 2016-09-23 23:30:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:30:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:30:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:30:39 --> URI Class Initialized
INFO - 2016-09-23 23:30:39 --> Router Class Initialized
INFO - 2016-09-23 23:30:39 --> Output Class Initialized
INFO - 2016-09-23 23:30:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:30:39 --> Input Class Initialized
INFO - 2016-09-23 23:30:39 --> Language Class Initialized
ERROR - 2016-09-23 23:30:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:31:09 --> Config Class Initialized
INFO - 2016-09-23 23:31:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:31:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:31:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:31:09 --> URI Class Initialized
INFO - 2016-09-23 23:31:09 --> Router Class Initialized
INFO - 2016-09-23 23:31:09 --> Output Class Initialized
INFO - 2016-09-23 23:31:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:31:09 --> Input Class Initialized
INFO - 2016-09-23 23:31:09 --> Language Class Initialized
ERROR - 2016-09-23 23:31:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:31:39 --> Config Class Initialized
INFO - 2016-09-23 23:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:31:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:31:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:31:39 --> URI Class Initialized
INFO - 2016-09-23 23:31:39 --> Router Class Initialized
INFO - 2016-09-23 23:31:39 --> Output Class Initialized
INFO - 2016-09-23 23:31:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:31:39 --> Input Class Initialized
INFO - 2016-09-23 23:31:39 --> Language Class Initialized
ERROR - 2016-09-23 23:31:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:32:09 --> Config Class Initialized
INFO - 2016-09-23 23:32:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:32:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:32:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:32:09 --> URI Class Initialized
INFO - 2016-09-23 23:32:09 --> Router Class Initialized
INFO - 2016-09-23 23:32:09 --> Output Class Initialized
INFO - 2016-09-23 23:32:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:32:09 --> Input Class Initialized
INFO - 2016-09-23 23:32:09 --> Language Class Initialized
ERROR - 2016-09-23 23:32:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:32:39 --> Config Class Initialized
INFO - 2016-09-23 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:32:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:32:39 --> URI Class Initialized
INFO - 2016-09-23 23:32:39 --> Router Class Initialized
INFO - 2016-09-23 23:32:39 --> Output Class Initialized
INFO - 2016-09-23 23:32:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:32:39 --> Input Class Initialized
INFO - 2016-09-23 23:32:39 --> Language Class Initialized
ERROR - 2016-09-23 23:32:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:33:09 --> Config Class Initialized
INFO - 2016-09-23 23:33:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:33:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:33:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:33:09 --> URI Class Initialized
INFO - 2016-09-23 23:33:09 --> Router Class Initialized
INFO - 2016-09-23 23:33:09 --> Output Class Initialized
INFO - 2016-09-23 23:33:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:33:09 --> Input Class Initialized
INFO - 2016-09-23 23:33:09 --> Language Class Initialized
ERROR - 2016-09-23 23:33:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:33:39 --> Config Class Initialized
INFO - 2016-09-23 23:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:33:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:33:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:33:39 --> URI Class Initialized
INFO - 2016-09-23 23:33:39 --> Router Class Initialized
INFO - 2016-09-23 23:33:39 --> Output Class Initialized
INFO - 2016-09-23 23:33:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:33:39 --> Input Class Initialized
INFO - 2016-09-23 23:33:39 --> Language Class Initialized
ERROR - 2016-09-23 23:33:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:34:09 --> Config Class Initialized
INFO - 2016-09-23 23:34:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:34:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:34:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:34:09 --> URI Class Initialized
INFO - 2016-09-23 23:34:09 --> Router Class Initialized
INFO - 2016-09-23 23:34:09 --> Output Class Initialized
INFO - 2016-09-23 23:34:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:34:09 --> Input Class Initialized
INFO - 2016-09-23 23:34:09 --> Language Class Initialized
ERROR - 2016-09-23 23:34:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:34:39 --> Config Class Initialized
INFO - 2016-09-23 23:34:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:34:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:34:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:34:39 --> URI Class Initialized
INFO - 2016-09-23 23:34:39 --> Router Class Initialized
INFO - 2016-09-23 23:34:39 --> Output Class Initialized
INFO - 2016-09-23 23:34:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:34:39 --> Input Class Initialized
INFO - 2016-09-23 23:34:39 --> Language Class Initialized
ERROR - 2016-09-23 23:34:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:35:09 --> Config Class Initialized
INFO - 2016-09-23 23:35:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:35:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:35:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:35:09 --> URI Class Initialized
INFO - 2016-09-23 23:35:09 --> Router Class Initialized
INFO - 2016-09-23 23:35:09 --> Output Class Initialized
INFO - 2016-09-23 23:35:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:35:09 --> Input Class Initialized
INFO - 2016-09-23 23:35:09 --> Language Class Initialized
ERROR - 2016-09-23 23:35:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:35:39 --> Config Class Initialized
INFO - 2016-09-23 23:35:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:35:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:35:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:35:39 --> URI Class Initialized
INFO - 2016-09-23 23:35:39 --> Router Class Initialized
INFO - 2016-09-23 23:35:39 --> Output Class Initialized
INFO - 2016-09-23 23:35:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:35:39 --> Input Class Initialized
INFO - 2016-09-23 23:35:39 --> Language Class Initialized
ERROR - 2016-09-23 23:35:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:36:09 --> Config Class Initialized
INFO - 2016-09-23 23:36:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:36:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:36:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:36:09 --> URI Class Initialized
INFO - 2016-09-23 23:36:09 --> Router Class Initialized
INFO - 2016-09-23 23:36:09 --> Output Class Initialized
INFO - 2016-09-23 23:36:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:36:09 --> Input Class Initialized
INFO - 2016-09-23 23:36:09 --> Language Class Initialized
ERROR - 2016-09-23 23:36:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:36:39 --> Config Class Initialized
INFO - 2016-09-23 23:36:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:36:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:36:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:36:39 --> URI Class Initialized
INFO - 2016-09-23 23:36:39 --> Router Class Initialized
INFO - 2016-09-23 23:36:39 --> Output Class Initialized
INFO - 2016-09-23 23:36:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:36:39 --> Input Class Initialized
INFO - 2016-09-23 23:36:39 --> Language Class Initialized
ERROR - 2016-09-23 23:36:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:37:09 --> Config Class Initialized
INFO - 2016-09-23 23:37:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:37:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:37:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:37:09 --> URI Class Initialized
INFO - 2016-09-23 23:37:09 --> Router Class Initialized
INFO - 2016-09-23 23:37:09 --> Output Class Initialized
INFO - 2016-09-23 23:37:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:37:09 --> Input Class Initialized
INFO - 2016-09-23 23:37:09 --> Language Class Initialized
ERROR - 2016-09-23 23:37:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:37:39 --> Config Class Initialized
INFO - 2016-09-23 23:37:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:37:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:37:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:37:39 --> URI Class Initialized
INFO - 2016-09-23 23:37:39 --> Router Class Initialized
INFO - 2016-09-23 23:37:39 --> Output Class Initialized
INFO - 2016-09-23 23:37:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:37:39 --> Input Class Initialized
INFO - 2016-09-23 23:37:39 --> Language Class Initialized
ERROR - 2016-09-23 23:37:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:38:09 --> Config Class Initialized
INFO - 2016-09-23 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:38:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:38:09 --> URI Class Initialized
INFO - 2016-09-23 23:38:09 --> Router Class Initialized
INFO - 2016-09-23 23:38:09 --> Output Class Initialized
INFO - 2016-09-23 23:38:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:38:09 --> Input Class Initialized
INFO - 2016-09-23 23:38:09 --> Language Class Initialized
ERROR - 2016-09-23 23:38:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:38:39 --> Config Class Initialized
INFO - 2016-09-23 23:38:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:38:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:38:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:38:39 --> URI Class Initialized
INFO - 2016-09-23 23:38:39 --> Router Class Initialized
INFO - 2016-09-23 23:38:39 --> Output Class Initialized
INFO - 2016-09-23 23:38:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:38:39 --> Input Class Initialized
INFO - 2016-09-23 23:38:39 --> Language Class Initialized
ERROR - 2016-09-23 23:38:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:39:09 --> Config Class Initialized
INFO - 2016-09-23 23:39:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:39:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:39:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:39:09 --> URI Class Initialized
INFO - 2016-09-23 23:39:09 --> Router Class Initialized
INFO - 2016-09-23 23:39:09 --> Output Class Initialized
INFO - 2016-09-23 23:39:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:39:09 --> Input Class Initialized
INFO - 2016-09-23 23:39:09 --> Language Class Initialized
ERROR - 2016-09-23 23:39:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:39:39 --> Config Class Initialized
INFO - 2016-09-23 23:39:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:39:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:39:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:39:39 --> URI Class Initialized
INFO - 2016-09-23 23:39:39 --> Router Class Initialized
INFO - 2016-09-23 23:39:39 --> Output Class Initialized
INFO - 2016-09-23 23:39:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:39:39 --> Input Class Initialized
INFO - 2016-09-23 23:39:39 --> Language Class Initialized
ERROR - 2016-09-23 23:39:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:40:09 --> Config Class Initialized
INFO - 2016-09-23 23:40:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:40:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:40:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:40:09 --> URI Class Initialized
INFO - 2016-09-23 23:40:09 --> Router Class Initialized
INFO - 2016-09-23 23:40:09 --> Output Class Initialized
INFO - 2016-09-23 23:40:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:40:09 --> Input Class Initialized
INFO - 2016-09-23 23:40:09 --> Language Class Initialized
ERROR - 2016-09-23 23:40:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:40:39 --> Config Class Initialized
INFO - 2016-09-23 23:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:40:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:40:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:40:39 --> URI Class Initialized
INFO - 2016-09-23 23:40:39 --> Router Class Initialized
INFO - 2016-09-23 23:40:39 --> Output Class Initialized
INFO - 2016-09-23 23:40:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:40:39 --> Input Class Initialized
INFO - 2016-09-23 23:40:39 --> Language Class Initialized
ERROR - 2016-09-23 23:40:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:41:09 --> Config Class Initialized
INFO - 2016-09-23 23:41:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:41:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:41:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:41:09 --> URI Class Initialized
INFO - 2016-09-23 23:41:09 --> Router Class Initialized
INFO - 2016-09-23 23:41:09 --> Output Class Initialized
INFO - 2016-09-23 23:41:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:41:09 --> Input Class Initialized
INFO - 2016-09-23 23:41:09 --> Language Class Initialized
ERROR - 2016-09-23 23:41:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:41:39 --> Config Class Initialized
INFO - 2016-09-23 23:41:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:41:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:41:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:41:39 --> URI Class Initialized
INFO - 2016-09-23 23:41:39 --> Router Class Initialized
INFO - 2016-09-23 23:41:39 --> Output Class Initialized
INFO - 2016-09-23 23:41:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:41:39 --> Input Class Initialized
INFO - 2016-09-23 23:41:39 --> Language Class Initialized
ERROR - 2016-09-23 23:41:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:42:09 --> Config Class Initialized
INFO - 2016-09-23 23:42:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:42:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:42:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:42:09 --> URI Class Initialized
INFO - 2016-09-23 23:42:09 --> Router Class Initialized
INFO - 2016-09-23 23:42:09 --> Output Class Initialized
INFO - 2016-09-23 23:42:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:42:09 --> Input Class Initialized
INFO - 2016-09-23 23:42:09 --> Language Class Initialized
ERROR - 2016-09-23 23:42:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:42:39 --> Config Class Initialized
INFO - 2016-09-23 23:42:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:42:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:42:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:42:39 --> URI Class Initialized
INFO - 2016-09-23 23:42:39 --> Router Class Initialized
INFO - 2016-09-23 23:42:39 --> Output Class Initialized
INFO - 2016-09-23 23:42:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:42:39 --> Input Class Initialized
INFO - 2016-09-23 23:42:39 --> Language Class Initialized
ERROR - 2016-09-23 23:42:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:43:09 --> Config Class Initialized
INFO - 2016-09-23 23:43:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:43:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:43:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:43:09 --> URI Class Initialized
INFO - 2016-09-23 23:43:09 --> Router Class Initialized
INFO - 2016-09-23 23:43:09 --> Output Class Initialized
INFO - 2016-09-23 23:43:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:43:09 --> Input Class Initialized
INFO - 2016-09-23 23:43:09 --> Language Class Initialized
ERROR - 2016-09-23 23:43:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:43:39 --> Config Class Initialized
INFO - 2016-09-23 23:43:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:43:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:43:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:43:39 --> URI Class Initialized
INFO - 2016-09-23 23:43:39 --> Router Class Initialized
INFO - 2016-09-23 23:43:39 --> Output Class Initialized
INFO - 2016-09-23 23:43:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:43:39 --> Input Class Initialized
INFO - 2016-09-23 23:43:39 --> Language Class Initialized
ERROR - 2016-09-23 23:43:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:44:09 --> Config Class Initialized
INFO - 2016-09-23 23:44:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:44:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:44:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:44:09 --> URI Class Initialized
INFO - 2016-09-23 23:44:09 --> Router Class Initialized
INFO - 2016-09-23 23:44:09 --> Output Class Initialized
INFO - 2016-09-23 23:44:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:44:09 --> Input Class Initialized
INFO - 2016-09-23 23:44:09 --> Language Class Initialized
ERROR - 2016-09-23 23:44:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:44:39 --> Config Class Initialized
INFO - 2016-09-23 23:44:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:44:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:44:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:44:39 --> URI Class Initialized
INFO - 2016-09-23 23:44:39 --> Router Class Initialized
INFO - 2016-09-23 23:44:39 --> Output Class Initialized
INFO - 2016-09-23 23:44:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:44:39 --> Input Class Initialized
INFO - 2016-09-23 23:44:39 --> Language Class Initialized
ERROR - 2016-09-23 23:44:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:45:09 --> Config Class Initialized
INFO - 2016-09-23 23:45:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:45:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:45:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:45:09 --> URI Class Initialized
INFO - 2016-09-23 23:45:09 --> Router Class Initialized
INFO - 2016-09-23 23:45:09 --> Output Class Initialized
INFO - 2016-09-23 23:45:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:45:09 --> Input Class Initialized
INFO - 2016-09-23 23:45:09 --> Language Class Initialized
ERROR - 2016-09-23 23:45:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:45:39 --> Config Class Initialized
INFO - 2016-09-23 23:45:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:45:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:45:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:45:39 --> URI Class Initialized
INFO - 2016-09-23 23:45:39 --> Router Class Initialized
INFO - 2016-09-23 23:45:39 --> Output Class Initialized
INFO - 2016-09-23 23:45:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:45:39 --> Input Class Initialized
INFO - 2016-09-23 23:45:39 --> Language Class Initialized
ERROR - 2016-09-23 23:45:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:46:09 --> Config Class Initialized
INFO - 2016-09-23 23:46:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:46:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:46:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:46:09 --> URI Class Initialized
INFO - 2016-09-23 23:46:09 --> Router Class Initialized
INFO - 2016-09-23 23:46:09 --> Output Class Initialized
INFO - 2016-09-23 23:46:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:46:09 --> Input Class Initialized
INFO - 2016-09-23 23:46:09 --> Language Class Initialized
ERROR - 2016-09-23 23:46:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:46:39 --> Config Class Initialized
INFO - 2016-09-23 23:46:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:46:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:46:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:46:39 --> URI Class Initialized
INFO - 2016-09-23 23:46:39 --> Router Class Initialized
INFO - 2016-09-23 23:46:39 --> Output Class Initialized
INFO - 2016-09-23 23:46:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:46:39 --> Input Class Initialized
INFO - 2016-09-23 23:46:39 --> Language Class Initialized
ERROR - 2016-09-23 23:46:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:47:09 --> Config Class Initialized
INFO - 2016-09-23 23:47:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:47:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:47:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:47:09 --> URI Class Initialized
INFO - 2016-09-23 23:47:09 --> Router Class Initialized
INFO - 2016-09-23 23:47:09 --> Output Class Initialized
INFO - 2016-09-23 23:47:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:47:09 --> Input Class Initialized
INFO - 2016-09-23 23:47:09 --> Language Class Initialized
ERROR - 2016-09-23 23:47:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:47:39 --> Config Class Initialized
INFO - 2016-09-23 23:47:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:47:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:47:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:47:39 --> URI Class Initialized
INFO - 2016-09-23 23:47:39 --> Router Class Initialized
INFO - 2016-09-23 23:47:39 --> Output Class Initialized
INFO - 2016-09-23 23:47:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:47:39 --> Input Class Initialized
INFO - 2016-09-23 23:47:39 --> Language Class Initialized
ERROR - 2016-09-23 23:47:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:48:09 --> Config Class Initialized
INFO - 2016-09-23 23:48:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:48:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:48:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:48:09 --> URI Class Initialized
INFO - 2016-09-23 23:48:09 --> Router Class Initialized
INFO - 2016-09-23 23:48:09 --> Output Class Initialized
INFO - 2016-09-23 23:48:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:48:09 --> Input Class Initialized
INFO - 2016-09-23 23:48:09 --> Language Class Initialized
ERROR - 2016-09-23 23:48:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:48:39 --> Config Class Initialized
INFO - 2016-09-23 23:48:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:48:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:48:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:48:39 --> URI Class Initialized
INFO - 2016-09-23 23:48:39 --> Router Class Initialized
INFO - 2016-09-23 23:48:39 --> Output Class Initialized
INFO - 2016-09-23 23:48:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:48:39 --> Input Class Initialized
INFO - 2016-09-23 23:48:39 --> Language Class Initialized
ERROR - 2016-09-23 23:48:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:49:09 --> Config Class Initialized
INFO - 2016-09-23 23:49:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:49:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:49:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:49:09 --> URI Class Initialized
INFO - 2016-09-23 23:49:09 --> Router Class Initialized
INFO - 2016-09-23 23:49:09 --> Output Class Initialized
INFO - 2016-09-23 23:49:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:49:09 --> Input Class Initialized
INFO - 2016-09-23 23:49:09 --> Language Class Initialized
ERROR - 2016-09-23 23:49:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:49:39 --> Config Class Initialized
INFO - 2016-09-23 23:49:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:49:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:49:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:49:39 --> URI Class Initialized
INFO - 2016-09-23 23:49:39 --> Router Class Initialized
INFO - 2016-09-23 23:49:39 --> Output Class Initialized
INFO - 2016-09-23 23:49:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:49:39 --> Input Class Initialized
INFO - 2016-09-23 23:49:39 --> Language Class Initialized
ERROR - 2016-09-23 23:49:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:50:09 --> Config Class Initialized
INFO - 2016-09-23 23:50:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:50:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:50:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:50:09 --> URI Class Initialized
INFO - 2016-09-23 23:50:09 --> Router Class Initialized
INFO - 2016-09-23 23:50:09 --> Output Class Initialized
INFO - 2016-09-23 23:50:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:50:09 --> Input Class Initialized
INFO - 2016-09-23 23:50:09 --> Language Class Initialized
ERROR - 2016-09-23 23:50:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:50:39 --> Config Class Initialized
INFO - 2016-09-23 23:50:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:50:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:50:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:50:39 --> URI Class Initialized
INFO - 2016-09-23 23:50:39 --> Router Class Initialized
INFO - 2016-09-23 23:50:39 --> Output Class Initialized
INFO - 2016-09-23 23:50:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:50:39 --> Input Class Initialized
INFO - 2016-09-23 23:50:39 --> Language Class Initialized
ERROR - 2016-09-23 23:50:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:51:09 --> Config Class Initialized
INFO - 2016-09-23 23:51:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:51:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:51:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:51:09 --> URI Class Initialized
INFO - 2016-09-23 23:51:09 --> Router Class Initialized
INFO - 2016-09-23 23:51:09 --> Output Class Initialized
INFO - 2016-09-23 23:51:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:51:09 --> Input Class Initialized
INFO - 2016-09-23 23:51:09 --> Language Class Initialized
ERROR - 2016-09-23 23:51:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:51:39 --> Config Class Initialized
INFO - 2016-09-23 23:51:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:51:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:51:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:51:39 --> URI Class Initialized
INFO - 2016-09-23 23:51:39 --> Router Class Initialized
INFO - 2016-09-23 23:51:39 --> Output Class Initialized
INFO - 2016-09-23 23:51:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:51:39 --> Input Class Initialized
INFO - 2016-09-23 23:51:39 --> Language Class Initialized
ERROR - 2016-09-23 23:51:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:52:09 --> Config Class Initialized
INFO - 2016-09-23 23:52:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:52:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:52:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:52:09 --> URI Class Initialized
INFO - 2016-09-23 23:52:09 --> Router Class Initialized
INFO - 2016-09-23 23:52:09 --> Output Class Initialized
INFO - 2016-09-23 23:52:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:52:09 --> Input Class Initialized
INFO - 2016-09-23 23:52:09 --> Language Class Initialized
ERROR - 2016-09-23 23:52:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:52:26 --> Config Class Initialized
INFO - 2016-09-23 23:52:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:52:26 --> Utf8 Class Initialized
INFO - 2016-09-23 23:52:26 --> URI Class Initialized
INFO - 2016-09-23 23:52:26 --> Router Class Initialized
INFO - 2016-09-23 23:52:26 --> Output Class Initialized
INFO - 2016-09-23 23:52:26 --> Config Class Initialized
INFO - 2016-09-23 23:52:26 --> Hooks Class Initialized
INFO - 2016-09-23 23:52:26 --> Security Class Initialized
DEBUG - 2016-09-23 23:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:52:26 --> Input Class Initialized
INFO - 2016-09-23 23:52:26 --> Language Class Initialized
DEBUG - 2016-09-23 23:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:52:26 --> Utf8 Class Initialized
INFO - 2016-09-23 23:52:26 --> URI Class Initialized
INFO - 2016-09-23 23:52:26 --> Loader Class Initialized
INFO - 2016-09-23 23:52:26 --> Router Class Initialized
INFO - 2016-09-23 23:52:26 --> Helper loaded: url_helper
INFO - 2016-09-23 23:52:26 --> Helper loaded: language_helper
INFO - 2016-09-23 23:52:26 --> Output Class Initialized
INFO - 2016-09-23 23:52:26 --> Security Class Initialized
INFO - 2016-09-23 23:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:52:26 --> Controller Class Initialized
DEBUG - 2016-09-23 23:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:52:26 --> Input Class Initialized
INFO - 2016-09-23 23:52:26 --> Language Class Initialized
INFO - 2016-09-23 23:52:26 --> Loader Class Initialized
INFO - 2016-09-23 23:52:26 --> Database Driver Class Initialized
INFO - 2016-09-23 23:52:26 --> Helper loaded: url_helper
INFO - 2016-09-23 23:52:26 --> Helper loaded: language_helper
INFO - 2016-09-23 23:52:26 --> Model Class Initialized
INFO - 2016-09-23 23:52:26 --> Model Class Initialized
INFO - 2016-09-23 23:52:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:52:26 --> Final output sent to browser
DEBUG - 2016-09-23 23:52:26 --> Total execution time: 0.0803
INFO - 2016-09-23 23:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:52:26 --> Controller Class Initialized
INFO - 2016-09-23 23:52:26 --> Database Driver Class Initialized
INFO - 2016-09-23 23:52:26 --> Model Class Initialized
INFO - 2016-09-23 23:52:26 --> Model Class Initialized
INFO - 2016-09-23 23:52:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:52:26 --> Final output sent to browser
DEBUG - 2016-09-23 23:52:26 --> Total execution time: 0.1226
INFO - 2016-09-23 23:52:39 --> Config Class Initialized
INFO - 2016-09-23 23:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:52:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:52:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:52:39 --> URI Class Initialized
INFO - 2016-09-23 23:52:39 --> Router Class Initialized
INFO - 2016-09-23 23:52:39 --> Output Class Initialized
INFO - 2016-09-23 23:52:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:52:39 --> Input Class Initialized
INFO - 2016-09-23 23:52:39 --> Language Class Initialized
ERROR - 2016-09-23 23:52:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:53:09 --> Config Class Initialized
INFO - 2016-09-23 23:53:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:53:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:53:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:53:09 --> URI Class Initialized
INFO - 2016-09-23 23:53:09 --> Router Class Initialized
INFO - 2016-09-23 23:53:09 --> Output Class Initialized
INFO - 2016-09-23 23:53:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:53:09 --> Input Class Initialized
INFO - 2016-09-23 23:53:09 --> Language Class Initialized
ERROR - 2016-09-23 23:53:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:53:33 --> Config Class Initialized
INFO - 2016-09-23 23:53:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:53:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:53:33 --> Utf8 Class Initialized
INFO - 2016-09-23 23:53:33 --> URI Class Initialized
INFO - 2016-09-23 23:53:33 --> Router Class Initialized
INFO - 2016-09-23 23:53:33 --> Config Class Initialized
INFO - 2016-09-23 23:53:33 --> Hooks Class Initialized
INFO - 2016-09-23 23:53:33 --> Output Class Initialized
INFO - 2016-09-23 23:53:33 --> Security Class Initialized
DEBUG - 2016-09-23 23:53:33 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:53:33 --> Utf8 Class Initialized
DEBUG - 2016-09-23 23:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:53:33 --> Input Class Initialized
INFO - 2016-09-23 23:53:33 --> URI Class Initialized
INFO - 2016-09-23 23:53:33 --> Language Class Initialized
INFO - 2016-09-23 23:53:33 --> Router Class Initialized
INFO - 2016-09-23 23:53:33 --> Loader Class Initialized
INFO - 2016-09-23 23:53:33 --> Output Class Initialized
INFO - 2016-09-23 23:53:33 --> Helper loaded: url_helper
INFO - 2016-09-23 23:53:33 --> Helper loaded: language_helper
INFO - 2016-09-23 23:53:33 --> Security Class Initialized
DEBUG - 2016-09-23 23:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:53:33 --> Input Class Initialized
INFO - 2016-09-23 23:53:33 --> Language Class Initialized
INFO - 2016-09-23 23:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:53:33 --> Controller Class Initialized
INFO - 2016-09-23 23:53:33 --> Loader Class Initialized
INFO - 2016-09-23 23:53:33 --> Helper loaded: url_helper
INFO - 2016-09-23 23:53:33 --> Helper loaded: language_helper
INFO - 2016-09-23 23:53:33 --> Database Driver Class Initialized
INFO - 2016-09-23 23:53:33 --> Model Class Initialized
INFO - 2016-09-23 23:53:33 --> Model Class Initialized
INFO - 2016-09-23 23:53:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:53:33 --> Final output sent to browser
DEBUG - 2016-09-23 23:53:33 --> Total execution time: 0.0886
INFO - 2016-09-23 23:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:53:33 --> Controller Class Initialized
INFO - 2016-09-23 23:53:33 --> Database Driver Class Initialized
INFO - 2016-09-23 23:53:33 --> Model Class Initialized
INFO - 2016-09-23 23:53:33 --> Model Class Initialized
INFO - 2016-09-23 23:53:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:53:33 --> Final output sent to browser
DEBUG - 2016-09-23 23:53:33 --> Total execution time: 0.1418
INFO - 2016-09-23 23:53:39 --> Config Class Initialized
INFO - 2016-09-23 23:53:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:53:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:53:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:53:39 --> URI Class Initialized
INFO - 2016-09-23 23:53:39 --> Router Class Initialized
INFO - 2016-09-23 23:53:39 --> Output Class Initialized
INFO - 2016-09-23 23:53:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:53:39 --> Input Class Initialized
INFO - 2016-09-23 23:53:39 --> Language Class Initialized
ERROR - 2016-09-23 23:53:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:54:08 --> Config Class Initialized
INFO - 2016-09-23 23:54:08 --> Hooks Class Initialized
INFO - 2016-09-23 23:54:08 --> Config Class Initialized
DEBUG - 2016-09-23 23:54:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:54:08 --> Hooks Class Initialized
INFO - 2016-09-23 23:54:08 --> Utf8 Class Initialized
INFO - 2016-09-23 23:54:08 --> URI Class Initialized
DEBUG - 2016-09-23 23:54:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:54:08 --> Router Class Initialized
INFO - 2016-09-23 23:54:08 --> Utf8 Class Initialized
INFO - 2016-09-23 23:54:08 --> URI Class Initialized
INFO - 2016-09-23 23:54:08 --> Output Class Initialized
INFO - 2016-09-23 23:54:08 --> Router Class Initialized
INFO - 2016-09-23 23:54:08 --> Security Class Initialized
DEBUG - 2016-09-23 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:54:08 --> Input Class Initialized
INFO - 2016-09-23 23:54:08 --> Output Class Initialized
INFO - 2016-09-23 23:54:08 --> Language Class Initialized
INFO - 2016-09-23 23:54:08 --> Security Class Initialized
INFO - 2016-09-23 23:54:08 --> Loader Class Initialized
DEBUG - 2016-09-23 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:54:08 --> Input Class Initialized
INFO - 2016-09-23 23:54:08 --> Helper loaded: url_helper
INFO - 2016-09-23 23:54:08 --> Language Class Initialized
INFO - 2016-09-23 23:54:08 --> Helper loaded: language_helper
INFO - 2016-09-23 23:54:08 --> Loader Class Initialized
INFO - 2016-09-23 23:54:08 --> Helper loaded: url_helper
INFO - 2016-09-23 23:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:54:08 --> Controller Class Initialized
INFO - 2016-09-23 23:54:08 --> Helper loaded: language_helper
INFO - 2016-09-23 23:54:08 --> Database Driver Class Initialized
INFO - 2016-09-23 23:54:08 --> Model Class Initialized
INFO - 2016-09-23 23:54:08 --> Model Class Initialized
INFO - 2016-09-23 23:54:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:54:08 --> Final output sent to browser
DEBUG - 2016-09-23 23:54:08 --> Total execution time: 0.0759
INFO - 2016-09-23 23:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:54:08 --> Controller Class Initialized
INFO - 2016-09-23 23:54:08 --> Database Driver Class Initialized
INFO - 2016-09-23 23:54:08 --> Model Class Initialized
INFO - 2016-09-23 23:54:08 --> Model Class Initialized
INFO - 2016-09-23 23:54:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:54:08 --> Final output sent to browser
DEBUG - 2016-09-23 23:54:08 --> Total execution time: 0.1492
INFO - 2016-09-23 23:54:08 --> Config Class Initialized
INFO - 2016-09-23 23:54:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:54:08 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:54:08 --> Utf8 Class Initialized
INFO - 2016-09-23 23:54:08 --> URI Class Initialized
INFO - 2016-09-23 23:54:08 --> Router Class Initialized
INFO - 2016-09-23 23:54:08 --> Output Class Initialized
INFO - 2016-09-23 23:54:08 --> Security Class Initialized
DEBUG - 2016-09-23 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:54:08 --> Input Class Initialized
INFO - 2016-09-23 23:54:08 --> Language Class Initialized
ERROR - 2016-09-23 23:54:08 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:54:39 --> Config Class Initialized
INFO - 2016-09-23 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:54:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:54:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:54:39 --> URI Class Initialized
INFO - 2016-09-23 23:54:39 --> Router Class Initialized
INFO - 2016-09-23 23:54:39 --> Output Class Initialized
INFO - 2016-09-23 23:54:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:54:39 --> Input Class Initialized
INFO - 2016-09-23 23:54:39 --> Language Class Initialized
ERROR - 2016-09-23 23:54:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:54:51 --> Config Class Initialized
INFO - 2016-09-23 23:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:54:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:54:51 --> Utf8 Class Initialized
INFO - 2016-09-23 23:54:51 --> Config Class Initialized
INFO - 2016-09-23 23:54:51 --> Hooks Class Initialized
INFO - 2016-09-23 23:54:51 --> URI Class Initialized
INFO - 2016-09-23 23:54:51 --> Router Class Initialized
DEBUG - 2016-09-23 23:54:51 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:54:51 --> Utf8 Class Initialized
INFO - 2016-09-23 23:54:51 --> Output Class Initialized
INFO - 2016-09-23 23:54:51 --> URI Class Initialized
INFO - 2016-09-23 23:54:51 --> Security Class Initialized
INFO - 2016-09-23 23:54:51 --> Router Class Initialized
DEBUG - 2016-09-23 23:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:54:51 --> Input Class Initialized
INFO - 2016-09-23 23:54:51 --> Output Class Initialized
INFO - 2016-09-23 23:54:51 --> Language Class Initialized
INFO - 2016-09-23 23:54:51 --> Security Class Initialized
DEBUG - 2016-09-23 23:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:54:51 --> Input Class Initialized
INFO - 2016-09-23 23:54:51 --> Loader Class Initialized
INFO - 2016-09-23 23:54:51 --> Language Class Initialized
INFO - 2016-09-23 23:54:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:54:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:54:51 --> Loader Class Initialized
INFO - 2016-09-23 23:54:51 --> Helper loaded: url_helper
INFO - 2016-09-23 23:54:51 --> Helper loaded: language_helper
INFO - 2016-09-23 23:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:54:51 --> Controller Class Initialized
INFO - 2016-09-23 23:54:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:54:51 --> Model Class Initialized
INFO - 2016-09-23 23:54:51 --> Model Class Initialized
INFO - 2016-09-23 23:54:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:54:51 --> Final output sent to browser
DEBUG - 2016-09-23 23:54:51 --> Total execution time: 0.1023
INFO - 2016-09-23 23:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-23 23:54:51 --> Controller Class Initialized
INFO - 2016-09-23 23:54:51 --> Database Driver Class Initialized
INFO - 2016-09-23 23:54:51 --> Model Class Initialized
INFO - 2016-09-23 23:54:51 --> Model Class Initialized
INFO - 2016-09-23 23:54:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-23 23:54:51 --> Final output sent to browser
DEBUG - 2016-09-23 23:54:51 --> Total execution time: 0.1239
INFO - 2016-09-23 23:55:09 --> Config Class Initialized
INFO - 2016-09-23 23:55:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:55:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:55:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:55:09 --> URI Class Initialized
INFO - 2016-09-23 23:55:09 --> Router Class Initialized
INFO - 2016-09-23 23:55:09 --> Output Class Initialized
INFO - 2016-09-23 23:55:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:55:09 --> Input Class Initialized
INFO - 2016-09-23 23:55:09 --> Language Class Initialized
ERROR - 2016-09-23 23:55:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:55:39 --> Config Class Initialized
INFO - 2016-09-23 23:55:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:55:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:55:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:55:39 --> URI Class Initialized
INFO - 2016-09-23 23:55:39 --> Router Class Initialized
INFO - 2016-09-23 23:55:39 --> Output Class Initialized
INFO - 2016-09-23 23:55:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:55:39 --> Input Class Initialized
INFO - 2016-09-23 23:55:39 --> Language Class Initialized
ERROR - 2016-09-23 23:55:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:56:09 --> Config Class Initialized
INFO - 2016-09-23 23:56:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:56:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:56:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:56:09 --> URI Class Initialized
INFO - 2016-09-23 23:56:09 --> Router Class Initialized
INFO - 2016-09-23 23:56:09 --> Output Class Initialized
INFO - 2016-09-23 23:56:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:56:09 --> Input Class Initialized
INFO - 2016-09-23 23:56:09 --> Language Class Initialized
ERROR - 2016-09-23 23:56:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:56:39 --> Config Class Initialized
INFO - 2016-09-23 23:56:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:56:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:56:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:56:39 --> URI Class Initialized
INFO - 2016-09-23 23:56:39 --> Router Class Initialized
INFO - 2016-09-23 23:56:39 --> Output Class Initialized
INFO - 2016-09-23 23:56:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:56:39 --> Input Class Initialized
INFO - 2016-09-23 23:56:39 --> Language Class Initialized
ERROR - 2016-09-23 23:56:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:57:09 --> Config Class Initialized
INFO - 2016-09-23 23:57:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:57:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:57:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:57:09 --> URI Class Initialized
INFO - 2016-09-23 23:57:09 --> Router Class Initialized
INFO - 2016-09-23 23:57:09 --> Output Class Initialized
INFO - 2016-09-23 23:57:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:57:09 --> Input Class Initialized
INFO - 2016-09-23 23:57:09 --> Language Class Initialized
ERROR - 2016-09-23 23:57:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:57:39 --> Config Class Initialized
INFO - 2016-09-23 23:57:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:57:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:57:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:57:39 --> URI Class Initialized
INFO - 2016-09-23 23:57:39 --> Router Class Initialized
INFO - 2016-09-23 23:57:39 --> Output Class Initialized
INFO - 2016-09-23 23:57:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:57:39 --> Input Class Initialized
INFO - 2016-09-23 23:57:39 --> Language Class Initialized
ERROR - 2016-09-23 23:57:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:58:09 --> Config Class Initialized
INFO - 2016-09-23 23:58:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:58:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:58:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:58:09 --> URI Class Initialized
INFO - 2016-09-23 23:58:09 --> Router Class Initialized
INFO - 2016-09-23 23:58:09 --> Output Class Initialized
INFO - 2016-09-23 23:58:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:58:09 --> Input Class Initialized
INFO - 2016-09-23 23:58:09 --> Language Class Initialized
ERROR - 2016-09-23 23:58:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:58:39 --> Config Class Initialized
INFO - 2016-09-23 23:58:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:58:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:58:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:58:39 --> URI Class Initialized
INFO - 2016-09-23 23:58:39 --> Router Class Initialized
INFO - 2016-09-23 23:58:39 --> Output Class Initialized
INFO - 2016-09-23 23:58:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:58:39 --> Input Class Initialized
INFO - 2016-09-23 23:58:39 --> Language Class Initialized
ERROR - 2016-09-23 23:58:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:59:09 --> Config Class Initialized
INFO - 2016-09-23 23:59:09 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:59:09 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:59:09 --> Utf8 Class Initialized
INFO - 2016-09-23 23:59:09 --> URI Class Initialized
INFO - 2016-09-23 23:59:09 --> Router Class Initialized
INFO - 2016-09-23 23:59:09 --> Output Class Initialized
INFO - 2016-09-23 23:59:09 --> Security Class Initialized
DEBUG - 2016-09-23 23:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:59:09 --> Input Class Initialized
INFO - 2016-09-23 23:59:09 --> Language Class Initialized
ERROR - 2016-09-23 23:59:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-23 23:59:39 --> Config Class Initialized
INFO - 2016-09-23 23:59:39 --> Hooks Class Initialized
DEBUG - 2016-09-23 23:59:39 --> UTF-8 Support Enabled
INFO - 2016-09-23 23:59:39 --> Utf8 Class Initialized
INFO - 2016-09-23 23:59:39 --> URI Class Initialized
INFO - 2016-09-23 23:59:39 --> Router Class Initialized
INFO - 2016-09-23 23:59:39 --> Output Class Initialized
INFO - 2016-09-23 23:59:39 --> Security Class Initialized
DEBUG - 2016-09-23 23:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-23 23:59:39 --> Input Class Initialized
INFO - 2016-09-23 23:59:39 --> Language Class Initialized
ERROR - 2016-09-23 23:59:39 --> 404 Page Not Found: Ujian/set_ind_time
