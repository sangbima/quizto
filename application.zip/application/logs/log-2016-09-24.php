<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-24 00:00:09 --> Config Class Initialized
INFO - 2016-09-24 00:00:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:00:09 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:00:09 --> Utf8 Class Initialized
INFO - 2016-09-24 00:00:09 --> URI Class Initialized
INFO - 2016-09-24 00:00:09 --> Router Class Initialized
INFO - 2016-09-24 00:00:09 --> Output Class Initialized
INFO - 2016-09-24 00:00:09 --> Security Class Initialized
DEBUG - 2016-09-24 00:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:00:09 --> Input Class Initialized
INFO - 2016-09-24 00:00:09 --> Language Class Initialized
ERROR - 2016-09-24 00:00:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:00:39 --> Config Class Initialized
INFO - 2016-09-24 00:00:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:00:39 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:00:39 --> Utf8 Class Initialized
INFO - 2016-09-24 00:00:39 --> URI Class Initialized
INFO - 2016-09-24 00:00:39 --> Router Class Initialized
INFO - 2016-09-24 00:00:39 --> Output Class Initialized
INFO - 2016-09-24 00:00:39 --> Security Class Initialized
DEBUG - 2016-09-24 00:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:00:39 --> Input Class Initialized
INFO - 2016-09-24 00:00:39 --> Language Class Initialized
ERROR - 2016-09-24 00:00:39 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:01:09 --> Config Class Initialized
INFO - 2016-09-24 00:01:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:01:09 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:01:09 --> Utf8 Class Initialized
INFO - 2016-09-24 00:01:09 --> URI Class Initialized
INFO - 2016-09-24 00:01:09 --> Router Class Initialized
INFO - 2016-09-24 00:01:09 --> Output Class Initialized
INFO - 2016-09-24 00:01:09 --> Security Class Initialized
DEBUG - 2016-09-24 00:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:01:09 --> Input Class Initialized
INFO - 2016-09-24 00:01:09 --> Language Class Initialized
ERROR - 2016-09-24 00:01:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:01:38 --> Config Class Initialized
INFO - 2016-09-24 00:01:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:01:38 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:01:38 --> Utf8 Class Initialized
INFO - 2016-09-24 00:01:38 --> URI Class Initialized
INFO - 2016-09-24 00:01:38 --> Router Class Initialized
INFO - 2016-09-24 00:01:38 --> Output Class Initialized
INFO - 2016-09-24 00:01:38 --> Security Class Initialized
DEBUG - 2016-09-24 00:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:01:38 --> Input Class Initialized
INFO - 2016-09-24 00:01:38 --> Language Class Initialized
ERROR - 2016-09-24 00:01:38 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:02:08 --> Config Class Initialized
INFO - 2016-09-24 00:02:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:02:08 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:02:08 --> Utf8 Class Initialized
INFO - 2016-09-24 00:02:08 --> URI Class Initialized
INFO - 2016-09-24 00:02:08 --> Router Class Initialized
INFO - 2016-09-24 00:02:08 --> Output Class Initialized
INFO - 2016-09-24 00:02:08 --> Security Class Initialized
DEBUG - 2016-09-24 00:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:02:08 --> Input Class Initialized
INFO - 2016-09-24 00:02:08 --> Language Class Initialized
ERROR - 2016-09-24 00:02:08 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:02:38 --> Config Class Initialized
INFO - 2016-09-24 00:02:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:02:38 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:02:38 --> Utf8 Class Initialized
INFO - 2016-09-24 00:02:38 --> URI Class Initialized
INFO - 2016-09-24 00:02:38 --> Router Class Initialized
INFO - 2016-09-24 00:02:38 --> Output Class Initialized
INFO - 2016-09-24 00:02:38 --> Security Class Initialized
DEBUG - 2016-09-24 00:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:02:38 --> Input Class Initialized
INFO - 2016-09-24 00:02:38 --> Language Class Initialized
ERROR - 2016-09-24 00:02:38 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:03:08 --> Config Class Initialized
INFO - 2016-09-24 00:03:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:03:08 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:03:08 --> Utf8 Class Initialized
INFO - 2016-09-24 00:03:08 --> URI Class Initialized
INFO - 2016-09-24 00:03:08 --> Router Class Initialized
INFO - 2016-09-24 00:03:08 --> Output Class Initialized
INFO - 2016-09-24 00:03:08 --> Security Class Initialized
DEBUG - 2016-09-24 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:03:08 --> Input Class Initialized
INFO - 2016-09-24 00:03:08 --> Language Class Initialized
ERROR - 2016-09-24 00:03:08 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:03:38 --> Config Class Initialized
INFO - 2016-09-24 00:03:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:03:38 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:03:38 --> Utf8 Class Initialized
INFO - 2016-09-24 00:03:38 --> URI Class Initialized
INFO - 2016-09-24 00:03:38 --> Router Class Initialized
INFO - 2016-09-24 00:03:38 --> Output Class Initialized
INFO - 2016-09-24 00:03:38 --> Security Class Initialized
DEBUG - 2016-09-24 00:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:03:38 --> Input Class Initialized
INFO - 2016-09-24 00:03:38 --> Language Class Initialized
ERROR - 2016-09-24 00:03:38 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:04:08 --> Config Class Initialized
INFO - 2016-09-24 00:04:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:04:08 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:08 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:08 --> URI Class Initialized
INFO - 2016-09-24 00:04:08 --> Router Class Initialized
INFO - 2016-09-24 00:04:08 --> Output Class Initialized
INFO - 2016-09-24 00:04:08 --> Security Class Initialized
DEBUG - 2016-09-24 00:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:08 --> Input Class Initialized
INFO - 2016-09-24 00:04:08 --> Language Class Initialized
ERROR - 2016-09-24 00:04:08 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:04:38 --> Config Class Initialized
INFO - 2016-09-24 00:04:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:04:38 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:38 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:38 --> URI Class Initialized
INFO - 2016-09-24 00:04:38 --> Router Class Initialized
INFO - 2016-09-24 00:04:38 --> Output Class Initialized
INFO - 2016-09-24 00:04:38 --> Security Class Initialized
DEBUG - 2016-09-24 00:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:38 --> Input Class Initialized
INFO - 2016-09-24 00:04:38 --> Language Class Initialized
ERROR - 2016-09-24 00:04:38 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:04:44 --> Config Class Initialized
INFO - 2016-09-24 00:04:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:04:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:44 --> URI Class Initialized
INFO - 2016-09-24 00:04:44 --> Router Class Initialized
INFO - 2016-09-24 00:04:44 --> Output Class Initialized
INFO - 2016-09-24 00:04:44 --> Security Class Initialized
DEBUG - 2016-09-24 00:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:44 --> Input Class Initialized
INFO - 2016-09-24 00:04:44 --> Language Class Initialized
INFO - 2016-09-24 00:04:44 --> Loader Class Initialized
INFO - 2016-09-24 00:04:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:04:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:04:44 --> Controller Class Initialized
INFO - 2016-09-24 00:04:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:04:44 --> Model Class Initialized
INFO - 2016-09-24 00:04:44 --> Model Class Initialized
INFO - 2016-09-24 00:04:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:04:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:04:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-24 00:04:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:04:44 --> Final output sent to browser
DEBUG - 2016-09-24 00:04:44 --> Total execution time: 0.0995
INFO - 2016-09-24 00:04:45 --> Config Class Initialized
INFO - 2016-09-24 00:04:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:04:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:45 --> Config Class Initialized
INFO - 2016-09-24 00:04:45 --> Hooks Class Initialized
INFO - 2016-09-24 00:04:45 --> URI Class Initialized
INFO - 2016-09-24 00:04:45 --> Router Class Initialized
INFO - 2016-09-24 00:04:45 --> Output Class Initialized
INFO - 2016-09-24 00:04:45 --> Security Class Initialized
DEBUG - 2016-09-24 00:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:45 --> Input Class Initialized
INFO - 2016-09-24 00:04:45 --> Language Class Initialized
DEBUG - 2016-09-24 00:04:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:45 --> Loader Class Initialized
INFO - 2016-09-24 00:04:45 --> URI Class Initialized
INFO - 2016-09-24 00:04:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:04:45 --> Router Class Initialized
INFO - 2016-09-24 00:04:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:04:45 --> Output Class Initialized
INFO - 2016-09-24 00:04:45 --> Security Class Initialized
INFO - 2016-09-24 00:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:04:45 --> Controller Class Initialized
DEBUG - 2016-09-24 00:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:45 --> Input Class Initialized
INFO - 2016-09-24 00:04:45 --> Language Class Initialized
INFO - 2016-09-24 00:04:45 --> Loader Class Initialized
INFO - 2016-09-24 00:04:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:04:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:04:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:04:45 --> Model Class Initialized
INFO - 2016-09-24 00:04:45 --> Model Class Initialized
INFO - 2016-09-24 00:04:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:04:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:04:45 --> Total execution time: 0.0886
INFO - 2016-09-24 00:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:04:45 --> Controller Class Initialized
INFO - 2016-09-24 00:04:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:04:45 --> Model Class Initialized
INFO - 2016-09-24 00:04:45 --> Model Class Initialized
INFO - 2016-09-24 00:04:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:04:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:04:45 --> Total execution time: 0.1660
INFO - 2016-09-24 00:04:53 --> Config Class Initialized
INFO - 2016-09-24 00:04:53 --> Hooks Class Initialized
INFO - 2016-09-24 00:04:53 --> Config Class Initialized
INFO - 2016-09-24 00:04:53 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:04:53 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:53 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:53 --> URI Class Initialized
INFO - 2016-09-24 00:04:53 --> Router Class Initialized
DEBUG - 2016-09-24 00:04:53 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:04:53 --> Utf8 Class Initialized
INFO - 2016-09-24 00:04:53 --> URI Class Initialized
INFO - 2016-09-24 00:04:53 --> Output Class Initialized
INFO - 2016-09-24 00:04:53 --> Router Class Initialized
INFO - 2016-09-24 00:04:53 --> Security Class Initialized
DEBUG - 2016-09-24 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:53 --> Input Class Initialized
INFO - 2016-09-24 00:04:53 --> Output Class Initialized
INFO - 2016-09-24 00:04:53 --> Language Class Initialized
INFO - 2016-09-24 00:04:53 --> Security Class Initialized
INFO - 2016-09-24 00:04:53 --> Loader Class Initialized
DEBUG - 2016-09-24 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:04:53 --> Input Class Initialized
INFO - 2016-09-24 00:04:53 --> Language Class Initialized
INFO - 2016-09-24 00:04:53 --> Helper loaded: url_helper
INFO - 2016-09-24 00:04:53 --> Helper loaded: language_helper
INFO - 2016-09-24 00:04:53 --> Loader Class Initialized
INFO - 2016-09-24 00:04:53 --> Helper loaded: url_helper
INFO - 2016-09-24 00:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:04:53 --> Controller Class Initialized
INFO - 2016-09-24 00:04:53 --> Helper loaded: language_helper
INFO - 2016-09-24 00:04:53 --> Database Driver Class Initialized
INFO - 2016-09-24 00:04:53 --> Model Class Initialized
INFO - 2016-09-24 00:04:53 --> Model Class Initialized
INFO - 2016-09-24 00:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:04:53 --> Final output sent to browser
DEBUG - 2016-09-24 00:04:53 --> Total execution time: 0.0809
INFO - 2016-09-24 00:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:04:53 --> Controller Class Initialized
INFO - 2016-09-24 00:04:53 --> Database Driver Class Initialized
INFO - 2016-09-24 00:04:53 --> Model Class Initialized
INFO - 2016-09-24 00:04:53 --> Model Class Initialized
INFO - 2016-09-24 00:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:04:53 --> Final output sent to browser
DEBUG - 2016-09-24 00:04:53 --> Total execution time: 0.1453
INFO - 2016-09-24 00:05:15 --> Config Class Initialized
INFO - 2016-09-24 00:05:15 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:05:15 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:15 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:15 --> URI Class Initialized
INFO - 2016-09-24 00:05:15 --> Router Class Initialized
INFO - 2016-09-24 00:05:15 --> Output Class Initialized
INFO - 2016-09-24 00:05:15 --> Security Class Initialized
DEBUG - 2016-09-24 00:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:15 --> Input Class Initialized
INFO - 2016-09-24 00:05:15 --> Language Class Initialized
ERROR - 2016-09-24 00:05:15 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:05:17 --> Config Class Initialized
INFO - 2016-09-24 00:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:17 --> URI Class Initialized
INFO - 2016-09-24 00:05:17 --> Router Class Initialized
INFO - 2016-09-24 00:05:17 --> Output Class Initialized
INFO - 2016-09-24 00:05:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:17 --> Input Class Initialized
INFO - 2016-09-24 00:05:17 --> Language Class Initialized
INFO - 2016-09-24 00:05:17 --> Loader Class Initialized
INFO - 2016-09-24 00:05:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:05:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:05:17 --> Controller Class Initialized
INFO - 2016-09-24 00:05:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:05:17 --> Model Class Initialized
INFO - 2016-09-24 00:05:17 --> Model Class Initialized
INFO - 2016-09-24 00:05:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:05:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:05:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-24 00:05:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:05:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:05:17 --> Total execution time: 0.0828
INFO - 2016-09-24 00:05:17 --> Config Class Initialized
INFO - 2016-09-24 00:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:17 --> Config Class Initialized
INFO - 2016-09-24 00:05:17 --> Hooks Class Initialized
INFO - 2016-09-24 00:05:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:17 --> URI Class Initialized
DEBUG - 2016-09-24 00:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:17 --> Router Class Initialized
INFO - 2016-09-24 00:05:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:17 --> URI Class Initialized
INFO - 2016-09-24 00:05:17 --> Output Class Initialized
INFO - 2016-09-24 00:05:17 --> Router Class Initialized
INFO - 2016-09-24 00:05:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:17 --> Input Class Initialized
INFO - 2016-09-24 00:05:17 --> Output Class Initialized
INFO - 2016-09-24 00:05:17 --> Language Class Initialized
INFO - 2016-09-24 00:05:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:17 --> Loader Class Initialized
INFO - 2016-09-24 00:05:17 --> Input Class Initialized
INFO - 2016-09-24 00:05:17 --> Language Class Initialized
INFO - 2016-09-24 00:05:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:05:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:05:17 --> Loader Class Initialized
INFO - 2016-09-24 00:05:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:05:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:05:17 --> Controller Class Initialized
INFO - 2016-09-24 00:05:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:05:17 --> Model Class Initialized
INFO - 2016-09-24 00:05:17 --> Model Class Initialized
INFO - 2016-09-24 00:05:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:05:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:05:17 --> Total execution time: 0.0919
INFO - 2016-09-24 00:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:05:17 --> Controller Class Initialized
INFO - 2016-09-24 00:05:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:05:17 --> Model Class Initialized
INFO - 2016-09-24 00:05:17 --> Model Class Initialized
INFO - 2016-09-24 00:05:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:05:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:05:17 --> Total execution time: 0.1666
INFO - 2016-09-24 00:05:31 --> Config Class Initialized
INFO - 2016-09-24 00:05:31 --> Hooks Class Initialized
INFO - 2016-09-24 00:05:31 --> Config Class Initialized
INFO - 2016-09-24 00:05:31 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:31 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:31 --> URI Class Initialized
DEBUG - 2016-09-24 00:05:31 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:31 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:31 --> Router Class Initialized
INFO - 2016-09-24 00:05:31 --> URI Class Initialized
INFO - 2016-09-24 00:05:31 --> Output Class Initialized
INFO - 2016-09-24 00:05:31 --> Router Class Initialized
INFO - 2016-09-24 00:05:31 --> Security Class Initialized
INFO - 2016-09-24 00:05:31 --> Output Class Initialized
DEBUG - 2016-09-24 00:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:31 --> Input Class Initialized
INFO - 2016-09-24 00:05:31 --> Security Class Initialized
INFO - 2016-09-24 00:05:31 --> Language Class Initialized
DEBUG - 2016-09-24 00:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:31 --> Input Class Initialized
INFO - 2016-09-24 00:05:31 --> Loader Class Initialized
INFO - 2016-09-24 00:05:31 --> Language Class Initialized
INFO - 2016-09-24 00:05:31 --> Helper loaded: url_helper
INFO - 2016-09-24 00:05:31 --> Helper loaded: language_helper
INFO - 2016-09-24 00:05:31 --> Loader Class Initialized
INFO - 2016-09-24 00:05:31 --> Helper loaded: url_helper
INFO - 2016-09-24 00:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:05:31 --> Controller Class Initialized
INFO - 2016-09-24 00:05:31 --> Helper loaded: language_helper
INFO - 2016-09-24 00:05:31 --> Database Driver Class Initialized
INFO - 2016-09-24 00:05:31 --> Model Class Initialized
INFO - 2016-09-24 00:05:31 --> Model Class Initialized
INFO - 2016-09-24 00:05:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:05:31 --> Final output sent to browser
DEBUG - 2016-09-24 00:05:31 --> Total execution time: 0.0865
INFO - 2016-09-24 00:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:05:31 --> Controller Class Initialized
INFO - 2016-09-24 00:05:31 --> Database Driver Class Initialized
INFO - 2016-09-24 00:05:31 --> Model Class Initialized
INFO - 2016-09-24 00:05:31 --> Model Class Initialized
INFO - 2016-09-24 00:05:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:05:31 --> Final output sent to browser
DEBUG - 2016-09-24 00:05:31 --> Total execution time: 0.1452
INFO - 2016-09-24 00:05:47 --> Config Class Initialized
INFO - 2016-09-24 00:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:05:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:05:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:05:47 --> URI Class Initialized
INFO - 2016-09-24 00:05:47 --> Router Class Initialized
INFO - 2016-09-24 00:05:47 --> Output Class Initialized
INFO - 2016-09-24 00:05:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:05:47 --> Input Class Initialized
INFO - 2016-09-24 00:05:47 --> Language Class Initialized
ERROR - 2016-09-24 00:05:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:06:17 --> Config Class Initialized
INFO - 2016-09-24 00:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:06:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:06:17 --> URI Class Initialized
INFO - 2016-09-24 00:06:17 --> Router Class Initialized
INFO - 2016-09-24 00:06:17 --> Output Class Initialized
INFO - 2016-09-24 00:06:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:06:17 --> Input Class Initialized
INFO - 2016-09-24 00:06:17 --> Language Class Initialized
ERROR - 2016-09-24 00:06:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:06:28 --> Config Class Initialized
INFO - 2016-09-24 00:06:28 --> Hooks Class Initialized
INFO - 2016-09-24 00:06:28 --> Config Class Initialized
INFO - 2016-09-24 00:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:06:28 --> Utf8 Class Initialized
INFO - 2016-09-24 00:06:28 --> URI Class Initialized
DEBUG - 2016-09-24 00:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:06:28 --> Utf8 Class Initialized
INFO - 2016-09-24 00:06:28 --> Router Class Initialized
INFO - 2016-09-24 00:06:28 --> URI Class Initialized
INFO - 2016-09-24 00:06:28 --> Output Class Initialized
INFO - 2016-09-24 00:06:28 --> Router Class Initialized
INFO - 2016-09-24 00:06:28 --> Security Class Initialized
INFO - 2016-09-24 00:06:28 --> Output Class Initialized
INFO - 2016-09-24 00:06:28 --> Security Class Initialized
DEBUG - 2016-09-24 00:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:06:28 --> Input Class Initialized
DEBUG - 2016-09-24 00:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:06:28 --> Language Class Initialized
INFO - 2016-09-24 00:06:28 --> Input Class Initialized
INFO - 2016-09-24 00:06:28 --> Language Class Initialized
INFO - 2016-09-24 00:06:28 --> Loader Class Initialized
INFO - 2016-09-24 00:06:28 --> Loader Class Initialized
INFO - 2016-09-24 00:06:28 --> Helper loaded: url_helper
INFO - 2016-09-24 00:06:28 --> Helper loaded: url_helper
INFO - 2016-09-24 00:06:28 --> Helper loaded: language_helper
INFO - 2016-09-24 00:06:28 --> Helper loaded: language_helper
INFO - 2016-09-24 00:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:06:28 --> Controller Class Initialized
INFO - 2016-09-24 00:06:28 --> Database Driver Class Initialized
INFO - 2016-09-24 00:06:28 --> Model Class Initialized
INFO - 2016-09-24 00:06:28 --> Model Class Initialized
INFO - 2016-09-24 00:06:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:06:28 --> Final output sent to browser
DEBUG - 2016-09-24 00:06:28 --> Total execution time: 0.1135
INFO - 2016-09-24 00:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:06:28 --> Controller Class Initialized
INFO - 2016-09-24 00:06:28 --> Database Driver Class Initialized
INFO - 2016-09-24 00:06:28 --> Model Class Initialized
INFO - 2016-09-24 00:06:28 --> Model Class Initialized
INFO - 2016-09-24 00:06:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:06:28 --> Final output sent to browser
DEBUG - 2016-09-24 00:06:28 --> Total execution time: 0.1375
INFO - 2016-09-24 00:06:47 --> Config Class Initialized
INFO - 2016-09-24 00:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:06:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:06:47 --> URI Class Initialized
INFO - 2016-09-24 00:06:47 --> Router Class Initialized
INFO - 2016-09-24 00:06:47 --> Output Class Initialized
INFO - 2016-09-24 00:06:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:06:47 --> Input Class Initialized
INFO - 2016-09-24 00:06:47 --> Language Class Initialized
ERROR - 2016-09-24 00:06:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:07:17 --> Config Class Initialized
INFO - 2016-09-24 00:07:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:07:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:17 --> URI Class Initialized
INFO - 2016-09-24 00:07:17 --> Router Class Initialized
INFO - 2016-09-24 00:07:17 --> Output Class Initialized
INFO - 2016-09-24 00:07:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:17 --> Input Class Initialized
INFO - 2016-09-24 00:07:17 --> Language Class Initialized
ERROR - 2016-09-24 00:07:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:07:21 --> Config Class Initialized
INFO - 2016-09-24 00:07:21 --> Hooks Class Initialized
INFO - 2016-09-24 00:07:21 --> Config Class Initialized
INFO - 2016-09-24 00:07:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:07:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:21 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:21 --> URI Class Initialized
INFO - 2016-09-24 00:07:21 --> Router Class Initialized
INFO - 2016-09-24 00:07:21 --> Output Class Initialized
DEBUG - 2016-09-24 00:07:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:21 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:21 --> Security Class Initialized
INFO - 2016-09-24 00:07:21 --> URI Class Initialized
DEBUG - 2016-09-24 00:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:21 --> Input Class Initialized
INFO - 2016-09-24 00:07:21 --> Router Class Initialized
INFO - 2016-09-24 00:07:21 --> Language Class Initialized
INFO - 2016-09-24 00:07:21 --> Output Class Initialized
INFO - 2016-09-24 00:07:21 --> Security Class Initialized
INFO - 2016-09-24 00:07:21 --> Loader Class Initialized
DEBUG - 2016-09-24 00:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:21 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:21 --> Input Class Initialized
INFO - 2016-09-24 00:07:21 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:21 --> Language Class Initialized
INFO - 2016-09-24 00:07:21 --> Loader Class Initialized
INFO - 2016-09-24 00:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:21 --> Controller Class Initialized
INFO - 2016-09-24 00:07:21 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:21 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:22 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:22 --> Model Class Initialized
INFO - 2016-09-24 00:07:22 --> Model Class Initialized
INFO - 2016-09-24 00:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:07:22 --> Final output sent to browser
DEBUG - 2016-09-24 00:07:22 --> Total execution time: 0.0713
INFO - 2016-09-24 00:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:22 --> Controller Class Initialized
INFO - 2016-09-24 00:07:22 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:22 --> Model Class Initialized
INFO - 2016-09-24 00:07:22 --> Model Class Initialized
INFO - 2016-09-24 00:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:07:22 --> Final output sent to browser
DEBUG - 2016-09-24 00:07:22 --> Total execution time: 0.1329
INFO - 2016-09-24 00:07:24 --> Config Class Initialized
INFO - 2016-09-24 00:07:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:07:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:24 --> URI Class Initialized
INFO - 2016-09-24 00:07:24 --> Config Class Initialized
INFO - 2016-09-24 00:07:24 --> Hooks Class Initialized
INFO - 2016-09-24 00:07:24 --> Router Class Initialized
INFO - 2016-09-24 00:07:24 --> Output Class Initialized
DEBUG - 2016-09-24 00:07:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:24 --> URI Class Initialized
INFO - 2016-09-24 00:07:24 --> Security Class Initialized
DEBUG - 2016-09-24 00:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:24 --> Input Class Initialized
INFO - 2016-09-24 00:07:24 --> Router Class Initialized
INFO - 2016-09-24 00:07:24 --> Language Class Initialized
INFO - 2016-09-24 00:07:24 --> Output Class Initialized
INFO - 2016-09-24 00:07:24 --> Security Class Initialized
INFO - 2016-09-24 00:07:24 --> Loader Class Initialized
INFO - 2016-09-24 00:07:24 --> Helper loaded: url_helper
DEBUG - 2016-09-24 00:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:24 --> Input Class Initialized
INFO - 2016-09-24 00:07:24 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:24 --> Language Class Initialized
INFO - 2016-09-24 00:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:24 --> Controller Class Initialized
INFO - 2016-09-24 00:07:24 --> Loader Class Initialized
INFO - 2016-09-24 00:07:24 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:24 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:24 --> Model Class Initialized
INFO - 2016-09-24 00:07:24 --> Model Class Initialized
INFO - 2016-09-24 00:07:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:07:24 --> Final output sent to browser
DEBUG - 2016-09-24 00:07:24 --> Total execution time: 0.0716
INFO - 2016-09-24 00:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:24 --> Controller Class Initialized
INFO - 2016-09-24 00:07:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:24 --> Model Class Initialized
INFO - 2016-09-24 00:07:24 --> Model Class Initialized
INFO - 2016-09-24 00:07:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:07:24 --> Final output sent to browser
DEBUG - 2016-09-24 00:07:24 --> Total execution time: 0.1281
INFO - 2016-09-24 00:07:48 --> Config Class Initialized
INFO - 2016-09-24 00:07:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:07:48 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:48 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:48 --> URI Class Initialized
INFO - 2016-09-24 00:07:48 --> Router Class Initialized
INFO - 2016-09-24 00:07:48 --> Output Class Initialized
INFO - 2016-09-24 00:07:48 --> Security Class Initialized
DEBUG - 2016-09-24 00:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:48 --> Input Class Initialized
INFO - 2016-09-24 00:07:48 --> Language Class Initialized
ERROR - 2016-09-24 00:07:48 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:07:56 --> Config Class Initialized
INFO - 2016-09-24 00:07:56 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:07:56 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:56 --> Config Class Initialized
INFO - 2016-09-24 00:07:56 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:56 --> Hooks Class Initialized
INFO - 2016-09-24 00:07:56 --> URI Class Initialized
DEBUG - 2016-09-24 00:07:56 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:56 --> Router Class Initialized
INFO - 2016-09-24 00:07:56 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:56 --> URI Class Initialized
INFO - 2016-09-24 00:07:56 --> Output Class Initialized
INFO - 2016-09-24 00:07:56 --> Security Class Initialized
INFO - 2016-09-24 00:07:56 --> Router Class Initialized
INFO - 2016-09-24 00:07:56 --> Output Class Initialized
DEBUG - 2016-09-24 00:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:56 --> Input Class Initialized
INFO - 2016-09-24 00:07:56 --> Language Class Initialized
INFO - 2016-09-24 00:07:56 --> Security Class Initialized
DEBUG - 2016-09-24 00:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:56 --> Input Class Initialized
INFO - 2016-09-24 00:07:56 --> Language Class Initialized
INFO - 2016-09-24 00:07:56 --> Loader Class Initialized
INFO - 2016-09-24 00:07:56 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:56 --> Loader Class Initialized
INFO - 2016-09-24 00:07:56 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:56 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:56 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:56 --> Controller Class Initialized
INFO - 2016-09-24 00:07:56 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:56 --> Model Class Initialized
INFO - 2016-09-24 00:07:56 --> Model Class Initialized
INFO - 2016-09-24 00:07:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:07:56 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:07:56 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 2)
INFO - 2016-09-24 00:07:56 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:56 --> Controller Class Initialized
INFO - 2016-09-24 00:07:56 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:56 --> Model Class Initialized
INFO - 2016-09-24 00:07:56 --> Model Class Initialized
INFO - 2016-09-24 00:07:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:07:56 --> Final output sent to browser
DEBUG - 2016-09-24 00:07:56 --> Total execution time: 0.1107
INFO - 2016-09-24 00:07:57 --> Config Class Initialized
INFO - 2016-09-24 00:07:57 --> Hooks Class Initialized
INFO - 2016-09-24 00:07:57 --> Config Class Initialized
INFO - 2016-09-24 00:07:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:07:57 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:07:57 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:07:57 --> URI Class Initialized
INFO - 2016-09-24 00:07:57 --> Utf8 Class Initialized
INFO - 2016-09-24 00:07:57 --> URI Class Initialized
INFO - 2016-09-24 00:07:57 --> Router Class Initialized
INFO - 2016-09-24 00:07:57 --> Router Class Initialized
INFO - 2016-09-24 00:07:57 --> Output Class Initialized
INFO - 2016-09-24 00:07:57 --> Output Class Initialized
INFO - 2016-09-24 00:07:57 --> Security Class Initialized
INFO - 2016-09-24 00:07:57 --> Security Class Initialized
DEBUG - 2016-09-24 00:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:57 --> Input Class Initialized
INFO - 2016-09-24 00:07:57 --> Language Class Initialized
DEBUG - 2016-09-24 00:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:07:57 --> Input Class Initialized
INFO - 2016-09-24 00:07:57 --> Language Class Initialized
INFO - 2016-09-24 00:07:57 --> Loader Class Initialized
INFO - 2016-09-24 00:07:57 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:57 --> Loader Class Initialized
INFO - 2016-09-24 00:07:57 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:57 --> Helper loaded: url_helper
INFO - 2016-09-24 00:07:57 --> Helper loaded: language_helper
INFO - 2016-09-24 00:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:57 --> Controller Class Initialized
INFO - 2016-09-24 00:07:57 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:57 --> Model Class Initialized
INFO - 2016-09-24 00:07:57 --> Model Class Initialized
INFO - 2016-09-24 00:07:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:07:57 --> Final output sent to browser
DEBUG - 2016-09-24 00:07:57 --> Total execution time: 0.0644
INFO - 2016-09-24 00:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:07:57 --> Controller Class Initialized
INFO - 2016-09-24 00:07:57 --> Database Driver Class Initialized
INFO - 2016-09-24 00:07:57 --> Model Class Initialized
INFO - 2016-09-24 00:07:57 --> Model Class Initialized
INFO - 2016-09-24 00:07:57 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:07:57 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:07:57 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 2)
INFO - 2016-09-24 00:07:57 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:08:18 --> Config Class Initialized
INFO - 2016-09-24 00:08:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:08:18 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:08:18 --> Utf8 Class Initialized
INFO - 2016-09-24 00:08:18 --> URI Class Initialized
INFO - 2016-09-24 00:08:18 --> Router Class Initialized
INFO - 2016-09-24 00:08:18 --> Output Class Initialized
INFO - 2016-09-24 00:08:18 --> Security Class Initialized
DEBUG - 2016-09-24 00:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:08:18 --> Input Class Initialized
INFO - 2016-09-24 00:08:18 --> Language Class Initialized
ERROR - 2016-09-24 00:08:18 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:08:44 --> Config Class Initialized
INFO - 2016-09-24 00:08:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:08:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:08:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:08:44 --> URI Class Initialized
INFO - 2016-09-24 00:08:44 --> Config Class Initialized
INFO - 2016-09-24 00:08:44 --> Router Class Initialized
INFO - 2016-09-24 00:08:44 --> Hooks Class Initialized
INFO - 2016-09-24 00:08:44 --> Output Class Initialized
DEBUG - 2016-09-24 00:08:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:08:44 --> Security Class Initialized
INFO - 2016-09-24 00:08:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:08:44 --> URI Class Initialized
INFO - 2016-09-24 00:08:44 --> Input Class Initialized
INFO - 2016-09-24 00:08:44 --> Language Class Initialized
INFO - 2016-09-24 00:08:44 --> Router Class Initialized
INFO - 2016-09-24 00:08:44 --> Output Class Initialized
INFO - 2016-09-24 00:08:44 --> Loader Class Initialized
INFO - 2016-09-24 00:08:44 --> Security Class Initialized
INFO - 2016-09-24 00:08:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:08:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:08:44 --> Input Class Initialized
INFO - 2016-09-24 00:08:44 --> Language Class Initialized
INFO - 2016-09-24 00:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:08:44 --> Controller Class Initialized
INFO - 2016-09-24 00:08:44 --> Loader Class Initialized
INFO - 2016-09-24 00:08:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:08:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:08:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:08:44 --> Model Class Initialized
INFO - 2016-09-24 00:08:44 --> Model Class Initialized
INFO - 2016-09-24 00:08:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:08:44 --> Final output sent to browser
DEBUG - 2016-09-24 00:08:44 --> Total execution time: 0.0686
INFO - 2016-09-24 00:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:08:44 --> Controller Class Initialized
INFO - 2016-09-24 00:08:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:08:44 --> Model Class Initialized
INFO - 2016-09-24 00:08:44 --> Model Class Initialized
INFO - 2016-09-24 00:08:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:08:44 --> Config Class Initialized
INFO - 2016-09-24 00:08:44 --> Hooks Class Initialized
INFO - 2016-09-24 00:08:44 --> Config Class Initialized
INFO - 2016-09-24 00:08:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:08:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:08:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:08:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:08:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:08:44 --> URI Class Initialized
INFO - 2016-09-24 00:08:44 --> URI Class Initialized
INFO - 2016-09-24 00:08:44 --> Router Class Initialized
INFO - 2016-09-24 00:08:44 --> Router Class Initialized
INFO - 2016-09-24 00:08:44 --> Output Class Initialized
INFO - 2016-09-24 00:08:44 --> Output Class Initialized
INFO - 2016-09-24 00:08:44 --> Security Class Initialized
INFO - 2016-09-24 00:08:44 --> Security Class Initialized
DEBUG - 2016-09-24 00:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:08:44 --> Input Class Initialized
INFO - 2016-09-24 00:08:44 --> Language Class Initialized
DEBUG - 2016-09-24 00:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:08:44 --> Input Class Initialized
INFO - 2016-09-24 00:08:44 --> Language Class Initialized
INFO - 2016-09-24 00:08:44 --> Loader Class Initialized
INFO - 2016-09-24 00:08:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:08:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:08:44 --> Loader Class Initialized
INFO - 2016-09-24 00:08:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:08:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:08:44 --> Controller Class Initialized
INFO - 2016-09-24 00:08:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:08:45 --> Model Class Initialized
INFO - 2016-09-24 00:08:45 --> Model Class Initialized
INFO - 2016-09-24 00:08:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:08:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:08:45 --> Total execution time: 0.0653
INFO - 2016-09-24 00:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:08:45 --> Controller Class Initialized
INFO - 2016-09-24 00:08:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:08:45 --> Model Class Initialized
INFO - 2016-09-24 00:08:45 --> Model Class Initialized
INFO - 2016-09-24 00:08:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:08:47 --> Config Class Initialized
INFO - 2016-09-24 00:08:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:08:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:08:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:08:47 --> URI Class Initialized
INFO - 2016-09-24 00:08:47 --> Router Class Initialized
INFO - 2016-09-24 00:08:47 --> Output Class Initialized
INFO - 2016-09-24 00:08:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:08:47 --> Input Class Initialized
INFO - 2016-09-24 00:08:47 --> Language Class Initialized
ERROR - 2016-09-24 00:08:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:09:06 --> Config Class Initialized
INFO - 2016-09-24 00:09:06 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:06 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:06 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:06 --> Config Class Initialized
INFO - 2016-09-24 00:09:06 --> Hooks Class Initialized
INFO - 2016-09-24 00:09:06 --> URI Class Initialized
INFO - 2016-09-24 00:09:06 --> Router Class Initialized
DEBUG - 2016-09-24 00:09:06 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:06 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:06 --> URI Class Initialized
INFO - 2016-09-24 00:09:06 --> Router Class Initialized
INFO - 2016-09-24 00:09:06 --> Output Class Initialized
INFO - 2016-09-24 00:09:06 --> Output Class Initialized
INFO - 2016-09-24 00:09:06 --> Security Class Initialized
INFO - 2016-09-24 00:09:06 --> Security Class Initialized
DEBUG - 2016-09-24 00:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:06 --> Input Class Initialized
DEBUG - 2016-09-24 00:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:06 --> Input Class Initialized
INFO - 2016-09-24 00:09:06 --> Language Class Initialized
INFO - 2016-09-24 00:09:06 --> Language Class Initialized
INFO - 2016-09-24 00:09:07 --> Loader Class Initialized
INFO - 2016-09-24 00:09:07 --> Loader Class Initialized
INFO - 2016-09-24 00:09:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:07 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:07 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:07 --> Controller Class Initialized
INFO - 2016-09-24 00:09:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:07 --> Model Class Initialized
INFO - 2016-09-24 00:09:07 --> Model Class Initialized
INFO - 2016-09-24 00:09:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:09:07 --> Final output sent to browser
DEBUG - 2016-09-24 00:09:07 --> Total execution time: 0.0794
INFO - 2016-09-24 00:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:07 --> Controller Class Initialized
INFO - 2016-09-24 00:09:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:07 --> Model Class Initialized
INFO - 2016-09-24 00:09:07 --> Model Class Initialized
INFO - 2016-09-24 00:09:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:09:17 --> Config Class Initialized
INFO - 2016-09-24 00:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:17 --> URI Class Initialized
INFO - 2016-09-24 00:09:17 --> Router Class Initialized
INFO - 2016-09-24 00:09:17 --> Output Class Initialized
INFO - 2016-09-24 00:09:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:17 --> Input Class Initialized
INFO - 2016-09-24 00:09:17 --> Language Class Initialized
ERROR - 2016-09-24 00:09:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:09:38 --> Config Class Initialized
INFO - 2016-09-24 00:09:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:38 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:38 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:38 --> Config Class Initialized
INFO - 2016-09-24 00:09:38 --> Hooks Class Initialized
INFO - 2016-09-24 00:09:38 --> URI Class Initialized
INFO - 2016-09-24 00:09:38 --> Router Class Initialized
DEBUG - 2016-09-24 00:09:38 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:38 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:38 --> Output Class Initialized
INFO - 2016-09-24 00:09:38 --> URI Class Initialized
INFO - 2016-09-24 00:09:38 --> Security Class Initialized
INFO - 2016-09-24 00:09:38 --> Router Class Initialized
DEBUG - 2016-09-24 00:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:38 --> Input Class Initialized
INFO - 2016-09-24 00:09:38 --> Output Class Initialized
INFO - 2016-09-24 00:09:38 --> Language Class Initialized
INFO - 2016-09-24 00:09:38 --> Security Class Initialized
INFO - 2016-09-24 00:09:38 --> Loader Class Initialized
DEBUG - 2016-09-24 00:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:38 --> Input Class Initialized
INFO - 2016-09-24 00:09:38 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:38 --> Language Class Initialized
INFO - 2016-09-24 00:09:38 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:38 --> Loader Class Initialized
INFO - 2016-09-24 00:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:38 --> Controller Class Initialized
INFO - 2016-09-24 00:09:38 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:38 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:38 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:38 --> Model Class Initialized
INFO - 2016-09-24 00:09:38 --> Model Class Initialized
INFO - 2016-09-24 00:09:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:09:38 --> Final output sent to browser
DEBUG - 2016-09-24 00:09:38 --> Total execution time: 0.0709
INFO - 2016-09-24 00:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:38 --> Controller Class Initialized
INFO - 2016-09-24 00:09:38 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:38 --> Model Class Initialized
INFO - 2016-09-24 00:09:38 --> Model Class Initialized
INFO - 2016-09-24 00:09:38 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:09:38 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:09:38 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:09:38 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:09:39 --> Config Class Initialized
INFO - 2016-09-24 00:09:39 --> Hooks Class Initialized
INFO - 2016-09-24 00:09:39 --> Config Class Initialized
INFO - 2016-09-24 00:09:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:09:39 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:39 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:39 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:39 --> URI Class Initialized
INFO - 2016-09-24 00:09:39 --> URI Class Initialized
INFO - 2016-09-24 00:09:39 --> Router Class Initialized
INFO - 2016-09-24 00:09:39 --> Router Class Initialized
INFO - 2016-09-24 00:09:39 --> Output Class Initialized
INFO - 2016-09-24 00:09:39 --> Output Class Initialized
INFO - 2016-09-24 00:09:39 --> Security Class Initialized
INFO - 2016-09-24 00:09:39 --> Security Class Initialized
DEBUG - 2016-09-24 00:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:39 --> Input Class Initialized
DEBUG - 2016-09-24 00:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:39 --> Input Class Initialized
INFO - 2016-09-24 00:09:39 --> Language Class Initialized
INFO - 2016-09-24 00:09:39 --> Language Class Initialized
INFO - 2016-09-24 00:09:39 --> Loader Class Initialized
INFO - 2016-09-24 00:09:39 --> Loader Class Initialized
INFO - 2016-09-24 00:09:39 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:39 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:39 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:39 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:39 --> Controller Class Initialized
INFO - 2016-09-24 00:09:39 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:09:39 --> Final output sent to browser
DEBUG - 2016-09-24 00:09:39 --> Total execution time: 0.0678
INFO - 2016-09-24 00:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:39 --> Controller Class Initialized
INFO - 2016-09-24 00:09:39 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:09:39 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:09:39 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:09:39 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:09:39 --> Config Class Initialized
INFO - 2016-09-24 00:09:39 --> Hooks Class Initialized
INFO - 2016-09-24 00:09:39 --> Config Class Initialized
INFO - 2016-09-24 00:09:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:39 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:39 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:39 --> URI Class Initialized
DEBUG - 2016-09-24 00:09:39 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:39 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:39 --> Router Class Initialized
INFO - 2016-09-24 00:09:39 --> URI Class Initialized
INFO - 2016-09-24 00:09:39 --> Output Class Initialized
INFO - 2016-09-24 00:09:39 --> Router Class Initialized
INFO - 2016-09-24 00:09:39 --> Security Class Initialized
INFO - 2016-09-24 00:09:39 --> Output Class Initialized
DEBUG - 2016-09-24 00:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:39 --> Input Class Initialized
INFO - 2016-09-24 00:09:39 --> Security Class Initialized
INFO - 2016-09-24 00:09:39 --> Language Class Initialized
DEBUG - 2016-09-24 00:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:39 --> Input Class Initialized
INFO - 2016-09-24 00:09:39 --> Loader Class Initialized
INFO - 2016-09-24 00:09:39 --> Language Class Initialized
INFO - 2016-09-24 00:09:39 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:39 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:39 --> Loader Class Initialized
INFO - 2016-09-24 00:09:39 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:39 --> Controller Class Initialized
INFO - 2016-09-24 00:09:39 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:39 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:09:39 --> Final output sent to browser
DEBUG - 2016-09-24 00:09:39 --> Total execution time: 0.0682
INFO - 2016-09-24 00:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:39 --> Controller Class Initialized
INFO - 2016-09-24 00:09:39 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Model Class Initialized
INFO - 2016-09-24 00:09:39 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:09:39 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:09:39 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:09:39 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:09:45 --> Config Class Initialized
INFO - 2016-09-24 00:09:45 --> Config Class Initialized
INFO - 2016-09-24 00:09:45 --> Hooks Class Initialized
INFO - 2016-09-24 00:09:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:45 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:09:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:45 --> URI Class Initialized
INFO - 2016-09-24 00:09:45 --> URI Class Initialized
INFO - 2016-09-24 00:09:45 --> Router Class Initialized
INFO - 2016-09-24 00:09:45 --> Router Class Initialized
INFO - 2016-09-24 00:09:45 --> Output Class Initialized
INFO - 2016-09-24 00:09:45 --> Output Class Initialized
INFO - 2016-09-24 00:09:45 --> Security Class Initialized
INFO - 2016-09-24 00:09:45 --> Security Class Initialized
DEBUG - 2016-09-24 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:45 --> Input Class Initialized
DEBUG - 2016-09-24 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:45 --> Input Class Initialized
INFO - 2016-09-24 00:09:45 --> Language Class Initialized
INFO - 2016-09-24 00:09:45 --> Language Class Initialized
INFO - 2016-09-24 00:09:45 --> Loader Class Initialized
INFO - 2016-09-24 00:09:45 --> Loader Class Initialized
INFO - 2016-09-24 00:09:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:09:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:45 --> Controller Class Initialized
INFO - 2016-09-24 00:09:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:45 --> Model Class Initialized
INFO - 2016-09-24 00:09:45 --> Model Class Initialized
INFO - 2016-09-24 00:09:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:09:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:09:45 --> Total execution time: 0.0706
INFO - 2016-09-24 00:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:09:45 --> Controller Class Initialized
INFO - 2016-09-24 00:09:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:09:45 --> Model Class Initialized
INFO - 2016-09-24 00:09:45 --> Model Class Initialized
INFO - 2016-09-24 00:09:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:09:45 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:09:45 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:09:45 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:09:47 --> Config Class Initialized
INFO - 2016-09-24 00:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:09:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:09:47 --> URI Class Initialized
INFO - 2016-09-24 00:09:47 --> Router Class Initialized
INFO - 2016-09-24 00:09:47 --> Output Class Initialized
INFO - 2016-09-24 00:09:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:09:47 --> Input Class Initialized
INFO - 2016-09-24 00:09:47 --> Language Class Initialized
ERROR - 2016-09-24 00:09:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:10:01 --> Config Class Initialized
INFO - 2016-09-24 00:10:01 --> Hooks Class Initialized
INFO - 2016-09-24 00:10:01 --> Config Class Initialized
INFO - 2016-09-24 00:10:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:10:01 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:01 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:01 --> URI Class Initialized
DEBUG - 2016-09-24 00:10:01 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:01 --> Router Class Initialized
INFO - 2016-09-24 00:10:01 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:01 --> URI Class Initialized
INFO - 2016-09-24 00:10:01 --> Output Class Initialized
INFO - 2016-09-24 00:10:01 --> Security Class Initialized
INFO - 2016-09-24 00:10:01 --> Router Class Initialized
DEBUG - 2016-09-24 00:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:01 --> Input Class Initialized
INFO - 2016-09-24 00:10:01 --> Output Class Initialized
INFO - 2016-09-24 00:10:01 --> Language Class Initialized
INFO - 2016-09-24 00:10:01 --> Security Class Initialized
INFO - 2016-09-24 00:10:01 --> Loader Class Initialized
DEBUG - 2016-09-24 00:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:01 --> Input Class Initialized
INFO - 2016-09-24 00:10:01 --> Language Class Initialized
INFO - 2016-09-24 00:10:01 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:01 --> Helper loaded: language_helper
INFO - 2016-09-24 00:10:01 --> Loader Class Initialized
INFO - 2016-09-24 00:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:01 --> Controller Class Initialized
INFO - 2016-09-24 00:10:01 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:01 --> Helper loaded: language_helper
INFO - 2016-09-24 00:10:01 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:01 --> Model Class Initialized
INFO - 2016-09-24 00:10:01 --> Model Class Initialized
INFO - 2016-09-24 00:10:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:10:01 --> Final output sent to browser
DEBUG - 2016-09-24 00:10:01 --> Total execution time: 0.0704
INFO - 2016-09-24 00:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:01 --> Controller Class Initialized
INFO - 2016-09-24 00:10:01 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:01 --> Model Class Initialized
INFO - 2016-09-24 00:10:01 --> Model Class Initialized
INFO - 2016-09-24 00:10:01 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:10:01 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:10:01 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:10:01 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:10:17 --> Config Class Initialized
INFO - 2016-09-24 00:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:17 --> URI Class Initialized
INFO - 2016-09-24 00:10:17 --> Router Class Initialized
INFO - 2016-09-24 00:10:17 --> Output Class Initialized
INFO - 2016-09-24 00:10:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:17 --> Input Class Initialized
INFO - 2016-09-24 00:10:17 --> Language Class Initialized
ERROR - 2016-09-24 00:10:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:10:36 --> Config Class Initialized
INFO - 2016-09-24 00:10:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:10:36 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:36 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:36 --> URI Class Initialized
INFO - 2016-09-24 00:10:36 --> Router Class Initialized
INFO - 2016-09-24 00:10:36 --> Config Class Initialized
INFO - 2016-09-24 00:10:36 --> Hooks Class Initialized
INFO - 2016-09-24 00:10:36 --> Output Class Initialized
INFO - 2016-09-24 00:10:36 --> Security Class Initialized
DEBUG - 2016-09-24 00:10:36 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:36 --> URI Class Initialized
INFO - 2016-09-24 00:10:36 --> Input Class Initialized
INFO - 2016-09-24 00:10:36 --> Language Class Initialized
INFO - 2016-09-24 00:10:36 --> Router Class Initialized
INFO - 2016-09-24 00:10:36 --> Output Class Initialized
INFO - 2016-09-24 00:10:36 --> Loader Class Initialized
INFO - 2016-09-24 00:10:36 --> Security Class Initialized
INFO - 2016-09-24 00:10:36 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:36 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:36 --> Input Class Initialized
INFO - 2016-09-24 00:10:36 --> Language Class Initialized
INFO - 2016-09-24 00:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:36 --> Controller Class Initialized
INFO - 2016-09-24 00:10:36 --> Loader Class Initialized
INFO - 2016-09-24 00:10:36 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:36 --> Helper loaded: language_helper
INFO - 2016-09-24 00:10:36 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:36 --> Model Class Initialized
INFO - 2016-09-24 00:10:36 --> Model Class Initialized
INFO - 2016-09-24 00:10:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:10:36 --> Final output sent to browser
DEBUG - 2016-09-24 00:10:36 --> Total execution time: 0.0692
INFO - 2016-09-24 00:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:36 --> Controller Class Initialized
INFO - 2016-09-24 00:10:36 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:36 --> Model Class Initialized
INFO - 2016-09-24 00:10:36 --> Model Class Initialized
INFO - 2016-09-24 00:10:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:10:36 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:10:36 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:10:36 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:10:41 --> Config Class Initialized
INFO - 2016-09-24 00:10:41 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:10:41 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:41 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:41 --> URI Class Initialized
INFO - 2016-09-24 00:10:41 --> Router Class Initialized
INFO - 2016-09-24 00:10:41 --> Output Class Initialized
INFO - 2016-09-24 00:10:41 --> Security Class Initialized
DEBUG - 2016-09-24 00:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:41 --> Input Class Initialized
INFO - 2016-09-24 00:10:41 --> Language Class Initialized
INFO - 2016-09-24 00:10:41 --> Loader Class Initialized
INFO - 2016-09-24 00:10:41 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:41 --> Helper loaded: language_helper
INFO - 2016-09-24 00:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:41 --> Controller Class Initialized
INFO - 2016-09-24 00:10:41 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:41 --> Model Class Initialized
INFO - 2016-09-24 00:10:41 --> Model Class Initialized
INFO - 2016-09-24 00:10:41 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:10:41 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 670
ERROR - 2016-09-24 00:10:41 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:10:41 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:10:43 --> Config Class Initialized
INFO - 2016-09-24 00:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:10:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:43 --> URI Class Initialized
INFO - 2016-09-24 00:10:43 --> Router Class Initialized
INFO - 2016-09-24 00:10:43 --> Output Class Initialized
INFO - 2016-09-24 00:10:43 --> Security Class Initialized
INFO - 2016-09-24 00:10:43 --> Config Class Initialized
DEBUG - 2016-09-24 00:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:43 --> Hooks Class Initialized
INFO - 2016-09-24 00:10:43 --> Input Class Initialized
INFO - 2016-09-24 00:10:43 --> Language Class Initialized
DEBUG - 2016-09-24 00:10:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:43 --> Utf8 Class Initialized
ERROR - 2016-09-24 00:10:43 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:10:43 --> URI Class Initialized
INFO - 2016-09-24 00:10:43 --> Router Class Initialized
INFO - 2016-09-24 00:10:43 --> Config Class Initialized
INFO - 2016-09-24 00:10:43 --> Hooks Class Initialized
INFO - 2016-09-24 00:10:43 --> Output Class Initialized
INFO - 2016-09-24 00:10:43 --> Security Class Initialized
DEBUG - 2016-09-24 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:43 --> Input Class Initialized
INFO - 2016-09-24 00:10:43 --> Language Class Initialized
INFO - 2016-09-24 00:10:43 --> URI Class Initialized
INFO - 2016-09-24 00:10:43 --> Router Class Initialized
INFO - 2016-09-24 00:10:43 --> Loader Class Initialized
INFO - 2016-09-24 00:10:43 --> Output Class Initialized
INFO - 2016-09-24 00:10:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:43 --> Security Class Initialized
INFO - 2016-09-24 00:10:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:43 --> Input Class Initialized
INFO - 2016-09-24 00:10:43 --> Language Class Initialized
INFO - 2016-09-24 00:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:43 --> Controller Class Initialized
INFO - 2016-09-24 00:10:43 --> Loader Class Initialized
INFO - 2016-09-24 00:10:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:43 --> Helper loaded: language_helper
INFO - 2016-09-24 00:10:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:43 --> Controller Class Initialized
INFO - 2016-09-24 00:10:43 --> Model Class Initialized
INFO - 2016-09-24 00:10:43 --> Model Class Initialized
INFO - 2016-09-24 00:10:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:10:43 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 189
INFO - 2016-09-24 00:10:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 00:10:43 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1474656043, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` = 67
INFO - 2016-09-24 00:10:43 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:10:43 --> Model Class Initialized
INFO - 2016-09-24 00:10:43 --> Model Class Initialized
INFO - 2016-09-24 00:10:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:10:43 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 00:10:43 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('67', NULL, '1', 'hewan', 0)
INFO - 2016-09-24 00:10:43 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 00:10:56 --> Config Class Initialized
INFO - 2016-09-24 00:10:56 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:10:56 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:10:56 --> Utf8 Class Initialized
INFO - 2016-09-24 00:10:56 --> URI Class Initialized
INFO - 2016-09-24 00:10:56 --> Router Class Initialized
INFO - 2016-09-24 00:10:56 --> Output Class Initialized
INFO - 2016-09-24 00:10:56 --> Security Class Initialized
DEBUG - 2016-09-24 00:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:10:56 --> Input Class Initialized
INFO - 2016-09-24 00:10:56 --> Language Class Initialized
INFO - 2016-09-24 00:10:56 --> Loader Class Initialized
INFO - 2016-09-24 00:10:56 --> Helper loaded: url_helper
INFO - 2016-09-24 00:10:56 --> Helper loaded: language_helper
INFO - 2016-09-24 00:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:10:56 --> Controller Class Initialized
INFO - 2016-09-24 00:10:56 --> Database Driver Class Initialized
INFO - 2016-09-24 00:10:56 --> Model Class Initialized
INFO - 2016-09-24 00:10:56 --> Model Class Initialized
INFO - 2016-09-24 00:10:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:10:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:10:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2016-09-24 00:10:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:10:56 --> Final output sent to browser
DEBUG - 2016-09-24 00:10:56 --> Total execution time: 0.0720
INFO - 2016-09-24 00:11:17 --> Config Class Initialized
INFO - 2016-09-24 00:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:17 --> URI Class Initialized
INFO - 2016-09-24 00:11:17 --> Router Class Initialized
INFO - 2016-09-24 00:11:17 --> Output Class Initialized
INFO - 2016-09-24 00:11:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:17 --> Input Class Initialized
INFO - 2016-09-24 00:11:17 --> Language Class Initialized
INFO - 2016-09-24 00:11:17 --> Loader Class Initialized
INFO - 2016-09-24 00:11:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:11:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:11:17 --> Controller Class Initialized
INFO - 2016-09-24 00:11:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:11:17 --> Config Class Initialized
INFO - 2016-09-24 00:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:17 --> URI Class Initialized
INFO - 2016-09-24 00:11:17 --> Router Class Initialized
INFO - 2016-09-24 00:11:17 --> Output Class Initialized
INFO - 2016-09-24 00:11:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:17 --> Input Class Initialized
INFO - 2016-09-24 00:11:17 --> Language Class Initialized
INFO - 2016-09-24 00:11:17 --> Loader Class Initialized
INFO - 2016-09-24 00:11:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:11:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:11:17 --> Controller Class Initialized
INFO - 2016-09-24 00:11:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-24 00:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:11:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:11:17 --> Total execution time: 0.0653
INFO - 2016-09-24 00:11:17 --> Config Class Initialized
INFO - 2016-09-24 00:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:17 --> URI Class Initialized
INFO - 2016-09-24 00:11:17 --> Config Class Initialized
INFO - 2016-09-24 00:11:17 --> Hooks Class Initialized
INFO - 2016-09-24 00:11:17 --> Router Class Initialized
INFO - 2016-09-24 00:11:17 --> Output Class Initialized
DEBUG - 2016-09-24 00:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:17 --> Security Class Initialized
INFO - 2016-09-24 00:11:17 --> URI Class Initialized
DEBUG - 2016-09-24 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:17 --> Input Class Initialized
INFO - 2016-09-24 00:11:17 --> Router Class Initialized
INFO - 2016-09-24 00:11:17 --> Language Class Initialized
INFO - 2016-09-24 00:11:17 --> Output Class Initialized
INFO - 2016-09-24 00:11:17 --> Security Class Initialized
INFO - 2016-09-24 00:11:17 --> Loader Class Initialized
DEBUG - 2016-09-24 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:17 --> Input Class Initialized
INFO - 2016-09-24 00:11:17 --> Language Class Initialized
INFO - 2016-09-24 00:11:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:11:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:11:17 --> Loader Class Initialized
INFO - 2016-09-24 00:11:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:11:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:11:17 --> Controller Class Initialized
INFO - 2016-09-24 00:11:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:11:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:11:17 --> Total execution time: 0.0889
INFO - 2016-09-24 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:11:17 --> Controller Class Initialized
INFO - 2016-09-24 00:11:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Model Class Initialized
INFO - 2016-09-24 00:11:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:11:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:11:17 --> Total execution time: 0.1356
INFO - 2016-09-24 00:11:25 --> Config Class Initialized
INFO - 2016-09-24 00:11:25 --> Hooks Class Initialized
INFO - 2016-09-24 00:11:25 --> Config Class Initialized
INFO - 2016-09-24 00:11:25 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:11:25 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:25 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:25 --> URI Class Initialized
DEBUG - 2016-09-24 00:11:25 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:25 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:25 --> Router Class Initialized
INFO - 2016-09-24 00:11:25 --> URI Class Initialized
INFO - 2016-09-24 00:11:25 --> Output Class Initialized
INFO - 2016-09-24 00:11:25 --> Router Class Initialized
INFO - 2016-09-24 00:11:25 --> Security Class Initialized
INFO - 2016-09-24 00:11:25 --> Output Class Initialized
DEBUG - 2016-09-24 00:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:25 --> Input Class Initialized
INFO - 2016-09-24 00:11:25 --> Language Class Initialized
INFO - 2016-09-24 00:11:25 --> Security Class Initialized
DEBUG - 2016-09-24 00:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:25 --> Input Class Initialized
INFO - 2016-09-24 00:11:25 --> Loader Class Initialized
INFO - 2016-09-24 00:11:25 --> Language Class Initialized
INFO - 2016-09-24 00:11:25 --> Helper loaded: url_helper
INFO - 2016-09-24 00:11:25 --> Helper loaded: language_helper
INFO - 2016-09-24 00:11:25 --> Loader Class Initialized
INFO - 2016-09-24 00:11:25 --> Helper loaded: url_helper
INFO - 2016-09-24 00:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:11:25 --> Controller Class Initialized
INFO - 2016-09-24 00:11:25 --> Helper loaded: language_helper
INFO - 2016-09-24 00:11:25 --> Database Driver Class Initialized
INFO - 2016-09-24 00:11:25 --> Model Class Initialized
INFO - 2016-09-24 00:11:25 --> Model Class Initialized
INFO - 2016-09-24 00:11:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:11:25 --> Final output sent to browser
DEBUG - 2016-09-24 00:11:25 --> Total execution time: 0.0722
INFO - 2016-09-24 00:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:11:25 --> Controller Class Initialized
INFO - 2016-09-24 00:11:25 --> Database Driver Class Initialized
INFO - 2016-09-24 00:11:25 --> Model Class Initialized
INFO - 2016-09-24 00:11:25 --> Model Class Initialized
INFO - 2016-09-24 00:11:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:11:25 --> Final output sent to browser
DEBUG - 2016-09-24 00:11:25 --> Total execution time: 0.1111
INFO - 2016-09-24 00:11:47 --> Config Class Initialized
INFO - 2016-09-24 00:11:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:11:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:11:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:11:47 --> URI Class Initialized
INFO - 2016-09-24 00:11:47 --> Router Class Initialized
INFO - 2016-09-24 00:11:47 --> Output Class Initialized
INFO - 2016-09-24 00:11:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:11:47 --> Input Class Initialized
INFO - 2016-09-24 00:11:47 --> Language Class Initialized
ERROR - 2016-09-24 00:11:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:12:17 --> Config Class Initialized
INFO - 2016-09-24 00:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:12:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:12:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:12:17 --> URI Class Initialized
INFO - 2016-09-24 00:12:17 --> Router Class Initialized
INFO - 2016-09-24 00:12:17 --> Output Class Initialized
INFO - 2016-09-24 00:12:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:12:17 --> Input Class Initialized
INFO - 2016-09-24 00:12:17 --> Language Class Initialized
ERROR - 2016-09-24 00:12:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:12:47 --> Config Class Initialized
INFO - 2016-09-24 00:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:12:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:12:47 --> URI Class Initialized
INFO - 2016-09-24 00:12:47 --> Router Class Initialized
INFO - 2016-09-24 00:12:47 --> Output Class Initialized
INFO - 2016-09-24 00:12:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:12:47 --> Input Class Initialized
INFO - 2016-09-24 00:12:47 --> Language Class Initialized
ERROR - 2016-09-24 00:12:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:13:17 --> Config Class Initialized
INFO - 2016-09-24 00:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:13:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:13:17 --> URI Class Initialized
INFO - 2016-09-24 00:13:17 --> Router Class Initialized
INFO - 2016-09-24 00:13:17 --> Output Class Initialized
INFO - 2016-09-24 00:13:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:13:17 --> Input Class Initialized
INFO - 2016-09-24 00:13:17 --> Language Class Initialized
ERROR - 2016-09-24 00:13:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:13:47 --> Config Class Initialized
INFO - 2016-09-24 00:13:47 --> Hooks Class Initialized
INFO - 2016-09-24 00:13:47 --> Config Class Initialized
INFO - 2016-09-24 00:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:13:47 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:13:47 --> URI Class Initialized
INFO - 2016-09-24 00:13:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:13:47 --> URI Class Initialized
INFO - 2016-09-24 00:13:47 --> Router Class Initialized
INFO - 2016-09-24 00:13:47 --> Router Class Initialized
INFO - 2016-09-24 00:13:47 --> Output Class Initialized
INFO - 2016-09-24 00:13:47 --> Security Class Initialized
INFO - 2016-09-24 00:13:47 --> Output Class Initialized
INFO - 2016-09-24 00:13:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:13:47 --> Input Class Initialized
INFO - 2016-09-24 00:13:47 --> Language Class Initialized
DEBUG - 2016-09-24 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:13:47 --> Input Class Initialized
INFO - 2016-09-24 00:13:47 --> Language Class Initialized
INFO - 2016-09-24 00:13:47 --> Loader Class Initialized
INFO - 2016-09-24 00:13:47 --> Helper loaded: url_helper
INFO - 2016-09-24 00:13:47 --> Helper loaded: language_helper
INFO - 2016-09-24 00:13:47 --> Loader Class Initialized
INFO - 2016-09-24 00:13:47 --> Helper loaded: url_helper
INFO - 2016-09-24 00:13:47 --> Helper loaded: language_helper
INFO - 2016-09-24 00:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:13:47 --> Controller Class Initialized
INFO - 2016-09-24 00:13:47 --> Database Driver Class Initialized
INFO - 2016-09-24 00:13:47 --> Model Class Initialized
INFO - 2016-09-24 00:13:47 --> Model Class Initialized
INFO - 2016-09-24 00:13:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:13:47 --> Final output sent to browser
DEBUG - 2016-09-24 00:13:47 --> Total execution time: 0.0626
INFO - 2016-09-24 00:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:13:47 --> Controller Class Initialized
INFO - 2016-09-24 00:13:47 --> Database Driver Class Initialized
INFO - 2016-09-24 00:13:47 --> Model Class Initialized
INFO - 2016-09-24 00:13:47 --> Model Class Initialized
INFO - 2016-09-24 00:13:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:13:47 --> Final output sent to browser
DEBUG - 2016-09-24 00:13:47 --> Total execution time: 0.1120
INFO - 2016-09-24 00:13:47 --> Config Class Initialized
INFO - 2016-09-24 00:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:13:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:13:47 --> URI Class Initialized
INFO - 2016-09-24 00:13:47 --> Router Class Initialized
INFO - 2016-09-24 00:13:47 --> Output Class Initialized
INFO - 2016-09-24 00:13:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:13:47 --> Input Class Initialized
INFO - 2016-09-24 00:13:47 --> Language Class Initialized
ERROR - 2016-09-24 00:13:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:13:53 --> Config Class Initialized
INFO - 2016-09-24 00:13:53 --> Hooks Class Initialized
INFO - 2016-09-24 00:13:53 --> Config Class Initialized
INFO - 2016-09-24 00:13:53 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:13:53 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:13:53 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:13:53 --> URI Class Initialized
INFO - 2016-09-24 00:13:53 --> Utf8 Class Initialized
INFO - 2016-09-24 00:13:53 --> URI Class Initialized
INFO - 2016-09-24 00:13:53 --> Router Class Initialized
INFO - 2016-09-24 00:13:53 --> Router Class Initialized
INFO - 2016-09-24 00:13:53 --> Output Class Initialized
INFO - 2016-09-24 00:13:53 --> Security Class Initialized
INFO - 2016-09-24 00:13:53 --> Output Class Initialized
DEBUG - 2016-09-24 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:13:53 --> Input Class Initialized
INFO - 2016-09-24 00:13:53 --> Security Class Initialized
INFO - 2016-09-24 00:13:53 --> Language Class Initialized
DEBUG - 2016-09-24 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:13:53 --> Input Class Initialized
INFO - 2016-09-24 00:13:53 --> Language Class Initialized
INFO - 2016-09-24 00:13:53 --> Loader Class Initialized
INFO - 2016-09-24 00:13:53 --> Helper loaded: url_helper
INFO - 2016-09-24 00:13:53 --> Helper loaded: language_helper
INFO - 2016-09-24 00:13:53 --> Loader Class Initialized
INFO - 2016-09-24 00:13:53 --> Helper loaded: url_helper
INFO - 2016-09-24 00:13:53 --> Helper loaded: language_helper
INFO - 2016-09-24 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:13:53 --> Controller Class Initialized
INFO - 2016-09-24 00:13:53 --> Database Driver Class Initialized
INFO - 2016-09-24 00:13:53 --> Model Class Initialized
INFO - 2016-09-24 00:13:53 --> Model Class Initialized
INFO - 2016-09-24 00:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:13:53 --> Final output sent to browser
DEBUG - 2016-09-24 00:13:53 --> Total execution time: 0.0658
INFO - 2016-09-24 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:13:53 --> Controller Class Initialized
INFO - 2016-09-24 00:13:53 --> Database Driver Class Initialized
INFO - 2016-09-24 00:13:53 --> Model Class Initialized
INFO - 2016-09-24 00:13:53 --> Model Class Initialized
INFO - 2016-09-24 00:13:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:13:53 --> Final output sent to browser
DEBUG - 2016-09-24 00:13:53 --> Total execution time: 0.1094
INFO - 2016-09-24 00:14:17 --> Config Class Initialized
INFO - 2016-09-24 00:14:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:14:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:14:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:14:17 --> URI Class Initialized
INFO - 2016-09-24 00:14:17 --> Router Class Initialized
INFO - 2016-09-24 00:14:17 --> Output Class Initialized
INFO - 2016-09-24 00:14:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:14:17 --> Input Class Initialized
INFO - 2016-09-24 00:14:17 --> Language Class Initialized
ERROR - 2016-09-24 00:14:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:14:23 --> Config Class Initialized
INFO - 2016-09-24 00:14:23 --> Hooks Class Initialized
INFO - 2016-09-24 00:14:23 --> Config Class Initialized
INFO - 2016-09-24 00:14:23 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:14:23 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:14:23 --> Utf8 Class Initialized
INFO - 2016-09-24 00:14:23 --> URI Class Initialized
INFO - 2016-09-24 00:14:23 --> Router Class Initialized
DEBUG - 2016-09-24 00:14:23 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:14:23 --> Output Class Initialized
INFO - 2016-09-24 00:14:23 --> Utf8 Class Initialized
INFO - 2016-09-24 00:14:23 --> Security Class Initialized
INFO - 2016-09-24 00:14:23 --> URI Class Initialized
DEBUG - 2016-09-24 00:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:14:23 --> Input Class Initialized
INFO - 2016-09-24 00:14:23 --> Router Class Initialized
INFO - 2016-09-24 00:14:23 --> Language Class Initialized
INFO - 2016-09-24 00:14:23 --> Output Class Initialized
INFO - 2016-09-24 00:14:23 --> Security Class Initialized
INFO - 2016-09-24 00:14:23 --> Loader Class Initialized
INFO - 2016-09-24 00:14:23 --> Helper loaded: url_helper
DEBUG - 2016-09-24 00:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:14:23 --> Input Class Initialized
INFO - 2016-09-24 00:14:23 --> Helper loaded: language_helper
INFO - 2016-09-24 00:14:23 --> Language Class Initialized
INFO - 2016-09-24 00:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:14:23 --> Controller Class Initialized
INFO - 2016-09-24 00:14:23 --> Loader Class Initialized
INFO - 2016-09-24 00:14:23 --> Helper loaded: url_helper
INFO - 2016-09-24 00:14:23 --> Helper loaded: language_helper
INFO - 2016-09-24 00:14:23 --> Database Driver Class Initialized
INFO - 2016-09-24 00:14:23 --> Model Class Initialized
INFO - 2016-09-24 00:14:23 --> Model Class Initialized
INFO - 2016-09-24 00:14:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:14:23 --> Final output sent to browser
DEBUG - 2016-09-24 00:14:23 --> Total execution time: 0.0690
INFO - 2016-09-24 00:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:14:23 --> Controller Class Initialized
INFO - 2016-09-24 00:14:23 --> Database Driver Class Initialized
INFO - 2016-09-24 00:14:23 --> Model Class Initialized
INFO - 2016-09-24 00:14:23 --> Model Class Initialized
INFO - 2016-09-24 00:14:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:14:23 --> Final output sent to browser
DEBUG - 2016-09-24 00:14:23 --> Total execution time: 0.1146
INFO - 2016-09-24 00:14:26 --> Config Class Initialized
INFO - 2016-09-24 00:14:26 --> Hooks Class Initialized
INFO - 2016-09-24 00:14:26 --> Config Class Initialized
INFO - 2016-09-24 00:14:26 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:14:26 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:14:26 --> Utf8 Class Initialized
INFO - 2016-09-24 00:14:26 --> URI Class Initialized
DEBUG - 2016-09-24 00:14:26 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:14:26 --> Utf8 Class Initialized
INFO - 2016-09-24 00:14:26 --> URI Class Initialized
INFO - 2016-09-24 00:14:26 --> Router Class Initialized
INFO - 2016-09-24 00:14:26 --> Router Class Initialized
INFO - 2016-09-24 00:14:26 --> Output Class Initialized
INFO - 2016-09-24 00:14:26 --> Security Class Initialized
INFO - 2016-09-24 00:14:26 --> Output Class Initialized
INFO - 2016-09-24 00:14:26 --> Security Class Initialized
DEBUG - 2016-09-24 00:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:14:26 --> Input Class Initialized
INFO - 2016-09-24 00:14:26 --> Language Class Initialized
DEBUG - 2016-09-24 00:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:14:26 --> Input Class Initialized
INFO - 2016-09-24 00:14:26 --> Language Class Initialized
INFO - 2016-09-24 00:14:26 --> Loader Class Initialized
INFO - 2016-09-24 00:14:26 --> Loader Class Initialized
INFO - 2016-09-24 00:14:26 --> Helper loaded: url_helper
INFO - 2016-09-24 00:14:26 --> Helper loaded: url_helper
INFO - 2016-09-24 00:14:26 --> Helper loaded: language_helper
INFO - 2016-09-24 00:14:26 --> Helper loaded: language_helper
INFO - 2016-09-24 00:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:14:26 --> Controller Class Initialized
INFO - 2016-09-24 00:14:26 --> Database Driver Class Initialized
INFO - 2016-09-24 00:14:26 --> Model Class Initialized
INFO - 2016-09-24 00:14:26 --> Model Class Initialized
INFO - 2016-09-24 00:14:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:14:26 --> Final output sent to browser
DEBUG - 2016-09-24 00:14:26 --> Total execution time: 0.0948
INFO - 2016-09-24 00:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:14:26 --> Controller Class Initialized
INFO - 2016-09-24 00:14:26 --> Database Driver Class Initialized
INFO - 2016-09-24 00:14:26 --> Model Class Initialized
INFO - 2016-09-24 00:14:26 --> Model Class Initialized
INFO - 2016-09-24 00:14:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:14:26 --> Final output sent to browser
DEBUG - 2016-09-24 00:14:26 --> Total execution time: 0.1259
INFO - 2016-09-24 00:14:47 --> Config Class Initialized
INFO - 2016-09-24 00:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:14:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:14:47 --> URI Class Initialized
INFO - 2016-09-24 00:14:47 --> Router Class Initialized
INFO - 2016-09-24 00:14:47 --> Output Class Initialized
INFO - 2016-09-24 00:14:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:14:47 --> Input Class Initialized
INFO - 2016-09-24 00:14:47 --> Language Class Initialized
ERROR - 2016-09-24 00:14:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:15:17 --> Config Class Initialized
INFO - 2016-09-24 00:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:15:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:15:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:15:17 --> URI Class Initialized
INFO - 2016-09-24 00:15:17 --> Router Class Initialized
INFO - 2016-09-24 00:15:17 --> Output Class Initialized
INFO - 2016-09-24 00:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:15:17 --> Input Class Initialized
INFO - 2016-09-24 00:15:17 --> Language Class Initialized
ERROR - 2016-09-24 00:15:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:15:47 --> Config Class Initialized
INFO - 2016-09-24 00:15:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:15:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:15:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:15:47 --> URI Class Initialized
INFO - 2016-09-24 00:15:47 --> Router Class Initialized
INFO - 2016-09-24 00:15:47 --> Output Class Initialized
INFO - 2016-09-24 00:15:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:15:47 --> Input Class Initialized
INFO - 2016-09-24 00:15:47 --> Language Class Initialized
ERROR - 2016-09-24 00:15:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:16:17 --> Config Class Initialized
INFO - 2016-09-24 00:16:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:16:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:16:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:16:17 --> URI Class Initialized
INFO - 2016-09-24 00:16:17 --> Router Class Initialized
INFO - 2016-09-24 00:16:17 --> Output Class Initialized
INFO - 2016-09-24 00:16:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:16:17 --> Input Class Initialized
INFO - 2016-09-24 00:16:17 --> Language Class Initialized
ERROR - 2016-09-24 00:16:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:16:47 --> Config Class Initialized
INFO - 2016-09-24 00:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:16:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:16:47 --> URI Class Initialized
INFO - 2016-09-24 00:16:47 --> Router Class Initialized
INFO - 2016-09-24 00:16:47 --> Output Class Initialized
INFO - 2016-09-24 00:16:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:16:47 --> Input Class Initialized
INFO - 2016-09-24 00:16:47 --> Language Class Initialized
ERROR - 2016-09-24 00:16:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:17:17 --> Config Class Initialized
INFO - 2016-09-24 00:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:17:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:17:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:17:17 --> URI Class Initialized
INFO - 2016-09-24 00:17:17 --> Router Class Initialized
INFO - 2016-09-24 00:17:17 --> Output Class Initialized
INFO - 2016-09-24 00:17:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:17:17 --> Input Class Initialized
INFO - 2016-09-24 00:17:17 --> Language Class Initialized
ERROR - 2016-09-24 00:17:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:17:47 --> Config Class Initialized
INFO - 2016-09-24 00:17:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:17:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:17:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:17:47 --> URI Class Initialized
INFO - 2016-09-24 00:17:47 --> Router Class Initialized
INFO - 2016-09-24 00:17:47 --> Output Class Initialized
INFO - 2016-09-24 00:17:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:17:47 --> Input Class Initialized
INFO - 2016-09-24 00:17:47 --> Language Class Initialized
ERROR - 2016-09-24 00:17:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:18:17 --> Config Class Initialized
INFO - 2016-09-24 00:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:18:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:18:17 --> URI Class Initialized
INFO - 2016-09-24 00:18:17 --> Router Class Initialized
INFO - 2016-09-24 00:18:17 --> Output Class Initialized
INFO - 2016-09-24 00:18:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:18:17 --> Input Class Initialized
INFO - 2016-09-24 00:18:17 --> Language Class Initialized
ERROR - 2016-09-24 00:18:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:18:47 --> Config Class Initialized
INFO - 2016-09-24 00:18:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:18:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:18:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:18:47 --> URI Class Initialized
INFO - 2016-09-24 00:18:47 --> Router Class Initialized
INFO - 2016-09-24 00:18:47 --> Output Class Initialized
INFO - 2016-09-24 00:18:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:18:47 --> Input Class Initialized
INFO - 2016-09-24 00:18:47 --> Language Class Initialized
ERROR - 2016-09-24 00:18:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:19:17 --> Config Class Initialized
INFO - 2016-09-24 00:19:17 --> Config Class Initialized
INFO - 2016-09-24 00:19:17 --> Hooks Class Initialized
INFO - 2016-09-24 00:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:19:17 --> URI Class Initialized
INFO - 2016-09-24 00:19:17 --> Router Class Initialized
DEBUG - 2016-09-24 00:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:19:17 --> URI Class Initialized
INFO - 2016-09-24 00:19:17 --> Output Class Initialized
INFO - 2016-09-24 00:19:17 --> Security Class Initialized
INFO - 2016-09-24 00:19:17 --> Router Class Initialized
DEBUG - 2016-09-24 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:19:17 --> Input Class Initialized
INFO - 2016-09-24 00:19:17 --> Output Class Initialized
INFO - 2016-09-24 00:19:17 --> Language Class Initialized
INFO - 2016-09-24 00:19:17 --> Security Class Initialized
INFO - 2016-09-24 00:19:17 --> Loader Class Initialized
DEBUG - 2016-09-24 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:19:17 --> Input Class Initialized
INFO - 2016-09-24 00:19:17 --> Language Class Initialized
INFO - 2016-09-24 00:19:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:19:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:19:17 --> Loader Class Initialized
INFO - 2016-09-24 00:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:19:17 --> Controller Class Initialized
INFO - 2016-09-24 00:19:17 --> Helper loaded: url_helper
INFO - 2016-09-24 00:19:17 --> Helper loaded: language_helper
INFO - 2016-09-24 00:19:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:19:17 --> Model Class Initialized
INFO - 2016-09-24 00:19:17 --> Model Class Initialized
INFO - 2016-09-24 00:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:19:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:19:17 --> Total execution time: 0.0746
INFO - 2016-09-24 00:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:19:17 --> Controller Class Initialized
INFO - 2016-09-24 00:19:17 --> Database Driver Class Initialized
INFO - 2016-09-24 00:19:17 --> Model Class Initialized
INFO - 2016-09-24 00:19:17 --> Model Class Initialized
INFO - 2016-09-24 00:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:19:17 --> Final output sent to browser
DEBUG - 2016-09-24 00:19:17 --> Total execution time: 0.1300
INFO - 2016-09-24 00:19:17 --> Config Class Initialized
INFO - 2016-09-24 00:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:19:17 --> URI Class Initialized
INFO - 2016-09-24 00:19:17 --> Router Class Initialized
INFO - 2016-09-24 00:19:17 --> Output Class Initialized
INFO - 2016-09-24 00:19:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:19:17 --> Input Class Initialized
INFO - 2016-09-24 00:19:17 --> Language Class Initialized
ERROR - 2016-09-24 00:19:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:19:25 --> Config Class Initialized
INFO - 2016-09-24 00:19:25 --> Config Class Initialized
INFO - 2016-09-24 00:19:25 --> Hooks Class Initialized
INFO - 2016-09-24 00:19:25 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:19:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:19:25 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:19:25 --> Utf8 Class Initialized
INFO - 2016-09-24 00:19:25 --> Utf8 Class Initialized
INFO - 2016-09-24 00:19:25 --> URI Class Initialized
INFO - 2016-09-24 00:19:25 --> URI Class Initialized
INFO - 2016-09-24 00:19:25 --> Router Class Initialized
INFO - 2016-09-24 00:19:25 --> Router Class Initialized
INFO - 2016-09-24 00:19:25 --> Output Class Initialized
INFO - 2016-09-24 00:19:25 --> Output Class Initialized
INFO - 2016-09-24 00:19:25 --> Security Class Initialized
INFO - 2016-09-24 00:19:25 --> Security Class Initialized
DEBUG - 2016-09-24 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:19:25 --> Input Class Initialized
DEBUG - 2016-09-24 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:19:25 --> Input Class Initialized
INFO - 2016-09-24 00:19:25 --> Language Class Initialized
INFO - 2016-09-24 00:19:25 --> Language Class Initialized
INFO - 2016-09-24 00:19:25 --> Loader Class Initialized
INFO - 2016-09-24 00:19:25 --> Helper loaded: url_helper
INFO - 2016-09-24 00:19:25 --> Loader Class Initialized
INFO - 2016-09-24 00:19:25 --> Helper loaded: language_helper
INFO - 2016-09-24 00:19:25 --> Helper loaded: url_helper
INFO - 2016-09-24 00:19:25 --> Helper loaded: language_helper
INFO - 2016-09-24 00:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:19:25 --> Controller Class Initialized
INFO - 2016-09-24 00:19:25 --> Database Driver Class Initialized
INFO - 2016-09-24 00:19:25 --> Model Class Initialized
INFO - 2016-09-24 00:19:25 --> Model Class Initialized
INFO - 2016-09-24 00:19:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:19:25 --> Final output sent to browser
DEBUG - 2016-09-24 00:19:25 --> Total execution time: 0.0663
INFO - 2016-09-24 00:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:19:25 --> Controller Class Initialized
INFO - 2016-09-24 00:19:25 --> Database Driver Class Initialized
INFO - 2016-09-24 00:19:25 --> Model Class Initialized
INFO - 2016-09-24 00:19:25 --> Model Class Initialized
INFO - 2016-09-24 00:19:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:19:25 --> Final output sent to browser
DEBUG - 2016-09-24 00:19:25 --> Total execution time: 0.1258
INFO - 2016-09-24 00:19:47 --> Config Class Initialized
INFO - 2016-09-24 00:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:19:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:19:47 --> URI Class Initialized
INFO - 2016-09-24 00:19:47 --> Router Class Initialized
INFO - 2016-09-24 00:19:47 --> Output Class Initialized
INFO - 2016-09-24 00:19:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:19:47 --> Input Class Initialized
INFO - 2016-09-24 00:19:47 --> Language Class Initialized
ERROR - 2016-09-24 00:19:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:20:17 --> Config Class Initialized
INFO - 2016-09-24 00:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:20:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:20:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:20:17 --> URI Class Initialized
INFO - 2016-09-24 00:20:17 --> Router Class Initialized
INFO - 2016-09-24 00:20:17 --> Output Class Initialized
INFO - 2016-09-24 00:20:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:20:17 --> Input Class Initialized
INFO - 2016-09-24 00:20:17 --> Language Class Initialized
ERROR - 2016-09-24 00:20:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:20:47 --> Config Class Initialized
INFO - 2016-09-24 00:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:20:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:20:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:20:47 --> URI Class Initialized
INFO - 2016-09-24 00:20:47 --> Router Class Initialized
INFO - 2016-09-24 00:20:47 --> Output Class Initialized
INFO - 2016-09-24 00:20:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:20:47 --> Input Class Initialized
INFO - 2016-09-24 00:20:47 --> Language Class Initialized
ERROR - 2016-09-24 00:20:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:21:16 --> Config Class Initialized
INFO - 2016-09-24 00:21:16 --> Config Class Initialized
INFO - 2016-09-24 00:21:16 --> Hooks Class Initialized
INFO - 2016-09-24 00:21:16 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:21:16 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:16 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:21:16 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:16 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:16 --> URI Class Initialized
INFO - 2016-09-24 00:21:16 --> URI Class Initialized
INFO - 2016-09-24 00:21:16 --> Router Class Initialized
INFO - 2016-09-24 00:21:16 --> Router Class Initialized
INFO - 2016-09-24 00:21:16 --> Output Class Initialized
INFO - 2016-09-24 00:21:16 --> Output Class Initialized
INFO - 2016-09-24 00:21:16 --> Security Class Initialized
INFO - 2016-09-24 00:21:16 --> Security Class Initialized
DEBUG - 2016-09-24 00:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-24 00:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:16 --> Input Class Initialized
INFO - 2016-09-24 00:21:16 --> Input Class Initialized
INFO - 2016-09-24 00:21:16 --> Language Class Initialized
INFO - 2016-09-24 00:21:16 --> Language Class Initialized
INFO - 2016-09-24 00:21:16 --> Loader Class Initialized
INFO - 2016-09-24 00:21:16 --> Loader Class Initialized
INFO - 2016-09-24 00:21:16 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:16 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:16 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:16 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:16 --> Controller Class Initialized
INFO - 2016-09-24 00:21:16 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:16 --> Model Class Initialized
INFO - 2016-09-24 00:21:16 --> Model Class Initialized
INFO - 2016-09-24 00:21:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:16 --> Final output sent to browser
DEBUG - 2016-09-24 00:21:16 --> Total execution time: 0.0707
INFO - 2016-09-24 00:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:16 --> Controller Class Initialized
INFO - 2016-09-24 00:21:16 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:16 --> Model Class Initialized
INFO - 2016-09-24 00:21:16 --> Model Class Initialized
INFO - 2016-09-24 00:21:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:17 --> Config Class Initialized
INFO - 2016-09-24 00:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:17 --> URI Class Initialized
INFO - 2016-09-24 00:21:17 --> Router Class Initialized
INFO - 2016-09-24 00:21:17 --> Output Class Initialized
INFO - 2016-09-24 00:21:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:17 --> Input Class Initialized
INFO - 2016-09-24 00:21:17 --> Language Class Initialized
ERROR - 2016-09-24 00:21:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:21:21 --> Config Class Initialized
INFO - 2016-09-24 00:21:21 --> Hooks Class Initialized
INFO - 2016-09-24 00:21:21 --> Config Class Initialized
INFO - 2016-09-24 00:21:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:21:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:21:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:21 --> URI Class Initialized
INFO - 2016-09-24 00:21:21 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:21 --> URI Class Initialized
INFO - 2016-09-24 00:21:21 --> Router Class Initialized
INFO - 2016-09-24 00:21:21 --> Router Class Initialized
INFO - 2016-09-24 00:21:21 --> Output Class Initialized
INFO - 2016-09-24 00:21:21 --> Output Class Initialized
INFO - 2016-09-24 00:21:21 --> Security Class Initialized
INFO - 2016-09-24 00:21:21 --> Security Class Initialized
DEBUG - 2016-09-24 00:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:21 --> Input Class Initialized
INFO - 2016-09-24 00:21:21 --> Language Class Initialized
DEBUG - 2016-09-24 00:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:21 --> Input Class Initialized
INFO - 2016-09-24 00:21:21 --> Language Class Initialized
INFO - 2016-09-24 00:21:21 --> Loader Class Initialized
INFO - 2016-09-24 00:21:21 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:21 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:21 --> Loader Class Initialized
INFO - 2016-09-24 00:21:21 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:21 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:21 --> Controller Class Initialized
INFO - 2016-09-24 00:21:21 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:21 --> Model Class Initialized
INFO - 2016-09-24 00:21:21 --> Model Class Initialized
INFO - 2016-09-24 00:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:21 --> Final output sent to browser
DEBUG - 2016-09-24 00:21:21 --> Total execution time: 0.0719
INFO - 2016-09-24 00:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:21 --> Controller Class Initialized
INFO - 2016-09-24 00:21:21 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:21 --> Model Class Initialized
INFO - 2016-09-24 00:21:21 --> Model Class Initialized
INFO - 2016-09-24 00:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:39 --> Config Class Initialized
INFO - 2016-09-24 00:21:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:21:39 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:39 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:39 --> URI Class Initialized
INFO - 2016-09-24 00:21:39 --> Router Class Initialized
INFO - 2016-09-24 00:21:39 --> Config Class Initialized
INFO - 2016-09-24 00:21:39 --> Hooks Class Initialized
INFO - 2016-09-24 00:21:39 --> Output Class Initialized
INFO - 2016-09-24 00:21:39 --> Security Class Initialized
DEBUG - 2016-09-24 00:21:39 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:39 --> Input Class Initialized
INFO - 2016-09-24 00:21:39 --> URI Class Initialized
INFO - 2016-09-24 00:21:39 --> Language Class Initialized
INFO - 2016-09-24 00:21:39 --> Router Class Initialized
INFO - 2016-09-24 00:21:39 --> Output Class Initialized
INFO - 2016-09-24 00:21:39 --> Loader Class Initialized
INFO - 2016-09-24 00:21:39 --> Security Class Initialized
INFO - 2016-09-24 00:21:39 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:39 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:39 --> Input Class Initialized
INFO - 2016-09-24 00:21:39 --> Language Class Initialized
INFO - 2016-09-24 00:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:39 --> Controller Class Initialized
INFO - 2016-09-24 00:21:39 --> Loader Class Initialized
INFO - 2016-09-24 00:21:39 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:39 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:39 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:39 --> Model Class Initialized
INFO - 2016-09-24 00:21:39 --> Model Class Initialized
INFO - 2016-09-24 00:21:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:39 --> Final output sent to browser
DEBUG - 2016-09-24 00:21:39 --> Total execution time: 0.0768
INFO - 2016-09-24 00:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:39 --> Controller Class Initialized
INFO - 2016-09-24 00:21:39 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:39 --> Model Class Initialized
INFO - 2016-09-24 00:21:39 --> Model Class Initialized
INFO - 2016-09-24 00:21:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:42 --> Config Class Initialized
INFO - 2016-09-24 00:21:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:21:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:42 --> URI Class Initialized
INFO - 2016-09-24 00:21:42 --> Config Class Initialized
INFO - 2016-09-24 00:21:42 --> Hooks Class Initialized
INFO - 2016-09-24 00:21:42 --> Router Class Initialized
INFO - 2016-09-24 00:21:42 --> Output Class Initialized
DEBUG - 2016-09-24 00:21:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:42 --> Security Class Initialized
INFO - 2016-09-24 00:21:42 --> URI Class Initialized
DEBUG - 2016-09-24 00:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:42 --> Input Class Initialized
INFO - 2016-09-24 00:21:42 --> Language Class Initialized
INFO - 2016-09-24 00:21:42 --> Router Class Initialized
INFO - 2016-09-24 00:21:42 --> Output Class Initialized
INFO - 2016-09-24 00:21:42 --> Loader Class Initialized
INFO - 2016-09-24 00:21:42 --> Security Class Initialized
INFO - 2016-09-24 00:21:42 --> Helper loaded: url_helper
DEBUG - 2016-09-24 00:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:42 --> Input Class Initialized
INFO - 2016-09-24 00:21:42 --> Language Class Initialized
INFO - 2016-09-24 00:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:42 --> Controller Class Initialized
INFO - 2016-09-24 00:21:42 --> Loader Class Initialized
INFO - 2016-09-24 00:21:42 --> Helper loaded: url_helper
INFO - 2016-09-24 00:21:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:21:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:42 --> Model Class Initialized
INFO - 2016-09-24 00:21:42 --> Model Class Initialized
INFO - 2016-09-24 00:21:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:42 --> Final output sent to browser
DEBUG - 2016-09-24 00:21:42 --> Total execution time: 0.0759
INFO - 2016-09-24 00:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:21:42 --> Controller Class Initialized
INFO - 2016-09-24 00:21:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:21:42 --> Model Class Initialized
INFO - 2016-09-24 00:21:42 --> Model Class Initialized
INFO - 2016-09-24 00:21:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:21:47 --> Config Class Initialized
INFO - 2016-09-24 00:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:21:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:21:47 --> URI Class Initialized
INFO - 2016-09-24 00:21:47 --> Router Class Initialized
INFO - 2016-09-24 00:21:47 --> Output Class Initialized
INFO - 2016-09-24 00:21:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:21:47 --> Input Class Initialized
INFO - 2016-09-24 00:21:47 --> Language Class Initialized
ERROR - 2016-09-24 00:21:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:22:17 --> Config Class Initialized
INFO - 2016-09-24 00:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:22:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:22:17 --> URI Class Initialized
INFO - 2016-09-24 00:22:17 --> Router Class Initialized
INFO - 2016-09-24 00:22:17 --> Output Class Initialized
INFO - 2016-09-24 00:22:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:22:17 --> Input Class Initialized
INFO - 2016-09-24 00:22:17 --> Language Class Initialized
ERROR - 2016-09-24 00:22:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:22:45 --> Config Class Initialized
INFO - 2016-09-24 00:22:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:22:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:22:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:22:45 --> URI Class Initialized
INFO - 2016-09-24 00:22:45 --> Config Class Initialized
INFO - 2016-09-24 00:22:45 --> Router Class Initialized
INFO - 2016-09-24 00:22:45 --> Hooks Class Initialized
INFO - 2016-09-24 00:22:45 --> Output Class Initialized
INFO - 2016-09-24 00:22:45 --> Security Class Initialized
DEBUG - 2016-09-24 00:22:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:22:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:22:45 --> URI Class Initialized
DEBUG - 2016-09-24 00:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:22:45 --> Input Class Initialized
INFO - 2016-09-24 00:22:45 --> Language Class Initialized
INFO - 2016-09-24 00:22:45 --> Router Class Initialized
INFO - 2016-09-24 00:22:45 --> Output Class Initialized
INFO - 2016-09-24 00:22:45 --> Loader Class Initialized
INFO - 2016-09-24 00:22:45 --> Security Class Initialized
DEBUG - 2016-09-24 00:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:22:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:22:45 --> Input Class Initialized
INFO - 2016-09-24 00:22:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:22:45 --> Language Class Initialized
INFO - 2016-09-24 00:22:45 --> Loader Class Initialized
INFO - 2016-09-24 00:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:22:45 --> Controller Class Initialized
INFO - 2016-09-24 00:22:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:22:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:22:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:22:45 --> Model Class Initialized
INFO - 2016-09-24 00:22:45 --> Model Class Initialized
INFO - 2016-09-24 00:22:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:22:45 --> Controller Class Initialized
INFO - 2016-09-24 00:22:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:22:45 --> Model Class Initialized
INFO - 2016-09-24 00:22:45 --> Model Class Initialized
INFO - 2016-09-24 00:22:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:22:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:22:45 --> Total execution time: 0.0855
INFO - 2016-09-24 00:22:47 --> Config Class Initialized
INFO - 2016-09-24 00:22:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:22:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:22:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:22:47 --> URI Class Initialized
INFO - 2016-09-24 00:22:47 --> Router Class Initialized
INFO - 2016-09-24 00:22:47 --> Output Class Initialized
INFO - 2016-09-24 00:22:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:22:47 --> Input Class Initialized
INFO - 2016-09-24 00:22:47 --> Language Class Initialized
ERROR - 2016-09-24 00:22:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:23:17 --> Config Class Initialized
INFO - 2016-09-24 00:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:23:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:23:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:23:17 --> URI Class Initialized
INFO - 2016-09-24 00:23:17 --> Router Class Initialized
INFO - 2016-09-24 00:23:17 --> Output Class Initialized
INFO - 2016-09-24 00:23:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:23:17 --> Input Class Initialized
INFO - 2016-09-24 00:23:17 --> Language Class Initialized
ERROR - 2016-09-24 00:23:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:23:32 --> Config Class Initialized
INFO - 2016-09-24 00:23:32 --> Hooks Class Initialized
INFO - 2016-09-24 00:23:32 --> Config Class Initialized
INFO - 2016-09-24 00:23:32 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:23:32 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:23:32 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:23:32 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:23:32 --> Utf8 Class Initialized
INFO - 2016-09-24 00:23:32 --> URI Class Initialized
INFO - 2016-09-24 00:23:32 --> URI Class Initialized
INFO - 2016-09-24 00:23:32 --> Router Class Initialized
INFO - 2016-09-24 00:23:32 --> Router Class Initialized
INFO - 2016-09-24 00:23:32 --> Output Class Initialized
INFO - 2016-09-24 00:23:32 --> Output Class Initialized
INFO - 2016-09-24 00:23:32 --> Security Class Initialized
INFO - 2016-09-24 00:23:32 --> Security Class Initialized
DEBUG - 2016-09-24 00:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:23:32 --> Input Class Initialized
DEBUG - 2016-09-24 00:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:23:32 --> Language Class Initialized
INFO - 2016-09-24 00:23:32 --> Input Class Initialized
INFO - 2016-09-24 00:23:32 --> Language Class Initialized
INFO - 2016-09-24 00:23:32 --> Loader Class Initialized
INFO - 2016-09-24 00:23:32 --> Helper loaded: url_helper
INFO - 2016-09-24 00:23:32 --> Loader Class Initialized
INFO - 2016-09-24 00:23:32 --> Helper loaded: language_helper
INFO - 2016-09-24 00:23:32 --> Helper loaded: url_helper
INFO - 2016-09-24 00:23:32 --> Helper loaded: language_helper
INFO - 2016-09-24 00:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:23:32 --> Controller Class Initialized
INFO - 2016-09-24 00:23:32 --> Database Driver Class Initialized
INFO - 2016-09-24 00:23:32 --> Model Class Initialized
INFO - 2016-09-24 00:23:32 --> Model Class Initialized
INFO - 2016-09-24 00:23:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:23:32 --> Final output sent to browser
DEBUG - 2016-09-24 00:23:32 --> Total execution time: 0.0734
INFO - 2016-09-24 00:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:23:32 --> Controller Class Initialized
INFO - 2016-09-24 00:23:32 --> Database Driver Class Initialized
INFO - 2016-09-24 00:23:32 --> Model Class Initialized
INFO - 2016-09-24 00:23:32 --> Model Class Initialized
INFO - 2016-09-24 00:23:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:23:36 --> Config Class Initialized
INFO - 2016-09-24 00:23:36 --> Hooks Class Initialized
INFO - 2016-09-24 00:23:36 --> Config Class Initialized
INFO - 2016-09-24 00:23:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:23:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:23:36 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:23:36 --> Utf8 Class Initialized
INFO - 2016-09-24 00:23:36 --> Utf8 Class Initialized
INFO - 2016-09-24 00:23:36 --> URI Class Initialized
INFO - 2016-09-24 00:23:36 --> URI Class Initialized
INFO - 2016-09-24 00:23:36 --> Router Class Initialized
INFO - 2016-09-24 00:23:36 --> Router Class Initialized
INFO - 2016-09-24 00:23:36 --> Output Class Initialized
INFO - 2016-09-24 00:23:36 --> Security Class Initialized
INFO - 2016-09-24 00:23:36 --> Output Class Initialized
INFO - 2016-09-24 00:23:36 --> Security Class Initialized
DEBUG - 2016-09-24 00:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:23:36 --> Input Class Initialized
DEBUG - 2016-09-24 00:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:23:36 --> Language Class Initialized
INFO - 2016-09-24 00:23:36 --> Input Class Initialized
INFO - 2016-09-24 00:23:36 --> Language Class Initialized
INFO - 2016-09-24 00:23:36 --> Loader Class Initialized
INFO - 2016-09-24 00:23:36 --> Loader Class Initialized
INFO - 2016-09-24 00:23:36 --> Helper loaded: url_helper
INFO - 2016-09-24 00:23:36 --> Helper loaded: language_helper
INFO - 2016-09-24 00:23:36 --> Helper loaded: url_helper
INFO - 2016-09-24 00:23:36 --> Helper loaded: language_helper
INFO - 2016-09-24 00:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:23:36 --> Controller Class Initialized
INFO - 2016-09-24 00:23:36 --> Database Driver Class Initialized
INFO - 2016-09-24 00:23:36 --> Model Class Initialized
INFO - 2016-09-24 00:23:36 --> Model Class Initialized
INFO - 2016-09-24 00:23:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:23:36 --> Controller Class Initialized
INFO - 2016-09-24 00:23:36 --> Database Driver Class Initialized
INFO - 2016-09-24 00:23:36 --> Model Class Initialized
INFO - 2016-09-24 00:23:36 --> Model Class Initialized
INFO - 2016-09-24 00:23:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:23:36 --> Final output sent to browser
DEBUG - 2016-09-24 00:23:36 --> Total execution time: 0.1172
INFO - 2016-09-24 00:23:47 --> Config Class Initialized
INFO - 2016-09-24 00:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:23:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:23:47 --> URI Class Initialized
INFO - 2016-09-24 00:23:47 --> Router Class Initialized
INFO - 2016-09-24 00:23:47 --> Output Class Initialized
INFO - 2016-09-24 00:23:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:23:47 --> Input Class Initialized
INFO - 2016-09-24 00:23:47 --> Language Class Initialized
ERROR - 2016-09-24 00:23:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:24:17 --> Config Class Initialized
INFO - 2016-09-24 00:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:17 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:17 --> URI Class Initialized
INFO - 2016-09-24 00:24:17 --> Router Class Initialized
INFO - 2016-09-24 00:24:17 --> Output Class Initialized
INFO - 2016-09-24 00:24:17 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:17 --> Input Class Initialized
INFO - 2016-09-24 00:24:17 --> Language Class Initialized
ERROR - 2016-09-24 00:24:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:24:33 --> Config Class Initialized
INFO - 2016-09-24 00:24:33 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:33 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:33 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:33 --> Config Class Initialized
INFO - 2016-09-24 00:24:33 --> URI Class Initialized
INFO - 2016-09-24 00:24:33 --> Hooks Class Initialized
INFO - 2016-09-24 00:24:33 --> Router Class Initialized
DEBUG - 2016-09-24 00:24:33 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:33 --> Output Class Initialized
INFO - 2016-09-24 00:24:33 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:33 --> URI Class Initialized
INFO - 2016-09-24 00:24:33 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:33 --> Router Class Initialized
INFO - 2016-09-24 00:24:33 --> Input Class Initialized
INFO - 2016-09-24 00:24:33 --> Language Class Initialized
INFO - 2016-09-24 00:24:33 --> Output Class Initialized
INFO - 2016-09-24 00:24:33 --> Security Class Initialized
INFO - 2016-09-24 00:24:33 --> Loader Class Initialized
DEBUG - 2016-09-24 00:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:33 --> Input Class Initialized
INFO - 2016-09-24 00:24:33 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:33 --> Language Class Initialized
INFO - 2016-09-24 00:24:33 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:33 --> Loader Class Initialized
INFO - 2016-09-24 00:24:33 --> Controller Class Initialized
INFO - 2016-09-24 00:24:33 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:33 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:33 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:33 --> Model Class Initialized
INFO - 2016-09-24 00:24:33 --> Model Class Initialized
INFO - 2016-09-24 00:24:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:33 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:33 --> Total execution time: 0.0689
INFO - 2016-09-24 00:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:33 --> Controller Class Initialized
INFO - 2016-09-24 00:24:33 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:33 --> Model Class Initialized
INFO - 2016-09-24 00:24:33 --> Model Class Initialized
INFO - 2016-09-24 00:24:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:33 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:33 --> Total execution time: 0.1279
INFO - 2016-09-24 00:24:42 --> Config Class Initialized
INFO - 2016-09-24 00:24:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:42 --> URI Class Initialized
INFO - 2016-09-24 00:24:42 --> Router Class Initialized
INFO - 2016-09-24 00:24:42 --> Output Class Initialized
INFO - 2016-09-24 00:24:42 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:42 --> Input Class Initialized
INFO - 2016-09-24 00:24:42 --> Language Class Initialized
INFO - 2016-09-24 00:24:42 --> Loader Class Initialized
INFO - 2016-09-24 00:24:42 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:42 --> Controller Class Initialized
INFO - 2016-09-24 00:24:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:42 --> Model Class Initialized
INFO - 2016-09-24 00:24:42 --> Model Class Initialized
INFO - 2016-09-24 00:24:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:42 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:42 --> Total execution time: 0.1158
INFO - 2016-09-24 00:24:44 --> Config Class Initialized
INFO - 2016-09-24 00:24:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:44 --> URI Class Initialized
INFO - 2016-09-24 00:24:44 --> Router Class Initialized
INFO - 2016-09-24 00:24:44 --> Output Class Initialized
INFO - 2016-09-24 00:24:44 --> Config Class Initialized
INFO - 2016-09-24 00:24:44 --> Security Class Initialized
INFO - 2016-09-24 00:24:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:44 --> Input Class Initialized
INFO - 2016-09-24 00:24:44 --> Config Class Initialized
INFO - 2016-09-24 00:24:44 --> Hooks Class Initialized
INFO - 2016-09-24 00:24:44 --> Language Class Initialized
DEBUG - 2016-09-24 00:24:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:44 --> URI Class Initialized
DEBUG - 2016-09-24 00:24:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:44 --> Loader Class Initialized
INFO - 2016-09-24 00:24:44 --> URI Class Initialized
INFO - 2016-09-24 00:24:44 --> Router Class Initialized
INFO - 2016-09-24 00:24:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:44 --> Output Class Initialized
INFO - 2016-09-24 00:24:44 --> Router Class Initialized
INFO - 2016-09-24 00:24:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:44 --> Security Class Initialized
INFO - 2016-09-24 00:24:44 --> Output Class Initialized
DEBUG - 2016-09-24 00:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:44 --> Security Class Initialized
INFO - 2016-09-24 00:24:44 --> Input Class Initialized
INFO - 2016-09-24 00:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:44 --> Controller Class Initialized
INFO - 2016-09-24 00:24:44 --> Language Class Initialized
DEBUG - 2016-09-24 00:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:44 --> Input Class Initialized
INFO - 2016-09-24 00:24:44 --> Language Class Initialized
INFO - 2016-09-24 00:24:44 --> Loader Class Initialized
ERROR - 2016-09-24 00:24:44 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:24:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:44 --> Model Class Initialized
INFO - 2016-09-24 00:24:44 --> Model Class Initialized
INFO - 2016-09-24 00:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:44 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:44 --> Total execution time: 0.1399
INFO - 2016-09-24 00:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:44 --> Controller Class Initialized
INFO - 2016-09-24 00:24:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:44 --> Model Class Initialized
INFO - 2016-09-24 00:24:44 --> Model Class Initialized
INFO - 2016-09-24 00:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:44 --> Config Class Initialized
INFO - 2016-09-24 00:24:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:44 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:44 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:44 --> URI Class Initialized
INFO - 2016-09-24 00:24:44 --> Router Class Initialized
INFO - 2016-09-24 00:24:44 --> Output Class Initialized
INFO - 2016-09-24 00:24:44 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:44 --> Input Class Initialized
INFO - 2016-09-24 00:24:44 --> Language Class Initialized
INFO - 2016-09-24 00:24:44 --> Loader Class Initialized
INFO - 2016-09-24 00:24:44 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:44 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:44 --> Controller Class Initialized
INFO - 2016-09-24 00:24:44 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:44 --> Model Class Initialized
INFO - 2016-09-24 00:24:44 --> Model Class Initialized
INFO - 2016-09-24 00:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:24:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2016-09-24 00:24:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:24:44 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:44 --> Total execution time: 0.0769
INFO - 2016-09-24 00:24:54 --> Config Class Initialized
INFO - 2016-09-24 00:24:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:54 --> URI Class Initialized
INFO - 2016-09-24 00:24:54 --> Router Class Initialized
INFO - 2016-09-24 00:24:54 --> Output Class Initialized
INFO - 2016-09-24 00:24:54 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:54 --> Input Class Initialized
INFO - 2016-09-24 00:24:54 --> Language Class Initialized
INFO - 2016-09-24 00:24:54 --> Loader Class Initialized
INFO - 2016-09-24 00:24:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:54 --> Controller Class Initialized
INFO - 2016-09-24 00:24:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:54 --> Config Class Initialized
INFO - 2016-09-24 00:24:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:54 --> URI Class Initialized
INFO - 2016-09-24 00:24:54 --> Router Class Initialized
INFO - 2016-09-24 00:24:54 --> Output Class Initialized
INFO - 2016-09-24 00:24:54 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:54 --> Input Class Initialized
INFO - 2016-09-24 00:24:54 --> Language Class Initialized
INFO - 2016-09-24 00:24:54 --> Loader Class Initialized
INFO - 2016-09-24 00:24:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:54 --> Controller Class Initialized
INFO - 2016-09-24 00:24:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2016-09-24 00:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:24:54 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:54 --> Total execution time: 0.0713
INFO - 2016-09-24 00:24:54 --> Config Class Initialized
INFO - 2016-09-24 00:24:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:24:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:24:54 --> URI Class Initialized
INFO - 2016-09-24 00:24:54 --> Router Class Initialized
INFO - 2016-09-24 00:24:54 --> Config Class Initialized
INFO - 2016-09-24 00:24:54 --> Hooks Class Initialized
INFO - 2016-09-24 00:24:54 --> Output Class Initialized
INFO - 2016-09-24 00:24:54 --> Security Class Initialized
DEBUG - 2016-09-24 00:24:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:24:54 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:54 --> Input Class Initialized
INFO - 2016-09-24 00:24:54 --> URI Class Initialized
INFO - 2016-09-24 00:24:54 --> Language Class Initialized
INFO - 2016-09-24 00:24:54 --> Router Class Initialized
INFO - 2016-09-24 00:24:54 --> Loader Class Initialized
INFO - 2016-09-24 00:24:54 --> Output Class Initialized
INFO - 2016-09-24 00:24:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:54 --> Security Class Initialized
INFO - 2016-09-24 00:24:54 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:24:54 --> Input Class Initialized
INFO - 2016-09-24 00:24:54 --> Language Class Initialized
INFO - 2016-09-24 00:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:54 --> Controller Class Initialized
INFO - 2016-09-24 00:24:54 --> Loader Class Initialized
INFO - 2016-09-24 00:24:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:24:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:24:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:24:54 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:54 --> Total execution time: 0.0799
INFO - 2016-09-24 00:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:24:54 --> Controller Class Initialized
INFO - 2016-09-24 00:24:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Model Class Initialized
INFO - 2016-09-24 00:24:54 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:24:54 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-24 00:24:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-24 00:24:54 --> Final output sent to browser
DEBUG - 2016-09-24 00:24:54 --> Total execution time: 0.1018
INFO - 2016-09-24 00:25:03 --> Config Class Initialized
INFO - 2016-09-24 00:25:03 --> Hooks Class Initialized
INFO - 2016-09-24 00:25:03 --> Config Class Initialized
INFO - 2016-09-24 00:25:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:25:03 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:03 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:03 --> URI Class Initialized
DEBUG - 2016-09-24 00:25:03 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:03 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:03 --> Router Class Initialized
INFO - 2016-09-24 00:25:03 --> URI Class Initialized
INFO - 2016-09-24 00:25:03 --> Output Class Initialized
INFO - 2016-09-24 00:25:03 --> Router Class Initialized
INFO - 2016-09-24 00:25:03 --> Security Class Initialized
INFO - 2016-09-24 00:25:03 --> Output Class Initialized
DEBUG - 2016-09-24 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:03 --> Input Class Initialized
INFO - 2016-09-24 00:25:03 --> Language Class Initialized
INFO - 2016-09-24 00:25:03 --> Security Class Initialized
DEBUG - 2016-09-24 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:03 --> Input Class Initialized
INFO - 2016-09-24 00:25:03 --> Language Class Initialized
INFO - 2016-09-24 00:25:03 --> Loader Class Initialized
INFO - 2016-09-24 00:25:03 --> Helper loaded: url_helper
INFO - 2016-09-24 00:25:03 --> Helper loaded: language_helper
INFO - 2016-09-24 00:25:03 --> Loader Class Initialized
INFO - 2016-09-24 00:25:03 --> Helper loaded: url_helper
INFO - 2016-09-24 00:25:03 --> Helper loaded: language_helper
INFO - 2016-09-24 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:25:03 --> Controller Class Initialized
INFO - 2016-09-24 00:25:03 --> Database Driver Class Initialized
INFO - 2016-09-24 00:25:03 --> Model Class Initialized
INFO - 2016-09-24 00:25:03 --> Model Class Initialized
INFO - 2016-09-24 00:25:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:25:03 --> Final output sent to browser
DEBUG - 2016-09-24 00:25:03 --> Total execution time: 0.0806
INFO - 2016-09-24 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:25:03 --> Controller Class Initialized
INFO - 2016-09-24 00:25:03 --> Database Driver Class Initialized
INFO - 2016-09-24 00:25:03 --> Model Class Initialized
INFO - 2016-09-24 00:25:03 --> Model Class Initialized
INFO - 2016-09-24 00:25:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:25:03 --> Final output sent to browser
DEBUG - 2016-09-24 00:25:03 --> Total execution time: 0.1082
INFO - 2016-09-24 00:25:06 --> Config Class Initialized
INFO - 2016-09-24 00:25:06 --> Hooks Class Initialized
INFO - 2016-09-24 00:25:06 --> Config Class Initialized
INFO - 2016-09-24 00:25:06 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:25:06 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:06 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:06 --> URI Class Initialized
DEBUG - 2016-09-24 00:25:06 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:06 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:06 --> Router Class Initialized
INFO - 2016-09-24 00:25:06 --> URI Class Initialized
INFO - 2016-09-24 00:25:06 --> Output Class Initialized
INFO - 2016-09-24 00:25:06 --> Router Class Initialized
INFO - 2016-09-24 00:25:06 --> Security Class Initialized
INFO - 2016-09-24 00:25:06 --> Output Class Initialized
DEBUG - 2016-09-24 00:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:06 --> Input Class Initialized
INFO - 2016-09-24 00:25:06 --> Security Class Initialized
INFO - 2016-09-24 00:25:06 --> Language Class Initialized
DEBUG - 2016-09-24 00:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:06 --> Input Class Initialized
INFO - 2016-09-24 00:25:06 --> Language Class Initialized
INFO - 2016-09-24 00:25:06 --> Loader Class Initialized
INFO - 2016-09-24 00:25:06 --> Helper loaded: url_helper
INFO - 2016-09-24 00:25:06 --> Helper loaded: language_helper
INFO - 2016-09-24 00:25:06 --> Loader Class Initialized
INFO - 2016-09-24 00:25:06 --> Helper loaded: url_helper
INFO - 2016-09-24 00:25:06 --> Helper loaded: language_helper
INFO - 2016-09-24 00:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:25:06 --> Controller Class Initialized
INFO - 2016-09-24 00:25:06 --> Database Driver Class Initialized
INFO - 2016-09-24 00:25:06 --> Model Class Initialized
INFO - 2016-09-24 00:25:06 --> Model Class Initialized
INFO - 2016-09-24 00:25:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:25:06 --> Final output sent to browser
DEBUG - 2016-09-24 00:25:06 --> Total execution time: 0.0875
INFO - 2016-09-24 00:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:25:06 --> Controller Class Initialized
INFO - 2016-09-24 00:25:06 --> Database Driver Class Initialized
INFO - 2016-09-24 00:25:06 --> Model Class Initialized
INFO - 2016-09-24 00:25:06 --> Model Class Initialized
INFO - 2016-09-24 00:25:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:25:06 --> Final output sent to browser
DEBUG - 2016-09-24 00:25:06 --> Total execution time: 0.1226
INFO - 2016-09-24 00:25:24 --> Config Class Initialized
INFO - 2016-09-24 00:25:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:25:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:24 --> URI Class Initialized
INFO - 2016-09-24 00:25:24 --> Router Class Initialized
INFO - 2016-09-24 00:25:24 --> Output Class Initialized
INFO - 2016-09-24 00:25:24 --> Security Class Initialized
DEBUG - 2016-09-24 00:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:24 --> Input Class Initialized
INFO - 2016-09-24 00:25:24 --> Language Class Initialized
ERROR - 2016-09-24 00:25:24 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:25:43 --> Config Class Initialized
INFO - 2016-09-24 00:25:43 --> Hooks Class Initialized
INFO - 2016-09-24 00:25:43 --> Config Class Initialized
INFO - 2016-09-24 00:25:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:25:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:43 --> URI Class Initialized
DEBUG - 2016-09-24 00:25:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:43 --> Router Class Initialized
INFO - 2016-09-24 00:25:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:43 --> URI Class Initialized
INFO - 2016-09-24 00:25:43 --> Output Class Initialized
INFO - 2016-09-24 00:25:43 --> Security Class Initialized
INFO - 2016-09-24 00:25:43 --> Router Class Initialized
DEBUG - 2016-09-24 00:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:43 --> Output Class Initialized
INFO - 2016-09-24 00:25:43 --> Input Class Initialized
INFO - 2016-09-24 00:25:43 --> Language Class Initialized
INFO - 2016-09-24 00:25:43 --> Security Class Initialized
DEBUG - 2016-09-24 00:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:43 --> Input Class Initialized
INFO - 2016-09-24 00:25:43 --> Loader Class Initialized
INFO - 2016-09-24 00:25:43 --> Language Class Initialized
INFO - 2016-09-24 00:25:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:25:43 --> Helper loaded: language_helper
INFO - 2016-09-24 00:25:43 --> Loader Class Initialized
INFO - 2016-09-24 00:25:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:25:43 --> Helper loaded: language_helper
INFO - 2016-09-24 00:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:25:43 --> Controller Class Initialized
INFO - 2016-09-24 00:25:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:25:43 --> Model Class Initialized
INFO - 2016-09-24 00:25:43 --> Model Class Initialized
INFO - 2016-09-24 00:25:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:25:43 --> Final output sent to browser
DEBUG - 2016-09-24 00:25:43 --> Total execution time: 0.0951
INFO - 2016-09-24 00:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:25:43 --> Controller Class Initialized
INFO - 2016-09-24 00:25:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:25:43 --> Model Class Initialized
INFO - 2016-09-24 00:25:43 --> Model Class Initialized
INFO - 2016-09-24 00:25:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:25:43 --> Final output sent to browser
DEBUG - 2016-09-24 00:25:43 --> Total execution time: 0.1252
INFO - 2016-09-24 00:25:55 --> Config Class Initialized
INFO - 2016-09-24 00:25:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:25:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:25:55 --> Utf8 Class Initialized
INFO - 2016-09-24 00:25:55 --> URI Class Initialized
INFO - 2016-09-24 00:25:55 --> Router Class Initialized
INFO - 2016-09-24 00:25:55 --> Output Class Initialized
INFO - 2016-09-24 00:25:55 --> Security Class Initialized
DEBUG - 2016-09-24 00:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:25:55 --> Input Class Initialized
INFO - 2016-09-24 00:25:55 --> Language Class Initialized
ERROR - 2016-09-24 00:25:55 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:26:24 --> Config Class Initialized
INFO - 2016-09-24 00:26:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:26:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:26:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:26:24 --> URI Class Initialized
INFO - 2016-09-24 00:26:24 --> Router Class Initialized
INFO - 2016-09-24 00:26:24 --> Output Class Initialized
INFO - 2016-09-24 00:26:24 --> Security Class Initialized
DEBUG - 2016-09-24 00:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:26:24 --> Input Class Initialized
INFO - 2016-09-24 00:26:24 --> Language Class Initialized
ERROR - 2016-09-24 00:26:24 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:26:35 --> Config Class Initialized
INFO - 2016-09-24 00:26:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:26:35 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:26:35 --> Utf8 Class Initialized
INFO - 2016-09-24 00:26:35 --> URI Class Initialized
INFO - 2016-09-24 00:26:35 --> Router Class Initialized
INFO - 2016-09-24 00:26:35 --> Config Class Initialized
INFO - 2016-09-24 00:26:35 --> Hooks Class Initialized
INFO - 2016-09-24 00:26:35 --> Output Class Initialized
INFO - 2016-09-24 00:26:35 --> Security Class Initialized
DEBUG - 2016-09-24 00:26:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:26:35 --> Utf8 Class Initialized
INFO - 2016-09-24 00:26:35 --> Input Class Initialized
INFO - 2016-09-24 00:26:35 --> Language Class Initialized
INFO - 2016-09-24 00:26:35 --> URI Class Initialized
INFO - 2016-09-24 00:26:35 --> Router Class Initialized
INFO - 2016-09-24 00:26:35 --> Loader Class Initialized
INFO - 2016-09-24 00:26:35 --> Output Class Initialized
INFO - 2016-09-24 00:26:35 --> Helper loaded: url_helper
INFO - 2016-09-24 00:26:35 --> Security Class Initialized
INFO - 2016-09-24 00:26:35 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:26:35 --> Input Class Initialized
INFO - 2016-09-24 00:26:35 --> Language Class Initialized
INFO - 2016-09-24 00:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:26:35 --> Controller Class Initialized
INFO - 2016-09-24 00:26:35 --> Loader Class Initialized
INFO - 2016-09-24 00:26:35 --> Helper loaded: url_helper
INFO - 2016-09-24 00:26:35 --> Helper loaded: language_helper
INFO - 2016-09-24 00:26:35 --> Database Driver Class Initialized
INFO - 2016-09-24 00:26:35 --> Model Class Initialized
INFO - 2016-09-24 00:26:35 --> Model Class Initialized
INFO - 2016-09-24 00:26:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:26:35 --> Final output sent to browser
DEBUG - 2016-09-24 00:26:35 --> Total execution time: 0.0700
INFO - 2016-09-24 00:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:26:35 --> Controller Class Initialized
INFO - 2016-09-24 00:26:35 --> Database Driver Class Initialized
INFO - 2016-09-24 00:26:35 --> Model Class Initialized
INFO - 2016-09-24 00:26:35 --> Model Class Initialized
INFO - 2016-09-24 00:26:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:26:35 --> Final output sent to browser
DEBUG - 2016-09-24 00:26:35 --> Total execution time: 0.1000
INFO - 2016-09-24 00:26:55 --> Config Class Initialized
INFO - 2016-09-24 00:26:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:26:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:26:55 --> Utf8 Class Initialized
INFO - 2016-09-24 00:26:55 --> URI Class Initialized
INFO - 2016-09-24 00:26:55 --> Router Class Initialized
INFO - 2016-09-24 00:26:55 --> Output Class Initialized
INFO - 2016-09-24 00:26:55 --> Security Class Initialized
DEBUG - 2016-09-24 00:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:26:55 --> Input Class Initialized
INFO - 2016-09-24 00:26:55 --> Language Class Initialized
ERROR - 2016-09-24 00:26:55 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:27:05 --> Config Class Initialized
INFO - 2016-09-24 00:27:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:05 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:05 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:05 --> URI Class Initialized
INFO - 2016-09-24 00:27:05 --> Router Class Initialized
INFO - 2016-09-24 00:27:05 --> Output Class Initialized
INFO - 2016-09-24 00:27:05 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:06 --> Input Class Initialized
INFO - 2016-09-24 00:27:06 --> Language Class Initialized
INFO - 2016-09-24 00:27:06 --> Loader Class Initialized
INFO - 2016-09-24 00:27:06 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:06 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:06 --> Controller Class Initialized
INFO - 2016-09-24 00:27:06 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:06 --> Model Class Initialized
INFO - 2016-09-24 00:27:06 --> Model Class Initialized
INFO - 2016-09-24 00:27:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:06 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:06 --> Total execution time: 0.0934
INFO - 2016-09-24 00:27:07 --> Config Class Initialized
INFO - 2016-09-24 00:27:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:07 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:07 --> URI Class Initialized
INFO - 2016-09-24 00:27:07 --> Router Class Initialized
INFO - 2016-09-24 00:27:07 --> Output Class Initialized
INFO - 2016-09-24 00:27:07 --> Security Class Initialized
INFO - 2016-09-24 00:27:07 --> Config Class Initialized
INFO - 2016-09-24 00:27:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:07 --> Input Class Initialized
INFO - 2016-09-24 00:27:07 --> Language Class Initialized
DEBUG - 2016-09-24 00:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:07 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:07 --> URI Class Initialized
INFO - 2016-09-24 00:27:07 --> Config Class Initialized
INFO - 2016-09-24 00:27:07 --> Loader Class Initialized
INFO - 2016-09-24 00:27:07 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:07 --> Router Class Initialized
INFO - 2016-09-24 00:27:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:07 --> Output Class Initialized
INFO - 2016-09-24 00:27:07 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:07 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:07 --> Security Class Initialized
INFO - 2016-09-24 00:27:07 --> URI Class Initialized
DEBUG - 2016-09-24 00:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:07 --> Input Class Initialized
INFO - 2016-09-24 00:27:07 --> Language Class Initialized
INFO - 2016-09-24 00:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:07 --> Controller Class Initialized
INFO - 2016-09-24 00:27:07 --> Router Class Initialized
INFO - 2016-09-24 00:27:07 --> Output Class Initialized
ERROR - 2016-09-24 00:27:07 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:27:07 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:07 --> Input Class Initialized
INFO - 2016-09-24 00:27:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:07 --> Language Class Initialized
INFO - 2016-09-24 00:27:07 --> Model Class Initialized
INFO - 2016-09-24 00:27:07 --> Model Class Initialized
INFO - 2016-09-24 00:27:07 --> Loader Class Initialized
INFO - 2016-09-24 00:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:07 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:07 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:07 --> Total execution time: 0.1354
INFO - 2016-09-24 00:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:07 --> Controller Class Initialized
INFO - 2016-09-24 00:27:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:07 --> Model Class Initialized
INFO - 2016-09-24 00:27:07 --> Model Class Initialized
INFO - 2016-09-24 00:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:07 --> Config Class Initialized
INFO - 2016-09-24 00:27:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:07 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:07 --> URI Class Initialized
INFO - 2016-09-24 00:27:07 --> Router Class Initialized
INFO - 2016-09-24 00:27:07 --> Output Class Initialized
INFO - 2016-09-24 00:27:07 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:07 --> Input Class Initialized
INFO - 2016-09-24 00:27:07 --> Language Class Initialized
INFO - 2016-09-24 00:27:07 --> Loader Class Initialized
INFO - 2016-09-24 00:27:07 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:07 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:07 --> Controller Class Initialized
INFO - 2016-09-24 00:27:07 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:07 --> Model Class Initialized
INFO - 2016-09-24 00:27:07 --> Model Class Initialized
INFO - 2016-09-24 00:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2016-09-24 00:27:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:27:07 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:07 --> Total execution time: 0.0869
INFO - 2016-09-24 00:27:19 --> Config Class Initialized
INFO - 2016-09-24 00:27:19 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:19 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:19 --> URI Class Initialized
INFO - 2016-09-24 00:27:19 --> Router Class Initialized
INFO - 2016-09-24 00:27:19 --> Output Class Initialized
INFO - 2016-09-24 00:27:19 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:19 --> Input Class Initialized
INFO - 2016-09-24 00:27:19 --> Language Class Initialized
INFO - 2016-09-24 00:27:19 --> Loader Class Initialized
INFO - 2016-09-24 00:27:19 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:19 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:19 --> Controller Class Initialized
INFO - 2016-09-24 00:27:19 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:19 --> Config Class Initialized
INFO - 2016-09-24 00:27:19 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:19 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:19 --> URI Class Initialized
INFO - 2016-09-24 00:27:19 --> Router Class Initialized
INFO - 2016-09-24 00:27:19 --> Output Class Initialized
INFO - 2016-09-24 00:27:19 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:19 --> Input Class Initialized
INFO - 2016-09-24 00:27:19 --> Language Class Initialized
INFO - 2016-09-24 00:27:19 --> Loader Class Initialized
INFO - 2016-09-24 00:27:19 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:19 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:19 --> Controller Class Initialized
INFO - 2016-09-24 00:27:19 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:27:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06_attempt.php
INFO - 2016-09-24 00:27:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:27:19 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:19 --> Total execution time: 0.0703
INFO - 2016-09-24 00:27:19 --> Config Class Initialized
INFO - 2016-09-24 00:27:19 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:19 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:19 --> URI Class Initialized
INFO - 2016-09-24 00:27:19 --> Config Class Initialized
INFO - 2016-09-24 00:27:19 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:19 --> Router Class Initialized
INFO - 2016-09-24 00:27:19 --> Output Class Initialized
DEBUG - 2016-09-24 00:27:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:19 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:19 --> URI Class Initialized
INFO - 2016-09-24 00:27:19 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:19 --> Input Class Initialized
INFO - 2016-09-24 00:27:19 --> Router Class Initialized
INFO - 2016-09-24 00:27:19 --> Language Class Initialized
INFO - 2016-09-24 00:27:19 --> Output Class Initialized
INFO - 2016-09-24 00:27:19 --> Security Class Initialized
INFO - 2016-09-24 00:27:19 --> Loader Class Initialized
DEBUG - 2016-09-24 00:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:19 --> Input Class Initialized
INFO - 2016-09-24 00:27:19 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:19 --> Language Class Initialized
INFO - 2016-09-24 00:27:19 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:19 --> Loader Class Initialized
INFO - 2016-09-24 00:27:19 --> Controller Class Initialized
INFO - 2016-09-24 00:27:19 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:19 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:19 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:19 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:19 --> Total execution time: 0.0841
INFO - 2016-09-24 00:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:19 --> Controller Class Initialized
INFO - 2016-09-24 00:27:19 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Model Class Initialized
INFO - 2016-09-24 00:27:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:27:19 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-24 00:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-24 00:27:19 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:19 --> Total execution time: 0.1100
INFO - 2016-09-24 00:27:34 --> Config Class Initialized
INFO - 2016-09-24 00:27:34 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:34 --> Config Class Initialized
INFO - 2016-09-24 00:27:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:34 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:27:34 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:34 --> URI Class Initialized
INFO - 2016-09-24 00:27:34 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:34 --> URI Class Initialized
INFO - 2016-09-24 00:27:34 --> Router Class Initialized
INFO - 2016-09-24 00:27:34 --> Router Class Initialized
INFO - 2016-09-24 00:27:34 --> Output Class Initialized
INFO - 2016-09-24 00:27:34 --> Output Class Initialized
INFO - 2016-09-24 00:27:34 --> Security Class Initialized
INFO - 2016-09-24 00:27:34 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:34 --> Input Class Initialized
INFO - 2016-09-24 00:27:34 --> Language Class Initialized
DEBUG - 2016-09-24 00:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:34 --> Input Class Initialized
INFO - 2016-09-24 00:27:34 --> Language Class Initialized
INFO - 2016-09-24 00:27:34 --> Loader Class Initialized
INFO - 2016-09-24 00:27:34 --> Loader Class Initialized
INFO - 2016-09-24 00:27:34 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:34 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:34 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:34 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:34 --> Controller Class Initialized
INFO - 2016-09-24 00:27:34 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:34 --> Model Class Initialized
INFO - 2016-09-24 00:27:34 --> Model Class Initialized
INFO - 2016-09-24 00:27:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:34 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:34 --> Total execution time: 0.0832
INFO - 2016-09-24 00:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:34 --> Controller Class Initialized
INFO - 2016-09-24 00:27:34 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:34 --> Model Class Initialized
INFO - 2016-09-24 00:27:34 --> Model Class Initialized
INFO - 2016-09-24 00:27:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:34 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:34 --> Total execution time: 0.1156
INFO - 2016-09-24 00:27:37 --> Config Class Initialized
INFO - 2016-09-24 00:27:37 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:37 --> Config Class Initialized
INFO - 2016-09-24 00:27:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:37 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:37 --> URI Class Initialized
INFO - 2016-09-24 00:27:37 --> Router Class Initialized
DEBUG - 2016-09-24 00:27:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:37 --> Output Class Initialized
INFO - 2016-09-24 00:27:37 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:37 --> URI Class Initialized
INFO - 2016-09-24 00:27:37 --> Security Class Initialized
INFO - 2016-09-24 00:27:37 --> Router Class Initialized
DEBUG - 2016-09-24 00:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:37 --> Input Class Initialized
INFO - 2016-09-24 00:27:37 --> Output Class Initialized
INFO - 2016-09-24 00:27:37 --> Language Class Initialized
INFO - 2016-09-24 00:27:37 --> Security Class Initialized
INFO - 2016-09-24 00:27:37 --> Loader Class Initialized
DEBUG - 2016-09-24 00:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:37 --> Input Class Initialized
INFO - 2016-09-24 00:27:37 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:37 --> Language Class Initialized
INFO - 2016-09-24 00:27:37 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:37 --> Loader Class Initialized
INFO - 2016-09-24 00:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:37 --> Controller Class Initialized
INFO - 2016-09-24 00:27:37 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:37 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:37 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:37 --> Model Class Initialized
INFO - 2016-09-24 00:27:37 --> Model Class Initialized
INFO - 2016-09-24 00:27:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:37 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:37 --> Total execution time: 0.0828
INFO - 2016-09-24 00:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:37 --> Controller Class Initialized
INFO - 2016-09-24 00:27:37 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:37 --> Model Class Initialized
INFO - 2016-09-24 00:27:37 --> Model Class Initialized
INFO - 2016-09-24 00:27:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:37 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:37 --> Total execution time: 0.1249
INFO - 2016-09-24 00:27:42 --> Config Class Initialized
INFO - 2016-09-24 00:27:42 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:42 --> Config Class Initialized
INFO - 2016-09-24 00:27:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:42 --> URI Class Initialized
INFO - 2016-09-24 00:27:42 --> Router Class Initialized
DEBUG - 2016-09-24 00:27:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:42 --> Output Class Initialized
INFO - 2016-09-24 00:27:42 --> URI Class Initialized
INFO - 2016-09-24 00:27:42 --> Security Class Initialized
INFO - 2016-09-24 00:27:42 --> Router Class Initialized
DEBUG - 2016-09-24 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:42 --> Input Class Initialized
INFO - 2016-09-24 00:27:42 --> Language Class Initialized
INFO - 2016-09-24 00:27:42 --> Output Class Initialized
INFO - 2016-09-24 00:27:42 --> Security Class Initialized
INFO - 2016-09-24 00:27:42 --> Loader Class Initialized
DEBUG - 2016-09-24 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:42 --> Input Class Initialized
INFO - 2016-09-24 00:27:42 --> Language Class Initialized
INFO - 2016-09-24 00:27:42 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:42 --> Loader Class Initialized
INFO - 2016-09-24 00:27:42 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:42 --> Controller Class Initialized
INFO - 2016-09-24 00:27:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:42 --> Model Class Initialized
INFO - 2016-09-24 00:27:42 --> Model Class Initialized
INFO - 2016-09-24 00:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:42 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:42 --> Total execution time: 0.0897
INFO - 2016-09-24 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:42 --> Controller Class Initialized
INFO - 2016-09-24 00:27:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:42 --> Model Class Initialized
INFO - 2016-09-24 00:27:42 --> Model Class Initialized
INFO - 2016-09-24 00:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:42 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:42 --> Total execution time: 0.1172
INFO - 2016-09-24 00:27:47 --> Config Class Initialized
INFO - 2016-09-24 00:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:47 --> Config Class Initialized
INFO - 2016-09-24 00:27:47 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:47 --> URI Class Initialized
DEBUG - 2016-09-24 00:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:47 --> Router Class Initialized
INFO - 2016-09-24 00:27:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:47 --> URI Class Initialized
INFO - 2016-09-24 00:27:47 --> Output Class Initialized
INFO - 2016-09-24 00:27:47 --> Router Class Initialized
INFO - 2016-09-24 00:27:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:47 --> Output Class Initialized
INFO - 2016-09-24 00:27:47 --> Input Class Initialized
INFO - 2016-09-24 00:27:47 --> Language Class Initialized
INFO - 2016-09-24 00:27:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:47 --> Input Class Initialized
INFO - 2016-09-24 00:27:47 --> Loader Class Initialized
INFO - 2016-09-24 00:27:47 --> Language Class Initialized
INFO - 2016-09-24 00:27:47 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:47 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:47 --> Loader Class Initialized
INFO - 2016-09-24 00:27:47 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:47 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:47 --> Controller Class Initialized
INFO - 2016-09-24 00:27:47 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:47 --> Model Class Initialized
INFO - 2016-09-24 00:27:47 --> Model Class Initialized
INFO - 2016-09-24 00:27:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:47 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:47 --> Total execution time: 0.0745
INFO - 2016-09-24 00:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:47 --> Controller Class Initialized
INFO - 2016-09-24 00:27:47 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:47 --> Model Class Initialized
INFO - 2016-09-24 00:27:47 --> Model Class Initialized
INFO - 2016-09-24 00:27:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:47 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:47 --> Total execution time: 0.1199
INFO - 2016-09-24 00:27:49 --> Config Class Initialized
INFO - 2016-09-24 00:27:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:49 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:49 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:49 --> URI Class Initialized
INFO - 2016-09-24 00:27:49 --> Router Class Initialized
INFO - 2016-09-24 00:27:49 --> Output Class Initialized
INFO - 2016-09-24 00:27:49 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:49 --> Input Class Initialized
INFO - 2016-09-24 00:27:49 --> Language Class Initialized
ERROR - 2016-09-24 00:27:49 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:27:53 --> Config Class Initialized
INFO - 2016-09-24 00:27:53 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:54 --> URI Class Initialized
INFO - 2016-09-24 00:27:54 --> Router Class Initialized
INFO - 2016-09-24 00:27:54 --> Output Class Initialized
INFO - 2016-09-24 00:27:54 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:54 --> Input Class Initialized
INFO - 2016-09-24 00:27:54 --> Language Class Initialized
INFO - 2016-09-24 00:27:54 --> Loader Class Initialized
INFO - 2016-09-24 00:27:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:54 --> Controller Class Initialized
INFO - 2016-09-24 00:27:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:54 --> Model Class Initialized
INFO - 2016-09-24 00:27:54 --> Model Class Initialized
INFO - 2016-09-24 00:27:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:54 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:54 --> Total execution time: 0.0930
INFO - 2016-09-24 00:27:55 --> Config Class Initialized
INFO - 2016-09-24 00:27:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:55 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:55 --> URI Class Initialized
INFO - 2016-09-24 00:27:55 --> Config Class Initialized
INFO - 2016-09-24 00:27:55 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:55 --> Router Class Initialized
INFO - 2016-09-24 00:27:55 --> Output Class Initialized
DEBUG - 2016-09-24 00:27:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:55 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:55 --> Security Class Initialized
INFO - 2016-09-24 00:27:55 --> URI Class Initialized
INFO - 2016-09-24 00:27:55 --> Router Class Initialized
DEBUG - 2016-09-24 00:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:55 --> Input Class Initialized
INFO - 2016-09-24 00:27:55 --> Config Class Initialized
INFO - 2016-09-24 00:27:55 --> Hooks Class Initialized
INFO - 2016-09-24 00:27:55 --> Language Class Initialized
INFO - 2016-09-24 00:27:55 --> Output Class Initialized
INFO - 2016-09-24 00:27:55 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:55 --> Input Class Initialized
INFO - 2016-09-24 00:27:55 --> URI Class Initialized
INFO - 2016-09-24 00:27:55 --> Language Class Initialized
INFO - 2016-09-24 00:27:55 --> Loader Class Initialized
INFO - 2016-09-24 00:27:55 --> Router Class Initialized
INFO - 2016-09-24 00:27:55 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:55 --> Helper loaded: language_helper
ERROR - 2016-09-24 00:27:55 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:27:55 --> Output Class Initialized
INFO - 2016-09-24 00:27:55 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:55 --> Input Class Initialized
INFO - 2016-09-24 00:27:55 --> Controller Class Initialized
INFO - 2016-09-24 00:27:55 --> Language Class Initialized
INFO - 2016-09-24 00:27:55 --> Loader Class Initialized
INFO - 2016-09-24 00:27:55 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:55 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:55 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:55 --> Model Class Initialized
INFO - 2016-09-24 00:27:55 --> Model Class Initialized
INFO - 2016-09-24 00:27:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:55 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:55 --> Total execution time: 0.1240
INFO - 2016-09-24 00:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:55 --> Controller Class Initialized
INFO - 2016-09-24 00:27:55 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:55 --> Model Class Initialized
INFO - 2016-09-24 00:27:55 --> Model Class Initialized
INFO - 2016-09-24 00:27:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:55 --> Config Class Initialized
INFO - 2016-09-24 00:27:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:27:55 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:27:55 --> Utf8 Class Initialized
INFO - 2016-09-24 00:27:55 --> URI Class Initialized
INFO - 2016-09-24 00:27:55 --> Router Class Initialized
INFO - 2016-09-24 00:27:55 --> Output Class Initialized
INFO - 2016-09-24 00:27:55 --> Security Class Initialized
DEBUG - 2016-09-24 00:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:27:55 --> Input Class Initialized
INFO - 2016-09-24 00:27:55 --> Language Class Initialized
INFO - 2016-09-24 00:27:55 --> Loader Class Initialized
INFO - 2016-09-24 00:27:55 --> Helper loaded: url_helper
INFO - 2016-09-24 00:27:55 --> Helper loaded: language_helper
INFO - 2016-09-24 00:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:27:55 --> Controller Class Initialized
INFO - 2016-09-24 00:27:55 --> Database Driver Class Initialized
INFO - 2016-09-24 00:27:55 --> Model Class Initialized
INFO - 2016-09-24 00:27:55 --> Model Class Initialized
INFO - 2016-09-24 00:27:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:27:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:27:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2016-09-24 00:27:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:27:55 --> Final output sent to browser
DEBUG - 2016-09-24 00:27:55 --> Total execution time: 0.0876
INFO - 2016-09-24 00:28:00 --> Config Class Initialized
INFO - 2016-09-24 00:28:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:00 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:00 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:00 --> URI Class Initialized
INFO - 2016-09-24 00:28:00 --> Router Class Initialized
INFO - 2016-09-24 00:28:00 --> Output Class Initialized
INFO - 2016-09-24 00:28:00 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:00 --> Input Class Initialized
INFO - 2016-09-24 00:28:00 --> Language Class Initialized
INFO - 2016-09-24 00:28:00 --> Loader Class Initialized
INFO - 2016-09-24 00:28:00 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:00 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:00 --> Controller Class Initialized
INFO - 2016-09-24 00:28:00 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:00 --> Config Class Initialized
INFO - 2016-09-24 00:28:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:00 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:00 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:00 --> URI Class Initialized
INFO - 2016-09-24 00:28:00 --> Router Class Initialized
INFO - 2016-09-24 00:28:00 --> Output Class Initialized
INFO - 2016-09-24 00:28:00 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:00 --> Input Class Initialized
INFO - 2016-09-24 00:28:00 --> Language Class Initialized
INFO - 2016-09-24 00:28:00 --> Loader Class Initialized
INFO - 2016-09-24 00:28:00 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:00 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:00 --> Controller Class Initialized
INFO - 2016-09-24 00:28:00 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:28:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07_attempt.php
INFO - 2016-09-24 00:28:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:28:00 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:00 --> Total execution time: 0.0785
INFO - 2016-09-24 00:28:00 --> Config Class Initialized
INFO - 2016-09-24 00:28:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:00 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:00 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:00 --> Config Class Initialized
INFO - 2016-09-24 00:28:00 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:00 --> URI Class Initialized
INFO - 2016-09-24 00:28:00 --> Router Class Initialized
DEBUG - 2016-09-24 00:28:00 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:00 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:00 --> Output Class Initialized
INFO - 2016-09-24 00:28:00 --> URI Class Initialized
INFO - 2016-09-24 00:28:00 --> Router Class Initialized
INFO - 2016-09-24 00:28:00 --> Security Class Initialized
INFO - 2016-09-24 00:28:00 --> Output Class Initialized
DEBUG - 2016-09-24 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:00 --> Input Class Initialized
INFO - 2016-09-24 00:28:00 --> Security Class Initialized
INFO - 2016-09-24 00:28:00 --> Language Class Initialized
DEBUG - 2016-09-24 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:00 --> Input Class Initialized
INFO - 2016-09-24 00:28:00 --> Language Class Initialized
INFO - 2016-09-24 00:28:00 --> Loader Class Initialized
INFO - 2016-09-24 00:28:00 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:00 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:00 --> Loader Class Initialized
INFO - 2016-09-24 00:28:00 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:00 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:00 --> Controller Class Initialized
INFO - 2016-09-24 00:28:00 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:00 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:00 --> Total execution time: 0.0831
INFO - 2016-09-24 00:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:00 --> Controller Class Initialized
INFO - 2016-09-24 00:28:00 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Model Class Initialized
INFO - 2016-09-24 00:28:00 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:28:00 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-24 00:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-24 00:28:00 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:00 --> Total execution time: 0.1157
INFO - 2016-09-24 00:28:13 --> Config Class Initialized
INFO - 2016-09-24 00:28:13 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:13 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:13 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:13 --> URI Class Initialized
INFO - 2016-09-24 00:28:13 --> Router Class Initialized
INFO - 2016-09-24 00:28:13 --> Config Class Initialized
INFO - 2016-09-24 00:28:13 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:13 --> Output Class Initialized
INFO - 2016-09-24 00:28:13 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:13 --> Input Class Initialized
DEBUG - 2016-09-24 00:28:13 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:13 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:13 --> Language Class Initialized
INFO - 2016-09-24 00:28:13 --> URI Class Initialized
INFO - 2016-09-24 00:28:13 --> Router Class Initialized
INFO - 2016-09-24 00:28:13 --> Loader Class Initialized
INFO - 2016-09-24 00:28:13 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:13 --> Output Class Initialized
INFO - 2016-09-24 00:28:13 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:13 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:13 --> Input Class Initialized
INFO - 2016-09-24 00:28:13 --> Language Class Initialized
INFO - 2016-09-24 00:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:13 --> Controller Class Initialized
INFO - 2016-09-24 00:28:13 --> Loader Class Initialized
INFO - 2016-09-24 00:28:13 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:13 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:13 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:13 --> Model Class Initialized
INFO - 2016-09-24 00:28:13 --> Model Class Initialized
INFO - 2016-09-24 00:28:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:13 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:13 --> Total execution time: 0.0800
INFO - 2016-09-24 00:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:13 --> Controller Class Initialized
INFO - 2016-09-24 00:28:13 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:13 --> Model Class Initialized
INFO - 2016-09-24 00:28:13 --> Model Class Initialized
INFO - 2016-09-24 00:28:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:13 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:13 --> Total execution time: 0.0911
INFO - 2016-09-24 00:28:18 --> Config Class Initialized
INFO - 2016-09-24 00:28:18 --> Config Class Initialized
INFO - 2016-09-24 00:28:18 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:18 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:18 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:18 --> URI Class Initialized
INFO - 2016-09-24 00:28:18 --> Router Class Initialized
DEBUG - 2016-09-24 00:28:18 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:18 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:18 --> Output Class Initialized
INFO - 2016-09-24 00:28:18 --> URI Class Initialized
INFO - 2016-09-24 00:28:18 --> Security Class Initialized
INFO - 2016-09-24 00:28:18 --> Router Class Initialized
DEBUG - 2016-09-24 00:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:18 --> Input Class Initialized
INFO - 2016-09-24 00:28:18 --> Language Class Initialized
INFO - 2016-09-24 00:28:18 --> Output Class Initialized
INFO - 2016-09-24 00:28:18 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:18 --> Loader Class Initialized
INFO - 2016-09-24 00:28:18 --> Input Class Initialized
INFO - 2016-09-24 00:28:18 --> Language Class Initialized
INFO - 2016-09-24 00:28:18 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:18 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:18 --> Loader Class Initialized
INFO - 2016-09-24 00:28:18 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:18 --> Controller Class Initialized
INFO - 2016-09-24 00:28:18 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:18 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:18 --> Model Class Initialized
INFO - 2016-09-24 00:28:18 --> Model Class Initialized
INFO - 2016-09-24 00:28:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:18 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:18 --> Total execution time: 0.0826
INFO - 2016-09-24 00:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:18 --> Controller Class Initialized
INFO - 2016-09-24 00:28:18 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:18 --> Model Class Initialized
INFO - 2016-09-24 00:28:18 --> Model Class Initialized
INFO - 2016-09-24 00:28:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:18 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:18 --> Total execution time: 0.1081
INFO - 2016-09-24 00:28:27 --> Config Class Initialized
INFO - 2016-09-24 00:28:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:27 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:27 --> URI Class Initialized
INFO - 2016-09-24 00:28:27 --> Config Class Initialized
INFO - 2016-09-24 00:28:27 --> Router Class Initialized
INFO - 2016-09-24 00:28:27 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:27 --> Output Class Initialized
DEBUG - 2016-09-24 00:28:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:27 --> Security Class Initialized
INFO - 2016-09-24 00:28:27 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:27 --> URI Class Initialized
DEBUG - 2016-09-24 00:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:27 --> Input Class Initialized
INFO - 2016-09-24 00:28:27 --> Language Class Initialized
INFO - 2016-09-24 00:28:27 --> Router Class Initialized
INFO - 2016-09-24 00:28:27 --> Output Class Initialized
INFO - 2016-09-24 00:28:27 --> Loader Class Initialized
INFO - 2016-09-24 00:28:27 --> Security Class Initialized
INFO - 2016-09-24 00:28:27 --> Helper loaded: url_helper
DEBUG - 2016-09-24 00:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:27 --> Input Class Initialized
INFO - 2016-09-24 00:28:27 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:27 --> Language Class Initialized
INFO - 2016-09-24 00:28:27 --> Loader Class Initialized
INFO - 2016-09-24 00:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:27 --> Controller Class Initialized
INFO - 2016-09-24 00:28:27 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:27 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:27 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:27 --> Model Class Initialized
INFO - 2016-09-24 00:28:27 --> Model Class Initialized
INFO - 2016-09-24 00:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:27 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:27 --> Total execution time: 0.0722
INFO - 2016-09-24 00:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:27 --> Controller Class Initialized
INFO - 2016-09-24 00:28:27 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:27 --> Model Class Initialized
INFO - 2016-09-24 00:28:27 --> Model Class Initialized
INFO - 2016-09-24 00:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:27 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:27 --> Total execution time: 0.0986
INFO - 2016-09-24 00:28:30 --> Config Class Initialized
INFO - 2016-09-24 00:28:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:30 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:30 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:30 --> URI Class Initialized
INFO - 2016-09-24 00:28:30 --> Router Class Initialized
INFO - 2016-09-24 00:28:30 --> Output Class Initialized
INFO - 2016-09-24 00:28:30 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:30 --> Input Class Initialized
INFO - 2016-09-24 00:28:30 --> Language Class Initialized
ERROR - 2016-09-24 00:28:30 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:28:31 --> Config Class Initialized
INFO - 2016-09-24 00:28:31 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:31 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:31 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:31 --> URI Class Initialized
INFO - 2016-09-24 00:28:31 --> Router Class Initialized
INFO - 2016-09-24 00:28:31 --> Output Class Initialized
INFO - 2016-09-24 00:28:31 --> Config Class Initialized
INFO - 2016-09-24 00:28:31 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:31 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:31 --> Input Class Initialized
INFO - 2016-09-24 00:28:31 --> Language Class Initialized
DEBUG - 2016-09-24 00:28:31 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:31 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:31 --> URI Class Initialized
INFO - 2016-09-24 00:28:31 --> Loader Class Initialized
INFO - 2016-09-24 00:28:31 --> Router Class Initialized
INFO - 2016-09-24 00:28:31 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:31 --> Output Class Initialized
INFO - 2016-09-24 00:28:31 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:31 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:31 --> Input Class Initialized
INFO - 2016-09-24 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:31 --> Language Class Initialized
INFO - 2016-09-24 00:28:31 --> Controller Class Initialized
INFO - 2016-09-24 00:28:31 --> Loader Class Initialized
INFO - 2016-09-24 00:28:31 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:31 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:31 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:31 --> Model Class Initialized
INFO - 2016-09-24 00:28:31 --> Model Class Initialized
INFO - 2016-09-24 00:28:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:31 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:31 --> Total execution time: 0.0733
INFO - 2016-09-24 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:31 --> Controller Class Initialized
INFO - 2016-09-24 00:28:31 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:31 --> Model Class Initialized
INFO - 2016-09-24 00:28:31 --> Model Class Initialized
INFO - 2016-09-24 00:28:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:31 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:31 --> Total execution time: 0.1209
INFO - 2016-09-24 00:28:35 --> Config Class Initialized
INFO - 2016-09-24 00:28:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:35 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:35 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:35 --> URI Class Initialized
INFO - 2016-09-24 00:28:35 --> Router Class Initialized
INFO - 2016-09-24 00:28:35 --> Output Class Initialized
INFO - 2016-09-24 00:28:35 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:35 --> Input Class Initialized
INFO - 2016-09-24 00:28:35 --> Language Class Initialized
INFO - 2016-09-24 00:28:35 --> Loader Class Initialized
INFO - 2016-09-24 00:28:35 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:35 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:35 --> Controller Class Initialized
INFO - 2016-09-24 00:28:35 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:35 --> Model Class Initialized
INFO - 2016-09-24 00:28:35 --> Model Class Initialized
INFO - 2016-09-24 00:28:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:35 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:35 --> Total execution time: 0.0887
INFO - 2016-09-24 00:28:37 --> Config Class Initialized
INFO - 2016-09-24 00:28:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:37 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:37 --> URI Class Initialized
INFO - 2016-09-24 00:28:37 --> Config Class Initialized
INFO - 2016-09-24 00:28:37 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:37 --> Router Class Initialized
INFO - 2016-09-24 00:28:37 --> Config Class Initialized
INFO - 2016-09-24 00:28:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:37 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:37 --> Output Class Initialized
DEBUG - 2016-09-24 00:28:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:37 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:37 --> Security Class Initialized
INFO - 2016-09-24 00:28:37 --> URI Class Initialized
INFO - 2016-09-24 00:28:37 --> URI Class Initialized
INFO - 2016-09-24 00:28:37 --> Router Class Initialized
DEBUG - 2016-09-24 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:37 --> Router Class Initialized
INFO - 2016-09-24 00:28:37 --> Input Class Initialized
INFO - 2016-09-24 00:28:37 --> Language Class Initialized
INFO - 2016-09-24 00:28:37 --> Output Class Initialized
INFO - 2016-09-24 00:28:37 --> Output Class Initialized
INFO - 2016-09-24 00:28:37 --> Security Class Initialized
INFO - 2016-09-24 00:28:37 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-24 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:37 --> Input Class Initialized
INFO - 2016-09-24 00:28:37 --> Input Class Initialized
INFO - 2016-09-24 00:28:37 --> Loader Class Initialized
INFO - 2016-09-24 00:28:37 --> Language Class Initialized
INFO - 2016-09-24 00:28:37 --> Language Class Initialized
INFO - 2016-09-24 00:28:37 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:37 --> Helper loaded: language_helper
ERROR - 2016-09-24 00:28:37 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:28:37 --> Loader Class Initialized
INFO - 2016-09-24 00:28:37 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:37 --> Controller Class Initialized
INFO - 2016-09-24 00:28:37 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:37 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:37 --> Model Class Initialized
INFO - 2016-09-24 00:28:37 --> Model Class Initialized
INFO - 2016-09-24 00:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:37 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:37 --> Total execution time: 0.1171
INFO - 2016-09-24 00:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:37 --> Controller Class Initialized
INFO - 2016-09-24 00:28:37 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:37 --> Model Class Initialized
INFO - 2016-09-24 00:28:37 --> Model Class Initialized
INFO - 2016-09-24 00:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:37 --> Config Class Initialized
INFO - 2016-09-24 00:28:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:37 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:37 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:37 --> URI Class Initialized
INFO - 2016-09-24 00:28:37 --> Router Class Initialized
INFO - 2016-09-24 00:28:37 --> Output Class Initialized
INFO - 2016-09-24 00:28:37 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:37 --> Input Class Initialized
INFO - 2016-09-24 00:28:37 --> Language Class Initialized
INFO - 2016-09-24 00:28:37 --> Loader Class Initialized
INFO - 2016-09-24 00:28:37 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:37 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:37 --> Controller Class Initialized
INFO - 2016-09-24 00:28:37 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:37 --> Model Class Initialized
INFO - 2016-09-24 00:28:37 --> Model Class Initialized
INFO - 2016-09-24 00:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:28:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2016-09-24 00:28:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:28:37 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:37 --> Total execution time: 0.0869
INFO - 2016-09-24 00:28:42 --> Config Class Initialized
INFO - 2016-09-24 00:28:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:42 --> URI Class Initialized
INFO - 2016-09-24 00:28:42 --> Router Class Initialized
INFO - 2016-09-24 00:28:42 --> Output Class Initialized
INFO - 2016-09-24 00:28:42 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:42 --> Input Class Initialized
INFO - 2016-09-24 00:28:42 --> Language Class Initialized
INFO - 2016-09-24 00:28:42 --> Loader Class Initialized
INFO - 2016-09-24 00:28:42 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:42 --> Controller Class Initialized
INFO - 2016-09-24 00:28:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:42 --> Model Class Initialized
INFO - 2016-09-24 00:28:42 --> Model Class Initialized
INFO - 2016-09-24 00:28:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:42 --> Config Class Initialized
INFO - 2016-09-24 00:28:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:42 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:42 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:42 --> URI Class Initialized
INFO - 2016-09-24 00:28:42 --> Router Class Initialized
INFO - 2016-09-24 00:28:42 --> Output Class Initialized
INFO - 2016-09-24 00:28:42 --> Security Class Initialized
DEBUG - 2016-09-24 00:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:42 --> Input Class Initialized
INFO - 2016-09-24 00:28:42 --> Language Class Initialized
INFO - 2016-09-24 00:28:42 --> Loader Class Initialized
INFO - 2016-09-24 00:28:42 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:42 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:42 --> Controller Class Initialized
INFO - 2016-09-24 00:28:42 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:42 --> Model Class Initialized
INFO - 2016-09-24 00:28:42 --> Model Class Initialized
INFO - 2016-09-24 00:28:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:28:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08_attempt.php
INFO - 2016-09-24 00:28:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:28:42 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:42 --> Total execution time: 0.0640
INFO - 2016-09-24 00:28:43 --> Config Class Initialized
INFO - 2016-09-24 00:28:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:28:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:43 --> Config Class Initialized
INFO - 2016-09-24 00:28:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:43 --> Hooks Class Initialized
INFO - 2016-09-24 00:28:43 --> URI Class Initialized
DEBUG - 2016-09-24 00:28:43 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:28:43 --> Utf8 Class Initialized
INFO - 2016-09-24 00:28:43 --> Router Class Initialized
INFO - 2016-09-24 00:28:43 --> URI Class Initialized
INFO - 2016-09-24 00:28:43 --> Output Class Initialized
INFO - 2016-09-24 00:28:43 --> Router Class Initialized
INFO - 2016-09-24 00:28:43 --> Security Class Initialized
INFO - 2016-09-24 00:28:43 --> Output Class Initialized
DEBUG - 2016-09-24 00:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:43 --> Input Class Initialized
INFO - 2016-09-24 00:28:43 --> Security Class Initialized
INFO - 2016-09-24 00:28:43 --> Language Class Initialized
DEBUG - 2016-09-24 00:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:28:43 --> Input Class Initialized
INFO - 2016-09-24 00:28:43 --> Language Class Initialized
INFO - 2016-09-24 00:28:43 --> Loader Class Initialized
INFO - 2016-09-24 00:28:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:43 --> Loader Class Initialized
INFO - 2016-09-24 00:28:43 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:43 --> Helper loaded: url_helper
INFO - 2016-09-24 00:28:43 --> Helper loaded: language_helper
INFO - 2016-09-24 00:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:43 --> Controller Class Initialized
INFO - 2016-09-24 00:28:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:43 --> Model Class Initialized
INFO - 2016-09-24 00:28:43 --> Model Class Initialized
INFO - 2016-09-24 00:28:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:28:43 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:43 --> Total execution time: 0.0807
INFO - 2016-09-24 00:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:28:43 --> Controller Class Initialized
INFO - 2016-09-24 00:28:43 --> Database Driver Class Initialized
INFO - 2016-09-24 00:28:43 --> Model Class Initialized
INFO - 2016-09-24 00:28:43 --> Model Class Initialized
INFO - 2016-09-24 00:28:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:28:43 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-24 00:28:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-24 00:28:43 --> Final output sent to browser
DEBUG - 2016-09-24 00:28:43 --> Total execution time: 0.1148
INFO - 2016-09-24 00:29:00 --> Config Class Initialized
INFO - 2016-09-24 00:29:00 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:00 --> Config Class Initialized
INFO - 2016-09-24 00:29:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:00 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:00 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:29:00 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:00 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:00 --> URI Class Initialized
INFO - 2016-09-24 00:29:00 --> URI Class Initialized
INFO - 2016-09-24 00:29:00 --> Router Class Initialized
INFO - 2016-09-24 00:29:00 --> Router Class Initialized
INFO - 2016-09-24 00:29:00 --> Output Class Initialized
INFO - 2016-09-24 00:29:00 --> Security Class Initialized
INFO - 2016-09-24 00:29:00 --> Output Class Initialized
DEBUG - 2016-09-24 00:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:00 --> Input Class Initialized
INFO - 2016-09-24 00:29:00 --> Security Class Initialized
INFO - 2016-09-24 00:29:00 --> Language Class Initialized
DEBUG - 2016-09-24 00:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:00 --> Input Class Initialized
INFO - 2016-09-24 00:29:00 --> Language Class Initialized
INFO - 2016-09-24 00:29:00 --> Loader Class Initialized
INFO - 2016-09-24 00:29:00 --> Loader Class Initialized
INFO - 2016-09-24 00:29:00 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:00 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:00 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:00 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:00 --> Controller Class Initialized
INFO - 2016-09-24 00:29:00 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:00 --> Model Class Initialized
INFO - 2016-09-24 00:29:00 --> Model Class Initialized
INFO - 2016-09-24 00:29:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:00 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:00 --> Total execution time: 0.0778
INFO - 2016-09-24 00:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:00 --> Controller Class Initialized
INFO - 2016-09-24 00:29:00 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:00 --> Model Class Initialized
INFO - 2016-09-24 00:29:00 --> Model Class Initialized
INFO - 2016-09-24 00:29:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:00 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:00 --> Total execution time: 0.1084
INFO - 2016-09-24 00:29:10 --> Config Class Initialized
INFO - 2016-09-24 00:29:10 --> Config Class Initialized
INFO - 2016-09-24 00:29:10 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:29:10 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:10 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:10 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:10 --> URI Class Initialized
INFO - 2016-09-24 00:29:10 --> URI Class Initialized
INFO - 2016-09-24 00:29:10 --> Router Class Initialized
INFO - 2016-09-24 00:29:10 --> Router Class Initialized
INFO - 2016-09-24 00:29:10 --> Output Class Initialized
INFO - 2016-09-24 00:29:10 --> Output Class Initialized
INFO - 2016-09-24 00:29:10 --> Security Class Initialized
INFO - 2016-09-24 00:29:10 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-24 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:10 --> Input Class Initialized
INFO - 2016-09-24 00:29:10 --> Input Class Initialized
INFO - 2016-09-24 00:29:10 --> Language Class Initialized
INFO - 2016-09-24 00:29:10 --> Language Class Initialized
INFO - 2016-09-24 00:29:10 --> Loader Class Initialized
INFO - 2016-09-24 00:29:10 --> Loader Class Initialized
INFO - 2016-09-24 00:29:10 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:10 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:10 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:10 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:10 --> Controller Class Initialized
INFO - 2016-09-24 00:29:10 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:10 --> Model Class Initialized
INFO - 2016-09-24 00:29:10 --> Model Class Initialized
INFO - 2016-09-24 00:29:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:10 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:10 --> Total execution time: 0.0800
INFO - 2016-09-24 00:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:10 --> Controller Class Initialized
INFO - 2016-09-24 00:29:10 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:10 --> Model Class Initialized
INFO - 2016-09-24 00:29:10 --> Model Class Initialized
INFO - 2016-09-24 00:29:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:10 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:10 --> Total execution time: 0.1075
INFO - 2016-09-24 00:29:13 --> Config Class Initialized
INFO - 2016-09-24 00:29:13 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:13 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:13 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:13 --> URI Class Initialized
INFO - 2016-09-24 00:29:13 --> Router Class Initialized
INFO - 2016-09-24 00:29:13 --> Output Class Initialized
INFO - 2016-09-24 00:29:13 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:13 --> Input Class Initialized
INFO - 2016-09-24 00:29:13 --> Language Class Initialized
ERROR - 2016-09-24 00:29:13 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:29:15 --> Config Class Initialized
INFO - 2016-09-24 00:29:15 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:15 --> Config Class Initialized
DEBUG - 2016-09-24 00:29:15 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:15 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:15 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:15 --> URI Class Initialized
DEBUG - 2016-09-24 00:29:15 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:15 --> Router Class Initialized
INFO - 2016-09-24 00:29:15 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:15 --> URI Class Initialized
INFO - 2016-09-24 00:29:15 --> Output Class Initialized
INFO - 2016-09-24 00:29:15 --> Router Class Initialized
INFO - 2016-09-24 00:29:15 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:15 --> Output Class Initialized
INFO - 2016-09-24 00:29:15 --> Input Class Initialized
INFO - 2016-09-24 00:29:15 --> Language Class Initialized
INFO - 2016-09-24 00:29:15 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:15 --> Input Class Initialized
INFO - 2016-09-24 00:29:15 --> Loader Class Initialized
INFO - 2016-09-24 00:29:15 --> Language Class Initialized
INFO - 2016-09-24 00:29:15 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:15 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:15 --> Loader Class Initialized
INFO - 2016-09-24 00:29:15 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:15 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:15 --> Controller Class Initialized
INFO - 2016-09-24 00:29:15 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:15 --> Model Class Initialized
INFO - 2016-09-24 00:29:15 --> Model Class Initialized
INFO - 2016-09-24 00:29:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:15 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:15 --> Total execution time: 0.0742
INFO - 2016-09-24 00:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:15 --> Controller Class Initialized
INFO - 2016-09-24 00:29:15 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:15 --> Model Class Initialized
INFO - 2016-09-24 00:29:15 --> Model Class Initialized
INFO - 2016-09-24 00:29:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:15 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:15 --> Total execution time: 0.1079
INFO - 2016-09-24 00:29:19 --> Config Class Initialized
INFO - 2016-09-24 00:29:19 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:19 --> Config Class Initialized
INFO - 2016-09-24 00:29:19 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 00:29:19 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:19 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:19 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:19 --> URI Class Initialized
INFO - 2016-09-24 00:29:19 --> URI Class Initialized
INFO - 2016-09-24 00:29:19 --> Router Class Initialized
INFO - 2016-09-24 00:29:19 --> Router Class Initialized
INFO - 2016-09-24 00:29:19 --> Output Class Initialized
INFO - 2016-09-24 00:29:19 --> Output Class Initialized
INFO - 2016-09-24 00:29:19 --> Security Class Initialized
INFO - 2016-09-24 00:29:19 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:19 --> Input Class Initialized
DEBUG - 2016-09-24 00:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:19 --> Input Class Initialized
INFO - 2016-09-24 00:29:19 --> Language Class Initialized
INFO - 2016-09-24 00:29:19 --> Language Class Initialized
INFO - 2016-09-24 00:29:19 --> Loader Class Initialized
INFO - 2016-09-24 00:29:19 --> Loader Class Initialized
INFO - 2016-09-24 00:29:19 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:19 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:19 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:19 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:19 --> Controller Class Initialized
INFO - 2016-09-24 00:29:19 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:19 --> Model Class Initialized
INFO - 2016-09-24 00:29:19 --> Model Class Initialized
INFO - 2016-09-24 00:29:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:19 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:19 --> Total execution time: 0.0734
INFO - 2016-09-24 00:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:19 --> Controller Class Initialized
INFO - 2016-09-24 00:29:19 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:19 --> Model Class Initialized
INFO - 2016-09-24 00:29:19 --> Model Class Initialized
INFO - 2016-09-24 00:29:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:19 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:19 --> Total execution time: 0.1157
INFO - 2016-09-24 00:29:23 --> Config Class Initialized
INFO - 2016-09-24 00:29:23 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:23 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:23 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:23 --> URI Class Initialized
INFO - 2016-09-24 00:29:23 --> Router Class Initialized
INFO - 2016-09-24 00:29:23 --> Output Class Initialized
INFO - 2016-09-24 00:29:23 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:23 --> Input Class Initialized
INFO - 2016-09-24 00:29:23 --> Language Class Initialized
INFO - 2016-09-24 00:29:23 --> Loader Class Initialized
INFO - 2016-09-24 00:29:23 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:23 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:23 --> Controller Class Initialized
INFO - 2016-09-24 00:29:23 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:23 --> Model Class Initialized
INFO - 2016-09-24 00:29:23 --> Model Class Initialized
INFO - 2016-09-24 00:29:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:23 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:23 --> Total execution time: 0.0862
INFO - 2016-09-24 00:29:24 --> Config Class Initialized
INFO - 2016-09-24 00:29:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:24 --> URI Class Initialized
INFO - 2016-09-24 00:29:24 --> Router Class Initialized
INFO - 2016-09-24 00:29:24 --> Config Class Initialized
INFO - 2016-09-24 00:29:24 --> Output Class Initialized
INFO - 2016-09-24 00:29:24 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:24 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-24 00:29:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:24 --> Input Class Initialized
INFO - 2016-09-24 00:29:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:24 --> Language Class Initialized
INFO - 2016-09-24 00:29:24 --> URI Class Initialized
INFO - 2016-09-24 00:29:24 --> Loader Class Initialized
INFO - 2016-09-24 00:29:24 --> Router Class Initialized
INFO - 2016-09-24 00:29:24 --> Config Class Initialized
INFO - 2016-09-24 00:29:24 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:24 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:24 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:29:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:24 --> Output Class Initialized
INFO - 2016-09-24 00:29:24 --> URI Class Initialized
INFO - 2016-09-24 00:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:24 --> Controller Class Initialized
INFO - 2016-09-24 00:29:24 --> Router Class Initialized
INFO - 2016-09-24 00:29:24 --> Security Class Initialized
INFO - 2016-09-24 00:29:24 --> Output Class Initialized
DEBUG - 2016-09-24 00:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:24 --> Input Class Initialized
INFO - 2016-09-24 00:29:24 --> Security Class Initialized
INFO - 2016-09-24 00:29:24 --> Language Class Initialized
DEBUG - 2016-09-24 00:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:24 --> Input Class Initialized
INFO - 2016-09-24 00:29:24 --> Language Class Initialized
ERROR - 2016-09-24 00:29:24 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:29:24 --> Loader Class Initialized
INFO - 2016-09-24 00:29:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:24 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:24 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:24 --> Model Class Initialized
INFO - 2016-09-24 00:29:24 --> Model Class Initialized
INFO - 2016-09-24 00:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:24 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:24 --> Total execution time: 0.1381
INFO - 2016-09-24 00:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:24 --> Controller Class Initialized
INFO - 2016-09-24 00:29:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:24 --> Model Class Initialized
INFO - 2016-09-24 00:29:24 --> Model Class Initialized
INFO - 2016-09-24 00:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:24 --> Config Class Initialized
INFO - 2016-09-24 00:29:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:24 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:24 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:24 --> URI Class Initialized
INFO - 2016-09-24 00:29:24 --> Router Class Initialized
INFO - 2016-09-24 00:29:24 --> Output Class Initialized
INFO - 2016-09-24 00:29:24 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:24 --> Input Class Initialized
INFO - 2016-09-24 00:29:24 --> Language Class Initialized
INFO - 2016-09-24 00:29:24 --> Loader Class Initialized
INFO - 2016-09-24 00:29:24 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:24 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:24 --> Controller Class Initialized
INFO - 2016-09-24 00:29:24 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:24 --> Model Class Initialized
INFO - 2016-09-24 00:29:24 --> Model Class Initialized
INFO - 2016-09-24 00:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-24 00:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:29:24 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:24 --> Total execution time: 0.0884
INFO - 2016-09-24 00:29:28 --> Config Class Initialized
INFO - 2016-09-24 00:29:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:28 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:28 --> URI Class Initialized
INFO - 2016-09-24 00:29:28 --> Router Class Initialized
INFO - 2016-09-24 00:29:28 --> Output Class Initialized
INFO - 2016-09-24 00:29:28 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:28 --> Input Class Initialized
INFO - 2016-09-24 00:29:28 --> Language Class Initialized
INFO - 2016-09-24 00:29:28 --> Loader Class Initialized
INFO - 2016-09-24 00:29:28 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:28 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:28 --> Controller Class Initialized
INFO - 2016-09-24 00:29:28 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:28 --> Model Class Initialized
INFO - 2016-09-24 00:29:28 --> Model Class Initialized
INFO - 2016-09-24 00:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:28 --> Config Class Initialized
INFO - 2016-09-24 00:29:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:28 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:28 --> URI Class Initialized
INFO - 2016-09-24 00:29:28 --> Router Class Initialized
INFO - 2016-09-24 00:29:28 --> Output Class Initialized
INFO - 2016-09-24 00:29:28 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:28 --> Input Class Initialized
INFO - 2016-09-24 00:29:28 --> Language Class Initialized
INFO - 2016-09-24 00:29:28 --> Loader Class Initialized
INFO - 2016-09-24 00:29:28 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:28 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:28 --> Controller Class Initialized
INFO - 2016-09-24 00:29:28 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:28 --> Model Class Initialized
INFO - 2016-09-24 00:29:28 --> Model Class Initialized
INFO - 2016-09-24 00:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-24 00:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:29:28 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:28 --> Total execution time: 0.0650
INFO - 2016-09-24 00:29:28 --> Config Class Initialized
INFO - 2016-09-24 00:29:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:28 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:28 --> URI Class Initialized
INFO - 2016-09-24 00:29:28 --> Config Class Initialized
INFO - 2016-09-24 00:29:28 --> Router Class Initialized
INFO - 2016-09-24 00:29:28 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:28 --> Output Class Initialized
DEBUG - 2016-09-24 00:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:28 --> Security Class Initialized
INFO - 2016-09-24 00:29:28 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:28 --> URI Class Initialized
INFO - 2016-09-24 00:29:28 --> Input Class Initialized
INFO - 2016-09-24 00:29:28 --> Language Class Initialized
INFO - 2016-09-24 00:29:28 --> Router Class Initialized
INFO - 2016-09-24 00:29:28 --> Output Class Initialized
INFO - 2016-09-24 00:29:28 --> Loader Class Initialized
INFO - 2016-09-24 00:29:28 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:28 --> Security Class Initialized
INFO - 2016-09-24 00:29:28 --> Helper loaded: language_helper
DEBUG - 2016-09-24 00:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:28 --> Input Class Initialized
INFO - 2016-09-24 00:29:28 --> Language Class Initialized
INFO - 2016-09-24 00:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:28 --> Controller Class Initialized
INFO - 2016-09-24 00:29:28 --> Loader Class Initialized
INFO - 2016-09-24 00:29:28 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:28 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:28 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:28 --> Model Class Initialized
INFO - 2016-09-24 00:29:28 --> Model Class Initialized
INFO - 2016-09-24 00:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:28 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:28 --> Total execution time: 0.0828
INFO - 2016-09-24 00:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:28 --> Controller Class Initialized
INFO - 2016-09-24 00:29:29 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:29 --> Model Class Initialized
INFO - 2016-09-24 00:29:29 --> Model Class Initialized
INFO - 2016-09-24 00:29:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 00:29:29 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-24 00:29:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-24 00:29:29 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:29 --> Total execution time: 0.1106
INFO - 2016-09-24 00:29:45 --> Config Class Initialized
INFO - 2016-09-24 00:29:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:45 --> URI Class Initialized
INFO - 2016-09-24 00:29:45 --> Router Class Initialized
INFO - 2016-09-24 00:29:45 --> Output Class Initialized
INFO - 2016-09-24 00:29:45 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:45 --> Input Class Initialized
INFO - 2016-09-24 00:29:45 --> Config Class Initialized
INFO - 2016-09-24 00:29:45 --> Language Class Initialized
INFO - 2016-09-24 00:29:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:45 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:45 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:45 --> Loader Class Initialized
INFO - 2016-09-24 00:29:45 --> URI Class Initialized
INFO - 2016-09-24 00:29:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:45 --> Router Class Initialized
INFO - 2016-09-24 00:29:45 --> Output Class Initialized
INFO - 2016-09-24 00:29:45 --> Security Class Initialized
INFO - 2016-09-24 00:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:45 --> Controller Class Initialized
DEBUG - 2016-09-24 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:45 --> Input Class Initialized
INFO - 2016-09-24 00:29:45 --> Language Class Initialized
INFO - 2016-09-24 00:29:45 --> Loader Class Initialized
INFO - 2016-09-24 00:29:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:45 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:45 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:45 --> Model Class Initialized
INFO - 2016-09-24 00:29:45 --> Model Class Initialized
INFO - 2016-09-24 00:29:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:45 --> Total execution time: 0.0738
INFO - 2016-09-24 00:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:45 --> Controller Class Initialized
INFO - 2016-09-24 00:29:45 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:45 --> Model Class Initialized
INFO - 2016-09-24 00:29:45 --> Model Class Initialized
INFO - 2016-09-24 00:29:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:45 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:45 --> Total execution time: 0.0879
INFO - 2016-09-24 00:29:47 --> Config Class Initialized
INFO - 2016-09-24 00:29:47 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:47 --> Config Class Initialized
DEBUG - 2016-09-24 00:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:47 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:47 --> URI Class Initialized
DEBUG - 2016-09-24 00:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:47 --> Router Class Initialized
INFO - 2016-09-24 00:29:47 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:47 --> URI Class Initialized
INFO - 2016-09-24 00:29:47 --> Output Class Initialized
INFO - 2016-09-24 00:29:47 --> Security Class Initialized
INFO - 2016-09-24 00:29:47 --> Router Class Initialized
DEBUG - 2016-09-24 00:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:47 --> Input Class Initialized
INFO - 2016-09-24 00:29:47 --> Output Class Initialized
INFO - 2016-09-24 00:29:47 --> Language Class Initialized
INFO - 2016-09-24 00:29:47 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:47 --> Input Class Initialized
INFO - 2016-09-24 00:29:47 --> Loader Class Initialized
INFO - 2016-09-24 00:29:47 --> Language Class Initialized
INFO - 2016-09-24 00:29:47 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:47 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:47 --> Loader Class Initialized
INFO - 2016-09-24 00:29:47 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:47 --> Controller Class Initialized
INFO - 2016-09-24 00:29:47 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:47 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:47 --> Model Class Initialized
INFO - 2016-09-24 00:29:47 --> Model Class Initialized
INFO - 2016-09-24 00:29:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:47 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:47 --> Total execution time: 0.0839
INFO - 2016-09-24 00:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:47 --> Controller Class Initialized
INFO - 2016-09-24 00:29:47 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:47 --> Model Class Initialized
INFO - 2016-09-24 00:29:47 --> Model Class Initialized
INFO - 2016-09-24 00:29:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:47 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:47 --> Total execution time: 0.1127
INFO - 2016-09-24 00:29:48 --> Config Class Initialized
INFO - 2016-09-24 00:29:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:48 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:48 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:48 --> Config Class Initialized
INFO - 2016-09-24 00:29:48 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:48 --> URI Class Initialized
INFO - 2016-09-24 00:29:48 --> Router Class Initialized
INFO - 2016-09-24 00:29:48 --> Output Class Initialized
DEBUG - 2016-09-24 00:29:48 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:48 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:48 --> Security Class Initialized
INFO - 2016-09-24 00:29:48 --> URI Class Initialized
DEBUG - 2016-09-24 00:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:48 --> Input Class Initialized
INFO - 2016-09-24 00:29:48 --> Router Class Initialized
INFO - 2016-09-24 00:29:48 --> Language Class Initialized
INFO - 2016-09-24 00:29:48 --> Output Class Initialized
INFO - 2016-09-24 00:29:48 --> Security Class Initialized
INFO - 2016-09-24 00:29:48 --> Loader Class Initialized
DEBUG - 2016-09-24 00:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:48 --> Input Class Initialized
INFO - 2016-09-24 00:29:48 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:48 --> Language Class Initialized
INFO - 2016-09-24 00:29:48 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:48 --> Loader Class Initialized
INFO - 2016-09-24 00:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:48 --> Controller Class Initialized
INFO - 2016-09-24 00:29:48 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:48 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:48 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:48 --> Model Class Initialized
INFO - 2016-09-24 00:29:48 --> Model Class Initialized
INFO - 2016-09-24 00:29:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:48 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:48 --> Total execution time: 0.0940
INFO - 2016-09-24 00:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:48 --> Controller Class Initialized
INFO - 2016-09-24 00:29:49 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:49 --> Model Class Initialized
INFO - 2016-09-24 00:29:49 --> Model Class Initialized
INFO - 2016-09-24 00:29:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:49 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:49 --> Total execution time: 0.1226
INFO - 2016-09-24 00:29:50 --> Config Class Initialized
INFO - 2016-09-24 00:29:50 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:50 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:50 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:50 --> URI Class Initialized
INFO - 2016-09-24 00:29:51 --> Router Class Initialized
INFO - 2016-09-24 00:29:51 --> Config Class Initialized
INFO - 2016-09-24 00:29:51 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:51 --> Output Class Initialized
INFO - 2016-09-24 00:29:51 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:51 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:51 --> Input Class Initialized
INFO - 2016-09-24 00:29:51 --> URI Class Initialized
INFO - 2016-09-24 00:29:51 --> Language Class Initialized
INFO - 2016-09-24 00:29:51 --> Router Class Initialized
INFO - 2016-09-24 00:29:51 --> Output Class Initialized
INFO - 2016-09-24 00:29:51 --> Loader Class Initialized
INFO - 2016-09-24 00:29:51 --> Security Class Initialized
INFO - 2016-09-24 00:29:51 --> Helper loaded: url_helper
DEBUG - 2016-09-24 00:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:51 --> Input Class Initialized
INFO - 2016-09-24 00:29:51 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:51 --> Language Class Initialized
INFO - 2016-09-24 00:29:51 --> Loader Class Initialized
INFO - 2016-09-24 00:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:51 --> Controller Class Initialized
INFO - 2016-09-24 00:29:51 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:51 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:51 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:51 --> Model Class Initialized
INFO - 2016-09-24 00:29:51 --> Model Class Initialized
INFO - 2016-09-24 00:29:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:51 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:51 --> Total execution time: 0.0867
INFO - 2016-09-24 00:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:51 --> Controller Class Initialized
INFO - 2016-09-24 00:29:51 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:51 --> Model Class Initialized
INFO - 2016-09-24 00:29:51 --> Model Class Initialized
INFO - 2016-09-24 00:29:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:51 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:51 --> Total execution time: 0.1015
INFO - 2016-09-24 00:29:53 --> Config Class Initialized
INFO - 2016-09-24 00:29:53 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:53 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:53 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:53 --> URI Class Initialized
INFO - 2016-09-24 00:29:53 --> Router Class Initialized
INFO - 2016-09-24 00:29:53 --> Output Class Initialized
INFO - 2016-09-24 00:29:53 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:53 --> Input Class Initialized
INFO - 2016-09-24 00:29:53 --> Language Class Initialized
INFO - 2016-09-24 00:29:53 --> Loader Class Initialized
INFO - 2016-09-24 00:29:53 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:53 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:53 --> Controller Class Initialized
INFO - 2016-09-24 00:29:53 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:53 --> Model Class Initialized
INFO - 2016-09-24 00:29:53 --> Model Class Initialized
INFO - 2016-09-24 00:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:53 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:53 --> Total execution time: 0.0847
INFO - 2016-09-24 00:29:54 --> Config Class Initialized
INFO - 2016-09-24 00:29:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:54 --> Config Class Initialized
INFO - 2016-09-24 00:29:54 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:54 --> URI Class Initialized
DEBUG - 2016-09-24 00:29:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:54 --> Router Class Initialized
INFO - 2016-09-24 00:29:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:54 --> Config Class Initialized
INFO - 2016-09-24 00:29:54 --> Hooks Class Initialized
INFO - 2016-09-24 00:29:54 --> URI Class Initialized
INFO - 2016-09-24 00:29:54 --> Output Class Initialized
INFO - 2016-09-24 00:29:54 --> Security Class Initialized
INFO - 2016-09-24 00:29:54 --> Router Class Initialized
DEBUG - 2016-09-24 00:29:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:54 --> Utf8 Class Initialized
DEBUG - 2016-09-24 00:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:54 --> Input Class Initialized
INFO - 2016-09-24 00:29:54 --> URI Class Initialized
INFO - 2016-09-24 00:29:54 --> Language Class Initialized
INFO - 2016-09-24 00:29:54 --> Output Class Initialized
INFO - 2016-09-24 00:29:54 --> Router Class Initialized
INFO - 2016-09-24 00:29:54 --> Security Class Initialized
INFO - 2016-09-24 00:29:54 --> Output Class Initialized
DEBUG - 2016-09-24 00:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:54 --> Input Class Initialized
INFO - 2016-09-24 00:29:54 --> Security Class Initialized
INFO - 2016-09-24 00:29:54 --> Language Class Initialized
DEBUG - 2016-09-24 00:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:54 --> Input Class Initialized
INFO - 2016-09-24 00:29:54 --> Language Class Initialized
ERROR - 2016-09-24 00:29:54 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 00:29:54 --> Loader Class Initialized
INFO - 2016-09-24 00:29:54 --> Loader Class Initialized
INFO - 2016-09-24 00:29:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:54 --> Controller Class Initialized
INFO - 2016-09-24 00:29:54 --> Controller Class Initialized
INFO - 2016-09-24 00:29:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:54 --> Model Class Initialized
INFO - 2016-09-24 00:29:54 --> Model Class Initialized
INFO - 2016-09-24 00:29:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:54 --> Model Class Initialized
INFO - 2016-09-24 00:29:54 --> Model Class Initialized
INFO - 2016-09-24 00:29:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:54 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:54 --> Total execution time: 0.1445
INFO - 2016-09-24 00:29:54 --> Config Class Initialized
INFO - 2016-09-24 00:29:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 00:29:54 --> UTF-8 Support Enabled
INFO - 2016-09-24 00:29:54 --> Utf8 Class Initialized
INFO - 2016-09-24 00:29:54 --> URI Class Initialized
INFO - 2016-09-24 00:29:54 --> Router Class Initialized
INFO - 2016-09-24 00:29:54 --> Output Class Initialized
INFO - 2016-09-24 00:29:54 --> Security Class Initialized
DEBUG - 2016-09-24 00:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 00:29:54 --> Input Class Initialized
INFO - 2016-09-24 00:29:54 --> Language Class Initialized
INFO - 2016-09-24 00:29:54 --> Loader Class Initialized
INFO - 2016-09-24 00:29:54 --> Helper loaded: url_helper
INFO - 2016-09-24 00:29:54 --> Helper loaded: language_helper
INFO - 2016-09-24 00:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 00:29:54 --> Controller Class Initialized
INFO - 2016-09-24 00:29:54 --> Database Driver Class Initialized
INFO - 2016-09-24 00:29:54 --> Model Class Initialized
INFO - 2016-09-24 00:29:54 --> Model Class Initialized
INFO - 2016-09-24 00:29:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 00:29:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 00:29:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-24 00:29:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 00:29:54 --> Final output sent to browser
DEBUG - 2016-09-24 00:29:54 --> Total execution time: 0.0950
INFO - 2016-09-24 09:33:07 --> Config Class Initialized
INFO - 2016-09-24 09:33:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:07 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:07 --> URI Class Initialized
INFO - 2016-09-24 09:33:07 --> Router Class Initialized
INFO - 2016-09-24 09:33:07 --> Output Class Initialized
INFO - 2016-09-24 09:33:07 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:07 --> Input Class Initialized
INFO - 2016-09-24 09:33:07 --> Language Class Initialized
INFO - 2016-09-24 09:33:07 --> Loader Class Initialized
INFO - 2016-09-24 09:33:07 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:07 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:07 --> Controller Class Initialized
INFO - 2016-09-24 09:33:07 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:07 --> Model Class Initialized
INFO - 2016-09-24 09:33:07 --> Model Class Initialized
INFO - 2016-09-24 09:33:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:07 --> Config Class Initialized
INFO - 2016-09-24 09:33:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:07 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:07 --> URI Class Initialized
INFO - 2016-09-24 09:33:07 --> Router Class Initialized
INFO - 2016-09-24 09:33:07 --> Output Class Initialized
INFO - 2016-09-24 09:33:07 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:07 --> Input Class Initialized
INFO - 2016-09-24 09:33:07 --> Language Class Initialized
INFO - 2016-09-24 09:33:07 --> Loader Class Initialized
INFO - 2016-09-24 09:33:07 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:07 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:07 --> Controller Class Initialized
INFO - 2016-09-24 09:33:07 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:07 --> Model Class Initialized
INFO - 2016-09-24 09:33:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-24 09:33:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-24 09:33:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-24 09:33:07 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:07 --> Total execution time: 0.0713
INFO - 2016-09-24 09:33:12 --> Config Class Initialized
INFO - 2016-09-24 09:33:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:12 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:12 --> URI Class Initialized
INFO - 2016-09-24 09:33:12 --> Router Class Initialized
INFO - 2016-09-24 09:33:12 --> Output Class Initialized
INFO - 2016-09-24 09:33:12 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:12 --> Input Class Initialized
INFO - 2016-09-24 09:33:12 --> Language Class Initialized
INFO - 2016-09-24 09:33:12 --> Loader Class Initialized
INFO - 2016-09-24 09:33:12 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:12 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:12 --> Controller Class Initialized
INFO - 2016-09-24 09:33:12 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:12 --> Model Class Initialized
INFO - 2016-09-24 09:33:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:12 --> Config Class Initialized
INFO - 2016-09-24 09:33:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:12 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:12 --> URI Class Initialized
INFO - 2016-09-24 09:33:12 --> Router Class Initialized
INFO - 2016-09-24 09:33:12 --> Output Class Initialized
INFO - 2016-09-24 09:33:12 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:12 --> Input Class Initialized
INFO - 2016-09-24 09:33:12 --> Language Class Initialized
INFO - 2016-09-24 09:33:12 --> Loader Class Initialized
INFO - 2016-09-24 09:33:12 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:12 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:12 --> Controller Class Initialized
INFO - 2016-09-24 09:33:12 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:12 --> Model Class Initialized
INFO - 2016-09-24 09:33:12 --> Model Class Initialized
INFO - 2016-09-24 09:33:12 --> Model Class Initialized
INFO - 2016-09-24 09:33:12 --> Model Class Initialized
INFO - 2016-09-24 09:33:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 09:33:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-24 09:33:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 09:33:12 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:12 --> Total execution time: 0.0750
INFO - 2016-09-24 09:33:17 --> Config Class Initialized
INFO - 2016-09-24 09:33:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:17 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:17 --> URI Class Initialized
INFO - 2016-09-24 09:33:17 --> Router Class Initialized
INFO - 2016-09-24 09:33:17 --> Output Class Initialized
INFO - 2016-09-24 09:33:17 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:17 --> Input Class Initialized
INFO - 2016-09-24 09:33:17 --> Language Class Initialized
INFO - 2016-09-24 09:33:17 --> Loader Class Initialized
INFO - 2016-09-24 09:33:17 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:17 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:17 --> Controller Class Initialized
INFO - 2016-09-24 09:33:17 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:17 --> Model Class Initialized
INFO - 2016-09-24 09:33:17 --> Model Class Initialized
INFO - 2016-09-24 09:33:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 09:33:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-24 09:33:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 09:33:17 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:17 --> Total execution time: 0.0585
INFO - 2016-09-24 09:33:18 --> Config Class Initialized
INFO - 2016-09-24 09:33:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:18 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:18 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:18 --> URI Class Initialized
INFO - 2016-09-24 09:33:18 --> Router Class Initialized
INFO - 2016-09-24 09:33:18 --> Output Class Initialized
INFO - 2016-09-24 09:33:18 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:18 --> Input Class Initialized
INFO - 2016-09-24 09:33:18 --> Language Class Initialized
INFO - 2016-09-24 09:33:18 --> Loader Class Initialized
INFO - 2016-09-24 09:33:18 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:18 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:18 --> Controller Class Initialized
INFO - 2016-09-24 09:33:18 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:18 --> Model Class Initialized
INFO - 2016-09-24 09:33:18 --> Model Class Initialized
INFO - 2016-09-24 09:33:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 09:33:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-09-24 09:33:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 09:33:18 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:18 --> Total execution time: 0.0721
INFO - 2016-09-24 09:33:21 --> Config Class Initialized
INFO - 2016-09-24 09:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:21 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:21 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:21 --> URI Class Initialized
INFO - 2016-09-24 09:33:21 --> Router Class Initialized
INFO - 2016-09-24 09:33:21 --> Output Class Initialized
INFO - 2016-09-24 09:33:21 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:21 --> Input Class Initialized
INFO - 2016-09-24 09:33:21 --> Language Class Initialized
INFO - 2016-09-24 09:33:21 --> Loader Class Initialized
INFO - 2016-09-24 09:33:21 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:21 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:21 --> Controller Class Initialized
INFO - 2016-09-24 09:33:21 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:21 --> Model Class Initialized
INFO - 2016-09-24 09:33:21 --> Model Class Initialized
INFO - 2016-09-24 09:33:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 09:33:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2016-09-24 09:33:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 09:33:21 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:21 --> Total execution time: 0.0726
INFO - 2016-09-24 09:33:27 --> Config Class Initialized
INFO - 2016-09-24 09:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:27 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:27 --> URI Class Initialized
INFO - 2016-09-24 09:33:27 --> Router Class Initialized
INFO - 2016-09-24 09:33:27 --> Output Class Initialized
INFO - 2016-09-24 09:33:27 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:27 --> Input Class Initialized
INFO - 2016-09-24 09:33:27 --> Language Class Initialized
INFO - 2016-09-24 09:33:27 --> Loader Class Initialized
INFO - 2016-09-24 09:33:27 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:27 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:27 --> Controller Class Initialized
INFO - 2016-09-24 09:33:27 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:27 --> Model Class Initialized
INFO - 2016-09-24 09:33:27 --> Model Class Initialized
INFO - 2016-09-24 09:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:27 --> Config Class Initialized
INFO - 2016-09-24 09:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:27 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:27 --> URI Class Initialized
INFO - 2016-09-24 09:33:27 --> Router Class Initialized
INFO - 2016-09-24 09:33:27 --> Output Class Initialized
INFO - 2016-09-24 09:33:27 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:27 --> Input Class Initialized
INFO - 2016-09-24 09:33:27 --> Language Class Initialized
INFO - 2016-09-24 09:33:27 --> Loader Class Initialized
INFO - 2016-09-24 09:33:27 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:27 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:27 --> Controller Class Initialized
INFO - 2016-09-24 09:33:27 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:27 --> Model Class Initialized
INFO - 2016-09-24 09:33:27 --> Model Class Initialized
INFO - 2016-09-24 09:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-24 09:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-09-24 09:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-24 09:33:27 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:27 --> Total execution time: 0.0757
INFO - 2016-09-24 09:33:27 --> Config Class Initialized
INFO - 2016-09-24 09:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:27 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:27 --> URI Class Initialized
INFO - 2016-09-24 09:33:27 --> Config Class Initialized
INFO - 2016-09-24 09:33:27 --> Hooks Class Initialized
INFO - 2016-09-24 09:33:27 --> Router Class Initialized
INFO - 2016-09-24 09:33:27 --> Output Class Initialized
INFO - 2016-09-24 09:33:27 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:27 --> Input Class Initialized
INFO - 2016-09-24 09:33:27 --> Language Class Initialized
DEBUG - 2016-09-24 09:33:27 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:27 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:27 --> URI Class Initialized
INFO - 2016-09-24 09:33:27 --> Loader Class Initialized
INFO - 2016-09-24 09:33:27 --> Router Class Initialized
INFO - 2016-09-24 09:33:27 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:27 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:27 --> Output Class Initialized
INFO - 2016-09-24 09:33:27 --> Security Class Initialized
INFO - 2016-09-24 09:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:27 --> Controller Class Initialized
DEBUG - 2016-09-24 09:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:27 --> Input Class Initialized
INFO - 2016-09-24 09:33:27 --> Language Class Initialized
INFO - 2016-09-24 09:33:27 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:27 --> Loader Class Initialized
INFO - 2016-09-24 09:33:27 --> Helper loaded: url_helper
INFO - 2016-09-24 09:33:27 --> Model Class Initialized
INFO - 2016-09-24 09:33:27 --> Helper loaded: language_helper
INFO - 2016-09-24 09:33:27 --> Model Class Initialized
INFO - 2016-09-24 09:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:27 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:27 --> Total execution time: 0.0929
INFO - 2016-09-24 09:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:33:27 --> Controller Class Initialized
INFO - 2016-09-24 09:33:28 --> Database Driver Class Initialized
INFO - 2016-09-24 09:33:28 --> Model Class Initialized
INFO - 2016-09-24 09:33:28 --> Model Class Initialized
INFO - 2016-09-24 09:33:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:33:28 --> Final output sent to browser
DEBUG - 2016-09-24 09:33:28 --> Total execution time: 0.1343
INFO - 2016-09-24 09:33:58 --> Config Class Initialized
INFO - 2016-09-24 09:33:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:33:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:33:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:33:58 --> URI Class Initialized
INFO - 2016-09-24 09:33:58 --> Router Class Initialized
INFO - 2016-09-24 09:33:58 --> Output Class Initialized
INFO - 2016-09-24 09:33:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:33:58 --> Input Class Initialized
INFO - 2016-09-24 09:33:58 --> Language Class Initialized
ERROR - 2016-09-24 09:33:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:34:14 --> Config Class Initialized
INFO - 2016-09-24 09:34:14 --> Hooks Class Initialized
INFO - 2016-09-24 09:34:14 --> Config Class Initialized
INFO - 2016-09-24 09:34:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:34:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 09:34:14 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:34:14 --> Utf8 Class Initialized
INFO - 2016-09-24 09:34:14 --> Utf8 Class Initialized
INFO - 2016-09-24 09:34:14 --> URI Class Initialized
INFO - 2016-09-24 09:34:14 --> URI Class Initialized
INFO - 2016-09-24 09:34:14 --> Router Class Initialized
INFO - 2016-09-24 09:34:14 --> Router Class Initialized
INFO - 2016-09-24 09:34:14 --> Output Class Initialized
INFO - 2016-09-24 09:34:14 --> Output Class Initialized
INFO - 2016-09-24 09:34:14 --> Security Class Initialized
INFO - 2016-09-24 09:34:14 --> Security Class Initialized
DEBUG - 2016-09-24 09:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-24 09:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:34:14 --> Input Class Initialized
INFO - 2016-09-24 09:34:14 --> Input Class Initialized
INFO - 2016-09-24 09:34:14 --> Language Class Initialized
INFO - 2016-09-24 09:34:14 --> Language Class Initialized
INFO - 2016-09-24 09:34:14 --> Loader Class Initialized
INFO - 2016-09-24 09:34:14 --> Loader Class Initialized
INFO - 2016-09-24 09:34:14 --> Helper loaded: url_helper
INFO - 2016-09-24 09:34:14 --> Helper loaded: url_helper
INFO - 2016-09-24 09:34:14 --> Helper loaded: language_helper
INFO - 2016-09-24 09:34:14 --> Helper loaded: language_helper
INFO - 2016-09-24 09:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:34:14 --> Controller Class Initialized
INFO - 2016-09-24 09:34:14 --> Database Driver Class Initialized
INFO - 2016-09-24 09:34:14 --> Model Class Initialized
INFO - 2016-09-24 09:34:14 --> Model Class Initialized
INFO - 2016-09-24 09:34:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:34:14 --> Final output sent to browser
DEBUG - 2016-09-24 09:34:14 --> Total execution time: 0.0700
INFO - 2016-09-24 09:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:34:14 --> Controller Class Initialized
INFO - 2016-09-24 09:34:14 --> Database Driver Class Initialized
INFO - 2016-09-24 09:34:14 --> Model Class Initialized
INFO - 2016-09-24 09:34:14 --> Model Class Initialized
INFO - 2016-09-24 09:34:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 5 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 6 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 7 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 8 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 10 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 11 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 12 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 13 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 14 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined offset: 15 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:34:14 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
INFO - 2016-09-24 09:34:14 --> Final output sent to browser
DEBUG - 2016-09-24 09:34:14 --> Total execution time: 0.2289
INFO - 2016-09-24 09:34:28 --> Config Class Initialized
INFO - 2016-09-24 09:34:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:34:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:34:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:34:28 --> URI Class Initialized
INFO - 2016-09-24 09:34:28 --> Router Class Initialized
INFO - 2016-09-24 09:34:28 --> Output Class Initialized
INFO - 2016-09-24 09:34:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:34:28 --> Input Class Initialized
INFO - 2016-09-24 09:34:28 --> Language Class Initialized
ERROR - 2016-09-24 09:34:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:34:57 --> Config Class Initialized
INFO - 2016-09-24 09:34:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:34:57 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:34:57 --> Utf8 Class Initialized
INFO - 2016-09-24 09:34:57 --> URI Class Initialized
INFO - 2016-09-24 09:34:57 --> Router Class Initialized
INFO - 2016-09-24 09:34:57 --> Output Class Initialized
INFO - 2016-09-24 09:34:57 --> Security Class Initialized
DEBUG - 2016-09-24 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:34:57 --> Input Class Initialized
INFO - 2016-09-24 09:34:57 --> Language Class Initialized
ERROR - 2016-09-24 09:34:57 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:35:07 --> Config Class Initialized
INFO - 2016-09-24 09:35:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:35:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:35:07 --> Utf8 Class Initialized
INFO - 2016-09-24 09:35:07 --> URI Class Initialized
INFO - 2016-09-24 09:35:07 --> Config Class Initialized
INFO - 2016-09-24 09:35:07 --> Hooks Class Initialized
INFO - 2016-09-24 09:35:07 --> Router Class Initialized
INFO - 2016-09-24 09:35:07 --> Output Class Initialized
DEBUG - 2016-09-24 09:35:07 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:35:07 --> Utf8 Class Initialized
INFO - 2016-09-24 09:35:07 --> Security Class Initialized
INFO - 2016-09-24 09:35:07 --> URI Class Initialized
DEBUG - 2016-09-24 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:35:07 --> Input Class Initialized
INFO - 2016-09-24 09:35:07 --> Router Class Initialized
INFO - 2016-09-24 09:35:07 --> Language Class Initialized
INFO - 2016-09-24 09:35:07 --> Output Class Initialized
INFO - 2016-09-24 09:35:07 --> Security Class Initialized
INFO - 2016-09-24 09:35:07 --> Loader Class Initialized
INFO - 2016-09-24 09:35:07 --> Helper loaded: url_helper
DEBUG - 2016-09-24 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:35:07 --> Input Class Initialized
INFO - 2016-09-24 09:35:07 --> Helper loaded: language_helper
INFO - 2016-09-24 09:35:07 --> Language Class Initialized
INFO - 2016-09-24 09:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:35:07 --> Controller Class Initialized
INFO - 2016-09-24 09:35:07 --> Loader Class Initialized
INFO - 2016-09-24 09:35:07 --> Helper loaded: url_helper
INFO - 2016-09-24 09:35:07 --> Helper loaded: language_helper
INFO - 2016-09-24 09:35:07 --> Database Driver Class Initialized
INFO - 2016-09-24 09:35:07 --> Model Class Initialized
INFO - 2016-09-24 09:35:07 --> Model Class Initialized
INFO - 2016-09-24 09:35:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-24 09:35:07 --> Final output sent to browser
DEBUG - 2016-09-24 09:35:07 --> Total execution time: 0.0697
INFO - 2016-09-24 09:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-24 09:35:07 --> Controller Class Initialized
INFO - 2016-09-24 09:35:07 --> Database Driver Class Initialized
INFO - 2016-09-24 09:35:07 --> Model Class Initialized
INFO - 2016-09-24 09:35:07 --> Model Class Initialized
INFO - 2016-09-24 09:35:07 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-24 09:35:07 --> Severity: Notice --> Undefined variable: ans_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:35:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 409
ERROR - 2016-09-24 09:35:07 --> Severity: Notice --> Undefined variable: ans_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:35:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 425
ERROR - 2016-09-24 09:35:07 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 370
ERROR - 2016-09-24 09:35:07 --> Query error: Column 'qid' cannot be null - Invalid query: INSERT INTO `savsoft_answers` (`rid`, `qid`, `uid`, `q_option`, `score_u`) VALUES ('74', NULL, '1', 'musim,cuaca', 0)
INFO - 2016-09-24 09:35:07 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-24 09:35:28 --> Config Class Initialized
INFO - 2016-09-24 09:35:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:35:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:35:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:35:28 --> URI Class Initialized
INFO - 2016-09-24 09:35:28 --> Router Class Initialized
INFO - 2016-09-24 09:35:28 --> Output Class Initialized
INFO - 2016-09-24 09:35:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:35:28 --> Input Class Initialized
INFO - 2016-09-24 09:35:28 --> Language Class Initialized
ERROR - 2016-09-24 09:35:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:35:58 --> Config Class Initialized
INFO - 2016-09-24 09:35:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:35:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:35:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:35:58 --> URI Class Initialized
INFO - 2016-09-24 09:35:58 --> Router Class Initialized
INFO - 2016-09-24 09:35:58 --> Output Class Initialized
INFO - 2016-09-24 09:35:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:35:58 --> Input Class Initialized
INFO - 2016-09-24 09:35:58 --> Language Class Initialized
ERROR - 2016-09-24 09:35:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:36:28 --> Config Class Initialized
INFO - 2016-09-24 09:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:36:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:36:28 --> URI Class Initialized
INFO - 2016-09-24 09:36:28 --> Router Class Initialized
INFO - 2016-09-24 09:36:28 --> Output Class Initialized
INFO - 2016-09-24 09:36:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:36:28 --> Input Class Initialized
INFO - 2016-09-24 09:36:28 --> Language Class Initialized
ERROR - 2016-09-24 09:36:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:36:58 --> Config Class Initialized
INFO - 2016-09-24 09:36:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:36:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:36:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:36:58 --> URI Class Initialized
INFO - 2016-09-24 09:36:58 --> Router Class Initialized
INFO - 2016-09-24 09:36:58 --> Output Class Initialized
INFO - 2016-09-24 09:36:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:36:58 --> Input Class Initialized
INFO - 2016-09-24 09:36:58 --> Language Class Initialized
ERROR - 2016-09-24 09:36:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:37:28 --> Config Class Initialized
INFO - 2016-09-24 09:37:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:37:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:37:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:37:28 --> URI Class Initialized
INFO - 2016-09-24 09:37:28 --> Router Class Initialized
INFO - 2016-09-24 09:37:28 --> Output Class Initialized
INFO - 2016-09-24 09:37:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:37:28 --> Input Class Initialized
INFO - 2016-09-24 09:37:28 --> Language Class Initialized
ERROR - 2016-09-24 09:37:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:37:58 --> Config Class Initialized
INFO - 2016-09-24 09:37:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:37:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:37:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:37:58 --> URI Class Initialized
INFO - 2016-09-24 09:37:58 --> Router Class Initialized
INFO - 2016-09-24 09:37:58 --> Output Class Initialized
INFO - 2016-09-24 09:37:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:37:58 --> Input Class Initialized
INFO - 2016-09-24 09:37:58 --> Language Class Initialized
ERROR - 2016-09-24 09:37:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:38:28 --> Config Class Initialized
INFO - 2016-09-24 09:38:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:38:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:38:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:38:28 --> URI Class Initialized
INFO - 2016-09-24 09:38:28 --> Router Class Initialized
INFO - 2016-09-24 09:38:28 --> Output Class Initialized
INFO - 2016-09-24 09:38:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:38:28 --> Input Class Initialized
INFO - 2016-09-24 09:38:28 --> Language Class Initialized
ERROR - 2016-09-24 09:38:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:38:58 --> Config Class Initialized
INFO - 2016-09-24 09:38:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:38:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:38:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:38:58 --> URI Class Initialized
INFO - 2016-09-24 09:38:58 --> Router Class Initialized
INFO - 2016-09-24 09:38:58 --> Output Class Initialized
INFO - 2016-09-24 09:38:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:38:58 --> Input Class Initialized
INFO - 2016-09-24 09:38:58 --> Language Class Initialized
ERROR - 2016-09-24 09:38:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:39:28 --> Config Class Initialized
INFO - 2016-09-24 09:39:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:39:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:39:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:39:28 --> URI Class Initialized
INFO - 2016-09-24 09:39:28 --> Router Class Initialized
INFO - 2016-09-24 09:39:28 --> Output Class Initialized
INFO - 2016-09-24 09:39:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:39:28 --> Input Class Initialized
INFO - 2016-09-24 09:39:28 --> Language Class Initialized
ERROR - 2016-09-24 09:39:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:39:58 --> Config Class Initialized
INFO - 2016-09-24 09:39:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:39:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:39:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:39:58 --> URI Class Initialized
INFO - 2016-09-24 09:39:58 --> Router Class Initialized
INFO - 2016-09-24 09:39:58 --> Output Class Initialized
INFO - 2016-09-24 09:39:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:39:58 --> Input Class Initialized
INFO - 2016-09-24 09:39:58 --> Language Class Initialized
ERROR - 2016-09-24 09:39:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:40:28 --> Config Class Initialized
INFO - 2016-09-24 09:40:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:40:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:40:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:40:28 --> URI Class Initialized
INFO - 2016-09-24 09:40:28 --> Router Class Initialized
INFO - 2016-09-24 09:40:28 --> Output Class Initialized
INFO - 2016-09-24 09:40:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:40:28 --> Input Class Initialized
INFO - 2016-09-24 09:40:28 --> Language Class Initialized
ERROR - 2016-09-24 09:40:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:40:58 --> Config Class Initialized
INFO - 2016-09-24 09:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:40:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:40:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:40:58 --> URI Class Initialized
INFO - 2016-09-24 09:40:58 --> Router Class Initialized
INFO - 2016-09-24 09:40:58 --> Output Class Initialized
INFO - 2016-09-24 09:40:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:40:58 --> Input Class Initialized
INFO - 2016-09-24 09:40:58 --> Language Class Initialized
ERROR - 2016-09-24 09:40:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:41:28 --> Config Class Initialized
INFO - 2016-09-24 09:41:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:41:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:41:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:41:28 --> URI Class Initialized
INFO - 2016-09-24 09:41:28 --> Router Class Initialized
INFO - 2016-09-24 09:41:28 --> Output Class Initialized
INFO - 2016-09-24 09:41:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:41:28 --> Input Class Initialized
INFO - 2016-09-24 09:41:28 --> Language Class Initialized
ERROR - 2016-09-24 09:41:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:41:58 --> Config Class Initialized
INFO - 2016-09-24 09:41:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:41:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:41:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:41:58 --> URI Class Initialized
INFO - 2016-09-24 09:41:58 --> Router Class Initialized
INFO - 2016-09-24 09:41:58 --> Output Class Initialized
INFO - 2016-09-24 09:41:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:41:58 --> Input Class Initialized
INFO - 2016-09-24 09:41:58 --> Language Class Initialized
ERROR - 2016-09-24 09:41:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:42:28 --> Config Class Initialized
INFO - 2016-09-24 09:42:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:42:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:42:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:42:28 --> URI Class Initialized
INFO - 2016-09-24 09:42:28 --> Router Class Initialized
INFO - 2016-09-24 09:42:28 --> Output Class Initialized
INFO - 2016-09-24 09:42:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:42:28 --> Input Class Initialized
INFO - 2016-09-24 09:42:28 --> Language Class Initialized
ERROR - 2016-09-24 09:42:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:42:58 --> Config Class Initialized
INFO - 2016-09-24 09:42:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:42:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:42:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:42:58 --> URI Class Initialized
INFO - 2016-09-24 09:42:58 --> Router Class Initialized
INFO - 2016-09-24 09:42:58 --> Output Class Initialized
INFO - 2016-09-24 09:42:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:42:58 --> Input Class Initialized
INFO - 2016-09-24 09:42:58 --> Language Class Initialized
ERROR - 2016-09-24 09:42:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:43:28 --> Config Class Initialized
INFO - 2016-09-24 09:43:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:43:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:43:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:43:28 --> URI Class Initialized
INFO - 2016-09-24 09:43:28 --> Router Class Initialized
INFO - 2016-09-24 09:43:28 --> Output Class Initialized
INFO - 2016-09-24 09:43:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:43:28 --> Input Class Initialized
INFO - 2016-09-24 09:43:28 --> Language Class Initialized
ERROR - 2016-09-24 09:43:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:43:58 --> Config Class Initialized
INFO - 2016-09-24 09:43:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:43:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:43:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:43:58 --> URI Class Initialized
INFO - 2016-09-24 09:43:58 --> Router Class Initialized
INFO - 2016-09-24 09:43:58 --> Output Class Initialized
INFO - 2016-09-24 09:43:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:43:58 --> Input Class Initialized
INFO - 2016-09-24 09:43:58 --> Language Class Initialized
ERROR - 2016-09-24 09:43:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:44:28 --> Config Class Initialized
INFO - 2016-09-24 09:44:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:44:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:44:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:44:28 --> URI Class Initialized
INFO - 2016-09-24 09:44:28 --> Router Class Initialized
INFO - 2016-09-24 09:44:28 --> Output Class Initialized
INFO - 2016-09-24 09:44:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:44:28 --> Input Class Initialized
INFO - 2016-09-24 09:44:28 --> Language Class Initialized
ERROR - 2016-09-24 09:44:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:44:58 --> Config Class Initialized
INFO - 2016-09-24 09:44:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:44:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:44:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:44:58 --> URI Class Initialized
INFO - 2016-09-24 09:44:58 --> Router Class Initialized
INFO - 2016-09-24 09:44:58 --> Output Class Initialized
INFO - 2016-09-24 09:44:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:44:58 --> Input Class Initialized
INFO - 2016-09-24 09:44:58 --> Language Class Initialized
ERROR - 2016-09-24 09:44:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:45:28 --> Config Class Initialized
INFO - 2016-09-24 09:45:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:45:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:45:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:45:28 --> URI Class Initialized
INFO - 2016-09-24 09:45:28 --> Router Class Initialized
INFO - 2016-09-24 09:45:28 --> Output Class Initialized
INFO - 2016-09-24 09:45:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:45:28 --> Input Class Initialized
INFO - 2016-09-24 09:45:28 --> Language Class Initialized
ERROR - 2016-09-24 09:45:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:45:58 --> Config Class Initialized
INFO - 2016-09-24 09:45:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:45:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:45:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:45:58 --> URI Class Initialized
INFO - 2016-09-24 09:45:58 --> Router Class Initialized
INFO - 2016-09-24 09:45:58 --> Output Class Initialized
INFO - 2016-09-24 09:45:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:45:58 --> Input Class Initialized
INFO - 2016-09-24 09:45:58 --> Language Class Initialized
ERROR - 2016-09-24 09:45:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:46:28 --> Config Class Initialized
INFO - 2016-09-24 09:46:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:46:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:46:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:46:28 --> URI Class Initialized
INFO - 2016-09-24 09:46:28 --> Router Class Initialized
INFO - 2016-09-24 09:46:28 --> Output Class Initialized
INFO - 2016-09-24 09:46:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:46:28 --> Input Class Initialized
INFO - 2016-09-24 09:46:28 --> Language Class Initialized
ERROR - 2016-09-24 09:46:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:46:58 --> Config Class Initialized
INFO - 2016-09-24 09:46:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:46:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:46:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:46:58 --> URI Class Initialized
INFO - 2016-09-24 09:46:58 --> Router Class Initialized
INFO - 2016-09-24 09:46:58 --> Output Class Initialized
INFO - 2016-09-24 09:46:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:46:58 --> Input Class Initialized
INFO - 2016-09-24 09:46:58 --> Language Class Initialized
ERROR - 2016-09-24 09:46:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:47:28 --> Config Class Initialized
INFO - 2016-09-24 09:47:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:47:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:47:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:47:28 --> URI Class Initialized
INFO - 2016-09-24 09:47:28 --> Router Class Initialized
INFO - 2016-09-24 09:47:28 --> Output Class Initialized
INFO - 2016-09-24 09:47:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:47:28 --> Input Class Initialized
INFO - 2016-09-24 09:47:28 --> Language Class Initialized
ERROR - 2016-09-24 09:47:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:47:58 --> Config Class Initialized
INFO - 2016-09-24 09:47:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:47:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:47:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:47:58 --> URI Class Initialized
INFO - 2016-09-24 09:47:58 --> Router Class Initialized
INFO - 2016-09-24 09:47:58 --> Output Class Initialized
INFO - 2016-09-24 09:47:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:47:58 --> Input Class Initialized
INFO - 2016-09-24 09:47:58 --> Language Class Initialized
ERROR - 2016-09-24 09:47:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:48:28 --> Config Class Initialized
INFO - 2016-09-24 09:48:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:48:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:48:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:48:28 --> URI Class Initialized
INFO - 2016-09-24 09:48:28 --> Router Class Initialized
INFO - 2016-09-24 09:48:28 --> Output Class Initialized
INFO - 2016-09-24 09:48:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:48:28 --> Input Class Initialized
INFO - 2016-09-24 09:48:28 --> Language Class Initialized
ERROR - 2016-09-24 09:48:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:48:58 --> Config Class Initialized
INFO - 2016-09-24 09:48:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:48:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:48:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:48:58 --> URI Class Initialized
INFO - 2016-09-24 09:48:58 --> Router Class Initialized
INFO - 2016-09-24 09:48:58 --> Output Class Initialized
INFO - 2016-09-24 09:48:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:48:58 --> Input Class Initialized
INFO - 2016-09-24 09:48:58 --> Language Class Initialized
ERROR - 2016-09-24 09:48:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:49:28 --> Config Class Initialized
INFO - 2016-09-24 09:49:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:49:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:49:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:49:28 --> URI Class Initialized
INFO - 2016-09-24 09:49:28 --> Router Class Initialized
INFO - 2016-09-24 09:49:28 --> Output Class Initialized
INFO - 2016-09-24 09:49:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:49:28 --> Input Class Initialized
INFO - 2016-09-24 09:49:28 --> Language Class Initialized
ERROR - 2016-09-24 09:49:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:49:58 --> Config Class Initialized
INFO - 2016-09-24 09:49:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:49:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:49:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:49:58 --> URI Class Initialized
INFO - 2016-09-24 09:49:58 --> Router Class Initialized
INFO - 2016-09-24 09:49:58 --> Output Class Initialized
INFO - 2016-09-24 09:49:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:49:58 --> Input Class Initialized
INFO - 2016-09-24 09:49:58 --> Language Class Initialized
ERROR - 2016-09-24 09:49:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:50:28 --> Config Class Initialized
INFO - 2016-09-24 09:50:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:50:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:50:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:50:28 --> URI Class Initialized
INFO - 2016-09-24 09:50:28 --> Router Class Initialized
INFO - 2016-09-24 09:50:28 --> Output Class Initialized
INFO - 2016-09-24 09:50:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:50:28 --> Input Class Initialized
INFO - 2016-09-24 09:50:28 --> Language Class Initialized
ERROR - 2016-09-24 09:50:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:50:58 --> Config Class Initialized
INFO - 2016-09-24 09:50:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:50:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:50:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:50:58 --> URI Class Initialized
INFO - 2016-09-24 09:50:58 --> Router Class Initialized
INFO - 2016-09-24 09:50:58 --> Output Class Initialized
INFO - 2016-09-24 09:50:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:50:58 --> Input Class Initialized
INFO - 2016-09-24 09:50:58 --> Language Class Initialized
ERROR - 2016-09-24 09:50:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:51:28 --> Config Class Initialized
INFO - 2016-09-24 09:51:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:51:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:51:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:51:28 --> URI Class Initialized
INFO - 2016-09-24 09:51:28 --> Router Class Initialized
INFO - 2016-09-24 09:51:28 --> Output Class Initialized
INFO - 2016-09-24 09:51:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:51:28 --> Input Class Initialized
INFO - 2016-09-24 09:51:28 --> Language Class Initialized
ERROR - 2016-09-24 09:51:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:51:58 --> Config Class Initialized
INFO - 2016-09-24 09:51:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:51:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:51:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:51:58 --> URI Class Initialized
INFO - 2016-09-24 09:51:58 --> Router Class Initialized
INFO - 2016-09-24 09:51:58 --> Output Class Initialized
INFO - 2016-09-24 09:51:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:51:58 --> Input Class Initialized
INFO - 2016-09-24 09:51:58 --> Language Class Initialized
ERROR - 2016-09-24 09:51:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:52:28 --> Config Class Initialized
INFO - 2016-09-24 09:52:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:52:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:52:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:52:28 --> URI Class Initialized
INFO - 2016-09-24 09:52:28 --> Router Class Initialized
INFO - 2016-09-24 09:52:28 --> Output Class Initialized
INFO - 2016-09-24 09:52:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:52:28 --> Input Class Initialized
INFO - 2016-09-24 09:52:28 --> Language Class Initialized
ERROR - 2016-09-24 09:52:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:52:58 --> Config Class Initialized
INFO - 2016-09-24 09:52:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:52:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:52:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:52:58 --> URI Class Initialized
INFO - 2016-09-24 09:52:58 --> Router Class Initialized
INFO - 2016-09-24 09:52:58 --> Output Class Initialized
INFO - 2016-09-24 09:52:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:52:58 --> Input Class Initialized
INFO - 2016-09-24 09:52:58 --> Language Class Initialized
ERROR - 2016-09-24 09:52:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:53:28 --> Config Class Initialized
INFO - 2016-09-24 09:53:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:53:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:53:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:53:28 --> URI Class Initialized
INFO - 2016-09-24 09:53:28 --> Router Class Initialized
INFO - 2016-09-24 09:53:28 --> Output Class Initialized
INFO - 2016-09-24 09:53:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:53:28 --> Input Class Initialized
INFO - 2016-09-24 09:53:28 --> Language Class Initialized
ERROR - 2016-09-24 09:53:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:53:58 --> Config Class Initialized
INFO - 2016-09-24 09:53:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:53:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:53:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:53:58 --> URI Class Initialized
INFO - 2016-09-24 09:53:58 --> Router Class Initialized
INFO - 2016-09-24 09:53:58 --> Output Class Initialized
INFO - 2016-09-24 09:53:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:53:58 --> Input Class Initialized
INFO - 2016-09-24 09:53:58 --> Language Class Initialized
ERROR - 2016-09-24 09:53:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:54:28 --> Config Class Initialized
INFO - 2016-09-24 09:54:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:54:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:54:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:54:28 --> URI Class Initialized
INFO - 2016-09-24 09:54:28 --> Router Class Initialized
INFO - 2016-09-24 09:54:28 --> Output Class Initialized
INFO - 2016-09-24 09:54:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:54:28 --> Input Class Initialized
INFO - 2016-09-24 09:54:28 --> Language Class Initialized
ERROR - 2016-09-24 09:54:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:54:58 --> Config Class Initialized
INFO - 2016-09-24 09:54:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:54:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:54:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:54:58 --> URI Class Initialized
INFO - 2016-09-24 09:54:58 --> Router Class Initialized
INFO - 2016-09-24 09:54:58 --> Output Class Initialized
INFO - 2016-09-24 09:54:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:54:58 --> Input Class Initialized
INFO - 2016-09-24 09:54:58 --> Language Class Initialized
ERROR - 2016-09-24 09:54:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:55:28 --> Config Class Initialized
INFO - 2016-09-24 09:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:55:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:55:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:55:28 --> URI Class Initialized
INFO - 2016-09-24 09:55:28 --> Router Class Initialized
INFO - 2016-09-24 09:55:28 --> Output Class Initialized
INFO - 2016-09-24 09:55:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:55:28 --> Input Class Initialized
INFO - 2016-09-24 09:55:28 --> Language Class Initialized
ERROR - 2016-09-24 09:55:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:55:58 --> Config Class Initialized
INFO - 2016-09-24 09:55:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:55:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:55:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:55:58 --> URI Class Initialized
INFO - 2016-09-24 09:55:58 --> Router Class Initialized
INFO - 2016-09-24 09:55:58 --> Output Class Initialized
INFO - 2016-09-24 09:55:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:55:58 --> Input Class Initialized
INFO - 2016-09-24 09:55:58 --> Language Class Initialized
ERROR - 2016-09-24 09:55:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:56:28 --> Config Class Initialized
INFO - 2016-09-24 09:56:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:56:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:56:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:56:28 --> URI Class Initialized
INFO - 2016-09-24 09:56:28 --> Router Class Initialized
INFO - 2016-09-24 09:56:28 --> Output Class Initialized
INFO - 2016-09-24 09:56:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:56:28 --> Input Class Initialized
INFO - 2016-09-24 09:56:28 --> Language Class Initialized
ERROR - 2016-09-24 09:56:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:56:58 --> Config Class Initialized
INFO - 2016-09-24 09:56:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:56:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:56:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:56:58 --> URI Class Initialized
INFO - 2016-09-24 09:56:58 --> Router Class Initialized
INFO - 2016-09-24 09:56:58 --> Output Class Initialized
INFO - 2016-09-24 09:56:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:56:58 --> Input Class Initialized
INFO - 2016-09-24 09:56:58 --> Language Class Initialized
ERROR - 2016-09-24 09:56:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:57:28 --> Config Class Initialized
INFO - 2016-09-24 09:57:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:57:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:57:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:57:28 --> URI Class Initialized
INFO - 2016-09-24 09:57:28 --> Router Class Initialized
INFO - 2016-09-24 09:57:28 --> Output Class Initialized
INFO - 2016-09-24 09:57:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:57:28 --> Input Class Initialized
INFO - 2016-09-24 09:57:28 --> Language Class Initialized
ERROR - 2016-09-24 09:57:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:57:58 --> Config Class Initialized
INFO - 2016-09-24 09:57:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:57:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:57:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:57:58 --> URI Class Initialized
INFO - 2016-09-24 09:57:58 --> Router Class Initialized
INFO - 2016-09-24 09:57:58 --> Output Class Initialized
INFO - 2016-09-24 09:57:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:57:58 --> Input Class Initialized
INFO - 2016-09-24 09:57:58 --> Language Class Initialized
ERROR - 2016-09-24 09:57:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:58:28 --> Config Class Initialized
INFO - 2016-09-24 09:58:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:58:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:58:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:58:28 --> URI Class Initialized
INFO - 2016-09-24 09:58:28 --> Router Class Initialized
INFO - 2016-09-24 09:58:28 --> Output Class Initialized
INFO - 2016-09-24 09:58:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:58:28 --> Input Class Initialized
INFO - 2016-09-24 09:58:28 --> Language Class Initialized
ERROR - 2016-09-24 09:58:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:58:58 --> Config Class Initialized
INFO - 2016-09-24 09:58:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:58:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:58:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:58:58 --> URI Class Initialized
INFO - 2016-09-24 09:58:58 --> Router Class Initialized
INFO - 2016-09-24 09:58:58 --> Output Class Initialized
INFO - 2016-09-24 09:58:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:58:58 --> Input Class Initialized
INFO - 2016-09-24 09:58:58 --> Language Class Initialized
ERROR - 2016-09-24 09:58:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:59:28 --> Config Class Initialized
INFO - 2016-09-24 09:59:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:59:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:59:28 --> Utf8 Class Initialized
INFO - 2016-09-24 09:59:28 --> URI Class Initialized
INFO - 2016-09-24 09:59:28 --> Router Class Initialized
INFO - 2016-09-24 09:59:28 --> Output Class Initialized
INFO - 2016-09-24 09:59:28 --> Security Class Initialized
DEBUG - 2016-09-24 09:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:59:28 --> Input Class Initialized
INFO - 2016-09-24 09:59:28 --> Language Class Initialized
ERROR - 2016-09-24 09:59:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 09:59:58 --> Config Class Initialized
INFO - 2016-09-24 09:59:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 09:59:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 09:59:58 --> Utf8 Class Initialized
INFO - 2016-09-24 09:59:58 --> URI Class Initialized
INFO - 2016-09-24 09:59:58 --> Router Class Initialized
INFO - 2016-09-24 09:59:58 --> Output Class Initialized
INFO - 2016-09-24 09:59:58 --> Security Class Initialized
DEBUG - 2016-09-24 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 09:59:58 --> Input Class Initialized
INFO - 2016-09-24 09:59:58 --> Language Class Initialized
ERROR - 2016-09-24 09:59:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:00:28 --> Config Class Initialized
INFO - 2016-09-24 10:00:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:00:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:00:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:00:28 --> URI Class Initialized
INFO - 2016-09-24 10:00:28 --> Router Class Initialized
INFO - 2016-09-24 10:00:28 --> Output Class Initialized
INFO - 2016-09-24 10:00:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:00:28 --> Input Class Initialized
INFO - 2016-09-24 10:00:28 --> Language Class Initialized
ERROR - 2016-09-24 10:00:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:00:58 --> Config Class Initialized
INFO - 2016-09-24 10:00:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:00:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:00:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:00:58 --> URI Class Initialized
INFO - 2016-09-24 10:00:58 --> Router Class Initialized
INFO - 2016-09-24 10:00:58 --> Output Class Initialized
INFO - 2016-09-24 10:00:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:00:58 --> Input Class Initialized
INFO - 2016-09-24 10:00:58 --> Language Class Initialized
ERROR - 2016-09-24 10:00:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:01:28 --> Config Class Initialized
INFO - 2016-09-24 10:01:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:01:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:01:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:01:28 --> URI Class Initialized
INFO - 2016-09-24 10:01:28 --> Router Class Initialized
INFO - 2016-09-24 10:01:28 --> Output Class Initialized
INFO - 2016-09-24 10:01:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:01:28 --> Input Class Initialized
INFO - 2016-09-24 10:01:28 --> Language Class Initialized
ERROR - 2016-09-24 10:01:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:01:58 --> Config Class Initialized
INFO - 2016-09-24 10:01:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:01:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:01:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:01:58 --> URI Class Initialized
INFO - 2016-09-24 10:01:58 --> Router Class Initialized
INFO - 2016-09-24 10:01:58 --> Output Class Initialized
INFO - 2016-09-24 10:01:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:01:58 --> Input Class Initialized
INFO - 2016-09-24 10:01:58 --> Language Class Initialized
ERROR - 2016-09-24 10:01:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:02:28 --> Config Class Initialized
INFO - 2016-09-24 10:02:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:02:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:02:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:02:28 --> URI Class Initialized
INFO - 2016-09-24 10:02:28 --> Router Class Initialized
INFO - 2016-09-24 10:02:28 --> Output Class Initialized
INFO - 2016-09-24 10:02:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:02:28 --> Input Class Initialized
INFO - 2016-09-24 10:02:28 --> Language Class Initialized
ERROR - 2016-09-24 10:02:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:02:58 --> Config Class Initialized
INFO - 2016-09-24 10:02:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:02:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:02:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:02:58 --> URI Class Initialized
INFO - 2016-09-24 10:02:58 --> Router Class Initialized
INFO - 2016-09-24 10:02:58 --> Output Class Initialized
INFO - 2016-09-24 10:02:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:02:58 --> Input Class Initialized
INFO - 2016-09-24 10:02:58 --> Language Class Initialized
ERROR - 2016-09-24 10:02:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:03:28 --> Config Class Initialized
INFO - 2016-09-24 10:03:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:03:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:03:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:03:28 --> URI Class Initialized
INFO - 2016-09-24 10:03:28 --> Router Class Initialized
INFO - 2016-09-24 10:03:28 --> Output Class Initialized
INFO - 2016-09-24 10:03:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:03:28 --> Input Class Initialized
INFO - 2016-09-24 10:03:28 --> Language Class Initialized
ERROR - 2016-09-24 10:03:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:03:58 --> Config Class Initialized
INFO - 2016-09-24 10:03:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:03:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:03:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:03:58 --> URI Class Initialized
INFO - 2016-09-24 10:03:58 --> Router Class Initialized
INFO - 2016-09-24 10:03:58 --> Output Class Initialized
INFO - 2016-09-24 10:03:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:03:58 --> Input Class Initialized
INFO - 2016-09-24 10:03:58 --> Language Class Initialized
ERROR - 2016-09-24 10:03:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:04:28 --> Config Class Initialized
INFO - 2016-09-24 10:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:04:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:04:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:04:28 --> URI Class Initialized
INFO - 2016-09-24 10:04:28 --> Router Class Initialized
INFO - 2016-09-24 10:04:28 --> Output Class Initialized
INFO - 2016-09-24 10:04:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:04:28 --> Input Class Initialized
INFO - 2016-09-24 10:04:28 --> Language Class Initialized
ERROR - 2016-09-24 10:04:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:04:58 --> Config Class Initialized
INFO - 2016-09-24 10:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:04:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:04:58 --> URI Class Initialized
INFO - 2016-09-24 10:04:58 --> Router Class Initialized
INFO - 2016-09-24 10:04:58 --> Output Class Initialized
INFO - 2016-09-24 10:04:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:04:58 --> Input Class Initialized
INFO - 2016-09-24 10:04:58 --> Language Class Initialized
ERROR - 2016-09-24 10:04:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:05:28 --> Config Class Initialized
INFO - 2016-09-24 10:05:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:05:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:05:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:05:28 --> URI Class Initialized
INFO - 2016-09-24 10:05:28 --> Router Class Initialized
INFO - 2016-09-24 10:05:28 --> Output Class Initialized
INFO - 2016-09-24 10:05:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:05:28 --> Input Class Initialized
INFO - 2016-09-24 10:05:28 --> Language Class Initialized
ERROR - 2016-09-24 10:05:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:05:58 --> Config Class Initialized
INFO - 2016-09-24 10:05:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:05:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:05:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:05:58 --> URI Class Initialized
INFO - 2016-09-24 10:05:58 --> Router Class Initialized
INFO - 2016-09-24 10:05:58 --> Output Class Initialized
INFO - 2016-09-24 10:05:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:05:58 --> Input Class Initialized
INFO - 2016-09-24 10:05:58 --> Language Class Initialized
ERROR - 2016-09-24 10:05:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:06:28 --> Config Class Initialized
INFO - 2016-09-24 10:06:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:06:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:06:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:06:28 --> URI Class Initialized
INFO - 2016-09-24 10:06:28 --> Router Class Initialized
INFO - 2016-09-24 10:06:28 --> Output Class Initialized
INFO - 2016-09-24 10:06:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:06:28 --> Input Class Initialized
INFO - 2016-09-24 10:06:28 --> Language Class Initialized
ERROR - 2016-09-24 10:06:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:06:58 --> Config Class Initialized
INFO - 2016-09-24 10:06:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:06:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:06:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:06:58 --> URI Class Initialized
INFO - 2016-09-24 10:06:58 --> Router Class Initialized
INFO - 2016-09-24 10:06:58 --> Output Class Initialized
INFO - 2016-09-24 10:06:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:06:58 --> Input Class Initialized
INFO - 2016-09-24 10:06:58 --> Language Class Initialized
ERROR - 2016-09-24 10:06:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:07:28 --> Config Class Initialized
INFO - 2016-09-24 10:07:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:07:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:07:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:07:28 --> URI Class Initialized
INFO - 2016-09-24 10:07:28 --> Router Class Initialized
INFO - 2016-09-24 10:07:28 --> Output Class Initialized
INFO - 2016-09-24 10:07:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:07:28 --> Input Class Initialized
INFO - 2016-09-24 10:07:28 --> Language Class Initialized
ERROR - 2016-09-24 10:07:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:07:58 --> Config Class Initialized
INFO - 2016-09-24 10:07:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:07:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:07:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:07:58 --> URI Class Initialized
INFO - 2016-09-24 10:07:58 --> Router Class Initialized
INFO - 2016-09-24 10:07:58 --> Output Class Initialized
INFO - 2016-09-24 10:07:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:07:58 --> Input Class Initialized
INFO - 2016-09-24 10:07:58 --> Language Class Initialized
ERROR - 2016-09-24 10:07:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:08:28 --> Config Class Initialized
INFO - 2016-09-24 10:08:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:08:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:08:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:08:28 --> URI Class Initialized
INFO - 2016-09-24 10:08:28 --> Router Class Initialized
INFO - 2016-09-24 10:08:28 --> Output Class Initialized
INFO - 2016-09-24 10:08:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:08:28 --> Input Class Initialized
INFO - 2016-09-24 10:08:28 --> Language Class Initialized
ERROR - 2016-09-24 10:08:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:08:58 --> Config Class Initialized
INFO - 2016-09-24 10:08:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:08:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:08:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:08:58 --> URI Class Initialized
INFO - 2016-09-24 10:08:58 --> Router Class Initialized
INFO - 2016-09-24 10:08:58 --> Output Class Initialized
INFO - 2016-09-24 10:08:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:08:58 --> Input Class Initialized
INFO - 2016-09-24 10:08:58 --> Language Class Initialized
ERROR - 2016-09-24 10:08:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:09:28 --> Config Class Initialized
INFO - 2016-09-24 10:09:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:09:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:09:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:09:28 --> URI Class Initialized
INFO - 2016-09-24 10:09:28 --> Router Class Initialized
INFO - 2016-09-24 10:09:28 --> Output Class Initialized
INFO - 2016-09-24 10:09:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:09:28 --> Input Class Initialized
INFO - 2016-09-24 10:09:28 --> Language Class Initialized
ERROR - 2016-09-24 10:09:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:09:58 --> Config Class Initialized
INFO - 2016-09-24 10:09:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:09:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:09:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:09:58 --> URI Class Initialized
INFO - 2016-09-24 10:09:58 --> Router Class Initialized
INFO - 2016-09-24 10:09:58 --> Output Class Initialized
INFO - 2016-09-24 10:09:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:09:58 --> Input Class Initialized
INFO - 2016-09-24 10:09:58 --> Language Class Initialized
ERROR - 2016-09-24 10:09:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:10:28 --> Config Class Initialized
INFO - 2016-09-24 10:10:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:10:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:10:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:10:28 --> URI Class Initialized
INFO - 2016-09-24 10:10:28 --> Router Class Initialized
INFO - 2016-09-24 10:10:28 --> Output Class Initialized
INFO - 2016-09-24 10:10:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:10:28 --> Input Class Initialized
INFO - 2016-09-24 10:10:28 --> Language Class Initialized
ERROR - 2016-09-24 10:10:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:10:58 --> Config Class Initialized
INFO - 2016-09-24 10:10:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:10:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:10:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:10:58 --> URI Class Initialized
INFO - 2016-09-24 10:10:58 --> Router Class Initialized
INFO - 2016-09-24 10:10:58 --> Output Class Initialized
INFO - 2016-09-24 10:10:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:10:58 --> Input Class Initialized
INFO - 2016-09-24 10:10:58 --> Language Class Initialized
ERROR - 2016-09-24 10:10:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:11:28 --> Config Class Initialized
INFO - 2016-09-24 10:11:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:11:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:11:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:11:28 --> URI Class Initialized
INFO - 2016-09-24 10:11:28 --> Router Class Initialized
INFO - 2016-09-24 10:11:28 --> Output Class Initialized
INFO - 2016-09-24 10:11:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:11:28 --> Input Class Initialized
INFO - 2016-09-24 10:11:28 --> Language Class Initialized
ERROR - 2016-09-24 10:11:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:11:58 --> Config Class Initialized
INFO - 2016-09-24 10:11:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:11:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:11:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:11:58 --> URI Class Initialized
INFO - 2016-09-24 10:11:58 --> Router Class Initialized
INFO - 2016-09-24 10:11:58 --> Output Class Initialized
INFO - 2016-09-24 10:11:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:11:58 --> Input Class Initialized
INFO - 2016-09-24 10:11:58 --> Language Class Initialized
ERROR - 2016-09-24 10:11:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:12:28 --> Config Class Initialized
INFO - 2016-09-24 10:12:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:12:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:12:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:12:28 --> URI Class Initialized
INFO - 2016-09-24 10:12:28 --> Router Class Initialized
INFO - 2016-09-24 10:12:28 --> Output Class Initialized
INFO - 2016-09-24 10:12:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:12:28 --> Input Class Initialized
INFO - 2016-09-24 10:12:28 --> Language Class Initialized
ERROR - 2016-09-24 10:12:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:12:58 --> Config Class Initialized
INFO - 2016-09-24 10:12:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:12:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:12:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:12:58 --> URI Class Initialized
INFO - 2016-09-24 10:12:58 --> Router Class Initialized
INFO - 2016-09-24 10:12:58 --> Output Class Initialized
INFO - 2016-09-24 10:12:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:12:58 --> Input Class Initialized
INFO - 2016-09-24 10:12:58 --> Language Class Initialized
ERROR - 2016-09-24 10:12:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:13:28 --> Config Class Initialized
INFO - 2016-09-24 10:13:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:13:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:13:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:13:28 --> URI Class Initialized
INFO - 2016-09-24 10:13:28 --> Router Class Initialized
INFO - 2016-09-24 10:13:28 --> Output Class Initialized
INFO - 2016-09-24 10:13:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:13:28 --> Input Class Initialized
INFO - 2016-09-24 10:13:28 --> Language Class Initialized
ERROR - 2016-09-24 10:13:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:13:58 --> Config Class Initialized
INFO - 2016-09-24 10:13:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:13:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:13:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:13:58 --> URI Class Initialized
INFO - 2016-09-24 10:13:58 --> Router Class Initialized
INFO - 2016-09-24 10:13:58 --> Output Class Initialized
INFO - 2016-09-24 10:13:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:13:58 --> Input Class Initialized
INFO - 2016-09-24 10:13:58 --> Language Class Initialized
ERROR - 2016-09-24 10:13:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:14:28 --> Config Class Initialized
INFO - 2016-09-24 10:14:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:14:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:14:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:14:28 --> URI Class Initialized
INFO - 2016-09-24 10:14:28 --> Router Class Initialized
INFO - 2016-09-24 10:14:28 --> Output Class Initialized
INFO - 2016-09-24 10:14:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:14:28 --> Input Class Initialized
INFO - 2016-09-24 10:14:28 --> Language Class Initialized
ERROR - 2016-09-24 10:14:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:14:58 --> Config Class Initialized
INFO - 2016-09-24 10:14:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:14:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:14:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:14:58 --> URI Class Initialized
INFO - 2016-09-24 10:14:58 --> Router Class Initialized
INFO - 2016-09-24 10:14:58 --> Output Class Initialized
INFO - 2016-09-24 10:14:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:14:58 --> Input Class Initialized
INFO - 2016-09-24 10:14:58 --> Language Class Initialized
ERROR - 2016-09-24 10:14:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:15:28 --> Config Class Initialized
INFO - 2016-09-24 10:15:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:15:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:15:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:15:28 --> URI Class Initialized
INFO - 2016-09-24 10:15:28 --> Router Class Initialized
INFO - 2016-09-24 10:15:28 --> Output Class Initialized
INFO - 2016-09-24 10:15:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:15:28 --> Input Class Initialized
INFO - 2016-09-24 10:15:28 --> Language Class Initialized
ERROR - 2016-09-24 10:15:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:15:58 --> Config Class Initialized
INFO - 2016-09-24 10:15:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:15:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:15:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:15:58 --> URI Class Initialized
INFO - 2016-09-24 10:15:58 --> Router Class Initialized
INFO - 2016-09-24 10:15:58 --> Output Class Initialized
INFO - 2016-09-24 10:15:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:15:58 --> Input Class Initialized
INFO - 2016-09-24 10:15:58 --> Language Class Initialized
ERROR - 2016-09-24 10:15:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:16:28 --> Config Class Initialized
INFO - 2016-09-24 10:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:16:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:16:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:16:28 --> URI Class Initialized
INFO - 2016-09-24 10:16:28 --> Router Class Initialized
INFO - 2016-09-24 10:16:28 --> Output Class Initialized
INFO - 2016-09-24 10:16:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:16:28 --> Input Class Initialized
INFO - 2016-09-24 10:16:28 --> Language Class Initialized
ERROR - 2016-09-24 10:16:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:16:58 --> Config Class Initialized
INFO - 2016-09-24 10:16:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:16:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:16:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:16:58 --> URI Class Initialized
INFO - 2016-09-24 10:16:58 --> Router Class Initialized
INFO - 2016-09-24 10:16:58 --> Output Class Initialized
INFO - 2016-09-24 10:16:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:16:58 --> Input Class Initialized
INFO - 2016-09-24 10:16:58 --> Language Class Initialized
ERROR - 2016-09-24 10:16:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:17:28 --> Config Class Initialized
INFO - 2016-09-24 10:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:17:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:17:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:17:28 --> URI Class Initialized
INFO - 2016-09-24 10:17:28 --> Router Class Initialized
INFO - 2016-09-24 10:17:28 --> Output Class Initialized
INFO - 2016-09-24 10:17:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:17:28 --> Input Class Initialized
INFO - 2016-09-24 10:17:28 --> Language Class Initialized
ERROR - 2016-09-24 10:17:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:17:58 --> Config Class Initialized
INFO - 2016-09-24 10:17:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:17:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:17:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:17:58 --> URI Class Initialized
INFO - 2016-09-24 10:17:58 --> Router Class Initialized
INFO - 2016-09-24 10:17:58 --> Output Class Initialized
INFO - 2016-09-24 10:17:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:17:58 --> Input Class Initialized
INFO - 2016-09-24 10:17:58 --> Language Class Initialized
ERROR - 2016-09-24 10:17:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:18:28 --> Config Class Initialized
INFO - 2016-09-24 10:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:18:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:18:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:18:28 --> URI Class Initialized
INFO - 2016-09-24 10:18:28 --> Router Class Initialized
INFO - 2016-09-24 10:18:28 --> Output Class Initialized
INFO - 2016-09-24 10:18:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:18:28 --> Input Class Initialized
INFO - 2016-09-24 10:18:28 --> Language Class Initialized
ERROR - 2016-09-24 10:18:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:18:58 --> Config Class Initialized
INFO - 2016-09-24 10:18:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:18:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:18:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:18:58 --> URI Class Initialized
INFO - 2016-09-24 10:18:58 --> Router Class Initialized
INFO - 2016-09-24 10:18:58 --> Output Class Initialized
INFO - 2016-09-24 10:18:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:18:58 --> Input Class Initialized
INFO - 2016-09-24 10:18:58 --> Language Class Initialized
ERROR - 2016-09-24 10:18:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:19:28 --> Config Class Initialized
INFO - 2016-09-24 10:19:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:19:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:19:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:19:28 --> URI Class Initialized
INFO - 2016-09-24 10:19:28 --> Router Class Initialized
INFO - 2016-09-24 10:19:28 --> Output Class Initialized
INFO - 2016-09-24 10:19:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:19:28 --> Input Class Initialized
INFO - 2016-09-24 10:19:28 --> Language Class Initialized
ERROR - 2016-09-24 10:19:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:19:58 --> Config Class Initialized
INFO - 2016-09-24 10:19:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:19:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:19:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:19:58 --> URI Class Initialized
INFO - 2016-09-24 10:19:58 --> Router Class Initialized
INFO - 2016-09-24 10:19:58 --> Output Class Initialized
INFO - 2016-09-24 10:19:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:19:58 --> Input Class Initialized
INFO - 2016-09-24 10:19:58 --> Language Class Initialized
ERROR - 2016-09-24 10:19:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:20:28 --> Config Class Initialized
INFO - 2016-09-24 10:20:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:20:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:20:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:20:28 --> URI Class Initialized
INFO - 2016-09-24 10:20:28 --> Router Class Initialized
INFO - 2016-09-24 10:20:28 --> Output Class Initialized
INFO - 2016-09-24 10:20:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:20:28 --> Input Class Initialized
INFO - 2016-09-24 10:20:28 --> Language Class Initialized
ERROR - 2016-09-24 10:20:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:20:58 --> Config Class Initialized
INFO - 2016-09-24 10:20:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:20:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:20:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:20:58 --> URI Class Initialized
INFO - 2016-09-24 10:20:58 --> Router Class Initialized
INFO - 2016-09-24 10:20:58 --> Output Class Initialized
INFO - 2016-09-24 10:20:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:20:58 --> Input Class Initialized
INFO - 2016-09-24 10:20:58 --> Language Class Initialized
ERROR - 2016-09-24 10:20:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:21:28 --> Config Class Initialized
INFO - 2016-09-24 10:21:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:21:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:21:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:21:28 --> URI Class Initialized
INFO - 2016-09-24 10:21:28 --> Router Class Initialized
INFO - 2016-09-24 10:21:28 --> Output Class Initialized
INFO - 2016-09-24 10:21:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:21:28 --> Input Class Initialized
INFO - 2016-09-24 10:21:28 --> Language Class Initialized
ERROR - 2016-09-24 10:21:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:21:58 --> Config Class Initialized
INFO - 2016-09-24 10:21:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:21:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:21:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:21:58 --> URI Class Initialized
INFO - 2016-09-24 10:21:58 --> Router Class Initialized
INFO - 2016-09-24 10:21:58 --> Output Class Initialized
INFO - 2016-09-24 10:21:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:21:58 --> Input Class Initialized
INFO - 2016-09-24 10:21:58 --> Language Class Initialized
ERROR - 2016-09-24 10:21:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:22:28 --> Config Class Initialized
INFO - 2016-09-24 10:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:22:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:22:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:22:28 --> URI Class Initialized
INFO - 2016-09-24 10:22:28 --> Router Class Initialized
INFO - 2016-09-24 10:22:28 --> Output Class Initialized
INFO - 2016-09-24 10:22:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:22:28 --> Input Class Initialized
INFO - 2016-09-24 10:22:28 --> Language Class Initialized
ERROR - 2016-09-24 10:22:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:22:58 --> Config Class Initialized
INFO - 2016-09-24 10:22:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:22:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:22:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:22:58 --> URI Class Initialized
INFO - 2016-09-24 10:22:58 --> Router Class Initialized
INFO - 2016-09-24 10:22:58 --> Output Class Initialized
INFO - 2016-09-24 10:22:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:22:58 --> Input Class Initialized
INFO - 2016-09-24 10:22:58 --> Language Class Initialized
ERROR - 2016-09-24 10:22:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:23:28 --> Config Class Initialized
INFO - 2016-09-24 10:23:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:23:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:23:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:23:28 --> URI Class Initialized
INFO - 2016-09-24 10:23:28 --> Router Class Initialized
INFO - 2016-09-24 10:23:28 --> Output Class Initialized
INFO - 2016-09-24 10:23:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:23:28 --> Input Class Initialized
INFO - 2016-09-24 10:23:28 --> Language Class Initialized
ERROR - 2016-09-24 10:23:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:23:58 --> Config Class Initialized
INFO - 2016-09-24 10:23:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:23:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:23:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:23:58 --> URI Class Initialized
INFO - 2016-09-24 10:23:58 --> Router Class Initialized
INFO - 2016-09-24 10:23:58 --> Output Class Initialized
INFO - 2016-09-24 10:23:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:23:58 --> Input Class Initialized
INFO - 2016-09-24 10:23:58 --> Language Class Initialized
ERROR - 2016-09-24 10:23:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:24:28 --> Config Class Initialized
INFO - 2016-09-24 10:24:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:24:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:24:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:24:28 --> URI Class Initialized
INFO - 2016-09-24 10:24:28 --> Router Class Initialized
INFO - 2016-09-24 10:24:28 --> Output Class Initialized
INFO - 2016-09-24 10:24:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:24:28 --> Input Class Initialized
INFO - 2016-09-24 10:24:28 --> Language Class Initialized
ERROR - 2016-09-24 10:24:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:24:58 --> Config Class Initialized
INFO - 2016-09-24 10:24:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:24:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:24:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:24:58 --> URI Class Initialized
INFO - 2016-09-24 10:24:58 --> Router Class Initialized
INFO - 2016-09-24 10:24:58 --> Output Class Initialized
INFO - 2016-09-24 10:24:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:24:58 --> Input Class Initialized
INFO - 2016-09-24 10:24:58 --> Language Class Initialized
ERROR - 2016-09-24 10:24:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:25:28 --> Config Class Initialized
INFO - 2016-09-24 10:25:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:25:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:25:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:25:28 --> URI Class Initialized
INFO - 2016-09-24 10:25:28 --> Router Class Initialized
INFO - 2016-09-24 10:25:28 --> Output Class Initialized
INFO - 2016-09-24 10:25:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:25:28 --> Input Class Initialized
INFO - 2016-09-24 10:25:28 --> Language Class Initialized
ERROR - 2016-09-24 10:25:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:25:58 --> Config Class Initialized
INFO - 2016-09-24 10:25:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:25:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:25:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:25:58 --> URI Class Initialized
INFO - 2016-09-24 10:25:58 --> Router Class Initialized
INFO - 2016-09-24 10:25:58 --> Output Class Initialized
INFO - 2016-09-24 10:25:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:25:58 --> Input Class Initialized
INFO - 2016-09-24 10:25:58 --> Language Class Initialized
ERROR - 2016-09-24 10:25:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:26:28 --> Config Class Initialized
INFO - 2016-09-24 10:26:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:26:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:26:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:26:28 --> URI Class Initialized
INFO - 2016-09-24 10:26:28 --> Router Class Initialized
INFO - 2016-09-24 10:26:28 --> Output Class Initialized
INFO - 2016-09-24 10:26:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:26:28 --> Input Class Initialized
INFO - 2016-09-24 10:26:28 --> Language Class Initialized
ERROR - 2016-09-24 10:26:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:26:58 --> Config Class Initialized
INFO - 2016-09-24 10:26:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:26:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:26:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:26:58 --> URI Class Initialized
INFO - 2016-09-24 10:26:58 --> Router Class Initialized
INFO - 2016-09-24 10:26:58 --> Output Class Initialized
INFO - 2016-09-24 10:26:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:26:58 --> Input Class Initialized
INFO - 2016-09-24 10:26:58 --> Language Class Initialized
ERROR - 2016-09-24 10:26:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:27:28 --> Config Class Initialized
INFO - 2016-09-24 10:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:27:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:27:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:27:28 --> URI Class Initialized
INFO - 2016-09-24 10:27:28 --> Router Class Initialized
INFO - 2016-09-24 10:27:28 --> Output Class Initialized
INFO - 2016-09-24 10:27:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:27:28 --> Input Class Initialized
INFO - 2016-09-24 10:27:28 --> Language Class Initialized
ERROR - 2016-09-24 10:27:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:27:58 --> Config Class Initialized
INFO - 2016-09-24 10:27:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:27:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:27:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:27:58 --> URI Class Initialized
INFO - 2016-09-24 10:27:58 --> Router Class Initialized
INFO - 2016-09-24 10:27:58 --> Output Class Initialized
INFO - 2016-09-24 10:27:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:27:58 --> Input Class Initialized
INFO - 2016-09-24 10:27:58 --> Language Class Initialized
ERROR - 2016-09-24 10:27:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:28:28 --> Config Class Initialized
INFO - 2016-09-24 10:28:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:28:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:28:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:28:28 --> URI Class Initialized
INFO - 2016-09-24 10:28:28 --> Router Class Initialized
INFO - 2016-09-24 10:28:28 --> Output Class Initialized
INFO - 2016-09-24 10:28:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:28:28 --> Input Class Initialized
INFO - 2016-09-24 10:28:28 --> Language Class Initialized
ERROR - 2016-09-24 10:28:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:28:58 --> Config Class Initialized
INFO - 2016-09-24 10:28:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:28:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:28:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:28:58 --> URI Class Initialized
INFO - 2016-09-24 10:28:58 --> Router Class Initialized
INFO - 2016-09-24 10:28:58 --> Output Class Initialized
INFO - 2016-09-24 10:28:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:28:58 --> Input Class Initialized
INFO - 2016-09-24 10:28:58 --> Language Class Initialized
ERROR - 2016-09-24 10:28:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:29:28 --> Config Class Initialized
INFO - 2016-09-24 10:29:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:29:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:29:28 --> URI Class Initialized
INFO - 2016-09-24 10:29:28 --> Router Class Initialized
INFO - 2016-09-24 10:29:28 --> Output Class Initialized
INFO - 2016-09-24 10:29:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:29:28 --> Input Class Initialized
INFO - 2016-09-24 10:29:28 --> Language Class Initialized
ERROR - 2016-09-24 10:29:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:29:58 --> Config Class Initialized
INFO - 2016-09-24 10:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:29:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:29:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:29:58 --> URI Class Initialized
INFO - 2016-09-24 10:29:58 --> Router Class Initialized
INFO - 2016-09-24 10:29:58 --> Output Class Initialized
INFO - 2016-09-24 10:29:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:29:58 --> Input Class Initialized
INFO - 2016-09-24 10:29:58 --> Language Class Initialized
ERROR - 2016-09-24 10:29:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:30:28 --> Config Class Initialized
INFO - 2016-09-24 10:30:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:30:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:30:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:30:28 --> URI Class Initialized
INFO - 2016-09-24 10:30:28 --> Router Class Initialized
INFO - 2016-09-24 10:30:28 --> Output Class Initialized
INFO - 2016-09-24 10:30:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:30:28 --> Input Class Initialized
INFO - 2016-09-24 10:30:28 --> Language Class Initialized
ERROR - 2016-09-24 10:30:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:30:58 --> Config Class Initialized
INFO - 2016-09-24 10:30:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:30:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:30:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:30:58 --> URI Class Initialized
INFO - 2016-09-24 10:30:58 --> Router Class Initialized
INFO - 2016-09-24 10:30:58 --> Output Class Initialized
INFO - 2016-09-24 10:30:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:30:58 --> Input Class Initialized
INFO - 2016-09-24 10:30:58 --> Language Class Initialized
ERROR - 2016-09-24 10:30:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:31:28 --> Config Class Initialized
INFO - 2016-09-24 10:31:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:31:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:31:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:31:28 --> URI Class Initialized
INFO - 2016-09-24 10:31:28 --> Router Class Initialized
INFO - 2016-09-24 10:31:28 --> Output Class Initialized
INFO - 2016-09-24 10:31:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:31:28 --> Input Class Initialized
INFO - 2016-09-24 10:31:28 --> Language Class Initialized
ERROR - 2016-09-24 10:31:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:31:58 --> Config Class Initialized
INFO - 2016-09-24 10:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:31:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:31:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:31:58 --> URI Class Initialized
INFO - 2016-09-24 10:31:58 --> Router Class Initialized
INFO - 2016-09-24 10:31:58 --> Output Class Initialized
INFO - 2016-09-24 10:31:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:31:58 --> Input Class Initialized
INFO - 2016-09-24 10:31:58 --> Language Class Initialized
ERROR - 2016-09-24 10:31:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:32:28 --> Config Class Initialized
INFO - 2016-09-24 10:32:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:32:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:32:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:32:28 --> URI Class Initialized
INFO - 2016-09-24 10:32:28 --> Router Class Initialized
INFO - 2016-09-24 10:32:28 --> Output Class Initialized
INFO - 2016-09-24 10:32:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:32:28 --> Input Class Initialized
INFO - 2016-09-24 10:32:28 --> Language Class Initialized
ERROR - 2016-09-24 10:32:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:32:58 --> Config Class Initialized
INFO - 2016-09-24 10:32:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:32:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:32:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:32:58 --> URI Class Initialized
INFO - 2016-09-24 10:32:58 --> Router Class Initialized
INFO - 2016-09-24 10:32:58 --> Output Class Initialized
INFO - 2016-09-24 10:32:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:32:58 --> Input Class Initialized
INFO - 2016-09-24 10:32:58 --> Language Class Initialized
ERROR - 2016-09-24 10:32:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:33:28 --> Config Class Initialized
INFO - 2016-09-24 10:33:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:33:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:33:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:33:28 --> URI Class Initialized
INFO - 2016-09-24 10:33:28 --> Router Class Initialized
INFO - 2016-09-24 10:33:28 --> Output Class Initialized
INFO - 2016-09-24 10:33:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:33:28 --> Input Class Initialized
INFO - 2016-09-24 10:33:28 --> Language Class Initialized
ERROR - 2016-09-24 10:33:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:33:58 --> Config Class Initialized
INFO - 2016-09-24 10:33:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:33:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:33:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:33:58 --> URI Class Initialized
INFO - 2016-09-24 10:33:58 --> Router Class Initialized
INFO - 2016-09-24 10:33:58 --> Output Class Initialized
INFO - 2016-09-24 10:33:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:33:58 --> Input Class Initialized
INFO - 2016-09-24 10:33:58 --> Language Class Initialized
ERROR - 2016-09-24 10:33:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:34:28 --> Config Class Initialized
INFO - 2016-09-24 10:34:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:34:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:34:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:34:28 --> URI Class Initialized
INFO - 2016-09-24 10:34:28 --> Router Class Initialized
INFO - 2016-09-24 10:34:28 --> Output Class Initialized
INFO - 2016-09-24 10:34:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:34:28 --> Input Class Initialized
INFO - 2016-09-24 10:34:28 --> Language Class Initialized
ERROR - 2016-09-24 10:34:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:34:58 --> Config Class Initialized
INFO - 2016-09-24 10:34:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:34:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:34:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:34:58 --> URI Class Initialized
INFO - 2016-09-24 10:34:58 --> Router Class Initialized
INFO - 2016-09-24 10:34:58 --> Output Class Initialized
INFO - 2016-09-24 10:34:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:34:58 --> Input Class Initialized
INFO - 2016-09-24 10:34:58 --> Language Class Initialized
ERROR - 2016-09-24 10:34:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:35:28 --> Config Class Initialized
INFO - 2016-09-24 10:35:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:35:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:35:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:35:28 --> URI Class Initialized
INFO - 2016-09-24 10:35:28 --> Router Class Initialized
INFO - 2016-09-24 10:35:28 --> Output Class Initialized
INFO - 2016-09-24 10:35:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:35:28 --> Input Class Initialized
INFO - 2016-09-24 10:35:28 --> Language Class Initialized
ERROR - 2016-09-24 10:35:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:35:58 --> Config Class Initialized
INFO - 2016-09-24 10:35:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:35:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:35:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:35:58 --> URI Class Initialized
INFO - 2016-09-24 10:35:58 --> Router Class Initialized
INFO - 2016-09-24 10:35:58 --> Output Class Initialized
INFO - 2016-09-24 10:35:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:35:58 --> Input Class Initialized
INFO - 2016-09-24 10:35:58 --> Language Class Initialized
ERROR - 2016-09-24 10:35:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:36:28 --> Config Class Initialized
INFO - 2016-09-24 10:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:36:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:36:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:36:28 --> URI Class Initialized
INFO - 2016-09-24 10:36:28 --> Router Class Initialized
INFO - 2016-09-24 10:36:28 --> Output Class Initialized
INFO - 2016-09-24 10:36:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:36:28 --> Input Class Initialized
INFO - 2016-09-24 10:36:28 --> Language Class Initialized
ERROR - 2016-09-24 10:36:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:36:58 --> Config Class Initialized
INFO - 2016-09-24 10:36:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:36:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:36:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:36:58 --> URI Class Initialized
INFO - 2016-09-24 10:36:58 --> Router Class Initialized
INFO - 2016-09-24 10:36:58 --> Output Class Initialized
INFO - 2016-09-24 10:36:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:36:58 --> Input Class Initialized
INFO - 2016-09-24 10:36:58 --> Language Class Initialized
ERROR - 2016-09-24 10:36:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:37:28 --> Config Class Initialized
INFO - 2016-09-24 10:37:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:37:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:37:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:37:28 --> URI Class Initialized
INFO - 2016-09-24 10:37:28 --> Router Class Initialized
INFO - 2016-09-24 10:37:28 --> Output Class Initialized
INFO - 2016-09-24 10:37:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:37:28 --> Input Class Initialized
INFO - 2016-09-24 10:37:28 --> Language Class Initialized
ERROR - 2016-09-24 10:37:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:37:58 --> Config Class Initialized
INFO - 2016-09-24 10:37:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:37:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:37:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:37:58 --> URI Class Initialized
INFO - 2016-09-24 10:37:58 --> Router Class Initialized
INFO - 2016-09-24 10:37:58 --> Output Class Initialized
INFO - 2016-09-24 10:37:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:37:58 --> Input Class Initialized
INFO - 2016-09-24 10:37:58 --> Language Class Initialized
ERROR - 2016-09-24 10:37:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:38:28 --> Config Class Initialized
INFO - 2016-09-24 10:38:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:38:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:38:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:38:28 --> URI Class Initialized
INFO - 2016-09-24 10:38:28 --> Router Class Initialized
INFO - 2016-09-24 10:38:28 --> Output Class Initialized
INFO - 2016-09-24 10:38:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:38:28 --> Input Class Initialized
INFO - 2016-09-24 10:38:28 --> Language Class Initialized
ERROR - 2016-09-24 10:38:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:38:58 --> Config Class Initialized
INFO - 2016-09-24 10:38:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:38:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:38:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:38:58 --> URI Class Initialized
INFO - 2016-09-24 10:38:58 --> Router Class Initialized
INFO - 2016-09-24 10:38:58 --> Output Class Initialized
INFO - 2016-09-24 10:38:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:38:58 --> Input Class Initialized
INFO - 2016-09-24 10:38:58 --> Language Class Initialized
ERROR - 2016-09-24 10:38:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:39:28 --> Config Class Initialized
INFO - 2016-09-24 10:39:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:39:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:39:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:39:28 --> URI Class Initialized
INFO - 2016-09-24 10:39:28 --> Router Class Initialized
INFO - 2016-09-24 10:39:28 --> Output Class Initialized
INFO - 2016-09-24 10:39:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:39:28 --> Input Class Initialized
INFO - 2016-09-24 10:39:28 --> Language Class Initialized
ERROR - 2016-09-24 10:39:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:39:58 --> Config Class Initialized
INFO - 2016-09-24 10:39:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:39:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:39:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:39:58 --> URI Class Initialized
INFO - 2016-09-24 10:39:58 --> Router Class Initialized
INFO - 2016-09-24 10:39:58 --> Output Class Initialized
INFO - 2016-09-24 10:39:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:39:58 --> Input Class Initialized
INFO - 2016-09-24 10:39:58 --> Language Class Initialized
ERROR - 2016-09-24 10:39:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:40:28 --> Config Class Initialized
INFO - 2016-09-24 10:40:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:40:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:40:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:40:28 --> URI Class Initialized
INFO - 2016-09-24 10:40:28 --> Router Class Initialized
INFO - 2016-09-24 10:40:28 --> Output Class Initialized
INFO - 2016-09-24 10:40:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:40:28 --> Input Class Initialized
INFO - 2016-09-24 10:40:28 --> Language Class Initialized
ERROR - 2016-09-24 10:40:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:40:58 --> Config Class Initialized
INFO - 2016-09-24 10:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:40:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:40:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:40:58 --> URI Class Initialized
INFO - 2016-09-24 10:40:58 --> Router Class Initialized
INFO - 2016-09-24 10:40:58 --> Output Class Initialized
INFO - 2016-09-24 10:40:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:40:58 --> Input Class Initialized
INFO - 2016-09-24 10:40:58 --> Language Class Initialized
ERROR - 2016-09-24 10:40:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:41:28 --> Config Class Initialized
INFO - 2016-09-24 10:41:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:41:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:41:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:41:28 --> URI Class Initialized
INFO - 2016-09-24 10:41:28 --> Router Class Initialized
INFO - 2016-09-24 10:41:28 --> Output Class Initialized
INFO - 2016-09-24 10:41:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:41:28 --> Input Class Initialized
INFO - 2016-09-24 10:41:28 --> Language Class Initialized
ERROR - 2016-09-24 10:41:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:41:58 --> Config Class Initialized
INFO - 2016-09-24 10:41:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:41:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:41:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:41:58 --> URI Class Initialized
INFO - 2016-09-24 10:41:58 --> Router Class Initialized
INFO - 2016-09-24 10:41:58 --> Output Class Initialized
INFO - 2016-09-24 10:41:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:41:58 --> Input Class Initialized
INFO - 2016-09-24 10:41:58 --> Language Class Initialized
ERROR - 2016-09-24 10:41:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:42:28 --> Config Class Initialized
INFO - 2016-09-24 10:42:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:42:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:42:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:42:28 --> URI Class Initialized
INFO - 2016-09-24 10:42:28 --> Router Class Initialized
INFO - 2016-09-24 10:42:28 --> Output Class Initialized
INFO - 2016-09-24 10:42:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:42:28 --> Input Class Initialized
INFO - 2016-09-24 10:42:28 --> Language Class Initialized
ERROR - 2016-09-24 10:42:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:42:58 --> Config Class Initialized
INFO - 2016-09-24 10:42:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:42:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:42:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:42:58 --> URI Class Initialized
INFO - 2016-09-24 10:42:58 --> Router Class Initialized
INFO - 2016-09-24 10:42:58 --> Output Class Initialized
INFO - 2016-09-24 10:42:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:42:58 --> Input Class Initialized
INFO - 2016-09-24 10:42:58 --> Language Class Initialized
ERROR - 2016-09-24 10:42:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:43:28 --> Config Class Initialized
INFO - 2016-09-24 10:43:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:43:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:43:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:43:28 --> URI Class Initialized
INFO - 2016-09-24 10:43:28 --> Router Class Initialized
INFO - 2016-09-24 10:43:28 --> Output Class Initialized
INFO - 2016-09-24 10:43:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:43:28 --> Input Class Initialized
INFO - 2016-09-24 10:43:28 --> Language Class Initialized
ERROR - 2016-09-24 10:43:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:43:58 --> Config Class Initialized
INFO - 2016-09-24 10:43:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:43:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:43:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:43:58 --> URI Class Initialized
INFO - 2016-09-24 10:43:58 --> Router Class Initialized
INFO - 2016-09-24 10:43:58 --> Output Class Initialized
INFO - 2016-09-24 10:43:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:43:58 --> Input Class Initialized
INFO - 2016-09-24 10:43:58 --> Language Class Initialized
ERROR - 2016-09-24 10:43:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:44:28 --> Config Class Initialized
INFO - 2016-09-24 10:44:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:44:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:44:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:44:28 --> URI Class Initialized
INFO - 2016-09-24 10:44:28 --> Router Class Initialized
INFO - 2016-09-24 10:44:28 --> Output Class Initialized
INFO - 2016-09-24 10:44:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:44:28 --> Input Class Initialized
INFO - 2016-09-24 10:44:28 --> Language Class Initialized
ERROR - 2016-09-24 10:44:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:44:58 --> Config Class Initialized
INFO - 2016-09-24 10:44:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:44:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:44:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:44:58 --> URI Class Initialized
INFO - 2016-09-24 10:44:58 --> Router Class Initialized
INFO - 2016-09-24 10:44:58 --> Output Class Initialized
INFO - 2016-09-24 10:44:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:44:58 --> Input Class Initialized
INFO - 2016-09-24 10:44:58 --> Language Class Initialized
ERROR - 2016-09-24 10:44:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:45:28 --> Config Class Initialized
INFO - 2016-09-24 10:45:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:45:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:45:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:45:28 --> URI Class Initialized
INFO - 2016-09-24 10:45:28 --> Router Class Initialized
INFO - 2016-09-24 10:45:28 --> Output Class Initialized
INFO - 2016-09-24 10:45:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:45:28 --> Input Class Initialized
INFO - 2016-09-24 10:45:28 --> Language Class Initialized
ERROR - 2016-09-24 10:45:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:45:58 --> Config Class Initialized
INFO - 2016-09-24 10:45:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:45:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:45:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:45:58 --> URI Class Initialized
INFO - 2016-09-24 10:45:58 --> Router Class Initialized
INFO - 2016-09-24 10:45:58 --> Output Class Initialized
INFO - 2016-09-24 10:45:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:45:58 --> Input Class Initialized
INFO - 2016-09-24 10:45:58 --> Language Class Initialized
ERROR - 2016-09-24 10:45:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:46:28 --> Config Class Initialized
INFO - 2016-09-24 10:46:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:46:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:46:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:46:28 --> URI Class Initialized
INFO - 2016-09-24 10:46:28 --> Router Class Initialized
INFO - 2016-09-24 10:46:28 --> Output Class Initialized
INFO - 2016-09-24 10:46:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:46:28 --> Input Class Initialized
INFO - 2016-09-24 10:46:28 --> Language Class Initialized
ERROR - 2016-09-24 10:46:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:46:58 --> Config Class Initialized
INFO - 2016-09-24 10:46:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:46:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:46:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:46:58 --> URI Class Initialized
INFO - 2016-09-24 10:46:58 --> Router Class Initialized
INFO - 2016-09-24 10:46:58 --> Output Class Initialized
INFO - 2016-09-24 10:46:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:46:58 --> Input Class Initialized
INFO - 2016-09-24 10:46:58 --> Language Class Initialized
ERROR - 2016-09-24 10:46:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:47:28 --> Config Class Initialized
INFO - 2016-09-24 10:47:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:47:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:47:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:47:28 --> URI Class Initialized
INFO - 2016-09-24 10:47:28 --> Router Class Initialized
INFO - 2016-09-24 10:47:28 --> Output Class Initialized
INFO - 2016-09-24 10:47:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:47:28 --> Input Class Initialized
INFO - 2016-09-24 10:47:28 --> Language Class Initialized
ERROR - 2016-09-24 10:47:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:47:58 --> Config Class Initialized
INFO - 2016-09-24 10:47:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:47:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:47:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:47:58 --> URI Class Initialized
INFO - 2016-09-24 10:47:58 --> Router Class Initialized
INFO - 2016-09-24 10:47:58 --> Output Class Initialized
INFO - 2016-09-24 10:47:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:47:58 --> Input Class Initialized
INFO - 2016-09-24 10:47:58 --> Language Class Initialized
ERROR - 2016-09-24 10:47:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:48:28 --> Config Class Initialized
INFO - 2016-09-24 10:48:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:48:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:48:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:48:28 --> URI Class Initialized
INFO - 2016-09-24 10:48:28 --> Router Class Initialized
INFO - 2016-09-24 10:48:28 --> Output Class Initialized
INFO - 2016-09-24 10:48:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:48:28 --> Input Class Initialized
INFO - 2016-09-24 10:48:28 --> Language Class Initialized
ERROR - 2016-09-24 10:48:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:48:58 --> Config Class Initialized
INFO - 2016-09-24 10:48:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:48:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:48:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:48:58 --> URI Class Initialized
INFO - 2016-09-24 10:48:58 --> Router Class Initialized
INFO - 2016-09-24 10:48:58 --> Output Class Initialized
INFO - 2016-09-24 10:48:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:48:58 --> Input Class Initialized
INFO - 2016-09-24 10:48:58 --> Language Class Initialized
ERROR - 2016-09-24 10:48:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:49:28 --> Config Class Initialized
INFO - 2016-09-24 10:49:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:49:28 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:49:28 --> Utf8 Class Initialized
INFO - 2016-09-24 10:49:28 --> URI Class Initialized
INFO - 2016-09-24 10:49:28 --> Router Class Initialized
INFO - 2016-09-24 10:49:28 --> Output Class Initialized
INFO - 2016-09-24 10:49:28 --> Security Class Initialized
DEBUG - 2016-09-24 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:49:28 --> Input Class Initialized
INFO - 2016-09-24 10:49:28 --> Language Class Initialized
ERROR - 2016-09-24 10:49:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 10:49:58 --> Config Class Initialized
INFO - 2016-09-24 10:49:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 10:49:58 --> UTF-8 Support Enabled
INFO - 2016-09-24 10:49:58 --> Utf8 Class Initialized
INFO - 2016-09-24 10:49:58 --> URI Class Initialized
INFO - 2016-09-24 10:49:58 --> Router Class Initialized
INFO - 2016-09-24 10:49:58 --> Output Class Initialized
INFO - 2016-09-24 10:49:58 --> Security Class Initialized
DEBUG - 2016-09-24 10:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 10:49:58 --> Input Class Initialized
INFO - 2016-09-24 10:49:58 --> Language Class Initialized
ERROR - 2016-09-24 10:49:58 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:06:09 --> Config Class Initialized
INFO - 2016-09-24 15:06:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:06:09 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:06:09 --> Utf8 Class Initialized
INFO - 2016-09-24 15:06:09 --> URI Class Initialized
INFO - 2016-09-24 15:06:09 --> Router Class Initialized
INFO - 2016-09-24 15:06:09 --> Output Class Initialized
INFO - 2016-09-24 15:06:09 --> Security Class Initialized
DEBUG - 2016-09-24 15:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:06:09 --> Input Class Initialized
INFO - 2016-09-24 15:06:09 --> Language Class Initialized
ERROR - 2016-09-24 15:06:09 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:06:17 --> Config Class Initialized
INFO - 2016-09-24 15:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:06:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:06:17 --> URI Class Initialized
INFO - 2016-09-24 15:06:17 --> Router Class Initialized
INFO - 2016-09-24 15:06:17 --> Output Class Initialized
INFO - 2016-09-24 15:06:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:06:17 --> Input Class Initialized
INFO - 2016-09-24 15:06:17 --> Language Class Initialized
ERROR - 2016-09-24 15:06:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:06:47 --> Config Class Initialized
INFO - 2016-09-24 15:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:06:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:06:47 --> URI Class Initialized
INFO - 2016-09-24 15:06:47 --> Router Class Initialized
INFO - 2016-09-24 15:06:47 --> Output Class Initialized
INFO - 2016-09-24 15:06:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:06:47 --> Input Class Initialized
INFO - 2016-09-24 15:06:47 --> Language Class Initialized
ERROR - 2016-09-24 15:06:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:07:17 --> Config Class Initialized
INFO - 2016-09-24 15:07:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:07:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:07:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:07:17 --> URI Class Initialized
INFO - 2016-09-24 15:07:17 --> Router Class Initialized
INFO - 2016-09-24 15:07:17 --> Output Class Initialized
INFO - 2016-09-24 15:07:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:07:17 --> Input Class Initialized
INFO - 2016-09-24 15:07:17 --> Language Class Initialized
ERROR - 2016-09-24 15:07:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:07:47 --> Config Class Initialized
INFO - 2016-09-24 15:07:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:07:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:07:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:07:47 --> URI Class Initialized
INFO - 2016-09-24 15:07:47 --> Router Class Initialized
INFO - 2016-09-24 15:07:47 --> Output Class Initialized
INFO - 2016-09-24 15:07:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:07:47 --> Input Class Initialized
INFO - 2016-09-24 15:07:47 --> Language Class Initialized
ERROR - 2016-09-24 15:07:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:08:17 --> Config Class Initialized
INFO - 2016-09-24 15:08:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:08:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:08:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:08:17 --> URI Class Initialized
INFO - 2016-09-24 15:08:17 --> Router Class Initialized
INFO - 2016-09-24 15:08:17 --> Output Class Initialized
INFO - 2016-09-24 15:08:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:08:17 --> Input Class Initialized
INFO - 2016-09-24 15:08:17 --> Language Class Initialized
ERROR - 2016-09-24 15:08:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:08:47 --> Config Class Initialized
INFO - 2016-09-24 15:08:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:08:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:08:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:08:47 --> URI Class Initialized
INFO - 2016-09-24 15:08:47 --> Router Class Initialized
INFO - 2016-09-24 15:08:47 --> Output Class Initialized
INFO - 2016-09-24 15:08:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:08:47 --> Input Class Initialized
INFO - 2016-09-24 15:08:47 --> Language Class Initialized
ERROR - 2016-09-24 15:08:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:09:17 --> Config Class Initialized
INFO - 2016-09-24 15:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:09:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:09:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:09:17 --> URI Class Initialized
INFO - 2016-09-24 15:09:17 --> Router Class Initialized
INFO - 2016-09-24 15:09:17 --> Output Class Initialized
INFO - 2016-09-24 15:09:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:09:17 --> Input Class Initialized
INFO - 2016-09-24 15:09:17 --> Language Class Initialized
ERROR - 2016-09-24 15:09:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:09:47 --> Config Class Initialized
INFO - 2016-09-24 15:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:09:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:09:47 --> URI Class Initialized
INFO - 2016-09-24 15:09:47 --> Router Class Initialized
INFO - 2016-09-24 15:09:47 --> Output Class Initialized
INFO - 2016-09-24 15:09:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:09:47 --> Input Class Initialized
INFO - 2016-09-24 15:09:47 --> Language Class Initialized
ERROR - 2016-09-24 15:09:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:10:17 --> Config Class Initialized
INFO - 2016-09-24 15:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:10:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:10:17 --> URI Class Initialized
INFO - 2016-09-24 15:10:17 --> Router Class Initialized
INFO - 2016-09-24 15:10:17 --> Output Class Initialized
INFO - 2016-09-24 15:10:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:10:17 --> Input Class Initialized
INFO - 2016-09-24 15:10:17 --> Language Class Initialized
ERROR - 2016-09-24 15:10:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:10:47 --> Config Class Initialized
INFO - 2016-09-24 15:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:10:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:10:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:10:47 --> URI Class Initialized
INFO - 2016-09-24 15:10:47 --> Router Class Initialized
INFO - 2016-09-24 15:10:47 --> Output Class Initialized
INFO - 2016-09-24 15:10:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:10:47 --> Input Class Initialized
INFO - 2016-09-24 15:10:47 --> Language Class Initialized
ERROR - 2016-09-24 15:10:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:11:17 --> Config Class Initialized
INFO - 2016-09-24 15:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:11:17 --> URI Class Initialized
INFO - 2016-09-24 15:11:17 --> Router Class Initialized
INFO - 2016-09-24 15:11:17 --> Output Class Initialized
INFO - 2016-09-24 15:11:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:11:17 --> Input Class Initialized
INFO - 2016-09-24 15:11:17 --> Language Class Initialized
ERROR - 2016-09-24 15:11:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:11:47 --> Config Class Initialized
INFO - 2016-09-24 15:11:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:11:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:11:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:11:47 --> URI Class Initialized
INFO - 2016-09-24 15:11:47 --> Router Class Initialized
INFO - 2016-09-24 15:11:47 --> Output Class Initialized
INFO - 2016-09-24 15:11:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:11:47 --> Input Class Initialized
INFO - 2016-09-24 15:11:47 --> Language Class Initialized
ERROR - 2016-09-24 15:11:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:12:17 --> Config Class Initialized
INFO - 2016-09-24 15:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:12:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:12:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:12:17 --> URI Class Initialized
INFO - 2016-09-24 15:12:17 --> Router Class Initialized
INFO - 2016-09-24 15:12:17 --> Output Class Initialized
INFO - 2016-09-24 15:12:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:12:17 --> Input Class Initialized
INFO - 2016-09-24 15:12:17 --> Language Class Initialized
ERROR - 2016-09-24 15:12:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:12:47 --> Config Class Initialized
INFO - 2016-09-24 15:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:12:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:12:47 --> URI Class Initialized
INFO - 2016-09-24 15:12:47 --> Router Class Initialized
INFO - 2016-09-24 15:12:47 --> Output Class Initialized
INFO - 2016-09-24 15:12:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:12:47 --> Input Class Initialized
INFO - 2016-09-24 15:12:47 --> Language Class Initialized
ERROR - 2016-09-24 15:12:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:13:17 --> Config Class Initialized
INFO - 2016-09-24 15:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:13:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:13:17 --> URI Class Initialized
INFO - 2016-09-24 15:13:17 --> Router Class Initialized
INFO - 2016-09-24 15:13:17 --> Output Class Initialized
INFO - 2016-09-24 15:13:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:13:17 --> Input Class Initialized
INFO - 2016-09-24 15:13:17 --> Language Class Initialized
ERROR - 2016-09-24 15:13:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:13:47 --> Config Class Initialized
INFO - 2016-09-24 15:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:13:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:13:47 --> URI Class Initialized
INFO - 2016-09-24 15:13:47 --> Router Class Initialized
INFO - 2016-09-24 15:13:47 --> Output Class Initialized
INFO - 2016-09-24 15:13:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:13:47 --> Input Class Initialized
INFO - 2016-09-24 15:13:47 --> Language Class Initialized
ERROR - 2016-09-24 15:13:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:14:17 --> Config Class Initialized
INFO - 2016-09-24 15:14:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:14:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:14:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:14:17 --> URI Class Initialized
INFO - 2016-09-24 15:14:17 --> Router Class Initialized
INFO - 2016-09-24 15:14:17 --> Output Class Initialized
INFO - 2016-09-24 15:14:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:14:17 --> Input Class Initialized
INFO - 2016-09-24 15:14:17 --> Language Class Initialized
ERROR - 2016-09-24 15:14:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:14:47 --> Config Class Initialized
INFO - 2016-09-24 15:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:14:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:14:47 --> URI Class Initialized
INFO - 2016-09-24 15:14:47 --> Router Class Initialized
INFO - 2016-09-24 15:14:47 --> Output Class Initialized
INFO - 2016-09-24 15:14:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:14:47 --> Input Class Initialized
INFO - 2016-09-24 15:14:47 --> Language Class Initialized
ERROR - 2016-09-24 15:14:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:15:17 --> Config Class Initialized
INFO - 2016-09-24 15:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:15:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:15:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:15:17 --> URI Class Initialized
INFO - 2016-09-24 15:15:17 --> Router Class Initialized
INFO - 2016-09-24 15:15:17 --> Output Class Initialized
INFO - 2016-09-24 15:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:15:17 --> Input Class Initialized
INFO - 2016-09-24 15:15:17 --> Language Class Initialized
ERROR - 2016-09-24 15:15:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:15:47 --> Config Class Initialized
INFO - 2016-09-24 15:15:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:15:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:15:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:15:47 --> URI Class Initialized
INFO - 2016-09-24 15:15:47 --> Router Class Initialized
INFO - 2016-09-24 15:15:47 --> Output Class Initialized
INFO - 2016-09-24 15:15:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:15:47 --> Input Class Initialized
INFO - 2016-09-24 15:15:47 --> Language Class Initialized
ERROR - 2016-09-24 15:15:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:16:17 --> Config Class Initialized
INFO - 2016-09-24 15:16:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:16:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:16:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:16:17 --> URI Class Initialized
INFO - 2016-09-24 15:16:17 --> Router Class Initialized
INFO - 2016-09-24 15:16:17 --> Output Class Initialized
INFO - 2016-09-24 15:16:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:16:17 --> Input Class Initialized
INFO - 2016-09-24 15:16:17 --> Language Class Initialized
ERROR - 2016-09-24 15:16:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:16:47 --> Config Class Initialized
INFO - 2016-09-24 15:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:16:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:16:47 --> URI Class Initialized
INFO - 2016-09-24 15:16:47 --> Router Class Initialized
INFO - 2016-09-24 15:16:47 --> Output Class Initialized
INFO - 2016-09-24 15:16:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:16:47 --> Input Class Initialized
INFO - 2016-09-24 15:16:47 --> Language Class Initialized
ERROR - 2016-09-24 15:16:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:17:17 --> Config Class Initialized
INFO - 2016-09-24 15:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:17:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:17:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:17:17 --> URI Class Initialized
INFO - 2016-09-24 15:17:17 --> Router Class Initialized
INFO - 2016-09-24 15:17:17 --> Output Class Initialized
INFO - 2016-09-24 15:17:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:17:17 --> Input Class Initialized
INFO - 2016-09-24 15:17:17 --> Language Class Initialized
ERROR - 2016-09-24 15:17:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:17:47 --> Config Class Initialized
INFO - 2016-09-24 15:17:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:17:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:17:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:17:47 --> URI Class Initialized
INFO - 2016-09-24 15:17:47 --> Router Class Initialized
INFO - 2016-09-24 15:17:47 --> Output Class Initialized
INFO - 2016-09-24 15:17:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:17:47 --> Input Class Initialized
INFO - 2016-09-24 15:17:47 --> Language Class Initialized
ERROR - 2016-09-24 15:17:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:18:17 --> Config Class Initialized
INFO - 2016-09-24 15:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:18:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:18:17 --> URI Class Initialized
INFO - 2016-09-24 15:18:17 --> Router Class Initialized
INFO - 2016-09-24 15:18:17 --> Output Class Initialized
INFO - 2016-09-24 15:18:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:18:17 --> Input Class Initialized
INFO - 2016-09-24 15:18:17 --> Language Class Initialized
ERROR - 2016-09-24 15:18:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:18:47 --> Config Class Initialized
INFO - 2016-09-24 15:18:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:18:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:18:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:18:47 --> URI Class Initialized
INFO - 2016-09-24 15:18:47 --> Router Class Initialized
INFO - 2016-09-24 15:18:47 --> Output Class Initialized
INFO - 2016-09-24 15:18:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:18:47 --> Input Class Initialized
INFO - 2016-09-24 15:18:47 --> Language Class Initialized
ERROR - 2016-09-24 15:18:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:19:17 --> Config Class Initialized
INFO - 2016-09-24 15:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:19:17 --> URI Class Initialized
INFO - 2016-09-24 15:19:17 --> Router Class Initialized
INFO - 2016-09-24 15:19:17 --> Output Class Initialized
INFO - 2016-09-24 15:19:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:19:17 --> Input Class Initialized
INFO - 2016-09-24 15:19:17 --> Language Class Initialized
ERROR - 2016-09-24 15:19:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:19:47 --> Config Class Initialized
INFO - 2016-09-24 15:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:19:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:19:47 --> URI Class Initialized
INFO - 2016-09-24 15:19:47 --> Router Class Initialized
INFO - 2016-09-24 15:19:47 --> Output Class Initialized
INFO - 2016-09-24 15:19:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:19:47 --> Input Class Initialized
INFO - 2016-09-24 15:19:47 --> Language Class Initialized
ERROR - 2016-09-24 15:19:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:20:17 --> Config Class Initialized
INFO - 2016-09-24 15:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:20:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:20:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:20:17 --> URI Class Initialized
INFO - 2016-09-24 15:20:17 --> Router Class Initialized
INFO - 2016-09-24 15:20:17 --> Output Class Initialized
INFO - 2016-09-24 15:20:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:20:17 --> Input Class Initialized
INFO - 2016-09-24 15:20:17 --> Language Class Initialized
ERROR - 2016-09-24 15:20:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:20:47 --> Config Class Initialized
INFO - 2016-09-24 15:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:20:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:20:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:20:47 --> URI Class Initialized
INFO - 2016-09-24 15:20:47 --> Router Class Initialized
INFO - 2016-09-24 15:20:47 --> Output Class Initialized
INFO - 2016-09-24 15:20:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:20:47 --> Input Class Initialized
INFO - 2016-09-24 15:20:47 --> Language Class Initialized
ERROR - 2016-09-24 15:20:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:21:17 --> Config Class Initialized
INFO - 2016-09-24 15:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:21:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:21:17 --> URI Class Initialized
INFO - 2016-09-24 15:21:17 --> Router Class Initialized
INFO - 2016-09-24 15:21:17 --> Output Class Initialized
INFO - 2016-09-24 15:21:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:21:17 --> Input Class Initialized
INFO - 2016-09-24 15:21:17 --> Language Class Initialized
ERROR - 2016-09-24 15:21:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:21:47 --> Config Class Initialized
INFO - 2016-09-24 15:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:21:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:21:47 --> URI Class Initialized
INFO - 2016-09-24 15:21:47 --> Router Class Initialized
INFO - 2016-09-24 15:21:47 --> Output Class Initialized
INFO - 2016-09-24 15:21:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:21:47 --> Input Class Initialized
INFO - 2016-09-24 15:21:47 --> Language Class Initialized
ERROR - 2016-09-24 15:21:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:22:17 --> Config Class Initialized
INFO - 2016-09-24 15:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:22:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:22:17 --> URI Class Initialized
INFO - 2016-09-24 15:22:17 --> Router Class Initialized
INFO - 2016-09-24 15:22:17 --> Output Class Initialized
INFO - 2016-09-24 15:22:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:22:17 --> Input Class Initialized
INFO - 2016-09-24 15:22:17 --> Language Class Initialized
ERROR - 2016-09-24 15:22:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:22:47 --> Config Class Initialized
INFO - 2016-09-24 15:22:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:22:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:22:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:22:47 --> URI Class Initialized
INFO - 2016-09-24 15:22:47 --> Router Class Initialized
INFO - 2016-09-24 15:22:47 --> Output Class Initialized
INFO - 2016-09-24 15:22:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:22:47 --> Input Class Initialized
INFO - 2016-09-24 15:22:47 --> Language Class Initialized
ERROR - 2016-09-24 15:22:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:23:17 --> Config Class Initialized
INFO - 2016-09-24 15:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:23:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:23:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:23:17 --> URI Class Initialized
INFO - 2016-09-24 15:23:17 --> Router Class Initialized
INFO - 2016-09-24 15:23:17 --> Output Class Initialized
INFO - 2016-09-24 15:23:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:23:17 --> Input Class Initialized
INFO - 2016-09-24 15:23:17 --> Language Class Initialized
ERROR - 2016-09-24 15:23:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:23:47 --> Config Class Initialized
INFO - 2016-09-24 15:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:23:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:23:47 --> URI Class Initialized
INFO - 2016-09-24 15:23:47 --> Router Class Initialized
INFO - 2016-09-24 15:23:47 --> Output Class Initialized
INFO - 2016-09-24 15:23:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:23:47 --> Input Class Initialized
INFO - 2016-09-24 15:23:47 --> Language Class Initialized
ERROR - 2016-09-24 15:23:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:24:17 --> Config Class Initialized
INFO - 2016-09-24 15:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:24:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:24:17 --> URI Class Initialized
INFO - 2016-09-24 15:24:17 --> Router Class Initialized
INFO - 2016-09-24 15:24:17 --> Output Class Initialized
INFO - 2016-09-24 15:24:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:24:17 --> Input Class Initialized
INFO - 2016-09-24 15:24:17 --> Language Class Initialized
ERROR - 2016-09-24 15:24:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:24:47 --> Config Class Initialized
INFO - 2016-09-24 15:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:24:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:24:47 --> URI Class Initialized
INFO - 2016-09-24 15:24:47 --> Router Class Initialized
INFO - 2016-09-24 15:24:47 --> Output Class Initialized
INFO - 2016-09-24 15:24:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:24:47 --> Input Class Initialized
INFO - 2016-09-24 15:24:47 --> Language Class Initialized
ERROR - 2016-09-24 15:24:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:25:17 --> Config Class Initialized
INFO - 2016-09-24 15:25:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:25:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:25:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:25:17 --> URI Class Initialized
INFO - 2016-09-24 15:25:17 --> Router Class Initialized
INFO - 2016-09-24 15:25:17 --> Output Class Initialized
INFO - 2016-09-24 15:25:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:25:17 --> Input Class Initialized
INFO - 2016-09-24 15:25:17 --> Language Class Initialized
ERROR - 2016-09-24 15:25:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:25:47 --> Config Class Initialized
INFO - 2016-09-24 15:25:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:25:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:25:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:25:47 --> URI Class Initialized
INFO - 2016-09-24 15:25:47 --> Router Class Initialized
INFO - 2016-09-24 15:25:47 --> Output Class Initialized
INFO - 2016-09-24 15:25:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:25:47 --> Input Class Initialized
INFO - 2016-09-24 15:25:47 --> Language Class Initialized
ERROR - 2016-09-24 15:25:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:26:17 --> Config Class Initialized
INFO - 2016-09-24 15:26:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:26:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:26:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:26:17 --> URI Class Initialized
INFO - 2016-09-24 15:26:17 --> Router Class Initialized
INFO - 2016-09-24 15:26:17 --> Output Class Initialized
INFO - 2016-09-24 15:26:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:26:17 --> Input Class Initialized
INFO - 2016-09-24 15:26:17 --> Language Class Initialized
ERROR - 2016-09-24 15:26:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:26:47 --> Config Class Initialized
INFO - 2016-09-24 15:26:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:26:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:26:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:26:47 --> URI Class Initialized
INFO - 2016-09-24 15:26:47 --> Router Class Initialized
INFO - 2016-09-24 15:26:47 --> Output Class Initialized
INFO - 2016-09-24 15:26:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:26:47 --> Input Class Initialized
INFO - 2016-09-24 15:26:47 --> Language Class Initialized
ERROR - 2016-09-24 15:26:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:27:17 --> Config Class Initialized
INFO - 2016-09-24 15:27:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:27:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:27:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:27:17 --> URI Class Initialized
INFO - 2016-09-24 15:27:17 --> Router Class Initialized
INFO - 2016-09-24 15:27:17 --> Output Class Initialized
INFO - 2016-09-24 15:27:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:27:17 --> Input Class Initialized
INFO - 2016-09-24 15:27:17 --> Language Class Initialized
ERROR - 2016-09-24 15:27:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:27:47 --> Config Class Initialized
INFO - 2016-09-24 15:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:27:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:27:47 --> URI Class Initialized
INFO - 2016-09-24 15:27:47 --> Router Class Initialized
INFO - 2016-09-24 15:27:47 --> Output Class Initialized
INFO - 2016-09-24 15:27:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:27:47 --> Input Class Initialized
INFO - 2016-09-24 15:27:47 --> Language Class Initialized
ERROR - 2016-09-24 15:27:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:28:17 --> Config Class Initialized
INFO - 2016-09-24 15:28:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:28:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:28:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:28:17 --> URI Class Initialized
INFO - 2016-09-24 15:28:17 --> Router Class Initialized
INFO - 2016-09-24 15:28:17 --> Output Class Initialized
INFO - 2016-09-24 15:28:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:28:17 --> Input Class Initialized
INFO - 2016-09-24 15:28:17 --> Language Class Initialized
ERROR - 2016-09-24 15:28:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:28:47 --> Config Class Initialized
INFO - 2016-09-24 15:28:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:28:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:28:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:28:47 --> URI Class Initialized
INFO - 2016-09-24 15:28:47 --> Router Class Initialized
INFO - 2016-09-24 15:28:47 --> Output Class Initialized
INFO - 2016-09-24 15:28:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:28:47 --> Input Class Initialized
INFO - 2016-09-24 15:28:47 --> Language Class Initialized
ERROR - 2016-09-24 15:28:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:29:17 --> Config Class Initialized
INFO - 2016-09-24 15:29:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:29:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:29:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:29:17 --> URI Class Initialized
INFO - 2016-09-24 15:29:17 --> Router Class Initialized
INFO - 2016-09-24 15:29:17 --> Output Class Initialized
INFO - 2016-09-24 15:29:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:29:17 --> Input Class Initialized
INFO - 2016-09-24 15:29:17 --> Language Class Initialized
ERROR - 2016-09-24 15:29:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:29:47 --> Config Class Initialized
INFO - 2016-09-24 15:29:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:29:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:29:47 --> URI Class Initialized
INFO - 2016-09-24 15:29:47 --> Router Class Initialized
INFO - 2016-09-24 15:29:47 --> Output Class Initialized
INFO - 2016-09-24 15:29:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:29:47 --> Input Class Initialized
INFO - 2016-09-24 15:29:47 --> Language Class Initialized
ERROR - 2016-09-24 15:29:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:30:17 --> Config Class Initialized
INFO - 2016-09-24 15:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:30:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:30:17 --> URI Class Initialized
INFO - 2016-09-24 15:30:17 --> Router Class Initialized
INFO - 2016-09-24 15:30:17 --> Output Class Initialized
INFO - 2016-09-24 15:30:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:30:17 --> Input Class Initialized
INFO - 2016-09-24 15:30:17 --> Language Class Initialized
ERROR - 2016-09-24 15:30:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:30:47 --> Config Class Initialized
INFO - 2016-09-24 15:30:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:30:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:30:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:30:47 --> URI Class Initialized
INFO - 2016-09-24 15:30:47 --> Router Class Initialized
INFO - 2016-09-24 15:30:47 --> Output Class Initialized
INFO - 2016-09-24 15:30:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:30:47 --> Input Class Initialized
INFO - 2016-09-24 15:30:47 --> Language Class Initialized
ERROR - 2016-09-24 15:30:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:31:17 --> Config Class Initialized
INFO - 2016-09-24 15:31:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:31:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:31:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:31:17 --> URI Class Initialized
INFO - 2016-09-24 15:31:17 --> Router Class Initialized
INFO - 2016-09-24 15:31:17 --> Output Class Initialized
INFO - 2016-09-24 15:31:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:31:17 --> Input Class Initialized
INFO - 2016-09-24 15:31:17 --> Language Class Initialized
ERROR - 2016-09-24 15:31:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:31:47 --> Config Class Initialized
INFO - 2016-09-24 15:31:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:31:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:31:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:31:47 --> URI Class Initialized
INFO - 2016-09-24 15:31:47 --> Router Class Initialized
INFO - 2016-09-24 15:31:47 --> Output Class Initialized
INFO - 2016-09-24 15:31:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:31:47 --> Input Class Initialized
INFO - 2016-09-24 15:31:47 --> Language Class Initialized
ERROR - 2016-09-24 15:31:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:32:17 --> Config Class Initialized
INFO - 2016-09-24 15:32:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:32:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:32:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:32:17 --> URI Class Initialized
INFO - 2016-09-24 15:32:17 --> Router Class Initialized
INFO - 2016-09-24 15:32:17 --> Output Class Initialized
INFO - 2016-09-24 15:32:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:32:17 --> Input Class Initialized
INFO - 2016-09-24 15:32:17 --> Language Class Initialized
ERROR - 2016-09-24 15:32:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:32:47 --> Config Class Initialized
INFO - 2016-09-24 15:32:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:32:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:32:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:32:47 --> URI Class Initialized
INFO - 2016-09-24 15:32:47 --> Router Class Initialized
INFO - 2016-09-24 15:32:47 --> Output Class Initialized
INFO - 2016-09-24 15:32:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:32:47 --> Input Class Initialized
INFO - 2016-09-24 15:32:47 --> Language Class Initialized
ERROR - 2016-09-24 15:32:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:33:17 --> Config Class Initialized
INFO - 2016-09-24 15:33:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:33:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:33:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:33:17 --> URI Class Initialized
INFO - 2016-09-24 15:33:17 --> Router Class Initialized
INFO - 2016-09-24 15:33:17 --> Output Class Initialized
INFO - 2016-09-24 15:33:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:33:17 --> Input Class Initialized
INFO - 2016-09-24 15:33:17 --> Language Class Initialized
ERROR - 2016-09-24 15:33:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:33:47 --> Config Class Initialized
INFO - 2016-09-24 15:33:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:33:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:33:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:33:47 --> URI Class Initialized
INFO - 2016-09-24 15:33:47 --> Router Class Initialized
INFO - 2016-09-24 15:33:47 --> Output Class Initialized
INFO - 2016-09-24 15:33:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:33:47 --> Input Class Initialized
INFO - 2016-09-24 15:33:47 --> Language Class Initialized
ERROR - 2016-09-24 15:33:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:34:17 --> Config Class Initialized
INFO - 2016-09-24 15:34:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:34:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:34:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:34:17 --> URI Class Initialized
INFO - 2016-09-24 15:34:17 --> Router Class Initialized
INFO - 2016-09-24 15:34:17 --> Output Class Initialized
INFO - 2016-09-24 15:34:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:34:17 --> Input Class Initialized
INFO - 2016-09-24 15:34:17 --> Language Class Initialized
ERROR - 2016-09-24 15:34:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:34:47 --> Config Class Initialized
INFO - 2016-09-24 15:34:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:34:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:34:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:34:47 --> URI Class Initialized
INFO - 2016-09-24 15:34:47 --> Router Class Initialized
INFO - 2016-09-24 15:34:47 --> Output Class Initialized
INFO - 2016-09-24 15:34:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:34:47 --> Input Class Initialized
INFO - 2016-09-24 15:34:47 --> Language Class Initialized
ERROR - 2016-09-24 15:34:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:35:17 --> Config Class Initialized
INFO - 2016-09-24 15:35:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:35:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:35:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:35:17 --> URI Class Initialized
INFO - 2016-09-24 15:35:17 --> Router Class Initialized
INFO - 2016-09-24 15:35:17 --> Output Class Initialized
INFO - 2016-09-24 15:35:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:35:17 --> Input Class Initialized
INFO - 2016-09-24 15:35:17 --> Language Class Initialized
ERROR - 2016-09-24 15:35:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:35:47 --> Config Class Initialized
INFO - 2016-09-24 15:35:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:35:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:35:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:35:47 --> URI Class Initialized
INFO - 2016-09-24 15:35:47 --> Router Class Initialized
INFO - 2016-09-24 15:35:47 --> Output Class Initialized
INFO - 2016-09-24 15:35:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:35:47 --> Input Class Initialized
INFO - 2016-09-24 15:35:47 --> Language Class Initialized
ERROR - 2016-09-24 15:35:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:36:17 --> Config Class Initialized
INFO - 2016-09-24 15:36:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:36:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:36:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:36:17 --> URI Class Initialized
INFO - 2016-09-24 15:36:17 --> Router Class Initialized
INFO - 2016-09-24 15:36:17 --> Output Class Initialized
INFO - 2016-09-24 15:36:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:36:17 --> Input Class Initialized
INFO - 2016-09-24 15:36:17 --> Language Class Initialized
ERROR - 2016-09-24 15:36:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:36:47 --> Config Class Initialized
INFO - 2016-09-24 15:36:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:36:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:36:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:36:47 --> URI Class Initialized
INFO - 2016-09-24 15:36:47 --> Router Class Initialized
INFO - 2016-09-24 15:36:47 --> Output Class Initialized
INFO - 2016-09-24 15:36:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:36:47 --> Input Class Initialized
INFO - 2016-09-24 15:36:47 --> Language Class Initialized
ERROR - 2016-09-24 15:36:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:37:17 --> Config Class Initialized
INFO - 2016-09-24 15:37:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:37:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:37:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:37:17 --> URI Class Initialized
INFO - 2016-09-24 15:37:17 --> Router Class Initialized
INFO - 2016-09-24 15:37:17 --> Output Class Initialized
INFO - 2016-09-24 15:37:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:37:17 --> Input Class Initialized
INFO - 2016-09-24 15:37:17 --> Language Class Initialized
ERROR - 2016-09-24 15:37:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:37:47 --> Config Class Initialized
INFO - 2016-09-24 15:37:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:37:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:37:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:37:47 --> URI Class Initialized
INFO - 2016-09-24 15:37:47 --> Router Class Initialized
INFO - 2016-09-24 15:37:47 --> Output Class Initialized
INFO - 2016-09-24 15:37:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:37:47 --> Input Class Initialized
INFO - 2016-09-24 15:37:47 --> Language Class Initialized
ERROR - 2016-09-24 15:37:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:38:17 --> Config Class Initialized
INFO - 2016-09-24 15:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:38:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:38:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:38:17 --> URI Class Initialized
INFO - 2016-09-24 15:38:17 --> Router Class Initialized
INFO - 2016-09-24 15:38:17 --> Output Class Initialized
INFO - 2016-09-24 15:38:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:38:17 --> Input Class Initialized
INFO - 2016-09-24 15:38:17 --> Language Class Initialized
ERROR - 2016-09-24 15:38:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:38:47 --> Config Class Initialized
INFO - 2016-09-24 15:38:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:38:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:38:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:38:47 --> URI Class Initialized
INFO - 2016-09-24 15:38:47 --> Router Class Initialized
INFO - 2016-09-24 15:38:47 --> Output Class Initialized
INFO - 2016-09-24 15:38:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:38:47 --> Input Class Initialized
INFO - 2016-09-24 15:38:47 --> Language Class Initialized
ERROR - 2016-09-24 15:38:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:39:17 --> Config Class Initialized
INFO - 2016-09-24 15:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:39:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:39:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:39:17 --> URI Class Initialized
INFO - 2016-09-24 15:39:17 --> Router Class Initialized
INFO - 2016-09-24 15:39:17 --> Output Class Initialized
INFO - 2016-09-24 15:39:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:39:17 --> Input Class Initialized
INFO - 2016-09-24 15:39:17 --> Language Class Initialized
ERROR - 2016-09-24 15:39:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:39:47 --> Config Class Initialized
INFO - 2016-09-24 15:39:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:39:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:39:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:39:47 --> URI Class Initialized
INFO - 2016-09-24 15:39:47 --> Router Class Initialized
INFO - 2016-09-24 15:39:47 --> Output Class Initialized
INFO - 2016-09-24 15:39:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:39:47 --> Input Class Initialized
INFO - 2016-09-24 15:39:47 --> Language Class Initialized
ERROR - 2016-09-24 15:39:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:40:17 --> Config Class Initialized
INFO - 2016-09-24 15:40:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:40:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:40:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:40:17 --> URI Class Initialized
INFO - 2016-09-24 15:40:17 --> Router Class Initialized
INFO - 2016-09-24 15:40:17 --> Output Class Initialized
INFO - 2016-09-24 15:40:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:40:17 --> Input Class Initialized
INFO - 2016-09-24 15:40:17 --> Language Class Initialized
ERROR - 2016-09-24 15:40:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:40:47 --> Config Class Initialized
INFO - 2016-09-24 15:40:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:40:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:40:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:40:47 --> URI Class Initialized
INFO - 2016-09-24 15:40:47 --> Router Class Initialized
INFO - 2016-09-24 15:40:47 --> Output Class Initialized
INFO - 2016-09-24 15:40:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:40:47 --> Input Class Initialized
INFO - 2016-09-24 15:40:47 --> Language Class Initialized
ERROR - 2016-09-24 15:40:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:41:17 --> Config Class Initialized
INFO - 2016-09-24 15:41:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:41:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:41:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:41:17 --> URI Class Initialized
INFO - 2016-09-24 15:41:17 --> Router Class Initialized
INFO - 2016-09-24 15:41:17 --> Output Class Initialized
INFO - 2016-09-24 15:41:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:41:17 --> Input Class Initialized
INFO - 2016-09-24 15:41:17 --> Language Class Initialized
ERROR - 2016-09-24 15:41:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:41:47 --> Config Class Initialized
INFO - 2016-09-24 15:41:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:41:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:41:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:41:47 --> URI Class Initialized
INFO - 2016-09-24 15:41:47 --> Router Class Initialized
INFO - 2016-09-24 15:41:47 --> Output Class Initialized
INFO - 2016-09-24 15:41:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:41:47 --> Input Class Initialized
INFO - 2016-09-24 15:41:47 --> Language Class Initialized
ERROR - 2016-09-24 15:41:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:42:17 --> Config Class Initialized
INFO - 2016-09-24 15:42:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:42:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:42:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:42:17 --> URI Class Initialized
INFO - 2016-09-24 15:42:17 --> Router Class Initialized
INFO - 2016-09-24 15:42:17 --> Output Class Initialized
INFO - 2016-09-24 15:42:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:42:17 --> Input Class Initialized
INFO - 2016-09-24 15:42:17 --> Language Class Initialized
ERROR - 2016-09-24 15:42:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:42:47 --> Config Class Initialized
INFO - 2016-09-24 15:42:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:42:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:42:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:42:47 --> URI Class Initialized
INFO - 2016-09-24 15:42:47 --> Router Class Initialized
INFO - 2016-09-24 15:42:47 --> Output Class Initialized
INFO - 2016-09-24 15:42:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:42:47 --> Input Class Initialized
INFO - 2016-09-24 15:42:47 --> Language Class Initialized
ERROR - 2016-09-24 15:42:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:43:17 --> Config Class Initialized
INFO - 2016-09-24 15:43:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:43:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:43:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:43:17 --> URI Class Initialized
INFO - 2016-09-24 15:43:17 --> Router Class Initialized
INFO - 2016-09-24 15:43:17 --> Output Class Initialized
INFO - 2016-09-24 15:43:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:43:17 --> Input Class Initialized
INFO - 2016-09-24 15:43:17 --> Language Class Initialized
ERROR - 2016-09-24 15:43:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:43:47 --> Config Class Initialized
INFO - 2016-09-24 15:43:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:43:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:43:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:43:47 --> URI Class Initialized
INFO - 2016-09-24 15:43:47 --> Router Class Initialized
INFO - 2016-09-24 15:43:47 --> Output Class Initialized
INFO - 2016-09-24 15:43:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:43:47 --> Input Class Initialized
INFO - 2016-09-24 15:43:47 --> Language Class Initialized
ERROR - 2016-09-24 15:43:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:44:17 --> Config Class Initialized
INFO - 2016-09-24 15:44:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:44:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:44:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:44:17 --> URI Class Initialized
INFO - 2016-09-24 15:44:17 --> Router Class Initialized
INFO - 2016-09-24 15:44:17 --> Output Class Initialized
INFO - 2016-09-24 15:44:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:44:17 --> Input Class Initialized
INFO - 2016-09-24 15:44:17 --> Language Class Initialized
ERROR - 2016-09-24 15:44:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:44:47 --> Config Class Initialized
INFO - 2016-09-24 15:44:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:44:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:44:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:44:47 --> URI Class Initialized
INFO - 2016-09-24 15:44:47 --> Router Class Initialized
INFO - 2016-09-24 15:44:47 --> Output Class Initialized
INFO - 2016-09-24 15:44:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:44:47 --> Input Class Initialized
INFO - 2016-09-24 15:44:47 --> Language Class Initialized
ERROR - 2016-09-24 15:44:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:45:17 --> Config Class Initialized
INFO - 2016-09-24 15:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:45:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:45:17 --> URI Class Initialized
INFO - 2016-09-24 15:45:17 --> Router Class Initialized
INFO - 2016-09-24 15:45:17 --> Output Class Initialized
INFO - 2016-09-24 15:45:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:45:17 --> Input Class Initialized
INFO - 2016-09-24 15:45:17 --> Language Class Initialized
ERROR - 2016-09-24 15:45:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:45:47 --> Config Class Initialized
INFO - 2016-09-24 15:45:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:45:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:45:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:45:47 --> URI Class Initialized
INFO - 2016-09-24 15:45:47 --> Router Class Initialized
INFO - 2016-09-24 15:45:47 --> Output Class Initialized
INFO - 2016-09-24 15:45:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:45:47 --> Input Class Initialized
INFO - 2016-09-24 15:45:47 --> Language Class Initialized
ERROR - 2016-09-24 15:45:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:46:17 --> Config Class Initialized
INFO - 2016-09-24 15:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:46:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:46:17 --> URI Class Initialized
INFO - 2016-09-24 15:46:17 --> Router Class Initialized
INFO - 2016-09-24 15:46:17 --> Output Class Initialized
INFO - 2016-09-24 15:46:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:46:17 --> Input Class Initialized
INFO - 2016-09-24 15:46:17 --> Language Class Initialized
ERROR - 2016-09-24 15:46:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:46:47 --> Config Class Initialized
INFO - 2016-09-24 15:46:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:46:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:46:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:46:47 --> URI Class Initialized
INFO - 2016-09-24 15:46:47 --> Router Class Initialized
INFO - 2016-09-24 15:46:47 --> Output Class Initialized
INFO - 2016-09-24 15:46:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:46:47 --> Input Class Initialized
INFO - 2016-09-24 15:46:47 --> Language Class Initialized
ERROR - 2016-09-24 15:46:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:47:17 --> Config Class Initialized
INFO - 2016-09-24 15:47:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:47:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:47:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:47:17 --> URI Class Initialized
INFO - 2016-09-24 15:47:17 --> Router Class Initialized
INFO - 2016-09-24 15:47:17 --> Output Class Initialized
INFO - 2016-09-24 15:47:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:47:17 --> Input Class Initialized
INFO - 2016-09-24 15:47:17 --> Language Class Initialized
ERROR - 2016-09-24 15:47:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:47:47 --> Config Class Initialized
INFO - 2016-09-24 15:47:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:47:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:47:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:47:47 --> URI Class Initialized
INFO - 2016-09-24 15:47:47 --> Router Class Initialized
INFO - 2016-09-24 15:47:47 --> Output Class Initialized
INFO - 2016-09-24 15:47:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:47:47 --> Input Class Initialized
INFO - 2016-09-24 15:47:47 --> Language Class Initialized
ERROR - 2016-09-24 15:47:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:48:17 --> Config Class Initialized
INFO - 2016-09-24 15:48:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:48:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:48:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:48:17 --> URI Class Initialized
INFO - 2016-09-24 15:48:17 --> Router Class Initialized
INFO - 2016-09-24 15:48:17 --> Output Class Initialized
INFO - 2016-09-24 15:48:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:48:17 --> Input Class Initialized
INFO - 2016-09-24 15:48:17 --> Language Class Initialized
ERROR - 2016-09-24 15:48:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:48:47 --> Config Class Initialized
INFO - 2016-09-24 15:48:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:48:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:48:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:48:47 --> URI Class Initialized
INFO - 2016-09-24 15:48:47 --> Router Class Initialized
INFO - 2016-09-24 15:48:47 --> Output Class Initialized
INFO - 2016-09-24 15:48:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:48:47 --> Input Class Initialized
INFO - 2016-09-24 15:48:47 --> Language Class Initialized
ERROR - 2016-09-24 15:48:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:49:17 --> Config Class Initialized
INFO - 2016-09-24 15:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:49:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:49:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:49:17 --> URI Class Initialized
INFO - 2016-09-24 15:49:17 --> Router Class Initialized
INFO - 2016-09-24 15:49:17 --> Output Class Initialized
INFO - 2016-09-24 15:49:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:49:17 --> Input Class Initialized
INFO - 2016-09-24 15:49:17 --> Language Class Initialized
ERROR - 2016-09-24 15:49:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:49:47 --> Config Class Initialized
INFO - 2016-09-24 15:49:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:49:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:49:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:49:47 --> URI Class Initialized
INFO - 2016-09-24 15:49:47 --> Router Class Initialized
INFO - 2016-09-24 15:49:47 --> Output Class Initialized
INFO - 2016-09-24 15:49:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:49:47 --> Input Class Initialized
INFO - 2016-09-24 15:49:47 --> Language Class Initialized
ERROR - 2016-09-24 15:49:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:50:17 --> Config Class Initialized
INFO - 2016-09-24 15:50:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:50:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:50:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:50:17 --> URI Class Initialized
INFO - 2016-09-24 15:50:17 --> Router Class Initialized
INFO - 2016-09-24 15:50:17 --> Output Class Initialized
INFO - 2016-09-24 15:50:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:50:17 --> Input Class Initialized
INFO - 2016-09-24 15:50:17 --> Language Class Initialized
ERROR - 2016-09-24 15:50:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:50:47 --> Config Class Initialized
INFO - 2016-09-24 15:50:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:50:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:50:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:50:47 --> URI Class Initialized
INFO - 2016-09-24 15:50:47 --> Router Class Initialized
INFO - 2016-09-24 15:50:47 --> Output Class Initialized
INFO - 2016-09-24 15:50:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:50:47 --> Input Class Initialized
INFO - 2016-09-24 15:50:47 --> Language Class Initialized
ERROR - 2016-09-24 15:50:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:51:17 --> Config Class Initialized
INFO - 2016-09-24 15:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:51:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:51:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:51:17 --> URI Class Initialized
INFO - 2016-09-24 15:51:17 --> Router Class Initialized
INFO - 2016-09-24 15:51:17 --> Output Class Initialized
INFO - 2016-09-24 15:51:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:51:17 --> Input Class Initialized
INFO - 2016-09-24 15:51:17 --> Language Class Initialized
ERROR - 2016-09-24 15:51:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:51:47 --> Config Class Initialized
INFO - 2016-09-24 15:51:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:51:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:51:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:51:47 --> URI Class Initialized
INFO - 2016-09-24 15:51:47 --> Router Class Initialized
INFO - 2016-09-24 15:51:47 --> Output Class Initialized
INFO - 2016-09-24 15:51:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:51:47 --> Input Class Initialized
INFO - 2016-09-24 15:51:47 --> Language Class Initialized
ERROR - 2016-09-24 15:51:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:52:17 --> Config Class Initialized
INFO - 2016-09-24 15:52:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:52:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:52:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:52:17 --> URI Class Initialized
INFO - 2016-09-24 15:52:17 --> Router Class Initialized
INFO - 2016-09-24 15:52:17 --> Output Class Initialized
INFO - 2016-09-24 15:52:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:52:17 --> Input Class Initialized
INFO - 2016-09-24 15:52:17 --> Language Class Initialized
ERROR - 2016-09-24 15:52:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:52:47 --> Config Class Initialized
INFO - 2016-09-24 15:52:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:52:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:52:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:52:47 --> URI Class Initialized
INFO - 2016-09-24 15:52:47 --> Router Class Initialized
INFO - 2016-09-24 15:52:47 --> Output Class Initialized
INFO - 2016-09-24 15:52:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:52:47 --> Input Class Initialized
INFO - 2016-09-24 15:52:47 --> Language Class Initialized
ERROR - 2016-09-24 15:52:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:53:17 --> Config Class Initialized
INFO - 2016-09-24 15:53:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:53:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:53:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:53:17 --> URI Class Initialized
INFO - 2016-09-24 15:53:17 --> Router Class Initialized
INFO - 2016-09-24 15:53:17 --> Output Class Initialized
INFO - 2016-09-24 15:53:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:53:17 --> Input Class Initialized
INFO - 2016-09-24 15:53:17 --> Language Class Initialized
ERROR - 2016-09-24 15:53:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:53:47 --> Config Class Initialized
INFO - 2016-09-24 15:53:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:53:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:53:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:53:47 --> URI Class Initialized
INFO - 2016-09-24 15:53:47 --> Router Class Initialized
INFO - 2016-09-24 15:53:47 --> Output Class Initialized
INFO - 2016-09-24 15:53:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:53:47 --> Input Class Initialized
INFO - 2016-09-24 15:53:47 --> Language Class Initialized
ERROR - 2016-09-24 15:53:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:54:17 --> Config Class Initialized
INFO - 2016-09-24 15:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:54:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:54:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:54:17 --> URI Class Initialized
INFO - 2016-09-24 15:54:17 --> Router Class Initialized
INFO - 2016-09-24 15:54:17 --> Output Class Initialized
INFO - 2016-09-24 15:54:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:54:17 --> Input Class Initialized
INFO - 2016-09-24 15:54:17 --> Language Class Initialized
ERROR - 2016-09-24 15:54:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:54:47 --> Config Class Initialized
INFO - 2016-09-24 15:54:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:54:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:54:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:54:47 --> URI Class Initialized
INFO - 2016-09-24 15:54:47 --> Router Class Initialized
INFO - 2016-09-24 15:54:47 --> Output Class Initialized
INFO - 2016-09-24 15:54:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:54:47 --> Input Class Initialized
INFO - 2016-09-24 15:54:47 --> Language Class Initialized
ERROR - 2016-09-24 15:54:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:55:17 --> Config Class Initialized
INFO - 2016-09-24 15:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:55:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:55:17 --> URI Class Initialized
INFO - 2016-09-24 15:55:17 --> Router Class Initialized
INFO - 2016-09-24 15:55:17 --> Output Class Initialized
INFO - 2016-09-24 15:55:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:55:17 --> Input Class Initialized
INFO - 2016-09-24 15:55:17 --> Language Class Initialized
ERROR - 2016-09-24 15:55:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:55:47 --> Config Class Initialized
INFO - 2016-09-24 15:55:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:55:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:55:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:55:47 --> URI Class Initialized
INFO - 2016-09-24 15:55:47 --> Router Class Initialized
INFO - 2016-09-24 15:55:47 --> Output Class Initialized
INFO - 2016-09-24 15:55:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:55:47 --> Input Class Initialized
INFO - 2016-09-24 15:55:47 --> Language Class Initialized
ERROR - 2016-09-24 15:55:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:56:17 --> Config Class Initialized
INFO - 2016-09-24 15:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:56:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:56:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:56:17 --> URI Class Initialized
INFO - 2016-09-24 15:56:17 --> Router Class Initialized
INFO - 2016-09-24 15:56:17 --> Output Class Initialized
INFO - 2016-09-24 15:56:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:56:17 --> Input Class Initialized
INFO - 2016-09-24 15:56:17 --> Language Class Initialized
ERROR - 2016-09-24 15:56:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:56:47 --> Config Class Initialized
INFO - 2016-09-24 15:56:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:56:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:56:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:56:47 --> URI Class Initialized
INFO - 2016-09-24 15:56:47 --> Router Class Initialized
INFO - 2016-09-24 15:56:47 --> Output Class Initialized
INFO - 2016-09-24 15:56:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:56:47 --> Input Class Initialized
INFO - 2016-09-24 15:56:47 --> Language Class Initialized
ERROR - 2016-09-24 15:56:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:57:17 --> Config Class Initialized
INFO - 2016-09-24 15:57:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:57:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:57:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:57:17 --> URI Class Initialized
INFO - 2016-09-24 15:57:17 --> Router Class Initialized
INFO - 2016-09-24 15:57:17 --> Output Class Initialized
INFO - 2016-09-24 15:57:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:57:17 --> Input Class Initialized
INFO - 2016-09-24 15:57:17 --> Language Class Initialized
ERROR - 2016-09-24 15:57:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:57:47 --> Config Class Initialized
INFO - 2016-09-24 15:57:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:57:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:57:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:57:47 --> URI Class Initialized
INFO - 2016-09-24 15:57:47 --> Router Class Initialized
INFO - 2016-09-24 15:57:47 --> Output Class Initialized
INFO - 2016-09-24 15:57:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:57:47 --> Input Class Initialized
INFO - 2016-09-24 15:57:47 --> Language Class Initialized
ERROR - 2016-09-24 15:57:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:58:17 --> Config Class Initialized
INFO - 2016-09-24 15:58:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:58:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:58:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:58:17 --> URI Class Initialized
INFO - 2016-09-24 15:58:17 --> Router Class Initialized
INFO - 2016-09-24 15:58:17 --> Output Class Initialized
INFO - 2016-09-24 15:58:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:58:17 --> Input Class Initialized
INFO - 2016-09-24 15:58:17 --> Language Class Initialized
ERROR - 2016-09-24 15:58:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:58:47 --> Config Class Initialized
INFO - 2016-09-24 15:58:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:58:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:58:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:58:47 --> URI Class Initialized
INFO - 2016-09-24 15:58:47 --> Router Class Initialized
INFO - 2016-09-24 15:58:47 --> Output Class Initialized
INFO - 2016-09-24 15:58:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:58:47 --> Input Class Initialized
INFO - 2016-09-24 15:58:47 --> Language Class Initialized
ERROR - 2016-09-24 15:58:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:59:17 --> Config Class Initialized
INFO - 2016-09-24 15:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:59:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:59:17 --> Utf8 Class Initialized
INFO - 2016-09-24 15:59:17 --> URI Class Initialized
INFO - 2016-09-24 15:59:17 --> Router Class Initialized
INFO - 2016-09-24 15:59:17 --> Output Class Initialized
INFO - 2016-09-24 15:59:17 --> Security Class Initialized
DEBUG - 2016-09-24 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:59:17 --> Input Class Initialized
INFO - 2016-09-24 15:59:17 --> Language Class Initialized
ERROR - 2016-09-24 15:59:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 15:59:47 --> Config Class Initialized
INFO - 2016-09-24 15:59:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 15:59:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 15:59:47 --> Utf8 Class Initialized
INFO - 2016-09-24 15:59:47 --> URI Class Initialized
INFO - 2016-09-24 15:59:47 --> Router Class Initialized
INFO - 2016-09-24 15:59:47 --> Output Class Initialized
INFO - 2016-09-24 15:59:47 --> Security Class Initialized
DEBUG - 2016-09-24 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 15:59:47 --> Input Class Initialized
INFO - 2016-09-24 15:59:47 --> Language Class Initialized
ERROR - 2016-09-24 15:59:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:00:17 --> Config Class Initialized
INFO - 2016-09-24 16:00:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:00:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:00:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:00:17 --> URI Class Initialized
INFO - 2016-09-24 16:00:17 --> Router Class Initialized
INFO - 2016-09-24 16:00:17 --> Output Class Initialized
INFO - 2016-09-24 16:00:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:00:17 --> Input Class Initialized
INFO - 2016-09-24 16:00:17 --> Language Class Initialized
ERROR - 2016-09-24 16:00:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:00:47 --> Config Class Initialized
INFO - 2016-09-24 16:00:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:00:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:00:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:00:47 --> URI Class Initialized
INFO - 2016-09-24 16:00:47 --> Router Class Initialized
INFO - 2016-09-24 16:00:47 --> Output Class Initialized
INFO - 2016-09-24 16:00:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:00:47 --> Input Class Initialized
INFO - 2016-09-24 16:00:47 --> Language Class Initialized
ERROR - 2016-09-24 16:00:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:01:17 --> Config Class Initialized
INFO - 2016-09-24 16:01:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:01:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:01:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:01:17 --> URI Class Initialized
INFO - 2016-09-24 16:01:17 --> Router Class Initialized
INFO - 2016-09-24 16:01:17 --> Output Class Initialized
INFO - 2016-09-24 16:01:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:01:17 --> Input Class Initialized
INFO - 2016-09-24 16:01:17 --> Language Class Initialized
ERROR - 2016-09-24 16:01:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:01:47 --> Config Class Initialized
INFO - 2016-09-24 16:01:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:01:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:01:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:01:47 --> URI Class Initialized
INFO - 2016-09-24 16:01:47 --> Router Class Initialized
INFO - 2016-09-24 16:01:47 --> Output Class Initialized
INFO - 2016-09-24 16:01:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:01:47 --> Input Class Initialized
INFO - 2016-09-24 16:01:47 --> Language Class Initialized
ERROR - 2016-09-24 16:01:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:02:17 --> Config Class Initialized
INFO - 2016-09-24 16:02:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:02:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:02:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:02:17 --> URI Class Initialized
INFO - 2016-09-24 16:02:17 --> Router Class Initialized
INFO - 2016-09-24 16:02:17 --> Output Class Initialized
INFO - 2016-09-24 16:02:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:02:17 --> Input Class Initialized
INFO - 2016-09-24 16:02:17 --> Language Class Initialized
ERROR - 2016-09-24 16:02:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:02:47 --> Config Class Initialized
INFO - 2016-09-24 16:02:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:02:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:02:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:02:47 --> URI Class Initialized
INFO - 2016-09-24 16:02:47 --> Router Class Initialized
INFO - 2016-09-24 16:02:47 --> Output Class Initialized
INFO - 2016-09-24 16:02:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:02:47 --> Input Class Initialized
INFO - 2016-09-24 16:02:47 --> Language Class Initialized
ERROR - 2016-09-24 16:02:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:03:17 --> Config Class Initialized
INFO - 2016-09-24 16:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:03:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:03:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:03:17 --> URI Class Initialized
INFO - 2016-09-24 16:03:17 --> Router Class Initialized
INFO - 2016-09-24 16:03:17 --> Output Class Initialized
INFO - 2016-09-24 16:03:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:03:17 --> Input Class Initialized
INFO - 2016-09-24 16:03:17 --> Language Class Initialized
ERROR - 2016-09-24 16:03:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:03:47 --> Config Class Initialized
INFO - 2016-09-24 16:03:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:03:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:03:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:03:47 --> URI Class Initialized
INFO - 2016-09-24 16:03:47 --> Router Class Initialized
INFO - 2016-09-24 16:03:47 --> Output Class Initialized
INFO - 2016-09-24 16:03:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:03:47 --> Input Class Initialized
INFO - 2016-09-24 16:03:47 --> Language Class Initialized
ERROR - 2016-09-24 16:03:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:04:17 --> Config Class Initialized
INFO - 2016-09-24 16:04:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:04:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:04:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:04:17 --> URI Class Initialized
INFO - 2016-09-24 16:04:17 --> Router Class Initialized
INFO - 2016-09-24 16:04:17 --> Output Class Initialized
INFO - 2016-09-24 16:04:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:04:17 --> Input Class Initialized
INFO - 2016-09-24 16:04:17 --> Language Class Initialized
ERROR - 2016-09-24 16:04:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:04:47 --> Config Class Initialized
INFO - 2016-09-24 16:04:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:04:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:04:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:04:47 --> URI Class Initialized
INFO - 2016-09-24 16:04:47 --> Router Class Initialized
INFO - 2016-09-24 16:04:47 --> Output Class Initialized
INFO - 2016-09-24 16:04:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:04:47 --> Input Class Initialized
INFO - 2016-09-24 16:04:47 --> Language Class Initialized
ERROR - 2016-09-24 16:04:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:05:17 --> Config Class Initialized
INFO - 2016-09-24 16:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:05:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:05:17 --> URI Class Initialized
INFO - 2016-09-24 16:05:17 --> Router Class Initialized
INFO - 2016-09-24 16:05:17 --> Output Class Initialized
INFO - 2016-09-24 16:05:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:05:17 --> Input Class Initialized
INFO - 2016-09-24 16:05:17 --> Language Class Initialized
ERROR - 2016-09-24 16:05:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:05:47 --> Config Class Initialized
INFO - 2016-09-24 16:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:05:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:05:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:05:47 --> URI Class Initialized
INFO - 2016-09-24 16:05:47 --> Router Class Initialized
INFO - 2016-09-24 16:05:47 --> Output Class Initialized
INFO - 2016-09-24 16:05:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:05:47 --> Input Class Initialized
INFO - 2016-09-24 16:05:47 --> Language Class Initialized
ERROR - 2016-09-24 16:05:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:06:17 --> Config Class Initialized
INFO - 2016-09-24 16:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:06:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:06:17 --> URI Class Initialized
INFO - 2016-09-24 16:06:17 --> Router Class Initialized
INFO - 2016-09-24 16:06:17 --> Output Class Initialized
INFO - 2016-09-24 16:06:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:06:17 --> Input Class Initialized
INFO - 2016-09-24 16:06:17 --> Language Class Initialized
ERROR - 2016-09-24 16:06:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:06:47 --> Config Class Initialized
INFO - 2016-09-24 16:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:06:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:06:47 --> URI Class Initialized
INFO - 2016-09-24 16:06:47 --> Router Class Initialized
INFO - 2016-09-24 16:06:47 --> Output Class Initialized
INFO - 2016-09-24 16:06:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:06:47 --> Input Class Initialized
INFO - 2016-09-24 16:06:47 --> Language Class Initialized
ERROR - 2016-09-24 16:06:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:07:17 --> Config Class Initialized
INFO - 2016-09-24 16:07:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:07:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:07:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:07:17 --> URI Class Initialized
INFO - 2016-09-24 16:07:17 --> Router Class Initialized
INFO - 2016-09-24 16:07:17 --> Output Class Initialized
INFO - 2016-09-24 16:07:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:07:17 --> Input Class Initialized
INFO - 2016-09-24 16:07:17 --> Language Class Initialized
ERROR - 2016-09-24 16:07:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:07:47 --> Config Class Initialized
INFO - 2016-09-24 16:07:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:07:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:07:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:07:47 --> URI Class Initialized
INFO - 2016-09-24 16:07:47 --> Router Class Initialized
INFO - 2016-09-24 16:07:47 --> Output Class Initialized
INFO - 2016-09-24 16:07:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:07:47 --> Input Class Initialized
INFO - 2016-09-24 16:07:47 --> Language Class Initialized
ERROR - 2016-09-24 16:07:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:08:17 --> Config Class Initialized
INFO - 2016-09-24 16:08:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:08:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:08:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:08:17 --> URI Class Initialized
INFO - 2016-09-24 16:08:17 --> Router Class Initialized
INFO - 2016-09-24 16:08:17 --> Output Class Initialized
INFO - 2016-09-24 16:08:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:08:17 --> Input Class Initialized
INFO - 2016-09-24 16:08:17 --> Language Class Initialized
ERROR - 2016-09-24 16:08:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:08:47 --> Config Class Initialized
INFO - 2016-09-24 16:08:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:08:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:08:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:08:47 --> URI Class Initialized
INFO - 2016-09-24 16:08:47 --> Router Class Initialized
INFO - 2016-09-24 16:08:47 --> Output Class Initialized
INFO - 2016-09-24 16:08:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:08:47 --> Input Class Initialized
INFO - 2016-09-24 16:08:47 --> Language Class Initialized
ERROR - 2016-09-24 16:08:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:09:17 --> Config Class Initialized
INFO - 2016-09-24 16:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:09:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:09:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:09:17 --> URI Class Initialized
INFO - 2016-09-24 16:09:17 --> Router Class Initialized
INFO - 2016-09-24 16:09:17 --> Output Class Initialized
INFO - 2016-09-24 16:09:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:09:17 --> Input Class Initialized
INFO - 2016-09-24 16:09:17 --> Language Class Initialized
ERROR - 2016-09-24 16:09:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:09:47 --> Config Class Initialized
INFO - 2016-09-24 16:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:09:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:09:47 --> URI Class Initialized
INFO - 2016-09-24 16:09:47 --> Router Class Initialized
INFO - 2016-09-24 16:09:47 --> Output Class Initialized
INFO - 2016-09-24 16:09:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:09:47 --> Input Class Initialized
INFO - 2016-09-24 16:09:47 --> Language Class Initialized
ERROR - 2016-09-24 16:09:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:10:17 --> Config Class Initialized
INFO - 2016-09-24 16:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:10:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:10:17 --> URI Class Initialized
INFO - 2016-09-24 16:10:17 --> Router Class Initialized
INFO - 2016-09-24 16:10:17 --> Output Class Initialized
INFO - 2016-09-24 16:10:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:10:17 --> Input Class Initialized
INFO - 2016-09-24 16:10:17 --> Language Class Initialized
ERROR - 2016-09-24 16:10:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:10:47 --> Config Class Initialized
INFO - 2016-09-24 16:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:10:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:10:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:10:47 --> URI Class Initialized
INFO - 2016-09-24 16:10:47 --> Router Class Initialized
INFO - 2016-09-24 16:10:47 --> Output Class Initialized
INFO - 2016-09-24 16:10:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:10:47 --> Input Class Initialized
INFO - 2016-09-24 16:10:47 --> Language Class Initialized
ERROR - 2016-09-24 16:10:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:11:17 --> Config Class Initialized
INFO - 2016-09-24 16:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:11:17 --> URI Class Initialized
INFO - 2016-09-24 16:11:17 --> Router Class Initialized
INFO - 2016-09-24 16:11:17 --> Output Class Initialized
INFO - 2016-09-24 16:11:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:11:17 --> Input Class Initialized
INFO - 2016-09-24 16:11:17 --> Language Class Initialized
ERROR - 2016-09-24 16:11:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:11:47 --> Config Class Initialized
INFO - 2016-09-24 16:11:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:11:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:11:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:11:47 --> URI Class Initialized
INFO - 2016-09-24 16:11:47 --> Router Class Initialized
INFO - 2016-09-24 16:11:47 --> Output Class Initialized
INFO - 2016-09-24 16:11:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:11:47 --> Input Class Initialized
INFO - 2016-09-24 16:11:47 --> Language Class Initialized
ERROR - 2016-09-24 16:11:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:12:17 --> Config Class Initialized
INFO - 2016-09-24 16:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:12:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:12:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:12:17 --> URI Class Initialized
INFO - 2016-09-24 16:12:17 --> Router Class Initialized
INFO - 2016-09-24 16:12:17 --> Output Class Initialized
INFO - 2016-09-24 16:12:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:12:17 --> Input Class Initialized
INFO - 2016-09-24 16:12:17 --> Language Class Initialized
ERROR - 2016-09-24 16:12:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:12:47 --> Config Class Initialized
INFO - 2016-09-24 16:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:12:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:12:47 --> URI Class Initialized
INFO - 2016-09-24 16:12:47 --> Router Class Initialized
INFO - 2016-09-24 16:12:47 --> Output Class Initialized
INFO - 2016-09-24 16:12:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:12:47 --> Input Class Initialized
INFO - 2016-09-24 16:12:47 --> Language Class Initialized
ERROR - 2016-09-24 16:12:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:13:17 --> Config Class Initialized
INFO - 2016-09-24 16:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:13:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:13:17 --> URI Class Initialized
INFO - 2016-09-24 16:13:17 --> Router Class Initialized
INFO - 2016-09-24 16:13:17 --> Output Class Initialized
INFO - 2016-09-24 16:13:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:13:17 --> Input Class Initialized
INFO - 2016-09-24 16:13:17 --> Language Class Initialized
ERROR - 2016-09-24 16:13:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:13:47 --> Config Class Initialized
INFO - 2016-09-24 16:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:13:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:13:47 --> URI Class Initialized
INFO - 2016-09-24 16:13:47 --> Router Class Initialized
INFO - 2016-09-24 16:13:47 --> Output Class Initialized
INFO - 2016-09-24 16:13:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:13:47 --> Input Class Initialized
INFO - 2016-09-24 16:13:47 --> Language Class Initialized
ERROR - 2016-09-24 16:13:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:14:17 --> Config Class Initialized
INFO - 2016-09-24 16:14:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:14:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:14:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:14:17 --> URI Class Initialized
INFO - 2016-09-24 16:14:17 --> Router Class Initialized
INFO - 2016-09-24 16:14:17 --> Output Class Initialized
INFO - 2016-09-24 16:14:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:14:17 --> Input Class Initialized
INFO - 2016-09-24 16:14:17 --> Language Class Initialized
ERROR - 2016-09-24 16:14:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:14:47 --> Config Class Initialized
INFO - 2016-09-24 16:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:14:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:14:47 --> URI Class Initialized
INFO - 2016-09-24 16:14:47 --> Router Class Initialized
INFO - 2016-09-24 16:14:47 --> Output Class Initialized
INFO - 2016-09-24 16:14:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:14:47 --> Input Class Initialized
INFO - 2016-09-24 16:14:47 --> Language Class Initialized
ERROR - 2016-09-24 16:14:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:15:17 --> Config Class Initialized
INFO - 2016-09-24 16:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:15:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:15:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:15:17 --> URI Class Initialized
INFO - 2016-09-24 16:15:17 --> Router Class Initialized
INFO - 2016-09-24 16:15:17 --> Output Class Initialized
INFO - 2016-09-24 16:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:15:17 --> Input Class Initialized
INFO - 2016-09-24 16:15:17 --> Language Class Initialized
ERROR - 2016-09-24 16:15:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:15:47 --> Config Class Initialized
INFO - 2016-09-24 16:15:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:15:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:15:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:15:47 --> URI Class Initialized
INFO - 2016-09-24 16:15:47 --> Router Class Initialized
INFO - 2016-09-24 16:15:47 --> Output Class Initialized
INFO - 2016-09-24 16:15:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:15:47 --> Input Class Initialized
INFO - 2016-09-24 16:15:47 --> Language Class Initialized
ERROR - 2016-09-24 16:15:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:16:17 --> Config Class Initialized
INFO - 2016-09-24 16:16:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:16:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:16:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:16:17 --> URI Class Initialized
INFO - 2016-09-24 16:16:17 --> Router Class Initialized
INFO - 2016-09-24 16:16:17 --> Output Class Initialized
INFO - 2016-09-24 16:16:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:16:17 --> Input Class Initialized
INFO - 2016-09-24 16:16:17 --> Language Class Initialized
ERROR - 2016-09-24 16:16:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:16:47 --> Config Class Initialized
INFO - 2016-09-24 16:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:16:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:16:47 --> URI Class Initialized
INFO - 2016-09-24 16:16:47 --> Router Class Initialized
INFO - 2016-09-24 16:16:47 --> Output Class Initialized
INFO - 2016-09-24 16:16:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:16:47 --> Input Class Initialized
INFO - 2016-09-24 16:16:47 --> Language Class Initialized
ERROR - 2016-09-24 16:16:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:17:17 --> Config Class Initialized
INFO - 2016-09-24 16:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:17:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:17:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:17:17 --> URI Class Initialized
INFO - 2016-09-24 16:17:17 --> Router Class Initialized
INFO - 2016-09-24 16:17:17 --> Output Class Initialized
INFO - 2016-09-24 16:17:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:17:17 --> Input Class Initialized
INFO - 2016-09-24 16:17:17 --> Language Class Initialized
ERROR - 2016-09-24 16:17:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:17:47 --> Config Class Initialized
INFO - 2016-09-24 16:17:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:17:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:17:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:17:47 --> URI Class Initialized
INFO - 2016-09-24 16:17:47 --> Router Class Initialized
INFO - 2016-09-24 16:17:47 --> Output Class Initialized
INFO - 2016-09-24 16:17:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:17:47 --> Input Class Initialized
INFO - 2016-09-24 16:17:47 --> Language Class Initialized
ERROR - 2016-09-24 16:17:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:18:17 --> Config Class Initialized
INFO - 2016-09-24 16:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:18:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:18:17 --> URI Class Initialized
INFO - 2016-09-24 16:18:17 --> Router Class Initialized
INFO - 2016-09-24 16:18:17 --> Output Class Initialized
INFO - 2016-09-24 16:18:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:18:17 --> Input Class Initialized
INFO - 2016-09-24 16:18:17 --> Language Class Initialized
ERROR - 2016-09-24 16:18:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:18:47 --> Config Class Initialized
INFO - 2016-09-24 16:18:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:18:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:18:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:18:47 --> URI Class Initialized
INFO - 2016-09-24 16:18:47 --> Router Class Initialized
INFO - 2016-09-24 16:18:47 --> Output Class Initialized
INFO - 2016-09-24 16:18:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:18:47 --> Input Class Initialized
INFO - 2016-09-24 16:18:47 --> Language Class Initialized
ERROR - 2016-09-24 16:18:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:19:17 --> Config Class Initialized
INFO - 2016-09-24 16:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:19:17 --> URI Class Initialized
INFO - 2016-09-24 16:19:17 --> Router Class Initialized
INFO - 2016-09-24 16:19:17 --> Output Class Initialized
INFO - 2016-09-24 16:19:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:19:17 --> Input Class Initialized
INFO - 2016-09-24 16:19:17 --> Language Class Initialized
ERROR - 2016-09-24 16:19:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:19:47 --> Config Class Initialized
INFO - 2016-09-24 16:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:19:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:19:47 --> URI Class Initialized
INFO - 2016-09-24 16:19:47 --> Router Class Initialized
INFO - 2016-09-24 16:19:47 --> Output Class Initialized
INFO - 2016-09-24 16:19:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:19:47 --> Input Class Initialized
INFO - 2016-09-24 16:19:47 --> Language Class Initialized
ERROR - 2016-09-24 16:19:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:20:17 --> Config Class Initialized
INFO - 2016-09-24 16:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:20:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:20:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:20:17 --> URI Class Initialized
INFO - 2016-09-24 16:20:17 --> Router Class Initialized
INFO - 2016-09-24 16:20:17 --> Output Class Initialized
INFO - 2016-09-24 16:20:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:20:17 --> Input Class Initialized
INFO - 2016-09-24 16:20:17 --> Language Class Initialized
ERROR - 2016-09-24 16:20:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:20:47 --> Config Class Initialized
INFO - 2016-09-24 16:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:20:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:20:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:20:47 --> URI Class Initialized
INFO - 2016-09-24 16:20:47 --> Router Class Initialized
INFO - 2016-09-24 16:20:47 --> Output Class Initialized
INFO - 2016-09-24 16:20:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:20:47 --> Input Class Initialized
INFO - 2016-09-24 16:20:47 --> Language Class Initialized
ERROR - 2016-09-24 16:20:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:21:17 --> Config Class Initialized
INFO - 2016-09-24 16:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:21:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:21:17 --> URI Class Initialized
INFO - 2016-09-24 16:21:17 --> Router Class Initialized
INFO - 2016-09-24 16:21:17 --> Output Class Initialized
INFO - 2016-09-24 16:21:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:21:17 --> Input Class Initialized
INFO - 2016-09-24 16:21:17 --> Language Class Initialized
ERROR - 2016-09-24 16:21:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:21:47 --> Config Class Initialized
INFO - 2016-09-24 16:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:21:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:21:47 --> URI Class Initialized
INFO - 2016-09-24 16:21:47 --> Router Class Initialized
INFO - 2016-09-24 16:21:47 --> Output Class Initialized
INFO - 2016-09-24 16:21:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:21:47 --> Input Class Initialized
INFO - 2016-09-24 16:21:47 --> Language Class Initialized
ERROR - 2016-09-24 16:21:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:22:17 --> Config Class Initialized
INFO - 2016-09-24 16:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:22:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:22:17 --> URI Class Initialized
INFO - 2016-09-24 16:22:17 --> Router Class Initialized
INFO - 2016-09-24 16:22:17 --> Output Class Initialized
INFO - 2016-09-24 16:22:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:22:17 --> Input Class Initialized
INFO - 2016-09-24 16:22:17 --> Language Class Initialized
ERROR - 2016-09-24 16:22:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:22:47 --> Config Class Initialized
INFO - 2016-09-24 16:22:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:22:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:22:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:22:47 --> URI Class Initialized
INFO - 2016-09-24 16:22:47 --> Router Class Initialized
INFO - 2016-09-24 16:22:47 --> Output Class Initialized
INFO - 2016-09-24 16:22:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:22:47 --> Input Class Initialized
INFO - 2016-09-24 16:22:47 --> Language Class Initialized
ERROR - 2016-09-24 16:22:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:23:17 --> Config Class Initialized
INFO - 2016-09-24 16:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:23:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:23:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:23:17 --> URI Class Initialized
INFO - 2016-09-24 16:23:17 --> Router Class Initialized
INFO - 2016-09-24 16:23:17 --> Output Class Initialized
INFO - 2016-09-24 16:23:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:23:17 --> Input Class Initialized
INFO - 2016-09-24 16:23:17 --> Language Class Initialized
ERROR - 2016-09-24 16:23:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:23:47 --> Config Class Initialized
INFO - 2016-09-24 16:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:23:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:23:47 --> URI Class Initialized
INFO - 2016-09-24 16:23:47 --> Router Class Initialized
INFO - 2016-09-24 16:23:47 --> Output Class Initialized
INFO - 2016-09-24 16:23:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:23:47 --> Input Class Initialized
INFO - 2016-09-24 16:23:47 --> Language Class Initialized
ERROR - 2016-09-24 16:23:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:24:17 --> Config Class Initialized
INFO - 2016-09-24 16:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:24:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:24:17 --> URI Class Initialized
INFO - 2016-09-24 16:24:17 --> Router Class Initialized
INFO - 2016-09-24 16:24:17 --> Output Class Initialized
INFO - 2016-09-24 16:24:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:24:17 --> Input Class Initialized
INFO - 2016-09-24 16:24:17 --> Language Class Initialized
ERROR - 2016-09-24 16:24:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:24:47 --> Config Class Initialized
INFO - 2016-09-24 16:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:24:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:24:47 --> URI Class Initialized
INFO - 2016-09-24 16:24:47 --> Router Class Initialized
INFO - 2016-09-24 16:24:47 --> Output Class Initialized
INFO - 2016-09-24 16:24:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:24:47 --> Input Class Initialized
INFO - 2016-09-24 16:24:47 --> Language Class Initialized
ERROR - 2016-09-24 16:24:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:25:17 --> Config Class Initialized
INFO - 2016-09-24 16:25:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:25:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:25:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:25:17 --> URI Class Initialized
INFO - 2016-09-24 16:25:17 --> Router Class Initialized
INFO - 2016-09-24 16:25:17 --> Output Class Initialized
INFO - 2016-09-24 16:25:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:25:17 --> Input Class Initialized
INFO - 2016-09-24 16:25:17 --> Language Class Initialized
ERROR - 2016-09-24 16:25:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:25:47 --> Config Class Initialized
INFO - 2016-09-24 16:25:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:25:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:25:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:25:47 --> URI Class Initialized
INFO - 2016-09-24 16:25:47 --> Router Class Initialized
INFO - 2016-09-24 16:25:47 --> Output Class Initialized
INFO - 2016-09-24 16:25:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:25:47 --> Input Class Initialized
INFO - 2016-09-24 16:25:47 --> Language Class Initialized
ERROR - 2016-09-24 16:25:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:26:17 --> Config Class Initialized
INFO - 2016-09-24 16:26:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:26:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:26:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:26:17 --> URI Class Initialized
INFO - 2016-09-24 16:26:17 --> Router Class Initialized
INFO - 2016-09-24 16:26:17 --> Output Class Initialized
INFO - 2016-09-24 16:26:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:26:17 --> Input Class Initialized
INFO - 2016-09-24 16:26:17 --> Language Class Initialized
ERROR - 2016-09-24 16:26:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:26:47 --> Config Class Initialized
INFO - 2016-09-24 16:26:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:26:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:26:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:26:47 --> URI Class Initialized
INFO - 2016-09-24 16:26:47 --> Router Class Initialized
INFO - 2016-09-24 16:26:47 --> Output Class Initialized
INFO - 2016-09-24 16:26:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:26:47 --> Input Class Initialized
INFO - 2016-09-24 16:26:47 --> Language Class Initialized
ERROR - 2016-09-24 16:26:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:27:17 --> Config Class Initialized
INFO - 2016-09-24 16:27:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:27:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:27:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:27:17 --> URI Class Initialized
INFO - 2016-09-24 16:27:17 --> Router Class Initialized
INFO - 2016-09-24 16:27:17 --> Output Class Initialized
INFO - 2016-09-24 16:27:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:27:17 --> Input Class Initialized
INFO - 2016-09-24 16:27:17 --> Language Class Initialized
ERROR - 2016-09-24 16:27:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:27:47 --> Config Class Initialized
INFO - 2016-09-24 16:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:27:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:27:47 --> URI Class Initialized
INFO - 2016-09-24 16:27:47 --> Router Class Initialized
INFO - 2016-09-24 16:27:47 --> Output Class Initialized
INFO - 2016-09-24 16:27:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:27:47 --> Input Class Initialized
INFO - 2016-09-24 16:27:47 --> Language Class Initialized
ERROR - 2016-09-24 16:27:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:28:17 --> Config Class Initialized
INFO - 2016-09-24 16:28:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:28:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:28:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:28:17 --> URI Class Initialized
INFO - 2016-09-24 16:28:17 --> Router Class Initialized
INFO - 2016-09-24 16:28:17 --> Output Class Initialized
INFO - 2016-09-24 16:28:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:28:17 --> Input Class Initialized
INFO - 2016-09-24 16:28:17 --> Language Class Initialized
ERROR - 2016-09-24 16:28:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:28:47 --> Config Class Initialized
INFO - 2016-09-24 16:28:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:28:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:28:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:28:47 --> URI Class Initialized
INFO - 2016-09-24 16:28:47 --> Router Class Initialized
INFO - 2016-09-24 16:28:47 --> Output Class Initialized
INFO - 2016-09-24 16:28:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:28:47 --> Input Class Initialized
INFO - 2016-09-24 16:28:47 --> Language Class Initialized
ERROR - 2016-09-24 16:28:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:29:17 --> Config Class Initialized
INFO - 2016-09-24 16:29:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:29:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:29:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:29:17 --> URI Class Initialized
INFO - 2016-09-24 16:29:17 --> Router Class Initialized
INFO - 2016-09-24 16:29:17 --> Output Class Initialized
INFO - 2016-09-24 16:29:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:29:17 --> Input Class Initialized
INFO - 2016-09-24 16:29:17 --> Language Class Initialized
ERROR - 2016-09-24 16:29:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:29:47 --> Config Class Initialized
INFO - 2016-09-24 16:29:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:29:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:29:47 --> URI Class Initialized
INFO - 2016-09-24 16:29:47 --> Router Class Initialized
INFO - 2016-09-24 16:29:47 --> Output Class Initialized
INFO - 2016-09-24 16:29:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:29:47 --> Input Class Initialized
INFO - 2016-09-24 16:29:47 --> Language Class Initialized
ERROR - 2016-09-24 16:29:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:30:17 --> Config Class Initialized
INFO - 2016-09-24 16:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:30:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:30:17 --> URI Class Initialized
INFO - 2016-09-24 16:30:17 --> Router Class Initialized
INFO - 2016-09-24 16:30:17 --> Output Class Initialized
INFO - 2016-09-24 16:30:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:30:17 --> Input Class Initialized
INFO - 2016-09-24 16:30:17 --> Language Class Initialized
ERROR - 2016-09-24 16:30:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:30:47 --> Config Class Initialized
INFO - 2016-09-24 16:30:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:30:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:30:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:30:47 --> URI Class Initialized
INFO - 2016-09-24 16:30:47 --> Router Class Initialized
INFO - 2016-09-24 16:30:47 --> Output Class Initialized
INFO - 2016-09-24 16:30:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:30:47 --> Input Class Initialized
INFO - 2016-09-24 16:30:47 --> Language Class Initialized
ERROR - 2016-09-24 16:30:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:31:17 --> Config Class Initialized
INFO - 2016-09-24 16:31:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:31:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:31:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:31:17 --> URI Class Initialized
INFO - 2016-09-24 16:31:17 --> Router Class Initialized
INFO - 2016-09-24 16:31:17 --> Output Class Initialized
INFO - 2016-09-24 16:31:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:31:17 --> Input Class Initialized
INFO - 2016-09-24 16:31:17 --> Language Class Initialized
ERROR - 2016-09-24 16:31:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:31:47 --> Config Class Initialized
INFO - 2016-09-24 16:31:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:31:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:31:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:31:47 --> URI Class Initialized
INFO - 2016-09-24 16:31:47 --> Router Class Initialized
INFO - 2016-09-24 16:31:47 --> Output Class Initialized
INFO - 2016-09-24 16:31:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:31:47 --> Input Class Initialized
INFO - 2016-09-24 16:31:47 --> Language Class Initialized
ERROR - 2016-09-24 16:31:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:32:17 --> Config Class Initialized
INFO - 2016-09-24 16:32:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:32:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:32:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:32:17 --> URI Class Initialized
INFO - 2016-09-24 16:32:17 --> Router Class Initialized
INFO - 2016-09-24 16:32:17 --> Output Class Initialized
INFO - 2016-09-24 16:32:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:32:17 --> Input Class Initialized
INFO - 2016-09-24 16:32:17 --> Language Class Initialized
ERROR - 2016-09-24 16:32:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:32:47 --> Config Class Initialized
INFO - 2016-09-24 16:32:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:32:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:32:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:32:47 --> URI Class Initialized
INFO - 2016-09-24 16:32:47 --> Router Class Initialized
INFO - 2016-09-24 16:32:47 --> Output Class Initialized
INFO - 2016-09-24 16:32:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:32:47 --> Input Class Initialized
INFO - 2016-09-24 16:32:47 --> Language Class Initialized
ERROR - 2016-09-24 16:32:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:33:17 --> Config Class Initialized
INFO - 2016-09-24 16:33:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:33:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:33:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:33:17 --> URI Class Initialized
INFO - 2016-09-24 16:33:17 --> Router Class Initialized
INFO - 2016-09-24 16:33:17 --> Output Class Initialized
INFO - 2016-09-24 16:33:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:33:17 --> Input Class Initialized
INFO - 2016-09-24 16:33:17 --> Language Class Initialized
ERROR - 2016-09-24 16:33:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:33:47 --> Config Class Initialized
INFO - 2016-09-24 16:33:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:33:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:33:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:33:47 --> URI Class Initialized
INFO - 2016-09-24 16:33:47 --> Router Class Initialized
INFO - 2016-09-24 16:33:47 --> Output Class Initialized
INFO - 2016-09-24 16:33:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:33:47 --> Input Class Initialized
INFO - 2016-09-24 16:33:47 --> Language Class Initialized
ERROR - 2016-09-24 16:33:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:34:17 --> Config Class Initialized
INFO - 2016-09-24 16:34:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:34:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:34:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:34:17 --> URI Class Initialized
INFO - 2016-09-24 16:34:17 --> Router Class Initialized
INFO - 2016-09-24 16:34:17 --> Output Class Initialized
INFO - 2016-09-24 16:34:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:34:17 --> Input Class Initialized
INFO - 2016-09-24 16:34:17 --> Language Class Initialized
ERROR - 2016-09-24 16:34:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:34:47 --> Config Class Initialized
INFO - 2016-09-24 16:34:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:34:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:34:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:34:47 --> URI Class Initialized
INFO - 2016-09-24 16:34:47 --> Router Class Initialized
INFO - 2016-09-24 16:34:47 --> Output Class Initialized
INFO - 2016-09-24 16:34:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:34:47 --> Input Class Initialized
INFO - 2016-09-24 16:34:47 --> Language Class Initialized
ERROR - 2016-09-24 16:34:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:35:17 --> Config Class Initialized
INFO - 2016-09-24 16:35:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:35:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:35:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:35:17 --> URI Class Initialized
INFO - 2016-09-24 16:35:17 --> Router Class Initialized
INFO - 2016-09-24 16:35:17 --> Output Class Initialized
INFO - 2016-09-24 16:35:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:35:17 --> Input Class Initialized
INFO - 2016-09-24 16:35:17 --> Language Class Initialized
ERROR - 2016-09-24 16:35:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:35:47 --> Config Class Initialized
INFO - 2016-09-24 16:35:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:35:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:35:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:35:47 --> URI Class Initialized
INFO - 2016-09-24 16:35:47 --> Router Class Initialized
INFO - 2016-09-24 16:35:47 --> Output Class Initialized
INFO - 2016-09-24 16:35:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:35:47 --> Input Class Initialized
INFO - 2016-09-24 16:35:47 --> Language Class Initialized
ERROR - 2016-09-24 16:35:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:36:17 --> Config Class Initialized
INFO - 2016-09-24 16:36:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:36:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:36:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:36:17 --> URI Class Initialized
INFO - 2016-09-24 16:36:17 --> Router Class Initialized
INFO - 2016-09-24 16:36:17 --> Output Class Initialized
INFO - 2016-09-24 16:36:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:36:17 --> Input Class Initialized
INFO - 2016-09-24 16:36:17 --> Language Class Initialized
ERROR - 2016-09-24 16:36:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:36:47 --> Config Class Initialized
INFO - 2016-09-24 16:36:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:36:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:36:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:36:47 --> URI Class Initialized
INFO - 2016-09-24 16:36:47 --> Router Class Initialized
INFO - 2016-09-24 16:36:47 --> Output Class Initialized
INFO - 2016-09-24 16:36:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:36:47 --> Input Class Initialized
INFO - 2016-09-24 16:36:47 --> Language Class Initialized
ERROR - 2016-09-24 16:36:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:37:17 --> Config Class Initialized
INFO - 2016-09-24 16:37:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:37:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:37:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:37:17 --> URI Class Initialized
INFO - 2016-09-24 16:37:17 --> Router Class Initialized
INFO - 2016-09-24 16:37:17 --> Output Class Initialized
INFO - 2016-09-24 16:37:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:37:17 --> Input Class Initialized
INFO - 2016-09-24 16:37:17 --> Language Class Initialized
ERROR - 2016-09-24 16:37:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:37:47 --> Config Class Initialized
INFO - 2016-09-24 16:37:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:37:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:37:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:37:47 --> URI Class Initialized
INFO - 2016-09-24 16:37:47 --> Router Class Initialized
INFO - 2016-09-24 16:37:47 --> Output Class Initialized
INFO - 2016-09-24 16:37:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:37:47 --> Input Class Initialized
INFO - 2016-09-24 16:37:47 --> Language Class Initialized
ERROR - 2016-09-24 16:37:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:38:17 --> Config Class Initialized
INFO - 2016-09-24 16:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:38:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:38:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:38:17 --> URI Class Initialized
INFO - 2016-09-24 16:38:17 --> Router Class Initialized
INFO - 2016-09-24 16:38:17 --> Output Class Initialized
INFO - 2016-09-24 16:38:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:38:17 --> Input Class Initialized
INFO - 2016-09-24 16:38:17 --> Language Class Initialized
ERROR - 2016-09-24 16:38:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:38:47 --> Config Class Initialized
INFO - 2016-09-24 16:38:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:38:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:38:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:38:47 --> URI Class Initialized
INFO - 2016-09-24 16:38:47 --> Router Class Initialized
INFO - 2016-09-24 16:38:47 --> Output Class Initialized
INFO - 2016-09-24 16:38:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:38:47 --> Input Class Initialized
INFO - 2016-09-24 16:38:47 --> Language Class Initialized
ERROR - 2016-09-24 16:38:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:39:17 --> Config Class Initialized
INFO - 2016-09-24 16:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:39:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:39:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:39:17 --> URI Class Initialized
INFO - 2016-09-24 16:39:17 --> Router Class Initialized
INFO - 2016-09-24 16:39:17 --> Output Class Initialized
INFO - 2016-09-24 16:39:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:39:17 --> Input Class Initialized
INFO - 2016-09-24 16:39:17 --> Language Class Initialized
ERROR - 2016-09-24 16:39:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:39:47 --> Config Class Initialized
INFO - 2016-09-24 16:39:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:39:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:39:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:39:47 --> URI Class Initialized
INFO - 2016-09-24 16:39:47 --> Router Class Initialized
INFO - 2016-09-24 16:39:47 --> Output Class Initialized
INFO - 2016-09-24 16:39:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:39:47 --> Input Class Initialized
INFO - 2016-09-24 16:39:47 --> Language Class Initialized
ERROR - 2016-09-24 16:39:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:40:17 --> Config Class Initialized
INFO - 2016-09-24 16:40:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:40:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:40:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:40:17 --> URI Class Initialized
INFO - 2016-09-24 16:40:17 --> Router Class Initialized
INFO - 2016-09-24 16:40:17 --> Output Class Initialized
INFO - 2016-09-24 16:40:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:40:17 --> Input Class Initialized
INFO - 2016-09-24 16:40:17 --> Language Class Initialized
ERROR - 2016-09-24 16:40:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:40:47 --> Config Class Initialized
INFO - 2016-09-24 16:40:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:40:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:40:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:40:47 --> URI Class Initialized
INFO - 2016-09-24 16:40:47 --> Router Class Initialized
INFO - 2016-09-24 16:40:47 --> Output Class Initialized
INFO - 2016-09-24 16:40:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:40:47 --> Input Class Initialized
INFO - 2016-09-24 16:40:47 --> Language Class Initialized
ERROR - 2016-09-24 16:40:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:41:17 --> Config Class Initialized
INFO - 2016-09-24 16:41:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:41:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:41:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:41:17 --> URI Class Initialized
INFO - 2016-09-24 16:41:17 --> Router Class Initialized
INFO - 2016-09-24 16:41:17 --> Output Class Initialized
INFO - 2016-09-24 16:41:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:41:17 --> Input Class Initialized
INFO - 2016-09-24 16:41:17 --> Language Class Initialized
ERROR - 2016-09-24 16:41:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:41:47 --> Config Class Initialized
INFO - 2016-09-24 16:41:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:41:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:41:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:41:47 --> URI Class Initialized
INFO - 2016-09-24 16:41:47 --> Router Class Initialized
INFO - 2016-09-24 16:41:47 --> Output Class Initialized
INFO - 2016-09-24 16:41:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:41:47 --> Input Class Initialized
INFO - 2016-09-24 16:41:47 --> Language Class Initialized
ERROR - 2016-09-24 16:41:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:42:17 --> Config Class Initialized
INFO - 2016-09-24 16:42:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:42:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:42:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:42:17 --> URI Class Initialized
INFO - 2016-09-24 16:42:17 --> Router Class Initialized
INFO - 2016-09-24 16:42:17 --> Output Class Initialized
INFO - 2016-09-24 16:42:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:42:17 --> Input Class Initialized
INFO - 2016-09-24 16:42:17 --> Language Class Initialized
ERROR - 2016-09-24 16:42:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:42:47 --> Config Class Initialized
INFO - 2016-09-24 16:42:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:42:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:42:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:42:47 --> URI Class Initialized
INFO - 2016-09-24 16:42:47 --> Router Class Initialized
INFO - 2016-09-24 16:42:47 --> Output Class Initialized
INFO - 2016-09-24 16:42:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:42:47 --> Input Class Initialized
INFO - 2016-09-24 16:42:47 --> Language Class Initialized
ERROR - 2016-09-24 16:42:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:43:17 --> Config Class Initialized
INFO - 2016-09-24 16:43:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:43:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:43:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:43:17 --> URI Class Initialized
INFO - 2016-09-24 16:43:17 --> Router Class Initialized
INFO - 2016-09-24 16:43:17 --> Output Class Initialized
INFO - 2016-09-24 16:43:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:43:17 --> Input Class Initialized
INFO - 2016-09-24 16:43:17 --> Language Class Initialized
ERROR - 2016-09-24 16:43:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:43:47 --> Config Class Initialized
INFO - 2016-09-24 16:43:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:43:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:43:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:43:47 --> URI Class Initialized
INFO - 2016-09-24 16:43:47 --> Router Class Initialized
INFO - 2016-09-24 16:43:47 --> Output Class Initialized
INFO - 2016-09-24 16:43:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:43:47 --> Input Class Initialized
INFO - 2016-09-24 16:43:47 --> Language Class Initialized
ERROR - 2016-09-24 16:43:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:44:17 --> Config Class Initialized
INFO - 2016-09-24 16:44:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:44:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:44:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:44:17 --> URI Class Initialized
INFO - 2016-09-24 16:44:17 --> Router Class Initialized
INFO - 2016-09-24 16:44:17 --> Output Class Initialized
INFO - 2016-09-24 16:44:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:44:17 --> Input Class Initialized
INFO - 2016-09-24 16:44:17 --> Language Class Initialized
ERROR - 2016-09-24 16:44:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:44:47 --> Config Class Initialized
INFO - 2016-09-24 16:44:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:44:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:44:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:44:47 --> URI Class Initialized
INFO - 2016-09-24 16:44:47 --> Router Class Initialized
INFO - 2016-09-24 16:44:47 --> Output Class Initialized
INFO - 2016-09-24 16:44:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:44:47 --> Input Class Initialized
INFO - 2016-09-24 16:44:47 --> Language Class Initialized
ERROR - 2016-09-24 16:44:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:45:17 --> Config Class Initialized
INFO - 2016-09-24 16:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:45:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:45:17 --> URI Class Initialized
INFO - 2016-09-24 16:45:17 --> Router Class Initialized
INFO - 2016-09-24 16:45:17 --> Output Class Initialized
INFO - 2016-09-24 16:45:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:45:17 --> Input Class Initialized
INFO - 2016-09-24 16:45:17 --> Language Class Initialized
ERROR - 2016-09-24 16:45:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:45:47 --> Config Class Initialized
INFO - 2016-09-24 16:45:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:45:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:45:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:45:47 --> URI Class Initialized
INFO - 2016-09-24 16:45:47 --> Router Class Initialized
INFO - 2016-09-24 16:45:47 --> Output Class Initialized
INFO - 2016-09-24 16:45:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:45:47 --> Input Class Initialized
INFO - 2016-09-24 16:45:47 --> Language Class Initialized
ERROR - 2016-09-24 16:45:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:46:17 --> Config Class Initialized
INFO - 2016-09-24 16:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:46:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:46:17 --> URI Class Initialized
INFO - 2016-09-24 16:46:17 --> Router Class Initialized
INFO - 2016-09-24 16:46:17 --> Output Class Initialized
INFO - 2016-09-24 16:46:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:46:17 --> Input Class Initialized
INFO - 2016-09-24 16:46:17 --> Language Class Initialized
ERROR - 2016-09-24 16:46:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:46:47 --> Config Class Initialized
INFO - 2016-09-24 16:46:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:46:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:46:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:46:47 --> URI Class Initialized
INFO - 2016-09-24 16:46:47 --> Router Class Initialized
INFO - 2016-09-24 16:46:47 --> Output Class Initialized
INFO - 2016-09-24 16:46:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:46:47 --> Input Class Initialized
INFO - 2016-09-24 16:46:47 --> Language Class Initialized
ERROR - 2016-09-24 16:46:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:47:17 --> Config Class Initialized
INFO - 2016-09-24 16:47:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:47:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:47:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:47:17 --> URI Class Initialized
INFO - 2016-09-24 16:47:17 --> Router Class Initialized
INFO - 2016-09-24 16:47:17 --> Output Class Initialized
INFO - 2016-09-24 16:47:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:47:17 --> Input Class Initialized
INFO - 2016-09-24 16:47:17 --> Language Class Initialized
ERROR - 2016-09-24 16:47:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:47:47 --> Config Class Initialized
INFO - 2016-09-24 16:47:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:47:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:47:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:47:47 --> URI Class Initialized
INFO - 2016-09-24 16:47:47 --> Router Class Initialized
INFO - 2016-09-24 16:47:47 --> Output Class Initialized
INFO - 2016-09-24 16:47:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:47:47 --> Input Class Initialized
INFO - 2016-09-24 16:47:47 --> Language Class Initialized
ERROR - 2016-09-24 16:47:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:48:17 --> Config Class Initialized
INFO - 2016-09-24 16:48:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:48:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:48:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:48:17 --> URI Class Initialized
INFO - 2016-09-24 16:48:17 --> Router Class Initialized
INFO - 2016-09-24 16:48:17 --> Output Class Initialized
INFO - 2016-09-24 16:48:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:48:17 --> Input Class Initialized
INFO - 2016-09-24 16:48:17 --> Language Class Initialized
ERROR - 2016-09-24 16:48:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:48:47 --> Config Class Initialized
INFO - 2016-09-24 16:48:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:48:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:48:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:48:47 --> URI Class Initialized
INFO - 2016-09-24 16:48:47 --> Router Class Initialized
INFO - 2016-09-24 16:48:47 --> Output Class Initialized
INFO - 2016-09-24 16:48:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:48:47 --> Input Class Initialized
INFO - 2016-09-24 16:48:47 --> Language Class Initialized
ERROR - 2016-09-24 16:48:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:49:17 --> Config Class Initialized
INFO - 2016-09-24 16:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:49:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:49:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:49:17 --> URI Class Initialized
INFO - 2016-09-24 16:49:17 --> Router Class Initialized
INFO - 2016-09-24 16:49:17 --> Output Class Initialized
INFO - 2016-09-24 16:49:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:49:17 --> Input Class Initialized
INFO - 2016-09-24 16:49:17 --> Language Class Initialized
ERROR - 2016-09-24 16:49:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:49:47 --> Config Class Initialized
INFO - 2016-09-24 16:49:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:49:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:49:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:49:47 --> URI Class Initialized
INFO - 2016-09-24 16:49:47 --> Router Class Initialized
INFO - 2016-09-24 16:49:47 --> Output Class Initialized
INFO - 2016-09-24 16:49:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:49:47 --> Input Class Initialized
INFO - 2016-09-24 16:49:47 --> Language Class Initialized
ERROR - 2016-09-24 16:49:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:50:17 --> Config Class Initialized
INFO - 2016-09-24 16:50:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:50:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:50:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:50:17 --> URI Class Initialized
INFO - 2016-09-24 16:50:17 --> Router Class Initialized
INFO - 2016-09-24 16:50:17 --> Output Class Initialized
INFO - 2016-09-24 16:50:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:50:17 --> Input Class Initialized
INFO - 2016-09-24 16:50:17 --> Language Class Initialized
ERROR - 2016-09-24 16:50:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:50:47 --> Config Class Initialized
INFO - 2016-09-24 16:50:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:50:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:50:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:50:47 --> URI Class Initialized
INFO - 2016-09-24 16:50:47 --> Router Class Initialized
INFO - 2016-09-24 16:50:47 --> Output Class Initialized
INFO - 2016-09-24 16:50:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:50:47 --> Input Class Initialized
INFO - 2016-09-24 16:50:47 --> Language Class Initialized
ERROR - 2016-09-24 16:50:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:51:17 --> Config Class Initialized
INFO - 2016-09-24 16:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:51:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:51:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:51:17 --> URI Class Initialized
INFO - 2016-09-24 16:51:17 --> Router Class Initialized
INFO - 2016-09-24 16:51:17 --> Output Class Initialized
INFO - 2016-09-24 16:51:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:51:17 --> Input Class Initialized
INFO - 2016-09-24 16:51:17 --> Language Class Initialized
ERROR - 2016-09-24 16:51:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:51:47 --> Config Class Initialized
INFO - 2016-09-24 16:51:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:51:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:51:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:51:47 --> URI Class Initialized
INFO - 2016-09-24 16:51:47 --> Router Class Initialized
INFO - 2016-09-24 16:51:47 --> Output Class Initialized
INFO - 2016-09-24 16:51:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:51:47 --> Input Class Initialized
INFO - 2016-09-24 16:51:47 --> Language Class Initialized
ERROR - 2016-09-24 16:51:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:52:17 --> Config Class Initialized
INFO - 2016-09-24 16:52:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:52:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:52:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:52:17 --> URI Class Initialized
INFO - 2016-09-24 16:52:17 --> Router Class Initialized
INFO - 2016-09-24 16:52:17 --> Output Class Initialized
INFO - 2016-09-24 16:52:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:52:17 --> Input Class Initialized
INFO - 2016-09-24 16:52:17 --> Language Class Initialized
ERROR - 2016-09-24 16:52:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:52:47 --> Config Class Initialized
INFO - 2016-09-24 16:52:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:52:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:52:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:52:47 --> URI Class Initialized
INFO - 2016-09-24 16:52:47 --> Router Class Initialized
INFO - 2016-09-24 16:52:47 --> Output Class Initialized
INFO - 2016-09-24 16:52:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:52:47 --> Input Class Initialized
INFO - 2016-09-24 16:52:47 --> Language Class Initialized
ERROR - 2016-09-24 16:52:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:53:17 --> Config Class Initialized
INFO - 2016-09-24 16:53:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:53:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:53:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:53:17 --> URI Class Initialized
INFO - 2016-09-24 16:53:17 --> Router Class Initialized
INFO - 2016-09-24 16:53:17 --> Output Class Initialized
INFO - 2016-09-24 16:53:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:53:17 --> Input Class Initialized
INFO - 2016-09-24 16:53:17 --> Language Class Initialized
ERROR - 2016-09-24 16:53:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:53:47 --> Config Class Initialized
INFO - 2016-09-24 16:53:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:53:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:53:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:53:47 --> URI Class Initialized
INFO - 2016-09-24 16:53:47 --> Router Class Initialized
INFO - 2016-09-24 16:53:47 --> Output Class Initialized
INFO - 2016-09-24 16:53:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:53:47 --> Input Class Initialized
INFO - 2016-09-24 16:53:47 --> Language Class Initialized
ERROR - 2016-09-24 16:53:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:54:17 --> Config Class Initialized
INFO - 2016-09-24 16:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:54:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:54:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:54:17 --> URI Class Initialized
INFO - 2016-09-24 16:54:17 --> Router Class Initialized
INFO - 2016-09-24 16:54:17 --> Output Class Initialized
INFO - 2016-09-24 16:54:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:54:17 --> Input Class Initialized
INFO - 2016-09-24 16:54:17 --> Language Class Initialized
ERROR - 2016-09-24 16:54:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:54:47 --> Config Class Initialized
INFO - 2016-09-24 16:54:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:54:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:54:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:54:47 --> URI Class Initialized
INFO - 2016-09-24 16:54:47 --> Router Class Initialized
INFO - 2016-09-24 16:54:47 --> Output Class Initialized
INFO - 2016-09-24 16:54:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:54:47 --> Input Class Initialized
INFO - 2016-09-24 16:54:47 --> Language Class Initialized
ERROR - 2016-09-24 16:54:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:55:17 --> Config Class Initialized
INFO - 2016-09-24 16:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:55:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:55:17 --> URI Class Initialized
INFO - 2016-09-24 16:55:17 --> Router Class Initialized
INFO - 2016-09-24 16:55:17 --> Output Class Initialized
INFO - 2016-09-24 16:55:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:55:17 --> Input Class Initialized
INFO - 2016-09-24 16:55:17 --> Language Class Initialized
ERROR - 2016-09-24 16:55:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:55:47 --> Config Class Initialized
INFO - 2016-09-24 16:55:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:55:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:55:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:55:47 --> URI Class Initialized
INFO - 2016-09-24 16:55:47 --> Router Class Initialized
INFO - 2016-09-24 16:55:47 --> Output Class Initialized
INFO - 2016-09-24 16:55:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:55:47 --> Input Class Initialized
INFO - 2016-09-24 16:55:47 --> Language Class Initialized
ERROR - 2016-09-24 16:55:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:56:17 --> Config Class Initialized
INFO - 2016-09-24 16:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:56:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:56:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:56:17 --> URI Class Initialized
INFO - 2016-09-24 16:56:17 --> Router Class Initialized
INFO - 2016-09-24 16:56:17 --> Output Class Initialized
INFO - 2016-09-24 16:56:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:56:17 --> Input Class Initialized
INFO - 2016-09-24 16:56:17 --> Language Class Initialized
ERROR - 2016-09-24 16:56:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:56:47 --> Config Class Initialized
INFO - 2016-09-24 16:56:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:56:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:56:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:56:47 --> URI Class Initialized
INFO - 2016-09-24 16:56:47 --> Router Class Initialized
INFO - 2016-09-24 16:56:47 --> Output Class Initialized
INFO - 2016-09-24 16:56:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:56:47 --> Input Class Initialized
INFO - 2016-09-24 16:56:47 --> Language Class Initialized
ERROR - 2016-09-24 16:56:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:57:17 --> Config Class Initialized
INFO - 2016-09-24 16:57:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:57:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:57:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:57:17 --> URI Class Initialized
INFO - 2016-09-24 16:57:17 --> Router Class Initialized
INFO - 2016-09-24 16:57:17 --> Output Class Initialized
INFO - 2016-09-24 16:57:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:57:17 --> Input Class Initialized
INFO - 2016-09-24 16:57:17 --> Language Class Initialized
ERROR - 2016-09-24 16:57:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:57:47 --> Config Class Initialized
INFO - 2016-09-24 16:57:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:57:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:57:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:57:47 --> URI Class Initialized
INFO - 2016-09-24 16:57:47 --> Router Class Initialized
INFO - 2016-09-24 16:57:47 --> Output Class Initialized
INFO - 2016-09-24 16:57:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:57:47 --> Input Class Initialized
INFO - 2016-09-24 16:57:47 --> Language Class Initialized
ERROR - 2016-09-24 16:57:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:58:17 --> Config Class Initialized
INFO - 2016-09-24 16:58:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:58:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:58:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:58:17 --> URI Class Initialized
INFO - 2016-09-24 16:58:17 --> Router Class Initialized
INFO - 2016-09-24 16:58:17 --> Output Class Initialized
INFO - 2016-09-24 16:58:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:58:17 --> Input Class Initialized
INFO - 2016-09-24 16:58:17 --> Language Class Initialized
ERROR - 2016-09-24 16:58:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:58:47 --> Config Class Initialized
INFO - 2016-09-24 16:58:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:58:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:58:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:58:47 --> URI Class Initialized
INFO - 2016-09-24 16:58:47 --> Router Class Initialized
INFO - 2016-09-24 16:58:47 --> Output Class Initialized
INFO - 2016-09-24 16:58:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:58:47 --> Input Class Initialized
INFO - 2016-09-24 16:58:47 --> Language Class Initialized
ERROR - 2016-09-24 16:58:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:59:17 --> Config Class Initialized
INFO - 2016-09-24 16:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:59:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:59:17 --> Utf8 Class Initialized
INFO - 2016-09-24 16:59:17 --> URI Class Initialized
INFO - 2016-09-24 16:59:17 --> Router Class Initialized
INFO - 2016-09-24 16:59:17 --> Output Class Initialized
INFO - 2016-09-24 16:59:17 --> Security Class Initialized
DEBUG - 2016-09-24 16:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:59:17 --> Input Class Initialized
INFO - 2016-09-24 16:59:17 --> Language Class Initialized
ERROR - 2016-09-24 16:59:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 16:59:47 --> Config Class Initialized
INFO - 2016-09-24 16:59:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 16:59:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 16:59:47 --> Utf8 Class Initialized
INFO - 2016-09-24 16:59:47 --> URI Class Initialized
INFO - 2016-09-24 16:59:47 --> Router Class Initialized
INFO - 2016-09-24 16:59:47 --> Output Class Initialized
INFO - 2016-09-24 16:59:47 --> Security Class Initialized
DEBUG - 2016-09-24 16:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 16:59:47 --> Input Class Initialized
INFO - 2016-09-24 16:59:47 --> Language Class Initialized
ERROR - 2016-09-24 16:59:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:00:17 --> Config Class Initialized
INFO - 2016-09-24 17:00:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:00:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:00:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:00:17 --> URI Class Initialized
INFO - 2016-09-24 17:00:17 --> Router Class Initialized
INFO - 2016-09-24 17:00:17 --> Output Class Initialized
INFO - 2016-09-24 17:00:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:00:17 --> Input Class Initialized
INFO - 2016-09-24 17:00:17 --> Language Class Initialized
ERROR - 2016-09-24 17:00:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:00:47 --> Config Class Initialized
INFO - 2016-09-24 17:00:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:00:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:00:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:00:47 --> URI Class Initialized
INFO - 2016-09-24 17:00:47 --> Router Class Initialized
INFO - 2016-09-24 17:00:47 --> Output Class Initialized
INFO - 2016-09-24 17:00:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:00:47 --> Input Class Initialized
INFO - 2016-09-24 17:00:47 --> Language Class Initialized
ERROR - 2016-09-24 17:00:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:01:17 --> Config Class Initialized
INFO - 2016-09-24 17:01:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:01:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:01:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:01:17 --> URI Class Initialized
INFO - 2016-09-24 17:01:17 --> Router Class Initialized
INFO - 2016-09-24 17:01:17 --> Output Class Initialized
INFO - 2016-09-24 17:01:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:01:17 --> Input Class Initialized
INFO - 2016-09-24 17:01:17 --> Language Class Initialized
ERROR - 2016-09-24 17:01:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:01:47 --> Config Class Initialized
INFO - 2016-09-24 17:01:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:01:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:01:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:01:47 --> URI Class Initialized
INFO - 2016-09-24 17:01:47 --> Router Class Initialized
INFO - 2016-09-24 17:01:47 --> Output Class Initialized
INFO - 2016-09-24 17:01:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:01:47 --> Input Class Initialized
INFO - 2016-09-24 17:01:47 --> Language Class Initialized
ERROR - 2016-09-24 17:01:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:02:17 --> Config Class Initialized
INFO - 2016-09-24 17:02:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:02:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:02:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:02:17 --> URI Class Initialized
INFO - 2016-09-24 17:02:17 --> Router Class Initialized
INFO - 2016-09-24 17:02:17 --> Output Class Initialized
INFO - 2016-09-24 17:02:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:02:17 --> Input Class Initialized
INFO - 2016-09-24 17:02:17 --> Language Class Initialized
ERROR - 2016-09-24 17:02:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:02:47 --> Config Class Initialized
INFO - 2016-09-24 17:02:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:02:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:02:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:02:47 --> URI Class Initialized
INFO - 2016-09-24 17:02:47 --> Router Class Initialized
INFO - 2016-09-24 17:02:47 --> Output Class Initialized
INFO - 2016-09-24 17:02:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:02:47 --> Input Class Initialized
INFO - 2016-09-24 17:02:47 --> Language Class Initialized
ERROR - 2016-09-24 17:02:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:03:17 --> Config Class Initialized
INFO - 2016-09-24 17:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:03:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:03:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:03:17 --> URI Class Initialized
INFO - 2016-09-24 17:03:17 --> Router Class Initialized
INFO - 2016-09-24 17:03:17 --> Output Class Initialized
INFO - 2016-09-24 17:03:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:03:17 --> Input Class Initialized
INFO - 2016-09-24 17:03:17 --> Language Class Initialized
ERROR - 2016-09-24 17:03:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:03:47 --> Config Class Initialized
INFO - 2016-09-24 17:03:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:03:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:03:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:03:47 --> URI Class Initialized
INFO - 2016-09-24 17:03:47 --> Router Class Initialized
INFO - 2016-09-24 17:03:47 --> Output Class Initialized
INFO - 2016-09-24 17:03:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:03:47 --> Input Class Initialized
INFO - 2016-09-24 17:03:47 --> Language Class Initialized
ERROR - 2016-09-24 17:03:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:04:17 --> Config Class Initialized
INFO - 2016-09-24 17:04:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:04:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:04:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:04:17 --> URI Class Initialized
INFO - 2016-09-24 17:04:17 --> Router Class Initialized
INFO - 2016-09-24 17:04:17 --> Output Class Initialized
INFO - 2016-09-24 17:04:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:04:17 --> Input Class Initialized
INFO - 2016-09-24 17:04:17 --> Language Class Initialized
ERROR - 2016-09-24 17:04:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:04:47 --> Config Class Initialized
INFO - 2016-09-24 17:04:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:04:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:04:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:04:47 --> URI Class Initialized
INFO - 2016-09-24 17:04:47 --> Router Class Initialized
INFO - 2016-09-24 17:04:47 --> Output Class Initialized
INFO - 2016-09-24 17:04:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:04:47 --> Input Class Initialized
INFO - 2016-09-24 17:04:47 --> Language Class Initialized
ERROR - 2016-09-24 17:04:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:05:17 --> Config Class Initialized
INFO - 2016-09-24 17:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:05:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:05:17 --> URI Class Initialized
INFO - 2016-09-24 17:05:17 --> Router Class Initialized
INFO - 2016-09-24 17:05:17 --> Output Class Initialized
INFO - 2016-09-24 17:05:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:05:17 --> Input Class Initialized
INFO - 2016-09-24 17:05:17 --> Language Class Initialized
ERROR - 2016-09-24 17:05:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:05:47 --> Config Class Initialized
INFO - 2016-09-24 17:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:05:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:05:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:05:47 --> URI Class Initialized
INFO - 2016-09-24 17:05:47 --> Router Class Initialized
INFO - 2016-09-24 17:05:47 --> Output Class Initialized
INFO - 2016-09-24 17:05:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:05:47 --> Input Class Initialized
INFO - 2016-09-24 17:05:47 --> Language Class Initialized
ERROR - 2016-09-24 17:05:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:06:17 --> Config Class Initialized
INFO - 2016-09-24 17:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:06:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:06:17 --> URI Class Initialized
INFO - 2016-09-24 17:06:17 --> Router Class Initialized
INFO - 2016-09-24 17:06:17 --> Output Class Initialized
INFO - 2016-09-24 17:06:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:06:17 --> Input Class Initialized
INFO - 2016-09-24 17:06:17 --> Language Class Initialized
ERROR - 2016-09-24 17:06:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:06:47 --> Config Class Initialized
INFO - 2016-09-24 17:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:06:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:06:47 --> URI Class Initialized
INFO - 2016-09-24 17:06:47 --> Router Class Initialized
INFO - 2016-09-24 17:06:47 --> Output Class Initialized
INFO - 2016-09-24 17:06:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:06:47 --> Input Class Initialized
INFO - 2016-09-24 17:06:47 --> Language Class Initialized
ERROR - 2016-09-24 17:06:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:07:17 --> Config Class Initialized
INFO - 2016-09-24 17:07:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:07:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:07:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:07:17 --> URI Class Initialized
INFO - 2016-09-24 17:07:17 --> Router Class Initialized
INFO - 2016-09-24 17:07:17 --> Output Class Initialized
INFO - 2016-09-24 17:07:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:07:17 --> Input Class Initialized
INFO - 2016-09-24 17:07:17 --> Language Class Initialized
ERROR - 2016-09-24 17:07:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:07:47 --> Config Class Initialized
INFO - 2016-09-24 17:07:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:07:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:07:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:07:47 --> URI Class Initialized
INFO - 2016-09-24 17:07:47 --> Router Class Initialized
INFO - 2016-09-24 17:07:47 --> Output Class Initialized
INFO - 2016-09-24 17:07:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:07:47 --> Input Class Initialized
INFO - 2016-09-24 17:07:47 --> Language Class Initialized
ERROR - 2016-09-24 17:07:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:08:17 --> Config Class Initialized
INFO - 2016-09-24 17:08:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:08:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:08:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:08:17 --> URI Class Initialized
INFO - 2016-09-24 17:08:17 --> Router Class Initialized
INFO - 2016-09-24 17:08:17 --> Output Class Initialized
INFO - 2016-09-24 17:08:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:08:17 --> Input Class Initialized
INFO - 2016-09-24 17:08:17 --> Language Class Initialized
ERROR - 2016-09-24 17:08:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:08:47 --> Config Class Initialized
INFO - 2016-09-24 17:08:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:08:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:08:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:08:47 --> URI Class Initialized
INFO - 2016-09-24 17:08:47 --> Router Class Initialized
INFO - 2016-09-24 17:08:47 --> Output Class Initialized
INFO - 2016-09-24 17:08:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:08:47 --> Input Class Initialized
INFO - 2016-09-24 17:08:47 --> Language Class Initialized
ERROR - 2016-09-24 17:08:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:09:17 --> Config Class Initialized
INFO - 2016-09-24 17:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:09:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:09:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:09:17 --> URI Class Initialized
INFO - 2016-09-24 17:09:17 --> Router Class Initialized
INFO - 2016-09-24 17:09:17 --> Output Class Initialized
INFO - 2016-09-24 17:09:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:09:17 --> Input Class Initialized
INFO - 2016-09-24 17:09:17 --> Language Class Initialized
ERROR - 2016-09-24 17:09:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:09:47 --> Config Class Initialized
INFO - 2016-09-24 17:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:09:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:09:47 --> URI Class Initialized
INFO - 2016-09-24 17:09:47 --> Router Class Initialized
INFO - 2016-09-24 17:09:47 --> Output Class Initialized
INFO - 2016-09-24 17:09:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:09:47 --> Input Class Initialized
INFO - 2016-09-24 17:09:47 --> Language Class Initialized
ERROR - 2016-09-24 17:09:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:10:17 --> Config Class Initialized
INFO - 2016-09-24 17:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:10:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:10:17 --> URI Class Initialized
INFO - 2016-09-24 17:10:17 --> Router Class Initialized
INFO - 2016-09-24 17:10:17 --> Output Class Initialized
INFO - 2016-09-24 17:10:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:10:17 --> Input Class Initialized
INFO - 2016-09-24 17:10:17 --> Language Class Initialized
ERROR - 2016-09-24 17:10:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:10:47 --> Config Class Initialized
INFO - 2016-09-24 17:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:10:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:10:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:10:47 --> URI Class Initialized
INFO - 2016-09-24 17:10:47 --> Router Class Initialized
INFO - 2016-09-24 17:10:47 --> Output Class Initialized
INFO - 2016-09-24 17:10:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:10:47 --> Input Class Initialized
INFO - 2016-09-24 17:10:47 --> Language Class Initialized
ERROR - 2016-09-24 17:10:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:11:17 --> Config Class Initialized
INFO - 2016-09-24 17:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:11:17 --> URI Class Initialized
INFO - 2016-09-24 17:11:17 --> Router Class Initialized
INFO - 2016-09-24 17:11:17 --> Output Class Initialized
INFO - 2016-09-24 17:11:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:11:17 --> Input Class Initialized
INFO - 2016-09-24 17:11:17 --> Language Class Initialized
ERROR - 2016-09-24 17:11:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:11:47 --> Config Class Initialized
INFO - 2016-09-24 17:11:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:11:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:11:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:11:47 --> URI Class Initialized
INFO - 2016-09-24 17:11:47 --> Router Class Initialized
INFO - 2016-09-24 17:11:47 --> Output Class Initialized
INFO - 2016-09-24 17:11:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:11:47 --> Input Class Initialized
INFO - 2016-09-24 17:11:47 --> Language Class Initialized
ERROR - 2016-09-24 17:11:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:12:17 --> Config Class Initialized
INFO - 2016-09-24 17:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:12:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:12:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:12:17 --> URI Class Initialized
INFO - 2016-09-24 17:12:17 --> Router Class Initialized
INFO - 2016-09-24 17:12:17 --> Output Class Initialized
INFO - 2016-09-24 17:12:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:12:17 --> Input Class Initialized
INFO - 2016-09-24 17:12:17 --> Language Class Initialized
ERROR - 2016-09-24 17:12:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:12:47 --> Config Class Initialized
INFO - 2016-09-24 17:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:12:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:12:47 --> URI Class Initialized
INFO - 2016-09-24 17:12:47 --> Router Class Initialized
INFO - 2016-09-24 17:12:47 --> Output Class Initialized
INFO - 2016-09-24 17:12:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:12:47 --> Input Class Initialized
INFO - 2016-09-24 17:12:47 --> Language Class Initialized
ERROR - 2016-09-24 17:12:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:13:17 --> Config Class Initialized
INFO - 2016-09-24 17:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:13:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:13:17 --> URI Class Initialized
INFO - 2016-09-24 17:13:17 --> Router Class Initialized
INFO - 2016-09-24 17:13:17 --> Output Class Initialized
INFO - 2016-09-24 17:13:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:13:17 --> Input Class Initialized
INFO - 2016-09-24 17:13:17 --> Language Class Initialized
ERROR - 2016-09-24 17:13:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:13:47 --> Config Class Initialized
INFO - 2016-09-24 17:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:13:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:13:47 --> URI Class Initialized
INFO - 2016-09-24 17:13:47 --> Router Class Initialized
INFO - 2016-09-24 17:13:47 --> Output Class Initialized
INFO - 2016-09-24 17:13:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:13:47 --> Input Class Initialized
INFO - 2016-09-24 17:13:47 --> Language Class Initialized
ERROR - 2016-09-24 17:13:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:14:17 --> Config Class Initialized
INFO - 2016-09-24 17:14:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:14:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:14:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:14:17 --> URI Class Initialized
INFO - 2016-09-24 17:14:17 --> Router Class Initialized
INFO - 2016-09-24 17:14:17 --> Output Class Initialized
INFO - 2016-09-24 17:14:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:14:17 --> Input Class Initialized
INFO - 2016-09-24 17:14:17 --> Language Class Initialized
ERROR - 2016-09-24 17:14:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:14:47 --> Config Class Initialized
INFO - 2016-09-24 17:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:14:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:14:47 --> URI Class Initialized
INFO - 2016-09-24 17:14:47 --> Router Class Initialized
INFO - 2016-09-24 17:14:47 --> Output Class Initialized
INFO - 2016-09-24 17:14:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:14:47 --> Input Class Initialized
INFO - 2016-09-24 17:14:47 --> Language Class Initialized
ERROR - 2016-09-24 17:14:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:15:17 --> Config Class Initialized
INFO - 2016-09-24 17:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:15:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:15:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:15:17 --> URI Class Initialized
INFO - 2016-09-24 17:15:17 --> Router Class Initialized
INFO - 2016-09-24 17:15:17 --> Output Class Initialized
INFO - 2016-09-24 17:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:15:17 --> Input Class Initialized
INFO - 2016-09-24 17:15:17 --> Language Class Initialized
ERROR - 2016-09-24 17:15:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:15:47 --> Config Class Initialized
INFO - 2016-09-24 17:15:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:15:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:15:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:15:47 --> URI Class Initialized
INFO - 2016-09-24 17:15:47 --> Router Class Initialized
INFO - 2016-09-24 17:15:47 --> Output Class Initialized
INFO - 2016-09-24 17:15:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:15:47 --> Input Class Initialized
INFO - 2016-09-24 17:15:47 --> Language Class Initialized
ERROR - 2016-09-24 17:15:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:16:17 --> Config Class Initialized
INFO - 2016-09-24 17:16:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:16:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:16:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:16:17 --> URI Class Initialized
INFO - 2016-09-24 17:16:17 --> Router Class Initialized
INFO - 2016-09-24 17:16:17 --> Output Class Initialized
INFO - 2016-09-24 17:16:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:16:17 --> Input Class Initialized
INFO - 2016-09-24 17:16:17 --> Language Class Initialized
ERROR - 2016-09-24 17:16:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:16:47 --> Config Class Initialized
INFO - 2016-09-24 17:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:16:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:16:47 --> URI Class Initialized
INFO - 2016-09-24 17:16:47 --> Router Class Initialized
INFO - 2016-09-24 17:16:47 --> Output Class Initialized
INFO - 2016-09-24 17:16:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:16:47 --> Input Class Initialized
INFO - 2016-09-24 17:16:47 --> Language Class Initialized
ERROR - 2016-09-24 17:16:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:17:17 --> Config Class Initialized
INFO - 2016-09-24 17:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:17:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:17:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:17:17 --> URI Class Initialized
INFO - 2016-09-24 17:17:17 --> Router Class Initialized
INFO - 2016-09-24 17:17:17 --> Output Class Initialized
INFO - 2016-09-24 17:17:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:17:17 --> Input Class Initialized
INFO - 2016-09-24 17:17:17 --> Language Class Initialized
ERROR - 2016-09-24 17:17:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:17:47 --> Config Class Initialized
INFO - 2016-09-24 17:17:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:17:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:17:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:17:47 --> URI Class Initialized
INFO - 2016-09-24 17:17:47 --> Router Class Initialized
INFO - 2016-09-24 17:17:47 --> Output Class Initialized
INFO - 2016-09-24 17:17:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:17:47 --> Input Class Initialized
INFO - 2016-09-24 17:17:47 --> Language Class Initialized
ERROR - 2016-09-24 17:17:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:18:17 --> Config Class Initialized
INFO - 2016-09-24 17:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:18:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:18:17 --> URI Class Initialized
INFO - 2016-09-24 17:18:17 --> Router Class Initialized
INFO - 2016-09-24 17:18:17 --> Output Class Initialized
INFO - 2016-09-24 17:18:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:18:17 --> Input Class Initialized
INFO - 2016-09-24 17:18:17 --> Language Class Initialized
ERROR - 2016-09-24 17:18:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:18:47 --> Config Class Initialized
INFO - 2016-09-24 17:18:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:18:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:18:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:18:47 --> URI Class Initialized
INFO - 2016-09-24 17:18:47 --> Router Class Initialized
INFO - 2016-09-24 17:18:47 --> Output Class Initialized
INFO - 2016-09-24 17:18:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:18:47 --> Input Class Initialized
INFO - 2016-09-24 17:18:47 --> Language Class Initialized
ERROR - 2016-09-24 17:18:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:19:17 --> Config Class Initialized
INFO - 2016-09-24 17:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:19:17 --> URI Class Initialized
INFO - 2016-09-24 17:19:17 --> Router Class Initialized
INFO - 2016-09-24 17:19:17 --> Output Class Initialized
INFO - 2016-09-24 17:19:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:19:17 --> Input Class Initialized
INFO - 2016-09-24 17:19:17 --> Language Class Initialized
ERROR - 2016-09-24 17:19:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:19:47 --> Config Class Initialized
INFO - 2016-09-24 17:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:19:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:19:47 --> URI Class Initialized
INFO - 2016-09-24 17:19:47 --> Router Class Initialized
INFO - 2016-09-24 17:19:47 --> Output Class Initialized
INFO - 2016-09-24 17:19:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:19:47 --> Input Class Initialized
INFO - 2016-09-24 17:19:47 --> Language Class Initialized
ERROR - 2016-09-24 17:19:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:20:17 --> Config Class Initialized
INFO - 2016-09-24 17:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:20:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:20:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:20:17 --> URI Class Initialized
INFO - 2016-09-24 17:20:17 --> Router Class Initialized
INFO - 2016-09-24 17:20:17 --> Output Class Initialized
INFO - 2016-09-24 17:20:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:20:17 --> Input Class Initialized
INFO - 2016-09-24 17:20:17 --> Language Class Initialized
ERROR - 2016-09-24 17:20:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:20:47 --> Config Class Initialized
INFO - 2016-09-24 17:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:20:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:20:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:20:47 --> URI Class Initialized
INFO - 2016-09-24 17:20:47 --> Router Class Initialized
INFO - 2016-09-24 17:20:47 --> Output Class Initialized
INFO - 2016-09-24 17:20:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:20:47 --> Input Class Initialized
INFO - 2016-09-24 17:20:47 --> Language Class Initialized
ERROR - 2016-09-24 17:20:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:21:17 --> Config Class Initialized
INFO - 2016-09-24 17:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:21:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:21:17 --> URI Class Initialized
INFO - 2016-09-24 17:21:17 --> Router Class Initialized
INFO - 2016-09-24 17:21:17 --> Output Class Initialized
INFO - 2016-09-24 17:21:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:21:17 --> Input Class Initialized
INFO - 2016-09-24 17:21:17 --> Language Class Initialized
ERROR - 2016-09-24 17:21:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:21:47 --> Config Class Initialized
INFO - 2016-09-24 17:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:21:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:21:47 --> URI Class Initialized
INFO - 2016-09-24 17:21:47 --> Router Class Initialized
INFO - 2016-09-24 17:21:47 --> Output Class Initialized
INFO - 2016-09-24 17:21:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:21:47 --> Input Class Initialized
INFO - 2016-09-24 17:21:47 --> Language Class Initialized
ERROR - 2016-09-24 17:21:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:22:17 --> Config Class Initialized
INFO - 2016-09-24 17:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:22:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:22:17 --> URI Class Initialized
INFO - 2016-09-24 17:22:17 --> Router Class Initialized
INFO - 2016-09-24 17:22:17 --> Output Class Initialized
INFO - 2016-09-24 17:22:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:22:17 --> Input Class Initialized
INFO - 2016-09-24 17:22:17 --> Language Class Initialized
ERROR - 2016-09-24 17:22:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:22:47 --> Config Class Initialized
INFO - 2016-09-24 17:22:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:22:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:22:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:22:47 --> URI Class Initialized
INFO - 2016-09-24 17:22:47 --> Router Class Initialized
INFO - 2016-09-24 17:22:47 --> Output Class Initialized
INFO - 2016-09-24 17:22:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:22:47 --> Input Class Initialized
INFO - 2016-09-24 17:22:47 --> Language Class Initialized
ERROR - 2016-09-24 17:22:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:23:17 --> Config Class Initialized
INFO - 2016-09-24 17:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:23:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:23:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:23:17 --> URI Class Initialized
INFO - 2016-09-24 17:23:17 --> Router Class Initialized
INFO - 2016-09-24 17:23:17 --> Output Class Initialized
INFO - 2016-09-24 17:23:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:23:17 --> Input Class Initialized
INFO - 2016-09-24 17:23:17 --> Language Class Initialized
ERROR - 2016-09-24 17:23:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:23:47 --> Config Class Initialized
INFO - 2016-09-24 17:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:23:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:23:47 --> URI Class Initialized
INFO - 2016-09-24 17:23:47 --> Router Class Initialized
INFO - 2016-09-24 17:23:47 --> Output Class Initialized
INFO - 2016-09-24 17:23:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:23:47 --> Input Class Initialized
INFO - 2016-09-24 17:23:47 --> Language Class Initialized
ERROR - 2016-09-24 17:23:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:24:17 --> Config Class Initialized
INFO - 2016-09-24 17:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:24:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:24:17 --> URI Class Initialized
INFO - 2016-09-24 17:24:17 --> Router Class Initialized
INFO - 2016-09-24 17:24:17 --> Output Class Initialized
INFO - 2016-09-24 17:24:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:24:17 --> Input Class Initialized
INFO - 2016-09-24 17:24:17 --> Language Class Initialized
ERROR - 2016-09-24 17:24:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:24:47 --> Config Class Initialized
INFO - 2016-09-24 17:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:24:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:24:47 --> URI Class Initialized
INFO - 2016-09-24 17:24:47 --> Router Class Initialized
INFO - 2016-09-24 17:24:47 --> Output Class Initialized
INFO - 2016-09-24 17:24:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:24:47 --> Input Class Initialized
INFO - 2016-09-24 17:24:47 --> Language Class Initialized
ERROR - 2016-09-24 17:24:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:25:17 --> Config Class Initialized
INFO - 2016-09-24 17:25:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:25:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:25:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:25:17 --> URI Class Initialized
INFO - 2016-09-24 17:25:17 --> Router Class Initialized
INFO - 2016-09-24 17:25:17 --> Output Class Initialized
INFO - 2016-09-24 17:25:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:25:17 --> Input Class Initialized
INFO - 2016-09-24 17:25:17 --> Language Class Initialized
ERROR - 2016-09-24 17:25:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:25:47 --> Config Class Initialized
INFO - 2016-09-24 17:25:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:25:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:25:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:25:47 --> URI Class Initialized
INFO - 2016-09-24 17:25:47 --> Router Class Initialized
INFO - 2016-09-24 17:25:47 --> Output Class Initialized
INFO - 2016-09-24 17:25:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:25:47 --> Input Class Initialized
INFO - 2016-09-24 17:25:47 --> Language Class Initialized
ERROR - 2016-09-24 17:25:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:26:17 --> Config Class Initialized
INFO - 2016-09-24 17:26:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:26:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:26:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:26:17 --> URI Class Initialized
INFO - 2016-09-24 17:26:17 --> Router Class Initialized
INFO - 2016-09-24 17:26:17 --> Output Class Initialized
INFO - 2016-09-24 17:26:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:26:17 --> Input Class Initialized
INFO - 2016-09-24 17:26:17 --> Language Class Initialized
ERROR - 2016-09-24 17:26:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:26:47 --> Config Class Initialized
INFO - 2016-09-24 17:26:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:26:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:26:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:26:47 --> URI Class Initialized
INFO - 2016-09-24 17:26:47 --> Router Class Initialized
INFO - 2016-09-24 17:26:47 --> Output Class Initialized
INFO - 2016-09-24 17:26:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:26:47 --> Input Class Initialized
INFO - 2016-09-24 17:26:47 --> Language Class Initialized
ERROR - 2016-09-24 17:26:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:27:17 --> Config Class Initialized
INFO - 2016-09-24 17:27:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:27:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:27:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:27:17 --> URI Class Initialized
INFO - 2016-09-24 17:27:17 --> Router Class Initialized
INFO - 2016-09-24 17:27:17 --> Output Class Initialized
INFO - 2016-09-24 17:27:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:27:17 --> Input Class Initialized
INFO - 2016-09-24 17:27:17 --> Language Class Initialized
ERROR - 2016-09-24 17:27:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:27:47 --> Config Class Initialized
INFO - 2016-09-24 17:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:27:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:27:47 --> URI Class Initialized
INFO - 2016-09-24 17:27:47 --> Router Class Initialized
INFO - 2016-09-24 17:27:47 --> Output Class Initialized
INFO - 2016-09-24 17:27:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:27:47 --> Input Class Initialized
INFO - 2016-09-24 17:27:47 --> Language Class Initialized
ERROR - 2016-09-24 17:27:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:28:17 --> Config Class Initialized
INFO - 2016-09-24 17:28:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:28:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:28:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:28:17 --> URI Class Initialized
INFO - 2016-09-24 17:28:17 --> Router Class Initialized
INFO - 2016-09-24 17:28:17 --> Output Class Initialized
INFO - 2016-09-24 17:28:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:28:17 --> Input Class Initialized
INFO - 2016-09-24 17:28:17 --> Language Class Initialized
ERROR - 2016-09-24 17:28:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:28:47 --> Config Class Initialized
INFO - 2016-09-24 17:28:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:28:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:28:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:28:47 --> URI Class Initialized
INFO - 2016-09-24 17:28:47 --> Router Class Initialized
INFO - 2016-09-24 17:28:47 --> Output Class Initialized
INFO - 2016-09-24 17:28:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:28:47 --> Input Class Initialized
INFO - 2016-09-24 17:28:47 --> Language Class Initialized
ERROR - 2016-09-24 17:28:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:29:17 --> Config Class Initialized
INFO - 2016-09-24 17:29:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:29:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:29:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:29:17 --> URI Class Initialized
INFO - 2016-09-24 17:29:17 --> Router Class Initialized
INFO - 2016-09-24 17:29:17 --> Output Class Initialized
INFO - 2016-09-24 17:29:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:29:17 --> Input Class Initialized
INFO - 2016-09-24 17:29:17 --> Language Class Initialized
ERROR - 2016-09-24 17:29:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:29:47 --> Config Class Initialized
INFO - 2016-09-24 17:29:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:29:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:29:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:29:47 --> URI Class Initialized
INFO - 2016-09-24 17:29:47 --> Router Class Initialized
INFO - 2016-09-24 17:29:47 --> Output Class Initialized
INFO - 2016-09-24 17:29:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:29:47 --> Input Class Initialized
INFO - 2016-09-24 17:29:47 --> Language Class Initialized
ERROR - 2016-09-24 17:29:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:30:17 --> Config Class Initialized
INFO - 2016-09-24 17:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:30:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:30:17 --> URI Class Initialized
INFO - 2016-09-24 17:30:17 --> Router Class Initialized
INFO - 2016-09-24 17:30:17 --> Output Class Initialized
INFO - 2016-09-24 17:30:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:30:17 --> Input Class Initialized
INFO - 2016-09-24 17:30:17 --> Language Class Initialized
ERROR - 2016-09-24 17:30:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:30:47 --> Config Class Initialized
INFO - 2016-09-24 17:30:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:30:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:30:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:30:47 --> URI Class Initialized
INFO - 2016-09-24 17:30:47 --> Router Class Initialized
INFO - 2016-09-24 17:30:47 --> Output Class Initialized
INFO - 2016-09-24 17:30:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:30:47 --> Input Class Initialized
INFO - 2016-09-24 17:30:47 --> Language Class Initialized
ERROR - 2016-09-24 17:30:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:31:17 --> Config Class Initialized
INFO - 2016-09-24 17:31:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:31:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:31:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:31:17 --> URI Class Initialized
INFO - 2016-09-24 17:31:17 --> Router Class Initialized
INFO - 2016-09-24 17:31:17 --> Output Class Initialized
INFO - 2016-09-24 17:31:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:31:17 --> Input Class Initialized
INFO - 2016-09-24 17:31:17 --> Language Class Initialized
ERROR - 2016-09-24 17:31:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:31:47 --> Config Class Initialized
INFO - 2016-09-24 17:31:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:31:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:31:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:31:47 --> URI Class Initialized
INFO - 2016-09-24 17:31:47 --> Router Class Initialized
INFO - 2016-09-24 17:31:47 --> Output Class Initialized
INFO - 2016-09-24 17:31:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:31:47 --> Input Class Initialized
INFO - 2016-09-24 17:31:47 --> Language Class Initialized
ERROR - 2016-09-24 17:31:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:32:17 --> Config Class Initialized
INFO - 2016-09-24 17:32:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:32:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:32:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:32:17 --> URI Class Initialized
INFO - 2016-09-24 17:32:17 --> Router Class Initialized
INFO - 2016-09-24 17:32:17 --> Output Class Initialized
INFO - 2016-09-24 17:32:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:32:17 --> Input Class Initialized
INFO - 2016-09-24 17:32:17 --> Language Class Initialized
ERROR - 2016-09-24 17:32:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:32:47 --> Config Class Initialized
INFO - 2016-09-24 17:32:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:32:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:32:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:32:47 --> URI Class Initialized
INFO - 2016-09-24 17:32:47 --> Router Class Initialized
INFO - 2016-09-24 17:32:47 --> Output Class Initialized
INFO - 2016-09-24 17:32:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:32:47 --> Input Class Initialized
INFO - 2016-09-24 17:32:47 --> Language Class Initialized
ERROR - 2016-09-24 17:32:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:33:17 --> Config Class Initialized
INFO - 2016-09-24 17:33:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:33:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:33:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:33:17 --> URI Class Initialized
INFO - 2016-09-24 17:33:17 --> Router Class Initialized
INFO - 2016-09-24 17:33:17 --> Output Class Initialized
INFO - 2016-09-24 17:33:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:33:17 --> Input Class Initialized
INFO - 2016-09-24 17:33:17 --> Language Class Initialized
ERROR - 2016-09-24 17:33:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:33:47 --> Config Class Initialized
INFO - 2016-09-24 17:33:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:33:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:33:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:33:47 --> URI Class Initialized
INFO - 2016-09-24 17:33:47 --> Router Class Initialized
INFO - 2016-09-24 17:33:47 --> Output Class Initialized
INFO - 2016-09-24 17:33:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:33:47 --> Input Class Initialized
INFO - 2016-09-24 17:33:47 --> Language Class Initialized
ERROR - 2016-09-24 17:33:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:34:17 --> Config Class Initialized
INFO - 2016-09-24 17:34:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:34:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:34:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:34:17 --> URI Class Initialized
INFO - 2016-09-24 17:34:17 --> Router Class Initialized
INFO - 2016-09-24 17:34:17 --> Output Class Initialized
INFO - 2016-09-24 17:34:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:34:17 --> Input Class Initialized
INFO - 2016-09-24 17:34:17 --> Language Class Initialized
ERROR - 2016-09-24 17:34:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:34:47 --> Config Class Initialized
INFO - 2016-09-24 17:34:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:34:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:34:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:34:47 --> URI Class Initialized
INFO - 2016-09-24 17:34:47 --> Router Class Initialized
INFO - 2016-09-24 17:34:47 --> Output Class Initialized
INFO - 2016-09-24 17:34:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:34:47 --> Input Class Initialized
INFO - 2016-09-24 17:34:47 --> Language Class Initialized
ERROR - 2016-09-24 17:34:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:35:17 --> Config Class Initialized
INFO - 2016-09-24 17:35:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:35:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:35:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:35:17 --> URI Class Initialized
INFO - 2016-09-24 17:35:17 --> Router Class Initialized
INFO - 2016-09-24 17:35:17 --> Output Class Initialized
INFO - 2016-09-24 17:35:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:35:17 --> Input Class Initialized
INFO - 2016-09-24 17:35:17 --> Language Class Initialized
ERROR - 2016-09-24 17:35:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:35:47 --> Config Class Initialized
INFO - 2016-09-24 17:35:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:35:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:35:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:35:47 --> URI Class Initialized
INFO - 2016-09-24 17:35:47 --> Router Class Initialized
INFO - 2016-09-24 17:35:47 --> Output Class Initialized
INFO - 2016-09-24 17:35:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:35:47 --> Input Class Initialized
INFO - 2016-09-24 17:35:47 --> Language Class Initialized
ERROR - 2016-09-24 17:35:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:36:17 --> Config Class Initialized
INFO - 2016-09-24 17:36:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:36:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:36:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:36:17 --> URI Class Initialized
INFO - 2016-09-24 17:36:17 --> Router Class Initialized
INFO - 2016-09-24 17:36:17 --> Output Class Initialized
INFO - 2016-09-24 17:36:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:36:17 --> Input Class Initialized
INFO - 2016-09-24 17:36:17 --> Language Class Initialized
ERROR - 2016-09-24 17:36:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:36:47 --> Config Class Initialized
INFO - 2016-09-24 17:36:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:36:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:36:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:36:47 --> URI Class Initialized
INFO - 2016-09-24 17:36:47 --> Router Class Initialized
INFO - 2016-09-24 17:36:47 --> Output Class Initialized
INFO - 2016-09-24 17:36:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:36:47 --> Input Class Initialized
INFO - 2016-09-24 17:36:47 --> Language Class Initialized
ERROR - 2016-09-24 17:36:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:37:17 --> Config Class Initialized
INFO - 2016-09-24 17:37:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:37:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:37:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:37:17 --> URI Class Initialized
INFO - 2016-09-24 17:37:17 --> Router Class Initialized
INFO - 2016-09-24 17:37:17 --> Output Class Initialized
INFO - 2016-09-24 17:37:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:37:17 --> Input Class Initialized
INFO - 2016-09-24 17:37:17 --> Language Class Initialized
ERROR - 2016-09-24 17:37:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:37:47 --> Config Class Initialized
INFO - 2016-09-24 17:37:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:37:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:37:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:37:47 --> URI Class Initialized
INFO - 2016-09-24 17:37:47 --> Router Class Initialized
INFO - 2016-09-24 17:37:47 --> Output Class Initialized
INFO - 2016-09-24 17:37:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:37:47 --> Input Class Initialized
INFO - 2016-09-24 17:37:47 --> Language Class Initialized
ERROR - 2016-09-24 17:37:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:38:17 --> Config Class Initialized
INFO - 2016-09-24 17:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:38:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:38:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:38:17 --> URI Class Initialized
INFO - 2016-09-24 17:38:17 --> Router Class Initialized
INFO - 2016-09-24 17:38:17 --> Output Class Initialized
INFO - 2016-09-24 17:38:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:38:17 --> Input Class Initialized
INFO - 2016-09-24 17:38:17 --> Language Class Initialized
ERROR - 2016-09-24 17:38:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:38:47 --> Config Class Initialized
INFO - 2016-09-24 17:38:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:38:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:38:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:38:47 --> URI Class Initialized
INFO - 2016-09-24 17:38:47 --> Router Class Initialized
INFO - 2016-09-24 17:38:47 --> Output Class Initialized
INFO - 2016-09-24 17:38:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:38:47 --> Input Class Initialized
INFO - 2016-09-24 17:38:47 --> Language Class Initialized
ERROR - 2016-09-24 17:38:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:39:17 --> Config Class Initialized
INFO - 2016-09-24 17:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:39:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:39:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:39:17 --> URI Class Initialized
INFO - 2016-09-24 17:39:17 --> Router Class Initialized
INFO - 2016-09-24 17:39:17 --> Output Class Initialized
INFO - 2016-09-24 17:39:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:39:17 --> Input Class Initialized
INFO - 2016-09-24 17:39:17 --> Language Class Initialized
ERROR - 2016-09-24 17:39:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:39:47 --> Config Class Initialized
INFO - 2016-09-24 17:39:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:39:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:39:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:39:47 --> URI Class Initialized
INFO - 2016-09-24 17:39:47 --> Router Class Initialized
INFO - 2016-09-24 17:39:47 --> Output Class Initialized
INFO - 2016-09-24 17:39:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:39:47 --> Input Class Initialized
INFO - 2016-09-24 17:39:47 --> Language Class Initialized
ERROR - 2016-09-24 17:39:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:40:17 --> Config Class Initialized
INFO - 2016-09-24 17:40:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:40:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:40:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:40:17 --> URI Class Initialized
INFO - 2016-09-24 17:40:17 --> Router Class Initialized
INFO - 2016-09-24 17:40:17 --> Output Class Initialized
INFO - 2016-09-24 17:40:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:40:17 --> Input Class Initialized
INFO - 2016-09-24 17:40:17 --> Language Class Initialized
ERROR - 2016-09-24 17:40:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:40:47 --> Config Class Initialized
INFO - 2016-09-24 17:40:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:40:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:40:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:40:47 --> URI Class Initialized
INFO - 2016-09-24 17:40:47 --> Router Class Initialized
INFO - 2016-09-24 17:40:47 --> Output Class Initialized
INFO - 2016-09-24 17:40:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:40:47 --> Input Class Initialized
INFO - 2016-09-24 17:40:47 --> Language Class Initialized
ERROR - 2016-09-24 17:40:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:41:17 --> Config Class Initialized
INFO - 2016-09-24 17:41:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:41:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:41:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:41:17 --> URI Class Initialized
INFO - 2016-09-24 17:41:17 --> Router Class Initialized
INFO - 2016-09-24 17:41:17 --> Output Class Initialized
INFO - 2016-09-24 17:41:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:41:17 --> Input Class Initialized
INFO - 2016-09-24 17:41:17 --> Language Class Initialized
ERROR - 2016-09-24 17:41:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:41:47 --> Config Class Initialized
INFO - 2016-09-24 17:41:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:41:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:41:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:41:47 --> URI Class Initialized
INFO - 2016-09-24 17:41:47 --> Router Class Initialized
INFO - 2016-09-24 17:41:47 --> Output Class Initialized
INFO - 2016-09-24 17:41:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:41:47 --> Input Class Initialized
INFO - 2016-09-24 17:41:47 --> Language Class Initialized
ERROR - 2016-09-24 17:41:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:42:17 --> Config Class Initialized
INFO - 2016-09-24 17:42:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:42:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:42:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:42:17 --> URI Class Initialized
INFO - 2016-09-24 17:42:17 --> Router Class Initialized
INFO - 2016-09-24 17:42:17 --> Output Class Initialized
INFO - 2016-09-24 17:42:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:42:17 --> Input Class Initialized
INFO - 2016-09-24 17:42:17 --> Language Class Initialized
ERROR - 2016-09-24 17:42:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:42:47 --> Config Class Initialized
INFO - 2016-09-24 17:42:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:42:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:42:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:42:47 --> URI Class Initialized
INFO - 2016-09-24 17:42:47 --> Router Class Initialized
INFO - 2016-09-24 17:42:47 --> Output Class Initialized
INFO - 2016-09-24 17:42:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:42:47 --> Input Class Initialized
INFO - 2016-09-24 17:42:47 --> Language Class Initialized
ERROR - 2016-09-24 17:42:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:43:17 --> Config Class Initialized
INFO - 2016-09-24 17:43:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:43:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:43:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:43:17 --> URI Class Initialized
INFO - 2016-09-24 17:43:17 --> Router Class Initialized
INFO - 2016-09-24 17:43:17 --> Output Class Initialized
INFO - 2016-09-24 17:43:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:43:17 --> Input Class Initialized
INFO - 2016-09-24 17:43:17 --> Language Class Initialized
ERROR - 2016-09-24 17:43:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:43:47 --> Config Class Initialized
INFO - 2016-09-24 17:43:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:43:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:43:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:43:47 --> URI Class Initialized
INFO - 2016-09-24 17:43:47 --> Router Class Initialized
INFO - 2016-09-24 17:43:47 --> Output Class Initialized
INFO - 2016-09-24 17:43:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:43:47 --> Input Class Initialized
INFO - 2016-09-24 17:43:47 --> Language Class Initialized
ERROR - 2016-09-24 17:43:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:44:17 --> Config Class Initialized
INFO - 2016-09-24 17:44:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:44:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:44:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:44:17 --> URI Class Initialized
INFO - 2016-09-24 17:44:17 --> Router Class Initialized
INFO - 2016-09-24 17:44:17 --> Output Class Initialized
INFO - 2016-09-24 17:44:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:44:17 --> Input Class Initialized
INFO - 2016-09-24 17:44:17 --> Language Class Initialized
ERROR - 2016-09-24 17:44:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:44:47 --> Config Class Initialized
INFO - 2016-09-24 17:44:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:44:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:44:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:44:47 --> URI Class Initialized
INFO - 2016-09-24 17:44:47 --> Router Class Initialized
INFO - 2016-09-24 17:44:47 --> Output Class Initialized
INFO - 2016-09-24 17:44:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:44:47 --> Input Class Initialized
INFO - 2016-09-24 17:44:47 --> Language Class Initialized
ERROR - 2016-09-24 17:44:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:45:17 --> Config Class Initialized
INFO - 2016-09-24 17:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:45:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:45:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:45:17 --> URI Class Initialized
INFO - 2016-09-24 17:45:17 --> Router Class Initialized
INFO - 2016-09-24 17:45:17 --> Output Class Initialized
INFO - 2016-09-24 17:45:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:45:17 --> Input Class Initialized
INFO - 2016-09-24 17:45:17 --> Language Class Initialized
ERROR - 2016-09-24 17:45:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:45:47 --> Config Class Initialized
INFO - 2016-09-24 17:45:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:45:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:45:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:45:47 --> URI Class Initialized
INFO - 2016-09-24 17:45:47 --> Router Class Initialized
INFO - 2016-09-24 17:45:47 --> Output Class Initialized
INFO - 2016-09-24 17:45:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:45:47 --> Input Class Initialized
INFO - 2016-09-24 17:45:47 --> Language Class Initialized
ERROR - 2016-09-24 17:45:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:46:17 --> Config Class Initialized
INFO - 2016-09-24 17:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:46:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:46:17 --> URI Class Initialized
INFO - 2016-09-24 17:46:17 --> Router Class Initialized
INFO - 2016-09-24 17:46:17 --> Output Class Initialized
INFO - 2016-09-24 17:46:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:46:17 --> Input Class Initialized
INFO - 2016-09-24 17:46:17 --> Language Class Initialized
ERROR - 2016-09-24 17:46:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:46:47 --> Config Class Initialized
INFO - 2016-09-24 17:46:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:46:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:46:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:46:47 --> URI Class Initialized
INFO - 2016-09-24 17:46:47 --> Router Class Initialized
INFO - 2016-09-24 17:46:47 --> Output Class Initialized
INFO - 2016-09-24 17:46:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:46:47 --> Input Class Initialized
INFO - 2016-09-24 17:46:47 --> Language Class Initialized
ERROR - 2016-09-24 17:46:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:47:17 --> Config Class Initialized
INFO - 2016-09-24 17:47:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:47:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:47:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:47:17 --> URI Class Initialized
INFO - 2016-09-24 17:47:17 --> Router Class Initialized
INFO - 2016-09-24 17:47:17 --> Output Class Initialized
INFO - 2016-09-24 17:47:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:47:17 --> Input Class Initialized
INFO - 2016-09-24 17:47:17 --> Language Class Initialized
ERROR - 2016-09-24 17:47:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:47:47 --> Config Class Initialized
INFO - 2016-09-24 17:47:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:47:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:47:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:47:47 --> URI Class Initialized
INFO - 2016-09-24 17:47:47 --> Router Class Initialized
INFO - 2016-09-24 17:47:47 --> Output Class Initialized
INFO - 2016-09-24 17:47:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:47:47 --> Input Class Initialized
INFO - 2016-09-24 17:47:47 --> Language Class Initialized
ERROR - 2016-09-24 17:47:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:48:17 --> Config Class Initialized
INFO - 2016-09-24 17:48:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:48:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:48:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:48:17 --> URI Class Initialized
INFO - 2016-09-24 17:48:17 --> Router Class Initialized
INFO - 2016-09-24 17:48:17 --> Output Class Initialized
INFO - 2016-09-24 17:48:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:48:17 --> Input Class Initialized
INFO - 2016-09-24 17:48:17 --> Language Class Initialized
ERROR - 2016-09-24 17:48:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:48:47 --> Config Class Initialized
INFO - 2016-09-24 17:48:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:48:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:48:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:48:47 --> URI Class Initialized
INFO - 2016-09-24 17:48:47 --> Router Class Initialized
INFO - 2016-09-24 17:48:47 --> Output Class Initialized
INFO - 2016-09-24 17:48:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:48:47 --> Input Class Initialized
INFO - 2016-09-24 17:48:47 --> Language Class Initialized
ERROR - 2016-09-24 17:48:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:49:17 --> Config Class Initialized
INFO - 2016-09-24 17:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:49:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:49:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:49:17 --> URI Class Initialized
INFO - 2016-09-24 17:49:17 --> Router Class Initialized
INFO - 2016-09-24 17:49:17 --> Output Class Initialized
INFO - 2016-09-24 17:49:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:49:17 --> Input Class Initialized
INFO - 2016-09-24 17:49:17 --> Language Class Initialized
ERROR - 2016-09-24 17:49:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:49:47 --> Config Class Initialized
INFO - 2016-09-24 17:49:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:49:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:49:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:49:47 --> URI Class Initialized
INFO - 2016-09-24 17:49:47 --> Router Class Initialized
INFO - 2016-09-24 17:49:47 --> Output Class Initialized
INFO - 2016-09-24 17:49:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:49:47 --> Input Class Initialized
INFO - 2016-09-24 17:49:47 --> Language Class Initialized
ERROR - 2016-09-24 17:49:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:50:17 --> Config Class Initialized
INFO - 2016-09-24 17:50:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:50:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:50:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:50:17 --> URI Class Initialized
INFO - 2016-09-24 17:50:17 --> Router Class Initialized
INFO - 2016-09-24 17:50:17 --> Output Class Initialized
INFO - 2016-09-24 17:50:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:50:17 --> Input Class Initialized
INFO - 2016-09-24 17:50:17 --> Language Class Initialized
ERROR - 2016-09-24 17:50:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:50:47 --> Config Class Initialized
INFO - 2016-09-24 17:50:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:50:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:50:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:50:47 --> URI Class Initialized
INFO - 2016-09-24 17:50:47 --> Router Class Initialized
INFO - 2016-09-24 17:50:47 --> Output Class Initialized
INFO - 2016-09-24 17:50:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:50:47 --> Input Class Initialized
INFO - 2016-09-24 17:50:47 --> Language Class Initialized
ERROR - 2016-09-24 17:50:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:51:17 --> Config Class Initialized
INFO - 2016-09-24 17:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:51:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:51:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:51:17 --> URI Class Initialized
INFO - 2016-09-24 17:51:17 --> Router Class Initialized
INFO - 2016-09-24 17:51:17 --> Output Class Initialized
INFO - 2016-09-24 17:51:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:51:17 --> Input Class Initialized
INFO - 2016-09-24 17:51:17 --> Language Class Initialized
ERROR - 2016-09-24 17:51:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:51:47 --> Config Class Initialized
INFO - 2016-09-24 17:51:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:51:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:51:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:51:47 --> URI Class Initialized
INFO - 2016-09-24 17:51:47 --> Router Class Initialized
INFO - 2016-09-24 17:51:47 --> Output Class Initialized
INFO - 2016-09-24 17:51:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:51:47 --> Input Class Initialized
INFO - 2016-09-24 17:51:47 --> Language Class Initialized
ERROR - 2016-09-24 17:51:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:52:17 --> Config Class Initialized
INFO - 2016-09-24 17:52:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:52:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:52:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:52:17 --> URI Class Initialized
INFO - 2016-09-24 17:52:17 --> Router Class Initialized
INFO - 2016-09-24 17:52:17 --> Output Class Initialized
INFO - 2016-09-24 17:52:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:52:17 --> Input Class Initialized
INFO - 2016-09-24 17:52:17 --> Language Class Initialized
ERROR - 2016-09-24 17:52:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:52:47 --> Config Class Initialized
INFO - 2016-09-24 17:52:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:52:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:52:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:52:47 --> URI Class Initialized
INFO - 2016-09-24 17:52:47 --> Router Class Initialized
INFO - 2016-09-24 17:52:47 --> Output Class Initialized
INFO - 2016-09-24 17:52:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:52:47 --> Input Class Initialized
INFO - 2016-09-24 17:52:47 --> Language Class Initialized
ERROR - 2016-09-24 17:52:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:53:17 --> Config Class Initialized
INFO - 2016-09-24 17:53:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:53:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:53:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:53:17 --> URI Class Initialized
INFO - 2016-09-24 17:53:17 --> Router Class Initialized
INFO - 2016-09-24 17:53:17 --> Output Class Initialized
INFO - 2016-09-24 17:53:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:53:17 --> Input Class Initialized
INFO - 2016-09-24 17:53:17 --> Language Class Initialized
ERROR - 2016-09-24 17:53:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:53:47 --> Config Class Initialized
INFO - 2016-09-24 17:53:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:53:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:53:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:53:47 --> URI Class Initialized
INFO - 2016-09-24 17:53:47 --> Router Class Initialized
INFO - 2016-09-24 17:53:47 --> Output Class Initialized
INFO - 2016-09-24 17:53:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:53:47 --> Input Class Initialized
INFO - 2016-09-24 17:53:47 --> Language Class Initialized
ERROR - 2016-09-24 17:53:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:54:17 --> Config Class Initialized
INFO - 2016-09-24 17:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:54:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:54:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:54:17 --> URI Class Initialized
INFO - 2016-09-24 17:54:17 --> Router Class Initialized
INFO - 2016-09-24 17:54:17 --> Output Class Initialized
INFO - 2016-09-24 17:54:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:54:17 --> Input Class Initialized
INFO - 2016-09-24 17:54:17 --> Language Class Initialized
ERROR - 2016-09-24 17:54:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:54:47 --> Config Class Initialized
INFO - 2016-09-24 17:54:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:54:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:54:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:54:47 --> URI Class Initialized
INFO - 2016-09-24 17:54:47 --> Router Class Initialized
INFO - 2016-09-24 17:54:47 --> Output Class Initialized
INFO - 2016-09-24 17:54:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:54:47 --> Input Class Initialized
INFO - 2016-09-24 17:54:47 --> Language Class Initialized
ERROR - 2016-09-24 17:54:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:55:17 --> Config Class Initialized
INFO - 2016-09-24 17:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:55:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:55:17 --> URI Class Initialized
INFO - 2016-09-24 17:55:17 --> Router Class Initialized
INFO - 2016-09-24 17:55:17 --> Output Class Initialized
INFO - 2016-09-24 17:55:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:55:17 --> Input Class Initialized
INFO - 2016-09-24 17:55:17 --> Language Class Initialized
ERROR - 2016-09-24 17:55:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:55:47 --> Config Class Initialized
INFO - 2016-09-24 17:55:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:55:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:55:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:55:47 --> URI Class Initialized
INFO - 2016-09-24 17:55:47 --> Router Class Initialized
INFO - 2016-09-24 17:55:47 --> Output Class Initialized
INFO - 2016-09-24 17:55:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:55:47 --> Input Class Initialized
INFO - 2016-09-24 17:55:47 --> Language Class Initialized
ERROR - 2016-09-24 17:55:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:56:17 --> Config Class Initialized
INFO - 2016-09-24 17:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:56:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:56:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:56:17 --> URI Class Initialized
INFO - 2016-09-24 17:56:17 --> Router Class Initialized
INFO - 2016-09-24 17:56:17 --> Output Class Initialized
INFO - 2016-09-24 17:56:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:56:17 --> Input Class Initialized
INFO - 2016-09-24 17:56:17 --> Language Class Initialized
ERROR - 2016-09-24 17:56:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:56:47 --> Config Class Initialized
INFO - 2016-09-24 17:56:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:56:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:56:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:56:47 --> URI Class Initialized
INFO - 2016-09-24 17:56:47 --> Router Class Initialized
INFO - 2016-09-24 17:56:47 --> Output Class Initialized
INFO - 2016-09-24 17:56:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:56:47 --> Input Class Initialized
INFO - 2016-09-24 17:56:47 --> Language Class Initialized
ERROR - 2016-09-24 17:56:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:57:17 --> Config Class Initialized
INFO - 2016-09-24 17:57:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:57:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:57:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:57:17 --> URI Class Initialized
INFO - 2016-09-24 17:57:17 --> Router Class Initialized
INFO - 2016-09-24 17:57:17 --> Output Class Initialized
INFO - 2016-09-24 17:57:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:57:17 --> Input Class Initialized
INFO - 2016-09-24 17:57:17 --> Language Class Initialized
ERROR - 2016-09-24 17:57:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:57:47 --> Config Class Initialized
INFO - 2016-09-24 17:57:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:57:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:57:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:57:47 --> URI Class Initialized
INFO - 2016-09-24 17:57:47 --> Router Class Initialized
INFO - 2016-09-24 17:57:47 --> Output Class Initialized
INFO - 2016-09-24 17:57:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:57:47 --> Input Class Initialized
INFO - 2016-09-24 17:57:47 --> Language Class Initialized
ERROR - 2016-09-24 17:57:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:58:17 --> Config Class Initialized
INFO - 2016-09-24 17:58:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:58:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:58:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:58:17 --> URI Class Initialized
INFO - 2016-09-24 17:58:17 --> Router Class Initialized
INFO - 2016-09-24 17:58:17 --> Output Class Initialized
INFO - 2016-09-24 17:58:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:58:17 --> Input Class Initialized
INFO - 2016-09-24 17:58:17 --> Language Class Initialized
ERROR - 2016-09-24 17:58:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:58:47 --> Config Class Initialized
INFO - 2016-09-24 17:58:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:58:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:58:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:58:47 --> URI Class Initialized
INFO - 2016-09-24 17:58:47 --> Router Class Initialized
INFO - 2016-09-24 17:58:47 --> Output Class Initialized
INFO - 2016-09-24 17:58:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:58:47 --> Input Class Initialized
INFO - 2016-09-24 17:58:47 --> Language Class Initialized
ERROR - 2016-09-24 17:58:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:59:17 --> Config Class Initialized
INFO - 2016-09-24 17:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:59:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:59:17 --> Utf8 Class Initialized
INFO - 2016-09-24 17:59:17 --> URI Class Initialized
INFO - 2016-09-24 17:59:17 --> Router Class Initialized
INFO - 2016-09-24 17:59:17 --> Output Class Initialized
INFO - 2016-09-24 17:59:17 --> Security Class Initialized
DEBUG - 2016-09-24 17:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:59:17 --> Input Class Initialized
INFO - 2016-09-24 17:59:17 --> Language Class Initialized
ERROR - 2016-09-24 17:59:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 17:59:47 --> Config Class Initialized
INFO - 2016-09-24 17:59:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 17:59:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 17:59:47 --> Utf8 Class Initialized
INFO - 2016-09-24 17:59:47 --> URI Class Initialized
INFO - 2016-09-24 17:59:47 --> Router Class Initialized
INFO - 2016-09-24 17:59:47 --> Output Class Initialized
INFO - 2016-09-24 17:59:47 --> Security Class Initialized
DEBUG - 2016-09-24 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 17:59:47 --> Input Class Initialized
INFO - 2016-09-24 17:59:47 --> Language Class Initialized
ERROR - 2016-09-24 17:59:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:00:17 --> Config Class Initialized
INFO - 2016-09-24 18:00:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:00:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:00:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:00:17 --> URI Class Initialized
INFO - 2016-09-24 18:00:17 --> Router Class Initialized
INFO - 2016-09-24 18:00:17 --> Output Class Initialized
INFO - 2016-09-24 18:00:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:00:17 --> Input Class Initialized
INFO - 2016-09-24 18:00:17 --> Language Class Initialized
ERROR - 2016-09-24 18:00:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:00:47 --> Config Class Initialized
INFO - 2016-09-24 18:00:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:00:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:00:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:00:47 --> URI Class Initialized
INFO - 2016-09-24 18:00:47 --> Router Class Initialized
INFO - 2016-09-24 18:00:47 --> Output Class Initialized
INFO - 2016-09-24 18:00:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:00:47 --> Input Class Initialized
INFO - 2016-09-24 18:00:47 --> Language Class Initialized
ERROR - 2016-09-24 18:00:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:01:17 --> Config Class Initialized
INFO - 2016-09-24 18:01:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:01:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:01:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:01:17 --> URI Class Initialized
INFO - 2016-09-24 18:01:17 --> Router Class Initialized
INFO - 2016-09-24 18:01:17 --> Output Class Initialized
INFO - 2016-09-24 18:01:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:01:17 --> Input Class Initialized
INFO - 2016-09-24 18:01:17 --> Language Class Initialized
ERROR - 2016-09-24 18:01:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:01:47 --> Config Class Initialized
INFO - 2016-09-24 18:01:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:01:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:01:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:01:47 --> URI Class Initialized
INFO - 2016-09-24 18:01:47 --> Router Class Initialized
INFO - 2016-09-24 18:01:47 --> Output Class Initialized
INFO - 2016-09-24 18:01:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:01:47 --> Input Class Initialized
INFO - 2016-09-24 18:01:47 --> Language Class Initialized
ERROR - 2016-09-24 18:01:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:02:17 --> Config Class Initialized
INFO - 2016-09-24 18:02:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:02:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:02:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:02:17 --> URI Class Initialized
INFO - 2016-09-24 18:02:17 --> Router Class Initialized
INFO - 2016-09-24 18:02:17 --> Output Class Initialized
INFO - 2016-09-24 18:02:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:02:17 --> Input Class Initialized
INFO - 2016-09-24 18:02:17 --> Language Class Initialized
ERROR - 2016-09-24 18:02:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:02:47 --> Config Class Initialized
INFO - 2016-09-24 18:02:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:02:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:02:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:02:47 --> URI Class Initialized
INFO - 2016-09-24 18:02:47 --> Router Class Initialized
INFO - 2016-09-24 18:02:47 --> Output Class Initialized
INFO - 2016-09-24 18:02:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:02:47 --> Input Class Initialized
INFO - 2016-09-24 18:02:47 --> Language Class Initialized
ERROR - 2016-09-24 18:02:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:03:17 --> Config Class Initialized
INFO - 2016-09-24 18:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:03:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:03:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:03:17 --> URI Class Initialized
INFO - 2016-09-24 18:03:17 --> Router Class Initialized
INFO - 2016-09-24 18:03:17 --> Output Class Initialized
INFO - 2016-09-24 18:03:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:03:17 --> Input Class Initialized
INFO - 2016-09-24 18:03:17 --> Language Class Initialized
ERROR - 2016-09-24 18:03:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:03:47 --> Config Class Initialized
INFO - 2016-09-24 18:03:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:03:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:03:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:03:47 --> URI Class Initialized
INFO - 2016-09-24 18:03:47 --> Router Class Initialized
INFO - 2016-09-24 18:03:47 --> Output Class Initialized
INFO - 2016-09-24 18:03:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:03:47 --> Input Class Initialized
INFO - 2016-09-24 18:03:47 --> Language Class Initialized
ERROR - 2016-09-24 18:03:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:04:17 --> Config Class Initialized
INFO - 2016-09-24 18:04:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:04:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:04:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:04:17 --> URI Class Initialized
INFO - 2016-09-24 18:04:17 --> Router Class Initialized
INFO - 2016-09-24 18:04:17 --> Output Class Initialized
INFO - 2016-09-24 18:04:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:04:17 --> Input Class Initialized
INFO - 2016-09-24 18:04:17 --> Language Class Initialized
ERROR - 2016-09-24 18:04:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:04:47 --> Config Class Initialized
INFO - 2016-09-24 18:04:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:04:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:04:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:04:47 --> URI Class Initialized
INFO - 2016-09-24 18:04:47 --> Router Class Initialized
INFO - 2016-09-24 18:04:47 --> Output Class Initialized
INFO - 2016-09-24 18:04:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:04:47 --> Input Class Initialized
INFO - 2016-09-24 18:04:47 --> Language Class Initialized
ERROR - 2016-09-24 18:04:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:05:17 --> Config Class Initialized
INFO - 2016-09-24 18:05:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:05:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:05:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:05:17 --> URI Class Initialized
INFO - 2016-09-24 18:05:17 --> Router Class Initialized
INFO - 2016-09-24 18:05:17 --> Output Class Initialized
INFO - 2016-09-24 18:05:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:05:17 --> Input Class Initialized
INFO - 2016-09-24 18:05:17 --> Language Class Initialized
ERROR - 2016-09-24 18:05:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:05:47 --> Config Class Initialized
INFO - 2016-09-24 18:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:05:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:05:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:05:47 --> URI Class Initialized
INFO - 2016-09-24 18:05:47 --> Router Class Initialized
INFO - 2016-09-24 18:05:47 --> Output Class Initialized
INFO - 2016-09-24 18:05:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:05:47 --> Input Class Initialized
INFO - 2016-09-24 18:05:47 --> Language Class Initialized
ERROR - 2016-09-24 18:05:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:06:17 --> Config Class Initialized
INFO - 2016-09-24 18:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:06:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:06:17 --> URI Class Initialized
INFO - 2016-09-24 18:06:17 --> Router Class Initialized
INFO - 2016-09-24 18:06:17 --> Output Class Initialized
INFO - 2016-09-24 18:06:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:06:17 --> Input Class Initialized
INFO - 2016-09-24 18:06:17 --> Language Class Initialized
ERROR - 2016-09-24 18:06:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:06:47 --> Config Class Initialized
INFO - 2016-09-24 18:06:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:06:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:06:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:06:47 --> URI Class Initialized
INFO - 2016-09-24 18:06:47 --> Router Class Initialized
INFO - 2016-09-24 18:06:47 --> Output Class Initialized
INFO - 2016-09-24 18:06:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:06:47 --> Input Class Initialized
INFO - 2016-09-24 18:06:47 --> Language Class Initialized
ERROR - 2016-09-24 18:06:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:07:17 --> Config Class Initialized
INFO - 2016-09-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:07:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:07:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:07:17 --> URI Class Initialized
INFO - 2016-09-24 18:07:17 --> Router Class Initialized
INFO - 2016-09-24 18:07:17 --> Output Class Initialized
INFO - 2016-09-24 18:07:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:07:17 --> Input Class Initialized
INFO - 2016-09-24 18:07:17 --> Language Class Initialized
ERROR - 2016-09-24 18:07:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:07:47 --> Config Class Initialized
INFO - 2016-09-24 18:07:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:07:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:07:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:07:47 --> URI Class Initialized
INFO - 2016-09-24 18:07:47 --> Router Class Initialized
INFO - 2016-09-24 18:07:47 --> Output Class Initialized
INFO - 2016-09-24 18:07:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:07:47 --> Input Class Initialized
INFO - 2016-09-24 18:07:47 --> Language Class Initialized
ERROR - 2016-09-24 18:07:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:08:17 --> Config Class Initialized
INFO - 2016-09-24 18:08:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:08:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:08:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:08:17 --> URI Class Initialized
INFO - 2016-09-24 18:08:17 --> Router Class Initialized
INFO - 2016-09-24 18:08:17 --> Output Class Initialized
INFO - 2016-09-24 18:08:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:08:17 --> Input Class Initialized
INFO - 2016-09-24 18:08:17 --> Language Class Initialized
ERROR - 2016-09-24 18:08:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:08:47 --> Config Class Initialized
INFO - 2016-09-24 18:08:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:08:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:08:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:08:47 --> URI Class Initialized
INFO - 2016-09-24 18:08:47 --> Router Class Initialized
INFO - 2016-09-24 18:08:47 --> Output Class Initialized
INFO - 2016-09-24 18:08:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:08:47 --> Input Class Initialized
INFO - 2016-09-24 18:08:47 --> Language Class Initialized
ERROR - 2016-09-24 18:08:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:09:17 --> Config Class Initialized
INFO - 2016-09-24 18:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:09:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:09:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:09:17 --> URI Class Initialized
INFO - 2016-09-24 18:09:17 --> Router Class Initialized
INFO - 2016-09-24 18:09:17 --> Output Class Initialized
INFO - 2016-09-24 18:09:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:09:17 --> Input Class Initialized
INFO - 2016-09-24 18:09:17 --> Language Class Initialized
ERROR - 2016-09-24 18:09:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:09:47 --> Config Class Initialized
INFO - 2016-09-24 18:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:09:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:09:47 --> URI Class Initialized
INFO - 2016-09-24 18:09:47 --> Router Class Initialized
INFO - 2016-09-24 18:09:47 --> Output Class Initialized
INFO - 2016-09-24 18:09:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:09:47 --> Input Class Initialized
INFO - 2016-09-24 18:09:47 --> Language Class Initialized
ERROR - 2016-09-24 18:09:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:10:17 --> Config Class Initialized
INFO - 2016-09-24 18:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:10:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:10:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:10:17 --> URI Class Initialized
INFO - 2016-09-24 18:10:17 --> Router Class Initialized
INFO - 2016-09-24 18:10:17 --> Output Class Initialized
INFO - 2016-09-24 18:10:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:10:17 --> Input Class Initialized
INFO - 2016-09-24 18:10:17 --> Language Class Initialized
ERROR - 2016-09-24 18:10:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:10:47 --> Config Class Initialized
INFO - 2016-09-24 18:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:10:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:10:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:10:47 --> URI Class Initialized
INFO - 2016-09-24 18:10:47 --> Router Class Initialized
INFO - 2016-09-24 18:10:47 --> Output Class Initialized
INFO - 2016-09-24 18:10:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:10:47 --> Input Class Initialized
INFO - 2016-09-24 18:10:47 --> Language Class Initialized
ERROR - 2016-09-24 18:10:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:11:17 --> Config Class Initialized
INFO - 2016-09-24 18:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:11:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:11:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:11:17 --> URI Class Initialized
INFO - 2016-09-24 18:11:17 --> Router Class Initialized
INFO - 2016-09-24 18:11:17 --> Output Class Initialized
INFO - 2016-09-24 18:11:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:11:17 --> Input Class Initialized
INFO - 2016-09-24 18:11:17 --> Language Class Initialized
ERROR - 2016-09-24 18:11:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:11:47 --> Config Class Initialized
INFO - 2016-09-24 18:11:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:11:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:11:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:11:47 --> URI Class Initialized
INFO - 2016-09-24 18:11:47 --> Router Class Initialized
INFO - 2016-09-24 18:11:47 --> Output Class Initialized
INFO - 2016-09-24 18:11:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:11:47 --> Input Class Initialized
INFO - 2016-09-24 18:11:47 --> Language Class Initialized
ERROR - 2016-09-24 18:11:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:12:17 --> Config Class Initialized
INFO - 2016-09-24 18:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:12:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:12:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:12:17 --> URI Class Initialized
INFO - 2016-09-24 18:12:17 --> Router Class Initialized
INFO - 2016-09-24 18:12:17 --> Output Class Initialized
INFO - 2016-09-24 18:12:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:12:17 --> Input Class Initialized
INFO - 2016-09-24 18:12:17 --> Language Class Initialized
ERROR - 2016-09-24 18:12:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:12:47 --> Config Class Initialized
INFO - 2016-09-24 18:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:12:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:12:47 --> URI Class Initialized
INFO - 2016-09-24 18:12:47 --> Router Class Initialized
INFO - 2016-09-24 18:12:47 --> Output Class Initialized
INFO - 2016-09-24 18:12:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:12:47 --> Input Class Initialized
INFO - 2016-09-24 18:12:47 --> Language Class Initialized
ERROR - 2016-09-24 18:12:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:13:17 --> Config Class Initialized
INFO - 2016-09-24 18:13:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:13:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:13:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:13:17 --> URI Class Initialized
INFO - 2016-09-24 18:13:17 --> Router Class Initialized
INFO - 2016-09-24 18:13:17 --> Output Class Initialized
INFO - 2016-09-24 18:13:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:13:17 --> Input Class Initialized
INFO - 2016-09-24 18:13:17 --> Language Class Initialized
ERROR - 2016-09-24 18:13:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:13:47 --> Config Class Initialized
INFO - 2016-09-24 18:13:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:13:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:13:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:13:47 --> URI Class Initialized
INFO - 2016-09-24 18:13:47 --> Router Class Initialized
INFO - 2016-09-24 18:13:47 --> Output Class Initialized
INFO - 2016-09-24 18:13:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:13:47 --> Input Class Initialized
INFO - 2016-09-24 18:13:47 --> Language Class Initialized
ERROR - 2016-09-24 18:13:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:14:17 --> Config Class Initialized
INFO - 2016-09-24 18:14:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:14:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:14:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:14:17 --> URI Class Initialized
INFO - 2016-09-24 18:14:17 --> Router Class Initialized
INFO - 2016-09-24 18:14:17 --> Output Class Initialized
INFO - 2016-09-24 18:14:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:14:17 --> Input Class Initialized
INFO - 2016-09-24 18:14:17 --> Language Class Initialized
ERROR - 2016-09-24 18:14:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:14:47 --> Config Class Initialized
INFO - 2016-09-24 18:14:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:14:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:14:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:14:47 --> URI Class Initialized
INFO - 2016-09-24 18:14:47 --> Router Class Initialized
INFO - 2016-09-24 18:14:47 --> Output Class Initialized
INFO - 2016-09-24 18:14:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:14:47 --> Input Class Initialized
INFO - 2016-09-24 18:14:47 --> Language Class Initialized
ERROR - 2016-09-24 18:14:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:15:17 --> Config Class Initialized
INFO - 2016-09-24 18:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:15:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:15:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:15:17 --> URI Class Initialized
INFO - 2016-09-24 18:15:17 --> Router Class Initialized
INFO - 2016-09-24 18:15:17 --> Output Class Initialized
INFO - 2016-09-24 18:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:15:17 --> Input Class Initialized
INFO - 2016-09-24 18:15:17 --> Language Class Initialized
ERROR - 2016-09-24 18:15:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:15:47 --> Config Class Initialized
INFO - 2016-09-24 18:15:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:15:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:15:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:15:47 --> URI Class Initialized
INFO - 2016-09-24 18:15:47 --> Router Class Initialized
INFO - 2016-09-24 18:15:47 --> Output Class Initialized
INFO - 2016-09-24 18:15:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:15:47 --> Input Class Initialized
INFO - 2016-09-24 18:15:47 --> Language Class Initialized
ERROR - 2016-09-24 18:15:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:16:17 --> Config Class Initialized
INFO - 2016-09-24 18:16:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:16:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:16:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:16:17 --> URI Class Initialized
INFO - 2016-09-24 18:16:17 --> Router Class Initialized
INFO - 2016-09-24 18:16:17 --> Output Class Initialized
INFO - 2016-09-24 18:16:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:16:17 --> Input Class Initialized
INFO - 2016-09-24 18:16:17 --> Language Class Initialized
ERROR - 2016-09-24 18:16:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:16:47 --> Config Class Initialized
INFO - 2016-09-24 18:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:16:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:16:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:16:47 --> URI Class Initialized
INFO - 2016-09-24 18:16:47 --> Router Class Initialized
INFO - 2016-09-24 18:16:47 --> Output Class Initialized
INFO - 2016-09-24 18:16:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:16:47 --> Input Class Initialized
INFO - 2016-09-24 18:16:47 --> Language Class Initialized
ERROR - 2016-09-24 18:16:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:17:17 --> Config Class Initialized
INFO - 2016-09-24 18:17:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:17:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:17:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:17:17 --> URI Class Initialized
INFO - 2016-09-24 18:17:17 --> Router Class Initialized
INFO - 2016-09-24 18:17:17 --> Output Class Initialized
INFO - 2016-09-24 18:17:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:17:17 --> Input Class Initialized
INFO - 2016-09-24 18:17:17 --> Language Class Initialized
ERROR - 2016-09-24 18:17:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:17:47 --> Config Class Initialized
INFO - 2016-09-24 18:17:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:17:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:17:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:17:47 --> URI Class Initialized
INFO - 2016-09-24 18:17:47 --> Router Class Initialized
INFO - 2016-09-24 18:17:47 --> Output Class Initialized
INFO - 2016-09-24 18:17:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:17:47 --> Input Class Initialized
INFO - 2016-09-24 18:17:47 --> Language Class Initialized
ERROR - 2016-09-24 18:17:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:18:17 --> Config Class Initialized
INFO - 2016-09-24 18:18:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:18:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:18:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:18:17 --> URI Class Initialized
INFO - 2016-09-24 18:18:17 --> Router Class Initialized
INFO - 2016-09-24 18:18:17 --> Output Class Initialized
INFO - 2016-09-24 18:18:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:18:17 --> Input Class Initialized
INFO - 2016-09-24 18:18:17 --> Language Class Initialized
ERROR - 2016-09-24 18:18:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:18:47 --> Config Class Initialized
INFO - 2016-09-24 18:18:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:18:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:18:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:18:47 --> URI Class Initialized
INFO - 2016-09-24 18:18:47 --> Router Class Initialized
INFO - 2016-09-24 18:18:47 --> Output Class Initialized
INFO - 2016-09-24 18:18:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:18:47 --> Input Class Initialized
INFO - 2016-09-24 18:18:47 --> Language Class Initialized
ERROR - 2016-09-24 18:18:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:19:17 --> Config Class Initialized
INFO - 2016-09-24 18:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:19:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:19:17 --> URI Class Initialized
INFO - 2016-09-24 18:19:17 --> Router Class Initialized
INFO - 2016-09-24 18:19:17 --> Output Class Initialized
INFO - 2016-09-24 18:19:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:19:17 --> Input Class Initialized
INFO - 2016-09-24 18:19:17 --> Language Class Initialized
ERROR - 2016-09-24 18:19:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:19:47 --> Config Class Initialized
INFO - 2016-09-24 18:19:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:19:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:19:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:19:47 --> URI Class Initialized
INFO - 2016-09-24 18:19:47 --> Router Class Initialized
INFO - 2016-09-24 18:19:47 --> Output Class Initialized
INFO - 2016-09-24 18:19:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:19:47 --> Input Class Initialized
INFO - 2016-09-24 18:19:47 --> Language Class Initialized
ERROR - 2016-09-24 18:19:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:20:17 --> Config Class Initialized
INFO - 2016-09-24 18:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:20:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:20:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:20:17 --> URI Class Initialized
INFO - 2016-09-24 18:20:17 --> Router Class Initialized
INFO - 2016-09-24 18:20:17 --> Output Class Initialized
INFO - 2016-09-24 18:20:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:20:17 --> Input Class Initialized
INFO - 2016-09-24 18:20:17 --> Language Class Initialized
ERROR - 2016-09-24 18:20:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:20:47 --> Config Class Initialized
INFO - 2016-09-24 18:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:20:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:20:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:20:47 --> URI Class Initialized
INFO - 2016-09-24 18:20:47 --> Router Class Initialized
INFO - 2016-09-24 18:20:47 --> Output Class Initialized
INFO - 2016-09-24 18:20:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:20:47 --> Input Class Initialized
INFO - 2016-09-24 18:20:47 --> Language Class Initialized
ERROR - 2016-09-24 18:20:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:21:17 --> Config Class Initialized
INFO - 2016-09-24 18:21:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:21:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:21:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:21:17 --> URI Class Initialized
INFO - 2016-09-24 18:21:17 --> Router Class Initialized
INFO - 2016-09-24 18:21:17 --> Output Class Initialized
INFO - 2016-09-24 18:21:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:21:17 --> Input Class Initialized
INFO - 2016-09-24 18:21:17 --> Language Class Initialized
ERROR - 2016-09-24 18:21:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:21:47 --> Config Class Initialized
INFO - 2016-09-24 18:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:21:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:21:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:21:47 --> URI Class Initialized
INFO - 2016-09-24 18:21:47 --> Router Class Initialized
INFO - 2016-09-24 18:21:47 --> Output Class Initialized
INFO - 2016-09-24 18:21:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:21:47 --> Input Class Initialized
INFO - 2016-09-24 18:21:47 --> Language Class Initialized
ERROR - 2016-09-24 18:21:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:22:17 --> Config Class Initialized
INFO - 2016-09-24 18:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:22:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:22:17 --> URI Class Initialized
INFO - 2016-09-24 18:22:17 --> Router Class Initialized
INFO - 2016-09-24 18:22:17 --> Output Class Initialized
INFO - 2016-09-24 18:22:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:22:17 --> Input Class Initialized
INFO - 2016-09-24 18:22:17 --> Language Class Initialized
ERROR - 2016-09-24 18:22:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:22:47 --> Config Class Initialized
INFO - 2016-09-24 18:22:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:22:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:22:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:22:47 --> URI Class Initialized
INFO - 2016-09-24 18:22:47 --> Router Class Initialized
INFO - 2016-09-24 18:22:47 --> Output Class Initialized
INFO - 2016-09-24 18:22:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:22:47 --> Input Class Initialized
INFO - 2016-09-24 18:22:47 --> Language Class Initialized
ERROR - 2016-09-24 18:22:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:23:17 --> Config Class Initialized
INFO - 2016-09-24 18:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:23:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:23:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:23:17 --> URI Class Initialized
INFO - 2016-09-24 18:23:17 --> Router Class Initialized
INFO - 2016-09-24 18:23:17 --> Output Class Initialized
INFO - 2016-09-24 18:23:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:23:17 --> Input Class Initialized
INFO - 2016-09-24 18:23:17 --> Language Class Initialized
ERROR - 2016-09-24 18:23:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:23:47 --> Config Class Initialized
INFO - 2016-09-24 18:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:23:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:23:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:23:47 --> URI Class Initialized
INFO - 2016-09-24 18:23:47 --> Router Class Initialized
INFO - 2016-09-24 18:23:47 --> Output Class Initialized
INFO - 2016-09-24 18:23:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:23:47 --> Input Class Initialized
INFO - 2016-09-24 18:23:47 --> Language Class Initialized
ERROR - 2016-09-24 18:23:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:24:17 --> Config Class Initialized
INFO - 2016-09-24 18:24:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:24:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:24:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:24:17 --> URI Class Initialized
INFO - 2016-09-24 18:24:17 --> Router Class Initialized
INFO - 2016-09-24 18:24:17 --> Output Class Initialized
INFO - 2016-09-24 18:24:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:24:17 --> Input Class Initialized
INFO - 2016-09-24 18:24:17 --> Language Class Initialized
ERROR - 2016-09-24 18:24:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:24:47 --> Config Class Initialized
INFO - 2016-09-24 18:24:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:24:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:24:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:24:47 --> URI Class Initialized
INFO - 2016-09-24 18:24:47 --> Router Class Initialized
INFO - 2016-09-24 18:24:47 --> Output Class Initialized
INFO - 2016-09-24 18:24:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:24:47 --> Input Class Initialized
INFO - 2016-09-24 18:24:47 --> Language Class Initialized
ERROR - 2016-09-24 18:24:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:25:17 --> Config Class Initialized
INFO - 2016-09-24 18:25:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:25:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:25:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:25:17 --> URI Class Initialized
INFO - 2016-09-24 18:25:17 --> Router Class Initialized
INFO - 2016-09-24 18:25:17 --> Output Class Initialized
INFO - 2016-09-24 18:25:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:25:17 --> Input Class Initialized
INFO - 2016-09-24 18:25:17 --> Language Class Initialized
ERROR - 2016-09-24 18:25:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:25:47 --> Config Class Initialized
INFO - 2016-09-24 18:25:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:25:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:25:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:25:47 --> URI Class Initialized
INFO - 2016-09-24 18:25:47 --> Router Class Initialized
INFO - 2016-09-24 18:25:47 --> Output Class Initialized
INFO - 2016-09-24 18:25:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:25:47 --> Input Class Initialized
INFO - 2016-09-24 18:25:47 --> Language Class Initialized
ERROR - 2016-09-24 18:25:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:26:17 --> Config Class Initialized
INFO - 2016-09-24 18:26:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:26:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:26:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:26:17 --> URI Class Initialized
INFO - 2016-09-24 18:26:17 --> Router Class Initialized
INFO - 2016-09-24 18:26:17 --> Output Class Initialized
INFO - 2016-09-24 18:26:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:26:17 --> Input Class Initialized
INFO - 2016-09-24 18:26:17 --> Language Class Initialized
ERROR - 2016-09-24 18:26:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:26:47 --> Config Class Initialized
INFO - 2016-09-24 18:26:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:26:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:26:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:26:47 --> URI Class Initialized
INFO - 2016-09-24 18:26:47 --> Router Class Initialized
INFO - 2016-09-24 18:26:47 --> Output Class Initialized
INFO - 2016-09-24 18:26:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:26:47 --> Input Class Initialized
INFO - 2016-09-24 18:26:47 --> Language Class Initialized
ERROR - 2016-09-24 18:26:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:27:17 --> Config Class Initialized
INFO - 2016-09-24 18:27:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:27:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:27:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:27:17 --> URI Class Initialized
INFO - 2016-09-24 18:27:17 --> Router Class Initialized
INFO - 2016-09-24 18:27:17 --> Output Class Initialized
INFO - 2016-09-24 18:27:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:27:17 --> Input Class Initialized
INFO - 2016-09-24 18:27:17 --> Language Class Initialized
ERROR - 2016-09-24 18:27:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:27:47 --> Config Class Initialized
INFO - 2016-09-24 18:27:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:27:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:27:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:27:47 --> URI Class Initialized
INFO - 2016-09-24 18:27:47 --> Router Class Initialized
INFO - 2016-09-24 18:27:47 --> Output Class Initialized
INFO - 2016-09-24 18:27:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:27:47 --> Input Class Initialized
INFO - 2016-09-24 18:27:47 --> Language Class Initialized
ERROR - 2016-09-24 18:27:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:28:17 --> Config Class Initialized
INFO - 2016-09-24 18:28:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:28:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:28:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:28:17 --> URI Class Initialized
INFO - 2016-09-24 18:28:17 --> Router Class Initialized
INFO - 2016-09-24 18:28:17 --> Output Class Initialized
INFO - 2016-09-24 18:28:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:28:17 --> Input Class Initialized
INFO - 2016-09-24 18:28:17 --> Language Class Initialized
ERROR - 2016-09-24 18:28:17 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:28:47 --> Config Class Initialized
INFO - 2016-09-24 18:28:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:28:47 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:28:47 --> Utf8 Class Initialized
INFO - 2016-09-24 18:28:47 --> URI Class Initialized
INFO - 2016-09-24 18:28:47 --> Router Class Initialized
INFO - 2016-09-24 18:28:47 --> Output Class Initialized
INFO - 2016-09-24 18:28:47 --> Security Class Initialized
DEBUG - 2016-09-24 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:28:47 --> Input Class Initialized
INFO - 2016-09-24 18:28:47 --> Language Class Initialized
ERROR - 2016-09-24 18:28:47 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-24 18:29:17 --> Config Class Initialized
INFO - 2016-09-24 18:29:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:29:17 --> UTF-8 Support Enabled
INFO - 2016-09-24 18:29:17 --> Utf8 Class Initialized
INFO - 2016-09-24 18:29:17 --> URI Class Initialized
INFO - 2016-09-24 18:29:17 --> Router Class Initialized
INFO - 2016-09-24 18:29:17 --> Output Class Initialized
INFO - 2016-09-24 18:29:17 --> Security Class Initialized
DEBUG - 2016-09-24 18:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-24 18:29:17 --> Input Class Initialized
INFO - 2016-09-24 18:29:17 --> Language Class Initialized
ERROR - 2016-09-24 18:29:17 --> 404 Page Not Found: Ujian/set_ind_time
