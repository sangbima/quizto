<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-26 08:58:16 --> Config Class Initialized
INFO - 2016-09-26 08:58:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 08:58:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 08:58:16 --> Utf8 Class Initialized
INFO - 2016-09-26 08:58:16 --> URI Class Initialized
INFO - 2016-09-26 08:58:16 --> Router Class Initialized
INFO - 2016-09-26 08:58:16 --> Output Class Initialized
INFO - 2016-09-26 08:58:16 --> Security Class Initialized
DEBUG - 2016-09-26 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 08:58:16 --> Input Class Initialized
INFO - 2016-09-26 08:58:16 --> Language Class Initialized
INFO - 2016-09-26 08:58:16 --> Loader Class Initialized
INFO - 2016-09-26 08:58:16 --> Helper loaded: url_helper
INFO - 2016-09-26 08:58:16 --> Helper loaded: language_helper
INFO - 2016-09-26 08:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 08:58:16 --> Controller Class Initialized
INFO - 2016-09-26 08:58:16 --> Database Driver Class Initialized
INFO - 2016-09-26 08:58:16 --> Model Class Initialized
INFO - 2016-09-26 08:58:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 08:58:16 --> Config Class Initialized
INFO - 2016-09-26 08:58:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 08:58:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 08:58:16 --> Utf8 Class Initialized
INFO - 2016-09-26 08:58:16 --> URI Class Initialized
INFO - 2016-09-26 08:58:16 --> Router Class Initialized
INFO - 2016-09-26 08:58:16 --> Output Class Initialized
INFO - 2016-09-26 08:58:16 --> Security Class Initialized
DEBUG - 2016-09-26 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 08:58:16 --> Input Class Initialized
INFO - 2016-09-26 08:58:16 --> Language Class Initialized
INFO - 2016-09-26 08:58:16 --> Loader Class Initialized
INFO - 2016-09-26 08:58:16 --> Helper loaded: url_helper
INFO - 2016-09-26 08:58:16 --> Helper loaded: language_helper
INFO - 2016-09-26 08:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 08:58:16 --> Controller Class Initialized
INFO - 2016-09-26 08:58:16 --> Database Driver Class Initialized
INFO - 2016-09-26 08:58:16 --> Model Class Initialized
INFO - 2016-09-26 08:58:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 08:58:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-26 08:58:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-26 08:58:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-26 08:58:16 --> Final output sent to browser
DEBUG - 2016-09-26 08:58:16 --> Total execution time: 0.0624
INFO - 2016-09-26 08:58:21 --> Config Class Initialized
INFO - 2016-09-26 08:58:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 08:58:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 08:58:21 --> Utf8 Class Initialized
INFO - 2016-09-26 08:58:21 --> URI Class Initialized
INFO - 2016-09-26 08:58:21 --> Router Class Initialized
INFO - 2016-09-26 08:58:21 --> Output Class Initialized
INFO - 2016-09-26 08:58:21 --> Security Class Initialized
DEBUG - 2016-09-26 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 08:58:21 --> Input Class Initialized
INFO - 2016-09-26 08:58:21 --> Language Class Initialized
INFO - 2016-09-26 08:58:21 --> Loader Class Initialized
INFO - 2016-09-26 08:58:21 --> Helper loaded: url_helper
INFO - 2016-09-26 08:58:21 --> Helper loaded: language_helper
INFO - 2016-09-26 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 08:58:21 --> Controller Class Initialized
INFO - 2016-09-26 08:58:21 --> Database Driver Class Initialized
INFO - 2016-09-26 08:58:21 --> Model Class Initialized
INFO - 2016-09-26 08:58:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 08:58:21 --> Config Class Initialized
INFO - 2016-09-26 08:58:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 08:58:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 08:58:21 --> Utf8 Class Initialized
INFO - 2016-09-26 08:58:21 --> URI Class Initialized
INFO - 2016-09-26 08:58:21 --> Router Class Initialized
INFO - 2016-09-26 08:58:21 --> Output Class Initialized
INFO - 2016-09-26 08:58:21 --> Security Class Initialized
DEBUG - 2016-09-26 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 08:58:21 --> Input Class Initialized
INFO - 2016-09-26 08:58:21 --> Language Class Initialized
INFO - 2016-09-26 08:58:21 --> Loader Class Initialized
INFO - 2016-09-26 08:58:21 --> Helper loaded: url_helper
INFO - 2016-09-26 08:58:21 --> Helper loaded: language_helper
INFO - 2016-09-26 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 08:58:21 --> Controller Class Initialized
INFO - 2016-09-26 08:58:21 --> Database Driver Class Initialized
INFO - 2016-09-26 08:58:21 --> Model Class Initialized
INFO - 2016-09-26 08:58:21 --> Model Class Initialized
INFO - 2016-09-26 08:58:21 --> Model Class Initialized
INFO - 2016-09-26 08:58:21 --> Model Class Initialized
INFO - 2016-09-26 08:58:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 08:58:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 08:58:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-26 08:58:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 08:58:21 --> Final output sent to browser
DEBUG - 2016-09-26 08:58:21 --> Total execution time: 0.0788
INFO - 2016-09-26 08:58:24 --> Config Class Initialized
INFO - 2016-09-26 08:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 08:58:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 08:58:24 --> Utf8 Class Initialized
INFO - 2016-09-26 08:58:24 --> URI Class Initialized
INFO - 2016-09-26 08:58:24 --> Router Class Initialized
INFO - 2016-09-26 08:58:24 --> Output Class Initialized
INFO - 2016-09-26 08:58:24 --> Security Class Initialized
DEBUG - 2016-09-26 08:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 08:58:24 --> Input Class Initialized
INFO - 2016-09-26 08:58:24 --> Language Class Initialized
INFO - 2016-09-26 08:58:24 --> Loader Class Initialized
INFO - 2016-09-26 08:58:24 --> Helper loaded: url_helper
INFO - 2016-09-26 08:58:24 --> Helper loaded: language_helper
INFO - 2016-09-26 08:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 08:58:24 --> Controller Class Initialized
INFO - 2016-09-26 08:58:24 --> Database Driver Class Initialized
INFO - 2016-09-26 08:58:24 --> Model Class Initialized
INFO - 2016-09-26 08:58:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 08:58:24 --> Helper loaded: form_helper
INFO - 2016-09-26 08:58:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 08:58:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 08:58:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 08:58:24 --> Final output sent to browser
DEBUG - 2016-09-26 08:58:24 --> Total execution time: 0.0754
INFO - 2016-09-26 09:02:38 --> Config Class Initialized
INFO - 2016-09-26 09:02:38 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:02:38 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:02:38 --> Utf8 Class Initialized
INFO - 2016-09-26 09:02:38 --> URI Class Initialized
INFO - 2016-09-26 09:02:38 --> Router Class Initialized
INFO - 2016-09-26 09:02:38 --> Output Class Initialized
INFO - 2016-09-26 09:02:38 --> Security Class Initialized
DEBUG - 2016-09-26 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:02:38 --> Input Class Initialized
INFO - 2016-09-26 09:02:38 --> Language Class Initialized
INFO - 2016-09-26 09:02:38 --> Loader Class Initialized
INFO - 2016-09-26 09:02:38 --> Helper loaded: url_helper
INFO - 2016-09-26 09:02:38 --> Helper loaded: language_helper
INFO - 2016-09-26 09:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:02:38 --> Controller Class Initialized
INFO - 2016-09-26 09:02:38 --> Database Driver Class Initialized
INFO - 2016-09-26 09:02:38 --> Model Class Initialized
INFO - 2016-09-26 09:02:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:02:38 --> Helper loaded: form_helper
INFO - 2016-09-26 09:02:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:02:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:02:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:02:38 --> Final output sent to browser
DEBUG - 2016-09-26 09:02:38 --> Total execution time: 0.0714
INFO - 2016-09-26 09:03:51 --> Config Class Initialized
INFO - 2016-09-26 09:03:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:03:51 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:03:51 --> Utf8 Class Initialized
INFO - 2016-09-26 09:03:51 --> URI Class Initialized
INFO - 2016-09-26 09:03:51 --> Router Class Initialized
INFO - 2016-09-26 09:03:51 --> Output Class Initialized
INFO - 2016-09-26 09:03:51 --> Security Class Initialized
DEBUG - 2016-09-26 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:03:51 --> Input Class Initialized
INFO - 2016-09-26 09:03:51 --> Language Class Initialized
INFO - 2016-09-26 09:03:51 --> Loader Class Initialized
INFO - 2016-09-26 09:03:51 --> Helper loaded: url_helper
INFO - 2016-09-26 09:03:51 --> Helper loaded: language_helper
INFO - 2016-09-26 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:03:51 --> Controller Class Initialized
INFO - 2016-09-26 09:03:51 --> Database Driver Class Initialized
INFO - 2016-09-26 09:03:51 --> Model Class Initialized
INFO - 2016-09-26 09:03:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:03:51 --> Helper loaded: form_helper
INFO - 2016-09-26 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:03:51 --> Final output sent to browser
DEBUG - 2016-09-26 09:03:51 --> Total execution time: 0.0738
INFO - 2016-09-26 09:04:06 --> Config Class Initialized
INFO - 2016-09-26 09:04:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:04:06 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:04:06 --> Utf8 Class Initialized
INFO - 2016-09-26 09:04:06 --> URI Class Initialized
INFO - 2016-09-26 09:04:06 --> Router Class Initialized
INFO - 2016-09-26 09:04:06 --> Output Class Initialized
INFO - 2016-09-26 09:04:06 --> Security Class Initialized
DEBUG - 2016-09-26 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:04:06 --> Input Class Initialized
INFO - 2016-09-26 09:04:06 --> Language Class Initialized
INFO - 2016-09-26 09:04:06 --> Loader Class Initialized
INFO - 2016-09-26 09:04:06 --> Helper loaded: url_helper
INFO - 2016-09-26 09:04:06 --> Helper loaded: language_helper
INFO - 2016-09-26 09:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:04:06 --> Controller Class Initialized
INFO - 2016-09-26 09:04:06 --> Database Driver Class Initialized
INFO - 2016-09-26 09:04:06 --> Model Class Initialized
INFO - 2016-09-26 09:04:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:04:06 --> Helper loaded: form_helper
INFO - 2016-09-26 09:04:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:04:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:04:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:04:06 --> Final output sent to browser
DEBUG - 2016-09-26 09:04:06 --> Total execution time: 0.0849
INFO - 2016-09-26 09:04:26 --> Config Class Initialized
INFO - 2016-09-26 09:04:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:04:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:04:26 --> Utf8 Class Initialized
INFO - 2016-09-26 09:04:26 --> URI Class Initialized
INFO - 2016-09-26 09:04:26 --> Router Class Initialized
INFO - 2016-09-26 09:04:26 --> Output Class Initialized
INFO - 2016-09-26 09:04:26 --> Security Class Initialized
DEBUG - 2016-09-26 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:04:26 --> Input Class Initialized
INFO - 2016-09-26 09:04:26 --> Language Class Initialized
INFO - 2016-09-26 09:04:26 --> Loader Class Initialized
INFO - 2016-09-26 09:04:26 --> Helper loaded: url_helper
INFO - 2016-09-26 09:04:26 --> Helper loaded: language_helper
INFO - 2016-09-26 09:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:04:26 --> Controller Class Initialized
INFO - 2016-09-26 09:04:26 --> Database Driver Class Initialized
INFO - 2016-09-26 09:04:26 --> Model Class Initialized
INFO - 2016-09-26 09:04:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:04:26 --> Helper loaded: form_helper
INFO - 2016-09-26 09:04:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:04:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:04:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:04:26 --> Final output sent to browser
DEBUG - 2016-09-26 09:04:26 --> Total execution time: 0.0650
INFO - 2016-09-26 09:05:01 --> Config Class Initialized
INFO - 2016-09-26 09:05:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:05:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:05:01 --> Utf8 Class Initialized
INFO - 2016-09-26 09:05:01 --> URI Class Initialized
INFO - 2016-09-26 09:05:01 --> Router Class Initialized
INFO - 2016-09-26 09:05:01 --> Output Class Initialized
INFO - 2016-09-26 09:05:01 --> Security Class Initialized
DEBUG - 2016-09-26 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:05:01 --> Input Class Initialized
INFO - 2016-09-26 09:05:01 --> Language Class Initialized
INFO - 2016-09-26 09:05:01 --> Loader Class Initialized
INFO - 2016-09-26 09:05:01 --> Helper loaded: url_helper
INFO - 2016-09-26 09:05:01 --> Helper loaded: language_helper
INFO - 2016-09-26 09:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:05:01 --> Controller Class Initialized
INFO - 2016-09-26 09:05:01 --> Database Driver Class Initialized
INFO - 2016-09-26 09:05:01 --> Model Class Initialized
INFO - 2016-09-26 09:05:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:05:01 --> Helper loaded: form_helper
INFO - 2016-09-26 09:05:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:05:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:05:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:05:01 --> Final output sent to browser
DEBUG - 2016-09-26 09:05:01 --> Total execution time: 0.0702
INFO - 2016-09-26 09:05:42 --> Config Class Initialized
INFO - 2016-09-26 09:05:42 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:05:42 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:05:42 --> Utf8 Class Initialized
INFO - 2016-09-26 09:05:42 --> URI Class Initialized
INFO - 2016-09-26 09:05:42 --> Router Class Initialized
INFO - 2016-09-26 09:05:42 --> Output Class Initialized
INFO - 2016-09-26 09:05:42 --> Security Class Initialized
DEBUG - 2016-09-26 09:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:05:42 --> Input Class Initialized
INFO - 2016-09-26 09:05:42 --> Language Class Initialized
INFO - 2016-09-26 09:05:42 --> Loader Class Initialized
INFO - 2016-09-26 09:05:42 --> Helper loaded: url_helper
INFO - 2016-09-26 09:05:42 --> Helper loaded: language_helper
INFO - 2016-09-26 09:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:05:42 --> Controller Class Initialized
INFO - 2016-09-26 09:05:42 --> Database Driver Class Initialized
INFO - 2016-09-26 09:05:42 --> Model Class Initialized
INFO - 2016-09-26 09:05:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:05:42 --> Helper loaded: form_helper
INFO - 2016-09-26 09:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:05:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:05:42 --> Final output sent to browser
DEBUG - 2016-09-26 09:05:42 --> Total execution time: 0.0760
INFO - 2016-09-26 09:05:50 --> Config Class Initialized
INFO - 2016-09-26 09:05:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:05:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:05:50 --> Utf8 Class Initialized
INFO - 2016-09-26 09:05:50 --> URI Class Initialized
INFO - 2016-09-26 09:05:50 --> Router Class Initialized
INFO - 2016-09-26 09:05:50 --> Output Class Initialized
INFO - 2016-09-26 09:05:50 --> Security Class Initialized
DEBUG - 2016-09-26 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:05:50 --> Input Class Initialized
INFO - 2016-09-26 09:05:50 --> Language Class Initialized
INFO - 2016-09-26 09:05:50 --> Loader Class Initialized
INFO - 2016-09-26 09:05:50 --> Helper loaded: url_helper
INFO - 2016-09-26 09:05:50 --> Helper loaded: language_helper
INFO - 2016-09-26 09:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:05:50 --> Controller Class Initialized
INFO - 2016-09-26 09:05:50 --> Database Driver Class Initialized
INFO - 2016-09-26 09:05:50 --> Model Class Initialized
INFO - 2016-09-26 09:05:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:05:50 --> Helper loaded: form_helper
INFO - 2016-09-26 09:05:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:05:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:05:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:05:50 --> Final output sent to browser
DEBUG - 2016-09-26 09:05:50 --> Total execution time: 0.0760
INFO - 2016-09-26 09:05:59 --> Config Class Initialized
INFO - 2016-09-26 09:05:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:05:59 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:05:59 --> Utf8 Class Initialized
INFO - 2016-09-26 09:05:59 --> URI Class Initialized
INFO - 2016-09-26 09:05:59 --> Router Class Initialized
INFO - 2016-09-26 09:05:59 --> Output Class Initialized
INFO - 2016-09-26 09:05:59 --> Security Class Initialized
DEBUG - 2016-09-26 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:05:59 --> Input Class Initialized
INFO - 2016-09-26 09:05:59 --> Language Class Initialized
INFO - 2016-09-26 09:05:59 --> Loader Class Initialized
INFO - 2016-09-26 09:05:59 --> Helper loaded: url_helper
INFO - 2016-09-26 09:05:59 --> Helper loaded: language_helper
INFO - 2016-09-26 09:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:05:59 --> Controller Class Initialized
INFO - 2016-09-26 09:05:59 --> Database Driver Class Initialized
INFO - 2016-09-26 09:05:59 --> Model Class Initialized
INFO - 2016-09-26 09:05:59 --> Model Class Initialized
INFO - 2016-09-26 09:05:59 --> Model Class Initialized
INFO - 2016-09-26 09:05:59 --> Model Class Initialized
INFO - 2016-09-26 09:05:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-26 09:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:05:59 --> Final output sent to browser
DEBUG - 2016-09-26 09:05:59 --> Total execution time: 0.0740
INFO - 2016-09-26 09:06:08 --> Config Class Initialized
INFO - 2016-09-26 09:06:08 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:06:08 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:06:08 --> Utf8 Class Initialized
INFO - 2016-09-26 09:06:08 --> URI Class Initialized
INFO - 2016-09-26 09:06:08 --> Router Class Initialized
INFO - 2016-09-26 09:06:08 --> Output Class Initialized
INFO - 2016-09-26 09:06:08 --> Security Class Initialized
DEBUG - 2016-09-26 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:06:08 --> Input Class Initialized
INFO - 2016-09-26 09:06:08 --> Language Class Initialized
INFO - 2016-09-26 09:06:08 --> Loader Class Initialized
INFO - 2016-09-26 09:06:08 --> Helper loaded: url_helper
INFO - 2016-09-26 09:06:08 --> Helper loaded: language_helper
INFO - 2016-09-26 09:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:06:08 --> Controller Class Initialized
INFO - 2016-09-26 09:06:08 --> Database Driver Class Initialized
INFO - 2016-09-26 09:06:08 --> Model Class Initialized
INFO - 2016-09-26 09:06:08 --> Model Class Initialized
INFO - 2016-09-26 09:06:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:06:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:06:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-26 09:06:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:06:08 --> Final output sent to browser
DEBUG - 2016-09-26 09:06:08 --> Total execution time: 0.0677
INFO - 2016-09-26 09:07:22 --> Config Class Initialized
INFO - 2016-09-26 09:07:22 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:07:22 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:07:22 --> Utf8 Class Initialized
INFO - 2016-09-26 09:07:22 --> URI Class Initialized
INFO - 2016-09-26 09:07:22 --> Router Class Initialized
INFO - 2016-09-26 09:07:22 --> Output Class Initialized
INFO - 2016-09-26 09:07:22 --> Security Class Initialized
DEBUG - 2016-09-26 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:07:22 --> Input Class Initialized
INFO - 2016-09-26 09:07:22 --> Language Class Initialized
INFO - 2016-09-26 09:07:22 --> Loader Class Initialized
INFO - 2016-09-26 09:07:22 --> Helper loaded: url_helper
INFO - 2016-09-26 09:07:22 --> Helper loaded: language_helper
INFO - 2016-09-26 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:07:22 --> Controller Class Initialized
INFO - 2016-09-26 09:07:22 --> Database Driver Class Initialized
INFO - 2016-09-26 09:07:22 --> Model Class Initialized
INFO - 2016-09-26 09:07:22 --> Model Class Initialized
INFO - 2016-09-26 09:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:07:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:07:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-09-26 09:07:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:07:22 --> Final output sent to browser
DEBUG - 2016-09-26 09:07:22 --> Total execution time: 0.0663
INFO - 2016-09-26 09:07:25 --> Config Class Initialized
INFO - 2016-09-26 09:07:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:07:25 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:07:25 --> Utf8 Class Initialized
INFO - 2016-09-26 09:07:25 --> URI Class Initialized
INFO - 2016-09-26 09:07:25 --> Router Class Initialized
INFO - 2016-09-26 09:07:25 --> Output Class Initialized
INFO - 2016-09-26 09:07:25 --> Security Class Initialized
DEBUG - 2016-09-26 09:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:07:25 --> Input Class Initialized
INFO - 2016-09-26 09:07:25 --> Language Class Initialized
INFO - 2016-09-26 09:07:25 --> Loader Class Initialized
INFO - 2016-09-26 09:07:25 --> Helper loaded: url_helper
INFO - 2016-09-26 09:07:25 --> Helper loaded: language_helper
INFO - 2016-09-26 09:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:07:25 --> Controller Class Initialized
INFO - 2016-09-26 09:07:25 --> Database Driver Class Initialized
INFO - 2016-09-26 09:07:25 --> Model Class Initialized
INFO - 2016-09-26 09:07:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:07:25 --> Helper loaded: form_helper
INFO - 2016-09-26 09:07:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:07:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:07:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:07:25 --> Final output sent to browser
DEBUG - 2016-09-26 09:07:25 --> Total execution time: 0.0805
INFO - 2016-09-26 09:07:50 --> Config Class Initialized
INFO - 2016-09-26 09:07:50 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:07:50 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:07:50 --> Utf8 Class Initialized
INFO - 2016-09-26 09:07:50 --> URI Class Initialized
INFO - 2016-09-26 09:07:50 --> Router Class Initialized
INFO - 2016-09-26 09:07:50 --> Output Class Initialized
INFO - 2016-09-26 09:07:50 --> Security Class Initialized
DEBUG - 2016-09-26 09:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:07:50 --> Input Class Initialized
INFO - 2016-09-26 09:07:50 --> Language Class Initialized
INFO - 2016-09-26 09:07:50 --> Loader Class Initialized
INFO - 2016-09-26 09:07:50 --> Helper loaded: url_helper
INFO - 2016-09-26 09:07:50 --> Helper loaded: language_helper
INFO - 2016-09-26 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:07:51 --> Controller Class Initialized
INFO - 2016-09-26 09:07:51 --> Database Driver Class Initialized
INFO - 2016-09-26 09:07:51 --> Model Class Initialized
INFO - 2016-09-26 09:07:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:07:51 --> Helper loaded: form_helper
INFO - 2016-09-26 09:07:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:07:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:07:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:07:51 --> Final output sent to browser
DEBUG - 2016-09-26 09:07:51 --> Total execution time: 0.0769
INFO - 2016-09-26 09:08:08 --> Config Class Initialized
INFO - 2016-09-26 09:08:08 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:08:08 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:08:08 --> Utf8 Class Initialized
INFO - 2016-09-26 09:08:08 --> URI Class Initialized
INFO - 2016-09-26 09:08:08 --> Router Class Initialized
INFO - 2016-09-26 09:08:08 --> Output Class Initialized
INFO - 2016-09-26 09:08:08 --> Security Class Initialized
DEBUG - 2016-09-26 09:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:08:08 --> Input Class Initialized
INFO - 2016-09-26 09:08:08 --> Language Class Initialized
INFO - 2016-09-26 09:08:08 --> Loader Class Initialized
INFO - 2016-09-26 09:08:08 --> Helper loaded: url_helper
INFO - 2016-09-26 09:08:08 --> Helper loaded: language_helper
INFO - 2016-09-26 09:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:08:08 --> Controller Class Initialized
INFO - 2016-09-26 09:08:08 --> Database Driver Class Initialized
INFO - 2016-09-26 09:08:08 --> Model Class Initialized
INFO - 2016-09-26 09:08:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:08:08 --> Helper loaded: form_helper
INFO - 2016-09-26 09:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:08:08 --> Final output sent to browser
DEBUG - 2016-09-26 09:08:08 --> Total execution time: 0.0704
INFO - 2016-09-26 09:09:41 --> Config Class Initialized
INFO - 2016-09-26 09:09:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:09:41 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:09:41 --> Utf8 Class Initialized
INFO - 2016-09-26 09:09:41 --> URI Class Initialized
INFO - 2016-09-26 09:09:41 --> Router Class Initialized
INFO - 2016-09-26 09:09:41 --> Output Class Initialized
INFO - 2016-09-26 09:09:41 --> Security Class Initialized
DEBUG - 2016-09-26 09:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:09:41 --> Input Class Initialized
INFO - 2016-09-26 09:09:41 --> Language Class Initialized
INFO - 2016-09-26 09:09:41 --> Loader Class Initialized
INFO - 2016-09-26 09:09:41 --> Helper loaded: url_helper
INFO - 2016-09-26 09:09:41 --> Helper loaded: language_helper
INFO - 2016-09-26 09:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:09:41 --> Controller Class Initialized
INFO - 2016-09-26 09:09:41 --> Database Driver Class Initialized
INFO - 2016-09-26 09:09:41 --> Model Class Initialized
INFO - 2016-09-26 09:09:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:09:41 --> Helper loaded: form_helper
INFO - 2016-09-26 09:09:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:09:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:09:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:09:41 --> Final output sent to browser
DEBUG - 2016-09-26 09:09:41 --> Total execution time: 0.0791
INFO - 2016-09-26 09:10:19 --> Config Class Initialized
INFO - 2016-09-26 09:10:19 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:10:19 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:10:19 --> Utf8 Class Initialized
INFO - 2016-09-26 09:10:19 --> URI Class Initialized
INFO - 2016-09-26 09:10:19 --> Router Class Initialized
INFO - 2016-09-26 09:10:19 --> Output Class Initialized
INFO - 2016-09-26 09:10:19 --> Security Class Initialized
DEBUG - 2016-09-26 09:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:10:19 --> Input Class Initialized
INFO - 2016-09-26 09:10:19 --> Language Class Initialized
INFO - 2016-09-26 09:10:19 --> Loader Class Initialized
INFO - 2016-09-26 09:10:19 --> Helper loaded: url_helper
INFO - 2016-09-26 09:10:19 --> Helper loaded: language_helper
INFO - 2016-09-26 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:10:19 --> Controller Class Initialized
INFO - 2016-09-26 09:10:19 --> Database Driver Class Initialized
INFO - 2016-09-26 09:10:19 --> Model Class Initialized
INFO - 2016-09-26 09:10:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:10:19 --> Helper loaded: form_helper
INFO - 2016-09-26 09:10:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:10:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:10:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:10:19 --> Final output sent to browser
DEBUG - 2016-09-26 09:10:19 --> Total execution time: 0.0655
INFO - 2016-09-26 09:11:14 --> Config Class Initialized
INFO - 2016-09-26 09:11:14 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:11:14 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:11:14 --> Utf8 Class Initialized
INFO - 2016-09-26 09:11:14 --> URI Class Initialized
INFO - 2016-09-26 09:11:14 --> Router Class Initialized
INFO - 2016-09-26 09:11:14 --> Output Class Initialized
INFO - 2016-09-26 09:11:14 --> Security Class Initialized
DEBUG - 2016-09-26 09:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:11:14 --> Input Class Initialized
INFO - 2016-09-26 09:11:14 --> Language Class Initialized
INFO - 2016-09-26 09:11:14 --> Loader Class Initialized
INFO - 2016-09-26 09:11:14 --> Helper loaded: url_helper
INFO - 2016-09-26 09:11:14 --> Helper loaded: language_helper
INFO - 2016-09-26 09:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:11:15 --> Controller Class Initialized
INFO - 2016-09-26 09:11:15 --> Database Driver Class Initialized
INFO - 2016-09-26 09:11:15 --> Model Class Initialized
INFO - 2016-09-26 09:11:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:11:15 --> Helper loaded: form_helper
INFO - 2016-09-26 09:11:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:11:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:11:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:11:15 --> Final output sent to browser
DEBUG - 2016-09-26 09:11:15 --> Total execution time: 0.0661
INFO - 2016-09-26 09:12:27 --> Config Class Initialized
INFO - 2016-09-26 09:12:27 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:12:27 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:12:27 --> Utf8 Class Initialized
INFO - 2016-09-26 09:12:27 --> URI Class Initialized
INFO - 2016-09-26 09:12:27 --> Router Class Initialized
INFO - 2016-09-26 09:12:27 --> Output Class Initialized
INFO - 2016-09-26 09:12:27 --> Security Class Initialized
DEBUG - 2016-09-26 09:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:12:27 --> Input Class Initialized
INFO - 2016-09-26 09:12:27 --> Language Class Initialized
INFO - 2016-09-26 09:12:27 --> Loader Class Initialized
INFO - 2016-09-26 09:12:27 --> Helper loaded: url_helper
INFO - 2016-09-26 09:12:27 --> Helper loaded: language_helper
INFO - 2016-09-26 09:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:12:27 --> Controller Class Initialized
INFO - 2016-09-26 09:12:27 --> Database Driver Class Initialized
INFO - 2016-09-26 09:12:27 --> Model Class Initialized
INFO - 2016-09-26 09:12:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:12:27 --> Helper loaded: form_helper
INFO - 2016-09-26 09:12:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:12:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:12:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:12:27 --> Final output sent to browser
DEBUG - 2016-09-26 09:12:27 --> Total execution time: 0.0652
INFO - 2016-09-26 09:16:14 --> Config Class Initialized
INFO - 2016-09-26 09:16:14 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:16:14 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:16:14 --> Utf8 Class Initialized
INFO - 2016-09-26 09:16:14 --> URI Class Initialized
INFO - 2016-09-26 09:16:14 --> Router Class Initialized
INFO - 2016-09-26 09:16:14 --> Output Class Initialized
INFO - 2016-09-26 09:16:14 --> Security Class Initialized
DEBUG - 2016-09-26 09:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:16:14 --> Input Class Initialized
INFO - 2016-09-26 09:16:14 --> Language Class Initialized
INFO - 2016-09-26 09:16:14 --> Loader Class Initialized
INFO - 2016-09-26 09:16:14 --> Helper loaded: url_helper
INFO - 2016-09-26 09:16:14 --> Helper loaded: language_helper
INFO - 2016-09-26 09:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:16:14 --> Controller Class Initialized
INFO - 2016-09-26 09:16:14 --> Database Driver Class Initialized
INFO - 2016-09-26 09:16:14 --> Model Class Initialized
INFO - 2016-09-26 09:16:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:16:14 --> Helper loaded: form_helper
INFO - 2016-09-26 09:16:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:16:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:16:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:16:14 --> Final output sent to browser
DEBUG - 2016-09-26 09:16:14 --> Total execution time: 0.0777
INFO - 2016-09-26 09:17:41 --> Config Class Initialized
INFO - 2016-09-26 09:17:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:17:41 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:17:41 --> Utf8 Class Initialized
INFO - 2016-09-26 09:17:41 --> URI Class Initialized
INFO - 2016-09-26 09:17:41 --> Router Class Initialized
INFO - 2016-09-26 09:17:41 --> Output Class Initialized
INFO - 2016-09-26 09:17:41 --> Security Class Initialized
DEBUG - 2016-09-26 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:17:41 --> Input Class Initialized
INFO - 2016-09-26 09:17:41 --> Language Class Initialized
INFO - 2016-09-26 09:17:41 --> Loader Class Initialized
INFO - 2016-09-26 09:17:41 --> Helper loaded: url_helper
INFO - 2016-09-26 09:17:41 --> Helper loaded: language_helper
INFO - 2016-09-26 09:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:17:41 --> Controller Class Initialized
INFO - 2016-09-26 09:17:41 --> Database Driver Class Initialized
INFO - 2016-09-26 09:17:41 --> Model Class Initialized
INFO - 2016-09-26 09:17:41 --> Model Class Initialized
INFO - 2016-09-26 09:17:41 --> Model Class Initialized
INFO - 2016-09-26 09:17:41 --> Model Class Initialized
INFO - 2016-09-26 09:17:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:17:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:17:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-26 09:17:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:17:41 --> Final output sent to browser
DEBUG - 2016-09-26 09:17:41 --> Total execution time: 0.0674
INFO - 2016-09-26 09:18:05 --> Config Class Initialized
INFO - 2016-09-26 09:18:05 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:18:05 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:18:05 --> Utf8 Class Initialized
INFO - 2016-09-26 09:18:05 --> URI Class Initialized
INFO - 2016-09-26 09:18:05 --> Router Class Initialized
INFO - 2016-09-26 09:18:05 --> Output Class Initialized
INFO - 2016-09-26 09:18:05 --> Security Class Initialized
DEBUG - 2016-09-26 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:18:05 --> Input Class Initialized
INFO - 2016-09-26 09:18:05 --> Language Class Initialized
INFO - 2016-09-26 09:18:05 --> Loader Class Initialized
INFO - 2016-09-26 09:18:05 --> Helper loaded: url_helper
INFO - 2016-09-26 09:18:05 --> Helper loaded: language_helper
INFO - 2016-09-26 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:18:05 --> Controller Class Initialized
INFO - 2016-09-26 09:18:05 --> Database Driver Class Initialized
INFO - 2016-09-26 09:18:05 --> Model Class Initialized
INFO - 2016-09-26 09:18:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:18:05 --> Helper loaded: form_helper
INFO - 2016-09-26 09:18:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:18:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:18:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:18:05 --> Final output sent to browser
DEBUG - 2016-09-26 09:18:05 --> Total execution time: 0.0640
INFO - 2016-09-26 09:18:42 --> Config Class Initialized
INFO - 2016-09-26 09:18:42 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:18:42 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:18:42 --> Utf8 Class Initialized
INFO - 2016-09-26 09:18:42 --> URI Class Initialized
INFO - 2016-09-26 09:18:42 --> Router Class Initialized
INFO - 2016-09-26 09:18:42 --> Output Class Initialized
INFO - 2016-09-26 09:18:42 --> Security Class Initialized
DEBUG - 2016-09-26 09:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:18:42 --> Input Class Initialized
INFO - 2016-09-26 09:18:42 --> Language Class Initialized
INFO - 2016-09-26 09:18:42 --> Loader Class Initialized
INFO - 2016-09-26 09:18:42 --> Helper loaded: url_helper
INFO - 2016-09-26 09:18:42 --> Helper loaded: language_helper
INFO - 2016-09-26 09:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:18:42 --> Controller Class Initialized
INFO - 2016-09-26 09:18:42 --> Database Driver Class Initialized
INFO - 2016-09-26 09:18:42 --> Model Class Initialized
INFO - 2016-09-26 09:18:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:18:42 --> Helper loaded: form_helper
INFO - 2016-09-26 09:18:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:18:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:18:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:18:42 --> Final output sent to browser
DEBUG - 2016-09-26 09:18:42 --> Total execution time: 0.0672
INFO - 2016-09-26 09:19:36 --> Config Class Initialized
INFO - 2016-09-26 09:19:36 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:19:36 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:19:36 --> Utf8 Class Initialized
INFO - 2016-09-26 09:19:36 --> URI Class Initialized
INFO - 2016-09-26 09:19:36 --> Router Class Initialized
INFO - 2016-09-26 09:19:36 --> Output Class Initialized
INFO - 2016-09-26 09:19:36 --> Security Class Initialized
DEBUG - 2016-09-26 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:19:36 --> Input Class Initialized
INFO - 2016-09-26 09:19:36 --> Language Class Initialized
INFO - 2016-09-26 09:19:36 --> Loader Class Initialized
INFO - 2016-09-26 09:19:36 --> Helper loaded: url_helper
INFO - 2016-09-26 09:19:36 --> Helper loaded: language_helper
INFO - 2016-09-26 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:19:36 --> Controller Class Initialized
INFO - 2016-09-26 09:19:36 --> Database Driver Class Initialized
INFO - 2016-09-26 09:19:36 --> Model Class Initialized
INFO - 2016-09-26 09:19:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:19:36 --> Helper loaded: form_helper
INFO - 2016-09-26 09:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:19:36 --> Final output sent to browser
DEBUG - 2016-09-26 09:19:36 --> Total execution time: 0.0640
INFO - 2016-09-26 09:19:53 --> Config Class Initialized
INFO - 2016-09-26 09:19:53 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:19:53 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:19:53 --> Utf8 Class Initialized
INFO - 2016-09-26 09:19:53 --> URI Class Initialized
INFO - 2016-09-26 09:19:53 --> Router Class Initialized
INFO - 2016-09-26 09:19:53 --> Output Class Initialized
INFO - 2016-09-26 09:19:53 --> Security Class Initialized
DEBUG - 2016-09-26 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:19:53 --> Input Class Initialized
INFO - 2016-09-26 09:19:53 --> Language Class Initialized
INFO - 2016-09-26 09:19:53 --> Loader Class Initialized
INFO - 2016-09-26 09:19:53 --> Helper loaded: url_helper
INFO - 2016-09-26 09:19:53 --> Helper loaded: language_helper
INFO - 2016-09-26 09:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:19:53 --> Controller Class Initialized
INFO - 2016-09-26 09:19:53 --> Database Driver Class Initialized
INFO - 2016-09-26 09:19:53 --> Model Class Initialized
INFO - 2016-09-26 09:19:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:19:53 --> Helper loaded: form_helper
INFO - 2016-09-26 09:19:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:19:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:19:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:19:53 --> Final output sent to browser
DEBUG - 2016-09-26 09:19:53 --> Total execution time: 0.0640
INFO - 2016-09-26 09:23:45 --> Config Class Initialized
INFO - 2016-09-26 09:23:45 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:23:45 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:23:45 --> Utf8 Class Initialized
INFO - 2016-09-26 09:23:45 --> URI Class Initialized
INFO - 2016-09-26 09:23:45 --> Router Class Initialized
INFO - 2016-09-26 09:23:45 --> Output Class Initialized
INFO - 2016-09-26 09:23:45 --> Security Class Initialized
DEBUG - 2016-09-26 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:23:45 --> Input Class Initialized
INFO - 2016-09-26 09:23:45 --> Language Class Initialized
INFO - 2016-09-26 09:23:45 --> Loader Class Initialized
INFO - 2016-09-26 09:23:45 --> Helper loaded: url_helper
INFO - 2016-09-26 09:23:45 --> Helper loaded: language_helper
INFO - 2016-09-26 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:23:45 --> Controller Class Initialized
INFO - 2016-09-26 09:23:45 --> Database Driver Class Initialized
INFO - 2016-09-26 09:23:45 --> Model Class Initialized
INFO - 2016-09-26 09:23:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:23:45 --> Helper loaded: form_helper
INFO - 2016-09-26 09:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:23:45 --> Final output sent to browser
DEBUG - 2016-09-26 09:23:45 --> Total execution time: 0.0753
INFO - 2016-09-26 09:24:01 --> Config Class Initialized
INFO - 2016-09-26 09:24:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:24:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:24:01 --> Utf8 Class Initialized
INFO - 2016-09-26 09:24:01 --> URI Class Initialized
INFO - 2016-09-26 09:24:01 --> Router Class Initialized
INFO - 2016-09-26 09:24:01 --> Output Class Initialized
INFO - 2016-09-26 09:24:01 --> Security Class Initialized
DEBUG - 2016-09-26 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:24:01 --> Input Class Initialized
INFO - 2016-09-26 09:24:01 --> Language Class Initialized
INFO - 2016-09-26 09:24:01 --> Loader Class Initialized
INFO - 2016-09-26 09:24:01 --> Helper loaded: url_helper
INFO - 2016-09-26 09:24:01 --> Helper loaded: language_helper
INFO - 2016-09-26 09:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:24:01 --> Controller Class Initialized
INFO - 2016-09-26 09:24:01 --> Database Driver Class Initialized
INFO - 2016-09-26 09:24:01 --> Model Class Initialized
INFO - 2016-09-26 09:24:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:24:01 --> Helper loaded: form_helper
INFO - 2016-09-26 09:24:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:24:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:24:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:24:01 --> Final output sent to browser
DEBUG - 2016-09-26 09:24:01 --> Total execution time: 0.0651
INFO - 2016-09-26 09:24:28 --> Config Class Initialized
INFO - 2016-09-26 09:24:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:24:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:24:28 --> Utf8 Class Initialized
INFO - 2016-09-26 09:24:28 --> URI Class Initialized
INFO - 2016-09-26 09:24:28 --> Router Class Initialized
INFO - 2016-09-26 09:24:28 --> Output Class Initialized
INFO - 2016-09-26 09:24:28 --> Security Class Initialized
DEBUG - 2016-09-26 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:24:28 --> Input Class Initialized
INFO - 2016-09-26 09:24:28 --> Language Class Initialized
INFO - 2016-09-26 09:24:28 --> Loader Class Initialized
INFO - 2016-09-26 09:24:28 --> Helper loaded: url_helper
INFO - 2016-09-26 09:24:28 --> Helper loaded: language_helper
INFO - 2016-09-26 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:24:28 --> Controller Class Initialized
INFO - 2016-09-26 09:24:28 --> Database Driver Class Initialized
INFO - 2016-09-26 09:24:28 --> Model Class Initialized
INFO - 2016-09-26 09:24:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:24:28 --> Helper loaded: form_helper
INFO - 2016-09-26 09:24:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:24:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:24:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:24:28 --> Final output sent to browser
DEBUG - 2016-09-26 09:24:28 --> Total execution time: 0.0690
INFO - 2016-09-26 09:25:21 --> Config Class Initialized
INFO - 2016-09-26 09:25:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 09:25:21 --> UTF-8 Support Enabled
INFO - 2016-09-26 09:25:21 --> Utf8 Class Initialized
INFO - 2016-09-26 09:25:21 --> URI Class Initialized
INFO - 2016-09-26 09:25:21 --> Router Class Initialized
INFO - 2016-09-26 09:25:21 --> Output Class Initialized
INFO - 2016-09-26 09:25:21 --> Security Class Initialized
DEBUG - 2016-09-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 09:25:21 --> Input Class Initialized
INFO - 2016-09-26 09:25:21 --> Language Class Initialized
INFO - 2016-09-26 09:25:21 --> Loader Class Initialized
INFO - 2016-09-26 09:25:21 --> Helper loaded: url_helper
INFO - 2016-09-26 09:25:21 --> Helper loaded: language_helper
INFO - 2016-09-26 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 09:25:21 --> Controller Class Initialized
INFO - 2016-09-26 09:25:21 --> Database Driver Class Initialized
INFO - 2016-09-26 09:25:21 --> Model Class Initialized
INFO - 2016-09-26 09:25:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 09:25:21 --> Helper loaded: form_helper
INFO - 2016-09-26 09:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 09:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 09:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 09:25:21 --> Final output sent to browser
DEBUG - 2016-09-26 09:25:21 --> Total execution time: 0.0654
INFO - 2016-09-26 10:03:41 --> Config Class Initialized
INFO - 2016-09-26 10:03:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:03:41 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:03:41 --> Utf8 Class Initialized
INFO - 2016-09-26 10:03:41 --> URI Class Initialized
INFO - 2016-09-26 10:03:41 --> Router Class Initialized
INFO - 2016-09-26 10:03:41 --> Output Class Initialized
INFO - 2016-09-26 10:03:41 --> Security Class Initialized
DEBUG - 2016-09-26 10:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:03:41 --> Input Class Initialized
INFO - 2016-09-26 10:03:41 --> Language Class Initialized
INFO - 2016-09-26 10:03:41 --> Loader Class Initialized
INFO - 2016-09-26 10:03:41 --> Helper loaded: url_helper
INFO - 2016-09-26 10:03:41 --> Helper loaded: language_helper
INFO - 2016-09-26 10:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:03:41 --> Controller Class Initialized
INFO - 2016-09-26 10:03:41 --> Database Driver Class Initialized
INFO - 2016-09-26 10:03:41 --> Model Class Initialized
INFO - 2016-09-26 10:03:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 10:03:41 --> Helper loaded: form_helper
INFO - 2016-09-26 10:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 10:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 10:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 10:03:41 --> Final output sent to browser
DEBUG - 2016-09-26 10:03:41 --> Total execution time: 0.1256
INFO - 2016-09-26 10:04:30 --> Config Class Initialized
INFO - 2016-09-26 10:04:30 --> Hooks Class Initialized
DEBUG - 2016-09-26 10:04:30 --> UTF-8 Support Enabled
INFO - 2016-09-26 10:04:30 --> Utf8 Class Initialized
INFO - 2016-09-26 10:04:30 --> URI Class Initialized
INFO - 2016-09-26 10:04:30 --> Router Class Initialized
INFO - 2016-09-26 10:04:30 --> Output Class Initialized
INFO - 2016-09-26 10:04:30 --> Security Class Initialized
DEBUG - 2016-09-26 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 10:04:30 --> Input Class Initialized
INFO - 2016-09-26 10:04:30 --> Language Class Initialized
INFO - 2016-09-26 10:04:30 --> Loader Class Initialized
INFO - 2016-09-26 10:04:30 --> Helper loaded: url_helper
INFO - 2016-09-26 10:04:30 --> Helper loaded: language_helper
INFO - 2016-09-26 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 10:04:30 --> Controller Class Initialized
INFO - 2016-09-26 10:04:30 --> Database Driver Class Initialized
INFO - 2016-09-26 10:04:30 --> Model Class Initialized
INFO - 2016-09-26 10:04:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 10:04:30 --> Helper loaded: form_helper
INFO - 2016-09-26 10:04:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 10:04:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 10:04:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 10:04:30 --> Final output sent to browser
DEBUG - 2016-09-26 10:04:30 --> Total execution time: 0.0765
INFO - 2016-09-26 11:35:00 --> Config Class Initialized
INFO - 2016-09-26 11:35:00 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:35:00 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:35:00 --> Utf8 Class Initialized
INFO - 2016-09-26 11:35:00 --> URI Class Initialized
INFO - 2016-09-26 11:35:00 --> Router Class Initialized
INFO - 2016-09-26 11:35:00 --> Output Class Initialized
INFO - 2016-09-26 11:35:00 --> Security Class Initialized
DEBUG - 2016-09-26 11:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:35:00 --> Input Class Initialized
INFO - 2016-09-26 11:35:00 --> Language Class Initialized
INFO - 2016-09-26 11:35:00 --> Loader Class Initialized
INFO - 2016-09-26 11:35:00 --> Helper loaded: url_helper
INFO - 2016-09-26 11:35:00 --> Helper loaded: language_helper
INFO - 2016-09-26 11:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:35:00 --> Controller Class Initialized
INFO - 2016-09-26 11:35:00 --> Database Driver Class Initialized
INFO - 2016-09-26 11:35:00 --> Model Class Initialized
INFO - 2016-09-26 11:35:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 11:35:00 --> Helper loaded: form_helper
INFO - 2016-09-26 11:35:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 11:35:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 11:35:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 11:35:00 --> Final output sent to browser
DEBUG - 2016-09-26 11:35:00 --> Total execution time: 0.1387
INFO - 2016-09-26 11:37:26 --> Config Class Initialized
INFO - 2016-09-26 11:37:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:37:26 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:37:26 --> Utf8 Class Initialized
INFO - 2016-09-26 11:37:26 --> URI Class Initialized
INFO - 2016-09-26 11:37:26 --> Router Class Initialized
INFO - 2016-09-26 11:37:26 --> Output Class Initialized
INFO - 2016-09-26 11:37:26 --> Security Class Initialized
DEBUG - 2016-09-26 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:37:26 --> Input Class Initialized
INFO - 2016-09-26 11:37:26 --> Language Class Initialized
INFO - 2016-09-26 11:37:26 --> Loader Class Initialized
INFO - 2016-09-26 11:37:26 --> Helper loaded: url_helper
INFO - 2016-09-26 11:37:26 --> Helper loaded: language_helper
INFO - 2016-09-26 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:37:26 --> Controller Class Initialized
INFO - 2016-09-26 11:37:26 --> Database Driver Class Initialized
INFO - 2016-09-26 11:37:26 --> Model Class Initialized
INFO - 2016-09-26 11:37:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 11:37:26 --> Helper loaded: form_helper
INFO - 2016-09-26 11:37:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 11:37:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 11:37:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 11:37:26 --> Final output sent to browser
DEBUG - 2016-09-26 11:37:26 --> Total execution time: 0.1012
INFO - 2016-09-26 11:38:45 --> Config Class Initialized
INFO - 2016-09-26 11:38:45 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:38:45 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:38:45 --> Utf8 Class Initialized
INFO - 2016-09-26 11:38:45 --> URI Class Initialized
INFO - 2016-09-26 11:38:45 --> Router Class Initialized
INFO - 2016-09-26 11:38:45 --> Output Class Initialized
INFO - 2016-09-26 11:38:45 --> Security Class Initialized
DEBUG - 2016-09-26 11:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:38:45 --> Input Class Initialized
INFO - 2016-09-26 11:38:45 --> Language Class Initialized
INFO - 2016-09-26 11:38:45 --> Loader Class Initialized
INFO - 2016-09-26 11:38:45 --> Helper loaded: url_helper
INFO - 2016-09-26 11:38:45 --> Helper loaded: language_helper
INFO - 2016-09-26 11:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:38:45 --> Controller Class Initialized
INFO - 2016-09-26 11:38:45 --> Database Driver Class Initialized
INFO - 2016-09-26 11:38:45 --> Model Class Initialized
INFO - 2016-09-26 11:38:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 11:38:45 --> Helper loaded: form_helper
INFO - 2016-09-26 11:38:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 11:38:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 11:38:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 11:38:45 --> Final output sent to browser
DEBUG - 2016-09-26 11:38:45 --> Total execution time: 0.0710
INFO - 2016-09-26 11:39:03 --> Config Class Initialized
INFO - 2016-09-26 11:39:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 11:39:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 11:39:03 --> Utf8 Class Initialized
INFO - 2016-09-26 11:39:03 --> URI Class Initialized
INFO - 2016-09-26 11:39:03 --> Router Class Initialized
INFO - 2016-09-26 11:39:03 --> Output Class Initialized
INFO - 2016-09-26 11:39:03 --> Security Class Initialized
DEBUG - 2016-09-26 11:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 11:39:03 --> Input Class Initialized
INFO - 2016-09-26 11:39:03 --> Language Class Initialized
INFO - 2016-09-26 11:39:03 --> Loader Class Initialized
INFO - 2016-09-26 11:39:03 --> Helper loaded: url_helper
INFO - 2016-09-26 11:39:03 --> Helper loaded: language_helper
INFO - 2016-09-26 11:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 11:39:03 --> Controller Class Initialized
INFO - 2016-09-26 11:39:03 --> Database Driver Class Initialized
INFO - 2016-09-26 11:39:03 --> Model Class Initialized
INFO - 2016-09-26 11:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 11:39:03 --> Helper loaded: form_helper
INFO - 2016-09-26 11:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 11:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 11:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 11:39:03 --> Final output sent to browser
DEBUG - 2016-09-26 11:39:03 --> Total execution time: 0.0803
INFO - 2016-09-26 15:22:10 --> Config Class Initialized
INFO - 2016-09-26 15:22:10 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:22:10 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:22:10 --> Utf8 Class Initialized
INFO - 2016-09-26 15:22:10 --> URI Class Initialized
INFO - 2016-09-26 15:22:10 --> Router Class Initialized
INFO - 2016-09-26 15:22:10 --> Output Class Initialized
INFO - 2016-09-26 15:22:10 --> Security Class Initialized
DEBUG - 2016-09-26 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:22:10 --> Input Class Initialized
INFO - 2016-09-26 15:22:10 --> Language Class Initialized
INFO - 2016-09-26 15:22:10 --> Loader Class Initialized
INFO - 2016-09-26 15:22:10 --> Helper loaded: url_helper
INFO - 2016-09-26 15:22:10 --> Helper loaded: language_helper
INFO - 2016-09-26 15:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:22:10 --> Controller Class Initialized
INFO - 2016-09-26 15:22:10 --> Database Driver Class Initialized
INFO - 2016-09-26 15:22:10 --> Model Class Initialized
INFO - 2016-09-26 15:22:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:22:10 --> Config Class Initialized
INFO - 2016-09-26 15:22:10 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:22:10 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:22:10 --> Utf8 Class Initialized
INFO - 2016-09-26 15:22:10 --> URI Class Initialized
INFO - 2016-09-26 15:22:10 --> Router Class Initialized
INFO - 2016-09-26 15:22:10 --> Output Class Initialized
INFO - 2016-09-26 15:22:10 --> Security Class Initialized
DEBUG - 2016-09-26 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:22:10 --> Input Class Initialized
INFO - 2016-09-26 15:22:10 --> Language Class Initialized
INFO - 2016-09-26 15:22:10 --> Loader Class Initialized
INFO - 2016-09-26 15:22:10 --> Helper loaded: url_helper
INFO - 2016-09-26 15:22:10 --> Helper loaded: language_helper
INFO - 2016-09-26 15:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:22:10 --> Controller Class Initialized
INFO - 2016-09-26 15:22:10 --> Database Driver Class Initialized
INFO - 2016-09-26 15:22:10 --> Model Class Initialized
INFO - 2016-09-26 15:22:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-26 15:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-26 15:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-26 15:22:10 --> Final output sent to browser
DEBUG - 2016-09-26 15:22:10 --> Total execution time: 0.0607
INFO - 2016-09-26 15:22:15 --> Config Class Initialized
INFO - 2016-09-26 15:22:15 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:22:15 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:22:15 --> Utf8 Class Initialized
INFO - 2016-09-26 15:22:15 --> URI Class Initialized
INFO - 2016-09-26 15:22:15 --> Router Class Initialized
INFO - 2016-09-26 15:22:15 --> Output Class Initialized
INFO - 2016-09-26 15:22:15 --> Security Class Initialized
DEBUG - 2016-09-26 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:22:15 --> Input Class Initialized
INFO - 2016-09-26 15:22:15 --> Language Class Initialized
INFO - 2016-09-26 15:22:15 --> Loader Class Initialized
INFO - 2016-09-26 15:22:15 --> Helper loaded: url_helper
INFO - 2016-09-26 15:22:15 --> Helper loaded: language_helper
INFO - 2016-09-26 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:22:15 --> Controller Class Initialized
INFO - 2016-09-26 15:22:15 --> Database Driver Class Initialized
INFO - 2016-09-26 15:22:15 --> Model Class Initialized
INFO - 2016-09-26 15:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:22:15 --> Config Class Initialized
INFO - 2016-09-26 15:22:15 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:22:15 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:22:15 --> Utf8 Class Initialized
INFO - 2016-09-26 15:22:15 --> URI Class Initialized
INFO - 2016-09-26 15:22:15 --> Router Class Initialized
INFO - 2016-09-26 15:22:15 --> Output Class Initialized
INFO - 2016-09-26 15:22:15 --> Security Class Initialized
DEBUG - 2016-09-26 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:22:15 --> Input Class Initialized
INFO - 2016-09-26 15:22:15 --> Language Class Initialized
INFO - 2016-09-26 15:22:15 --> Loader Class Initialized
INFO - 2016-09-26 15:22:15 --> Helper loaded: url_helper
INFO - 2016-09-26 15:22:15 --> Helper loaded: language_helper
INFO - 2016-09-26 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:22:15 --> Controller Class Initialized
INFO - 2016-09-26 15:22:15 --> Database Driver Class Initialized
INFO - 2016-09-26 15:22:15 --> Model Class Initialized
INFO - 2016-09-26 15:22:15 --> Model Class Initialized
INFO - 2016-09-26 15:22:15 --> Model Class Initialized
INFO - 2016-09-26 15:22:15 --> Model Class Initialized
INFO - 2016-09-26 15:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-26 15:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:22:15 --> Final output sent to browser
DEBUG - 2016-09-26 15:22:15 --> Total execution time: 0.0753
INFO - 2016-09-26 15:22:17 --> Config Class Initialized
INFO - 2016-09-26 15:22:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:22:17 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:22:17 --> Utf8 Class Initialized
INFO - 2016-09-26 15:22:17 --> URI Class Initialized
INFO - 2016-09-26 15:22:17 --> Router Class Initialized
INFO - 2016-09-26 15:22:17 --> Output Class Initialized
INFO - 2016-09-26 15:22:17 --> Security Class Initialized
DEBUG - 2016-09-26 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:22:17 --> Input Class Initialized
INFO - 2016-09-26 15:22:17 --> Language Class Initialized
INFO - 2016-09-26 15:22:17 --> Loader Class Initialized
INFO - 2016-09-26 15:22:17 --> Helper loaded: url_helper
INFO - 2016-09-26 15:22:17 --> Helper loaded: language_helper
INFO - 2016-09-26 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:22:17 --> Controller Class Initialized
INFO - 2016-09-26 15:22:17 --> Database Driver Class Initialized
INFO - 2016-09-26 15:22:17 --> Model Class Initialized
INFO - 2016-09-26 15:22:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:22:17 --> Helper loaded: form_helper
INFO - 2016-09-26 15:22:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:22:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 15:22:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:22:17 --> Final output sent to browser
DEBUG - 2016-09-26 15:22:17 --> Total execution time: 0.0649
INFO - 2016-09-26 15:22:22 --> Config Class Initialized
INFO - 2016-09-26 15:22:22 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:22:22 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:22:22 --> Utf8 Class Initialized
INFO - 2016-09-26 15:22:22 --> URI Class Initialized
INFO - 2016-09-26 15:22:22 --> Router Class Initialized
INFO - 2016-09-26 15:22:22 --> Output Class Initialized
INFO - 2016-09-26 15:22:22 --> Security Class Initialized
DEBUG - 2016-09-26 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:22:22 --> Input Class Initialized
INFO - 2016-09-26 15:22:22 --> Language Class Initialized
INFO - 2016-09-26 15:22:22 --> Loader Class Initialized
INFO - 2016-09-26 15:22:22 --> Helper loaded: url_helper
INFO - 2016-09-26 15:22:22 --> Helper loaded: language_helper
INFO - 2016-09-26 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:22:22 --> Controller Class Initialized
INFO - 2016-09-26 15:22:22 --> Database Driver Class Initialized
INFO - 2016-09-26 15:22:22 --> Model Class Initialized
INFO - 2016-09-26 15:22:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:22:22 --> Helper loaded: form_helper
INFO - 2016-09-26 15:22:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:22:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:22:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:22:22 --> Final output sent to browser
DEBUG - 2016-09-26 15:22:22 --> Total execution time: 0.0585
INFO - 2016-09-26 15:23:16 --> Config Class Initialized
INFO - 2016-09-26 15:23:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:23:16 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:23:16 --> Utf8 Class Initialized
INFO - 2016-09-26 15:23:16 --> URI Class Initialized
INFO - 2016-09-26 15:23:16 --> Router Class Initialized
INFO - 2016-09-26 15:23:16 --> Output Class Initialized
INFO - 2016-09-26 15:23:16 --> Security Class Initialized
DEBUG - 2016-09-26 15:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:23:16 --> Input Class Initialized
INFO - 2016-09-26 15:23:16 --> Language Class Initialized
INFO - 2016-09-26 15:23:16 --> Loader Class Initialized
INFO - 2016-09-26 15:23:16 --> Helper loaded: url_helper
INFO - 2016-09-26 15:23:16 --> Helper loaded: language_helper
INFO - 2016-09-26 15:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:23:16 --> Controller Class Initialized
INFO - 2016-09-26 15:23:16 --> Database Driver Class Initialized
INFO - 2016-09-26 15:23:16 --> Model Class Initialized
INFO - 2016-09-26 15:23:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:23:16 --> Helper loaded: form_helper
INFO - 2016-09-26 15:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:23:16 --> Final output sent to browser
DEBUG - 2016-09-26 15:23:16 --> Total execution time: 0.0601
INFO - 2016-09-26 15:25:42 --> Config Class Initialized
INFO - 2016-09-26 15:25:42 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:25:42 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:25:42 --> Utf8 Class Initialized
INFO - 2016-09-26 15:25:42 --> URI Class Initialized
INFO - 2016-09-26 15:25:42 --> Router Class Initialized
INFO - 2016-09-26 15:25:42 --> Output Class Initialized
INFO - 2016-09-26 15:25:42 --> Security Class Initialized
DEBUG - 2016-09-26 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:25:42 --> Input Class Initialized
INFO - 2016-09-26 15:25:42 --> Language Class Initialized
INFO - 2016-09-26 15:25:42 --> Loader Class Initialized
INFO - 2016-09-26 15:25:42 --> Helper loaded: url_helper
INFO - 2016-09-26 15:25:42 --> Helper loaded: language_helper
INFO - 2016-09-26 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:25:42 --> Controller Class Initialized
INFO - 2016-09-26 15:25:42 --> Database Driver Class Initialized
INFO - 2016-09-26 15:25:42 --> Model Class Initialized
INFO - 2016-09-26 15:25:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:25:42 --> Helper loaded: form_helper
INFO - 2016-09-26 15:25:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:25:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:25:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:25:42 --> Final output sent to browser
DEBUG - 2016-09-26 15:25:42 --> Total execution time: 0.0603
INFO - 2016-09-26 15:25:44 --> Config Class Initialized
INFO - 2016-09-26 15:25:44 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:25:44 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:25:44 --> Utf8 Class Initialized
INFO - 2016-09-26 15:25:47 --> Config Class Initialized
INFO - 2016-09-26 15:25:47 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:25:47 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:25:47 --> Utf8 Class Initialized
INFO - 2016-09-26 15:25:47 --> URI Class Initialized
INFO - 2016-09-26 15:25:47 --> Router Class Initialized
INFO - 2016-09-26 15:25:47 --> Output Class Initialized
INFO - 2016-09-26 15:25:47 --> Security Class Initialized
DEBUG - 2016-09-26 15:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:25:47 --> Input Class Initialized
INFO - 2016-09-26 15:25:47 --> Language Class Initialized
INFO - 2016-09-26 15:25:47 --> Loader Class Initialized
INFO - 2016-09-26 15:25:47 --> Helper loaded: url_helper
INFO - 2016-09-26 15:25:47 --> Helper loaded: language_helper
INFO - 2016-09-26 15:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:25:47 --> Controller Class Initialized
INFO - 2016-09-26 15:25:47 --> Database Driver Class Initialized
INFO - 2016-09-26 15:25:47 --> Model Class Initialized
INFO - 2016-09-26 15:25:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:25:47 --> Helper loaded: form_helper
INFO - 2016-09-26 15:25:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:25:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:25:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:25:47 --> Final output sent to browser
DEBUG - 2016-09-26 15:25:47 --> Total execution time: 0.0786
INFO - 2016-09-26 15:26:31 --> Config Class Initialized
INFO - 2016-09-26 15:26:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:26:31 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:26:31 --> Utf8 Class Initialized
INFO - 2016-09-26 15:26:31 --> URI Class Initialized
INFO - 2016-09-26 15:26:31 --> Router Class Initialized
INFO - 2016-09-26 15:26:31 --> Output Class Initialized
INFO - 2016-09-26 15:26:31 --> Security Class Initialized
DEBUG - 2016-09-26 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:26:31 --> Input Class Initialized
INFO - 2016-09-26 15:26:31 --> Language Class Initialized
INFO - 2016-09-26 15:26:31 --> Loader Class Initialized
INFO - 2016-09-26 15:26:31 --> Helper loaded: url_helper
INFO - 2016-09-26 15:26:31 --> Helper loaded: language_helper
INFO - 2016-09-26 15:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:26:31 --> Controller Class Initialized
INFO - 2016-09-26 15:26:31 --> Database Driver Class Initialized
INFO - 2016-09-26 15:26:31 --> Model Class Initialized
INFO - 2016-09-26 15:26:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:26:31 --> Helper loaded: form_helper
INFO - 2016-09-26 15:26:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:26:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:26:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:26:31 --> Final output sent to browser
DEBUG - 2016-09-26 15:26:31 --> Total execution time: 0.0591
INFO - 2016-09-26 15:28:01 --> Config Class Initialized
INFO - 2016-09-26 15:28:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:28:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:28:01 --> Utf8 Class Initialized
INFO - 2016-09-26 15:28:01 --> URI Class Initialized
INFO - 2016-09-26 15:28:01 --> Router Class Initialized
INFO - 2016-09-26 15:28:01 --> Output Class Initialized
INFO - 2016-09-26 15:28:01 --> Security Class Initialized
DEBUG - 2016-09-26 15:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:28:01 --> Input Class Initialized
INFO - 2016-09-26 15:28:01 --> Language Class Initialized
INFO - 2016-09-26 15:28:01 --> Loader Class Initialized
INFO - 2016-09-26 15:28:01 --> Helper loaded: url_helper
INFO - 2016-09-26 15:28:01 --> Helper loaded: language_helper
INFO - 2016-09-26 15:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:28:01 --> Controller Class Initialized
INFO - 2016-09-26 15:28:01 --> Database Driver Class Initialized
INFO - 2016-09-26 15:28:01 --> Model Class Initialized
INFO - 2016-09-26 15:28:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:28:01 --> Helper loaded: form_helper
INFO - 2016-09-26 15:28:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:28:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:28:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:28:01 --> Final output sent to browser
DEBUG - 2016-09-26 15:28:01 --> Total execution time: 0.0737
INFO - 2016-09-26 15:33:01 --> Config Class Initialized
INFO - 2016-09-26 15:33:01 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:33:01 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:33:01 --> Utf8 Class Initialized
INFO - 2016-09-26 15:33:01 --> URI Class Initialized
INFO - 2016-09-26 15:33:01 --> Router Class Initialized
INFO - 2016-09-26 15:33:01 --> Output Class Initialized
INFO - 2016-09-26 15:33:01 --> Security Class Initialized
DEBUG - 2016-09-26 15:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:33:01 --> Input Class Initialized
INFO - 2016-09-26 15:33:01 --> Language Class Initialized
INFO - 2016-09-26 15:33:01 --> Loader Class Initialized
INFO - 2016-09-26 15:33:01 --> Helper loaded: url_helper
INFO - 2016-09-26 15:33:01 --> Helper loaded: language_helper
INFO - 2016-09-26 15:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:33:01 --> Controller Class Initialized
INFO - 2016-09-26 15:33:01 --> Database Driver Class Initialized
INFO - 2016-09-26 15:33:01 --> Model Class Initialized
INFO - 2016-09-26 15:33:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:33:01 --> Helper loaded: form_helper
INFO - 2016-09-26 15:33:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:33:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:33:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:33:01 --> Final output sent to browser
DEBUG - 2016-09-26 15:33:01 --> Total execution time: 0.0682
INFO - 2016-09-26 15:33:30 --> Config Class Initialized
INFO - 2016-09-26 15:33:30 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:33:30 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:33:30 --> Utf8 Class Initialized
INFO - 2016-09-26 15:33:30 --> URI Class Initialized
INFO - 2016-09-26 15:33:30 --> Router Class Initialized
INFO - 2016-09-26 15:33:30 --> Output Class Initialized
INFO - 2016-09-26 15:33:30 --> Security Class Initialized
DEBUG - 2016-09-26 15:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:33:30 --> Input Class Initialized
INFO - 2016-09-26 15:33:30 --> Language Class Initialized
INFO - 2016-09-26 15:33:30 --> Loader Class Initialized
INFO - 2016-09-26 15:33:30 --> Helper loaded: url_helper
INFO - 2016-09-26 15:33:30 --> Helper loaded: language_helper
INFO - 2016-09-26 15:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:33:30 --> Controller Class Initialized
INFO - 2016-09-26 15:33:30 --> Database Driver Class Initialized
INFO - 2016-09-26 15:33:30 --> Model Class Initialized
INFO - 2016-09-26 15:33:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:33:30 --> Helper loaded: form_helper
INFO - 2016-09-26 15:33:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:33:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:33:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:33:30 --> Final output sent to browser
DEBUG - 2016-09-26 15:33:30 --> Total execution time: 0.0647
INFO - 2016-09-26 15:35:12 --> Config Class Initialized
INFO - 2016-09-26 15:35:12 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:35:12 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:35:12 --> Utf8 Class Initialized
INFO - 2016-09-26 15:35:12 --> URI Class Initialized
INFO - 2016-09-26 15:35:12 --> Router Class Initialized
INFO - 2016-09-26 15:35:12 --> Output Class Initialized
INFO - 2016-09-26 15:35:12 --> Security Class Initialized
DEBUG - 2016-09-26 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:35:12 --> Input Class Initialized
INFO - 2016-09-26 15:35:12 --> Language Class Initialized
INFO - 2016-09-26 15:35:12 --> Loader Class Initialized
INFO - 2016-09-26 15:35:12 --> Helper loaded: url_helper
INFO - 2016-09-26 15:35:12 --> Helper loaded: language_helper
INFO - 2016-09-26 15:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:35:12 --> Controller Class Initialized
INFO - 2016-09-26 15:35:12 --> Database Driver Class Initialized
INFO - 2016-09-26 15:35:12 --> Model Class Initialized
INFO - 2016-09-26 15:35:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:35:12 --> Helper loaded: form_helper
INFO - 2016-09-26 15:35:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:35:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:35:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:35:12 --> Final output sent to browser
DEBUG - 2016-09-26 15:35:12 --> Total execution time: 0.0582
INFO - 2016-09-26 15:35:24 --> Config Class Initialized
INFO - 2016-09-26 15:35:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:35:24 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:35:24 --> Utf8 Class Initialized
INFO - 2016-09-26 15:35:24 --> URI Class Initialized
INFO - 2016-09-26 15:35:24 --> Router Class Initialized
INFO - 2016-09-26 15:35:24 --> Output Class Initialized
INFO - 2016-09-26 15:35:24 --> Security Class Initialized
DEBUG - 2016-09-26 15:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:35:24 --> Input Class Initialized
INFO - 2016-09-26 15:35:24 --> Language Class Initialized
INFO - 2016-09-26 15:35:24 --> Loader Class Initialized
INFO - 2016-09-26 15:35:24 --> Helper loaded: url_helper
INFO - 2016-09-26 15:35:24 --> Helper loaded: language_helper
INFO - 2016-09-26 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:35:24 --> Controller Class Initialized
INFO - 2016-09-26 15:35:24 --> Database Driver Class Initialized
INFO - 2016-09-26 15:35:24 --> Model Class Initialized
INFO - 2016-09-26 15:35:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:35:24 --> Helper loaded: form_helper
INFO - 2016-09-26 15:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 15:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:35:24 --> Final output sent to browser
DEBUG - 2016-09-26 15:35:24 --> Total execution time: 0.0605
INFO - 2016-09-26 15:36:08 --> Config Class Initialized
INFO - 2016-09-26 15:36:08 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:36:08 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:36:08 --> Utf8 Class Initialized
INFO - 2016-09-26 15:36:08 --> URI Class Initialized
INFO - 2016-09-26 15:36:08 --> Router Class Initialized
INFO - 2016-09-26 15:36:08 --> Output Class Initialized
INFO - 2016-09-26 15:36:08 --> Security Class Initialized
DEBUG - 2016-09-26 15:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:36:08 --> Input Class Initialized
INFO - 2016-09-26 15:36:08 --> Language Class Initialized
INFO - 2016-09-26 15:36:08 --> Loader Class Initialized
INFO - 2016-09-26 15:36:08 --> Helper loaded: url_helper
INFO - 2016-09-26 15:36:08 --> Helper loaded: language_helper
INFO - 2016-09-26 15:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:36:08 --> Controller Class Initialized
INFO - 2016-09-26 15:36:08 --> Database Driver Class Initialized
INFO - 2016-09-26 15:36:08 --> Model Class Initialized
INFO - 2016-09-26 15:36:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:36:08 --> Helper loaded: form_helper
INFO - 2016-09-26 15:36:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:36:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:36:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:36:08 --> Final output sent to browser
DEBUG - 2016-09-26 15:36:08 --> Total execution time: 0.0595
INFO - 2016-09-26 15:45:23 --> Config Class Initialized
INFO - 2016-09-26 15:45:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:45:23 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:45:23 --> Utf8 Class Initialized
INFO - 2016-09-26 15:45:23 --> URI Class Initialized
INFO - 2016-09-26 15:45:23 --> Router Class Initialized
INFO - 2016-09-26 15:45:23 --> Output Class Initialized
INFO - 2016-09-26 15:45:23 --> Security Class Initialized
DEBUG - 2016-09-26 15:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:45:23 --> Input Class Initialized
INFO - 2016-09-26 15:45:23 --> Language Class Initialized
INFO - 2016-09-26 15:45:23 --> Loader Class Initialized
INFO - 2016-09-26 15:45:23 --> Helper loaded: url_helper
INFO - 2016-09-26 15:45:23 --> Helper loaded: language_helper
INFO - 2016-09-26 15:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:45:23 --> Controller Class Initialized
INFO - 2016-09-26 15:45:23 --> Database Driver Class Initialized
INFO - 2016-09-26 15:45:23 --> Model Class Initialized
INFO - 2016-09-26 15:45:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:45:23 --> Helper loaded: form_helper
INFO - 2016-09-26 15:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:45:23 --> Final output sent to browser
DEBUG - 2016-09-26 15:45:23 --> Total execution time: 0.0657
INFO - 2016-09-26 15:46:52 --> Config Class Initialized
INFO - 2016-09-26 15:46:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:46:52 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:46:52 --> Utf8 Class Initialized
INFO - 2016-09-26 15:46:52 --> URI Class Initialized
INFO - 2016-09-26 15:46:52 --> Router Class Initialized
INFO - 2016-09-26 15:46:52 --> Output Class Initialized
INFO - 2016-09-26 15:46:52 --> Security Class Initialized
DEBUG - 2016-09-26 15:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:46:52 --> Input Class Initialized
INFO - 2016-09-26 15:46:52 --> Language Class Initialized
INFO - 2016-09-26 15:46:52 --> Loader Class Initialized
INFO - 2016-09-26 15:46:52 --> Helper loaded: url_helper
INFO - 2016-09-26 15:46:52 --> Helper loaded: language_helper
INFO - 2016-09-26 15:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:46:52 --> Controller Class Initialized
INFO - 2016-09-26 15:46:52 --> Database Driver Class Initialized
INFO - 2016-09-26 15:46:52 --> Model Class Initialized
INFO - 2016-09-26 15:46:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:46:52 --> Helper loaded: form_helper
INFO - 2016-09-26 15:46:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:46:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:46:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:46:52 --> Final output sent to browser
DEBUG - 2016-09-26 15:46:52 --> Total execution time: 0.0614
INFO - 2016-09-26 15:47:49 --> Config Class Initialized
INFO - 2016-09-26 15:47:49 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:47:49 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:47:49 --> Utf8 Class Initialized
INFO - 2016-09-26 15:47:49 --> URI Class Initialized
INFO - 2016-09-26 15:47:49 --> Router Class Initialized
INFO - 2016-09-26 15:47:49 --> Output Class Initialized
INFO - 2016-09-26 15:47:49 --> Security Class Initialized
DEBUG - 2016-09-26 15:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:47:49 --> Input Class Initialized
INFO - 2016-09-26 15:47:49 --> Language Class Initialized
INFO - 2016-09-26 15:47:49 --> Loader Class Initialized
INFO - 2016-09-26 15:47:49 --> Helper loaded: url_helper
INFO - 2016-09-26 15:47:49 --> Helper loaded: language_helper
INFO - 2016-09-26 15:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:47:49 --> Controller Class Initialized
INFO - 2016-09-26 15:47:49 --> Database Driver Class Initialized
INFO - 2016-09-26 15:47:49 --> Model Class Initialized
INFO - 2016-09-26 15:47:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:47:49 --> Helper loaded: form_helper
INFO - 2016-09-26 15:47:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:47:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:47:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:47:49 --> Final output sent to browser
DEBUG - 2016-09-26 15:47:49 --> Total execution time: 0.0581
INFO - 2016-09-26 15:48:12 --> Config Class Initialized
INFO - 2016-09-26 15:48:12 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:48:12 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:48:12 --> Utf8 Class Initialized
INFO - 2016-09-26 15:48:12 --> URI Class Initialized
INFO - 2016-09-26 15:48:12 --> Router Class Initialized
INFO - 2016-09-26 15:48:12 --> Output Class Initialized
INFO - 2016-09-26 15:48:12 --> Security Class Initialized
DEBUG - 2016-09-26 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:48:12 --> Input Class Initialized
INFO - 2016-09-26 15:48:12 --> Language Class Initialized
INFO - 2016-09-26 15:48:12 --> Loader Class Initialized
INFO - 2016-09-26 15:48:12 --> Helper loaded: url_helper
INFO - 2016-09-26 15:48:12 --> Helper loaded: language_helper
INFO - 2016-09-26 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:48:12 --> Controller Class Initialized
INFO - 2016-09-26 15:48:12 --> Database Driver Class Initialized
INFO - 2016-09-26 15:48:12 --> Model Class Initialized
INFO - 2016-09-26 15:48:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:48:12 --> Helper loaded: form_helper
INFO - 2016-09-26 15:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:48:12 --> Final output sent to browser
DEBUG - 2016-09-26 15:48:12 --> Total execution time: 0.0717
INFO - 2016-09-26 15:48:35 --> Config Class Initialized
INFO - 2016-09-26 15:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:48:35 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:48:35 --> Utf8 Class Initialized
INFO - 2016-09-26 15:48:35 --> URI Class Initialized
INFO - 2016-09-26 15:48:35 --> Router Class Initialized
INFO - 2016-09-26 15:48:35 --> Output Class Initialized
INFO - 2016-09-26 15:48:35 --> Security Class Initialized
DEBUG - 2016-09-26 15:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:48:35 --> Input Class Initialized
INFO - 2016-09-26 15:48:35 --> Language Class Initialized
INFO - 2016-09-26 15:48:35 --> Loader Class Initialized
INFO - 2016-09-26 15:48:35 --> Helper loaded: url_helper
INFO - 2016-09-26 15:48:35 --> Helper loaded: language_helper
INFO - 2016-09-26 15:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:48:35 --> Controller Class Initialized
INFO - 2016-09-26 15:48:35 --> Database Driver Class Initialized
INFO - 2016-09-26 15:48:35 --> Model Class Initialized
INFO - 2016-09-26 15:48:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:48:35 --> Helper loaded: form_helper
INFO - 2016-09-26 15:48:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:48:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:48:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:48:35 --> Final output sent to browser
DEBUG - 2016-09-26 15:48:35 --> Total execution time: 0.0579
INFO - 2016-09-26 15:50:29 --> Config Class Initialized
INFO - 2016-09-26 15:50:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:50:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:50:29 --> Utf8 Class Initialized
INFO - 2016-09-26 15:50:29 --> URI Class Initialized
INFO - 2016-09-26 15:50:29 --> Router Class Initialized
INFO - 2016-09-26 15:50:29 --> Output Class Initialized
INFO - 2016-09-26 15:50:29 --> Security Class Initialized
DEBUG - 2016-09-26 15:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:50:29 --> Input Class Initialized
INFO - 2016-09-26 15:50:29 --> Language Class Initialized
INFO - 2016-09-26 15:50:29 --> Loader Class Initialized
INFO - 2016-09-26 15:50:29 --> Helper loaded: url_helper
INFO - 2016-09-26 15:50:29 --> Helper loaded: language_helper
INFO - 2016-09-26 15:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:50:29 --> Controller Class Initialized
INFO - 2016-09-26 15:50:29 --> Database Driver Class Initialized
INFO - 2016-09-26 15:50:29 --> Model Class Initialized
INFO - 2016-09-26 15:50:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:50:29 --> Helper loaded: form_helper
ERROR - 2016-09-26 15:50:29 --> Severity: Notice --> Undefined property: Hasil::$hasil_detail C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 54
ERROR - 2016-09-26 15:50:29 --> Severity: error --> Exception: Call to a member function hasil_list() on null C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 54
INFO - 2016-09-26 15:50:48 --> Config Class Initialized
INFO - 2016-09-26 15:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:50:48 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:50:48 --> Utf8 Class Initialized
INFO - 2016-09-26 15:50:48 --> URI Class Initialized
INFO - 2016-09-26 15:50:48 --> Router Class Initialized
INFO - 2016-09-26 15:50:48 --> Output Class Initialized
INFO - 2016-09-26 15:50:48 --> Security Class Initialized
DEBUG - 2016-09-26 15:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:50:48 --> Input Class Initialized
INFO - 2016-09-26 15:50:48 --> Language Class Initialized
INFO - 2016-09-26 15:50:48 --> Loader Class Initialized
INFO - 2016-09-26 15:50:48 --> Helper loaded: url_helper
INFO - 2016-09-26 15:50:48 --> Helper loaded: language_helper
INFO - 2016-09-26 15:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:50:48 --> Controller Class Initialized
INFO - 2016-09-26 15:50:48 --> Database Driver Class Initialized
INFO - 2016-09-26 15:50:48 --> Model Class Initialized
INFO - 2016-09-26 15:50:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:50:48 --> Helper loaded: form_helper
INFO - 2016-09-26 15:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:50:48 --> Final output sent to browser
DEBUG - 2016-09-26 15:50:48 --> Total execution time: 0.0605
INFO - 2016-09-26 15:55:54 --> Config Class Initialized
INFO - 2016-09-26 15:55:54 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:55:54 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:55:54 --> Utf8 Class Initialized
INFO - 2016-09-26 15:55:54 --> URI Class Initialized
INFO - 2016-09-26 15:55:54 --> Router Class Initialized
INFO - 2016-09-26 15:55:54 --> Output Class Initialized
INFO - 2016-09-26 15:55:54 --> Security Class Initialized
DEBUG - 2016-09-26 15:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:55:54 --> Input Class Initialized
INFO - 2016-09-26 15:55:54 --> Language Class Initialized
INFO - 2016-09-26 15:55:54 --> Loader Class Initialized
INFO - 2016-09-26 15:55:54 --> Helper loaded: url_helper
INFO - 2016-09-26 15:55:54 --> Helper loaded: language_helper
INFO - 2016-09-26 15:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:55:54 --> Controller Class Initialized
INFO - 2016-09-26 15:55:54 --> Database Driver Class Initialized
INFO - 2016-09-26 15:55:54 --> Model Class Initialized
INFO - 2016-09-26 15:55:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:55:54 --> Helper loaded: form_helper
ERROR - 2016-09-26 15:55:54 --> Severity: Notice --> Undefined property: Hasil::$user_model C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 54
ERROR - 2016-09-26 15:55:54 --> Severity: error --> Exception: Call to a member function get_user() on null C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 54
INFO - 2016-09-26 15:56:28 --> Config Class Initialized
INFO - 2016-09-26 15:56:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:56:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:56:28 --> Utf8 Class Initialized
INFO - 2016-09-26 15:56:28 --> URI Class Initialized
INFO - 2016-09-26 15:56:28 --> Router Class Initialized
INFO - 2016-09-26 15:56:28 --> Output Class Initialized
INFO - 2016-09-26 15:56:28 --> Security Class Initialized
DEBUG - 2016-09-26 15:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:56:28 --> Input Class Initialized
INFO - 2016-09-26 15:56:28 --> Language Class Initialized
INFO - 2016-09-26 15:56:28 --> Loader Class Initialized
INFO - 2016-09-26 15:56:28 --> Helper loaded: url_helper
INFO - 2016-09-26 15:56:28 --> Helper loaded: language_helper
INFO - 2016-09-26 15:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:56:28 --> Controller Class Initialized
INFO - 2016-09-26 15:56:28 --> Database Driver Class Initialized
INFO - 2016-09-26 15:56:28 --> Model Class Initialized
INFO - 2016-09-26 15:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:56:28 --> Model Class Initialized
INFO - 2016-09-26 15:56:28 --> Helper loaded: form_helper
INFO - 2016-09-26 15:56:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:56:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:56:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:56:28 --> Final output sent to browser
DEBUG - 2016-09-26 15:56:28 --> Total execution time: 0.0761
INFO - 2016-09-26 15:58:03 --> Config Class Initialized
INFO - 2016-09-26 15:58:03 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:58:03 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:58:03 --> Utf8 Class Initialized
INFO - 2016-09-26 15:58:03 --> URI Class Initialized
INFO - 2016-09-26 15:58:03 --> Router Class Initialized
INFO - 2016-09-26 15:58:03 --> Output Class Initialized
INFO - 2016-09-26 15:58:03 --> Security Class Initialized
DEBUG - 2016-09-26 15:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:58:03 --> Input Class Initialized
INFO - 2016-09-26 15:58:03 --> Language Class Initialized
INFO - 2016-09-26 15:58:03 --> Loader Class Initialized
INFO - 2016-09-26 15:58:03 --> Helper loaded: url_helper
INFO - 2016-09-26 15:58:03 --> Helper loaded: language_helper
INFO - 2016-09-26 15:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:58:03 --> Controller Class Initialized
INFO - 2016-09-26 15:58:03 --> Database Driver Class Initialized
INFO - 2016-09-26 15:58:03 --> Model Class Initialized
INFO - 2016-09-26 15:58:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:58:03 --> Model Class Initialized
INFO - 2016-09-26 15:58:03 --> Helper loaded: form_helper
INFO - 2016-09-26 15:58:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:58:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:58:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:58:03 --> Final output sent to browser
DEBUG - 2016-09-26 15:58:03 --> Total execution time: 0.0677
INFO - 2016-09-26 15:59:30 --> Config Class Initialized
INFO - 2016-09-26 15:59:30 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:59:30 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:59:30 --> Utf8 Class Initialized
INFO - 2016-09-26 15:59:30 --> URI Class Initialized
INFO - 2016-09-26 15:59:30 --> Router Class Initialized
INFO - 2016-09-26 15:59:30 --> Output Class Initialized
INFO - 2016-09-26 15:59:30 --> Security Class Initialized
DEBUG - 2016-09-26 15:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:59:30 --> Input Class Initialized
INFO - 2016-09-26 15:59:30 --> Language Class Initialized
INFO - 2016-09-26 15:59:30 --> Loader Class Initialized
INFO - 2016-09-26 15:59:30 --> Helper loaded: url_helper
INFO - 2016-09-26 15:59:30 --> Helper loaded: language_helper
INFO - 2016-09-26 15:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:59:30 --> Controller Class Initialized
INFO - 2016-09-26 15:59:30 --> Database Driver Class Initialized
INFO - 2016-09-26 15:59:30 --> Model Class Initialized
INFO - 2016-09-26 15:59:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:59:30 --> Helper loaded: form_helper
INFO - 2016-09-26 15:59:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:59:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 15:59:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:59:30 --> Final output sent to browser
DEBUG - 2016-09-26 15:59:30 --> Total execution time: 0.0622
INFO - 2016-09-26 15:59:35 --> Config Class Initialized
INFO - 2016-09-26 15:59:35 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:59:35 --> UTF-8 Support Enabled
INFO - 2016-09-26 15:59:35 --> Utf8 Class Initialized
INFO - 2016-09-26 15:59:35 --> URI Class Initialized
INFO - 2016-09-26 15:59:35 --> Router Class Initialized
INFO - 2016-09-26 15:59:35 --> Output Class Initialized
INFO - 2016-09-26 15:59:35 --> Security Class Initialized
DEBUG - 2016-09-26 15:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 15:59:35 --> Input Class Initialized
INFO - 2016-09-26 15:59:35 --> Language Class Initialized
INFO - 2016-09-26 15:59:35 --> Loader Class Initialized
INFO - 2016-09-26 15:59:35 --> Helper loaded: url_helper
INFO - 2016-09-26 15:59:35 --> Helper loaded: language_helper
INFO - 2016-09-26 15:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 15:59:35 --> Controller Class Initialized
INFO - 2016-09-26 15:59:35 --> Database Driver Class Initialized
INFO - 2016-09-26 15:59:35 --> Model Class Initialized
INFO - 2016-09-26 15:59:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 15:59:35 --> Model Class Initialized
INFO - 2016-09-26 15:59:35 --> Helper loaded: form_helper
INFO - 2016-09-26 15:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 15:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 15:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 15:59:35 --> Final output sent to browser
DEBUG - 2016-09-26 15:59:35 --> Total execution time: 0.0627
INFO - 2016-09-26 16:01:29 --> Config Class Initialized
INFO - 2016-09-26 16:01:29 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:01:29 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:01:29 --> Utf8 Class Initialized
INFO - 2016-09-26 16:01:29 --> URI Class Initialized
INFO - 2016-09-26 16:01:29 --> Router Class Initialized
INFO - 2016-09-26 16:01:29 --> Output Class Initialized
INFO - 2016-09-26 16:01:29 --> Security Class Initialized
DEBUG - 2016-09-26 16:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:01:29 --> Input Class Initialized
INFO - 2016-09-26 16:01:29 --> Language Class Initialized
INFO - 2016-09-26 16:01:29 --> Loader Class Initialized
INFO - 2016-09-26 16:01:29 --> Helper loaded: url_helper
INFO - 2016-09-26 16:01:29 --> Helper loaded: language_helper
INFO - 2016-09-26 16:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:01:29 --> Controller Class Initialized
INFO - 2016-09-26 16:01:29 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:29 --> Model Class Initialized
INFO - 2016-09-26 16:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:01:29 --> Helper loaded: form_helper
INFO - 2016-09-26 16:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 16:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:01:29 --> Final output sent to browser
DEBUG - 2016-09-26 16:01:29 --> Total execution time: 0.0650
INFO - 2016-09-26 16:01:34 --> Config Class Initialized
INFO - 2016-09-26 16:01:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:01:34 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:01:34 --> Utf8 Class Initialized
INFO - 2016-09-26 16:01:34 --> URI Class Initialized
INFO - 2016-09-26 16:01:34 --> Router Class Initialized
INFO - 2016-09-26 16:01:34 --> Output Class Initialized
INFO - 2016-09-26 16:01:34 --> Security Class Initialized
DEBUG - 2016-09-26 16:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:01:34 --> Input Class Initialized
INFO - 2016-09-26 16:01:34 --> Language Class Initialized
INFO - 2016-09-26 16:01:34 --> Loader Class Initialized
INFO - 2016-09-26 16:01:34 --> Helper loaded: url_helper
INFO - 2016-09-26 16:01:34 --> Helper loaded: language_helper
INFO - 2016-09-26 16:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:01:34 --> Controller Class Initialized
INFO - 2016-09-26 16:01:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:01:34 --> Model Class Initialized
INFO - 2016-09-26 16:01:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:01:34 --> Model Class Initialized
INFO - 2016-09-26 16:01:34 --> Helper loaded: form_helper
INFO - 2016-09-26 16:01:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:01:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:01:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:01:34 --> Final output sent to browser
DEBUG - 2016-09-26 16:01:34 --> Total execution time: 0.0719
INFO - 2016-09-26 16:05:55 --> Config Class Initialized
INFO - 2016-09-26 16:05:55 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:05:55 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:05:55 --> Utf8 Class Initialized
INFO - 2016-09-26 16:05:55 --> URI Class Initialized
INFO - 2016-09-26 16:05:55 --> Router Class Initialized
INFO - 2016-09-26 16:05:55 --> Output Class Initialized
INFO - 2016-09-26 16:05:55 --> Security Class Initialized
DEBUG - 2016-09-26 16:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:05:55 --> Input Class Initialized
INFO - 2016-09-26 16:05:55 --> Language Class Initialized
INFO - 2016-09-26 16:05:55 --> Loader Class Initialized
INFO - 2016-09-26 16:05:55 --> Helper loaded: url_helper
INFO - 2016-09-26 16:05:55 --> Helper loaded: language_helper
INFO - 2016-09-26 16:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:05:55 --> Controller Class Initialized
INFO - 2016-09-26 16:05:55 --> Database Driver Class Initialized
INFO - 2016-09-26 16:05:55 --> Model Class Initialized
INFO - 2016-09-26 16:05:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:05:55 --> Model Class Initialized
INFO - 2016-09-26 16:05:55 --> Helper loaded: form_helper
ERROR - 2016-09-26 16:05:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'by d.uid
                order by total desc' at line 7 - Invalid query: SELECT d.uid,concat(d.first_name,' ',d.last_name) as fullname,round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist0,round(sum(case when c.cid=12 then a.score_u else null end), 0) as ist1,round(sum(case when c.cid=13 then a.score_u else null end), 0) as ist2,round(sum(case when c.cid=14 then a.score_u else null end), 0) as ist3,round(sum(case when c.cid=15 then a.score_u else null end), 0) as ist4,round(sum(case when c.cid=16 then a.score_u else null end), 0) as ist5,round(sum(case when c.cid=17 then a.score_u else null end), 0) as ist6,round(sum(case when c.cid=19 then a.score_u else null end), 0) as ist7,round(sum(case when c.cid=20 then a.score_u else null end), 0) as ist8,
                round(sum(a.score_u), 0) as total
                from quiz.savsoft_answers a
                left join quiz.savsoft_qbank b on b.qid = a.qid
                left join quiz.savsoft_category c on c.cid = b.cid
                left join quiz.savsoft_users d on d.uid = a.uid
                where registration_no != '11111' and d.uid = 10group by d.uid
                order by total desc
INFO - 2016-09-26 16:05:55 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-09-26 16:08:34 --> Config Class Initialized
INFO - 2016-09-26 16:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:08:34 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:08:34 --> Utf8 Class Initialized
INFO - 2016-09-26 16:08:34 --> URI Class Initialized
INFO - 2016-09-26 16:08:34 --> Router Class Initialized
INFO - 2016-09-26 16:08:34 --> Output Class Initialized
INFO - 2016-09-26 16:08:34 --> Security Class Initialized
DEBUG - 2016-09-26 16:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:08:34 --> Input Class Initialized
INFO - 2016-09-26 16:08:34 --> Language Class Initialized
INFO - 2016-09-26 16:08:34 --> Loader Class Initialized
INFO - 2016-09-26 16:08:34 --> Helper loaded: url_helper
INFO - 2016-09-26 16:08:34 --> Helper loaded: language_helper
INFO - 2016-09-26 16:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:08:34 --> Controller Class Initialized
INFO - 2016-09-26 16:08:34 --> Database Driver Class Initialized
INFO - 2016-09-26 16:08:34 --> Model Class Initialized
INFO - 2016-09-26 16:08:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:08:34 --> Model Class Initialized
INFO - 2016-09-26 16:08:34 --> Helper loaded: form_helper
INFO - 2016-09-26 16:08:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:08:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:08:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:08:34 --> Final output sent to browser
DEBUG - 2016-09-26 16:08:34 --> Total execution time: 0.0723
INFO - 2016-09-26 16:09:08 --> Config Class Initialized
INFO - 2016-09-26 16:09:08 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:09:08 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:09:08 --> Utf8 Class Initialized
INFO - 2016-09-26 16:09:08 --> URI Class Initialized
INFO - 2016-09-26 16:09:08 --> Router Class Initialized
INFO - 2016-09-26 16:09:08 --> Output Class Initialized
INFO - 2016-09-26 16:09:08 --> Security Class Initialized
DEBUG - 2016-09-26 16:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:09:08 --> Input Class Initialized
INFO - 2016-09-26 16:09:08 --> Language Class Initialized
INFO - 2016-09-26 16:09:08 --> Loader Class Initialized
INFO - 2016-09-26 16:09:08 --> Helper loaded: url_helper
INFO - 2016-09-26 16:09:08 --> Helper loaded: language_helper
INFO - 2016-09-26 16:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:09:08 --> Controller Class Initialized
INFO - 2016-09-26 16:09:08 --> Database Driver Class Initialized
INFO - 2016-09-26 16:09:08 --> Model Class Initialized
INFO - 2016-09-26 16:09:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:09:08 --> Model Class Initialized
INFO - 2016-09-26 16:09:08 --> Helper loaded: form_helper
INFO - 2016-09-26 16:09:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:09:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:09:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:09:08 --> Final output sent to browser
DEBUG - 2016-09-26 16:09:08 --> Total execution time: 0.0674
INFO - 2016-09-26 16:11:40 --> Config Class Initialized
INFO - 2016-09-26 16:11:40 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:11:40 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:11:40 --> Utf8 Class Initialized
INFO - 2016-09-26 16:11:40 --> URI Class Initialized
INFO - 2016-09-26 16:11:40 --> Router Class Initialized
INFO - 2016-09-26 16:11:40 --> Output Class Initialized
INFO - 2016-09-26 16:11:40 --> Security Class Initialized
DEBUG - 2016-09-26 16:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:11:40 --> Input Class Initialized
INFO - 2016-09-26 16:11:40 --> Language Class Initialized
INFO - 2016-09-26 16:11:40 --> Loader Class Initialized
INFO - 2016-09-26 16:11:40 --> Helper loaded: url_helper
INFO - 2016-09-26 16:11:40 --> Helper loaded: language_helper
INFO - 2016-09-26 16:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:11:40 --> Controller Class Initialized
INFO - 2016-09-26 16:11:40 --> Database Driver Class Initialized
INFO - 2016-09-26 16:11:40 --> Model Class Initialized
INFO - 2016-09-26 16:11:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:11:40 --> Model Class Initialized
INFO - 2016-09-26 16:11:40 --> Helper loaded: form_helper
INFO - 2016-09-26 16:11:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:11:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:11:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:11:40 --> Final output sent to browser
DEBUG - 2016-09-26 16:11:40 --> Total execution time: 0.0728
INFO - 2016-09-26 16:12:33 --> Config Class Initialized
INFO - 2016-09-26 16:12:33 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:33 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:33 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:33 --> URI Class Initialized
INFO - 2016-09-26 16:12:33 --> Router Class Initialized
INFO - 2016-09-26 16:12:33 --> Output Class Initialized
INFO - 2016-09-26 16:12:33 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:33 --> Input Class Initialized
INFO - 2016-09-26 16:12:33 --> Language Class Initialized
INFO - 2016-09-26 16:12:33 --> Loader Class Initialized
INFO - 2016-09-26 16:12:33 --> Helper loaded: url_helper
INFO - 2016-09-26 16:12:33 --> Helper loaded: language_helper
INFO - 2016-09-26 16:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:12:33 --> Controller Class Initialized
INFO - 2016-09-26 16:12:33 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:33 --> Model Class Initialized
INFO - 2016-09-26 16:12:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:12:33 --> Model Class Initialized
INFO - 2016-09-26 16:12:33 --> Helper loaded: form_helper
INFO - 2016-09-26 16:12:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:12:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:12:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:12:33 --> Final output sent to browser
DEBUG - 2016-09-26 16:12:33 --> Total execution time: 0.0676
INFO - 2016-09-26 16:12:47 --> Config Class Initialized
INFO - 2016-09-26 16:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:47 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:12:47 --> Utf8 Class Initialized
INFO - 2016-09-26 16:12:47 --> URI Class Initialized
INFO - 2016-09-26 16:12:47 --> Router Class Initialized
INFO - 2016-09-26 16:12:47 --> Output Class Initialized
INFO - 2016-09-26 16:12:47 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:12:47 --> Input Class Initialized
INFO - 2016-09-26 16:12:47 --> Language Class Initialized
INFO - 2016-09-26 16:12:47 --> Loader Class Initialized
INFO - 2016-09-26 16:12:47 --> Helper loaded: url_helper
INFO - 2016-09-26 16:12:47 --> Helper loaded: language_helper
INFO - 2016-09-26 16:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:12:47 --> Controller Class Initialized
INFO - 2016-09-26 16:12:47 --> Database Driver Class Initialized
INFO - 2016-09-26 16:12:47 --> Model Class Initialized
INFO - 2016-09-26 16:12:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:12:47 --> Model Class Initialized
INFO - 2016-09-26 16:12:47 --> Helper loaded: form_helper
INFO - 2016-09-26 16:12:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:12:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:12:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:12:47 --> Final output sent to browser
DEBUG - 2016-09-26 16:12:47 --> Total execution time: 0.0657
INFO - 2016-09-26 16:13:07 --> Config Class Initialized
INFO - 2016-09-26 16:13:07 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:13:07 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:13:07 --> Utf8 Class Initialized
INFO - 2016-09-26 16:13:07 --> URI Class Initialized
INFO - 2016-09-26 16:13:07 --> Router Class Initialized
INFO - 2016-09-26 16:13:07 --> Output Class Initialized
INFO - 2016-09-26 16:13:07 --> Security Class Initialized
DEBUG - 2016-09-26 16:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:13:07 --> Input Class Initialized
INFO - 2016-09-26 16:13:07 --> Language Class Initialized
INFO - 2016-09-26 16:13:07 --> Loader Class Initialized
INFO - 2016-09-26 16:13:07 --> Helper loaded: url_helper
INFO - 2016-09-26 16:13:07 --> Helper loaded: language_helper
INFO - 2016-09-26 16:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:13:07 --> Controller Class Initialized
INFO - 2016-09-26 16:13:07 --> Database Driver Class Initialized
INFO - 2016-09-26 16:13:07 --> Model Class Initialized
INFO - 2016-09-26 16:13:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:13:07 --> Model Class Initialized
INFO - 2016-09-26 16:13:07 --> Helper loaded: form_helper
INFO - 2016-09-26 16:13:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:13:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:13:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:13:07 --> Final output sent to browser
DEBUG - 2016-09-26 16:13:07 --> Total execution time: 0.0620
INFO - 2016-09-26 16:14:28 --> Config Class Initialized
INFO - 2016-09-26 16:14:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:14:28 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:14:28 --> Utf8 Class Initialized
INFO - 2016-09-26 16:14:28 --> URI Class Initialized
INFO - 2016-09-26 16:14:28 --> Router Class Initialized
INFO - 2016-09-26 16:14:28 --> Output Class Initialized
INFO - 2016-09-26 16:14:28 --> Security Class Initialized
DEBUG - 2016-09-26 16:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:14:28 --> Input Class Initialized
INFO - 2016-09-26 16:14:28 --> Language Class Initialized
INFO - 2016-09-26 16:14:28 --> Loader Class Initialized
INFO - 2016-09-26 16:14:28 --> Helper loaded: url_helper
INFO - 2016-09-26 16:14:28 --> Helper loaded: language_helper
INFO - 2016-09-26 16:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:14:28 --> Controller Class Initialized
INFO - 2016-09-26 16:14:28 --> Database Driver Class Initialized
INFO - 2016-09-26 16:14:28 --> Model Class Initialized
INFO - 2016-09-26 16:14:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:14:28 --> Model Class Initialized
INFO - 2016-09-26 16:14:28 --> Helper loaded: form_helper
INFO - 2016-09-26 16:14:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:14:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:14:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:14:28 --> Final output sent to browser
DEBUG - 2016-09-26 16:14:28 --> Total execution time: 0.0665
INFO - 2016-09-26 16:14:38 --> Config Class Initialized
INFO - 2016-09-26 16:14:38 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:14:38 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:14:38 --> Utf8 Class Initialized
INFO - 2016-09-26 16:14:38 --> URI Class Initialized
INFO - 2016-09-26 16:14:38 --> Router Class Initialized
INFO - 2016-09-26 16:14:38 --> Output Class Initialized
INFO - 2016-09-26 16:14:38 --> Security Class Initialized
DEBUG - 2016-09-26 16:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:14:38 --> Input Class Initialized
INFO - 2016-09-26 16:14:38 --> Language Class Initialized
INFO - 2016-09-26 16:14:38 --> Loader Class Initialized
INFO - 2016-09-26 16:14:38 --> Helper loaded: url_helper
INFO - 2016-09-26 16:14:38 --> Helper loaded: language_helper
INFO - 2016-09-26 16:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:14:38 --> Controller Class Initialized
INFO - 2016-09-26 16:14:38 --> Database Driver Class Initialized
INFO - 2016-09-26 16:14:38 --> Model Class Initialized
INFO - 2016-09-26 16:14:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:14:38 --> Helper loaded: form_helper
INFO - 2016-09-26 16:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-26 16:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:14:38 --> Final output sent to browser
DEBUG - 2016-09-26 16:14:38 --> Total execution time: 0.0661
INFO - 2016-09-26 16:14:42 --> Config Class Initialized
INFO - 2016-09-26 16:14:42 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:14:42 --> UTF-8 Support Enabled
INFO - 2016-09-26 16:14:42 --> Utf8 Class Initialized
INFO - 2016-09-26 16:14:42 --> URI Class Initialized
INFO - 2016-09-26 16:14:42 --> Router Class Initialized
INFO - 2016-09-26 16:14:42 --> Output Class Initialized
INFO - 2016-09-26 16:14:42 --> Security Class Initialized
DEBUG - 2016-09-26 16:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-26 16:14:42 --> Input Class Initialized
INFO - 2016-09-26 16:14:42 --> Language Class Initialized
INFO - 2016-09-26 16:14:42 --> Loader Class Initialized
INFO - 2016-09-26 16:14:42 --> Helper loaded: url_helper
INFO - 2016-09-26 16:14:42 --> Helper loaded: language_helper
INFO - 2016-09-26 16:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-26 16:14:42 --> Controller Class Initialized
INFO - 2016-09-26 16:14:42 --> Database Driver Class Initialized
INFO - 2016-09-26 16:14:42 --> Model Class Initialized
INFO - 2016-09-26 16:14:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-26 16:14:42 --> Model Class Initialized
INFO - 2016-09-26 16:14:42 --> Helper loaded: form_helper
INFO - 2016-09-26 16:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-26 16:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-26 16:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-26 16:14:42 --> Final output sent to browser
DEBUG - 2016-09-26 16:14:42 --> Total execution time: 0.0617
