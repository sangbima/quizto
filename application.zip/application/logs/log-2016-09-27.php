<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-27 09:53:09 --> Config Class Initialized
INFO - 2016-09-27 09:53:09 --> Hooks Class Initialized
DEBUG - 2016-09-27 09:53:09 --> UTF-8 Support Enabled
INFO - 2016-09-27 09:53:09 --> Utf8 Class Initialized
INFO - 2016-09-27 09:53:09 --> URI Class Initialized
INFO - 2016-09-27 09:53:09 --> Router Class Initialized
INFO - 2016-09-27 09:53:09 --> Output Class Initialized
INFO - 2016-09-27 09:53:09 --> Security Class Initialized
DEBUG - 2016-09-27 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 09:53:09 --> Input Class Initialized
INFO - 2016-09-27 09:53:09 --> Language Class Initialized
INFO - 2016-09-27 09:53:09 --> Loader Class Initialized
INFO - 2016-09-27 09:53:09 --> Helper loaded: url_helper
INFO - 2016-09-27 09:53:09 --> Helper loaded: language_helper
INFO - 2016-09-27 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 09:53:09 --> Controller Class Initialized
INFO - 2016-09-27 09:53:09 --> Database Driver Class Initialized
INFO - 2016-09-27 09:53:09 --> Model Class Initialized
INFO - 2016-09-27 09:53:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 09:53:09 --> Config Class Initialized
INFO - 2016-09-27 09:53:09 --> Hooks Class Initialized
DEBUG - 2016-09-27 09:53:09 --> UTF-8 Support Enabled
INFO - 2016-09-27 09:53:09 --> Utf8 Class Initialized
INFO - 2016-09-27 09:53:09 --> URI Class Initialized
INFO - 2016-09-27 09:53:09 --> Router Class Initialized
INFO - 2016-09-27 09:53:09 --> Output Class Initialized
INFO - 2016-09-27 09:53:09 --> Security Class Initialized
DEBUG - 2016-09-27 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 09:53:09 --> Input Class Initialized
INFO - 2016-09-27 09:53:09 --> Language Class Initialized
INFO - 2016-09-27 09:53:09 --> Loader Class Initialized
INFO - 2016-09-27 09:53:09 --> Helper loaded: url_helper
INFO - 2016-09-27 09:53:09 --> Helper loaded: language_helper
INFO - 2016-09-27 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 09:53:09 --> Controller Class Initialized
INFO - 2016-09-27 09:53:09 --> Database Driver Class Initialized
INFO - 2016-09-27 09:53:09 --> Model Class Initialized
INFO - 2016-09-27 09:53:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 09:53:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-27 09:53:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-27 09:53:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-27 09:53:09 --> Final output sent to browser
DEBUG - 2016-09-27 09:53:09 --> Total execution time: 0.0602
INFO - 2016-09-27 09:53:17 --> Config Class Initialized
INFO - 2016-09-27 09:53:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 09:53:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 09:53:17 --> Utf8 Class Initialized
INFO - 2016-09-27 09:53:17 --> URI Class Initialized
INFO - 2016-09-27 09:53:17 --> Router Class Initialized
INFO - 2016-09-27 09:53:17 --> Output Class Initialized
INFO - 2016-09-27 09:53:17 --> Security Class Initialized
DEBUG - 2016-09-27 09:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 09:53:17 --> Input Class Initialized
INFO - 2016-09-27 09:53:17 --> Language Class Initialized
INFO - 2016-09-27 09:53:17 --> Loader Class Initialized
INFO - 2016-09-27 09:53:17 --> Helper loaded: url_helper
INFO - 2016-09-27 09:53:17 --> Helper loaded: language_helper
INFO - 2016-09-27 09:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 09:53:17 --> Controller Class Initialized
INFO - 2016-09-27 09:53:17 --> Database Driver Class Initialized
INFO - 2016-09-27 09:53:17 --> Model Class Initialized
INFO - 2016-09-27 09:53:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 09:53:17 --> Config Class Initialized
INFO - 2016-09-27 09:53:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 09:53:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 09:53:17 --> Utf8 Class Initialized
INFO - 2016-09-27 09:53:17 --> URI Class Initialized
INFO - 2016-09-27 09:53:17 --> Router Class Initialized
INFO - 2016-09-27 09:53:17 --> Output Class Initialized
INFO - 2016-09-27 09:53:17 --> Security Class Initialized
DEBUG - 2016-09-27 09:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 09:53:17 --> Input Class Initialized
INFO - 2016-09-27 09:53:17 --> Language Class Initialized
INFO - 2016-09-27 09:53:17 --> Loader Class Initialized
INFO - 2016-09-27 09:53:17 --> Helper loaded: url_helper
INFO - 2016-09-27 09:53:17 --> Helper loaded: language_helper
INFO - 2016-09-27 09:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 09:53:17 --> Controller Class Initialized
INFO - 2016-09-27 09:53:17 --> Database Driver Class Initialized
INFO - 2016-09-27 09:53:17 --> Model Class Initialized
INFO - 2016-09-27 09:53:17 --> Model Class Initialized
INFO - 2016-09-27 09:53:17 --> Model Class Initialized
INFO - 2016-09-27 09:53:17 --> Model Class Initialized
INFO - 2016-09-27 09:53:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 09:53:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 09:53:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-27 09:53:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 09:53:17 --> Final output sent to browser
DEBUG - 2016-09-27 09:53:17 --> Total execution time: 0.0851
INFO - 2016-09-27 09:53:31 --> Config Class Initialized
INFO - 2016-09-27 09:53:31 --> Hooks Class Initialized
DEBUG - 2016-09-27 09:53:31 --> UTF-8 Support Enabled
INFO - 2016-09-27 09:53:31 --> Utf8 Class Initialized
INFO - 2016-09-27 09:53:31 --> URI Class Initialized
INFO - 2016-09-27 09:53:31 --> Router Class Initialized
INFO - 2016-09-27 09:53:31 --> Output Class Initialized
INFO - 2016-09-27 09:53:31 --> Security Class Initialized
DEBUG - 2016-09-27 09:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 09:53:31 --> Input Class Initialized
INFO - 2016-09-27 09:53:31 --> Language Class Initialized
INFO - 2016-09-27 09:53:31 --> Loader Class Initialized
INFO - 2016-09-27 09:53:31 --> Helper loaded: url_helper
INFO - 2016-09-27 09:53:31 --> Helper loaded: language_helper
INFO - 2016-09-27 09:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 09:53:31 --> Controller Class Initialized
INFO - 2016-09-27 09:53:31 --> Database Driver Class Initialized
INFO - 2016-09-27 09:53:31 --> Model Class Initialized
INFO - 2016-09-27 09:53:31 --> Model Class Initialized
INFO - 2016-09-27 09:53:31 --> Model Class Initialized
INFO - 2016-09-27 09:53:31 --> Model Class Initialized
INFO - 2016-09-27 09:53:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 09:53:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 09:53:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-27 09:53:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 09:53:31 --> Final output sent to browser
DEBUG - 2016-09-27 09:53:31 --> Total execution time: 0.0818
INFO - 2016-09-27 09:54:47 --> Config Class Initialized
INFO - 2016-09-27 09:54:47 --> Hooks Class Initialized
DEBUG - 2016-09-27 09:54:47 --> UTF-8 Support Enabled
INFO - 2016-09-27 09:54:47 --> Utf8 Class Initialized
INFO - 2016-09-27 09:54:47 --> URI Class Initialized
INFO - 2016-09-27 09:54:47 --> Router Class Initialized
INFO - 2016-09-27 09:54:47 --> Output Class Initialized
INFO - 2016-09-27 09:54:47 --> Security Class Initialized
DEBUG - 2016-09-27 09:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 09:54:47 --> Input Class Initialized
INFO - 2016-09-27 09:54:47 --> Language Class Initialized
INFO - 2016-09-27 09:54:47 --> Loader Class Initialized
INFO - 2016-09-27 09:54:47 --> Helper loaded: url_helper
INFO - 2016-09-27 09:54:47 --> Helper loaded: language_helper
INFO - 2016-09-27 09:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 09:54:47 --> Controller Class Initialized
INFO - 2016-09-27 09:54:47 --> Database Driver Class Initialized
INFO - 2016-09-27 09:54:47 --> Model Class Initialized
INFO - 2016-09-27 09:54:47 --> Model Class Initialized
INFO - 2016-09-27 09:54:47 --> Model Class Initialized
INFO - 2016-09-27 09:54:47 --> Model Class Initialized
INFO - 2016-09-27 09:54:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 09:54:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 09:54:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-27 09:54:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 09:54:47 --> Final output sent to browser
DEBUG - 2016-09-27 09:54:47 --> Total execution time: 0.0990
INFO - 2016-09-27 14:40:10 --> Config Class Initialized
INFO - 2016-09-27 14:40:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:40:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:40:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:40:10 --> URI Class Initialized
INFO - 2016-09-27 14:40:10 --> Router Class Initialized
INFO - 2016-09-27 14:40:10 --> Output Class Initialized
INFO - 2016-09-27 14:40:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:40:10 --> Input Class Initialized
INFO - 2016-09-27 14:40:10 --> Language Class Initialized
INFO - 2016-09-27 14:40:10 --> Loader Class Initialized
INFO - 2016-09-27 14:40:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:40:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:40:10 --> Controller Class Initialized
INFO - 2016-09-27 14:40:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:40:10 --> Model Class Initialized
INFO - 2016-09-27 14:40:10 --> Model Class Initialized
INFO - 2016-09-27 14:40:10 --> Model Class Initialized
INFO - 2016-09-27 14:40:10 --> Model Class Initialized
INFO - 2016-09-27 14:40:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:40:10 --> Config Class Initialized
INFO - 2016-09-27 14:40:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:40:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:40:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:40:10 --> URI Class Initialized
INFO - 2016-09-27 14:40:10 --> Router Class Initialized
INFO - 2016-09-27 14:40:10 --> Output Class Initialized
INFO - 2016-09-27 14:40:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:40:10 --> Input Class Initialized
INFO - 2016-09-27 14:40:10 --> Language Class Initialized
INFO - 2016-09-27 14:40:10 --> Loader Class Initialized
INFO - 2016-09-27 14:40:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:40:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:40:10 --> Controller Class Initialized
INFO - 2016-09-27 14:40:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:40:10 --> Model Class Initialized
INFO - 2016-09-27 14:40:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:40:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-09-27 14:40:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-09-27 14:40:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-09-27 14:40:10 --> Final output sent to browser
DEBUG - 2016-09-27 14:40:10 --> Total execution time: 0.0604
INFO - 2016-09-27 14:40:15 --> Config Class Initialized
INFO - 2016-09-27 14:40:15 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:40:15 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:40:15 --> Utf8 Class Initialized
INFO - 2016-09-27 14:40:15 --> URI Class Initialized
INFO - 2016-09-27 14:40:15 --> Router Class Initialized
INFO - 2016-09-27 14:40:15 --> Output Class Initialized
INFO - 2016-09-27 14:40:15 --> Security Class Initialized
DEBUG - 2016-09-27 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:40:15 --> Input Class Initialized
INFO - 2016-09-27 14:40:15 --> Language Class Initialized
INFO - 2016-09-27 14:40:15 --> Loader Class Initialized
INFO - 2016-09-27 14:40:15 --> Helper loaded: url_helper
INFO - 2016-09-27 14:40:15 --> Helper loaded: language_helper
INFO - 2016-09-27 14:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:40:15 --> Controller Class Initialized
INFO - 2016-09-27 14:40:15 --> Database Driver Class Initialized
INFO - 2016-09-27 14:40:15 --> Model Class Initialized
INFO - 2016-09-27 14:40:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:40:15 --> Config Class Initialized
INFO - 2016-09-27 14:40:15 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:40:15 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:40:15 --> Utf8 Class Initialized
INFO - 2016-09-27 14:40:15 --> URI Class Initialized
INFO - 2016-09-27 14:40:15 --> Router Class Initialized
INFO - 2016-09-27 14:40:15 --> Output Class Initialized
INFO - 2016-09-27 14:40:15 --> Security Class Initialized
DEBUG - 2016-09-27 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:40:15 --> Input Class Initialized
INFO - 2016-09-27 14:40:15 --> Language Class Initialized
INFO - 2016-09-27 14:40:15 --> Loader Class Initialized
INFO - 2016-09-27 14:40:15 --> Helper loaded: url_helper
INFO - 2016-09-27 14:40:15 --> Helper loaded: language_helper
INFO - 2016-09-27 14:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:40:15 --> Controller Class Initialized
INFO - 2016-09-27 14:40:15 --> Database Driver Class Initialized
INFO - 2016-09-27 14:40:15 --> Model Class Initialized
INFO - 2016-09-27 14:40:15 --> Model Class Initialized
INFO - 2016-09-27 14:40:15 --> Model Class Initialized
INFO - 2016-09-27 14:40:15 --> Model Class Initialized
INFO - 2016-09-27 14:40:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:40:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:40:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-09-27 14:40:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:40:15 --> Final output sent to browser
DEBUG - 2016-09-27 14:40:15 --> Total execution time: 0.0780
INFO - 2016-09-27 14:40:22 --> Config Class Initialized
INFO - 2016-09-27 14:40:22 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:40:22 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:40:22 --> Utf8 Class Initialized
INFO - 2016-09-27 14:40:22 --> URI Class Initialized
INFO - 2016-09-27 14:40:22 --> Router Class Initialized
INFO - 2016-09-27 14:40:22 --> Output Class Initialized
INFO - 2016-09-27 14:40:22 --> Security Class Initialized
DEBUG - 2016-09-27 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:40:22 --> Input Class Initialized
INFO - 2016-09-27 14:40:22 --> Language Class Initialized
INFO - 2016-09-27 14:40:22 --> Loader Class Initialized
INFO - 2016-09-27 14:40:22 --> Helper loaded: url_helper
INFO - 2016-09-27 14:40:22 --> Helper loaded: language_helper
INFO - 2016-09-27 14:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:40:22 --> Controller Class Initialized
INFO - 2016-09-27 14:40:22 --> Database Driver Class Initialized
INFO - 2016-09-27 14:40:22 --> Model Class Initialized
INFO - 2016-09-27 14:40:22 --> Model Class Initialized
INFO - 2016-09-27 14:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:40:22 --> Final output sent to browser
DEBUG - 2016-09-27 14:40:22 --> Total execution time: 0.0713
INFO - 2016-09-27 14:41:30 --> Config Class Initialized
INFO - 2016-09-27 14:41:30 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:41:30 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:41:30 --> Utf8 Class Initialized
INFO - 2016-09-27 14:41:30 --> URI Class Initialized
INFO - 2016-09-27 14:41:30 --> Router Class Initialized
INFO - 2016-09-27 14:41:30 --> Output Class Initialized
INFO - 2016-09-27 14:41:30 --> Security Class Initialized
DEBUG - 2016-09-27 14:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:41:30 --> Input Class Initialized
INFO - 2016-09-27 14:41:30 --> Language Class Initialized
INFO - 2016-09-27 14:41:30 --> Loader Class Initialized
INFO - 2016-09-27 14:41:30 --> Helper loaded: url_helper
INFO - 2016-09-27 14:41:30 --> Helper loaded: language_helper
INFO - 2016-09-27 14:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:41:30 --> Controller Class Initialized
INFO - 2016-09-27 14:41:30 --> Database Driver Class Initialized
INFO - 2016-09-27 14:41:30 --> Model Class Initialized
INFO - 2016-09-27 14:41:30 --> Model Class Initialized
INFO - 2016-09-27 14:41:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:41:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:41:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:41:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:41:30 --> Final output sent to browser
DEBUG - 2016-09-27 14:41:30 --> Total execution time: 0.0714
INFO - 2016-09-27 14:41:51 --> Config Class Initialized
INFO - 2016-09-27 14:41:51 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:41:51 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:41:51 --> Utf8 Class Initialized
INFO - 2016-09-27 14:41:51 --> URI Class Initialized
INFO - 2016-09-27 14:41:51 --> Router Class Initialized
INFO - 2016-09-27 14:41:51 --> Output Class Initialized
INFO - 2016-09-27 14:41:51 --> Security Class Initialized
DEBUG - 2016-09-27 14:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:41:51 --> Input Class Initialized
INFO - 2016-09-27 14:41:51 --> Language Class Initialized
INFO - 2016-09-27 14:41:51 --> Loader Class Initialized
INFO - 2016-09-27 14:41:51 --> Helper loaded: url_helper
INFO - 2016-09-27 14:41:51 --> Helper loaded: language_helper
INFO - 2016-09-27 14:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:41:51 --> Controller Class Initialized
INFO - 2016-09-27 14:41:52 --> Database Driver Class Initialized
INFO - 2016-09-27 14:41:52 --> Model Class Initialized
INFO - 2016-09-27 14:41:52 --> Model Class Initialized
INFO - 2016-09-27 14:41:52 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-27 14:41:52 --> Severity: Warning --> Missing argument 1 for Ujian::validate_ujian_me(), called in C:\wamp64\www\savsoftquiz\system\core\CodeIgniter.php on line 514 and defined C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 330
ERROR - 2016-09-27 14:41:52 --> Severity: Notice --> Undefined variable: quid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 336
ERROR - 2016-09-27 14:41:52 --> Severity: Notice --> Undefined variable: quid C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 347
INFO - 2016-09-27 14:41:52 --> Config Class Initialized
INFO - 2016-09-27 14:41:52 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:41:52 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:41:52 --> Utf8 Class Initialized
INFO - 2016-09-27 14:41:52 --> URI Class Initialized
INFO - 2016-09-27 14:41:52 --> Router Class Initialized
INFO - 2016-09-27 14:41:52 --> Output Class Initialized
INFO - 2016-09-27 14:41:52 --> Security Class Initialized
DEBUG - 2016-09-27 14:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:41:52 --> Input Class Initialized
INFO - 2016-09-27 14:41:52 --> Language Class Initialized
INFO - 2016-09-27 14:41:52 --> Loader Class Initialized
INFO - 2016-09-27 14:41:52 --> Helper loaded: url_helper
INFO - 2016-09-27 14:41:52 --> Helper loaded: language_helper
INFO - 2016-09-27 14:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:41:52 --> Controller Class Initialized
INFO - 2016-09-27 14:41:52 --> Database Driver Class Initialized
INFO - 2016-09-27 14:41:52 --> Model Class Initialized
INFO - 2016-09-27 14:41:52 --> Model Class Initialized
INFO - 2016-09-27 14:41:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:41:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:41:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-27 14:41:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:41:52 --> Final output sent to browser
DEBUG - 2016-09-27 14:41:52 --> Total execution time: 0.0821
INFO - 2016-09-27 14:43:31 --> Config Class Initialized
INFO - 2016-09-27 14:43:31 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:43:31 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:43:31 --> Utf8 Class Initialized
INFO - 2016-09-27 14:43:31 --> URI Class Initialized
INFO - 2016-09-27 14:43:31 --> Router Class Initialized
INFO - 2016-09-27 14:43:31 --> Output Class Initialized
INFO - 2016-09-27 14:43:31 --> Security Class Initialized
DEBUG - 2016-09-27 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:43:31 --> Input Class Initialized
INFO - 2016-09-27 14:43:31 --> Language Class Initialized
INFO - 2016-09-27 14:43:31 --> Loader Class Initialized
INFO - 2016-09-27 14:43:31 --> Helper loaded: url_helper
INFO - 2016-09-27 14:43:31 --> Helper loaded: language_helper
INFO - 2016-09-27 14:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:43:31 --> Controller Class Initialized
INFO - 2016-09-27 14:43:31 --> Database Driver Class Initialized
INFO - 2016-09-27 14:43:31 --> Model Class Initialized
INFO - 2016-09-27 14:43:31 --> Model Class Initialized
INFO - 2016-09-27 14:43:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:43:31 --> Final output sent to browser
DEBUG - 2016-09-27 14:43:31 --> Total execution time: 0.0799
INFO - 2016-09-27 14:45:18 --> Config Class Initialized
INFO - 2016-09-27 14:45:18 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:18 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:18 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:18 --> URI Class Initialized
INFO - 2016-09-27 14:45:18 --> Router Class Initialized
INFO - 2016-09-27 14:45:18 --> Output Class Initialized
INFO - 2016-09-27 14:45:18 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:18 --> Input Class Initialized
INFO - 2016-09-27 14:45:18 --> Language Class Initialized
INFO - 2016-09-27 14:45:18 --> Loader Class Initialized
INFO - 2016-09-27 14:45:18 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:18 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:18 --> Controller Class Initialized
INFO - 2016-09-27 14:45:18 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:18 --> Model Class Initialized
INFO - 2016-09-27 14:45:18 --> Model Class Initialized
INFO - 2016-09-27 14:45:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:45:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:18 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:18 --> Total execution time: 0.0705
INFO - 2016-09-27 14:45:41 --> Config Class Initialized
INFO - 2016-09-27 14:45:41 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:41 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:41 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:41 --> URI Class Initialized
INFO - 2016-09-27 14:45:41 --> Router Class Initialized
INFO - 2016-09-27 14:45:41 --> Output Class Initialized
INFO - 2016-09-27 14:45:41 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:41 --> Input Class Initialized
INFO - 2016-09-27 14:45:41 --> Language Class Initialized
INFO - 2016-09-27 14:45:41 --> Loader Class Initialized
INFO - 2016-09-27 14:45:41 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:41 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:41 --> Controller Class Initialized
INFO - 2016-09-27 14:45:41 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:41 --> Model Class Initialized
INFO - 2016-09-27 14:45:41 --> Model Class Initialized
INFO - 2016-09-27 14:45:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:41 --> Config Class Initialized
INFO - 2016-09-27 14:45:41 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:41 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:41 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:41 --> URI Class Initialized
INFO - 2016-09-27 14:45:41 --> Router Class Initialized
INFO - 2016-09-27 14:45:41 --> Output Class Initialized
INFO - 2016-09-27 14:45:41 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:41 --> Input Class Initialized
INFO - 2016-09-27 14:45:41 --> Language Class Initialized
INFO - 2016-09-27 14:45:41 --> Loader Class Initialized
INFO - 2016-09-27 14:45:41 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:41 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:41 --> Controller Class Initialized
INFO - 2016-09-27 14:45:41 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:41 --> Model Class Initialized
INFO - 2016-09-27 14:45:41 --> Model Class Initialized
INFO - 2016-09-27 14:45:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:45:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:41 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:41 --> Total execution time: 0.0849
INFO - 2016-09-27 14:45:45 --> Config Class Initialized
INFO - 2016-09-27 14:45:45 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:45 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:45 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:45 --> URI Class Initialized
INFO - 2016-09-27 14:45:45 --> Router Class Initialized
INFO - 2016-09-27 14:45:45 --> Output Class Initialized
INFO - 2016-09-27 14:45:45 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:45 --> Input Class Initialized
INFO - 2016-09-27 14:45:45 --> Language Class Initialized
INFO - 2016-09-27 14:45:45 --> Loader Class Initialized
INFO - 2016-09-27 14:45:45 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:45 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:45 --> Controller Class Initialized
INFO - 2016-09-27 14:45:45 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:45 --> Model Class Initialized
INFO - 2016-09-27 14:45:45 --> Model Class Initialized
INFO - 2016-09-27 14:45:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:45 --> Config Class Initialized
INFO - 2016-09-27 14:45:45 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:45 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:45 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:45 --> URI Class Initialized
INFO - 2016-09-27 14:45:45 --> Router Class Initialized
INFO - 2016-09-27 14:45:45 --> Output Class Initialized
INFO - 2016-09-27 14:45:45 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:45 --> Input Class Initialized
INFO - 2016-09-27 14:45:45 --> Language Class Initialized
INFO - 2016-09-27 14:45:45 --> Loader Class Initialized
INFO - 2016-09-27 14:45:45 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:45 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:45 --> Controller Class Initialized
INFO - 2016-09-27 14:45:45 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:45 --> Model Class Initialized
INFO - 2016-09-27 14:45:45 --> Model Class Initialized
INFO - 2016-09-27 14:45:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:45:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:45 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:45 --> Total execution time: 0.0679
INFO - 2016-09-27 14:45:48 --> Config Class Initialized
INFO - 2016-09-27 14:45:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:48 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:48 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:48 --> URI Class Initialized
INFO - 2016-09-27 14:45:48 --> Router Class Initialized
INFO - 2016-09-27 14:45:48 --> Output Class Initialized
INFO - 2016-09-27 14:45:48 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:48 --> Input Class Initialized
INFO - 2016-09-27 14:45:48 --> Language Class Initialized
INFO - 2016-09-27 14:45:48 --> Loader Class Initialized
INFO - 2016-09-27 14:45:48 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:48 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:48 --> Controller Class Initialized
INFO - 2016-09-27 14:45:48 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:48 --> Model Class Initialized
INFO - 2016-09-27 14:45:48 --> Model Class Initialized
INFO - 2016-09-27 14:45:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:48 --> Config Class Initialized
INFO - 2016-09-27 14:45:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:48 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:48 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:48 --> URI Class Initialized
INFO - 2016-09-27 14:45:48 --> Router Class Initialized
INFO - 2016-09-27 14:45:48 --> Output Class Initialized
INFO - 2016-09-27 14:45:48 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:48 --> Input Class Initialized
INFO - 2016-09-27 14:45:48 --> Language Class Initialized
INFO - 2016-09-27 14:45:48 --> Loader Class Initialized
INFO - 2016-09-27 14:45:48 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:48 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:48 --> Controller Class Initialized
INFO - 2016-09-27 14:45:48 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:48 --> Model Class Initialized
INFO - 2016-09-27 14:45:48 --> Model Class Initialized
INFO - 2016-09-27 14:45:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:49 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:49 --> Total execution time: 0.0670
INFO - 2016-09-27 14:45:52 --> Config Class Initialized
INFO - 2016-09-27 14:45:52 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:52 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:52 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:52 --> URI Class Initialized
INFO - 2016-09-27 14:45:52 --> Router Class Initialized
INFO - 2016-09-27 14:45:52 --> Output Class Initialized
INFO - 2016-09-27 14:45:52 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:52 --> Input Class Initialized
INFO - 2016-09-27 14:45:52 --> Language Class Initialized
INFO - 2016-09-27 14:45:52 --> Loader Class Initialized
INFO - 2016-09-27 14:45:52 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:52 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:52 --> Controller Class Initialized
INFO - 2016-09-27 14:45:52 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:52 --> Model Class Initialized
INFO - 2016-09-27 14:45:52 --> Model Class Initialized
INFO - 2016-09-27 14:45:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:52 --> Config Class Initialized
INFO - 2016-09-27 14:45:52 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:52 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:52 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:52 --> URI Class Initialized
INFO - 2016-09-27 14:45:52 --> Router Class Initialized
INFO - 2016-09-27 14:45:52 --> Output Class Initialized
INFO - 2016-09-27 14:45:52 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:52 --> Input Class Initialized
INFO - 2016-09-27 14:45:52 --> Language Class Initialized
INFO - 2016-09-27 14:45:52 --> Loader Class Initialized
INFO - 2016-09-27 14:45:52 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:52 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:52 --> Controller Class Initialized
INFO - 2016-09-27 14:45:52 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:52 --> Model Class Initialized
INFO - 2016-09-27 14:45:52 --> Model Class Initialized
INFO - 2016-09-27 14:45:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:45:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:52 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:52 --> Total execution time: 0.0683
INFO - 2016-09-27 14:45:56 --> Config Class Initialized
INFO - 2016-09-27 14:45:56 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:56 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:56 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:56 --> URI Class Initialized
INFO - 2016-09-27 14:45:56 --> Router Class Initialized
INFO - 2016-09-27 14:45:56 --> Output Class Initialized
INFO - 2016-09-27 14:45:56 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:56 --> Input Class Initialized
INFO - 2016-09-27 14:45:56 --> Language Class Initialized
INFO - 2016-09-27 14:45:56 --> Loader Class Initialized
INFO - 2016-09-27 14:45:56 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:56 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:56 --> Controller Class Initialized
INFO - 2016-09-27 14:45:56 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:56 --> Model Class Initialized
INFO - 2016-09-27 14:45:56 --> Model Class Initialized
INFO - 2016-09-27 14:45:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:56 --> Config Class Initialized
INFO - 2016-09-27 14:45:56 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:56 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:56 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:56 --> URI Class Initialized
INFO - 2016-09-27 14:45:56 --> Router Class Initialized
INFO - 2016-09-27 14:45:56 --> Output Class Initialized
INFO - 2016-09-27 14:45:56 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:56 --> Input Class Initialized
INFO - 2016-09-27 14:45:56 --> Language Class Initialized
INFO - 2016-09-27 14:45:56 --> Loader Class Initialized
INFO - 2016-09-27 14:45:56 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:56 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:56 --> Controller Class Initialized
INFO - 2016-09-27 14:45:56 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:56 --> Model Class Initialized
INFO - 2016-09-27 14:45:56 --> Model Class Initialized
INFO - 2016-09-27 14:45:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:45:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:56 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:56 --> Total execution time: 0.0650
INFO - 2016-09-27 14:45:59 --> Config Class Initialized
INFO - 2016-09-27 14:45:59 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:59 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:59 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:59 --> URI Class Initialized
INFO - 2016-09-27 14:45:59 --> Router Class Initialized
INFO - 2016-09-27 14:45:59 --> Output Class Initialized
INFO - 2016-09-27 14:45:59 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:59 --> Input Class Initialized
INFO - 2016-09-27 14:45:59 --> Language Class Initialized
INFO - 2016-09-27 14:45:59 --> Loader Class Initialized
INFO - 2016-09-27 14:45:59 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:59 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:59 --> Controller Class Initialized
INFO - 2016-09-27 14:45:59 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:59 --> Model Class Initialized
INFO - 2016-09-27 14:45:59 --> Model Class Initialized
INFO - 2016-09-27 14:45:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:59 --> Config Class Initialized
INFO - 2016-09-27 14:45:59 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:45:59 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:45:59 --> Utf8 Class Initialized
INFO - 2016-09-27 14:45:59 --> URI Class Initialized
INFO - 2016-09-27 14:45:59 --> Router Class Initialized
INFO - 2016-09-27 14:45:59 --> Output Class Initialized
INFO - 2016-09-27 14:45:59 --> Security Class Initialized
DEBUG - 2016-09-27 14:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:45:59 --> Input Class Initialized
INFO - 2016-09-27 14:45:59 --> Language Class Initialized
INFO - 2016-09-27 14:45:59 --> Loader Class Initialized
INFO - 2016-09-27 14:45:59 --> Helper loaded: url_helper
INFO - 2016-09-27 14:45:59 --> Helper loaded: language_helper
INFO - 2016-09-27 14:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:45:59 --> Controller Class Initialized
INFO - 2016-09-27 14:45:59 --> Database Driver Class Initialized
INFO - 2016-09-27 14:45:59 --> Model Class Initialized
INFO - 2016-09-27 14:45:59 --> Model Class Initialized
INFO - 2016-09-27 14:45:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:45:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:45:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:45:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:45:59 --> Final output sent to browser
DEBUG - 2016-09-27 14:45:59 --> Total execution time: 0.0672
INFO - 2016-09-27 14:46:03 --> Config Class Initialized
INFO - 2016-09-27 14:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:03 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:03 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:03 --> URI Class Initialized
INFO - 2016-09-27 14:46:03 --> Router Class Initialized
INFO - 2016-09-27 14:46:03 --> Output Class Initialized
INFO - 2016-09-27 14:46:03 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:03 --> Input Class Initialized
INFO - 2016-09-27 14:46:03 --> Language Class Initialized
INFO - 2016-09-27 14:46:03 --> Loader Class Initialized
INFO - 2016-09-27 14:46:03 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:03 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:03 --> Controller Class Initialized
INFO - 2016-09-27 14:46:03 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:03 --> Model Class Initialized
INFO - 2016-09-27 14:46:03 --> Model Class Initialized
INFO - 2016-09-27 14:46:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:03 --> Config Class Initialized
INFO - 2016-09-27 14:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:03 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:03 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:03 --> URI Class Initialized
INFO - 2016-09-27 14:46:03 --> Router Class Initialized
INFO - 2016-09-27 14:46:03 --> Output Class Initialized
INFO - 2016-09-27 14:46:03 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:03 --> Input Class Initialized
INFO - 2016-09-27 14:46:03 --> Language Class Initialized
INFO - 2016-09-27 14:46:03 --> Loader Class Initialized
INFO - 2016-09-27 14:46:03 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:03 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:03 --> Controller Class Initialized
INFO - 2016-09-27 14:46:03 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:03 --> Model Class Initialized
INFO - 2016-09-27 14:46:03 --> Model Class Initialized
INFO - 2016-09-27 14:46:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:46:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:03 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:03 --> Total execution time: 0.0665
INFO - 2016-09-27 14:46:06 --> Config Class Initialized
INFO - 2016-09-27 14:46:06 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:06 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:06 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:06 --> URI Class Initialized
INFO - 2016-09-27 14:46:06 --> Router Class Initialized
INFO - 2016-09-27 14:46:06 --> Output Class Initialized
INFO - 2016-09-27 14:46:06 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:06 --> Input Class Initialized
INFO - 2016-09-27 14:46:06 --> Language Class Initialized
INFO - 2016-09-27 14:46:06 --> Loader Class Initialized
INFO - 2016-09-27 14:46:06 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:06 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:06 --> Controller Class Initialized
INFO - 2016-09-27 14:46:06 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:06 --> Model Class Initialized
INFO - 2016-09-27 14:46:06 --> Model Class Initialized
INFO - 2016-09-27 14:46:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:06 --> Config Class Initialized
INFO - 2016-09-27 14:46:06 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:06 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:06 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:06 --> URI Class Initialized
INFO - 2016-09-27 14:46:06 --> Router Class Initialized
INFO - 2016-09-27 14:46:06 --> Output Class Initialized
INFO - 2016-09-27 14:46:06 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:06 --> Input Class Initialized
INFO - 2016-09-27 14:46:06 --> Language Class Initialized
INFO - 2016-09-27 14:46:06 --> Loader Class Initialized
INFO - 2016-09-27 14:46:06 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:06 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:06 --> Controller Class Initialized
INFO - 2016-09-27 14:46:06 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:06 --> Model Class Initialized
INFO - 2016-09-27 14:46:06 --> Model Class Initialized
INFO - 2016-09-27 14:46:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:07 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:07 --> Total execution time: 0.0666
INFO - 2016-09-27 14:46:10 --> Config Class Initialized
INFO - 2016-09-27 14:46:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:10 --> URI Class Initialized
INFO - 2016-09-27 14:46:10 --> Router Class Initialized
INFO - 2016-09-27 14:46:10 --> Output Class Initialized
INFO - 2016-09-27 14:46:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:10 --> Input Class Initialized
INFO - 2016-09-27 14:46:10 --> Language Class Initialized
INFO - 2016-09-27 14:46:10 --> Loader Class Initialized
INFO - 2016-09-27 14:46:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:10 --> Controller Class Initialized
INFO - 2016-09-27 14:46:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:10 --> Model Class Initialized
INFO - 2016-09-27 14:46:10 --> Model Class Initialized
INFO - 2016-09-27 14:46:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:10 --> Config Class Initialized
INFO - 2016-09-27 14:46:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:10 --> URI Class Initialized
INFO - 2016-09-27 14:46:10 --> Router Class Initialized
INFO - 2016-09-27 14:46:10 --> Output Class Initialized
INFO - 2016-09-27 14:46:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:10 --> Input Class Initialized
INFO - 2016-09-27 14:46:10 --> Language Class Initialized
INFO - 2016-09-27 14:46:10 --> Loader Class Initialized
INFO - 2016-09-27 14:46:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:10 --> Controller Class Initialized
INFO - 2016-09-27 14:46:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:10 --> Model Class Initialized
INFO - 2016-09-27 14:46:10 --> Model Class Initialized
INFO - 2016-09-27 14:46:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:46:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:10 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:10 --> Total execution time: 0.0640
INFO - 2016-09-27 14:46:14 --> Config Class Initialized
INFO - 2016-09-27 14:46:14 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:14 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:14 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:14 --> URI Class Initialized
INFO - 2016-09-27 14:46:14 --> Router Class Initialized
INFO - 2016-09-27 14:46:14 --> Output Class Initialized
INFO - 2016-09-27 14:46:14 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:14 --> Input Class Initialized
INFO - 2016-09-27 14:46:14 --> Language Class Initialized
INFO - 2016-09-27 14:46:14 --> Loader Class Initialized
INFO - 2016-09-27 14:46:14 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:14 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:14 --> Controller Class Initialized
INFO - 2016-09-27 14:46:14 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:14 --> Model Class Initialized
INFO - 2016-09-27 14:46:14 --> Model Class Initialized
INFO - 2016-09-27 14:46:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:14 --> Config Class Initialized
INFO - 2016-09-27 14:46:14 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:14 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:14 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:14 --> URI Class Initialized
INFO - 2016-09-27 14:46:14 --> Router Class Initialized
INFO - 2016-09-27 14:46:14 --> Output Class Initialized
INFO - 2016-09-27 14:46:14 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:14 --> Input Class Initialized
INFO - 2016-09-27 14:46:14 --> Language Class Initialized
INFO - 2016-09-27 14:46:14 --> Loader Class Initialized
INFO - 2016-09-27 14:46:14 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:14 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:14 --> Controller Class Initialized
INFO - 2016-09-27 14:46:14 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:14 --> Model Class Initialized
INFO - 2016-09-27 14:46:14 --> Model Class Initialized
INFO - 2016-09-27 14:46:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:46:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:14 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:14 --> Total execution time: 0.0746
INFO - 2016-09-27 14:46:17 --> Config Class Initialized
INFO - 2016-09-27 14:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:17 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:17 --> URI Class Initialized
INFO - 2016-09-27 14:46:17 --> Router Class Initialized
INFO - 2016-09-27 14:46:17 --> Output Class Initialized
INFO - 2016-09-27 14:46:17 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:17 --> Input Class Initialized
INFO - 2016-09-27 14:46:17 --> Language Class Initialized
INFO - 2016-09-27 14:46:17 --> Loader Class Initialized
INFO - 2016-09-27 14:46:17 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:17 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:17 --> Controller Class Initialized
INFO - 2016-09-27 14:46:17 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:17 --> Model Class Initialized
INFO - 2016-09-27 14:46:17 --> Model Class Initialized
INFO - 2016-09-27 14:46:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:17 --> Config Class Initialized
INFO - 2016-09-27 14:46:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:17 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:17 --> URI Class Initialized
INFO - 2016-09-27 14:46:17 --> Router Class Initialized
INFO - 2016-09-27 14:46:17 --> Output Class Initialized
INFO - 2016-09-27 14:46:17 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:17 --> Input Class Initialized
INFO - 2016-09-27 14:46:17 --> Language Class Initialized
INFO - 2016-09-27 14:46:17 --> Loader Class Initialized
INFO - 2016-09-27 14:46:17 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:17 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:17 --> Controller Class Initialized
INFO - 2016-09-27 14:46:17 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:17 --> Model Class Initialized
INFO - 2016-09-27 14:46:17 --> Model Class Initialized
INFO - 2016-09-27 14:46:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:46:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:17 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:17 --> Total execution time: 0.0617
INFO - 2016-09-27 14:46:21 --> Config Class Initialized
INFO - 2016-09-27 14:46:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:21 --> URI Class Initialized
INFO - 2016-09-27 14:46:21 --> Router Class Initialized
INFO - 2016-09-27 14:46:21 --> Output Class Initialized
INFO - 2016-09-27 14:46:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:21 --> Input Class Initialized
INFO - 2016-09-27 14:46:21 --> Language Class Initialized
INFO - 2016-09-27 14:46:21 --> Loader Class Initialized
INFO - 2016-09-27 14:46:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:21 --> Controller Class Initialized
INFO - 2016-09-27 14:46:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:21 --> Model Class Initialized
INFO - 2016-09-27 14:46:21 --> Model Class Initialized
INFO - 2016-09-27 14:46:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:21 --> Config Class Initialized
INFO - 2016-09-27 14:46:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:21 --> URI Class Initialized
INFO - 2016-09-27 14:46:21 --> Router Class Initialized
INFO - 2016-09-27 14:46:21 --> Output Class Initialized
INFO - 2016-09-27 14:46:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:21 --> Input Class Initialized
INFO - 2016-09-27 14:46:21 --> Language Class Initialized
INFO - 2016-09-27 14:46:21 --> Loader Class Initialized
INFO - 2016-09-27 14:46:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:21 --> Controller Class Initialized
INFO - 2016-09-27 14:46:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:21 --> Model Class Initialized
INFO - 2016-09-27 14:46:21 --> Model Class Initialized
INFO - 2016-09-27 14:46:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:46:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:21 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:21 --> Total execution time: 0.0630
INFO - 2016-09-27 14:46:23 --> Config Class Initialized
INFO - 2016-09-27 14:46:23 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:46:23 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:46:23 --> Utf8 Class Initialized
INFO - 2016-09-27 14:46:23 --> URI Class Initialized
INFO - 2016-09-27 14:46:23 --> Router Class Initialized
INFO - 2016-09-27 14:46:23 --> Output Class Initialized
INFO - 2016-09-27 14:46:23 --> Security Class Initialized
DEBUG - 2016-09-27 14:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:46:23 --> Input Class Initialized
INFO - 2016-09-27 14:46:23 --> Language Class Initialized
INFO - 2016-09-27 14:46:23 --> Loader Class Initialized
INFO - 2016-09-27 14:46:23 --> Helper loaded: url_helper
INFO - 2016-09-27 14:46:23 --> Helper loaded: language_helper
INFO - 2016-09-27 14:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:46:23 --> Controller Class Initialized
INFO - 2016-09-27 14:46:23 --> Database Driver Class Initialized
INFO - 2016-09-27 14:46:23 --> Model Class Initialized
INFO - 2016-09-27 14:46:23 --> Model Class Initialized
INFO - 2016-09-27 14:46:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:46:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:46:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:46:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:46:23 --> Final output sent to browser
DEBUG - 2016-09-27 14:46:23 --> Total execution time: 0.0765
INFO - 2016-09-27 14:51:21 --> Config Class Initialized
INFO - 2016-09-27 14:51:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:21 --> URI Class Initialized
INFO - 2016-09-27 14:51:21 --> Router Class Initialized
INFO - 2016-09-27 14:51:21 --> Output Class Initialized
INFO - 2016-09-27 14:51:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:21 --> Input Class Initialized
INFO - 2016-09-27 14:51:21 --> Language Class Initialized
INFO - 2016-09-27 14:51:21 --> Loader Class Initialized
INFO - 2016-09-27 14:51:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:21 --> Controller Class Initialized
INFO - 2016-09-27 14:51:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:21 --> Model Class Initialized
INFO - 2016-09-27 14:51:21 --> Model Class Initialized
INFO - 2016-09-27 14:51:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:51:21 --> Final output sent to browser
DEBUG - 2016-09-27 14:51:21 --> Total execution time: 0.0842
INFO - 2016-09-27 14:51:43 --> Config Class Initialized
INFO - 2016-09-27 14:51:43 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:43 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:43 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:43 --> URI Class Initialized
INFO - 2016-09-27 14:51:43 --> Router Class Initialized
INFO - 2016-09-27 14:51:43 --> Output Class Initialized
INFO - 2016-09-27 14:51:43 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:43 --> Input Class Initialized
INFO - 2016-09-27 14:51:43 --> Language Class Initialized
INFO - 2016-09-27 14:51:43 --> Loader Class Initialized
INFO - 2016-09-27 14:51:43 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:43 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:43 --> Controller Class Initialized
INFO - 2016-09-27 14:51:43 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:43 --> Model Class Initialized
INFO - 2016-09-27 14:51:43 --> Model Class Initialized
INFO - 2016-09-27 14:51:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:43 --> Config Class Initialized
INFO - 2016-09-27 14:51:43 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:43 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:43 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:43 --> URI Class Initialized
INFO - 2016-09-27 14:51:43 --> Router Class Initialized
INFO - 2016-09-27 14:51:43 --> Output Class Initialized
INFO - 2016-09-27 14:51:43 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:43 --> Input Class Initialized
INFO - 2016-09-27 14:51:43 --> Language Class Initialized
INFO - 2016-09-27 14:51:43 --> Loader Class Initialized
INFO - 2016-09-27 14:51:43 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:43 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:43 --> Controller Class Initialized
INFO - 2016-09-27 14:51:43 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:43 --> Model Class Initialized
INFO - 2016-09-27 14:51:43 --> Model Class Initialized
INFO - 2016-09-27 14:51:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:51:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:51:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:51:43 --> Final output sent to browser
DEBUG - 2016-09-27 14:51:43 --> Total execution time: 0.0610
INFO - 2016-09-27 14:51:46 --> Config Class Initialized
INFO - 2016-09-27 14:51:46 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:46 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:46 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:46 --> URI Class Initialized
INFO - 2016-09-27 14:51:46 --> Router Class Initialized
INFO - 2016-09-27 14:51:46 --> Output Class Initialized
INFO - 2016-09-27 14:51:46 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:46 --> Input Class Initialized
INFO - 2016-09-27 14:51:46 --> Language Class Initialized
INFO - 2016-09-27 14:51:46 --> Loader Class Initialized
INFO - 2016-09-27 14:51:46 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:46 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:46 --> Controller Class Initialized
INFO - 2016-09-27 14:51:46 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:46 --> Model Class Initialized
INFO - 2016-09-27 14:51:46 --> Model Class Initialized
INFO - 2016-09-27 14:51:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:47 --> Config Class Initialized
INFO - 2016-09-27 14:51:47 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:47 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:47 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:47 --> URI Class Initialized
INFO - 2016-09-27 14:51:47 --> Router Class Initialized
INFO - 2016-09-27 14:51:47 --> Output Class Initialized
INFO - 2016-09-27 14:51:47 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:47 --> Input Class Initialized
INFO - 2016-09-27 14:51:47 --> Language Class Initialized
INFO - 2016-09-27 14:51:47 --> Loader Class Initialized
INFO - 2016-09-27 14:51:47 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:47 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:47 --> Controller Class Initialized
INFO - 2016-09-27 14:51:47 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:47 --> Model Class Initialized
INFO - 2016-09-27 14:51:47 --> Model Class Initialized
INFO - 2016-09-27 14:51:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:51:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:51:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:51:47 --> Final output sent to browser
DEBUG - 2016-09-27 14:51:47 --> Total execution time: 0.0617
INFO - 2016-09-27 14:51:50 --> Config Class Initialized
INFO - 2016-09-27 14:51:50 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:50 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:50 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:50 --> URI Class Initialized
INFO - 2016-09-27 14:51:50 --> Router Class Initialized
INFO - 2016-09-27 14:51:50 --> Output Class Initialized
INFO - 2016-09-27 14:51:50 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:50 --> Input Class Initialized
INFO - 2016-09-27 14:51:50 --> Language Class Initialized
INFO - 2016-09-27 14:51:50 --> Loader Class Initialized
INFO - 2016-09-27 14:51:50 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:50 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:50 --> Controller Class Initialized
INFO - 2016-09-27 14:51:50 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:50 --> Model Class Initialized
INFO - 2016-09-27 14:51:50 --> Model Class Initialized
INFO - 2016-09-27 14:51:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:50 --> Config Class Initialized
INFO - 2016-09-27 14:51:50 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:50 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:50 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:50 --> URI Class Initialized
INFO - 2016-09-27 14:51:50 --> Router Class Initialized
INFO - 2016-09-27 14:51:50 --> Output Class Initialized
INFO - 2016-09-27 14:51:50 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:50 --> Input Class Initialized
INFO - 2016-09-27 14:51:50 --> Language Class Initialized
INFO - 2016-09-27 14:51:50 --> Loader Class Initialized
INFO - 2016-09-27 14:51:50 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:50 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:50 --> Controller Class Initialized
INFO - 2016-09-27 14:51:50 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:50 --> Model Class Initialized
INFO - 2016-09-27 14:51:50 --> Model Class Initialized
INFO - 2016-09-27 14:51:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:51:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:51:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:51:50 --> Final output sent to browser
DEBUG - 2016-09-27 14:51:50 --> Total execution time: 0.0772
INFO - 2016-09-27 14:51:54 --> Config Class Initialized
INFO - 2016-09-27 14:51:54 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:54 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:54 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:54 --> URI Class Initialized
INFO - 2016-09-27 14:51:54 --> Router Class Initialized
INFO - 2016-09-27 14:51:54 --> Output Class Initialized
INFO - 2016-09-27 14:51:54 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:54 --> Input Class Initialized
INFO - 2016-09-27 14:51:54 --> Language Class Initialized
INFO - 2016-09-27 14:51:54 --> Loader Class Initialized
INFO - 2016-09-27 14:51:54 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:54 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:54 --> Controller Class Initialized
INFO - 2016-09-27 14:51:54 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:54 --> Model Class Initialized
INFO - 2016-09-27 14:51:54 --> Model Class Initialized
INFO - 2016-09-27 14:51:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:54 --> Config Class Initialized
INFO - 2016-09-27 14:51:54 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:54 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:54 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:54 --> URI Class Initialized
INFO - 2016-09-27 14:51:54 --> Router Class Initialized
INFO - 2016-09-27 14:51:54 --> Output Class Initialized
INFO - 2016-09-27 14:51:54 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:54 --> Input Class Initialized
INFO - 2016-09-27 14:51:54 --> Language Class Initialized
INFO - 2016-09-27 14:51:54 --> Loader Class Initialized
INFO - 2016-09-27 14:51:54 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:54 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:54 --> Controller Class Initialized
INFO - 2016-09-27 14:51:54 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:54 --> Model Class Initialized
INFO - 2016-09-27 14:51:54 --> Model Class Initialized
INFO - 2016-09-27 14:51:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:51:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:51:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:51:54 --> Final output sent to browser
DEBUG - 2016-09-27 14:51:54 --> Total execution time: 0.0599
INFO - 2016-09-27 14:51:57 --> Config Class Initialized
INFO - 2016-09-27 14:51:57 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:57 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:57 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:57 --> URI Class Initialized
INFO - 2016-09-27 14:51:57 --> Router Class Initialized
INFO - 2016-09-27 14:51:57 --> Output Class Initialized
INFO - 2016-09-27 14:51:57 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:57 --> Input Class Initialized
INFO - 2016-09-27 14:51:57 --> Language Class Initialized
INFO - 2016-09-27 14:51:57 --> Loader Class Initialized
INFO - 2016-09-27 14:51:57 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:57 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:57 --> Controller Class Initialized
INFO - 2016-09-27 14:51:57 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:57 --> Model Class Initialized
INFO - 2016-09-27 14:51:57 --> Model Class Initialized
INFO - 2016-09-27 14:51:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:57 --> Config Class Initialized
INFO - 2016-09-27 14:51:57 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:51:57 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:51:57 --> Utf8 Class Initialized
INFO - 2016-09-27 14:51:57 --> URI Class Initialized
INFO - 2016-09-27 14:51:57 --> Router Class Initialized
INFO - 2016-09-27 14:51:57 --> Output Class Initialized
INFO - 2016-09-27 14:51:57 --> Security Class Initialized
DEBUG - 2016-09-27 14:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:51:57 --> Input Class Initialized
INFO - 2016-09-27 14:51:57 --> Language Class Initialized
INFO - 2016-09-27 14:51:57 --> Loader Class Initialized
INFO - 2016-09-27 14:51:57 --> Helper loaded: url_helper
INFO - 2016-09-27 14:51:57 --> Helper loaded: language_helper
INFO - 2016-09-27 14:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:51:57 --> Controller Class Initialized
INFO - 2016-09-27 14:51:57 --> Database Driver Class Initialized
INFO - 2016-09-27 14:51:57 --> Model Class Initialized
INFO - 2016-09-27 14:51:57 --> Model Class Initialized
INFO - 2016-09-27 14:51:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:51:57 --> Final output sent to browser
DEBUG - 2016-09-27 14:51:57 --> Total execution time: 0.0604
INFO - 2016-09-27 14:52:01 --> Config Class Initialized
INFO - 2016-09-27 14:52:01 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:52:01 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:52:01 --> Utf8 Class Initialized
INFO - 2016-09-27 14:52:01 --> URI Class Initialized
INFO - 2016-09-27 14:52:01 --> Router Class Initialized
INFO - 2016-09-27 14:52:01 --> Output Class Initialized
INFO - 2016-09-27 14:52:01 --> Security Class Initialized
DEBUG - 2016-09-27 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:52:01 --> Input Class Initialized
INFO - 2016-09-27 14:52:01 --> Language Class Initialized
INFO - 2016-09-27 14:52:01 --> Loader Class Initialized
INFO - 2016-09-27 14:52:01 --> Helper loaded: url_helper
INFO - 2016-09-27 14:52:01 --> Helper loaded: language_helper
INFO - 2016-09-27 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:52:01 --> Controller Class Initialized
INFO - 2016-09-27 14:52:01 --> Database Driver Class Initialized
INFO - 2016-09-27 14:52:01 --> Model Class Initialized
INFO - 2016-09-27 14:52:01 --> Model Class Initialized
INFO - 2016-09-27 14:52:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:52:01 --> Config Class Initialized
INFO - 2016-09-27 14:52:01 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:52:01 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:52:01 --> Utf8 Class Initialized
INFO - 2016-09-27 14:52:01 --> URI Class Initialized
INFO - 2016-09-27 14:52:01 --> Router Class Initialized
INFO - 2016-09-27 14:52:01 --> Output Class Initialized
INFO - 2016-09-27 14:52:01 --> Security Class Initialized
DEBUG - 2016-09-27 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:52:01 --> Input Class Initialized
INFO - 2016-09-27 14:52:01 --> Language Class Initialized
INFO - 2016-09-27 14:52:01 --> Loader Class Initialized
INFO - 2016-09-27 14:52:01 --> Helper loaded: url_helper
INFO - 2016-09-27 14:52:01 --> Helper loaded: language_helper
INFO - 2016-09-27 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:52:01 --> Controller Class Initialized
INFO - 2016-09-27 14:52:01 --> Database Driver Class Initialized
INFO - 2016-09-27 14:52:01 --> Model Class Initialized
INFO - 2016-09-27 14:52:01 --> Model Class Initialized
INFO - 2016-09-27 14:52:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:52:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:52:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:52:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:52:01 --> Final output sent to browser
DEBUG - 2016-09-27 14:52:01 --> Total execution time: 0.0682
INFO - 2016-09-27 14:52:01 --> Config Class Initialized
INFO - 2016-09-27 14:52:01 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:52:01 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:52:01 --> Utf8 Class Initialized
INFO - 2016-09-27 14:52:01 --> URI Class Initialized
INFO - 2016-09-27 14:52:01 --> Router Class Initialized
INFO - 2016-09-27 14:52:01 --> Output Class Initialized
INFO - 2016-09-27 14:52:01 --> Security Class Initialized
DEBUG - 2016-09-27 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:52:01 --> Input Class Initialized
INFO - 2016-09-27 14:52:01 --> Language Class Initialized
INFO - 2016-09-27 14:52:01 --> Loader Class Initialized
INFO - 2016-09-27 14:52:01 --> Helper loaded: url_helper
INFO - 2016-09-27 14:52:01 --> Helper loaded: language_helper
INFO - 2016-09-27 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:52:01 --> Controller Class Initialized
INFO - 2016-09-27 14:52:01 --> Database Driver Class Initialized
INFO - 2016-09-27 14:52:01 --> Model Class Initialized
INFO - 2016-09-27 14:52:01 --> Model Class Initialized
INFO - 2016-09-27 14:52:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:52:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:52:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:52:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:52:01 --> Final output sent to browser
DEBUG - 2016-09-27 14:52:01 --> Total execution time: 0.0780
INFO - 2016-09-27 14:52:19 --> Config Class Initialized
INFO - 2016-09-27 14:52:19 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:52:19 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:52:19 --> Utf8 Class Initialized
INFO - 2016-09-27 14:52:19 --> URI Class Initialized
INFO - 2016-09-27 14:52:19 --> Router Class Initialized
INFO - 2016-09-27 14:52:19 --> Output Class Initialized
INFO - 2016-09-27 14:52:19 --> Security Class Initialized
DEBUG - 2016-09-27 14:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:52:19 --> Input Class Initialized
INFO - 2016-09-27 14:52:19 --> Language Class Initialized
INFO - 2016-09-27 14:52:19 --> Loader Class Initialized
INFO - 2016-09-27 14:52:19 --> Helper loaded: url_helper
INFO - 2016-09-27 14:52:19 --> Helper loaded: language_helper
INFO - 2016-09-27 14:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:52:19 --> Controller Class Initialized
INFO - 2016-09-27 14:52:19 --> Database Driver Class Initialized
INFO - 2016-09-27 14:52:19 --> Model Class Initialized
INFO - 2016-09-27 14:52:19 --> Model Class Initialized
INFO - 2016-09-27 14:52:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:52:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:52:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:52:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:52:19 --> Final output sent to browser
DEBUG - 2016-09-27 14:52:19 --> Total execution time: 0.0889
INFO - 2016-09-27 14:52:24 --> Config Class Initialized
INFO - 2016-09-27 14:52:24 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:52:24 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:52:24 --> Utf8 Class Initialized
INFO - 2016-09-27 14:52:24 --> URI Class Initialized
INFO - 2016-09-27 14:52:24 --> Router Class Initialized
INFO - 2016-09-27 14:52:24 --> Output Class Initialized
INFO - 2016-09-27 14:52:24 --> Security Class Initialized
DEBUG - 2016-09-27 14:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:52:24 --> Input Class Initialized
INFO - 2016-09-27 14:52:24 --> Language Class Initialized
INFO - 2016-09-27 14:52:24 --> Loader Class Initialized
INFO - 2016-09-27 14:52:24 --> Helper loaded: url_helper
INFO - 2016-09-27 14:52:24 --> Helper loaded: language_helper
INFO - 2016-09-27 14:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:52:24 --> Controller Class Initialized
INFO - 2016-09-27 14:52:24 --> Database Driver Class Initialized
INFO - 2016-09-27 14:52:24 --> Model Class Initialized
INFO - 2016-09-27 14:52:24 --> Model Class Initialized
INFO - 2016-09-27 14:52:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:52:24 --> Final output sent to browser
DEBUG - 2016-09-27 14:52:24 --> Total execution time: 0.0854
INFO - 2016-09-27 14:52:55 --> Config Class Initialized
INFO - 2016-09-27 14:52:55 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:52:55 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:52:55 --> Utf8 Class Initialized
INFO - 2016-09-27 14:52:55 --> URI Class Initialized
INFO - 2016-09-27 14:52:55 --> Router Class Initialized
INFO - 2016-09-27 14:52:55 --> Output Class Initialized
INFO - 2016-09-27 14:52:55 --> Security Class Initialized
DEBUG - 2016-09-27 14:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:52:55 --> Input Class Initialized
INFO - 2016-09-27 14:52:55 --> Language Class Initialized
INFO - 2016-09-27 14:52:55 --> Loader Class Initialized
INFO - 2016-09-27 14:52:55 --> Helper loaded: url_helper
INFO - 2016-09-27 14:52:55 --> Helper loaded: language_helper
INFO - 2016-09-27 14:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:52:55 --> Controller Class Initialized
INFO - 2016-09-27 14:52:55 --> Database Driver Class Initialized
INFO - 2016-09-27 14:52:55 --> Model Class Initialized
INFO - 2016-09-27 14:52:55 --> Model Class Initialized
INFO - 2016-09-27 14:52:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:52:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:52:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:52:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:52:55 --> Final output sent to browser
DEBUG - 2016-09-27 14:52:55 --> Total execution time: 0.0671
INFO - 2016-09-27 14:53:00 --> Config Class Initialized
INFO - 2016-09-27 14:53:00 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:00 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:00 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:00 --> URI Class Initialized
INFO - 2016-09-27 14:53:00 --> Router Class Initialized
INFO - 2016-09-27 14:53:00 --> Output Class Initialized
INFO - 2016-09-27 14:53:00 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:00 --> Input Class Initialized
INFO - 2016-09-27 14:53:00 --> Language Class Initialized
INFO - 2016-09-27 14:53:00 --> Loader Class Initialized
INFO - 2016-09-27 14:53:00 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:00 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:00 --> Controller Class Initialized
INFO - 2016-09-27 14:53:00 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:00 --> Model Class Initialized
INFO - 2016-09-27 14:53:00 --> Model Class Initialized
INFO - 2016-09-27 14:53:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:53:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:00 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:00 --> Total execution time: 0.0638
INFO - 2016-09-27 14:53:10 --> Config Class Initialized
INFO - 2016-09-27 14:53:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:10 --> URI Class Initialized
INFO - 2016-09-27 14:53:10 --> Router Class Initialized
INFO - 2016-09-27 14:53:10 --> Output Class Initialized
INFO - 2016-09-27 14:53:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:10 --> Input Class Initialized
INFO - 2016-09-27 14:53:10 --> Language Class Initialized
INFO - 2016-09-27 14:53:10 --> Loader Class Initialized
INFO - 2016-09-27 14:53:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:10 --> Controller Class Initialized
INFO - 2016-09-27 14:53:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:10 --> Model Class Initialized
INFO - 2016-09-27 14:53:10 --> Model Class Initialized
INFO - 2016-09-27 14:53:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:10 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:10 --> Total execution time: 0.0631
INFO - 2016-09-27 14:53:30 --> Config Class Initialized
INFO - 2016-09-27 14:53:30 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:30 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:30 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:30 --> URI Class Initialized
INFO - 2016-09-27 14:53:30 --> Router Class Initialized
INFO - 2016-09-27 14:53:30 --> Output Class Initialized
INFO - 2016-09-27 14:53:30 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:30 --> Input Class Initialized
INFO - 2016-09-27 14:53:30 --> Language Class Initialized
INFO - 2016-09-27 14:53:30 --> Loader Class Initialized
INFO - 2016-09-27 14:53:30 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:30 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:30 --> Controller Class Initialized
INFO - 2016-09-27 14:53:30 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:30 --> Model Class Initialized
INFO - 2016-09-27 14:53:30 --> Model Class Initialized
INFO - 2016-09-27 14:53:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:30 --> Config Class Initialized
INFO - 2016-09-27 14:53:30 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:30 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:30 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:30 --> URI Class Initialized
INFO - 2016-09-27 14:53:30 --> Router Class Initialized
INFO - 2016-09-27 14:53:30 --> Output Class Initialized
INFO - 2016-09-27 14:53:30 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:30 --> Input Class Initialized
INFO - 2016-09-27 14:53:30 --> Language Class Initialized
INFO - 2016-09-27 14:53:30 --> Loader Class Initialized
INFO - 2016-09-27 14:53:30 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:30 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:30 --> Controller Class Initialized
INFO - 2016-09-27 14:53:30 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:30 --> Model Class Initialized
INFO - 2016-09-27 14:53:30 --> Model Class Initialized
INFO - 2016-09-27 14:53:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:30 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:30 --> Total execution time: 0.0702
INFO - 2016-09-27 14:53:34 --> Config Class Initialized
INFO - 2016-09-27 14:53:34 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:34 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:34 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:34 --> URI Class Initialized
INFO - 2016-09-27 14:53:34 --> Router Class Initialized
INFO - 2016-09-27 14:53:34 --> Output Class Initialized
INFO - 2016-09-27 14:53:34 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:34 --> Input Class Initialized
INFO - 2016-09-27 14:53:34 --> Language Class Initialized
INFO - 2016-09-27 14:53:34 --> Loader Class Initialized
INFO - 2016-09-27 14:53:34 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:34 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:34 --> Controller Class Initialized
INFO - 2016-09-27 14:53:34 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:34 --> Model Class Initialized
INFO - 2016-09-27 14:53:34 --> Model Class Initialized
INFO - 2016-09-27 14:53:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:34 --> Config Class Initialized
INFO - 2016-09-27 14:53:34 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:34 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:34 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:34 --> URI Class Initialized
INFO - 2016-09-27 14:53:34 --> Router Class Initialized
INFO - 2016-09-27 14:53:34 --> Output Class Initialized
INFO - 2016-09-27 14:53:34 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:34 --> Input Class Initialized
INFO - 2016-09-27 14:53:34 --> Language Class Initialized
INFO - 2016-09-27 14:53:34 --> Loader Class Initialized
INFO - 2016-09-27 14:53:34 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:34 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:34 --> Controller Class Initialized
INFO - 2016-09-27 14:53:34 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:34 --> Model Class Initialized
INFO - 2016-09-27 14:53:34 --> Model Class Initialized
INFO - 2016-09-27 14:53:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:34 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:34 --> Total execution time: 0.0610
INFO - 2016-09-27 14:53:38 --> Config Class Initialized
INFO - 2016-09-27 14:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:38 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:38 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:38 --> URI Class Initialized
INFO - 2016-09-27 14:53:38 --> Router Class Initialized
INFO - 2016-09-27 14:53:38 --> Output Class Initialized
INFO - 2016-09-27 14:53:38 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:38 --> Input Class Initialized
INFO - 2016-09-27 14:53:38 --> Language Class Initialized
INFO - 2016-09-27 14:53:38 --> Loader Class Initialized
INFO - 2016-09-27 14:53:38 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:38 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:38 --> Controller Class Initialized
INFO - 2016-09-27 14:53:38 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:38 --> Model Class Initialized
INFO - 2016-09-27 14:53:38 --> Model Class Initialized
INFO - 2016-09-27 14:53:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:38 --> Config Class Initialized
INFO - 2016-09-27 14:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:38 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:38 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:38 --> URI Class Initialized
INFO - 2016-09-27 14:53:38 --> Router Class Initialized
INFO - 2016-09-27 14:53:38 --> Output Class Initialized
INFO - 2016-09-27 14:53:38 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:38 --> Input Class Initialized
INFO - 2016-09-27 14:53:38 --> Language Class Initialized
INFO - 2016-09-27 14:53:38 --> Loader Class Initialized
INFO - 2016-09-27 14:53:38 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:38 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:38 --> Controller Class Initialized
INFO - 2016-09-27 14:53:38 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:38 --> Model Class Initialized
INFO - 2016-09-27 14:53:38 --> Model Class Initialized
INFO - 2016-09-27 14:53:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:38 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:38 --> Total execution time: 0.0619
INFO - 2016-09-27 14:53:41 --> Config Class Initialized
INFO - 2016-09-27 14:53:41 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:41 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:41 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:41 --> URI Class Initialized
INFO - 2016-09-27 14:53:41 --> Router Class Initialized
INFO - 2016-09-27 14:53:41 --> Output Class Initialized
INFO - 2016-09-27 14:53:41 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:41 --> Input Class Initialized
INFO - 2016-09-27 14:53:41 --> Language Class Initialized
INFO - 2016-09-27 14:53:41 --> Loader Class Initialized
INFO - 2016-09-27 14:53:41 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:41 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:41 --> Controller Class Initialized
INFO - 2016-09-27 14:53:41 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:41 --> Model Class Initialized
INFO - 2016-09-27 14:53:41 --> Model Class Initialized
INFO - 2016-09-27 14:53:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:41 --> Config Class Initialized
INFO - 2016-09-27 14:53:41 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:41 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:41 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:41 --> URI Class Initialized
INFO - 2016-09-27 14:53:41 --> Router Class Initialized
INFO - 2016-09-27 14:53:41 --> Output Class Initialized
INFO - 2016-09-27 14:53:41 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:41 --> Input Class Initialized
INFO - 2016-09-27 14:53:41 --> Language Class Initialized
INFO - 2016-09-27 14:53:41 --> Loader Class Initialized
INFO - 2016-09-27 14:53:41 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:41 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:41 --> Controller Class Initialized
INFO - 2016-09-27 14:53:41 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:41 --> Model Class Initialized
INFO - 2016-09-27 14:53:41 --> Model Class Initialized
INFO - 2016-09-27 14:53:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:41 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:41 --> Total execution time: 0.0661
INFO - 2016-09-27 14:53:45 --> Config Class Initialized
INFO - 2016-09-27 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:45 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:45 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:45 --> URI Class Initialized
INFO - 2016-09-27 14:53:45 --> Router Class Initialized
INFO - 2016-09-27 14:53:45 --> Output Class Initialized
INFO - 2016-09-27 14:53:45 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:45 --> Input Class Initialized
INFO - 2016-09-27 14:53:45 --> Language Class Initialized
INFO - 2016-09-27 14:53:45 --> Loader Class Initialized
INFO - 2016-09-27 14:53:45 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:45 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:45 --> Controller Class Initialized
INFO - 2016-09-27 14:53:45 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:45 --> Model Class Initialized
INFO - 2016-09-27 14:53:45 --> Model Class Initialized
INFO - 2016-09-27 14:53:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:45 --> Config Class Initialized
INFO - 2016-09-27 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:45 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:45 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:45 --> URI Class Initialized
INFO - 2016-09-27 14:53:45 --> Router Class Initialized
INFO - 2016-09-27 14:53:45 --> Output Class Initialized
INFO - 2016-09-27 14:53:45 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:45 --> Input Class Initialized
INFO - 2016-09-27 14:53:45 --> Language Class Initialized
INFO - 2016-09-27 14:53:45 --> Loader Class Initialized
INFO - 2016-09-27 14:53:45 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:45 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:45 --> Controller Class Initialized
INFO - 2016-09-27 14:53:45 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:45 --> Model Class Initialized
INFO - 2016-09-27 14:53:45 --> Model Class Initialized
INFO - 2016-09-27 14:53:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:45 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:45 --> Total execution time: 0.0613
INFO - 2016-09-27 14:53:48 --> Config Class Initialized
INFO - 2016-09-27 14:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:48 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:48 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:48 --> URI Class Initialized
INFO - 2016-09-27 14:53:48 --> Router Class Initialized
INFO - 2016-09-27 14:53:48 --> Output Class Initialized
INFO - 2016-09-27 14:53:48 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:48 --> Input Class Initialized
INFO - 2016-09-27 14:53:48 --> Language Class Initialized
INFO - 2016-09-27 14:53:48 --> Loader Class Initialized
INFO - 2016-09-27 14:53:48 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:48 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:48 --> Controller Class Initialized
INFO - 2016-09-27 14:53:48 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:48 --> Model Class Initialized
INFO - 2016-09-27 14:53:48 --> Model Class Initialized
INFO - 2016-09-27 14:53:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:48 --> Config Class Initialized
INFO - 2016-09-27 14:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:48 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:48 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:48 --> URI Class Initialized
INFO - 2016-09-27 14:53:48 --> Router Class Initialized
INFO - 2016-09-27 14:53:48 --> Output Class Initialized
INFO - 2016-09-27 14:53:48 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:48 --> Input Class Initialized
INFO - 2016-09-27 14:53:48 --> Language Class Initialized
INFO - 2016-09-27 14:53:48 --> Loader Class Initialized
INFO - 2016-09-27 14:53:48 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:48 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:48 --> Controller Class Initialized
INFO - 2016-09-27 14:53:48 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:48 --> Model Class Initialized
INFO - 2016-09-27 14:53:48 --> Model Class Initialized
INFO - 2016-09-27 14:53:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:48 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:48 --> Total execution time: 0.0639
INFO - 2016-09-27 14:53:52 --> Config Class Initialized
INFO - 2016-09-27 14:53:52 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:52 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:52 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:52 --> URI Class Initialized
INFO - 2016-09-27 14:53:52 --> Router Class Initialized
INFO - 2016-09-27 14:53:52 --> Output Class Initialized
INFO - 2016-09-27 14:53:52 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:52 --> Input Class Initialized
INFO - 2016-09-27 14:53:52 --> Language Class Initialized
INFO - 2016-09-27 14:53:52 --> Loader Class Initialized
INFO - 2016-09-27 14:53:52 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:52 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:52 --> Controller Class Initialized
INFO - 2016-09-27 14:53:52 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:52 --> Model Class Initialized
INFO - 2016-09-27 14:53:52 --> Model Class Initialized
INFO - 2016-09-27 14:53:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:52 --> Config Class Initialized
INFO - 2016-09-27 14:53:52 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:52 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:52 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:52 --> URI Class Initialized
INFO - 2016-09-27 14:53:52 --> Router Class Initialized
INFO - 2016-09-27 14:53:52 --> Output Class Initialized
INFO - 2016-09-27 14:53:52 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:52 --> Input Class Initialized
INFO - 2016-09-27 14:53:52 --> Language Class Initialized
INFO - 2016-09-27 14:53:52 --> Loader Class Initialized
INFO - 2016-09-27 14:53:52 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:52 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:52 --> Controller Class Initialized
INFO - 2016-09-27 14:53:52 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:52 --> Model Class Initialized
INFO - 2016-09-27 14:53:52 --> Model Class Initialized
INFO - 2016-09-27 14:53:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:52 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:52 --> Total execution time: 0.0610
INFO - 2016-09-27 14:53:56 --> Config Class Initialized
INFO - 2016-09-27 14:53:56 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:56 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:56 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:56 --> URI Class Initialized
INFO - 2016-09-27 14:53:56 --> Router Class Initialized
INFO - 2016-09-27 14:53:56 --> Output Class Initialized
INFO - 2016-09-27 14:53:56 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:56 --> Input Class Initialized
INFO - 2016-09-27 14:53:56 --> Language Class Initialized
INFO - 2016-09-27 14:53:56 --> Loader Class Initialized
INFO - 2016-09-27 14:53:56 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:56 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:56 --> Controller Class Initialized
INFO - 2016-09-27 14:53:56 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:56 --> Model Class Initialized
INFO - 2016-09-27 14:53:56 --> Model Class Initialized
INFO - 2016-09-27 14:53:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:56 --> Config Class Initialized
INFO - 2016-09-27 14:53:56 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:56 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:56 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:56 --> URI Class Initialized
INFO - 2016-09-27 14:53:56 --> Router Class Initialized
INFO - 2016-09-27 14:53:56 --> Output Class Initialized
INFO - 2016-09-27 14:53:56 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:56 --> Input Class Initialized
INFO - 2016-09-27 14:53:56 --> Language Class Initialized
INFO - 2016-09-27 14:53:56 --> Loader Class Initialized
INFO - 2016-09-27 14:53:56 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:56 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:56 --> Controller Class Initialized
INFO - 2016-09-27 14:53:56 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:56 --> Model Class Initialized
INFO - 2016-09-27 14:53:56 --> Model Class Initialized
INFO - 2016-09-27 14:53:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:56 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:56 --> Total execution time: 0.0612
INFO - 2016-09-27 14:53:59 --> Config Class Initialized
INFO - 2016-09-27 14:53:59 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:59 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:59 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:59 --> URI Class Initialized
INFO - 2016-09-27 14:53:59 --> Router Class Initialized
INFO - 2016-09-27 14:53:59 --> Output Class Initialized
INFO - 2016-09-27 14:53:59 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:59 --> Input Class Initialized
INFO - 2016-09-27 14:53:59 --> Language Class Initialized
INFO - 2016-09-27 14:53:59 --> Loader Class Initialized
INFO - 2016-09-27 14:53:59 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:59 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:59 --> Controller Class Initialized
INFO - 2016-09-27 14:53:59 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:59 --> Model Class Initialized
INFO - 2016-09-27 14:53:59 --> Model Class Initialized
INFO - 2016-09-27 14:53:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:59 --> Config Class Initialized
INFO - 2016-09-27 14:53:59 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:53:59 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:53:59 --> Utf8 Class Initialized
INFO - 2016-09-27 14:53:59 --> URI Class Initialized
INFO - 2016-09-27 14:53:59 --> Router Class Initialized
INFO - 2016-09-27 14:53:59 --> Output Class Initialized
INFO - 2016-09-27 14:53:59 --> Security Class Initialized
DEBUG - 2016-09-27 14:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:53:59 --> Input Class Initialized
INFO - 2016-09-27 14:53:59 --> Language Class Initialized
INFO - 2016-09-27 14:53:59 --> Loader Class Initialized
INFO - 2016-09-27 14:53:59 --> Helper loaded: url_helper
INFO - 2016-09-27 14:53:59 --> Helper loaded: language_helper
INFO - 2016-09-27 14:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:53:59 --> Controller Class Initialized
INFO - 2016-09-27 14:53:59 --> Database Driver Class Initialized
INFO - 2016-09-27 14:53:59 --> Model Class Initialized
INFO - 2016-09-27 14:53:59 --> Model Class Initialized
INFO - 2016-09-27 14:53:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:53:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:53:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:53:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:53:59 --> Final output sent to browser
DEBUG - 2016-09-27 14:53:59 --> Total execution time: 0.0654
INFO - 2016-09-27 14:54:03 --> Config Class Initialized
INFO - 2016-09-27 14:54:03 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:03 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:03 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:03 --> URI Class Initialized
INFO - 2016-09-27 14:54:03 --> Router Class Initialized
INFO - 2016-09-27 14:54:03 --> Output Class Initialized
INFO - 2016-09-27 14:54:03 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:03 --> Input Class Initialized
INFO - 2016-09-27 14:54:03 --> Language Class Initialized
INFO - 2016-09-27 14:54:03 --> Loader Class Initialized
INFO - 2016-09-27 14:54:03 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:03 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:03 --> Controller Class Initialized
INFO - 2016-09-27 14:54:03 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:03 --> Model Class Initialized
INFO - 2016-09-27 14:54:03 --> Model Class Initialized
INFO - 2016-09-27 14:54:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:03 --> Config Class Initialized
INFO - 2016-09-27 14:54:03 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:03 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:03 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:03 --> URI Class Initialized
INFO - 2016-09-27 14:54:03 --> Router Class Initialized
INFO - 2016-09-27 14:54:03 --> Output Class Initialized
INFO - 2016-09-27 14:54:03 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:03 --> Input Class Initialized
INFO - 2016-09-27 14:54:03 --> Language Class Initialized
INFO - 2016-09-27 14:54:03 --> Loader Class Initialized
INFO - 2016-09-27 14:54:03 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:03 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:03 --> Controller Class Initialized
INFO - 2016-09-27 14:54:03 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:03 --> Model Class Initialized
INFO - 2016-09-27 14:54:03 --> Model Class Initialized
INFO - 2016-09-27 14:54:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:03 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:03 --> Total execution time: 0.0633
INFO - 2016-09-27 14:54:06 --> Config Class Initialized
INFO - 2016-09-27 14:54:06 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:06 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:06 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:06 --> URI Class Initialized
INFO - 2016-09-27 14:54:06 --> Router Class Initialized
INFO - 2016-09-27 14:54:06 --> Output Class Initialized
INFO - 2016-09-27 14:54:06 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:06 --> Input Class Initialized
INFO - 2016-09-27 14:54:06 --> Language Class Initialized
INFO - 2016-09-27 14:54:06 --> Loader Class Initialized
INFO - 2016-09-27 14:54:06 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:06 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:06 --> Controller Class Initialized
INFO - 2016-09-27 14:54:06 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:06 --> Model Class Initialized
INFO - 2016-09-27 14:54:06 --> Model Class Initialized
INFO - 2016-09-27 14:54:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:06 --> Config Class Initialized
INFO - 2016-09-27 14:54:06 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:06 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:06 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:06 --> URI Class Initialized
INFO - 2016-09-27 14:54:06 --> Router Class Initialized
INFO - 2016-09-27 14:54:06 --> Output Class Initialized
INFO - 2016-09-27 14:54:06 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:06 --> Input Class Initialized
INFO - 2016-09-27 14:54:06 --> Language Class Initialized
INFO - 2016-09-27 14:54:06 --> Loader Class Initialized
INFO - 2016-09-27 14:54:06 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:06 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:06 --> Controller Class Initialized
INFO - 2016-09-27 14:54:06 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:06 --> Model Class Initialized
INFO - 2016-09-27 14:54:06 --> Model Class Initialized
INFO - 2016-09-27 14:54:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:06 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:06 --> Total execution time: 0.0614
INFO - 2016-09-27 14:54:10 --> Config Class Initialized
INFO - 2016-09-27 14:54:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:10 --> URI Class Initialized
INFO - 2016-09-27 14:54:10 --> Router Class Initialized
INFO - 2016-09-27 14:54:10 --> Output Class Initialized
INFO - 2016-09-27 14:54:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:10 --> Input Class Initialized
INFO - 2016-09-27 14:54:10 --> Language Class Initialized
INFO - 2016-09-27 14:54:10 --> Loader Class Initialized
INFO - 2016-09-27 14:54:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:10 --> Controller Class Initialized
INFO - 2016-09-27 14:54:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:10 --> Model Class Initialized
INFO - 2016-09-27 14:54:10 --> Model Class Initialized
INFO - 2016-09-27 14:54:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:10 --> Config Class Initialized
INFO - 2016-09-27 14:54:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:10 --> URI Class Initialized
INFO - 2016-09-27 14:54:10 --> Router Class Initialized
INFO - 2016-09-27 14:54:10 --> Output Class Initialized
INFO - 2016-09-27 14:54:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:10 --> Input Class Initialized
INFO - 2016-09-27 14:54:10 --> Language Class Initialized
INFO - 2016-09-27 14:54:10 --> Loader Class Initialized
INFO - 2016-09-27 14:54:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:10 --> Controller Class Initialized
INFO - 2016-09-27 14:54:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:10 --> Model Class Initialized
INFO - 2016-09-27 14:54:10 --> Model Class Initialized
INFO - 2016-09-27 14:54:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:10 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:10 --> Total execution time: 0.0632
INFO - 2016-09-27 14:54:14 --> Config Class Initialized
INFO - 2016-09-27 14:54:14 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:14 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:14 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:14 --> URI Class Initialized
INFO - 2016-09-27 14:54:14 --> Router Class Initialized
INFO - 2016-09-27 14:54:14 --> Output Class Initialized
INFO - 2016-09-27 14:54:14 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:14 --> Input Class Initialized
INFO - 2016-09-27 14:54:14 --> Language Class Initialized
INFO - 2016-09-27 14:54:14 --> Loader Class Initialized
INFO - 2016-09-27 14:54:14 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:14 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:14 --> Controller Class Initialized
INFO - 2016-09-27 14:54:14 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:14 --> Model Class Initialized
INFO - 2016-09-27 14:54:14 --> Model Class Initialized
INFO - 2016-09-27 14:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:14 --> Config Class Initialized
INFO - 2016-09-27 14:54:14 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:14 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:14 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:14 --> URI Class Initialized
INFO - 2016-09-27 14:54:14 --> Router Class Initialized
INFO - 2016-09-27 14:54:14 --> Output Class Initialized
INFO - 2016-09-27 14:54:14 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:14 --> Input Class Initialized
INFO - 2016-09-27 14:54:14 --> Language Class Initialized
INFO - 2016-09-27 14:54:14 --> Loader Class Initialized
INFO - 2016-09-27 14:54:14 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:14 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:14 --> Controller Class Initialized
INFO - 2016-09-27 14:54:14 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:14 --> Model Class Initialized
INFO - 2016-09-27 14:54:14 --> Model Class Initialized
INFO - 2016-09-27 14:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:14 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:14 --> Total execution time: 0.0627
INFO - 2016-09-27 14:54:17 --> Config Class Initialized
INFO - 2016-09-27 14:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:17 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:17 --> URI Class Initialized
INFO - 2016-09-27 14:54:17 --> Router Class Initialized
INFO - 2016-09-27 14:54:17 --> Output Class Initialized
INFO - 2016-09-27 14:54:17 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:17 --> Input Class Initialized
INFO - 2016-09-27 14:54:17 --> Language Class Initialized
INFO - 2016-09-27 14:54:17 --> Loader Class Initialized
INFO - 2016-09-27 14:54:17 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:17 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:17 --> Controller Class Initialized
INFO - 2016-09-27 14:54:17 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:17 --> Model Class Initialized
INFO - 2016-09-27 14:54:17 --> Model Class Initialized
INFO - 2016-09-27 14:54:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:17 --> Config Class Initialized
INFO - 2016-09-27 14:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:17 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:17 --> URI Class Initialized
INFO - 2016-09-27 14:54:17 --> Router Class Initialized
INFO - 2016-09-27 14:54:17 --> Output Class Initialized
INFO - 2016-09-27 14:54:17 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:17 --> Input Class Initialized
INFO - 2016-09-27 14:54:17 --> Language Class Initialized
INFO - 2016-09-27 14:54:17 --> Loader Class Initialized
INFO - 2016-09-27 14:54:17 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:17 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:17 --> Controller Class Initialized
INFO - 2016-09-27 14:54:17 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:17 --> Model Class Initialized
INFO - 2016-09-27 14:54:17 --> Model Class Initialized
INFO - 2016-09-27 14:54:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:17 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:17 --> Total execution time: 0.0941
INFO - 2016-09-27 14:54:21 --> Config Class Initialized
INFO - 2016-09-27 14:54:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:21 --> URI Class Initialized
INFO - 2016-09-27 14:54:21 --> Router Class Initialized
INFO - 2016-09-27 14:54:21 --> Output Class Initialized
INFO - 2016-09-27 14:54:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:21 --> Input Class Initialized
INFO - 2016-09-27 14:54:21 --> Language Class Initialized
INFO - 2016-09-27 14:54:21 --> Loader Class Initialized
INFO - 2016-09-27 14:54:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:21 --> Controller Class Initialized
INFO - 2016-09-27 14:54:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:21 --> Model Class Initialized
INFO - 2016-09-27 14:54:21 --> Model Class Initialized
INFO - 2016-09-27 14:54:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:21 --> Config Class Initialized
INFO - 2016-09-27 14:54:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:21 --> URI Class Initialized
INFO - 2016-09-27 14:54:21 --> Router Class Initialized
INFO - 2016-09-27 14:54:21 --> Output Class Initialized
INFO - 2016-09-27 14:54:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:21 --> Input Class Initialized
INFO - 2016-09-27 14:54:21 --> Language Class Initialized
INFO - 2016-09-27 14:54:21 --> Loader Class Initialized
INFO - 2016-09-27 14:54:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:21 --> Controller Class Initialized
INFO - 2016-09-27 14:54:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:21 --> Model Class Initialized
INFO - 2016-09-27 14:54:21 --> Model Class Initialized
INFO - 2016-09-27 14:54:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:21 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:21 --> Total execution time: 0.0620
INFO - 2016-09-27 14:54:24 --> Config Class Initialized
INFO - 2016-09-27 14:54:24 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:24 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:24 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:24 --> URI Class Initialized
INFO - 2016-09-27 14:54:24 --> Router Class Initialized
INFO - 2016-09-27 14:54:24 --> Output Class Initialized
INFO - 2016-09-27 14:54:24 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:24 --> Input Class Initialized
INFO - 2016-09-27 14:54:24 --> Language Class Initialized
INFO - 2016-09-27 14:54:24 --> Loader Class Initialized
INFO - 2016-09-27 14:54:24 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:24 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:24 --> Controller Class Initialized
INFO - 2016-09-27 14:54:24 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:24 --> Model Class Initialized
INFO - 2016-09-27 14:54:24 --> Model Class Initialized
INFO - 2016-09-27 14:54:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:24 --> Config Class Initialized
INFO - 2016-09-27 14:54:24 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:24 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:24 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:24 --> URI Class Initialized
INFO - 2016-09-27 14:54:24 --> Router Class Initialized
INFO - 2016-09-27 14:54:24 --> Output Class Initialized
INFO - 2016-09-27 14:54:24 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:24 --> Input Class Initialized
INFO - 2016-09-27 14:54:24 --> Language Class Initialized
INFO - 2016-09-27 14:54:24 --> Loader Class Initialized
INFO - 2016-09-27 14:54:24 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:24 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:24 --> Controller Class Initialized
INFO - 2016-09-27 14:54:24 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:24 --> Model Class Initialized
INFO - 2016-09-27 14:54:24 --> Model Class Initialized
INFO - 2016-09-27 14:54:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:24 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:24 --> Total execution time: 0.0833
INFO - 2016-09-27 14:54:28 --> Config Class Initialized
INFO - 2016-09-27 14:54:28 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:28 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:28 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:28 --> URI Class Initialized
INFO - 2016-09-27 14:54:28 --> Router Class Initialized
INFO - 2016-09-27 14:54:28 --> Output Class Initialized
INFO - 2016-09-27 14:54:28 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:28 --> Input Class Initialized
INFO - 2016-09-27 14:54:28 --> Language Class Initialized
INFO - 2016-09-27 14:54:28 --> Loader Class Initialized
INFO - 2016-09-27 14:54:28 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:28 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:28 --> Controller Class Initialized
INFO - 2016-09-27 14:54:28 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:28 --> Model Class Initialized
INFO - 2016-09-27 14:54:28 --> Model Class Initialized
INFO - 2016-09-27 14:54:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:28 --> Config Class Initialized
INFO - 2016-09-27 14:54:28 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:28 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:28 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:28 --> URI Class Initialized
INFO - 2016-09-27 14:54:28 --> Router Class Initialized
INFO - 2016-09-27 14:54:28 --> Output Class Initialized
INFO - 2016-09-27 14:54:28 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:28 --> Input Class Initialized
INFO - 2016-09-27 14:54:28 --> Language Class Initialized
INFO - 2016-09-27 14:54:28 --> Loader Class Initialized
INFO - 2016-09-27 14:54:28 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:28 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:28 --> Controller Class Initialized
INFO - 2016-09-27 14:54:28 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:28 --> Model Class Initialized
INFO - 2016-09-27 14:54:28 --> Model Class Initialized
INFO - 2016-09-27 14:54:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:28 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:28 --> Total execution time: 0.0635
INFO - 2016-09-27 14:54:32 --> Config Class Initialized
INFO - 2016-09-27 14:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:32 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:32 --> URI Class Initialized
INFO - 2016-09-27 14:54:32 --> Router Class Initialized
INFO - 2016-09-27 14:54:32 --> Output Class Initialized
INFO - 2016-09-27 14:54:32 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:32 --> Input Class Initialized
INFO - 2016-09-27 14:54:32 --> Language Class Initialized
INFO - 2016-09-27 14:54:32 --> Loader Class Initialized
INFO - 2016-09-27 14:54:32 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:32 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:32 --> Controller Class Initialized
INFO - 2016-09-27 14:54:32 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:32 --> Model Class Initialized
INFO - 2016-09-27 14:54:32 --> Model Class Initialized
INFO - 2016-09-27 14:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:32 --> Config Class Initialized
INFO - 2016-09-27 14:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:32 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:32 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:32 --> URI Class Initialized
INFO - 2016-09-27 14:54:32 --> Router Class Initialized
INFO - 2016-09-27 14:54:32 --> Output Class Initialized
INFO - 2016-09-27 14:54:32 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:32 --> Input Class Initialized
INFO - 2016-09-27 14:54:32 --> Language Class Initialized
INFO - 2016-09-27 14:54:32 --> Loader Class Initialized
INFO - 2016-09-27 14:54:32 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:32 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:32 --> Controller Class Initialized
INFO - 2016-09-27 14:54:32 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:32 --> Model Class Initialized
INFO - 2016-09-27 14:54:32 --> Model Class Initialized
INFO - 2016-09-27 14:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:32 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:32 --> Total execution time: 0.0682
INFO - 2016-09-27 14:54:35 --> Config Class Initialized
INFO - 2016-09-27 14:54:35 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:35 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:35 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:35 --> URI Class Initialized
INFO - 2016-09-27 14:54:35 --> Router Class Initialized
INFO - 2016-09-27 14:54:35 --> Output Class Initialized
INFO - 2016-09-27 14:54:35 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:35 --> Input Class Initialized
INFO - 2016-09-27 14:54:35 --> Language Class Initialized
INFO - 2016-09-27 14:54:35 --> Loader Class Initialized
INFO - 2016-09-27 14:54:35 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:35 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:35 --> Controller Class Initialized
INFO - 2016-09-27 14:54:35 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:35 --> Model Class Initialized
INFO - 2016-09-27 14:54:35 --> Model Class Initialized
INFO - 2016-09-27 14:54:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:35 --> Config Class Initialized
INFO - 2016-09-27 14:54:35 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:35 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:35 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:35 --> URI Class Initialized
INFO - 2016-09-27 14:54:35 --> Router Class Initialized
INFO - 2016-09-27 14:54:35 --> Output Class Initialized
INFO - 2016-09-27 14:54:35 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:35 --> Input Class Initialized
INFO - 2016-09-27 14:54:35 --> Language Class Initialized
INFO - 2016-09-27 14:54:35 --> Loader Class Initialized
INFO - 2016-09-27 14:54:35 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:35 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:35 --> Controller Class Initialized
INFO - 2016-09-27 14:54:35 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:35 --> Model Class Initialized
INFO - 2016-09-27 14:54:35 --> Model Class Initialized
INFO - 2016-09-27 14:54:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:35 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:35 --> Total execution time: 0.0647
INFO - 2016-09-27 14:54:39 --> Config Class Initialized
INFO - 2016-09-27 14:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:39 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:39 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:39 --> URI Class Initialized
INFO - 2016-09-27 14:54:39 --> Router Class Initialized
INFO - 2016-09-27 14:54:39 --> Output Class Initialized
INFO - 2016-09-27 14:54:39 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:39 --> Input Class Initialized
INFO - 2016-09-27 14:54:39 --> Language Class Initialized
INFO - 2016-09-27 14:54:39 --> Loader Class Initialized
INFO - 2016-09-27 14:54:39 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:39 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:39 --> Controller Class Initialized
INFO - 2016-09-27 14:54:39 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:39 --> Model Class Initialized
INFO - 2016-09-27 14:54:39 --> Model Class Initialized
INFO - 2016-09-27 14:54:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:39 --> Config Class Initialized
INFO - 2016-09-27 14:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:39 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:39 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:39 --> URI Class Initialized
INFO - 2016-09-27 14:54:39 --> Router Class Initialized
INFO - 2016-09-27 14:54:39 --> Output Class Initialized
INFO - 2016-09-27 14:54:39 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:39 --> Input Class Initialized
INFO - 2016-09-27 14:54:39 --> Language Class Initialized
INFO - 2016-09-27 14:54:39 --> Loader Class Initialized
INFO - 2016-09-27 14:54:39 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:39 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:39 --> Controller Class Initialized
INFO - 2016-09-27 14:54:39 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:39 --> Model Class Initialized
INFO - 2016-09-27 14:54:39 --> Model Class Initialized
INFO - 2016-09-27 14:54:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:39 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:39 --> Total execution time: 0.0617
INFO - 2016-09-27 14:54:42 --> Config Class Initialized
INFO - 2016-09-27 14:54:42 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:42 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:42 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:42 --> URI Class Initialized
INFO - 2016-09-27 14:54:42 --> Router Class Initialized
INFO - 2016-09-27 14:54:42 --> Output Class Initialized
INFO - 2016-09-27 14:54:42 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:42 --> Input Class Initialized
INFO - 2016-09-27 14:54:42 --> Language Class Initialized
INFO - 2016-09-27 14:54:42 --> Loader Class Initialized
INFO - 2016-09-27 14:54:42 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:42 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:42 --> Controller Class Initialized
INFO - 2016-09-27 14:54:42 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:42 --> Model Class Initialized
INFO - 2016-09-27 14:54:42 --> Model Class Initialized
INFO - 2016-09-27 14:54:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:42 --> Config Class Initialized
INFO - 2016-09-27 14:54:42 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:42 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:42 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:42 --> URI Class Initialized
INFO - 2016-09-27 14:54:42 --> Router Class Initialized
INFO - 2016-09-27 14:54:42 --> Output Class Initialized
INFO - 2016-09-27 14:54:42 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:42 --> Input Class Initialized
INFO - 2016-09-27 14:54:42 --> Language Class Initialized
INFO - 2016-09-27 14:54:42 --> Loader Class Initialized
INFO - 2016-09-27 14:54:42 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:42 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:42 --> Controller Class Initialized
INFO - 2016-09-27 14:54:42 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:42 --> Model Class Initialized
INFO - 2016-09-27 14:54:42 --> Model Class Initialized
INFO - 2016-09-27 14:54:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:42 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:42 --> Total execution time: 0.0603
INFO - 2016-09-27 14:54:46 --> Config Class Initialized
INFO - 2016-09-27 14:54:46 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:46 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:46 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:46 --> URI Class Initialized
INFO - 2016-09-27 14:54:46 --> Router Class Initialized
INFO - 2016-09-27 14:54:46 --> Output Class Initialized
INFO - 2016-09-27 14:54:46 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:46 --> Input Class Initialized
INFO - 2016-09-27 14:54:46 --> Language Class Initialized
INFO - 2016-09-27 14:54:46 --> Loader Class Initialized
INFO - 2016-09-27 14:54:46 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:46 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:46 --> Controller Class Initialized
INFO - 2016-09-27 14:54:46 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:46 --> Model Class Initialized
INFO - 2016-09-27 14:54:46 --> Model Class Initialized
INFO - 2016-09-27 14:54:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:54:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:46 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:46 --> Total execution time: 0.0692
INFO - 2016-09-27 14:54:49 --> Config Class Initialized
INFO - 2016-09-27 14:54:49 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:54:49 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:54:49 --> Utf8 Class Initialized
INFO - 2016-09-27 14:54:49 --> URI Class Initialized
INFO - 2016-09-27 14:54:49 --> Router Class Initialized
INFO - 2016-09-27 14:54:49 --> Output Class Initialized
INFO - 2016-09-27 14:54:49 --> Security Class Initialized
DEBUG - 2016-09-27 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:54:49 --> Input Class Initialized
INFO - 2016-09-27 14:54:49 --> Language Class Initialized
INFO - 2016-09-27 14:54:49 --> Loader Class Initialized
INFO - 2016-09-27 14:54:49 --> Helper loaded: url_helper
INFO - 2016-09-27 14:54:49 --> Helper loaded: language_helper
INFO - 2016-09-27 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:54:49 --> Controller Class Initialized
INFO - 2016-09-27 14:54:49 --> Database Driver Class Initialized
INFO - 2016-09-27 14:54:49 --> Model Class Initialized
INFO - 2016-09-27 14:54:49 --> Model Class Initialized
INFO - 2016-09-27 14:54:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:54:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:54:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:54:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:54:49 --> Final output sent to browser
DEBUG - 2016-09-27 14:54:49 --> Total execution time: 0.0718
INFO - 2016-09-27 14:55:10 --> Config Class Initialized
INFO - 2016-09-27 14:55:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:10 --> URI Class Initialized
INFO - 2016-09-27 14:55:10 --> Router Class Initialized
INFO - 2016-09-27 14:55:10 --> Output Class Initialized
INFO - 2016-09-27 14:55:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:10 --> Input Class Initialized
INFO - 2016-09-27 14:55:10 --> Language Class Initialized
INFO - 2016-09-27 14:55:10 --> Loader Class Initialized
INFO - 2016-09-27 14:55:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:10 --> Controller Class Initialized
INFO - 2016-09-27 14:55:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:10 --> Model Class Initialized
INFO - 2016-09-27 14:55:10 --> Model Class Initialized
INFO - 2016-09-27 14:55:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:10 --> Config Class Initialized
INFO - 2016-09-27 14:55:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:10 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:10 --> URI Class Initialized
INFO - 2016-09-27 14:55:10 --> Router Class Initialized
INFO - 2016-09-27 14:55:10 --> Output Class Initialized
INFO - 2016-09-27 14:55:10 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:10 --> Input Class Initialized
INFO - 2016-09-27 14:55:10 --> Language Class Initialized
INFO - 2016-09-27 14:55:10 --> Loader Class Initialized
INFO - 2016-09-27 14:55:10 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:10 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:10 --> Controller Class Initialized
INFO - 2016-09-27 14:55:10 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:10 --> Model Class Initialized
INFO - 2016-09-27 14:55:10 --> Model Class Initialized
INFO - 2016-09-27 14:55:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:10 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:10 --> Total execution time: 0.0657
INFO - 2016-09-27 14:55:13 --> Config Class Initialized
INFO - 2016-09-27 14:55:13 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:13 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:13 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:13 --> URI Class Initialized
INFO - 2016-09-27 14:55:13 --> Router Class Initialized
INFO - 2016-09-27 14:55:13 --> Output Class Initialized
INFO - 2016-09-27 14:55:13 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:13 --> Input Class Initialized
INFO - 2016-09-27 14:55:13 --> Language Class Initialized
INFO - 2016-09-27 14:55:13 --> Loader Class Initialized
INFO - 2016-09-27 14:55:13 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:13 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:13 --> Controller Class Initialized
INFO - 2016-09-27 14:55:13 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:13 --> Model Class Initialized
INFO - 2016-09-27 14:55:13 --> Model Class Initialized
INFO - 2016-09-27 14:55:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:13 --> Config Class Initialized
INFO - 2016-09-27 14:55:13 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:13 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:13 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:13 --> URI Class Initialized
INFO - 2016-09-27 14:55:13 --> Router Class Initialized
INFO - 2016-09-27 14:55:13 --> Output Class Initialized
INFO - 2016-09-27 14:55:13 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:13 --> Input Class Initialized
INFO - 2016-09-27 14:55:13 --> Language Class Initialized
INFO - 2016-09-27 14:55:13 --> Loader Class Initialized
INFO - 2016-09-27 14:55:14 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:14 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:14 --> Controller Class Initialized
INFO - 2016-09-27 14:55:14 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:14 --> Model Class Initialized
INFO - 2016-09-27 14:55:14 --> Model Class Initialized
INFO - 2016-09-27 14:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:14 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:14 --> Total execution time: 0.0676
INFO - 2016-09-27 14:55:17 --> Config Class Initialized
INFO - 2016-09-27 14:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:17 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:17 --> URI Class Initialized
INFO - 2016-09-27 14:55:17 --> Router Class Initialized
INFO - 2016-09-27 14:55:17 --> Output Class Initialized
INFO - 2016-09-27 14:55:17 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:17 --> Input Class Initialized
INFO - 2016-09-27 14:55:17 --> Language Class Initialized
INFO - 2016-09-27 14:55:17 --> Loader Class Initialized
INFO - 2016-09-27 14:55:17 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:17 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:17 --> Controller Class Initialized
INFO - 2016-09-27 14:55:17 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:17 --> Model Class Initialized
INFO - 2016-09-27 14:55:17 --> Model Class Initialized
INFO - 2016-09-27 14:55:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:17 --> Config Class Initialized
INFO - 2016-09-27 14:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:17 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:17 --> URI Class Initialized
INFO - 2016-09-27 14:55:17 --> Router Class Initialized
INFO - 2016-09-27 14:55:17 --> Output Class Initialized
INFO - 2016-09-27 14:55:17 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:17 --> Input Class Initialized
INFO - 2016-09-27 14:55:17 --> Language Class Initialized
INFO - 2016-09-27 14:55:17 --> Loader Class Initialized
INFO - 2016-09-27 14:55:17 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:17 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:17 --> Controller Class Initialized
INFO - 2016-09-27 14:55:17 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:17 --> Model Class Initialized
INFO - 2016-09-27 14:55:17 --> Model Class Initialized
INFO - 2016-09-27 14:55:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:17 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:17 --> Total execution time: 0.0614
INFO - 2016-09-27 14:55:21 --> Config Class Initialized
INFO - 2016-09-27 14:55:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:21 --> URI Class Initialized
INFO - 2016-09-27 14:55:21 --> Router Class Initialized
INFO - 2016-09-27 14:55:21 --> Output Class Initialized
INFO - 2016-09-27 14:55:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:21 --> Input Class Initialized
INFO - 2016-09-27 14:55:21 --> Language Class Initialized
INFO - 2016-09-27 14:55:21 --> Loader Class Initialized
INFO - 2016-09-27 14:55:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:21 --> Controller Class Initialized
INFO - 2016-09-27 14:55:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:21 --> Model Class Initialized
INFO - 2016-09-27 14:55:21 --> Model Class Initialized
INFO - 2016-09-27 14:55:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:21 --> Config Class Initialized
INFO - 2016-09-27 14:55:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:21 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:21 --> URI Class Initialized
INFO - 2016-09-27 14:55:21 --> Router Class Initialized
INFO - 2016-09-27 14:55:21 --> Output Class Initialized
INFO - 2016-09-27 14:55:21 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:21 --> Input Class Initialized
INFO - 2016-09-27 14:55:21 --> Language Class Initialized
INFO - 2016-09-27 14:55:21 --> Loader Class Initialized
INFO - 2016-09-27 14:55:21 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:21 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:21 --> Controller Class Initialized
INFO - 2016-09-27 14:55:21 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:21 --> Model Class Initialized
INFO - 2016-09-27 14:55:21 --> Model Class Initialized
INFO - 2016-09-27 14:55:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:21 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:21 --> Total execution time: 0.0708
INFO - 2016-09-27 14:55:24 --> Config Class Initialized
INFO - 2016-09-27 14:55:24 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:24 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:24 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:24 --> URI Class Initialized
INFO - 2016-09-27 14:55:24 --> Router Class Initialized
INFO - 2016-09-27 14:55:24 --> Output Class Initialized
INFO - 2016-09-27 14:55:24 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:24 --> Input Class Initialized
INFO - 2016-09-27 14:55:24 --> Language Class Initialized
INFO - 2016-09-27 14:55:24 --> Loader Class Initialized
INFO - 2016-09-27 14:55:24 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:24 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:24 --> Controller Class Initialized
INFO - 2016-09-27 14:55:24 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:24 --> Model Class Initialized
INFO - 2016-09-27 14:55:24 --> Model Class Initialized
INFO - 2016-09-27 14:55:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:24 --> Config Class Initialized
INFO - 2016-09-27 14:55:24 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:24 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:24 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:24 --> URI Class Initialized
INFO - 2016-09-27 14:55:24 --> Router Class Initialized
INFO - 2016-09-27 14:55:24 --> Output Class Initialized
INFO - 2016-09-27 14:55:24 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:24 --> Input Class Initialized
INFO - 2016-09-27 14:55:24 --> Language Class Initialized
INFO - 2016-09-27 14:55:24 --> Loader Class Initialized
INFO - 2016-09-27 14:55:24 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:24 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:24 --> Controller Class Initialized
INFO - 2016-09-27 14:55:24 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:24 --> Model Class Initialized
INFO - 2016-09-27 14:55:24 --> Model Class Initialized
INFO - 2016-09-27 14:55:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:24 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:24 --> Total execution time: 0.0622
INFO - 2016-09-27 14:55:28 --> Config Class Initialized
INFO - 2016-09-27 14:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:28 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:28 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:28 --> URI Class Initialized
INFO - 2016-09-27 14:55:28 --> Router Class Initialized
INFO - 2016-09-27 14:55:28 --> Output Class Initialized
INFO - 2016-09-27 14:55:28 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:28 --> Input Class Initialized
INFO - 2016-09-27 14:55:28 --> Language Class Initialized
INFO - 2016-09-27 14:55:28 --> Loader Class Initialized
INFO - 2016-09-27 14:55:28 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:28 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:28 --> Controller Class Initialized
INFO - 2016-09-27 14:55:28 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:28 --> Model Class Initialized
INFO - 2016-09-27 14:55:28 --> Model Class Initialized
INFO - 2016-09-27 14:55:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:28 --> Config Class Initialized
INFO - 2016-09-27 14:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:28 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:28 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:28 --> URI Class Initialized
INFO - 2016-09-27 14:55:28 --> Router Class Initialized
INFO - 2016-09-27 14:55:28 --> Output Class Initialized
INFO - 2016-09-27 14:55:28 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:28 --> Input Class Initialized
INFO - 2016-09-27 14:55:28 --> Language Class Initialized
INFO - 2016-09-27 14:55:28 --> Loader Class Initialized
INFO - 2016-09-27 14:55:28 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:28 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:28 --> Controller Class Initialized
INFO - 2016-09-27 14:55:28 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:28 --> Model Class Initialized
INFO - 2016-09-27 14:55:28 --> Model Class Initialized
INFO - 2016-09-27 14:55:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:28 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:28 --> Total execution time: 0.0618
INFO - 2016-09-27 14:55:31 --> Config Class Initialized
INFO - 2016-09-27 14:55:31 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:31 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:31 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:31 --> URI Class Initialized
INFO - 2016-09-27 14:55:31 --> Router Class Initialized
INFO - 2016-09-27 14:55:31 --> Output Class Initialized
INFO - 2016-09-27 14:55:31 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:31 --> Input Class Initialized
INFO - 2016-09-27 14:55:31 --> Language Class Initialized
INFO - 2016-09-27 14:55:31 --> Loader Class Initialized
INFO - 2016-09-27 14:55:31 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:31 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:31 --> Controller Class Initialized
INFO - 2016-09-27 14:55:31 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:31 --> Model Class Initialized
INFO - 2016-09-27 14:55:31 --> Model Class Initialized
INFO - 2016-09-27 14:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:31 --> Config Class Initialized
INFO - 2016-09-27 14:55:31 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:31 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:31 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:31 --> URI Class Initialized
INFO - 2016-09-27 14:55:31 --> Router Class Initialized
INFO - 2016-09-27 14:55:31 --> Output Class Initialized
INFO - 2016-09-27 14:55:31 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:31 --> Input Class Initialized
INFO - 2016-09-27 14:55:31 --> Language Class Initialized
INFO - 2016-09-27 14:55:32 --> Loader Class Initialized
INFO - 2016-09-27 14:55:32 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:32 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:32 --> Controller Class Initialized
INFO - 2016-09-27 14:55:32 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:32 --> Model Class Initialized
INFO - 2016-09-27 14:55:32 --> Model Class Initialized
INFO - 2016-09-27 14:55:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:32 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:32 --> Total execution time: 0.0777
INFO - 2016-09-27 14:55:35 --> Config Class Initialized
INFO - 2016-09-27 14:55:35 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:35 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:35 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:35 --> URI Class Initialized
INFO - 2016-09-27 14:55:35 --> Router Class Initialized
INFO - 2016-09-27 14:55:35 --> Output Class Initialized
INFO - 2016-09-27 14:55:35 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:35 --> Input Class Initialized
INFO - 2016-09-27 14:55:35 --> Language Class Initialized
INFO - 2016-09-27 14:55:35 --> Loader Class Initialized
INFO - 2016-09-27 14:55:35 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:35 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:35 --> Controller Class Initialized
INFO - 2016-09-27 14:55:35 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:35 --> Model Class Initialized
INFO - 2016-09-27 14:55:35 --> Model Class Initialized
INFO - 2016-09-27 14:55:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:35 --> Config Class Initialized
INFO - 2016-09-27 14:55:35 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:35 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:35 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:35 --> URI Class Initialized
INFO - 2016-09-27 14:55:35 --> Router Class Initialized
INFO - 2016-09-27 14:55:35 --> Output Class Initialized
INFO - 2016-09-27 14:55:35 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:35 --> Input Class Initialized
INFO - 2016-09-27 14:55:35 --> Language Class Initialized
INFO - 2016-09-27 14:55:35 --> Loader Class Initialized
INFO - 2016-09-27 14:55:35 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:35 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:35 --> Controller Class Initialized
INFO - 2016-09-27 14:55:35 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:35 --> Model Class Initialized
INFO - 2016-09-27 14:55:35 --> Model Class Initialized
INFO - 2016-09-27 14:55:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:35 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:35 --> Total execution time: 0.0630
INFO - 2016-09-27 14:55:39 --> Config Class Initialized
INFO - 2016-09-27 14:55:39 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:39 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:39 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:39 --> URI Class Initialized
INFO - 2016-09-27 14:55:39 --> Router Class Initialized
INFO - 2016-09-27 14:55:39 --> Output Class Initialized
INFO - 2016-09-27 14:55:39 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:39 --> Input Class Initialized
INFO - 2016-09-27 14:55:39 --> Language Class Initialized
INFO - 2016-09-27 14:55:39 --> Loader Class Initialized
INFO - 2016-09-27 14:55:39 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:39 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:39 --> Controller Class Initialized
INFO - 2016-09-27 14:55:39 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:39 --> Model Class Initialized
INFO - 2016-09-27 14:55:39 --> Model Class Initialized
INFO - 2016-09-27 14:55:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:39 --> Config Class Initialized
INFO - 2016-09-27 14:55:39 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:39 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:39 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:39 --> URI Class Initialized
INFO - 2016-09-27 14:55:39 --> Router Class Initialized
INFO - 2016-09-27 14:55:39 --> Output Class Initialized
INFO - 2016-09-27 14:55:39 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:39 --> Input Class Initialized
INFO - 2016-09-27 14:55:39 --> Language Class Initialized
INFO - 2016-09-27 14:55:39 --> Loader Class Initialized
INFO - 2016-09-27 14:55:39 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:39 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:39 --> Controller Class Initialized
INFO - 2016-09-27 14:55:39 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:39 --> Model Class Initialized
INFO - 2016-09-27 14:55:39 --> Model Class Initialized
INFO - 2016-09-27 14:55:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 14:55:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:39 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:39 --> Total execution time: 0.0693
INFO - 2016-09-27 14:55:39 --> Config Class Initialized
INFO - 2016-09-27 14:55:39 --> Hooks Class Initialized
DEBUG - 2016-09-27 14:55:39 --> UTF-8 Support Enabled
INFO - 2016-09-27 14:55:39 --> Utf8 Class Initialized
INFO - 2016-09-27 14:55:39 --> URI Class Initialized
INFO - 2016-09-27 14:55:39 --> Router Class Initialized
INFO - 2016-09-27 14:55:39 --> Output Class Initialized
INFO - 2016-09-27 14:55:39 --> Security Class Initialized
DEBUG - 2016-09-27 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 14:55:39 --> Input Class Initialized
INFO - 2016-09-27 14:55:39 --> Language Class Initialized
INFO - 2016-09-27 14:55:39 --> Loader Class Initialized
INFO - 2016-09-27 14:55:39 --> Helper loaded: url_helper
INFO - 2016-09-27 14:55:39 --> Helper loaded: language_helper
INFO - 2016-09-27 14:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 14:55:39 --> Controller Class Initialized
INFO - 2016-09-27 14:55:39 --> Database Driver Class Initialized
INFO - 2016-09-27 14:55:39 --> Model Class Initialized
INFO - 2016-09-27 14:55:39 --> Model Class Initialized
INFO - 2016-09-27 14:55:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 14:55:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 14:55:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 14:55:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 14:55:39 --> Final output sent to browser
DEBUG - 2016-09-27 14:55:39 --> Total execution time: 0.0636
INFO - 2016-09-27 15:01:05 --> Config Class Initialized
INFO - 2016-09-27 15:01:05 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:01:05 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:01:05 --> Utf8 Class Initialized
INFO - 2016-09-27 15:01:05 --> URI Class Initialized
INFO - 2016-09-27 15:01:05 --> Router Class Initialized
INFO - 2016-09-27 15:01:05 --> Output Class Initialized
INFO - 2016-09-27 15:01:05 --> Security Class Initialized
DEBUG - 2016-09-27 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:01:05 --> Input Class Initialized
INFO - 2016-09-27 15:01:05 --> Language Class Initialized
INFO - 2016-09-27 15:01:05 --> Loader Class Initialized
INFO - 2016-09-27 15:01:05 --> Helper loaded: url_helper
INFO - 2016-09-27 15:01:05 --> Helper loaded: language_helper
INFO - 2016-09-27 15:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:01:05 --> Controller Class Initialized
INFO - 2016-09-27 15:01:05 --> Database Driver Class Initialized
INFO - 2016-09-27 15:01:05 --> Model Class Initialized
INFO - 2016-09-27 15:01:05 --> Model Class Initialized
INFO - 2016-09-27 15:01:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:01:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:01:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 15:01:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:01:05 --> Final output sent to browser
DEBUG - 2016-09-27 15:01:05 --> Total execution time: 0.0775
INFO - 2016-09-27 15:03:09 --> Config Class Initialized
INFO - 2016-09-27 15:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:03:09 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:03:09 --> Utf8 Class Initialized
INFO - 2016-09-27 15:03:09 --> URI Class Initialized
INFO - 2016-09-27 15:03:09 --> Router Class Initialized
INFO - 2016-09-27 15:03:09 --> Output Class Initialized
INFO - 2016-09-27 15:03:09 --> Security Class Initialized
DEBUG - 2016-09-27 15:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:03:09 --> Input Class Initialized
INFO - 2016-09-27 15:03:09 --> Language Class Initialized
INFO - 2016-09-27 15:03:09 --> Loader Class Initialized
INFO - 2016-09-27 15:03:09 --> Helper loaded: url_helper
INFO - 2016-09-27 15:03:09 --> Helper loaded: language_helper
INFO - 2016-09-27 15:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:03:09 --> Controller Class Initialized
INFO - 2016-09-27 15:03:09 --> Database Driver Class Initialized
INFO - 2016-09-27 15:03:09 --> Model Class Initialized
INFO - 2016-09-27 15:03:09 --> Model Class Initialized
INFO - 2016-09-27 15:03:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:03:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:03:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 15:03:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:03:09 --> Final output sent to browser
DEBUG - 2016-09-27 15:03:09 --> Total execution time: 0.0715
INFO - 2016-09-27 15:04:36 --> Config Class Initialized
INFO - 2016-09-27 15:04:36 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:04:36 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:04:36 --> Utf8 Class Initialized
INFO - 2016-09-27 15:04:36 --> URI Class Initialized
INFO - 2016-09-27 15:04:36 --> Router Class Initialized
INFO - 2016-09-27 15:04:36 --> Output Class Initialized
INFO - 2016-09-27 15:04:36 --> Security Class Initialized
DEBUG - 2016-09-27 15:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:04:36 --> Input Class Initialized
INFO - 2016-09-27 15:04:36 --> Language Class Initialized
INFO - 2016-09-27 15:04:36 --> Loader Class Initialized
INFO - 2016-09-27 15:04:36 --> Helper loaded: url_helper
INFO - 2016-09-27 15:04:36 --> Helper loaded: language_helper
INFO - 2016-09-27 15:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:04:36 --> Controller Class Initialized
INFO - 2016-09-27 15:04:36 --> Database Driver Class Initialized
INFO - 2016-09-27 15:04:36 --> Model Class Initialized
INFO - 2016-09-27 15:04:36 --> Model Class Initialized
INFO - 2016-09-27 15:04:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 15:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:04:36 --> Final output sent to browser
DEBUG - 2016-09-27 15:04:36 --> Total execution time: 0.0765
INFO - 2016-09-27 15:04:58 --> Config Class Initialized
INFO - 2016-09-27 15:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:04:58 --> Utf8 Class Initialized
INFO - 2016-09-27 15:04:58 --> URI Class Initialized
INFO - 2016-09-27 15:04:58 --> Router Class Initialized
INFO - 2016-09-27 15:04:58 --> Output Class Initialized
INFO - 2016-09-27 15:04:58 --> Security Class Initialized
DEBUG - 2016-09-27 15:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:04:58 --> Input Class Initialized
INFO - 2016-09-27 15:04:58 --> Language Class Initialized
INFO - 2016-09-27 15:04:58 --> Loader Class Initialized
INFO - 2016-09-27 15:04:58 --> Helper loaded: url_helper
INFO - 2016-09-27 15:04:58 --> Helper loaded: language_helper
INFO - 2016-09-27 15:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:04:58 --> Controller Class Initialized
INFO - 2016-09-27 15:04:58 --> Database Driver Class Initialized
INFO - 2016-09-27 15:04:58 --> Model Class Initialized
INFO - 2016-09-27 15:04:58 --> Model Class Initialized
INFO - 2016-09-27 15:04:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:04:58 --> Config Class Initialized
INFO - 2016-09-27 15:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:04:58 --> Utf8 Class Initialized
INFO - 2016-09-27 15:04:58 --> URI Class Initialized
INFO - 2016-09-27 15:04:58 --> Router Class Initialized
INFO - 2016-09-27 15:04:58 --> Output Class Initialized
INFO - 2016-09-27 15:04:58 --> Security Class Initialized
DEBUG - 2016-09-27 15:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:04:58 --> Input Class Initialized
INFO - 2016-09-27 15:04:58 --> Language Class Initialized
INFO - 2016-09-27 15:04:58 --> Loader Class Initialized
INFO - 2016-09-27 15:04:58 --> Helper loaded: url_helper
INFO - 2016-09-27 15:04:58 --> Helper loaded: language_helper
INFO - 2016-09-27 15:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:04:58 --> Controller Class Initialized
INFO - 2016-09-27 15:04:58 --> Database Driver Class Initialized
INFO - 2016-09-27 15:04:58 --> Model Class Initialized
INFO - 2016-09-27 15:04:58 --> Model Class Initialized
INFO - 2016-09-27 15:04:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 15:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:04:58 --> Final output sent to browser
DEBUG - 2016-09-27 15:04:58 --> Total execution time: 0.0688
INFO - 2016-09-27 15:04:58 --> Config Class Initialized
INFO - 2016-09-27 15:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:04:58 --> Utf8 Class Initialized
INFO - 2016-09-27 15:04:58 --> URI Class Initialized
INFO - 2016-09-27 15:04:58 --> Config Class Initialized
INFO - 2016-09-27 15:04:58 --> Hooks Class Initialized
INFO - 2016-09-27 15:04:58 --> Router Class Initialized
INFO - 2016-09-27 15:04:58 --> Output Class Initialized
DEBUG - 2016-09-27 15:04:58 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:04:58 --> Utf8 Class Initialized
INFO - 2016-09-27 15:04:58 --> Security Class Initialized
INFO - 2016-09-27 15:04:58 --> URI Class Initialized
DEBUG - 2016-09-27 15:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:04:58 --> Input Class Initialized
INFO - 2016-09-27 15:04:58 --> Language Class Initialized
INFO - 2016-09-27 15:04:58 --> Router Class Initialized
INFO - 2016-09-27 15:04:58 --> Loader Class Initialized
INFO - 2016-09-27 15:04:58 --> Output Class Initialized
INFO - 2016-09-27 15:04:58 --> Helper loaded: url_helper
INFO - 2016-09-27 15:04:58 --> Helper loaded: language_helper
INFO - 2016-09-27 15:04:58 --> Security Class Initialized
DEBUG - 2016-09-27 15:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:04:58 --> Input Class Initialized
INFO - 2016-09-27 15:04:58 --> Language Class Initialized
INFO - 2016-09-27 15:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:04:58 --> Controller Class Initialized
INFO - 2016-09-27 15:04:58 --> Loader Class Initialized
INFO - 2016-09-27 15:04:58 --> Helper loaded: url_helper
INFO - 2016-09-27 15:04:58 --> Helper loaded: language_helper
INFO - 2016-09-27 15:04:58 --> Database Driver Class Initialized
INFO - 2016-09-27 15:04:58 --> Model Class Initialized
INFO - 2016-09-27 15:04:58 --> Model Class Initialized
INFO - 2016-09-27 15:04:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:04:58 --> Final output sent to browser
DEBUG - 2016-09-27 15:04:58 --> Total execution time: 0.0890
INFO - 2016-09-27 15:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:04:58 --> Controller Class Initialized
INFO - 2016-09-27 15:04:59 --> Database Driver Class Initialized
INFO - 2016-09-27 15:04:59 --> Model Class Initialized
INFO - 2016-09-27 15:04:59 --> Model Class Initialized
INFO - 2016-09-27 15:04:59 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-27 15:04:59 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-27 15:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-27 15:04:59 --> Final output sent to browser
DEBUG - 2016-09-27 15:04:59 --> Total execution time: 0.1194
INFO - 2016-09-27 15:05:28 --> Config Class Initialized
INFO - 2016-09-27 15:05:28 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:05:28 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:05:28 --> Utf8 Class Initialized
INFO - 2016-09-27 15:05:28 --> URI Class Initialized
INFO - 2016-09-27 15:05:28 --> Router Class Initialized
INFO - 2016-09-27 15:05:28 --> Output Class Initialized
INFO - 2016-09-27 15:05:28 --> Security Class Initialized
DEBUG - 2016-09-27 15:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:05:28 --> Input Class Initialized
INFO - 2016-09-27 15:05:28 --> Language Class Initialized
ERROR - 2016-09-27 15:05:28 --> 404 Page Not Found: Ujian/set_ind_time
INFO - 2016-09-27 15:05:32 --> Config Class Initialized
INFO - 2016-09-27 15:05:32 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:05:32 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:05:32 --> Utf8 Class Initialized
INFO - 2016-09-27 15:05:32 --> URI Class Initialized
INFO - 2016-09-27 15:05:32 --> Router Class Initialized
INFO - 2016-09-27 15:05:32 --> Output Class Initialized
INFO - 2016-09-27 15:05:32 --> Security Class Initialized
DEBUG - 2016-09-27 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:05:32 --> Input Class Initialized
INFO - 2016-09-27 15:05:32 --> Language Class Initialized
INFO - 2016-09-27 15:05:32 --> Loader Class Initialized
INFO - 2016-09-27 15:05:32 --> Helper loaded: url_helper
INFO - 2016-09-27 15:05:32 --> Helper loaded: language_helper
INFO - 2016-09-27 15:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:05:32 --> Controller Class Initialized
INFO - 2016-09-27 15:05:32 --> Database Driver Class Initialized
INFO - 2016-09-27 15:05:32 --> Model Class Initialized
INFO - 2016-09-27 15:05:32 --> Model Class Initialized
INFO - 2016-09-27 15:05:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:05:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:05:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-27 15:05:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:05:32 --> Final output sent to browser
DEBUG - 2016-09-27 15:05:32 --> Total execution time: 0.0732
INFO - 2016-09-27 15:05:48 --> Config Class Initialized
INFO - 2016-09-27 15:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:05:48 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:05:48 --> Utf8 Class Initialized
INFO - 2016-09-27 15:05:48 --> URI Class Initialized
INFO - 2016-09-27 15:05:48 --> Router Class Initialized
INFO - 2016-09-27 15:05:48 --> Output Class Initialized
INFO - 2016-09-27 15:05:48 --> Security Class Initialized
DEBUG - 2016-09-27 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:05:48 --> Input Class Initialized
INFO - 2016-09-27 15:05:48 --> Language Class Initialized
INFO - 2016-09-27 15:05:48 --> Loader Class Initialized
INFO - 2016-09-27 15:05:48 --> Helper loaded: url_helper
INFO - 2016-09-27 15:05:48 --> Helper loaded: language_helper
INFO - 2016-09-27 15:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:05:48 --> Controller Class Initialized
INFO - 2016-09-27 15:05:48 --> Database Driver Class Initialized
INFO - 2016-09-27 15:05:48 --> Model Class Initialized
INFO - 2016-09-27 15:05:48 --> Model Class Initialized
INFO - 2016-09-27 15:05:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 15:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:05:48 --> Final output sent to browser
DEBUG - 2016-09-27 15:05:48 --> Total execution time: 0.0800
INFO - 2016-09-27 15:05:48 --> Config Class Initialized
INFO - 2016-09-27 15:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:05:49 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:05:49 --> Utf8 Class Initialized
INFO - 2016-09-27 15:05:49 --> URI Class Initialized
INFO - 2016-09-27 15:05:49 --> Router Class Initialized
INFO - 2016-09-27 15:05:49 --> Output Class Initialized
INFO - 2016-09-27 15:05:49 --> Security Class Initialized
DEBUG - 2016-09-27 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:05:49 --> Input Class Initialized
INFO - 2016-09-27 15:05:49 --> Language Class Initialized
INFO - 2016-09-27 15:05:49 --> Loader Class Initialized
INFO - 2016-09-27 15:05:49 --> Helper loaded: url_helper
INFO - 2016-09-27 15:05:49 --> Helper loaded: language_helper
INFO - 2016-09-27 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:05:49 --> Controller Class Initialized
INFO - 2016-09-27 15:05:49 --> Database Driver Class Initialized
INFO - 2016-09-27 15:05:49 --> Model Class Initialized
INFO - 2016-09-27 15:05:49 --> Model Class Initialized
INFO - 2016-09-27 15:05:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-09-27 15:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:05:49 --> Final output sent to browser
DEBUG - 2016-09-27 15:05:49 --> Total execution time: 0.0763
INFO - 2016-09-27 15:06:11 --> Config Class Initialized
INFO - 2016-09-27 15:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:06:11 --> Utf8 Class Initialized
INFO - 2016-09-27 15:06:11 --> URI Class Initialized
INFO - 2016-09-27 15:06:11 --> Router Class Initialized
INFO - 2016-09-27 15:06:11 --> Output Class Initialized
INFO - 2016-09-27 15:06:11 --> Security Class Initialized
DEBUG - 2016-09-27 15:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:06:11 --> Input Class Initialized
INFO - 2016-09-27 15:06:11 --> Language Class Initialized
INFO - 2016-09-27 15:06:11 --> Loader Class Initialized
INFO - 2016-09-27 15:06:11 --> Helper loaded: url_helper
INFO - 2016-09-27 15:06:11 --> Helper loaded: language_helper
INFO - 2016-09-27 15:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:06:11 --> Controller Class Initialized
INFO - 2016-09-27 15:06:11 --> Database Driver Class Initialized
INFO - 2016-09-27 15:06:11 --> Model Class Initialized
INFO - 2016-09-27 15:06:11 --> Model Class Initialized
INFO - 2016-09-27 15:06:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:06:11 --> Config Class Initialized
INFO - 2016-09-27 15:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:06:11 --> Utf8 Class Initialized
INFO - 2016-09-27 15:06:11 --> URI Class Initialized
INFO - 2016-09-27 15:06:11 --> Router Class Initialized
INFO - 2016-09-27 15:06:11 --> Output Class Initialized
INFO - 2016-09-27 15:06:11 --> Security Class Initialized
DEBUG - 2016-09-27 15:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:06:11 --> Input Class Initialized
INFO - 2016-09-27 15:06:11 --> Language Class Initialized
INFO - 2016-09-27 15:06:11 --> Loader Class Initialized
INFO - 2016-09-27 15:06:11 --> Helper loaded: url_helper
INFO - 2016-09-27 15:06:11 --> Helper loaded: language_helper
INFO - 2016-09-27 15:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:06:11 --> Controller Class Initialized
INFO - 2016-09-27 15:06:11 --> Database Driver Class Initialized
INFO - 2016-09-27 15:06:11 --> Model Class Initialized
INFO - 2016-09-27 15:06:11 --> Model Class Initialized
INFO - 2016-09-27 15:06:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:06:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:06:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-09-27 15:06:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:06:11 --> Final output sent to browser
DEBUG - 2016-09-27 15:06:11 --> Total execution time: 0.0765
INFO - 2016-09-27 15:06:11 --> Config Class Initialized
INFO - 2016-09-27 15:06:11 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:06:11 --> Utf8 Class Initialized
INFO - 2016-09-27 15:06:11 --> URI Class Initialized
INFO - 2016-09-27 15:06:11 --> Config Class Initialized
INFO - 2016-09-27 15:06:11 --> Hooks Class Initialized
INFO - 2016-09-27 15:06:11 --> Router Class Initialized
DEBUG - 2016-09-27 15:06:11 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:06:11 --> Utf8 Class Initialized
INFO - 2016-09-27 15:06:11 --> Output Class Initialized
INFO - 2016-09-27 15:06:11 --> URI Class Initialized
INFO - 2016-09-27 15:06:11 --> Security Class Initialized
INFO - 2016-09-27 15:06:11 --> Router Class Initialized
DEBUG - 2016-09-27 15:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:06:11 --> Input Class Initialized
INFO - 2016-09-27 15:06:11 --> Language Class Initialized
INFO - 2016-09-27 15:06:11 --> Output Class Initialized
INFO - 2016-09-27 15:06:11 --> Security Class Initialized
INFO - 2016-09-27 15:06:11 --> Loader Class Initialized
DEBUG - 2016-09-27 15:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:06:11 --> Helper loaded: url_helper
INFO - 2016-09-27 15:06:11 --> Input Class Initialized
INFO - 2016-09-27 15:06:11 --> Helper loaded: language_helper
INFO - 2016-09-27 15:06:11 --> Language Class Initialized
INFO - 2016-09-27 15:06:11 --> Loader Class Initialized
INFO - 2016-09-27 15:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:06:11 --> Controller Class Initialized
INFO - 2016-09-27 15:06:11 --> Helper loaded: url_helper
INFO - 2016-09-27 15:06:11 --> Helper loaded: language_helper
INFO - 2016-09-27 15:06:11 --> Database Driver Class Initialized
INFO - 2016-09-27 15:06:11 --> Model Class Initialized
INFO - 2016-09-27 15:06:11 --> Model Class Initialized
INFO - 2016-09-27 15:06:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:06:12 --> Final output sent to browser
DEBUG - 2016-09-27 15:06:12 --> Total execution time: 0.0919
INFO - 2016-09-27 15:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:06:12 --> Controller Class Initialized
INFO - 2016-09-27 15:06:12 --> Database Driver Class Initialized
INFO - 2016-09-27 15:06:12 --> Model Class Initialized
INFO - 2016-09-27 15:06:12 --> Model Class Initialized
INFO - 2016-09-27 15:06:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-09-27 15:06:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-09-27 15:06:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-09-27 15:06:12 --> Final output sent to browser
DEBUG - 2016-09-27 15:06:12 --> Total execution time: 0.1246
INFO - 2016-09-27 15:06:17 --> Config Class Initialized
INFO - 2016-09-27 15:06:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:06:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:06:17 --> Utf8 Class Initialized
INFO - 2016-09-27 15:06:17 --> URI Class Initialized
INFO - 2016-09-27 15:06:17 --> Router Class Initialized
INFO - 2016-09-27 15:06:17 --> Output Class Initialized
INFO - 2016-09-27 15:06:17 --> Security Class Initialized
DEBUG - 2016-09-27 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:06:17 --> Input Class Initialized
INFO - 2016-09-27 15:06:17 --> Language Class Initialized
INFO - 2016-09-27 15:06:17 --> Loader Class Initialized
INFO - 2016-09-27 15:06:17 --> Helper loaded: url_helper
INFO - 2016-09-27 15:06:17 --> Helper loaded: language_helper
INFO - 2016-09-27 15:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:06:17 --> Controller Class Initialized
INFO - 2016-09-27 15:06:17 --> Database Driver Class Initialized
INFO - 2016-09-27 15:06:17 --> Model Class Initialized
INFO - 2016-09-27 15:06:17 --> Model Class Initialized
INFO - 2016-09-27 15:06:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:06:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:06:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-27 15:06:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:06:17 --> Final output sent to browser
DEBUG - 2016-09-27 15:06:17 --> Total execution time: 0.0725
INFO - 2016-09-27 15:09:37 --> Config Class Initialized
INFO - 2016-09-27 15:09:37 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:09:37 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:09:37 --> Utf8 Class Initialized
INFO - 2016-09-27 15:09:37 --> URI Class Initialized
INFO - 2016-09-27 15:09:37 --> Router Class Initialized
INFO - 2016-09-27 15:09:37 --> Output Class Initialized
INFO - 2016-09-27 15:09:37 --> Security Class Initialized
DEBUG - 2016-09-27 15:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:09:37 --> Input Class Initialized
INFO - 2016-09-27 15:09:37 --> Language Class Initialized
INFO - 2016-09-27 15:09:37 --> Loader Class Initialized
INFO - 2016-09-27 15:09:37 --> Helper loaded: url_helper
INFO - 2016-09-27 15:09:37 --> Helper loaded: language_helper
INFO - 2016-09-27 15:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:09:37 --> Controller Class Initialized
INFO - 2016-09-27 15:09:37 --> Database Driver Class Initialized
INFO - 2016-09-27 15:09:37 --> Model Class Initialized
INFO - 2016-09-27 15:09:37 --> Model Class Initialized
INFO - 2016-09-27 15:09:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:09:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:09:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-09-27 15:09:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:09:37 --> Final output sent to browser
DEBUG - 2016-09-27 15:09:37 --> Total execution time: 0.0707
INFO - 2016-09-27 15:10:40 --> Config Class Initialized
INFO - 2016-09-27 15:10:40 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:10:40 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:10:40 --> Utf8 Class Initialized
INFO - 2016-09-27 15:10:40 --> URI Class Initialized
INFO - 2016-09-27 15:10:40 --> Router Class Initialized
INFO - 2016-09-27 15:10:40 --> Output Class Initialized
INFO - 2016-09-27 15:10:40 --> Security Class Initialized
DEBUG - 2016-09-27 15:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:10:40 --> Input Class Initialized
INFO - 2016-09-27 15:10:40 --> Language Class Initialized
INFO - 2016-09-27 15:10:40 --> Loader Class Initialized
INFO - 2016-09-27 15:10:40 --> Helper loaded: url_helper
INFO - 2016-09-27 15:10:40 --> Helper loaded: language_helper
INFO - 2016-09-27 15:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:10:40 --> Controller Class Initialized
INFO - 2016-09-27 15:10:40 --> Database Driver Class Initialized
INFO - 2016-09-27 15:10:40 --> Model Class Initialized
INFO - 2016-09-27 15:10:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:10:40 --> Helper loaded: form_helper
INFO - 2016-09-27 15:10:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:10:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 15:10:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:10:40 --> Final output sent to browser
DEBUG - 2016-09-27 15:10:40 --> Total execution time: 0.0733
INFO - 2016-09-27 15:10:45 --> Config Class Initialized
INFO - 2016-09-27 15:10:45 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:10:45 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:10:45 --> Utf8 Class Initialized
INFO - 2016-09-27 15:10:45 --> URI Class Initialized
INFO - 2016-09-27 15:10:45 --> Router Class Initialized
INFO - 2016-09-27 15:10:45 --> Output Class Initialized
INFO - 2016-09-27 15:10:45 --> Security Class Initialized
DEBUG - 2016-09-27 15:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:10:45 --> Input Class Initialized
INFO - 2016-09-27 15:10:45 --> Language Class Initialized
INFO - 2016-09-27 15:10:45 --> Loader Class Initialized
INFO - 2016-09-27 15:10:45 --> Helper loaded: url_helper
INFO - 2016-09-27 15:10:45 --> Helper loaded: language_helper
INFO - 2016-09-27 15:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:10:45 --> Controller Class Initialized
INFO - 2016-09-27 15:10:45 --> Database Driver Class Initialized
INFO - 2016-09-27 15:10:45 --> Model Class Initialized
INFO - 2016-09-27 15:10:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:10:45 --> Model Class Initialized
INFO - 2016-09-27 15:10:45 --> Helper loaded: form_helper
INFO - 2016-09-27 15:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 15:10:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:10:45 --> Final output sent to browser
DEBUG - 2016-09-27 15:10:45 --> Total execution time: 0.0688
INFO - 2016-09-27 15:31:30 --> Config Class Initialized
INFO - 2016-09-27 15:31:30 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:31:30 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:31:30 --> Utf8 Class Initialized
INFO - 2016-09-27 15:31:30 --> URI Class Initialized
INFO - 2016-09-27 15:31:30 --> Router Class Initialized
INFO - 2016-09-27 15:31:30 --> Output Class Initialized
INFO - 2016-09-27 15:31:30 --> Security Class Initialized
DEBUG - 2016-09-27 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:31:30 --> Input Class Initialized
INFO - 2016-09-27 15:31:30 --> Language Class Initialized
INFO - 2016-09-27 15:31:30 --> Loader Class Initialized
INFO - 2016-09-27 15:31:30 --> Helper loaded: url_helper
INFO - 2016-09-27 15:31:30 --> Helper loaded: language_helper
INFO - 2016-09-27 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:31:30 --> Controller Class Initialized
INFO - 2016-09-27 15:31:30 --> Database Driver Class Initialized
INFO - 2016-09-27 15:31:30 --> Model Class Initialized
INFO - 2016-09-27 15:31:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:31:30 --> Model Class Initialized
INFO - 2016-09-27 15:31:30 --> Helper loaded: form_helper
INFO - 2016-09-27 15:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 15:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:31:30 --> Final output sent to browser
DEBUG - 2016-09-27 15:31:30 --> Total execution time: 0.0753
INFO - 2016-09-27 15:31:33 --> Config Class Initialized
INFO - 2016-09-27 15:31:33 --> Hooks Class Initialized
DEBUG - 2016-09-27 15:31:33 --> UTF-8 Support Enabled
INFO - 2016-09-27 15:31:33 --> Utf8 Class Initialized
INFO - 2016-09-27 15:31:33 --> URI Class Initialized
INFO - 2016-09-27 15:31:33 --> Router Class Initialized
INFO - 2016-09-27 15:31:33 --> Output Class Initialized
INFO - 2016-09-27 15:31:33 --> Security Class Initialized
DEBUG - 2016-09-27 15:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 15:31:33 --> Input Class Initialized
INFO - 2016-09-27 15:31:33 --> Language Class Initialized
INFO - 2016-09-27 15:31:33 --> Loader Class Initialized
INFO - 2016-09-27 15:31:33 --> Helper loaded: url_helper
INFO - 2016-09-27 15:31:33 --> Helper loaded: language_helper
INFO - 2016-09-27 15:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 15:31:33 --> Controller Class Initialized
INFO - 2016-09-27 15:31:33 --> Database Driver Class Initialized
INFO - 2016-09-27 15:31:33 --> Model Class Initialized
INFO - 2016-09-27 15:31:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 15:31:33 --> Helper loaded: form_helper
INFO - 2016-09-27 15:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 15:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 15:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 15:31:33 --> Final output sent to browser
DEBUG - 2016-09-27 15:31:33 --> Total execution time: 0.0700
INFO - 2016-09-27 16:12:19 --> Config Class Initialized
INFO - 2016-09-27 16:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:12:19 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:12:19 --> Utf8 Class Initialized
INFO - 2016-09-27 16:12:19 --> URI Class Initialized
INFO - 2016-09-27 16:12:19 --> Router Class Initialized
INFO - 2016-09-27 16:12:19 --> Output Class Initialized
INFO - 2016-09-27 16:12:19 --> Security Class Initialized
DEBUG - 2016-09-27 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:12:19 --> Input Class Initialized
INFO - 2016-09-27 16:12:19 --> Language Class Initialized
INFO - 2016-09-27 16:12:19 --> Loader Class Initialized
INFO - 2016-09-27 16:12:19 --> Helper loaded: url_helper
INFO - 2016-09-27 16:12:19 --> Helper loaded: language_helper
INFO - 2016-09-27 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:12:19 --> Controller Class Initialized
INFO - 2016-09-27 16:12:19 --> Database Driver Class Initialized
INFO - 2016-09-27 16:12:19 --> Model Class Initialized
INFO - 2016-09-27 16:12:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:12:19 --> Helper loaded: form_helper
INFO - 2016-09-27 16:12:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:12:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:12:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:12:19 --> Final output sent to browser
DEBUG - 2016-09-27 16:12:19 --> Total execution time: 0.0681
INFO - 2016-09-27 16:13:06 --> Config Class Initialized
INFO - 2016-09-27 16:13:06 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:13:06 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:13:06 --> Utf8 Class Initialized
INFO - 2016-09-27 16:13:06 --> URI Class Initialized
INFO - 2016-09-27 16:13:06 --> Router Class Initialized
INFO - 2016-09-27 16:13:06 --> Output Class Initialized
INFO - 2016-09-27 16:13:06 --> Security Class Initialized
DEBUG - 2016-09-27 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:13:06 --> Input Class Initialized
INFO - 2016-09-27 16:13:06 --> Language Class Initialized
INFO - 2016-09-27 16:13:06 --> Loader Class Initialized
INFO - 2016-09-27 16:13:06 --> Helper loaded: url_helper
INFO - 2016-09-27 16:13:06 --> Helper loaded: language_helper
INFO - 2016-09-27 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:13:06 --> Controller Class Initialized
INFO - 2016-09-27 16:13:06 --> Database Driver Class Initialized
ERROR - 2016-09-27 16:13:06 --> Severity: error --> Exception: syntax error, unexpected '','' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\savsoftquiz\application\models\Hasil_model.php 14
INFO - 2016-09-27 16:13:49 --> Config Class Initialized
INFO - 2016-09-27 16:13:49 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:13:49 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:13:49 --> Utf8 Class Initialized
INFO - 2016-09-27 16:13:49 --> URI Class Initialized
INFO - 2016-09-27 16:13:49 --> Router Class Initialized
INFO - 2016-09-27 16:13:49 --> Output Class Initialized
INFO - 2016-09-27 16:13:49 --> Security Class Initialized
DEBUG - 2016-09-27 16:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:13:49 --> Input Class Initialized
INFO - 2016-09-27 16:13:49 --> Language Class Initialized
INFO - 2016-09-27 16:13:49 --> Loader Class Initialized
INFO - 2016-09-27 16:13:49 --> Helper loaded: url_helper
INFO - 2016-09-27 16:13:49 --> Helper loaded: language_helper
INFO - 2016-09-27 16:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:13:49 --> Controller Class Initialized
INFO - 2016-09-27 16:13:49 --> Database Driver Class Initialized
INFO - 2016-09-27 16:13:49 --> Model Class Initialized
INFO - 2016-09-27 16:13:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:13:49 --> Helper loaded: form_helper
INFO - 2016-09-27 16:13:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-27 16:13:49 --> Severity: Notice --> Undefined index: ist0 C:\wamp64\www\savsoftquiz\application\views\hasil_list.php 34
INFO - 2016-09-27 16:13:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:13:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:13:49 --> Final output sent to browser
DEBUG - 2016-09-27 16:13:49 --> Total execution time: 0.0684
INFO - 2016-09-27 16:14:14 --> Config Class Initialized
INFO - 2016-09-27 16:14:14 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:14:14 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:14:14 --> Utf8 Class Initialized
INFO - 2016-09-27 16:14:14 --> URI Class Initialized
INFO - 2016-09-27 16:14:14 --> Router Class Initialized
INFO - 2016-09-27 16:14:14 --> Output Class Initialized
INFO - 2016-09-27 16:14:14 --> Security Class Initialized
DEBUG - 2016-09-27 16:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:14:14 --> Input Class Initialized
INFO - 2016-09-27 16:14:14 --> Language Class Initialized
INFO - 2016-09-27 16:14:14 --> Loader Class Initialized
INFO - 2016-09-27 16:14:14 --> Helper loaded: url_helper
INFO - 2016-09-27 16:14:14 --> Helper loaded: language_helper
INFO - 2016-09-27 16:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:14:14 --> Controller Class Initialized
INFO - 2016-09-27 16:14:14 --> Database Driver Class Initialized
INFO - 2016-09-27 16:14:14 --> Model Class Initialized
INFO - 2016-09-27 16:14:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:14:14 --> Helper loaded: form_helper
INFO - 2016-09-27 16:14:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-27 16:14:14 --> Severity: Notice --> Undefined index: ist0 C:\wamp64\www\savsoftquiz\application\views\hasil_list.php 42
INFO - 2016-09-27 16:14:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:14:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:14:14 --> Final output sent to browser
DEBUG - 2016-09-27 16:14:14 --> Total execution time: 0.0670
INFO - 2016-09-27 16:14:51 --> Config Class Initialized
INFO - 2016-09-27 16:14:51 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:14:51 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:14:51 --> Utf8 Class Initialized
INFO - 2016-09-27 16:14:51 --> URI Class Initialized
INFO - 2016-09-27 16:14:51 --> Router Class Initialized
INFO - 2016-09-27 16:14:51 --> Output Class Initialized
INFO - 2016-09-27 16:14:51 --> Security Class Initialized
DEBUG - 2016-09-27 16:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:14:51 --> Input Class Initialized
INFO - 2016-09-27 16:14:51 --> Language Class Initialized
INFO - 2016-09-27 16:14:51 --> Loader Class Initialized
INFO - 2016-09-27 16:14:51 --> Helper loaded: url_helper
INFO - 2016-09-27 16:14:51 --> Helper loaded: language_helper
INFO - 2016-09-27 16:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:14:51 --> Controller Class Initialized
INFO - 2016-09-27 16:14:51 --> Database Driver Class Initialized
INFO - 2016-09-27 16:14:51 --> Model Class Initialized
INFO - 2016-09-27 16:14:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:14:51 --> Helper loaded: form_helper
INFO - 2016-09-27 16:14:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:14:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:14:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:14:51 --> Final output sent to browser
DEBUG - 2016-09-27 16:14:51 --> Total execution time: 0.0691
INFO - 2016-09-27 16:24:50 --> Config Class Initialized
INFO - 2016-09-27 16:24:50 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:24:50 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:24:50 --> Utf8 Class Initialized
INFO - 2016-09-27 16:24:50 --> URI Class Initialized
INFO - 2016-09-27 16:24:50 --> Router Class Initialized
INFO - 2016-09-27 16:24:50 --> Output Class Initialized
INFO - 2016-09-27 16:24:50 --> Security Class Initialized
DEBUG - 2016-09-27 16:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:24:50 --> Input Class Initialized
INFO - 2016-09-27 16:24:50 --> Language Class Initialized
INFO - 2016-09-27 16:24:50 --> Loader Class Initialized
INFO - 2016-09-27 16:24:50 --> Helper loaded: url_helper
INFO - 2016-09-27 16:24:50 --> Helper loaded: language_helper
INFO - 2016-09-27 16:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:24:50 --> Controller Class Initialized
INFO - 2016-09-27 16:24:50 --> Database Driver Class Initialized
INFO - 2016-09-27 16:24:50 --> Model Class Initialized
INFO - 2016-09-27 16:24:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:24:50 --> Helper loaded: form_helper
INFO - 2016-09-27 16:24:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:24:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:24:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:24:50 --> Final output sent to browser
DEBUG - 2016-09-27 16:24:50 --> Total execution time: 0.0721
INFO - 2016-09-27 16:25:09 --> Config Class Initialized
INFO - 2016-09-27 16:25:09 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:25:09 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:25:09 --> Utf8 Class Initialized
INFO - 2016-09-27 16:25:09 --> URI Class Initialized
INFO - 2016-09-27 16:25:09 --> Router Class Initialized
INFO - 2016-09-27 16:25:09 --> Output Class Initialized
INFO - 2016-09-27 16:25:09 --> Security Class Initialized
DEBUG - 2016-09-27 16:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:25:09 --> Input Class Initialized
INFO - 2016-09-27 16:25:09 --> Language Class Initialized
INFO - 2016-09-27 16:25:09 --> Loader Class Initialized
INFO - 2016-09-27 16:25:09 --> Helper loaded: url_helper
INFO - 2016-09-27 16:25:09 --> Helper loaded: language_helper
INFO - 2016-09-27 16:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:25:09 --> Controller Class Initialized
INFO - 2016-09-27 16:25:09 --> Database Driver Class Initialized
INFO - 2016-09-27 16:25:09 --> Model Class Initialized
INFO - 2016-09-27 16:25:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:25:09 --> Helper loaded: form_helper
INFO - 2016-09-27 16:25:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:25:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:25:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:25:09 --> Final output sent to browser
DEBUG - 2016-09-27 16:25:09 --> Total execution time: 0.0659
INFO - 2016-09-27 16:25:10 --> Config Class Initialized
INFO - 2016-09-27 16:25:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:25:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:25:10 --> Utf8 Class Initialized
INFO - 2016-09-27 16:25:10 --> URI Class Initialized
INFO - 2016-09-27 16:25:10 --> Router Class Initialized
INFO - 2016-09-27 16:25:10 --> Output Class Initialized
INFO - 2016-09-27 16:25:10 --> Security Class Initialized
DEBUG - 2016-09-27 16:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:25:10 --> Input Class Initialized
INFO - 2016-09-27 16:25:10 --> Language Class Initialized
INFO - 2016-09-27 16:25:10 --> Loader Class Initialized
INFO - 2016-09-27 16:25:10 --> Helper loaded: url_helper
INFO - 2016-09-27 16:25:10 --> Helper loaded: language_helper
INFO - 2016-09-27 16:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:25:10 --> Controller Class Initialized
INFO - 2016-09-27 16:25:10 --> Database Driver Class Initialized
INFO - 2016-09-27 16:25:10 --> Model Class Initialized
INFO - 2016-09-27 16:25:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:25:10 --> Helper loaded: form_helper
INFO - 2016-09-27 16:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:25:10 --> Final output sent to browser
DEBUG - 2016-09-27 16:25:10 --> Total execution time: 0.0798
INFO - 2016-09-27 16:25:26 --> Config Class Initialized
INFO - 2016-09-27 16:25:26 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:25:26 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:25:26 --> Utf8 Class Initialized
INFO - 2016-09-27 16:25:26 --> URI Class Initialized
INFO - 2016-09-27 16:25:26 --> Router Class Initialized
INFO - 2016-09-27 16:25:27 --> Output Class Initialized
INFO - 2016-09-27 16:25:27 --> Security Class Initialized
DEBUG - 2016-09-27 16:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:25:27 --> Input Class Initialized
INFO - 2016-09-27 16:25:27 --> Language Class Initialized
INFO - 2016-09-27 16:25:27 --> Loader Class Initialized
INFO - 2016-09-27 16:25:27 --> Helper loaded: url_helper
INFO - 2016-09-27 16:25:27 --> Helper loaded: language_helper
INFO - 2016-09-27 16:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:25:27 --> Controller Class Initialized
INFO - 2016-09-27 16:25:27 --> Database Driver Class Initialized
INFO - 2016-09-27 16:25:27 --> Model Class Initialized
INFO - 2016-09-27 16:25:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:25:27 --> Helper loaded: form_helper
INFO - 2016-09-27 16:25:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:25:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-09-27 16:25:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:25:27 --> Final output sent to browser
DEBUG - 2016-09-27 16:25:27 --> Total execution time: 0.0697
INFO - 2016-09-27 16:25:36 --> Config Class Initialized
INFO - 2016-09-27 16:25:36 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:25:36 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:25:36 --> Utf8 Class Initialized
INFO - 2016-09-27 16:25:36 --> URI Class Initialized
INFO - 2016-09-27 16:25:36 --> Router Class Initialized
INFO - 2016-09-27 16:25:36 --> Output Class Initialized
INFO - 2016-09-27 16:25:36 --> Security Class Initialized
DEBUG - 2016-09-27 16:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:25:36 --> Input Class Initialized
INFO - 2016-09-27 16:25:36 --> Language Class Initialized
INFO - 2016-09-27 16:25:36 --> Loader Class Initialized
INFO - 2016-09-27 16:25:36 --> Helper loaded: url_helper
INFO - 2016-09-27 16:25:36 --> Helper loaded: language_helper
INFO - 2016-09-27 16:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:25:36 --> Controller Class Initialized
INFO - 2016-09-27 16:25:36 --> Database Driver Class Initialized
INFO - 2016-09-27 16:25:36 --> Model Class Initialized
INFO - 2016-09-27 16:25:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:25:36 --> Model Class Initialized
INFO - 2016-09-27 16:25:36 --> Model Class Initialized
INFO - 2016-09-27 16:25:36 --> Helper loaded: form_helper
INFO - 2016-09-27 16:25:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-27 16:25:36 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::and_where() C:\wamp64\www\savsoftquiz\application\models\Norma_ist_model.php 19
INFO - 2016-09-27 16:26:25 --> Config Class Initialized
INFO - 2016-09-27 16:26:25 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:26:25 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:26:25 --> Utf8 Class Initialized
INFO - 2016-09-27 16:26:25 --> URI Class Initialized
INFO - 2016-09-27 16:26:25 --> Router Class Initialized
INFO - 2016-09-27 16:26:25 --> Output Class Initialized
INFO - 2016-09-27 16:26:25 --> Security Class Initialized
DEBUG - 2016-09-27 16:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:26:25 --> Input Class Initialized
INFO - 2016-09-27 16:26:25 --> Language Class Initialized
INFO - 2016-09-27 16:26:25 --> Loader Class Initialized
INFO - 2016-09-27 16:26:25 --> Helper loaded: url_helper
INFO - 2016-09-27 16:26:25 --> Helper loaded: language_helper
INFO - 2016-09-27 16:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:26:25 --> Controller Class Initialized
INFO - 2016-09-27 16:26:25 --> Database Driver Class Initialized
INFO - 2016-09-27 16:26:25 --> Model Class Initialized
INFO - 2016-09-27 16:26:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:26:25 --> Model Class Initialized
INFO - 2016-09-27 16:26:25 --> Model Class Initialized
INFO - 2016-09-27 16:26:25 --> Helper loaded: form_helper
INFO - 2016-09-27 16:26:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:26:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:26:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:26:25 --> Final output sent to browser
DEBUG - 2016-09-27 16:26:25 --> Total execution time: 0.0706
INFO - 2016-09-27 16:53:35 --> Config Class Initialized
INFO - 2016-09-27 16:53:35 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:53:35 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:53:35 --> Utf8 Class Initialized
INFO - 2016-09-27 16:53:35 --> URI Class Initialized
INFO - 2016-09-27 16:53:35 --> Router Class Initialized
INFO - 2016-09-27 16:53:35 --> Output Class Initialized
INFO - 2016-09-27 16:53:35 --> Security Class Initialized
DEBUG - 2016-09-27 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:53:35 --> Input Class Initialized
INFO - 2016-09-27 16:53:35 --> Language Class Initialized
INFO - 2016-09-27 16:53:35 --> Loader Class Initialized
INFO - 2016-09-27 16:53:35 --> Helper loaded: url_helper
INFO - 2016-09-27 16:53:35 --> Helper loaded: language_helper
INFO - 2016-09-27 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:53:35 --> Controller Class Initialized
INFO - 2016-09-27 16:53:35 --> Database Driver Class Initialized
INFO - 2016-09-27 16:53:35 --> Model Class Initialized
INFO - 2016-09-27 16:53:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:53:35 --> Model Class Initialized
INFO - 2016-09-27 16:53:35 --> Model Class Initialized
INFO - 2016-09-27 16:53:35 --> Helper loaded: form_helper
INFO - 2016-09-27 16:53:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:53:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:53:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:53:35 --> Final output sent to browser
DEBUG - 2016-09-27 16:53:35 --> Total execution time: 0.0799
INFO - 2016-09-27 16:53:43 --> Config Class Initialized
INFO - 2016-09-27 16:53:43 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:53:43 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:53:43 --> Utf8 Class Initialized
INFO - 2016-09-27 16:53:43 --> URI Class Initialized
INFO - 2016-09-27 16:53:43 --> Router Class Initialized
INFO - 2016-09-27 16:53:43 --> Output Class Initialized
INFO - 2016-09-27 16:53:43 --> Security Class Initialized
DEBUG - 2016-09-27 16:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:53:43 --> Input Class Initialized
INFO - 2016-09-27 16:53:43 --> Language Class Initialized
INFO - 2016-09-27 16:53:43 --> Loader Class Initialized
INFO - 2016-09-27 16:53:43 --> Helper loaded: url_helper
INFO - 2016-09-27 16:53:43 --> Helper loaded: language_helper
INFO - 2016-09-27 16:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:53:43 --> Controller Class Initialized
INFO - 2016-09-27 16:53:43 --> Database Driver Class Initialized
INFO - 2016-09-27 16:53:43 --> Model Class Initialized
INFO - 2016-09-27 16:53:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:53:43 --> Model Class Initialized
INFO - 2016-09-27 16:53:43 --> Model Class Initialized
INFO - 2016-09-27 16:53:43 --> Helper loaded: form_helper
INFO - 2016-09-27 16:53:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:53:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:53:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:53:43 --> Final output sent to browser
DEBUG - 2016-09-27 16:53:43 --> Total execution time: 0.0820
INFO - 2016-09-27 16:55:55 --> Config Class Initialized
INFO - 2016-09-27 16:55:55 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:55:55 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:55:55 --> Utf8 Class Initialized
INFO - 2016-09-27 16:55:55 --> URI Class Initialized
INFO - 2016-09-27 16:55:55 --> Router Class Initialized
INFO - 2016-09-27 16:55:55 --> Output Class Initialized
INFO - 2016-09-27 16:55:55 --> Security Class Initialized
DEBUG - 2016-09-27 16:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:55:55 --> Input Class Initialized
INFO - 2016-09-27 16:55:55 --> Language Class Initialized
INFO - 2016-09-27 16:55:55 --> Loader Class Initialized
INFO - 2016-09-27 16:55:55 --> Helper loaded: url_helper
INFO - 2016-09-27 16:55:55 --> Helper loaded: language_helper
INFO - 2016-09-27 16:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:55:55 --> Controller Class Initialized
INFO - 2016-09-27 16:55:55 --> Database Driver Class Initialized
INFO - 2016-09-27 16:55:55 --> Model Class Initialized
INFO - 2016-09-27 16:55:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:55:55 --> Model Class Initialized
INFO - 2016-09-27 16:55:55 --> Model Class Initialized
INFO - 2016-09-27 16:55:55 --> Helper loaded: form_helper
INFO - 2016-09-27 16:55:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:55:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:55:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:55:55 --> Final output sent to browser
DEBUG - 2016-09-27 16:55:55 --> Total execution time: 0.0777
INFO - 2016-09-27 16:57:42 --> Config Class Initialized
INFO - 2016-09-27 16:57:42 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:57:42 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:57:42 --> Utf8 Class Initialized
INFO - 2016-09-27 16:57:42 --> URI Class Initialized
INFO - 2016-09-27 16:57:42 --> Router Class Initialized
INFO - 2016-09-27 16:57:42 --> Output Class Initialized
INFO - 2016-09-27 16:57:42 --> Security Class Initialized
DEBUG - 2016-09-27 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:57:42 --> Input Class Initialized
INFO - 2016-09-27 16:57:42 --> Language Class Initialized
INFO - 2016-09-27 16:57:42 --> Loader Class Initialized
INFO - 2016-09-27 16:57:42 --> Helper loaded: url_helper
INFO - 2016-09-27 16:57:42 --> Helper loaded: language_helper
INFO - 2016-09-27 16:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:57:42 --> Controller Class Initialized
INFO - 2016-09-27 16:57:42 --> Database Driver Class Initialized
INFO - 2016-09-27 16:57:42 --> Model Class Initialized
INFO - 2016-09-27 16:57:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:57:42 --> Model Class Initialized
INFO - 2016-09-27 16:57:42 --> Model Class Initialized
INFO - 2016-09-27 16:57:42 --> Helper loaded: form_helper
INFO - 2016-09-27 16:57:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:57:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:57:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:57:42 --> Final output sent to browser
DEBUG - 2016-09-27 16:57:42 --> Total execution time: 0.0711
INFO - 2016-09-27 16:58:35 --> Config Class Initialized
INFO - 2016-09-27 16:58:35 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:58:35 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:58:35 --> Utf8 Class Initialized
INFO - 2016-09-27 16:58:35 --> URI Class Initialized
INFO - 2016-09-27 16:58:35 --> Router Class Initialized
INFO - 2016-09-27 16:58:35 --> Output Class Initialized
INFO - 2016-09-27 16:58:35 --> Security Class Initialized
DEBUG - 2016-09-27 16:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:58:35 --> Input Class Initialized
INFO - 2016-09-27 16:58:35 --> Language Class Initialized
INFO - 2016-09-27 16:58:35 --> Loader Class Initialized
INFO - 2016-09-27 16:58:35 --> Helper loaded: url_helper
INFO - 2016-09-27 16:58:35 --> Helper loaded: language_helper
INFO - 2016-09-27 16:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:58:35 --> Controller Class Initialized
INFO - 2016-09-27 16:58:35 --> Database Driver Class Initialized
INFO - 2016-09-27 16:58:35 --> Model Class Initialized
INFO - 2016-09-27 16:58:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:58:35 --> Model Class Initialized
INFO - 2016-09-27 16:58:35 --> Model Class Initialized
INFO - 2016-09-27 16:58:35 --> Helper loaded: form_helper
INFO - 2016-09-27 16:58:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:58:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:58:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:58:35 --> Final output sent to browser
DEBUG - 2016-09-27 16:58:35 --> Total execution time: 0.0706
INFO - 2016-09-27 16:58:54 --> Config Class Initialized
INFO - 2016-09-27 16:58:54 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:58:54 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:58:54 --> Utf8 Class Initialized
INFO - 2016-09-27 16:58:54 --> URI Class Initialized
INFO - 2016-09-27 16:58:54 --> Router Class Initialized
INFO - 2016-09-27 16:58:54 --> Output Class Initialized
INFO - 2016-09-27 16:58:54 --> Security Class Initialized
DEBUG - 2016-09-27 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:58:54 --> Input Class Initialized
INFO - 2016-09-27 16:58:54 --> Language Class Initialized
INFO - 2016-09-27 16:58:54 --> Loader Class Initialized
INFO - 2016-09-27 16:58:54 --> Helper loaded: url_helper
INFO - 2016-09-27 16:58:54 --> Helper loaded: language_helper
INFO - 2016-09-27 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:58:54 --> Controller Class Initialized
INFO - 2016-09-27 16:58:54 --> Database Driver Class Initialized
INFO - 2016-09-27 16:58:54 --> Model Class Initialized
INFO - 2016-09-27 16:58:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:58:54 --> Model Class Initialized
INFO - 2016-09-27 16:58:54 --> Model Class Initialized
INFO - 2016-09-27 16:58:54 --> Helper loaded: form_helper
INFO - 2016-09-27 16:58:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:58:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:58:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:58:54 --> Final output sent to browser
DEBUG - 2016-09-27 16:58:54 --> Total execution time: 0.0780
INFO - 2016-09-27 16:59:26 --> Config Class Initialized
INFO - 2016-09-27 16:59:26 --> Hooks Class Initialized
DEBUG - 2016-09-27 16:59:26 --> UTF-8 Support Enabled
INFO - 2016-09-27 16:59:26 --> Utf8 Class Initialized
INFO - 2016-09-27 16:59:26 --> URI Class Initialized
INFO - 2016-09-27 16:59:26 --> Router Class Initialized
INFO - 2016-09-27 16:59:26 --> Output Class Initialized
INFO - 2016-09-27 16:59:26 --> Security Class Initialized
DEBUG - 2016-09-27 16:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 16:59:26 --> Input Class Initialized
INFO - 2016-09-27 16:59:26 --> Language Class Initialized
INFO - 2016-09-27 16:59:26 --> Loader Class Initialized
INFO - 2016-09-27 16:59:26 --> Helper loaded: url_helper
INFO - 2016-09-27 16:59:26 --> Helper loaded: language_helper
INFO - 2016-09-27 16:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 16:59:26 --> Controller Class Initialized
INFO - 2016-09-27 16:59:26 --> Database Driver Class Initialized
INFO - 2016-09-27 16:59:26 --> Model Class Initialized
INFO - 2016-09-27 16:59:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 16:59:26 --> Model Class Initialized
INFO - 2016-09-27 16:59:26 --> Model Class Initialized
INFO - 2016-09-27 16:59:26 --> Helper loaded: form_helper
INFO - 2016-09-27 16:59:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 16:59:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 16:59:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 16:59:26 --> Final output sent to browser
DEBUG - 2016-09-27 16:59:26 --> Total execution time: 0.0796
INFO - 2016-09-27 17:00:23 --> Config Class Initialized
INFO - 2016-09-27 17:00:23 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:00:23 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:00:23 --> Utf8 Class Initialized
INFO - 2016-09-27 17:00:23 --> URI Class Initialized
INFO - 2016-09-27 17:00:23 --> Router Class Initialized
INFO - 2016-09-27 17:00:23 --> Output Class Initialized
INFO - 2016-09-27 17:00:23 --> Security Class Initialized
DEBUG - 2016-09-27 17:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:00:23 --> Input Class Initialized
INFO - 2016-09-27 17:00:23 --> Language Class Initialized
INFO - 2016-09-27 17:00:23 --> Loader Class Initialized
INFO - 2016-09-27 17:00:23 --> Helper loaded: url_helper
INFO - 2016-09-27 17:00:23 --> Helper loaded: language_helper
INFO - 2016-09-27 17:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:00:23 --> Controller Class Initialized
INFO - 2016-09-27 17:00:23 --> Database Driver Class Initialized
INFO - 2016-09-27 17:00:23 --> Model Class Initialized
INFO - 2016-09-27 17:00:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:00:23 --> Model Class Initialized
INFO - 2016-09-27 17:00:23 --> Model Class Initialized
INFO - 2016-09-27 17:00:23 --> Helper loaded: form_helper
INFO - 2016-09-27 17:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:00:23 --> Final output sent to browser
DEBUG - 2016-09-27 17:00:23 --> Total execution time: 0.0716
INFO - 2016-09-27 17:04:48 --> Config Class Initialized
INFO - 2016-09-27 17:04:48 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:04:48 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:04:48 --> Utf8 Class Initialized
INFO - 2016-09-27 17:04:48 --> URI Class Initialized
INFO - 2016-09-27 17:04:48 --> Router Class Initialized
INFO - 2016-09-27 17:04:48 --> Output Class Initialized
INFO - 2016-09-27 17:04:48 --> Security Class Initialized
DEBUG - 2016-09-27 17:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:04:48 --> Input Class Initialized
INFO - 2016-09-27 17:04:48 --> Language Class Initialized
ERROR - 2016-09-27 17:04:48 --> Severity: error --> Exception: syntax error, unexpected '$model_norma_ist' (T_VARIABLE) C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 61
INFO - 2016-09-27 17:06:10 --> Config Class Initialized
INFO - 2016-09-27 17:06:10 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:06:10 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:06:10 --> Utf8 Class Initialized
INFO - 2016-09-27 17:06:10 --> URI Class Initialized
INFO - 2016-09-27 17:06:10 --> Router Class Initialized
INFO - 2016-09-27 17:06:10 --> Output Class Initialized
INFO - 2016-09-27 17:06:10 --> Security Class Initialized
DEBUG - 2016-09-27 17:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:06:10 --> Input Class Initialized
INFO - 2016-09-27 17:06:10 --> Language Class Initialized
ERROR - 2016-09-27 17:06:10 --> Severity: error --> Exception: syntax error, unexpected '$model_norma_ist' (T_VARIABLE) C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
INFO - 2016-09-27 17:06:45 --> Config Class Initialized
INFO - 2016-09-27 17:06:45 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:06:45 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:06:45 --> Utf8 Class Initialized
INFO - 2016-09-27 17:06:45 --> URI Class Initialized
INFO - 2016-09-27 17:06:45 --> Router Class Initialized
INFO - 2016-09-27 17:06:45 --> Output Class Initialized
INFO - 2016-09-27 17:06:45 --> Security Class Initialized
DEBUG - 2016-09-27 17:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:06:45 --> Input Class Initialized
INFO - 2016-09-27 17:06:45 --> Language Class Initialized
INFO - 2016-09-27 17:06:45 --> Loader Class Initialized
INFO - 2016-09-27 17:06:45 --> Helper loaded: url_helper
INFO - 2016-09-27 17:06:45 --> Helper loaded: language_helper
INFO - 2016-09-27 17:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:06:45 --> Controller Class Initialized
INFO - 2016-09-27 17:06:45 --> Database Driver Class Initialized
INFO - 2016-09-27 17:06:45 --> Model Class Initialized
INFO - 2016-09-27 17:06:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:06:45 --> Model Class Initialized
INFO - 2016-09-27 17:06:45 --> Model Class Initialized
INFO - 2016-09-27 17:06:45 --> Helper loaded: form_helper
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
ERROR - 2016-09-27 17:06:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 62
INFO - 2016-09-27 17:07:27 --> Config Class Initialized
INFO - 2016-09-27 17:07:27 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:07:27 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:07:27 --> Utf8 Class Initialized
INFO - 2016-09-27 17:07:27 --> URI Class Initialized
INFO - 2016-09-27 17:07:27 --> Router Class Initialized
INFO - 2016-09-27 17:07:27 --> Output Class Initialized
INFO - 2016-09-27 17:07:27 --> Security Class Initialized
DEBUG - 2016-09-27 17:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:07:27 --> Input Class Initialized
INFO - 2016-09-27 17:07:27 --> Language Class Initialized
INFO - 2016-09-27 17:07:27 --> Loader Class Initialized
INFO - 2016-09-27 17:07:27 --> Helper loaded: url_helper
INFO - 2016-09-27 17:07:27 --> Helper loaded: language_helper
INFO - 2016-09-27 17:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:07:27 --> Controller Class Initialized
INFO - 2016-09-27 17:07:27 --> Database Driver Class Initialized
INFO - 2016-09-27 17:07:27 --> Model Class Initialized
INFO - 2016-09-27 17:07:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:07:27 --> Model Class Initialized
INFO - 2016-09-27 17:07:27 --> Model Class Initialized
INFO - 2016-09-27 17:07:27 --> Helper loaded: form_helper
INFO - 2016-09-27 17:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:07:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:07:27 --> Final output sent to browser
DEBUG - 2016-09-27 17:07:27 --> Total execution time: 0.0685
INFO - 2016-09-27 17:08:31 --> Config Class Initialized
INFO - 2016-09-27 17:08:31 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:08:31 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:08:31 --> Utf8 Class Initialized
INFO - 2016-09-27 17:08:31 --> URI Class Initialized
INFO - 2016-09-27 17:08:31 --> Router Class Initialized
INFO - 2016-09-27 17:08:31 --> Output Class Initialized
INFO - 2016-09-27 17:08:31 --> Security Class Initialized
DEBUG - 2016-09-27 17:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:08:31 --> Input Class Initialized
INFO - 2016-09-27 17:08:31 --> Language Class Initialized
INFO - 2016-09-27 17:08:31 --> Loader Class Initialized
INFO - 2016-09-27 17:08:31 --> Helper loaded: url_helper
INFO - 2016-09-27 17:08:31 --> Helper loaded: language_helper
INFO - 2016-09-27 17:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:08:31 --> Controller Class Initialized
INFO - 2016-09-27 17:08:31 --> Database Driver Class Initialized
INFO - 2016-09-27 17:08:31 --> Model Class Initialized
INFO - 2016-09-27 17:08:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:08:31 --> Model Class Initialized
INFO - 2016-09-27 17:08:31 --> Model Class Initialized
INFO - 2016-09-27 17:08:31 --> Helper loaded: form_helper
INFO - 2016-09-27 17:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:08:31 --> Final output sent to browser
DEBUG - 2016-09-27 17:08:31 --> Total execution time: 0.0690
INFO - 2016-09-27 17:09:20 --> Config Class Initialized
INFO - 2016-09-27 17:09:20 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:09:20 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:09:20 --> Utf8 Class Initialized
INFO - 2016-09-27 17:09:20 --> URI Class Initialized
INFO - 2016-09-27 17:09:20 --> Router Class Initialized
INFO - 2016-09-27 17:09:20 --> Output Class Initialized
INFO - 2016-09-27 17:09:20 --> Security Class Initialized
DEBUG - 2016-09-27 17:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:09:20 --> Input Class Initialized
INFO - 2016-09-27 17:09:20 --> Language Class Initialized
INFO - 2016-09-27 17:09:20 --> Loader Class Initialized
INFO - 2016-09-27 17:09:20 --> Helper loaded: url_helper
INFO - 2016-09-27 17:09:20 --> Helper loaded: language_helper
INFO - 2016-09-27 17:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:09:20 --> Controller Class Initialized
INFO - 2016-09-27 17:09:20 --> Database Driver Class Initialized
INFO - 2016-09-27 17:09:20 --> Model Class Initialized
INFO - 2016-09-27 17:09:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:09:20 --> Model Class Initialized
INFO - 2016-09-27 17:09:20 --> Model Class Initialized
INFO - 2016-09-27 17:09:20 --> Helper loaded: form_helper
INFO - 2016-09-27 17:10:51 --> Config Class Initialized
INFO - 2016-09-27 17:10:51 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:10:51 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:10:51 --> Utf8 Class Initialized
INFO - 2016-09-27 17:10:51 --> URI Class Initialized
INFO - 2016-09-27 17:10:51 --> Router Class Initialized
INFO - 2016-09-27 17:10:51 --> Output Class Initialized
INFO - 2016-09-27 17:10:51 --> Security Class Initialized
DEBUG - 2016-09-27 17:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:10:51 --> Input Class Initialized
INFO - 2016-09-27 17:10:51 --> Language Class Initialized
INFO - 2016-09-27 17:10:51 --> Loader Class Initialized
INFO - 2016-09-27 17:10:51 --> Helper loaded: url_helper
INFO - 2016-09-27 17:10:51 --> Helper loaded: language_helper
INFO - 2016-09-27 17:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:10:51 --> Controller Class Initialized
INFO - 2016-09-27 17:10:51 --> Database Driver Class Initialized
INFO - 2016-09-27 17:10:51 --> Model Class Initialized
INFO - 2016-09-27 17:10:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:10:51 --> Model Class Initialized
INFO - 2016-09-27 17:10:51 --> Model Class Initialized
INFO - 2016-09-27 17:10:51 --> Helper loaded: form_helper
ERROR - 2016-09-27 17:10:51 --> Severity: Warning --> Illegal string offset 'ist0' C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 66
ERROR - 2016-09-27 17:10:51 --> Severity: error --> Exception: [] operator not supported for strings C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 66
INFO - 2016-09-27 17:11:05 --> Config Class Initialized
INFO - 2016-09-27 17:11:05 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:11:05 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:11:05 --> Utf8 Class Initialized
INFO - 2016-09-27 17:11:05 --> URI Class Initialized
INFO - 2016-09-27 17:11:05 --> Router Class Initialized
INFO - 2016-09-27 17:11:05 --> Output Class Initialized
INFO - 2016-09-27 17:11:05 --> Security Class Initialized
DEBUG - 2016-09-27 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:11:05 --> Input Class Initialized
INFO - 2016-09-27 17:11:05 --> Language Class Initialized
INFO - 2016-09-27 17:11:05 --> Loader Class Initialized
INFO - 2016-09-27 17:11:05 --> Helper loaded: url_helper
INFO - 2016-09-27 17:11:05 --> Helper loaded: language_helper
INFO - 2016-09-27 17:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:11:05 --> Controller Class Initialized
INFO - 2016-09-27 17:11:05 --> Database Driver Class Initialized
INFO - 2016-09-27 17:11:05 --> Model Class Initialized
INFO - 2016-09-27 17:11:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:11:05 --> Model Class Initialized
INFO - 2016-09-27 17:11:05 --> Model Class Initialized
INFO - 2016-09-27 17:11:05 --> Helper loaded: form_helper
ERROR - 2016-09-27 17:11:05 --> Severity: error --> Exception: [] operator not supported for strings C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 66
INFO - 2016-09-27 17:11:32 --> Config Class Initialized
INFO - 2016-09-27 17:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:11:32 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:11:32 --> Utf8 Class Initialized
INFO - 2016-09-27 17:11:32 --> URI Class Initialized
INFO - 2016-09-27 17:11:32 --> Router Class Initialized
INFO - 2016-09-27 17:11:32 --> Output Class Initialized
INFO - 2016-09-27 17:11:32 --> Security Class Initialized
DEBUG - 2016-09-27 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:11:32 --> Input Class Initialized
INFO - 2016-09-27 17:11:32 --> Language Class Initialized
INFO - 2016-09-27 17:11:32 --> Loader Class Initialized
INFO - 2016-09-27 17:11:32 --> Helper loaded: url_helper
INFO - 2016-09-27 17:11:32 --> Helper loaded: language_helper
INFO - 2016-09-27 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:11:32 --> Controller Class Initialized
INFO - 2016-09-27 17:11:32 --> Database Driver Class Initialized
INFO - 2016-09-27 17:11:32 --> Model Class Initialized
INFO - 2016-09-27 17:11:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:11:32 --> Model Class Initialized
INFO - 2016-09-27 17:11:32 --> Model Class Initialized
INFO - 2016-09-27 17:11:32 --> Helper loaded: form_helper
INFO - 2016-09-27 17:11:47 --> Config Class Initialized
INFO - 2016-09-27 17:11:47 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:11:47 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:11:47 --> Utf8 Class Initialized
INFO - 2016-09-27 17:11:47 --> URI Class Initialized
INFO - 2016-09-27 17:11:47 --> Router Class Initialized
INFO - 2016-09-27 17:11:47 --> Output Class Initialized
INFO - 2016-09-27 17:11:47 --> Security Class Initialized
DEBUG - 2016-09-27 17:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:11:47 --> Input Class Initialized
INFO - 2016-09-27 17:11:47 --> Language Class Initialized
INFO - 2016-09-27 17:11:47 --> Loader Class Initialized
INFO - 2016-09-27 17:11:47 --> Helper loaded: url_helper
INFO - 2016-09-27 17:11:47 --> Helper loaded: language_helper
INFO - 2016-09-27 17:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:11:47 --> Controller Class Initialized
INFO - 2016-09-27 17:11:47 --> Database Driver Class Initialized
INFO - 2016-09-27 17:11:47 --> Model Class Initialized
INFO - 2016-09-27 17:11:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:11:47 --> Model Class Initialized
INFO - 2016-09-27 17:11:47 --> Model Class Initialized
INFO - 2016-09-27 17:11:47 --> Helper loaded: form_helper
INFO - 2016-09-27 17:15:02 --> Config Class Initialized
INFO - 2016-09-27 17:15:02 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:15:02 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:15:02 --> Utf8 Class Initialized
INFO - 2016-09-27 17:15:02 --> URI Class Initialized
INFO - 2016-09-27 17:15:02 --> Router Class Initialized
INFO - 2016-09-27 17:15:02 --> Output Class Initialized
INFO - 2016-09-27 17:15:02 --> Security Class Initialized
DEBUG - 2016-09-27 17:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:15:02 --> Input Class Initialized
INFO - 2016-09-27 17:15:02 --> Language Class Initialized
INFO - 2016-09-27 17:15:02 --> Loader Class Initialized
INFO - 2016-09-27 17:15:02 --> Helper loaded: url_helper
INFO - 2016-09-27 17:15:02 --> Helper loaded: language_helper
INFO - 2016-09-27 17:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:15:02 --> Controller Class Initialized
INFO - 2016-09-27 17:15:02 --> Database Driver Class Initialized
INFO - 2016-09-27 17:15:02 --> Model Class Initialized
INFO - 2016-09-27 17:15:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:15:02 --> Model Class Initialized
INFO - 2016-09-27 17:15:02 --> Model Class Initialized
INFO - 2016-09-27 17:15:02 --> Helper loaded: form_helper
INFO - 2016-09-27 17:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:15:03 --> Final output sent to browser
DEBUG - 2016-09-27 17:15:03 --> Total execution time: 0.0693
INFO - 2016-09-27 17:15:19 --> Config Class Initialized
INFO - 2016-09-27 17:15:19 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:15:19 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:15:19 --> Utf8 Class Initialized
INFO - 2016-09-27 17:15:19 --> URI Class Initialized
INFO - 2016-09-27 17:15:19 --> Router Class Initialized
INFO - 2016-09-27 17:15:19 --> Output Class Initialized
INFO - 2016-09-27 17:15:19 --> Security Class Initialized
DEBUG - 2016-09-27 17:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:15:19 --> Input Class Initialized
INFO - 2016-09-27 17:15:19 --> Language Class Initialized
INFO - 2016-09-27 17:15:19 --> Loader Class Initialized
INFO - 2016-09-27 17:15:19 --> Helper loaded: url_helper
INFO - 2016-09-27 17:15:19 --> Helper loaded: language_helper
INFO - 2016-09-27 17:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:15:19 --> Controller Class Initialized
INFO - 2016-09-27 17:15:19 --> Database Driver Class Initialized
INFO - 2016-09-27 17:15:19 --> Model Class Initialized
INFO - 2016-09-27 17:15:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:15:19 --> Model Class Initialized
INFO - 2016-09-27 17:15:19 --> Model Class Initialized
INFO - 2016-09-27 17:15:19 --> Helper loaded: form_helper
INFO - 2016-09-27 17:15:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:15:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:15:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:15:19 --> Final output sent to browser
DEBUG - 2016-09-27 17:15:19 --> Total execution time: 0.0675
INFO - 2016-09-27 17:19:17 --> Config Class Initialized
INFO - 2016-09-27 17:19:17 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:19:17 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:19:17 --> Utf8 Class Initialized
INFO - 2016-09-27 17:19:17 --> URI Class Initialized
INFO - 2016-09-27 17:19:17 --> Router Class Initialized
INFO - 2016-09-27 17:19:17 --> Output Class Initialized
INFO - 2016-09-27 17:19:17 --> Security Class Initialized
DEBUG - 2016-09-27 17:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:19:17 --> Input Class Initialized
INFO - 2016-09-27 17:19:17 --> Language Class Initialized
INFO - 2016-09-27 17:19:17 --> Loader Class Initialized
INFO - 2016-09-27 17:19:17 --> Helper loaded: url_helper
INFO - 2016-09-27 17:19:17 --> Helper loaded: language_helper
INFO - 2016-09-27 17:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:19:17 --> Controller Class Initialized
INFO - 2016-09-27 17:19:17 --> Database Driver Class Initialized
INFO - 2016-09-27 17:19:17 --> Model Class Initialized
INFO - 2016-09-27 17:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:19:17 --> Model Class Initialized
INFO - 2016-09-27 17:19:17 --> Model Class Initialized
INFO - 2016-09-27 17:19:17 --> Helper loaded: form_helper
INFO - 2016-09-27 17:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:19:17 --> Final output sent to browser
DEBUG - 2016-09-27 17:19:17 --> Total execution time: 0.0811
INFO - 2016-09-27 17:23:23 --> Config Class Initialized
INFO - 2016-09-27 17:23:23 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:23:23 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:23:23 --> Utf8 Class Initialized
INFO - 2016-09-27 17:23:23 --> URI Class Initialized
INFO - 2016-09-27 17:23:23 --> Router Class Initialized
INFO - 2016-09-27 17:23:23 --> Output Class Initialized
INFO - 2016-09-27 17:23:23 --> Security Class Initialized
DEBUG - 2016-09-27 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:23:23 --> Input Class Initialized
INFO - 2016-09-27 17:23:23 --> Language Class Initialized
INFO - 2016-09-27 17:23:23 --> Loader Class Initialized
INFO - 2016-09-27 17:23:23 --> Helper loaded: url_helper
INFO - 2016-09-27 17:23:23 --> Helper loaded: language_helper
INFO - 2016-09-27 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:23:23 --> Controller Class Initialized
INFO - 2016-09-27 17:23:23 --> Database Driver Class Initialized
INFO - 2016-09-27 17:23:23 --> Model Class Initialized
INFO - 2016-09-27 17:23:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:23:23 --> Model Class Initialized
INFO - 2016-09-27 17:23:23 --> Model Class Initialized
INFO - 2016-09-27 17:23:23 --> Helper loaded: form_helper
INFO - 2016-09-27 17:23:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:23:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:23:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:23:23 --> Final output sent to browser
DEBUG - 2016-09-27 17:23:23 --> Total execution time: 0.0799
INFO - 2016-09-27 17:24:43 --> Config Class Initialized
INFO - 2016-09-27 17:24:43 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:24:43 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:24:43 --> Utf8 Class Initialized
INFO - 2016-09-27 17:24:43 --> URI Class Initialized
INFO - 2016-09-27 17:24:43 --> Router Class Initialized
INFO - 2016-09-27 17:24:43 --> Output Class Initialized
INFO - 2016-09-27 17:24:43 --> Security Class Initialized
DEBUG - 2016-09-27 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:24:43 --> Input Class Initialized
INFO - 2016-09-27 17:24:43 --> Language Class Initialized
INFO - 2016-09-27 17:24:43 --> Loader Class Initialized
INFO - 2016-09-27 17:24:43 --> Helper loaded: url_helper
INFO - 2016-09-27 17:24:43 --> Helper loaded: language_helper
INFO - 2016-09-27 17:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:24:43 --> Controller Class Initialized
INFO - 2016-09-27 17:24:43 --> Database Driver Class Initialized
INFO - 2016-09-27 17:24:43 --> Model Class Initialized
INFO - 2016-09-27 17:24:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:24:43 --> Model Class Initialized
INFO - 2016-09-27 17:24:43 --> Model Class Initialized
INFO - 2016-09-27 17:24:43 --> Helper loaded: form_helper
INFO - 2016-09-27 17:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-09-27 17:24:43 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\savsoftquiz\application\models\Norma_ist_model.php 49
INFO - 2016-09-27 17:28:59 --> Config Class Initialized
INFO - 2016-09-27 17:28:59 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:28:59 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:28:59 --> Utf8 Class Initialized
INFO - 2016-09-27 17:28:59 --> URI Class Initialized
INFO - 2016-09-27 17:28:59 --> Router Class Initialized
INFO - 2016-09-27 17:28:59 --> Output Class Initialized
INFO - 2016-09-27 17:28:59 --> Security Class Initialized
DEBUG - 2016-09-27 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:28:59 --> Input Class Initialized
INFO - 2016-09-27 17:28:59 --> Language Class Initialized
INFO - 2016-09-27 17:28:59 --> Loader Class Initialized
INFO - 2016-09-27 17:28:59 --> Helper loaded: url_helper
INFO - 2016-09-27 17:28:59 --> Helper loaded: language_helper
INFO - 2016-09-27 17:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:28:59 --> Controller Class Initialized
INFO - 2016-09-27 17:28:59 --> Database Driver Class Initialized
INFO - 2016-09-27 17:28:59 --> Model Class Initialized
INFO - 2016-09-27 17:28:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:28:59 --> Model Class Initialized
ERROR - 2016-09-27 17:28:59 --> Severity: error --> Exception: syntax error, unexpected 'break' (T_BREAK) C:\wamp64\www\savsoftquiz\application\models\Norma_ist_model.php 60
INFO - 2016-09-27 17:29:21 --> Config Class Initialized
INFO - 2016-09-27 17:29:21 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:29:21 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:29:21 --> Utf8 Class Initialized
INFO - 2016-09-27 17:29:21 --> URI Class Initialized
INFO - 2016-09-27 17:29:21 --> Router Class Initialized
INFO - 2016-09-27 17:29:21 --> Output Class Initialized
INFO - 2016-09-27 17:29:21 --> Security Class Initialized
DEBUG - 2016-09-27 17:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:29:21 --> Input Class Initialized
INFO - 2016-09-27 17:29:21 --> Language Class Initialized
INFO - 2016-09-27 17:29:21 --> Loader Class Initialized
INFO - 2016-09-27 17:29:21 --> Helper loaded: url_helper
INFO - 2016-09-27 17:29:21 --> Helper loaded: language_helper
INFO - 2016-09-27 17:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:29:21 --> Controller Class Initialized
INFO - 2016-09-27 17:29:21 --> Database Driver Class Initialized
INFO - 2016-09-27 17:29:21 --> Model Class Initialized
INFO - 2016-09-27 17:29:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:29:21 --> Model Class Initialized
INFO - 2016-09-27 17:29:21 --> Model Class Initialized
INFO - 2016-09-27 17:29:21 --> Helper loaded: form_helper
INFO - 2016-09-27 17:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:29:21 --> Final output sent to browser
DEBUG - 2016-09-27 17:29:21 --> Total execution time: 0.0883
INFO - 2016-09-27 17:30:36 --> Config Class Initialized
INFO - 2016-09-27 17:30:36 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:30:36 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:30:36 --> Utf8 Class Initialized
INFO - 2016-09-27 17:30:36 --> URI Class Initialized
INFO - 2016-09-27 17:30:36 --> Router Class Initialized
INFO - 2016-09-27 17:30:36 --> Output Class Initialized
INFO - 2016-09-27 17:30:36 --> Security Class Initialized
DEBUG - 2016-09-27 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:30:36 --> Input Class Initialized
INFO - 2016-09-27 17:30:36 --> Language Class Initialized
INFO - 2016-09-27 17:30:36 --> Loader Class Initialized
INFO - 2016-09-27 17:30:36 --> Helper loaded: url_helper
INFO - 2016-09-27 17:30:36 --> Helper loaded: language_helper
INFO - 2016-09-27 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:30:36 --> Controller Class Initialized
INFO - 2016-09-27 17:30:36 --> Database Driver Class Initialized
INFO - 2016-09-27 17:30:36 --> Model Class Initialized
INFO - 2016-09-27 17:30:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:30:36 --> Model Class Initialized
INFO - 2016-09-27 17:30:36 --> Model Class Initialized
INFO - 2016-09-27 17:30:36 --> Helper loaded: form_helper
INFO - 2016-09-27 17:30:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:30:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:30:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:30:36 --> Final output sent to browser
DEBUG - 2016-09-27 17:30:36 --> Total execution time: 0.0779
INFO - 2016-09-27 17:31:07 --> Config Class Initialized
INFO - 2016-09-27 17:31:07 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:31:07 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:31:07 --> Utf8 Class Initialized
INFO - 2016-09-27 17:31:07 --> URI Class Initialized
INFO - 2016-09-27 17:31:07 --> Router Class Initialized
INFO - 2016-09-27 17:31:07 --> Output Class Initialized
INFO - 2016-09-27 17:31:07 --> Security Class Initialized
DEBUG - 2016-09-27 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:31:07 --> Input Class Initialized
INFO - 2016-09-27 17:31:07 --> Language Class Initialized
INFO - 2016-09-27 17:31:07 --> Loader Class Initialized
INFO - 2016-09-27 17:31:07 --> Helper loaded: url_helper
INFO - 2016-09-27 17:31:07 --> Helper loaded: language_helper
INFO - 2016-09-27 17:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:31:07 --> Controller Class Initialized
INFO - 2016-09-27 17:31:07 --> Database Driver Class Initialized
INFO - 2016-09-27 17:31:07 --> Model Class Initialized
INFO - 2016-09-27 17:31:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:31:07 --> Model Class Initialized
INFO - 2016-09-27 17:31:07 --> Model Class Initialized
INFO - 2016-09-27 17:31:07 --> Helper loaded: form_helper
INFO - 2016-09-27 17:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:31:07 --> Final output sent to browser
DEBUG - 2016-09-27 17:31:07 --> Total execution time: 0.0886
INFO - 2016-09-27 17:31:52 --> Config Class Initialized
INFO - 2016-09-27 17:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:31:52 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:31:52 --> Utf8 Class Initialized
INFO - 2016-09-27 17:31:52 --> URI Class Initialized
INFO - 2016-09-27 17:31:52 --> Router Class Initialized
INFO - 2016-09-27 17:31:52 --> Output Class Initialized
INFO - 2016-09-27 17:31:52 --> Security Class Initialized
DEBUG - 2016-09-27 17:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:31:52 --> Input Class Initialized
INFO - 2016-09-27 17:31:52 --> Language Class Initialized
INFO - 2016-09-27 17:31:52 --> Loader Class Initialized
INFO - 2016-09-27 17:31:52 --> Helper loaded: url_helper
INFO - 2016-09-27 17:31:52 --> Helper loaded: language_helper
INFO - 2016-09-27 17:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:31:52 --> Controller Class Initialized
INFO - 2016-09-27 17:31:52 --> Database Driver Class Initialized
INFO - 2016-09-27 17:31:52 --> Model Class Initialized
INFO - 2016-09-27 17:31:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:31:52 --> Model Class Initialized
INFO - 2016-09-27 17:31:52 --> Model Class Initialized
INFO - 2016-09-27 17:31:52 --> Helper loaded: form_helper
INFO - 2016-09-27 17:31:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:31:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:31:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:31:52 --> Final output sent to browser
DEBUG - 2016-09-27 17:31:52 --> Total execution time: 0.0895
INFO - 2016-09-27 17:39:31 --> Config Class Initialized
INFO - 2016-09-27 17:39:31 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:39:31 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:39:31 --> Utf8 Class Initialized
INFO - 2016-09-27 17:39:31 --> URI Class Initialized
INFO - 2016-09-27 17:39:31 --> Router Class Initialized
INFO - 2016-09-27 17:39:31 --> Output Class Initialized
INFO - 2016-09-27 17:39:31 --> Security Class Initialized
DEBUG - 2016-09-27 17:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:39:31 --> Input Class Initialized
INFO - 2016-09-27 17:39:31 --> Language Class Initialized
INFO - 2016-09-27 17:39:31 --> Loader Class Initialized
INFO - 2016-09-27 17:39:31 --> Helper loaded: url_helper
INFO - 2016-09-27 17:39:31 --> Helper loaded: language_helper
INFO - 2016-09-27 17:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:39:31 --> Controller Class Initialized
INFO - 2016-09-27 17:39:31 --> Database Driver Class Initialized
INFO - 2016-09-27 17:39:31 --> Model Class Initialized
INFO - 2016-09-27 17:39:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:39:31 --> Model Class Initialized
INFO - 2016-09-27 17:39:31 --> Model Class Initialized
INFO - 2016-09-27 17:39:31 --> Helper loaded: form_helper
INFO - 2016-09-27 17:39:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:39:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:39:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:39:31 --> Final output sent to browser
DEBUG - 2016-09-27 17:39:31 --> Total execution time: 0.0737
INFO - 2016-09-27 17:40:36 --> Config Class Initialized
INFO - 2016-09-27 17:40:36 --> Hooks Class Initialized
DEBUG - 2016-09-27 17:40:36 --> UTF-8 Support Enabled
INFO - 2016-09-27 17:40:36 --> Utf8 Class Initialized
INFO - 2016-09-27 17:40:36 --> URI Class Initialized
INFO - 2016-09-27 17:40:36 --> Router Class Initialized
INFO - 2016-09-27 17:40:36 --> Output Class Initialized
INFO - 2016-09-27 17:40:36 --> Security Class Initialized
DEBUG - 2016-09-27 17:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-27 17:40:36 --> Input Class Initialized
INFO - 2016-09-27 17:40:36 --> Language Class Initialized
INFO - 2016-09-27 17:40:36 --> Loader Class Initialized
INFO - 2016-09-27 17:40:36 --> Helper loaded: url_helper
INFO - 2016-09-27 17:40:36 --> Helper loaded: language_helper
INFO - 2016-09-27 17:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-27 17:40:36 --> Controller Class Initialized
INFO - 2016-09-27 17:40:36 --> Database Driver Class Initialized
INFO - 2016-09-27 17:40:36 --> Model Class Initialized
INFO - 2016-09-27 17:40:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-09-27 17:40:36 --> Model Class Initialized
INFO - 2016-09-27 17:40:36 --> Model Class Initialized
INFO - 2016-09-27 17:40:36 --> Helper loaded: form_helper
INFO - 2016-09-27 17:40:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-09-27 17:40:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-09-27 17:40:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-09-27 17:40:36 --> Final output sent to browser
DEBUG - 2016-09-27 17:40:36 --> Total execution time: 0.0835
