<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-03 08:05:45 --> Config Class Initialized
INFO - 2016-10-03 08:05:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:05:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:05:45 --> Utf8 Class Initialized
INFO - 2016-10-03 08:05:45 --> URI Class Initialized
INFO - 2016-10-03 08:05:45 --> Router Class Initialized
INFO - 2016-10-03 08:05:45 --> Output Class Initialized
INFO - 2016-10-03 08:05:45 --> Security Class Initialized
DEBUG - 2016-10-03 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:05:45 --> Input Class Initialized
INFO - 2016-10-03 08:05:45 --> Language Class Initialized
INFO - 2016-10-03 08:05:45 --> Loader Class Initialized
INFO - 2016-10-03 08:05:45 --> Helper loaded: url_helper
INFO - 2016-10-03 08:05:45 --> Helper loaded: language_helper
INFO - 2016-10-03 08:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:05:45 --> Controller Class Initialized
INFO - 2016-10-03 08:05:45 --> Database Driver Class Initialized
INFO - 2016-10-03 08:05:45 --> Model Class Initialized
INFO - 2016-10-03 08:05:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:05:45 --> Config Class Initialized
INFO - 2016-10-03 08:05:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:05:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:05:45 --> Utf8 Class Initialized
INFO - 2016-10-03 08:05:45 --> URI Class Initialized
INFO - 2016-10-03 08:05:45 --> Router Class Initialized
INFO - 2016-10-03 08:05:45 --> Output Class Initialized
INFO - 2016-10-03 08:05:45 --> Security Class Initialized
DEBUG - 2016-10-03 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:05:45 --> Input Class Initialized
INFO - 2016-10-03 08:05:45 --> Language Class Initialized
INFO - 2016-10-03 08:05:45 --> Loader Class Initialized
INFO - 2016-10-03 08:05:45 --> Helper loaded: url_helper
INFO - 2016-10-03 08:05:45 --> Helper loaded: language_helper
INFO - 2016-10-03 08:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:05:45 --> Controller Class Initialized
INFO - 2016-10-03 08:05:45 --> Database Driver Class Initialized
INFO - 2016-10-03 08:05:45 --> Model Class Initialized
INFO - 2016-10-03 08:05:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:05:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-03 08:05:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-03 08:05:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-03 08:05:45 --> Final output sent to browser
DEBUG - 2016-10-03 08:05:45 --> Total execution time: 0.0565
INFO - 2016-10-03 08:52:20 --> Config Class Initialized
INFO - 2016-10-03 08:52:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:20 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:20 --> URI Class Initialized
INFO - 2016-10-03 08:52:20 --> Router Class Initialized
INFO - 2016-10-03 08:52:20 --> Output Class Initialized
INFO - 2016-10-03 08:52:20 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:20 --> Input Class Initialized
INFO - 2016-10-03 08:52:20 --> Language Class Initialized
INFO - 2016-10-03 08:52:20 --> Loader Class Initialized
INFO - 2016-10-03 08:52:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:20 --> Controller Class Initialized
INFO - 2016-10-03 08:52:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:20 --> Model Class Initialized
INFO - 2016-10-03 08:52:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:21 --> Config Class Initialized
INFO - 2016-10-03 08:52:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:21 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:21 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:21 --> URI Class Initialized
INFO - 2016-10-03 08:52:21 --> Router Class Initialized
INFO - 2016-10-03 08:52:21 --> Output Class Initialized
INFO - 2016-10-03 08:52:21 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:21 --> Input Class Initialized
INFO - 2016-10-03 08:52:21 --> Language Class Initialized
INFO - 2016-10-03 08:52:21 --> Loader Class Initialized
INFO - 2016-10-03 08:52:21 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:21 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:21 --> Controller Class Initialized
INFO - 2016-10-03 08:52:21 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:21 --> Model Class Initialized
INFO - 2016-10-03 08:52:21 --> Model Class Initialized
INFO - 2016-10-03 08:52:21 --> Model Class Initialized
INFO - 2016-10-03 08:52:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:52:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-10-03 08:52:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:52:21 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:21 --> Total execution time: 0.0737
INFO - 2016-10-03 08:52:25 --> Config Class Initialized
INFO - 2016-10-03 08:52:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:25 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:25 --> URI Class Initialized
INFO - 2016-10-03 08:52:25 --> Router Class Initialized
INFO - 2016-10-03 08:52:25 --> Output Class Initialized
INFO - 2016-10-03 08:52:25 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:25 --> Input Class Initialized
INFO - 2016-10-03 08:52:25 --> Language Class Initialized
INFO - 2016-10-03 08:52:25 --> Loader Class Initialized
INFO - 2016-10-03 08:52:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:25 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:25 --> Controller Class Initialized
INFO - 2016-10-03 08:52:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:25 --> Model Class Initialized
INFO - 2016-10-03 08:52:25 --> Model Class Initialized
INFO - 2016-10-03 08:52:25 --> Model Class Initialized
INFO - 2016-10-03 08:52:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:52:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-10-03 08:52:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:52:25 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:25 --> Total execution time: 0.0687
INFO - 2016-10-03 08:52:27 --> Config Class Initialized
INFO - 2016-10-03 08:52:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:27 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:27 --> URI Class Initialized
INFO - 2016-10-03 08:52:27 --> Router Class Initialized
INFO - 2016-10-03 08:52:27 --> Output Class Initialized
INFO - 2016-10-03 08:52:27 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:27 --> Input Class Initialized
INFO - 2016-10-03 08:52:27 --> Language Class Initialized
INFO - 2016-10-03 08:52:27 --> Loader Class Initialized
INFO - 2016-10-03 08:52:27 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:27 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:27 --> Controller Class Initialized
INFO - 2016-10-03 08:52:27 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:27 --> Config Class Initialized
INFO - 2016-10-03 08:52:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:27 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:27 --> URI Class Initialized
INFO - 2016-10-03 08:52:27 --> Router Class Initialized
INFO - 2016-10-03 08:52:27 --> Output Class Initialized
INFO - 2016-10-03 08:52:27 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:27 --> Input Class Initialized
INFO - 2016-10-03 08:52:27 --> Language Class Initialized
INFO - 2016-10-03 08:52:27 --> Loader Class Initialized
INFO - 2016-10-03 08:52:27 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:27 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:27 --> Controller Class Initialized
INFO - 2016-10-03 08:52:27 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:52:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-10-03 08:52:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:52:27 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:27 --> Total execution time: 0.0730
INFO - 2016-10-03 08:52:27 --> Config Class Initialized
INFO - 2016-10-03 08:52:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:27 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:27 --> URI Class Initialized
INFO - 2016-10-03 08:52:27 --> Config Class Initialized
INFO - 2016-10-03 08:52:27 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:27 --> Router Class Initialized
INFO - 2016-10-03 08:52:27 --> Output Class Initialized
INFO - 2016-10-03 08:52:27 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:27 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:27 --> Input Class Initialized
INFO - 2016-10-03 08:52:27 --> URI Class Initialized
INFO - 2016-10-03 08:52:27 --> Language Class Initialized
INFO - 2016-10-03 08:52:27 --> Router Class Initialized
INFO - 2016-10-03 08:52:27 --> Loader Class Initialized
INFO - 2016-10-03 08:52:27 --> Output Class Initialized
INFO - 2016-10-03 08:52:27 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:27 --> Security Class Initialized
INFO - 2016-10-03 08:52:27 --> Helper loaded: language_helper
DEBUG - 2016-10-03 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:27 --> Input Class Initialized
INFO - 2016-10-03 08:52:27 --> Language Class Initialized
INFO - 2016-10-03 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:27 --> Controller Class Initialized
INFO - 2016-10-03 08:52:27 --> Loader Class Initialized
INFO - 2016-10-03 08:52:27 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:27 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:27 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:27 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:27 --> Total execution time: 0.0822
INFO - 2016-10-03 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:27 --> Controller Class Initialized
INFO - 2016-10-03 08:52:27 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Model Class Initialized
INFO - 2016-10-03 08:52:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:52:27 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:52:27 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:27 --> Total execution time: 0.1146
INFO - 2016-10-03 08:52:31 --> Config Class Initialized
INFO - 2016-10-03 08:52:31 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:31 --> Config Class Initialized
INFO - 2016-10-03 08:52:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:31 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:31 --> URI Class Initialized
DEBUG - 2016-10-03 08:52:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:31 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:31 --> URI Class Initialized
INFO - 2016-10-03 08:52:31 --> Router Class Initialized
INFO - 2016-10-03 08:52:31 --> Router Class Initialized
INFO - 2016-10-03 08:52:31 --> Output Class Initialized
INFO - 2016-10-03 08:52:31 --> Security Class Initialized
INFO - 2016-10-03 08:52:31 --> Output Class Initialized
DEBUG - 2016-10-03 08:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:31 --> Input Class Initialized
INFO - 2016-10-03 08:52:31 --> Security Class Initialized
INFO - 2016-10-03 08:52:31 --> Language Class Initialized
DEBUG - 2016-10-03 08:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:31 --> Input Class Initialized
INFO - 2016-10-03 08:52:31 --> Language Class Initialized
INFO - 2016-10-03 08:52:31 --> Loader Class Initialized
INFO - 2016-10-03 08:52:31 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:31 --> Loader Class Initialized
INFO - 2016-10-03 08:52:31 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:31 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:31 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:31 --> Controller Class Initialized
INFO - 2016-10-03 08:52:31 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:31 --> Model Class Initialized
INFO - 2016-10-03 08:52:31 --> Model Class Initialized
INFO - 2016-10-03 08:52:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:31 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:31 --> Total execution time: 0.0669
INFO - 2016-10-03 08:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:31 --> Controller Class Initialized
INFO - 2016-10-03 08:52:31 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:31 --> Model Class Initialized
INFO - 2016-10-03 08:52:31 --> Model Class Initialized
INFO - 2016-10-03 08:52:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:31 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:31 --> Total execution time: 0.1003
INFO - 2016-10-03 08:52:33 --> Config Class Initialized
INFO - 2016-10-03 08:52:33 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:33 --> Config Class Initialized
INFO - 2016-10-03 08:52:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:33 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:52:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:33 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:33 --> URI Class Initialized
INFO - 2016-10-03 08:52:33 --> URI Class Initialized
INFO - 2016-10-03 08:52:33 --> Router Class Initialized
INFO - 2016-10-03 08:52:33 --> Router Class Initialized
INFO - 2016-10-03 08:52:33 --> Output Class Initialized
INFO - 2016-10-03 08:52:33 --> Output Class Initialized
INFO - 2016-10-03 08:52:33 --> Security Class Initialized
INFO - 2016-10-03 08:52:33 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:33 --> Input Class Initialized
DEBUG - 2016-10-03 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:33 --> Input Class Initialized
INFO - 2016-10-03 08:52:33 --> Language Class Initialized
INFO - 2016-10-03 08:52:33 --> Language Class Initialized
INFO - 2016-10-03 08:52:33 --> Loader Class Initialized
INFO - 2016-10-03 08:52:33 --> Loader Class Initialized
INFO - 2016-10-03 08:52:33 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:33 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:33 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:33 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:33 --> Controller Class Initialized
INFO - 2016-10-03 08:52:33 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:33 --> Model Class Initialized
INFO - 2016-10-03 08:52:33 --> Model Class Initialized
INFO - 2016-10-03 08:52:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:33 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:33 --> Total execution time: 0.0766
INFO - 2016-10-03 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:33 --> Controller Class Initialized
INFO - 2016-10-03 08:52:33 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:33 --> Model Class Initialized
INFO - 2016-10-03 08:52:33 --> Model Class Initialized
INFO - 2016-10-03 08:52:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:33 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:33 --> Total execution time: 0.1023
INFO - 2016-10-03 08:52:35 --> Config Class Initialized
INFO - 2016-10-03 08:52:35 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:35 --> Config Class Initialized
INFO - 2016-10-03 08:52:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:35 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:35 --> URI Class Initialized
INFO - 2016-10-03 08:52:35 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:35 --> URI Class Initialized
INFO - 2016-10-03 08:52:35 --> Router Class Initialized
INFO - 2016-10-03 08:52:35 --> Router Class Initialized
INFO - 2016-10-03 08:52:35 --> Output Class Initialized
INFO - 2016-10-03 08:52:35 --> Output Class Initialized
INFO - 2016-10-03 08:52:35 --> Security Class Initialized
INFO - 2016-10-03 08:52:35 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:35 --> Input Class Initialized
INFO - 2016-10-03 08:52:35 --> Language Class Initialized
DEBUG - 2016-10-03 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:35 --> Input Class Initialized
INFO - 2016-10-03 08:52:35 --> Language Class Initialized
INFO - 2016-10-03 08:52:35 --> Loader Class Initialized
INFO - 2016-10-03 08:52:35 --> Loader Class Initialized
INFO - 2016-10-03 08:52:35 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:35 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:35 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:35 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:35 --> Controller Class Initialized
INFO - 2016-10-03 08:52:35 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:35 --> Model Class Initialized
INFO - 2016-10-03 08:52:35 --> Model Class Initialized
INFO - 2016-10-03 08:52:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:35 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:35 --> Total execution time: 0.0773
INFO - 2016-10-03 08:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:35 --> Controller Class Initialized
INFO - 2016-10-03 08:52:35 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:35 --> Model Class Initialized
INFO - 2016-10-03 08:52:35 --> Model Class Initialized
INFO - 2016-10-03 08:52:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:35 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:35 --> Total execution time: 0.0974
INFO - 2016-10-03 08:52:39 --> Config Class Initialized
INFO - 2016-10-03 08:52:39 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:39 --> Config Class Initialized
INFO - 2016-10-03 08:52:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:52:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:39 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:39 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:39 --> URI Class Initialized
INFO - 2016-10-03 08:52:39 --> URI Class Initialized
INFO - 2016-10-03 08:52:39 --> Router Class Initialized
INFO - 2016-10-03 08:52:39 --> Router Class Initialized
INFO - 2016-10-03 08:52:39 --> Output Class Initialized
INFO - 2016-10-03 08:52:39 --> Output Class Initialized
INFO - 2016-10-03 08:52:39 --> Security Class Initialized
INFO - 2016-10-03 08:52:39 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-03 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:39 --> Input Class Initialized
INFO - 2016-10-03 08:52:39 --> Input Class Initialized
INFO - 2016-10-03 08:52:39 --> Language Class Initialized
INFO - 2016-10-03 08:52:39 --> Language Class Initialized
INFO - 2016-10-03 08:52:39 --> Loader Class Initialized
INFO - 2016-10-03 08:52:39 --> Loader Class Initialized
INFO - 2016-10-03 08:52:39 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:39 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:39 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:39 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:39 --> Controller Class Initialized
INFO - 2016-10-03 08:52:39 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:39 --> Model Class Initialized
INFO - 2016-10-03 08:52:39 --> Model Class Initialized
INFO - 2016-10-03 08:52:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:39 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:39 --> Total execution time: 0.0876
INFO - 2016-10-03 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:39 --> Controller Class Initialized
INFO - 2016-10-03 08:52:39 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:39 --> Model Class Initialized
INFO - 2016-10-03 08:52:39 --> Model Class Initialized
INFO - 2016-10-03 08:52:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:39 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:39 --> Total execution time: 0.1168
INFO - 2016-10-03 08:52:42 --> Config Class Initialized
INFO - 2016-10-03 08:52:42 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:42 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:42 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:42 --> URI Class Initialized
INFO - 2016-10-03 08:52:42 --> Router Class Initialized
INFO - 2016-10-03 08:52:42 --> Output Class Initialized
INFO - 2016-10-03 08:52:42 --> Security Class Initialized
DEBUG - 2016-10-03 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:42 --> Input Class Initialized
INFO - 2016-10-03 08:52:42 --> Language Class Initialized
INFO - 2016-10-03 08:52:42 --> Loader Class Initialized
INFO - 2016-10-03 08:52:42 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:42 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:42 --> Controller Class Initialized
INFO - 2016-10-03 08:52:42 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:42 --> Model Class Initialized
INFO - 2016-10-03 08:52:42 --> Model Class Initialized
INFO - 2016-10-03 08:52:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:42 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:42 --> Total execution time: 0.0921
INFO - 2016-10-03 08:52:44 --> Config Class Initialized
INFO - 2016-10-03 08:52:44 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:44 --> Config Class Initialized
INFO - 2016-10-03 08:52:44 --> Config Class Initialized
INFO - 2016-10-03 08:52:44 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:44 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:52:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:44 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:44 --> URI Class Initialized
INFO - 2016-10-03 08:52:44 --> Router Class Initialized
INFO - 2016-10-03 08:52:44 --> URI Class Initialized
DEBUG - 2016-10-03 08:52:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:44 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:44 --> Config Class Initialized
INFO - 2016-10-03 08:52:44 --> Hooks Class Initialized
INFO - 2016-10-03 08:52:44 --> Router Class Initialized
INFO - 2016-10-03 08:52:44 --> Output Class Initialized
DEBUG - 2016-10-03 08:52:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:44 --> Security Class Initialized
INFO - 2016-10-03 08:52:44 --> Utf8 Class Initialized
INFO - 2016-10-03 08:52:44 --> Output Class Initialized
DEBUG - 2016-10-03 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:44 --> URI Class Initialized
INFO - 2016-10-03 08:52:44 --> URI Class Initialized
INFO - 2016-10-03 08:52:44 --> Input Class Initialized
INFO - 2016-10-03 08:52:44 --> Router Class Initialized
INFO - 2016-10-03 08:52:44 --> Language Class Initialized
INFO - 2016-10-03 08:52:44 --> Router Class Initialized
INFO - 2016-10-03 08:52:44 --> Output Class Initialized
INFO - 2016-10-03 08:52:44 --> Output Class Initialized
INFO - 2016-10-03 08:52:44 --> Security Class Initialized
INFO - 2016-10-03 08:52:44 --> Loader Class Initialized
INFO - 2016-10-03 08:52:44 --> Config Class Initialized
INFO - 2016-10-03 08:52:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:44 --> Security Class Initialized
INFO - 2016-10-03 08:52:44 --> Input Class Initialized
INFO - 2016-10-03 08:52:44 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:44 --> Language Class Initialized
INFO - 2016-10-03 08:52:44 --> Helper loaded: language_helper
DEBUG - 2016-10-03 08:52:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:52:44 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:44 --> Input Class Initialized
INFO - 2016-10-03 08:52:44 --> URI Class Initialized
INFO - 2016-10-03 08:52:44 --> Security Class Initialized
INFO - 2016-10-03 08:52:44 --> Loader Class Initialized
INFO - 2016-10-03 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:44 --> Controller Class Initialized
DEBUG - 2016-10-03 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:44 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:44 --> Input Class Initialized
INFO - 2016-10-03 08:52:44 --> Language Class Initialized
INFO - 2016-10-03 08:52:44 --> Language Class Initialized
INFO - 2016-10-03 08:52:44 --> Router Class Initialized
INFO - 2016-10-03 08:52:44 --> Loader Class Initialized
INFO - 2016-10-03 08:52:44 --> Output Class Initialized
INFO - 2016-10-03 08:52:44 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:44 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:44 --> Security Class Initialized
INFO - 2016-10-03 08:52:44 --> Loader Class Initialized
INFO - 2016-10-03 08:52:44 --> Helper loaded: language_helper
DEBUG - 2016-10-03 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:52:44 --> Input Class Initialized
INFO - 2016-10-03 08:52:44 --> Language Class Initialized
INFO - 2016-10-03 08:52:44 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:44 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:44 --> Loader Class Initialized
INFO - 2016-10-03 08:52:44 --> Helper loaded: url_helper
INFO - 2016-10-03 08:52:44 --> Helper loaded: language_helper
INFO - 2016-10-03 08:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:44 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:44 --> Total execution time: 0.1353
INFO - 2016-10-03 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:44 --> Controller Class Initialized
INFO - 2016-10-03 08:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:44 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:44 --> Total execution time: 0.2009
INFO - 2016-10-03 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:44 --> Controller Class Initialized
INFO - 2016-10-03 08:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:44 --> Final output sent to browser
DEBUG - 2016-10-03 08:52:44 --> Total execution time: 0.2458
INFO - 2016-10-03 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:44 --> Controller Class Initialized
INFO - 2016-10-03 08:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:52:44 --> Controller Class Initialized
INFO - 2016-10-03 08:52:44 --> Database Driver Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:44 --> Model Class Initialized
INFO - 2016-10-03 08:52:45 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:52:45 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 301
ERROR - 2016-10-03 08:52:45 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `savsoft_result` SET `total_time` = 0, `end_time` = 1475464965, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2016-10-03 08:52:45 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-10-03 08:53:45 --> Config Class Initialized
INFO - 2016-10-03 08:53:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:53:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:53:45 --> Utf8 Class Initialized
INFO - 2016-10-03 08:53:45 --> URI Class Initialized
DEBUG - 2016-10-03 08:53:45 --> No URI present. Default controller set.
INFO - 2016-10-03 08:53:45 --> Router Class Initialized
INFO - 2016-10-03 08:53:45 --> Output Class Initialized
INFO - 2016-10-03 08:53:45 --> Security Class Initialized
DEBUG - 2016-10-03 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:53:45 --> Input Class Initialized
INFO - 2016-10-03 08:53:45 --> Language Class Initialized
INFO - 2016-10-03 08:53:45 --> Loader Class Initialized
INFO - 2016-10-03 08:53:45 --> Helper loaded: url_helper
INFO - 2016-10-03 08:53:45 --> Helper loaded: language_helper
INFO - 2016-10-03 08:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:53:45 --> Controller Class Initialized
INFO - 2016-10-03 08:53:45 --> Database Driver Class Initialized
INFO - 2016-10-03 08:53:45 --> Model Class Initialized
INFO - 2016-10-03 08:53:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:53:45 --> Config Class Initialized
INFO - 2016-10-03 08:53:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:53:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:53:45 --> Utf8 Class Initialized
INFO - 2016-10-03 08:53:45 --> URI Class Initialized
INFO - 2016-10-03 08:53:45 --> Router Class Initialized
INFO - 2016-10-03 08:53:45 --> Output Class Initialized
INFO - 2016-10-03 08:53:45 --> Security Class Initialized
DEBUG - 2016-10-03 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:53:45 --> Input Class Initialized
INFO - 2016-10-03 08:53:45 --> Language Class Initialized
INFO - 2016-10-03 08:53:45 --> Loader Class Initialized
INFO - 2016-10-03 08:53:45 --> Helper loaded: url_helper
INFO - 2016-10-03 08:53:45 --> Helper loaded: language_helper
INFO - 2016-10-03 08:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:53:45 --> Controller Class Initialized
INFO - 2016-10-03 08:53:45 --> Database Driver Class Initialized
INFO - 2016-10-03 08:53:45 --> Model Class Initialized
INFO - 2016-10-03 08:53:45 --> Model Class Initialized
INFO - 2016-10-03 08:53:45 --> Model Class Initialized
INFO - 2016-10-03 08:53:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:53:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:53:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-10-03 08:53:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:53:45 --> Final output sent to browser
DEBUG - 2016-10-03 08:53:45 --> Total execution time: 0.0629
INFO - 2016-10-03 08:54:11 --> Config Class Initialized
INFO - 2016-10-03 08:54:11 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:11 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:11 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:11 --> URI Class Initialized
INFO - 2016-10-03 08:54:11 --> Router Class Initialized
INFO - 2016-10-03 08:54:11 --> Output Class Initialized
INFO - 2016-10-03 08:54:11 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:11 --> Input Class Initialized
INFO - 2016-10-03 08:54:11 --> Language Class Initialized
INFO - 2016-10-03 08:54:11 --> Loader Class Initialized
INFO - 2016-10-03 08:54:11 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:11 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:11 --> Controller Class Initialized
INFO - 2016-10-03 08:54:11 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:11 --> Model Class Initialized
INFO - 2016-10-03 08:54:11 --> Model Class Initialized
INFO - 2016-10-03 08:54:11 --> Model Class Initialized
INFO - 2016-10-03 08:54:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-10-03 08:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:54:11 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:11 --> Total execution time: 0.0641
INFO - 2016-10-03 08:54:14 --> Config Class Initialized
INFO - 2016-10-03 08:54:14 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:14 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:14 --> URI Class Initialized
INFO - 2016-10-03 08:54:14 --> Router Class Initialized
INFO - 2016-10-03 08:54:14 --> Output Class Initialized
INFO - 2016-10-03 08:54:14 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:14 --> Input Class Initialized
INFO - 2016-10-03 08:54:14 --> Language Class Initialized
INFO - 2016-10-03 08:54:14 --> Loader Class Initialized
INFO - 2016-10-03 08:54:14 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:14 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:14 --> Controller Class Initialized
INFO - 2016-10-03 08:54:14 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:14 --> Config Class Initialized
INFO - 2016-10-03 08:54:14 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:14 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:14 --> URI Class Initialized
INFO - 2016-10-03 08:54:14 --> Router Class Initialized
INFO - 2016-10-03 08:54:14 --> Output Class Initialized
INFO - 2016-10-03 08:54:14 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:14 --> Input Class Initialized
INFO - 2016-10-03 08:54:14 --> Language Class Initialized
INFO - 2016-10-03 08:54:14 --> Loader Class Initialized
INFO - 2016-10-03 08:54:14 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:14 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:14 --> Controller Class Initialized
INFO - 2016-10-03 08:54:14 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-10-03 08:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:54:14 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:14 --> Total execution time: 0.0713
INFO - 2016-10-03 08:54:14 --> Config Class Initialized
INFO - 2016-10-03 08:54:14 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:14 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:14 --> URI Class Initialized
INFO - 2016-10-03 08:54:14 --> Router Class Initialized
INFO - 2016-10-03 08:54:14 --> Output Class Initialized
INFO - 2016-10-03 08:54:14 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:14 --> Input Class Initialized
INFO - 2016-10-03 08:54:14 --> Config Class Initialized
INFO - 2016-10-03 08:54:14 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:14 --> Language Class Initialized
DEBUG - 2016-10-03 08:54:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:14 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:14 --> Loader Class Initialized
INFO - 2016-10-03 08:54:14 --> URI Class Initialized
INFO - 2016-10-03 08:54:14 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:14 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:14 --> Router Class Initialized
INFO - 2016-10-03 08:54:14 --> Output Class Initialized
INFO - 2016-10-03 08:54:14 --> Security Class Initialized
INFO - 2016-10-03 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:14 --> Controller Class Initialized
DEBUG - 2016-10-03 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:14 --> Input Class Initialized
INFO - 2016-10-03 08:54:14 --> Language Class Initialized
INFO - 2016-10-03 08:54:14 --> Loader Class Initialized
INFO - 2016-10-03 08:54:14 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:14 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:14 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:14 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:14 --> Total execution time: 0.0811
INFO - 2016-10-03 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:14 --> Controller Class Initialized
INFO - 2016-10-03 08:54:14 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Model Class Initialized
INFO - 2016-10-03 08:54:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:54:14 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:54:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:54:14 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:14 --> Total execution time: 0.1057
INFO - 2016-10-03 08:54:18 --> Config Class Initialized
INFO - 2016-10-03 08:54:18 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:18 --> Config Class Initialized
INFO - 2016-10-03 08:54:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:18 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:18 --> URI Class Initialized
DEBUG - 2016-10-03 08:54:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:18 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:18 --> Router Class Initialized
INFO - 2016-10-03 08:54:18 --> URI Class Initialized
INFO - 2016-10-03 08:54:18 --> Output Class Initialized
INFO - 2016-10-03 08:54:18 --> Router Class Initialized
INFO - 2016-10-03 08:54:18 --> Security Class Initialized
INFO - 2016-10-03 08:54:18 --> Output Class Initialized
DEBUG - 2016-10-03 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:18 --> Input Class Initialized
INFO - 2016-10-03 08:54:18 --> Language Class Initialized
INFO - 2016-10-03 08:54:18 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:18 --> Input Class Initialized
INFO - 2016-10-03 08:54:18 --> Loader Class Initialized
INFO - 2016-10-03 08:54:18 --> Language Class Initialized
INFO - 2016-10-03 08:54:18 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:18 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:18 --> Loader Class Initialized
INFO - 2016-10-03 08:54:18 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:18 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:18 --> Controller Class Initialized
INFO - 2016-10-03 08:54:18 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:18 --> Model Class Initialized
INFO - 2016-10-03 08:54:18 --> Model Class Initialized
INFO - 2016-10-03 08:54:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:18 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:18 --> Total execution time: 0.0689
INFO - 2016-10-03 08:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:18 --> Controller Class Initialized
INFO - 2016-10-03 08:54:18 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:18 --> Model Class Initialized
INFO - 2016-10-03 08:54:18 --> Model Class Initialized
INFO - 2016-10-03 08:54:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:18 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:18 --> Total execution time: 0.0956
INFO - 2016-10-03 08:54:20 --> Config Class Initialized
INFO - 2016-10-03 08:54:20 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:20 --> Config Class Initialized
INFO - 2016-10-03 08:54:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:20 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:54:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:20 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:20 --> URI Class Initialized
INFO - 2016-10-03 08:54:20 --> URI Class Initialized
INFO - 2016-10-03 08:54:20 --> Router Class Initialized
INFO - 2016-10-03 08:54:20 --> Router Class Initialized
INFO - 2016-10-03 08:54:20 --> Output Class Initialized
INFO - 2016-10-03 08:54:20 --> Output Class Initialized
INFO - 2016-10-03 08:54:20 --> Security Class Initialized
INFO - 2016-10-03 08:54:20 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:20 --> Input Class Initialized
INFO - 2016-10-03 08:54:20 --> Language Class Initialized
DEBUG - 2016-10-03 08:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:20 --> Input Class Initialized
INFO - 2016-10-03 08:54:20 --> Language Class Initialized
INFO - 2016-10-03 08:54:20 --> Loader Class Initialized
INFO - 2016-10-03 08:54:20 --> Loader Class Initialized
INFO - 2016-10-03 08:54:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:20 --> Controller Class Initialized
INFO - 2016-10-03 08:54:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:20 --> Model Class Initialized
INFO - 2016-10-03 08:54:20 --> Model Class Initialized
INFO - 2016-10-03 08:54:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:20 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:20 --> Total execution time: 0.0756
INFO - 2016-10-03 08:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:20 --> Controller Class Initialized
INFO - 2016-10-03 08:54:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:20 --> Model Class Initialized
INFO - 2016-10-03 08:54:20 --> Model Class Initialized
INFO - 2016-10-03 08:54:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:20 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:20 --> Total execution time: 0.1158
INFO - 2016-10-03 08:54:22 --> Config Class Initialized
INFO - 2016-10-03 08:54:22 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:22 --> Config Class Initialized
INFO - 2016-10-03 08:54:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:22 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:54:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:22 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:22 --> URI Class Initialized
INFO - 2016-10-03 08:54:22 --> URI Class Initialized
INFO - 2016-10-03 08:54:22 --> Router Class Initialized
INFO - 2016-10-03 08:54:22 --> Router Class Initialized
INFO - 2016-10-03 08:54:22 --> Output Class Initialized
INFO - 2016-10-03 08:54:22 --> Output Class Initialized
INFO - 2016-10-03 08:54:22 --> Security Class Initialized
INFO - 2016-10-03 08:54:22 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:22 --> Input Class Initialized
DEBUG - 2016-10-03 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:22 --> Input Class Initialized
INFO - 2016-10-03 08:54:22 --> Language Class Initialized
INFO - 2016-10-03 08:54:22 --> Language Class Initialized
INFO - 2016-10-03 08:54:22 --> Loader Class Initialized
INFO - 2016-10-03 08:54:22 --> Loader Class Initialized
INFO - 2016-10-03 08:54:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:22 --> Controller Class Initialized
INFO - 2016-10-03 08:54:22 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:22 --> Model Class Initialized
INFO - 2016-10-03 08:54:22 --> Model Class Initialized
INFO - 2016-10-03 08:54:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:22 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:22 --> Total execution time: 0.0916
INFO - 2016-10-03 08:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:22 --> Controller Class Initialized
INFO - 2016-10-03 08:54:22 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:22 --> Model Class Initialized
INFO - 2016-10-03 08:54:22 --> Model Class Initialized
INFO - 2016-10-03 08:54:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:22 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:22 --> Total execution time: 0.1147
INFO - 2016-10-03 08:54:25 --> Config Class Initialized
INFO - 2016-10-03 08:54:25 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:25 --> Config Class Initialized
INFO - 2016-10-03 08:54:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:54:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:25 --> URI Class Initialized
INFO - 2016-10-03 08:54:25 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:25 --> URI Class Initialized
INFO - 2016-10-03 08:54:25 --> Router Class Initialized
INFO - 2016-10-03 08:54:25 --> Router Class Initialized
INFO - 2016-10-03 08:54:25 --> Output Class Initialized
INFO - 2016-10-03 08:54:25 --> Output Class Initialized
INFO - 2016-10-03 08:54:25 --> Security Class Initialized
INFO - 2016-10-03 08:54:25 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:25 --> Input Class Initialized
INFO - 2016-10-03 08:54:25 --> Language Class Initialized
DEBUG - 2016-10-03 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:25 --> Input Class Initialized
INFO - 2016-10-03 08:54:25 --> Language Class Initialized
INFO - 2016-10-03 08:54:25 --> Loader Class Initialized
INFO - 2016-10-03 08:54:25 --> Loader Class Initialized
INFO - 2016-10-03 08:54:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:25 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:25 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:25 --> Controller Class Initialized
INFO - 2016-10-03 08:54:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:25 --> Model Class Initialized
INFO - 2016-10-03 08:54:25 --> Model Class Initialized
INFO - 2016-10-03 08:54:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:25 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:25 --> Total execution time: 0.0666
INFO - 2016-10-03 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:25 --> Controller Class Initialized
INFO - 2016-10-03 08:54:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:25 --> Model Class Initialized
INFO - 2016-10-03 08:54:25 --> Model Class Initialized
INFO - 2016-10-03 08:54:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:25 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:25 --> Total execution time: 0.1047
INFO - 2016-10-03 08:54:28 --> Config Class Initialized
INFO - 2016-10-03 08:54:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:28 --> URI Class Initialized
INFO - 2016-10-03 08:54:28 --> Router Class Initialized
INFO - 2016-10-03 08:54:28 --> Output Class Initialized
INFO - 2016-10-03 08:54:28 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:28 --> Input Class Initialized
INFO - 2016-10-03 08:54:28 --> Language Class Initialized
INFO - 2016-10-03 08:54:28 --> Loader Class Initialized
INFO - 2016-10-03 08:54:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:28 --> Controller Class Initialized
INFO - 2016-10-03 08:54:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:28 --> Model Class Initialized
INFO - 2016-10-03 08:54:28 --> Model Class Initialized
INFO - 2016-10-03 08:54:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:28 --> Total execution time: 0.0842
INFO - 2016-10-03 08:54:28 --> Config Class Initialized
INFO - 2016-10-03 08:54:28 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:28 --> Config Class Initialized
DEBUG - 2016-10-03 08:54:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:28 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:28 --> URI Class Initialized
DEBUG - 2016-10-03 08:54:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:28 --> Router Class Initialized
INFO - 2016-10-03 08:54:28 --> Config Class Initialized
INFO - 2016-10-03 08:54:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:28 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:28 --> URI Class Initialized
INFO - 2016-10-03 08:54:28 --> Output Class Initialized
INFO - 2016-10-03 08:54:28 --> Security Class Initialized
INFO - 2016-10-03 08:54:28 --> Router Class Initialized
DEBUG - 2016-10-03 08:54:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:29 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:29 --> Input Class Initialized
INFO - 2016-10-03 08:54:29 --> Output Class Initialized
INFO - 2016-10-03 08:54:29 --> URI Class Initialized
INFO - 2016-10-03 08:54:29 --> Language Class Initialized
INFO - 2016-10-03 08:54:29 --> Security Class Initialized
INFO - 2016-10-03 08:54:29 --> Router Class Initialized
DEBUG - 2016-10-03 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:29 --> Input Class Initialized
INFO - 2016-10-03 08:54:29 --> Output Class Initialized
INFO - 2016-10-03 08:54:29 --> Language Class Initialized
INFO - 2016-10-03 08:54:29 --> Loader Class Initialized
INFO - 2016-10-03 08:54:29 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:29 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:29 --> Input Class Initialized
INFO - 2016-10-03 08:54:29 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:29 --> Language Class Initialized
INFO - 2016-10-03 08:54:29 --> Loader Class Initialized
INFO - 2016-10-03 08:54:29 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:29 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:29 --> Loader Class Initialized
INFO - 2016-10-03 08:54:29 --> Controller Class Initialized
INFO - 2016-10-03 08:54:29 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:29 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:29 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:29 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:29 --> Total execution time: 0.0981
INFO - 2016-10-03 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:29 --> Controller Class Initialized
INFO - 2016-10-03 08:54:29 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:29 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:29 --> Total execution time: 0.1192
INFO - 2016-10-03 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:29 --> Controller Class Initialized
INFO - 2016-10-03 08:54:29 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:29 --> Config Class Initialized
INFO - 2016-10-03 08:54:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:29 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:29 --> URI Class Initialized
INFO - 2016-10-03 08:54:29 --> Router Class Initialized
INFO - 2016-10-03 08:54:29 --> Output Class Initialized
INFO - 2016-10-03 08:54:29 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:29 --> Input Class Initialized
INFO - 2016-10-03 08:54:29 --> Language Class Initialized
INFO - 2016-10-03 08:54:29 --> Loader Class Initialized
INFO - 2016-10-03 08:54:29 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:29 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:29 --> Controller Class Initialized
INFO - 2016-10-03 08:54:29 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Model Class Initialized
INFO - 2016-10-03 08:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:54:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-10-03 08:54:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:54:29 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:29 --> Total execution time: 0.0639
INFO - 2016-10-03 08:54:33 --> Config Class Initialized
INFO - 2016-10-03 08:54:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:33 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:33 --> URI Class Initialized
INFO - 2016-10-03 08:54:33 --> Router Class Initialized
INFO - 2016-10-03 08:54:33 --> Output Class Initialized
INFO - 2016-10-03 08:54:33 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:33 --> Input Class Initialized
INFO - 2016-10-03 08:54:33 --> Language Class Initialized
INFO - 2016-10-03 08:54:33 --> Loader Class Initialized
INFO - 2016-10-03 08:54:33 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:33 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:33 --> Controller Class Initialized
INFO - 2016-10-03 08:54:33 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:33 --> Config Class Initialized
INFO - 2016-10-03 08:54:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:33 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:33 --> URI Class Initialized
INFO - 2016-10-03 08:54:33 --> Router Class Initialized
INFO - 2016-10-03 08:54:33 --> Output Class Initialized
INFO - 2016-10-03 08:54:33 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:33 --> Input Class Initialized
INFO - 2016-10-03 08:54:33 --> Language Class Initialized
INFO - 2016-10-03 08:54:33 --> Loader Class Initialized
INFO - 2016-10-03 08:54:33 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:33 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:33 --> Controller Class Initialized
INFO - 2016-10-03 08:54:33 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:54:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2016-10-03 08:54:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:54:33 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:33 --> Total execution time: 0.0693
INFO - 2016-10-03 08:54:33 --> Config Class Initialized
INFO - 2016-10-03 08:54:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:33 --> Config Class Initialized
INFO - 2016-10-03 08:54:33 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:33 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:33 --> URI Class Initialized
INFO - 2016-10-03 08:54:33 --> Router Class Initialized
DEBUG - 2016-10-03 08:54:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:33 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:33 --> URI Class Initialized
INFO - 2016-10-03 08:54:33 --> Output Class Initialized
INFO - 2016-10-03 08:54:33 --> Security Class Initialized
INFO - 2016-10-03 08:54:33 --> Router Class Initialized
DEBUG - 2016-10-03 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:33 --> Input Class Initialized
INFO - 2016-10-03 08:54:33 --> Output Class Initialized
INFO - 2016-10-03 08:54:33 --> Language Class Initialized
INFO - 2016-10-03 08:54:33 --> Security Class Initialized
DEBUG - 2016-10-03 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:33 --> Input Class Initialized
INFO - 2016-10-03 08:54:33 --> Loader Class Initialized
INFO - 2016-10-03 08:54:33 --> Language Class Initialized
INFO - 2016-10-03 08:54:33 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:33 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:33 --> Loader Class Initialized
INFO - 2016-10-03 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:33 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:33 --> Controller Class Initialized
INFO - 2016-10-03 08:54:33 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:33 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:33 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:33 --> Total execution time: 0.0720
INFO - 2016-10-03 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:33 --> Controller Class Initialized
INFO - 2016-10-03 08:54:33 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Model Class Initialized
INFO - 2016-10-03 08:54:33 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:54:33 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:54:33 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:33 --> Total execution time: 0.1043
INFO - 2016-10-03 08:54:36 --> Config Class Initialized
INFO - 2016-10-03 08:54:36 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:36 --> Config Class Initialized
INFO - 2016-10-03 08:54:36 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:36 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:36 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:36 --> URI Class Initialized
DEBUG - 2016-10-03 08:54:36 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:36 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:36 --> Router Class Initialized
INFO - 2016-10-03 08:54:36 --> URI Class Initialized
INFO - 2016-10-03 08:54:36 --> Output Class Initialized
INFO - 2016-10-03 08:54:36 --> Router Class Initialized
INFO - 2016-10-03 08:54:36 --> Security Class Initialized
INFO - 2016-10-03 08:54:36 --> Output Class Initialized
DEBUG - 2016-10-03 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:36 --> Input Class Initialized
INFO - 2016-10-03 08:54:36 --> Security Class Initialized
INFO - 2016-10-03 08:54:36 --> Language Class Initialized
DEBUG - 2016-10-03 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:36 --> Input Class Initialized
INFO - 2016-10-03 08:54:36 --> Language Class Initialized
INFO - 2016-10-03 08:54:36 --> Loader Class Initialized
INFO - 2016-10-03 08:54:36 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:36 --> Loader Class Initialized
INFO - 2016-10-03 08:54:36 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:36 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:36 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:36 --> Controller Class Initialized
INFO - 2016-10-03 08:54:36 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:36 --> Model Class Initialized
INFO - 2016-10-03 08:54:36 --> Model Class Initialized
INFO - 2016-10-03 08:54:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:36 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:36 --> Total execution time: 0.0648
INFO - 2016-10-03 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:36 --> Controller Class Initialized
INFO - 2016-10-03 08:54:36 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:36 --> Model Class Initialized
INFO - 2016-10-03 08:54:36 --> Model Class Initialized
INFO - 2016-10-03 08:54:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:36 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:36 --> Total execution time: 0.0876
INFO - 2016-10-03 08:54:55 --> Config Class Initialized
INFO - 2016-10-03 08:54:55 --> Hooks Class Initialized
INFO - 2016-10-03 08:54:55 --> Config Class Initialized
INFO - 2016-10-03 08:54:55 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:54:55 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:55 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:55 --> URI Class Initialized
DEBUG - 2016-10-03 08:54:55 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:54:55 --> Utf8 Class Initialized
INFO - 2016-10-03 08:54:55 --> Router Class Initialized
INFO - 2016-10-03 08:54:55 --> URI Class Initialized
INFO - 2016-10-03 08:54:55 --> Output Class Initialized
INFO - 2016-10-03 08:54:55 --> Router Class Initialized
INFO - 2016-10-03 08:54:55 --> Security Class Initialized
INFO - 2016-10-03 08:54:55 --> Output Class Initialized
DEBUG - 2016-10-03 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:55 --> Security Class Initialized
INFO - 2016-10-03 08:54:55 --> Input Class Initialized
INFO - 2016-10-03 08:54:55 --> Language Class Initialized
DEBUG - 2016-10-03 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:54:55 --> Input Class Initialized
INFO - 2016-10-03 08:54:55 --> Language Class Initialized
INFO - 2016-10-03 08:54:55 --> Loader Class Initialized
INFO - 2016-10-03 08:54:55 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:55 --> Loader Class Initialized
INFO - 2016-10-03 08:54:55 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:55 --> Helper loaded: url_helper
INFO - 2016-10-03 08:54:55 --> Helper loaded: language_helper
INFO - 2016-10-03 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:55 --> Controller Class Initialized
INFO - 2016-10-03 08:54:55 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:55 --> Model Class Initialized
INFO - 2016-10-03 08:54:55 --> Model Class Initialized
INFO - 2016-10-03 08:54:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:55 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:55 --> Total execution time: 0.0809
INFO - 2016-10-03 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:54:55 --> Controller Class Initialized
INFO - 2016-10-03 08:54:55 --> Database Driver Class Initialized
INFO - 2016-10-03 08:54:55 --> Model Class Initialized
INFO - 2016-10-03 08:54:55 --> Model Class Initialized
INFO - 2016-10-03 08:54:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:54:55 --> Final output sent to browser
DEBUG - 2016-10-03 08:54:55 --> Total execution time: 0.1151
INFO - 2016-10-03 08:55:01 --> Config Class Initialized
INFO - 2016-10-03 08:55:01 --> Config Class Initialized
INFO - 2016-10-03 08:55:01 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:55:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:01 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:01 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:01 --> URI Class Initialized
INFO - 2016-10-03 08:55:01 --> URI Class Initialized
INFO - 2016-10-03 08:55:01 --> Router Class Initialized
INFO - 2016-10-03 08:55:01 --> Router Class Initialized
INFO - 2016-10-03 08:55:01 --> Output Class Initialized
INFO - 2016-10-03 08:55:01 --> Output Class Initialized
INFO - 2016-10-03 08:55:01 --> Security Class Initialized
INFO - 2016-10-03 08:55:01 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-03 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:01 --> Input Class Initialized
INFO - 2016-10-03 08:55:01 --> Input Class Initialized
INFO - 2016-10-03 08:55:01 --> Language Class Initialized
INFO - 2016-10-03 08:55:01 --> Language Class Initialized
INFO - 2016-10-03 08:55:01 --> Loader Class Initialized
INFO - 2016-10-03 08:55:01 --> Loader Class Initialized
INFO - 2016-10-03 08:55:01 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:01 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:01 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:01 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:01 --> Controller Class Initialized
INFO - 2016-10-03 08:55:01 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:01 --> Model Class Initialized
INFO - 2016-10-03 08:55:01 --> Model Class Initialized
INFO - 2016-10-03 08:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:01 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:01 --> Total execution time: 0.0678
INFO - 2016-10-03 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:01 --> Controller Class Initialized
INFO - 2016-10-03 08:55:01 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:01 --> Model Class Initialized
INFO - 2016-10-03 08:55:01 --> Model Class Initialized
INFO - 2016-10-03 08:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:01 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:01 --> Total execution time: 0.1038
INFO - 2016-10-03 08:55:03 --> Config Class Initialized
INFO - 2016-10-03 08:55:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:03 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:03 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:03 --> URI Class Initialized
INFO - 2016-10-03 08:55:03 --> Router Class Initialized
INFO - 2016-10-03 08:55:03 --> Output Class Initialized
INFO - 2016-10-03 08:55:03 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:03 --> Input Class Initialized
INFO - 2016-10-03 08:55:03 --> Language Class Initialized
INFO - 2016-10-03 08:55:03 --> Loader Class Initialized
INFO - 2016-10-03 08:55:03 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:03 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:03 --> Controller Class Initialized
INFO - 2016-10-03 08:55:03 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:03 --> Model Class Initialized
INFO - 2016-10-03 08:55:03 --> Model Class Initialized
INFO - 2016-10-03 08:55:03 --> Model Class Initialized
INFO - 2016-10-03 08:55:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:03 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:03 --> Total execution time: 0.0734
INFO - 2016-10-03 08:55:08 --> Config Class Initialized
INFO - 2016-10-03 08:55:08 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:08 --> Config Class Initialized
INFO - 2016-10-03 08:55:08 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:08 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:08 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:55:08 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:08 --> URI Class Initialized
INFO - 2016-10-03 08:55:08 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:08 --> URI Class Initialized
INFO - 2016-10-03 08:55:08 --> Router Class Initialized
INFO - 2016-10-03 08:55:08 --> Router Class Initialized
INFO - 2016-10-03 08:55:08 --> Output Class Initialized
INFO - 2016-10-03 08:55:08 --> Security Class Initialized
INFO - 2016-10-03 08:55:08 --> Output Class Initialized
DEBUG - 2016-10-03 08:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:08 --> Security Class Initialized
INFO - 2016-10-03 08:55:08 --> Input Class Initialized
INFO - 2016-10-03 08:55:08 --> Language Class Initialized
DEBUG - 2016-10-03 08:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:08 --> Input Class Initialized
INFO - 2016-10-03 08:55:08 --> Language Class Initialized
INFO - 2016-10-03 08:55:08 --> Loader Class Initialized
INFO - 2016-10-03 08:55:08 --> Loader Class Initialized
INFO - 2016-10-03 08:55:08 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:08 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:08 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:08 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:08 --> Controller Class Initialized
INFO - 2016-10-03 08:55:08 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:08 --> Model Class Initialized
INFO - 2016-10-03 08:55:08 --> Model Class Initialized
INFO - 2016-10-03 08:55:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:08 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:08 --> Total execution time: 0.0688
INFO - 2016-10-03 08:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:08 --> Controller Class Initialized
INFO - 2016-10-03 08:55:08 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:08 --> Model Class Initialized
INFO - 2016-10-03 08:55:08 --> Model Class Initialized
INFO - 2016-10-03 08:55:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:08 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:08 --> Total execution time: 0.1011
INFO - 2016-10-03 08:55:15 --> Config Class Initialized
INFO - 2016-10-03 08:55:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:15 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:15 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:15 --> URI Class Initialized
INFO - 2016-10-03 08:55:15 --> Router Class Initialized
INFO - 2016-10-03 08:55:15 --> Output Class Initialized
INFO - 2016-10-03 08:55:15 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:15 --> Input Class Initialized
INFO - 2016-10-03 08:55:15 --> Language Class Initialized
INFO - 2016-10-03 08:55:15 --> Loader Class Initialized
INFO - 2016-10-03 08:55:15 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:15 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:15 --> Controller Class Initialized
INFO - 2016-10-03 08:55:15 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:15 --> Model Class Initialized
INFO - 2016-10-03 08:55:15 --> Model Class Initialized
INFO - 2016-10-03 08:55:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:15 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:15 --> Total execution time: 0.0755
INFO - 2016-10-03 08:55:22 --> Config Class Initialized
INFO - 2016-10-03 08:55:22 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:22 --> Config Class Initialized
INFO - 2016-10-03 08:55:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:22 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:22 --> Config Class Initialized
INFO - 2016-10-03 08:55:22 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:22 --> URI Class Initialized
DEBUG - 2016-10-03 08:55:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:22 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:22 --> Router Class Initialized
INFO - 2016-10-03 08:55:22 --> URI Class Initialized
DEBUG - 2016-10-03 08:55:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:22 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:22 --> Output Class Initialized
INFO - 2016-10-03 08:55:22 --> Router Class Initialized
INFO - 2016-10-03 08:55:22 --> URI Class Initialized
INFO - 2016-10-03 08:55:22 --> Security Class Initialized
INFO - 2016-10-03 08:55:22 --> Output Class Initialized
INFO - 2016-10-03 08:55:22 --> Router Class Initialized
DEBUG - 2016-10-03 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:22 --> Input Class Initialized
INFO - 2016-10-03 08:55:22 --> Security Class Initialized
INFO - 2016-10-03 08:55:22 --> Language Class Initialized
INFO - 2016-10-03 08:55:22 --> Output Class Initialized
INFO - 2016-10-03 08:55:22 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:22 --> Input Class Initialized
INFO - 2016-10-03 08:55:22 --> Language Class Initialized
DEBUG - 2016-10-03 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:22 --> Input Class Initialized
INFO - 2016-10-03 08:55:22 --> Loader Class Initialized
INFO - 2016-10-03 08:55:22 --> Language Class Initialized
INFO - 2016-10-03 08:55:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:22 --> Loader Class Initialized
INFO - 2016-10-03 08:55:22 --> Loader Class Initialized
INFO - 2016-10-03 08:55:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:22 --> Controller Class Initialized
INFO - 2016-10-03 08:55:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:22 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:22 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:22 --> Total execution time: 0.0802
INFO - 2016-10-03 08:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:22 --> Controller Class Initialized
INFO - 2016-10-03 08:55:22 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:22 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:22 --> Total execution time: 0.1252
INFO - 2016-10-03 08:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:22 --> Controller Class Initialized
INFO - 2016-10-03 08:55:22 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Model Class Initialized
INFO - 2016-10-03 08:55:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:22 --> Config Class Initialized
INFO - 2016-10-03 08:55:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:22 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:22 --> URI Class Initialized
INFO - 2016-10-03 08:55:22 --> Router Class Initialized
INFO - 2016-10-03 08:55:22 --> Output Class Initialized
INFO - 2016-10-03 08:55:22 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:22 --> Input Class Initialized
INFO - 2016-10-03 08:55:22 --> Language Class Initialized
INFO - 2016-10-03 08:55:22 --> Loader Class Initialized
INFO - 2016-10-03 08:55:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:23 --> Controller Class Initialized
INFO - 2016-10-03 08:55:23 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:23 --> Model Class Initialized
INFO - 2016-10-03 08:55:23 --> Model Class Initialized
INFO - 2016-10-03 08:55:23 --> Model Class Initialized
INFO - 2016-10-03 08:55:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:55:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-10-03 08:55:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:55:23 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:23 --> Total execution time: 0.0656
INFO - 2016-10-03 08:55:26 --> Config Class Initialized
INFO - 2016-10-03 08:55:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:26 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:26 --> URI Class Initialized
INFO - 2016-10-03 08:55:26 --> Router Class Initialized
INFO - 2016-10-03 08:55:26 --> Output Class Initialized
INFO - 2016-10-03 08:55:26 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:26 --> Input Class Initialized
INFO - 2016-10-03 08:55:26 --> Language Class Initialized
INFO - 2016-10-03 08:55:26 --> Loader Class Initialized
INFO - 2016-10-03 08:55:26 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:26 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:26 --> Controller Class Initialized
INFO - 2016-10-03 08:55:26 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:26 --> Config Class Initialized
INFO - 2016-10-03 08:55:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:26 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:26 --> URI Class Initialized
INFO - 2016-10-03 08:55:26 --> Router Class Initialized
INFO - 2016-10-03 08:55:26 --> Output Class Initialized
INFO - 2016-10-03 08:55:26 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:26 --> Input Class Initialized
INFO - 2016-10-03 08:55:26 --> Language Class Initialized
INFO - 2016-10-03 08:55:26 --> Loader Class Initialized
INFO - 2016-10-03 08:55:26 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:26 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:26 --> Controller Class Initialized
INFO - 2016-10-03 08:55:26 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:55:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2016-10-03 08:55:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:55:26 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:26 --> Total execution time: 0.0689
INFO - 2016-10-03 08:55:26 --> Config Class Initialized
INFO - 2016-10-03 08:55:26 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:26 --> Config Class Initialized
INFO - 2016-10-03 08:55:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:55:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:26 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:26 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:26 --> URI Class Initialized
INFO - 2016-10-03 08:55:26 --> URI Class Initialized
INFO - 2016-10-03 08:55:26 --> Router Class Initialized
INFO - 2016-10-03 08:55:26 --> Router Class Initialized
INFO - 2016-10-03 08:55:26 --> Output Class Initialized
INFO - 2016-10-03 08:55:26 --> Output Class Initialized
INFO - 2016-10-03 08:55:26 --> Security Class Initialized
INFO - 2016-10-03 08:55:26 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-03 08:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:26 --> Input Class Initialized
INFO - 2016-10-03 08:55:26 --> Input Class Initialized
INFO - 2016-10-03 08:55:26 --> Language Class Initialized
INFO - 2016-10-03 08:55:26 --> Language Class Initialized
INFO - 2016-10-03 08:55:26 --> Loader Class Initialized
INFO - 2016-10-03 08:55:26 --> Loader Class Initialized
INFO - 2016-10-03 08:55:26 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:26 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:26 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:26 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:26 --> Controller Class Initialized
INFO - 2016-10-03 08:55:26 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:26 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:26 --> Total execution time: 0.0766
INFO - 2016-10-03 08:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:26 --> Controller Class Initialized
INFO - 2016-10-03 08:55:26 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Model Class Initialized
INFO - 2016-10-03 08:55:26 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:55:26 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:55:26 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:26 --> Total execution time: 0.1103
INFO - 2016-10-03 08:55:31 --> Config Class Initialized
INFO - 2016-10-03 08:55:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:31 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:31 --> Config Class Initialized
INFO - 2016-10-03 08:55:31 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:31 --> URI Class Initialized
INFO - 2016-10-03 08:55:31 --> Router Class Initialized
DEBUG - 2016-10-03 08:55:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:31 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:31 --> Output Class Initialized
INFO - 2016-10-03 08:55:31 --> URI Class Initialized
INFO - 2016-10-03 08:55:31 --> Security Class Initialized
INFO - 2016-10-03 08:55:31 --> Router Class Initialized
DEBUG - 2016-10-03 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:31 --> Input Class Initialized
INFO - 2016-10-03 08:55:31 --> Output Class Initialized
INFO - 2016-10-03 08:55:31 --> Language Class Initialized
INFO - 2016-10-03 08:55:31 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:31 --> Input Class Initialized
INFO - 2016-10-03 08:55:31 --> Loader Class Initialized
INFO - 2016-10-03 08:55:31 --> Language Class Initialized
INFO - 2016-10-03 08:55:31 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:31 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:31 --> Loader Class Initialized
INFO - 2016-10-03 08:55:31 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:31 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:31 --> Controller Class Initialized
INFO - 2016-10-03 08:55:31 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:31 --> Model Class Initialized
INFO - 2016-10-03 08:55:31 --> Model Class Initialized
INFO - 2016-10-03 08:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:31 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:31 --> Total execution time: 0.0638
INFO - 2016-10-03 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:31 --> Controller Class Initialized
INFO - 2016-10-03 08:55:31 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:31 --> Model Class Initialized
INFO - 2016-10-03 08:55:31 --> Model Class Initialized
INFO - 2016-10-03 08:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:31 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:31 --> Total execution time: 0.0860
INFO - 2016-10-03 08:55:35 --> Config Class Initialized
INFO - 2016-10-03 08:55:35 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:35 --> Config Class Initialized
INFO - 2016-10-03 08:55:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:35 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:55:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:35 --> URI Class Initialized
INFO - 2016-10-03 08:55:35 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:35 --> URI Class Initialized
INFO - 2016-10-03 08:55:35 --> Router Class Initialized
INFO - 2016-10-03 08:55:35 --> Router Class Initialized
INFO - 2016-10-03 08:55:35 --> Output Class Initialized
INFO - 2016-10-03 08:55:35 --> Output Class Initialized
INFO - 2016-10-03 08:55:35 --> Security Class Initialized
INFO - 2016-10-03 08:55:35 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:35 --> Input Class Initialized
DEBUG - 2016-10-03 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:35 --> Language Class Initialized
INFO - 2016-10-03 08:55:35 --> Input Class Initialized
INFO - 2016-10-03 08:55:35 --> Language Class Initialized
INFO - 2016-10-03 08:55:35 --> Loader Class Initialized
INFO - 2016-10-03 08:55:35 --> Loader Class Initialized
INFO - 2016-10-03 08:55:35 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:35 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:35 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:35 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:35 --> Controller Class Initialized
INFO - 2016-10-03 08:55:35 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:35 --> Model Class Initialized
INFO - 2016-10-03 08:55:35 --> Model Class Initialized
INFO - 2016-10-03 08:55:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:35 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:35 --> Total execution time: 0.0662
INFO - 2016-10-03 08:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:35 --> Controller Class Initialized
INFO - 2016-10-03 08:55:35 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:35 --> Model Class Initialized
INFO - 2016-10-03 08:55:35 --> Model Class Initialized
INFO - 2016-10-03 08:55:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:35 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:35 --> Total execution time: 0.0979
INFO - 2016-10-03 08:55:42 --> Config Class Initialized
INFO - 2016-10-03 08:55:42 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:42 --> Config Class Initialized
INFO - 2016-10-03 08:55:42 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:42 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:42 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:55:42 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:42 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:42 --> URI Class Initialized
INFO - 2016-10-03 08:55:42 --> URI Class Initialized
INFO - 2016-10-03 08:55:42 --> Router Class Initialized
INFO - 2016-10-03 08:55:42 --> Router Class Initialized
INFO - 2016-10-03 08:55:42 --> Output Class Initialized
INFO - 2016-10-03 08:55:42 --> Output Class Initialized
INFO - 2016-10-03 08:55:42 --> Security Class Initialized
INFO - 2016-10-03 08:55:42 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:42 --> Input Class Initialized
DEBUG - 2016-10-03 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:42 --> Input Class Initialized
INFO - 2016-10-03 08:55:42 --> Language Class Initialized
INFO - 2016-10-03 08:55:42 --> Language Class Initialized
INFO - 2016-10-03 08:55:42 --> Loader Class Initialized
INFO - 2016-10-03 08:55:42 --> Loader Class Initialized
INFO - 2016-10-03 08:55:42 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:42 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:42 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:42 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:42 --> Controller Class Initialized
INFO - 2016-10-03 08:55:42 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:42 --> Model Class Initialized
INFO - 2016-10-03 08:55:42 --> Model Class Initialized
INFO - 2016-10-03 08:55:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:42 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:42 --> Total execution time: 0.0631
INFO - 2016-10-03 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:42 --> Controller Class Initialized
INFO - 2016-10-03 08:55:42 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:42 --> Model Class Initialized
INFO - 2016-10-03 08:55:42 --> Model Class Initialized
INFO - 2016-10-03 08:55:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:42 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:42 --> Total execution time: 0.0959
INFO - 2016-10-03 08:55:47 --> Config Class Initialized
INFO - 2016-10-03 08:55:47 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:47 --> Config Class Initialized
INFO - 2016-10-03 08:55:47 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:47 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:47 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:55:47 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:47 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:47 --> URI Class Initialized
INFO - 2016-10-03 08:55:47 --> URI Class Initialized
INFO - 2016-10-03 08:55:47 --> Router Class Initialized
INFO - 2016-10-03 08:55:47 --> Router Class Initialized
INFO - 2016-10-03 08:55:47 --> Output Class Initialized
INFO - 2016-10-03 08:55:47 --> Output Class Initialized
INFO - 2016-10-03 08:55:47 --> Security Class Initialized
INFO - 2016-10-03 08:55:47 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:47 --> Input Class Initialized
DEBUG - 2016-10-03 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:47 --> Input Class Initialized
INFO - 2016-10-03 08:55:47 --> Language Class Initialized
INFO - 2016-10-03 08:55:47 --> Language Class Initialized
INFO - 2016-10-03 08:55:47 --> Loader Class Initialized
INFO - 2016-10-03 08:55:47 --> Loader Class Initialized
INFO - 2016-10-03 08:55:47 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:47 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:47 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:47 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:47 --> Controller Class Initialized
INFO - 2016-10-03 08:55:47 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:47 --> Model Class Initialized
INFO - 2016-10-03 08:55:47 --> Model Class Initialized
INFO - 2016-10-03 08:55:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:47 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:47 --> Total execution time: 0.0842
INFO - 2016-10-03 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:47 --> Controller Class Initialized
INFO - 2016-10-03 08:55:47 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:47 --> Model Class Initialized
INFO - 2016-10-03 08:55:47 --> Model Class Initialized
INFO - 2016-10-03 08:55:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:47 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:47 --> Total execution time: 0.1122
INFO - 2016-10-03 08:55:53 --> Config Class Initialized
INFO - 2016-10-03 08:55:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:53 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:53 --> URI Class Initialized
INFO - 2016-10-03 08:55:53 --> Router Class Initialized
INFO - 2016-10-03 08:55:53 --> Output Class Initialized
INFO - 2016-10-03 08:55:53 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:53 --> Input Class Initialized
INFO - 2016-10-03 08:55:53 --> Language Class Initialized
INFO - 2016-10-03 08:55:53 --> Loader Class Initialized
INFO - 2016-10-03 08:55:53 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:53 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:53 --> Controller Class Initialized
INFO - 2016-10-03 08:55:53 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:53 --> Model Class Initialized
INFO - 2016-10-03 08:55:53 --> Model Class Initialized
INFO - 2016-10-03 08:55:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:53 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:53 --> Total execution time: 0.0774
INFO - 2016-10-03 08:55:54 --> Config Class Initialized
INFO - 2016-10-03 08:55:54 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:54 --> Config Class Initialized
INFO - 2016-10-03 08:55:54 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:54 --> Config Class Initialized
INFO - 2016-10-03 08:55:54 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:54 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:54 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:55:54 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:55:54 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:54 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:54 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:54 --> URI Class Initialized
INFO - 2016-10-03 08:55:54 --> URI Class Initialized
INFO - 2016-10-03 08:55:54 --> URI Class Initialized
INFO - 2016-10-03 08:55:54 --> Router Class Initialized
INFO - 2016-10-03 08:55:54 --> Router Class Initialized
INFO - 2016-10-03 08:55:54 --> Router Class Initialized
INFO - 2016-10-03 08:55:54 --> Output Class Initialized
INFO - 2016-10-03 08:55:54 --> Output Class Initialized
INFO - 2016-10-03 08:55:54 --> Output Class Initialized
INFO - 2016-10-03 08:55:54 --> Security Class Initialized
INFO - 2016-10-03 08:55:54 --> Security Class Initialized
INFO - 2016-10-03 08:55:54 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-03 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:54 --> Input Class Initialized
INFO - 2016-10-03 08:55:54 --> Input Class Initialized
DEBUG - 2016-10-03 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:54 --> Input Class Initialized
INFO - 2016-10-03 08:55:54 --> Language Class Initialized
INFO - 2016-10-03 08:55:54 --> Language Class Initialized
INFO - 2016-10-03 08:55:54 --> Language Class Initialized
INFO - 2016-10-03 08:55:54 --> Loader Class Initialized
INFO - 2016-10-03 08:55:54 --> Loader Class Initialized
INFO - 2016-10-03 08:55:54 --> Loader Class Initialized
INFO - 2016-10-03 08:55:54 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:54 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:54 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:54 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:54 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:54 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:54 --> Controller Class Initialized
INFO - 2016-10-03 08:55:54 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:54 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:54 --> Total execution time: 0.0759
INFO - 2016-10-03 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:54 --> Controller Class Initialized
INFO - 2016-10-03 08:55:54 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:54 --> Controller Class Initialized
INFO - 2016-10-03 08:55:54 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Config Class Initialized
INFO - 2016-10-03 08:55:54 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:54 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:54 --> Total execution time: 0.1348
DEBUG - 2016-10-03 08:55:54 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:54 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:54 --> URI Class Initialized
INFO - 2016-10-03 08:55:54 --> Router Class Initialized
INFO - 2016-10-03 08:55:54 --> Output Class Initialized
INFO - 2016-10-03 08:55:54 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:54 --> Input Class Initialized
INFO - 2016-10-03 08:55:54 --> Language Class Initialized
INFO - 2016-10-03 08:55:54 --> Loader Class Initialized
INFO - 2016-10-03 08:55:54 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:54 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:54 --> Controller Class Initialized
INFO - 2016-10-03 08:55:54 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Model Class Initialized
INFO - 2016-10-03 08:55:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:55:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2016-10-03 08:55:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:55:54 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:54 --> Total execution time: 0.0668
INFO - 2016-10-03 08:55:58 --> Config Class Initialized
INFO - 2016-10-03 08:55:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:58 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:58 --> URI Class Initialized
INFO - 2016-10-03 08:55:58 --> Router Class Initialized
INFO - 2016-10-03 08:55:58 --> Output Class Initialized
INFO - 2016-10-03 08:55:58 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:58 --> Input Class Initialized
INFO - 2016-10-03 08:55:58 --> Language Class Initialized
INFO - 2016-10-03 08:55:58 --> Loader Class Initialized
INFO - 2016-10-03 08:55:58 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:58 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:58 --> Controller Class Initialized
INFO - 2016-10-03 08:55:58 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:58 --> Config Class Initialized
INFO - 2016-10-03 08:55:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:55:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:58 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:58 --> URI Class Initialized
INFO - 2016-10-03 08:55:58 --> Router Class Initialized
INFO - 2016-10-03 08:55:58 --> Output Class Initialized
INFO - 2016-10-03 08:55:58 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:58 --> Input Class Initialized
INFO - 2016-10-03 08:55:58 --> Language Class Initialized
INFO - 2016-10-03 08:55:58 --> Loader Class Initialized
INFO - 2016-10-03 08:55:58 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:58 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:58 --> Controller Class Initialized
INFO - 2016-10-03 08:55:58 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-10-03 08:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:55:58 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:58 --> Total execution time: 0.0860
INFO - 2016-10-03 08:55:58 --> Config Class Initialized
INFO - 2016-10-03 08:55:58 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:58 --> Config Class Initialized
DEBUG - 2016-10-03 08:55:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:58 --> Hooks Class Initialized
INFO - 2016-10-03 08:55:58 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:58 --> URI Class Initialized
DEBUG - 2016-10-03 08:55:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:55:58 --> Router Class Initialized
INFO - 2016-10-03 08:55:58 --> Utf8 Class Initialized
INFO - 2016-10-03 08:55:58 --> URI Class Initialized
INFO - 2016-10-03 08:55:58 --> Output Class Initialized
INFO - 2016-10-03 08:55:58 --> Router Class Initialized
INFO - 2016-10-03 08:55:58 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:58 --> Input Class Initialized
INFO - 2016-10-03 08:55:58 --> Output Class Initialized
INFO - 2016-10-03 08:55:58 --> Language Class Initialized
INFO - 2016-10-03 08:55:58 --> Security Class Initialized
DEBUG - 2016-10-03 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:55:58 --> Loader Class Initialized
INFO - 2016-10-03 08:55:58 --> Input Class Initialized
INFO - 2016-10-03 08:55:58 --> Language Class Initialized
INFO - 2016-10-03 08:55:58 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:58 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:58 --> Loader Class Initialized
INFO - 2016-10-03 08:55:58 --> Helper loaded: url_helper
INFO - 2016-10-03 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:58 --> Helper loaded: language_helper
INFO - 2016-10-03 08:55:58 --> Controller Class Initialized
INFO - 2016-10-03 08:55:58 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:58 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:58 --> Total execution time: 0.0875
INFO - 2016-10-03 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:55:58 --> Controller Class Initialized
INFO - 2016-10-03 08:55:58 --> Database Driver Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Model Class Initialized
INFO - 2016-10-03 08:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:55:58 --> Final output sent to browser
DEBUG - 2016-10-03 08:55:58 --> Total execution time: 0.1350
INFO - 2016-10-03 08:56:09 --> Config Class Initialized
INFO - 2016-10-03 08:56:09 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:09 --> Config Class Initialized
DEBUG - 2016-10-03 08:56:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:09 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:09 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:09 --> URI Class Initialized
DEBUG - 2016-10-03 08:56:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:09 --> Router Class Initialized
INFO - 2016-10-03 08:56:09 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:09 --> URI Class Initialized
INFO - 2016-10-03 08:56:09 --> Output Class Initialized
INFO - 2016-10-03 08:56:09 --> Router Class Initialized
INFO - 2016-10-03 08:56:09 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:09 --> Input Class Initialized
INFO - 2016-10-03 08:56:09 --> Output Class Initialized
INFO - 2016-10-03 08:56:09 --> Language Class Initialized
INFO - 2016-10-03 08:56:09 --> Security Class Initialized
INFO - 2016-10-03 08:56:09 --> Loader Class Initialized
DEBUG - 2016-10-03 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:09 --> Input Class Initialized
INFO - 2016-10-03 08:56:09 --> Language Class Initialized
INFO - 2016-10-03 08:56:09 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:09 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:09 --> Loader Class Initialized
INFO - 2016-10-03 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:09 --> Controller Class Initialized
INFO - 2016-10-03 08:56:09 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:09 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:09 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:09 --> Model Class Initialized
INFO - 2016-10-03 08:56:09 --> Model Class Initialized
INFO - 2016-10-03 08:56:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:09 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:09 --> Total execution time: 0.0641
INFO - 2016-10-03 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:09 --> Controller Class Initialized
INFO - 2016-10-03 08:56:09 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:09 --> Model Class Initialized
INFO - 2016-10-03 08:56:09 --> Model Class Initialized
INFO - 2016-10-03 08:56:09 --> Model Class Initialized
INFO - 2016-10-03 08:56:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:09 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:09 --> Total execution time: 0.1298
INFO - 2016-10-03 08:56:17 --> Config Class Initialized
INFO - 2016-10-03 08:56:17 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:17 --> Config Class Initialized
INFO - 2016-10-03 08:56:17 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:17 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:17 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:17 --> URI Class Initialized
DEBUG - 2016-10-03 08:56:17 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:17 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:17 --> Router Class Initialized
INFO - 2016-10-03 08:56:17 --> URI Class Initialized
INFO - 2016-10-03 08:56:17 --> Output Class Initialized
INFO - 2016-10-03 08:56:17 --> Router Class Initialized
INFO - 2016-10-03 08:56:17 --> Security Class Initialized
INFO - 2016-10-03 08:56:17 --> Output Class Initialized
DEBUG - 2016-10-03 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:17 --> Input Class Initialized
INFO - 2016-10-03 08:56:17 --> Security Class Initialized
INFO - 2016-10-03 08:56:17 --> Language Class Initialized
DEBUG - 2016-10-03 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:17 --> Input Class Initialized
INFO - 2016-10-03 08:56:17 --> Loader Class Initialized
INFO - 2016-10-03 08:56:17 --> Language Class Initialized
INFO - 2016-10-03 08:56:17 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:17 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:17 --> Loader Class Initialized
INFO - 2016-10-03 08:56:17 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:17 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:17 --> Controller Class Initialized
INFO - 2016-10-03 08:56:17 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:17 --> Model Class Initialized
INFO - 2016-10-03 08:56:17 --> Model Class Initialized
INFO - 2016-10-03 08:56:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:17 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:17 --> Total execution time: 0.0642
INFO - 2016-10-03 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:17 --> Controller Class Initialized
INFO - 2016-10-03 08:56:17 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:17 --> Model Class Initialized
INFO - 2016-10-03 08:56:17 --> Model Class Initialized
INFO - 2016-10-03 08:56:17 --> Model Class Initialized
INFO - 2016-10-03 08:56:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:17 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:17 --> Total execution time: 0.1313
INFO - 2016-10-03 08:56:20 --> Config Class Initialized
INFO - 2016-10-03 08:56:20 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:20 --> Config Class Initialized
INFO - 2016-10-03 08:56:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:20 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:56:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:20 --> URI Class Initialized
INFO - 2016-10-03 08:56:20 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:20 --> URI Class Initialized
INFO - 2016-10-03 08:56:20 --> Router Class Initialized
INFO - 2016-10-03 08:56:20 --> Router Class Initialized
INFO - 2016-10-03 08:56:20 --> Output Class Initialized
INFO - 2016-10-03 08:56:20 --> Security Class Initialized
INFO - 2016-10-03 08:56:20 --> Output Class Initialized
DEBUG - 2016-10-03 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:20 --> Security Class Initialized
INFO - 2016-10-03 08:56:20 --> Input Class Initialized
INFO - 2016-10-03 08:56:20 --> Language Class Initialized
DEBUG - 2016-10-03 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:20 --> Input Class Initialized
INFO - 2016-10-03 08:56:20 --> Language Class Initialized
INFO - 2016-10-03 08:56:20 --> Loader Class Initialized
INFO - 2016-10-03 08:56:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:20 --> Loader Class Initialized
INFO - 2016-10-03 08:56:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:20 --> Controller Class Initialized
INFO - 2016-10-03 08:56:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:20 --> Model Class Initialized
INFO - 2016-10-03 08:56:20 --> Model Class Initialized
INFO - 2016-10-03 08:56:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:20 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:20 --> Total execution time: 0.0627
INFO - 2016-10-03 08:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:20 --> Controller Class Initialized
INFO - 2016-10-03 08:56:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:20 --> Model Class Initialized
INFO - 2016-10-03 08:56:20 --> Model Class Initialized
INFO - 2016-10-03 08:56:20 --> Model Class Initialized
INFO - 2016-10-03 08:56:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:20 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:20 --> Total execution time: 0.1340
INFO - 2016-10-03 08:56:28 --> Config Class Initialized
INFO - 2016-10-03 08:56:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:28 --> URI Class Initialized
INFO - 2016-10-03 08:56:28 --> Router Class Initialized
INFO - 2016-10-03 08:56:28 --> Output Class Initialized
INFO - 2016-10-03 08:56:28 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:28 --> Input Class Initialized
INFO - 2016-10-03 08:56:28 --> Language Class Initialized
INFO - 2016-10-03 08:56:28 --> Loader Class Initialized
INFO - 2016-10-03 08:56:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:28 --> Controller Class Initialized
INFO - 2016-10-03 08:56:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:28 --> Model Class Initialized
INFO - 2016-10-03 08:56:28 --> Model Class Initialized
INFO - 2016-10-03 08:56:28 --> Model Class Initialized
INFO - 2016-10-03 08:56:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:28 --> Total execution time: 0.0602
INFO - 2016-10-03 08:56:29 --> Config Class Initialized
INFO - 2016-10-03 08:56:29 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:29 --> Config Class Initialized
INFO - 2016-10-03 08:56:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:29 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:29 --> URI Class Initialized
DEBUG - 2016-10-03 08:56:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:29 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:29 --> Router Class Initialized
INFO - 2016-10-03 08:56:29 --> URI Class Initialized
INFO - 2016-10-03 08:56:29 --> Output Class Initialized
INFO - 2016-10-03 08:56:29 --> Security Class Initialized
INFO - 2016-10-03 08:56:29 --> Router Class Initialized
DEBUG - 2016-10-03 08:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:29 --> Output Class Initialized
INFO - 2016-10-03 08:56:29 --> Input Class Initialized
INFO - 2016-10-03 08:56:29 --> Language Class Initialized
INFO - 2016-10-03 08:56:29 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:29 --> Input Class Initialized
INFO - 2016-10-03 08:56:29 --> Language Class Initialized
INFO - 2016-10-03 08:56:29 --> Loader Class Initialized
INFO - 2016-10-03 08:56:29 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:29 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:29 --> Loader Class Initialized
INFO - 2016-10-03 08:56:29 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:29 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:30 --> Controller Class Initialized
INFO - 2016-10-03 08:56:30 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:30 --> Model Class Initialized
INFO - 2016-10-03 08:56:30 --> Model Class Initialized
INFO - 2016-10-03 08:56:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:30 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:30 --> Total execution time: 0.0694
INFO - 2016-10-03 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:30 --> Controller Class Initialized
INFO - 2016-10-03 08:56:30 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:30 --> Model Class Initialized
INFO - 2016-10-03 08:56:30 --> Model Class Initialized
INFO - 2016-10-03 08:56:30 --> Model Class Initialized
INFO - 2016-10-03 08:56:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:30 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:30 --> Total execution time: 0.1453
INFO - 2016-10-03 08:56:35 --> Config Class Initialized
INFO - 2016-10-03 08:56:35 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:35 --> Config Class Initialized
INFO - 2016-10-03 08:56:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:35 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:56:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:35 --> URI Class Initialized
INFO - 2016-10-03 08:56:35 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:35 --> URI Class Initialized
INFO - 2016-10-03 08:56:35 --> Router Class Initialized
INFO - 2016-10-03 08:56:35 --> Output Class Initialized
INFO - 2016-10-03 08:56:35 --> Router Class Initialized
INFO - 2016-10-03 08:56:35 --> Security Class Initialized
INFO - 2016-10-03 08:56:35 --> Output Class Initialized
DEBUG - 2016-10-03 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:35 --> Input Class Initialized
INFO - 2016-10-03 08:56:35 --> Security Class Initialized
INFO - 2016-10-03 08:56:35 --> Language Class Initialized
DEBUG - 2016-10-03 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:35 --> Input Class Initialized
INFO - 2016-10-03 08:56:35 --> Language Class Initialized
INFO - 2016-10-03 08:56:35 --> Loader Class Initialized
INFO - 2016-10-03 08:56:35 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:35 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:35 --> Loader Class Initialized
INFO - 2016-10-03 08:56:35 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:35 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:35 --> Controller Class Initialized
INFO - 2016-10-03 08:56:35 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:35 --> Model Class Initialized
INFO - 2016-10-03 08:56:35 --> Model Class Initialized
INFO - 2016-10-03 08:56:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:35 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:35 --> Total execution time: 0.0626
INFO - 2016-10-03 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:35 --> Controller Class Initialized
INFO - 2016-10-03 08:56:35 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:35 --> Model Class Initialized
INFO - 2016-10-03 08:56:35 --> Model Class Initialized
INFO - 2016-10-03 08:56:35 --> Model Class Initialized
INFO - 2016-10-03 08:56:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:35 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:35 --> Total execution time: 0.1332
INFO - 2016-10-03 08:56:39 --> Config Class Initialized
INFO - 2016-10-03 08:56:39 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:39 --> Config Class Initialized
INFO - 2016-10-03 08:56:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:39 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:56:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:39 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:39 --> URI Class Initialized
INFO - 2016-10-03 08:56:39 --> URI Class Initialized
INFO - 2016-10-03 08:56:39 --> Router Class Initialized
INFO - 2016-10-03 08:56:39 --> Router Class Initialized
INFO - 2016-10-03 08:56:39 --> Output Class Initialized
INFO - 2016-10-03 08:56:39 --> Output Class Initialized
INFO - 2016-10-03 08:56:39 --> Security Class Initialized
INFO - 2016-10-03 08:56:39 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:39 --> Input Class Initialized
DEBUG - 2016-10-03 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:39 --> Language Class Initialized
INFO - 2016-10-03 08:56:39 --> Input Class Initialized
INFO - 2016-10-03 08:56:39 --> Language Class Initialized
INFO - 2016-10-03 08:56:39 --> Loader Class Initialized
INFO - 2016-10-03 08:56:39 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:39 --> Loader Class Initialized
INFO - 2016-10-03 08:56:39 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:39 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:39 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:39 --> Controller Class Initialized
INFO - 2016-10-03 08:56:39 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:39 --> Model Class Initialized
INFO - 2016-10-03 08:56:39 --> Model Class Initialized
INFO - 2016-10-03 08:56:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:39 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:39 --> Total execution time: 0.0613
INFO - 2016-10-03 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:39 --> Controller Class Initialized
INFO - 2016-10-03 08:56:39 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:39 --> Model Class Initialized
INFO - 2016-10-03 08:56:39 --> Model Class Initialized
INFO - 2016-10-03 08:56:39 --> Model Class Initialized
INFO - 2016-10-03 08:56:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:39 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:39 --> Total execution time: 0.1309
INFO - 2016-10-03 08:56:43 --> Config Class Initialized
INFO - 2016-10-03 08:56:43 --> Config Class Initialized
INFO - 2016-10-03 08:56:43 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:56:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:43 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:43 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:43 --> URI Class Initialized
INFO - 2016-10-03 08:56:43 --> URI Class Initialized
INFO - 2016-10-03 08:56:43 --> Router Class Initialized
INFO - 2016-10-03 08:56:43 --> Router Class Initialized
INFO - 2016-10-03 08:56:43 --> Output Class Initialized
INFO - 2016-10-03 08:56:43 --> Output Class Initialized
INFO - 2016-10-03 08:56:43 --> Security Class Initialized
INFO - 2016-10-03 08:56:43 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:43 --> Input Class Initialized
DEBUG - 2016-10-03 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:43 --> Language Class Initialized
INFO - 2016-10-03 08:56:43 --> Input Class Initialized
INFO - 2016-10-03 08:56:43 --> Language Class Initialized
INFO - 2016-10-03 08:56:43 --> Loader Class Initialized
INFO - 2016-10-03 08:56:43 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:43 --> Loader Class Initialized
INFO - 2016-10-03 08:56:43 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:43 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:43 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:43 --> Controller Class Initialized
INFO - 2016-10-03 08:56:43 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:43 --> Model Class Initialized
INFO - 2016-10-03 08:56:43 --> Model Class Initialized
INFO - 2016-10-03 08:56:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:43 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:43 --> Total execution time: 0.0646
INFO - 2016-10-03 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:43 --> Controller Class Initialized
INFO - 2016-10-03 08:56:43 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:43 --> Model Class Initialized
INFO - 2016-10-03 08:56:43 --> Model Class Initialized
INFO - 2016-10-03 08:56:43 --> Model Class Initialized
INFO - 2016-10-03 08:56:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:43 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:43 --> Total execution time: 0.1328
INFO - 2016-10-03 08:56:48 --> Config Class Initialized
INFO - 2016-10-03 08:56:48 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:48 --> Config Class Initialized
INFO - 2016-10-03 08:56:48 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:48 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:48 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:56:48 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:48 --> URI Class Initialized
INFO - 2016-10-03 08:56:48 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:48 --> URI Class Initialized
INFO - 2016-10-03 08:56:48 --> Router Class Initialized
INFO - 2016-10-03 08:56:48 --> Router Class Initialized
INFO - 2016-10-03 08:56:48 --> Output Class Initialized
INFO - 2016-10-03 08:56:48 --> Security Class Initialized
INFO - 2016-10-03 08:56:48 --> Output Class Initialized
DEBUG - 2016-10-03 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:48 --> Security Class Initialized
INFO - 2016-10-03 08:56:48 --> Input Class Initialized
INFO - 2016-10-03 08:56:48 --> Language Class Initialized
DEBUG - 2016-10-03 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:48 --> Input Class Initialized
INFO - 2016-10-03 08:56:48 --> Language Class Initialized
INFO - 2016-10-03 08:56:48 --> Loader Class Initialized
INFO - 2016-10-03 08:56:48 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:48 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:48 --> Loader Class Initialized
INFO - 2016-10-03 08:56:48 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:48 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:48 --> Controller Class Initialized
INFO - 2016-10-03 08:56:48 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:48 --> Model Class Initialized
INFO - 2016-10-03 08:56:48 --> Model Class Initialized
INFO - 2016-10-03 08:56:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:48 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:48 --> Total execution time: 0.0631
INFO - 2016-10-03 08:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:48 --> Controller Class Initialized
INFO - 2016-10-03 08:56:48 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:48 --> Model Class Initialized
INFO - 2016-10-03 08:56:48 --> Model Class Initialized
INFO - 2016-10-03 08:56:48 --> Model Class Initialized
INFO - 2016-10-03 08:56:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:48 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:48 --> Total execution time: 0.1255
INFO - 2016-10-03 08:56:57 --> Config Class Initialized
INFO - 2016-10-03 08:56:57 --> Hooks Class Initialized
INFO - 2016-10-03 08:56:57 --> Config Class Initialized
INFO - 2016-10-03 08:56:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:57 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:56:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:57 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:57 --> URI Class Initialized
INFO - 2016-10-03 08:56:57 --> URI Class Initialized
INFO - 2016-10-03 08:56:57 --> Router Class Initialized
INFO - 2016-10-03 08:56:57 --> Router Class Initialized
INFO - 2016-10-03 08:56:57 --> Output Class Initialized
INFO - 2016-10-03 08:56:57 --> Output Class Initialized
INFO - 2016-10-03 08:56:57 --> Security Class Initialized
INFO - 2016-10-03 08:56:57 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:57 --> Input Class Initialized
DEBUG - 2016-10-03 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:57 --> Language Class Initialized
INFO - 2016-10-03 08:56:57 --> Input Class Initialized
INFO - 2016-10-03 08:56:57 --> Language Class Initialized
INFO - 2016-10-03 08:56:57 --> Loader Class Initialized
INFO - 2016-10-03 08:56:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:57 --> Loader Class Initialized
INFO - 2016-10-03 08:56:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:57 --> Controller Class Initialized
INFO - 2016-10-03 08:56:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:57 --> Model Class Initialized
INFO - 2016-10-03 08:56:57 --> Model Class Initialized
INFO - 2016-10-03 08:56:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:57 --> Total execution time: 0.0635
INFO - 2016-10-03 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:57 --> Controller Class Initialized
INFO - 2016-10-03 08:56:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:57 --> Model Class Initialized
INFO - 2016-10-03 08:56:57 --> Model Class Initialized
INFO - 2016-10-03 08:56:57 --> Model Class Initialized
INFO - 2016-10-03 08:56:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:57 --> Total execution time: 0.1346
INFO - 2016-10-03 08:56:58 --> Config Class Initialized
INFO - 2016-10-03 08:56:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:56:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:56:58 --> Utf8 Class Initialized
INFO - 2016-10-03 08:56:58 --> URI Class Initialized
INFO - 2016-10-03 08:56:58 --> Router Class Initialized
INFO - 2016-10-03 08:56:58 --> Output Class Initialized
INFO - 2016-10-03 08:56:58 --> Security Class Initialized
DEBUG - 2016-10-03 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:56:58 --> Input Class Initialized
INFO - 2016-10-03 08:56:58 --> Language Class Initialized
INFO - 2016-10-03 08:56:58 --> Loader Class Initialized
INFO - 2016-10-03 08:56:58 --> Helper loaded: url_helper
INFO - 2016-10-03 08:56:58 --> Helper loaded: language_helper
INFO - 2016-10-03 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:56:58 --> Controller Class Initialized
INFO - 2016-10-03 08:56:58 --> Database Driver Class Initialized
INFO - 2016-10-03 08:56:58 --> Model Class Initialized
INFO - 2016-10-03 08:56:58 --> Model Class Initialized
INFO - 2016-10-03 08:56:58 --> Model Class Initialized
INFO - 2016-10-03 08:56:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:56:58 --> Final output sent to browser
DEBUG - 2016-10-03 08:56:58 --> Total execution time: 0.0703
INFO - 2016-10-03 08:57:02 --> Config Class Initialized
INFO - 2016-10-03 08:57:02 --> Config Class Initialized
INFO - 2016-10-03 08:57:02 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:57:02 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:02 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:02 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:02 --> URI Class Initialized
INFO - 2016-10-03 08:57:02 --> URI Class Initialized
INFO - 2016-10-03 08:57:02 --> Router Class Initialized
INFO - 2016-10-03 08:57:02 --> Router Class Initialized
INFO - 2016-10-03 08:57:02 --> Output Class Initialized
INFO - 2016-10-03 08:57:02 --> Output Class Initialized
INFO - 2016-10-03 08:57:02 --> Security Class Initialized
INFO - 2016-10-03 08:57:02 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:02 --> Input Class Initialized
DEBUG - 2016-10-03 08:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:02 --> Input Class Initialized
INFO - 2016-10-03 08:57:02 --> Language Class Initialized
INFO - 2016-10-03 08:57:02 --> Language Class Initialized
INFO - 2016-10-03 08:57:02 --> Loader Class Initialized
INFO - 2016-10-03 08:57:02 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:02 --> Loader Class Initialized
INFO - 2016-10-03 08:57:02 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:02 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:02 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:02 --> Controller Class Initialized
INFO - 2016-10-03 08:57:02 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:02 --> Model Class Initialized
INFO - 2016-10-03 08:57:02 --> Model Class Initialized
INFO - 2016-10-03 08:57:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:02 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:02 --> Total execution time: 0.0675
INFO - 2016-10-03 08:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:02 --> Controller Class Initialized
INFO - 2016-10-03 08:57:02 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:02 --> Model Class Initialized
INFO - 2016-10-03 08:57:02 --> Model Class Initialized
INFO - 2016-10-03 08:57:02 --> Model Class Initialized
INFO - 2016-10-03 08:57:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:02 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:02 --> Total execution time: 0.1362
INFO - 2016-10-03 08:57:16 --> Config Class Initialized
INFO - 2016-10-03 08:57:16 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:16 --> Config Class Initialized
INFO - 2016-10-03 08:57:16 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:16 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:16 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:57:16 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:16 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:16 --> URI Class Initialized
INFO - 2016-10-03 08:57:16 --> URI Class Initialized
INFO - 2016-10-03 08:57:16 --> Router Class Initialized
INFO - 2016-10-03 08:57:16 --> Router Class Initialized
INFO - 2016-10-03 08:57:16 --> Output Class Initialized
INFO - 2016-10-03 08:57:16 --> Output Class Initialized
INFO - 2016-10-03 08:57:16 --> Security Class Initialized
INFO - 2016-10-03 08:57:16 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:16 --> Input Class Initialized
DEBUG - 2016-10-03 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:16 --> Language Class Initialized
INFO - 2016-10-03 08:57:16 --> Input Class Initialized
INFO - 2016-10-03 08:57:16 --> Language Class Initialized
INFO - 2016-10-03 08:57:16 --> Loader Class Initialized
INFO - 2016-10-03 08:57:16 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:16 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:16 --> Loader Class Initialized
INFO - 2016-10-03 08:57:16 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:16 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:16 --> Controller Class Initialized
INFO - 2016-10-03 08:57:16 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:16 --> Model Class Initialized
INFO - 2016-10-03 08:57:16 --> Model Class Initialized
INFO - 2016-10-03 08:57:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:16 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:16 --> Total execution time: 0.0744
INFO - 2016-10-03 08:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:16 --> Controller Class Initialized
INFO - 2016-10-03 08:57:16 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:16 --> Model Class Initialized
INFO - 2016-10-03 08:57:16 --> Model Class Initialized
INFO - 2016-10-03 08:57:16 --> Model Class Initialized
INFO - 2016-10-03 08:57:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:16 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:16 --> Total execution time: 0.1436
INFO - 2016-10-03 08:57:23 --> Config Class Initialized
INFO - 2016-10-03 08:57:23 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:23 --> Config Class Initialized
INFO - 2016-10-03 08:57:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:23 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:57:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:23 --> URI Class Initialized
INFO - 2016-10-03 08:57:23 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:23 --> URI Class Initialized
INFO - 2016-10-03 08:57:23 --> Router Class Initialized
INFO - 2016-10-03 08:57:23 --> Router Class Initialized
INFO - 2016-10-03 08:57:23 --> Output Class Initialized
INFO - 2016-10-03 08:57:23 --> Output Class Initialized
INFO - 2016-10-03 08:57:23 --> Security Class Initialized
INFO - 2016-10-03 08:57:23 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:23 --> Input Class Initialized
INFO - 2016-10-03 08:57:23 --> Language Class Initialized
DEBUG - 2016-10-03 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:23 --> Input Class Initialized
INFO - 2016-10-03 08:57:23 --> Language Class Initialized
INFO - 2016-10-03 08:57:23 --> Loader Class Initialized
INFO - 2016-10-03 08:57:23 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:23 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:23 --> Loader Class Initialized
INFO - 2016-10-03 08:57:23 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:23 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:23 --> Controller Class Initialized
INFO - 2016-10-03 08:57:23 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:23 --> Model Class Initialized
INFO - 2016-10-03 08:57:23 --> Model Class Initialized
INFO - 2016-10-03 08:57:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:23 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:23 --> Total execution time: 0.0674
INFO - 2016-10-03 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:23 --> Controller Class Initialized
INFO - 2016-10-03 08:57:23 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:23 --> Model Class Initialized
INFO - 2016-10-03 08:57:23 --> Model Class Initialized
INFO - 2016-10-03 08:57:23 --> Model Class Initialized
INFO - 2016-10-03 08:57:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:23 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:23 --> Total execution time: 0.1456
INFO - 2016-10-03 08:57:28 --> Config Class Initialized
INFO - 2016-10-03 08:57:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:28 --> URI Class Initialized
INFO - 2016-10-03 08:57:28 --> Router Class Initialized
INFO - 2016-10-03 08:57:28 --> Output Class Initialized
INFO - 2016-10-03 08:57:28 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:28 --> Input Class Initialized
INFO - 2016-10-03 08:57:28 --> Language Class Initialized
INFO - 2016-10-03 08:57:28 --> Loader Class Initialized
INFO - 2016-10-03 08:57:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:28 --> Controller Class Initialized
INFO - 2016-10-03 08:57:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:28 --> Total execution time: 0.0567
INFO - 2016-10-03 08:57:28 --> Config Class Initialized
INFO - 2016-10-03 08:57:28 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:28 --> Config Class Initialized
INFO - 2016-10-03 08:57:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:28 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:57:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:28 --> URI Class Initialized
INFO - 2016-10-03 08:57:28 --> URI Class Initialized
INFO - 2016-10-03 08:57:28 --> Router Class Initialized
INFO - 2016-10-03 08:57:28 --> Router Class Initialized
INFO - 2016-10-03 08:57:28 --> Output Class Initialized
INFO - 2016-10-03 08:57:28 --> Output Class Initialized
INFO - 2016-10-03 08:57:28 --> Security Class Initialized
INFO - 2016-10-03 08:57:28 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:28 --> Input Class Initialized
INFO - 2016-10-03 08:57:28 --> Language Class Initialized
DEBUG - 2016-10-03 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:28 --> Input Class Initialized
INFO - 2016-10-03 08:57:28 --> Language Class Initialized
INFO - 2016-10-03 08:57:28 --> Loader Class Initialized
INFO - 2016-10-03 08:57:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:28 --> Loader Class Initialized
INFO - 2016-10-03 08:57:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:28 --> Controller Class Initialized
INFO - 2016-10-03 08:57:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:28 --> Total execution time: 0.0688
INFO - 2016-10-03 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:28 --> Controller Class Initialized
INFO - 2016-10-03 08:57:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Model Class Initialized
INFO - 2016-10-03 08:57:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:28 --> Total execution time: 0.1427
INFO - 2016-10-03 08:57:41 --> Config Class Initialized
INFO - 2016-10-03 08:57:41 --> Config Class Initialized
INFO - 2016-10-03 08:57:41 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:57:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:41 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:41 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:41 --> URI Class Initialized
INFO - 2016-10-03 08:57:41 --> URI Class Initialized
INFO - 2016-10-03 08:57:41 --> Router Class Initialized
INFO - 2016-10-03 08:57:41 --> Router Class Initialized
INFO - 2016-10-03 08:57:41 --> Output Class Initialized
INFO - 2016-10-03 08:57:41 --> Output Class Initialized
INFO - 2016-10-03 08:57:41 --> Security Class Initialized
INFO - 2016-10-03 08:57:41 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:41 --> Input Class Initialized
DEBUG - 2016-10-03 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:41 --> Language Class Initialized
INFO - 2016-10-03 08:57:41 --> Input Class Initialized
INFO - 2016-10-03 08:57:41 --> Language Class Initialized
INFO - 2016-10-03 08:57:41 --> Loader Class Initialized
INFO - 2016-10-03 08:57:41 --> Loader Class Initialized
INFO - 2016-10-03 08:57:41 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:41 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:41 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:41 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:41 --> Controller Class Initialized
INFO - 2016-10-03 08:57:41 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:41 --> Model Class Initialized
INFO - 2016-10-03 08:57:41 --> Model Class Initialized
INFO - 2016-10-03 08:57:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:41 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:41 --> Total execution time: 0.0662
INFO - 2016-10-03 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:41 --> Controller Class Initialized
INFO - 2016-10-03 08:57:41 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:41 --> Model Class Initialized
INFO - 2016-10-03 08:57:41 --> Model Class Initialized
INFO - 2016-10-03 08:57:41 --> Model Class Initialized
INFO - 2016-10-03 08:57:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:41 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:41 --> Total execution time: 0.1369
INFO - 2016-10-03 08:57:46 --> Config Class Initialized
INFO - 2016-10-03 08:57:46 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:46 --> Config Class Initialized
INFO - 2016-10-03 08:57:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:46 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:46 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:57:46 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:46 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:46 --> URI Class Initialized
INFO - 2016-10-03 08:57:46 --> URI Class Initialized
INFO - 2016-10-03 08:57:46 --> Router Class Initialized
INFO - 2016-10-03 08:57:46 --> Router Class Initialized
INFO - 2016-10-03 08:57:46 --> Output Class Initialized
INFO - 2016-10-03 08:57:46 --> Output Class Initialized
INFO - 2016-10-03 08:57:46 --> Security Class Initialized
INFO - 2016-10-03 08:57:46 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:46 --> Input Class Initialized
INFO - 2016-10-03 08:57:46 --> Language Class Initialized
DEBUG - 2016-10-03 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:46 --> Input Class Initialized
INFO - 2016-10-03 08:57:46 --> Language Class Initialized
INFO - 2016-10-03 08:57:46 --> Loader Class Initialized
INFO - 2016-10-03 08:57:46 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:46 --> Loader Class Initialized
INFO - 2016-10-03 08:57:46 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:46 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:46 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:46 --> Controller Class Initialized
INFO - 2016-10-03 08:57:46 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:46 --> Model Class Initialized
INFO - 2016-10-03 08:57:46 --> Model Class Initialized
INFO - 2016-10-03 08:57:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:46 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:46 --> Total execution time: 0.0617
INFO - 2016-10-03 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:46 --> Controller Class Initialized
INFO - 2016-10-03 08:57:46 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:46 --> Model Class Initialized
INFO - 2016-10-03 08:57:46 --> Model Class Initialized
INFO - 2016-10-03 08:57:46 --> Model Class Initialized
INFO - 2016-10-03 08:57:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:46 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:46 --> Total execution time: 0.1288
INFO - 2016-10-03 08:57:49 --> Config Class Initialized
INFO - 2016-10-03 08:57:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:49 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:49 --> URI Class Initialized
INFO - 2016-10-03 08:57:49 --> Router Class Initialized
INFO - 2016-10-03 08:57:49 --> Output Class Initialized
INFO - 2016-10-03 08:57:49 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:49 --> Input Class Initialized
INFO - 2016-10-03 08:57:49 --> Language Class Initialized
INFO - 2016-10-03 08:57:49 --> Loader Class Initialized
INFO - 2016-10-03 08:57:49 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:49 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:49 --> Controller Class Initialized
INFO - 2016-10-03 08:57:50 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:50 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:50 --> Total execution time: 0.1144
INFO - 2016-10-03 08:57:50 --> Config Class Initialized
INFO - 2016-10-03 08:57:50 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:50 --> Config Class Initialized
INFO - 2016-10-03 08:57:50 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:50 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:50 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:57:50 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:50 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:50 --> URI Class Initialized
INFO - 2016-10-03 08:57:50 --> Config Class Initialized
INFO - 2016-10-03 08:57:50 --> URI Class Initialized
INFO - 2016-10-03 08:57:50 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:50 --> Router Class Initialized
INFO - 2016-10-03 08:57:50 --> Output Class Initialized
INFO - 2016-10-03 08:57:50 --> Router Class Initialized
DEBUG - 2016-10-03 08:57:50 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:50 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:50 --> Security Class Initialized
INFO - 2016-10-03 08:57:50 --> Output Class Initialized
DEBUG - 2016-10-03 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:50 --> URI Class Initialized
INFO - 2016-10-03 08:57:50 --> Input Class Initialized
INFO - 2016-10-03 08:57:50 --> Security Class Initialized
INFO - 2016-10-03 08:57:50 --> Language Class Initialized
INFO - 2016-10-03 08:57:50 --> Router Class Initialized
INFO - 2016-10-03 08:57:50 --> Output Class Initialized
DEBUG - 2016-10-03 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:50 --> Input Class Initialized
INFO - 2016-10-03 08:57:50 --> Loader Class Initialized
INFO - 2016-10-03 08:57:50 --> Security Class Initialized
INFO - 2016-10-03 08:57:50 --> Language Class Initialized
INFO - 2016-10-03 08:57:50 --> Helper loaded: url_helper
DEBUG - 2016-10-03 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:50 --> Input Class Initialized
INFO - 2016-10-03 08:57:50 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:50 --> Language Class Initialized
INFO - 2016-10-03 08:57:50 --> Loader Class Initialized
INFO - 2016-10-03 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:50 --> Controller Class Initialized
INFO - 2016-10-03 08:57:50 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:50 --> Loader Class Initialized
INFO - 2016-10-03 08:57:50 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:50 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:50 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:50 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:50 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:50 --> Total execution time: 0.0789
INFO - 2016-10-03 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:50 --> Controller Class Initialized
INFO - 2016-10-03 08:57:50 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Model Class Initialized
INFO - 2016-10-03 08:57:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:51 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:51 --> Total execution time: 0.1526
INFO - 2016-10-03 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:51 --> Controller Class Initialized
INFO - 2016-10-03 08:57:51 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:51 --> Model Class Initialized
INFO - 2016-10-03 08:57:51 --> Model Class Initialized
INFO - 2016-10-03 08:57:51 --> Model Class Initialized
INFO - 2016-10-03 08:57:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:51 --> Config Class Initialized
INFO - 2016-10-03 08:57:51 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:51 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:51 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:51 --> URI Class Initialized
INFO - 2016-10-03 08:57:51 --> Router Class Initialized
INFO - 2016-10-03 08:57:51 --> Output Class Initialized
INFO - 2016-10-03 08:57:51 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:51 --> Input Class Initialized
INFO - 2016-10-03 08:57:51 --> Language Class Initialized
INFO - 2016-10-03 08:57:51 --> Loader Class Initialized
INFO - 2016-10-03 08:57:51 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:51 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:51 --> Controller Class Initialized
INFO - 2016-10-03 08:57:51 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:51 --> Model Class Initialized
INFO - 2016-10-03 08:57:51 --> Model Class Initialized
INFO - 2016-10-03 08:57:51 --> Model Class Initialized
INFO - 2016-10-03 08:57:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2016-10-03 08:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:57:51 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:51 --> Total execution time: 0.0888
INFO - 2016-10-03 08:57:56 --> Config Class Initialized
INFO - 2016-10-03 08:57:56 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:56 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:56 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:56 --> URI Class Initialized
INFO - 2016-10-03 08:57:56 --> Router Class Initialized
INFO - 2016-10-03 08:57:56 --> Output Class Initialized
INFO - 2016-10-03 08:57:56 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:56 --> Input Class Initialized
INFO - 2016-10-03 08:57:56 --> Language Class Initialized
INFO - 2016-10-03 08:57:56 --> Loader Class Initialized
INFO - 2016-10-03 08:57:56 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:56 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:57 --> Controller Class Initialized
INFO - 2016-10-03 08:57:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:57 --> Config Class Initialized
INFO - 2016-10-03 08:57:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:57 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:57 --> URI Class Initialized
INFO - 2016-10-03 08:57:57 --> Router Class Initialized
INFO - 2016-10-03 08:57:57 --> Output Class Initialized
INFO - 2016-10-03 08:57:57 --> Security Class Initialized
DEBUG - 2016-10-03 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:57 --> Input Class Initialized
INFO - 2016-10-03 08:57:57 --> Language Class Initialized
INFO - 2016-10-03 08:57:57 --> Loader Class Initialized
INFO - 2016-10-03 08:57:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:57 --> Controller Class Initialized
INFO - 2016-10-03 08:57:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:57:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2016-10-03 08:57:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:57:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:57 --> Total execution time: 0.0756
INFO - 2016-10-03 08:57:57 --> Config Class Initialized
INFO - 2016-10-03 08:57:57 --> Hooks Class Initialized
INFO - 2016-10-03 08:57:57 --> Config Class Initialized
INFO - 2016-10-03 08:57:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:57:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:57 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:57 --> URI Class Initialized
INFO - 2016-10-03 08:57:57 --> Router Class Initialized
DEBUG - 2016-10-03 08:57:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:57:57 --> Utf8 Class Initialized
INFO - 2016-10-03 08:57:57 --> Output Class Initialized
INFO - 2016-10-03 08:57:57 --> URI Class Initialized
INFO - 2016-10-03 08:57:57 --> Security Class Initialized
INFO - 2016-10-03 08:57:57 --> Router Class Initialized
DEBUG - 2016-10-03 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:57 --> Input Class Initialized
INFO - 2016-10-03 08:57:57 --> Language Class Initialized
INFO - 2016-10-03 08:57:57 --> Output Class Initialized
INFO - 2016-10-03 08:57:57 --> Security Class Initialized
INFO - 2016-10-03 08:57:57 --> Loader Class Initialized
DEBUG - 2016-10-03 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:57:57 --> Input Class Initialized
INFO - 2016-10-03 08:57:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:57 --> Language Class Initialized
INFO - 2016-10-03 08:57:57 --> Loader Class Initialized
INFO - 2016-10-03 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:57 --> Controller Class Initialized
INFO - 2016-10-03 08:57:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:57:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:57:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:57:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:57 --> Total execution time: 0.0761
INFO - 2016-10-03 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:57:57 --> Controller Class Initialized
INFO - 2016-10-03 08:57:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Model Class Initialized
INFO - 2016-10-03 08:57:57 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:57:57 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:57:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:57:57 --> Total execution time: 0.1054
INFO - 2016-10-03 08:58:05 --> Config Class Initialized
INFO - 2016-10-03 08:58:05 --> Hooks Class Initialized
INFO - 2016-10-03 08:58:05 --> Config Class Initialized
DEBUG - 2016-10-03 08:58:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:05 --> Hooks Class Initialized
INFO - 2016-10-03 08:58:05 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:05 --> URI Class Initialized
DEBUG - 2016-10-03 08:58:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:05 --> Router Class Initialized
INFO - 2016-10-03 08:58:05 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:05 --> URI Class Initialized
INFO - 2016-10-03 08:58:05 --> Output Class Initialized
INFO - 2016-10-03 08:58:05 --> Router Class Initialized
INFO - 2016-10-03 08:58:05 --> Security Class Initialized
DEBUG - 2016-10-03 08:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:05 --> Output Class Initialized
INFO - 2016-10-03 08:58:05 --> Input Class Initialized
INFO - 2016-10-03 08:58:05 --> Language Class Initialized
INFO - 2016-10-03 08:58:05 --> Security Class Initialized
DEBUG - 2016-10-03 08:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:05 --> Input Class Initialized
INFO - 2016-10-03 08:58:05 --> Loader Class Initialized
INFO - 2016-10-03 08:58:05 --> Language Class Initialized
INFO - 2016-10-03 08:58:05 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:05 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:05 --> Loader Class Initialized
INFO - 2016-10-03 08:58:05 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:05 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:05 --> Controller Class Initialized
INFO - 2016-10-03 08:58:05 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:05 --> Model Class Initialized
INFO - 2016-10-03 08:58:05 --> Model Class Initialized
INFO - 2016-10-03 08:58:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:05 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:05 --> Total execution time: 0.0661
INFO - 2016-10-03 08:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:05 --> Controller Class Initialized
INFO - 2016-10-03 08:58:05 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:05 --> Model Class Initialized
INFO - 2016-10-03 08:58:05 --> Model Class Initialized
INFO - 2016-10-03 08:58:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:05 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:05 --> Total execution time: 0.0890
INFO - 2016-10-03 08:58:14 --> Config Class Initialized
INFO - 2016-10-03 08:58:14 --> Hooks Class Initialized
INFO - 2016-10-03 08:58:14 --> Config Class Initialized
INFO - 2016-10-03 08:58:14 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:58:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:14 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:58:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:14 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:14 --> URI Class Initialized
INFO - 2016-10-03 08:58:14 --> URI Class Initialized
INFO - 2016-10-03 08:58:14 --> Router Class Initialized
INFO - 2016-10-03 08:58:14 --> Router Class Initialized
INFO - 2016-10-03 08:58:14 --> Output Class Initialized
INFO - 2016-10-03 08:58:14 --> Output Class Initialized
INFO - 2016-10-03 08:58:14 --> Security Class Initialized
INFO - 2016-10-03 08:58:14 --> Security Class Initialized
DEBUG - 2016-10-03 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:14 --> Input Class Initialized
INFO - 2016-10-03 08:58:14 --> Language Class Initialized
DEBUG - 2016-10-03 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:14 --> Input Class Initialized
INFO - 2016-10-03 08:58:14 --> Language Class Initialized
INFO - 2016-10-03 08:58:14 --> Loader Class Initialized
INFO - 2016-10-03 08:58:14 --> Loader Class Initialized
INFO - 2016-10-03 08:58:14 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:14 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:14 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:14 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:14 --> Controller Class Initialized
INFO - 2016-10-03 08:58:14 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:14 --> Model Class Initialized
INFO - 2016-10-03 08:58:14 --> Model Class Initialized
INFO - 2016-10-03 08:58:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:14 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:14 --> Total execution time: 0.0659
INFO - 2016-10-03 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:14 --> Controller Class Initialized
INFO - 2016-10-03 08:58:14 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:14 --> Model Class Initialized
INFO - 2016-10-03 08:58:14 --> Model Class Initialized
INFO - 2016-10-03 08:58:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:14 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:14 --> Total execution time: 0.1015
INFO - 2016-10-03 08:58:19 --> Config Class Initialized
INFO - 2016-10-03 08:58:19 --> Config Class Initialized
INFO - 2016-10-03 08:58:19 --> Hooks Class Initialized
INFO - 2016-10-03 08:58:19 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:58:19 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 08:58:19 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:19 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:19 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:19 --> URI Class Initialized
INFO - 2016-10-03 08:58:19 --> URI Class Initialized
INFO - 2016-10-03 08:58:19 --> Router Class Initialized
INFO - 2016-10-03 08:58:19 --> Router Class Initialized
INFO - 2016-10-03 08:58:19 --> Output Class Initialized
INFO - 2016-10-03 08:58:19 --> Output Class Initialized
INFO - 2016-10-03 08:58:19 --> Security Class Initialized
INFO - 2016-10-03 08:58:19 --> Security Class Initialized
DEBUG - 2016-10-03 08:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-03 08:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:19 --> Input Class Initialized
INFO - 2016-10-03 08:58:19 --> Input Class Initialized
INFO - 2016-10-03 08:58:19 --> Language Class Initialized
INFO - 2016-10-03 08:58:19 --> Language Class Initialized
INFO - 2016-10-03 08:58:19 --> Loader Class Initialized
INFO - 2016-10-03 08:58:19 --> Loader Class Initialized
INFO - 2016-10-03 08:58:19 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:19 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:19 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:19 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:19 --> Controller Class Initialized
INFO - 2016-10-03 08:58:19 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:19 --> Model Class Initialized
INFO - 2016-10-03 08:58:19 --> Model Class Initialized
INFO - 2016-10-03 08:58:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:19 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:19 --> Total execution time: 0.0687
INFO - 2016-10-03 08:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:19 --> Controller Class Initialized
INFO - 2016-10-03 08:58:19 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:19 --> Model Class Initialized
INFO - 2016-10-03 08:58:19 --> Model Class Initialized
INFO - 2016-10-03 08:58:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:19 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:19 --> Total execution time: 0.1103
INFO - 2016-10-03 08:58:27 --> Config Class Initialized
INFO - 2016-10-03 08:58:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:58:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:27 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:27 --> URI Class Initialized
INFO - 2016-10-03 08:58:27 --> Router Class Initialized
INFO - 2016-10-03 08:58:27 --> Output Class Initialized
INFO - 2016-10-03 08:58:27 --> Security Class Initialized
DEBUG - 2016-10-03 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:27 --> Input Class Initialized
INFO - 2016-10-03 08:58:27 --> Language Class Initialized
INFO - 2016-10-03 08:58:27 --> Loader Class Initialized
INFO - 2016-10-03 08:58:27 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:27 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:27 --> Controller Class Initialized
INFO - 2016-10-03 08:58:27 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:27 --> Model Class Initialized
INFO - 2016-10-03 08:58:27 --> Model Class Initialized
INFO - 2016-10-03 08:58:27 --> Model Class Initialized
INFO - 2016-10-03 08:58:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:27 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:27 --> Total execution time: 0.0587
INFO - 2016-10-03 08:58:57 --> Config Class Initialized
INFO - 2016-10-03 08:58:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:58:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:57 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:57 --> URI Class Initialized
INFO - 2016-10-03 08:58:57 --> Router Class Initialized
INFO - 2016-10-03 08:58:57 --> Output Class Initialized
INFO - 2016-10-03 08:58:57 --> Security Class Initialized
DEBUG - 2016-10-03 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:57 --> Input Class Initialized
INFO - 2016-10-03 08:58:57 --> Language Class Initialized
INFO - 2016-10-03 08:58:57 --> Loader Class Initialized
INFO - 2016-10-03 08:58:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:57 --> Controller Class Initialized
INFO - 2016-10-03 08:58:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:57 --> Model Class Initialized
INFO - 2016-10-03 08:58:57 --> Model Class Initialized
INFO - 2016-10-03 08:58:57 --> Model Class Initialized
INFO - 2016-10-03 08:58:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:57 --> Total execution time: 0.0596
INFO - 2016-10-03 08:58:59 --> Config Class Initialized
INFO - 2016-10-03 08:58:59 --> Hooks Class Initialized
INFO - 2016-10-03 08:58:59 --> Config Class Initialized
INFO - 2016-10-03 08:58:59 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:58:59 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:59 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:59 --> URI Class Initialized
DEBUG - 2016-10-03 08:58:59 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:58:59 --> Utf8 Class Initialized
INFO - 2016-10-03 08:58:59 --> Router Class Initialized
INFO - 2016-10-03 08:58:59 --> URI Class Initialized
INFO - 2016-10-03 08:58:59 --> Output Class Initialized
INFO - 2016-10-03 08:58:59 --> Router Class Initialized
INFO - 2016-10-03 08:58:59 --> Security Class Initialized
INFO - 2016-10-03 08:58:59 --> Output Class Initialized
DEBUG - 2016-10-03 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:59 --> Input Class Initialized
INFO - 2016-10-03 08:58:59 --> Security Class Initialized
INFO - 2016-10-03 08:58:59 --> Language Class Initialized
DEBUG - 2016-10-03 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:58:59 --> Input Class Initialized
INFO - 2016-10-03 08:58:59 --> Language Class Initialized
INFO - 2016-10-03 08:58:59 --> Loader Class Initialized
INFO - 2016-10-03 08:58:59 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:59 --> Loader Class Initialized
INFO - 2016-10-03 08:58:59 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:59 --> Helper loaded: url_helper
INFO - 2016-10-03 08:58:59 --> Helper loaded: language_helper
INFO - 2016-10-03 08:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:59 --> Controller Class Initialized
INFO - 2016-10-03 08:58:59 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:59 --> Model Class Initialized
INFO - 2016-10-03 08:58:59 --> Model Class Initialized
INFO - 2016-10-03 08:58:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:59 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:59 --> Total execution time: 0.0675
INFO - 2016-10-03 08:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:58:59 --> Controller Class Initialized
INFO - 2016-10-03 08:58:59 --> Database Driver Class Initialized
INFO - 2016-10-03 08:58:59 --> Model Class Initialized
INFO - 2016-10-03 08:58:59 --> Model Class Initialized
INFO - 2016-10-03 08:58:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:58:59 --> Final output sent to browser
DEBUG - 2016-10-03 08:58:59 --> Total execution time: 0.1067
INFO - 2016-10-03 08:59:04 --> Config Class Initialized
INFO - 2016-10-03 08:59:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:04 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:04 --> URI Class Initialized
INFO - 2016-10-03 08:59:04 --> Router Class Initialized
INFO - 2016-10-03 08:59:04 --> Output Class Initialized
INFO - 2016-10-03 08:59:04 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:04 --> Input Class Initialized
INFO - 2016-10-03 08:59:04 --> Language Class Initialized
INFO - 2016-10-03 08:59:04 --> Loader Class Initialized
INFO - 2016-10-03 08:59:04 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:04 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:04 --> Controller Class Initialized
INFO - 2016-10-03 08:59:04 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:04 --> Model Class Initialized
INFO - 2016-10-03 08:59:04 --> Model Class Initialized
INFO - 2016-10-03 08:59:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:04 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:04 --> Total execution time: 0.0966
INFO - 2016-10-03 08:59:05 --> Config Class Initialized
INFO - 2016-10-03 08:59:05 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:05 --> Config Class Initialized
INFO - 2016-10-03 08:59:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:05 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:59:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:05 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:05 --> URI Class Initialized
INFO - 2016-10-03 08:59:05 --> Config Class Initialized
INFO - 2016-10-03 08:59:05 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:05 --> URI Class Initialized
INFO - 2016-10-03 08:59:05 --> Router Class Initialized
INFO - 2016-10-03 08:59:05 --> Router Class Initialized
DEBUG - 2016-10-03 08:59:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:05 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:05 --> Output Class Initialized
INFO - 2016-10-03 08:59:05 --> Output Class Initialized
INFO - 2016-10-03 08:59:05 --> URI Class Initialized
INFO - 2016-10-03 08:59:05 --> Security Class Initialized
INFO - 2016-10-03 08:59:05 --> Router Class Initialized
INFO - 2016-10-03 08:59:05 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:05 --> Input Class Initialized
INFO - 2016-10-03 08:59:05 --> Output Class Initialized
INFO - 2016-10-03 08:59:05 --> Language Class Initialized
DEBUG - 2016-10-03 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:05 --> Input Class Initialized
INFO - 2016-10-03 08:59:05 --> Language Class Initialized
INFO - 2016-10-03 08:59:05 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:05 --> Input Class Initialized
INFO - 2016-10-03 08:59:05 --> Loader Class Initialized
INFO - 2016-10-03 08:59:05 --> Language Class Initialized
INFO - 2016-10-03 08:59:05 --> Loader Class Initialized
INFO - 2016-10-03 08:59:05 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:05 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:05 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:05 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:05 --> Loader Class Initialized
INFO - 2016-10-03 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:05 --> Controller Class Initialized
INFO - 2016-10-03 08:59:05 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:05 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:05 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:05 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:05 --> Total execution time: 0.0894
INFO - 2016-10-03 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:05 --> Controller Class Initialized
INFO - 2016-10-03 08:59:05 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:05 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:05 --> Total execution time: 0.1462
INFO - 2016-10-03 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:05 --> Controller Class Initialized
INFO - 2016-10-03 08:59:05 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:05 --> Config Class Initialized
INFO - 2016-10-03 08:59:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:05 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:05 --> URI Class Initialized
INFO - 2016-10-03 08:59:05 --> Router Class Initialized
INFO - 2016-10-03 08:59:05 --> Output Class Initialized
INFO - 2016-10-03 08:59:05 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:05 --> Input Class Initialized
INFO - 2016-10-03 08:59:05 --> Language Class Initialized
INFO - 2016-10-03 08:59:05 --> Loader Class Initialized
INFO - 2016-10-03 08:59:05 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:05 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:05 --> Controller Class Initialized
INFO - 2016-10-03 08:59:05 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Model Class Initialized
INFO - 2016-10-03 08:59:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:59:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2016-10-03 08:59:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:59:05 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:05 --> Total execution time: 0.0804
INFO - 2016-10-03 08:59:09 --> Config Class Initialized
INFO - 2016-10-03 08:59:09 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:09 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:09 --> URI Class Initialized
INFO - 2016-10-03 08:59:09 --> Router Class Initialized
INFO - 2016-10-03 08:59:09 --> Output Class Initialized
INFO - 2016-10-03 08:59:09 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:09 --> Input Class Initialized
INFO - 2016-10-03 08:59:09 --> Language Class Initialized
INFO - 2016-10-03 08:59:09 --> Loader Class Initialized
INFO - 2016-10-03 08:59:09 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:09 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:09 --> Controller Class Initialized
INFO - 2016-10-03 08:59:09 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:09 --> Config Class Initialized
INFO - 2016-10-03 08:59:09 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:09 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:09 --> URI Class Initialized
INFO - 2016-10-03 08:59:09 --> Router Class Initialized
INFO - 2016-10-03 08:59:09 --> Output Class Initialized
INFO - 2016-10-03 08:59:09 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:09 --> Input Class Initialized
INFO - 2016-10-03 08:59:09 --> Language Class Initialized
INFO - 2016-10-03 08:59:09 --> Loader Class Initialized
INFO - 2016-10-03 08:59:09 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:09 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:09 --> Controller Class Initialized
INFO - 2016-10-03 08:59:09 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06_attempt.php
INFO - 2016-10-03 08:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:59:09 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:09 --> Total execution time: 0.0660
INFO - 2016-10-03 08:59:09 --> Config Class Initialized
INFO - 2016-10-03 08:59:09 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:09 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:09 --> Config Class Initialized
INFO - 2016-10-03 08:59:09 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:09 --> URI Class Initialized
INFO - 2016-10-03 08:59:09 --> Router Class Initialized
DEBUG - 2016-10-03 08:59:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:09 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:09 --> Output Class Initialized
INFO - 2016-10-03 08:59:09 --> URI Class Initialized
INFO - 2016-10-03 08:59:09 --> Security Class Initialized
INFO - 2016-10-03 08:59:09 --> Router Class Initialized
DEBUG - 2016-10-03 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:09 --> Input Class Initialized
INFO - 2016-10-03 08:59:09 --> Language Class Initialized
INFO - 2016-10-03 08:59:09 --> Output Class Initialized
INFO - 2016-10-03 08:59:09 --> Security Class Initialized
INFO - 2016-10-03 08:59:09 --> Loader Class Initialized
DEBUG - 2016-10-03 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:09 --> Input Class Initialized
INFO - 2016-10-03 08:59:09 --> Language Class Initialized
INFO - 2016-10-03 08:59:09 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:09 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:09 --> Loader Class Initialized
INFO - 2016-10-03 08:59:09 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:09 --> Controller Class Initialized
INFO - 2016-10-03 08:59:09 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:09 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:09 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:09 --> Total execution time: 0.0755
INFO - 2016-10-03 08:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:09 --> Controller Class Initialized
INFO - 2016-10-03 08:59:09 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Model Class Initialized
INFO - 2016-10-03 08:59:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:59:09 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:59:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:59:09 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:09 --> Total execution time: 0.1028
INFO - 2016-10-03 08:59:13 --> Config Class Initialized
INFO - 2016-10-03 08:59:13 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:13 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:13 --> Config Class Initialized
INFO - 2016-10-03 08:59:13 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:13 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:13 --> URI Class Initialized
DEBUG - 2016-10-03 08:59:13 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:13 --> Router Class Initialized
INFO - 2016-10-03 08:59:13 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:13 --> URI Class Initialized
INFO - 2016-10-03 08:59:13 --> Output Class Initialized
INFO - 2016-10-03 08:59:13 --> Router Class Initialized
INFO - 2016-10-03 08:59:13 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:13 --> Output Class Initialized
INFO - 2016-10-03 08:59:13 --> Input Class Initialized
INFO - 2016-10-03 08:59:13 --> Language Class Initialized
INFO - 2016-10-03 08:59:13 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:13 --> Input Class Initialized
INFO - 2016-10-03 08:59:13 --> Loader Class Initialized
INFO - 2016-10-03 08:59:13 --> Language Class Initialized
INFO - 2016-10-03 08:59:13 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:13 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:13 --> Loader Class Initialized
INFO - 2016-10-03 08:59:13 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:13 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:13 --> Controller Class Initialized
INFO - 2016-10-03 08:59:13 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:13 --> Model Class Initialized
INFO - 2016-10-03 08:59:13 --> Model Class Initialized
INFO - 2016-10-03 08:59:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:13 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:13 --> Total execution time: 0.0661
INFO - 2016-10-03 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:13 --> Controller Class Initialized
INFO - 2016-10-03 08:59:13 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:13 --> Model Class Initialized
INFO - 2016-10-03 08:59:13 --> Model Class Initialized
INFO - 2016-10-03 08:59:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:13 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:13 --> Total execution time: 0.0892
INFO - 2016-10-03 08:59:15 --> Config Class Initialized
INFO - 2016-10-03 08:59:15 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:16 --> Config Class Initialized
INFO - 2016-10-03 08:59:16 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:16 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:16 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:16 --> URI Class Initialized
DEBUG - 2016-10-03 08:59:16 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:16 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:16 --> Router Class Initialized
INFO - 2016-10-03 08:59:16 --> URI Class Initialized
INFO - 2016-10-03 08:59:16 --> Output Class Initialized
INFO - 2016-10-03 08:59:16 --> Router Class Initialized
INFO - 2016-10-03 08:59:16 --> Security Class Initialized
INFO - 2016-10-03 08:59:16 --> Output Class Initialized
DEBUG - 2016-10-03 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:16 --> Input Class Initialized
INFO - 2016-10-03 08:59:16 --> Security Class Initialized
INFO - 2016-10-03 08:59:16 --> Language Class Initialized
DEBUG - 2016-10-03 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:16 --> Input Class Initialized
INFO - 2016-10-03 08:59:16 --> Language Class Initialized
INFO - 2016-10-03 08:59:16 --> Loader Class Initialized
INFO - 2016-10-03 08:59:16 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:16 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:16 --> Loader Class Initialized
INFO - 2016-10-03 08:59:16 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:16 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:16 --> Controller Class Initialized
INFO - 2016-10-03 08:59:16 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:16 --> Model Class Initialized
INFO - 2016-10-03 08:59:16 --> Model Class Initialized
INFO - 2016-10-03 08:59:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:16 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:16 --> Total execution time: 0.0695
INFO - 2016-10-03 08:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:16 --> Controller Class Initialized
INFO - 2016-10-03 08:59:16 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:16 --> Model Class Initialized
INFO - 2016-10-03 08:59:16 --> Model Class Initialized
INFO - 2016-10-03 08:59:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:16 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:16 --> Total execution time: 0.1042
INFO - 2016-10-03 08:59:18 --> Config Class Initialized
INFO - 2016-10-03 08:59:18 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:18 --> Config Class Initialized
INFO - 2016-10-03 08:59:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:18 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:18 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:18 --> URI Class Initialized
INFO - 2016-10-03 08:59:18 --> URI Class Initialized
INFO - 2016-10-03 08:59:18 --> Router Class Initialized
INFO - 2016-10-03 08:59:18 --> Router Class Initialized
INFO - 2016-10-03 08:59:18 --> Output Class Initialized
INFO - 2016-10-03 08:59:18 --> Output Class Initialized
INFO - 2016-10-03 08:59:18 --> Security Class Initialized
INFO - 2016-10-03 08:59:18 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-03 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:18 --> Input Class Initialized
INFO - 2016-10-03 08:59:18 --> Input Class Initialized
INFO - 2016-10-03 08:59:18 --> Language Class Initialized
INFO - 2016-10-03 08:59:18 --> Language Class Initialized
INFO - 2016-10-03 08:59:18 --> Loader Class Initialized
INFO - 2016-10-03 08:59:18 --> Loader Class Initialized
INFO - 2016-10-03 08:59:18 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:18 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:18 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:18 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:18 --> Controller Class Initialized
INFO - 2016-10-03 08:59:18 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:18 --> Model Class Initialized
INFO - 2016-10-03 08:59:18 --> Model Class Initialized
INFO - 2016-10-03 08:59:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:18 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:18 --> Total execution time: 0.0852
INFO - 2016-10-03 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:18 --> Controller Class Initialized
INFO - 2016-10-03 08:59:18 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:18 --> Model Class Initialized
INFO - 2016-10-03 08:59:18 --> Model Class Initialized
INFO - 2016-10-03 08:59:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:18 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:18 --> Total execution time: 0.1064
INFO - 2016-10-03 08:59:20 --> Config Class Initialized
INFO - 2016-10-03 08:59:20 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:20 --> Config Class Initialized
INFO - 2016-10-03 08:59:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:20 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:59:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:20 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:20 --> URI Class Initialized
INFO - 2016-10-03 08:59:20 --> URI Class Initialized
INFO - 2016-10-03 08:59:20 --> Router Class Initialized
INFO - 2016-10-03 08:59:20 --> Router Class Initialized
INFO - 2016-10-03 08:59:20 --> Output Class Initialized
INFO - 2016-10-03 08:59:20 --> Output Class Initialized
INFO - 2016-10-03 08:59:20 --> Security Class Initialized
INFO - 2016-10-03 08:59:20 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:20 --> Input Class Initialized
DEBUG - 2016-10-03 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:20 --> Language Class Initialized
INFO - 2016-10-03 08:59:20 --> Input Class Initialized
INFO - 2016-10-03 08:59:20 --> Language Class Initialized
INFO - 2016-10-03 08:59:20 --> Loader Class Initialized
INFO - 2016-10-03 08:59:20 --> Loader Class Initialized
INFO - 2016-10-03 08:59:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:20 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:20 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:20 --> Controller Class Initialized
INFO - 2016-10-03 08:59:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:20 --> Model Class Initialized
INFO - 2016-10-03 08:59:20 --> Model Class Initialized
INFO - 2016-10-03 08:59:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:20 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:20 --> Total execution time: 0.0688
INFO - 2016-10-03 08:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:20 --> Controller Class Initialized
INFO - 2016-10-03 08:59:20 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:20 --> Model Class Initialized
INFO - 2016-10-03 08:59:20 --> Model Class Initialized
INFO - 2016-10-03 08:59:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:20 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:20 --> Total execution time: 0.1106
INFO - 2016-10-03 08:59:22 --> Config Class Initialized
INFO - 2016-10-03 08:59:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:22 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:22 --> URI Class Initialized
INFO - 2016-10-03 08:59:22 --> Router Class Initialized
INFO - 2016-10-03 08:59:22 --> Output Class Initialized
INFO - 2016-10-03 08:59:22 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:22 --> Input Class Initialized
INFO - 2016-10-03 08:59:22 --> Language Class Initialized
INFO - 2016-10-03 08:59:22 --> Loader Class Initialized
INFO - 2016-10-03 08:59:22 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:22 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:22 --> Controller Class Initialized
INFO - 2016-10-03 08:59:22 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:22 --> Model Class Initialized
INFO - 2016-10-03 08:59:22 --> Model Class Initialized
INFO - 2016-10-03 08:59:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:22 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:22 --> Total execution time: 0.1199
INFO - 2016-10-03 08:59:24 --> Config Class Initialized
INFO - 2016-10-03 08:59:24 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:24 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:24 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:24 --> URI Class Initialized
INFO - 2016-10-03 08:59:24 --> Router Class Initialized
INFO - 2016-10-03 08:59:24 --> Output Class Initialized
INFO - 2016-10-03 08:59:24 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:24 --> Input Class Initialized
INFO - 2016-10-03 08:59:24 --> Language Class Initialized
INFO - 2016-10-03 08:59:24 --> Loader Class Initialized
INFO - 2016-10-03 08:59:24 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:24 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:24 --> Controller Class Initialized
INFO - 2016-10-03 08:59:24 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:24 --> Model Class Initialized
INFO - 2016-10-03 08:59:24 --> Model Class Initialized
INFO - 2016-10-03 08:59:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:24 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:24 --> Total execution time: 0.1217
INFO - 2016-10-03 08:59:25 --> Config Class Initialized
INFO - 2016-10-03 08:59:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:25 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:25 --> Config Class Initialized
INFO - 2016-10-03 08:59:25 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:25 --> URI Class Initialized
INFO - 2016-10-03 08:59:25 --> Router Class Initialized
INFO - 2016-10-03 08:59:25 --> Config Class Initialized
INFO - 2016-10-03 08:59:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:25 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:25 --> Output Class Initialized
INFO - 2016-10-03 08:59:25 --> URI Class Initialized
INFO - 2016-10-03 08:59:25 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:25 --> Router Class Initialized
INFO - 2016-10-03 08:59:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:25 --> URI Class Initialized
INFO - 2016-10-03 08:59:25 --> Input Class Initialized
INFO - 2016-10-03 08:59:25 --> Output Class Initialized
INFO - 2016-10-03 08:59:25 --> Language Class Initialized
INFO - 2016-10-03 08:59:25 --> Router Class Initialized
INFO - 2016-10-03 08:59:25 --> Security Class Initialized
INFO - 2016-10-03 08:59:25 --> Output Class Initialized
DEBUG - 2016-10-03 08:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:25 --> Input Class Initialized
INFO - 2016-10-03 08:59:25 --> Loader Class Initialized
INFO - 2016-10-03 08:59:25 --> Language Class Initialized
INFO - 2016-10-03 08:59:25 --> Security Class Initialized
INFO - 2016-10-03 08:59:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:25 --> Helper loaded: language_helper
DEBUG - 2016-10-03 08:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:25 --> Input Class Initialized
INFO - 2016-10-03 08:59:25 --> Language Class Initialized
INFO - 2016-10-03 08:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:25 --> Controller Class Initialized
INFO - 2016-10-03 08:59:25 --> Loader Class Initialized
INFO - 2016-10-03 08:59:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:25 --> Loader Class Initialized
INFO - 2016-10-03 08:59:25 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:25 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:25 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:25 --> Total execution time: 0.1120
INFO - 2016-10-03 08:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:25 --> Controller Class Initialized
INFO - 2016-10-03 08:59:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:25 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:25 --> Total execution time: 0.1320
INFO - 2016-10-03 08:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:25 --> Controller Class Initialized
INFO - 2016-10-03 08:59:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:25 --> Config Class Initialized
INFO - 2016-10-03 08:59:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:25 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:25 --> URI Class Initialized
INFO - 2016-10-03 08:59:25 --> Router Class Initialized
INFO - 2016-10-03 08:59:25 --> Output Class Initialized
INFO - 2016-10-03 08:59:25 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:25 --> Input Class Initialized
INFO - 2016-10-03 08:59:25 --> Language Class Initialized
INFO - 2016-10-03 08:59:25 --> Loader Class Initialized
INFO - 2016-10-03 08:59:25 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:25 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:25 --> Controller Class Initialized
INFO - 2016-10-03 08:59:25 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Model Class Initialized
INFO - 2016-10-03 08:59:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:59:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2016-10-03 08:59:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:59:25 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:25 --> Total execution time: 0.0633
INFO - 2016-10-03 08:59:27 --> Config Class Initialized
INFO - 2016-10-03 08:59:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:27 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:27 --> URI Class Initialized
INFO - 2016-10-03 08:59:27 --> Router Class Initialized
INFO - 2016-10-03 08:59:27 --> Output Class Initialized
INFO - 2016-10-03 08:59:27 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:28 --> Input Class Initialized
INFO - 2016-10-03 08:59:28 --> Language Class Initialized
INFO - 2016-10-03 08:59:28 --> Loader Class Initialized
INFO - 2016-10-03 08:59:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:28 --> Controller Class Initialized
INFO - 2016-10-03 08:59:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:28 --> Config Class Initialized
INFO - 2016-10-03 08:59:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:28 --> URI Class Initialized
INFO - 2016-10-03 08:59:28 --> Router Class Initialized
INFO - 2016-10-03 08:59:28 --> Output Class Initialized
INFO - 2016-10-03 08:59:28 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:28 --> Input Class Initialized
INFO - 2016-10-03 08:59:28 --> Language Class Initialized
INFO - 2016-10-03 08:59:28 --> Loader Class Initialized
INFO - 2016-10-03 08:59:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:28 --> Controller Class Initialized
INFO - 2016-10-03 08:59:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 08:59:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07_attempt.php
INFO - 2016-10-03 08:59:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 08:59:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:28 --> Total execution time: 0.0707
INFO - 2016-10-03 08:59:28 --> Config Class Initialized
INFO - 2016-10-03 08:59:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:28 --> Config Class Initialized
INFO - 2016-10-03 08:59:28 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:28 --> URI Class Initialized
DEBUG - 2016-10-03 08:59:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:28 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:28 --> Router Class Initialized
INFO - 2016-10-03 08:59:28 --> URI Class Initialized
INFO - 2016-10-03 08:59:28 --> Output Class Initialized
INFO - 2016-10-03 08:59:28 --> Router Class Initialized
INFO - 2016-10-03 08:59:28 --> Security Class Initialized
INFO - 2016-10-03 08:59:28 --> Output Class Initialized
DEBUG - 2016-10-03 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:28 --> Input Class Initialized
INFO - 2016-10-03 08:59:28 --> Security Class Initialized
INFO - 2016-10-03 08:59:28 --> Language Class Initialized
DEBUG - 2016-10-03 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:28 --> Input Class Initialized
INFO - 2016-10-03 08:59:28 --> Language Class Initialized
INFO - 2016-10-03 08:59:28 --> Loader Class Initialized
INFO - 2016-10-03 08:59:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:28 --> Loader Class Initialized
INFO - 2016-10-03 08:59:28 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:28 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:28 --> Controller Class Initialized
INFO - 2016-10-03 08:59:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:28 --> Total execution time: 0.0929
INFO - 2016-10-03 08:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:28 --> Controller Class Initialized
INFO - 2016-10-03 08:59:28 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Model Class Initialized
INFO - 2016-10-03 08:59:28 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 08:59:28 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 08:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 08:59:28 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:28 --> Total execution time: 0.1163
INFO - 2016-10-03 08:59:32 --> Config Class Initialized
INFO - 2016-10-03 08:59:32 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:32 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:32 --> Config Class Initialized
INFO - 2016-10-03 08:59:32 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:32 --> URI Class Initialized
DEBUG - 2016-10-03 08:59:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:32 --> Router Class Initialized
INFO - 2016-10-03 08:59:32 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:32 --> URI Class Initialized
INFO - 2016-10-03 08:59:32 --> Output Class Initialized
INFO - 2016-10-03 08:59:32 --> Security Class Initialized
INFO - 2016-10-03 08:59:32 --> Router Class Initialized
DEBUG - 2016-10-03 08:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:32 --> Output Class Initialized
INFO - 2016-10-03 08:59:32 --> Input Class Initialized
INFO - 2016-10-03 08:59:32 --> Language Class Initialized
INFO - 2016-10-03 08:59:32 --> Security Class Initialized
INFO - 2016-10-03 08:59:32 --> Loader Class Initialized
DEBUG - 2016-10-03 08:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:32 --> Input Class Initialized
INFO - 2016-10-03 08:59:32 --> Language Class Initialized
INFO - 2016-10-03 08:59:32 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:32 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:32 --> Loader Class Initialized
INFO - 2016-10-03 08:59:32 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:32 --> Controller Class Initialized
INFO - 2016-10-03 08:59:32 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:32 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:32 --> Model Class Initialized
INFO - 2016-10-03 08:59:32 --> Model Class Initialized
INFO - 2016-10-03 08:59:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:32 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:32 --> Total execution time: 0.0823
INFO - 2016-10-03 08:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:32 --> Controller Class Initialized
INFO - 2016-10-03 08:59:32 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:32 --> Model Class Initialized
INFO - 2016-10-03 08:59:32 --> Model Class Initialized
INFO - 2016-10-03 08:59:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:32 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:32 --> Total execution time: 0.1065
INFO - 2016-10-03 08:59:53 --> Config Class Initialized
INFO - 2016-10-03 08:59:53 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:53 --> Config Class Initialized
INFO - 2016-10-03 08:59:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:53 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:53 --> URI Class Initialized
INFO - 2016-10-03 08:59:53 --> Router Class Initialized
DEBUG - 2016-10-03 08:59:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:53 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:53 --> Output Class Initialized
INFO - 2016-10-03 08:59:53 --> URI Class Initialized
INFO - 2016-10-03 08:59:53 --> Security Class Initialized
INFO - 2016-10-03 08:59:53 --> Router Class Initialized
DEBUG - 2016-10-03 08:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:53 --> Output Class Initialized
INFO - 2016-10-03 08:59:53 --> Input Class Initialized
INFO - 2016-10-03 08:59:53 --> Language Class Initialized
INFO - 2016-10-03 08:59:53 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:53 --> Input Class Initialized
INFO - 2016-10-03 08:59:53 --> Loader Class Initialized
INFO - 2016-10-03 08:59:53 --> Language Class Initialized
INFO - 2016-10-03 08:59:53 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:53 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:53 --> Loader Class Initialized
INFO - 2016-10-03 08:59:53 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:53 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:53 --> Controller Class Initialized
INFO - 2016-10-03 08:59:53 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:53 --> Model Class Initialized
INFO - 2016-10-03 08:59:53 --> Model Class Initialized
INFO - 2016-10-03 08:59:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:53 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:53 --> Total execution time: 0.0812
INFO - 2016-10-03 08:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:53 --> Controller Class Initialized
INFO - 2016-10-03 08:59:53 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:53 --> Model Class Initialized
INFO - 2016-10-03 08:59:53 --> Model Class Initialized
INFO - 2016-10-03 08:59:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:53 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:53 --> Total execution time: 0.1143
INFO - 2016-10-03 08:59:57 --> Config Class Initialized
INFO - 2016-10-03 08:59:57 --> Hooks Class Initialized
INFO - 2016-10-03 08:59:57 --> Config Class Initialized
INFO - 2016-10-03 08:59:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:57 --> Utf8 Class Initialized
DEBUG - 2016-10-03 08:59:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:57 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:57 --> URI Class Initialized
INFO - 2016-10-03 08:59:57 --> URI Class Initialized
INFO - 2016-10-03 08:59:57 --> Router Class Initialized
INFO - 2016-10-03 08:59:57 --> Router Class Initialized
INFO - 2016-10-03 08:59:57 --> Output Class Initialized
INFO - 2016-10-03 08:59:57 --> Output Class Initialized
INFO - 2016-10-03 08:59:57 --> Security Class Initialized
INFO - 2016-10-03 08:59:57 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:57 --> Input Class Initialized
DEBUG - 2016-10-03 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:57 --> Language Class Initialized
INFO - 2016-10-03 08:59:57 --> Input Class Initialized
INFO - 2016-10-03 08:59:57 --> Language Class Initialized
INFO - 2016-10-03 08:59:57 --> Loader Class Initialized
INFO - 2016-10-03 08:59:57 --> Loader Class Initialized
INFO - 2016-10-03 08:59:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:57 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:57 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:57 --> Controller Class Initialized
INFO - 2016-10-03 08:59:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:57 --> Model Class Initialized
INFO - 2016-10-03 08:59:57 --> Model Class Initialized
INFO - 2016-10-03 08:59:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:57 --> Total execution time: 0.0684
INFO - 2016-10-03 08:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:57 --> Controller Class Initialized
INFO - 2016-10-03 08:59:57 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:57 --> Model Class Initialized
INFO - 2016-10-03 08:59:57 --> Model Class Initialized
INFO - 2016-10-03 08:59:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:57 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:57 --> Total execution time: 0.1024
INFO - 2016-10-03 08:59:58 --> Config Class Initialized
INFO - 2016-10-03 08:59:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 08:59:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 08:59:58 --> Utf8 Class Initialized
INFO - 2016-10-03 08:59:58 --> URI Class Initialized
INFO - 2016-10-03 08:59:58 --> Router Class Initialized
INFO - 2016-10-03 08:59:58 --> Output Class Initialized
INFO - 2016-10-03 08:59:58 --> Security Class Initialized
DEBUG - 2016-10-03 08:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 08:59:58 --> Input Class Initialized
INFO - 2016-10-03 08:59:58 --> Language Class Initialized
INFO - 2016-10-03 08:59:58 --> Loader Class Initialized
INFO - 2016-10-03 08:59:58 --> Helper loaded: url_helper
INFO - 2016-10-03 08:59:58 --> Helper loaded: language_helper
INFO - 2016-10-03 08:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 08:59:58 --> Controller Class Initialized
INFO - 2016-10-03 08:59:58 --> Database Driver Class Initialized
INFO - 2016-10-03 08:59:58 --> Model Class Initialized
INFO - 2016-10-03 08:59:58 --> Model Class Initialized
INFO - 2016-10-03 08:59:58 --> Model Class Initialized
INFO - 2016-10-03 08:59:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 08:59:58 --> Final output sent to browser
DEBUG - 2016-10-03 08:59:58 --> Total execution time: 0.0610
INFO - 2016-10-03 09:00:04 --> Config Class Initialized
INFO - 2016-10-03 09:00:04 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:04 --> Config Class Initialized
INFO - 2016-10-03 09:00:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:04 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:04 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:04 --> URI Class Initialized
INFO - 2016-10-03 09:00:04 --> URI Class Initialized
INFO - 2016-10-03 09:00:04 --> Router Class Initialized
INFO - 2016-10-03 09:00:04 --> Router Class Initialized
INFO - 2016-10-03 09:00:04 --> Output Class Initialized
INFO - 2016-10-03 09:00:04 --> Output Class Initialized
INFO - 2016-10-03 09:00:04 --> Security Class Initialized
INFO - 2016-10-03 09:00:04 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:04 --> Input Class Initialized
INFO - 2016-10-03 09:00:04 --> Language Class Initialized
DEBUG - 2016-10-03 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:04 --> Input Class Initialized
INFO - 2016-10-03 09:00:04 --> Language Class Initialized
INFO - 2016-10-03 09:00:04 --> Loader Class Initialized
INFO - 2016-10-03 09:00:04 --> Loader Class Initialized
INFO - 2016-10-03 09:00:04 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:04 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:04 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:04 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:04 --> Controller Class Initialized
INFO - 2016-10-03 09:00:04 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:04 --> Model Class Initialized
INFO - 2016-10-03 09:00:04 --> Model Class Initialized
INFO - 2016-10-03 09:00:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:04 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:04 --> Total execution time: 0.0965
INFO - 2016-10-03 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:04 --> Controller Class Initialized
INFO - 2016-10-03 09:00:04 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:04 --> Model Class Initialized
INFO - 2016-10-03 09:00:04 --> Model Class Initialized
INFO - 2016-10-03 09:00:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:04 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:04 --> Total execution time: 0.1265
INFO - 2016-10-03 09:00:08 --> Config Class Initialized
INFO - 2016-10-03 09:00:08 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:08 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:08 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:08 --> URI Class Initialized
INFO - 2016-10-03 09:00:08 --> Router Class Initialized
INFO - 2016-10-03 09:00:08 --> Output Class Initialized
INFO - 2016-10-03 09:00:08 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:08 --> Input Class Initialized
INFO - 2016-10-03 09:00:08 --> Language Class Initialized
INFO - 2016-10-03 09:00:08 --> Loader Class Initialized
INFO - 2016-10-03 09:00:08 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:08 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:08 --> Controller Class Initialized
INFO - 2016-10-03 09:00:08 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:08 --> Model Class Initialized
INFO - 2016-10-03 09:00:08 --> Model Class Initialized
INFO - 2016-10-03 09:00:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:08 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:08 --> Total execution time: 0.0738
INFO - 2016-10-03 09:00:09 --> Config Class Initialized
INFO - 2016-10-03 09:00:09 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:09 --> Config Class Initialized
INFO - 2016-10-03 09:00:09 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:09 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:09 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:09 --> URI Class Initialized
INFO - 2016-10-03 09:00:09 --> URI Class Initialized
INFO - 2016-10-03 09:00:09 --> Config Class Initialized
INFO - 2016-10-03 09:00:09 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:09 --> Router Class Initialized
INFO - 2016-10-03 09:00:09 --> Router Class Initialized
INFO - 2016-10-03 09:00:09 --> Output Class Initialized
DEBUG - 2016-10-03 09:00:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:09 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:09 --> Security Class Initialized
INFO - 2016-10-03 09:00:09 --> Output Class Initialized
INFO - 2016-10-03 09:00:09 --> URI Class Initialized
INFO - 2016-10-03 09:00:09 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:09 --> Router Class Initialized
INFO - 2016-10-03 09:00:09 --> Input Class Initialized
INFO - 2016-10-03 09:00:09 --> Language Class Initialized
DEBUG - 2016-10-03 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:09 --> Input Class Initialized
INFO - 2016-10-03 09:00:09 --> Language Class Initialized
INFO - 2016-10-03 09:00:09 --> Output Class Initialized
INFO - 2016-10-03 09:00:09 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:09 --> Loader Class Initialized
INFO - 2016-10-03 09:00:09 --> Input Class Initialized
INFO - 2016-10-03 09:00:09 --> Language Class Initialized
INFO - 2016-10-03 09:00:09 --> Loader Class Initialized
INFO - 2016-10-03 09:00:09 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:09 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:09 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:09 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:09 --> Loader Class Initialized
INFO - 2016-10-03 09:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:09 --> Controller Class Initialized
INFO - 2016-10-03 09:00:09 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:09 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:09 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:09 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:09 --> Total execution time: 0.0794
INFO - 2016-10-03 09:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:09 --> Controller Class Initialized
INFO - 2016-10-03 09:00:09 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:09 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:09 --> Total execution time: 0.1237
INFO - 2016-10-03 09:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:09 --> Controller Class Initialized
INFO - 2016-10-03 09:00:09 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:09 --> Config Class Initialized
INFO - 2016-10-03 09:00:09 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:09 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:09 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:09 --> URI Class Initialized
INFO - 2016-10-03 09:00:09 --> Router Class Initialized
INFO - 2016-10-03 09:00:09 --> Output Class Initialized
INFO - 2016-10-03 09:00:09 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:09 --> Input Class Initialized
INFO - 2016-10-03 09:00:09 --> Language Class Initialized
INFO - 2016-10-03 09:00:09 --> Loader Class Initialized
INFO - 2016-10-03 09:00:09 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:09 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:09 --> Controller Class Initialized
INFO - 2016-10-03 09:00:09 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Model Class Initialized
INFO - 2016-10-03 09:00:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:00:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2016-10-03 09:00:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:00:09 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:09 --> Total execution time: 0.0651
INFO - 2016-10-03 09:00:12 --> Config Class Initialized
INFO - 2016-10-03 09:00:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:12 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:12 --> URI Class Initialized
INFO - 2016-10-03 09:00:12 --> Router Class Initialized
INFO - 2016-10-03 09:00:12 --> Output Class Initialized
INFO - 2016-10-03 09:00:12 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:12 --> Input Class Initialized
INFO - 2016-10-03 09:00:12 --> Language Class Initialized
INFO - 2016-10-03 09:00:12 --> Loader Class Initialized
INFO - 2016-10-03 09:00:12 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:12 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:12 --> Controller Class Initialized
INFO - 2016-10-03 09:00:12 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:12 --> Config Class Initialized
INFO - 2016-10-03 09:00:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:12 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:12 --> URI Class Initialized
INFO - 2016-10-03 09:00:12 --> Router Class Initialized
INFO - 2016-10-03 09:00:12 --> Output Class Initialized
INFO - 2016-10-03 09:00:12 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:12 --> Input Class Initialized
INFO - 2016-10-03 09:00:12 --> Language Class Initialized
INFO - 2016-10-03 09:00:12 --> Loader Class Initialized
INFO - 2016-10-03 09:00:12 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:12 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:12 --> Controller Class Initialized
INFO - 2016-10-03 09:00:12 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:00:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08_attempt.php
INFO - 2016-10-03 09:00:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:00:12 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:12 --> Total execution time: 0.0730
INFO - 2016-10-03 09:00:12 --> Config Class Initialized
INFO - 2016-10-03 09:00:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:12 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:12 --> URI Class Initialized
INFO - 2016-10-03 09:00:12 --> Config Class Initialized
INFO - 2016-10-03 09:00:12 --> Router Class Initialized
INFO - 2016-10-03 09:00:12 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:12 --> Output Class Initialized
DEBUG - 2016-10-03 09:00:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:12 --> Security Class Initialized
INFO - 2016-10-03 09:00:12 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:12 --> URI Class Initialized
INFO - 2016-10-03 09:00:12 --> Input Class Initialized
INFO - 2016-10-03 09:00:12 --> Language Class Initialized
INFO - 2016-10-03 09:00:12 --> Router Class Initialized
INFO - 2016-10-03 09:00:12 --> Output Class Initialized
INFO - 2016-10-03 09:00:12 --> Loader Class Initialized
INFO - 2016-10-03 09:00:12 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:12 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:12 --> Input Class Initialized
INFO - 2016-10-03 09:00:12 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:12 --> Language Class Initialized
INFO - 2016-10-03 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:12 --> Controller Class Initialized
INFO - 2016-10-03 09:00:12 --> Loader Class Initialized
INFO - 2016-10-03 09:00:12 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:12 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:12 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:12 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:12 --> Total execution time: 0.0809
INFO - 2016-10-03 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:12 --> Controller Class Initialized
INFO - 2016-10-03 09:00:12 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Model Class Initialized
INFO - 2016-10-03 09:00:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 09:00:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 09:00:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 09:00:12 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:12 --> Total execution time: 0.1004
INFO - 2016-10-03 09:00:18 --> Config Class Initialized
INFO - 2016-10-03 09:00:18 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:18 --> Config Class Initialized
INFO - 2016-10-03 09:00:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:18 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:18 --> URI Class Initialized
DEBUG - 2016-10-03 09:00:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:18 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:18 --> Router Class Initialized
INFO - 2016-10-03 09:00:18 --> URI Class Initialized
INFO - 2016-10-03 09:00:18 --> Output Class Initialized
INFO - 2016-10-03 09:00:18 --> Router Class Initialized
INFO - 2016-10-03 09:00:18 --> Security Class Initialized
INFO - 2016-10-03 09:00:18 --> Output Class Initialized
DEBUG - 2016-10-03 09:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:18 --> Input Class Initialized
INFO - 2016-10-03 09:00:18 --> Security Class Initialized
INFO - 2016-10-03 09:00:18 --> Language Class Initialized
DEBUG - 2016-10-03 09:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:18 --> Input Class Initialized
INFO - 2016-10-03 09:00:18 --> Language Class Initialized
INFO - 2016-10-03 09:00:18 --> Loader Class Initialized
INFO - 2016-10-03 09:00:18 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:18 --> Loader Class Initialized
INFO - 2016-10-03 09:00:18 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:18 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:18 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:18 --> Controller Class Initialized
INFO - 2016-10-03 09:00:18 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:18 --> Model Class Initialized
INFO - 2016-10-03 09:00:18 --> Model Class Initialized
INFO - 2016-10-03 09:00:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:18 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:18 --> Total execution time: 0.0656
INFO - 2016-10-03 09:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:18 --> Controller Class Initialized
INFO - 2016-10-03 09:00:18 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:18 --> Model Class Initialized
INFO - 2016-10-03 09:00:18 --> Model Class Initialized
INFO - 2016-10-03 09:00:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:18 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:18 --> Total execution time: 0.0877
INFO - 2016-10-03 09:00:20 --> Config Class Initialized
INFO - 2016-10-03 09:00:20 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:20 --> Config Class Initialized
INFO - 2016-10-03 09:00:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:20 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:20 --> URI Class Initialized
INFO - 2016-10-03 09:00:20 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:20 --> URI Class Initialized
INFO - 2016-10-03 09:00:20 --> Router Class Initialized
INFO - 2016-10-03 09:00:20 --> Router Class Initialized
INFO - 2016-10-03 09:00:20 --> Output Class Initialized
INFO - 2016-10-03 09:00:20 --> Output Class Initialized
INFO - 2016-10-03 09:00:20 --> Security Class Initialized
INFO - 2016-10-03 09:00:20 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:20 --> Input Class Initialized
DEBUG - 2016-10-03 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:20 --> Language Class Initialized
INFO - 2016-10-03 09:00:20 --> Input Class Initialized
INFO - 2016-10-03 09:00:20 --> Language Class Initialized
INFO - 2016-10-03 09:00:20 --> Loader Class Initialized
INFO - 2016-10-03 09:00:20 --> Loader Class Initialized
INFO - 2016-10-03 09:00:20 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:20 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:20 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:20 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:20 --> Controller Class Initialized
INFO - 2016-10-03 09:00:20 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:20 --> Model Class Initialized
INFO - 2016-10-03 09:00:20 --> Model Class Initialized
INFO - 2016-10-03 09:00:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:20 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:20 --> Total execution time: 0.0686
INFO - 2016-10-03 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:20 --> Controller Class Initialized
INFO - 2016-10-03 09:00:20 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:20 --> Model Class Initialized
INFO - 2016-10-03 09:00:20 --> Model Class Initialized
INFO - 2016-10-03 09:00:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:20 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:20 --> Total execution time: 0.1038
INFO - 2016-10-03 09:00:23 --> Config Class Initialized
INFO - 2016-10-03 09:00:23 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:23 --> Config Class Initialized
INFO - 2016-10-03 09:00:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:23 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:23 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:23 --> URI Class Initialized
INFO - 2016-10-03 09:00:23 --> URI Class Initialized
INFO - 2016-10-03 09:00:23 --> Router Class Initialized
INFO - 2016-10-03 09:00:23 --> Router Class Initialized
INFO - 2016-10-03 09:00:23 --> Output Class Initialized
INFO - 2016-10-03 09:00:23 --> Output Class Initialized
INFO - 2016-10-03 09:00:23 --> Security Class Initialized
INFO - 2016-10-03 09:00:23 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:23 --> Input Class Initialized
INFO - 2016-10-03 09:00:23 --> Language Class Initialized
DEBUG - 2016-10-03 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:23 --> Input Class Initialized
INFO - 2016-10-03 09:00:23 --> Language Class Initialized
INFO - 2016-10-03 09:00:23 --> Loader Class Initialized
INFO - 2016-10-03 09:00:23 --> Loader Class Initialized
INFO - 2016-10-03 09:00:23 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:23 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:23 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:23 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:23 --> Controller Class Initialized
INFO - 2016-10-03 09:00:23 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:23 --> Model Class Initialized
INFO - 2016-10-03 09:00:23 --> Model Class Initialized
INFO - 2016-10-03 09:00:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:23 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:23 --> Total execution time: 0.0666
INFO - 2016-10-03 09:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:23 --> Controller Class Initialized
INFO - 2016-10-03 09:00:23 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:23 --> Model Class Initialized
INFO - 2016-10-03 09:00:23 --> Model Class Initialized
INFO - 2016-10-03 09:00:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:23 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:23 --> Total execution time: 0.1008
INFO - 2016-10-03 09:00:24 --> Config Class Initialized
INFO - 2016-10-03 09:00:24 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:24 --> Config Class Initialized
INFO - 2016-10-03 09:00:24 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:24 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:24 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:24 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:24 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:24 --> URI Class Initialized
INFO - 2016-10-03 09:00:24 --> URI Class Initialized
INFO - 2016-10-03 09:00:24 --> Router Class Initialized
INFO - 2016-10-03 09:00:24 --> Router Class Initialized
INFO - 2016-10-03 09:00:24 --> Output Class Initialized
INFO - 2016-10-03 09:00:24 --> Output Class Initialized
INFO - 2016-10-03 09:00:25 --> Security Class Initialized
INFO - 2016-10-03 09:00:25 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:25 --> Input Class Initialized
INFO - 2016-10-03 09:00:25 --> Language Class Initialized
DEBUG - 2016-10-03 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:25 --> Input Class Initialized
INFO - 2016-10-03 09:00:25 --> Language Class Initialized
INFO - 2016-10-03 09:00:25 --> Loader Class Initialized
INFO - 2016-10-03 09:00:25 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:25 --> Loader Class Initialized
INFO - 2016-10-03 09:00:25 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:25 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:25 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:25 --> Controller Class Initialized
INFO - 2016-10-03 09:00:25 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:25 --> Model Class Initialized
INFO - 2016-10-03 09:00:25 --> Model Class Initialized
INFO - 2016-10-03 09:00:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:25 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:25 --> Total execution time: 0.0766
INFO - 2016-10-03 09:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:25 --> Controller Class Initialized
INFO - 2016-10-03 09:00:25 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:25 --> Model Class Initialized
INFO - 2016-10-03 09:00:25 --> Model Class Initialized
INFO - 2016-10-03 09:00:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:25 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:25 --> Total execution time: 0.1243
INFO - 2016-10-03 09:00:26 --> Config Class Initialized
INFO - 2016-10-03 09:00:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:26 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:26 --> URI Class Initialized
INFO - 2016-10-03 09:00:26 --> Router Class Initialized
INFO - 2016-10-03 09:00:26 --> Output Class Initialized
INFO - 2016-10-03 09:00:26 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:26 --> Input Class Initialized
INFO - 2016-10-03 09:00:26 --> Language Class Initialized
INFO - 2016-10-03 09:00:26 --> Loader Class Initialized
INFO - 2016-10-03 09:00:26 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:26 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:26 --> Controller Class Initialized
INFO - 2016-10-03 09:00:26 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:26 --> Model Class Initialized
INFO - 2016-10-03 09:00:26 --> Model Class Initialized
INFO - 2016-10-03 09:00:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:26 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:26 --> Total execution time: 0.0833
INFO - 2016-10-03 09:00:27 --> Config Class Initialized
INFO - 2016-10-03 09:00:27 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:27 --> Config Class Initialized
INFO - 2016-10-03 09:00:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:27 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:27 --> URI Class Initialized
DEBUG - 2016-10-03 09:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:27 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:27 --> URI Class Initialized
INFO - 2016-10-03 09:00:27 --> Router Class Initialized
INFO - 2016-10-03 09:00:27 --> Config Class Initialized
INFO - 2016-10-03 09:00:27 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:27 --> Router Class Initialized
INFO - 2016-10-03 09:00:27 --> Output Class Initialized
INFO - 2016-10-03 09:00:27 --> Security Class Initialized
INFO - 2016-10-03 09:00:27 --> Output Class Initialized
DEBUG - 2016-10-03 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:27 --> Security Class Initialized
INFO - 2016-10-03 09:00:27 --> Input Class Initialized
DEBUG - 2016-10-03 09:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:27 --> Language Class Initialized
INFO - 2016-10-03 09:00:27 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:27 --> Input Class Initialized
INFO - 2016-10-03 09:00:27 --> URI Class Initialized
INFO - 2016-10-03 09:00:27 --> Language Class Initialized
INFO - 2016-10-03 09:00:27 --> Router Class Initialized
INFO - 2016-10-03 09:00:27 --> Loader Class Initialized
INFO - 2016-10-03 09:00:27 --> Output Class Initialized
INFO - 2016-10-03 09:00:27 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:27 --> Loader Class Initialized
INFO - 2016-10-03 09:00:27 --> Security Class Initialized
INFO - 2016-10-03 09:00:27 --> Helper loaded: language_helper
DEBUG - 2016-10-03 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:27 --> Input Class Initialized
INFO - 2016-10-03 09:00:27 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:27 --> Language Class Initialized
INFO - 2016-10-03 09:00:27 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:27 --> Controller Class Initialized
INFO - 2016-10-03 09:00:27 --> Loader Class Initialized
INFO - 2016-10-03 09:00:27 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:27 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:27 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:27 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:27 --> Total execution time: 0.0885
INFO - 2016-10-03 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:27 --> Controller Class Initialized
INFO - 2016-10-03 09:00:27 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:27 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:27 --> Total execution time: 0.1364
INFO - 2016-10-03 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:27 --> Controller Class Initialized
INFO - 2016-10-03 09:00:27 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Model Class Initialized
INFO - 2016-10-03 09:00:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:27 --> Config Class Initialized
INFO - 2016-10-03 09:00:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:27 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:27 --> URI Class Initialized
INFO - 2016-10-03 09:00:27 --> Router Class Initialized
INFO - 2016-10-03 09:00:27 --> Output Class Initialized
INFO - 2016-10-03 09:00:27 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:27 --> Input Class Initialized
INFO - 2016-10-03 09:00:27 --> Language Class Initialized
INFO - 2016-10-03 09:00:27 --> Loader Class Initialized
INFO - 2016-10-03 09:00:27 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:27 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:27 --> Controller Class Initialized
INFO - 2016-10-03 09:00:28 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:28 --> Model Class Initialized
INFO - 2016-10-03 09:00:28 --> Model Class Initialized
INFO - 2016-10-03 09:00:28 --> Model Class Initialized
INFO - 2016-10-03 09:00:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:00:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2016-10-03 09:00:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:00:28 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:28 --> Total execution time: 0.0735
INFO - 2016-10-03 09:00:53 --> Config Class Initialized
INFO - 2016-10-03 09:00:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:53 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:53 --> URI Class Initialized
INFO - 2016-10-03 09:00:53 --> Router Class Initialized
INFO - 2016-10-03 09:00:53 --> Output Class Initialized
INFO - 2016-10-03 09:00:53 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:53 --> Input Class Initialized
INFO - 2016-10-03 09:00:53 --> Language Class Initialized
INFO - 2016-10-03 09:00:53 --> Loader Class Initialized
INFO - 2016-10-03 09:00:53 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:53 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:53 --> Controller Class Initialized
INFO - 2016-10-03 09:00:53 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:53 --> Config Class Initialized
INFO - 2016-10-03 09:00:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:53 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:53 --> URI Class Initialized
INFO - 2016-10-03 09:00:53 --> Router Class Initialized
INFO - 2016-10-03 09:00:53 --> Output Class Initialized
INFO - 2016-10-03 09:00:53 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:53 --> Input Class Initialized
INFO - 2016-10-03 09:00:53 --> Language Class Initialized
INFO - 2016-10-03 09:00:53 --> Loader Class Initialized
INFO - 2016-10-03 09:00:53 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:53 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:53 --> Controller Class Initialized
INFO - 2016-10-03 09:00:53 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:00:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2016-10-03 09:00:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:00:53 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:53 --> Total execution time: 0.0681
INFO - 2016-10-03 09:00:53 --> Config Class Initialized
INFO - 2016-10-03 09:00:53 --> Hooks Class Initialized
INFO - 2016-10-03 09:00:53 --> Config Class Initialized
INFO - 2016-10-03 09:00:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:00:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:53 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:53 --> URI Class Initialized
DEBUG - 2016-10-03 09:00:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:00:53 --> Utf8 Class Initialized
INFO - 2016-10-03 09:00:53 --> URI Class Initialized
INFO - 2016-10-03 09:00:53 --> Router Class Initialized
INFO - 2016-10-03 09:00:53 --> Output Class Initialized
INFO - 2016-10-03 09:00:53 --> Router Class Initialized
INFO - 2016-10-03 09:00:53 --> Security Class Initialized
INFO - 2016-10-03 09:00:53 --> Output Class Initialized
DEBUG - 2016-10-03 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:53 --> Input Class Initialized
INFO - 2016-10-03 09:00:53 --> Language Class Initialized
INFO - 2016-10-03 09:00:53 --> Security Class Initialized
DEBUG - 2016-10-03 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:00:53 --> Input Class Initialized
INFO - 2016-10-03 09:00:53 --> Language Class Initialized
INFO - 2016-10-03 09:00:53 --> Loader Class Initialized
INFO - 2016-10-03 09:00:53 --> Loader Class Initialized
INFO - 2016-10-03 09:00:53 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:53 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:53 --> Helper loaded: url_helper
INFO - 2016-10-03 09:00:53 --> Helper loaded: language_helper
INFO - 2016-10-03 09:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:53 --> Controller Class Initialized
INFO - 2016-10-03 09:00:53 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:00:53 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:53 --> Total execution time: 0.0819
INFO - 2016-10-03 09:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:00:53 --> Controller Class Initialized
INFO - 2016-10-03 09:00:53 --> Database Driver Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Model Class Initialized
INFO - 2016-10-03 09:00:53 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 09:00:53 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 09:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 09:00:53 --> Final output sent to browser
DEBUG - 2016-10-03 09:00:53 --> Total execution time: 0.1093
INFO - 2016-10-03 09:01:23 --> Config Class Initialized
INFO - 2016-10-03 09:01:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:23 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:23 --> URI Class Initialized
INFO - 2016-10-03 09:01:23 --> Router Class Initialized
INFO - 2016-10-03 09:01:23 --> Output Class Initialized
INFO - 2016-10-03 09:01:23 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:23 --> Input Class Initialized
INFO - 2016-10-03 09:01:23 --> Language Class Initialized
INFO - 2016-10-03 09:01:23 --> Loader Class Initialized
INFO - 2016-10-03 09:01:23 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:23 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:23 --> Controller Class Initialized
INFO - 2016-10-03 09:01:23 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:23 --> Model Class Initialized
INFO - 2016-10-03 09:01:23 --> Model Class Initialized
INFO - 2016-10-03 09:01:23 --> Model Class Initialized
INFO - 2016-10-03 09:01:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:23 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:23 --> Total execution time: 0.0617
INFO - 2016-10-03 09:01:29 --> Config Class Initialized
INFO - 2016-10-03 09:01:29 --> Hooks Class Initialized
INFO - 2016-10-03 09:01:29 --> Config Class Initialized
INFO - 2016-10-03 09:01:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:29 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:29 --> URI Class Initialized
DEBUG - 2016-10-03 09:01:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:29 --> Router Class Initialized
INFO - 2016-10-03 09:01:29 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:29 --> URI Class Initialized
INFO - 2016-10-03 09:01:29 --> Output Class Initialized
INFO - 2016-10-03 09:01:29 --> Router Class Initialized
INFO - 2016-10-03 09:01:29 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:29 --> Input Class Initialized
INFO - 2016-10-03 09:01:29 --> Output Class Initialized
INFO - 2016-10-03 09:01:29 --> Language Class Initialized
INFO - 2016-10-03 09:01:29 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:29 --> Input Class Initialized
INFO - 2016-10-03 09:01:29 --> Loader Class Initialized
INFO - 2016-10-03 09:01:29 --> Language Class Initialized
INFO - 2016-10-03 09:01:29 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:29 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:29 --> Loader Class Initialized
INFO - 2016-10-03 09:01:29 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:29 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:29 --> Controller Class Initialized
INFO - 2016-10-03 09:01:29 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:29 --> Model Class Initialized
INFO - 2016-10-03 09:01:29 --> Model Class Initialized
INFO - 2016-10-03 09:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:29 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:29 --> Total execution time: 0.0728
INFO - 2016-10-03 09:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:29 --> Controller Class Initialized
INFO - 2016-10-03 09:01:29 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:29 --> Model Class Initialized
INFO - 2016-10-03 09:01:29 --> Model Class Initialized
INFO - 2016-10-03 09:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:29 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:29 --> Total execution time: 0.0937
INFO - 2016-10-03 09:01:31 --> Config Class Initialized
INFO - 2016-10-03 09:01:31 --> Hooks Class Initialized
INFO - 2016-10-03 09:01:31 --> Config Class Initialized
INFO - 2016-10-03 09:01:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:31 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:01:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:31 --> URI Class Initialized
INFO - 2016-10-03 09:01:31 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:31 --> URI Class Initialized
INFO - 2016-10-03 09:01:31 --> Router Class Initialized
INFO - 2016-10-03 09:01:31 --> Router Class Initialized
INFO - 2016-10-03 09:01:31 --> Output Class Initialized
INFO - 2016-10-03 09:01:31 --> Security Class Initialized
INFO - 2016-10-03 09:01:31 --> Output Class Initialized
DEBUG - 2016-10-03 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:31 --> Security Class Initialized
INFO - 2016-10-03 09:01:31 --> Input Class Initialized
INFO - 2016-10-03 09:01:31 --> Language Class Initialized
DEBUG - 2016-10-03 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:31 --> Input Class Initialized
INFO - 2016-10-03 09:01:31 --> Language Class Initialized
INFO - 2016-10-03 09:01:31 --> Loader Class Initialized
INFO - 2016-10-03 09:01:31 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:31 --> Loader Class Initialized
INFO - 2016-10-03 09:01:31 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:31 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:31 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:31 --> Controller Class Initialized
INFO - 2016-10-03 09:01:31 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:31 --> Model Class Initialized
INFO - 2016-10-03 09:01:31 --> Model Class Initialized
INFO - 2016-10-03 09:01:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:31 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:31 --> Total execution time: 0.0662
INFO - 2016-10-03 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:31 --> Controller Class Initialized
INFO - 2016-10-03 09:01:31 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:31 --> Model Class Initialized
INFO - 2016-10-03 09:01:31 --> Model Class Initialized
INFO - 2016-10-03 09:01:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:31 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:31 --> Total execution time: 0.0941
INFO - 2016-10-03 09:01:32 --> Config Class Initialized
INFO - 2016-10-03 09:01:32 --> Hooks Class Initialized
INFO - 2016-10-03 09:01:32 --> Config Class Initialized
INFO - 2016-10-03 09:01:32 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:32 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:01:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:32 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:32 --> URI Class Initialized
INFO - 2016-10-03 09:01:32 --> URI Class Initialized
INFO - 2016-10-03 09:01:32 --> Router Class Initialized
INFO - 2016-10-03 09:01:32 --> Router Class Initialized
INFO - 2016-10-03 09:01:32 --> Output Class Initialized
INFO - 2016-10-03 09:01:32 --> Output Class Initialized
INFO - 2016-10-03 09:01:32 --> Security Class Initialized
INFO - 2016-10-03 09:01:32 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:32 --> Input Class Initialized
INFO - 2016-10-03 09:01:32 --> Language Class Initialized
DEBUG - 2016-10-03 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:32 --> Input Class Initialized
INFO - 2016-10-03 09:01:32 --> Language Class Initialized
INFO - 2016-10-03 09:01:32 --> Loader Class Initialized
INFO - 2016-10-03 09:01:32 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:32 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:32 --> Loader Class Initialized
INFO - 2016-10-03 09:01:32 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:32 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:32 --> Controller Class Initialized
INFO - 2016-10-03 09:01:32 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:32 --> Model Class Initialized
INFO - 2016-10-03 09:01:32 --> Model Class Initialized
INFO - 2016-10-03 09:01:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:32 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:32 --> Total execution time: 0.0856
INFO - 2016-10-03 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:32 --> Controller Class Initialized
INFO - 2016-10-03 09:01:32 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:32 --> Model Class Initialized
INFO - 2016-10-03 09:01:32 --> Model Class Initialized
INFO - 2016-10-03 09:01:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:32 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:32 --> Total execution time: 0.1074
INFO - 2016-10-03 09:01:34 --> Config Class Initialized
INFO - 2016-10-03 09:01:34 --> Hooks Class Initialized
INFO - 2016-10-03 09:01:34 --> Config Class Initialized
INFO - 2016-10-03 09:01:34 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:34 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:34 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:34 --> URI Class Initialized
DEBUG - 2016-10-03 09:01:34 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:34 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:34 --> URI Class Initialized
INFO - 2016-10-03 09:01:34 --> Router Class Initialized
INFO - 2016-10-03 09:01:34 --> Router Class Initialized
INFO - 2016-10-03 09:01:34 --> Output Class Initialized
INFO - 2016-10-03 09:01:34 --> Output Class Initialized
INFO - 2016-10-03 09:01:34 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:34 --> Input Class Initialized
INFO - 2016-10-03 09:01:34 --> Security Class Initialized
INFO - 2016-10-03 09:01:34 --> Language Class Initialized
DEBUG - 2016-10-03 09:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:34 --> Input Class Initialized
INFO - 2016-10-03 09:01:34 --> Language Class Initialized
INFO - 2016-10-03 09:01:34 --> Loader Class Initialized
INFO - 2016-10-03 09:01:34 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:34 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:34 --> Loader Class Initialized
INFO - 2016-10-03 09:01:34 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:34 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:34 --> Controller Class Initialized
INFO - 2016-10-03 09:01:34 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:34 --> Model Class Initialized
INFO - 2016-10-03 09:01:34 --> Model Class Initialized
INFO - 2016-10-03 09:01:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:34 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:34 --> Total execution time: 0.0698
INFO - 2016-10-03 09:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:34 --> Controller Class Initialized
INFO - 2016-10-03 09:01:34 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:34 --> Model Class Initialized
INFO - 2016-10-03 09:01:34 --> Model Class Initialized
INFO - 2016-10-03 09:01:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:34 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:34 --> Total execution time: 0.1154
INFO - 2016-10-03 09:01:36 --> Config Class Initialized
INFO - 2016-10-03 09:01:36 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:36 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:36 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:36 --> URI Class Initialized
INFO - 2016-10-03 09:01:36 --> Router Class Initialized
INFO - 2016-10-03 09:01:36 --> Output Class Initialized
INFO - 2016-10-03 09:01:36 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:36 --> Input Class Initialized
INFO - 2016-10-03 09:01:36 --> Language Class Initialized
INFO - 2016-10-03 09:01:36 --> Loader Class Initialized
INFO - 2016-10-03 09:01:36 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:36 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:36 --> Controller Class Initialized
INFO - 2016-10-03 09:01:36 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:36 --> Model Class Initialized
INFO - 2016-10-03 09:01:36 --> Model Class Initialized
INFO - 2016-10-03 09:01:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:36 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:36 --> Total execution time: 0.0758
INFO - 2016-10-03 09:01:38 --> Config Class Initialized
INFO - 2016-10-03 09:01:38 --> Hooks Class Initialized
INFO - 2016-10-03 09:01:38 --> Config Class Initialized
INFO - 2016-10-03 09:01:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:38 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:01:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:38 --> URI Class Initialized
INFO - 2016-10-03 09:01:38 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:38 --> Config Class Initialized
INFO - 2016-10-03 09:01:38 --> Hooks Class Initialized
INFO - 2016-10-03 09:01:38 --> Router Class Initialized
INFO - 2016-10-03 09:01:38 --> URI Class Initialized
INFO - 2016-10-03 09:01:38 --> Router Class Initialized
INFO - 2016-10-03 09:01:38 --> Output Class Initialized
DEBUG - 2016-10-03 09:01:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:38 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:38 --> Output Class Initialized
INFO - 2016-10-03 09:01:38 --> Security Class Initialized
INFO - 2016-10-03 09:01:38 --> URI Class Initialized
INFO - 2016-10-03 09:01:38 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:38 --> Input Class Initialized
DEBUG - 2016-10-03 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:38 --> Router Class Initialized
INFO - 2016-10-03 09:01:38 --> Input Class Initialized
INFO - 2016-10-03 09:01:38 --> Language Class Initialized
INFO - 2016-10-03 09:01:38 --> Language Class Initialized
INFO - 2016-10-03 09:01:38 --> Output Class Initialized
INFO - 2016-10-03 09:01:38 --> Loader Class Initialized
INFO - 2016-10-03 09:01:38 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:38 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:38 --> Input Class Initialized
INFO - 2016-10-03 09:01:38 --> Loader Class Initialized
INFO - 2016-10-03 09:01:38 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:38 --> Language Class Initialized
INFO - 2016-10-03 09:01:38 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:38 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:38 --> Loader Class Initialized
INFO - 2016-10-03 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:38 --> Controller Class Initialized
INFO - 2016-10-03 09:01:38 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:38 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:38 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:38 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:38 --> Total execution time: 0.1315
INFO - 2016-10-03 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:38 --> Controller Class Initialized
INFO - 2016-10-03 09:01:38 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:38 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:38 --> Total execution time: 0.1701
INFO - 2016-10-03 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:38 --> Controller Class Initialized
INFO - 2016-10-03 09:01:38 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:38 --> Config Class Initialized
INFO - 2016-10-03 09:01:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:01:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:01:38 --> Utf8 Class Initialized
INFO - 2016-10-03 09:01:38 --> URI Class Initialized
INFO - 2016-10-03 09:01:38 --> Router Class Initialized
INFO - 2016-10-03 09:01:38 --> Output Class Initialized
INFO - 2016-10-03 09:01:38 --> Security Class Initialized
DEBUG - 2016-10-03 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:01:38 --> Input Class Initialized
INFO - 2016-10-03 09:01:38 --> Language Class Initialized
INFO - 2016-10-03 09:01:38 --> Loader Class Initialized
INFO - 2016-10-03 09:01:38 --> Helper loaded: url_helper
INFO - 2016-10-03 09:01:38 --> Helper loaded: language_helper
INFO - 2016-10-03 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:01:38 --> Controller Class Initialized
INFO - 2016-10-03 09:01:38 --> Database Driver Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Model Class Initialized
INFO - 2016-10-03 09:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2016-10-03 09:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:01:38 --> Final output sent to browser
DEBUG - 2016-10-03 09:01:38 --> Total execution time: 0.0952
INFO - 2016-10-03 09:02:30 --> Config Class Initialized
INFO - 2016-10-03 09:02:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:02:30 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:02:30 --> Utf8 Class Initialized
INFO - 2016-10-03 09:02:30 --> URI Class Initialized
INFO - 2016-10-03 09:02:30 --> Router Class Initialized
INFO - 2016-10-03 09:02:30 --> Output Class Initialized
INFO - 2016-10-03 09:02:30 --> Security Class Initialized
DEBUG - 2016-10-03 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:02:30 --> Input Class Initialized
INFO - 2016-10-03 09:02:30 --> Language Class Initialized
INFO - 2016-10-03 09:02:30 --> Loader Class Initialized
INFO - 2016-10-03 09:02:30 --> Helper loaded: url_helper
INFO - 2016-10-03 09:02:30 --> Helper loaded: language_helper
INFO - 2016-10-03 09:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:02:30 --> Controller Class Initialized
INFO - 2016-10-03 09:02:30 --> Database Driver Class Initialized
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:02:30 --> Config Class Initialized
INFO - 2016-10-03 09:02:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:02:30 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:02:30 --> Utf8 Class Initialized
INFO - 2016-10-03 09:02:30 --> URI Class Initialized
INFO - 2016-10-03 09:02:30 --> Router Class Initialized
INFO - 2016-10-03 09:02:30 --> Output Class Initialized
INFO - 2016-10-03 09:02:30 --> Security Class Initialized
DEBUG - 2016-10-03 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:02:30 --> Input Class Initialized
INFO - 2016-10-03 09:02:30 --> Language Class Initialized
INFO - 2016-10-03 09:02:30 --> Loader Class Initialized
INFO - 2016-10-03 09:02:30 --> Helper loaded: url_helper
INFO - 2016-10-03 09:02:30 --> Helper loaded: language_helper
INFO - 2016-10-03 09:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:02:30 --> Controller Class Initialized
INFO - 2016-10-03 09:02:30 --> Database Driver Class Initialized
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:02:30 --> Model Class Initialized
INFO - 2016-10-03 09:02:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:02:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2016-10-03 09:02:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:02:31 --> Final output sent to browser
DEBUG - 2016-10-03 09:02:31 --> Total execution time: 0.0862
INFO - 2016-10-03 09:02:31 --> Config Class Initialized
INFO - 2016-10-03 09:02:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:02:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:02:31 --> Utf8 Class Initialized
INFO - 2016-10-03 09:02:31 --> URI Class Initialized
INFO - 2016-10-03 09:02:31 --> Router Class Initialized
INFO - 2016-10-03 09:02:31 --> Config Class Initialized
INFO - 2016-10-03 09:02:31 --> Hooks Class Initialized
INFO - 2016-10-03 09:02:31 --> Output Class Initialized
INFO - 2016-10-03 09:02:31 --> Security Class Initialized
DEBUG - 2016-10-03 09:02:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:02:31 --> Utf8 Class Initialized
DEBUG - 2016-10-03 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:02:31 --> Input Class Initialized
INFO - 2016-10-03 09:02:31 --> URI Class Initialized
INFO - 2016-10-03 09:02:31 --> Language Class Initialized
INFO - 2016-10-03 09:02:31 --> Router Class Initialized
INFO - 2016-10-03 09:02:31 --> Loader Class Initialized
INFO - 2016-10-03 09:02:31 --> Output Class Initialized
INFO - 2016-10-03 09:02:31 --> Helper loaded: url_helper
INFO - 2016-10-03 09:02:31 --> Security Class Initialized
INFO - 2016-10-03 09:02:31 --> Helper loaded: language_helper
DEBUG - 2016-10-03 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:02:31 --> Input Class Initialized
INFO - 2016-10-03 09:02:31 --> Language Class Initialized
INFO - 2016-10-03 09:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:02:31 --> Controller Class Initialized
INFO - 2016-10-03 09:02:31 --> Loader Class Initialized
INFO - 2016-10-03 09:02:31 --> Helper loaded: url_helper
INFO - 2016-10-03 09:02:31 --> Helper loaded: language_helper
INFO - 2016-10-03 09:02:31 --> Database Driver Class Initialized
INFO - 2016-10-03 09:02:31 --> Model Class Initialized
INFO - 2016-10-03 09:02:31 --> Model Class Initialized
INFO - 2016-10-03 09:02:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:02:31 --> Final output sent to browser
DEBUG - 2016-10-03 09:02:31 --> Total execution time: 0.0834
INFO - 2016-10-03 09:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:02:31 --> Controller Class Initialized
INFO - 2016-10-03 09:02:31 --> Database Driver Class Initialized
INFO - 2016-10-03 09:02:31 --> Model Class Initialized
INFO - 2016-10-03 09:02:31 --> Model Class Initialized
INFO - 2016-10-03 09:02:31 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-03 09:02:31 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-03 09:02:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-03 09:02:31 --> Final output sent to browser
DEBUG - 2016-10-03 09:02:31 --> Total execution time: 0.1035
INFO - 2016-10-03 09:03:01 --> Config Class Initialized
INFO - 2016-10-03 09:03:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:01 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:01 --> URI Class Initialized
INFO - 2016-10-03 09:03:01 --> Router Class Initialized
INFO - 2016-10-03 09:03:01 --> Output Class Initialized
INFO - 2016-10-03 09:03:01 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:01 --> Input Class Initialized
INFO - 2016-10-03 09:03:01 --> Language Class Initialized
INFO - 2016-10-03 09:03:01 --> Loader Class Initialized
INFO - 2016-10-03 09:03:01 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:01 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:01 --> Controller Class Initialized
INFO - 2016-10-03 09:03:01 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:01 --> Model Class Initialized
INFO - 2016-10-03 09:03:01 --> Model Class Initialized
INFO - 2016-10-03 09:03:01 --> Model Class Initialized
INFO - 2016-10-03 09:03:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:01 --> Final output sent to browser
DEBUG - 2016-10-03 09:03:01 --> Total execution time: 0.0632
INFO - 2016-10-03 09:03:31 --> Config Class Initialized
INFO - 2016-10-03 09:03:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:31 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:31 --> URI Class Initialized
INFO - 2016-10-03 09:03:31 --> Router Class Initialized
INFO - 2016-10-03 09:03:31 --> Output Class Initialized
INFO - 2016-10-03 09:03:31 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:31 --> Input Class Initialized
INFO - 2016-10-03 09:03:31 --> Language Class Initialized
INFO - 2016-10-03 09:03:31 --> Loader Class Initialized
INFO - 2016-10-03 09:03:31 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:31 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:31 --> Controller Class Initialized
INFO - 2016-10-03 09:03:31 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:31 --> Model Class Initialized
INFO - 2016-10-03 09:03:31 --> Model Class Initialized
INFO - 2016-10-03 09:03:31 --> Model Class Initialized
INFO - 2016-10-03 09:03:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:31 --> Final output sent to browser
DEBUG - 2016-10-03 09:03:31 --> Total execution time: 0.0644
INFO - 2016-10-03 09:03:43 --> Config Class Initialized
INFO - 2016-10-03 09:03:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:43 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:43 --> URI Class Initialized
INFO - 2016-10-03 09:03:43 --> Router Class Initialized
INFO - 2016-10-03 09:03:43 --> Output Class Initialized
INFO - 2016-10-03 09:03:43 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:43 --> Input Class Initialized
INFO - 2016-10-03 09:03:43 --> Language Class Initialized
INFO - 2016-10-03 09:03:43 --> Loader Class Initialized
INFO - 2016-10-03 09:03:43 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:43 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:43 --> Controller Class Initialized
INFO - 2016-10-03 09:03:43 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:43 --> Model Class Initialized
INFO - 2016-10-03 09:03:43 --> Model Class Initialized
INFO - 2016-10-03 09:03:43 --> Model Class Initialized
INFO - 2016-10-03 09:03:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:43 --> Config Class Initialized
INFO - 2016-10-03 09:03:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:43 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:43 --> URI Class Initialized
INFO - 2016-10-03 09:03:43 --> Router Class Initialized
INFO - 2016-10-03 09:03:43 --> Output Class Initialized
INFO - 2016-10-03 09:03:43 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:43 --> Input Class Initialized
INFO - 2016-10-03 09:03:43 --> Language Class Initialized
INFO - 2016-10-03 09:03:43 --> Loader Class Initialized
INFO - 2016-10-03 09:03:43 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:43 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:43 --> Controller Class Initialized
INFO - 2016-10-03 09:03:43 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:43 --> Model Class Initialized
INFO - 2016-10-03 09:03:44 --> Model Class Initialized
INFO - 2016-10-03 09:03:44 --> Model Class Initialized
INFO - 2016-10-03 09:03:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:03:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-10-03 09:03:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:03:44 --> Final output sent to browser
DEBUG - 2016-10-03 09:03:44 --> Total execution time: 0.0863
INFO - 2016-10-03 09:03:51 --> Config Class Initialized
INFO - 2016-10-03 09:03:51 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:51 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:51 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:51 --> URI Class Initialized
INFO - 2016-10-03 09:03:51 --> Router Class Initialized
INFO - 2016-10-03 09:03:51 --> Output Class Initialized
INFO - 2016-10-03 09:03:51 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:51 --> Input Class Initialized
INFO - 2016-10-03 09:03:51 --> Language Class Initialized
INFO - 2016-10-03 09:03:51 --> Loader Class Initialized
INFO - 2016-10-03 09:03:51 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:51 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:51 --> Controller Class Initialized
INFO - 2016-10-03 09:03:51 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:51 --> Model Class Initialized
INFO - 2016-10-03 09:03:51 --> Model Class Initialized
INFO - 2016-10-03 09:03:51 --> Model Class Initialized
INFO - 2016-10-03 09:03:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-10-03 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:03:51 --> Final output sent to browser
DEBUG - 2016-10-03 09:03:51 --> Total execution time: 0.0639
INFO - 2016-10-03 09:03:59 --> Config Class Initialized
INFO - 2016-10-03 09:03:59 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:59 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:59 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:59 --> URI Class Initialized
INFO - 2016-10-03 09:03:59 --> Router Class Initialized
INFO - 2016-10-03 09:03:59 --> Output Class Initialized
INFO - 2016-10-03 09:03:59 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:59 --> Input Class Initialized
INFO - 2016-10-03 09:03:59 --> Language Class Initialized
INFO - 2016-10-03 09:03:59 --> Loader Class Initialized
INFO - 2016-10-03 09:03:59 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:59 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:59 --> Controller Class Initialized
INFO - 2016-10-03 09:03:59 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:59 --> Model Class Initialized
INFO - 2016-10-03 09:03:59 --> Model Class Initialized
INFO - 2016-10-03 09:03:59 --> Model Class Initialized
INFO - 2016-10-03 09:03:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:59 --> Config Class Initialized
INFO - 2016-10-03 09:03:59 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:03:59 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:03:59 --> Utf8 Class Initialized
INFO - 2016-10-03 09:03:59 --> URI Class Initialized
INFO - 2016-10-03 09:03:59 --> Router Class Initialized
INFO - 2016-10-03 09:03:59 --> Output Class Initialized
INFO - 2016-10-03 09:03:59 --> Security Class Initialized
DEBUG - 2016-10-03 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:03:59 --> Input Class Initialized
INFO - 2016-10-03 09:03:59 --> Language Class Initialized
INFO - 2016-10-03 09:03:59 --> Loader Class Initialized
INFO - 2016-10-03 09:03:59 --> Helper loaded: url_helper
INFO - 2016-10-03 09:03:59 --> Helper loaded: language_helper
INFO - 2016-10-03 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:03:59 --> Controller Class Initialized
INFO - 2016-10-03 09:03:59 --> Database Driver Class Initialized
INFO - 2016-10-03 09:03:59 --> Model Class Initialized
INFO - 2016-10-03 09:03:59 --> Model Class Initialized
INFO - 2016-10-03 09:03:59 --> Model Class Initialized
INFO - 2016-10-03 09:03:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:03:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:03:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-10-03 09:03:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:03:59 --> Final output sent to browser
DEBUG - 2016-10-03 09:03:59 --> Total execution time: 0.0650
INFO - 2016-10-03 09:04:05 --> Config Class Initialized
INFO - 2016-10-03 09:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:04:05 --> Utf8 Class Initialized
INFO - 2016-10-03 09:04:05 --> URI Class Initialized
INFO - 2016-10-03 09:04:05 --> Router Class Initialized
INFO - 2016-10-03 09:04:05 --> Output Class Initialized
INFO - 2016-10-03 09:04:05 --> Security Class Initialized
DEBUG - 2016-10-03 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:04:05 --> Input Class Initialized
INFO - 2016-10-03 09:04:05 --> Language Class Initialized
INFO - 2016-10-03 09:04:05 --> Loader Class Initialized
INFO - 2016-10-03 09:04:05 --> Helper loaded: url_helper
INFO - 2016-10-03 09:04:05 --> Helper loaded: language_helper
INFO - 2016-10-03 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:04:05 --> Controller Class Initialized
INFO - 2016-10-03 09:04:05 --> Database Driver Class Initialized
INFO - 2016-10-03 09:04:05 --> Model Class Initialized
INFO - 2016-10-03 09:04:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:04:05 --> Config Class Initialized
INFO - 2016-10-03 09:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:04:05 --> Utf8 Class Initialized
INFO - 2016-10-03 09:04:05 --> URI Class Initialized
INFO - 2016-10-03 09:04:05 --> Router Class Initialized
INFO - 2016-10-03 09:04:05 --> Output Class Initialized
INFO - 2016-10-03 09:04:05 --> Security Class Initialized
DEBUG - 2016-10-03 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:04:05 --> Input Class Initialized
INFO - 2016-10-03 09:04:05 --> Language Class Initialized
INFO - 2016-10-03 09:04:05 --> Loader Class Initialized
INFO - 2016-10-03 09:04:05 --> Helper loaded: url_helper
INFO - 2016-10-03 09:04:05 --> Helper loaded: language_helper
INFO - 2016-10-03 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:04:05 --> Controller Class Initialized
INFO - 2016-10-03 09:04:05 --> Database Driver Class Initialized
INFO - 2016-10-03 09:04:05 --> Model Class Initialized
INFO - 2016-10-03 09:04:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:04:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-03 09:04:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-03 09:04:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-03 09:04:05 --> Final output sent to browser
DEBUG - 2016-10-03 09:04:05 --> Total execution time: 0.0591
INFO - 2016-10-03 09:04:10 --> Config Class Initialized
INFO - 2016-10-03 09:04:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:04:10 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:04:10 --> Utf8 Class Initialized
INFO - 2016-10-03 09:04:10 --> URI Class Initialized
INFO - 2016-10-03 09:04:10 --> Router Class Initialized
INFO - 2016-10-03 09:04:10 --> Output Class Initialized
INFO - 2016-10-03 09:04:10 --> Security Class Initialized
DEBUG - 2016-10-03 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:04:10 --> Input Class Initialized
INFO - 2016-10-03 09:04:10 --> Language Class Initialized
INFO - 2016-10-03 09:04:10 --> Loader Class Initialized
INFO - 2016-10-03 09:04:10 --> Helper loaded: url_helper
INFO - 2016-10-03 09:04:10 --> Helper loaded: language_helper
INFO - 2016-10-03 09:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:04:10 --> Controller Class Initialized
INFO - 2016-10-03 09:04:10 --> Database Driver Class Initialized
INFO - 2016-10-03 09:04:10 --> Model Class Initialized
INFO - 2016-10-03 09:04:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:04:10 --> Config Class Initialized
INFO - 2016-10-03 09:04:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:04:10 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:04:10 --> Utf8 Class Initialized
INFO - 2016-10-03 09:04:10 --> URI Class Initialized
INFO - 2016-10-03 09:04:10 --> Router Class Initialized
INFO - 2016-10-03 09:04:10 --> Output Class Initialized
INFO - 2016-10-03 09:04:10 --> Security Class Initialized
DEBUG - 2016-10-03 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:04:10 --> Input Class Initialized
INFO - 2016-10-03 09:04:10 --> Language Class Initialized
INFO - 2016-10-03 09:04:10 --> Loader Class Initialized
INFO - 2016-10-03 09:04:10 --> Helper loaded: url_helper
INFO - 2016-10-03 09:04:10 --> Helper loaded: language_helper
INFO - 2016-10-03 09:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:04:10 --> Controller Class Initialized
INFO - 2016-10-03 09:04:10 --> Database Driver Class Initialized
INFO - 2016-10-03 09:04:10 --> Model Class Initialized
INFO - 2016-10-03 09:04:10 --> Model Class Initialized
INFO - 2016-10-03 09:04:10 --> Model Class Initialized
INFO - 2016-10-03 09:04:10 --> Model Class Initialized
INFO - 2016-10-03 09:04:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:04:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:04:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-03 09:04:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:04:10 --> Final output sent to browser
DEBUG - 2016-10-03 09:04:10 --> Total execution time: 0.0674
INFO - 2016-10-03 09:04:12 --> Config Class Initialized
INFO - 2016-10-03 09:04:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:04:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:04:12 --> Utf8 Class Initialized
INFO - 2016-10-03 09:04:12 --> URI Class Initialized
INFO - 2016-10-03 09:04:12 --> Router Class Initialized
INFO - 2016-10-03 09:04:12 --> Output Class Initialized
INFO - 2016-10-03 09:04:12 --> Security Class Initialized
DEBUG - 2016-10-03 09:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:04:12 --> Input Class Initialized
INFO - 2016-10-03 09:04:12 --> Language Class Initialized
INFO - 2016-10-03 09:04:12 --> Loader Class Initialized
INFO - 2016-10-03 09:04:12 --> Helper loaded: url_helper
INFO - 2016-10-03 09:04:12 --> Helper loaded: language_helper
INFO - 2016-10-03 09:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:04:12 --> Controller Class Initialized
INFO - 2016-10-03 09:04:12 --> Database Driver Class Initialized
INFO - 2016-10-03 09:04:12 --> Model Class Initialized
INFO - 2016-10-03 09:04:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:04:12 --> Helper loaded: form_helper
INFO - 2016-10-03 09:04:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:04:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-03 09:04:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:04:12 --> Final output sent to browser
DEBUG - 2016-10-03 09:04:12 --> Total execution time: 0.0643
INFO - 2016-10-03 09:04:43 --> Config Class Initialized
INFO - 2016-10-03 09:04:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:04:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:04:43 --> Utf8 Class Initialized
INFO - 2016-10-03 09:04:43 --> URI Class Initialized
INFO - 2016-10-03 09:04:43 --> Router Class Initialized
INFO - 2016-10-03 09:04:43 --> Output Class Initialized
INFO - 2016-10-03 09:04:43 --> Security Class Initialized
DEBUG - 2016-10-03 09:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:04:43 --> Input Class Initialized
INFO - 2016-10-03 09:04:43 --> Language Class Initialized
INFO - 2016-10-03 09:04:43 --> Loader Class Initialized
INFO - 2016-10-03 09:04:43 --> Helper loaded: url_helper
INFO - 2016-10-03 09:04:43 --> Helper loaded: language_helper
INFO - 2016-10-03 09:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:04:43 --> Controller Class Initialized
INFO - 2016-10-03 09:04:43 --> Database Driver Class Initialized
INFO - 2016-10-03 09:04:43 --> Model Class Initialized
INFO - 2016-10-03 09:04:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:04:43 --> Model Class Initialized
INFO - 2016-10-03 09:04:43 --> Model Class Initialized
INFO - 2016-10-03 09:04:43 --> Helper loaded: form_helper
INFO - 2016-10-03 09:04:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:04:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:04:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:04:43 --> Final output sent to browser
DEBUG - 2016-10-03 09:04:43 --> Total execution time: 0.0825
INFO - 2016-10-03 09:12:40 --> Config Class Initialized
INFO - 2016-10-03 09:12:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:12:40 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:12:40 --> Utf8 Class Initialized
INFO - 2016-10-03 09:12:40 --> URI Class Initialized
INFO - 2016-10-03 09:12:40 --> Router Class Initialized
INFO - 2016-10-03 09:12:40 --> Output Class Initialized
INFO - 2016-10-03 09:12:40 --> Security Class Initialized
DEBUG - 2016-10-03 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:12:40 --> Input Class Initialized
INFO - 2016-10-03 09:12:40 --> Language Class Initialized
INFO - 2016-10-03 09:12:40 --> Loader Class Initialized
INFO - 2016-10-03 09:12:40 --> Helper loaded: url_helper
INFO - 2016-10-03 09:12:40 --> Helper loaded: language_helper
INFO - 2016-10-03 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:12:40 --> Controller Class Initialized
INFO - 2016-10-03 09:12:40 --> Database Driver Class Initialized
INFO - 2016-10-03 09:12:40 --> Model Class Initialized
INFO - 2016-10-03 09:12:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:12:40 --> Model Class Initialized
INFO - 2016-10-03 09:12:40 --> Model Class Initialized
INFO - 2016-10-03 09:12:40 --> Helper loaded: form_helper
INFO - 2016-10-03 09:12:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:12:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:12:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:12:40 --> Final output sent to browser
DEBUG - 2016-10-03 09:12:40 --> Total execution time: 0.0806
INFO - 2016-10-03 09:12:41 --> Config Class Initialized
INFO - 2016-10-03 09:12:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:12:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:12:41 --> Utf8 Class Initialized
INFO - 2016-10-03 09:12:41 --> URI Class Initialized
INFO - 2016-10-03 09:12:41 --> Router Class Initialized
INFO - 2016-10-03 09:12:41 --> Output Class Initialized
INFO - 2016-10-03 09:12:41 --> Security Class Initialized
DEBUG - 2016-10-03 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:12:41 --> Input Class Initialized
INFO - 2016-10-03 09:12:41 --> Language Class Initialized
INFO - 2016-10-03 09:12:41 --> Loader Class Initialized
INFO - 2016-10-03 09:12:41 --> Helper loaded: url_helper
INFO - 2016-10-03 09:12:41 --> Helper loaded: language_helper
INFO - 2016-10-03 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:12:41 --> Controller Class Initialized
INFO - 2016-10-03 09:12:41 --> Database Driver Class Initialized
INFO - 2016-10-03 09:12:41 --> Model Class Initialized
INFO - 2016-10-03 09:12:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:12:41 --> Model Class Initialized
INFO - 2016-10-03 09:12:41 --> Model Class Initialized
INFO - 2016-10-03 09:12:41 --> Helper loaded: form_helper
INFO - 2016-10-03 09:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:12:41 --> Final output sent to browser
DEBUG - 2016-10-03 09:12:41 --> Total execution time: 0.1089
INFO - 2016-10-03 09:14:42 --> Config Class Initialized
INFO - 2016-10-03 09:14:42 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:14:42 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:14:42 --> Utf8 Class Initialized
INFO - 2016-10-03 09:14:42 --> URI Class Initialized
INFO - 2016-10-03 09:14:42 --> Router Class Initialized
INFO - 2016-10-03 09:14:42 --> Output Class Initialized
INFO - 2016-10-03 09:14:42 --> Security Class Initialized
DEBUG - 2016-10-03 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:14:42 --> Input Class Initialized
INFO - 2016-10-03 09:14:42 --> Language Class Initialized
INFO - 2016-10-03 09:14:42 --> Loader Class Initialized
INFO - 2016-10-03 09:14:42 --> Helper loaded: url_helper
INFO - 2016-10-03 09:14:42 --> Helper loaded: language_helper
INFO - 2016-10-03 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:14:42 --> Controller Class Initialized
INFO - 2016-10-03 09:14:42 --> Database Driver Class Initialized
INFO - 2016-10-03 09:14:42 --> Model Class Initialized
INFO - 2016-10-03 09:14:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:14:42 --> Model Class Initialized
INFO - 2016-10-03 09:14:42 --> Model Class Initialized
INFO - 2016-10-03 09:14:42 --> Helper loaded: form_helper
INFO - 2016-10-03 09:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:14:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:14:42 --> Final output sent to browser
DEBUG - 2016-10-03 09:14:42 --> Total execution time: 0.0805
INFO - 2016-10-03 09:30:18 --> Config Class Initialized
INFO - 2016-10-03 09:30:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:30:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:30:18 --> Utf8 Class Initialized
INFO - 2016-10-03 09:30:18 --> URI Class Initialized
INFO - 2016-10-03 09:30:18 --> Router Class Initialized
INFO - 2016-10-03 09:30:18 --> Output Class Initialized
INFO - 2016-10-03 09:30:18 --> Security Class Initialized
DEBUG - 2016-10-03 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:30:18 --> Input Class Initialized
INFO - 2016-10-03 09:30:18 --> Language Class Initialized
INFO - 2016-10-03 09:30:18 --> Loader Class Initialized
INFO - 2016-10-03 09:30:18 --> Helper loaded: url_helper
INFO - 2016-10-03 09:30:18 --> Helper loaded: language_helper
INFO - 2016-10-03 09:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:30:18 --> Controller Class Initialized
INFO - 2016-10-03 09:30:18 --> Database Driver Class Initialized
INFO - 2016-10-03 09:30:18 --> Model Class Initialized
INFO - 2016-10-03 09:30:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:30:18 --> Model Class Initialized
INFO - 2016-10-03 09:30:18 --> Model Class Initialized
INFO - 2016-10-03 09:30:18 --> Helper loaded: form_helper
INFO - 2016-10-03 09:30:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:30:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:30:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:30:18 --> Final output sent to browser
DEBUG - 2016-10-03 09:30:18 --> Total execution time: 0.0974
INFO - 2016-10-03 09:30:33 --> Config Class Initialized
INFO - 2016-10-03 09:30:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:30:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:30:33 --> Utf8 Class Initialized
INFO - 2016-10-03 09:30:33 --> URI Class Initialized
INFO - 2016-10-03 09:30:33 --> Router Class Initialized
INFO - 2016-10-03 09:30:33 --> Output Class Initialized
INFO - 2016-10-03 09:30:33 --> Security Class Initialized
DEBUG - 2016-10-03 09:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:30:33 --> Input Class Initialized
INFO - 2016-10-03 09:30:33 --> Language Class Initialized
INFO - 2016-10-03 09:30:33 --> Loader Class Initialized
INFO - 2016-10-03 09:30:33 --> Helper loaded: url_helper
INFO - 2016-10-03 09:30:33 --> Helper loaded: language_helper
INFO - 2016-10-03 09:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:30:34 --> Controller Class Initialized
INFO - 2016-10-03 09:30:34 --> Database Driver Class Initialized
INFO - 2016-10-03 09:30:34 --> Model Class Initialized
INFO - 2016-10-03 09:30:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:30:34 --> Model Class Initialized
INFO - 2016-10-03 09:30:34 --> Model Class Initialized
INFO - 2016-10-03 09:30:34 --> Helper loaded: form_helper
INFO - 2016-10-03 09:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:30:34 --> Final output sent to browser
DEBUG - 2016-10-03 09:30:34 --> Total execution time: 0.1103
INFO - 2016-10-03 09:34:52 --> Config Class Initialized
INFO - 2016-10-03 09:34:52 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:34:52 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:34:52 --> Utf8 Class Initialized
INFO - 2016-10-03 09:34:52 --> URI Class Initialized
INFO - 2016-10-03 09:34:52 --> Router Class Initialized
INFO - 2016-10-03 09:34:52 --> Output Class Initialized
INFO - 2016-10-03 09:34:52 --> Security Class Initialized
DEBUG - 2016-10-03 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:34:52 --> Input Class Initialized
INFO - 2016-10-03 09:34:52 --> Language Class Initialized
INFO - 2016-10-03 09:34:52 --> Loader Class Initialized
INFO - 2016-10-03 09:34:52 --> Helper loaded: url_helper
INFO - 2016-10-03 09:34:52 --> Helper loaded: language_helper
INFO - 2016-10-03 09:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:34:52 --> Controller Class Initialized
INFO - 2016-10-03 09:34:52 --> Database Driver Class Initialized
INFO - 2016-10-03 09:34:52 --> Model Class Initialized
INFO - 2016-10-03 09:34:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:34:52 --> Model Class Initialized
INFO - 2016-10-03 09:34:52 --> Model Class Initialized
INFO - 2016-10-03 09:34:52 --> Helper loaded: form_helper
ERROR - 2016-10-03 09:34:52 --> Severity: Notice --> Undefined variable: disc_m C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 180
ERROR - 2016-10-03 09:34:52 --> Severity: Notice --> Undefined variable: disc_l C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
INFO - 2016-10-03 09:34:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:34:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:34:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:34:52 --> Final output sent to browser
DEBUG - 2016-10-03 09:34:52 --> Total execution time: 0.1068
INFO - 2016-10-03 09:35:12 --> Config Class Initialized
INFO - 2016-10-03 09:35:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:35:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:35:12 --> Utf8 Class Initialized
INFO - 2016-10-03 09:35:12 --> URI Class Initialized
INFO - 2016-10-03 09:35:12 --> Router Class Initialized
INFO - 2016-10-03 09:35:12 --> Output Class Initialized
INFO - 2016-10-03 09:35:12 --> Security Class Initialized
DEBUG - 2016-10-03 09:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:35:12 --> Input Class Initialized
INFO - 2016-10-03 09:35:12 --> Language Class Initialized
INFO - 2016-10-03 09:35:12 --> Loader Class Initialized
INFO - 2016-10-03 09:35:12 --> Helper loaded: url_helper
INFO - 2016-10-03 09:35:12 --> Helper loaded: language_helper
INFO - 2016-10-03 09:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:35:12 --> Controller Class Initialized
INFO - 2016-10-03 09:35:12 --> Database Driver Class Initialized
INFO - 2016-10-03 09:35:12 --> Model Class Initialized
INFO - 2016-10-03 09:35:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:35:12 --> Model Class Initialized
INFO - 2016-10-03 09:35:12 --> Model Class Initialized
INFO - 2016-10-03 09:35:12 --> Helper loaded: form_helper
INFO - 2016-10-03 09:35:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:35:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:35:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:35:12 --> Final output sent to browser
DEBUG - 2016-10-03 09:35:12 --> Total execution time: 0.1021
INFO - 2016-10-03 09:35:39 --> Config Class Initialized
INFO - 2016-10-03 09:35:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:35:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:35:39 --> Utf8 Class Initialized
INFO - 2016-10-03 09:35:39 --> URI Class Initialized
INFO - 2016-10-03 09:35:39 --> Router Class Initialized
INFO - 2016-10-03 09:35:39 --> Output Class Initialized
INFO - 2016-10-03 09:35:39 --> Security Class Initialized
DEBUG - 2016-10-03 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:35:39 --> Input Class Initialized
INFO - 2016-10-03 09:35:39 --> Language Class Initialized
INFO - 2016-10-03 09:35:39 --> Loader Class Initialized
INFO - 2016-10-03 09:35:39 --> Helper loaded: url_helper
INFO - 2016-10-03 09:35:39 --> Helper loaded: language_helper
INFO - 2016-10-03 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:35:39 --> Controller Class Initialized
INFO - 2016-10-03 09:35:39 --> Database Driver Class Initialized
INFO - 2016-10-03 09:35:39 --> Model Class Initialized
INFO - 2016-10-03 09:35:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:35:39 --> Model Class Initialized
INFO - 2016-10-03 09:35:39 --> Model Class Initialized
INFO - 2016-10-03 09:35:39 --> Helper loaded: form_helper
INFO - 2016-10-03 09:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:35:39 --> Final output sent to browser
DEBUG - 2016-10-03 09:35:39 --> Total execution time: 0.0888
INFO - 2016-10-03 09:36:10 --> Config Class Initialized
INFO - 2016-10-03 09:36:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:36:10 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:36:10 --> Utf8 Class Initialized
INFO - 2016-10-03 09:36:10 --> URI Class Initialized
INFO - 2016-10-03 09:36:10 --> Router Class Initialized
INFO - 2016-10-03 09:36:10 --> Output Class Initialized
INFO - 2016-10-03 09:36:10 --> Security Class Initialized
DEBUG - 2016-10-03 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:36:10 --> Input Class Initialized
INFO - 2016-10-03 09:36:10 --> Language Class Initialized
INFO - 2016-10-03 09:36:10 --> Loader Class Initialized
INFO - 2016-10-03 09:36:10 --> Helper loaded: url_helper
INFO - 2016-10-03 09:36:10 --> Helper loaded: language_helper
INFO - 2016-10-03 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:36:10 --> Controller Class Initialized
INFO - 2016-10-03 09:36:10 --> Database Driver Class Initialized
INFO - 2016-10-03 09:36:10 --> Model Class Initialized
INFO - 2016-10-03 09:36:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:36:10 --> Model Class Initialized
INFO - 2016-10-03 09:36:10 --> Model Class Initialized
INFO - 2016-10-03 09:36:10 --> Helper loaded: form_helper
INFO - 2016-10-03 09:36:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:36:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:36:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:36:10 --> Final output sent to browser
DEBUG - 2016-10-03 09:36:10 --> Total execution time: 0.0998
INFO - 2016-10-03 09:38:57 --> Config Class Initialized
INFO - 2016-10-03 09:38:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:38:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:38:57 --> Utf8 Class Initialized
INFO - 2016-10-03 09:38:57 --> URI Class Initialized
INFO - 2016-10-03 09:38:57 --> Router Class Initialized
INFO - 2016-10-03 09:38:57 --> Output Class Initialized
INFO - 2016-10-03 09:38:57 --> Security Class Initialized
DEBUG - 2016-10-03 09:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:38:57 --> Input Class Initialized
INFO - 2016-10-03 09:38:57 --> Language Class Initialized
INFO - 2016-10-03 09:38:57 --> Loader Class Initialized
INFO - 2016-10-03 09:38:57 --> Helper loaded: url_helper
INFO - 2016-10-03 09:38:57 --> Helper loaded: language_helper
INFO - 2016-10-03 09:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:38:57 --> Controller Class Initialized
INFO - 2016-10-03 09:38:57 --> Database Driver Class Initialized
INFO - 2016-10-03 09:38:57 --> Model Class Initialized
INFO - 2016-10-03 09:38:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:38:57 --> Model Class Initialized
INFO - 2016-10-03 09:38:57 --> Model Class Initialized
INFO - 2016-10-03 09:38:57 --> Helper loaded: form_helper
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:38:57 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
INFO - 2016-10-03 09:38:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:38:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:38:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:38:57 --> Final output sent to browser
DEBUG - 2016-10-03 09:38:57 --> Total execution time: 0.1312
INFO - 2016-10-03 09:39:18 --> Config Class Initialized
INFO - 2016-10-03 09:39:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:39:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:39:18 --> Utf8 Class Initialized
INFO - 2016-10-03 09:39:18 --> URI Class Initialized
INFO - 2016-10-03 09:39:18 --> Router Class Initialized
INFO - 2016-10-03 09:39:18 --> Output Class Initialized
INFO - 2016-10-03 09:39:18 --> Security Class Initialized
DEBUG - 2016-10-03 09:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:39:18 --> Input Class Initialized
INFO - 2016-10-03 09:39:18 --> Language Class Initialized
INFO - 2016-10-03 09:39:18 --> Loader Class Initialized
INFO - 2016-10-03 09:39:18 --> Helper loaded: url_helper
INFO - 2016-10-03 09:39:18 --> Helper loaded: language_helper
INFO - 2016-10-03 09:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:39:18 --> Controller Class Initialized
INFO - 2016-10-03 09:39:18 --> Database Driver Class Initialized
INFO - 2016-10-03 09:39:18 --> Model Class Initialized
INFO - 2016-10-03 09:39:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:39:18 --> Model Class Initialized
INFO - 2016-10-03 09:39:18 --> Model Class Initialized
INFO - 2016-10-03 09:39:18 --> Helper loaded: form_helper
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostD' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostI' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostS' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 09:39:18 --> Severity: Warning --> Illegal string offset 'mostC' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
INFO - 2016-10-03 09:39:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:39:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:39:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:39:18 --> Final output sent to browser
DEBUG - 2016-10-03 09:39:18 --> Total execution time: 0.1057
INFO - 2016-10-03 09:45:35 --> Config Class Initialized
INFO - 2016-10-03 09:45:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:45:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:45:35 --> Utf8 Class Initialized
INFO - 2016-10-03 09:45:35 --> URI Class Initialized
INFO - 2016-10-03 09:45:35 --> Router Class Initialized
INFO - 2016-10-03 09:45:35 --> Output Class Initialized
INFO - 2016-10-03 09:45:35 --> Security Class Initialized
DEBUG - 2016-10-03 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:45:35 --> Input Class Initialized
INFO - 2016-10-03 09:45:35 --> Language Class Initialized
INFO - 2016-10-03 09:45:35 --> Loader Class Initialized
INFO - 2016-10-03 09:45:35 --> Helper loaded: url_helper
INFO - 2016-10-03 09:45:35 --> Helper loaded: language_helper
INFO - 2016-10-03 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:45:35 --> Controller Class Initialized
INFO - 2016-10-03 09:45:35 --> Database Driver Class Initialized
INFO - 2016-10-03 09:45:35 --> Model Class Initialized
INFO - 2016-10-03 09:45:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:45:35 --> Model Class Initialized
INFO - 2016-10-03 09:45:35 --> Model Class Initialized
INFO - 2016-10-03 09:45:35 --> Helper loaded: form_helper
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:45:35 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
INFO - 2016-10-03 09:45:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:45:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:45:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:45:35 --> Final output sent to browser
DEBUG - 2016-10-03 09:45:35 --> Total execution time: 0.0985
INFO - 2016-10-03 09:47:38 --> Config Class Initialized
INFO - 2016-10-03 09:47:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:47:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:47:38 --> Utf8 Class Initialized
INFO - 2016-10-03 09:47:38 --> URI Class Initialized
INFO - 2016-10-03 09:47:38 --> Router Class Initialized
INFO - 2016-10-03 09:47:38 --> Output Class Initialized
INFO - 2016-10-03 09:47:38 --> Security Class Initialized
DEBUG - 2016-10-03 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:47:38 --> Input Class Initialized
INFO - 2016-10-03 09:47:38 --> Language Class Initialized
INFO - 2016-10-03 09:47:38 --> Loader Class Initialized
INFO - 2016-10-03 09:47:38 --> Helper loaded: url_helper
INFO - 2016-10-03 09:47:38 --> Helper loaded: language_helper
INFO - 2016-10-03 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:47:38 --> Controller Class Initialized
INFO - 2016-10-03 09:47:38 --> Database Driver Class Initialized
INFO - 2016-10-03 09:47:38 --> Model Class Initialized
INFO - 2016-10-03 09:47:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:47:38 --> Model Class Initialized
INFO - 2016-10-03 09:47:38 --> Model Class Initialized
INFO - 2016-10-03 09:47:38 --> Helper loaded: form_helper
ERROR - 2016-10-03 09:47:38 --> Severity: Notice --> Undefined index: mostD C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:47:38 --> Severity: Notice --> Undefined index: mostI C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:47:38 --> Severity: Notice --> Undefined index: mostS C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
ERROR - 2016-10-03 09:47:38 --> Severity: Notice --> Undefined index: mostC C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 181
INFO - 2016-10-03 09:47:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:47:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:47:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:47:38 --> Final output sent to browser
DEBUG - 2016-10-03 09:47:38 --> Total execution time: 0.0920
INFO - 2016-10-03 09:50:53 --> Config Class Initialized
INFO - 2016-10-03 09:50:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:50:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:50:53 --> Utf8 Class Initialized
INFO - 2016-10-03 09:50:53 --> URI Class Initialized
INFO - 2016-10-03 09:50:53 --> Router Class Initialized
INFO - 2016-10-03 09:50:53 --> Output Class Initialized
INFO - 2016-10-03 09:50:53 --> Security Class Initialized
DEBUG - 2016-10-03 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:50:53 --> Input Class Initialized
INFO - 2016-10-03 09:50:53 --> Language Class Initialized
INFO - 2016-10-03 09:50:53 --> Loader Class Initialized
INFO - 2016-10-03 09:50:53 --> Helper loaded: url_helper
INFO - 2016-10-03 09:50:53 --> Helper loaded: language_helper
INFO - 2016-10-03 09:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:50:53 --> Controller Class Initialized
INFO - 2016-10-03 09:50:53 --> Database Driver Class Initialized
INFO - 2016-10-03 09:50:53 --> Model Class Initialized
INFO - 2016-10-03 09:50:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:50:53 --> Model Class Initialized
INFO - 2016-10-03 09:50:53 --> Model Class Initialized
INFO - 2016-10-03 09:50:53 --> Helper loaded: form_helper
INFO - 2016-10-03 09:50:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: li C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 225
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: mostD C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 233
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: leastD C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 233
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: mostI C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 234
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: leastI C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 234
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: mostS C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 235
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: leastS C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 235
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: mostC C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 236
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: leastC C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 236
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: mostX C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 237
ERROR - 2016-10-03 09:50:53 --> Severity: Notice --> Undefined index: leastX C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 237
INFO - 2016-10-03 09:50:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:50:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:50:53 --> Final output sent to browser
DEBUG - 2016-10-03 09:50:53 --> Total execution time: 0.0981
INFO - 2016-10-03 09:51:06 --> Config Class Initialized
INFO - 2016-10-03 09:51:06 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:51:06 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:51:06 --> Utf8 Class Initialized
INFO - 2016-10-03 09:51:06 --> URI Class Initialized
INFO - 2016-10-03 09:51:06 --> Router Class Initialized
INFO - 2016-10-03 09:51:06 --> Output Class Initialized
INFO - 2016-10-03 09:51:06 --> Security Class Initialized
DEBUG - 2016-10-03 09:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:51:06 --> Input Class Initialized
INFO - 2016-10-03 09:51:06 --> Language Class Initialized
INFO - 2016-10-03 09:51:06 --> Loader Class Initialized
INFO - 2016-10-03 09:51:06 --> Helper loaded: url_helper
INFO - 2016-10-03 09:51:06 --> Helper loaded: language_helper
INFO - 2016-10-03 09:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:51:06 --> Controller Class Initialized
INFO - 2016-10-03 09:51:06 --> Database Driver Class Initialized
INFO - 2016-10-03 09:51:06 --> Model Class Initialized
INFO - 2016-10-03 09:51:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:51:06 --> Model Class Initialized
INFO - 2016-10-03 09:51:06 --> Model Class Initialized
INFO - 2016-10-03 09:51:06 --> Helper loaded: form_helper
INFO - 2016-10-03 09:51:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: mostD C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 233
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: leastD C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 233
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: mostI C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 234
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: leastI C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 234
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: mostS C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 235
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: leastS C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 235
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: mostC C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 236
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: leastC C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 236
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: mostX C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 237
ERROR - 2016-10-03 09:51:07 --> Severity: Notice --> Undefined index: leastX C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 237
INFO - 2016-10-03 09:51:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:51:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:51:07 --> Final output sent to browser
DEBUG - 2016-10-03 09:51:07 --> Total execution time: 0.0993
INFO - 2016-10-03 09:51:46 --> Config Class Initialized
INFO - 2016-10-03 09:51:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 09:51:46 --> UTF-8 Support Enabled
INFO - 2016-10-03 09:51:46 --> Utf8 Class Initialized
INFO - 2016-10-03 09:51:46 --> URI Class Initialized
INFO - 2016-10-03 09:51:46 --> Router Class Initialized
INFO - 2016-10-03 09:51:46 --> Output Class Initialized
INFO - 2016-10-03 09:51:46 --> Security Class Initialized
DEBUG - 2016-10-03 09:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 09:51:46 --> Input Class Initialized
INFO - 2016-10-03 09:51:46 --> Language Class Initialized
INFO - 2016-10-03 09:51:46 --> Loader Class Initialized
INFO - 2016-10-03 09:51:46 --> Helper loaded: url_helper
INFO - 2016-10-03 09:51:46 --> Helper loaded: language_helper
INFO - 2016-10-03 09:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 09:51:46 --> Controller Class Initialized
INFO - 2016-10-03 09:51:46 --> Database Driver Class Initialized
INFO - 2016-10-03 09:51:46 --> Model Class Initialized
INFO - 2016-10-03 09:51:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 09:51:46 --> Model Class Initialized
INFO - 2016-10-03 09:51:46 --> Model Class Initialized
INFO - 2016-10-03 09:51:46 --> Helper loaded: form_helper
INFO - 2016-10-03 09:51:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 09:51:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 09:51:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 09:51:46 --> Final output sent to browser
DEBUG - 2016-10-03 09:51:46 --> Total execution time: 0.0806
INFO - 2016-10-03 10:03:31 --> Config Class Initialized
INFO - 2016-10-03 10:03:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 10:03:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 10:03:31 --> Utf8 Class Initialized
INFO - 2016-10-03 10:03:31 --> URI Class Initialized
INFO - 2016-10-03 10:03:31 --> Router Class Initialized
INFO - 2016-10-03 10:03:31 --> Output Class Initialized
INFO - 2016-10-03 10:03:31 --> Security Class Initialized
DEBUG - 2016-10-03 10:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 10:03:31 --> Input Class Initialized
INFO - 2016-10-03 10:03:31 --> Language Class Initialized
INFO - 2016-10-03 10:03:31 --> Loader Class Initialized
INFO - 2016-10-03 10:03:31 --> Helper loaded: url_helper
INFO - 2016-10-03 10:03:31 --> Helper loaded: language_helper
INFO - 2016-10-03 10:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 10:03:31 --> Controller Class Initialized
INFO - 2016-10-03 10:03:31 --> Database Driver Class Initialized
INFO - 2016-10-03 10:03:31 --> Model Class Initialized
INFO - 2016-10-03 10:03:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 10:03:31 --> Model Class Initialized
INFO - 2016-10-03 10:03:31 --> Model Class Initialized
INFO - 2016-10-03 10:03:31 --> Helper loaded: form_helper
INFO - 2016-10-03 10:03:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 10:03:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 10:03:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 10:03:31 --> Final output sent to browser
DEBUG - 2016-10-03 10:03:31 --> Total execution time: 0.0806
INFO - 2016-10-03 10:04:48 --> Config Class Initialized
INFO - 2016-10-03 10:04:48 --> Hooks Class Initialized
DEBUG - 2016-10-03 10:04:48 --> UTF-8 Support Enabled
INFO - 2016-10-03 10:04:48 --> Utf8 Class Initialized
INFO - 2016-10-03 10:04:48 --> URI Class Initialized
INFO - 2016-10-03 10:04:48 --> Router Class Initialized
INFO - 2016-10-03 10:04:48 --> Output Class Initialized
INFO - 2016-10-03 10:04:48 --> Security Class Initialized
DEBUG - 2016-10-03 10:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 10:04:48 --> Input Class Initialized
INFO - 2016-10-03 10:04:48 --> Language Class Initialized
INFO - 2016-10-03 10:04:48 --> Loader Class Initialized
INFO - 2016-10-03 10:04:48 --> Helper loaded: url_helper
INFO - 2016-10-03 10:04:48 --> Helper loaded: language_helper
INFO - 2016-10-03 10:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 10:04:48 --> Controller Class Initialized
INFO - 2016-10-03 10:04:48 --> Database Driver Class Initialized
INFO - 2016-10-03 10:04:48 --> Model Class Initialized
INFO - 2016-10-03 10:04:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 10:04:48 --> Model Class Initialized
INFO - 2016-10-03 10:04:48 --> Model Class Initialized
INFO - 2016-10-03 10:04:48 --> Helper loaded: form_helper
INFO - 2016-10-03 10:04:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 10:04:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 10:04:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 10:04:48 --> Final output sent to browser
DEBUG - 2016-10-03 10:04:48 --> Total execution time: 0.0776
INFO - 2016-10-03 10:12:43 --> Config Class Initialized
INFO - 2016-10-03 10:12:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 10:12:43 --> UTF-8 Support Enabled
INFO - 2016-10-03 10:12:43 --> Utf8 Class Initialized
INFO - 2016-10-03 10:12:43 --> URI Class Initialized
INFO - 2016-10-03 10:12:43 --> Router Class Initialized
INFO - 2016-10-03 10:12:43 --> Output Class Initialized
INFO - 2016-10-03 10:12:43 --> Security Class Initialized
DEBUG - 2016-10-03 10:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 10:12:43 --> Input Class Initialized
INFO - 2016-10-03 10:12:43 --> Language Class Initialized
INFO - 2016-10-03 10:12:43 --> Loader Class Initialized
INFO - 2016-10-03 10:12:43 --> Helper loaded: url_helper
INFO - 2016-10-03 10:12:43 --> Helper loaded: language_helper
INFO - 2016-10-03 10:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 10:12:43 --> Controller Class Initialized
INFO - 2016-10-03 10:12:43 --> Database Driver Class Initialized
INFO - 2016-10-03 10:12:43 --> Model Class Initialized
INFO - 2016-10-03 10:12:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 10:12:43 --> Model Class Initialized
INFO - 2016-10-03 10:12:43 --> Model Class Initialized
INFO - 2016-10-03 10:12:43 --> Helper loaded: form_helper
INFO - 2016-10-03 10:12:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 10:12:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 10:12:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 10:12:43 --> Final output sent to browser
DEBUG - 2016-10-03 10:12:43 --> Total execution time: 0.0832
INFO - 2016-10-03 10:13:04 --> Config Class Initialized
INFO - 2016-10-03 10:13:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 10:13:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 10:13:04 --> Utf8 Class Initialized
INFO - 2016-10-03 10:13:04 --> URI Class Initialized
INFO - 2016-10-03 10:13:04 --> Router Class Initialized
INFO - 2016-10-03 10:13:04 --> Output Class Initialized
INFO - 2016-10-03 10:13:04 --> Security Class Initialized
DEBUG - 2016-10-03 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 10:13:04 --> Input Class Initialized
INFO - 2016-10-03 10:13:04 --> Language Class Initialized
INFO - 2016-10-03 10:13:04 --> Loader Class Initialized
INFO - 2016-10-03 10:13:04 --> Helper loaded: url_helper
INFO - 2016-10-03 10:13:04 --> Helper loaded: language_helper
INFO - 2016-10-03 10:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 10:13:04 --> Controller Class Initialized
INFO - 2016-10-03 10:13:04 --> Database Driver Class Initialized
INFO - 2016-10-03 10:13:04 --> Model Class Initialized
INFO - 2016-10-03 10:13:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 10:13:04 --> Model Class Initialized
INFO - 2016-10-03 10:13:04 --> Model Class Initialized
INFO - 2016-10-03 10:13:04 --> Helper loaded: form_helper
INFO - 2016-10-03 10:13:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 10:13:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 10:13:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 10:13:04 --> Final output sent to browser
DEBUG - 2016-10-03 10:13:04 --> Total execution time: 0.1010
INFO - 2016-10-03 10:13:12 --> Config Class Initialized
INFO - 2016-10-03 10:13:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 10:13:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 10:13:12 --> Utf8 Class Initialized
INFO - 2016-10-03 10:13:12 --> URI Class Initialized
INFO - 2016-10-03 10:13:12 --> Router Class Initialized
INFO - 2016-10-03 10:13:12 --> Output Class Initialized
INFO - 2016-10-03 10:13:12 --> Security Class Initialized
DEBUG - 2016-10-03 10:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 10:13:12 --> Input Class Initialized
INFO - 2016-10-03 10:13:12 --> Language Class Initialized
INFO - 2016-10-03 10:13:12 --> Loader Class Initialized
INFO - 2016-10-03 10:13:12 --> Helper loaded: url_helper
INFO - 2016-10-03 10:13:12 --> Helper loaded: language_helper
INFO - 2016-10-03 10:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 10:13:12 --> Controller Class Initialized
INFO - 2016-10-03 10:13:12 --> Database Driver Class Initialized
INFO - 2016-10-03 10:13:12 --> Model Class Initialized
INFO - 2016-10-03 10:13:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 10:13:12 --> Model Class Initialized
INFO - 2016-10-03 10:13:12 --> Model Class Initialized
INFO - 2016-10-03 10:13:12 --> Helper loaded: form_helper
INFO - 2016-10-03 10:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 10:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 10:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 10:13:12 --> Final output sent to browser
DEBUG - 2016-10-03 10:13:12 --> Total execution time: 0.0856
INFO - 2016-10-03 11:51:49 --> Config Class Initialized
INFO - 2016-10-03 11:51:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 11:51:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 11:51:49 --> Utf8 Class Initialized
INFO - 2016-10-03 11:51:49 --> URI Class Initialized
INFO - 2016-10-03 11:51:49 --> Router Class Initialized
INFO - 2016-10-03 11:51:49 --> Output Class Initialized
INFO - 2016-10-03 11:51:49 --> Security Class Initialized
DEBUG - 2016-10-03 11:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 11:51:49 --> Input Class Initialized
INFO - 2016-10-03 11:51:49 --> Language Class Initialized
INFO - 2016-10-03 11:51:49 --> Loader Class Initialized
INFO - 2016-10-03 11:51:49 --> Helper loaded: url_helper
INFO - 2016-10-03 11:51:49 --> Helper loaded: language_helper
INFO - 2016-10-03 11:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 11:51:49 --> Controller Class Initialized
INFO - 2016-10-03 11:51:49 --> Database Driver Class Initialized
INFO - 2016-10-03 11:51:49 --> Model Class Initialized
INFO - 2016-10-03 11:51:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 11:51:49 --> Model Class Initialized
INFO - 2016-10-03 11:51:49 --> Model Class Initialized
INFO - 2016-10-03 11:51:49 --> Helper loaded: form_helper
INFO - 2016-10-03 11:51:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 11:51:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 11:51:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 11:51:49 --> Final output sent to browser
DEBUG - 2016-10-03 11:51:49 --> Total execution time: 0.1181
INFO - 2016-10-03 12:02:11 --> Config Class Initialized
INFO - 2016-10-03 12:02:11 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:02:11 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:02:11 --> Utf8 Class Initialized
INFO - 2016-10-03 12:02:11 --> URI Class Initialized
INFO - 2016-10-03 12:02:11 --> Router Class Initialized
INFO - 2016-10-03 12:02:11 --> Output Class Initialized
INFO - 2016-10-03 12:02:11 --> Security Class Initialized
DEBUG - 2016-10-03 12:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:02:11 --> Input Class Initialized
INFO - 2016-10-03 12:02:11 --> Language Class Initialized
INFO - 2016-10-03 12:02:11 --> Loader Class Initialized
INFO - 2016-10-03 12:02:11 --> Helper loaded: url_helper
INFO - 2016-10-03 12:02:11 --> Helper loaded: language_helper
INFO - 2016-10-03 12:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:02:11 --> Controller Class Initialized
INFO - 2016-10-03 12:02:11 --> Database Driver Class Initialized
INFO - 2016-10-03 12:02:11 --> Model Class Initialized
INFO - 2016-10-03 12:02:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:02:11 --> Model Class Initialized
INFO - 2016-10-03 12:02:11 --> Model Class Initialized
INFO - 2016-10-03 12:02:11 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:02:11 --> Severity: Notice --> Undefined variable: order C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Notice --> Undefined variable: order C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Notice --> Undefined variable: order C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Notice --> Undefined variable: order C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
ERROR - 2016-10-03 12:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 196
INFO - 2016-10-03 12:02:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:02:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:02:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:02:11 --> Final output sent to browser
DEBUG - 2016-10-03 12:02:11 --> Total execution time: 0.1052
INFO - 2016-10-03 12:02:45 --> Config Class Initialized
INFO - 2016-10-03 12:02:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:02:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:02:45 --> Utf8 Class Initialized
INFO - 2016-10-03 12:02:45 --> URI Class Initialized
INFO - 2016-10-03 12:02:45 --> Router Class Initialized
INFO - 2016-10-03 12:02:45 --> Output Class Initialized
INFO - 2016-10-03 12:02:45 --> Security Class Initialized
DEBUG - 2016-10-03 12:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:02:45 --> Input Class Initialized
INFO - 2016-10-03 12:02:45 --> Language Class Initialized
INFO - 2016-10-03 12:02:45 --> Loader Class Initialized
INFO - 2016-10-03 12:02:45 --> Helper loaded: url_helper
INFO - 2016-10-03 12:02:45 --> Helper loaded: language_helper
INFO - 2016-10-03 12:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:02:45 --> Controller Class Initialized
INFO - 2016-10-03 12:02:46 --> Database Driver Class Initialized
INFO - 2016-10-03 12:02:46 --> Model Class Initialized
INFO - 2016-10-03 12:02:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:02:46 --> Model Class Initialized
INFO - 2016-10-03 12:02:46 --> Model Class Initialized
INFO - 2016-10-03 12:02:46 --> Helper loaded: form_helper
INFO - 2016-10-03 12:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:02:46 --> Final output sent to browser
DEBUG - 2016-10-03 12:02:46 --> Total execution time: 0.0976
INFO - 2016-10-03 12:03:41 --> Config Class Initialized
INFO - 2016-10-03 12:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:03:41 --> Utf8 Class Initialized
INFO - 2016-10-03 12:03:41 --> URI Class Initialized
INFO - 2016-10-03 12:03:41 --> Router Class Initialized
INFO - 2016-10-03 12:03:41 --> Output Class Initialized
INFO - 2016-10-03 12:03:41 --> Security Class Initialized
DEBUG - 2016-10-03 12:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:03:41 --> Input Class Initialized
INFO - 2016-10-03 12:03:41 --> Language Class Initialized
INFO - 2016-10-03 12:03:41 --> Loader Class Initialized
INFO - 2016-10-03 12:03:41 --> Helper loaded: url_helper
INFO - 2016-10-03 12:03:41 --> Helper loaded: language_helper
INFO - 2016-10-03 12:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:03:41 --> Controller Class Initialized
INFO - 2016-10-03 12:03:41 --> Database Driver Class Initialized
INFO - 2016-10-03 12:03:41 --> Model Class Initialized
INFO - 2016-10-03 12:03:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:03:41 --> Model Class Initialized
INFO - 2016-10-03 12:03:41 --> Model Class Initialized
INFO - 2016-10-03 12:03:41 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:03:41 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:03:41 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:03:41 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:03:41 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
INFO - 2016-10-03 12:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:03:41 --> Final output sent to browser
DEBUG - 2016-10-03 12:03:41 --> Total execution time: 0.0949
INFO - 2016-10-03 12:04:08 --> Config Class Initialized
INFO - 2016-10-03 12:04:08 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:04:08 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:04:08 --> Utf8 Class Initialized
INFO - 2016-10-03 12:04:08 --> URI Class Initialized
INFO - 2016-10-03 12:04:08 --> Router Class Initialized
INFO - 2016-10-03 12:04:08 --> Output Class Initialized
INFO - 2016-10-03 12:04:08 --> Security Class Initialized
DEBUG - 2016-10-03 12:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:04:08 --> Input Class Initialized
INFO - 2016-10-03 12:04:08 --> Language Class Initialized
INFO - 2016-10-03 12:04:08 --> Loader Class Initialized
INFO - 2016-10-03 12:04:08 --> Helper loaded: url_helper
INFO - 2016-10-03 12:04:08 --> Helper loaded: language_helper
INFO - 2016-10-03 12:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:04:08 --> Controller Class Initialized
INFO - 2016-10-03 12:04:08 --> Database Driver Class Initialized
INFO - 2016-10-03 12:04:08 --> Model Class Initialized
INFO - 2016-10-03 12:04:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:04:08 --> Model Class Initialized
INFO - 2016-10-03 12:04:08 --> Model Class Initialized
INFO - 2016-10-03 12:04:08 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:04:08 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:04:08 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:04:08 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:04:08 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
INFO - 2016-10-03 12:04:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:04:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:04:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:04:08 --> Final output sent to browser
DEBUG - 2016-10-03 12:04:08 --> Total execution time: 0.0965
INFO - 2016-10-03 12:04:55 --> Config Class Initialized
INFO - 2016-10-03 12:04:55 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:04:55 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:04:55 --> Utf8 Class Initialized
INFO - 2016-10-03 12:04:55 --> URI Class Initialized
INFO - 2016-10-03 12:04:55 --> Router Class Initialized
INFO - 2016-10-03 12:04:55 --> Output Class Initialized
INFO - 2016-10-03 12:04:55 --> Security Class Initialized
DEBUG - 2016-10-03 12:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:04:55 --> Input Class Initialized
INFO - 2016-10-03 12:04:55 --> Language Class Initialized
INFO - 2016-10-03 12:04:55 --> Loader Class Initialized
INFO - 2016-10-03 12:04:55 --> Helper loaded: url_helper
INFO - 2016-10-03 12:04:55 --> Helper loaded: language_helper
INFO - 2016-10-03 12:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:04:55 --> Controller Class Initialized
INFO - 2016-10-03 12:04:55 --> Database Driver Class Initialized
INFO - 2016-10-03 12:04:55 --> Model Class Initialized
INFO - 2016-10-03 12:04:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:04:55 --> Model Class Initialized
INFO - 2016-10-03 12:04:55 --> Model Class Initialized
INFO - 2016-10-03 12:04:55 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:04:55 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:04:55 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:04:55 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
ERROR - 2016-10-03 12:04:55 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 202
INFO - 2016-10-03 12:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:04:55 --> Final output sent to browser
DEBUG - 2016-10-03 12:04:55 --> Total execution time: 0.0868
INFO - 2016-10-03 12:05:57 --> Config Class Initialized
INFO - 2016-10-03 12:05:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:05:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:05:57 --> Utf8 Class Initialized
INFO - 2016-10-03 12:05:57 --> URI Class Initialized
INFO - 2016-10-03 12:05:57 --> Router Class Initialized
INFO - 2016-10-03 12:05:57 --> Output Class Initialized
INFO - 2016-10-03 12:05:57 --> Security Class Initialized
DEBUG - 2016-10-03 12:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:05:57 --> Input Class Initialized
INFO - 2016-10-03 12:05:57 --> Language Class Initialized
INFO - 2016-10-03 12:05:57 --> Loader Class Initialized
INFO - 2016-10-03 12:05:57 --> Helper loaded: url_helper
INFO - 2016-10-03 12:05:57 --> Helper loaded: language_helper
INFO - 2016-10-03 12:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:05:57 --> Controller Class Initialized
INFO - 2016-10-03 12:05:57 --> Database Driver Class Initialized
INFO - 2016-10-03 12:05:57 --> Model Class Initialized
INFO - 2016-10-03 12:05:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:05:57 --> Model Class Initialized
INFO - 2016-10-03 12:05:57 --> Model Class Initialized
INFO - 2016-10-03 12:05:57 --> Helper loaded: form_helper
INFO - 2016-10-03 12:05:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:05:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:05:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:05:57 --> Final output sent to browser
DEBUG - 2016-10-03 12:05:57 --> Total execution time: 0.0977
INFO - 2016-10-03 12:12:53 --> Config Class Initialized
INFO - 2016-10-03 12:12:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:12:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:12:53 --> Utf8 Class Initialized
INFO - 2016-10-03 12:12:53 --> URI Class Initialized
INFO - 2016-10-03 12:12:53 --> Router Class Initialized
INFO - 2016-10-03 12:12:53 --> Output Class Initialized
INFO - 2016-10-03 12:12:53 --> Security Class Initialized
DEBUG - 2016-10-03 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:12:53 --> Input Class Initialized
INFO - 2016-10-03 12:12:53 --> Language Class Initialized
INFO - 2016-10-03 12:12:53 --> Loader Class Initialized
INFO - 2016-10-03 12:12:53 --> Helper loaded: url_helper
INFO - 2016-10-03 12:12:53 --> Helper loaded: language_helper
INFO - 2016-10-03 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:12:53 --> Controller Class Initialized
INFO - 2016-10-03 12:12:53 --> Database Driver Class Initialized
INFO - 2016-10-03 12:12:53 --> Model Class Initialized
INFO - 2016-10-03 12:12:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:12:53 --> Model Class Initialized
INFO - 2016-10-03 12:12:53 --> Model Class Initialized
INFO - 2016-10-03 12:12:53 --> Helper loaded: form_helper
INFO - 2016-10-03 12:12:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:12:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:12:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:12:53 --> Final output sent to browser
DEBUG - 2016-10-03 12:12:53 --> Total execution time: 0.0819
INFO - 2016-10-03 12:13:17 --> Config Class Initialized
INFO - 2016-10-03 12:13:17 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:13:17 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:13:17 --> Utf8 Class Initialized
INFO - 2016-10-03 12:13:17 --> URI Class Initialized
INFO - 2016-10-03 12:13:17 --> Router Class Initialized
INFO - 2016-10-03 12:13:17 --> Output Class Initialized
INFO - 2016-10-03 12:13:17 --> Security Class Initialized
DEBUG - 2016-10-03 12:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:13:17 --> Input Class Initialized
INFO - 2016-10-03 12:13:17 --> Language Class Initialized
INFO - 2016-10-03 12:13:17 --> Loader Class Initialized
INFO - 2016-10-03 12:13:17 --> Helper loaded: url_helper
INFO - 2016-10-03 12:13:17 --> Helper loaded: language_helper
INFO - 2016-10-03 12:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:13:17 --> Controller Class Initialized
INFO - 2016-10-03 12:13:17 --> Database Driver Class Initialized
INFO - 2016-10-03 12:13:17 --> Model Class Initialized
INFO - 2016-10-03 12:13:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:13:17 --> Model Class Initialized
INFO - 2016-10-03 12:13:17 --> Model Class Initialized
INFO - 2016-10-03 12:13:17 --> Helper loaded: form_helper
INFO - 2016-10-03 12:13:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:13:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:13:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:13:17 --> Final output sent to browser
DEBUG - 2016-10-03 12:13:17 --> Total execution time: 0.0804
INFO - 2016-10-03 12:13:39 --> Config Class Initialized
INFO - 2016-10-03 12:13:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:13:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:13:39 --> Utf8 Class Initialized
INFO - 2016-10-03 12:13:39 --> URI Class Initialized
INFO - 2016-10-03 12:13:39 --> Router Class Initialized
INFO - 2016-10-03 12:13:39 --> Output Class Initialized
INFO - 2016-10-03 12:13:39 --> Security Class Initialized
DEBUG - 2016-10-03 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:13:39 --> Input Class Initialized
INFO - 2016-10-03 12:13:39 --> Language Class Initialized
INFO - 2016-10-03 12:13:39 --> Loader Class Initialized
INFO - 2016-10-03 12:13:39 --> Helper loaded: url_helper
INFO - 2016-10-03 12:13:39 --> Helper loaded: language_helper
INFO - 2016-10-03 12:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:13:39 --> Controller Class Initialized
INFO - 2016-10-03 12:13:39 --> Database Driver Class Initialized
INFO - 2016-10-03 12:13:39 --> Model Class Initialized
INFO - 2016-10-03 12:13:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:13:39 --> Model Class Initialized
INFO - 2016-10-03 12:13:39 --> Model Class Initialized
INFO - 2016-10-03 12:13:39 --> Helper loaded: form_helper
INFO - 2016-10-03 12:13:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:13:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:13:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:13:40 --> Final output sent to browser
DEBUG - 2016-10-03 12:13:40 --> Total execution time: 0.0819
INFO - 2016-10-03 12:13:41 --> Config Class Initialized
INFO - 2016-10-03 12:13:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:13:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:13:41 --> Utf8 Class Initialized
INFO - 2016-10-03 12:13:41 --> URI Class Initialized
INFO - 2016-10-03 12:13:41 --> Router Class Initialized
INFO - 2016-10-03 12:13:41 --> Output Class Initialized
INFO - 2016-10-03 12:13:41 --> Security Class Initialized
DEBUG - 2016-10-03 12:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:13:41 --> Input Class Initialized
INFO - 2016-10-03 12:13:41 --> Language Class Initialized
INFO - 2016-10-03 12:13:41 --> Loader Class Initialized
INFO - 2016-10-03 12:13:41 --> Helper loaded: url_helper
INFO - 2016-10-03 12:13:41 --> Helper loaded: language_helper
INFO - 2016-10-03 12:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:13:41 --> Controller Class Initialized
INFO - 2016-10-03 12:13:41 --> Database Driver Class Initialized
INFO - 2016-10-03 12:13:41 --> Model Class Initialized
INFO - 2016-10-03 12:13:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:13:41 --> Model Class Initialized
INFO - 2016-10-03 12:13:41 --> Model Class Initialized
INFO - 2016-10-03 12:13:41 --> Helper loaded: form_helper
INFO - 2016-10-03 12:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:13:41 --> Final output sent to browser
DEBUG - 2016-10-03 12:13:41 --> Total execution time: 0.0919
INFO - 2016-10-03 12:14:38 --> Config Class Initialized
INFO - 2016-10-03 12:14:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:14:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:14:38 --> Utf8 Class Initialized
INFO - 2016-10-03 12:14:38 --> URI Class Initialized
INFO - 2016-10-03 12:14:38 --> Router Class Initialized
INFO - 2016-10-03 12:14:38 --> Output Class Initialized
INFO - 2016-10-03 12:14:38 --> Security Class Initialized
DEBUG - 2016-10-03 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:14:38 --> Input Class Initialized
INFO - 2016-10-03 12:14:38 --> Language Class Initialized
INFO - 2016-10-03 12:14:38 --> Loader Class Initialized
INFO - 2016-10-03 12:14:38 --> Helper loaded: url_helper
INFO - 2016-10-03 12:14:38 --> Helper loaded: language_helper
INFO - 2016-10-03 12:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:14:38 --> Controller Class Initialized
INFO - 2016-10-03 12:14:38 --> Database Driver Class Initialized
INFO - 2016-10-03 12:14:38 --> Model Class Initialized
INFO - 2016-10-03 12:14:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:14:38 --> Model Class Initialized
INFO - 2016-10-03 12:14:38 --> Model Class Initialized
INFO - 2016-10-03 12:14:38 --> Helper loaded: form_helper
INFO - 2016-10-03 12:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:14:38 --> Final output sent to browser
DEBUG - 2016-10-03 12:14:38 --> Total execution time: 0.0875
INFO - 2016-10-03 12:15:01 --> Config Class Initialized
INFO - 2016-10-03 12:15:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:15:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:15:01 --> Utf8 Class Initialized
INFO - 2016-10-03 12:15:01 --> URI Class Initialized
INFO - 2016-10-03 12:15:01 --> Router Class Initialized
INFO - 2016-10-03 12:15:01 --> Output Class Initialized
INFO - 2016-10-03 12:15:01 --> Security Class Initialized
DEBUG - 2016-10-03 12:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:15:01 --> Input Class Initialized
INFO - 2016-10-03 12:15:01 --> Language Class Initialized
INFO - 2016-10-03 12:15:01 --> Loader Class Initialized
INFO - 2016-10-03 12:15:01 --> Helper loaded: url_helper
INFO - 2016-10-03 12:15:01 --> Helper loaded: language_helper
INFO - 2016-10-03 12:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:15:01 --> Controller Class Initialized
INFO - 2016-10-03 12:15:01 --> Database Driver Class Initialized
INFO - 2016-10-03 12:15:01 --> Model Class Initialized
INFO - 2016-10-03 12:15:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:15:01 --> Model Class Initialized
INFO - 2016-10-03 12:15:01 --> Model Class Initialized
INFO - 2016-10-03 12:15:01 --> Helper loaded: form_helper
INFO - 2016-10-03 12:15:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:15:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:15:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:15:01 --> Final output sent to browser
DEBUG - 2016-10-03 12:15:01 --> Total execution time: 0.0883
INFO - 2016-10-03 12:15:12 --> Config Class Initialized
INFO - 2016-10-03 12:15:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:15:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:15:12 --> Utf8 Class Initialized
INFO - 2016-10-03 12:15:12 --> URI Class Initialized
INFO - 2016-10-03 12:15:12 --> Router Class Initialized
INFO - 2016-10-03 12:15:12 --> Output Class Initialized
INFO - 2016-10-03 12:15:12 --> Security Class Initialized
DEBUG - 2016-10-03 12:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:15:12 --> Input Class Initialized
INFO - 2016-10-03 12:15:12 --> Language Class Initialized
INFO - 2016-10-03 12:15:12 --> Loader Class Initialized
INFO - 2016-10-03 12:15:12 --> Helper loaded: url_helper
INFO - 2016-10-03 12:15:12 --> Helper loaded: language_helper
INFO - 2016-10-03 12:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:15:12 --> Controller Class Initialized
INFO - 2016-10-03 12:15:12 --> Database Driver Class Initialized
INFO - 2016-10-03 12:15:12 --> Model Class Initialized
INFO - 2016-10-03 12:15:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:15:12 --> Model Class Initialized
INFO - 2016-10-03 12:15:12 --> Model Class Initialized
INFO - 2016-10-03 12:15:12 --> Helper loaded: form_helper
INFO - 2016-10-03 12:15:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:15:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:15:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:15:12 --> Final output sent to browser
DEBUG - 2016-10-03 12:15:12 --> Total execution time: 0.0796
INFO - 2016-10-03 12:17:28 --> Config Class Initialized
INFO - 2016-10-03 12:17:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:17:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:17:28 --> Utf8 Class Initialized
INFO - 2016-10-03 12:17:28 --> URI Class Initialized
INFO - 2016-10-03 12:17:28 --> Router Class Initialized
INFO - 2016-10-03 12:17:28 --> Output Class Initialized
INFO - 2016-10-03 12:17:28 --> Security Class Initialized
DEBUG - 2016-10-03 12:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:17:28 --> Input Class Initialized
INFO - 2016-10-03 12:17:28 --> Language Class Initialized
INFO - 2016-10-03 12:17:28 --> Loader Class Initialized
INFO - 2016-10-03 12:17:28 --> Helper loaded: url_helper
INFO - 2016-10-03 12:17:28 --> Helper loaded: language_helper
INFO - 2016-10-03 12:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:17:28 --> Controller Class Initialized
INFO - 2016-10-03 12:17:28 --> Database Driver Class Initialized
INFO - 2016-10-03 12:17:28 --> Model Class Initialized
INFO - 2016-10-03 12:17:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:17:28 --> Model Class Initialized
INFO - 2016-10-03 12:17:28 --> Model Class Initialized
INFO - 2016-10-03 12:17:28 --> Helper loaded: form_helper
INFO - 2016-10-03 12:17:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:17:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:17:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:17:28 --> Final output sent to browser
DEBUG - 2016-10-03 12:17:28 --> Total execution time: 0.0926
INFO - 2016-10-03 12:17:49 --> Config Class Initialized
INFO - 2016-10-03 12:17:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:17:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:17:49 --> Utf8 Class Initialized
INFO - 2016-10-03 12:17:49 --> URI Class Initialized
INFO - 2016-10-03 12:17:49 --> Router Class Initialized
INFO - 2016-10-03 12:17:49 --> Output Class Initialized
INFO - 2016-10-03 12:17:49 --> Security Class Initialized
DEBUG - 2016-10-03 12:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:17:49 --> Input Class Initialized
INFO - 2016-10-03 12:17:49 --> Language Class Initialized
INFO - 2016-10-03 12:17:49 --> Loader Class Initialized
INFO - 2016-10-03 12:17:49 --> Helper loaded: url_helper
INFO - 2016-10-03 12:17:49 --> Helper loaded: language_helper
INFO - 2016-10-03 12:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:17:49 --> Controller Class Initialized
INFO - 2016-10-03 12:17:49 --> Database Driver Class Initialized
INFO - 2016-10-03 12:17:49 --> Model Class Initialized
INFO - 2016-10-03 12:17:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:17:49 --> Model Class Initialized
ERROR - 2016-10-03 12:17:49 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING) C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 195
INFO - 2016-10-03 12:17:57 --> Config Class Initialized
INFO - 2016-10-03 12:17:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:17:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:17:57 --> Utf8 Class Initialized
INFO - 2016-10-03 12:17:57 --> URI Class Initialized
INFO - 2016-10-03 12:17:57 --> Router Class Initialized
INFO - 2016-10-03 12:17:57 --> Output Class Initialized
INFO - 2016-10-03 12:17:57 --> Security Class Initialized
DEBUG - 2016-10-03 12:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:17:57 --> Input Class Initialized
INFO - 2016-10-03 12:17:57 --> Language Class Initialized
INFO - 2016-10-03 12:17:57 --> Loader Class Initialized
INFO - 2016-10-03 12:17:57 --> Helper loaded: url_helper
INFO - 2016-10-03 12:17:57 --> Helper loaded: language_helper
INFO - 2016-10-03 12:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:17:57 --> Controller Class Initialized
INFO - 2016-10-03 12:17:57 --> Database Driver Class Initialized
INFO - 2016-10-03 12:17:57 --> Model Class Initialized
INFO - 2016-10-03 12:17:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:17:57 --> Model Class Initialized
INFO - 2016-10-03 12:17:57 --> Model Class Initialized
INFO - 2016-10-03 12:17:57 --> Helper loaded: form_helper
INFO - 2016-10-03 12:17:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:17:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:17:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:17:57 --> Final output sent to browser
DEBUG - 2016-10-03 12:17:57 --> Total execution time: 0.0897
INFO - 2016-10-03 12:19:49 --> Config Class Initialized
INFO - 2016-10-03 12:19:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:19:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:19:49 --> Utf8 Class Initialized
INFO - 2016-10-03 12:19:49 --> URI Class Initialized
INFO - 2016-10-03 12:19:49 --> Router Class Initialized
INFO - 2016-10-03 12:19:49 --> Output Class Initialized
INFO - 2016-10-03 12:19:49 --> Security Class Initialized
DEBUG - 2016-10-03 12:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:19:49 --> Input Class Initialized
INFO - 2016-10-03 12:19:49 --> Language Class Initialized
INFO - 2016-10-03 12:19:49 --> Loader Class Initialized
INFO - 2016-10-03 12:19:49 --> Helper loaded: url_helper
INFO - 2016-10-03 12:19:49 --> Helper loaded: language_helper
INFO - 2016-10-03 12:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:19:49 --> Controller Class Initialized
INFO - 2016-10-03 12:19:49 --> Database Driver Class Initialized
INFO - 2016-10-03 12:19:49 --> Model Class Initialized
INFO - 2016-10-03 12:19:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:19:49 --> Model Class Initialized
INFO - 2016-10-03 12:19:49 --> Model Class Initialized
INFO - 2016-10-03 12:19:49 --> Helper loaded: form_helper
INFO - 2016-10-03 12:19:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:19:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:19:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:19:49 --> Final output sent to browser
DEBUG - 2016-10-03 12:19:49 --> Total execution time: 0.0964
INFO - 2016-10-03 12:20:03 --> Config Class Initialized
INFO - 2016-10-03 12:20:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:20:03 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:20:03 --> Utf8 Class Initialized
INFO - 2016-10-03 12:20:03 --> URI Class Initialized
INFO - 2016-10-03 12:20:03 --> Router Class Initialized
INFO - 2016-10-03 12:20:03 --> Output Class Initialized
INFO - 2016-10-03 12:20:03 --> Security Class Initialized
DEBUG - 2016-10-03 12:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:20:03 --> Input Class Initialized
INFO - 2016-10-03 12:20:03 --> Language Class Initialized
INFO - 2016-10-03 12:20:03 --> Loader Class Initialized
INFO - 2016-10-03 12:20:03 --> Helper loaded: url_helper
INFO - 2016-10-03 12:20:03 --> Helper loaded: language_helper
INFO - 2016-10-03 12:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:20:03 --> Controller Class Initialized
INFO - 2016-10-03 12:20:03 --> Database Driver Class Initialized
INFO - 2016-10-03 12:20:03 --> Model Class Initialized
INFO - 2016-10-03 12:20:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:20:03 --> Model Class Initialized
INFO - 2016-10-03 12:20:03 --> Model Class Initialized
INFO - 2016-10-03 12:20:03 --> Helper loaded: form_helper
INFO - 2016-10-03 12:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:20:03 --> Final output sent to browser
DEBUG - 2016-10-03 12:20:03 --> Total execution time: 0.0770
INFO - 2016-10-03 12:20:49 --> Config Class Initialized
INFO - 2016-10-03 12:20:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:20:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:20:49 --> Utf8 Class Initialized
INFO - 2016-10-03 12:20:49 --> URI Class Initialized
INFO - 2016-10-03 12:20:49 --> Router Class Initialized
INFO - 2016-10-03 12:20:49 --> Output Class Initialized
INFO - 2016-10-03 12:20:49 --> Security Class Initialized
DEBUG - 2016-10-03 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:20:49 --> Input Class Initialized
INFO - 2016-10-03 12:20:49 --> Language Class Initialized
INFO - 2016-10-03 12:20:49 --> Loader Class Initialized
INFO - 2016-10-03 12:20:49 --> Helper loaded: url_helper
INFO - 2016-10-03 12:20:49 --> Helper loaded: language_helper
INFO - 2016-10-03 12:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:20:49 --> Controller Class Initialized
INFO - 2016-10-03 12:20:49 --> Database Driver Class Initialized
INFO - 2016-10-03 12:20:49 --> Model Class Initialized
INFO - 2016-10-03 12:20:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:20:49 --> Model Class Initialized
INFO - 2016-10-03 12:20:49 --> Model Class Initialized
INFO - 2016-10-03 12:20:49 --> Helper loaded: form_helper
INFO - 2016-10-03 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:20:49 --> Final output sent to browser
DEBUG - 2016-10-03 12:20:49 --> Total execution time: 0.0758
INFO - 2016-10-03 12:20:59 --> Config Class Initialized
INFO - 2016-10-03 12:20:59 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:20:59 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:20:59 --> Utf8 Class Initialized
INFO - 2016-10-03 12:20:59 --> URI Class Initialized
INFO - 2016-10-03 12:20:59 --> Router Class Initialized
INFO - 2016-10-03 12:20:59 --> Output Class Initialized
INFO - 2016-10-03 12:20:59 --> Security Class Initialized
DEBUG - 2016-10-03 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:20:59 --> Input Class Initialized
INFO - 2016-10-03 12:20:59 --> Language Class Initialized
INFO - 2016-10-03 12:20:59 --> Loader Class Initialized
INFO - 2016-10-03 12:20:59 --> Helper loaded: url_helper
INFO - 2016-10-03 12:20:59 --> Helper loaded: language_helper
INFO - 2016-10-03 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:20:59 --> Controller Class Initialized
INFO - 2016-10-03 12:20:59 --> Database Driver Class Initialized
INFO - 2016-10-03 12:20:59 --> Model Class Initialized
INFO - 2016-10-03 12:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:20:59 --> Model Class Initialized
INFO - 2016-10-03 12:20:59 --> Model Class Initialized
INFO - 2016-10-03 12:20:59 --> Helper loaded: form_helper
INFO - 2016-10-03 12:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:20:59 --> Final output sent to browser
DEBUG - 2016-10-03 12:20:59 --> Total execution time: 0.0850
INFO - 2016-10-03 12:23:41 --> Config Class Initialized
INFO - 2016-10-03 12:23:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:23:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:23:41 --> Utf8 Class Initialized
INFO - 2016-10-03 12:23:41 --> URI Class Initialized
INFO - 2016-10-03 12:23:41 --> Router Class Initialized
INFO - 2016-10-03 12:23:41 --> Output Class Initialized
INFO - 2016-10-03 12:23:41 --> Security Class Initialized
DEBUG - 2016-10-03 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:23:41 --> Input Class Initialized
INFO - 2016-10-03 12:23:41 --> Language Class Initialized
INFO - 2016-10-03 12:23:41 --> Loader Class Initialized
INFO - 2016-10-03 12:23:41 --> Helper loaded: url_helper
INFO - 2016-10-03 12:23:41 --> Helper loaded: language_helper
INFO - 2016-10-03 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:23:41 --> Controller Class Initialized
INFO - 2016-10-03 12:23:41 --> Database Driver Class Initialized
INFO - 2016-10-03 12:23:41 --> Model Class Initialized
INFO - 2016-10-03 12:23:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:23:41 --> Model Class Initialized
ERROR - 2016-10-03 12:23:41 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS), expecting ',' or ')' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 199
INFO - 2016-10-03 12:23:56 --> Config Class Initialized
INFO - 2016-10-03 12:23:56 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:23:56 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:23:56 --> Utf8 Class Initialized
INFO - 2016-10-03 12:23:56 --> URI Class Initialized
INFO - 2016-10-03 12:23:56 --> Router Class Initialized
INFO - 2016-10-03 12:23:56 --> Output Class Initialized
INFO - 2016-10-03 12:23:56 --> Security Class Initialized
DEBUG - 2016-10-03 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:23:56 --> Input Class Initialized
INFO - 2016-10-03 12:23:56 --> Language Class Initialized
INFO - 2016-10-03 12:23:56 --> Loader Class Initialized
INFO - 2016-10-03 12:23:56 --> Helper loaded: url_helper
INFO - 2016-10-03 12:23:56 --> Helper loaded: language_helper
INFO - 2016-10-03 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:23:56 --> Controller Class Initialized
INFO - 2016-10-03 12:23:56 --> Database Driver Class Initialized
INFO - 2016-10-03 12:23:56 --> Model Class Initialized
INFO - 2016-10-03 12:23:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:23:56 --> Model Class Initialized
INFO - 2016-10-03 12:23:56 --> Model Class Initialized
INFO - 2016-10-03 12:23:56 --> Helper loaded: form_helper
INFO - 2016-10-03 12:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:23:56 --> Final output sent to browser
DEBUG - 2016-10-03 12:23:56 --> Total execution time: 0.0777
INFO - 2016-10-03 12:33:46 --> Config Class Initialized
INFO - 2016-10-03 12:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:33:46 --> Utf8 Class Initialized
INFO - 2016-10-03 12:33:46 --> URI Class Initialized
INFO - 2016-10-03 12:33:46 --> Router Class Initialized
INFO - 2016-10-03 12:33:46 --> Output Class Initialized
INFO - 2016-10-03 12:33:46 --> Security Class Initialized
DEBUG - 2016-10-03 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:33:46 --> Input Class Initialized
INFO - 2016-10-03 12:33:46 --> Language Class Initialized
INFO - 2016-10-03 12:33:46 --> Loader Class Initialized
INFO - 2016-10-03 12:33:46 --> Helper loaded: url_helper
INFO - 2016-10-03 12:33:46 --> Helper loaded: language_helper
INFO - 2016-10-03 12:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:33:46 --> Controller Class Initialized
INFO - 2016-10-03 12:33:46 --> Database Driver Class Initialized
INFO - 2016-10-03 12:33:46 --> Model Class Initialized
INFO - 2016-10-03 12:33:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:33:46 --> Model Class Initialized
INFO - 2016-10-03 12:33:46 --> Model Class Initialized
INFO - 2016-10-03 12:33:46 --> Helper loaded: form_helper
INFO - 2016-10-03 12:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:33:46 --> Final output sent to browser
DEBUG - 2016-10-03 12:33:46 --> Total execution time: 0.0803
INFO - 2016-10-03 12:39:02 --> Config Class Initialized
INFO - 2016-10-03 12:39:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:39:02 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:39:02 --> Utf8 Class Initialized
INFO - 2016-10-03 12:39:02 --> URI Class Initialized
INFO - 2016-10-03 12:39:02 --> Router Class Initialized
INFO - 2016-10-03 12:39:02 --> Output Class Initialized
INFO - 2016-10-03 12:39:02 --> Security Class Initialized
DEBUG - 2016-10-03 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:39:02 --> Input Class Initialized
INFO - 2016-10-03 12:39:02 --> Language Class Initialized
INFO - 2016-10-03 12:39:02 --> Loader Class Initialized
INFO - 2016-10-03 12:39:02 --> Helper loaded: url_helper
INFO - 2016-10-03 12:39:02 --> Helper loaded: language_helper
INFO - 2016-10-03 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:39:02 --> Controller Class Initialized
INFO - 2016-10-03 12:39:02 --> Database Driver Class Initialized
INFO - 2016-10-03 12:39:02 --> Model Class Initialized
INFO - 2016-10-03 12:39:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:39:02 --> Model Class Initialized
INFO - 2016-10-03 12:39:02 --> Model Class Initialized
INFO - 2016-10-03 12:39:02 --> Helper loaded: form_helper
INFO - 2016-10-03 12:39:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:39:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:39:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:39:02 --> Final output sent to browser
DEBUG - 2016-10-03 12:39:02 --> Total execution time: 0.0825
INFO - 2016-10-03 12:39:26 --> Config Class Initialized
INFO - 2016-10-03 12:39:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:39:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:39:26 --> Utf8 Class Initialized
INFO - 2016-10-03 12:39:26 --> URI Class Initialized
INFO - 2016-10-03 12:39:26 --> Router Class Initialized
INFO - 2016-10-03 12:39:26 --> Output Class Initialized
INFO - 2016-10-03 12:39:26 --> Security Class Initialized
DEBUG - 2016-10-03 12:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:39:26 --> Input Class Initialized
INFO - 2016-10-03 12:39:26 --> Language Class Initialized
INFO - 2016-10-03 12:39:26 --> Loader Class Initialized
INFO - 2016-10-03 12:39:26 --> Helper loaded: url_helper
INFO - 2016-10-03 12:39:26 --> Helper loaded: language_helper
INFO - 2016-10-03 12:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:39:26 --> Controller Class Initialized
INFO - 2016-10-03 12:39:26 --> Database Driver Class Initialized
INFO - 2016-10-03 12:39:26 --> Model Class Initialized
INFO - 2016-10-03 12:39:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:39:26 --> Model Class Initialized
INFO - 2016-10-03 12:39:26 --> Model Class Initialized
INFO - 2016-10-03 12:39:26 --> Helper loaded: form_helper
INFO - 2016-10-03 12:39:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:39:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:39:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:39:26 --> Final output sent to browser
DEBUG - 2016-10-03 12:39:26 --> Total execution time: 0.1141
INFO - 2016-10-03 12:40:21 --> Config Class Initialized
INFO - 2016-10-03 12:40:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:40:21 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:40:21 --> Utf8 Class Initialized
INFO - 2016-10-03 12:40:21 --> URI Class Initialized
INFO - 2016-10-03 12:40:21 --> Router Class Initialized
INFO - 2016-10-03 12:40:21 --> Output Class Initialized
INFO - 2016-10-03 12:40:21 --> Security Class Initialized
DEBUG - 2016-10-03 12:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:40:21 --> Input Class Initialized
INFO - 2016-10-03 12:40:21 --> Language Class Initialized
INFO - 2016-10-03 12:40:21 --> Loader Class Initialized
INFO - 2016-10-03 12:40:21 --> Helper loaded: url_helper
INFO - 2016-10-03 12:40:21 --> Helper loaded: language_helper
INFO - 2016-10-03 12:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:40:21 --> Controller Class Initialized
INFO - 2016-10-03 12:40:21 --> Database Driver Class Initialized
INFO - 2016-10-03 12:40:21 --> Model Class Initialized
INFO - 2016-10-03 12:40:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:40:21 --> Model Class Initialized
INFO - 2016-10-03 12:40:21 --> Model Class Initialized
INFO - 2016-10-03 12:40:21 --> Helper loaded: form_helper
INFO - 2016-10-03 12:40:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:40:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:40:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:40:21 --> Final output sent to browser
DEBUG - 2016-10-03 12:40:21 --> Total execution time: 0.0788
INFO - 2016-10-03 12:43:21 --> Config Class Initialized
INFO - 2016-10-03 12:43:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:43:21 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:43:21 --> Utf8 Class Initialized
INFO - 2016-10-03 12:43:21 --> URI Class Initialized
INFO - 2016-10-03 12:43:21 --> Router Class Initialized
INFO - 2016-10-03 12:43:21 --> Output Class Initialized
INFO - 2016-10-03 12:43:21 --> Security Class Initialized
DEBUG - 2016-10-03 12:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:43:21 --> Input Class Initialized
INFO - 2016-10-03 12:43:21 --> Language Class Initialized
INFO - 2016-10-03 12:43:21 --> Loader Class Initialized
INFO - 2016-10-03 12:43:21 --> Helper loaded: url_helper
INFO - 2016-10-03 12:43:21 --> Helper loaded: language_helper
INFO - 2016-10-03 12:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:43:21 --> Controller Class Initialized
INFO - 2016-10-03 12:43:21 --> Database Driver Class Initialized
INFO - 2016-10-03 12:43:21 --> Model Class Initialized
INFO - 2016-10-03 12:43:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:43:21 --> Model Class Initialized
INFO - 2016-10-03 12:43:21 --> Model Class Initialized
INFO - 2016-10-03 12:43:21 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:43:21 --> Severity: Warning --> Illegal string offset 'scale' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 12:43:21 --> Severity: Warning --> Illegal string offset 'scale' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 12:43:21 --> Severity: Warning --> Illegal string offset 'scale' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
ERROR - 2016-10-03 12:43:21 --> Severity: Warning --> Illegal string offset 'scale' C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 184
INFO - 2016-10-03 12:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:43:21 --> Final output sent to browser
DEBUG - 2016-10-03 12:43:21 --> Total execution time: 0.1129
INFO - 2016-10-03 12:44:57 --> Config Class Initialized
INFO - 2016-10-03 12:44:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:44:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:44:57 --> Utf8 Class Initialized
INFO - 2016-10-03 12:44:57 --> URI Class Initialized
INFO - 2016-10-03 12:44:57 --> Router Class Initialized
INFO - 2016-10-03 12:44:57 --> Output Class Initialized
INFO - 2016-10-03 12:44:57 --> Security Class Initialized
DEBUG - 2016-10-03 12:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:44:57 --> Input Class Initialized
INFO - 2016-10-03 12:44:57 --> Language Class Initialized
INFO - 2016-10-03 12:44:57 --> Loader Class Initialized
INFO - 2016-10-03 12:44:57 --> Helper loaded: url_helper
INFO - 2016-10-03 12:44:57 --> Helper loaded: language_helper
INFO - 2016-10-03 12:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:44:57 --> Controller Class Initialized
INFO - 2016-10-03 12:44:57 --> Database Driver Class Initialized
INFO - 2016-10-03 12:44:57 --> Model Class Initialized
INFO - 2016-10-03 12:44:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:44:57 --> Model Class Initialized
INFO - 2016-10-03 12:44:57 --> Model Class Initialized
INFO - 2016-10-03 12:44:57 --> Helper loaded: form_helper
INFO - 2016-10-03 12:44:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:44:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:44:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:44:57 --> Final output sent to browser
DEBUG - 2016-10-03 12:44:57 --> Total execution time: 0.0942
INFO - 2016-10-03 12:45:12 --> Config Class Initialized
INFO - 2016-10-03 12:45:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:45:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:45:12 --> Utf8 Class Initialized
INFO - 2016-10-03 12:45:12 --> URI Class Initialized
INFO - 2016-10-03 12:45:12 --> Router Class Initialized
INFO - 2016-10-03 12:45:12 --> Output Class Initialized
INFO - 2016-10-03 12:45:12 --> Security Class Initialized
DEBUG - 2016-10-03 12:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:45:12 --> Input Class Initialized
INFO - 2016-10-03 12:45:12 --> Language Class Initialized
INFO - 2016-10-03 12:45:12 --> Loader Class Initialized
INFO - 2016-10-03 12:45:12 --> Helper loaded: url_helper
INFO - 2016-10-03 12:45:12 --> Helper loaded: language_helper
INFO - 2016-10-03 12:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:45:12 --> Controller Class Initialized
INFO - 2016-10-03 12:45:12 --> Database Driver Class Initialized
INFO - 2016-10-03 12:45:12 --> Model Class Initialized
INFO - 2016-10-03 12:45:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:45:12 --> Model Class Initialized
INFO - 2016-10-03 12:45:12 --> Model Class Initialized
INFO - 2016-10-03 12:45:12 --> Helper loaded: form_helper
INFO - 2016-10-03 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:45:12 --> Final output sent to browser
DEBUG - 2016-10-03 12:45:12 --> Total execution time: 0.0783
INFO - 2016-10-03 12:47:36 --> Config Class Initialized
INFO - 2016-10-03 12:47:36 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:47:36 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:47:36 --> Utf8 Class Initialized
INFO - 2016-10-03 12:47:36 --> URI Class Initialized
INFO - 2016-10-03 12:47:36 --> Router Class Initialized
INFO - 2016-10-03 12:47:36 --> Output Class Initialized
INFO - 2016-10-03 12:47:36 --> Security Class Initialized
DEBUG - 2016-10-03 12:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:47:36 --> Input Class Initialized
INFO - 2016-10-03 12:47:36 --> Language Class Initialized
INFO - 2016-10-03 12:47:36 --> Loader Class Initialized
INFO - 2016-10-03 12:47:36 --> Helper loaded: url_helper
INFO - 2016-10-03 12:47:36 --> Helper loaded: language_helper
INFO - 2016-10-03 12:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:47:36 --> Controller Class Initialized
INFO - 2016-10-03 12:47:36 --> Database Driver Class Initialized
INFO - 2016-10-03 12:47:36 --> Model Class Initialized
INFO - 2016-10-03 12:47:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:47:36 --> Model Class Initialized
INFO - 2016-10-03 12:47:36 --> Model Class Initialized
INFO - 2016-10-03 12:47:36 --> Helper loaded: form_helper
INFO - 2016-10-03 12:47:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:47:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:47:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:47:37 --> Final output sent to browser
DEBUG - 2016-10-03 12:47:37 --> Total execution time: 0.1130
INFO - 2016-10-03 12:50:48 --> Config Class Initialized
INFO - 2016-10-03 12:50:48 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:50:48 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:50:48 --> Utf8 Class Initialized
INFO - 2016-10-03 12:50:48 --> URI Class Initialized
INFO - 2016-10-03 12:50:48 --> Router Class Initialized
INFO - 2016-10-03 12:50:48 --> Output Class Initialized
INFO - 2016-10-03 12:50:48 --> Security Class Initialized
DEBUG - 2016-10-03 12:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:50:48 --> Input Class Initialized
INFO - 2016-10-03 12:50:48 --> Language Class Initialized
INFO - 2016-10-03 12:50:48 --> Loader Class Initialized
INFO - 2016-10-03 12:50:48 --> Helper loaded: url_helper
INFO - 2016-10-03 12:50:48 --> Helper loaded: language_helper
INFO - 2016-10-03 12:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:50:48 --> Controller Class Initialized
INFO - 2016-10-03 12:50:48 --> Database Driver Class Initialized
INFO - 2016-10-03 12:50:48 --> Model Class Initialized
INFO - 2016-10-03 12:50:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:50:48 --> Model Class Initialized
INFO - 2016-10-03 12:50:48 --> Model Class Initialized
INFO - 2016-10-03 12:50:48 --> Helper loaded: form_helper
INFO - 2016-10-03 12:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:50:48 --> Final output sent to browser
DEBUG - 2016-10-03 12:50:48 --> Total execution time: 0.0885
INFO - 2016-10-03 12:51:02 --> Config Class Initialized
INFO - 2016-10-03 12:51:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:51:02 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:51:02 --> Utf8 Class Initialized
INFO - 2016-10-03 12:51:02 --> URI Class Initialized
INFO - 2016-10-03 12:51:02 --> Router Class Initialized
INFO - 2016-10-03 12:51:02 --> Output Class Initialized
INFO - 2016-10-03 12:51:02 --> Security Class Initialized
DEBUG - 2016-10-03 12:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:51:02 --> Input Class Initialized
INFO - 2016-10-03 12:51:02 --> Language Class Initialized
INFO - 2016-10-03 12:51:02 --> Loader Class Initialized
INFO - 2016-10-03 12:51:02 --> Helper loaded: url_helper
INFO - 2016-10-03 12:51:02 --> Helper loaded: language_helper
INFO - 2016-10-03 12:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:51:02 --> Controller Class Initialized
INFO - 2016-10-03 12:51:02 --> Database Driver Class Initialized
INFO - 2016-10-03 12:51:02 --> Model Class Initialized
INFO - 2016-10-03 12:51:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:51:02 --> Model Class Initialized
INFO - 2016-10-03 12:51:02 --> Model Class Initialized
INFO - 2016-10-03 12:51:02 --> Helper loaded: form_helper
INFO - 2016-10-03 12:51:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:51:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:51:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:51:02 --> Final output sent to browser
DEBUG - 2016-10-03 12:51:02 --> Total execution time: 0.0867
INFO - 2016-10-03 12:53:31 --> Config Class Initialized
INFO - 2016-10-03 12:53:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:53:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:53:31 --> Utf8 Class Initialized
INFO - 2016-10-03 12:53:31 --> URI Class Initialized
INFO - 2016-10-03 12:53:31 --> Router Class Initialized
INFO - 2016-10-03 12:53:31 --> Output Class Initialized
INFO - 2016-10-03 12:53:31 --> Security Class Initialized
DEBUG - 2016-10-03 12:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:53:31 --> Input Class Initialized
INFO - 2016-10-03 12:53:31 --> Language Class Initialized
INFO - 2016-10-03 12:53:31 --> Loader Class Initialized
INFO - 2016-10-03 12:53:31 --> Helper loaded: url_helper
INFO - 2016-10-03 12:53:31 --> Helper loaded: language_helper
INFO - 2016-10-03 12:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:53:31 --> Controller Class Initialized
INFO - 2016-10-03 12:53:31 --> Database Driver Class Initialized
INFO - 2016-10-03 12:53:31 --> Model Class Initialized
INFO - 2016-10-03 12:53:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:53:31 --> Model Class Initialized
INFO - 2016-10-03 12:53:31 --> Model Class Initialized
INFO - 2016-10-03 12:53:31 --> Helper loaded: form_helper
INFO - 2016-10-03 12:53:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:53:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:53:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:53:31 --> Final output sent to browser
DEBUG - 2016-10-03 12:53:31 --> Total execution time: 0.0792
INFO - 2016-10-03 12:55:01 --> Config Class Initialized
INFO - 2016-10-03 12:55:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:55:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:55:01 --> Utf8 Class Initialized
INFO - 2016-10-03 12:55:01 --> URI Class Initialized
INFO - 2016-10-03 12:55:01 --> Router Class Initialized
INFO - 2016-10-03 12:55:01 --> Output Class Initialized
INFO - 2016-10-03 12:55:01 --> Security Class Initialized
DEBUG - 2016-10-03 12:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:55:01 --> Input Class Initialized
INFO - 2016-10-03 12:55:01 --> Language Class Initialized
INFO - 2016-10-03 12:55:01 --> Loader Class Initialized
INFO - 2016-10-03 12:55:01 --> Helper loaded: url_helper
INFO - 2016-10-03 12:55:01 --> Helper loaded: language_helper
INFO - 2016-10-03 12:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:55:01 --> Controller Class Initialized
INFO - 2016-10-03 12:55:01 --> Database Driver Class Initialized
INFO - 2016-10-03 12:55:01 --> Model Class Initialized
INFO - 2016-10-03 12:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:55:01 --> Model Class Initialized
INFO - 2016-10-03 12:55:01 --> Model Class Initialized
INFO - 2016-10-03 12:55:01 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:55:01 --> Severity: Notice --> Undefined index: scale C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
ERROR - 2016-10-03 12:55:01 --> Severity: Notice --> Undefined index: scale C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
ERROR - 2016-10-03 12:55:01 --> Severity: Notice --> Undefined index: scale C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
ERROR - 2016-10-03 12:55:01 --> Severity: Notice --> Undefined index: scale C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
INFO - 2016-10-03 12:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:55:01 --> Final output sent to browser
DEBUG - 2016-10-03 12:55:01 --> Total execution time: 0.0860
INFO - 2016-10-03 12:55:13 --> Config Class Initialized
INFO - 2016-10-03 12:55:13 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:55:13 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:55:13 --> Utf8 Class Initialized
INFO - 2016-10-03 12:55:13 --> URI Class Initialized
INFO - 2016-10-03 12:55:13 --> Router Class Initialized
INFO - 2016-10-03 12:55:13 --> Output Class Initialized
INFO - 2016-10-03 12:55:13 --> Security Class Initialized
DEBUG - 2016-10-03 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:55:13 --> Input Class Initialized
INFO - 2016-10-03 12:55:13 --> Language Class Initialized
INFO - 2016-10-03 12:55:13 --> Loader Class Initialized
INFO - 2016-10-03 12:55:13 --> Helper loaded: url_helper
INFO - 2016-10-03 12:55:13 --> Helper loaded: language_helper
INFO - 2016-10-03 12:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:55:13 --> Controller Class Initialized
INFO - 2016-10-03 12:55:13 --> Database Driver Class Initialized
INFO - 2016-10-03 12:55:13 --> Model Class Initialized
INFO - 2016-10-03 12:55:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:55:13 --> Model Class Initialized
INFO - 2016-10-03 12:55:13 --> Model Class Initialized
INFO - 2016-10-03 12:55:13 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:55:13 --> Severity: Notice --> Undefined index: d C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
ERROR - 2016-10-03 12:55:13 --> Severity: Notice --> Undefined index: i C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
ERROR - 2016-10-03 12:55:13 --> Severity: Notice --> Undefined index: s C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
ERROR - 2016-10-03 12:55:13 --> Severity: Notice --> Undefined index: c C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 191
INFO - 2016-10-03 12:55:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:55:14 --> Final output sent to browser
DEBUG - 2016-10-03 12:55:14 --> Total execution time: 0.0930
INFO - 2016-10-03 12:55:41 --> Config Class Initialized
INFO - 2016-10-03 12:55:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:55:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:55:41 --> Utf8 Class Initialized
INFO - 2016-10-03 12:55:41 --> URI Class Initialized
INFO - 2016-10-03 12:55:41 --> Router Class Initialized
INFO - 2016-10-03 12:55:41 --> Output Class Initialized
INFO - 2016-10-03 12:55:41 --> Security Class Initialized
DEBUG - 2016-10-03 12:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:55:41 --> Input Class Initialized
INFO - 2016-10-03 12:55:41 --> Language Class Initialized
INFO - 2016-10-03 12:55:41 --> Loader Class Initialized
INFO - 2016-10-03 12:55:41 --> Helper loaded: url_helper
INFO - 2016-10-03 12:55:41 --> Helper loaded: language_helper
INFO - 2016-10-03 12:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:55:41 --> Controller Class Initialized
INFO - 2016-10-03 12:55:41 --> Database Driver Class Initialized
INFO - 2016-10-03 12:55:41 --> Model Class Initialized
INFO - 2016-10-03 12:55:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:55:41 --> Model Class Initialized
INFO - 2016-10-03 12:55:41 --> Model Class Initialized
INFO - 2016-10-03 12:55:41 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:55:41 --> Severity: Notice --> Undefined variable: rc C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 207
INFO - 2016-10-03 12:55:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:55:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:55:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:55:41 --> Final output sent to browser
DEBUG - 2016-10-03 12:55:41 --> Total execution time: 0.0976
INFO - 2016-10-03 12:55:50 --> Config Class Initialized
INFO - 2016-10-03 12:55:50 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:55:50 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:55:50 --> Utf8 Class Initialized
INFO - 2016-10-03 12:55:50 --> URI Class Initialized
INFO - 2016-10-03 12:55:50 --> Router Class Initialized
INFO - 2016-10-03 12:55:50 --> Output Class Initialized
INFO - 2016-10-03 12:55:50 --> Security Class Initialized
DEBUG - 2016-10-03 12:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:55:50 --> Input Class Initialized
INFO - 2016-10-03 12:55:50 --> Language Class Initialized
INFO - 2016-10-03 12:55:50 --> Loader Class Initialized
INFO - 2016-10-03 12:55:50 --> Helper loaded: url_helper
INFO - 2016-10-03 12:55:50 --> Helper loaded: language_helper
INFO - 2016-10-03 12:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:55:50 --> Controller Class Initialized
INFO - 2016-10-03 12:55:50 --> Database Driver Class Initialized
INFO - 2016-10-03 12:55:50 --> Model Class Initialized
INFO - 2016-10-03 12:55:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:55:50 --> Model Class Initialized
INFO - 2016-10-03 12:55:50 --> Model Class Initialized
INFO - 2016-10-03 12:55:50 --> Helper loaded: form_helper
INFO - 2016-10-03 12:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:55:50 --> Final output sent to browser
DEBUG - 2016-10-03 12:55:50 --> Total execution time: 0.0943
INFO - 2016-10-03 12:57:24 --> Config Class Initialized
INFO - 2016-10-03 12:57:24 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:57:24 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:57:24 --> Utf8 Class Initialized
INFO - 2016-10-03 12:57:24 --> URI Class Initialized
INFO - 2016-10-03 12:57:24 --> Router Class Initialized
INFO - 2016-10-03 12:57:24 --> Output Class Initialized
INFO - 2016-10-03 12:57:24 --> Security Class Initialized
DEBUG - 2016-10-03 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:57:24 --> Input Class Initialized
INFO - 2016-10-03 12:57:24 --> Language Class Initialized
INFO - 2016-10-03 12:57:24 --> Loader Class Initialized
INFO - 2016-10-03 12:57:24 --> Helper loaded: url_helper
INFO - 2016-10-03 12:57:24 --> Helper loaded: language_helper
INFO - 2016-10-03 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:57:24 --> Controller Class Initialized
INFO - 2016-10-03 12:57:24 --> Database Driver Class Initialized
INFO - 2016-10-03 12:57:24 --> Model Class Initialized
INFO - 2016-10-03 12:57:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:57:24 --> Model Class Initialized
INFO - 2016-10-03 12:57:24 --> Model Class Initialized
INFO - 2016-10-03 12:57:24 --> Helper loaded: form_helper
INFO - 2016-10-03 12:57:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:57:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:57:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:57:24 --> Final output sent to browser
DEBUG - 2016-10-03 12:57:24 --> Total execution time: 0.0809
INFO - 2016-10-03 12:58:05 --> Config Class Initialized
INFO - 2016-10-03 12:58:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:58:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:58:05 --> Utf8 Class Initialized
INFO - 2016-10-03 12:58:05 --> URI Class Initialized
INFO - 2016-10-03 12:58:05 --> Router Class Initialized
INFO - 2016-10-03 12:58:05 --> Output Class Initialized
INFO - 2016-10-03 12:58:05 --> Security Class Initialized
DEBUG - 2016-10-03 12:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:58:05 --> Input Class Initialized
INFO - 2016-10-03 12:58:05 --> Language Class Initialized
INFO - 2016-10-03 12:58:05 --> Loader Class Initialized
INFO - 2016-10-03 12:58:05 --> Helper loaded: url_helper
INFO - 2016-10-03 12:58:05 --> Helper loaded: language_helper
INFO - 2016-10-03 12:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:58:05 --> Controller Class Initialized
INFO - 2016-10-03 12:58:05 --> Database Driver Class Initialized
INFO - 2016-10-03 12:58:05 --> Model Class Initialized
INFO - 2016-10-03 12:58:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:58:05 --> Model Class Initialized
INFO - 2016-10-03 12:58:05 --> Model Class Initialized
INFO - 2016-10-03 12:58:05 --> Helper loaded: form_helper
ERROR - 2016-10-03 12:58:05 --> Severity: Notice --> Undefined variable: k C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 194
INFO - 2016-10-03 12:58:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:58:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:58:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:58:05 --> Final output sent to browser
DEBUG - 2016-10-03 12:58:05 --> Total execution time: 0.0827
INFO - 2016-10-03 12:58:15 --> Config Class Initialized
INFO - 2016-10-03 12:58:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:58:15 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:58:15 --> Utf8 Class Initialized
INFO - 2016-10-03 12:58:15 --> URI Class Initialized
INFO - 2016-10-03 12:58:15 --> Router Class Initialized
INFO - 2016-10-03 12:58:15 --> Output Class Initialized
INFO - 2016-10-03 12:58:15 --> Security Class Initialized
DEBUG - 2016-10-03 12:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:58:15 --> Input Class Initialized
INFO - 2016-10-03 12:58:15 --> Language Class Initialized
INFO - 2016-10-03 12:58:15 --> Loader Class Initialized
INFO - 2016-10-03 12:58:15 --> Helper loaded: url_helper
INFO - 2016-10-03 12:58:15 --> Helper loaded: language_helper
INFO - 2016-10-03 12:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:58:15 --> Controller Class Initialized
INFO - 2016-10-03 12:58:15 --> Database Driver Class Initialized
INFO - 2016-10-03 12:58:15 --> Model Class Initialized
INFO - 2016-10-03 12:58:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:58:15 --> Model Class Initialized
INFO - 2016-10-03 12:58:15 --> Model Class Initialized
INFO - 2016-10-03 12:58:15 --> Helper loaded: form_helper
INFO - 2016-10-03 12:58:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:58:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:58:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:58:15 --> Final output sent to browser
DEBUG - 2016-10-03 12:58:15 --> Total execution time: 0.0937
INFO - 2016-10-03 12:58:52 --> Config Class Initialized
INFO - 2016-10-03 12:58:52 --> Hooks Class Initialized
DEBUG - 2016-10-03 12:58:52 --> UTF-8 Support Enabled
INFO - 2016-10-03 12:58:52 --> Utf8 Class Initialized
INFO - 2016-10-03 12:58:52 --> URI Class Initialized
INFO - 2016-10-03 12:58:52 --> Router Class Initialized
INFO - 2016-10-03 12:58:52 --> Output Class Initialized
INFO - 2016-10-03 12:58:52 --> Security Class Initialized
DEBUG - 2016-10-03 12:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 12:58:52 --> Input Class Initialized
INFO - 2016-10-03 12:58:52 --> Language Class Initialized
INFO - 2016-10-03 12:58:52 --> Loader Class Initialized
INFO - 2016-10-03 12:58:52 --> Helper loaded: url_helper
INFO - 2016-10-03 12:58:52 --> Helper loaded: language_helper
INFO - 2016-10-03 12:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 12:58:52 --> Controller Class Initialized
INFO - 2016-10-03 12:58:52 --> Database Driver Class Initialized
INFO - 2016-10-03 12:58:52 --> Model Class Initialized
INFO - 2016-10-03 12:58:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 12:58:52 --> Model Class Initialized
INFO - 2016-10-03 12:58:52 --> Model Class Initialized
INFO - 2016-10-03 12:58:52 --> Helper loaded: form_helper
INFO - 2016-10-03 12:58:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 12:58:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 12:58:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 12:58:52 --> Final output sent to browser
DEBUG - 2016-10-03 12:58:52 --> Total execution time: 0.0796
INFO - 2016-10-03 13:00:38 --> Config Class Initialized
INFO - 2016-10-03 13:00:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:00:38 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:00:38 --> Utf8 Class Initialized
INFO - 2016-10-03 13:00:38 --> URI Class Initialized
INFO - 2016-10-03 13:00:38 --> Router Class Initialized
INFO - 2016-10-03 13:00:38 --> Output Class Initialized
INFO - 2016-10-03 13:00:38 --> Security Class Initialized
DEBUG - 2016-10-03 13:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:00:38 --> Input Class Initialized
INFO - 2016-10-03 13:00:38 --> Language Class Initialized
INFO - 2016-10-03 13:00:38 --> Loader Class Initialized
INFO - 2016-10-03 13:00:38 --> Helper loaded: url_helper
INFO - 2016-10-03 13:00:38 --> Helper loaded: language_helper
INFO - 2016-10-03 13:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:00:38 --> Controller Class Initialized
INFO - 2016-10-03 13:00:38 --> Database Driver Class Initialized
INFO - 2016-10-03 13:00:38 --> Model Class Initialized
INFO - 2016-10-03 13:00:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:00:38 --> Model Class Initialized
INFO - 2016-10-03 13:00:38 --> Model Class Initialized
INFO - 2016-10-03 13:00:38 --> Helper loaded: form_helper
INFO - 2016-10-03 13:00:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:00:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:00:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:00:38 --> Final output sent to browser
DEBUG - 2016-10-03 13:00:38 --> Total execution time: 0.0775
INFO - 2016-10-03 13:01:31 --> Config Class Initialized
INFO - 2016-10-03 13:01:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:01:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:01:31 --> Utf8 Class Initialized
INFO - 2016-10-03 13:01:31 --> URI Class Initialized
INFO - 2016-10-03 13:01:31 --> Router Class Initialized
INFO - 2016-10-03 13:01:31 --> Output Class Initialized
INFO - 2016-10-03 13:01:31 --> Security Class Initialized
DEBUG - 2016-10-03 13:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:01:31 --> Input Class Initialized
INFO - 2016-10-03 13:01:31 --> Language Class Initialized
INFO - 2016-10-03 13:01:31 --> Loader Class Initialized
INFO - 2016-10-03 13:01:31 --> Helper loaded: url_helper
INFO - 2016-10-03 13:01:31 --> Helper loaded: language_helper
INFO - 2016-10-03 13:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:01:31 --> Controller Class Initialized
INFO - 2016-10-03 13:01:31 --> Database Driver Class Initialized
INFO - 2016-10-03 13:01:31 --> Model Class Initialized
INFO - 2016-10-03 13:01:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:01:31 --> Model Class Initialized
INFO - 2016-10-03 13:01:31 --> Model Class Initialized
INFO - 2016-10-03 13:01:31 --> Helper loaded: form_helper
INFO - 2016-10-03 13:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:01:31 --> Final output sent to browser
DEBUG - 2016-10-03 13:01:31 --> Total execution time: 0.0880
INFO - 2016-10-03 13:02:41 --> Config Class Initialized
INFO - 2016-10-03 13:02:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:02:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:02:41 --> Utf8 Class Initialized
INFO - 2016-10-03 13:02:41 --> URI Class Initialized
INFO - 2016-10-03 13:02:41 --> Router Class Initialized
INFO - 2016-10-03 13:02:41 --> Output Class Initialized
INFO - 2016-10-03 13:02:41 --> Security Class Initialized
DEBUG - 2016-10-03 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:02:41 --> Input Class Initialized
INFO - 2016-10-03 13:02:41 --> Language Class Initialized
INFO - 2016-10-03 13:02:41 --> Loader Class Initialized
INFO - 2016-10-03 13:02:41 --> Helper loaded: url_helper
INFO - 2016-10-03 13:02:41 --> Helper loaded: language_helper
INFO - 2016-10-03 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:02:41 --> Controller Class Initialized
INFO - 2016-10-03 13:02:41 --> Database Driver Class Initialized
INFO - 2016-10-03 13:02:41 --> Model Class Initialized
INFO - 2016-10-03 13:02:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:02:41 --> Model Class Initialized
INFO - 2016-10-03 13:02:41 --> Model Class Initialized
INFO - 2016-10-03 13:02:41 --> Helper loaded: form_helper
INFO - 2016-10-03 13:02:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:02:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:02:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:02:41 --> Final output sent to browser
DEBUG - 2016-10-03 13:02:41 --> Total execution time: 0.0800
INFO - 2016-10-03 13:03:32 --> Config Class Initialized
INFO - 2016-10-03 13:03:32 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:03:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:03:32 --> Utf8 Class Initialized
INFO - 2016-10-03 13:03:32 --> URI Class Initialized
INFO - 2016-10-03 13:03:32 --> Router Class Initialized
INFO - 2016-10-03 13:03:32 --> Output Class Initialized
INFO - 2016-10-03 13:03:32 --> Security Class Initialized
DEBUG - 2016-10-03 13:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:03:32 --> Input Class Initialized
INFO - 2016-10-03 13:03:32 --> Language Class Initialized
INFO - 2016-10-03 13:03:32 --> Loader Class Initialized
INFO - 2016-10-03 13:03:32 --> Helper loaded: url_helper
INFO - 2016-10-03 13:03:32 --> Helper loaded: language_helper
INFO - 2016-10-03 13:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:03:32 --> Controller Class Initialized
INFO - 2016-10-03 13:03:32 --> Database Driver Class Initialized
INFO - 2016-10-03 13:03:32 --> Model Class Initialized
INFO - 2016-10-03 13:03:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:03:32 --> Model Class Initialized
INFO - 2016-10-03 13:03:32 --> Model Class Initialized
INFO - 2016-10-03 13:03:32 --> Helper loaded: form_helper
INFO - 2016-10-03 13:03:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:03:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:03:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:03:32 --> Final output sent to browser
DEBUG - 2016-10-03 13:03:32 --> Total execution time: 0.0778
INFO - 2016-10-03 13:04:16 --> Config Class Initialized
INFO - 2016-10-03 13:04:16 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:04:16 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:04:16 --> Utf8 Class Initialized
INFO - 2016-10-03 13:04:16 --> URI Class Initialized
INFO - 2016-10-03 13:04:16 --> Router Class Initialized
INFO - 2016-10-03 13:04:16 --> Output Class Initialized
INFO - 2016-10-03 13:04:16 --> Security Class Initialized
DEBUG - 2016-10-03 13:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:04:16 --> Input Class Initialized
INFO - 2016-10-03 13:04:16 --> Language Class Initialized
INFO - 2016-10-03 13:04:16 --> Loader Class Initialized
INFO - 2016-10-03 13:04:16 --> Helper loaded: url_helper
INFO - 2016-10-03 13:04:16 --> Helper loaded: language_helper
INFO - 2016-10-03 13:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:04:16 --> Controller Class Initialized
INFO - 2016-10-03 13:04:16 --> Database Driver Class Initialized
INFO - 2016-10-03 13:04:16 --> Model Class Initialized
INFO - 2016-10-03 13:04:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:04:16 --> Model Class Initialized
INFO - 2016-10-03 13:04:16 --> Model Class Initialized
INFO - 2016-10-03 13:04:16 --> Helper loaded: form_helper
INFO - 2016-10-03 13:04:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:04:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:04:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:04:16 --> Final output sent to browser
DEBUG - 2016-10-03 13:04:16 --> Total execution time: 0.0775
INFO - 2016-10-03 13:06:18 --> Config Class Initialized
INFO - 2016-10-03 13:06:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:06:19 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:06:19 --> Utf8 Class Initialized
INFO - 2016-10-03 13:06:19 --> URI Class Initialized
INFO - 2016-10-03 13:06:19 --> Router Class Initialized
INFO - 2016-10-03 13:06:19 --> Output Class Initialized
INFO - 2016-10-03 13:06:19 --> Security Class Initialized
DEBUG - 2016-10-03 13:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:06:19 --> Input Class Initialized
INFO - 2016-10-03 13:06:19 --> Language Class Initialized
INFO - 2016-10-03 13:06:19 --> Loader Class Initialized
INFO - 2016-10-03 13:06:19 --> Helper loaded: url_helper
INFO - 2016-10-03 13:06:19 --> Helper loaded: language_helper
INFO - 2016-10-03 13:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:06:19 --> Controller Class Initialized
INFO - 2016-10-03 13:06:19 --> Database Driver Class Initialized
INFO - 2016-10-03 13:06:19 --> Model Class Initialized
INFO - 2016-10-03 13:06:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:06:19 --> Model Class Initialized
INFO - 2016-10-03 13:06:19 --> Model Class Initialized
INFO - 2016-10-03 13:06:19 --> Helper loaded: form_helper
INFO - 2016-10-03 13:06:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:06:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:06:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:06:19 --> Final output sent to browser
DEBUG - 2016-10-03 13:06:19 --> Total execution time: 0.0817
INFO - 2016-10-03 13:07:46 --> Config Class Initialized
INFO - 2016-10-03 13:07:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:07:46 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:07:46 --> Utf8 Class Initialized
INFO - 2016-10-03 13:07:46 --> URI Class Initialized
INFO - 2016-10-03 13:07:46 --> Router Class Initialized
INFO - 2016-10-03 13:07:46 --> Output Class Initialized
INFO - 2016-10-03 13:07:46 --> Security Class Initialized
DEBUG - 2016-10-03 13:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:07:46 --> Input Class Initialized
INFO - 2016-10-03 13:07:46 --> Language Class Initialized
INFO - 2016-10-03 13:07:46 --> Loader Class Initialized
INFO - 2016-10-03 13:07:46 --> Helper loaded: url_helper
INFO - 2016-10-03 13:07:46 --> Helper loaded: language_helper
INFO - 2016-10-03 13:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:07:46 --> Controller Class Initialized
INFO - 2016-10-03 13:07:46 --> Database Driver Class Initialized
INFO - 2016-10-03 13:07:46 --> Model Class Initialized
INFO - 2016-10-03 13:07:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:07:46 --> Model Class Initialized
INFO - 2016-10-03 13:07:46 --> Model Class Initialized
INFO - 2016-10-03 13:07:46 --> Helper loaded: form_helper
INFO - 2016-10-03 13:07:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:07:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:07:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:07:46 --> Final output sent to browser
DEBUG - 2016-10-03 13:07:46 --> Total execution time: 0.0807
INFO - 2016-10-03 13:11:18 --> Config Class Initialized
INFO - 2016-10-03 13:11:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:11:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:11:18 --> Utf8 Class Initialized
INFO - 2016-10-03 13:11:18 --> URI Class Initialized
INFO - 2016-10-03 13:11:18 --> Router Class Initialized
INFO - 2016-10-03 13:11:18 --> Output Class Initialized
INFO - 2016-10-03 13:11:18 --> Security Class Initialized
DEBUG - 2016-10-03 13:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:11:18 --> Input Class Initialized
INFO - 2016-10-03 13:11:18 --> Language Class Initialized
INFO - 2016-10-03 13:11:18 --> Loader Class Initialized
INFO - 2016-10-03 13:11:18 --> Helper loaded: url_helper
INFO - 2016-10-03 13:11:18 --> Helper loaded: language_helper
INFO - 2016-10-03 13:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:11:18 --> Controller Class Initialized
INFO - 2016-10-03 13:11:18 --> Database Driver Class Initialized
INFO - 2016-10-03 13:11:18 --> Model Class Initialized
INFO - 2016-10-03 13:11:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:11:18 --> Model Class Initialized
ERROR - 2016-10-03 13:11:18 --> Severity: error --> Exception: syntax error, unexpected 'rsort' (T_STRING) C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 200
INFO - 2016-10-03 13:11:26 --> Config Class Initialized
INFO - 2016-10-03 13:11:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:11:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:11:26 --> Utf8 Class Initialized
INFO - 2016-10-03 13:11:26 --> URI Class Initialized
INFO - 2016-10-03 13:11:26 --> Router Class Initialized
INFO - 2016-10-03 13:11:26 --> Output Class Initialized
INFO - 2016-10-03 13:11:26 --> Security Class Initialized
DEBUG - 2016-10-03 13:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:11:26 --> Input Class Initialized
INFO - 2016-10-03 13:11:26 --> Language Class Initialized
INFO - 2016-10-03 13:11:26 --> Loader Class Initialized
INFO - 2016-10-03 13:11:26 --> Helper loaded: url_helper
INFO - 2016-10-03 13:11:26 --> Helper loaded: language_helper
INFO - 2016-10-03 13:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:11:26 --> Controller Class Initialized
INFO - 2016-10-03 13:11:26 --> Database Driver Class Initialized
INFO - 2016-10-03 13:11:26 --> Model Class Initialized
INFO - 2016-10-03 13:11:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:11:26 --> Model Class Initialized
INFO - 2016-10-03 13:11:26 --> Model Class Initialized
INFO - 2016-10-03 13:11:26 --> Helper loaded: form_helper
INFO - 2016-10-03 13:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:11:26 --> Final output sent to browser
DEBUG - 2016-10-03 13:11:26 --> Total execution time: 0.0788
INFO - 2016-10-03 13:11:59 --> Config Class Initialized
INFO - 2016-10-03 13:11:59 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:11:59 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:11:59 --> Utf8 Class Initialized
INFO - 2016-10-03 13:11:59 --> URI Class Initialized
INFO - 2016-10-03 13:11:59 --> Router Class Initialized
INFO - 2016-10-03 13:11:59 --> Output Class Initialized
INFO - 2016-10-03 13:11:59 --> Security Class Initialized
DEBUG - 2016-10-03 13:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:11:59 --> Input Class Initialized
INFO - 2016-10-03 13:11:59 --> Language Class Initialized
INFO - 2016-10-03 13:11:59 --> Loader Class Initialized
INFO - 2016-10-03 13:11:59 --> Helper loaded: url_helper
INFO - 2016-10-03 13:11:59 --> Helper loaded: language_helper
INFO - 2016-10-03 13:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:11:59 --> Controller Class Initialized
INFO - 2016-10-03 13:11:59 --> Database Driver Class Initialized
INFO - 2016-10-03 13:11:59 --> Model Class Initialized
INFO - 2016-10-03 13:11:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:11:59 --> Model Class Initialized
INFO - 2016-10-03 13:11:59 --> Model Class Initialized
INFO - 2016-10-03 13:11:59 --> Helper loaded: form_helper
INFO - 2016-10-03 13:11:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:11:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:11:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:11:59 --> Final output sent to browser
DEBUG - 2016-10-03 13:11:59 --> Total execution time: 0.0800
INFO - 2016-10-03 13:13:29 --> Config Class Initialized
INFO - 2016-10-03 13:13:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:13:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:13:29 --> Utf8 Class Initialized
INFO - 2016-10-03 13:13:29 --> URI Class Initialized
INFO - 2016-10-03 13:13:29 --> Router Class Initialized
INFO - 2016-10-03 13:13:29 --> Output Class Initialized
INFO - 2016-10-03 13:13:29 --> Security Class Initialized
DEBUG - 2016-10-03 13:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:13:29 --> Input Class Initialized
INFO - 2016-10-03 13:13:29 --> Language Class Initialized
INFO - 2016-10-03 13:13:29 --> Loader Class Initialized
INFO - 2016-10-03 13:13:29 --> Helper loaded: url_helper
INFO - 2016-10-03 13:13:29 --> Helper loaded: language_helper
INFO - 2016-10-03 13:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:13:29 --> Controller Class Initialized
INFO - 2016-10-03 13:13:29 --> Database Driver Class Initialized
INFO - 2016-10-03 13:13:29 --> Model Class Initialized
INFO - 2016-10-03 13:13:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:13:29 --> Model Class Initialized
INFO - 2016-10-03 13:13:29 --> Model Class Initialized
INFO - 2016-10-03 13:13:29 --> Helper loaded: form_helper
INFO - 2016-10-03 13:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:13:29 --> Final output sent to browser
DEBUG - 2016-10-03 13:13:29 --> Total execution time: 0.0825
INFO - 2016-10-03 13:14:05 --> Config Class Initialized
INFO - 2016-10-03 13:14:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:14:05 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:14:05 --> Utf8 Class Initialized
INFO - 2016-10-03 13:14:05 --> URI Class Initialized
INFO - 2016-10-03 13:14:05 --> Router Class Initialized
INFO - 2016-10-03 13:14:05 --> Output Class Initialized
INFO - 2016-10-03 13:14:05 --> Security Class Initialized
DEBUG - 2016-10-03 13:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:14:05 --> Input Class Initialized
INFO - 2016-10-03 13:14:05 --> Language Class Initialized
INFO - 2016-10-03 13:14:05 --> Loader Class Initialized
INFO - 2016-10-03 13:14:05 --> Helper loaded: url_helper
INFO - 2016-10-03 13:14:05 --> Helper loaded: language_helper
INFO - 2016-10-03 13:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:14:05 --> Controller Class Initialized
INFO - 2016-10-03 13:14:05 --> Database Driver Class Initialized
INFO - 2016-10-03 13:14:05 --> Model Class Initialized
INFO - 2016-10-03 13:14:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:14:05 --> Model Class Initialized
INFO - 2016-10-03 13:14:05 --> Model Class Initialized
INFO - 2016-10-03 13:14:05 --> Helper loaded: form_helper
INFO - 2016-10-03 13:14:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:14:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:14:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:14:05 --> Final output sent to browser
DEBUG - 2016-10-03 13:14:05 --> Total execution time: 0.0868
INFO - 2016-10-03 13:17:03 --> Config Class Initialized
INFO - 2016-10-03 13:17:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:17:03 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:17:03 --> Utf8 Class Initialized
INFO - 2016-10-03 13:17:03 --> URI Class Initialized
INFO - 2016-10-03 13:17:03 --> Router Class Initialized
INFO - 2016-10-03 13:17:03 --> Output Class Initialized
INFO - 2016-10-03 13:17:03 --> Security Class Initialized
DEBUG - 2016-10-03 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:17:03 --> Input Class Initialized
INFO - 2016-10-03 13:17:03 --> Language Class Initialized
INFO - 2016-10-03 13:17:03 --> Loader Class Initialized
INFO - 2016-10-03 13:17:03 --> Helper loaded: url_helper
INFO - 2016-10-03 13:17:03 --> Helper loaded: language_helper
INFO - 2016-10-03 13:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:17:03 --> Controller Class Initialized
INFO - 2016-10-03 13:17:03 --> Database Driver Class Initialized
INFO - 2016-10-03 13:17:03 --> Model Class Initialized
INFO - 2016-10-03 13:17:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:17:03 --> Model Class Initialized
INFO - 2016-10-03 13:17:03 --> Model Class Initialized
INFO - 2016-10-03 13:17:03 --> Helper loaded: form_helper
ERROR - 2016-10-03 13:17:03 --> Severity: Notice --> Undefined variable: rco C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 197
INFO - 2016-10-03 13:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:17:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:17:03 --> Final output sent to browser
DEBUG - 2016-10-03 13:17:03 --> Total execution time: 0.0850
INFO - 2016-10-03 13:17:21 --> Config Class Initialized
INFO - 2016-10-03 13:17:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:17:21 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:17:21 --> Utf8 Class Initialized
INFO - 2016-10-03 13:17:21 --> URI Class Initialized
INFO - 2016-10-03 13:17:21 --> Router Class Initialized
INFO - 2016-10-03 13:17:21 --> Output Class Initialized
INFO - 2016-10-03 13:17:21 --> Security Class Initialized
DEBUG - 2016-10-03 13:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:17:21 --> Input Class Initialized
INFO - 2016-10-03 13:17:21 --> Language Class Initialized
INFO - 2016-10-03 13:17:21 --> Loader Class Initialized
INFO - 2016-10-03 13:17:21 --> Helper loaded: url_helper
INFO - 2016-10-03 13:17:21 --> Helper loaded: language_helper
INFO - 2016-10-03 13:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:17:21 --> Controller Class Initialized
INFO - 2016-10-03 13:17:21 --> Database Driver Class Initialized
INFO - 2016-10-03 13:17:21 --> Model Class Initialized
INFO - 2016-10-03 13:17:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:17:21 --> Model Class Initialized
INFO - 2016-10-03 13:17:21 --> Model Class Initialized
INFO - 2016-10-03 13:17:21 --> Helper loaded: form_helper
INFO - 2016-10-03 13:17:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:17:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:17:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:17:21 --> Final output sent to browser
DEBUG - 2016-10-03 13:17:21 --> Total execution time: 0.0799
INFO - 2016-10-03 13:18:15 --> Config Class Initialized
INFO - 2016-10-03 13:18:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:18:15 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:18:15 --> Utf8 Class Initialized
INFO - 2016-10-03 13:18:15 --> URI Class Initialized
INFO - 2016-10-03 13:18:15 --> Router Class Initialized
INFO - 2016-10-03 13:18:15 --> Output Class Initialized
INFO - 2016-10-03 13:18:15 --> Security Class Initialized
DEBUG - 2016-10-03 13:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:18:15 --> Input Class Initialized
INFO - 2016-10-03 13:18:15 --> Language Class Initialized
INFO - 2016-10-03 13:18:15 --> Loader Class Initialized
INFO - 2016-10-03 13:18:15 --> Helper loaded: url_helper
INFO - 2016-10-03 13:18:15 --> Helper loaded: language_helper
INFO - 2016-10-03 13:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:18:15 --> Controller Class Initialized
INFO - 2016-10-03 13:18:15 --> Database Driver Class Initialized
INFO - 2016-10-03 13:18:15 --> Model Class Initialized
INFO - 2016-10-03 13:18:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:18:15 --> Model Class Initialized
INFO - 2016-10-03 13:18:15 --> Model Class Initialized
INFO - 2016-10-03 13:18:15 --> Helper loaded: form_helper
ERROR - 2016-10-03 13:18:15 --> Severity: Notice --> Undefined variable: rcos C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 199
ERROR - 2016-10-03 13:18:15 --> Severity: Warning --> rsort() expects parameter 1 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 200
ERROR - 2016-10-03 13:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 203
ERROR - 2016-10-03 13:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 203
ERROR - 2016-10-03 13:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 203
ERROR - 2016-10-03 13:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 203
INFO - 2016-10-03 13:18:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:18:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:18:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:18:15 --> Final output sent to browser
DEBUG - 2016-10-03 13:18:15 --> Total execution time: 0.1049
INFO - 2016-10-03 13:18:27 --> Config Class Initialized
INFO - 2016-10-03 13:18:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:18:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:18:27 --> Utf8 Class Initialized
INFO - 2016-10-03 13:18:27 --> URI Class Initialized
INFO - 2016-10-03 13:18:27 --> Router Class Initialized
INFO - 2016-10-03 13:18:27 --> Output Class Initialized
INFO - 2016-10-03 13:18:27 --> Security Class Initialized
DEBUG - 2016-10-03 13:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:18:27 --> Input Class Initialized
INFO - 2016-10-03 13:18:27 --> Language Class Initialized
INFO - 2016-10-03 13:18:27 --> Loader Class Initialized
INFO - 2016-10-03 13:18:27 --> Helper loaded: url_helper
INFO - 2016-10-03 13:18:27 --> Helper loaded: language_helper
INFO - 2016-10-03 13:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:18:27 --> Controller Class Initialized
INFO - 2016-10-03 13:18:27 --> Database Driver Class Initialized
INFO - 2016-10-03 13:18:27 --> Model Class Initialized
INFO - 2016-10-03 13:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:18:27 --> Model Class Initialized
INFO - 2016-10-03 13:18:27 --> Model Class Initialized
INFO - 2016-10-03 13:18:27 --> Helper loaded: form_helper
INFO - 2016-10-03 13:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:18:27 --> Final output sent to browser
DEBUG - 2016-10-03 13:18:27 --> Total execution time: 0.0897
INFO - 2016-10-03 13:20:15 --> Config Class Initialized
INFO - 2016-10-03 13:20:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:20:15 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:20:15 --> Utf8 Class Initialized
INFO - 2016-10-03 13:20:15 --> URI Class Initialized
INFO - 2016-10-03 13:20:15 --> Router Class Initialized
INFO - 2016-10-03 13:20:15 --> Output Class Initialized
INFO - 2016-10-03 13:20:15 --> Security Class Initialized
DEBUG - 2016-10-03 13:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:20:15 --> Input Class Initialized
INFO - 2016-10-03 13:20:15 --> Language Class Initialized
INFO - 2016-10-03 13:20:15 --> Loader Class Initialized
INFO - 2016-10-03 13:20:15 --> Helper loaded: url_helper
INFO - 2016-10-03 13:20:15 --> Helper loaded: language_helper
INFO - 2016-10-03 13:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:20:15 --> Controller Class Initialized
INFO - 2016-10-03 13:20:15 --> Database Driver Class Initialized
INFO - 2016-10-03 13:20:15 --> Model Class Initialized
INFO - 2016-10-03 13:20:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:20:15 --> Model Class Initialized
INFO - 2016-10-03 13:20:15 --> Model Class Initialized
INFO - 2016-10-03 13:20:15 --> Helper loaded: form_helper
INFO - 2016-10-03 13:20:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:20:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:20:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:20:15 --> Final output sent to browser
DEBUG - 2016-10-03 13:20:15 --> Total execution time: 0.0818
INFO - 2016-10-03 13:20:57 --> Config Class Initialized
INFO - 2016-10-03 13:20:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 13:20:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 13:20:57 --> Utf8 Class Initialized
INFO - 2016-10-03 13:20:57 --> URI Class Initialized
INFO - 2016-10-03 13:20:57 --> Router Class Initialized
INFO - 2016-10-03 13:20:57 --> Output Class Initialized
INFO - 2016-10-03 13:20:57 --> Security Class Initialized
DEBUG - 2016-10-03 13:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 13:20:57 --> Input Class Initialized
INFO - 2016-10-03 13:20:57 --> Language Class Initialized
INFO - 2016-10-03 13:20:57 --> Loader Class Initialized
INFO - 2016-10-03 13:20:57 --> Helper loaded: url_helper
INFO - 2016-10-03 13:20:57 --> Helper loaded: language_helper
INFO - 2016-10-03 13:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 13:20:57 --> Controller Class Initialized
INFO - 2016-10-03 13:20:57 --> Database Driver Class Initialized
INFO - 2016-10-03 13:20:57 --> Model Class Initialized
INFO - 2016-10-03 13:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 13:20:57 --> Model Class Initialized
INFO - 2016-10-03 13:20:57 --> Model Class Initialized
INFO - 2016-10-03 13:20:57 --> Helper loaded: form_helper
INFO - 2016-10-03 13:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 13:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 13:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 13:20:57 --> Final output sent to browser
DEBUG - 2016-10-03 13:20:57 --> Total execution time: 0.0769
INFO - 2016-10-03 14:45:23 --> Config Class Initialized
INFO - 2016-10-03 14:45:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:45:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 14:45:23 --> Utf8 Class Initialized
INFO - 2016-10-03 14:45:23 --> URI Class Initialized
INFO - 2016-10-03 14:45:23 --> Router Class Initialized
INFO - 2016-10-03 14:45:23 --> Output Class Initialized
INFO - 2016-10-03 14:45:23 --> Security Class Initialized
DEBUG - 2016-10-03 14:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 14:45:23 --> Input Class Initialized
INFO - 2016-10-03 14:45:23 --> Language Class Initialized
INFO - 2016-10-03 14:45:23 --> Loader Class Initialized
INFO - 2016-10-03 14:45:23 --> Helper loaded: url_helper
INFO - 2016-10-03 14:45:23 --> Helper loaded: language_helper
INFO - 2016-10-03 14:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 14:45:23 --> Controller Class Initialized
INFO - 2016-10-03 14:45:23 --> Database Driver Class Initialized
INFO - 2016-10-03 14:45:23 --> Model Class Initialized
INFO - 2016-10-03 14:45:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 14:45:23 --> Model Class Initialized
INFO - 2016-10-03 14:45:23 --> Model Class Initialized
INFO - 2016-10-03 14:45:23 --> Helper loaded: form_helper
INFO - 2016-10-03 14:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 14:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 14:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 14:45:23 --> Final output sent to browser
DEBUG - 2016-10-03 14:45:23 --> Total execution time: 0.0940
INFO - 2016-10-03 14:45:26 --> Config Class Initialized
INFO - 2016-10-03 14:45:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:45:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 14:45:26 --> Utf8 Class Initialized
INFO - 2016-10-03 14:45:26 --> URI Class Initialized
INFO - 2016-10-03 14:45:26 --> Router Class Initialized
INFO - 2016-10-03 14:45:26 --> Output Class Initialized
INFO - 2016-10-03 14:45:26 --> Security Class Initialized
DEBUG - 2016-10-03 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 14:45:26 --> Input Class Initialized
INFO - 2016-10-03 14:45:26 --> Language Class Initialized
INFO - 2016-10-03 14:45:26 --> Loader Class Initialized
INFO - 2016-10-03 14:45:26 --> Helper loaded: url_helper
INFO - 2016-10-03 14:45:26 --> Helper loaded: language_helper
INFO - 2016-10-03 14:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 14:45:26 --> Controller Class Initialized
INFO - 2016-10-03 14:45:26 --> Database Driver Class Initialized
INFO - 2016-10-03 14:45:26 --> Model Class Initialized
INFO - 2016-10-03 14:45:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 14:45:26 --> Model Class Initialized
INFO - 2016-10-03 14:45:26 --> Model Class Initialized
INFO - 2016-10-03 14:45:26 --> Helper loaded: form_helper
INFO - 2016-10-03 14:45:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 14:45:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 14:45:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 14:45:26 --> Final output sent to browser
DEBUG - 2016-10-03 14:45:26 --> Total execution time: 0.0857
INFO - 2016-10-03 14:45:31 --> Config Class Initialized
INFO - 2016-10-03 14:45:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:45:31 --> UTF-8 Support Enabled
INFO - 2016-10-03 14:45:31 --> Utf8 Class Initialized
INFO - 2016-10-03 14:45:31 --> URI Class Initialized
INFO - 2016-10-03 14:45:31 --> Router Class Initialized
INFO - 2016-10-03 14:45:31 --> Output Class Initialized
INFO - 2016-10-03 14:45:31 --> Security Class Initialized
DEBUG - 2016-10-03 14:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 14:45:31 --> Input Class Initialized
INFO - 2016-10-03 14:45:31 --> Language Class Initialized
INFO - 2016-10-03 14:45:31 --> Loader Class Initialized
INFO - 2016-10-03 14:45:31 --> Helper loaded: url_helper
INFO - 2016-10-03 14:45:31 --> Helper loaded: language_helper
INFO - 2016-10-03 14:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 14:45:31 --> Controller Class Initialized
INFO - 2016-10-03 14:45:31 --> Database Driver Class Initialized
INFO - 2016-10-03 14:45:31 --> Model Class Initialized
INFO - 2016-10-03 14:45:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 14:45:31 --> Model Class Initialized
INFO - 2016-10-03 14:45:31 --> Model Class Initialized
INFO - 2016-10-03 14:45:31 --> Helper loaded: form_helper
INFO - 2016-10-03 14:45:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 14:45:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 14:45:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 14:45:31 --> Final output sent to browser
DEBUG - 2016-10-03 14:45:31 --> Total execution time: 0.0972
INFO - 2016-10-03 14:46:42 --> Config Class Initialized
INFO - 2016-10-03 14:46:42 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:46:42 --> UTF-8 Support Enabled
INFO - 2016-10-03 14:46:42 --> Utf8 Class Initialized
INFO - 2016-10-03 14:46:42 --> URI Class Initialized
INFO - 2016-10-03 14:46:42 --> Router Class Initialized
INFO - 2016-10-03 14:46:42 --> Output Class Initialized
INFO - 2016-10-03 14:46:42 --> Security Class Initialized
DEBUG - 2016-10-03 14:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 14:46:42 --> Input Class Initialized
INFO - 2016-10-03 14:46:42 --> Language Class Initialized
INFO - 2016-10-03 14:46:42 --> Loader Class Initialized
INFO - 2016-10-03 14:46:42 --> Helper loaded: url_helper
INFO - 2016-10-03 14:46:42 --> Helper loaded: language_helper
INFO - 2016-10-03 14:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 14:46:42 --> Controller Class Initialized
INFO - 2016-10-03 14:46:42 --> Database Driver Class Initialized
INFO - 2016-10-03 14:46:42 --> Model Class Initialized
INFO - 2016-10-03 14:46:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 14:46:42 --> Model Class Initialized
INFO - 2016-10-03 14:46:42 --> Model Class Initialized
INFO - 2016-10-03 14:46:42 --> Helper loaded: form_helper
INFO - 2016-10-03 14:46:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 14:46:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 14:46:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 14:46:42 --> Final output sent to browser
DEBUG - 2016-10-03 14:46:42 --> Total execution time: 0.0799
INFO - 2016-10-03 14:47:01 --> Config Class Initialized
INFO - 2016-10-03 14:47:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:47:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 14:47:01 --> Utf8 Class Initialized
INFO - 2016-10-03 14:47:01 --> URI Class Initialized
INFO - 2016-10-03 14:47:01 --> Router Class Initialized
INFO - 2016-10-03 14:47:01 --> Output Class Initialized
INFO - 2016-10-03 14:47:01 --> Security Class Initialized
DEBUG - 2016-10-03 14:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 14:47:01 --> Input Class Initialized
INFO - 2016-10-03 14:47:01 --> Language Class Initialized
INFO - 2016-10-03 14:47:01 --> Loader Class Initialized
INFO - 2016-10-03 14:47:01 --> Helper loaded: url_helper
INFO - 2016-10-03 14:47:01 --> Helper loaded: language_helper
INFO - 2016-10-03 14:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 14:47:01 --> Controller Class Initialized
INFO - 2016-10-03 14:47:01 --> Database Driver Class Initialized
INFO - 2016-10-03 14:47:01 --> Model Class Initialized
INFO - 2016-10-03 14:47:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 14:47:01 --> Model Class Initialized
INFO - 2016-10-03 14:47:01 --> Model Class Initialized
INFO - 2016-10-03 14:47:01 --> Helper loaded: form_helper
INFO - 2016-10-03 14:47:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 14:47:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 14:47:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 14:47:01 --> Final output sent to browser
DEBUG - 2016-10-03 14:47:01 --> Total execution time: 0.0886
INFO - 2016-10-03 14:53:49 --> Config Class Initialized
INFO - 2016-10-03 14:53:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:53:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 14:53:49 --> Utf8 Class Initialized
INFO - 2016-10-03 14:53:49 --> URI Class Initialized
INFO - 2016-10-03 14:53:49 --> Router Class Initialized
INFO - 2016-10-03 14:53:49 --> Output Class Initialized
INFO - 2016-10-03 14:53:49 --> Security Class Initialized
DEBUG - 2016-10-03 14:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 14:53:49 --> Input Class Initialized
INFO - 2016-10-03 14:53:49 --> Language Class Initialized
INFO - 2016-10-03 14:53:49 --> Loader Class Initialized
INFO - 2016-10-03 14:53:49 --> Helper loaded: url_helper
INFO - 2016-10-03 14:53:49 --> Helper loaded: language_helper
INFO - 2016-10-03 14:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 14:53:49 --> Controller Class Initialized
INFO - 2016-10-03 14:53:49 --> Database Driver Class Initialized
INFO - 2016-10-03 14:53:49 --> Model Class Initialized
INFO - 2016-10-03 14:53:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 14:53:49 --> Model Class Initialized
INFO - 2016-10-03 14:53:49 --> Model Class Initialized
INFO - 2016-10-03 14:53:49 --> Helper loaded: form_helper
INFO - 2016-10-03 14:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 14:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 14:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 14:53:49 --> Final output sent to browser
DEBUG - 2016-10-03 14:53:49 --> Total execution time: 0.1063
INFO - 2016-10-03 15:00:25 --> Config Class Initialized
INFO - 2016-10-03 15:00:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 15:00:25 --> UTF-8 Support Enabled
INFO - 2016-10-03 15:00:25 --> Utf8 Class Initialized
INFO - 2016-10-03 15:00:25 --> URI Class Initialized
INFO - 2016-10-03 15:00:25 --> Router Class Initialized
INFO - 2016-10-03 15:00:25 --> Output Class Initialized
INFO - 2016-10-03 15:00:25 --> Security Class Initialized
DEBUG - 2016-10-03 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 15:00:25 --> Input Class Initialized
INFO - 2016-10-03 15:00:25 --> Language Class Initialized
INFO - 2016-10-03 15:00:25 --> Loader Class Initialized
INFO - 2016-10-03 15:00:25 --> Helper loaded: url_helper
INFO - 2016-10-03 15:00:25 --> Helper loaded: language_helper
INFO - 2016-10-03 15:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 15:00:25 --> Controller Class Initialized
INFO - 2016-10-03 15:00:25 --> Database Driver Class Initialized
INFO - 2016-10-03 15:00:25 --> Model Class Initialized
INFO - 2016-10-03 15:00:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 15:00:25 --> Model Class Initialized
INFO - 2016-10-03 15:00:25 --> Model Class Initialized
INFO - 2016-10-03 15:00:25 --> Helper loaded: form_helper
INFO - 2016-10-03 15:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 15:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 15:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 15:00:25 --> Final output sent to browser
DEBUG - 2016-10-03 15:00:25 --> Total execution time: 0.0819
INFO - 2016-10-03 15:00:47 --> Config Class Initialized
INFO - 2016-10-03 15:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-03 15:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-03 15:00:47 --> Utf8 Class Initialized
INFO - 2016-10-03 15:00:47 --> URI Class Initialized
INFO - 2016-10-03 15:00:47 --> Router Class Initialized
INFO - 2016-10-03 15:00:47 --> Output Class Initialized
INFO - 2016-10-03 15:00:47 --> Security Class Initialized
DEBUG - 2016-10-03 15:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 15:00:47 --> Input Class Initialized
INFO - 2016-10-03 15:00:47 --> Language Class Initialized
INFO - 2016-10-03 15:00:47 --> Loader Class Initialized
INFO - 2016-10-03 15:00:47 --> Helper loaded: url_helper
INFO - 2016-10-03 15:00:47 --> Helper loaded: language_helper
INFO - 2016-10-03 15:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 15:00:47 --> Controller Class Initialized
INFO - 2016-10-03 15:00:47 --> Database Driver Class Initialized
INFO - 2016-10-03 15:00:47 --> Model Class Initialized
INFO - 2016-10-03 15:00:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 15:00:47 --> Model Class Initialized
INFO - 2016-10-03 15:00:47 --> Model Class Initialized
INFO - 2016-10-03 15:00:47 --> Helper loaded: form_helper
INFO - 2016-10-03 15:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 15:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 15:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 15:00:47 --> Final output sent to browser
DEBUG - 2016-10-03 15:00:47 --> Total execution time: 0.0757
INFO - 2016-10-03 15:02:22 --> Config Class Initialized
INFO - 2016-10-03 15:02:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 15:02:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 15:02:22 --> Utf8 Class Initialized
INFO - 2016-10-03 15:02:22 --> URI Class Initialized
INFO - 2016-10-03 15:02:22 --> Router Class Initialized
INFO - 2016-10-03 15:02:22 --> Output Class Initialized
INFO - 2016-10-03 15:02:22 --> Security Class Initialized
DEBUG - 2016-10-03 15:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 15:02:22 --> Input Class Initialized
INFO - 2016-10-03 15:02:22 --> Language Class Initialized
INFO - 2016-10-03 15:02:22 --> Loader Class Initialized
INFO - 2016-10-03 15:02:22 --> Helper loaded: url_helper
INFO - 2016-10-03 15:02:22 --> Helper loaded: language_helper
INFO - 2016-10-03 15:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 15:02:22 --> Controller Class Initialized
INFO - 2016-10-03 15:02:22 --> Database Driver Class Initialized
INFO - 2016-10-03 15:02:22 --> Model Class Initialized
INFO - 2016-10-03 15:02:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 15:02:22 --> Model Class Initialized
INFO - 2016-10-03 15:02:22 --> Model Class Initialized
INFO - 2016-10-03 15:02:22 --> Helper loaded: form_helper
INFO - 2016-10-03 15:02:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 15:02:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 15:02:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 15:02:22 --> Final output sent to browser
DEBUG - 2016-10-03 15:02:22 --> Total execution time: 0.0802
INFO - 2016-10-03 16:13:13 --> Config Class Initialized
INFO - 2016-10-03 16:13:13 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:13:14 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:13:14 --> Utf8 Class Initialized
INFO - 2016-10-03 16:13:14 --> URI Class Initialized
INFO - 2016-10-03 16:13:14 --> Router Class Initialized
INFO - 2016-10-03 16:13:14 --> Output Class Initialized
INFO - 2016-10-03 16:13:14 --> Security Class Initialized
DEBUG - 2016-10-03 16:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:13:14 --> Input Class Initialized
INFO - 2016-10-03 16:13:14 --> Language Class Initialized
INFO - 2016-10-03 16:13:14 --> Loader Class Initialized
INFO - 2016-10-03 16:13:14 --> Helper loaded: url_helper
INFO - 2016-10-03 16:13:14 --> Helper loaded: language_helper
INFO - 2016-10-03 16:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:13:14 --> Controller Class Initialized
INFO - 2016-10-03 16:13:14 --> Database Driver Class Initialized
INFO - 2016-10-03 16:13:14 --> Model Class Initialized
INFO - 2016-10-03 16:13:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:13:14 --> Model Class Initialized
INFO - 2016-10-03 16:13:14 --> Model Class Initialized
INFO - 2016-10-03 16:13:14 --> Helper loaded: form_helper
INFO - 2016-10-03 16:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:13:14 --> Final output sent to browser
DEBUG - 2016-10-03 16:13:14 --> Total execution time: 0.0999
INFO - 2016-10-03 16:14:30 --> Config Class Initialized
INFO - 2016-10-03 16:14:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:14:30 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:14:30 --> Utf8 Class Initialized
INFO - 2016-10-03 16:14:30 --> URI Class Initialized
INFO - 2016-10-03 16:14:30 --> Router Class Initialized
INFO - 2016-10-03 16:14:30 --> Output Class Initialized
INFO - 2016-10-03 16:14:30 --> Security Class Initialized
DEBUG - 2016-10-03 16:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:14:30 --> Input Class Initialized
INFO - 2016-10-03 16:14:30 --> Language Class Initialized
INFO - 2016-10-03 16:14:30 --> Loader Class Initialized
INFO - 2016-10-03 16:14:30 --> Helper loaded: url_helper
INFO - 2016-10-03 16:14:30 --> Helper loaded: language_helper
INFO - 2016-10-03 16:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:14:30 --> Controller Class Initialized
INFO - 2016-10-03 16:14:30 --> Database Driver Class Initialized
INFO - 2016-10-03 16:14:30 --> Model Class Initialized
INFO - 2016-10-03 16:14:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:14:30 --> Model Class Initialized
INFO - 2016-10-03 16:14:30 --> Model Class Initialized
INFO - 2016-10-03 16:14:30 --> Helper loaded: form_helper
INFO - 2016-10-03 16:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:14:30 --> Final output sent to browser
DEBUG - 2016-10-03 16:14:30 --> Total execution time: 0.0796
INFO - 2016-10-03 16:15:30 --> Config Class Initialized
INFO - 2016-10-03 16:15:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:15:30 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:15:30 --> Utf8 Class Initialized
INFO - 2016-10-03 16:15:30 --> URI Class Initialized
INFO - 2016-10-03 16:15:30 --> Router Class Initialized
INFO - 2016-10-03 16:15:30 --> Output Class Initialized
INFO - 2016-10-03 16:15:30 --> Security Class Initialized
DEBUG - 2016-10-03 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:15:30 --> Input Class Initialized
INFO - 2016-10-03 16:15:30 --> Language Class Initialized
INFO - 2016-10-03 16:15:30 --> Loader Class Initialized
INFO - 2016-10-03 16:15:30 --> Helper loaded: url_helper
INFO - 2016-10-03 16:15:30 --> Helper loaded: language_helper
INFO - 2016-10-03 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:15:30 --> Controller Class Initialized
INFO - 2016-10-03 16:15:30 --> Database Driver Class Initialized
INFO - 2016-10-03 16:15:30 --> Model Class Initialized
INFO - 2016-10-03 16:15:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:15:30 --> Model Class Initialized
INFO - 2016-10-03 16:15:30 --> Model Class Initialized
INFO - 2016-10-03 16:15:30 --> Helper loaded: form_helper
INFO - 2016-10-03 16:15:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:15:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:15:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:15:30 --> Final output sent to browser
DEBUG - 2016-10-03 16:15:30 --> Total execution time: 0.0882
INFO - 2016-10-03 16:23:17 --> Config Class Initialized
INFO - 2016-10-03 16:23:17 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:23:17 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:23:17 --> Utf8 Class Initialized
INFO - 2016-10-03 16:23:17 --> URI Class Initialized
INFO - 2016-10-03 16:23:17 --> Router Class Initialized
INFO - 2016-10-03 16:23:17 --> Output Class Initialized
INFO - 2016-10-03 16:23:17 --> Security Class Initialized
DEBUG - 2016-10-03 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:23:17 --> Input Class Initialized
INFO - 2016-10-03 16:23:17 --> Language Class Initialized
INFO - 2016-10-03 16:23:17 --> Loader Class Initialized
INFO - 2016-10-03 16:23:17 --> Helper loaded: url_helper
INFO - 2016-10-03 16:23:17 --> Helper loaded: language_helper
INFO - 2016-10-03 16:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:23:17 --> Controller Class Initialized
INFO - 2016-10-03 16:23:17 --> Database Driver Class Initialized
INFO - 2016-10-03 16:23:17 --> Model Class Initialized
INFO - 2016-10-03 16:23:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:23:17 --> Model Class Initialized
INFO - 2016-10-03 16:23:17 --> Model Class Initialized
INFO - 2016-10-03 16:23:17 --> Helper loaded: form_helper
INFO - 2016-10-03 16:23:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:23:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:23:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:23:17 --> Final output sent to browser
DEBUG - 2016-10-03 16:23:17 --> Total execution time: 0.0834
INFO - 2016-10-03 16:24:54 --> Config Class Initialized
INFO - 2016-10-03 16:24:54 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:24:54 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:24:54 --> Utf8 Class Initialized
INFO - 2016-10-03 16:24:54 --> URI Class Initialized
INFO - 2016-10-03 16:24:54 --> Router Class Initialized
INFO - 2016-10-03 16:24:54 --> Output Class Initialized
INFO - 2016-10-03 16:24:54 --> Security Class Initialized
DEBUG - 2016-10-03 16:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:24:54 --> Input Class Initialized
INFO - 2016-10-03 16:24:54 --> Language Class Initialized
INFO - 2016-10-03 16:24:54 --> Loader Class Initialized
INFO - 2016-10-03 16:24:54 --> Helper loaded: url_helper
INFO - 2016-10-03 16:24:54 --> Helper loaded: language_helper
INFO - 2016-10-03 16:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:24:54 --> Controller Class Initialized
INFO - 2016-10-03 16:24:54 --> Database Driver Class Initialized
INFO - 2016-10-03 16:24:54 --> Model Class Initialized
INFO - 2016-10-03 16:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:24:54 --> Model Class Initialized
INFO - 2016-10-03 16:24:54 --> Model Class Initialized
INFO - 2016-10-03 16:24:54 --> Helper loaded: form_helper
INFO - 2016-10-03 16:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:24:54 --> Final output sent to browser
DEBUG - 2016-10-03 16:24:54 --> Total execution time: 0.0808
INFO - 2016-10-03 16:26:45 --> Config Class Initialized
INFO - 2016-10-03 16:26:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:26:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:26:45 --> Utf8 Class Initialized
INFO - 2016-10-03 16:26:45 --> URI Class Initialized
INFO - 2016-10-03 16:26:45 --> Router Class Initialized
INFO - 2016-10-03 16:26:45 --> Output Class Initialized
INFO - 2016-10-03 16:26:45 --> Security Class Initialized
DEBUG - 2016-10-03 16:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:26:45 --> Input Class Initialized
INFO - 2016-10-03 16:26:45 --> Language Class Initialized
INFO - 2016-10-03 16:26:45 --> Loader Class Initialized
INFO - 2016-10-03 16:26:45 --> Helper loaded: url_helper
INFO - 2016-10-03 16:26:45 --> Helper loaded: language_helper
INFO - 2016-10-03 16:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:26:45 --> Controller Class Initialized
INFO - 2016-10-03 16:26:45 --> Database Driver Class Initialized
INFO - 2016-10-03 16:26:45 --> Model Class Initialized
INFO - 2016-10-03 16:26:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:26:45 --> Model Class Initialized
INFO - 2016-10-03 16:26:45 --> Model Class Initialized
INFO - 2016-10-03 16:26:45 --> Helper loaded: form_helper
INFO - 2016-10-03 16:26:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:26:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:26:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:26:45 --> Final output sent to browser
DEBUG - 2016-10-03 16:26:45 --> Total execution time: 0.0891
INFO - 2016-10-03 16:54:02 --> Config Class Initialized
INFO - 2016-10-03 16:54:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:54:02 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:54:02 --> Utf8 Class Initialized
INFO - 2016-10-03 16:54:02 --> URI Class Initialized
INFO - 2016-10-03 16:54:02 --> Router Class Initialized
INFO - 2016-10-03 16:54:02 --> Output Class Initialized
INFO - 2016-10-03 16:54:02 --> Security Class Initialized
DEBUG - 2016-10-03 16:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:54:02 --> Input Class Initialized
INFO - 2016-10-03 16:54:02 --> Language Class Initialized
INFO - 2016-10-03 16:54:02 --> Loader Class Initialized
INFO - 2016-10-03 16:54:02 --> Helper loaded: url_helper
INFO - 2016-10-03 16:54:02 --> Helper loaded: language_helper
INFO - 2016-10-03 16:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:54:02 --> Controller Class Initialized
INFO - 2016-10-03 16:54:02 --> Database Driver Class Initialized
INFO - 2016-10-03 16:54:02 --> Model Class Initialized
INFO - 2016-10-03 16:54:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:54:02 --> Model Class Initialized
INFO - 2016-10-03 16:54:02 --> Model Class Initialized
INFO - 2016-10-03 16:54:02 --> Helper loaded: form_helper
INFO - 2016-10-03 16:54:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:54:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:54:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:54:02 --> Final output sent to browser
DEBUG - 2016-10-03 16:54:02 --> Total execution time: 0.0923
INFO - 2016-10-03 16:58:33 --> Config Class Initialized
INFO - 2016-10-03 16:58:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:58:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:58:33 --> Utf8 Class Initialized
INFO - 2016-10-03 16:58:33 --> URI Class Initialized
INFO - 2016-10-03 16:58:33 --> Router Class Initialized
INFO - 2016-10-03 16:58:33 --> Output Class Initialized
INFO - 2016-10-03 16:58:33 --> Security Class Initialized
DEBUG - 2016-10-03 16:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:58:33 --> Input Class Initialized
INFO - 2016-10-03 16:58:33 --> Language Class Initialized
INFO - 2016-10-03 16:58:33 --> Loader Class Initialized
INFO - 2016-10-03 16:58:33 --> Helper loaded: url_helper
INFO - 2016-10-03 16:58:33 --> Helper loaded: language_helper
INFO - 2016-10-03 16:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:58:33 --> Controller Class Initialized
INFO - 2016-10-03 16:58:33 --> Database Driver Class Initialized
INFO - 2016-10-03 16:58:33 --> Model Class Initialized
INFO - 2016-10-03 16:58:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:58:33 --> Model Class Initialized
INFO - 2016-10-03 16:58:33 --> Model Class Initialized
INFO - 2016-10-03 16:58:33 --> Helper loaded: form_helper
INFO - 2016-10-03 16:58:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:58:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:58:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:58:34 --> Final output sent to browser
DEBUG - 2016-10-03 16:58:34 --> Total execution time: 0.0829
INFO - 2016-10-03 16:59:02 --> Config Class Initialized
INFO - 2016-10-03 16:59:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:59:02 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:59:02 --> Utf8 Class Initialized
INFO - 2016-10-03 16:59:02 --> URI Class Initialized
INFO - 2016-10-03 16:59:02 --> Router Class Initialized
INFO - 2016-10-03 16:59:02 --> Output Class Initialized
INFO - 2016-10-03 16:59:02 --> Security Class Initialized
DEBUG - 2016-10-03 16:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:59:02 --> Input Class Initialized
INFO - 2016-10-03 16:59:02 --> Language Class Initialized
INFO - 2016-10-03 16:59:03 --> Loader Class Initialized
INFO - 2016-10-03 16:59:03 --> Helper loaded: url_helper
INFO - 2016-10-03 16:59:03 --> Helper loaded: language_helper
INFO - 2016-10-03 16:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:59:03 --> Controller Class Initialized
INFO - 2016-10-03 16:59:03 --> Database Driver Class Initialized
INFO - 2016-10-03 16:59:03 --> Model Class Initialized
INFO - 2016-10-03 16:59:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:59:03 --> Model Class Initialized
INFO - 2016-10-03 16:59:03 --> Model Class Initialized
INFO - 2016-10-03 16:59:03 --> Helper loaded: form_helper
INFO - 2016-10-03 16:59:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:59:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:59:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:59:03 --> Final output sent to browser
DEBUG - 2016-10-03 16:59:03 --> Total execution time: 0.0809
INFO - 2016-10-03 16:59:27 --> Config Class Initialized
INFO - 2016-10-03 16:59:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 16:59:27 --> UTF-8 Support Enabled
INFO - 2016-10-03 16:59:27 --> Utf8 Class Initialized
INFO - 2016-10-03 16:59:27 --> URI Class Initialized
INFO - 2016-10-03 16:59:27 --> Router Class Initialized
INFO - 2016-10-03 16:59:27 --> Output Class Initialized
INFO - 2016-10-03 16:59:27 --> Security Class Initialized
DEBUG - 2016-10-03 16:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 16:59:27 --> Input Class Initialized
INFO - 2016-10-03 16:59:27 --> Language Class Initialized
INFO - 2016-10-03 16:59:27 --> Loader Class Initialized
INFO - 2016-10-03 16:59:27 --> Helper loaded: url_helper
INFO - 2016-10-03 16:59:27 --> Helper loaded: language_helper
INFO - 2016-10-03 16:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 16:59:27 --> Controller Class Initialized
INFO - 2016-10-03 16:59:27 --> Database Driver Class Initialized
INFO - 2016-10-03 16:59:27 --> Model Class Initialized
INFO - 2016-10-03 16:59:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 16:59:27 --> Model Class Initialized
INFO - 2016-10-03 16:59:27 --> Model Class Initialized
INFO - 2016-10-03 16:59:27 --> Helper loaded: form_helper
INFO - 2016-10-03 16:59:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 16:59:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 16:59:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 16:59:27 --> Final output sent to browser
DEBUG - 2016-10-03 16:59:27 --> Total execution time: 0.0800
INFO - 2016-10-03 17:00:45 --> Config Class Initialized
INFO - 2016-10-03 17:00:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:00:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:00:45 --> Utf8 Class Initialized
INFO - 2016-10-03 17:00:45 --> URI Class Initialized
INFO - 2016-10-03 17:00:45 --> Router Class Initialized
INFO - 2016-10-03 17:00:45 --> Output Class Initialized
INFO - 2016-10-03 17:00:45 --> Security Class Initialized
DEBUG - 2016-10-03 17:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:00:45 --> Input Class Initialized
INFO - 2016-10-03 17:00:45 --> Language Class Initialized
INFO - 2016-10-03 17:00:45 --> Loader Class Initialized
INFO - 2016-10-03 17:00:45 --> Helper loaded: url_helper
INFO - 2016-10-03 17:00:45 --> Helper loaded: language_helper
INFO - 2016-10-03 17:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:00:46 --> Controller Class Initialized
INFO - 2016-10-03 17:00:46 --> Database Driver Class Initialized
INFO - 2016-10-03 17:00:46 --> Model Class Initialized
INFO - 2016-10-03 17:00:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:00:46 --> Model Class Initialized
INFO - 2016-10-03 17:00:46 --> Model Class Initialized
INFO - 2016-10-03 17:00:46 --> Helper loaded: form_helper
INFO - 2016-10-03 17:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:00:46 --> Final output sent to browser
DEBUG - 2016-10-03 17:00:46 --> Total execution time: 0.0825
INFO - 2016-10-03 17:05:30 --> Config Class Initialized
INFO - 2016-10-03 17:05:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:05:30 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:05:30 --> Utf8 Class Initialized
INFO - 2016-10-03 17:05:30 --> URI Class Initialized
INFO - 2016-10-03 17:05:30 --> Router Class Initialized
INFO - 2016-10-03 17:05:30 --> Output Class Initialized
INFO - 2016-10-03 17:05:30 --> Security Class Initialized
DEBUG - 2016-10-03 17:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:05:30 --> Input Class Initialized
INFO - 2016-10-03 17:05:30 --> Language Class Initialized
INFO - 2016-10-03 17:05:30 --> Loader Class Initialized
INFO - 2016-10-03 17:05:30 --> Helper loaded: url_helper
INFO - 2016-10-03 17:05:30 --> Helper loaded: language_helper
INFO - 2016-10-03 17:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:05:30 --> Controller Class Initialized
INFO - 2016-10-03 17:05:30 --> Database Driver Class Initialized
INFO - 2016-10-03 17:05:30 --> Model Class Initialized
INFO - 2016-10-03 17:05:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:05:30 --> Model Class Initialized
INFO - 2016-10-03 17:05:30 --> Model Class Initialized
INFO - 2016-10-03 17:05:30 --> Helper loaded: form_helper
INFO - 2016-10-03 17:05:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:05:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:05:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:05:30 --> Final output sent to browser
DEBUG - 2016-10-03 17:05:30 --> Total execution time: 0.1027
INFO - 2016-10-03 17:10:56 --> Config Class Initialized
INFO - 2016-10-03 17:10:56 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:10:56 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:10:56 --> Utf8 Class Initialized
INFO - 2016-10-03 17:10:56 --> URI Class Initialized
INFO - 2016-10-03 17:10:56 --> Router Class Initialized
INFO - 2016-10-03 17:10:56 --> Output Class Initialized
INFO - 2016-10-03 17:10:56 --> Security Class Initialized
DEBUG - 2016-10-03 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:10:56 --> Input Class Initialized
INFO - 2016-10-03 17:10:56 --> Language Class Initialized
INFO - 2016-10-03 17:10:56 --> Loader Class Initialized
INFO - 2016-10-03 17:10:56 --> Helper loaded: url_helper
INFO - 2016-10-03 17:10:56 --> Helper loaded: language_helper
INFO - 2016-10-03 17:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:10:56 --> Controller Class Initialized
INFO - 2016-10-03 17:10:56 --> Database Driver Class Initialized
INFO - 2016-10-03 17:10:56 --> Model Class Initialized
INFO - 2016-10-03 17:10:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:10:56 --> Model Class Initialized
INFO - 2016-10-03 17:10:56 --> Model Class Initialized
INFO - 2016-10-03 17:10:56 --> Helper loaded: form_helper
INFO - 2016-10-03 17:10:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:10:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:10:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:10:56 --> Final output sent to browser
DEBUG - 2016-10-03 17:10:56 --> Total execution time: 0.0971
INFO - 2016-10-03 17:11:22 --> Config Class Initialized
INFO - 2016-10-03 17:11:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:11:22 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:11:22 --> Utf8 Class Initialized
INFO - 2016-10-03 17:11:22 --> URI Class Initialized
INFO - 2016-10-03 17:11:22 --> Router Class Initialized
INFO - 2016-10-03 17:11:22 --> Output Class Initialized
INFO - 2016-10-03 17:11:22 --> Security Class Initialized
DEBUG - 2016-10-03 17:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:11:22 --> Input Class Initialized
INFO - 2016-10-03 17:11:22 --> Language Class Initialized
INFO - 2016-10-03 17:11:22 --> Loader Class Initialized
INFO - 2016-10-03 17:11:22 --> Helper loaded: url_helper
INFO - 2016-10-03 17:11:22 --> Helper loaded: language_helper
INFO - 2016-10-03 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:11:22 --> Controller Class Initialized
INFO - 2016-10-03 17:11:22 --> Database Driver Class Initialized
INFO - 2016-10-03 17:11:22 --> Model Class Initialized
INFO - 2016-10-03 17:11:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:11:22 --> Model Class Initialized
INFO - 2016-10-03 17:11:22 --> Model Class Initialized
INFO - 2016-10-03 17:11:22 --> Helper loaded: form_helper
INFO - 2016-10-03 17:11:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:11:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:11:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:11:22 --> Final output sent to browser
DEBUG - 2016-10-03 17:11:22 --> Total execution time: 0.0946
INFO - 2016-10-03 17:12:28 --> Config Class Initialized
INFO - 2016-10-03 17:12:28 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:12:28 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:12:28 --> Utf8 Class Initialized
INFO - 2016-10-03 17:12:28 --> URI Class Initialized
INFO - 2016-10-03 17:12:28 --> Router Class Initialized
INFO - 2016-10-03 17:12:28 --> Output Class Initialized
INFO - 2016-10-03 17:12:28 --> Security Class Initialized
DEBUG - 2016-10-03 17:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:12:28 --> Input Class Initialized
INFO - 2016-10-03 17:12:28 --> Language Class Initialized
INFO - 2016-10-03 17:12:28 --> Loader Class Initialized
INFO - 2016-10-03 17:12:28 --> Helper loaded: url_helper
INFO - 2016-10-03 17:12:28 --> Helper loaded: language_helper
INFO - 2016-10-03 17:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:12:28 --> Controller Class Initialized
INFO - 2016-10-03 17:12:28 --> Database Driver Class Initialized
INFO - 2016-10-03 17:12:28 --> Model Class Initialized
INFO - 2016-10-03 17:12:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:12:28 --> Model Class Initialized
INFO - 2016-10-03 17:12:28 --> Model Class Initialized
INFO - 2016-10-03 17:12:28 --> Helper loaded: form_helper
INFO - 2016-10-03 17:12:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:12:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:12:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:12:28 --> Final output sent to browser
DEBUG - 2016-10-03 17:12:28 --> Total execution time: 0.0933
INFO - 2016-10-03 17:13:03 --> Config Class Initialized
INFO - 2016-10-03 17:13:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:13:03 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:13:03 --> Utf8 Class Initialized
INFO - 2016-10-03 17:13:03 --> URI Class Initialized
INFO - 2016-10-03 17:13:03 --> Router Class Initialized
INFO - 2016-10-03 17:13:03 --> Output Class Initialized
INFO - 2016-10-03 17:13:03 --> Security Class Initialized
DEBUG - 2016-10-03 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:13:03 --> Input Class Initialized
INFO - 2016-10-03 17:13:03 --> Language Class Initialized
INFO - 2016-10-03 17:13:03 --> Loader Class Initialized
INFO - 2016-10-03 17:13:03 --> Helper loaded: url_helper
INFO - 2016-10-03 17:13:03 --> Helper loaded: language_helper
INFO - 2016-10-03 17:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:13:03 --> Controller Class Initialized
INFO - 2016-10-03 17:13:03 --> Database Driver Class Initialized
INFO - 2016-10-03 17:13:03 --> Model Class Initialized
INFO - 2016-10-03 17:13:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:13:03 --> Model Class Initialized
INFO - 2016-10-03 17:13:03 --> Model Class Initialized
INFO - 2016-10-03 17:13:03 --> Helper loaded: form_helper
INFO - 2016-10-03 17:13:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:13:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:13:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:13:03 --> Final output sent to browser
DEBUG - 2016-10-03 17:13:03 --> Total execution time: 0.0795
INFO - 2016-10-03 17:13:37 --> Config Class Initialized
INFO - 2016-10-03 17:13:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:13:37 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:13:37 --> Utf8 Class Initialized
INFO - 2016-10-03 17:13:37 --> URI Class Initialized
INFO - 2016-10-03 17:13:37 --> Router Class Initialized
INFO - 2016-10-03 17:13:37 --> Output Class Initialized
INFO - 2016-10-03 17:13:37 --> Security Class Initialized
DEBUG - 2016-10-03 17:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:13:37 --> Input Class Initialized
INFO - 2016-10-03 17:13:37 --> Language Class Initialized
INFO - 2016-10-03 17:13:37 --> Loader Class Initialized
INFO - 2016-10-03 17:13:37 --> Helper loaded: url_helper
INFO - 2016-10-03 17:13:37 --> Helper loaded: language_helper
INFO - 2016-10-03 17:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:13:37 --> Controller Class Initialized
INFO - 2016-10-03 17:13:37 --> Database Driver Class Initialized
INFO - 2016-10-03 17:13:37 --> Model Class Initialized
INFO - 2016-10-03 17:13:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:13:37 --> Model Class Initialized
INFO - 2016-10-03 17:13:37 --> Model Class Initialized
INFO - 2016-10-03 17:13:37 --> Helper loaded: form_helper
INFO - 2016-10-03 17:13:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:13:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:13:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:13:37 --> Final output sent to browser
DEBUG - 2016-10-03 17:13:37 --> Total execution time: 0.0813
INFO - 2016-10-03 17:18:56 --> Config Class Initialized
INFO - 2016-10-03 17:18:56 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:18:56 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:18:56 --> Utf8 Class Initialized
INFO - 2016-10-03 17:18:56 --> URI Class Initialized
INFO - 2016-10-03 17:18:56 --> Router Class Initialized
INFO - 2016-10-03 17:18:56 --> Output Class Initialized
INFO - 2016-10-03 17:18:56 --> Security Class Initialized
DEBUG - 2016-10-03 17:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:18:56 --> Input Class Initialized
INFO - 2016-10-03 17:18:56 --> Language Class Initialized
INFO - 2016-10-03 17:18:56 --> Loader Class Initialized
INFO - 2016-10-03 17:18:56 --> Helper loaded: url_helper
INFO - 2016-10-03 17:18:56 --> Helper loaded: language_helper
INFO - 2016-10-03 17:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:18:56 --> Controller Class Initialized
INFO - 2016-10-03 17:18:56 --> Database Driver Class Initialized
INFO - 2016-10-03 17:18:56 --> Model Class Initialized
INFO - 2016-10-03 17:18:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:18:56 --> Model Class Initialized
INFO - 2016-10-03 17:18:56 --> Model Class Initialized
INFO - 2016-10-03 17:18:56 --> Helper loaded: form_helper
INFO - 2016-10-03 17:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:18:56 --> Final output sent to browser
DEBUG - 2016-10-03 17:18:56 --> Total execution time: 0.0806
INFO - 2016-10-03 17:20:01 --> Config Class Initialized
INFO - 2016-10-03 17:20:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:20:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:20:01 --> Utf8 Class Initialized
INFO - 2016-10-03 17:20:01 --> URI Class Initialized
INFO - 2016-10-03 17:20:01 --> Router Class Initialized
INFO - 2016-10-03 17:20:01 --> Output Class Initialized
INFO - 2016-10-03 17:20:01 --> Security Class Initialized
DEBUG - 2016-10-03 17:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:20:01 --> Input Class Initialized
INFO - 2016-10-03 17:20:01 --> Language Class Initialized
INFO - 2016-10-03 17:20:01 --> Loader Class Initialized
INFO - 2016-10-03 17:20:01 --> Helper loaded: url_helper
INFO - 2016-10-03 17:20:01 --> Helper loaded: language_helper
INFO - 2016-10-03 17:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:20:01 --> Controller Class Initialized
INFO - 2016-10-03 17:20:01 --> Database Driver Class Initialized
INFO - 2016-10-03 17:20:01 --> Model Class Initialized
INFO - 2016-10-03 17:20:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:20:01 --> Model Class Initialized
INFO - 2016-10-03 17:20:01 --> Model Class Initialized
INFO - 2016-10-03 17:20:01 --> Helper loaded: form_helper
INFO - 2016-10-03 17:20:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:20:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:20:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:20:01 --> Final output sent to browser
DEBUG - 2016-10-03 17:20:01 --> Total execution time: 0.0809
INFO - 2016-10-03 17:20:35 --> Config Class Initialized
INFO - 2016-10-03 17:20:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:20:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:20:35 --> Utf8 Class Initialized
INFO - 2016-10-03 17:20:35 --> URI Class Initialized
INFO - 2016-10-03 17:20:35 --> Router Class Initialized
INFO - 2016-10-03 17:20:35 --> Output Class Initialized
INFO - 2016-10-03 17:20:35 --> Security Class Initialized
DEBUG - 2016-10-03 17:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:20:35 --> Input Class Initialized
INFO - 2016-10-03 17:20:35 --> Language Class Initialized
INFO - 2016-10-03 17:20:35 --> Loader Class Initialized
INFO - 2016-10-03 17:20:35 --> Helper loaded: url_helper
INFO - 2016-10-03 17:20:35 --> Helper loaded: language_helper
INFO - 2016-10-03 17:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:20:35 --> Controller Class Initialized
INFO - 2016-10-03 17:20:35 --> Database Driver Class Initialized
INFO - 2016-10-03 17:20:35 --> Model Class Initialized
INFO - 2016-10-03 17:20:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:20:35 --> Model Class Initialized
INFO - 2016-10-03 17:20:35 --> Model Class Initialized
INFO - 2016-10-03 17:20:35 --> Helper loaded: form_helper
INFO - 2016-10-03 17:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:20:35 --> Final output sent to browser
DEBUG - 2016-10-03 17:20:35 --> Total execution time: 0.1118
INFO - 2016-10-03 17:20:44 --> Config Class Initialized
INFO - 2016-10-03 17:20:44 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:20:44 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:20:44 --> Utf8 Class Initialized
INFO - 2016-10-03 17:20:44 --> URI Class Initialized
INFO - 2016-10-03 17:20:44 --> Router Class Initialized
INFO - 2016-10-03 17:20:44 --> Output Class Initialized
INFO - 2016-10-03 17:20:44 --> Security Class Initialized
DEBUG - 2016-10-03 17:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:20:44 --> Input Class Initialized
INFO - 2016-10-03 17:20:44 --> Language Class Initialized
INFO - 2016-10-03 17:20:44 --> Loader Class Initialized
INFO - 2016-10-03 17:20:44 --> Helper loaded: url_helper
INFO - 2016-10-03 17:20:44 --> Helper loaded: language_helper
INFO - 2016-10-03 17:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:20:44 --> Controller Class Initialized
INFO - 2016-10-03 17:20:44 --> Database Driver Class Initialized
INFO - 2016-10-03 17:20:44 --> Model Class Initialized
INFO - 2016-10-03 17:20:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:20:44 --> Model Class Initialized
INFO - 2016-10-03 17:20:44 --> Model Class Initialized
INFO - 2016-10-03 17:20:44 --> Helper loaded: form_helper
INFO - 2016-10-03 17:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:20:44 --> Final output sent to browser
DEBUG - 2016-10-03 17:20:44 --> Total execution time: 0.1067
INFO - 2016-10-03 17:23:23 --> Config Class Initialized
INFO - 2016-10-03 17:23:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:23:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:23:23 --> Utf8 Class Initialized
INFO - 2016-10-03 17:23:23 --> URI Class Initialized
INFO - 2016-10-03 17:23:23 --> Router Class Initialized
INFO - 2016-10-03 17:23:23 --> Output Class Initialized
INFO - 2016-10-03 17:23:23 --> Security Class Initialized
DEBUG - 2016-10-03 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:23:23 --> Input Class Initialized
INFO - 2016-10-03 17:23:23 --> Language Class Initialized
INFO - 2016-10-03 17:23:23 --> Loader Class Initialized
INFO - 2016-10-03 17:23:23 --> Helper loaded: url_helper
INFO - 2016-10-03 17:23:23 --> Helper loaded: language_helper
INFO - 2016-10-03 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:23:23 --> Controller Class Initialized
INFO - 2016-10-03 17:23:23 --> Database Driver Class Initialized
INFO - 2016-10-03 17:23:23 --> Model Class Initialized
INFO - 2016-10-03 17:23:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:23:24 --> Model Class Initialized
INFO - 2016-10-03 17:23:24 --> Model Class Initialized
INFO - 2016-10-03 17:23:24 --> Helper loaded: form_helper
INFO - 2016-10-03 17:23:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:23:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:23:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:23:24 --> Final output sent to browser
DEBUG - 2016-10-03 17:23:24 --> Total execution time: 0.0899
INFO - 2016-10-03 17:26:51 --> Config Class Initialized
INFO - 2016-10-03 17:26:51 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:26:51 --> UTF-8 Support Enabled
INFO - 2016-10-03 17:26:51 --> Utf8 Class Initialized
INFO - 2016-10-03 17:26:51 --> URI Class Initialized
INFO - 2016-10-03 17:26:51 --> Router Class Initialized
INFO - 2016-10-03 17:26:51 --> Output Class Initialized
INFO - 2016-10-03 17:26:51 --> Security Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 17:26:51 --> Input Class Initialized
INFO - 2016-10-03 17:26:51 --> Language Class Initialized
INFO - 2016-10-03 17:26:51 --> Loader Class Initialized
INFO - 2016-10-03 17:26:51 --> Helper loaded: url_helper
INFO - 2016-10-03 17:26:51 --> Helper loaded: language_helper
INFO - 2016-10-03 17:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 17:26:51 --> Controller Class Initialized
INFO - 2016-10-03 17:26:51 --> Database Driver Class Initialized
INFO - 2016-10-03 17:26:51 --> Model Class Initialized
INFO - 2016-10-03 17:26:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 17:26:51 --> Model Class Initialized
INFO - 2016-10-03 17:26:51 --> Model Class Initialized
INFO - 2016-10-03 17:26:51 --> Helper loaded: form_helper
INFO - 2016-10-03 17:26:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 17:26:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 17:26:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 17:26:51 --> Final output sent to browser
DEBUG - 2016-10-03 17:26:51 --> Total execution time: 0.0847
INFO - 2016-10-03 18:03:06 --> Config Class Initialized
INFO - 2016-10-03 18:03:06 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:03:06 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:03:06 --> Utf8 Class Initialized
INFO - 2016-10-03 18:03:06 --> URI Class Initialized
INFO - 2016-10-03 18:03:06 --> Router Class Initialized
INFO - 2016-10-03 18:03:06 --> Output Class Initialized
INFO - 2016-10-03 18:03:06 --> Security Class Initialized
DEBUG - 2016-10-03 18:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:03:06 --> Input Class Initialized
INFO - 2016-10-03 18:03:06 --> Language Class Initialized
INFO - 2016-10-03 18:03:06 --> Loader Class Initialized
INFO - 2016-10-03 18:03:06 --> Helper loaded: url_helper
INFO - 2016-10-03 18:03:06 --> Helper loaded: language_helper
INFO - 2016-10-03 18:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:03:06 --> Controller Class Initialized
INFO - 2016-10-03 18:03:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:03:06 --> Model Class Initialized
INFO - 2016-10-03 18:03:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:03:06 --> Model Class Initialized
INFO - 2016-10-03 18:03:06 --> Model Class Initialized
INFO - 2016-10-03 18:03:06 --> Helper loaded: form_helper
ERROR - 2016-10-03 18:03:06 --> Severity: Notice --> Undefined variable: kd C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 18:03:06 --> Severity: Notice --> Undefined variable: vd C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 182
ERROR - 2016-10-03 18:03:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by scale desc' at line 1 - Invalid query: SELECT scale FROM most_scale where value_=  order by scale desc
INFO - 2016-10-03 18:03:06 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-10-03 18:03:33 --> Config Class Initialized
INFO - 2016-10-03 18:03:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:03:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:03:33 --> Utf8 Class Initialized
INFO - 2016-10-03 18:03:33 --> URI Class Initialized
INFO - 2016-10-03 18:03:33 --> Router Class Initialized
INFO - 2016-10-03 18:03:33 --> Output Class Initialized
INFO - 2016-10-03 18:03:33 --> Security Class Initialized
DEBUG - 2016-10-03 18:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:03:33 --> Input Class Initialized
INFO - 2016-10-03 18:03:33 --> Language Class Initialized
INFO - 2016-10-03 18:03:33 --> Loader Class Initialized
INFO - 2016-10-03 18:03:33 --> Helper loaded: url_helper
INFO - 2016-10-03 18:03:33 --> Helper loaded: language_helper
INFO - 2016-10-03 18:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:03:33 --> Controller Class Initialized
INFO - 2016-10-03 18:03:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:03:33 --> Model Class Initialized
INFO - 2016-10-03 18:03:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:03:33 --> Model Class Initialized
INFO - 2016-10-03 18:03:33 --> Model Class Initialized
INFO - 2016-10-03 18:03:33 --> Helper loaded: form_helper
ERROR - 2016-10-03 18:03:33 --> Severity: Notice --> Undefined variable: rc C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 18:03:33 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 18:03:33 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
ERROR - 2016-10-03 18:03:33 --> Severity: Notice --> Undefined offset: 3 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 183
INFO - 2016-10-03 18:03:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:03:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:03:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:03:33 --> Final output sent to browser
DEBUG - 2016-10-03 18:03:33 --> Total execution time: 0.0852
INFO - 2016-10-03 18:04:24 --> Config Class Initialized
INFO - 2016-10-03 18:04:24 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:04:24 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:04:24 --> Utf8 Class Initialized
INFO - 2016-10-03 18:04:24 --> URI Class Initialized
INFO - 2016-10-03 18:04:24 --> Router Class Initialized
INFO - 2016-10-03 18:04:24 --> Output Class Initialized
INFO - 2016-10-03 18:04:24 --> Security Class Initialized
DEBUG - 2016-10-03 18:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:04:24 --> Input Class Initialized
INFO - 2016-10-03 18:04:24 --> Language Class Initialized
INFO - 2016-10-03 18:04:24 --> Loader Class Initialized
INFO - 2016-10-03 18:04:24 --> Helper loaded: url_helper
INFO - 2016-10-03 18:04:24 --> Helper loaded: language_helper
INFO - 2016-10-03 18:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:04:24 --> Controller Class Initialized
INFO - 2016-10-03 18:04:24 --> Database Driver Class Initialized
INFO - 2016-10-03 18:04:24 --> Model Class Initialized
INFO - 2016-10-03 18:04:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:04:24 --> Model Class Initialized
INFO - 2016-10-03 18:04:24 --> Model Class Initialized
INFO - 2016-10-03 18:04:24 --> Helper loaded: form_helper
INFO - 2016-10-03 18:04:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:04:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:04:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:04:24 --> Final output sent to browser
DEBUG - 2016-10-03 18:04:24 --> Total execution time: 0.0985
INFO - 2016-10-03 18:04:47 --> Config Class Initialized
INFO - 2016-10-03 18:04:47 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:04:47 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:04:47 --> Utf8 Class Initialized
INFO - 2016-10-03 18:04:47 --> URI Class Initialized
INFO - 2016-10-03 18:04:47 --> Router Class Initialized
INFO - 2016-10-03 18:04:47 --> Output Class Initialized
INFO - 2016-10-03 18:04:47 --> Security Class Initialized
DEBUG - 2016-10-03 18:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:04:47 --> Input Class Initialized
INFO - 2016-10-03 18:04:47 --> Language Class Initialized
INFO - 2016-10-03 18:04:47 --> Loader Class Initialized
INFO - 2016-10-03 18:04:47 --> Helper loaded: url_helper
INFO - 2016-10-03 18:04:47 --> Helper loaded: language_helper
INFO - 2016-10-03 18:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:04:47 --> Controller Class Initialized
INFO - 2016-10-03 18:04:47 --> Database Driver Class Initialized
INFO - 2016-10-03 18:04:47 --> Model Class Initialized
INFO - 2016-10-03 18:04:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:04:47 --> Model Class Initialized
INFO - 2016-10-03 18:04:47 --> Model Class Initialized
INFO - 2016-10-03 18:04:47 --> Helper loaded: form_helper
INFO - 2016-10-03 18:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:04:47 --> Final output sent to browser
DEBUG - 2016-10-03 18:04:47 --> Total execution time: 0.0808
INFO - 2016-10-03 18:14:49 --> Config Class Initialized
INFO - 2016-10-03 18:14:49 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:14:49 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:14:49 --> Utf8 Class Initialized
INFO - 2016-10-03 18:14:49 --> URI Class Initialized
INFO - 2016-10-03 18:14:49 --> Router Class Initialized
INFO - 2016-10-03 18:14:49 --> Output Class Initialized
INFO - 2016-10-03 18:14:49 --> Security Class Initialized
DEBUG - 2016-10-03 18:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:14:49 --> Input Class Initialized
INFO - 2016-10-03 18:14:49 --> Language Class Initialized
INFO - 2016-10-03 18:14:49 --> Loader Class Initialized
INFO - 2016-10-03 18:14:49 --> Helper loaded: url_helper
INFO - 2016-10-03 18:14:49 --> Helper loaded: language_helper
INFO - 2016-10-03 18:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:14:49 --> Controller Class Initialized
INFO - 2016-10-03 18:14:49 --> Database Driver Class Initialized
INFO - 2016-10-03 18:14:49 --> Model Class Initialized
INFO - 2016-10-03 18:14:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:14:49 --> Model Class Initialized
INFO - 2016-10-03 18:14:49 --> Model Class Initialized
INFO - 2016-10-03 18:14:49 --> Helper loaded: form_helper
INFO - 2016-10-03 18:14:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:14:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:14:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:14:49 --> Final output sent to browser
DEBUG - 2016-10-03 18:14:49 --> Total execution time: 0.0848
INFO - 2016-10-03 18:15:53 --> Config Class Initialized
INFO - 2016-10-03 18:15:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:15:53 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:15:53 --> Utf8 Class Initialized
INFO - 2016-10-03 18:15:53 --> URI Class Initialized
INFO - 2016-10-03 18:15:53 --> Router Class Initialized
INFO - 2016-10-03 18:15:53 --> Output Class Initialized
INFO - 2016-10-03 18:15:53 --> Security Class Initialized
DEBUG - 2016-10-03 18:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:15:53 --> Input Class Initialized
INFO - 2016-10-03 18:15:53 --> Language Class Initialized
INFO - 2016-10-03 18:15:53 --> Loader Class Initialized
INFO - 2016-10-03 18:15:53 --> Helper loaded: url_helper
INFO - 2016-10-03 18:15:53 --> Helper loaded: language_helper
INFO - 2016-10-03 18:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:15:53 --> Controller Class Initialized
INFO - 2016-10-03 18:15:53 --> Database Driver Class Initialized
INFO - 2016-10-03 18:15:53 --> Model Class Initialized
INFO - 2016-10-03 18:15:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:15:53 --> Model Class Initialized
INFO - 2016-10-03 18:15:53 --> Model Class Initialized
INFO - 2016-10-03 18:15:53 --> Helper loaded: form_helper
INFO - 2016-10-03 18:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:15:53 --> Final output sent to browser
DEBUG - 2016-10-03 18:15:53 --> Total execution time: 0.0839
INFO - 2016-10-03 18:16:26 --> Config Class Initialized
INFO - 2016-10-03 18:16:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:16:26 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:16:26 --> Utf8 Class Initialized
INFO - 2016-10-03 18:16:26 --> URI Class Initialized
INFO - 2016-10-03 18:16:26 --> Router Class Initialized
INFO - 2016-10-03 18:16:26 --> Output Class Initialized
INFO - 2016-10-03 18:16:26 --> Security Class Initialized
DEBUG - 2016-10-03 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:16:26 --> Input Class Initialized
INFO - 2016-10-03 18:16:26 --> Language Class Initialized
INFO - 2016-10-03 18:16:26 --> Loader Class Initialized
INFO - 2016-10-03 18:16:26 --> Helper loaded: url_helper
INFO - 2016-10-03 18:16:26 --> Helper loaded: language_helper
INFO - 2016-10-03 18:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:16:26 --> Controller Class Initialized
INFO - 2016-10-03 18:16:26 --> Database Driver Class Initialized
INFO - 2016-10-03 18:16:26 --> Model Class Initialized
INFO - 2016-10-03 18:16:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:16:26 --> Model Class Initialized
INFO - 2016-10-03 18:16:26 --> Model Class Initialized
INFO - 2016-10-03 18:16:26 --> Helper loaded: form_helper
INFO - 2016-10-03 18:16:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:16:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:16:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:16:26 --> Final output sent to browser
DEBUG - 2016-10-03 18:16:26 --> Total execution time: 0.0772
INFO - 2016-10-03 18:17:45 --> Config Class Initialized
INFO - 2016-10-03 18:17:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:17:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:17:45 --> Utf8 Class Initialized
INFO - 2016-10-03 18:17:45 --> URI Class Initialized
INFO - 2016-10-03 18:17:45 --> Router Class Initialized
INFO - 2016-10-03 18:17:45 --> Output Class Initialized
INFO - 2016-10-03 18:17:45 --> Security Class Initialized
DEBUG - 2016-10-03 18:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:17:45 --> Input Class Initialized
INFO - 2016-10-03 18:17:45 --> Language Class Initialized
INFO - 2016-10-03 18:17:45 --> Loader Class Initialized
INFO - 2016-10-03 18:17:45 --> Helper loaded: url_helper
INFO - 2016-10-03 18:17:45 --> Helper loaded: language_helper
INFO - 2016-10-03 18:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:17:45 --> Controller Class Initialized
INFO - 2016-10-03 18:17:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:17:45 --> Model Class Initialized
INFO - 2016-10-03 18:17:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:17:45 --> Model Class Initialized
INFO - 2016-10-03 18:17:45 --> Model Class Initialized
INFO - 2016-10-03 18:17:45 --> Helper loaded: form_helper
INFO - 2016-10-03 18:17:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:17:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:17:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:17:45 --> Final output sent to browser
DEBUG - 2016-10-03 18:17:45 --> Total execution time: 0.0887
INFO - 2016-10-03 18:19:12 --> Config Class Initialized
INFO - 2016-10-03 18:19:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:19:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:19:12 --> Utf8 Class Initialized
INFO - 2016-10-03 18:19:12 --> URI Class Initialized
INFO - 2016-10-03 18:19:12 --> Router Class Initialized
INFO - 2016-10-03 18:19:12 --> Output Class Initialized
INFO - 2016-10-03 18:19:12 --> Security Class Initialized
DEBUG - 2016-10-03 18:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:19:12 --> Input Class Initialized
INFO - 2016-10-03 18:19:12 --> Language Class Initialized
INFO - 2016-10-03 18:19:12 --> Loader Class Initialized
INFO - 2016-10-03 18:19:12 --> Helper loaded: url_helper
INFO - 2016-10-03 18:19:12 --> Helper loaded: language_helper
INFO - 2016-10-03 18:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:19:12 --> Controller Class Initialized
INFO - 2016-10-03 18:19:12 --> Database Driver Class Initialized
INFO - 2016-10-03 18:19:12 --> Model Class Initialized
INFO - 2016-10-03 18:19:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:19:12 --> Model Class Initialized
INFO - 2016-10-03 18:19:12 --> Model Class Initialized
INFO - 2016-10-03 18:19:12 --> Helper loaded: form_helper
INFO - 2016-10-03 18:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:19:12 --> Final output sent to browser
DEBUG - 2016-10-03 18:19:12 --> Total execution time: 0.0872
INFO - 2016-10-03 18:21:32 --> Config Class Initialized
INFO - 2016-10-03 18:21:32 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:21:32 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:21:32 --> Utf8 Class Initialized
INFO - 2016-10-03 18:21:32 --> URI Class Initialized
INFO - 2016-10-03 18:21:32 --> Router Class Initialized
INFO - 2016-10-03 18:21:32 --> Output Class Initialized
INFO - 2016-10-03 18:21:32 --> Security Class Initialized
DEBUG - 2016-10-03 18:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:21:32 --> Input Class Initialized
INFO - 2016-10-03 18:21:32 --> Language Class Initialized
INFO - 2016-10-03 18:21:32 --> Loader Class Initialized
INFO - 2016-10-03 18:21:32 --> Helper loaded: url_helper
INFO - 2016-10-03 18:21:32 --> Helper loaded: language_helper
INFO - 2016-10-03 18:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:21:32 --> Controller Class Initialized
INFO - 2016-10-03 18:21:32 --> Database Driver Class Initialized
INFO - 2016-10-03 18:21:32 --> Model Class Initialized
INFO - 2016-10-03 18:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:21:32 --> Model Class Initialized
INFO - 2016-10-03 18:21:32 --> Model Class Initialized
INFO - 2016-10-03 18:21:32 --> Helper loaded: form_helper
INFO - 2016-10-03 18:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:21:32 --> Final output sent to browser
DEBUG - 2016-10-03 18:21:32 --> Total execution time: 0.0874
INFO - 2016-10-03 18:22:10 --> Config Class Initialized
INFO - 2016-10-03 18:22:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:22:10 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:22:10 --> Utf8 Class Initialized
INFO - 2016-10-03 18:22:10 --> URI Class Initialized
INFO - 2016-10-03 18:22:10 --> Router Class Initialized
INFO - 2016-10-03 18:22:10 --> Output Class Initialized
INFO - 2016-10-03 18:22:10 --> Security Class Initialized
DEBUG - 2016-10-03 18:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:22:10 --> Input Class Initialized
INFO - 2016-10-03 18:22:10 --> Language Class Initialized
INFO - 2016-10-03 18:22:10 --> Loader Class Initialized
INFO - 2016-10-03 18:22:10 --> Helper loaded: url_helper
INFO - 2016-10-03 18:22:10 --> Helper loaded: language_helper
INFO - 2016-10-03 18:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:22:10 --> Controller Class Initialized
INFO - 2016-10-03 18:22:10 --> Database Driver Class Initialized
INFO - 2016-10-03 18:22:10 --> Model Class Initialized
INFO - 2016-10-03 18:22:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:22:10 --> Model Class Initialized
INFO - 2016-10-03 18:22:10 --> Model Class Initialized
INFO - 2016-10-03 18:22:10 --> Helper loaded: form_helper
INFO - 2016-10-03 18:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:22:10 --> Final output sent to browser
DEBUG - 2016-10-03 18:22:10 --> Total execution time: 0.0851
INFO - 2016-10-03 18:23:45 --> Config Class Initialized
INFO - 2016-10-03 18:23:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:23:45 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:23:45 --> Utf8 Class Initialized
INFO - 2016-10-03 18:23:45 --> URI Class Initialized
INFO - 2016-10-03 18:23:45 --> Router Class Initialized
INFO - 2016-10-03 18:23:45 --> Output Class Initialized
INFO - 2016-10-03 18:23:45 --> Security Class Initialized
DEBUG - 2016-10-03 18:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:23:45 --> Input Class Initialized
INFO - 2016-10-03 18:23:45 --> Language Class Initialized
INFO - 2016-10-03 18:23:45 --> Loader Class Initialized
INFO - 2016-10-03 18:23:45 --> Helper loaded: url_helper
INFO - 2016-10-03 18:23:45 --> Helper loaded: language_helper
INFO - 2016-10-03 18:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:23:45 --> Controller Class Initialized
INFO - 2016-10-03 18:23:45 --> Database Driver Class Initialized
INFO - 2016-10-03 18:23:45 --> Model Class Initialized
INFO - 2016-10-03 18:23:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:23:45 --> Model Class Initialized
INFO - 2016-10-03 18:23:45 --> Model Class Initialized
INFO - 2016-10-03 18:23:45 --> Helper loaded: form_helper
INFO - 2016-10-03 18:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:23:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:23:45 --> Final output sent to browser
DEBUG - 2016-10-03 18:23:45 --> Total execution time: 0.0856
INFO - 2016-10-03 18:36:29 --> Config Class Initialized
INFO - 2016-10-03 18:36:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:36:29 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:36:29 --> Utf8 Class Initialized
INFO - 2016-10-03 18:36:29 --> URI Class Initialized
INFO - 2016-10-03 18:36:29 --> Router Class Initialized
INFO - 2016-10-03 18:36:29 --> Output Class Initialized
INFO - 2016-10-03 18:36:29 --> Security Class Initialized
DEBUG - 2016-10-03 18:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:36:29 --> Input Class Initialized
INFO - 2016-10-03 18:36:29 --> Language Class Initialized
INFO - 2016-10-03 18:36:29 --> Loader Class Initialized
INFO - 2016-10-03 18:36:29 --> Helper loaded: url_helper
INFO - 2016-10-03 18:36:29 --> Helper loaded: language_helper
INFO - 2016-10-03 18:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:36:29 --> Controller Class Initialized
INFO - 2016-10-03 18:36:29 --> Database Driver Class Initialized
INFO - 2016-10-03 18:36:29 --> Model Class Initialized
INFO - 2016-10-03 18:36:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:36:29 --> Model Class Initialized
INFO - 2016-10-03 18:36:29 --> Model Class Initialized
INFO - 2016-10-03 18:36:29 --> Helper loaded: form_helper
INFO - 2016-10-03 18:36:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:36:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:36:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:36:29 --> Final output sent to browser
DEBUG - 2016-10-03 18:36:29 --> Total execution time: 0.0954
INFO - 2016-10-03 18:39:06 --> Config Class Initialized
INFO - 2016-10-03 18:39:06 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:39:06 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:39:06 --> Utf8 Class Initialized
INFO - 2016-10-03 18:39:06 --> URI Class Initialized
INFO - 2016-10-03 18:39:06 --> Router Class Initialized
INFO - 2016-10-03 18:39:06 --> Output Class Initialized
INFO - 2016-10-03 18:39:06 --> Security Class Initialized
DEBUG - 2016-10-03 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:39:06 --> Input Class Initialized
INFO - 2016-10-03 18:39:06 --> Language Class Initialized
INFO - 2016-10-03 18:39:06 --> Loader Class Initialized
INFO - 2016-10-03 18:39:06 --> Helper loaded: url_helper
INFO - 2016-10-03 18:39:06 --> Helper loaded: language_helper
INFO - 2016-10-03 18:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:39:06 --> Controller Class Initialized
INFO - 2016-10-03 18:39:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:39:06 --> Model Class Initialized
INFO - 2016-10-03 18:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:39:06 --> Model Class Initialized
INFO - 2016-10-03 18:39:06 --> Model Class Initialized
INFO - 2016-10-03 18:39:06 --> Helper loaded: form_helper
INFO - 2016-10-03 18:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:39:06 --> Final output sent to browser
DEBUG - 2016-10-03 18:39:06 --> Total execution time: 0.0957
INFO - 2016-10-03 18:39:24 --> Config Class Initialized
INFO - 2016-10-03 18:39:24 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:39:24 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:39:24 --> Utf8 Class Initialized
INFO - 2016-10-03 18:39:24 --> URI Class Initialized
INFO - 2016-10-03 18:39:24 --> Router Class Initialized
INFO - 2016-10-03 18:39:24 --> Output Class Initialized
INFO - 2016-10-03 18:39:24 --> Security Class Initialized
DEBUG - 2016-10-03 18:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:39:24 --> Input Class Initialized
INFO - 2016-10-03 18:39:24 --> Language Class Initialized
INFO - 2016-10-03 18:39:24 --> Loader Class Initialized
INFO - 2016-10-03 18:39:24 --> Helper loaded: url_helper
INFO - 2016-10-03 18:39:24 --> Helper loaded: language_helper
INFO - 2016-10-03 18:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:39:24 --> Controller Class Initialized
INFO - 2016-10-03 18:39:24 --> Database Driver Class Initialized
INFO - 2016-10-03 18:39:24 --> Model Class Initialized
INFO - 2016-10-03 18:39:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:39:24 --> Model Class Initialized
INFO - 2016-10-03 18:39:24 --> Model Class Initialized
INFO - 2016-10-03 18:39:24 --> Helper loaded: form_helper
INFO - 2016-10-03 18:39:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:39:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:39:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:39:24 --> Final output sent to browser
DEBUG - 2016-10-03 18:39:24 --> Total execution time: 0.0962
INFO - 2016-10-03 18:40:46 --> Config Class Initialized
INFO - 2016-10-03 18:40:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:40:46 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:40:46 --> Utf8 Class Initialized
INFO - 2016-10-03 18:40:46 --> URI Class Initialized
INFO - 2016-10-03 18:40:46 --> Router Class Initialized
INFO - 2016-10-03 18:40:46 --> Output Class Initialized
INFO - 2016-10-03 18:40:46 --> Security Class Initialized
DEBUG - 2016-10-03 18:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:40:46 --> Input Class Initialized
INFO - 2016-10-03 18:40:46 --> Language Class Initialized
INFO - 2016-10-03 18:40:46 --> Loader Class Initialized
INFO - 2016-10-03 18:40:46 --> Helper loaded: url_helper
INFO - 2016-10-03 18:40:46 --> Helper loaded: language_helper
INFO - 2016-10-03 18:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:40:46 --> Controller Class Initialized
INFO - 2016-10-03 18:40:46 --> Database Driver Class Initialized
INFO - 2016-10-03 18:40:46 --> Model Class Initialized
INFO - 2016-10-03 18:40:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:40:46 --> Model Class Initialized
INFO - 2016-10-03 18:40:46 --> Model Class Initialized
INFO - 2016-10-03 18:40:46 --> Helper loaded: form_helper
INFO - 2016-10-03 18:40:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:40:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:40:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:40:46 --> Final output sent to browser
DEBUG - 2016-10-03 18:40:46 --> Total execution time: 0.0874
INFO - 2016-10-03 18:41:04 --> Config Class Initialized
INFO - 2016-10-03 18:41:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:41:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:41:04 --> Utf8 Class Initialized
INFO - 2016-10-03 18:41:04 --> URI Class Initialized
INFO - 2016-10-03 18:41:04 --> Router Class Initialized
INFO - 2016-10-03 18:41:04 --> Output Class Initialized
INFO - 2016-10-03 18:41:04 --> Security Class Initialized
DEBUG - 2016-10-03 18:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:41:04 --> Input Class Initialized
INFO - 2016-10-03 18:41:04 --> Language Class Initialized
INFO - 2016-10-03 18:41:04 --> Loader Class Initialized
INFO - 2016-10-03 18:41:04 --> Helper loaded: url_helper
INFO - 2016-10-03 18:41:04 --> Helper loaded: language_helper
INFO - 2016-10-03 18:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:41:04 --> Controller Class Initialized
INFO - 2016-10-03 18:41:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:41:04 --> Model Class Initialized
INFO - 2016-10-03 18:41:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:41:04 --> Model Class Initialized
INFO - 2016-10-03 18:41:04 --> Model Class Initialized
INFO - 2016-10-03 18:41:04 --> Helper loaded: form_helper
INFO - 2016-10-03 18:41:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-03 18:41:04 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 317
INFO - 2016-10-03 18:41:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:41:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:41:04 --> Final output sent to browser
DEBUG - 2016-10-03 18:41:04 --> Total execution time: 0.0867
INFO - 2016-10-03 18:42:18 --> Config Class Initialized
INFO - 2016-10-03 18:42:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:42:18 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:42:18 --> Utf8 Class Initialized
INFO - 2016-10-03 18:42:18 --> URI Class Initialized
INFO - 2016-10-03 18:42:18 --> Router Class Initialized
INFO - 2016-10-03 18:42:18 --> Output Class Initialized
INFO - 2016-10-03 18:42:18 --> Security Class Initialized
DEBUG - 2016-10-03 18:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:42:18 --> Input Class Initialized
INFO - 2016-10-03 18:42:18 --> Language Class Initialized
INFO - 2016-10-03 18:42:18 --> Loader Class Initialized
INFO - 2016-10-03 18:42:18 --> Helper loaded: url_helper
INFO - 2016-10-03 18:42:18 --> Helper loaded: language_helper
INFO - 2016-10-03 18:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:42:18 --> Controller Class Initialized
INFO - 2016-10-03 18:42:18 --> Database Driver Class Initialized
INFO - 2016-10-03 18:42:18 --> Model Class Initialized
INFO - 2016-10-03 18:42:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:42:18 --> Model Class Initialized
INFO - 2016-10-03 18:42:18 --> Model Class Initialized
INFO - 2016-10-03 18:42:18 --> Helper loaded: form_helper
INFO - 2016-10-03 18:42:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:42:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:42:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:42:18 --> Final output sent to browser
DEBUG - 2016-10-03 18:42:18 --> Total execution time: 0.1081
INFO - 2016-10-03 18:43:04 --> Config Class Initialized
INFO - 2016-10-03 18:43:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:43:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:43:04 --> Utf8 Class Initialized
INFO - 2016-10-03 18:43:04 --> URI Class Initialized
INFO - 2016-10-03 18:43:04 --> Router Class Initialized
INFO - 2016-10-03 18:43:04 --> Output Class Initialized
INFO - 2016-10-03 18:43:04 --> Security Class Initialized
DEBUG - 2016-10-03 18:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:43:04 --> Input Class Initialized
INFO - 2016-10-03 18:43:04 --> Language Class Initialized
INFO - 2016-10-03 18:43:04 --> Loader Class Initialized
INFO - 2016-10-03 18:43:04 --> Helper loaded: url_helper
INFO - 2016-10-03 18:43:04 --> Helper loaded: language_helper
INFO - 2016-10-03 18:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:43:04 --> Controller Class Initialized
INFO - 2016-10-03 18:43:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:43:04 --> Model Class Initialized
INFO - 2016-10-03 18:43:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:43:04 --> Model Class Initialized
INFO - 2016-10-03 18:43:04 --> Model Class Initialized
INFO - 2016-10-03 18:43:04 --> Helper loaded: form_helper
INFO - 2016-10-03 18:43:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:43:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:43:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:43:04 --> Final output sent to browser
DEBUG - 2016-10-03 18:43:04 --> Total execution time: 0.0903
INFO - 2016-10-03 18:43:36 --> Config Class Initialized
INFO - 2016-10-03 18:43:36 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:43:36 --> Utf8 Class Initialized
INFO - 2016-10-03 18:43:36 --> URI Class Initialized
INFO - 2016-10-03 18:43:36 --> Router Class Initialized
INFO - 2016-10-03 18:43:36 --> Output Class Initialized
INFO - 2016-10-03 18:43:36 --> Security Class Initialized
DEBUG - 2016-10-03 18:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:43:36 --> Input Class Initialized
INFO - 2016-10-03 18:43:36 --> Language Class Initialized
INFO - 2016-10-03 18:43:36 --> Loader Class Initialized
INFO - 2016-10-03 18:43:36 --> Helper loaded: url_helper
INFO - 2016-10-03 18:43:36 --> Helper loaded: language_helper
INFO - 2016-10-03 18:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:43:36 --> Controller Class Initialized
INFO - 2016-10-03 18:43:36 --> Database Driver Class Initialized
INFO - 2016-10-03 18:43:36 --> Model Class Initialized
INFO - 2016-10-03 18:43:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:43:36 --> Model Class Initialized
INFO - 2016-10-03 18:43:36 --> Model Class Initialized
INFO - 2016-10-03 18:43:36 --> Helper loaded: form_helper
INFO - 2016-10-03 18:43:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:43:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:43:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:43:36 --> Final output sent to browser
DEBUG - 2016-10-03 18:43:36 --> Total execution time: 0.0862
INFO - 2016-10-03 18:44:37 --> Config Class Initialized
INFO - 2016-10-03 18:44:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:44:37 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:44:37 --> Utf8 Class Initialized
INFO - 2016-10-03 18:44:37 --> URI Class Initialized
INFO - 2016-10-03 18:44:37 --> Router Class Initialized
INFO - 2016-10-03 18:44:37 --> Output Class Initialized
INFO - 2016-10-03 18:44:37 --> Security Class Initialized
DEBUG - 2016-10-03 18:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:44:37 --> Input Class Initialized
INFO - 2016-10-03 18:44:37 --> Language Class Initialized
INFO - 2016-10-03 18:44:37 --> Loader Class Initialized
INFO - 2016-10-03 18:44:37 --> Helper loaded: url_helper
INFO - 2016-10-03 18:44:37 --> Helper loaded: language_helper
INFO - 2016-10-03 18:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:44:37 --> Controller Class Initialized
INFO - 2016-10-03 18:44:37 --> Database Driver Class Initialized
INFO - 2016-10-03 18:44:37 --> Model Class Initialized
INFO - 2016-10-03 18:44:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:44:37 --> Model Class Initialized
INFO - 2016-10-03 18:44:37 --> Model Class Initialized
INFO - 2016-10-03 18:44:37 --> Helper loaded: form_helper
INFO - 2016-10-03 18:44:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:44:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:44:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:44:37 --> Final output sent to browser
DEBUG - 2016-10-03 18:44:37 --> Total execution time: 0.0848
INFO - 2016-10-03 18:47:23 --> Config Class Initialized
INFO - 2016-10-03 18:47:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:47:23 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:47:23 --> Utf8 Class Initialized
INFO - 2016-10-03 18:47:23 --> URI Class Initialized
INFO - 2016-10-03 18:47:23 --> Router Class Initialized
INFO - 2016-10-03 18:47:23 --> Output Class Initialized
INFO - 2016-10-03 18:47:23 --> Security Class Initialized
DEBUG - 2016-10-03 18:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:47:23 --> Input Class Initialized
INFO - 2016-10-03 18:47:23 --> Language Class Initialized
INFO - 2016-10-03 18:47:23 --> Loader Class Initialized
INFO - 2016-10-03 18:47:23 --> Helper loaded: url_helper
INFO - 2016-10-03 18:47:23 --> Helper loaded: language_helper
INFO - 2016-10-03 18:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:47:23 --> Controller Class Initialized
INFO - 2016-10-03 18:47:23 --> Database Driver Class Initialized
INFO - 2016-10-03 18:47:23 --> Model Class Initialized
INFO - 2016-10-03 18:47:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:47:23 --> Model Class Initialized
INFO - 2016-10-03 18:47:23 --> Model Class Initialized
INFO - 2016-10-03 18:47:23 --> Helper loaded: form_helper
INFO - 2016-10-03 18:47:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:47:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:47:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:47:24 --> Final output sent to browser
DEBUG - 2016-10-03 18:47:24 --> Total execution time: 0.0863
INFO - 2016-10-03 18:47:41 --> Config Class Initialized
INFO - 2016-10-03 18:47:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:47:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:47:41 --> Utf8 Class Initialized
INFO - 2016-10-03 18:47:41 --> URI Class Initialized
INFO - 2016-10-03 18:47:41 --> Router Class Initialized
INFO - 2016-10-03 18:47:41 --> Output Class Initialized
INFO - 2016-10-03 18:47:41 --> Security Class Initialized
DEBUG - 2016-10-03 18:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:47:41 --> Input Class Initialized
INFO - 2016-10-03 18:47:41 --> Language Class Initialized
INFO - 2016-10-03 18:47:41 --> Loader Class Initialized
INFO - 2016-10-03 18:47:41 --> Helper loaded: url_helper
INFO - 2016-10-03 18:47:41 --> Helper loaded: language_helper
INFO - 2016-10-03 18:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:47:42 --> Controller Class Initialized
INFO - 2016-10-03 18:47:42 --> Database Driver Class Initialized
INFO - 2016-10-03 18:47:42 --> Model Class Initialized
INFO - 2016-10-03 18:47:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:47:42 --> Model Class Initialized
INFO - 2016-10-03 18:47:42 --> Model Class Initialized
INFO - 2016-10-03 18:47:42 --> Helper loaded: form_helper
INFO - 2016-10-03 18:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:47:42 --> Final output sent to browser
DEBUG - 2016-10-03 18:47:42 --> Total execution time: 0.0880
INFO - 2016-10-03 18:47:51 --> Config Class Initialized
INFO - 2016-10-03 18:47:51 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:47:51 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:47:51 --> Utf8 Class Initialized
INFO - 2016-10-03 18:47:51 --> URI Class Initialized
INFO - 2016-10-03 18:47:51 --> Router Class Initialized
INFO - 2016-10-03 18:47:51 --> Output Class Initialized
INFO - 2016-10-03 18:47:51 --> Security Class Initialized
DEBUG - 2016-10-03 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:47:51 --> Input Class Initialized
INFO - 2016-10-03 18:47:51 --> Language Class Initialized
INFO - 2016-10-03 18:47:51 --> Loader Class Initialized
INFO - 2016-10-03 18:47:51 --> Helper loaded: url_helper
INFO - 2016-10-03 18:47:51 --> Helper loaded: language_helper
INFO - 2016-10-03 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:47:51 --> Controller Class Initialized
INFO - 2016-10-03 18:47:51 --> Database Driver Class Initialized
INFO - 2016-10-03 18:47:51 --> Model Class Initialized
INFO - 2016-10-03 18:47:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:47:51 --> Model Class Initialized
INFO - 2016-10-03 18:47:51 --> Model Class Initialized
INFO - 2016-10-03 18:47:51 --> Helper loaded: form_helper
INFO - 2016-10-03 18:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:47:51 --> Final output sent to browser
DEBUG - 2016-10-03 18:47:51 --> Total execution time: 0.0813
INFO - 2016-10-03 18:48:20 --> Config Class Initialized
INFO - 2016-10-03 18:48:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:48:20 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:48:20 --> Utf8 Class Initialized
INFO - 2016-10-03 18:48:20 --> URI Class Initialized
INFO - 2016-10-03 18:48:21 --> Router Class Initialized
INFO - 2016-10-03 18:48:21 --> Output Class Initialized
INFO - 2016-10-03 18:48:21 --> Security Class Initialized
DEBUG - 2016-10-03 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:48:21 --> Input Class Initialized
INFO - 2016-10-03 18:48:21 --> Language Class Initialized
INFO - 2016-10-03 18:48:21 --> Loader Class Initialized
INFO - 2016-10-03 18:48:21 --> Helper loaded: url_helper
INFO - 2016-10-03 18:48:21 --> Helper loaded: language_helper
INFO - 2016-10-03 18:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:48:21 --> Controller Class Initialized
INFO - 2016-10-03 18:48:21 --> Database Driver Class Initialized
INFO - 2016-10-03 18:48:21 --> Model Class Initialized
INFO - 2016-10-03 18:48:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:48:21 --> Model Class Initialized
INFO - 2016-10-03 18:48:21 --> Model Class Initialized
INFO - 2016-10-03 18:48:21 --> Helper loaded: form_helper
INFO - 2016-10-03 18:48:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:48:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:48:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:48:21 --> Final output sent to browser
DEBUG - 2016-10-03 18:48:21 --> Total execution time: 0.0827
INFO - 2016-10-03 18:49:02 --> Config Class Initialized
INFO - 2016-10-03 18:49:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:49:02 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:49:02 --> Utf8 Class Initialized
INFO - 2016-10-03 18:49:02 --> URI Class Initialized
INFO - 2016-10-03 18:49:02 --> Router Class Initialized
INFO - 2016-10-03 18:49:02 --> Output Class Initialized
INFO - 2016-10-03 18:49:02 --> Security Class Initialized
DEBUG - 2016-10-03 18:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:49:02 --> Input Class Initialized
INFO - 2016-10-03 18:49:02 --> Language Class Initialized
INFO - 2016-10-03 18:49:02 --> Loader Class Initialized
INFO - 2016-10-03 18:49:02 --> Helper loaded: url_helper
INFO - 2016-10-03 18:49:02 --> Helper loaded: language_helper
INFO - 2016-10-03 18:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:49:02 --> Controller Class Initialized
INFO - 2016-10-03 18:49:02 --> Database Driver Class Initialized
INFO - 2016-10-03 18:49:02 --> Model Class Initialized
INFO - 2016-10-03 18:49:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:49:02 --> Model Class Initialized
INFO - 2016-10-03 18:49:02 --> Model Class Initialized
INFO - 2016-10-03 18:49:02 --> Helper loaded: form_helper
INFO - 2016-10-03 18:49:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:49:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:49:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:49:03 --> Final output sent to browser
DEBUG - 2016-10-03 18:49:03 --> Total execution time: 0.0855
INFO - 2016-10-03 18:51:04 --> Config Class Initialized
INFO - 2016-10-03 18:51:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:51:04 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:51:04 --> Utf8 Class Initialized
INFO - 2016-10-03 18:51:04 --> URI Class Initialized
INFO - 2016-10-03 18:51:04 --> Router Class Initialized
INFO - 2016-10-03 18:51:04 --> Output Class Initialized
INFO - 2016-10-03 18:51:04 --> Security Class Initialized
DEBUG - 2016-10-03 18:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:51:04 --> Input Class Initialized
INFO - 2016-10-03 18:51:04 --> Language Class Initialized
INFO - 2016-10-03 18:51:04 --> Loader Class Initialized
INFO - 2016-10-03 18:51:04 --> Helper loaded: url_helper
INFO - 2016-10-03 18:51:04 --> Helper loaded: language_helper
INFO - 2016-10-03 18:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:51:04 --> Controller Class Initialized
INFO - 2016-10-03 18:51:04 --> Database Driver Class Initialized
INFO - 2016-10-03 18:51:04 --> Model Class Initialized
INFO - 2016-10-03 18:51:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:51:04 --> Model Class Initialized
INFO - 2016-10-03 18:51:04 --> Model Class Initialized
INFO - 2016-10-03 18:51:04 --> Helper loaded: form_helper
INFO - 2016-10-03 18:51:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:51:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:51:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:51:04 --> Final output sent to browser
DEBUG - 2016-10-03 18:51:04 --> Total execution time: 0.0830
INFO - 2016-10-03 18:51:06 --> Config Class Initialized
INFO - 2016-10-03 18:51:06 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:51:06 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:51:06 --> Utf8 Class Initialized
INFO - 2016-10-03 18:51:06 --> URI Class Initialized
INFO - 2016-10-03 18:51:06 --> Router Class Initialized
INFO - 2016-10-03 18:51:06 --> Output Class Initialized
INFO - 2016-10-03 18:51:06 --> Security Class Initialized
DEBUG - 2016-10-03 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:51:06 --> Input Class Initialized
INFO - 2016-10-03 18:51:06 --> Language Class Initialized
INFO - 2016-10-03 18:51:06 --> Loader Class Initialized
INFO - 2016-10-03 18:51:06 --> Helper loaded: url_helper
INFO - 2016-10-03 18:51:06 --> Helper loaded: language_helper
INFO - 2016-10-03 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:51:06 --> Controller Class Initialized
INFO - 2016-10-03 18:51:06 --> Database Driver Class Initialized
INFO - 2016-10-03 18:51:06 --> Model Class Initialized
INFO - 2016-10-03 18:51:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:51:06 --> Model Class Initialized
INFO - 2016-10-03 18:51:06 --> Model Class Initialized
INFO - 2016-10-03 18:51:06 --> Helper loaded: form_helper
INFO - 2016-10-03 18:51:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:51:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:51:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:51:06 --> Final output sent to browser
DEBUG - 2016-10-03 18:51:06 --> Total execution time: 0.1132
INFO - 2016-10-03 18:51:33 --> Config Class Initialized
INFO - 2016-10-03 18:51:33 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:51:33 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:51:33 --> Utf8 Class Initialized
INFO - 2016-10-03 18:51:33 --> URI Class Initialized
INFO - 2016-10-03 18:51:33 --> Router Class Initialized
INFO - 2016-10-03 18:51:33 --> Output Class Initialized
INFO - 2016-10-03 18:51:33 --> Security Class Initialized
DEBUG - 2016-10-03 18:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:51:33 --> Input Class Initialized
INFO - 2016-10-03 18:51:33 --> Language Class Initialized
INFO - 2016-10-03 18:51:33 --> Loader Class Initialized
INFO - 2016-10-03 18:51:33 --> Helper loaded: url_helper
INFO - 2016-10-03 18:51:33 --> Helper loaded: language_helper
INFO - 2016-10-03 18:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:51:33 --> Controller Class Initialized
INFO - 2016-10-03 18:51:33 --> Database Driver Class Initialized
INFO - 2016-10-03 18:51:33 --> Model Class Initialized
INFO - 2016-10-03 18:51:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:51:33 --> Model Class Initialized
INFO - 2016-10-03 18:51:33 --> Model Class Initialized
INFO - 2016-10-03 18:51:33 --> Helper loaded: form_helper
INFO - 2016-10-03 18:51:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:51:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:51:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:51:33 --> Final output sent to browser
DEBUG - 2016-10-03 18:51:33 --> Total execution time: 0.0957
INFO - 2016-10-03 18:51:58 --> Config Class Initialized
INFO - 2016-10-03 18:51:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:51:58 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:51:58 --> Utf8 Class Initialized
INFO - 2016-10-03 18:51:58 --> URI Class Initialized
INFO - 2016-10-03 18:51:58 --> Router Class Initialized
INFO - 2016-10-03 18:51:58 --> Output Class Initialized
INFO - 2016-10-03 18:51:58 --> Security Class Initialized
DEBUG - 2016-10-03 18:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:51:58 --> Input Class Initialized
INFO - 2016-10-03 18:51:58 --> Language Class Initialized
INFO - 2016-10-03 18:51:58 --> Loader Class Initialized
INFO - 2016-10-03 18:51:58 --> Helper loaded: url_helper
INFO - 2016-10-03 18:51:58 --> Helper loaded: language_helper
INFO - 2016-10-03 18:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:51:58 --> Controller Class Initialized
INFO - 2016-10-03 18:51:58 --> Database Driver Class Initialized
INFO - 2016-10-03 18:51:58 --> Model Class Initialized
INFO - 2016-10-03 18:51:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:51:58 --> Model Class Initialized
INFO - 2016-10-03 18:51:58 --> Model Class Initialized
INFO - 2016-10-03 18:51:58 --> Helper loaded: form_helper
INFO - 2016-10-03 18:51:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:51:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:51:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:51:58 --> Final output sent to browser
DEBUG - 2016-10-03 18:51:58 --> Total execution time: 0.0825
INFO - 2016-10-03 18:54:12 --> Config Class Initialized
INFO - 2016-10-03 18:54:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:54:12 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:54:12 --> Utf8 Class Initialized
INFO - 2016-10-03 18:54:12 --> URI Class Initialized
INFO - 2016-10-03 18:54:12 --> Router Class Initialized
INFO - 2016-10-03 18:54:12 --> Output Class Initialized
INFO - 2016-10-03 18:54:12 --> Security Class Initialized
DEBUG - 2016-10-03 18:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:54:12 --> Input Class Initialized
INFO - 2016-10-03 18:54:12 --> Language Class Initialized
INFO - 2016-10-03 18:54:12 --> Loader Class Initialized
INFO - 2016-10-03 18:54:12 --> Helper loaded: url_helper
INFO - 2016-10-03 18:54:12 --> Helper loaded: language_helper
INFO - 2016-10-03 18:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:54:12 --> Controller Class Initialized
INFO - 2016-10-03 18:54:12 --> Database Driver Class Initialized
INFO - 2016-10-03 18:54:12 --> Model Class Initialized
INFO - 2016-10-03 18:54:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:54:12 --> Model Class Initialized
INFO - 2016-10-03 18:54:12 --> Model Class Initialized
INFO - 2016-10-03 18:54:12 --> Helper loaded: form_helper
INFO - 2016-10-03 18:54:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:54:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:54:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:54:12 --> Final output sent to browser
DEBUG - 2016-10-03 18:54:12 --> Total execution time: 0.0855
INFO - 2016-10-03 18:55:37 --> Config Class Initialized
INFO - 2016-10-03 18:55:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:55:37 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:55:37 --> Utf8 Class Initialized
INFO - 2016-10-03 18:55:37 --> URI Class Initialized
INFO - 2016-10-03 18:55:37 --> Router Class Initialized
INFO - 2016-10-03 18:55:37 --> Output Class Initialized
INFO - 2016-10-03 18:55:37 --> Security Class Initialized
DEBUG - 2016-10-03 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:55:37 --> Input Class Initialized
INFO - 2016-10-03 18:55:37 --> Language Class Initialized
INFO - 2016-10-03 18:55:37 --> Loader Class Initialized
INFO - 2016-10-03 18:55:37 --> Helper loaded: url_helper
INFO - 2016-10-03 18:55:37 --> Helper loaded: language_helper
INFO - 2016-10-03 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:55:37 --> Controller Class Initialized
INFO - 2016-10-03 18:55:37 --> Database Driver Class Initialized
INFO - 2016-10-03 18:55:37 --> Model Class Initialized
INFO - 2016-10-03 18:55:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:55:37 --> Model Class Initialized
INFO - 2016-10-03 18:55:37 --> Model Class Initialized
INFO - 2016-10-03 18:55:37 --> Helper loaded: form_helper
ERROR - 2016-10-03 18:55:37 --> Severity: Notice --> Undefined offset: 4 C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 224
INFO - 2016-10-03 18:55:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:55:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:55:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:55:37 --> Final output sent to browser
DEBUG - 2016-10-03 18:55:37 --> Total execution time: 0.0825
INFO - 2016-10-03 18:55:57 --> Config Class Initialized
INFO - 2016-10-03 18:55:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:55:57 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:55:57 --> Utf8 Class Initialized
INFO - 2016-10-03 18:55:57 --> URI Class Initialized
INFO - 2016-10-03 18:55:57 --> Router Class Initialized
INFO - 2016-10-03 18:55:57 --> Output Class Initialized
INFO - 2016-10-03 18:55:57 --> Security Class Initialized
DEBUG - 2016-10-03 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:55:58 --> Input Class Initialized
INFO - 2016-10-03 18:55:58 --> Language Class Initialized
INFO - 2016-10-03 18:55:58 --> Loader Class Initialized
INFO - 2016-10-03 18:55:58 --> Helper loaded: url_helper
INFO - 2016-10-03 18:55:58 --> Helper loaded: language_helper
INFO - 2016-10-03 18:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:55:58 --> Controller Class Initialized
INFO - 2016-10-03 18:55:58 --> Database Driver Class Initialized
INFO - 2016-10-03 18:55:58 --> Model Class Initialized
INFO - 2016-10-03 18:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:55:58 --> Model Class Initialized
INFO - 2016-10-03 18:55:58 --> Model Class Initialized
INFO - 2016-10-03 18:55:58 --> Helper loaded: form_helper
INFO - 2016-10-03 18:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:55:58 --> Final output sent to browser
DEBUG - 2016-10-03 18:55:58 --> Total execution time: 0.0956
INFO - 2016-10-03 18:56:41 --> Config Class Initialized
INFO - 2016-10-03 18:56:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:56:41 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:56:41 --> Utf8 Class Initialized
INFO - 2016-10-03 18:56:41 --> URI Class Initialized
INFO - 2016-10-03 18:56:41 --> Router Class Initialized
INFO - 2016-10-03 18:56:41 --> Output Class Initialized
INFO - 2016-10-03 18:56:41 --> Security Class Initialized
DEBUG - 2016-10-03 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:56:41 --> Input Class Initialized
INFO - 2016-10-03 18:56:41 --> Language Class Initialized
INFO - 2016-10-03 18:56:41 --> Loader Class Initialized
INFO - 2016-10-03 18:56:41 --> Helper loaded: url_helper
INFO - 2016-10-03 18:56:41 --> Helper loaded: language_helper
INFO - 2016-10-03 18:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:56:41 --> Controller Class Initialized
INFO - 2016-10-03 18:56:41 --> Database Driver Class Initialized
INFO - 2016-10-03 18:56:41 --> Model Class Initialized
INFO - 2016-10-03 18:56:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:56:41 --> Model Class Initialized
INFO - 2016-10-03 18:56:41 --> Model Class Initialized
INFO - 2016-10-03 18:56:41 --> Helper loaded: form_helper
INFO - 2016-10-03 18:56:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:56:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:56:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:56:41 --> Final output sent to browser
DEBUG - 2016-10-03 18:56:41 --> Total execution time: 0.0858
INFO - 2016-10-03 18:59:39 --> Config Class Initialized
INFO - 2016-10-03 18:59:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:59:39 --> UTF-8 Support Enabled
INFO - 2016-10-03 18:59:39 --> Utf8 Class Initialized
INFO - 2016-10-03 18:59:39 --> URI Class Initialized
INFO - 2016-10-03 18:59:39 --> Router Class Initialized
INFO - 2016-10-03 18:59:39 --> Output Class Initialized
INFO - 2016-10-03 18:59:39 --> Security Class Initialized
DEBUG - 2016-10-03 18:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 18:59:39 --> Input Class Initialized
INFO - 2016-10-03 18:59:39 --> Language Class Initialized
INFO - 2016-10-03 18:59:39 --> Loader Class Initialized
INFO - 2016-10-03 18:59:39 --> Helper loaded: url_helper
INFO - 2016-10-03 18:59:39 --> Helper loaded: language_helper
INFO - 2016-10-03 18:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 18:59:39 --> Controller Class Initialized
INFO - 2016-10-03 18:59:39 --> Database Driver Class Initialized
INFO - 2016-10-03 18:59:39 --> Model Class Initialized
INFO - 2016-10-03 18:59:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 18:59:39 --> Model Class Initialized
INFO - 2016-10-03 18:59:39 --> Model Class Initialized
INFO - 2016-10-03 18:59:39 --> Helper loaded: form_helper
INFO - 2016-10-03 18:59:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 18:59:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 18:59:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 18:59:39 --> Final output sent to browser
DEBUG - 2016-10-03 18:59:39 --> Total execution time: 0.0902
INFO - 2016-10-03 19:00:35 --> Config Class Initialized
INFO - 2016-10-03 19:00:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 19:00:35 --> UTF-8 Support Enabled
INFO - 2016-10-03 19:00:35 --> Utf8 Class Initialized
INFO - 2016-10-03 19:00:35 --> URI Class Initialized
INFO - 2016-10-03 19:00:35 --> Router Class Initialized
INFO - 2016-10-03 19:00:35 --> Output Class Initialized
INFO - 2016-10-03 19:00:35 --> Security Class Initialized
DEBUG - 2016-10-03 19:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 19:00:35 --> Input Class Initialized
INFO - 2016-10-03 19:00:35 --> Language Class Initialized
INFO - 2016-10-03 19:00:35 --> Loader Class Initialized
INFO - 2016-10-03 19:00:35 --> Helper loaded: url_helper
INFO - 2016-10-03 19:00:35 --> Helper loaded: language_helper
INFO - 2016-10-03 19:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 19:00:35 --> Controller Class Initialized
INFO - 2016-10-03 19:00:35 --> Database Driver Class Initialized
INFO - 2016-10-03 19:00:35 --> Model Class Initialized
INFO - 2016-10-03 19:00:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 19:00:35 --> Model Class Initialized
INFO - 2016-10-03 19:00:35 --> Model Class Initialized
INFO - 2016-10-03 19:00:35 --> Helper loaded: form_helper
INFO - 2016-10-03 19:00:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 19:00:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-03 19:00:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 19:00:35 --> Final output sent to browser
DEBUG - 2016-10-03 19:00:35 --> Total execution time: 0.0872
INFO - 2016-10-03 19:20:01 --> Config Class Initialized
INFO - 2016-10-03 19:20:01 --> Hooks Class Initialized
DEBUG - 2016-10-03 19:20:01 --> UTF-8 Support Enabled
INFO - 2016-10-03 19:20:01 --> Utf8 Class Initialized
INFO - 2016-10-03 19:20:01 --> URI Class Initialized
INFO - 2016-10-03 19:20:01 --> Router Class Initialized
INFO - 2016-10-03 19:20:01 --> Output Class Initialized
INFO - 2016-10-03 19:20:01 --> Security Class Initialized
DEBUG - 2016-10-03 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 19:20:01 --> Input Class Initialized
INFO - 2016-10-03 19:20:01 --> Language Class Initialized
INFO - 2016-10-03 19:20:01 --> Loader Class Initialized
INFO - 2016-10-03 19:20:01 --> Helper loaded: url_helper
INFO - 2016-10-03 19:20:01 --> Helper loaded: language_helper
INFO - 2016-10-03 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 19:20:01 --> Controller Class Initialized
INFO - 2016-10-03 19:20:01 --> Database Driver Class Initialized
INFO - 2016-10-03 19:20:01 --> Model Class Initialized
INFO - 2016-10-03 19:20:01 --> Model Class Initialized
INFO - 2016-10-03 19:20:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 19:20:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 19:20:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-10-03 19:20:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 19:20:01 --> Final output sent to browser
DEBUG - 2016-10-03 19:20:01 --> Total execution time: 0.0846
INFO - 2016-10-03 19:20:03 --> Config Class Initialized
INFO - 2016-10-03 19:20:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 19:20:03 --> UTF-8 Support Enabled
INFO - 2016-10-03 19:20:03 --> Utf8 Class Initialized
INFO - 2016-10-03 19:20:03 --> URI Class Initialized
INFO - 2016-10-03 19:20:03 --> Router Class Initialized
INFO - 2016-10-03 19:20:03 --> Output Class Initialized
INFO - 2016-10-03 19:20:03 --> Security Class Initialized
DEBUG - 2016-10-03 19:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 19:20:03 --> Input Class Initialized
INFO - 2016-10-03 19:20:03 --> Language Class Initialized
INFO - 2016-10-03 19:20:03 --> Loader Class Initialized
INFO - 2016-10-03 19:20:03 --> Helper loaded: url_helper
INFO - 2016-10-03 19:20:03 --> Helper loaded: language_helper
INFO - 2016-10-03 19:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 19:20:03 --> Controller Class Initialized
INFO - 2016-10-03 19:20:03 --> Database Driver Class Initialized
INFO - 2016-10-03 19:20:03 --> Model Class Initialized
INFO - 2016-10-03 19:20:03 --> Model Class Initialized
INFO - 2016-10-03 19:20:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 19:20:03 --> Model Class Initialized
INFO - 2016-10-03 19:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 19:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-03 19:20:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 19:20:03 --> Final output sent to browser
DEBUG - 2016-10-03 19:20:03 --> Total execution time: 0.0796
INFO - 2016-10-03 19:44:11 --> Config Class Initialized
INFO - 2016-10-03 19:44:11 --> Hooks Class Initialized
DEBUG - 2016-10-03 19:44:11 --> UTF-8 Support Enabled
INFO - 2016-10-03 19:44:11 --> Utf8 Class Initialized
INFO - 2016-10-03 19:44:11 --> URI Class Initialized
INFO - 2016-10-03 19:44:11 --> Router Class Initialized
INFO - 2016-10-03 19:44:11 --> Output Class Initialized
INFO - 2016-10-03 19:44:11 --> Security Class Initialized
DEBUG - 2016-10-03 19:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-03 19:44:11 --> Input Class Initialized
INFO - 2016-10-03 19:44:11 --> Language Class Initialized
INFO - 2016-10-03 19:44:11 --> Loader Class Initialized
INFO - 2016-10-03 19:44:11 --> Helper loaded: url_helper
INFO - 2016-10-03 19:44:11 --> Helper loaded: language_helper
INFO - 2016-10-03 19:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-03 19:44:11 --> Controller Class Initialized
INFO - 2016-10-03 19:44:11 --> Database Driver Class Initialized
INFO - 2016-10-03 19:44:11 --> Model Class Initialized
INFO - 2016-10-03 19:44:11 --> Model Class Initialized
INFO - 2016-10-03 19:44:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-03 19:44:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-03 19:44:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-10-03 19:44:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-03 19:44:11 --> Final output sent to browser
DEBUG - 2016-10-03 19:44:11 --> Total execution time: 0.0886
