<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-04 08:41:32 --> Config Class Initialized
INFO - 2016-10-04 08:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:41:32 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:41:32 --> Utf8 Class Initialized
INFO - 2016-10-04 08:41:32 --> URI Class Initialized
INFO - 2016-10-04 08:41:32 --> Router Class Initialized
INFO - 2016-10-04 08:41:32 --> Output Class Initialized
INFO - 2016-10-04 08:41:32 --> Security Class Initialized
DEBUG - 2016-10-04 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:41:32 --> Input Class Initialized
INFO - 2016-10-04 08:41:32 --> Language Class Initialized
INFO - 2016-10-04 08:41:32 --> Loader Class Initialized
INFO - 2016-10-04 08:41:32 --> Helper loaded: url_helper
INFO - 2016-10-04 08:41:32 --> Helper loaded: language_helper
INFO - 2016-10-04 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:41:32 --> Controller Class Initialized
INFO - 2016-10-04 08:41:32 --> Database Driver Class Initialized
INFO - 2016-10-04 08:41:32 --> Model Class Initialized
INFO - 2016-10-04 08:41:32 --> Model Class Initialized
INFO - 2016-10-04 08:41:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:41:32 --> Config Class Initialized
INFO - 2016-10-04 08:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:41:32 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:41:32 --> Utf8 Class Initialized
INFO - 2016-10-04 08:41:32 --> URI Class Initialized
INFO - 2016-10-04 08:41:32 --> Router Class Initialized
INFO - 2016-10-04 08:41:32 --> Output Class Initialized
INFO - 2016-10-04 08:41:32 --> Security Class Initialized
DEBUG - 2016-10-04 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:41:32 --> Input Class Initialized
INFO - 2016-10-04 08:41:32 --> Language Class Initialized
INFO - 2016-10-04 08:41:32 --> Loader Class Initialized
INFO - 2016-10-04 08:41:32 --> Helper loaded: url_helper
INFO - 2016-10-04 08:41:32 --> Helper loaded: language_helper
INFO - 2016-10-04 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:41:32 --> Controller Class Initialized
INFO - 2016-10-04 08:41:32 --> Database Driver Class Initialized
INFO - 2016-10-04 08:41:32 --> Model Class Initialized
INFO - 2016-10-04 08:41:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-04 08:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-04 08:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-04 08:41:32 --> Final output sent to browser
DEBUG - 2016-10-04 08:41:32 --> Total execution time: 0.0618
INFO - 2016-10-04 08:41:36 --> Config Class Initialized
INFO - 2016-10-04 08:41:36 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:41:36 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:41:36 --> Utf8 Class Initialized
INFO - 2016-10-04 08:41:36 --> URI Class Initialized
INFO - 2016-10-04 08:41:36 --> Router Class Initialized
INFO - 2016-10-04 08:41:36 --> Output Class Initialized
INFO - 2016-10-04 08:41:36 --> Security Class Initialized
DEBUG - 2016-10-04 08:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:41:36 --> Input Class Initialized
INFO - 2016-10-04 08:41:36 --> Language Class Initialized
INFO - 2016-10-04 08:41:36 --> Loader Class Initialized
INFO - 2016-10-04 08:41:36 --> Helper loaded: url_helper
INFO - 2016-10-04 08:41:36 --> Helper loaded: language_helper
INFO - 2016-10-04 08:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:41:36 --> Controller Class Initialized
INFO - 2016-10-04 08:41:36 --> Database Driver Class Initialized
INFO - 2016-10-04 08:41:36 --> Model Class Initialized
INFO - 2016-10-04 08:41:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:41:36 --> Config Class Initialized
INFO - 2016-10-04 08:41:36 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:41:36 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:41:36 --> Utf8 Class Initialized
INFO - 2016-10-04 08:41:36 --> URI Class Initialized
INFO - 2016-10-04 08:41:36 --> Router Class Initialized
INFO - 2016-10-04 08:41:36 --> Output Class Initialized
INFO - 2016-10-04 08:41:36 --> Security Class Initialized
DEBUG - 2016-10-04 08:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:41:36 --> Input Class Initialized
INFO - 2016-10-04 08:41:36 --> Language Class Initialized
INFO - 2016-10-04 08:41:36 --> Loader Class Initialized
INFO - 2016-10-04 08:41:36 --> Helper loaded: url_helper
INFO - 2016-10-04 08:41:36 --> Helper loaded: language_helper
INFO - 2016-10-04 08:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:41:36 --> Controller Class Initialized
INFO - 2016-10-04 08:41:36 --> Database Driver Class Initialized
INFO - 2016-10-04 08:41:36 --> Model Class Initialized
INFO - 2016-10-04 08:41:36 --> Model Class Initialized
INFO - 2016-10-04 08:41:36 --> Model Class Initialized
INFO - 2016-10-04 08:41:36 --> Model Class Initialized
INFO - 2016-10-04 08:41:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:41:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:41:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-04 08:41:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:41:36 --> Final output sent to browser
DEBUG - 2016-10-04 08:41:36 --> Total execution time: 0.0740
INFO - 2016-10-04 08:41:38 --> Config Class Initialized
INFO - 2016-10-04 08:41:38 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:41:38 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:41:38 --> Utf8 Class Initialized
INFO - 2016-10-04 08:41:38 --> URI Class Initialized
INFO - 2016-10-04 08:41:38 --> Router Class Initialized
INFO - 2016-10-04 08:41:38 --> Output Class Initialized
INFO - 2016-10-04 08:41:38 --> Security Class Initialized
DEBUG - 2016-10-04 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:41:38 --> Input Class Initialized
INFO - 2016-10-04 08:41:38 --> Language Class Initialized
INFO - 2016-10-04 08:41:38 --> Loader Class Initialized
INFO - 2016-10-04 08:41:38 --> Helper loaded: url_helper
INFO - 2016-10-04 08:41:38 --> Helper loaded: language_helper
INFO - 2016-10-04 08:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:41:38 --> Controller Class Initialized
INFO - 2016-10-04 08:41:38 --> Database Driver Class Initialized
INFO - 2016-10-04 08:41:38 --> Model Class Initialized
INFO - 2016-10-04 08:41:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:41:38 --> Helper loaded: form_helper
INFO - 2016-10-04 08:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-04 08:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:41:38 --> Final output sent to browser
DEBUG - 2016-10-04 08:41:38 --> Total execution time: 0.0767
INFO - 2016-10-04 08:41:40 --> Config Class Initialized
INFO - 2016-10-04 08:41:40 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:41:40 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:41:40 --> Utf8 Class Initialized
INFO - 2016-10-04 08:41:40 --> URI Class Initialized
INFO - 2016-10-04 08:41:40 --> Router Class Initialized
INFO - 2016-10-04 08:41:40 --> Output Class Initialized
INFO - 2016-10-04 08:41:40 --> Security Class Initialized
DEBUG - 2016-10-04 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:41:40 --> Input Class Initialized
INFO - 2016-10-04 08:41:40 --> Language Class Initialized
INFO - 2016-10-04 08:41:40 --> Loader Class Initialized
INFO - 2016-10-04 08:41:40 --> Helper loaded: url_helper
INFO - 2016-10-04 08:41:40 --> Helper loaded: language_helper
INFO - 2016-10-04 08:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:41:40 --> Controller Class Initialized
INFO - 2016-10-04 08:41:40 --> Database Driver Class Initialized
INFO - 2016-10-04 08:41:40 --> Model Class Initialized
INFO - 2016-10-04 08:41:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:41:40 --> Model Class Initialized
INFO - 2016-10-04 08:41:40 --> Model Class Initialized
INFO - 2016-10-04 08:41:40 --> Helper loaded: form_helper
INFO - 2016-10-04 08:41:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:41:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-04 08:41:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:41:40 --> Final output sent to browser
DEBUG - 2016-10-04 08:41:40 --> Total execution time: 0.1013
INFO - 2016-10-04 08:44:09 --> Config Class Initialized
INFO - 2016-10-04 08:44:09 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:44:09 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:44:09 --> Utf8 Class Initialized
INFO - 2016-10-04 08:44:09 --> URI Class Initialized
INFO - 2016-10-04 08:44:09 --> Router Class Initialized
INFO - 2016-10-04 08:44:09 --> Output Class Initialized
INFO - 2016-10-04 08:44:09 --> Security Class Initialized
DEBUG - 2016-10-04 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:44:09 --> Input Class Initialized
INFO - 2016-10-04 08:44:09 --> Language Class Initialized
INFO - 2016-10-04 08:44:09 --> Loader Class Initialized
INFO - 2016-10-04 08:44:09 --> Helper loaded: url_helper
INFO - 2016-10-04 08:44:09 --> Helper loaded: language_helper
INFO - 2016-10-04 08:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:44:09 --> Controller Class Initialized
INFO - 2016-10-04 08:44:09 --> Database Driver Class Initialized
INFO - 2016-10-04 08:44:09 --> Model Class Initialized
INFO - 2016-10-04 08:44:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:44:10 --> Config Class Initialized
INFO - 2016-10-04 08:44:10 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:44:10 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:44:10 --> Utf8 Class Initialized
INFO - 2016-10-04 08:44:10 --> URI Class Initialized
INFO - 2016-10-04 08:44:10 --> Router Class Initialized
INFO - 2016-10-04 08:44:10 --> Output Class Initialized
INFO - 2016-10-04 08:44:10 --> Security Class Initialized
DEBUG - 2016-10-04 08:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:44:10 --> Input Class Initialized
INFO - 2016-10-04 08:44:10 --> Language Class Initialized
INFO - 2016-10-04 08:44:10 --> Loader Class Initialized
INFO - 2016-10-04 08:44:10 --> Helper loaded: url_helper
INFO - 2016-10-04 08:44:10 --> Helper loaded: language_helper
INFO - 2016-10-04 08:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:44:10 --> Controller Class Initialized
INFO - 2016-10-04 08:44:10 --> Database Driver Class Initialized
INFO - 2016-10-04 08:44:10 --> Model Class Initialized
INFO - 2016-10-04 08:44:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:44:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-04 08:44:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-04 08:44:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-04 08:44:10 --> Final output sent to browser
DEBUG - 2016-10-04 08:44:10 --> Total execution time: 0.0670
INFO - 2016-10-04 08:50:52 --> Config Class Initialized
INFO - 2016-10-04 08:50:52 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:50:52 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:50:52 --> Utf8 Class Initialized
INFO - 2016-10-04 08:50:52 --> URI Class Initialized
INFO - 2016-10-04 08:50:52 --> Router Class Initialized
INFO - 2016-10-04 08:50:52 --> Output Class Initialized
INFO - 2016-10-04 08:50:52 --> Security Class Initialized
DEBUG - 2016-10-04 08:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:50:52 --> Input Class Initialized
INFO - 2016-10-04 08:50:52 --> Language Class Initialized
INFO - 2016-10-04 08:50:52 --> Loader Class Initialized
INFO - 2016-10-04 08:50:52 --> Helper loaded: url_helper
INFO - 2016-10-04 08:50:52 --> Helper loaded: language_helper
INFO - 2016-10-04 08:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:50:52 --> Controller Class Initialized
INFO - 2016-10-04 08:50:52 --> Database Driver Class Initialized
INFO - 2016-10-04 08:50:52 --> Model Class Initialized
INFO - 2016-10-04 08:50:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:50:52 --> Config Class Initialized
INFO - 2016-10-04 08:50:52 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:50:52 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:50:52 --> Utf8 Class Initialized
INFO - 2016-10-04 08:50:52 --> URI Class Initialized
INFO - 2016-10-04 08:50:52 --> Router Class Initialized
INFO - 2016-10-04 08:50:52 --> Output Class Initialized
INFO - 2016-10-04 08:50:52 --> Security Class Initialized
DEBUG - 2016-10-04 08:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:50:52 --> Input Class Initialized
INFO - 2016-10-04 08:50:52 --> Language Class Initialized
INFO - 2016-10-04 08:50:52 --> Loader Class Initialized
INFO - 2016-10-04 08:50:52 --> Helper loaded: url_helper
INFO - 2016-10-04 08:50:52 --> Helper loaded: language_helper
INFO - 2016-10-04 08:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:50:52 --> Controller Class Initialized
INFO - 2016-10-04 08:50:52 --> Database Driver Class Initialized
INFO - 2016-10-04 08:50:52 --> Model Class Initialized
INFO - 2016-10-04 08:50:52 --> Model Class Initialized
INFO - 2016-10-04 08:50:52 --> Model Class Initialized
INFO - 2016-10-04 08:50:52 --> Model Class Initialized
INFO - 2016-10-04 08:50:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:50:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:50:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-04 08:50:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:50:52 --> Final output sent to browser
DEBUG - 2016-10-04 08:50:52 --> Total execution time: 0.0675
INFO - 2016-10-04 08:50:55 --> Config Class Initialized
INFO - 2016-10-04 08:50:55 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:50:55 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:50:55 --> Utf8 Class Initialized
INFO - 2016-10-04 08:50:55 --> URI Class Initialized
INFO - 2016-10-04 08:50:55 --> Router Class Initialized
INFO - 2016-10-04 08:50:55 --> Output Class Initialized
INFO - 2016-10-04 08:50:55 --> Security Class Initialized
DEBUG - 2016-10-04 08:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:50:55 --> Input Class Initialized
INFO - 2016-10-04 08:50:55 --> Language Class Initialized
INFO - 2016-10-04 08:50:55 --> Loader Class Initialized
INFO - 2016-10-04 08:50:55 --> Helper loaded: url_helper
INFO - 2016-10-04 08:50:55 --> Helper loaded: language_helper
INFO - 2016-10-04 08:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:50:55 --> Controller Class Initialized
INFO - 2016-10-04 08:50:55 --> Database Driver Class Initialized
INFO - 2016-10-04 08:50:55 --> Model Class Initialized
INFO - 2016-10-04 08:50:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:50:55 --> Helper loaded: form_helper
INFO - 2016-10-04 08:50:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:50:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-04 08:50:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:50:55 --> Final output sent to browser
DEBUG - 2016-10-04 08:50:55 --> Total execution time: 0.0606
INFO - 2016-10-04 08:50:58 --> Config Class Initialized
INFO - 2016-10-04 08:50:58 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:50:58 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:50:58 --> Utf8 Class Initialized
INFO - 2016-10-04 08:50:58 --> URI Class Initialized
INFO - 2016-10-04 08:50:58 --> Router Class Initialized
INFO - 2016-10-04 08:50:58 --> Output Class Initialized
INFO - 2016-10-04 08:50:58 --> Security Class Initialized
DEBUG - 2016-10-04 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:50:58 --> Input Class Initialized
INFO - 2016-10-04 08:50:58 --> Language Class Initialized
INFO - 2016-10-04 08:50:58 --> Loader Class Initialized
INFO - 2016-10-04 08:50:58 --> Helper loaded: url_helper
INFO - 2016-10-04 08:50:58 --> Helper loaded: language_helper
INFO - 2016-10-04 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:50:58 --> Controller Class Initialized
INFO - 2016-10-04 08:50:58 --> Database Driver Class Initialized
INFO - 2016-10-04 08:50:58 --> Model Class Initialized
INFO - 2016-10-04 08:50:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:50:58 --> Model Class Initialized
INFO - 2016-10-04 08:50:58 --> Model Class Initialized
INFO - 2016-10-04 08:50:58 --> Helper loaded: form_helper
INFO - 2016-10-04 08:50:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:50:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-04 08:50:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:50:58 --> Final output sent to browser
DEBUG - 2016-10-04 08:50:58 --> Total execution time: 0.0788
INFO - 2016-10-04 08:52:33 --> Config Class Initialized
INFO - 2016-10-04 08:52:33 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:52:33 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:52:33 --> Utf8 Class Initialized
INFO - 2016-10-04 08:52:33 --> URI Class Initialized
INFO - 2016-10-04 08:52:33 --> Router Class Initialized
INFO - 2016-10-04 08:52:33 --> Output Class Initialized
INFO - 2016-10-04 08:52:33 --> Security Class Initialized
DEBUG - 2016-10-04 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:52:33 --> Input Class Initialized
INFO - 2016-10-04 08:52:33 --> Language Class Initialized
INFO - 2016-10-04 08:52:33 --> Loader Class Initialized
INFO - 2016-10-04 08:52:33 --> Helper loaded: url_helper
INFO - 2016-10-04 08:52:33 --> Helper loaded: language_helper
INFO - 2016-10-04 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:52:33 --> Controller Class Initialized
INFO - 2016-10-04 08:52:33 --> Database Driver Class Initialized
INFO - 2016-10-04 08:52:33 --> Model Class Initialized
INFO - 2016-10-04 08:52:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:52:33 --> Model Class Initialized
INFO - 2016-10-04 08:52:33 --> Model Class Initialized
INFO - 2016-10-04 08:52:33 --> Helper loaded: form_helper
INFO - 2016-10-04 08:52:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:52:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-04 08:52:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:52:33 --> Final output sent to browser
DEBUG - 2016-10-04 08:52:33 --> Total execution time: 0.0845
INFO - 2016-10-04 08:54:37 --> Config Class Initialized
INFO - 2016-10-04 08:54:37 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:54:37 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:54:37 --> Utf8 Class Initialized
INFO - 2016-10-04 08:54:37 --> URI Class Initialized
INFO - 2016-10-04 08:54:37 --> Router Class Initialized
INFO - 2016-10-04 08:54:37 --> Output Class Initialized
INFO - 2016-10-04 08:54:37 --> Security Class Initialized
DEBUG - 2016-10-04 08:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:54:37 --> Input Class Initialized
INFO - 2016-10-04 08:54:37 --> Language Class Initialized
INFO - 2016-10-04 08:54:37 --> Loader Class Initialized
INFO - 2016-10-04 08:54:37 --> Helper loaded: url_helper
INFO - 2016-10-04 08:54:37 --> Helper loaded: language_helper
INFO - 2016-10-04 08:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:54:37 --> Controller Class Initialized
INFO - 2016-10-04 08:54:37 --> Database Driver Class Initialized
INFO - 2016-10-04 08:54:37 --> Model Class Initialized
INFO - 2016-10-04 08:54:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:54:37 --> Model Class Initialized
INFO - 2016-10-04 08:54:37 --> Model Class Initialized
INFO - 2016-10-04 08:54:37 --> Helper loaded: form_helper
INFO - 2016-10-04 08:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-04 08:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:54:37 --> Final output sent to browser
DEBUG - 2016-10-04 08:54:37 --> Total execution time: 0.0981
INFO - 2016-10-04 08:55:42 --> Config Class Initialized
INFO - 2016-10-04 08:55:42 --> Hooks Class Initialized
DEBUG - 2016-10-04 08:55:42 --> UTF-8 Support Enabled
INFO - 2016-10-04 08:55:42 --> Utf8 Class Initialized
INFO - 2016-10-04 08:55:42 --> URI Class Initialized
INFO - 2016-10-04 08:55:42 --> Router Class Initialized
INFO - 2016-10-04 08:55:42 --> Output Class Initialized
INFO - 2016-10-04 08:55:42 --> Security Class Initialized
DEBUG - 2016-10-04 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-04 08:55:42 --> Input Class Initialized
INFO - 2016-10-04 08:55:42 --> Language Class Initialized
INFO - 2016-10-04 08:55:42 --> Loader Class Initialized
INFO - 2016-10-04 08:55:42 --> Helper loaded: url_helper
INFO - 2016-10-04 08:55:42 --> Helper loaded: language_helper
INFO - 2016-10-04 08:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-04 08:55:43 --> Controller Class Initialized
INFO - 2016-10-04 08:55:43 --> Database Driver Class Initialized
INFO - 2016-10-04 08:55:43 --> Model Class Initialized
INFO - 2016-10-04 08:55:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-04 08:55:43 --> Model Class Initialized
INFO - 2016-10-04 08:55:43 --> Model Class Initialized
INFO - 2016-10-04 08:55:43 --> Helper loaded: form_helper
INFO - 2016-10-04 08:55:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-04 08:55:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-04 08:55:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-04 08:55:43 --> Final output sent to browser
DEBUG - 2016-10-04 08:55:43 --> Total execution time: 0.0830
