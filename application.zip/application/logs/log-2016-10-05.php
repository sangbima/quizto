<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-05 11:46:50 --> Config Class Initialized
INFO - 2016-10-05 11:46:50 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:46:50 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:46:50 --> Utf8 Class Initialized
INFO - 2016-10-05 11:46:50 --> URI Class Initialized
INFO - 2016-10-05 11:46:50 --> Router Class Initialized
INFO - 2016-10-05 11:46:50 --> Output Class Initialized
INFO - 2016-10-05 11:46:50 --> Security Class Initialized
DEBUG - 2016-10-05 11:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:46:50 --> Input Class Initialized
INFO - 2016-10-05 11:46:50 --> Language Class Initialized
INFO - 2016-10-05 11:46:50 --> Loader Class Initialized
INFO - 2016-10-05 11:46:50 --> Helper loaded: url_helper
INFO - 2016-10-05 11:46:50 --> Helper loaded: language_helper
INFO - 2016-10-05 11:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:46:50 --> Controller Class Initialized
INFO - 2016-10-05 11:46:50 --> Database Driver Class Initialized
INFO - 2016-10-05 11:46:50 --> Model Class Initialized
INFO - 2016-10-05 11:46:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:46:50 --> Config Class Initialized
INFO - 2016-10-05 11:46:50 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:46:50 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:46:50 --> Utf8 Class Initialized
INFO - 2016-10-05 11:46:50 --> URI Class Initialized
INFO - 2016-10-05 11:46:50 --> Router Class Initialized
INFO - 2016-10-05 11:46:50 --> Output Class Initialized
INFO - 2016-10-05 11:46:50 --> Security Class Initialized
DEBUG - 2016-10-05 11:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:46:50 --> Input Class Initialized
INFO - 2016-10-05 11:46:50 --> Language Class Initialized
INFO - 2016-10-05 11:46:50 --> Loader Class Initialized
INFO - 2016-10-05 11:46:50 --> Helper loaded: url_helper
INFO - 2016-10-05 11:46:50 --> Helper loaded: language_helper
INFO - 2016-10-05 11:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:46:51 --> Controller Class Initialized
INFO - 2016-10-05 11:46:51 --> Database Driver Class Initialized
INFO - 2016-10-05 11:46:51 --> Model Class Initialized
INFO - 2016-10-05 11:46:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:46:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-05 11:46:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-05 11:46:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-05 11:46:51 --> Final output sent to browser
DEBUG - 2016-10-05 11:46:51 --> Total execution time: 0.0732
INFO - 2016-10-05 11:46:55 --> Config Class Initialized
INFO - 2016-10-05 11:46:55 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:46:55 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:46:55 --> Utf8 Class Initialized
INFO - 2016-10-05 11:46:55 --> URI Class Initialized
INFO - 2016-10-05 11:46:55 --> Router Class Initialized
INFO - 2016-10-05 11:46:55 --> Output Class Initialized
INFO - 2016-10-05 11:46:55 --> Security Class Initialized
DEBUG - 2016-10-05 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:46:55 --> Input Class Initialized
INFO - 2016-10-05 11:46:55 --> Language Class Initialized
INFO - 2016-10-05 11:46:55 --> Loader Class Initialized
INFO - 2016-10-05 11:46:55 --> Helper loaded: url_helper
INFO - 2016-10-05 11:46:55 --> Helper loaded: language_helper
INFO - 2016-10-05 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:46:55 --> Controller Class Initialized
INFO - 2016-10-05 11:46:55 --> Database Driver Class Initialized
INFO - 2016-10-05 11:46:55 --> Model Class Initialized
INFO - 2016-10-05 11:46:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:46:55 --> Config Class Initialized
INFO - 2016-10-05 11:46:55 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:46:55 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:46:55 --> Utf8 Class Initialized
INFO - 2016-10-05 11:46:55 --> URI Class Initialized
INFO - 2016-10-05 11:46:55 --> Router Class Initialized
INFO - 2016-10-05 11:46:55 --> Output Class Initialized
INFO - 2016-10-05 11:46:55 --> Security Class Initialized
DEBUG - 2016-10-05 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:46:55 --> Input Class Initialized
INFO - 2016-10-05 11:46:55 --> Language Class Initialized
INFO - 2016-10-05 11:46:55 --> Loader Class Initialized
INFO - 2016-10-05 11:46:55 --> Helper loaded: url_helper
INFO - 2016-10-05 11:46:55 --> Helper loaded: language_helper
INFO - 2016-10-05 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:46:55 --> Controller Class Initialized
INFO - 2016-10-05 11:46:55 --> Database Driver Class Initialized
INFO - 2016-10-05 11:46:55 --> Model Class Initialized
INFO - 2016-10-05 11:46:55 --> Model Class Initialized
INFO - 2016-10-05 11:46:55 --> Model Class Initialized
INFO - 2016-10-05 11:46:55 --> Model Class Initialized
INFO - 2016-10-05 11:46:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:46:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:46:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-05 11:46:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:46:55 --> Final output sent to browser
DEBUG - 2016-10-05 11:46:55 --> Total execution time: 0.1060
INFO - 2016-10-05 11:46:57 --> Config Class Initialized
INFO - 2016-10-05 11:46:57 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:46:57 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:46:57 --> Utf8 Class Initialized
INFO - 2016-10-05 11:46:57 --> URI Class Initialized
INFO - 2016-10-05 11:46:57 --> Router Class Initialized
INFO - 2016-10-05 11:46:57 --> Output Class Initialized
INFO - 2016-10-05 11:46:57 --> Security Class Initialized
DEBUG - 2016-10-05 11:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:46:57 --> Input Class Initialized
INFO - 2016-10-05 11:46:57 --> Language Class Initialized
INFO - 2016-10-05 11:46:57 --> Loader Class Initialized
INFO - 2016-10-05 11:46:57 --> Helper loaded: url_helper
INFO - 2016-10-05 11:46:57 --> Helper loaded: language_helper
INFO - 2016-10-05 11:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:46:57 --> Controller Class Initialized
INFO - 2016-10-05 11:46:57 --> Database Driver Class Initialized
INFO - 2016-10-05 11:46:57 --> Model Class Initialized
INFO - 2016-10-05 11:46:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:46:57 --> Helper loaded: form_helper
INFO - 2016-10-05 11:46:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:46:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-05 11:46:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:46:57 --> Final output sent to browser
DEBUG - 2016-10-05 11:46:57 --> Total execution time: 0.1001
INFO - 2016-10-05 11:46:58 --> Config Class Initialized
INFO - 2016-10-05 11:46:58 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:46:58 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:46:58 --> Utf8 Class Initialized
INFO - 2016-10-05 11:46:58 --> URI Class Initialized
INFO - 2016-10-05 11:46:58 --> Router Class Initialized
INFO - 2016-10-05 11:46:58 --> Output Class Initialized
INFO - 2016-10-05 11:46:58 --> Security Class Initialized
DEBUG - 2016-10-05 11:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:46:58 --> Input Class Initialized
INFO - 2016-10-05 11:46:58 --> Language Class Initialized
INFO - 2016-10-05 11:46:58 --> Loader Class Initialized
INFO - 2016-10-05 11:46:58 --> Helper loaded: url_helper
INFO - 2016-10-05 11:46:58 --> Helper loaded: language_helper
INFO - 2016-10-05 11:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:46:58 --> Controller Class Initialized
INFO - 2016-10-05 11:46:58 --> Database Driver Class Initialized
INFO - 2016-10-05 11:46:58 --> Model Class Initialized
INFO - 2016-10-05 11:46:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:46:58 --> Model Class Initialized
INFO - 2016-10-05 11:46:58 --> Model Class Initialized
INFO - 2016-10-05 11:46:58 --> Helper loaded: form_helper
ERROR - 2016-10-05 11:46:58 --> Query error: Unknown column 'value_value' in 'where clause' - Invalid query: SELECT scale FROM least_scale where value_value= DISC order by scale desc
INFO - 2016-10-05 11:46:58 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-10-05 11:48:07 --> Config Class Initialized
INFO - 2016-10-05 11:48:07 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:48:07 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:48:07 --> Utf8 Class Initialized
INFO - 2016-10-05 11:48:07 --> URI Class Initialized
INFO - 2016-10-05 11:48:07 --> Router Class Initialized
INFO - 2016-10-05 11:48:07 --> Output Class Initialized
INFO - 2016-10-05 11:48:07 --> Security Class Initialized
DEBUG - 2016-10-05 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:48:07 --> Input Class Initialized
INFO - 2016-10-05 11:48:07 --> Language Class Initialized
INFO - 2016-10-05 11:48:07 --> Loader Class Initialized
INFO - 2016-10-05 11:48:07 --> Helper loaded: url_helper
INFO - 2016-10-05 11:48:07 --> Helper loaded: language_helper
INFO - 2016-10-05 11:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:48:07 --> Controller Class Initialized
INFO - 2016-10-05 11:48:07 --> Database Driver Class Initialized
INFO - 2016-10-05 11:48:07 --> Model Class Initialized
INFO - 2016-10-05 11:48:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:48:07 --> Model Class Initialized
INFO - 2016-10-05 11:48:07 --> Model Class Initialized
INFO - 2016-10-05 11:48:07 --> Helper loaded: form_helper
INFO - 2016-10-05 11:49:53 --> Config Class Initialized
INFO - 2016-10-05 11:49:53 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:49:53 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:49:53 --> Utf8 Class Initialized
INFO - 2016-10-05 11:49:53 --> URI Class Initialized
INFO - 2016-10-05 11:49:53 --> Router Class Initialized
INFO - 2016-10-05 11:49:53 --> Output Class Initialized
INFO - 2016-10-05 11:49:53 --> Security Class Initialized
DEBUG - 2016-10-05 11:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:49:53 --> Input Class Initialized
INFO - 2016-10-05 11:49:53 --> Language Class Initialized
INFO - 2016-10-05 11:49:53 --> Loader Class Initialized
INFO - 2016-10-05 11:49:53 --> Helper loaded: url_helper
INFO - 2016-10-05 11:49:53 --> Helper loaded: language_helper
INFO - 2016-10-05 11:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:49:53 --> Controller Class Initialized
INFO - 2016-10-05 11:49:53 --> Database Driver Class Initialized
INFO - 2016-10-05 11:49:53 --> Model Class Initialized
INFO - 2016-10-05 11:49:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:49:53 --> Model Class Initialized
INFO - 2016-10-05 11:49:53 --> Model Class Initialized
INFO - 2016-10-05 11:49:53 --> Helper loaded: form_helper
INFO - 2016-10-05 11:50:33 --> Config Class Initialized
INFO - 2016-10-05 11:50:33 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:50:33 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:50:33 --> Utf8 Class Initialized
INFO - 2016-10-05 11:50:33 --> URI Class Initialized
INFO - 2016-10-05 11:50:33 --> Router Class Initialized
INFO - 2016-10-05 11:50:33 --> Output Class Initialized
INFO - 2016-10-05 11:50:33 --> Security Class Initialized
DEBUG - 2016-10-05 11:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:50:33 --> Input Class Initialized
INFO - 2016-10-05 11:50:33 --> Language Class Initialized
INFO - 2016-10-05 11:50:33 --> Loader Class Initialized
INFO - 2016-10-05 11:50:33 --> Helper loaded: url_helper
INFO - 2016-10-05 11:50:33 --> Helper loaded: language_helper
INFO - 2016-10-05 11:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:50:33 --> Controller Class Initialized
INFO - 2016-10-05 11:50:33 --> Database Driver Class Initialized
INFO - 2016-10-05 11:50:33 --> Model Class Initialized
INFO - 2016-10-05 11:50:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:50:33 --> Model Class Initialized
INFO - 2016-10-05 11:50:33 --> Model Class Initialized
INFO - 2016-10-05 11:50:33 --> Helper loaded: form_helper
ERROR - 2016-10-05 11:50:33 --> Severity: Notice --> Undefined variable: result_l C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 207
ERROR - 2016-10-05 11:50:33 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 207
INFO - 2016-10-05 11:50:45 --> Config Class Initialized
INFO - 2016-10-05 11:50:45 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:50:45 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:50:45 --> Utf8 Class Initialized
INFO - 2016-10-05 11:50:45 --> URI Class Initialized
INFO - 2016-10-05 11:50:45 --> Router Class Initialized
INFO - 2016-10-05 11:50:45 --> Output Class Initialized
INFO - 2016-10-05 11:50:45 --> Security Class Initialized
DEBUG - 2016-10-05 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:50:45 --> Input Class Initialized
INFO - 2016-10-05 11:50:45 --> Language Class Initialized
INFO - 2016-10-05 11:50:45 --> Loader Class Initialized
INFO - 2016-10-05 11:50:45 --> Helper loaded: url_helper
INFO - 2016-10-05 11:50:45 --> Helper loaded: language_helper
INFO - 2016-10-05 11:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:50:45 --> Controller Class Initialized
INFO - 2016-10-05 11:50:45 --> Database Driver Class Initialized
INFO - 2016-10-05 11:50:45 --> Model Class Initialized
INFO - 2016-10-05 11:50:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:50:45 --> Model Class Initialized
INFO - 2016-10-05 11:50:45 --> Model Class Initialized
INFO - 2016-10-05 11:50:45 --> Helper loaded: form_helper
INFO - 2016-10-05 11:51:14 --> Config Class Initialized
INFO - 2016-10-05 11:51:14 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:51:14 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:51:14 --> Utf8 Class Initialized
INFO - 2016-10-05 11:51:14 --> URI Class Initialized
INFO - 2016-10-05 11:51:14 --> Router Class Initialized
INFO - 2016-10-05 11:51:14 --> Output Class Initialized
INFO - 2016-10-05 11:51:14 --> Security Class Initialized
DEBUG - 2016-10-05 11:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:51:14 --> Input Class Initialized
INFO - 2016-10-05 11:51:14 --> Language Class Initialized
INFO - 2016-10-05 11:51:14 --> Loader Class Initialized
INFO - 2016-10-05 11:51:14 --> Helper loaded: url_helper
INFO - 2016-10-05 11:51:14 --> Helper loaded: language_helper
INFO - 2016-10-05 11:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:51:14 --> Controller Class Initialized
INFO - 2016-10-05 11:51:14 --> Database Driver Class Initialized
INFO - 2016-10-05 11:51:14 --> Model Class Initialized
INFO - 2016-10-05 11:51:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:51:14 --> Model Class Initialized
INFO - 2016-10-05 11:51:14 --> Model Class Initialized
INFO - 2016-10-05 11:51:14 --> Helper loaded: form_helper
INFO - 2016-10-05 11:51:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-05 11:51:14 --> Severity: Notice --> Undefined index: value C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 291
INFO - 2016-10-05 11:51:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:51:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:51:14 --> Final output sent to browser
DEBUG - 2016-10-05 11:51:14 --> Total execution time: 0.1284
INFO - 2016-10-05 11:51:57 --> Config Class Initialized
INFO - 2016-10-05 11:51:57 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:51:57 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:51:57 --> Utf8 Class Initialized
INFO - 2016-10-05 11:51:57 --> URI Class Initialized
INFO - 2016-10-05 11:51:57 --> Router Class Initialized
INFO - 2016-10-05 11:51:57 --> Output Class Initialized
INFO - 2016-10-05 11:51:57 --> Security Class Initialized
DEBUG - 2016-10-05 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:51:57 --> Input Class Initialized
INFO - 2016-10-05 11:51:57 --> Language Class Initialized
INFO - 2016-10-05 11:51:57 --> Loader Class Initialized
INFO - 2016-10-05 11:51:57 --> Helper loaded: url_helper
INFO - 2016-10-05 11:51:57 --> Helper loaded: language_helper
INFO - 2016-10-05 11:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:51:57 --> Controller Class Initialized
INFO - 2016-10-05 11:51:57 --> Database Driver Class Initialized
INFO - 2016-10-05 11:51:57 --> Model Class Initialized
INFO - 2016-10-05 11:51:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:51:57 --> Model Class Initialized
INFO - 2016-10-05 11:51:57 --> Model Class Initialized
INFO - 2016-10-05 11:51:57 --> Helper loaded: form_helper
INFO - 2016-10-05 11:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-05 11:51:57 --> Severity: Notice --> Undefined index: value C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 291
INFO - 2016-10-05 11:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:51:57 --> Final output sent to browser
DEBUG - 2016-10-05 11:51:57 --> Total execution time: 0.1132
INFO - 2016-10-05 11:56:43 --> Config Class Initialized
INFO - 2016-10-05 11:56:43 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:56:43 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:56:43 --> Utf8 Class Initialized
INFO - 2016-10-05 11:56:43 --> URI Class Initialized
INFO - 2016-10-05 11:56:43 --> Router Class Initialized
INFO - 2016-10-05 11:56:43 --> Output Class Initialized
INFO - 2016-10-05 11:56:43 --> Security Class Initialized
DEBUG - 2016-10-05 11:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:56:43 --> Input Class Initialized
INFO - 2016-10-05 11:56:43 --> Language Class Initialized
INFO - 2016-10-05 11:56:43 --> Loader Class Initialized
INFO - 2016-10-05 11:56:43 --> Helper loaded: url_helper
INFO - 2016-10-05 11:56:43 --> Helper loaded: language_helper
INFO - 2016-10-05 11:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:56:43 --> Controller Class Initialized
INFO - 2016-10-05 11:56:43 --> Database Driver Class Initialized
INFO - 2016-10-05 11:56:43 --> Model Class Initialized
INFO - 2016-10-05 11:56:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:56:43 --> Model Class Initialized
INFO - 2016-10-05 11:56:43 --> Model Class Initialized
INFO - 2016-10-05 11:56:43 --> Helper loaded: form_helper
INFO - 2016-10-05 11:56:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:56:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:56:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:56:43 --> Final output sent to browser
DEBUG - 2016-10-05 11:56:43 --> Total execution time: 0.1214
INFO - 2016-10-05 11:57:41 --> Config Class Initialized
INFO - 2016-10-05 11:57:41 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:57:41 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:57:41 --> Utf8 Class Initialized
INFO - 2016-10-05 11:57:41 --> URI Class Initialized
INFO - 2016-10-05 11:57:41 --> Router Class Initialized
INFO - 2016-10-05 11:57:41 --> Output Class Initialized
INFO - 2016-10-05 11:57:41 --> Security Class Initialized
DEBUG - 2016-10-05 11:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:57:41 --> Input Class Initialized
INFO - 2016-10-05 11:57:41 --> Language Class Initialized
INFO - 2016-10-05 11:57:41 --> Loader Class Initialized
INFO - 2016-10-05 11:57:41 --> Helper loaded: url_helper
INFO - 2016-10-05 11:57:41 --> Helper loaded: language_helper
INFO - 2016-10-05 11:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:57:41 --> Controller Class Initialized
INFO - 2016-10-05 11:57:41 --> Database Driver Class Initialized
INFO - 2016-10-05 11:57:41 --> Model Class Initialized
INFO - 2016-10-05 11:57:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:57:41 --> Model Class Initialized
INFO - 2016-10-05 11:57:41 --> Model Class Initialized
INFO - 2016-10-05 11:57:41 --> Helper loaded: form_helper
INFO - 2016-10-05 11:57:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:57:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:57:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:57:41 --> Final output sent to browser
DEBUG - 2016-10-05 11:57:41 --> Total execution time: 0.1126
INFO - 2016-10-05 11:58:31 --> Config Class Initialized
INFO - 2016-10-05 11:58:31 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:58:31 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:58:31 --> Utf8 Class Initialized
INFO - 2016-10-05 11:58:31 --> URI Class Initialized
INFO - 2016-10-05 11:58:31 --> Router Class Initialized
INFO - 2016-10-05 11:58:31 --> Output Class Initialized
INFO - 2016-10-05 11:58:31 --> Security Class Initialized
DEBUG - 2016-10-05 11:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:58:31 --> Input Class Initialized
INFO - 2016-10-05 11:58:31 --> Language Class Initialized
INFO - 2016-10-05 11:58:31 --> Loader Class Initialized
INFO - 2016-10-05 11:58:31 --> Helper loaded: url_helper
INFO - 2016-10-05 11:58:31 --> Helper loaded: language_helper
INFO - 2016-10-05 11:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:58:31 --> Controller Class Initialized
INFO - 2016-10-05 11:58:31 --> Database Driver Class Initialized
INFO - 2016-10-05 11:58:31 --> Model Class Initialized
INFO - 2016-10-05 11:58:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:58:31 --> Model Class Initialized
INFO - 2016-10-05 11:58:31 --> Model Class Initialized
INFO - 2016-10-05 11:58:31 --> Helper loaded: form_helper
INFO - 2016-10-05 11:58:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:58:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:58:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:58:31 --> Final output sent to browser
DEBUG - 2016-10-05 11:58:31 --> Total execution time: 0.1230
INFO - 2016-10-05 11:59:15 --> Config Class Initialized
INFO - 2016-10-05 11:59:15 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:59:15 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:59:15 --> Utf8 Class Initialized
INFO - 2016-10-05 11:59:15 --> URI Class Initialized
INFO - 2016-10-05 11:59:15 --> Router Class Initialized
INFO - 2016-10-05 11:59:15 --> Output Class Initialized
INFO - 2016-10-05 11:59:15 --> Security Class Initialized
DEBUG - 2016-10-05 11:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:59:15 --> Input Class Initialized
INFO - 2016-10-05 11:59:15 --> Language Class Initialized
INFO - 2016-10-05 11:59:15 --> Loader Class Initialized
INFO - 2016-10-05 11:59:15 --> Helper loaded: url_helper
INFO - 2016-10-05 11:59:15 --> Helper loaded: language_helper
INFO - 2016-10-05 11:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:59:15 --> Controller Class Initialized
INFO - 2016-10-05 11:59:15 --> Database Driver Class Initialized
INFO - 2016-10-05 11:59:15 --> Model Class Initialized
INFO - 2016-10-05 11:59:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:59:15 --> Model Class Initialized
INFO - 2016-10-05 11:59:15 --> Model Class Initialized
INFO - 2016-10-05 11:59:15 --> Helper loaded: form_helper
INFO - 2016-10-05 11:59:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:59:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:59:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:59:15 --> Final output sent to browser
DEBUG - 2016-10-05 11:59:15 --> Total execution time: 0.1192
INFO - 2016-10-05 11:59:24 --> Config Class Initialized
INFO - 2016-10-05 11:59:24 --> Hooks Class Initialized
DEBUG - 2016-10-05 11:59:24 --> UTF-8 Support Enabled
INFO - 2016-10-05 11:59:24 --> Utf8 Class Initialized
INFO - 2016-10-05 11:59:24 --> URI Class Initialized
INFO - 2016-10-05 11:59:24 --> Router Class Initialized
INFO - 2016-10-05 11:59:24 --> Output Class Initialized
INFO - 2016-10-05 11:59:24 --> Security Class Initialized
DEBUG - 2016-10-05 11:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 11:59:24 --> Input Class Initialized
INFO - 2016-10-05 11:59:24 --> Language Class Initialized
INFO - 2016-10-05 11:59:24 --> Loader Class Initialized
INFO - 2016-10-05 11:59:24 --> Helper loaded: url_helper
INFO - 2016-10-05 11:59:24 --> Helper loaded: language_helper
INFO - 2016-10-05 11:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 11:59:24 --> Controller Class Initialized
INFO - 2016-10-05 11:59:24 --> Database Driver Class Initialized
INFO - 2016-10-05 11:59:24 --> Model Class Initialized
INFO - 2016-10-05 11:59:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 11:59:24 --> Model Class Initialized
INFO - 2016-10-05 11:59:24 --> Model Class Initialized
INFO - 2016-10-05 11:59:24 --> Helper loaded: form_helper
INFO - 2016-10-05 11:59:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 11:59:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 11:59:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 11:59:24 --> Final output sent to browser
DEBUG - 2016-10-05 11:59:24 --> Total execution time: 0.1402
INFO - 2016-10-05 12:00:16 --> Config Class Initialized
INFO - 2016-10-05 12:00:16 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:00:16 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:00:16 --> Utf8 Class Initialized
INFO - 2016-10-05 12:00:16 --> URI Class Initialized
INFO - 2016-10-05 12:00:16 --> Router Class Initialized
INFO - 2016-10-05 12:00:16 --> Output Class Initialized
INFO - 2016-10-05 12:00:16 --> Security Class Initialized
DEBUG - 2016-10-05 12:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:00:16 --> Input Class Initialized
INFO - 2016-10-05 12:00:16 --> Language Class Initialized
INFO - 2016-10-05 12:00:16 --> Loader Class Initialized
INFO - 2016-10-05 12:00:16 --> Helper loaded: url_helper
INFO - 2016-10-05 12:00:16 --> Helper loaded: language_helper
INFO - 2016-10-05 12:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:00:16 --> Controller Class Initialized
INFO - 2016-10-05 12:00:16 --> Database Driver Class Initialized
INFO - 2016-10-05 12:00:16 --> Model Class Initialized
INFO - 2016-10-05 12:00:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:00:16 --> Model Class Initialized
INFO - 2016-10-05 12:00:16 --> Model Class Initialized
INFO - 2016-10-05 12:00:16 --> Helper loaded: form_helper
INFO - 2016-10-05 12:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:00:16 --> Final output sent to browser
DEBUG - 2016-10-05 12:00:16 --> Total execution time: 0.1070
INFO - 2016-10-05 12:01:20 --> Config Class Initialized
INFO - 2016-10-05 12:01:20 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:01:20 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:01:20 --> Utf8 Class Initialized
INFO - 2016-10-05 12:01:20 --> URI Class Initialized
INFO - 2016-10-05 12:01:20 --> Router Class Initialized
INFO - 2016-10-05 12:01:20 --> Output Class Initialized
INFO - 2016-10-05 12:01:20 --> Security Class Initialized
DEBUG - 2016-10-05 12:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:01:20 --> Input Class Initialized
INFO - 2016-10-05 12:01:20 --> Language Class Initialized
INFO - 2016-10-05 12:01:20 --> Loader Class Initialized
INFO - 2016-10-05 12:01:20 --> Helper loaded: url_helper
INFO - 2016-10-05 12:01:20 --> Helper loaded: language_helper
INFO - 2016-10-05 12:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:01:20 --> Controller Class Initialized
INFO - 2016-10-05 12:01:20 --> Database Driver Class Initialized
INFO - 2016-10-05 12:01:20 --> Model Class Initialized
INFO - 2016-10-05 12:01:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:01:20 --> Model Class Initialized
INFO - 2016-10-05 12:01:20 --> Model Class Initialized
INFO - 2016-10-05 12:01:20 --> Helper loaded: form_helper
INFO - 2016-10-05 12:01:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:01:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:01:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:01:20 --> Final output sent to browser
DEBUG - 2016-10-05 12:01:20 --> Total execution time: 0.1073
INFO - 2016-10-05 12:05:04 --> Config Class Initialized
INFO - 2016-10-05 12:05:04 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:05:04 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:05:04 --> Utf8 Class Initialized
INFO - 2016-10-05 12:05:04 --> URI Class Initialized
INFO - 2016-10-05 12:05:04 --> Router Class Initialized
INFO - 2016-10-05 12:05:04 --> Output Class Initialized
INFO - 2016-10-05 12:05:04 --> Security Class Initialized
DEBUG - 2016-10-05 12:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:05:04 --> Input Class Initialized
INFO - 2016-10-05 12:05:04 --> Language Class Initialized
INFO - 2016-10-05 12:05:04 --> Loader Class Initialized
INFO - 2016-10-05 12:05:04 --> Helper loaded: url_helper
INFO - 2016-10-05 12:05:04 --> Helper loaded: language_helper
INFO - 2016-10-05 12:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:05:04 --> Controller Class Initialized
INFO - 2016-10-05 12:05:04 --> Database Driver Class Initialized
INFO - 2016-10-05 12:05:04 --> Model Class Initialized
INFO - 2016-10-05 12:05:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:05:04 --> Model Class Initialized
INFO - 2016-10-05 12:05:04 --> Model Class Initialized
INFO - 2016-10-05 12:05:04 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:05:04 --> Severity: error --> Exception: [] operator not supported for strings C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
INFO - 2016-10-05 12:06:21 --> Config Class Initialized
INFO - 2016-10-05 12:06:21 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:06:21 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:06:21 --> Utf8 Class Initialized
INFO - 2016-10-05 12:06:21 --> URI Class Initialized
INFO - 2016-10-05 12:06:21 --> Router Class Initialized
INFO - 2016-10-05 12:06:21 --> Output Class Initialized
INFO - 2016-10-05 12:06:21 --> Security Class Initialized
DEBUG - 2016-10-05 12:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:06:21 --> Input Class Initialized
INFO - 2016-10-05 12:06:21 --> Language Class Initialized
INFO - 2016-10-05 12:06:21 --> Loader Class Initialized
INFO - 2016-10-05 12:06:21 --> Helper loaded: url_helper
INFO - 2016-10-05 12:06:21 --> Helper loaded: language_helper
INFO - 2016-10-05 12:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:06:21 --> Controller Class Initialized
INFO - 2016-10-05 12:06:21 --> Database Driver Class Initialized
INFO - 2016-10-05 12:06:21 --> Model Class Initialized
INFO - 2016-10-05 12:06:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:06:21 --> Model Class Initialized
INFO - 2016-10-05 12:06:21 --> Model Class Initialized
INFO - 2016-10-05 12:06:21 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:06:21 --> Severity: Notice --> Undefined index: value C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 198
ERROR - 2016-10-05 12:06:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 200
INFO - 2016-10-05 12:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:06:21 --> Final output sent to browser
DEBUG - 2016-10-05 12:06:21 --> Total execution time: 0.1196
INFO - 2016-10-05 12:07:05 --> Config Class Initialized
INFO - 2016-10-05 12:07:05 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:07:05 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:07:05 --> Utf8 Class Initialized
INFO - 2016-10-05 12:07:05 --> URI Class Initialized
INFO - 2016-10-05 12:07:05 --> Router Class Initialized
INFO - 2016-10-05 12:07:05 --> Output Class Initialized
INFO - 2016-10-05 12:07:05 --> Security Class Initialized
DEBUG - 2016-10-05 12:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:07:05 --> Input Class Initialized
INFO - 2016-10-05 12:07:05 --> Language Class Initialized
INFO - 2016-10-05 12:07:05 --> Loader Class Initialized
INFO - 2016-10-05 12:07:05 --> Helper loaded: url_helper
INFO - 2016-10-05 12:07:05 --> Helper loaded: language_helper
INFO - 2016-10-05 12:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:07:05 --> Controller Class Initialized
INFO - 2016-10-05 12:07:05 --> Database Driver Class Initialized
INFO - 2016-10-05 12:07:05 --> Model Class Initialized
INFO - 2016-10-05 12:07:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:07:05 --> Model Class Initialized
INFO - 2016-10-05 12:07:05 --> Model Class Initialized
INFO - 2016-10-05 12:07:05 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:07:05 --> Severity: Notice --> Undefined index: value C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 198
INFO - 2016-10-05 12:07:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:07:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:07:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:07:05 --> Final output sent to browser
DEBUG - 2016-10-05 12:07:05 --> Total execution time: 0.1022
INFO - 2016-10-05 12:07:31 --> Config Class Initialized
INFO - 2016-10-05 12:07:31 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:07:31 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:07:31 --> Utf8 Class Initialized
INFO - 2016-10-05 12:07:31 --> URI Class Initialized
INFO - 2016-10-05 12:07:31 --> Router Class Initialized
INFO - 2016-10-05 12:07:31 --> Output Class Initialized
INFO - 2016-10-05 12:07:31 --> Security Class Initialized
DEBUG - 2016-10-05 12:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:07:31 --> Input Class Initialized
INFO - 2016-10-05 12:07:31 --> Language Class Initialized
INFO - 2016-10-05 12:07:31 --> Loader Class Initialized
INFO - 2016-10-05 12:07:31 --> Helper loaded: url_helper
INFO - 2016-10-05 12:07:31 --> Helper loaded: language_helper
INFO - 2016-10-05 12:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:07:31 --> Controller Class Initialized
INFO - 2016-10-05 12:07:31 --> Database Driver Class Initialized
INFO - 2016-10-05 12:07:31 --> Model Class Initialized
INFO - 2016-10-05 12:07:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:07:31 --> Model Class Initialized
INFO - 2016-10-05 12:07:31 --> Model Class Initialized
INFO - 2016-10-05 12:07:31 --> Helper loaded: form_helper
INFO - 2016-10-05 12:07:43 --> Config Class Initialized
INFO - 2016-10-05 12:07:43 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:07:43 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:07:43 --> Utf8 Class Initialized
INFO - 2016-10-05 12:07:43 --> URI Class Initialized
INFO - 2016-10-05 12:07:43 --> Router Class Initialized
INFO - 2016-10-05 12:07:43 --> Output Class Initialized
INFO - 2016-10-05 12:07:43 --> Security Class Initialized
DEBUG - 2016-10-05 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:07:43 --> Input Class Initialized
INFO - 2016-10-05 12:07:43 --> Language Class Initialized
INFO - 2016-10-05 12:07:43 --> Loader Class Initialized
INFO - 2016-10-05 12:07:43 --> Helper loaded: url_helper
INFO - 2016-10-05 12:07:43 --> Helper loaded: language_helper
INFO - 2016-10-05 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:07:43 --> Controller Class Initialized
INFO - 2016-10-05 12:07:43 --> Database Driver Class Initialized
INFO - 2016-10-05 12:07:43 --> Model Class Initialized
INFO - 2016-10-05 12:07:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:07:43 --> Model Class Initialized
INFO - 2016-10-05 12:07:43 --> Model Class Initialized
INFO - 2016-10-05 12:07:43 --> Helper loaded: form_helper
INFO - 2016-10-05 12:08:21 --> Config Class Initialized
INFO - 2016-10-05 12:08:21 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:08:21 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:08:21 --> Utf8 Class Initialized
INFO - 2016-10-05 12:08:21 --> URI Class Initialized
INFO - 2016-10-05 12:08:21 --> Router Class Initialized
INFO - 2016-10-05 12:08:21 --> Output Class Initialized
INFO - 2016-10-05 12:08:21 --> Security Class Initialized
DEBUG - 2016-10-05 12:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:08:21 --> Input Class Initialized
INFO - 2016-10-05 12:08:21 --> Language Class Initialized
INFO - 2016-10-05 12:08:21 --> Loader Class Initialized
INFO - 2016-10-05 12:08:21 --> Helper loaded: url_helper
INFO - 2016-10-05 12:08:21 --> Helper loaded: language_helper
INFO - 2016-10-05 12:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:08:21 --> Controller Class Initialized
INFO - 2016-10-05 12:08:21 --> Database Driver Class Initialized
INFO - 2016-10-05 12:08:21 --> Model Class Initialized
INFO - 2016-10-05 12:08:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:08:21 --> Model Class Initialized
INFO - 2016-10-05 12:08:21 --> Model Class Initialized
INFO - 2016-10-05 12:08:21 --> Helper loaded: form_helper
INFO - 2016-10-05 12:08:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:08:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:08:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:08:21 --> Final output sent to browser
DEBUG - 2016-10-05 12:08:21 --> Total execution time: 0.0968
INFO - 2016-10-05 12:18:56 --> Config Class Initialized
INFO - 2016-10-05 12:18:56 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:18:56 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:18:56 --> Utf8 Class Initialized
INFO - 2016-10-05 12:18:56 --> URI Class Initialized
INFO - 2016-10-05 12:18:56 --> Router Class Initialized
INFO - 2016-10-05 12:18:56 --> Output Class Initialized
INFO - 2016-10-05 12:18:56 --> Security Class Initialized
DEBUG - 2016-10-05 12:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:18:56 --> Input Class Initialized
INFO - 2016-10-05 12:18:56 --> Language Class Initialized
INFO - 2016-10-05 12:18:56 --> Loader Class Initialized
INFO - 2016-10-05 12:18:56 --> Helper loaded: url_helper
INFO - 2016-10-05 12:18:56 --> Helper loaded: language_helper
INFO - 2016-10-05 12:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:18:56 --> Controller Class Initialized
INFO - 2016-10-05 12:18:56 --> Database Driver Class Initialized
INFO - 2016-10-05 12:18:56 --> Model Class Initialized
INFO - 2016-10-05 12:18:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:18:56 --> Model Class Initialized
INFO - 2016-10-05 12:18:56 --> Model Class Initialized
INFO - 2016-10-05 12:18:56 --> Helper loaded: form_helper
INFO - 2016-10-05 12:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-05 12:18:56 --> Severity: Notice --> Undefined index: value C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 291
INFO - 2016-10-05 12:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:18:56 --> Final output sent to browser
DEBUG - 2016-10-05 12:18:56 --> Total execution time: 0.1136
INFO - 2016-10-05 12:19:27 --> Config Class Initialized
INFO - 2016-10-05 12:19:27 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:19:27 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:19:27 --> Utf8 Class Initialized
INFO - 2016-10-05 12:19:27 --> URI Class Initialized
INFO - 2016-10-05 12:19:27 --> Router Class Initialized
INFO - 2016-10-05 12:19:27 --> Output Class Initialized
INFO - 2016-10-05 12:19:27 --> Security Class Initialized
DEBUG - 2016-10-05 12:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:19:27 --> Input Class Initialized
INFO - 2016-10-05 12:19:27 --> Language Class Initialized
INFO - 2016-10-05 12:19:27 --> Loader Class Initialized
INFO - 2016-10-05 12:19:27 --> Helper loaded: url_helper
INFO - 2016-10-05 12:19:27 --> Helper loaded: language_helper
INFO - 2016-10-05 12:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:19:27 --> Controller Class Initialized
INFO - 2016-10-05 12:19:27 --> Database Driver Class Initialized
INFO - 2016-10-05 12:19:27 --> Model Class Initialized
INFO - 2016-10-05 12:19:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:19:27 --> Model Class Initialized
INFO - 2016-10-05 12:19:27 --> Model Class Initialized
INFO - 2016-10-05 12:19:27 --> Helper loaded: form_helper
INFO - 2016-10-05 12:19:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-05 12:19:27 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 291
INFO - 2016-10-05 12:19:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:19:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:19:27 --> Final output sent to browser
DEBUG - 2016-10-05 12:19:27 --> Total execution time: 0.1133
INFO - 2016-10-05 12:20:30 --> Config Class Initialized
INFO - 2016-10-05 12:20:30 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:20:30 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:20:30 --> Utf8 Class Initialized
INFO - 2016-10-05 12:20:30 --> URI Class Initialized
INFO - 2016-10-05 12:20:30 --> Router Class Initialized
INFO - 2016-10-05 12:20:30 --> Output Class Initialized
INFO - 2016-10-05 12:20:30 --> Security Class Initialized
DEBUG - 2016-10-05 12:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:20:30 --> Input Class Initialized
INFO - 2016-10-05 12:20:30 --> Language Class Initialized
INFO - 2016-10-05 12:20:30 --> Loader Class Initialized
INFO - 2016-10-05 12:20:30 --> Helper loaded: url_helper
INFO - 2016-10-05 12:20:30 --> Helper loaded: language_helper
INFO - 2016-10-05 12:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:20:30 --> Controller Class Initialized
INFO - 2016-10-05 12:20:30 --> Database Driver Class Initialized
INFO - 2016-10-05 12:20:30 --> Model Class Initialized
INFO - 2016-10-05 12:20:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:20:30 --> Model Class Initialized
INFO - 2016-10-05 12:20:30 --> Model Class Initialized
INFO - 2016-10-05 12:20:30 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:20:30 --> Severity: Warning --> implode(): Invalid arguments passed C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 195
ERROR - 2016-10-05 12:20:30 --> Severity: Warning --> implode(): Invalid arguments passed C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 195
ERROR - 2016-10-05 12:20:30 --> Severity: Warning --> implode(): Invalid arguments passed C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 195
ERROR - 2016-10-05 12:20:30 --> Severity: Warning --> implode(): Invalid arguments passed C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 195
INFO - 2016-10-05 12:20:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-05 12:20:30 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 291
INFO - 2016-10-05 12:20:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:20:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:20:30 --> Final output sent to browser
DEBUG - 2016-10-05 12:20:30 --> Total execution time: 0.1120
INFO - 2016-10-05 12:21:34 --> Config Class Initialized
INFO - 2016-10-05 12:21:34 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:21:34 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:21:34 --> Utf8 Class Initialized
INFO - 2016-10-05 12:21:34 --> URI Class Initialized
INFO - 2016-10-05 12:21:34 --> Router Class Initialized
INFO - 2016-10-05 12:21:34 --> Output Class Initialized
INFO - 2016-10-05 12:21:34 --> Security Class Initialized
DEBUG - 2016-10-05 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:21:34 --> Input Class Initialized
INFO - 2016-10-05 12:21:34 --> Language Class Initialized
INFO - 2016-10-05 12:21:34 --> Loader Class Initialized
INFO - 2016-10-05 12:21:34 --> Helper loaded: url_helper
INFO - 2016-10-05 12:21:34 --> Helper loaded: language_helper
INFO - 2016-10-05 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:21:34 --> Controller Class Initialized
INFO - 2016-10-05 12:21:34 --> Database Driver Class Initialized
INFO - 2016-10-05 12:21:34 --> Model Class Initialized
INFO - 2016-10-05 12:21:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:21:34 --> Model Class Initialized
INFO - 2016-10-05 12:21:34 --> Model Class Initialized
INFO - 2016-10-05 12:21:34 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:21:34 --> Severity: Warning --> implode(): Invalid arguments passed C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 198
INFO - 2016-10-05 12:21:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:21:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:21:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:21:34 --> Final output sent to browser
DEBUG - 2016-10-05 12:21:34 --> Total execution time: 0.1108
INFO - 2016-10-05 12:22:00 --> Config Class Initialized
INFO - 2016-10-05 12:22:00 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:22:00 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:22:00 --> Utf8 Class Initialized
INFO - 2016-10-05 12:22:00 --> URI Class Initialized
INFO - 2016-10-05 12:22:00 --> Router Class Initialized
INFO - 2016-10-05 12:22:00 --> Output Class Initialized
INFO - 2016-10-05 12:22:00 --> Security Class Initialized
DEBUG - 2016-10-05 12:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:22:00 --> Input Class Initialized
INFO - 2016-10-05 12:22:00 --> Language Class Initialized
INFO - 2016-10-05 12:22:00 --> Loader Class Initialized
INFO - 2016-10-05 12:22:00 --> Helper loaded: url_helper
INFO - 2016-10-05 12:22:00 --> Helper loaded: language_helper
INFO - 2016-10-05 12:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:22:00 --> Controller Class Initialized
INFO - 2016-10-05 12:22:00 --> Database Driver Class Initialized
INFO - 2016-10-05 12:22:00 --> Model Class Initialized
INFO - 2016-10-05 12:22:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:22:00 --> Model Class Initialized
INFO - 2016-10-05 12:22:00 --> Model Class Initialized
INFO - 2016-10-05 12:22:00 --> Helper loaded: form_helper
INFO - 2016-10-05 12:22:36 --> Config Class Initialized
INFO - 2016-10-05 12:22:36 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:22:36 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:22:36 --> Utf8 Class Initialized
INFO - 2016-10-05 12:22:36 --> URI Class Initialized
INFO - 2016-10-05 12:22:36 --> Router Class Initialized
INFO - 2016-10-05 12:22:36 --> Output Class Initialized
INFO - 2016-10-05 12:22:36 --> Security Class Initialized
DEBUG - 2016-10-05 12:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:22:36 --> Input Class Initialized
INFO - 2016-10-05 12:22:36 --> Language Class Initialized
INFO - 2016-10-05 12:22:36 --> Loader Class Initialized
INFO - 2016-10-05 12:22:36 --> Helper loaded: url_helper
INFO - 2016-10-05 12:22:36 --> Helper loaded: language_helper
INFO - 2016-10-05 12:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:22:36 --> Controller Class Initialized
INFO - 2016-10-05 12:22:36 --> Database Driver Class Initialized
INFO - 2016-10-05 12:22:36 --> Model Class Initialized
INFO - 2016-10-05 12:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:22:36 --> Model Class Initialized
INFO - 2016-10-05 12:22:36 --> Model Class Initialized
INFO - 2016-10-05 12:22:36 --> Helper loaded: form_helper
INFO - 2016-10-05 12:24:09 --> Config Class Initialized
INFO - 2016-10-05 12:24:09 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:24:09 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:24:09 --> Utf8 Class Initialized
INFO - 2016-10-05 12:24:09 --> URI Class Initialized
INFO - 2016-10-05 12:24:09 --> Router Class Initialized
INFO - 2016-10-05 12:24:09 --> Output Class Initialized
INFO - 2016-10-05 12:24:09 --> Security Class Initialized
DEBUG - 2016-10-05 12:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:24:09 --> Input Class Initialized
INFO - 2016-10-05 12:24:09 --> Language Class Initialized
INFO - 2016-10-05 12:24:09 --> Loader Class Initialized
INFO - 2016-10-05 12:24:09 --> Helper loaded: url_helper
INFO - 2016-10-05 12:24:09 --> Helper loaded: language_helper
INFO - 2016-10-05 12:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:24:09 --> Controller Class Initialized
INFO - 2016-10-05 12:24:09 --> Database Driver Class Initialized
INFO - 2016-10-05 12:24:09 --> Model Class Initialized
INFO - 2016-10-05 12:24:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:24:09 --> Model Class Initialized
INFO - 2016-10-05 12:24:09 --> Model Class Initialized
INFO - 2016-10-05 12:24:09 --> Helper loaded: form_helper
INFO - 2016-10-05 12:24:50 --> Config Class Initialized
INFO - 2016-10-05 12:24:50 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:24:50 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:24:50 --> Utf8 Class Initialized
INFO - 2016-10-05 12:24:50 --> URI Class Initialized
INFO - 2016-10-05 12:24:50 --> Router Class Initialized
INFO - 2016-10-05 12:24:50 --> Output Class Initialized
INFO - 2016-10-05 12:24:50 --> Security Class Initialized
DEBUG - 2016-10-05 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:24:50 --> Input Class Initialized
INFO - 2016-10-05 12:24:50 --> Language Class Initialized
INFO - 2016-10-05 12:24:50 --> Loader Class Initialized
INFO - 2016-10-05 12:24:50 --> Helper loaded: url_helper
INFO - 2016-10-05 12:24:50 --> Helper loaded: language_helper
INFO - 2016-10-05 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:24:50 --> Controller Class Initialized
INFO - 2016-10-05 12:24:50 --> Database Driver Class Initialized
INFO - 2016-10-05 12:24:50 --> Model Class Initialized
INFO - 2016-10-05 12:24:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:24:50 --> Model Class Initialized
INFO - 2016-10-05 12:24:50 --> Model Class Initialized
INFO - 2016-10-05 12:24:50 --> Helper loaded: form_helper
INFO - 2016-10-05 12:25:19 --> Config Class Initialized
INFO - 2016-10-05 12:25:19 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:25:19 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:25:19 --> Utf8 Class Initialized
INFO - 2016-10-05 12:25:19 --> URI Class Initialized
INFO - 2016-10-05 12:25:19 --> Router Class Initialized
INFO - 2016-10-05 12:25:19 --> Output Class Initialized
INFO - 2016-10-05 12:25:19 --> Security Class Initialized
DEBUG - 2016-10-05 12:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:25:19 --> Input Class Initialized
INFO - 2016-10-05 12:25:19 --> Language Class Initialized
INFO - 2016-10-05 12:25:19 --> Loader Class Initialized
INFO - 2016-10-05 12:25:19 --> Helper loaded: url_helper
INFO - 2016-10-05 12:25:19 --> Helper loaded: language_helper
INFO - 2016-10-05 12:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:25:19 --> Controller Class Initialized
INFO - 2016-10-05 12:25:19 --> Database Driver Class Initialized
INFO - 2016-10-05 12:25:19 --> Model Class Initialized
INFO - 2016-10-05 12:25:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:25:19 --> Model Class Initialized
INFO - 2016-10-05 12:25:19 --> Model Class Initialized
INFO - 2016-10-05 12:25:19 --> Helper loaded: form_helper
INFO - 2016-10-05 12:27:04 --> Config Class Initialized
INFO - 2016-10-05 12:27:04 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:27:04 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:27:04 --> Utf8 Class Initialized
INFO - 2016-10-05 12:27:04 --> URI Class Initialized
INFO - 2016-10-05 12:27:04 --> Router Class Initialized
INFO - 2016-10-05 12:27:04 --> Output Class Initialized
INFO - 2016-10-05 12:27:04 --> Security Class Initialized
DEBUG - 2016-10-05 12:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:27:04 --> Input Class Initialized
INFO - 2016-10-05 12:27:04 --> Language Class Initialized
INFO - 2016-10-05 12:27:04 --> Loader Class Initialized
INFO - 2016-10-05 12:27:04 --> Helper loaded: url_helper
INFO - 2016-10-05 12:27:04 --> Helper loaded: language_helper
INFO - 2016-10-05 12:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:27:04 --> Controller Class Initialized
INFO - 2016-10-05 12:27:04 --> Database Driver Class Initialized
INFO - 2016-10-05 12:27:04 --> Model Class Initialized
INFO - 2016-10-05 12:27:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:27:04 --> Model Class Initialized
INFO - 2016-10-05 12:27:04 --> Model Class Initialized
INFO - 2016-10-05 12:27:04 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:27:04 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 199
INFO - 2016-10-05 12:27:22 --> Config Class Initialized
INFO - 2016-10-05 12:27:22 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:27:22 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:27:22 --> Utf8 Class Initialized
INFO - 2016-10-05 12:27:22 --> URI Class Initialized
INFO - 2016-10-05 12:27:22 --> Router Class Initialized
INFO - 2016-10-05 12:27:22 --> Output Class Initialized
INFO - 2016-10-05 12:27:22 --> Security Class Initialized
DEBUG - 2016-10-05 12:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:27:22 --> Input Class Initialized
INFO - 2016-10-05 12:27:22 --> Language Class Initialized
INFO - 2016-10-05 12:27:22 --> Loader Class Initialized
INFO - 2016-10-05 12:27:22 --> Helper loaded: url_helper
INFO - 2016-10-05 12:27:22 --> Helper loaded: language_helper
INFO - 2016-10-05 12:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:27:22 --> Controller Class Initialized
INFO - 2016-10-05 12:27:22 --> Database Driver Class Initialized
INFO - 2016-10-05 12:27:22 --> Model Class Initialized
INFO - 2016-10-05 12:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:27:22 --> Model Class Initialized
INFO - 2016-10-05 12:27:22 --> Model Class Initialized
INFO - 2016-10-05 12:27:22 --> Helper loaded: form_helper
INFO - 2016-10-05 12:28:00 --> Config Class Initialized
INFO - 2016-10-05 12:28:00 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:28:00 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:28:00 --> Utf8 Class Initialized
INFO - 2016-10-05 12:28:00 --> URI Class Initialized
INFO - 2016-10-05 12:28:00 --> Router Class Initialized
INFO - 2016-10-05 12:28:00 --> Output Class Initialized
INFO - 2016-10-05 12:28:00 --> Security Class Initialized
DEBUG - 2016-10-05 12:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:28:00 --> Input Class Initialized
INFO - 2016-10-05 12:28:00 --> Language Class Initialized
INFO - 2016-10-05 12:28:00 --> Loader Class Initialized
INFO - 2016-10-05 12:28:00 --> Helper loaded: url_helper
INFO - 2016-10-05 12:28:00 --> Helper loaded: language_helper
INFO - 2016-10-05 12:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:28:00 --> Controller Class Initialized
INFO - 2016-10-05 12:28:00 --> Database Driver Class Initialized
INFO - 2016-10-05 12:28:00 --> Model Class Initialized
INFO - 2016-10-05 12:28:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:28:00 --> Model Class Initialized
INFO - 2016-10-05 12:28:00 --> Model Class Initialized
INFO - 2016-10-05 12:28:00 --> Helper loaded: form_helper
INFO - 2016-10-05 12:28:52 --> Config Class Initialized
INFO - 2016-10-05 12:28:52 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:28:52 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:28:52 --> Utf8 Class Initialized
INFO - 2016-10-05 12:28:52 --> URI Class Initialized
INFO - 2016-10-05 12:28:52 --> Router Class Initialized
INFO - 2016-10-05 12:28:52 --> Output Class Initialized
INFO - 2016-10-05 12:28:52 --> Security Class Initialized
DEBUG - 2016-10-05 12:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:28:52 --> Input Class Initialized
INFO - 2016-10-05 12:28:52 --> Language Class Initialized
INFO - 2016-10-05 12:28:52 --> Loader Class Initialized
INFO - 2016-10-05 12:28:52 --> Helper loaded: url_helper
INFO - 2016-10-05 12:28:52 --> Helper loaded: language_helper
INFO - 2016-10-05 12:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:28:52 --> Controller Class Initialized
INFO - 2016-10-05 12:28:53 --> Database Driver Class Initialized
INFO - 2016-10-05 12:28:53 --> Model Class Initialized
INFO - 2016-10-05 12:28:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:28:53 --> Model Class Initialized
INFO - 2016-10-05 12:28:53 --> Model Class Initialized
INFO - 2016-10-05 12:28:53 --> Helper loaded: form_helper
INFO - 2016-10-05 12:29:07 --> Config Class Initialized
INFO - 2016-10-05 12:29:07 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:29:07 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:29:07 --> Utf8 Class Initialized
INFO - 2016-10-05 12:29:07 --> URI Class Initialized
INFO - 2016-10-05 12:29:07 --> Router Class Initialized
INFO - 2016-10-05 12:29:07 --> Output Class Initialized
INFO - 2016-10-05 12:29:07 --> Security Class Initialized
DEBUG - 2016-10-05 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:29:07 --> Input Class Initialized
INFO - 2016-10-05 12:29:07 --> Language Class Initialized
INFO - 2016-10-05 12:29:07 --> Loader Class Initialized
INFO - 2016-10-05 12:29:07 --> Helper loaded: url_helper
INFO - 2016-10-05 12:29:07 --> Helper loaded: language_helper
INFO - 2016-10-05 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:29:07 --> Controller Class Initialized
INFO - 2016-10-05 12:29:07 --> Database Driver Class Initialized
INFO - 2016-10-05 12:29:07 --> Model Class Initialized
INFO - 2016-10-05 12:29:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:29:07 --> Model Class Initialized
INFO - 2016-10-05 12:29:07 --> Model Class Initialized
INFO - 2016-10-05 12:29:07 --> Helper loaded: form_helper
ERROR - 2016-10-05 12:29:07 --> Severity: Warning --> array_merge(): Argument #2 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 199
INFO - 2016-10-05 12:29:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:29:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:29:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:29:07 --> Final output sent to browser
DEBUG - 2016-10-05 12:29:07 --> Total execution time: 0.0974
INFO - 2016-10-05 12:29:25 --> Config Class Initialized
INFO - 2016-10-05 12:29:25 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:29:25 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:29:25 --> Utf8 Class Initialized
INFO - 2016-10-05 12:29:25 --> URI Class Initialized
INFO - 2016-10-05 12:29:25 --> Router Class Initialized
INFO - 2016-10-05 12:29:25 --> Output Class Initialized
INFO - 2016-10-05 12:29:25 --> Security Class Initialized
DEBUG - 2016-10-05 12:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:29:25 --> Input Class Initialized
INFO - 2016-10-05 12:29:25 --> Language Class Initialized
INFO - 2016-10-05 12:29:25 --> Loader Class Initialized
INFO - 2016-10-05 12:29:25 --> Helper loaded: url_helper
INFO - 2016-10-05 12:29:25 --> Helper loaded: language_helper
INFO - 2016-10-05 12:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:29:25 --> Controller Class Initialized
INFO - 2016-10-05 12:29:25 --> Database Driver Class Initialized
INFO - 2016-10-05 12:29:25 --> Model Class Initialized
INFO - 2016-10-05 12:29:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:29:25 --> Model Class Initialized
INFO - 2016-10-05 12:29:25 --> Model Class Initialized
INFO - 2016-10-05 12:29:25 --> Helper loaded: form_helper
INFO - 2016-10-05 12:29:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:29:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:29:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:29:25 --> Final output sent to browser
DEBUG - 2016-10-05 12:29:25 --> Total execution time: 0.0998
INFO - 2016-10-05 12:29:56 --> Config Class Initialized
INFO - 2016-10-05 12:29:56 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:29:56 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:29:56 --> Utf8 Class Initialized
INFO - 2016-10-05 12:29:56 --> URI Class Initialized
INFO - 2016-10-05 12:29:56 --> Router Class Initialized
INFO - 2016-10-05 12:29:56 --> Output Class Initialized
INFO - 2016-10-05 12:29:56 --> Security Class Initialized
DEBUG - 2016-10-05 12:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:29:56 --> Input Class Initialized
INFO - 2016-10-05 12:29:56 --> Language Class Initialized
INFO - 2016-10-05 12:29:56 --> Loader Class Initialized
INFO - 2016-10-05 12:29:56 --> Helper loaded: url_helper
INFO - 2016-10-05 12:29:56 --> Helper loaded: language_helper
INFO - 2016-10-05 12:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:29:56 --> Controller Class Initialized
INFO - 2016-10-05 12:29:56 --> Database Driver Class Initialized
INFO - 2016-10-05 12:29:56 --> Model Class Initialized
INFO - 2016-10-05 12:29:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:29:56 --> Model Class Initialized
INFO - 2016-10-05 12:29:56 --> Model Class Initialized
INFO - 2016-10-05 12:29:56 --> Helper loaded: form_helper
INFO - 2016-10-05 12:29:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:29:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:29:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:29:56 --> Final output sent to browser
DEBUG - 2016-10-05 12:29:56 --> Total execution time: 0.0937
INFO - 2016-10-05 12:31:28 --> Config Class Initialized
INFO - 2016-10-05 12:31:28 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:31:28 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:31:28 --> Utf8 Class Initialized
INFO - 2016-10-05 12:31:28 --> URI Class Initialized
INFO - 2016-10-05 12:31:28 --> Router Class Initialized
INFO - 2016-10-05 12:31:28 --> Output Class Initialized
INFO - 2016-10-05 12:31:28 --> Security Class Initialized
DEBUG - 2016-10-05 12:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:31:28 --> Input Class Initialized
INFO - 2016-10-05 12:31:28 --> Language Class Initialized
INFO - 2016-10-05 12:31:28 --> Loader Class Initialized
INFO - 2016-10-05 12:31:28 --> Helper loaded: url_helper
INFO - 2016-10-05 12:31:28 --> Helper loaded: language_helper
INFO - 2016-10-05 12:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:31:28 --> Controller Class Initialized
INFO - 2016-10-05 12:31:28 --> Database Driver Class Initialized
INFO - 2016-10-05 12:31:28 --> Model Class Initialized
INFO - 2016-10-05 12:31:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:31:28 --> Model Class Initialized
INFO - 2016-10-05 12:31:28 --> Model Class Initialized
INFO - 2016-10-05 12:31:28 --> Helper loaded: form_helper
INFO - 2016-10-05 12:31:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:31:29 --> Final output sent to browser
DEBUG - 2016-10-05 12:31:29 --> Total execution time: 0.1195
INFO - 2016-10-05 12:31:45 --> Config Class Initialized
INFO - 2016-10-05 12:31:45 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:31:45 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:31:45 --> Utf8 Class Initialized
INFO - 2016-10-05 12:31:45 --> URI Class Initialized
INFO - 2016-10-05 12:31:45 --> Router Class Initialized
INFO - 2016-10-05 12:31:45 --> Output Class Initialized
INFO - 2016-10-05 12:31:45 --> Security Class Initialized
DEBUG - 2016-10-05 12:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:31:45 --> Input Class Initialized
INFO - 2016-10-05 12:31:45 --> Language Class Initialized
INFO - 2016-10-05 12:31:45 --> Loader Class Initialized
INFO - 2016-10-05 12:31:45 --> Helper loaded: url_helper
INFO - 2016-10-05 12:31:45 --> Helper loaded: language_helper
INFO - 2016-10-05 12:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:31:45 --> Controller Class Initialized
INFO - 2016-10-05 12:31:45 --> Database Driver Class Initialized
INFO - 2016-10-05 12:31:45 --> Model Class Initialized
INFO - 2016-10-05 12:31:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:31:45 --> Model Class Initialized
INFO - 2016-10-05 12:31:45 --> Model Class Initialized
INFO - 2016-10-05 12:31:45 --> Helper loaded: form_helper
INFO - 2016-10-05 12:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:31:45 --> Final output sent to browser
DEBUG - 2016-10-05 12:31:45 --> Total execution time: 0.1015
INFO - 2016-10-05 12:33:07 --> Config Class Initialized
INFO - 2016-10-05 12:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:33:07 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:33:07 --> Utf8 Class Initialized
INFO - 2016-10-05 12:33:07 --> URI Class Initialized
INFO - 2016-10-05 12:33:07 --> Router Class Initialized
INFO - 2016-10-05 12:33:07 --> Output Class Initialized
INFO - 2016-10-05 12:33:07 --> Security Class Initialized
DEBUG - 2016-10-05 12:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:33:07 --> Input Class Initialized
INFO - 2016-10-05 12:33:07 --> Language Class Initialized
INFO - 2016-10-05 12:33:07 --> Loader Class Initialized
INFO - 2016-10-05 12:33:07 --> Helper loaded: url_helper
INFO - 2016-10-05 12:33:07 --> Helper loaded: language_helper
INFO - 2016-10-05 12:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:33:07 --> Controller Class Initialized
INFO - 2016-10-05 12:33:07 --> Database Driver Class Initialized
INFO - 2016-10-05 12:33:07 --> Model Class Initialized
INFO - 2016-10-05 12:33:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:33:07 --> Model Class Initialized
INFO - 2016-10-05 12:33:07 --> Model Class Initialized
INFO - 2016-10-05 12:33:07 --> Helper loaded: form_helper
INFO - 2016-10-05 12:33:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:33:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:33:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:33:07 --> Final output sent to browser
DEBUG - 2016-10-05 12:33:07 --> Total execution time: 0.0989
INFO - 2016-10-05 12:33:19 --> Config Class Initialized
INFO - 2016-10-05 12:33:19 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:33:19 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:33:19 --> Utf8 Class Initialized
INFO - 2016-10-05 12:33:19 --> URI Class Initialized
INFO - 2016-10-05 12:33:19 --> Router Class Initialized
INFO - 2016-10-05 12:33:19 --> Output Class Initialized
INFO - 2016-10-05 12:33:19 --> Security Class Initialized
DEBUG - 2016-10-05 12:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:33:19 --> Input Class Initialized
INFO - 2016-10-05 12:33:19 --> Language Class Initialized
INFO - 2016-10-05 12:33:19 --> Loader Class Initialized
INFO - 2016-10-05 12:33:19 --> Helper loaded: url_helper
INFO - 2016-10-05 12:33:19 --> Helper loaded: language_helper
INFO - 2016-10-05 12:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:33:19 --> Controller Class Initialized
INFO - 2016-10-05 12:33:19 --> Database Driver Class Initialized
INFO - 2016-10-05 12:33:19 --> Model Class Initialized
INFO - 2016-10-05 12:33:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:33:19 --> Model Class Initialized
INFO - 2016-10-05 12:33:19 --> Model Class Initialized
INFO - 2016-10-05 12:33:19 --> Helper loaded: form_helper
INFO - 2016-10-05 12:33:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:33:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:33:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:33:19 --> Final output sent to browser
DEBUG - 2016-10-05 12:33:19 --> Total execution time: 0.0886
INFO - 2016-10-05 12:34:15 --> Config Class Initialized
INFO - 2016-10-05 12:34:15 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:34:15 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:34:15 --> Utf8 Class Initialized
INFO - 2016-10-05 12:34:15 --> URI Class Initialized
INFO - 2016-10-05 12:34:15 --> Router Class Initialized
INFO - 2016-10-05 12:34:15 --> Output Class Initialized
INFO - 2016-10-05 12:34:15 --> Security Class Initialized
DEBUG - 2016-10-05 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:34:15 --> Input Class Initialized
INFO - 2016-10-05 12:34:15 --> Language Class Initialized
INFO - 2016-10-05 12:34:15 --> Loader Class Initialized
INFO - 2016-10-05 12:34:15 --> Helper loaded: url_helper
INFO - 2016-10-05 12:34:15 --> Helper loaded: language_helper
INFO - 2016-10-05 12:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:34:15 --> Controller Class Initialized
INFO - 2016-10-05 12:34:15 --> Database Driver Class Initialized
INFO - 2016-10-05 12:34:15 --> Model Class Initialized
INFO - 2016-10-05 12:34:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:34:15 --> Model Class Initialized
INFO - 2016-10-05 12:34:15 --> Model Class Initialized
INFO - 2016-10-05 12:34:15 --> Helper loaded: form_helper
INFO - 2016-10-05 12:34:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:34:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:34:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:34:15 --> Final output sent to browser
DEBUG - 2016-10-05 12:34:15 --> Total execution time: 0.0918
INFO - 2016-10-05 12:35:04 --> Config Class Initialized
INFO - 2016-10-05 12:35:04 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:35:04 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:35:04 --> Utf8 Class Initialized
INFO - 2016-10-05 12:35:04 --> URI Class Initialized
INFO - 2016-10-05 12:35:04 --> Router Class Initialized
INFO - 2016-10-05 12:35:04 --> Output Class Initialized
INFO - 2016-10-05 12:35:04 --> Security Class Initialized
DEBUG - 2016-10-05 12:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:35:04 --> Input Class Initialized
INFO - 2016-10-05 12:35:04 --> Language Class Initialized
INFO - 2016-10-05 12:35:04 --> Loader Class Initialized
INFO - 2016-10-05 12:35:04 --> Helper loaded: url_helper
INFO - 2016-10-05 12:35:04 --> Helper loaded: language_helper
INFO - 2016-10-05 12:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:35:04 --> Controller Class Initialized
INFO - 2016-10-05 12:35:04 --> Database Driver Class Initialized
INFO - 2016-10-05 12:35:04 --> Model Class Initialized
INFO - 2016-10-05 12:35:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:35:04 --> Model Class Initialized
INFO - 2016-10-05 12:35:04 --> Model Class Initialized
INFO - 2016-10-05 12:35:04 --> Helper loaded: form_helper
INFO - 2016-10-05 12:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:35:04 --> Final output sent to browser
DEBUG - 2016-10-05 12:35:04 --> Total execution time: 0.0967
INFO - 2016-10-05 12:40:04 --> Config Class Initialized
INFO - 2016-10-05 12:40:04 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:40:04 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:40:04 --> Utf8 Class Initialized
INFO - 2016-10-05 12:40:04 --> URI Class Initialized
INFO - 2016-10-05 12:40:04 --> Router Class Initialized
INFO - 2016-10-05 12:40:04 --> Output Class Initialized
INFO - 2016-10-05 12:40:04 --> Security Class Initialized
DEBUG - 2016-10-05 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:40:04 --> Input Class Initialized
INFO - 2016-10-05 12:40:04 --> Language Class Initialized
INFO - 2016-10-05 12:40:04 --> Loader Class Initialized
INFO - 2016-10-05 12:40:04 --> Helper loaded: url_helper
INFO - 2016-10-05 12:40:04 --> Helper loaded: language_helper
INFO - 2016-10-05 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:40:04 --> Controller Class Initialized
INFO - 2016-10-05 12:40:04 --> Database Driver Class Initialized
INFO - 2016-10-05 12:40:04 --> Model Class Initialized
INFO - 2016-10-05 12:40:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:40:04 --> Model Class Initialized
INFO - 2016-10-05 12:40:04 --> Model Class Initialized
INFO - 2016-10-05 12:40:04 --> Helper loaded: form_helper
INFO - 2016-10-05 12:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2016-10-05 12:40:04 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php 351
INFO - 2016-10-05 12:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:40:04 --> Final output sent to browser
DEBUG - 2016-10-05 12:40:04 --> Total execution time: 0.1084
INFO - 2016-10-05 12:40:28 --> Config Class Initialized
INFO - 2016-10-05 12:40:28 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:40:28 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:40:28 --> Utf8 Class Initialized
INFO - 2016-10-05 12:40:28 --> URI Class Initialized
INFO - 2016-10-05 12:40:28 --> Router Class Initialized
INFO - 2016-10-05 12:40:28 --> Output Class Initialized
INFO - 2016-10-05 12:40:28 --> Security Class Initialized
DEBUG - 2016-10-05 12:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:40:28 --> Input Class Initialized
INFO - 2016-10-05 12:40:28 --> Language Class Initialized
INFO - 2016-10-05 12:40:28 --> Loader Class Initialized
INFO - 2016-10-05 12:40:28 --> Helper loaded: url_helper
INFO - 2016-10-05 12:40:28 --> Helper loaded: language_helper
INFO - 2016-10-05 12:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:40:28 --> Controller Class Initialized
INFO - 2016-10-05 12:40:28 --> Database Driver Class Initialized
INFO - 2016-10-05 12:40:28 --> Model Class Initialized
INFO - 2016-10-05 12:40:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:40:28 --> Model Class Initialized
INFO - 2016-10-05 12:40:28 --> Model Class Initialized
INFO - 2016-10-05 12:40:28 --> Helper loaded: form_helper
INFO - 2016-10-05 12:40:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:40:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:40:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:40:28 --> Final output sent to browser
DEBUG - 2016-10-05 12:40:28 --> Total execution time: 0.1011
INFO - 2016-10-05 12:41:18 --> Config Class Initialized
INFO - 2016-10-05 12:41:18 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:41:18 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:41:18 --> Utf8 Class Initialized
INFO - 2016-10-05 12:41:18 --> URI Class Initialized
INFO - 2016-10-05 12:41:18 --> Router Class Initialized
INFO - 2016-10-05 12:41:18 --> Output Class Initialized
INFO - 2016-10-05 12:41:18 --> Security Class Initialized
DEBUG - 2016-10-05 12:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:41:18 --> Input Class Initialized
INFO - 2016-10-05 12:41:18 --> Language Class Initialized
INFO - 2016-10-05 12:41:18 --> Loader Class Initialized
INFO - 2016-10-05 12:41:18 --> Helper loaded: url_helper
INFO - 2016-10-05 12:41:18 --> Helper loaded: language_helper
INFO - 2016-10-05 12:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:41:18 --> Controller Class Initialized
INFO - 2016-10-05 12:41:18 --> Database Driver Class Initialized
INFO - 2016-10-05 12:41:18 --> Model Class Initialized
INFO - 2016-10-05 12:41:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:41:18 --> Model Class Initialized
INFO - 2016-10-05 12:41:18 --> Model Class Initialized
INFO - 2016-10-05 12:41:18 --> Helper loaded: form_helper
INFO - 2016-10-05 12:41:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:41:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:41:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:41:18 --> Final output sent to browser
DEBUG - 2016-10-05 12:41:18 --> Total execution time: 0.0890
INFO - 2016-10-05 12:42:17 --> Config Class Initialized
INFO - 2016-10-05 12:42:17 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:42:17 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:42:17 --> Utf8 Class Initialized
INFO - 2016-10-05 12:42:17 --> URI Class Initialized
INFO - 2016-10-05 12:42:17 --> Router Class Initialized
INFO - 2016-10-05 12:42:17 --> Output Class Initialized
INFO - 2016-10-05 12:42:17 --> Security Class Initialized
DEBUG - 2016-10-05 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:42:17 --> Input Class Initialized
INFO - 2016-10-05 12:42:17 --> Language Class Initialized
INFO - 2016-10-05 12:42:17 --> Loader Class Initialized
INFO - 2016-10-05 12:42:17 --> Helper loaded: url_helper
INFO - 2016-10-05 12:42:17 --> Helper loaded: language_helper
INFO - 2016-10-05 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:42:17 --> Controller Class Initialized
INFO - 2016-10-05 12:42:17 --> Database Driver Class Initialized
INFO - 2016-10-05 12:42:17 --> Model Class Initialized
INFO - 2016-10-05 12:42:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:42:17 --> Model Class Initialized
INFO - 2016-10-05 12:42:17 --> Model Class Initialized
INFO - 2016-10-05 12:42:17 --> Helper loaded: form_helper
INFO - 2016-10-05 12:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:42:17 --> Final output sent to browser
DEBUG - 2016-10-05 12:42:17 --> Total execution time: 0.0945
INFO - 2016-10-05 12:46:04 --> Config Class Initialized
INFO - 2016-10-05 12:46:04 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:46:04 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:46:04 --> Utf8 Class Initialized
INFO - 2016-10-05 12:46:04 --> URI Class Initialized
INFO - 2016-10-05 12:46:04 --> Router Class Initialized
INFO - 2016-10-05 12:46:04 --> Output Class Initialized
INFO - 2016-10-05 12:46:04 --> Security Class Initialized
DEBUG - 2016-10-05 12:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:46:04 --> Input Class Initialized
INFO - 2016-10-05 12:46:04 --> Language Class Initialized
INFO - 2016-10-05 12:46:04 --> Loader Class Initialized
INFO - 2016-10-05 12:46:04 --> Helper loaded: url_helper
INFO - 2016-10-05 12:46:04 --> Helper loaded: language_helper
INFO - 2016-10-05 12:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:46:04 --> Controller Class Initialized
INFO - 2016-10-05 12:46:04 --> Database Driver Class Initialized
INFO - 2016-10-05 12:46:04 --> Model Class Initialized
INFO - 2016-10-05 12:46:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:46:04 --> Model Class Initialized
INFO - 2016-10-05 12:46:04 --> Model Class Initialized
INFO - 2016-10-05 12:46:04 --> Helper loaded: form_helper
INFO - 2016-10-05 12:46:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:46:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:46:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:46:04 --> Final output sent to browser
DEBUG - 2016-10-05 12:46:04 --> Total execution time: 0.1082
INFO - 2016-10-05 12:46:36 --> Config Class Initialized
INFO - 2016-10-05 12:46:36 --> Hooks Class Initialized
DEBUG - 2016-10-05 12:46:36 --> UTF-8 Support Enabled
INFO - 2016-10-05 12:46:36 --> Utf8 Class Initialized
INFO - 2016-10-05 12:46:36 --> URI Class Initialized
INFO - 2016-10-05 12:46:36 --> Router Class Initialized
INFO - 2016-10-05 12:46:36 --> Output Class Initialized
INFO - 2016-10-05 12:46:36 --> Security Class Initialized
DEBUG - 2016-10-05 12:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 12:46:36 --> Input Class Initialized
INFO - 2016-10-05 12:46:36 --> Language Class Initialized
INFO - 2016-10-05 12:46:36 --> Loader Class Initialized
INFO - 2016-10-05 12:46:36 --> Helper loaded: url_helper
INFO - 2016-10-05 12:46:36 --> Helper loaded: language_helper
INFO - 2016-10-05 12:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 12:46:36 --> Controller Class Initialized
INFO - 2016-10-05 12:46:36 --> Database Driver Class Initialized
INFO - 2016-10-05 12:46:36 --> Model Class Initialized
INFO - 2016-10-05 12:46:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 12:46:36 --> Model Class Initialized
INFO - 2016-10-05 12:46:36 --> Model Class Initialized
INFO - 2016-10-05 12:46:36 --> Helper loaded: form_helper
INFO - 2016-10-05 12:46:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 12:46:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 12:46:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 12:46:36 --> Final output sent to browser
DEBUG - 2016-10-05 12:46:36 --> Total execution time: 0.0928
INFO - 2016-10-05 13:12:04 --> Config Class Initialized
INFO - 2016-10-05 13:12:04 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:12:04 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:12:04 --> Utf8 Class Initialized
INFO - 2016-10-05 13:12:04 --> URI Class Initialized
INFO - 2016-10-05 13:12:05 --> Router Class Initialized
INFO - 2016-10-05 13:12:05 --> Output Class Initialized
INFO - 2016-10-05 13:12:05 --> Security Class Initialized
DEBUG - 2016-10-05 13:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:12:05 --> Input Class Initialized
INFO - 2016-10-05 13:12:05 --> Language Class Initialized
INFO - 2016-10-05 13:12:05 --> Loader Class Initialized
INFO - 2016-10-05 13:12:05 --> Helper loaded: url_helper
INFO - 2016-10-05 13:12:05 --> Helper loaded: language_helper
INFO - 2016-10-05 13:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:12:05 --> Controller Class Initialized
INFO - 2016-10-05 13:12:05 --> Database Driver Class Initialized
INFO - 2016-10-05 13:12:05 --> Model Class Initialized
INFO - 2016-10-05 13:12:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:12:05 --> Model Class Initialized
INFO - 2016-10-05 13:12:05 --> Model Class Initialized
INFO - 2016-10-05 13:12:05 --> Helper loaded: form_helper
INFO - 2016-10-05 13:12:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:12:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:12:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:12:05 --> Final output sent to browser
DEBUG - 2016-10-05 13:12:05 --> Total execution time: 0.1045
INFO - 2016-10-05 13:13:05 --> Config Class Initialized
INFO - 2016-10-05 13:13:05 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:13:05 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:13:05 --> Utf8 Class Initialized
INFO - 2016-10-05 13:13:05 --> URI Class Initialized
INFO - 2016-10-05 13:13:05 --> Router Class Initialized
INFO - 2016-10-05 13:13:05 --> Output Class Initialized
INFO - 2016-10-05 13:13:05 --> Security Class Initialized
DEBUG - 2016-10-05 13:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:13:05 --> Input Class Initialized
INFO - 2016-10-05 13:13:05 --> Language Class Initialized
INFO - 2016-10-05 13:13:05 --> Loader Class Initialized
INFO - 2016-10-05 13:13:05 --> Helper loaded: url_helper
INFO - 2016-10-05 13:13:05 --> Helper loaded: language_helper
INFO - 2016-10-05 13:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:13:05 --> Controller Class Initialized
INFO - 2016-10-05 13:13:05 --> Database Driver Class Initialized
INFO - 2016-10-05 13:13:05 --> Model Class Initialized
INFO - 2016-10-05 13:13:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:13:05 --> Model Class Initialized
INFO - 2016-10-05 13:13:05 --> Model Class Initialized
INFO - 2016-10-05 13:13:05 --> Helper loaded: form_helper
INFO - 2016-10-05 13:13:26 --> Config Class Initialized
INFO - 2016-10-05 13:13:26 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:13:26 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:13:26 --> Utf8 Class Initialized
INFO - 2016-10-05 13:13:26 --> URI Class Initialized
INFO - 2016-10-05 13:13:26 --> Router Class Initialized
INFO - 2016-10-05 13:13:26 --> Output Class Initialized
INFO - 2016-10-05 13:13:26 --> Security Class Initialized
DEBUG - 2016-10-05 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:13:26 --> Input Class Initialized
INFO - 2016-10-05 13:13:26 --> Language Class Initialized
INFO - 2016-10-05 13:13:26 --> Loader Class Initialized
INFO - 2016-10-05 13:13:26 --> Helper loaded: url_helper
INFO - 2016-10-05 13:13:26 --> Helper loaded: language_helper
INFO - 2016-10-05 13:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:13:26 --> Controller Class Initialized
INFO - 2016-10-05 13:13:26 --> Database Driver Class Initialized
INFO - 2016-10-05 13:13:26 --> Model Class Initialized
INFO - 2016-10-05 13:13:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:13:26 --> Model Class Initialized
INFO - 2016-10-05 13:13:26 --> Model Class Initialized
INFO - 2016-10-05 13:13:26 --> Helper loaded: form_helper
INFO - 2016-10-05 13:13:28 --> Config Class Initialized
INFO - 2016-10-05 13:13:28 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:13:28 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:13:28 --> Utf8 Class Initialized
INFO - 2016-10-05 13:13:28 --> URI Class Initialized
INFO - 2016-10-05 13:13:28 --> Router Class Initialized
INFO - 2016-10-05 13:13:28 --> Output Class Initialized
INFO - 2016-10-05 13:13:28 --> Security Class Initialized
DEBUG - 2016-10-05 13:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:13:28 --> Input Class Initialized
INFO - 2016-10-05 13:13:28 --> Language Class Initialized
INFO - 2016-10-05 13:13:28 --> Loader Class Initialized
INFO - 2016-10-05 13:13:28 --> Helper loaded: url_helper
INFO - 2016-10-05 13:13:28 --> Helper loaded: language_helper
INFO - 2016-10-05 13:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:13:28 --> Controller Class Initialized
INFO - 2016-10-05 13:13:28 --> Database Driver Class Initialized
INFO - 2016-10-05 13:13:28 --> Model Class Initialized
INFO - 2016-10-05 13:13:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:13:28 --> Model Class Initialized
INFO - 2016-10-05 13:13:28 --> Model Class Initialized
INFO - 2016-10-05 13:13:28 --> Helper loaded: form_helper
INFO - 2016-10-05 13:13:54 --> Config Class Initialized
INFO - 2016-10-05 13:13:54 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:13:54 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:13:54 --> Utf8 Class Initialized
INFO - 2016-10-05 13:13:54 --> URI Class Initialized
INFO - 2016-10-05 13:13:54 --> Router Class Initialized
INFO - 2016-10-05 13:13:54 --> Output Class Initialized
INFO - 2016-10-05 13:13:54 --> Security Class Initialized
DEBUG - 2016-10-05 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:13:54 --> Input Class Initialized
INFO - 2016-10-05 13:13:54 --> Language Class Initialized
INFO - 2016-10-05 13:13:54 --> Loader Class Initialized
INFO - 2016-10-05 13:13:54 --> Helper loaded: url_helper
INFO - 2016-10-05 13:13:54 --> Helper loaded: language_helper
INFO - 2016-10-05 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:13:54 --> Controller Class Initialized
INFO - 2016-10-05 13:13:54 --> Database Driver Class Initialized
INFO - 2016-10-05 13:13:54 --> Model Class Initialized
INFO - 2016-10-05 13:13:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:13:54 --> Model Class Initialized
INFO - 2016-10-05 13:13:54 --> Model Class Initialized
INFO - 2016-10-05 13:13:54 --> Helper loaded: form_helper
INFO - 2016-10-05 13:14:03 --> Config Class Initialized
INFO - 2016-10-05 13:14:03 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:14:03 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:14:03 --> Utf8 Class Initialized
INFO - 2016-10-05 13:14:03 --> URI Class Initialized
INFO - 2016-10-05 13:14:03 --> Router Class Initialized
INFO - 2016-10-05 13:14:03 --> Output Class Initialized
INFO - 2016-10-05 13:14:03 --> Security Class Initialized
DEBUG - 2016-10-05 13:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:14:03 --> Input Class Initialized
INFO - 2016-10-05 13:14:03 --> Language Class Initialized
INFO - 2016-10-05 13:14:03 --> Loader Class Initialized
INFO - 2016-10-05 13:14:03 --> Helper loaded: url_helper
INFO - 2016-10-05 13:14:03 --> Helper loaded: language_helper
INFO - 2016-10-05 13:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:14:03 --> Controller Class Initialized
INFO - 2016-10-05 13:14:03 --> Database Driver Class Initialized
INFO - 2016-10-05 13:14:03 --> Model Class Initialized
INFO - 2016-10-05 13:14:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:14:03 --> Model Class Initialized
INFO - 2016-10-05 13:14:03 --> Model Class Initialized
INFO - 2016-10-05 13:14:03 --> Helper loaded: form_helper
INFO - 2016-10-05 13:14:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:14:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:14:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:14:03 --> Final output sent to browser
DEBUG - 2016-10-05 13:14:03 --> Total execution time: 0.0889
INFO - 2016-10-05 13:19:12 --> Config Class Initialized
INFO - 2016-10-05 13:19:12 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:19:12 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:19:12 --> Utf8 Class Initialized
INFO - 2016-10-05 13:19:12 --> URI Class Initialized
INFO - 2016-10-05 13:19:12 --> Router Class Initialized
INFO - 2016-10-05 13:19:12 --> Output Class Initialized
INFO - 2016-10-05 13:19:12 --> Security Class Initialized
DEBUG - 2016-10-05 13:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:19:12 --> Input Class Initialized
INFO - 2016-10-05 13:19:12 --> Language Class Initialized
INFO - 2016-10-05 13:19:12 --> Loader Class Initialized
INFO - 2016-10-05 13:19:12 --> Helper loaded: url_helper
INFO - 2016-10-05 13:19:12 --> Helper loaded: language_helper
INFO - 2016-10-05 13:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:19:12 --> Controller Class Initialized
INFO - 2016-10-05 13:19:12 --> Database Driver Class Initialized
INFO - 2016-10-05 13:19:12 --> Model Class Initialized
INFO - 2016-10-05 13:19:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:19:12 --> Model Class Initialized
INFO - 2016-10-05 13:19:12 --> Model Class Initialized
INFO - 2016-10-05 13:19:12 --> Helper loaded: form_helper
INFO - 2016-10-05 13:20:35 --> Config Class Initialized
INFO - 2016-10-05 13:20:35 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:20:35 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:20:35 --> Utf8 Class Initialized
INFO - 2016-10-05 13:20:35 --> URI Class Initialized
INFO - 2016-10-05 13:20:35 --> Router Class Initialized
INFO - 2016-10-05 13:20:35 --> Output Class Initialized
INFO - 2016-10-05 13:20:35 --> Security Class Initialized
DEBUG - 2016-10-05 13:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:20:35 --> Input Class Initialized
INFO - 2016-10-05 13:20:35 --> Language Class Initialized
INFO - 2016-10-05 13:20:35 --> Loader Class Initialized
INFO - 2016-10-05 13:20:35 --> Helper loaded: url_helper
INFO - 2016-10-05 13:20:35 --> Helper loaded: language_helper
INFO - 2016-10-05 13:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:20:35 --> Controller Class Initialized
INFO - 2016-10-05 13:20:35 --> Database Driver Class Initialized
INFO - 2016-10-05 13:20:35 --> Model Class Initialized
INFO - 2016-10-05 13:20:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:20:35 --> Model Class Initialized
INFO - 2016-10-05 13:20:35 --> Model Class Initialized
INFO - 2016-10-05 13:20:35 --> Helper loaded: form_helper
INFO - 2016-10-05 13:21:02 --> Config Class Initialized
INFO - 2016-10-05 13:21:02 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:21:02 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:21:02 --> Utf8 Class Initialized
INFO - 2016-10-05 13:21:02 --> URI Class Initialized
INFO - 2016-10-05 13:21:02 --> Router Class Initialized
INFO - 2016-10-05 13:21:02 --> Output Class Initialized
INFO - 2016-10-05 13:21:02 --> Security Class Initialized
DEBUG - 2016-10-05 13:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:21:02 --> Input Class Initialized
INFO - 2016-10-05 13:21:02 --> Language Class Initialized
INFO - 2016-10-05 13:21:02 --> Loader Class Initialized
INFO - 2016-10-05 13:21:02 --> Helper loaded: url_helper
INFO - 2016-10-05 13:21:02 --> Helper loaded: language_helper
INFO - 2016-10-05 13:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:21:02 --> Controller Class Initialized
INFO - 2016-10-05 13:21:02 --> Database Driver Class Initialized
INFO - 2016-10-05 13:21:02 --> Model Class Initialized
INFO - 2016-10-05 13:21:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:21:02 --> Model Class Initialized
INFO - 2016-10-05 13:21:02 --> Model Class Initialized
INFO - 2016-10-05 13:21:02 --> Helper loaded: form_helper
ERROR - 2016-10-05 13:21:02 --> Query error: Unknown column 'CSID' in 'where clause' - Invalid query: SELECT norma FROM disc_norma where norma = CSID 
INFO - 2016-10-05 13:21:02 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-10-05 13:21:29 --> Config Class Initialized
INFO - 2016-10-05 13:21:29 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:21:29 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:21:29 --> Utf8 Class Initialized
INFO - 2016-10-05 13:21:29 --> URI Class Initialized
INFO - 2016-10-05 13:21:29 --> Router Class Initialized
INFO - 2016-10-05 13:21:29 --> Output Class Initialized
INFO - 2016-10-05 13:21:29 --> Security Class Initialized
DEBUG - 2016-10-05 13:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:21:29 --> Input Class Initialized
INFO - 2016-10-05 13:21:29 --> Language Class Initialized
INFO - 2016-10-05 13:21:29 --> Loader Class Initialized
INFO - 2016-10-05 13:21:29 --> Helper loaded: url_helper
INFO - 2016-10-05 13:21:29 --> Helper loaded: language_helper
INFO - 2016-10-05 13:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:21:29 --> Controller Class Initialized
INFO - 2016-10-05 13:21:29 --> Database Driver Class Initialized
INFO - 2016-10-05 13:21:29 --> Model Class Initialized
INFO - 2016-10-05 13:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:21:29 --> Model Class Initialized
INFO - 2016-10-05 13:21:29 --> Model Class Initialized
INFO - 2016-10-05 13:21:29 --> Helper loaded: form_helper
INFO - 2016-10-05 13:21:57 --> Config Class Initialized
INFO - 2016-10-05 13:21:57 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:21:57 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:21:57 --> Utf8 Class Initialized
INFO - 2016-10-05 13:21:57 --> URI Class Initialized
INFO - 2016-10-05 13:21:57 --> Router Class Initialized
INFO - 2016-10-05 13:21:57 --> Output Class Initialized
INFO - 2016-10-05 13:21:57 --> Security Class Initialized
DEBUG - 2016-10-05 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:21:57 --> Input Class Initialized
INFO - 2016-10-05 13:21:57 --> Language Class Initialized
INFO - 2016-10-05 13:21:57 --> Loader Class Initialized
INFO - 2016-10-05 13:21:57 --> Helper loaded: url_helper
INFO - 2016-10-05 13:21:57 --> Helper loaded: language_helper
INFO - 2016-10-05 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:21:57 --> Controller Class Initialized
INFO - 2016-10-05 13:21:57 --> Database Driver Class Initialized
INFO - 2016-10-05 13:21:57 --> Model Class Initialized
INFO - 2016-10-05 13:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:21:57 --> Model Class Initialized
INFO - 2016-10-05 13:21:57 --> Model Class Initialized
INFO - 2016-10-05 13:21:57 --> Helper loaded: form_helper
INFO - 2016-10-05 13:21:58 --> Config Class Initialized
INFO - 2016-10-05 13:21:58 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:21:58 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:21:58 --> Utf8 Class Initialized
INFO - 2016-10-05 13:21:58 --> URI Class Initialized
INFO - 2016-10-05 13:21:58 --> Router Class Initialized
INFO - 2016-10-05 13:21:58 --> Output Class Initialized
INFO - 2016-10-05 13:21:58 --> Security Class Initialized
DEBUG - 2016-10-05 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:21:58 --> Input Class Initialized
INFO - 2016-10-05 13:21:58 --> Language Class Initialized
INFO - 2016-10-05 13:21:58 --> Loader Class Initialized
INFO - 2016-10-05 13:21:58 --> Helper loaded: url_helper
INFO - 2016-10-05 13:21:58 --> Helper loaded: language_helper
INFO - 2016-10-05 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:21:58 --> Controller Class Initialized
INFO - 2016-10-05 13:21:58 --> Database Driver Class Initialized
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Helper loaded: form_helper
INFO - 2016-10-05 13:21:58 --> Config Class Initialized
INFO - 2016-10-05 13:21:58 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:21:58 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:21:58 --> Utf8 Class Initialized
INFO - 2016-10-05 13:21:58 --> URI Class Initialized
INFO - 2016-10-05 13:21:58 --> Router Class Initialized
INFO - 2016-10-05 13:21:58 --> Output Class Initialized
INFO - 2016-10-05 13:21:58 --> Security Class Initialized
DEBUG - 2016-10-05 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:21:58 --> Input Class Initialized
INFO - 2016-10-05 13:21:58 --> Language Class Initialized
INFO - 2016-10-05 13:21:58 --> Loader Class Initialized
INFO - 2016-10-05 13:21:58 --> Helper loaded: url_helper
INFO - 2016-10-05 13:21:58 --> Helper loaded: language_helper
INFO - 2016-10-05 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:21:58 --> Controller Class Initialized
INFO - 2016-10-05 13:21:58 --> Database Driver Class Initialized
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Helper loaded: form_helper
INFO - 2016-10-05 13:21:58 --> Config Class Initialized
INFO - 2016-10-05 13:21:58 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:21:58 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:21:58 --> Utf8 Class Initialized
INFO - 2016-10-05 13:21:58 --> URI Class Initialized
INFO - 2016-10-05 13:21:58 --> Router Class Initialized
INFO - 2016-10-05 13:21:58 --> Output Class Initialized
INFO - 2016-10-05 13:21:58 --> Security Class Initialized
DEBUG - 2016-10-05 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:21:58 --> Input Class Initialized
INFO - 2016-10-05 13:21:58 --> Language Class Initialized
INFO - 2016-10-05 13:21:58 --> Loader Class Initialized
INFO - 2016-10-05 13:21:58 --> Helper loaded: url_helper
INFO - 2016-10-05 13:21:58 --> Helper loaded: language_helper
INFO - 2016-10-05 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:21:58 --> Controller Class Initialized
INFO - 2016-10-05 13:21:58 --> Database Driver Class Initialized
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Model Class Initialized
INFO - 2016-10-05 13:21:58 --> Helper loaded: form_helper
INFO - 2016-10-05 13:22:14 --> Config Class Initialized
INFO - 2016-10-05 13:22:14 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:22:14 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:22:14 --> Utf8 Class Initialized
INFO - 2016-10-05 13:22:14 --> URI Class Initialized
INFO - 2016-10-05 13:22:14 --> Router Class Initialized
INFO - 2016-10-05 13:22:14 --> Output Class Initialized
INFO - 2016-10-05 13:22:14 --> Security Class Initialized
DEBUG - 2016-10-05 13:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:22:14 --> Input Class Initialized
INFO - 2016-10-05 13:22:14 --> Language Class Initialized
INFO - 2016-10-05 13:22:14 --> Loader Class Initialized
INFO - 2016-10-05 13:22:14 --> Helper loaded: url_helper
INFO - 2016-10-05 13:22:14 --> Helper loaded: language_helper
INFO - 2016-10-05 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:22:14 --> Controller Class Initialized
INFO - 2016-10-05 13:22:14 --> Database Driver Class Initialized
INFO - 2016-10-05 13:22:14 --> Model Class Initialized
INFO - 2016-10-05 13:22:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:22:14 --> Model Class Initialized
INFO - 2016-10-05 13:22:14 --> Model Class Initialized
INFO - 2016-10-05 13:22:14 --> Helper loaded: form_helper
ERROR - 2016-10-05 13:22:14 --> Query error: Unknown column 'CSID' in 'where clause' - Invalid query: SELECT norma FROM disc_norma where norma = CSID
INFO - 2016-10-05 13:22:14 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-10-05 13:24:02 --> Config Class Initialized
INFO - 2016-10-05 13:24:02 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:24:02 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:24:02 --> Utf8 Class Initialized
INFO - 2016-10-05 13:24:02 --> URI Class Initialized
INFO - 2016-10-05 13:24:02 --> Router Class Initialized
INFO - 2016-10-05 13:24:02 --> Output Class Initialized
INFO - 2016-10-05 13:24:02 --> Security Class Initialized
DEBUG - 2016-10-05 13:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:24:02 --> Input Class Initialized
INFO - 2016-10-05 13:24:02 --> Language Class Initialized
INFO - 2016-10-05 13:24:02 --> Loader Class Initialized
INFO - 2016-10-05 13:24:02 --> Helper loaded: url_helper
INFO - 2016-10-05 13:24:02 --> Helper loaded: language_helper
INFO - 2016-10-05 13:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:24:02 --> Controller Class Initialized
INFO - 2016-10-05 13:24:02 --> Database Driver Class Initialized
INFO - 2016-10-05 13:24:02 --> Model Class Initialized
INFO - 2016-10-05 13:24:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:24:02 --> Model Class Initialized
INFO - 2016-10-05 13:24:02 --> Model Class Initialized
INFO - 2016-10-05 13:24:02 --> Helper loaded: form_helper
ERROR - 2016-10-05 13:24:02 --> Query error: Unknown column 'CSID' in 'where clause' - Invalid query: SELECT norma FROM disc_norma where type = CSID
INFO - 2016-10-05 13:24:02 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2016-10-05 13:24:39 --> Config Class Initialized
INFO - 2016-10-05 13:24:39 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:24:39 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:24:39 --> Utf8 Class Initialized
INFO - 2016-10-05 13:24:39 --> URI Class Initialized
INFO - 2016-10-05 13:24:39 --> Router Class Initialized
INFO - 2016-10-05 13:24:39 --> Output Class Initialized
INFO - 2016-10-05 13:24:39 --> Security Class Initialized
DEBUG - 2016-10-05 13:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:24:39 --> Input Class Initialized
INFO - 2016-10-05 13:24:39 --> Language Class Initialized
INFO - 2016-10-05 13:24:39 --> Loader Class Initialized
INFO - 2016-10-05 13:24:39 --> Helper loaded: url_helper
INFO - 2016-10-05 13:24:39 --> Helper loaded: language_helper
INFO - 2016-10-05 13:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:24:39 --> Controller Class Initialized
INFO - 2016-10-05 13:24:39 --> Database Driver Class Initialized
INFO - 2016-10-05 13:24:39 --> Model Class Initialized
INFO - 2016-10-05 13:24:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:24:39 --> Model Class Initialized
INFO - 2016-10-05 13:24:39 --> Model Class Initialized
INFO - 2016-10-05 13:24:39 --> Helper loaded: form_helper
INFO - 2016-10-05 13:25:16 --> Config Class Initialized
INFO - 2016-10-05 13:25:16 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:25:16 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:25:16 --> Utf8 Class Initialized
INFO - 2016-10-05 13:25:16 --> URI Class Initialized
INFO - 2016-10-05 13:25:16 --> Router Class Initialized
INFO - 2016-10-05 13:25:16 --> Output Class Initialized
INFO - 2016-10-05 13:25:16 --> Security Class Initialized
DEBUG - 2016-10-05 13:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:25:16 --> Input Class Initialized
INFO - 2016-10-05 13:25:16 --> Language Class Initialized
INFO - 2016-10-05 13:25:16 --> Loader Class Initialized
INFO - 2016-10-05 13:25:16 --> Helper loaded: url_helper
INFO - 2016-10-05 13:25:16 --> Helper loaded: language_helper
INFO - 2016-10-05 13:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:25:16 --> Controller Class Initialized
INFO - 2016-10-05 13:25:16 --> Database Driver Class Initialized
INFO - 2016-10-05 13:25:16 --> Model Class Initialized
INFO - 2016-10-05 13:25:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:25:16 --> Model Class Initialized
INFO - 2016-10-05 13:25:16 --> Model Class Initialized
INFO - 2016-10-05 13:25:16 --> Helper loaded: form_helper
INFO - 2016-10-05 13:25:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:25:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:25:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:25:16 --> Final output sent to browser
DEBUG - 2016-10-05 13:25:16 --> Total execution time: 0.0908
INFO - 2016-10-05 13:41:32 --> Config Class Initialized
INFO - 2016-10-05 13:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:41:32 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:41:32 --> Utf8 Class Initialized
INFO - 2016-10-05 13:41:32 --> URI Class Initialized
INFO - 2016-10-05 13:41:32 --> Router Class Initialized
INFO - 2016-10-05 13:41:32 --> Output Class Initialized
INFO - 2016-10-05 13:41:32 --> Security Class Initialized
DEBUG - 2016-10-05 13:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:41:32 --> Input Class Initialized
INFO - 2016-10-05 13:41:32 --> Language Class Initialized
INFO - 2016-10-05 13:41:32 --> Loader Class Initialized
INFO - 2016-10-05 13:41:32 --> Helper loaded: url_helper
INFO - 2016-10-05 13:41:32 --> Helper loaded: language_helper
INFO - 2016-10-05 13:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:41:32 --> Controller Class Initialized
INFO - 2016-10-05 13:41:32 --> Database Driver Class Initialized
INFO - 2016-10-05 13:41:32 --> Model Class Initialized
INFO - 2016-10-05 13:41:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:41:32 --> Model Class Initialized
INFO - 2016-10-05 13:41:32 --> Model Class Initialized
INFO - 2016-10-05 13:41:32 --> Helper loaded: form_helper
INFO - 2016-10-05 13:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:41:32 --> Final output sent to browser
DEBUG - 2016-10-05 13:41:32 --> Total execution time: 0.1245
INFO - 2016-10-05 13:41:47 --> Config Class Initialized
INFO - 2016-10-05 13:41:47 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:41:47 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:41:47 --> Utf8 Class Initialized
INFO - 2016-10-05 13:41:47 --> URI Class Initialized
INFO - 2016-10-05 13:41:47 --> Router Class Initialized
INFO - 2016-10-05 13:41:47 --> Output Class Initialized
INFO - 2016-10-05 13:41:47 --> Security Class Initialized
DEBUG - 2016-10-05 13:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:41:47 --> Input Class Initialized
INFO - 2016-10-05 13:41:47 --> Language Class Initialized
INFO - 2016-10-05 13:41:47 --> Loader Class Initialized
INFO - 2016-10-05 13:41:47 --> Helper loaded: url_helper
INFO - 2016-10-05 13:41:47 --> Helper loaded: language_helper
INFO - 2016-10-05 13:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:41:47 --> Controller Class Initialized
INFO - 2016-10-05 13:41:47 --> Database Driver Class Initialized
INFO - 2016-10-05 13:41:47 --> Model Class Initialized
INFO - 2016-10-05 13:41:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:41:47 --> Model Class Initialized
INFO - 2016-10-05 13:41:47 --> Model Class Initialized
INFO - 2016-10-05 13:41:47 --> Helper loaded: form_helper
INFO - 2016-10-05 13:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:41:47 --> Final output sent to browser
DEBUG - 2016-10-05 13:41:47 --> Total execution time: 0.0968
INFO - 2016-10-05 13:42:01 --> Config Class Initialized
INFO - 2016-10-05 13:42:01 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:42:01 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:42:01 --> Utf8 Class Initialized
INFO - 2016-10-05 13:42:01 --> URI Class Initialized
INFO - 2016-10-05 13:42:01 --> Router Class Initialized
INFO - 2016-10-05 13:42:01 --> Output Class Initialized
INFO - 2016-10-05 13:42:01 --> Security Class Initialized
DEBUG - 2016-10-05 13:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:42:01 --> Input Class Initialized
INFO - 2016-10-05 13:42:01 --> Language Class Initialized
INFO - 2016-10-05 13:42:01 --> Loader Class Initialized
INFO - 2016-10-05 13:42:01 --> Helper loaded: url_helper
INFO - 2016-10-05 13:42:01 --> Helper loaded: language_helper
INFO - 2016-10-05 13:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:42:01 --> Controller Class Initialized
INFO - 2016-10-05 13:42:01 --> Database Driver Class Initialized
INFO - 2016-10-05 13:42:01 --> Model Class Initialized
INFO - 2016-10-05 13:42:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:42:01 --> Model Class Initialized
INFO - 2016-10-05 13:42:01 --> Model Class Initialized
INFO - 2016-10-05 13:42:01 --> Helper loaded: form_helper
INFO - 2016-10-05 13:42:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:42:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:42:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:42:01 --> Final output sent to browser
DEBUG - 2016-10-05 13:42:01 --> Total execution time: 0.1010
INFO - 2016-10-05 13:42:29 --> Config Class Initialized
INFO - 2016-10-05 13:42:29 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:42:29 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:42:29 --> Utf8 Class Initialized
INFO - 2016-10-05 13:42:29 --> URI Class Initialized
INFO - 2016-10-05 13:42:29 --> Router Class Initialized
INFO - 2016-10-05 13:42:29 --> Output Class Initialized
INFO - 2016-10-05 13:42:29 --> Security Class Initialized
DEBUG - 2016-10-05 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:42:29 --> Input Class Initialized
INFO - 2016-10-05 13:42:29 --> Language Class Initialized
INFO - 2016-10-05 13:42:29 --> Loader Class Initialized
INFO - 2016-10-05 13:42:29 --> Helper loaded: url_helper
INFO - 2016-10-05 13:42:29 --> Helper loaded: language_helper
INFO - 2016-10-05 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:42:29 --> Controller Class Initialized
INFO - 2016-10-05 13:42:29 --> Database Driver Class Initialized
INFO - 2016-10-05 13:42:29 --> Model Class Initialized
INFO - 2016-10-05 13:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:42:29 --> Model Class Initialized
INFO - 2016-10-05 13:42:29 --> Model Class Initialized
INFO - 2016-10-05 13:42:29 --> Helper loaded: form_helper
INFO - 2016-10-05 13:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:42:29 --> Final output sent to browser
DEBUG - 2016-10-05 13:42:29 --> Total execution time: 0.1013
INFO - 2016-10-05 13:46:47 --> Config Class Initialized
INFO - 2016-10-05 13:46:47 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:46:47 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:46:47 --> Utf8 Class Initialized
INFO - 2016-10-05 13:46:47 --> URI Class Initialized
INFO - 2016-10-05 13:46:47 --> Router Class Initialized
INFO - 2016-10-05 13:46:47 --> Output Class Initialized
INFO - 2016-10-05 13:46:47 --> Security Class Initialized
DEBUG - 2016-10-05 13:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:46:47 --> Input Class Initialized
INFO - 2016-10-05 13:46:47 --> Language Class Initialized
INFO - 2016-10-05 13:46:47 --> Loader Class Initialized
INFO - 2016-10-05 13:46:47 --> Helper loaded: url_helper
INFO - 2016-10-05 13:46:47 --> Helper loaded: language_helper
INFO - 2016-10-05 13:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:46:47 --> Controller Class Initialized
INFO - 2016-10-05 13:46:47 --> Database Driver Class Initialized
INFO - 2016-10-05 13:46:47 --> Model Class Initialized
INFO - 2016-10-05 13:46:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:46:47 --> Model Class Initialized
INFO - 2016-10-05 13:46:47 --> Model Class Initialized
INFO - 2016-10-05 13:46:47 --> Helper loaded: form_helper
INFO - 2016-10-05 13:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:46:47 --> Final output sent to browser
DEBUG - 2016-10-05 13:46:47 --> Total execution time: 0.1203
INFO - 2016-10-05 13:47:25 --> Config Class Initialized
INFO - 2016-10-05 13:47:25 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:47:25 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:47:25 --> Utf8 Class Initialized
INFO - 2016-10-05 13:47:25 --> URI Class Initialized
INFO - 2016-10-05 13:47:25 --> Router Class Initialized
INFO - 2016-10-05 13:47:25 --> Output Class Initialized
INFO - 2016-10-05 13:47:25 --> Security Class Initialized
DEBUG - 2016-10-05 13:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:47:25 --> Input Class Initialized
INFO - 2016-10-05 13:47:25 --> Language Class Initialized
INFO - 2016-10-05 13:47:25 --> Loader Class Initialized
INFO - 2016-10-05 13:47:25 --> Helper loaded: url_helper
INFO - 2016-10-05 13:47:25 --> Helper loaded: language_helper
INFO - 2016-10-05 13:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:47:25 --> Controller Class Initialized
INFO - 2016-10-05 13:47:25 --> Database Driver Class Initialized
INFO - 2016-10-05 13:47:25 --> Model Class Initialized
INFO - 2016-10-05 13:47:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:47:25 --> Model Class Initialized
INFO - 2016-10-05 13:47:25 --> Model Class Initialized
INFO - 2016-10-05 13:47:25 --> Helper loaded: form_helper
INFO - 2016-10-05 13:47:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:47:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:47:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:47:25 --> Final output sent to browser
DEBUG - 2016-10-05 13:47:25 --> Total execution time: 0.1183
INFO - 2016-10-05 13:48:23 --> Config Class Initialized
INFO - 2016-10-05 13:48:23 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:48:23 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:48:23 --> Utf8 Class Initialized
INFO - 2016-10-05 13:48:23 --> URI Class Initialized
INFO - 2016-10-05 13:48:23 --> Router Class Initialized
INFO - 2016-10-05 13:48:23 --> Output Class Initialized
INFO - 2016-10-05 13:48:23 --> Security Class Initialized
DEBUG - 2016-10-05 13:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:48:23 --> Input Class Initialized
INFO - 2016-10-05 13:48:23 --> Language Class Initialized
INFO - 2016-10-05 13:48:23 --> Loader Class Initialized
INFO - 2016-10-05 13:48:23 --> Helper loaded: url_helper
INFO - 2016-10-05 13:48:23 --> Helper loaded: language_helper
INFO - 2016-10-05 13:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:48:23 --> Controller Class Initialized
INFO - 2016-10-05 13:48:23 --> Database Driver Class Initialized
INFO - 2016-10-05 13:48:23 --> Model Class Initialized
INFO - 2016-10-05 13:48:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:48:23 --> Model Class Initialized
INFO - 2016-10-05 13:48:23 --> Model Class Initialized
INFO - 2016-10-05 13:48:23 --> Helper loaded: form_helper
INFO - 2016-10-05 13:48:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:48:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:48:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:48:23 --> Final output sent to browser
DEBUG - 2016-10-05 13:48:23 --> Total execution time: 0.0941
INFO - 2016-10-05 13:50:26 --> Config Class Initialized
INFO - 2016-10-05 13:50:26 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:50:26 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:50:26 --> Utf8 Class Initialized
INFO - 2016-10-05 13:50:26 --> URI Class Initialized
INFO - 2016-10-05 13:50:26 --> Router Class Initialized
INFO - 2016-10-05 13:50:26 --> Output Class Initialized
INFO - 2016-10-05 13:50:26 --> Security Class Initialized
DEBUG - 2016-10-05 13:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:50:26 --> Input Class Initialized
INFO - 2016-10-05 13:50:26 --> Language Class Initialized
INFO - 2016-10-05 13:50:26 --> Loader Class Initialized
INFO - 2016-10-05 13:50:26 --> Helper loaded: url_helper
INFO - 2016-10-05 13:50:26 --> Helper loaded: language_helper
INFO - 2016-10-05 13:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:50:26 --> Controller Class Initialized
INFO - 2016-10-05 13:50:26 --> Database Driver Class Initialized
INFO - 2016-10-05 13:50:26 --> Model Class Initialized
INFO - 2016-10-05 13:50:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:50:26 --> Model Class Initialized
INFO - 2016-10-05 13:50:26 --> Model Class Initialized
INFO - 2016-10-05 13:50:26 --> Helper loaded: form_helper
INFO - 2016-10-05 13:50:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:50:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:50:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:50:26 --> Final output sent to browser
DEBUG - 2016-10-05 13:50:26 --> Total execution time: 0.0930
INFO - 2016-10-05 13:51:27 --> Config Class Initialized
INFO - 2016-10-05 13:51:27 --> Hooks Class Initialized
DEBUG - 2016-10-05 13:51:27 --> UTF-8 Support Enabled
INFO - 2016-10-05 13:51:27 --> Utf8 Class Initialized
INFO - 2016-10-05 13:51:27 --> URI Class Initialized
INFO - 2016-10-05 13:51:27 --> Router Class Initialized
INFO - 2016-10-05 13:51:27 --> Output Class Initialized
INFO - 2016-10-05 13:51:27 --> Security Class Initialized
DEBUG - 2016-10-05 13:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-05 13:51:27 --> Input Class Initialized
INFO - 2016-10-05 13:51:27 --> Language Class Initialized
INFO - 2016-10-05 13:51:27 --> Loader Class Initialized
INFO - 2016-10-05 13:51:27 --> Helper loaded: url_helper
INFO - 2016-10-05 13:51:27 --> Helper loaded: language_helper
INFO - 2016-10-05 13:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-05 13:51:27 --> Controller Class Initialized
INFO - 2016-10-05 13:51:27 --> Database Driver Class Initialized
INFO - 2016-10-05 13:51:27 --> Model Class Initialized
INFO - 2016-10-05 13:51:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-05 13:51:27 --> Model Class Initialized
INFO - 2016-10-05 13:51:27 --> Model Class Initialized
INFO - 2016-10-05 13:51:27 --> Helper loaded: form_helper
INFO - 2016-10-05 13:51:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-05 13:51:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-05 13:51:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-05 13:51:27 --> Final output sent to browser
DEBUG - 2016-10-05 13:51:27 --> Total execution time: 0.0994
