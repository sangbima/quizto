<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-20 08:55:14 --> Config Class Initialized
INFO - 2016-10-20 08:55:14 --> Hooks Class Initialized
DEBUG - 2016-10-20 08:55:14 --> UTF-8 Support Enabled
INFO - 2016-10-20 08:55:14 --> Utf8 Class Initialized
INFO - 2016-10-20 08:55:14 --> URI Class Initialized
INFO - 2016-10-20 08:55:14 --> Router Class Initialized
INFO - 2016-10-20 08:55:14 --> Output Class Initialized
INFO - 2016-10-20 08:55:14 --> Security Class Initialized
DEBUG - 2016-10-20 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-20 08:55:14 --> Input Class Initialized
INFO - 2016-10-20 08:55:14 --> Language Class Initialized
INFO - 2016-10-20 08:55:14 --> Loader Class Initialized
INFO - 2016-10-20 08:55:14 --> Helper loaded: url_helper
INFO - 2016-10-20 08:55:14 --> Helper loaded: language_helper
INFO - 2016-10-20 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-20 08:55:14 --> Controller Class Initialized
INFO - 2016-10-20 08:55:14 --> Database Driver Class Initialized
INFO - 2016-10-20 08:55:14 --> Model Class Initialized
INFO - 2016-10-20 08:55:14 --> Model Class Initialized
INFO - 2016-10-20 08:55:14 --> Model Class Initialized
INFO - 2016-10-20 08:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-20 08:55:14 --> Config Class Initialized
INFO - 2016-10-20 08:55:14 --> Hooks Class Initialized
DEBUG - 2016-10-20 08:55:14 --> UTF-8 Support Enabled
INFO - 2016-10-20 08:55:14 --> Utf8 Class Initialized
INFO - 2016-10-20 08:55:14 --> URI Class Initialized
INFO - 2016-10-20 08:55:14 --> Router Class Initialized
INFO - 2016-10-20 08:55:14 --> Output Class Initialized
INFO - 2016-10-20 08:55:14 --> Security Class Initialized
DEBUG - 2016-10-20 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-20 08:55:14 --> Input Class Initialized
INFO - 2016-10-20 08:55:14 --> Language Class Initialized
INFO - 2016-10-20 08:55:14 --> Loader Class Initialized
INFO - 2016-10-20 08:55:14 --> Helper loaded: url_helper
INFO - 2016-10-20 08:55:14 --> Helper loaded: language_helper
INFO - 2016-10-20 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-20 08:55:14 --> Controller Class Initialized
INFO - 2016-10-20 08:55:14 --> Database Driver Class Initialized
INFO - 2016-10-20 08:55:14 --> Model Class Initialized
INFO - 2016-10-20 08:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-20 08:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-20 08:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-20 08:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-20 08:55:14 --> Final output sent to browser
DEBUG - 2016-10-20 08:55:14 --> Total execution time: 0.0496
INFO - 2016-10-20 08:56:05 --> Config Class Initialized
INFO - 2016-10-20 08:56:05 --> Hooks Class Initialized
DEBUG - 2016-10-20 08:56:05 --> UTF-8 Support Enabled
INFO - 2016-10-20 08:56:05 --> Utf8 Class Initialized
INFO - 2016-10-20 08:56:05 --> URI Class Initialized
DEBUG - 2016-10-20 08:56:05 --> No URI present. Default controller set.
INFO - 2016-10-20 08:56:05 --> Router Class Initialized
INFO - 2016-10-20 08:56:05 --> Output Class Initialized
INFO - 2016-10-20 08:56:05 --> Security Class Initialized
DEBUG - 2016-10-20 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-20 08:56:05 --> Input Class Initialized
INFO - 2016-10-20 08:56:05 --> Language Class Initialized
INFO - 2016-10-20 08:56:05 --> Loader Class Initialized
INFO - 2016-10-20 08:56:05 --> Helper loaded: url_helper
INFO - 2016-10-20 08:56:05 --> Helper loaded: language_helper
INFO - 2016-10-20 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-20 08:56:05 --> Controller Class Initialized
INFO - 2016-10-20 08:56:05 --> Database Driver Class Initialized
INFO - 2016-10-20 08:56:05 --> Model Class Initialized
INFO - 2016-10-20 08:56:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-20 08:56:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-20 08:56:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-20 08:56:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-20 08:56:05 --> Final output sent to browser
DEBUG - 2016-10-20 08:56:05 --> Total execution time: 0.0487
INFO - 2016-10-20 17:49:04 --> Config Class Initialized
INFO - 2016-10-20 17:49:04 --> Hooks Class Initialized
DEBUG - 2016-10-20 17:49:04 --> UTF-8 Support Enabled
INFO - 2016-10-20 17:49:04 --> Utf8 Class Initialized
INFO - 2016-10-20 17:49:04 --> URI Class Initialized
INFO - 2016-10-20 17:49:04 --> Router Class Initialized
INFO - 2016-10-20 17:49:04 --> Output Class Initialized
INFO - 2016-10-20 17:49:04 --> Security Class Initialized
DEBUG - 2016-10-20 17:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-20 17:49:04 --> Input Class Initialized
INFO - 2016-10-20 17:49:04 --> Language Class Initialized
INFO - 2016-10-20 17:49:04 --> Loader Class Initialized
INFO - 2016-10-20 17:49:04 --> Helper loaded: url_helper
INFO - 2016-10-20 17:49:04 --> Helper loaded: language_helper
INFO - 2016-10-20 17:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-20 17:49:04 --> Controller Class Initialized
INFO - 2016-10-20 17:49:04 --> Database Driver Class Initialized
INFO - 2016-10-20 17:49:04 --> Model Class Initialized
INFO - 2016-10-20 17:49:04 --> Model Class Initialized
INFO - 2016-10-20 17:49:04 --> Model Class Initialized
INFO - 2016-10-20 17:49:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-20 17:49:04 --> Config Class Initialized
INFO - 2016-10-20 17:49:04 --> Hooks Class Initialized
DEBUG - 2016-10-20 17:49:04 --> UTF-8 Support Enabled
INFO - 2016-10-20 17:49:04 --> Utf8 Class Initialized
INFO - 2016-10-20 17:49:04 --> URI Class Initialized
INFO - 2016-10-20 17:49:04 --> Router Class Initialized
INFO - 2016-10-20 17:49:04 --> Output Class Initialized
INFO - 2016-10-20 17:49:04 --> Security Class Initialized
DEBUG - 2016-10-20 17:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-20 17:49:04 --> Input Class Initialized
INFO - 2016-10-20 17:49:04 --> Language Class Initialized
INFO - 2016-10-20 17:49:04 --> Loader Class Initialized
INFO - 2016-10-20 17:49:04 --> Helper loaded: url_helper
INFO - 2016-10-20 17:49:04 --> Helper loaded: language_helper
INFO - 2016-10-20 17:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-20 17:49:04 --> Controller Class Initialized
INFO - 2016-10-20 17:49:04 --> Database Driver Class Initialized
INFO - 2016-10-20 17:49:04 --> Model Class Initialized
INFO - 2016-10-20 17:49:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-20 17:49:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-20 17:49:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-20 17:49:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-20 17:49:04 --> Final output sent to browser
DEBUG - 2016-10-20 17:49:04 --> Total execution time: 0.0573
