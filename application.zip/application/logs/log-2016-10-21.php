<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-21 12:36:42 --> Config Class Initialized
INFO - 2016-10-21 12:36:42 --> Hooks Class Initialized
DEBUG - 2016-10-21 12:36:42 --> UTF-8 Support Enabled
INFO - 2016-10-21 12:36:42 --> Utf8 Class Initialized
INFO - 2016-10-21 12:36:42 --> URI Class Initialized
INFO - 2016-10-21 12:36:42 --> Router Class Initialized
INFO - 2016-10-21 12:36:42 --> Output Class Initialized
INFO - 2016-10-21 12:36:42 --> Security Class Initialized
DEBUG - 2016-10-21 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 12:36:42 --> Input Class Initialized
INFO - 2016-10-21 12:36:42 --> Language Class Initialized
INFO - 2016-10-21 12:36:42 --> Loader Class Initialized
INFO - 2016-10-21 12:36:42 --> Helper loaded: url_helper
INFO - 2016-10-21 12:36:42 --> Helper loaded: language_helper
INFO - 2016-10-21 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 12:36:42 --> Controller Class Initialized
INFO - 2016-10-21 12:36:42 --> Database Driver Class Initialized
INFO - 2016-10-21 12:36:42 --> Model Class Initialized
INFO - 2016-10-21 12:36:42 --> Model Class Initialized
INFO - 2016-10-21 12:36:42 --> Model Class Initialized
INFO - 2016-10-21 12:36:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-21 12:36:42 --> Config Class Initialized
INFO - 2016-10-21 12:36:42 --> Hooks Class Initialized
DEBUG - 2016-10-21 12:36:42 --> UTF-8 Support Enabled
INFO - 2016-10-21 12:36:42 --> Utf8 Class Initialized
INFO - 2016-10-21 12:36:42 --> URI Class Initialized
INFO - 2016-10-21 12:36:42 --> Router Class Initialized
INFO - 2016-10-21 12:36:42 --> Output Class Initialized
INFO - 2016-10-21 12:36:42 --> Security Class Initialized
DEBUG - 2016-10-21 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 12:36:42 --> Input Class Initialized
INFO - 2016-10-21 12:36:42 --> Language Class Initialized
INFO - 2016-10-21 12:36:42 --> Loader Class Initialized
INFO - 2016-10-21 12:36:42 --> Helper loaded: url_helper
INFO - 2016-10-21 12:36:42 --> Helper loaded: language_helper
INFO - 2016-10-21 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 12:36:42 --> Controller Class Initialized
INFO - 2016-10-21 12:36:42 --> Database Driver Class Initialized
INFO - 2016-10-21 12:36:42 --> Model Class Initialized
INFO - 2016-10-21 12:36:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-21 12:36:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-21 12:36:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-21 12:36:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-21 12:36:42 --> Final output sent to browser
DEBUG - 2016-10-21 12:36:42 --> Total execution time: 0.0775
