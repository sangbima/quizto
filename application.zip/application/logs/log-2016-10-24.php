<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-24 15:17:33 --> Config Class Initialized
INFO - 2016-10-24 15:17:33 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:33 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:33 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:33 --> URI Class Initialized
INFO - 2016-10-24 15:17:33 --> Router Class Initialized
INFO - 2016-10-24 15:17:33 --> Output Class Initialized
INFO - 2016-10-24 15:17:33 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:33 --> Input Class Initialized
INFO - 2016-10-24 15:17:33 --> Language Class Initialized
INFO - 2016-10-24 15:17:33 --> Loader Class Initialized
INFO - 2016-10-24 15:17:33 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:33 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:33 --> Controller Class Initialized
INFO - 2016-10-24 15:17:33 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:33 --> Model Class Initialized
INFO - 2016-10-24 15:17:33 --> Model Class Initialized
INFO - 2016-10-24 15:17:33 --> Model Class Initialized
INFO - 2016-10-24 15:17:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:33 --> Config Class Initialized
INFO - 2016-10-24 15:17:33 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:33 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:33 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:33 --> URI Class Initialized
INFO - 2016-10-24 15:17:33 --> Router Class Initialized
INFO - 2016-10-24 15:17:33 --> Output Class Initialized
INFO - 2016-10-24 15:17:33 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:33 --> Input Class Initialized
INFO - 2016-10-24 15:17:33 --> Language Class Initialized
INFO - 2016-10-24 15:17:33 --> Loader Class Initialized
INFO - 2016-10-24 15:17:33 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:33 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:33 --> Controller Class Initialized
INFO - 2016-10-24 15:17:33 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:33 --> Model Class Initialized
INFO - 2016-10-24 15:17:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-24 15:17:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-24 15:17:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-24 15:17:33 --> Final output sent to browser
DEBUG - 2016-10-24 15:17:33 --> Total execution time: 0.0942
INFO - 2016-10-24 15:17:42 --> Config Class Initialized
INFO - 2016-10-24 15:17:42 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:42 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:42 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:42 --> URI Class Initialized
INFO - 2016-10-24 15:17:42 --> Router Class Initialized
INFO - 2016-10-24 15:17:42 --> Output Class Initialized
INFO - 2016-10-24 15:17:42 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:42 --> Input Class Initialized
INFO - 2016-10-24 15:17:42 --> Language Class Initialized
INFO - 2016-10-24 15:17:42 --> Loader Class Initialized
INFO - 2016-10-24 15:17:42 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:42 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:42 --> Controller Class Initialized
INFO - 2016-10-24 15:17:42 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:42 --> Model Class Initialized
INFO - 2016-10-24 15:17:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:42 --> Config Class Initialized
INFO - 2016-10-24 15:17:42 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:42 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:42 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:42 --> URI Class Initialized
INFO - 2016-10-24 15:17:42 --> Router Class Initialized
INFO - 2016-10-24 15:17:42 --> Output Class Initialized
INFO - 2016-10-24 15:17:42 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:42 --> Input Class Initialized
INFO - 2016-10-24 15:17:42 --> Language Class Initialized
INFO - 2016-10-24 15:17:42 --> Loader Class Initialized
INFO - 2016-10-24 15:17:42 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:42 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:42 --> Controller Class Initialized
INFO - 2016-10-24 15:17:42 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:42 --> Model Class Initialized
INFO - 2016-10-24 15:17:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-24 15:17:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-24 15:17:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-24 15:17:42 --> Final output sent to browser
DEBUG - 2016-10-24 15:17:42 --> Total execution time: 0.0669
INFO - 2016-10-24 15:17:47 --> Config Class Initialized
INFO - 2016-10-24 15:17:47 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:47 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:47 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:47 --> URI Class Initialized
INFO - 2016-10-24 15:17:47 --> Router Class Initialized
INFO - 2016-10-24 15:17:47 --> Output Class Initialized
INFO - 2016-10-24 15:17:47 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:47 --> Input Class Initialized
INFO - 2016-10-24 15:17:47 --> Language Class Initialized
INFO - 2016-10-24 15:17:47 --> Loader Class Initialized
INFO - 2016-10-24 15:17:47 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:47 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:47 --> Controller Class Initialized
INFO - 2016-10-24 15:17:47 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:47 --> Model Class Initialized
INFO - 2016-10-24 15:17:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:47 --> Config Class Initialized
INFO - 2016-10-24 15:17:47 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:47 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:47 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:47 --> URI Class Initialized
INFO - 2016-10-24 15:17:47 --> Router Class Initialized
INFO - 2016-10-24 15:17:47 --> Output Class Initialized
INFO - 2016-10-24 15:17:47 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:47 --> Input Class Initialized
INFO - 2016-10-24 15:17:47 --> Language Class Initialized
INFO - 2016-10-24 15:17:47 --> Loader Class Initialized
INFO - 2016-10-24 15:17:47 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:47 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:47 --> Controller Class Initialized
INFO - 2016-10-24 15:17:47 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:47 --> Model Class Initialized
INFO - 2016-10-24 15:17:47 --> Model Class Initialized
INFO - 2016-10-24 15:17:47 --> Model Class Initialized
INFO - 2016-10-24 15:17:47 --> Model Class Initialized
INFO - 2016-10-24 15:17:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-24 15:17:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-24 15:17:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-24 15:17:47 --> Final output sent to browser
DEBUG - 2016-10-24 15:17:47 --> Total execution time: 0.1083
INFO - 2016-10-24 15:17:49 --> Config Class Initialized
INFO - 2016-10-24 15:17:49 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:49 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:49 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:49 --> URI Class Initialized
INFO - 2016-10-24 15:17:49 --> Router Class Initialized
INFO - 2016-10-24 15:17:49 --> Output Class Initialized
INFO - 2016-10-24 15:17:49 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:49 --> Input Class Initialized
INFO - 2016-10-24 15:17:49 --> Language Class Initialized
INFO - 2016-10-24 15:17:49 --> Loader Class Initialized
INFO - 2016-10-24 15:17:49 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:49 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:49 --> Controller Class Initialized
INFO - 2016-10-24 15:17:49 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:49 --> Model Class Initialized
INFO - 2016-10-24 15:17:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:49 --> Helper loaded: form_helper
INFO - 2016-10-24 15:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-24 15:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-24 15:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-24 15:17:49 --> Final output sent to browser
DEBUG - 2016-10-24 15:17:49 --> Total execution time: 0.1127
INFO - 2016-10-24 15:17:52 --> Config Class Initialized
INFO - 2016-10-24 15:17:52 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:17:52 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:17:52 --> Utf8 Class Initialized
INFO - 2016-10-24 15:17:52 --> URI Class Initialized
INFO - 2016-10-24 15:17:52 --> Router Class Initialized
INFO - 2016-10-24 15:17:52 --> Output Class Initialized
INFO - 2016-10-24 15:17:52 --> Security Class Initialized
DEBUG - 2016-10-24 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:17:52 --> Input Class Initialized
INFO - 2016-10-24 15:17:52 --> Language Class Initialized
INFO - 2016-10-24 15:17:52 --> Loader Class Initialized
INFO - 2016-10-24 15:17:52 --> Helper loaded: url_helper
INFO - 2016-10-24 15:17:52 --> Helper loaded: language_helper
INFO - 2016-10-24 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:17:52 --> Controller Class Initialized
INFO - 2016-10-24 15:17:52 --> Database Driver Class Initialized
INFO - 2016-10-24 15:17:52 --> Model Class Initialized
INFO - 2016-10-24 15:17:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:17:52 --> Model Class Initialized
INFO - 2016-10-24 15:17:52 --> Model Class Initialized
INFO - 2016-10-24 15:17:52 --> Helper loaded: form_helper
INFO - 2016-10-24 15:17:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-24 15:17:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-24 15:17:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-24 15:17:52 --> Final output sent to browser
DEBUG - 2016-10-24 15:17:52 --> Total execution time: 0.1480
INFO - 2016-10-24 15:19:57 --> Config Class Initialized
INFO - 2016-10-24 15:19:57 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:19:57 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:19:57 --> Utf8 Class Initialized
INFO - 2016-10-24 15:19:57 --> URI Class Initialized
INFO - 2016-10-24 15:19:57 --> Router Class Initialized
INFO - 2016-10-24 15:19:57 --> Output Class Initialized
INFO - 2016-10-24 15:19:57 --> Security Class Initialized
DEBUG - 2016-10-24 15:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:19:57 --> Input Class Initialized
INFO - 2016-10-24 15:19:57 --> Language Class Initialized
INFO - 2016-10-24 15:19:57 --> Loader Class Initialized
INFO - 2016-10-24 15:19:57 --> Helper loaded: url_helper
INFO - 2016-10-24 15:19:57 --> Helper loaded: language_helper
INFO - 2016-10-24 15:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:19:57 --> Controller Class Initialized
INFO - 2016-10-24 15:19:57 --> Database Driver Class Initialized
INFO - 2016-10-24 15:19:57 --> Model Class Initialized
INFO - 2016-10-24 15:19:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:19:57 --> Helper loaded: form_helper
INFO - 2016-10-24 15:19:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-24 15:19:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-24 15:19:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-24 15:19:57 --> Final output sent to browser
DEBUG - 2016-10-24 15:19:57 --> Total execution time: 0.1126
INFO - 2016-10-24 15:20:04 --> Config Class Initialized
INFO - 2016-10-24 15:20:04 --> Hooks Class Initialized
DEBUG - 2016-10-24 15:20:04 --> UTF-8 Support Enabled
INFO - 2016-10-24 15:20:04 --> Utf8 Class Initialized
INFO - 2016-10-24 15:20:04 --> URI Class Initialized
INFO - 2016-10-24 15:20:04 --> Router Class Initialized
INFO - 2016-10-24 15:20:04 --> Output Class Initialized
INFO - 2016-10-24 15:20:04 --> Security Class Initialized
DEBUG - 2016-10-24 15:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 15:20:04 --> Input Class Initialized
INFO - 2016-10-24 15:20:04 --> Language Class Initialized
INFO - 2016-10-24 15:20:04 --> Loader Class Initialized
INFO - 2016-10-24 15:20:04 --> Helper loaded: url_helper
INFO - 2016-10-24 15:20:04 --> Helper loaded: language_helper
INFO - 2016-10-24 15:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 15:20:04 --> Controller Class Initialized
INFO - 2016-10-24 15:20:04 --> Database Driver Class Initialized
INFO - 2016-10-24 15:20:04 --> Model Class Initialized
INFO - 2016-10-24 15:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-24 15:20:04 --> Model Class Initialized
INFO - 2016-10-24 15:20:04 --> Model Class Initialized
INFO - 2016-10-24 15:20:04 --> Helper loaded: form_helper
INFO - 2016-10-24 15:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-24 15:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-24 15:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-24 15:20:04 --> Final output sent to browser
DEBUG - 2016-10-24 15:20:04 --> Total execution time: 0.1444
