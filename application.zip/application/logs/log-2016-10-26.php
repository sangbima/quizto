<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-26 08:41:32 --> Config Class Initialized
INFO - 2016-10-26 08:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:41:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:41:32 --> Utf8 Class Initialized
INFO - 2016-10-26 08:41:32 --> URI Class Initialized
INFO - 2016-10-26 08:41:32 --> Router Class Initialized
INFO - 2016-10-26 08:41:32 --> Output Class Initialized
INFO - 2016-10-26 08:41:32 --> Security Class Initialized
DEBUG - 2016-10-26 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:41:32 --> Input Class Initialized
INFO - 2016-10-26 08:41:32 --> Language Class Initialized
INFO - 2016-10-26 08:41:32 --> Loader Class Initialized
INFO - 2016-10-26 08:41:32 --> Helper loaded: url_helper
INFO - 2016-10-26 08:41:32 --> Helper loaded: language_helper
INFO - 2016-10-26 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:41:32 --> Controller Class Initialized
INFO - 2016-10-26 08:41:32 --> Database Driver Class Initialized
INFO - 2016-10-26 08:41:32 --> Model Class Initialized
INFO - 2016-10-26 08:41:32 --> Model Class Initialized
INFO - 2016-10-26 08:41:32 --> Model Class Initialized
INFO - 2016-10-26 08:41:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:41:32 --> Config Class Initialized
INFO - 2016-10-26 08:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:41:32 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:41:32 --> Utf8 Class Initialized
INFO - 2016-10-26 08:41:32 --> URI Class Initialized
INFO - 2016-10-26 08:41:32 --> Router Class Initialized
INFO - 2016-10-26 08:41:32 --> Output Class Initialized
INFO - 2016-10-26 08:41:32 --> Security Class Initialized
DEBUG - 2016-10-26 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:41:32 --> Input Class Initialized
INFO - 2016-10-26 08:41:32 --> Language Class Initialized
INFO - 2016-10-26 08:41:32 --> Loader Class Initialized
INFO - 2016-10-26 08:41:32 --> Helper loaded: url_helper
INFO - 2016-10-26 08:41:32 --> Helper loaded: language_helper
INFO - 2016-10-26 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:41:32 --> Controller Class Initialized
INFO - 2016-10-26 08:41:32 --> Database Driver Class Initialized
INFO - 2016-10-26 08:41:32 --> Model Class Initialized
INFO - 2016-10-26 08:41:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-26 08:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-26 08:41:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-26 08:41:32 --> Final output sent to browser
DEBUG - 2016-10-26 08:41:32 --> Total execution time: 0.0619
INFO - 2016-10-26 08:42:11 --> Config Class Initialized
INFO - 2016-10-26 08:42:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:11 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:11 --> URI Class Initialized
INFO - 2016-10-26 08:42:11 --> Router Class Initialized
INFO - 2016-10-26 08:42:11 --> Output Class Initialized
INFO - 2016-10-26 08:42:11 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:11 --> Input Class Initialized
INFO - 2016-10-26 08:42:11 --> Language Class Initialized
INFO - 2016-10-26 08:42:11 --> Loader Class Initialized
INFO - 2016-10-26 08:42:11 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:11 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:11 --> Controller Class Initialized
INFO - 2016-10-26 08:42:11 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:11 --> Model Class Initialized
INFO - 2016-10-26 08:42:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:11 --> Config Class Initialized
INFO - 2016-10-26 08:42:11 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:11 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:11 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:11 --> URI Class Initialized
INFO - 2016-10-26 08:42:11 --> Router Class Initialized
INFO - 2016-10-26 08:42:11 --> Output Class Initialized
INFO - 2016-10-26 08:42:11 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:11 --> Input Class Initialized
INFO - 2016-10-26 08:42:11 --> Language Class Initialized
INFO - 2016-10-26 08:42:11 --> Loader Class Initialized
INFO - 2016-10-26 08:42:11 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:11 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:11 --> Controller Class Initialized
INFO - 2016-10-26 08:42:11 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:11 --> Model Class Initialized
INFO - 2016-10-26 08:42:11 --> Model Class Initialized
INFO - 2016-10-26 08:42:11 --> Model Class Initialized
INFO - 2016-10-26 08:42:11 --> Model Class Initialized
INFO - 2016-10-26 08:42:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 08:42:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-26 08:42:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 08:42:11 --> Final output sent to browser
DEBUG - 2016-10-26 08:42:11 --> Total execution time: 0.0814
INFO - 2016-10-26 08:42:30 --> Config Class Initialized
INFO - 2016-10-26 08:42:30 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:30 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:30 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:30 --> URI Class Initialized
INFO - 2016-10-26 08:42:30 --> Router Class Initialized
INFO - 2016-10-26 08:42:30 --> Output Class Initialized
INFO - 2016-10-26 08:42:30 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:30 --> Input Class Initialized
INFO - 2016-10-26 08:42:30 --> Language Class Initialized
INFO - 2016-10-26 08:42:30 --> Loader Class Initialized
INFO - 2016-10-26 08:42:30 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:30 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:30 --> Controller Class Initialized
INFO - 2016-10-26 08:42:30 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:30 --> Model Class Initialized
INFO - 2016-10-26 08:42:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 08:42:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-10-26 08:42:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 08:42:30 --> Final output sent to browser
DEBUG - 2016-10-26 08:42:30 --> Total execution time: 0.0631
INFO - 2016-10-26 08:42:40 --> Config Class Initialized
INFO - 2016-10-26 08:42:40 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:40 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:40 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:40 --> URI Class Initialized
INFO - 2016-10-26 08:42:40 --> Router Class Initialized
INFO - 2016-10-26 08:42:40 --> Output Class Initialized
INFO - 2016-10-26 08:42:40 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:40 --> Input Class Initialized
INFO - 2016-10-26 08:42:40 --> Language Class Initialized
INFO - 2016-10-26 08:42:40 --> Loader Class Initialized
INFO - 2016-10-26 08:42:40 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:40 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:40 --> Controller Class Initialized
INFO - 2016-10-26 08:42:40 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:40 --> Model Class Initialized
INFO - 2016-10-26 08:42:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:40 --> Model Class Initialized
INFO - 2016-10-26 08:42:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 08:42:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2016-10-26 08:42:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 08:42:40 --> Final output sent to browser
DEBUG - 2016-10-26 08:42:40 --> Total execution time: 0.0914
INFO - 2016-10-26 08:42:43 --> Config Class Initialized
INFO - 2016-10-26 08:42:43 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:43 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:43 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:43 --> URI Class Initialized
INFO - 2016-10-26 08:42:43 --> Router Class Initialized
INFO - 2016-10-26 08:42:43 --> Output Class Initialized
INFO - 2016-10-26 08:42:43 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:43 --> Input Class Initialized
INFO - 2016-10-26 08:42:43 --> Language Class Initialized
INFO - 2016-10-26 08:42:43 --> Loader Class Initialized
INFO - 2016-10-26 08:42:43 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:43 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:43 --> Controller Class Initialized
INFO - 2016-10-26 08:42:43 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:43 --> Model Class Initialized
INFO - 2016-10-26 08:42:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:43 --> Helper loaded: form_helper
INFO - 2016-10-26 08:42:43 --> Form Validation Class Initialized
INFO - 2016-10-26 08:42:43 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-26 08:42:43 --> Config Class Initialized
INFO - 2016-10-26 08:42:43 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:43 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:43 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:43 --> URI Class Initialized
INFO - 2016-10-26 08:42:43 --> Router Class Initialized
INFO - 2016-10-26 08:42:43 --> Output Class Initialized
INFO - 2016-10-26 08:42:43 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:43 --> Input Class Initialized
INFO - 2016-10-26 08:42:43 --> Language Class Initialized
INFO - 2016-10-26 08:42:43 --> Loader Class Initialized
INFO - 2016-10-26 08:42:43 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:43 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:43 --> Controller Class Initialized
INFO - 2016-10-26 08:42:43 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:43 --> Model Class Initialized
INFO - 2016-10-26 08:42:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:43 --> Model Class Initialized
INFO - 2016-10-26 08:42:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 08:42:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2016-10-26 08:42:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 08:42:43 --> Final output sent to browser
DEBUG - 2016-10-26 08:42:43 --> Total execution time: 0.0706
INFO - 2016-10-26 08:42:47 --> Config Class Initialized
INFO - 2016-10-26 08:42:47 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:42:47 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:42:47 --> Utf8 Class Initialized
INFO - 2016-10-26 08:42:47 --> URI Class Initialized
INFO - 2016-10-26 08:42:47 --> Router Class Initialized
INFO - 2016-10-26 08:42:47 --> Output Class Initialized
INFO - 2016-10-26 08:42:47 --> Security Class Initialized
DEBUG - 2016-10-26 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:42:47 --> Input Class Initialized
INFO - 2016-10-26 08:42:47 --> Language Class Initialized
INFO - 2016-10-26 08:42:47 --> Loader Class Initialized
INFO - 2016-10-26 08:42:47 --> Helper loaded: url_helper
INFO - 2016-10-26 08:42:47 --> Helper loaded: language_helper
INFO - 2016-10-26 08:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:42:47 --> Controller Class Initialized
INFO - 2016-10-26 08:42:47 --> Database Driver Class Initialized
INFO - 2016-10-26 08:42:47 --> Model Class Initialized
INFO - 2016-10-26 08:42:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:42:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 08:42:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-10-26 08:42:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 08:42:47 --> Final output sent to browser
DEBUG - 2016-10-26 08:42:47 --> Total execution time: 0.0528
INFO - 2016-10-26 08:55:03 --> Config Class Initialized
INFO - 2016-10-26 08:55:03 --> Hooks Class Initialized
DEBUG - 2016-10-26 08:55:03 --> UTF-8 Support Enabled
INFO - 2016-10-26 08:55:03 --> Utf8 Class Initialized
INFO - 2016-10-26 08:55:03 --> URI Class Initialized
INFO - 2016-10-26 08:55:03 --> Router Class Initialized
INFO - 2016-10-26 08:55:03 --> Output Class Initialized
INFO - 2016-10-26 08:55:03 --> Security Class Initialized
DEBUG - 2016-10-26 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 08:55:03 --> Input Class Initialized
INFO - 2016-10-26 08:55:03 --> Language Class Initialized
INFO - 2016-10-26 08:55:03 --> Loader Class Initialized
INFO - 2016-10-26 08:55:03 --> Helper loaded: url_helper
INFO - 2016-10-26 08:55:03 --> Helper loaded: language_helper
INFO - 2016-10-26 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 08:55:03 --> Controller Class Initialized
INFO - 2016-10-26 08:55:03 --> Database Driver Class Initialized
INFO - 2016-10-26 08:55:03 --> Model Class Initialized
INFO - 2016-10-26 08:55:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 08:55:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 08:55:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-10-26 08:55:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 08:55:03 --> Final output sent to browser
DEBUG - 2016-10-26 08:55:03 --> Total execution time: 0.1055
INFO - 2016-10-26 09:03:18 --> Config Class Initialized
INFO - 2016-10-26 09:03:18 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:03:18 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:03:18 --> Utf8 Class Initialized
INFO - 2016-10-26 09:03:18 --> URI Class Initialized
INFO - 2016-10-26 09:03:18 --> Router Class Initialized
INFO - 2016-10-26 09:03:18 --> Output Class Initialized
INFO - 2016-10-26 09:03:18 --> Security Class Initialized
DEBUG - 2016-10-26 09:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:03:18 --> Input Class Initialized
INFO - 2016-10-26 09:03:18 --> Language Class Initialized
INFO - 2016-10-26 09:03:18 --> Loader Class Initialized
INFO - 2016-10-26 09:03:18 --> Helper loaded: url_helper
INFO - 2016-10-26 09:03:18 --> Helper loaded: language_helper
INFO - 2016-10-26 09:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:03:18 --> Controller Class Initialized
INFO - 2016-10-26 09:03:18 --> Database Driver Class Initialized
INFO - 2016-10-26 09:03:18 --> Model Class Initialized
INFO - 2016-10-26 09:03:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:03:18 --> Helper loaded: form_helper
INFO - 2016-10-26 09:03:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:03:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-26 09:03:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:03:18 --> Final output sent to browser
DEBUG - 2016-10-26 09:03:18 --> Total execution time: 0.1066
INFO - 2016-10-26 09:04:13 --> Config Class Initialized
INFO - 2016-10-26 09:04:13 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:04:13 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:04:13 --> Utf8 Class Initialized
INFO - 2016-10-26 09:04:13 --> URI Class Initialized
INFO - 2016-10-26 09:04:13 --> Router Class Initialized
INFO - 2016-10-26 09:04:13 --> Output Class Initialized
INFO - 2016-10-26 09:04:13 --> Security Class Initialized
DEBUG - 2016-10-26 09:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:04:13 --> Input Class Initialized
INFO - 2016-10-26 09:04:13 --> Language Class Initialized
INFO - 2016-10-26 09:04:13 --> Loader Class Initialized
INFO - 2016-10-26 09:04:13 --> Helper loaded: url_helper
INFO - 2016-10-26 09:04:13 --> Helper loaded: language_helper
INFO - 2016-10-26 09:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:04:13 --> Controller Class Initialized
INFO - 2016-10-26 09:04:13 --> Database Driver Class Initialized
INFO - 2016-10-26 09:04:13 --> Model Class Initialized
INFO - 2016-10-26 09:04:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:04:13 --> Model Class Initialized
INFO - 2016-10-26 09:04:13 --> Model Class Initialized
INFO - 2016-10-26 09:04:13 --> Helper loaded: form_helper
INFO - 2016-10-26 09:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-26 09:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:04:13 --> Final output sent to browser
DEBUG - 2016-10-26 09:04:13 --> Total execution time: 0.1018
INFO - 2016-10-26 09:06:07 --> Config Class Initialized
INFO - 2016-10-26 09:06:07 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:06:07 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:06:07 --> Utf8 Class Initialized
INFO - 2016-10-26 09:06:07 --> URI Class Initialized
INFO - 2016-10-26 09:06:07 --> Router Class Initialized
INFO - 2016-10-26 09:06:07 --> Output Class Initialized
INFO - 2016-10-26 09:06:07 --> Security Class Initialized
DEBUG - 2016-10-26 09:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:06:07 --> Input Class Initialized
INFO - 2016-10-26 09:06:07 --> Language Class Initialized
INFO - 2016-10-26 09:06:07 --> Loader Class Initialized
INFO - 2016-10-26 09:06:07 --> Helper loaded: url_helper
INFO - 2016-10-26 09:06:07 --> Helper loaded: language_helper
INFO - 2016-10-26 09:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:06:07 --> Controller Class Initialized
INFO - 2016-10-26 09:06:07 --> Database Driver Class Initialized
INFO - 2016-10-26 09:06:07 --> Model Class Initialized
INFO - 2016-10-26 09:06:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:06:07 --> Helper loaded: form_helper
INFO - 2016-10-26 09:06:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:06:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-26 09:06:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:06:08 --> Final output sent to browser
DEBUG - 2016-10-26 09:06:08 --> Total execution time: 0.0565
INFO - 2016-10-26 09:08:19 --> Config Class Initialized
INFO - 2016-10-26 09:08:19 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:08:19 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:08:19 --> Utf8 Class Initialized
INFO - 2016-10-26 09:08:19 --> URI Class Initialized
INFO - 2016-10-26 09:08:19 --> Router Class Initialized
INFO - 2016-10-26 09:08:19 --> Output Class Initialized
INFO - 2016-10-26 09:08:19 --> Security Class Initialized
DEBUG - 2016-10-26 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:08:19 --> Input Class Initialized
INFO - 2016-10-26 09:08:19 --> Language Class Initialized
INFO - 2016-10-26 09:08:20 --> Loader Class Initialized
INFO - 2016-10-26 09:08:20 --> Helper loaded: url_helper
INFO - 2016-10-26 09:08:20 --> Helper loaded: language_helper
INFO - 2016-10-26 09:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:08:20 --> Controller Class Initialized
INFO - 2016-10-26 09:08:20 --> Database Driver Class Initialized
INFO - 2016-10-26 09:08:20 --> Model Class Initialized
INFO - 2016-10-26 09:08:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:08:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:08:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-10-26 09:08:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:08:20 --> Final output sent to browser
DEBUG - 2016-10-26 09:08:20 --> Total execution time: 0.0576
INFO - 2016-10-26 09:08:22 --> Config Class Initialized
INFO - 2016-10-26 09:08:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:08:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:08:22 --> Utf8 Class Initialized
INFO - 2016-10-26 09:08:22 --> URI Class Initialized
INFO - 2016-10-26 09:08:22 --> Router Class Initialized
INFO - 2016-10-26 09:08:22 --> Output Class Initialized
INFO - 2016-10-26 09:08:22 --> Security Class Initialized
DEBUG - 2016-10-26 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:08:22 --> Input Class Initialized
INFO - 2016-10-26 09:08:22 --> Language Class Initialized
INFO - 2016-10-26 09:08:22 --> Loader Class Initialized
INFO - 2016-10-26 09:08:22 --> Helper loaded: url_helper
INFO - 2016-10-26 09:08:22 --> Helper loaded: language_helper
INFO - 2016-10-26 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:08:22 --> Controller Class Initialized
INFO - 2016-10-26 09:08:22 --> Database Driver Class Initialized
INFO - 2016-10-26 09:08:22 --> Model Class Initialized
INFO - 2016-10-26 09:08:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:08:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:08:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2016-10-26 09:08:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:08:22 --> Final output sent to browser
DEBUG - 2016-10-26 09:08:22 --> Total execution time: 0.0578
INFO - 2016-10-26 09:08:22 --> Config Class Initialized
INFO - 2016-10-26 09:08:22 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:08:22 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:08:22 --> Utf8 Class Initialized
INFO - 2016-10-26 09:08:22 --> URI Class Initialized
INFO - 2016-10-26 09:08:22 --> Router Class Initialized
INFO - 2016-10-26 09:08:22 --> Output Class Initialized
INFO - 2016-10-26 09:08:22 --> Security Class Initialized
DEBUG - 2016-10-26 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:08:22 --> Input Class Initialized
INFO - 2016-10-26 09:08:22 --> Language Class Initialized
INFO - 2016-10-26 09:08:22 --> Loader Class Initialized
INFO - 2016-10-26 09:08:22 --> Helper loaded: url_helper
INFO - 2016-10-26 09:08:22 --> Helper loaded: language_helper
INFO - 2016-10-26 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:08:22 --> Controller Class Initialized
INFO - 2016-10-26 09:08:22 --> Database Driver Class Initialized
INFO - 2016-10-26 09:08:22 --> Model Class Initialized
INFO - 2016-10-26 09:08:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:08:22 --> Final output sent to browser
DEBUG - 2016-10-26 09:08:22 --> Total execution time: 0.0737
INFO - 2016-10-26 09:32:56 --> Config Class Initialized
INFO - 2016-10-26 09:32:56 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:32:56 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:32:56 --> Utf8 Class Initialized
INFO - 2016-10-26 09:32:56 --> URI Class Initialized
INFO - 2016-10-26 09:32:56 --> Router Class Initialized
INFO - 2016-10-26 09:32:56 --> Output Class Initialized
INFO - 2016-10-26 09:32:56 --> Security Class Initialized
DEBUG - 2016-10-26 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:32:56 --> Input Class Initialized
INFO - 2016-10-26 09:32:56 --> Language Class Initialized
INFO - 2016-10-26 09:32:56 --> Loader Class Initialized
INFO - 2016-10-26 09:32:56 --> Helper loaded: url_helper
INFO - 2016-10-26 09:32:56 --> Helper loaded: language_helper
INFO - 2016-10-26 09:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:32:56 --> Controller Class Initialized
INFO - 2016-10-26 09:32:56 --> Database Driver Class Initialized
INFO - 2016-10-26 09:32:56 --> Model Class Initialized
INFO - 2016-10-26 09:32:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:32:56 --> Helper loaded: form_helper
INFO - 2016-10-26 09:32:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:32:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-26 09:32:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:32:56 --> Final output sent to browser
DEBUG - 2016-10-26 09:32:56 --> Total execution time: 0.0902
INFO - 2016-10-26 09:32:58 --> Config Class Initialized
INFO - 2016-10-26 09:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-26 09:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-26 09:32:58 --> Utf8 Class Initialized
INFO - 2016-10-26 09:32:58 --> URI Class Initialized
INFO - 2016-10-26 09:32:58 --> Router Class Initialized
INFO - 2016-10-26 09:32:58 --> Output Class Initialized
INFO - 2016-10-26 09:32:58 --> Security Class Initialized
DEBUG - 2016-10-26 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 09:32:58 --> Input Class Initialized
INFO - 2016-10-26 09:32:58 --> Language Class Initialized
INFO - 2016-10-26 09:32:58 --> Loader Class Initialized
INFO - 2016-10-26 09:32:58 --> Helper loaded: url_helper
INFO - 2016-10-26 09:32:58 --> Helper loaded: language_helper
INFO - 2016-10-26 09:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 09:32:58 --> Controller Class Initialized
INFO - 2016-10-26 09:32:58 --> Database Driver Class Initialized
INFO - 2016-10-26 09:32:58 --> Model Class Initialized
INFO - 2016-10-26 09:32:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 09:32:58 --> Model Class Initialized
INFO - 2016-10-26 09:32:58 --> Model Class Initialized
INFO - 2016-10-26 09:32:58 --> Helper loaded: form_helper
INFO - 2016-10-26 09:32:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 09:32:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-26 09:32:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 09:32:58 --> Final output sent to browser
DEBUG - 2016-10-26 09:32:58 --> Total execution time: 0.1055
INFO - 2016-10-26 10:06:16 --> Config Class Initialized
INFO - 2016-10-26 10:06:16 --> Hooks Class Initialized
DEBUG - 2016-10-26 10:06:16 --> UTF-8 Support Enabled
INFO - 2016-10-26 10:06:16 --> Utf8 Class Initialized
INFO - 2016-10-26 10:06:16 --> URI Class Initialized
INFO - 2016-10-26 10:06:16 --> Router Class Initialized
INFO - 2016-10-26 10:06:16 --> Output Class Initialized
INFO - 2016-10-26 10:06:16 --> Security Class Initialized
DEBUG - 2016-10-26 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 10:06:16 --> Input Class Initialized
INFO - 2016-10-26 10:06:16 --> Language Class Initialized
INFO - 2016-10-26 10:06:16 --> Loader Class Initialized
INFO - 2016-10-26 10:06:16 --> Helper loaded: url_helper
INFO - 2016-10-26 10:06:16 --> Helper loaded: language_helper
INFO - 2016-10-26 10:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 10:06:16 --> Controller Class Initialized
INFO - 2016-10-26 10:06:16 --> Database Driver Class Initialized
INFO - 2016-10-26 10:06:16 --> Model Class Initialized
INFO - 2016-10-26 10:06:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 10:06:16 --> Helper loaded: form_helper
INFO - 2016-10-26 10:06:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-26 10:06:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-26 10:06:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-26 10:06:16 --> Final output sent to browser
DEBUG - 2016-10-26 10:06:16 --> Total execution time: 0.0811
INFO - 2016-10-26 10:08:45 --> Config Class Initialized
INFO - 2016-10-26 10:08:45 --> Hooks Class Initialized
DEBUG - 2016-10-26 10:08:45 --> UTF-8 Support Enabled
INFO - 2016-10-26 10:08:45 --> Utf8 Class Initialized
INFO - 2016-10-26 10:08:45 --> URI Class Initialized
INFO - 2016-10-26 10:08:45 --> Router Class Initialized
INFO - 2016-10-26 10:08:46 --> Output Class Initialized
INFO - 2016-10-26 10:08:46 --> Security Class Initialized
DEBUG - 2016-10-26 10:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 10:08:46 --> Input Class Initialized
INFO - 2016-10-26 10:08:46 --> Language Class Initialized
INFO - 2016-10-26 10:08:46 --> Loader Class Initialized
INFO - 2016-10-26 10:08:46 --> Helper loaded: url_helper
INFO - 2016-10-26 10:08:46 --> Helper loaded: language_helper
INFO - 2016-10-26 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 10:08:46 --> Controller Class Initialized
INFO - 2016-10-26 10:08:46 --> Database Driver Class Initialized
INFO - 2016-10-26 10:08:46 --> Model Class Initialized
INFO - 2016-10-26 10:08:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 10:08:46 --> Config Class Initialized
INFO - 2016-10-26 10:08:46 --> Hooks Class Initialized
DEBUG - 2016-10-26 10:08:46 --> UTF-8 Support Enabled
INFO - 2016-10-26 10:08:46 --> Utf8 Class Initialized
INFO - 2016-10-26 10:08:46 --> URI Class Initialized
INFO - 2016-10-26 10:08:46 --> Router Class Initialized
INFO - 2016-10-26 10:08:46 --> Output Class Initialized
INFO - 2016-10-26 10:08:46 --> Security Class Initialized
DEBUG - 2016-10-26 10:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-26 10:08:46 --> Input Class Initialized
INFO - 2016-10-26 10:08:46 --> Language Class Initialized
INFO - 2016-10-26 10:08:46 --> Loader Class Initialized
INFO - 2016-10-26 10:08:46 --> Helper loaded: url_helper
INFO - 2016-10-26 10:08:46 --> Helper loaded: language_helper
INFO - 2016-10-26 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-26 10:08:46 --> Controller Class Initialized
INFO - 2016-10-26 10:08:46 --> Database Driver Class Initialized
INFO - 2016-10-26 10:08:46 --> Model Class Initialized
INFO - 2016-10-26 10:08:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-26 10:08:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-26 10:08:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-26 10:08:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-26 10:08:46 --> Final output sent to browser
DEBUG - 2016-10-26 10:08:46 --> Total execution time: 0.0542
