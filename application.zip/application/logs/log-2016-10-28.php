<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-28 08:02:09 --> Config Class Initialized
INFO - 2016-10-28 08:02:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 08:02:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 08:02:09 --> Utf8 Class Initialized
INFO - 2016-10-28 08:02:09 --> URI Class Initialized
INFO - 2016-10-28 08:02:10 --> Router Class Initialized
INFO - 2016-10-28 08:02:10 --> Output Class Initialized
INFO - 2016-10-28 08:02:10 --> Security Class Initialized
DEBUG - 2016-10-28 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 08:02:10 --> Input Class Initialized
INFO - 2016-10-28 08:02:10 --> Language Class Initialized
INFO - 2016-10-28 08:02:10 --> Loader Class Initialized
INFO - 2016-10-28 08:02:10 --> Helper loaded: url_helper
INFO - 2016-10-28 08:02:10 --> Helper loaded: language_helper
INFO - 2016-10-28 08:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 08:02:10 --> Controller Class Initialized
INFO - 2016-10-28 08:02:10 --> Database Driver Class Initialized
INFO - 2016-10-28 08:02:10 --> Model Class Initialized
INFO - 2016-10-28 08:02:10 --> Model Class Initialized
INFO - 2016-10-28 08:02:10 --> Model Class Initialized
INFO - 2016-10-28 08:02:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 08:02:10 --> Config Class Initialized
INFO - 2016-10-28 08:02:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 08:02:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 08:02:10 --> Utf8 Class Initialized
INFO - 2016-10-28 08:02:10 --> URI Class Initialized
INFO - 2016-10-28 08:02:10 --> Router Class Initialized
INFO - 2016-10-28 08:02:10 --> Output Class Initialized
INFO - 2016-10-28 08:02:10 --> Security Class Initialized
DEBUG - 2016-10-28 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 08:02:10 --> Input Class Initialized
INFO - 2016-10-28 08:02:10 --> Language Class Initialized
INFO - 2016-10-28 08:02:10 --> Loader Class Initialized
INFO - 2016-10-28 08:02:10 --> Helper loaded: url_helper
INFO - 2016-10-28 08:02:10 --> Helper loaded: language_helper
INFO - 2016-10-28 08:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 08:02:10 --> Controller Class Initialized
INFO - 2016-10-28 08:02:10 --> Database Driver Class Initialized
INFO - 2016-10-28 08:02:10 --> Model Class Initialized
INFO - 2016-10-28 08:02:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 08:02:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 08:02:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 08:02:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 08:02:10 --> Final output sent to browser
DEBUG - 2016-10-28 08:02:10 --> Total execution time: 0.0644
INFO - 2016-10-28 12:42:40 --> Config Class Initialized
INFO - 2016-10-28 12:42:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:42:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:42:40 --> Utf8 Class Initialized
INFO - 2016-10-28 12:42:40 --> URI Class Initialized
DEBUG - 2016-10-28 12:42:40 --> No URI present. Default controller set.
INFO - 2016-10-28 12:42:40 --> Router Class Initialized
INFO - 2016-10-28 12:42:40 --> Output Class Initialized
INFO - 2016-10-28 12:42:40 --> Security Class Initialized
DEBUG - 2016-10-28 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:42:40 --> Input Class Initialized
INFO - 2016-10-28 12:42:40 --> Language Class Initialized
INFO - 2016-10-28 12:42:40 --> Loader Class Initialized
INFO - 2016-10-28 12:42:40 --> Helper loaded: url_helper
INFO - 2016-10-28 12:42:40 --> Helper loaded: language_helper
INFO - 2016-10-28 12:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:42:40 --> Controller Class Initialized
INFO - 2016-10-28 12:42:40 --> Database Driver Class Initialized
INFO - 2016-10-28 12:42:40 --> Model Class Initialized
INFO - 2016-10-28 12:42:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 12:42:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 12:42:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 12:42:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 12:42:40 --> Final output sent to browser
DEBUG - 2016-10-28 12:42:40 --> Total execution time: 0.1852
INFO - 2016-10-28 12:44:29 --> Config Class Initialized
INFO - 2016-10-28 12:44:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:29 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:29 --> URI Class Initialized
DEBUG - 2016-10-28 12:44:29 --> No URI present. Default controller set.
INFO - 2016-10-28 12:44:29 --> Router Class Initialized
INFO - 2016-10-28 12:44:29 --> Output Class Initialized
INFO - 2016-10-28 12:44:29 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:29 --> Input Class Initialized
INFO - 2016-10-28 12:44:29 --> Language Class Initialized
INFO - 2016-10-28 12:44:29 --> Loader Class Initialized
INFO - 2016-10-28 12:44:29 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:29 --> Helper loaded: language_helper
INFO - 2016-10-28 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:29 --> Controller Class Initialized
INFO - 2016-10-28 12:44:29 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:29 --> Model Class Initialized
INFO - 2016-10-28 12:44:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 12:44:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 12:44:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 12:44:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 12:44:29 --> Final output sent to browser
DEBUG - 2016-10-28 12:44:29 --> Total execution time: 0.1285
INFO - 2016-10-28 12:46:07 --> Config Class Initialized
INFO - 2016-10-28 12:46:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:46:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:46:07 --> Utf8 Class Initialized
INFO - 2016-10-28 12:46:07 --> URI Class Initialized
DEBUG - 2016-10-28 12:46:07 --> No URI present. Default controller set.
INFO - 2016-10-28 12:46:07 --> Router Class Initialized
INFO - 2016-10-28 12:46:07 --> Output Class Initialized
INFO - 2016-10-28 12:46:07 --> Security Class Initialized
DEBUG - 2016-10-28 12:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:46:07 --> Input Class Initialized
INFO - 2016-10-28 12:46:07 --> Language Class Initialized
INFO - 2016-10-28 12:46:07 --> Loader Class Initialized
INFO - 2016-10-28 12:46:07 --> Helper loaded: url_helper
INFO - 2016-10-28 12:46:07 --> Helper loaded: language_helper
INFO - 2016-10-28 12:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:46:07 --> Controller Class Initialized
INFO - 2016-10-28 12:46:07 --> Database Driver Class Initialized
INFO - 2016-10-28 12:46:07 --> Model Class Initialized
INFO - 2016-10-28 12:46:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 12:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 12:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 12:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 12:46:07 --> Final output sent to browser
DEBUG - 2016-10-28 12:46:07 --> Total execution time: 0.1067
INFO - 2016-10-28 12:47:22 --> Config Class Initialized
INFO - 2016-10-28 12:47:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:47:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:47:22 --> Utf8 Class Initialized
INFO - 2016-10-28 12:47:22 --> URI Class Initialized
DEBUG - 2016-10-28 12:47:22 --> No URI present. Default controller set.
INFO - 2016-10-28 12:47:22 --> Router Class Initialized
INFO - 2016-10-28 12:47:22 --> Output Class Initialized
INFO - 2016-10-28 12:47:22 --> Security Class Initialized
DEBUG - 2016-10-28 12:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:47:22 --> Input Class Initialized
INFO - 2016-10-28 12:47:22 --> Language Class Initialized
INFO - 2016-10-28 12:47:22 --> Loader Class Initialized
INFO - 2016-10-28 12:47:22 --> Helper loaded: url_helper
INFO - 2016-10-28 12:47:22 --> Helper loaded: language_helper
INFO - 2016-10-28 12:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:47:22 --> Controller Class Initialized
INFO - 2016-10-28 12:47:22 --> Database Driver Class Initialized
INFO - 2016-10-28 12:47:22 --> Model Class Initialized
INFO - 2016-10-28 12:47:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 12:47:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 12:47:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 12:47:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 12:47:22 --> Final output sent to browser
DEBUG - 2016-10-28 12:47:22 --> Total execution time: 0.1067
INFO - 2016-10-28 12:49:48 --> Config Class Initialized
INFO - 2016-10-28 12:49:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:49:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:49:48 --> Utf8 Class Initialized
INFO - 2016-10-28 12:49:48 --> URI Class Initialized
DEBUG - 2016-10-28 12:49:48 --> No URI present. Default controller set.
INFO - 2016-10-28 12:49:48 --> Router Class Initialized
INFO - 2016-10-28 12:49:48 --> Output Class Initialized
INFO - 2016-10-28 12:49:48 --> Security Class Initialized
DEBUG - 2016-10-28 12:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:49:48 --> Input Class Initialized
INFO - 2016-10-28 12:49:48 --> Language Class Initialized
INFO - 2016-10-28 12:49:48 --> Loader Class Initialized
INFO - 2016-10-28 12:49:48 --> Helper loaded: url_helper
INFO - 2016-10-28 12:49:48 --> Helper loaded: language_helper
INFO - 2016-10-28 12:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:49:48 --> Controller Class Initialized
INFO - 2016-10-28 12:49:48 --> Database Driver Class Initialized
INFO - 2016-10-28 12:49:48 --> Model Class Initialized
INFO - 2016-10-28 12:49:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 12:49:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 12:49:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 12:49:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 12:49:48 --> Final output sent to browser
DEBUG - 2016-10-28 12:49:48 --> Total execution time: 0.1569
INFO - 2016-10-28 12:51:08 --> Config Class Initialized
INFO - 2016-10-28 12:51:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:51:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:51:08 --> Utf8 Class Initialized
INFO - 2016-10-28 12:51:08 --> URI Class Initialized
DEBUG - 2016-10-28 12:51:08 --> No URI present. Default controller set.
INFO - 2016-10-28 12:51:08 --> Router Class Initialized
INFO - 2016-10-28 12:51:08 --> Output Class Initialized
INFO - 2016-10-28 12:51:08 --> Security Class Initialized
DEBUG - 2016-10-28 12:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:51:08 --> Input Class Initialized
INFO - 2016-10-28 12:51:08 --> Language Class Initialized
INFO - 2016-10-28 12:51:08 --> Loader Class Initialized
INFO - 2016-10-28 12:51:08 --> Helper loaded: url_helper
INFO - 2016-10-28 12:51:08 --> Helper loaded: language_helper
INFO - 2016-10-28 12:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:51:08 --> Controller Class Initialized
INFO - 2016-10-28 12:51:08 --> Database Driver Class Initialized
INFO - 2016-10-28 12:51:08 --> Model Class Initialized
INFO - 2016-10-28 12:51:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 12:51:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 12:51:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 12:51:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 12:51:08 --> Final output sent to browser
DEBUG - 2016-10-28 12:51:08 --> Total execution time: 0.1126
INFO - 2016-10-28 13:04:15 --> Config Class Initialized
INFO - 2016-10-28 13:04:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:04:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:04:15 --> Utf8 Class Initialized
INFO - 2016-10-28 13:04:15 --> URI Class Initialized
DEBUG - 2016-10-28 13:04:15 --> No URI present. Default controller set.
INFO - 2016-10-28 13:04:15 --> Router Class Initialized
INFO - 2016-10-28 13:04:15 --> Output Class Initialized
INFO - 2016-10-28 13:04:15 --> Security Class Initialized
DEBUG - 2016-10-28 13:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:04:15 --> Input Class Initialized
INFO - 2016-10-28 13:04:15 --> Language Class Initialized
INFO - 2016-10-28 13:04:15 --> Loader Class Initialized
INFO - 2016-10-28 13:04:15 --> Helper loaded: url_helper
INFO - 2016-10-28 13:04:15 --> Helper loaded: language_helper
INFO - 2016-10-28 13:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:04:15 --> Controller Class Initialized
INFO - 2016-10-28 13:04:15 --> Database Driver Class Initialized
INFO - 2016-10-28 13:04:16 --> Model Class Initialized
INFO - 2016-10-28 13:04:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:04:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 13:04:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 13:04:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 13:04:16 --> Final output sent to browser
DEBUG - 2016-10-28 13:04:16 --> Total execution time: 0.1335
INFO - 2016-10-28 13:05:49 --> Config Class Initialized
INFO - 2016-10-28 13:05:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:05:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:05:49 --> Utf8 Class Initialized
INFO - 2016-10-28 13:05:49 --> URI Class Initialized
DEBUG - 2016-10-28 13:05:49 --> No URI present. Default controller set.
INFO - 2016-10-28 13:05:49 --> Router Class Initialized
INFO - 2016-10-28 13:05:49 --> Output Class Initialized
INFO - 2016-10-28 13:05:49 --> Security Class Initialized
DEBUG - 2016-10-28 13:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:05:49 --> Input Class Initialized
INFO - 2016-10-28 13:05:49 --> Language Class Initialized
INFO - 2016-10-28 13:05:49 --> Loader Class Initialized
INFO - 2016-10-28 13:05:49 --> Helper loaded: url_helper
INFO - 2016-10-28 13:05:49 --> Helper loaded: language_helper
INFO - 2016-10-28 13:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:05:49 --> Controller Class Initialized
INFO - 2016-10-28 13:05:49 --> Database Driver Class Initialized
INFO - 2016-10-28 13:05:49 --> Model Class Initialized
INFO - 2016-10-28 13:05:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 13:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 13:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 13:05:49 --> Final output sent to browser
DEBUG - 2016-10-28 13:05:49 --> Total execution time: 0.0918
INFO - 2016-10-28 13:06:14 --> Config Class Initialized
INFO - 2016-10-28 13:06:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:06:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:06:14 --> Utf8 Class Initialized
INFO - 2016-10-28 13:06:14 --> URI Class Initialized
DEBUG - 2016-10-28 13:06:14 --> No URI present. Default controller set.
INFO - 2016-10-28 13:06:14 --> Router Class Initialized
INFO - 2016-10-28 13:06:14 --> Output Class Initialized
INFO - 2016-10-28 13:06:14 --> Security Class Initialized
DEBUG - 2016-10-28 13:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:06:14 --> Input Class Initialized
INFO - 2016-10-28 13:06:14 --> Language Class Initialized
INFO - 2016-10-28 13:06:14 --> Loader Class Initialized
INFO - 2016-10-28 13:06:14 --> Helper loaded: url_helper
INFO - 2016-10-28 13:06:14 --> Helper loaded: language_helper
INFO - 2016-10-28 13:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:06:14 --> Controller Class Initialized
INFO - 2016-10-28 13:06:14 --> Database Driver Class Initialized
INFO - 2016-10-28 13:06:14 --> Model Class Initialized
INFO - 2016-10-28 13:06:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 13:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 13:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 13:06:14 --> Final output sent to browser
DEBUG - 2016-10-28 13:06:14 --> Total execution time: 0.0852
INFO - 2016-10-28 13:10:21 --> Config Class Initialized
INFO - 2016-10-28 13:10:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:10:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:10:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:10:21 --> URI Class Initialized
DEBUG - 2016-10-28 13:10:21 --> No URI present. Default controller set.
INFO - 2016-10-28 13:10:21 --> Router Class Initialized
INFO - 2016-10-28 13:10:21 --> Output Class Initialized
INFO - 2016-10-28 13:10:21 --> Security Class Initialized
DEBUG - 2016-10-28 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:10:21 --> Input Class Initialized
INFO - 2016-10-28 13:10:21 --> Language Class Initialized
INFO - 2016-10-28 13:10:21 --> Loader Class Initialized
INFO - 2016-10-28 13:10:21 --> Helper loaded: url_helper
INFO - 2016-10-28 13:10:21 --> Helper loaded: language_helper
INFO - 2016-10-28 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:10:21 --> Controller Class Initialized
INFO - 2016-10-28 13:10:21 --> Database Driver Class Initialized
INFO - 2016-10-28 13:10:21 --> Model Class Initialized
INFO - 2016-10-28 13:10:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:10:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 13:10:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 13:10:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 13:10:21 --> Final output sent to browser
DEBUG - 2016-10-28 13:10:21 --> Total execution time: 0.1347
INFO - 2016-10-28 13:10:38 --> Config Class Initialized
INFO - 2016-10-28 13:10:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:10:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:10:38 --> Utf8 Class Initialized
INFO - 2016-10-28 13:10:38 --> URI Class Initialized
DEBUG - 2016-10-28 13:10:38 --> No URI present. Default controller set.
INFO - 2016-10-28 13:10:38 --> Router Class Initialized
INFO - 2016-10-28 13:10:38 --> Output Class Initialized
INFO - 2016-10-28 13:10:38 --> Security Class Initialized
DEBUG - 2016-10-28 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:10:38 --> Input Class Initialized
INFO - 2016-10-28 13:10:38 --> Language Class Initialized
INFO - 2016-10-28 13:10:38 --> Loader Class Initialized
INFO - 2016-10-28 13:10:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:10:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:10:38 --> Controller Class Initialized
INFO - 2016-10-28 13:10:38 --> Database Driver Class Initialized
INFO - 2016-10-28 13:10:38 --> Model Class Initialized
INFO - 2016-10-28 13:10:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:10:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 13:10:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 13:10:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 13:10:38 --> Final output sent to browser
DEBUG - 2016-10-28 13:10:38 --> Total execution time: 0.0857
INFO - 2016-10-28 13:11:17 --> Config Class Initialized
INFO - 2016-10-28 13:11:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:11:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:11:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:11:17 --> URI Class Initialized
DEBUG - 2016-10-28 13:11:17 --> No URI present. Default controller set.
INFO - 2016-10-28 13:11:17 --> Router Class Initialized
INFO - 2016-10-28 13:11:17 --> Output Class Initialized
INFO - 2016-10-28 13:11:17 --> Security Class Initialized
DEBUG - 2016-10-28 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:11:17 --> Input Class Initialized
INFO - 2016-10-28 13:11:17 --> Language Class Initialized
INFO - 2016-10-28 13:11:17 --> Loader Class Initialized
INFO - 2016-10-28 13:11:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:11:17 --> Helper loaded: language_helper
INFO - 2016-10-28 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:11:17 --> Controller Class Initialized
INFO - 2016-10-28 13:11:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:11:17 --> Model Class Initialized
INFO - 2016-10-28 13:11:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2016-10-28 13:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2016-10-28 13:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2016-10-28 13:11:17 --> Final output sent to browser
DEBUG - 2016-10-28 13:11:17 --> Total execution time: 0.0907
INFO - 2016-10-28 13:18:41 --> Config Class Initialized
INFO - 2016-10-28 13:18:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:18:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:18:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:18:41 --> URI Class Initialized
INFO - 2016-10-28 13:18:41 --> Router Class Initialized
INFO - 2016-10-28 13:18:41 --> Output Class Initialized
INFO - 2016-10-28 13:18:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:18:41 --> Input Class Initialized
INFO - 2016-10-28 13:18:41 --> Language Class Initialized
INFO - 2016-10-28 13:18:41 --> Loader Class Initialized
INFO - 2016-10-28 13:18:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:18:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:18:41 --> Controller Class Initialized
INFO - 2016-10-28 13:18:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:18:41 --> Model Class Initialized
INFO - 2016-10-28 13:18:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:18:41 --> Config Class Initialized
INFO - 2016-10-28 13:18:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:18:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:18:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:18:41 --> URI Class Initialized
INFO - 2016-10-28 13:18:41 --> Router Class Initialized
INFO - 2016-10-28 13:18:41 --> Output Class Initialized
INFO - 2016-10-28 13:18:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:18:41 --> Input Class Initialized
INFO - 2016-10-28 13:18:41 --> Language Class Initialized
INFO - 2016-10-28 13:18:41 --> Loader Class Initialized
INFO - 2016-10-28 13:18:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:18:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:18:41 --> Controller Class Initialized
INFO - 2016-10-28 13:18:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:18:41 --> Model Class Initialized
INFO - 2016-10-28 13:18:41 --> Model Class Initialized
INFO - 2016-10-28 13:18:41 --> Model Class Initialized
INFO - 2016-10-28 13:18:41 --> Model Class Initialized
INFO - 2016-10-28 13:18:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:18:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:18:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2016-10-28 13:18:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:18:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:18:41 --> Total execution time: 0.2134
INFO - 2016-10-28 13:18:46 --> Config Class Initialized
INFO - 2016-10-28 13:18:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:18:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:18:46 --> Utf8 Class Initialized
INFO - 2016-10-28 13:18:46 --> URI Class Initialized
INFO - 2016-10-28 13:18:46 --> Router Class Initialized
INFO - 2016-10-28 13:18:46 --> Output Class Initialized
INFO - 2016-10-28 13:18:46 --> Security Class Initialized
DEBUG - 2016-10-28 13:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:18:46 --> Input Class Initialized
INFO - 2016-10-28 13:18:46 --> Language Class Initialized
INFO - 2016-10-28 13:18:46 --> Loader Class Initialized
INFO - 2016-10-28 13:18:46 --> Helper loaded: url_helper
INFO - 2016-10-28 13:18:46 --> Helper loaded: language_helper
INFO - 2016-10-28 13:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:18:46 --> Controller Class Initialized
INFO - 2016-10-28 13:18:46 --> Database Driver Class Initialized
INFO - 2016-10-28 13:18:46 --> Model Class Initialized
INFO - 2016-10-28 13:18:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-10-28 13:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:18:46 --> Final output sent to browser
DEBUG - 2016-10-28 13:18:46 --> Total execution time: 0.0923
INFO - 2016-10-28 13:18:54 --> Config Class Initialized
INFO - 2016-10-28 13:18:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:18:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:18:54 --> Utf8 Class Initialized
INFO - 2016-10-28 13:18:54 --> URI Class Initialized
INFO - 2016-10-28 13:18:54 --> Router Class Initialized
INFO - 2016-10-28 13:18:54 --> Output Class Initialized
INFO - 2016-10-28 13:18:54 --> Security Class Initialized
DEBUG - 2016-10-28 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:18:54 --> Input Class Initialized
INFO - 2016-10-28 13:18:54 --> Language Class Initialized
INFO - 2016-10-28 13:18:54 --> Loader Class Initialized
INFO - 2016-10-28 13:18:54 --> Helper loaded: url_helper
INFO - 2016-10-28 13:18:54 --> Helper loaded: language_helper
INFO - 2016-10-28 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:18:54 --> Controller Class Initialized
INFO - 2016-10-28 13:18:54 --> Database Driver Class Initialized
INFO - 2016-10-28 13:18:54 --> Model Class Initialized
INFO - 2016-10-28 13:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2016-10-28 13:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:18:54 --> Final output sent to browser
DEBUG - 2016-10-28 13:18:54 --> Total execution time: 0.1011
INFO - 2016-10-28 13:18:54 --> Config Class Initialized
INFO - 2016-10-28 13:18:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:18:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:18:54 --> Utf8 Class Initialized
INFO - 2016-10-28 13:18:54 --> URI Class Initialized
INFO - 2016-10-28 13:18:54 --> Router Class Initialized
INFO - 2016-10-28 13:18:54 --> Output Class Initialized
INFO - 2016-10-28 13:18:54 --> Security Class Initialized
DEBUG - 2016-10-28 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:18:54 --> Input Class Initialized
INFO - 2016-10-28 13:18:54 --> Language Class Initialized
INFO - 2016-10-28 13:18:54 --> Loader Class Initialized
INFO - 2016-10-28 13:18:54 --> Helper loaded: url_helper
INFO - 2016-10-28 13:18:54 --> Helper loaded: language_helper
INFO - 2016-10-28 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:18:54 --> Controller Class Initialized
INFO - 2016-10-28 13:18:54 --> Database Driver Class Initialized
INFO - 2016-10-28 13:18:54 --> Model Class Initialized
INFO - 2016-10-28 13:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:18:54 --> Final output sent to browser
DEBUG - 2016-10-28 13:18:54 --> Total execution time: 0.0955
INFO - 2016-10-28 13:19:46 --> Config Class Initialized
INFO - 2016-10-28 13:19:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:19:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:19:46 --> Utf8 Class Initialized
INFO - 2016-10-28 13:19:46 --> URI Class Initialized
INFO - 2016-10-28 13:19:46 --> Router Class Initialized
INFO - 2016-10-28 13:19:46 --> Output Class Initialized
INFO - 2016-10-28 13:19:46 --> Security Class Initialized
DEBUG - 2016-10-28 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:19:46 --> Input Class Initialized
INFO - 2016-10-28 13:19:46 --> Language Class Initialized
INFO - 2016-10-28 13:19:46 --> Loader Class Initialized
INFO - 2016-10-28 13:19:46 --> Helper loaded: url_helper
INFO - 2016-10-28 13:19:46 --> Helper loaded: language_helper
INFO - 2016-10-28 13:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:19:46 --> Controller Class Initialized
INFO - 2016-10-28 13:19:46 --> Database Driver Class Initialized
INFO - 2016-10-28 13:19:46 --> Model Class Initialized
INFO - 2016-10-28 13:19:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:19:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:19:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2016-10-28 13:19:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:19:46 --> Final output sent to browser
DEBUG - 2016-10-28 13:19:46 --> Total execution time: 0.0843
INFO - 2016-10-28 13:19:53 --> Config Class Initialized
INFO - 2016-10-28 13:19:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:19:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:19:53 --> Utf8 Class Initialized
INFO - 2016-10-28 13:19:53 --> URI Class Initialized
INFO - 2016-10-28 13:19:53 --> Router Class Initialized
INFO - 2016-10-28 13:19:53 --> Output Class Initialized
INFO - 2016-10-28 13:19:53 --> Security Class Initialized
DEBUG - 2016-10-28 13:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:19:53 --> Input Class Initialized
INFO - 2016-10-28 13:19:53 --> Language Class Initialized
INFO - 2016-10-28 13:19:53 --> Loader Class Initialized
INFO - 2016-10-28 13:19:53 --> Helper loaded: url_helper
INFO - 2016-10-28 13:19:53 --> Helper loaded: language_helper
INFO - 2016-10-28 13:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:19:53 --> Controller Class Initialized
INFO - 2016-10-28 13:19:53 --> Database Driver Class Initialized
INFO - 2016-10-28 13:19:53 --> Model Class Initialized
INFO - 2016-10-28 13:19:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:19:53 --> Helper loaded: form_helper
INFO - 2016-10-28 13:19:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:19:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2016-10-28 13:19:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:19:53 --> Final output sent to browser
DEBUG - 2016-10-28 13:19:53 --> Total execution time: 0.1129
INFO - 2016-10-28 13:20:37 --> Config Class Initialized
INFO - 2016-10-28 13:20:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:20:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:20:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:20:37 --> URI Class Initialized
INFO - 2016-10-28 13:20:37 --> Router Class Initialized
INFO - 2016-10-28 13:20:37 --> Output Class Initialized
INFO - 2016-10-28 13:20:37 --> Security Class Initialized
DEBUG - 2016-10-28 13:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:20:37 --> Input Class Initialized
INFO - 2016-10-28 13:20:37 --> Language Class Initialized
INFO - 2016-10-28 13:20:37 --> Loader Class Initialized
INFO - 2016-10-28 13:20:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:20:37 --> Helper loaded: language_helper
INFO - 2016-10-28 13:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:20:37 --> Controller Class Initialized
INFO - 2016-10-28 13:20:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:20:37 --> Model Class Initialized
INFO - 2016-10-28 13:20:37 --> Model Class Initialized
INFO - 2016-10-28 13:20:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-10-28 13:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:20:37 --> Final output sent to browser
DEBUG - 2016-10-28 13:20:37 --> Total execution time: 0.1408
INFO - 2016-10-28 13:20:39 --> Config Class Initialized
INFO - 2016-10-28 13:20:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:20:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:20:39 --> Utf8 Class Initialized
INFO - 2016-10-28 13:20:39 --> URI Class Initialized
INFO - 2016-10-28 13:20:39 --> Router Class Initialized
INFO - 2016-10-28 13:20:39 --> Output Class Initialized
INFO - 2016-10-28 13:20:39 --> Security Class Initialized
DEBUG - 2016-10-28 13:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:20:39 --> Input Class Initialized
INFO - 2016-10-28 13:20:39 --> Language Class Initialized
INFO - 2016-10-28 13:20:39 --> Loader Class Initialized
INFO - 2016-10-28 13:20:39 --> Helper loaded: url_helper
INFO - 2016-10-28 13:20:39 --> Helper loaded: language_helper
INFO - 2016-10-28 13:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:20:39 --> Controller Class Initialized
INFO - 2016-10-28 13:20:40 --> Database Driver Class Initialized
INFO - 2016-10-28 13:20:40 --> Model Class Initialized
INFO - 2016-10-28 13:20:40 --> Model Class Initialized
INFO - 2016-10-28 13:20:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:20:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:20:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2016-10-28 13:20:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:20:40 --> Final output sent to browser
DEBUG - 2016-10-28 13:20:40 --> Total execution time: 0.0886
INFO - 2016-10-28 13:21:14 --> Config Class Initialized
INFO - 2016-10-28 13:21:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:14 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:14 --> URI Class Initialized
INFO - 2016-10-28 13:21:14 --> Router Class Initialized
INFO - 2016-10-28 13:21:14 --> Output Class Initialized
INFO - 2016-10-28 13:21:14 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:14 --> Input Class Initialized
INFO - 2016-10-28 13:21:14 --> Language Class Initialized
INFO - 2016-10-28 13:21:14 --> Loader Class Initialized
INFO - 2016-10-28 13:21:15 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:15 --> Helper loaded: language_helper
INFO - 2016-10-28 13:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:15 --> Controller Class Initialized
INFO - 2016-10-28 13:21:15 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:15 --> Model Class Initialized
INFO - 2016-10-28 13:21:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:21:15 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:21:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-28 13:21:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:21:15 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:15 --> Total execution time: 0.1084
INFO - 2016-10-28 13:21:22 --> Config Class Initialized
INFO - 2016-10-28 13:21:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:22 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:22 --> URI Class Initialized
INFO - 2016-10-28 13:21:22 --> Router Class Initialized
INFO - 2016-10-28 13:21:22 --> Output Class Initialized
INFO - 2016-10-28 13:21:22 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:22 --> Input Class Initialized
INFO - 2016-10-28 13:21:22 --> Language Class Initialized
INFO - 2016-10-28 13:21:22 --> Loader Class Initialized
INFO - 2016-10-28 13:21:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:22 --> Helper loaded: language_helper
INFO - 2016-10-28 13:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:22 --> Controller Class Initialized
INFO - 2016-10-28 13:21:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:22 --> Model Class Initialized
INFO - 2016-10-28 13:21:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:21:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:21:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2016-10-28 13:21:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:21:22 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:22 --> Total execution time: 0.0872
INFO - 2016-10-28 13:21:25 --> Config Class Initialized
INFO - 2016-10-28 13:21:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:25 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:25 --> URI Class Initialized
INFO - 2016-10-28 13:21:25 --> Router Class Initialized
INFO - 2016-10-28 13:21:25 --> Output Class Initialized
INFO - 2016-10-28 13:21:25 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:25 --> Input Class Initialized
INFO - 2016-10-28 13:21:25 --> Language Class Initialized
INFO - 2016-10-28 13:21:25 --> Loader Class Initialized
INFO - 2016-10-28 13:21:25 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:25 --> Helper loaded: language_helper
INFO - 2016-10-28 13:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:25 --> Controller Class Initialized
INFO - 2016-10-28 13:21:25 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:25 --> Model Class Initialized
INFO - 2016-10-28 13:21:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:21:25 --> Model Class Initialized
INFO - 2016-10-28 13:21:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:21:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2016-10-28 13:21:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:21:25 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:25 --> Total execution time: 0.0905
INFO - 2016-10-28 13:21:36 --> Config Class Initialized
INFO - 2016-10-28 13:21:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:36 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:36 --> URI Class Initialized
INFO - 2016-10-28 13:21:36 --> Router Class Initialized
INFO - 2016-10-28 13:21:36 --> Output Class Initialized
INFO - 2016-10-28 13:21:36 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:36 --> Input Class Initialized
INFO - 2016-10-28 13:21:36 --> Language Class Initialized
INFO - 2016-10-28 13:21:36 --> Loader Class Initialized
INFO - 2016-10-28 13:21:36 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:36 --> Helper loaded: language_helper
INFO - 2016-10-28 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:36 --> Controller Class Initialized
INFO - 2016-10-28 13:21:36 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:36 --> Model Class Initialized
INFO - 2016-10-28 13:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:21:36 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:36 --> Form Validation Class Initialized
INFO - 2016-10-28 13:21:36 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:21:36 --> Config Class Initialized
INFO - 2016-10-28 13:21:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:36 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:36 --> URI Class Initialized
INFO - 2016-10-28 13:21:36 --> Router Class Initialized
INFO - 2016-10-28 13:21:36 --> Output Class Initialized
INFO - 2016-10-28 13:21:36 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:36 --> Input Class Initialized
INFO - 2016-10-28 13:21:36 --> Language Class Initialized
INFO - 2016-10-28 13:21:36 --> Loader Class Initialized
INFO - 2016-10-28 13:21:36 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:36 --> Helper loaded: language_helper
INFO - 2016-10-28 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:36 --> Controller Class Initialized
INFO - 2016-10-28 13:21:36 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:36 --> Model Class Initialized
INFO - 2016-10-28 13:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:21:36 --> Model Class Initialized
INFO - 2016-10-28 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2016-10-28 13:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:21:36 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:36 --> Total execution time: 0.1005
INFO - 2016-10-28 13:21:38 --> Config Class Initialized
INFO - 2016-10-28 13:21:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:38 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:38 --> URI Class Initialized
INFO - 2016-10-28 13:21:38 --> Router Class Initialized
INFO - 2016-10-28 13:21:38 --> Output Class Initialized
INFO - 2016-10-28 13:21:38 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:38 --> Input Class Initialized
INFO - 2016-10-28 13:21:38 --> Language Class Initialized
INFO - 2016-10-28 13:21:38 --> Loader Class Initialized
INFO - 2016-10-28 13:21:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:38 --> Controller Class Initialized
INFO - 2016-10-28 13:21:38 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:38 --> Model Class Initialized
INFO - 2016-10-28 13:21:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:21:38 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:21:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2016-10-28 13:21:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:21:38 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:38 --> Total execution time: 0.1279
INFO - 2016-10-28 13:22:12 --> Config Class Initialized
INFO - 2016-10-28 13:22:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:22:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:22:12 --> Utf8 Class Initialized
INFO - 2016-10-28 13:22:12 --> URI Class Initialized
INFO - 2016-10-28 13:22:12 --> Router Class Initialized
INFO - 2016-10-28 13:22:12 --> Output Class Initialized
INFO - 2016-10-28 13:22:12 --> Security Class Initialized
DEBUG - 2016-10-28 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:22:12 --> Input Class Initialized
INFO - 2016-10-28 13:22:12 --> Language Class Initialized
INFO - 2016-10-28 13:22:12 --> Loader Class Initialized
INFO - 2016-10-28 13:22:12 --> Helper loaded: url_helper
INFO - 2016-10-28 13:22:12 --> Helper loaded: language_helper
INFO - 2016-10-28 13:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:22:12 --> Controller Class Initialized
INFO - 2016-10-28 13:22:12 --> Database Driver Class Initialized
INFO - 2016-10-28 13:22:12 --> Model Class Initialized
INFO - 2016-10-28 13:22:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:22:12 --> Model Class Initialized
INFO - 2016-10-28 13:22:12 --> Model Class Initialized
INFO - 2016-10-28 13:22:12 --> Helper loaded: form_helper
INFO - 2016-10-28 13:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2016-10-28 13:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:22:12 --> Final output sent to browser
DEBUG - 2016-10-28 13:22:12 --> Total execution time: 0.1669
INFO - 2016-10-28 13:22:55 --> Config Class Initialized
INFO - 2016-10-28 13:22:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:22:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:22:55 --> Utf8 Class Initialized
INFO - 2016-10-28 13:22:55 --> URI Class Initialized
INFO - 2016-10-28 13:22:55 --> Router Class Initialized
INFO - 2016-10-28 13:22:55 --> Output Class Initialized
INFO - 2016-10-28 13:22:55 --> Security Class Initialized
DEBUG - 2016-10-28 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:22:55 --> Input Class Initialized
INFO - 2016-10-28 13:22:55 --> Language Class Initialized
INFO - 2016-10-28 13:22:55 --> Loader Class Initialized
INFO - 2016-10-28 13:22:55 --> Helper loaded: url_helper
INFO - 2016-10-28 13:22:55 --> Helper loaded: language_helper
INFO - 2016-10-28 13:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:22:55 --> Controller Class Initialized
INFO - 2016-10-28 13:22:55 --> Database Driver Class Initialized
INFO - 2016-10-28 13:22:55 --> Model Class Initialized
INFO - 2016-10-28 13:22:55 --> Model Class Initialized
INFO - 2016-10-28 13:22:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:22:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:22:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-10-28 13:22:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:22:55 --> Final output sent to browser
DEBUG - 2016-10-28 13:22:55 --> Total execution time: 0.0855
INFO - 2016-10-28 13:23:06 --> Config Class Initialized
INFO - 2016-10-28 13:23:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:06 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:06 --> URI Class Initialized
INFO - 2016-10-28 13:23:06 --> Router Class Initialized
INFO - 2016-10-28 13:23:06 --> Output Class Initialized
INFO - 2016-10-28 13:23:06 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:06 --> Input Class Initialized
INFO - 2016-10-28 13:23:06 --> Language Class Initialized
INFO - 2016-10-28 13:23:06 --> Loader Class Initialized
INFO - 2016-10-28 13:23:06 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:06 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:06 --> Controller Class Initialized
INFO - 2016-10-28 13:23:06 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:06 --> Model Class Initialized
INFO - 2016-10-28 13:23:06 --> Model Class Initialized
INFO - 2016-10-28 13:23:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:06 --> Model Class Initialized
INFO - 2016-10-28 13:23:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:06 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:06 --> Total execution time: 0.1149
INFO - 2016-10-28 13:23:17 --> Config Class Initialized
INFO - 2016-10-28 13:23:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:17 --> URI Class Initialized
INFO - 2016-10-28 13:23:17 --> Router Class Initialized
INFO - 2016-10-28 13:23:17 --> Output Class Initialized
INFO - 2016-10-28 13:23:17 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:17 --> Input Class Initialized
INFO - 2016-10-28 13:23:17 --> Language Class Initialized
INFO - 2016-10-28 13:23:17 --> Loader Class Initialized
INFO - 2016-10-28 13:23:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:17 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:17 --> Controller Class Initialized
INFO - 2016-10-28 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:17 --> Model Class Initialized
INFO - 2016-10-28 13:23:17 --> Model Class Initialized
INFO - 2016-10-28 13:23:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:17 --> Helper loaded: form_helper
INFO - 2016-10-28 13:23:17 --> Form Validation Class Initialized
INFO - 2016-10-28 13:23:17 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:23:17 --> Config Class Initialized
INFO - 2016-10-28 13:23:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:17 --> URI Class Initialized
INFO - 2016-10-28 13:23:17 --> Router Class Initialized
INFO - 2016-10-28 13:23:17 --> Output Class Initialized
INFO - 2016-10-28 13:23:17 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:17 --> Input Class Initialized
INFO - 2016-10-28 13:23:17 --> Language Class Initialized
INFO - 2016-10-28 13:23:17 --> Loader Class Initialized
INFO - 2016-10-28 13:23:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:17 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:17 --> Controller Class Initialized
INFO - 2016-10-28 13:23:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:17 --> Model Class Initialized
INFO - 2016-10-28 13:23:17 --> Model Class Initialized
INFO - 2016-10-28 13:23:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:17 --> Model Class Initialized
INFO - 2016-10-28 13:23:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:17 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:17 --> Total execution time: 0.1498
INFO - 2016-10-28 13:23:20 --> Config Class Initialized
INFO - 2016-10-28 13:23:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:20 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:20 --> URI Class Initialized
INFO - 2016-10-28 13:23:20 --> Router Class Initialized
INFO - 2016-10-28 13:23:20 --> Output Class Initialized
INFO - 2016-10-28 13:23:20 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:20 --> Input Class Initialized
INFO - 2016-10-28 13:23:20 --> Language Class Initialized
INFO - 2016-10-28 13:23:20 --> Loader Class Initialized
INFO - 2016-10-28 13:23:20 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:20 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:21 --> Controller Class Initialized
INFO - 2016-10-28 13:23:21 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:21 --> Model Class Initialized
INFO - 2016-10-28 13:23:21 --> Model Class Initialized
INFO - 2016-10-28 13:23:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-10-28 13:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:21 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:21 --> Total execution time: 0.0834
INFO - 2016-10-28 13:23:22 --> Config Class Initialized
INFO - 2016-10-28 13:23:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:22 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:22 --> URI Class Initialized
INFO - 2016-10-28 13:23:22 --> Router Class Initialized
INFO - 2016-10-28 13:23:23 --> Output Class Initialized
INFO - 2016-10-28 13:23:23 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:23 --> Input Class Initialized
INFO - 2016-10-28 13:23:23 --> Language Class Initialized
INFO - 2016-10-28 13:23:23 --> Loader Class Initialized
INFO - 2016-10-28 13:23:23 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:23 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:23 --> Controller Class Initialized
INFO - 2016-10-28 13:23:23 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:23 --> Model Class Initialized
INFO - 2016-10-28 13:23:23 --> Model Class Initialized
INFO - 2016-10-28 13:23:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:23 --> Model Class Initialized
INFO - 2016-10-28 13:23:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:23 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:23 --> Total execution time: 0.1074
INFO - 2016-10-28 13:23:30 --> Config Class Initialized
INFO - 2016-10-28 13:23:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:30 --> URI Class Initialized
INFO - 2016-10-28 13:23:30 --> Router Class Initialized
INFO - 2016-10-28 13:23:30 --> Output Class Initialized
INFO - 2016-10-28 13:23:30 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:30 --> Input Class Initialized
INFO - 2016-10-28 13:23:30 --> Language Class Initialized
INFO - 2016-10-28 13:23:30 --> Loader Class Initialized
INFO - 2016-10-28 13:23:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:30 --> Controller Class Initialized
INFO - 2016-10-28 13:23:30 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:30 --> Model Class Initialized
INFO - 2016-10-28 13:23:30 --> Model Class Initialized
INFO - 2016-10-28 13:23:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:31 --> Helper loaded: form_helper
INFO - 2016-10-28 13:23:31 --> Form Validation Class Initialized
INFO - 2016-10-28 13:23:31 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:23:31 --> Config Class Initialized
INFO - 2016-10-28 13:23:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:31 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:31 --> URI Class Initialized
INFO - 2016-10-28 13:23:31 --> Router Class Initialized
INFO - 2016-10-28 13:23:31 --> Output Class Initialized
INFO - 2016-10-28 13:23:31 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:31 --> Input Class Initialized
INFO - 2016-10-28 13:23:31 --> Language Class Initialized
INFO - 2016-10-28 13:23:31 --> Loader Class Initialized
INFO - 2016-10-28 13:23:31 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:31 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:31 --> Controller Class Initialized
INFO - 2016-10-28 13:23:31 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:31 --> Model Class Initialized
INFO - 2016-10-28 13:23:31 --> Model Class Initialized
INFO - 2016-10-28 13:23:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:31 --> Model Class Initialized
INFO - 2016-10-28 13:23:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:31 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:31 --> Total execution time: 0.1209
INFO - 2016-10-28 13:23:35 --> Config Class Initialized
INFO - 2016-10-28 13:23:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:35 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:35 --> URI Class Initialized
INFO - 2016-10-28 13:23:35 --> Router Class Initialized
INFO - 2016-10-28 13:23:35 --> Output Class Initialized
INFO - 2016-10-28 13:23:35 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:35 --> Input Class Initialized
INFO - 2016-10-28 13:23:35 --> Language Class Initialized
INFO - 2016-10-28 13:23:35 --> Loader Class Initialized
INFO - 2016-10-28 13:23:35 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:35 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:35 --> Controller Class Initialized
INFO - 2016-10-28 13:23:35 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:35 --> Model Class Initialized
INFO - 2016-10-28 13:23:35 --> Model Class Initialized
INFO - 2016-10-28 13:23:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2016-10-28 13:23:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:35 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:35 --> Total execution time: 0.0821
INFO - 2016-10-28 13:23:39 --> Config Class Initialized
INFO - 2016-10-28 13:23:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:39 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:39 --> URI Class Initialized
INFO - 2016-10-28 13:23:39 --> Router Class Initialized
INFO - 2016-10-28 13:23:39 --> Output Class Initialized
INFO - 2016-10-28 13:23:39 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:39 --> Input Class Initialized
INFO - 2016-10-28 13:23:39 --> Language Class Initialized
INFO - 2016-10-28 13:23:39 --> Loader Class Initialized
INFO - 2016-10-28 13:23:39 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:39 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:39 --> Controller Class Initialized
INFO - 2016-10-28 13:23:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:39 --> Model Class Initialized
INFO - 2016-10-28 13:23:39 --> Model Class Initialized
INFO - 2016-10-28 13:23:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:39 --> Model Class Initialized
INFO - 2016-10-28 13:23:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:39 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:39 --> Total execution time: 0.1278
INFO - 2016-10-28 13:23:40 --> Config Class Initialized
INFO - 2016-10-28 13:23:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:40 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:40 --> URI Class Initialized
INFO - 2016-10-28 13:23:40 --> Router Class Initialized
INFO - 2016-10-28 13:23:40 --> Output Class Initialized
INFO - 2016-10-28 13:23:40 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:40 --> Input Class Initialized
INFO - 2016-10-28 13:23:40 --> Language Class Initialized
INFO - 2016-10-28 13:23:40 --> Loader Class Initialized
INFO - 2016-10-28 13:23:40 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:40 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:40 --> Controller Class Initialized
INFO - 2016-10-28 13:23:40 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:40 --> Model Class Initialized
INFO - 2016-10-28 13:23:40 --> Model Class Initialized
INFO - 2016-10-28 13:23:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:40 --> Model Class Initialized
INFO - 2016-10-28 13:23:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:40 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:40 --> Total execution time: 0.1376
INFO - 2016-10-28 13:23:42 --> Config Class Initialized
INFO - 2016-10-28 13:23:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:42 --> URI Class Initialized
INFO - 2016-10-28 13:23:42 --> Router Class Initialized
INFO - 2016-10-28 13:23:42 --> Output Class Initialized
INFO - 2016-10-28 13:23:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:42 --> Input Class Initialized
INFO - 2016-10-28 13:23:42 --> Language Class Initialized
INFO - 2016-10-28 13:23:42 --> Loader Class Initialized
INFO - 2016-10-28 13:23:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:42 --> Controller Class Initialized
INFO - 2016-10-28 13:23:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:42 --> Model Class Initialized
INFO - 2016-10-28 13:23:42 --> Model Class Initialized
INFO - 2016-10-28 13:23:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:42 --> Model Class Initialized
INFO - 2016-10-28 13:23:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:42 --> Total execution time: 0.1826
INFO - 2016-10-28 13:23:43 --> Config Class Initialized
INFO - 2016-10-28 13:23:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:43 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:43 --> URI Class Initialized
INFO - 2016-10-28 13:23:43 --> Router Class Initialized
INFO - 2016-10-28 13:23:43 --> Output Class Initialized
INFO - 2016-10-28 13:23:43 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:43 --> Input Class Initialized
INFO - 2016-10-28 13:23:43 --> Language Class Initialized
INFO - 2016-10-28 13:23:43 --> Loader Class Initialized
INFO - 2016-10-28 13:23:43 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:43 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:43 --> Controller Class Initialized
INFO - 2016-10-28 13:23:43 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:43 --> Model Class Initialized
INFO - 2016-10-28 13:23:43 --> Model Class Initialized
INFO - 2016-10-28 13:23:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:43 --> Model Class Initialized
INFO - 2016-10-28 13:23:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:43 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:43 --> Total execution time: 0.1496
INFO - 2016-10-28 13:23:46 --> Config Class Initialized
INFO - 2016-10-28 13:23:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:46 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:46 --> URI Class Initialized
INFO - 2016-10-28 13:23:46 --> Router Class Initialized
INFO - 2016-10-28 13:23:46 --> Output Class Initialized
INFO - 2016-10-28 13:23:46 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:46 --> Input Class Initialized
INFO - 2016-10-28 13:23:46 --> Language Class Initialized
INFO - 2016-10-28 13:23:46 --> Loader Class Initialized
INFO - 2016-10-28 13:23:46 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:46 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:46 --> Controller Class Initialized
INFO - 2016-10-28 13:23:46 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:46 --> Model Class Initialized
INFO - 2016-10-28 13:23:46 --> Model Class Initialized
INFO - 2016-10-28 13:23:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:46 --> Model Class Initialized
INFO - 2016-10-28 13:23:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:46 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:46 --> Total execution time: 0.1179
INFO - 2016-10-28 13:23:47 --> Config Class Initialized
INFO - 2016-10-28 13:23:47 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:47 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:47 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:47 --> URI Class Initialized
INFO - 2016-10-28 13:23:47 --> Router Class Initialized
INFO - 2016-10-28 13:23:47 --> Output Class Initialized
INFO - 2016-10-28 13:23:47 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:47 --> Input Class Initialized
INFO - 2016-10-28 13:23:47 --> Language Class Initialized
INFO - 2016-10-28 13:23:47 --> Loader Class Initialized
INFO - 2016-10-28 13:23:47 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:47 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:47 --> Controller Class Initialized
INFO - 2016-10-28 13:23:47 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:47 --> Model Class Initialized
INFO - 2016-10-28 13:23:47 --> Model Class Initialized
INFO - 2016-10-28 13:23:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:47 --> Model Class Initialized
INFO - 2016-10-28 13:23:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:47 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:47 --> Total execution time: 0.1509
INFO - 2016-10-28 13:23:49 --> Config Class Initialized
INFO - 2016-10-28 13:23:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:49 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:49 --> URI Class Initialized
INFO - 2016-10-28 13:23:49 --> Router Class Initialized
INFO - 2016-10-28 13:23:49 --> Output Class Initialized
INFO - 2016-10-28 13:23:49 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:49 --> Input Class Initialized
INFO - 2016-10-28 13:23:49 --> Language Class Initialized
INFO - 2016-10-28 13:23:50 --> Loader Class Initialized
INFO - 2016-10-28 13:23:50 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:50 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:50 --> Controller Class Initialized
INFO - 2016-10-28 13:23:50 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:50 --> Model Class Initialized
INFO - 2016-10-28 13:23:50 --> Model Class Initialized
INFO - 2016-10-28 13:23:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:50 --> Model Class Initialized
INFO - 2016-10-28 13:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:50 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:50 --> Total execution time: 0.2035
INFO - 2016-10-28 13:23:51 --> Config Class Initialized
INFO - 2016-10-28 13:23:51 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:51 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:51 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:51 --> URI Class Initialized
INFO - 2016-10-28 13:23:51 --> Router Class Initialized
INFO - 2016-10-28 13:23:51 --> Output Class Initialized
INFO - 2016-10-28 13:23:51 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:51 --> Input Class Initialized
INFO - 2016-10-28 13:23:51 --> Language Class Initialized
INFO - 2016-10-28 13:23:51 --> Loader Class Initialized
INFO - 2016-10-28 13:23:51 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:51 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:51 --> Controller Class Initialized
INFO - 2016-10-28 13:23:51 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:51 --> Model Class Initialized
INFO - 2016-10-28 13:23:51 --> Model Class Initialized
INFO - 2016-10-28 13:23:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:51 --> Model Class Initialized
INFO - 2016-10-28 13:23:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:51 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:51 --> Total execution time: 0.1504
INFO - 2016-10-28 13:23:53 --> Config Class Initialized
INFO - 2016-10-28 13:23:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:53 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:53 --> URI Class Initialized
INFO - 2016-10-28 13:23:53 --> Router Class Initialized
INFO - 2016-10-28 13:23:53 --> Output Class Initialized
INFO - 2016-10-28 13:23:53 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:53 --> Input Class Initialized
INFO - 2016-10-28 13:23:53 --> Language Class Initialized
INFO - 2016-10-28 13:23:53 --> Loader Class Initialized
INFO - 2016-10-28 13:23:53 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:53 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:53 --> Controller Class Initialized
INFO - 2016-10-28 13:23:53 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:53 --> Model Class Initialized
INFO - 2016-10-28 13:23:53 --> Model Class Initialized
INFO - 2016-10-28 13:23:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:53 --> Model Class Initialized
INFO - 2016-10-28 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:23:53 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:53 --> Total execution time: 0.1254
INFO - 2016-10-28 13:23:58 --> Config Class Initialized
INFO - 2016-10-28 13:23:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:58 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:58 --> URI Class Initialized
INFO - 2016-10-28 13:23:58 --> Router Class Initialized
INFO - 2016-10-28 13:23:58 --> Output Class Initialized
INFO - 2016-10-28 13:23:58 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:58 --> Input Class Initialized
INFO - 2016-10-28 13:23:58 --> Language Class Initialized
INFO - 2016-10-28 13:23:58 --> Loader Class Initialized
INFO - 2016-10-28 13:23:58 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:58 --> Helper loaded: language_helper
INFO - 2016-10-28 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:58 --> Controller Class Initialized
INFO - 2016-10-28 13:23:58 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:58 --> Model Class Initialized
INFO - 2016-10-28 13:23:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:23:58 --> Model Class Initialized
INFO - 2016-10-28 13:24:01 --> Config Class Initialized
INFO - 2016-10-28 13:24:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:01 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:01 --> URI Class Initialized
INFO - 2016-10-28 13:24:01 --> Router Class Initialized
INFO - 2016-10-28 13:24:01 --> Output Class Initialized
INFO - 2016-10-28 13:24:01 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:01 --> Input Class Initialized
INFO - 2016-10-28 13:24:01 --> Language Class Initialized
INFO - 2016-10-28 13:24:01 --> Loader Class Initialized
INFO - 2016-10-28 13:24:01 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:01 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:01 --> Controller Class Initialized
INFO - 2016-10-28 13:24:01 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:01 --> Model Class Initialized
INFO - 2016-10-28 13:24:01 --> Model Class Initialized
INFO - 2016-10-28 13:24:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:01 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:01 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:01 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:01 --> Config Class Initialized
INFO - 2016-10-28 13:24:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:01 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:01 --> URI Class Initialized
INFO - 2016-10-28 13:24:01 --> Router Class Initialized
INFO - 2016-10-28 13:24:01 --> Output Class Initialized
INFO - 2016-10-28 13:24:01 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:01 --> Input Class Initialized
INFO - 2016-10-28 13:24:01 --> Language Class Initialized
INFO - 2016-10-28 13:24:01 --> Loader Class Initialized
INFO - 2016-10-28 13:24:01 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:01 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:01 --> Controller Class Initialized
INFO - 2016-10-28 13:24:01 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:01 --> Model Class Initialized
INFO - 2016-10-28 13:24:01 --> Model Class Initialized
INFO - 2016-10-28 13:24:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:01 --> Model Class Initialized
INFO - 2016-10-28 13:24:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:01 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:01 --> Total execution time: 0.1391
INFO - 2016-10-28 13:24:08 --> Config Class Initialized
INFO - 2016-10-28 13:24:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:08 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:08 --> URI Class Initialized
INFO - 2016-10-28 13:24:08 --> Router Class Initialized
INFO - 2016-10-28 13:24:08 --> Output Class Initialized
INFO - 2016-10-28 13:24:08 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:08 --> Input Class Initialized
INFO - 2016-10-28 13:24:08 --> Language Class Initialized
INFO - 2016-10-28 13:24:08 --> Loader Class Initialized
INFO - 2016-10-28 13:24:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:08 --> Controller Class Initialized
INFO - 2016-10-28 13:24:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:08 --> Model Class Initialized
INFO - 2016-10-28 13:24:08 --> Model Class Initialized
INFO - 2016-10-28 13:24:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:08 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:08 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:08 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:08 --> Config Class Initialized
INFO - 2016-10-28 13:24:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:08 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:08 --> URI Class Initialized
INFO - 2016-10-28 13:24:08 --> Router Class Initialized
INFO - 2016-10-28 13:24:08 --> Output Class Initialized
INFO - 2016-10-28 13:24:08 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:08 --> Input Class Initialized
INFO - 2016-10-28 13:24:08 --> Language Class Initialized
INFO - 2016-10-28 13:24:08 --> Loader Class Initialized
INFO - 2016-10-28 13:24:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:08 --> Controller Class Initialized
INFO - 2016-10-28 13:24:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:08 --> Model Class Initialized
INFO - 2016-10-28 13:24:08 --> Model Class Initialized
INFO - 2016-10-28 13:24:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:08 --> Model Class Initialized
INFO - 2016-10-28 13:24:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:08 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:08 --> Total execution time: 0.0976
INFO - 2016-10-28 13:24:16 --> Config Class Initialized
INFO - 2016-10-28 13:24:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:16 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:16 --> URI Class Initialized
INFO - 2016-10-28 13:24:16 --> Router Class Initialized
INFO - 2016-10-28 13:24:16 --> Output Class Initialized
INFO - 2016-10-28 13:24:16 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:16 --> Input Class Initialized
INFO - 2016-10-28 13:24:16 --> Language Class Initialized
INFO - 2016-10-28 13:24:16 --> Loader Class Initialized
INFO - 2016-10-28 13:24:16 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:16 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:16 --> Controller Class Initialized
INFO - 2016-10-28 13:24:16 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:16 --> Model Class Initialized
INFO - 2016-10-28 13:24:16 --> Model Class Initialized
INFO - 2016-10-28 13:24:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:16 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:16 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:16 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:16 --> Config Class Initialized
INFO - 2016-10-28 13:24:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:16 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:16 --> URI Class Initialized
INFO - 2016-10-28 13:24:16 --> Router Class Initialized
INFO - 2016-10-28 13:24:16 --> Output Class Initialized
INFO - 2016-10-28 13:24:16 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:16 --> Input Class Initialized
INFO - 2016-10-28 13:24:16 --> Language Class Initialized
INFO - 2016-10-28 13:24:16 --> Loader Class Initialized
INFO - 2016-10-28 13:24:16 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:16 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:16 --> Controller Class Initialized
INFO - 2016-10-28 13:24:16 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:16 --> Model Class Initialized
INFO - 2016-10-28 13:24:16 --> Model Class Initialized
INFO - 2016-10-28 13:24:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:16 --> Model Class Initialized
INFO - 2016-10-28 13:24:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:16 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:16 --> Total execution time: 0.1205
INFO - 2016-10-28 13:24:22 --> Config Class Initialized
INFO - 2016-10-28 13:24:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:22 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:22 --> URI Class Initialized
INFO - 2016-10-28 13:24:22 --> Router Class Initialized
INFO - 2016-10-28 13:24:22 --> Output Class Initialized
INFO - 2016-10-28 13:24:22 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:22 --> Input Class Initialized
INFO - 2016-10-28 13:24:22 --> Language Class Initialized
INFO - 2016-10-28 13:24:22 --> Loader Class Initialized
INFO - 2016-10-28 13:24:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:22 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:22 --> Controller Class Initialized
INFO - 2016-10-28 13:24:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:22 --> Model Class Initialized
INFO - 2016-10-28 13:24:22 --> Model Class Initialized
INFO - 2016-10-28 13:24:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:22 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:22 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:22 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:22 --> Config Class Initialized
INFO - 2016-10-28 13:24:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:22 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:22 --> URI Class Initialized
INFO - 2016-10-28 13:24:22 --> Router Class Initialized
INFO - 2016-10-28 13:24:22 --> Output Class Initialized
INFO - 2016-10-28 13:24:22 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:22 --> Input Class Initialized
INFO - 2016-10-28 13:24:22 --> Language Class Initialized
INFO - 2016-10-28 13:24:22 --> Loader Class Initialized
INFO - 2016-10-28 13:24:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:22 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:22 --> Controller Class Initialized
INFO - 2016-10-28 13:24:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:22 --> Model Class Initialized
INFO - 2016-10-28 13:24:22 --> Model Class Initialized
INFO - 2016-10-28 13:24:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:22 --> Model Class Initialized
INFO - 2016-10-28 13:24:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:22 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:22 --> Total execution time: 0.1119
INFO - 2016-10-28 13:24:29 --> Config Class Initialized
INFO - 2016-10-28 13:24:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:29 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:29 --> URI Class Initialized
INFO - 2016-10-28 13:24:29 --> Router Class Initialized
INFO - 2016-10-28 13:24:29 --> Output Class Initialized
INFO - 2016-10-28 13:24:29 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:29 --> Input Class Initialized
INFO - 2016-10-28 13:24:29 --> Language Class Initialized
INFO - 2016-10-28 13:24:29 --> Loader Class Initialized
INFO - 2016-10-28 13:24:29 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:29 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:29 --> Controller Class Initialized
INFO - 2016-10-28 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:29 --> Model Class Initialized
INFO - 2016-10-28 13:24:29 --> Model Class Initialized
INFO - 2016-10-28 13:24:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:29 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:29 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:29 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:29 --> Config Class Initialized
INFO - 2016-10-28 13:24:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:29 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:29 --> URI Class Initialized
INFO - 2016-10-28 13:24:29 --> Router Class Initialized
INFO - 2016-10-28 13:24:29 --> Output Class Initialized
INFO - 2016-10-28 13:24:29 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:29 --> Input Class Initialized
INFO - 2016-10-28 13:24:29 --> Language Class Initialized
INFO - 2016-10-28 13:24:29 --> Loader Class Initialized
INFO - 2016-10-28 13:24:29 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:29 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:29 --> Controller Class Initialized
INFO - 2016-10-28 13:24:29 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:30 --> Model Class Initialized
INFO - 2016-10-28 13:24:30 --> Model Class Initialized
INFO - 2016-10-28 13:24:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:30 --> Model Class Initialized
INFO - 2016-10-28 13:24:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:30 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:30 --> Total execution time: 0.0877
INFO - 2016-10-28 13:24:38 --> Config Class Initialized
INFO - 2016-10-28 13:24:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:38 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:38 --> URI Class Initialized
INFO - 2016-10-28 13:24:38 --> Router Class Initialized
INFO - 2016-10-28 13:24:38 --> Output Class Initialized
INFO - 2016-10-28 13:24:38 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:38 --> Input Class Initialized
INFO - 2016-10-28 13:24:38 --> Language Class Initialized
INFO - 2016-10-28 13:24:38 --> Loader Class Initialized
INFO - 2016-10-28 13:24:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:38 --> Controller Class Initialized
INFO - 2016-10-28 13:24:38 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:38 --> Model Class Initialized
INFO - 2016-10-28 13:24:38 --> Model Class Initialized
INFO - 2016-10-28 13:24:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:38 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:38 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:38 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:38 --> Config Class Initialized
INFO - 2016-10-28 13:24:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:38 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:38 --> URI Class Initialized
INFO - 2016-10-28 13:24:38 --> Router Class Initialized
INFO - 2016-10-28 13:24:38 --> Output Class Initialized
INFO - 2016-10-28 13:24:38 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:38 --> Input Class Initialized
INFO - 2016-10-28 13:24:38 --> Language Class Initialized
INFO - 2016-10-28 13:24:38 --> Loader Class Initialized
INFO - 2016-10-28 13:24:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:38 --> Controller Class Initialized
INFO - 2016-10-28 13:24:38 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:38 --> Model Class Initialized
INFO - 2016-10-28 13:24:38 --> Model Class Initialized
INFO - 2016-10-28 13:24:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:38 --> Model Class Initialized
INFO - 2016-10-28 13:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:38 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:38 --> Total execution time: 0.0891
INFO - 2016-10-28 13:24:45 --> Config Class Initialized
INFO - 2016-10-28 13:24:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:45 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:45 --> URI Class Initialized
INFO - 2016-10-28 13:24:45 --> Router Class Initialized
INFO - 2016-10-28 13:24:45 --> Output Class Initialized
INFO - 2016-10-28 13:24:45 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:45 --> Input Class Initialized
INFO - 2016-10-28 13:24:45 --> Language Class Initialized
INFO - 2016-10-28 13:24:45 --> Loader Class Initialized
INFO - 2016-10-28 13:24:45 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:45 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:45 --> Controller Class Initialized
INFO - 2016-10-28 13:24:45 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:45 --> Model Class Initialized
INFO - 2016-10-28 13:24:45 --> Model Class Initialized
INFO - 2016-10-28 13:24:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:45 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:45 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:45 --> Config Class Initialized
INFO - 2016-10-28 13:24:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:45 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:45 --> URI Class Initialized
INFO - 2016-10-28 13:24:45 --> Router Class Initialized
INFO - 2016-10-28 13:24:45 --> Output Class Initialized
INFO - 2016-10-28 13:24:45 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:45 --> Input Class Initialized
INFO - 2016-10-28 13:24:45 --> Language Class Initialized
INFO - 2016-10-28 13:24:45 --> Loader Class Initialized
INFO - 2016-10-28 13:24:45 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:45 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:45 --> Controller Class Initialized
INFO - 2016-10-28 13:24:45 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:45 --> Model Class Initialized
INFO - 2016-10-28 13:24:45 --> Model Class Initialized
INFO - 2016-10-28 13:24:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:45 --> Model Class Initialized
INFO - 2016-10-28 13:24:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:45 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:45 --> Total execution time: 0.1235
INFO - 2016-10-28 13:24:52 --> Config Class Initialized
INFO - 2016-10-28 13:24:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:52 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:52 --> URI Class Initialized
INFO - 2016-10-28 13:24:52 --> Router Class Initialized
INFO - 2016-10-28 13:24:52 --> Output Class Initialized
INFO - 2016-10-28 13:24:52 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:52 --> Input Class Initialized
INFO - 2016-10-28 13:24:52 --> Language Class Initialized
INFO - 2016-10-28 13:24:52 --> Loader Class Initialized
INFO - 2016-10-28 13:24:52 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:52 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:52 --> Controller Class Initialized
INFO - 2016-10-28 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:52 --> Model Class Initialized
INFO - 2016-10-28 13:24:52 --> Model Class Initialized
INFO - 2016-10-28 13:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:52 --> Helper loaded: form_helper
INFO - 2016-10-28 13:24:52 --> Form Validation Class Initialized
INFO - 2016-10-28 13:24:52 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2016-10-28 13:24:52 --> Config Class Initialized
INFO - 2016-10-28 13:24:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:24:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:24:52 --> Utf8 Class Initialized
INFO - 2016-10-28 13:24:52 --> URI Class Initialized
INFO - 2016-10-28 13:24:52 --> Router Class Initialized
INFO - 2016-10-28 13:24:52 --> Output Class Initialized
INFO - 2016-10-28 13:24:52 --> Security Class Initialized
DEBUG - 2016-10-28 13:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:24:52 --> Input Class Initialized
INFO - 2016-10-28 13:24:52 --> Language Class Initialized
INFO - 2016-10-28 13:24:52 --> Loader Class Initialized
INFO - 2016-10-28 13:24:52 --> Helper loaded: url_helper
INFO - 2016-10-28 13:24:52 --> Helper loaded: language_helper
INFO - 2016-10-28 13:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:24:52 --> Controller Class Initialized
INFO - 2016-10-28 13:24:52 --> Database Driver Class Initialized
INFO - 2016-10-28 13:24:52 --> Model Class Initialized
INFO - 2016-10-28 13:24:52 --> Model Class Initialized
INFO - 2016-10-28 13:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:24:52 --> Model Class Initialized
INFO - 2016-10-28 13:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2016-10-28 13:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:24:52 --> Final output sent to browser
DEBUG - 2016-10-28 13:24:52 --> Total execution time: 0.1441
INFO - 2016-10-28 13:25:10 --> Config Class Initialized
INFO - 2016-10-28 13:25:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:10 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:10 --> URI Class Initialized
INFO - 2016-10-28 13:25:10 --> Router Class Initialized
INFO - 2016-10-28 13:25:10 --> Output Class Initialized
INFO - 2016-10-28 13:25:10 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:10 --> Input Class Initialized
INFO - 2016-10-28 13:25:10 --> Language Class Initialized
INFO - 2016-10-28 13:25:10 --> Loader Class Initialized
INFO - 2016-10-28 13:25:10 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:10 --> Helper loaded: language_helper
INFO - 2016-10-28 13:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:10 --> Controller Class Initialized
INFO - 2016-10-28 13:25:10 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:10 --> Model Class Initialized
INFO - 2016-10-28 13:25:10 --> Model Class Initialized
INFO - 2016-10-28 13:25:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-10-28 13:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:25:10 --> Final output sent to browser
DEBUG - 2016-10-28 13:25:10 --> Total execution time: 0.1219
INFO - 2016-10-28 13:25:18 --> Config Class Initialized
INFO - 2016-10-28 13:25:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:18 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:18 --> URI Class Initialized
INFO - 2016-10-28 13:25:18 --> Router Class Initialized
INFO - 2016-10-28 13:25:18 --> Output Class Initialized
INFO - 2016-10-28 13:25:18 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:18 --> Input Class Initialized
INFO - 2016-10-28 13:25:18 --> Language Class Initialized
ERROR - 2016-10-28 13:25:18 --> 404 Page Not Found: Disc_new/index
INFO - 2016-10-28 13:25:24 --> Config Class Initialized
INFO - 2016-10-28 13:25:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:24 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:24 --> URI Class Initialized
INFO - 2016-10-28 13:25:24 --> Router Class Initialized
INFO - 2016-10-28 13:25:24 --> Output Class Initialized
INFO - 2016-10-28 13:25:24 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:24 --> Input Class Initialized
INFO - 2016-10-28 13:25:24 --> Language Class Initialized
INFO - 2016-10-28 13:25:24 --> Loader Class Initialized
INFO - 2016-10-28 13:25:24 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:24 --> Helper loaded: language_helper
INFO - 2016-10-28 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:24 --> Controller Class Initialized
INFO - 2016-10-28 13:25:24 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:24 --> Model Class Initialized
INFO - 2016-10-28 13:25:24 --> Model Class Initialized
INFO - 2016-10-28 13:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-10-28 13:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:25:24 --> Final output sent to browser
DEBUG - 2016-10-28 13:25:24 --> Total execution time: 0.0980
INFO - 2016-10-28 13:25:39 --> Config Class Initialized
INFO - 2016-10-28 13:25:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:39 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:39 --> URI Class Initialized
INFO - 2016-10-28 13:25:39 --> Router Class Initialized
INFO - 2016-10-28 13:25:39 --> Output Class Initialized
INFO - 2016-10-28 13:25:39 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:39 --> Input Class Initialized
INFO - 2016-10-28 13:25:39 --> Language Class Initialized
INFO - 2016-10-28 13:25:39 --> Loader Class Initialized
INFO - 2016-10-28 13:25:39 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:39 --> Helper loaded: language_helper
INFO - 2016-10-28 13:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:39 --> Controller Class Initialized
INFO - 2016-10-28 13:25:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:39 --> Model Class Initialized
INFO - 2016-10-28 13:25:39 --> Model Class Initialized
INFO - 2016-10-28 13:25:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:25:39 --> Helper loaded: form_helper
INFO - 2016-10-28 13:25:39 --> Form Validation Class Initialized
INFO - 2016-10-28 13:25:39 --> Config Class Initialized
INFO - 2016-10-28 13:25:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:39 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:39 --> URI Class Initialized
INFO - 2016-10-28 13:25:39 --> Router Class Initialized
INFO - 2016-10-28 13:25:39 --> Output Class Initialized
INFO - 2016-10-28 13:25:39 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:39 --> Input Class Initialized
INFO - 2016-10-28 13:25:39 --> Language Class Initialized
INFO - 2016-10-28 13:25:39 --> Loader Class Initialized
INFO - 2016-10-28 13:25:39 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:39 --> Helper loaded: language_helper
INFO - 2016-10-28 13:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:39 --> Controller Class Initialized
INFO - 2016-10-28 13:25:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:39 --> Model Class Initialized
INFO - 2016-10-28 13:25:39 --> Model Class Initialized
INFO - 2016-10-28 13:25:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:25:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:25:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_disc_statement.php
INFO - 2016-10-28 13:25:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:25:39 --> Final output sent to browser
DEBUG - 2016-10-28 13:25:39 --> Total execution time: 0.0898
INFO - 2016-10-28 13:26:04 --> Config Class Initialized
INFO - 2016-10-28 13:26:04 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:26:04 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:04 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:04 --> URI Class Initialized
INFO - 2016-10-28 13:26:04 --> Router Class Initialized
INFO - 2016-10-28 13:26:04 --> Output Class Initialized
INFO - 2016-10-28 13:26:04 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:04 --> Input Class Initialized
INFO - 2016-10-28 13:26:04 --> Language Class Initialized
INFO - 2016-10-28 13:26:04 --> Loader Class Initialized
INFO - 2016-10-28 13:26:04 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:04 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:04 --> Controller Class Initialized
INFO - 2016-10-28 13:26:04 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:04 --> Model Class Initialized
INFO - 2016-10-28 13:26:04 --> Model Class Initialized
INFO - 2016-10-28 13:26:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:26:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:26:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2016-10-28 13:26:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:26:04 --> Final output sent to browser
DEBUG - 2016-10-28 13:26:04 --> Total execution time: 0.1209
INFO - 2016-10-28 13:26:23 --> Config Class Initialized
INFO - 2016-10-28 13:26:23 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:26:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:23 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:23 --> URI Class Initialized
INFO - 2016-10-28 13:26:23 --> Router Class Initialized
INFO - 2016-10-28 13:26:23 --> Output Class Initialized
INFO - 2016-10-28 13:26:23 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:23 --> Input Class Initialized
INFO - 2016-10-28 13:26:23 --> Language Class Initialized
INFO - 2016-10-28 13:26:23 --> Loader Class Initialized
INFO - 2016-10-28 13:26:23 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:23 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:23 --> Controller Class Initialized
INFO - 2016-10-28 13:26:23 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:23 --> Model Class Initialized
INFO - 2016-10-28 13:26:23 --> Model Class Initialized
INFO - 2016-10-28 13:26:23 --> Model Class Initialized
INFO - 2016-10-28 13:26:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:26:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:26:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2016-10-28 13:26:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:26:23 --> Final output sent to browser
DEBUG - 2016-10-28 13:26:23 --> Total execution time: 0.1730
INFO - 2016-10-28 13:26:27 --> Config Class Initialized
INFO - 2016-10-28 13:26:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:26:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:27 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:27 --> URI Class Initialized
INFO - 2016-10-28 13:26:27 --> Router Class Initialized
INFO - 2016-10-28 13:26:27 --> Output Class Initialized
INFO - 2016-10-28 13:26:27 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:27 --> Input Class Initialized
INFO - 2016-10-28 13:26:27 --> Language Class Initialized
INFO - 2016-10-28 13:26:27 --> Loader Class Initialized
INFO - 2016-10-28 13:26:27 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:27 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:27 --> Controller Class Initialized
INFO - 2016-10-28 13:26:27 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:27 --> Model Class Initialized
INFO - 2016-10-28 13:26:27 --> Model Class Initialized
INFO - 2016-10-28 13:26:27 --> Model Class Initialized
INFO - 2016-10-28 13:26:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2016-10-28 13:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:26:27 --> Final output sent to browser
DEBUG - 2016-10-28 13:26:27 --> Total execution time: 0.0845
INFO - 2016-10-28 13:26:30 --> Config Class Initialized
INFO - 2016-10-28 13:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:30 --> URI Class Initialized
INFO - 2016-10-28 13:26:30 --> Router Class Initialized
INFO - 2016-10-28 13:26:30 --> Output Class Initialized
INFO - 2016-10-28 13:26:30 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:30 --> Input Class Initialized
INFO - 2016-10-28 13:26:30 --> Language Class Initialized
INFO - 2016-10-28 13:26:30 --> Loader Class Initialized
INFO - 2016-10-28 13:26:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:30 --> Controller Class Initialized
INFO - 2016-10-28 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:26:30 --> Config Class Initialized
INFO - 2016-10-28 13:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:30 --> URI Class Initialized
INFO - 2016-10-28 13:26:30 --> Router Class Initialized
INFO - 2016-10-28 13:26:30 --> Output Class Initialized
INFO - 2016-10-28 13:26:30 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:30 --> Input Class Initialized
INFO - 2016-10-28 13:26:30 --> Language Class Initialized
INFO - 2016-10-28 13:26:30 --> Loader Class Initialized
INFO - 2016-10-28 13:26:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:30 --> Controller Class Initialized
INFO - 2016-10-28 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2016-10-28 13:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:26:30 --> Final output sent to browser
DEBUG - 2016-10-28 13:26:30 --> Total execution time: 0.1093
INFO - 2016-10-28 13:26:30 --> Config Class Initialized
INFO - 2016-10-28 13:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:30 --> URI Class Initialized
INFO - 2016-10-28 13:26:30 --> Router Class Initialized
INFO - 2016-10-28 13:26:30 --> Config Class Initialized
INFO - 2016-10-28 13:26:30 --> Hooks Class Initialized
INFO - 2016-10-28 13:26:30 --> Output Class Initialized
INFO - 2016-10-28 13:26:30 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:30 --> Input Class Initialized
DEBUG - 2016-10-28 13:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:26:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:26:30 --> Language Class Initialized
INFO - 2016-10-28 13:26:30 --> URI Class Initialized
INFO - 2016-10-28 13:26:30 --> Loader Class Initialized
INFO - 2016-10-28 13:26:30 --> Router Class Initialized
INFO - 2016-10-28 13:26:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:30 --> Output Class Initialized
INFO - 2016-10-28 13:26:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:30 --> Security Class Initialized
DEBUG - 2016-10-28 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:26:30 --> Input Class Initialized
INFO - 2016-10-28 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:30 --> Language Class Initialized
INFO - 2016-10-28 13:26:30 --> Controller Class Initialized
INFO - 2016-10-28 13:26:30 --> Loader Class Initialized
INFO - 2016-10-28 13:26:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:26:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:26:30 --> Final output sent to browser
DEBUG - 2016-10-28 13:26:30 --> Total execution time: 0.0983
INFO - 2016-10-28 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:26:30 --> Controller Class Initialized
INFO - 2016-10-28 13:26:30 --> Database Driver Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Model Class Initialized
INFO - 2016-10-28 13:26:30 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-28 13:26:30 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-28 13:26:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-28 13:26:30 --> Final output sent to browser
DEBUG - 2016-10-28 13:26:30 --> Total execution time: 0.1413
INFO - 2016-10-28 13:27:00 --> Config Class Initialized
INFO - 2016-10-28 13:27:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:00 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:00 --> URI Class Initialized
INFO - 2016-10-28 13:27:00 --> Config Class Initialized
INFO - 2016-10-28 13:27:00 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:00 --> Router Class Initialized
INFO - 2016-10-28 13:27:00 --> Output Class Initialized
DEBUG - 2016-10-28 13:27:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:00 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:00 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:00 --> Input Class Initialized
INFO - 2016-10-28 13:27:00 --> Language Class Initialized
INFO - 2016-10-28 13:27:00 --> URI Class Initialized
INFO - 2016-10-28 13:27:00 --> Loader Class Initialized
INFO - 2016-10-28 13:27:00 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:00 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:00 --> Router Class Initialized
INFO - 2016-10-28 13:27:00 --> Output Class Initialized
INFO - 2016-10-28 13:27:00 --> Security Class Initialized
INFO - 2016-10-28 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:00 --> Controller Class Initialized
DEBUG - 2016-10-28 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:00 --> Input Class Initialized
INFO - 2016-10-28 13:27:00 --> Language Class Initialized
INFO - 2016-10-28 13:27:00 --> Loader Class Initialized
INFO - 2016-10-28 13:27:00 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:00 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:00 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:00 --> Total execution time: 0.0840
INFO - 2016-10-28 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:00 --> Controller Class Initialized
INFO - 2016-10-28 13:27:00 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:00 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:00 --> Total execution time: 0.1947
INFO - 2016-10-28 13:27:00 --> Config Class Initialized
INFO - 2016-10-28 13:27:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:00 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:00 --> URI Class Initialized
INFO - 2016-10-28 13:27:00 --> Router Class Initialized
INFO - 2016-10-28 13:27:00 --> Output Class Initialized
INFO - 2016-10-28 13:27:00 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:00 --> Input Class Initialized
INFO - 2016-10-28 13:27:00 --> Language Class Initialized
INFO - 2016-10-28 13:27:00 --> Loader Class Initialized
INFO - 2016-10-28 13:27:00 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:00 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:00 --> Controller Class Initialized
INFO - 2016-10-28 13:27:00 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Model Class Initialized
INFO - 2016-10-28 13:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:00 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:00 --> Total execution time: 0.0862
INFO - 2016-10-28 13:27:02 --> Config Class Initialized
INFO - 2016-10-28 13:27:02 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:02 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:02 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:02 --> URI Class Initialized
INFO - 2016-10-28 13:27:02 --> Config Class Initialized
INFO - 2016-10-28 13:27:02 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:02 --> Router Class Initialized
INFO - 2016-10-28 13:27:02 --> Output Class Initialized
DEBUG - 2016-10-28 13:27:02 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:02 --> Security Class Initialized
INFO - 2016-10-28 13:27:02 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:02 --> URI Class Initialized
INFO - 2016-10-28 13:27:02 --> Input Class Initialized
INFO - 2016-10-28 13:27:02 --> Language Class Initialized
INFO - 2016-10-28 13:27:02 --> Router Class Initialized
INFO - 2016-10-28 13:27:02 --> Output Class Initialized
INFO - 2016-10-28 13:27:02 --> Loader Class Initialized
INFO - 2016-10-28 13:27:02 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:02 --> Input Class Initialized
INFO - 2016-10-28 13:27:02 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:02 --> Language Class Initialized
INFO - 2016-10-28 13:27:02 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:02 --> Loader Class Initialized
INFO - 2016-10-28 13:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:02 --> Controller Class Initialized
INFO - 2016-10-28 13:27:02 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:02 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:02 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:02 --> Model Class Initialized
INFO - 2016-10-28 13:27:02 --> Model Class Initialized
INFO - 2016-10-28 13:27:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:02 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:02 --> Total execution time: 0.1186
INFO - 2016-10-28 13:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:02 --> Controller Class Initialized
INFO - 2016-10-28 13:27:02 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:02 --> Model Class Initialized
INFO - 2016-10-28 13:27:02 --> Model Class Initialized
INFO - 2016-10-28 13:27:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:02 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:02 --> Total execution time: 0.1891
INFO - 2016-10-28 13:27:03 --> Config Class Initialized
INFO - 2016-10-28 13:27:03 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:03 --> Config Class Initialized
INFO - 2016-10-28 13:27:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:03 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:03 --> URI Class Initialized
INFO - 2016-10-28 13:27:03 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:03 --> URI Class Initialized
INFO - 2016-10-28 13:27:03 --> Router Class Initialized
INFO - 2016-10-28 13:27:03 --> Router Class Initialized
INFO - 2016-10-28 13:27:03 --> Output Class Initialized
INFO - 2016-10-28 13:27:03 --> Output Class Initialized
INFO - 2016-10-28 13:27:03 --> Security Class Initialized
INFO - 2016-10-28 13:27:03 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:03 --> Input Class Initialized
INFO - 2016-10-28 13:27:03 --> Language Class Initialized
DEBUG - 2016-10-28 13:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:03 --> Input Class Initialized
INFO - 2016-10-28 13:27:03 --> Language Class Initialized
INFO - 2016-10-28 13:27:03 --> Loader Class Initialized
INFO - 2016-10-28 13:27:03 --> Loader Class Initialized
INFO - 2016-10-28 13:27:03 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:03 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:03 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:03 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:03 --> Controller Class Initialized
INFO - 2016-10-28 13:27:03 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:03 --> Model Class Initialized
INFO - 2016-10-28 13:27:03 --> Model Class Initialized
INFO - 2016-10-28 13:27:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:03 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:03 --> Total execution time: 0.2002
INFO - 2016-10-28 13:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:03 --> Controller Class Initialized
INFO - 2016-10-28 13:27:03 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:04 --> Model Class Initialized
INFO - 2016-10-28 13:27:04 --> Model Class Initialized
INFO - 2016-10-28 13:27:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:04 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:04 --> Total execution time: 0.2534
INFO - 2016-10-28 13:27:05 --> Config Class Initialized
INFO - 2016-10-28 13:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:05 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:05 --> Config Class Initialized
INFO - 2016-10-28 13:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:05 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:05 --> URI Class Initialized
INFO - 2016-10-28 13:27:05 --> URI Class Initialized
INFO - 2016-10-28 13:27:05 --> Router Class Initialized
INFO - 2016-10-28 13:27:05 --> Router Class Initialized
INFO - 2016-10-28 13:27:05 --> Output Class Initialized
INFO - 2016-10-28 13:27:05 --> Security Class Initialized
INFO - 2016-10-28 13:27:05 --> Output Class Initialized
DEBUG - 2016-10-28 13:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:05 --> Security Class Initialized
INFO - 2016-10-28 13:27:05 --> Input Class Initialized
INFO - 2016-10-28 13:27:05 --> Language Class Initialized
DEBUG - 2016-10-28 13:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:05 --> Input Class Initialized
INFO - 2016-10-28 13:27:05 --> Language Class Initialized
INFO - 2016-10-28 13:27:05 --> Loader Class Initialized
INFO - 2016-10-28 13:27:05 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:05 --> Loader Class Initialized
INFO - 2016-10-28 13:27:05 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:05 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:05 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:05 --> Controller Class Initialized
INFO - 2016-10-28 13:27:05 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:05 --> Model Class Initialized
INFO - 2016-10-28 13:27:05 --> Model Class Initialized
INFO - 2016-10-28 13:27:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:05 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:05 --> Total execution time: 0.1061
INFO - 2016-10-28 13:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:05 --> Controller Class Initialized
INFO - 2016-10-28 13:27:05 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:05 --> Model Class Initialized
INFO - 2016-10-28 13:27:05 --> Model Class Initialized
INFO - 2016-10-28 13:27:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:05 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:05 --> Total execution time: 0.2531
INFO - 2016-10-28 13:27:07 --> Config Class Initialized
INFO - 2016-10-28 13:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:07 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:07 --> URI Class Initialized
INFO - 2016-10-28 13:27:07 --> Router Class Initialized
INFO - 2016-10-28 13:27:07 --> Output Class Initialized
INFO - 2016-10-28 13:27:07 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:07 --> Input Class Initialized
INFO - 2016-10-28 13:27:07 --> Language Class Initialized
INFO - 2016-10-28 13:27:07 --> Loader Class Initialized
INFO - 2016-10-28 13:27:07 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:07 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:07 --> Controller Class Initialized
INFO - 2016-10-28 13:27:07 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:07 --> Model Class Initialized
INFO - 2016-10-28 13:27:07 --> Model Class Initialized
INFO - 2016-10-28 13:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:07 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:07 --> Total execution time: 0.1424
INFO - 2016-10-28 13:27:08 --> Config Class Initialized
INFO - 2016-10-28 13:27:08 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:08 --> Config Class Initialized
INFO - 2016-10-28 13:27:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:08 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:08 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:08 --> URI Class Initialized
INFO - 2016-10-28 13:27:08 --> URI Class Initialized
INFO - 2016-10-28 13:27:08 --> Router Class Initialized
INFO - 2016-10-28 13:27:08 --> Router Class Initialized
INFO - 2016-10-28 13:27:08 --> Output Class Initialized
INFO - 2016-10-28 13:27:08 --> Output Class Initialized
INFO - 2016-10-28 13:27:08 --> Config Class Initialized
INFO - 2016-10-28 13:27:08 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:08 --> Security Class Initialized
INFO - 2016-10-28 13:27:08 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:08 --> Input Class Initialized
DEBUG - 2016-10-28 13:27:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:08 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:08 --> Language Class Initialized
DEBUG - 2016-10-28 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:08 --> Input Class Initialized
INFO - 2016-10-28 13:27:08 --> URI Class Initialized
INFO - 2016-10-28 13:27:08 --> Language Class Initialized
INFO - 2016-10-28 13:27:08 --> Router Class Initialized
INFO - 2016-10-28 13:27:08 --> Loader Class Initialized
INFO - 2016-10-28 13:27:08 --> Output Class Initialized
INFO - 2016-10-28 13:27:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:08 --> Loader Class Initialized
INFO - 2016-10-28 13:27:08 --> Security Class Initialized
INFO - 2016-10-28 13:27:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:08 --> Helper loaded: url_helper
DEBUG - 2016-10-28 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:08 --> Input Class Initialized
INFO - 2016-10-28 13:27:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:08 --> Language Class Initialized
INFO - 2016-10-28 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:08 --> Controller Class Initialized
INFO - 2016-10-28 13:27:08 --> Loader Class Initialized
INFO - 2016-10-28 13:27:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:08 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:08 --> Total execution time: 0.1004
INFO - 2016-10-28 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:08 --> Controller Class Initialized
INFO - 2016-10-28 13:27:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:08 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:08 --> Total execution time: 0.1801
INFO - 2016-10-28 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:08 --> Controller Class Initialized
INFO - 2016-10-28 13:27:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:08 --> Config Class Initialized
INFO - 2016-10-28 13:27:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:08 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:08 --> URI Class Initialized
INFO - 2016-10-28 13:27:08 --> Router Class Initialized
INFO - 2016-10-28 13:27:08 --> Output Class Initialized
INFO - 2016-10-28 13:27:08 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:08 --> Input Class Initialized
INFO - 2016-10-28 13:27:08 --> Language Class Initialized
INFO - 2016-10-28 13:27:08 --> Loader Class Initialized
INFO - 2016-10-28 13:27:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:08 --> Controller Class Initialized
INFO - 2016-10-28 13:27:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Model Class Initialized
INFO - 2016-10-28 13:27:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2016-10-28 13:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:27:08 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:08 --> Total execution time: 0.0774
INFO - 2016-10-28 13:27:11 --> Config Class Initialized
INFO - 2016-10-28 13:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:11 --> URI Class Initialized
INFO - 2016-10-28 13:27:11 --> Router Class Initialized
INFO - 2016-10-28 13:27:11 --> Output Class Initialized
INFO - 2016-10-28 13:27:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:11 --> Input Class Initialized
INFO - 2016-10-28 13:27:11 --> Language Class Initialized
INFO - 2016-10-28 13:27:11 --> Loader Class Initialized
INFO - 2016-10-28 13:27:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:11 --> Controller Class Initialized
INFO - 2016-10-28 13:27:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:11 --> Model Class Initialized
INFO - 2016-10-28 13:27:11 --> Model Class Initialized
INFO - 2016-10-28 13:27:11 --> Model Class Initialized
INFO - 2016-10-28 13:27:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:11 --> Config Class Initialized
INFO - 2016-10-28 13:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:11 --> URI Class Initialized
INFO - 2016-10-28 13:27:11 --> Router Class Initialized
INFO - 2016-10-28 13:27:11 --> Output Class Initialized
INFO - 2016-10-28 13:27:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:11 --> Input Class Initialized
INFO - 2016-10-28 13:27:11 --> Language Class Initialized
INFO - 2016-10-28 13:27:11 --> Loader Class Initialized
INFO - 2016-10-28 13:27:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:11 --> Controller Class Initialized
INFO - 2016-10-28 13:27:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:11 --> Model Class Initialized
INFO - 2016-10-28 13:27:11 --> Model Class Initialized
INFO - 2016-10-28 13:27:11 --> Model Class Initialized
INFO - 2016-10-28 13:27:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:27:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2016-10-28 13:27:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:27:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:11 --> Total execution time: 0.0901
INFO - 2016-10-28 13:27:12 --> Config Class Initialized
INFO - 2016-10-28 13:27:12 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:12 --> Config Class Initialized
DEBUG - 2016-10-28 13:27:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:12 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:12 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:12 --> URI Class Initialized
DEBUG - 2016-10-28 13:27:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:12 --> Router Class Initialized
INFO - 2016-10-28 13:27:12 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:12 --> Output Class Initialized
INFO - 2016-10-28 13:27:12 --> URI Class Initialized
INFO - 2016-10-28 13:27:12 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:12 --> Router Class Initialized
INFO - 2016-10-28 13:27:12 --> Input Class Initialized
INFO - 2016-10-28 13:27:12 --> Language Class Initialized
INFO - 2016-10-28 13:27:12 --> Output Class Initialized
INFO - 2016-10-28 13:27:12 --> Security Class Initialized
INFO - 2016-10-28 13:27:12 --> Loader Class Initialized
DEBUG - 2016-10-28 13:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:12 --> Input Class Initialized
INFO - 2016-10-28 13:27:12 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:12 --> Language Class Initialized
INFO - 2016-10-28 13:27:12 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:12 --> Loader Class Initialized
INFO - 2016-10-28 13:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:12 --> Controller Class Initialized
INFO - 2016-10-28 13:27:12 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:12 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:12 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:12 --> Model Class Initialized
INFO - 2016-10-28 13:27:12 --> Model Class Initialized
INFO - 2016-10-28 13:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:12 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:12 --> Total execution time: 0.1068
INFO - 2016-10-28 13:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:12 --> Controller Class Initialized
INFO - 2016-10-28 13:27:12 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:12 --> Model Class Initialized
INFO - 2016-10-28 13:27:12 --> Model Class Initialized
INFO - 2016-10-28 13:27:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-28 13:27:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-28 13:27:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-28 13:27:12 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:12 --> Total execution time: 0.1444
INFO - 2016-10-28 13:27:13 --> Config Class Initialized
INFO - 2016-10-28 13:27:13 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:13 --> Config Class Initialized
INFO - 2016-10-28 13:27:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:13 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:13 --> URI Class Initialized
INFO - 2016-10-28 13:27:13 --> Router Class Initialized
INFO - 2016-10-28 13:27:13 --> Output Class Initialized
INFO - 2016-10-28 13:27:13 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:13 --> Input Class Initialized
DEBUG - 2016-10-28 13:27:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:13 --> Language Class Initialized
INFO - 2016-10-28 13:27:13 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:13 --> Loader Class Initialized
INFO - 2016-10-28 13:27:13 --> URI Class Initialized
INFO - 2016-10-28 13:27:13 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:13 --> Router Class Initialized
INFO - 2016-10-28 13:27:13 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:13 --> Output Class Initialized
INFO - 2016-10-28 13:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:13 --> Security Class Initialized
INFO - 2016-10-28 13:27:14 --> Controller Class Initialized
DEBUG - 2016-10-28 13:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:14 --> Input Class Initialized
INFO - 2016-10-28 13:27:14 --> Language Class Initialized
INFO - 2016-10-28 13:27:14 --> Loader Class Initialized
INFO - 2016-10-28 13:27:14 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:14 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:14 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:14 --> Model Class Initialized
INFO - 2016-10-28 13:27:14 --> Model Class Initialized
INFO - 2016-10-28 13:27:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:14 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:14 --> Total execution time: 0.1031
INFO - 2016-10-28 13:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:14 --> Controller Class Initialized
INFO - 2016-10-28 13:27:14 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:14 --> Model Class Initialized
INFO - 2016-10-28 13:27:14 --> Model Class Initialized
INFO - 2016-10-28 13:27:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:14 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:14 --> Total execution time: 0.1556
INFO - 2016-10-28 13:27:15 --> Config Class Initialized
INFO - 2016-10-28 13:27:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:15 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:15 --> Config Class Initialized
INFO - 2016-10-28 13:27:15 --> URI Class Initialized
INFO - 2016-10-28 13:27:15 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:15 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:15 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:15 --> Output Class Initialized
INFO - 2016-10-28 13:27:15 --> URI Class Initialized
INFO - 2016-10-28 13:27:15 --> Security Class Initialized
INFO - 2016-10-28 13:27:15 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:15 --> Input Class Initialized
INFO - 2016-10-28 13:27:15 --> Output Class Initialized
INFO - 2016-10-28 13:27:15 --> Language Class Initialized
INFO - 2016-10-28 13:27:15 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:15 --> Input Class Initialized
INFO - 2016-10-28 13:27:15 --> Loader Class Initialized
INFO - 2016-10-28 13:27:15 --> Language Class Initialized
INFO - 2016-10-28 13:27:15 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:15 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:15 --> Loader Class Initialized
INFO - 2016-10-28 13:27:15 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:15 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:15 --> Controller Class Initialized
INFO - 2016-10-28 13:27:15 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:15 --> Model Class Initialized
INFO - 2016-10-28 13:27:15 --> Model Class Initialized
INFO - 2016-10-28 13:27:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:15 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:15 --> Total execution time: 0.0958
INFO - 2016-10-28 13:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:15 --> Controller Class Initialized
INFO - 2016-10-28 13:27:15 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:15 --> Model Class Initialized
INFO - 2016-10-28 13:27:15 --> Model Class Initialized
INFO - 2016-10-28 13:27:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:15 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:15 --> Total execution time: 0.1628
INFO - 2016-10-28 13:27:17 --> Config Class Initialized
INFO - 2016-10-28 13:27:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:17 --> Config Class Initialized
INFO - 2016-10-28 13:27:17 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:17 --> URI Class Initialized
DEBUG - 2016-10-28 13:27:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:17 --> Router Class Initialized
INFO - 2016-10-28 13:27:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:17 --> Output Class Initialized
INFO - 2016-10-28 13:27:17 --> Security Class Initialized
INFO - 2016-10-28 13:27:17 --> URI Class Initialized
INFO - 2016-10-28 13:27:17 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:17 --> Input Class Initialized
INFO - 2016-10-28 13:27:17 --> Output Class Initialized
INFO - 2016-10-28 13:27:17 --> Language Class Initialized
INFO - 2016-10-28 13:27:17 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:17 --> Input Class Initialized
INFO - 2016-10-28 13:27:17 --> Language Class Initialized
INFO - 2016-10-28 13:27:17 --> Loader Class Initialized
INFO - 2016-10-28 13:27:17 --> Loader Class Initialized
INFO - 2016-10-28 13:27:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:17 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:17 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:17 --> Controller Class Initialized
INFO - 2016-10-28 13:27:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:17 --> Model Class Initialized
INFO - 2016-10-28 13:27:17 --> Model Class Initialized
INFO - 2016-10-28 13:27:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:17 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:17 --> Total execution time: 0.0965
INFO - 2016-10-28 13:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:17 --> Controller Class Initialized
INFO - 2016-10-28 13:27:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:17 --> Model Class Initialized
INFO - 2016-10-28 13:27:17 --> Model Class Initialized
INFO - 2016-10-28 13:27:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:17 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:17 --> Total execution time: 0.1949
INFO - 2016-10-28 13:27:18 --> Config Class Initialized
INFO - 2016-10-28 13:27:18 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:18 --> Config Class Initialized
INFO - 2016-10-28 13:27:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:18 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:18 --> URI Class Initialized
INFO - 2016-10-28 13:27:18 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:18 --> Router Class Initialized
INFO - 2016-10-28 13:27:18 --> Output Class Initialized
INFO - 2016-10-28 13:27:18 --> URI Class Initialized
INFO - 2016-10-28 13:27:18 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:18 --> Input Class Initialized
INFO - 2016-10-28 13:27:18 --> Language Class Initialized
INFO - 2016-10-28 13:27:18 --> Router Class Initialized
INFO - 2016-10-28 13:27:18 --> Loader Class Initialized
INFO - 2016-10-28 13:27:18 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:18 --> Output Class Initialized
INFO - 2016-10-28 13:27:18 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:18 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:18 --> Input Class Initialized
INFO - 2016-10-28 13:27:18 --> Language Class Initialized
INFO - 2016-10-28 13:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:18 --> Controller Class Initialized
INFO - 2016-10-28 13:27:18 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:18 --> Loader Class Initialized
INFO - 2016-10-28 13:27:18 --> Model Class Initialized
INFO - 2016-10-28 13:27:18 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:18 --> Model Class Initialized
INFO - 2016-10-28 13:27:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:18 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:18 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:18 --> Total execution time: 0.1031
INFO - 2016-10-28 13:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:18 --> Controller Class Initialized
INFO - 2016-10-28 13:27:18 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:18 --> Model Class Initialized
INFO - 2016-10-28 13:27:18 --> Model Class Initialized
INFO - 2016-10-28 13:27:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:18 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:18 --> Total execution time: 0.1757
INFO - 2016-10-28 13:27:20 --> Config Class Initialized
INFO - 2016-10-28 13:27:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:20 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:20 --> URI Class Initialized
INFO - 2016-10-28 13:27:20 --> Router Class Initialized
INFO - 2016-10-28 13:27:20 --> Output Class Initialized
INFO - 2016-10-28 13:27:20 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:20 --> Input Class Initialized
INFO - 2016-10-28 13:27:20 --> Language Class Initialized
INFO - 2016-10-28 13:27:20 --> Loader Class Initialized
INFO - 2016-10-28 13:27:20 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:20 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:20 --> Controller Class Initialized
INFO - 2016-10-28 13:27:20 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:20 --> Model Class Initialized
INFO - 2016-10-28 13:27:20 --> Model Class Initialized
INFO - 2016-10-28 13:27:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:20 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:20 --> Total execution time: 0.1081
INFO - 2016-10-28 13:27:21 --> Config Class Initialized
INFO - 2016-10-28 13:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:21 --> URI Class Initialized
INFO - 2016-10-28 13:27:21 --> Config Class Initialized
INFO - 2016-10-28 13:27:21 --> Router Class Initialized
INFO - 2016-10-28 13:27:21 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:21 --> Config Class Initialized
INFO - 2016-10-28 13:27:21 --> Output Class Initialized
INFO - 2016-10-28 13:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:21 --> Security Class Initialized
INFO - 2016-10-28 13:27:21 --> URI Class Initialized
DEBUG - 2016-10-28 13:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:21 --> Input Class Initialized
INFO - 2016-10-28 13:27:21 --> Router Class Initialized
INFO - 2016-10-28 13:27:21 --> Language Class Initialized
DEBUG - 2016-10-28 13:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:21 --> Output Class Initialized
INFO - 2016-10-28 13:27:21 --> URI Class Initialized
INFO - 2016-10-28 13:27:21 --> Security Class Initialized
INFO - 2016-10-28 13:27:21 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:21 --> Input Class Initialized
INFO - 2016-10-28 13:27:22 --> Loader Class Initialized
INFO - 2016-10-28 13:27:22 --> Language Class Initialized
INFO - 2016-10-28 13:27:22 --> Output Class Initialized
INFO - 2016-10-28 13:27:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:22 --> Security Class Initialized
INFO - 2016-10-28 13:27:22 --> Helper loaded: language_helper
DEBUG - 2016-10-28 13:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:22 --> Loader Class Initialized
INFO - 2016-10-28 13:27:22 --> Input Class Initialized
INFO - 2016-10-28 13:27:22 --> Language Class Initialized
INFO - 2016-10-28 13:27:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:22 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:22 --> Loader Class Initialized
INFO - 2016-10-28 13:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:22 --> Controller Class Initialized
INFO - 2016-10-28 13:27:22 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:22 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:22 --> Total execution time: 0.1445
INFO - 2016-10-28 13:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:22 --> Controller Class Initialized
INFO - 2016-10-28 13:27:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:22 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:22 --> Total execution time: 0.1865
INFO - 2016-10-28 13:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:22 --> Controller Class Initialized
INFO - 2016-10-28 13:27:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:22 --> Config Class Initialized
INFO - 2016-10-28 13:27:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:22 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:22 --> URI Class Initialized
INFO - 2016-10-28 13:27:22 --> Router Class Initialized
INFO - 2016-10-28 13:27:22 --> Output Class Initialized
INFO - 2016-10-28 13:27:22 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:22 --> Input Class Initialized
INFO - 2016-10-28 13:27:22 --> Language Class Initialized
INFO - 2016-10-28 13:27:22 --> Loader Class Initialized
INFO - 2016-10-28 13:27:22 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:22 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:22 --> Controller Class Initialized
INFO - 2016-10-28 13:27:22 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Model Class Initialized
INFO - 2016-10-28 13:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:27:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2016-10-28 13:27:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:27:22 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:22 --> Total execution time: 0.1312
INFO - 2016-10-28 13:27:25 --> Config Class Initialized
INFO - 2016-10-28 13:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:25 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:25 --> URI Class Initialized
INFO - 2016-10-28 13:27:25 --> Router Class Initialized
INFO - 2016-10-28 13:27:25 --> Output Class Initialized
INFO - 2016-10-28 13:27:25 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:25 --> Input Class Initialized
INFO - 2016-10-28 13:27:25 --> Language Class Initialized
INFO - 2016-10-28 13:27:25 --> Loader Class Initialized
INFO - 2016-10-28 13:27:25 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:25 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:25 --> Controller Class Initialized
INFO - 2016-10-28 13:27:25 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:25 --> Model Class Initialized
INFO - 2016-10-28 13:27:25 --> Model Class Initialized
INFO - 2016-10-28 13:27:25 --> Model Class Initialized
INFO - 2016-10-28 13:27:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:25 --> Config Class Initialized
INFO - 2016-10-28 13:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:25 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:25 --> URI Class Initialized
INFO - 2016-10-28 13:27:25 --> Router Class Initialized
INFO - 2016-10-28 13:27:25 --> Output Class Initialized
INFO - 2016-10-28 13:27:25 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:25 --> Input Class Initialized
INFO - 2016-10-28 13:27:25 --> Language Class Initialized
INFO - 2016-10-28 13:27:25 --> Loader Class Initialized
INFO - 2016-10-28 13:27:25 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:25 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:25 --> Controller Class Initialized
INFO - 2016-10-28 13:27:25 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:25 --> Model Class Initialized
INFO - 2016-10-28 13:27:25 --> Model Class Initialized
INFO - 2016-10-28 13:27:25 --> Model Class Initialized
INFO - 2016-10-28 13:27:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2016-10-28 13:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:27:25 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:25 --> Total execution time: 0.1400
INFO - 2016-10-28 13:27:26 --> Config Class Initialized
INFO - 2016-10-28 13:27:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:26 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:26 --> Config Class Initialized
INFO - 2016-10-28 13:27:26 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:26 --> URI Class Initialized
INFO - 2016-10-28 13:27:26 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:26 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:26 --> Output Class Initialized
INFO - 2016-10-28 13:27:26 --> URI Class Initialized
INFO - 2016-10-28 13:27:26 --> Security Class Initialized
INFO - 2016-10-28 13:27:26 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:26 --> Input Class Initialized
INFO - 2016-10-28 13:27:26 --> Output Class Initialized
INFO - 2016-10-28 13:27:26 --> Language Class Initialized
INFO - 2016-10-28 13:27:26 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:26 --> Input Class Initialized
INFO - 2016-10-28 13:27:26 --> Loader Class Initialized
INFO - 2016-10-28 13:27:26 --> Language Class Initialized
INFO - 2016-10-28 13:27:26 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:26 --> Loader Class Initialized
INFO - 2016-10-28 13:27:26 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:26 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:26 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:26 --> Controller Class Initialized
INFO - 2016-10-28 13:27:26 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:26 --> Model Class Initialized
INFO - 2016-10-28 13:27:26 --> Model Class Initialized
INFO - 2016-10-28 13:27:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:26 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:26 --> Total execution time: 0.1025
INFO - 2016-10-28 13:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:26 --> Controller Class Initialized
INFO - 2016-10-28 13:27:26 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:26 --> Model Class Initialized
INFO - 2016-10-28 13:27:26 --> Model Class Initialized
INFO - 2016-10-28 13:27:26 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-28 13:27:26 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-28 13:27:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-28 13:27:26 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:26 --> Total execution time: 0.1724
INFO - 2016-10-28 13:27:28 --> Config Class Initialized
INFO - 2016-10-28 13:27:28 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:28 --> Config Class Initialized
INFO - 2016-10-28 13:27:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:28 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:28 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:28 --> URI Class Initialized
INFO - 2016-10-28 13:27:28 --> URI Class Initialized
INFO - 2016-10-28 13:27:28 --> Router Class Initialized
INFO - 2016-10-28 13:27:28 --> Router Class Initialized
INFO - 2016-10-28 13:27:28 --> Output Class Initialized
INFO - 2016-10-28 13:27:28 --> Output Class Initialized
INFO - 2016-10-28 13:27:28 --> Security Class Initialized
INFO - 2016-10-28 13:27:28 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-28 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:28 --> Input Class Initialized
INFO - 2016-10-28 13:27:28 --> Input Class Initialized
INFO - 2016-10-28 13:27:28 --> Language Class Initialized
INFO - 2016-10-28 13:27:28 --> Language Class Initialized
INFO - 2016-10-28 13:27:28 --> Loader Class Initialized
INFO - 2016-10-28 13:27:28 --> Loader Class Initialized
INFO - 2016-10-28 13:27:28 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:28 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:28 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:28 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:28 --> Controller Class Initialized
INFO - 2016-10-28 13:27:28 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:28 --> Model Class Initialized
INFO - 2016-10-28 13:27:28 --> Model Class Initialized
INFO - 2016-10-28 13:27:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:28 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:28 --> Total execution time: 0.1023
INFO - 2016-10-28 13:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:28 --> Controller Class Initialized
INFO - 2016-10-28 13:27:28 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:28 --> Model Class Initialized
INFO - 2016-10-28 13:27:28 --> Model Class Initialized
INFO - 2016-10-28 13:27:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:28 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:28 --> Total execution time: 0.2343
INFO - 2016-10-28 13:27:29 --> Config Class Initialized
INFO - 2016-10-28 13:27:29 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:29 --> Config Class Initialized
INFO - 2016-10-28 13:27:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:29 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:29 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:29 --> URI Class Initialized
INFO - 2016-10-28 13:27:29 --> URI Class Initialized
INFO - 2016-10-28 13:27:29 --> Router Class Initialized
INFO - 2016-10-28 13:27:29 --> Router Class Initialized
INFO - 2016-10-28 13:27:29 --> Output Class Initialized
INFO - 2016-10-28 13:27:29 --> Output Class Initialized
INFO - 2016-10-28 13:27:29 --> Security Class Initialized
INFO - 2016-10-28 13:27:29 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:29 --> Input Class Initialized
DEBUG - 2016-10-28 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:29 --> Language Class Initialized
INFO - 2016-10-28 13:27:29 --> Input Class Initialized
INFO - 2016-10-28 13:27:29 --> Language Class Initialized
INFO - 2016-10-28 13:27:29 --> Loader Class Initialized
INFO - 2016-10-28 13:27:29 --> Loader Class Initialized
INFO - 2016-10-28 13:27:29 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:29 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:29 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:29 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:29 --> Controller Class Initialized
INFO - 2016-10-28 13:27:29 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:29 --> Model Class Initialized
INFO - 2016-10-28 13:27:29 --> Model Class Initialized
INFO - 2016-10-28 13:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:29 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:29 --> Total execution time: 0.0915
INFO - 2016-10-28 13:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:29 --> Controller Class Initialized
INFO - 2016-10-28 13:27:29 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:29 --> Model Class Initialized
INFO - 2016-10-28 13:27:29 --> Model Class Initialized
INFO - 2016-10-28 13:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:29 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:29 --> Total execution time: 0.1629
INFO - 2016-10-28 13:27:31 --> Config Class Initialized
INFO - 2016-10-28 13:27:31 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:31 --> Config Class Initialized
INFO - 2016-10-28 13:27:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:31 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:31 --> URI Class Initialized
DEBUG - 2016-10-28 13:27:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:31 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:31 --> URI Class Initialized
INFO - 2016-10-28 13:27:31 --> Router Class Initialized
INFO - 2016-10-28 13:27:31 --> Router Class Initialized
INFO - 2016-10-28 13:27:31 --> Output Class Initialized
INFO - 2016-10-28 13:27:31 --> Security Class Initialized
INFO - 2016-10-28 13:27:31 --> Output Class Initialized
DEBUG - 2016-10-28 13:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:31 --> Input Class Initialized
INFO - 2016-10-28 13:27:31 --> Security Class Initialized
INFO - 2016-10-28 13:27:31 --> Language Class Initialized
DEBUG - 2016-10-28 13:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:31 --> Input Class Initialized
INFO - 2016-10-28 13:27:31 --> Language Class Initialized
INFO - 2016-10-28 13:27:31 --> Loader Class Initialized
INFO - 2016-10-28 13:27:31 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:31 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:31 --> Loader Class Initialized
INFO - 2016-10-28 13:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:31 --> Controller Class Initialized
INFO - 2016-10-28 13:27:31 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:31 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:31 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:31 --> Model Class Initialized
INFO - 2016-10-28 13:27:31 --> Model Class Initialized
INFO - 2016-10-28 13:27:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:31 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:31 --> Total execution time: 0.0886
INFO - 2016-10-28 13:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:31 --> Controller Class Initialized
INFO - 2016-10-28 13:27:31 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:31 --> Model Class Initialized
INFO - 2016-10-28 13:27:31 --> Model Class Initialized
INFO - 2016-10-28 13:27:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:31 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:31 --> Total execution time: 0.1655
INFO - 2016-10-28 13:27:33 --> Config Class Initialized
INFO - 2016-10-28 13:27:33 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:33 --> Config Class Initialized
INFO - 2016-10-28 13:27:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:33 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:33 --> URI Class Initialized
DEBUG - 2016-10-28 13:27:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:33 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:33 --> Router Class Initialized
INFO - 2016-10-28 13:27:33 --> URI Class Initialized
INFO - 2016-10-28 13:27:33 --> Output Class Initialized
INFO - 2016-10-28 13:27:33 --> Router Class Initialized
INFO - 2016-10-28 13:27:33 --> Security Class Initialized
INFO - 2016-10-28 13:27:33 --> Output Class Initialized
DEBUG - 2016-10-28 13:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:33 --> Security Class Initialized
INFO - 2016-10-28 13:27:33 --> Input Class Initialized
INFO - 2016-10-28 13:27:33 --> Language Class Initialized
DEBUG - 2016-10-28 13:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:33 --> Input Class Initialized
INFO - 2016-10-28 13:27:33 --> Language Class Initialized
INFO - 2016-10-28 13:27:33 --> Loader Class Initialized
INFO - 2016-10-28 13:27:33 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:33 --> Loader Class Initialized
INFO - 2016-10-28 13:27:33 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:33 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:33 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:33 --> Controller Class Initialized
INFO - 2016-10-28 13:27:33 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:33 --> Model Class Initialized
INFO - 2016-10-28 13:27:33 --> Model Class Initialized
INFO - 2016-10-28 13:27:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:33 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:33 --> Total execution time: 0.0968
INFO - 2016-10-28 13:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:33 --> Controller Class Initialized
INFO - 2016-10-28 13:27:33 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:33 --> Model Class Initialized
INFO - 2016-10-28 13:27:33 --> Model Class Initialized
INFO - 2016-10-28 13:27:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:33 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:33 --> Total execution time: 0.1394
INFO - 2016-10-28 13:27:37 --> Config Class Initialized
INFO - 2016-10-28 13:27:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:37 --> URI Class Initialized
INFO - 2016-10-28 13:27:37 --> Router Class Initialized
INFO - 2016-10-28 13:27:37 --> Output Class Initialized
INFO - 2016-10-28 13:27:37 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:37 --> Input Class Initialized
INFO - 2016-10-28 13:27:37 --> Language Class Initialized
INFO - 2016-10-28 13:27:37 --> Loader Class Initialized
INFO - 2016-10-28 13:27:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:37 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:37 --> Controller Class Initialized
INFO - 2016-10-28 13:27:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:37 --> Model Class Initialized
INFO - 2016-10-28 13:27:37 --> Model Class Initialized
INFO - 2016-10-28 13:27:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:37 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:37 --> Total execution time: 0.0984
INFO - 2016-10-28 13:27:38 --> Config Class Initialized
INFO - 2016-10-28 13:27:38 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:38 --> Config Class Initialized
INFO - 2016-10-28 13:27:38 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:38 --> Config Class Initialized
INFO - 2016-10-28 13:27:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:38 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:27:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:38 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:38 --> URI Class Initialized
INFO - 2016-10-28 13:27:38 --> URI Class Initialized
INFO - 2016-10-28 13:27:38 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:38 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:38 --> Router Class Initialized
INFO - 2016-10-28 13:27:38 --> Output Class Initialized
INFO - 2016-10-28 13:27:38 --> URI Class Initialized
INFO - 2016-10-28 13:27:38 --> Security Class Initialized
INFO - 2016-10-28 13:27:38 --> Router Class Initialized
INFO - 2016-10-28 13:27:38 --> Output Class Initialized
DEBUG - 2016-10-28 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:38 --> Input Class Initialized
INFO - 2016-10-28 13:27:38 --> Output Class Initialized
INFO - 2016-10-28 13:27:38 --> Language Class Initialized
INFO - 2016-10-28 13:27:38 --> Security Class Initialized
INFO - 2016-10-28 13:27:38 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-28 13:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:38 --> Input Class Initialized
INFO - 2016-10-28 13:27:38 --> Loader Class Initialized
INFO - 2016-10-28 13:27:38 --> Input Class Initialized
INFO - 2016-10-28 13:27:38 --> Language Class Initialized
INFO - 2016-10-28 13:27:38 --> Language Class Initialized
INFO - 2016-10-28 13:27:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:38 --> Loader Class Initialized
INFO - 2016-10-28 13:27:38 --> Loader Class Initialized
INFO - 2016-10-28 13:27:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:38 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:38 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:38 --> Controller Class Initialized
INFO - 2016-10-28 13:27:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:39 --> Controller Class Initialized
INFO - 2016-10-28 13:27:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:39 --> Config Class Initialized
INFO - 2016-10-28 13:27:39 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
DEBUG - 2016-10-28 13:27:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:39 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:39 --> URI Class Initialized
INFO - 2016-10-28 13:27:39 --> Router Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Output Class Initialized
INFO - 2016-10-28 13:27:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:39 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:39 --> Total execution time: 0.1544
INFO - 2016-10-28 13:27:39 --> Security Class Initialized
INFO - 2016-10-28 13:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:39 --> Controller Class Initialized
DEBUG - 2016-10-28 13:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:39 --> Input Class Initialized
INFO - 2016-10-28 13:27:39 --> Language Class Initialized
INFO - 2016-10-28 13:27:39 --> Loader Class Initialized
INFO - 2016-10-28 13:27:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:39 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:39 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:39 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:39 --> Total execution time: 0.2056
INFO - 2016-10-28 13:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:39 --> Controller Class Initialized
INFO - 2016-10-28 13:27:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Model Class Initialized
INFO - 2016-10-28 13:27:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:27:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2016-10-28 13:27:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:27:39 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:39 --> Total execution time: 0.1158
INFO - 2016-10-28 13:27:42 --> Config Class Initialized
INFO - 2016-10-28 13:27:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:42 --> URI Class Initialized
INFO - 2016-10-28 13:27:42 --> Router Class Initialized
INFO - 2016-10-28 13:27:42 --> Output Class Initialized
INFO - 2016-10-28 13:27:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:42 --> Input Class Initialized
INFO - 2016-10-28 13:27:42 --> Language Class Initialized
INFO - 2016-10-28 13:27:42 --> Loader Class Initialized
INFO - 2016-10-28 13:27:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:42 --> Controller Class Initialized
INFO - 2016-10-28 13:27:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:42 --> Config Class Initialized
INFO - 2016-10-28 13:27:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:42 --> URI Class Initialized
INFO - 2016-10-28 13:27:42 --> Router Class Initialized
INFO - 2016-10-28 13:27:42 --> Output Class Initialized
INFO - 2016-10-28 13:27:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:42 --> Input Class Initialized
INFO - 2016-10-28 13:27:42 --> Language Class Initialized
INFO - 2016-10-28 13:27:42 --> Loader Class Initialized
INFO - 2016-10-28 13:27:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:42 --> Controller Class Initialized
INFO - 2016-10-28 13:27:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2016-10-28 13:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:27:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:42 --> Total execution time: 0.1420
INFO - 2016-10-28 13:27:42 --> Config Class Initialized
INFO - 2016-10-28 13:27:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:27:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:42 --> Config Class Initialized
INFO - 2016-10-28 13:27:42 --> Hooks Class Initialized
INFO - 2016-10-28 13:27:42 --> URI Class Initialized
INFO - 2016-10-28 13:27:42 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:27:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:27:42 --> Output Class Initialized
INFO - 2016-10-28 13:27:42 --> URI Class Initialized
INFO - 2016-10-28 13:27:42 --> Security Class Initialized
INFO - 2016-10-28 13:27:42 --> Router Class Initialized
DEBUG - 2016-10-28 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:42 --> Input Class Initialized
INFO - 2016-10-28 13:27:42 --> Output Class Initialized
INFO - 2016-10-28 13:27:42 --> Language Class Initialized
INFO - 2016-10-28 13:27:42 --> Security Class Initialized
INFO - 2016-10-28 13:27:42 --> Loader Class Initialized
DEBUG - 2016-10-28 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:27:42 --> Input Class Initialized
INFO - 2016-10-28 13:27:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:42 --> Language Class Initialized
INFO - 2016-10-28 13:27:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:42 --> Loader Class Initialized
INFO - 2016-10-28 13:27:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:42 --> Controller Class Initialized
INFO - 2016-10-28 13:27:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:27:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:42 --> Total execution time: 0.0978
INFO - 2016-10-28 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:27:42 --> Controller Class Initialized
INFO - 2016-10-28 13:27:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:42 --> Model Class Initialized
INFO - 2016-10-28 13:27:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:27:43 --> Final output sent to browser
DEBUG - 2016-10-28 13:27:43 --> Total execution time: 0.1605
INFO - 2016-10-28 13:28:08 --> Config Class Initialized
INFO - 2016-10-28 13:28:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:08 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:08 --> Config Class Initialized
INFO - 2016-10-28 13:28:08 --> URI Class Initialized
INFO - 2016-10-28 13:28:08 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:08 --> Router Class Initialized
INFO - 2016-10-28 13:28:08 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:08 --> Security Class Initialized
INFO - 2016-10-28 13:28:08 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:08 --> Input Class Initialized
INFO - 2016-10-28 13:28:08 --> URI Class Initialized
INFO - 2016-10-28 13:28:08 --> Language Class Initialized
INFO - 2016-10-28 13:28:08 --> Router Class Initialized
INFO - 2016-10-28 13:28:08 --> Output Class Initialized
INFO - 2016-10-28 13:28:08 --> Loader Class Initialized
INFO - 2016-10-28 13:28:08 --> Security Class Initialized
INFO - 2016-10-28 13:28:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:08 --> Helper loaded: language_helper
DEBUG - 2016-10-28 13:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:08 --> Input Class Initialized
INFO - 2016-10-28 13:28:08 --> Language Class Initialized
INFO - 2016-10-28 13:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:08 --> Controller Class Initialized
INFO - 2016-10-28 13:28:08 --> Loader Class Initialized
INFO - 2016-10-28 13:28:08 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:08 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:08 --> Model Class Initialized
INFO - 2016-10-28 13:28:08 --> Model Class Initialized
INFO - 2016-10-28 13:28:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:08 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:08 --> Total execution time: 0.1122
INFO - 2016-10-28 13:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:08 --> Controller Class Initialized
INFO - 2016-10-28 13:28:08 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:08 --> Model Class Initialized
INFO - 2016-10-28 13:28:08 --> Model Class Initialized
INFO - 2016-10-28 13:28:08 --> Model Class Initialized
INFO - 2016-10-28 13:28:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:08 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:08 --> Total execution time: 0.2376
INFO - 2016-10-28 13:28:09 --> Config Class Initialized
INFO - 2016-10-28 13:28:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:09 --> Config Class Initialized
INFO - 2016-10-28 13:28:09 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:09 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:09 --> URI Class Initialized
INFO - 2016-10-28 13:28:09 --> Router Class Initialized
INFO - 2016-10-28 13:28:09 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:09 --> Security Class Initialized
INFO - 2016-10-28 13:28:09 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:09 --> Input Class Initialized
INFO - 2016-10-28 13:28:09 --> URI Class Initialized
INFO - 2016-10-28 13:28:09 --> Language Class Initialized
INFO - 2016-10-28 13:28:09 --> Router Class Initialized
INFO - 2016-10-28 13:28:09 --> Loader Class Initialized
INFO - 2016-10-28 13:28:09 --> Output Class Initialized
INFO - 2016-10-28 13:28:09 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:09 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:09 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:09 --> Input Class Initialized
INFO - 2016-10-28 13:28:09 --> Language Class Initialized
INFO - 2016-10-28 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:09 --> Controller Class Initialized
INFO - 2016-10-28 13:28:09 --> Loader Class Initialized
INFO - 2016-10-28 13:28:09 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:09 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:09 --> Model Class Initialized
INFO - 2016-10-28 13:28:09 --> Model Class Initialized
INFO - 2016-10-28 13:28:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:09 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:09 --> Total execution time: 0.1016
INFO - 2016-10-28 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:09 --> Controller Class Initialized
INFO - 2016-10-28 13:28:09 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:09 --> Model Class Initialized
INFO - 2016-10-28 13:28:09 --> Model Class Initialized
INFO - 2016-10-28 13:28:09 --> Model Class Initialized
INFO - 2016-10-28 13:28:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:10 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:10 --> Total execution time: 0.2897
INFO - 2016-10-28 13:28:11 --> Config Class Initialized
INFO - 2016-10-28 13:28:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:11 --> URI Class Initialized
INFO - 2016-10-28 13:28:11 --> Config Class Initialized
INFO - 2016-10-28 13:28:11 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:11 --> Router Class Initialized
DEBUG - 2016-10-28 13:28:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:11 --> Output Class Initialized
INFO - 2016-10-28 13:28:11 --> URI Class Initialized
INFO - 2016-10-28 13:28:11 --> Router Class Initialized
INFO - 2016-10-28 13:28:11 --> Security Class Initialized
INFO - 2016-10-28 13:28:11 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:11 --> Input Class Initialized
INFO - 2016-10-28 13:28:11 --> Security Class Initialized
INFO - 2016-10-28 13:28:11 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:11 --> Input Class Initialized
INFO - 2016-10-28 13:28:11 --> Language Class Initialized
INFO - 2016-10-28 13:28:11 --> Loader Class Initialized
INFO - 2016-10-28 13:28:11 --> Loader Class Initialized
INFO - 2016-10-28 13:28:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:11 --> Controller Class Initialized
INFO - 2016-10-28 13:28:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:11 --> Model Class Initialized
INFO - 2016-10-28 13:28:11 --> Model Class Initialized
INFO - 2016-10-28 13:28:11 --> Model Class Initialized
INFO - 2016-10-28 13:28:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:11 --> Total execution time: 0.2082
INFO - 2016-10-28 13:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:11 --> Controller Class Initialized
INFO - 2016-10-28 13:28:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:11 --> Model Class Initialized
INFO - 2016-10-28 13:28:11 --> Model Class Initialized
INFO - 2016-10-28 13:28:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:11 --> Total execution time: 0.2588
INFO - 2016-10-28 13:28:12 --> Config Class Initialized
INFO - 2016-10-28 13:28:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:12 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:12 --> URI Class Initialized
INFO - 2016-10-28 13:28:12 --> Router Class Initialized
INFO - 2016-10-28 13:28:12 --> Output Class Initialized
INFO - 2016-10-28 13:28:12 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:12 --> Input Class Initialized
INFO - 2016-10-28 13:28:12 --> Language Class Initialized
INFO - 2016-10-28 13:28:12 --> Loader Class Initialized
INFO - 2016-10-28 13:28:12 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:12 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:12 --> Controller Class Initialized
INFO - 2016-10-28 13:28:12 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:12 --> Model Class Initialized
INFO - 2016-10-28 13:28:12 --> Model Class Initialized
INFO - 2016-10-28 13:28:12 --> Model Class Initialized
INFO - 2016-10-28 13:28:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:12 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:12 --> Total execution time: 0.0937
INFO - 2016-10-28 13:28:13 --> Config Class Initialized
INFO - 2016-10-28 13:28:13 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:13 --> Config Class Initialized
INFO - 2016-10-28 13:28:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:13 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:13 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:13 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:13 --> URI Class Initialized
INFO - 2016-10-28 13:28:13 --> Router Class Initialized
INFO - 2016-10-28 13:28:13 --> Output Class Initialized
INFO - 2016-10-28 13:28:13 --> Security Class Initialized
INFO - 2016-10-28 13:28:13 --> Router Class Initialized
INFO - 2016-10-28 13:28:13 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:13 --> Input Class Initialized
INFO - 2016-10-28 13:28:13 --> Security Class Initialized
INFO - 2016-10-28 13:28:13 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:13 --> Input Class Initialized
INFO - 2016-10-28 13:28:13 --> Language Class Initialized
INFO - 2016-10-28 13:28:13 --> Loader Class Initialized
INFO - 2016-10-28 13:28:13 --> Loader Class Initialized
INFO - 2016-10-28 13:28:13 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:13 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:13 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:13 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:13 --> Controller Class Initialized
INFO - 2016-10-28 13:28:13 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:13 --> Model Class Initialized
INFO - 2016-10-28 13:28:13 --> Model Class Initialized
INFO - 2016-10-28 13:28:13 --> Model Class Initialized
INFO - 2016-10-28 13:28:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:13 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:13 --> Total execution time: 0.1748
INFO - 2016-10-28 13:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:13 --> Controller Class Initialized
INFO - 2016-10-28 13:28:13 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:13 --> Model Class Initialized
INFO - 2016-10-28 13:28:13 --> Model Class Initialized
INFO - 2016-10-28 13:28:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:13 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:13 --> Total execution time: 0.2195
INFO - 2016-10-28 13:28:15 --> Config Class Initialized
INFO - 2016-10-28 13:28:15 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:15 --> Config Class Initialized
INFO - 2016-10-28 13:28:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:15 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:28:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:15 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:15 --> URI Class Initialized
INFO - 2016-10-28 13:28:15 --> URI Class Initialized
INFO - 2016-10-28 13:28:15 --> Router Class Initialized
INFO - 2016-10-28 13:28:15 --> Router Class Initialized
INFO - 2016-10-28 13:28:15 --> Output Class Initialized
INFO - 2016-10-28 13:28:15 --> Security Class Initialized
INFO - 2016-10-28 13:28:15 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:15 --> Input Class Initialized
INFO - 2016-10-28 13:28:15 --> Security Class Initialized
INFO - 2016-10-28 13:28:15 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:15 --> Input Class Initialized
INFO - 2016-10-28 13:28:15 --> Language Class Initialized
INFO - 2016-10-28 13:28:15 --> Loader Class Initialized
INFO - 2016-10-28 13:28:15 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:15 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:15 --> Loader Class Initialized
INFO - 2016-10-28 13:28:15 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:15 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:15 --> Controller Class Initialized
INFO - 2016-10-28 13:28:15 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:15 --> Model Class Initialized
INFO - 2016-10-28 13:28:15 --> Model Class Initialized
INFO - 2016-10-28 13:28:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:15 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:15 --> Total execution time: 0.1010
INFO - 2016-10-28 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:15 --> Controller Class Initialized
INFO - 2016-10-28 13:28:15 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:15 --> Model Class Initialized
INFO - 2016-10-28 13:28:15 --> Model Class Initialized
INFO - 2016-10-28 13:28:15 --> Model Class Initialized
INFO - 2016-10-28 13:28:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:15 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:15 --> Total execution time: 0.2384
INFO - 2016-10-28 13:28:17 --> Config Class Initialized
INFO - 2016-10-28 13:28:17 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:17 --> Config Class Initialized
INFO - 2016-10-28 13:28:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:17 --> URI Class Initialized
INFO - 2016-10-28 13:28:17 --> Router Class Initialized
DEBUG - 2016-10-28 13:28:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:17 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:17 --> Output Class Initialized
INFO - 2016-10-28 13:28:17 --> Security Class Initialized
INFO - 2016-10-28 13:28:17 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:17 --> Input Class Initialized
INFO - 2016-10-28 13:28:17 --> Language Class Initialized
INFO - 2016-10-28 13:28:17 --> Router Class Initialized
INFO - 2016-10-28 13:28:17 --> Loader Class Initialized
INFO - 2016-10-28 13:28:17 --> Output Class Initialized
INFO - 2016-10-28 13:28:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:17 --> Security Class Initialized
INFO - 2016-10-28 13:28:17 --> Helper loaded: language_helper
DEBUG - 2016-10-28 13:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:17 --> Input Class Initialized
INFO - 2016-10-28 13:28:17 --> Language Class Initialized
INFO - 2016-10-28 13:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:17 --> Controller Class Initialized
INFO - 2016-10-28 13:28:17 --> Loader Class Initialized
INFO - 2016-10-28 13:28:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:17 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:17 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:17 --> Model Class Initialized
INFO - 2016-10-28 13:28:17 --> Model Class Initialized
INFO - 2016-10-28 13:28:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:17 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:17 --> Total execution time: 0.0982
INFO - 2016-10-28 13:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:17 --> Controller Class Initialized
INFO - 2016-10-28 13:28:17 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:17 --> Model Class Initialized
INFO - 2016-10-28 13:28:17 --> Model Class Initialized
INFO - 2016-10-28 13:28:17 --> Model Class Initialized
INFO - 2016-10-28 13:28:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:17 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:17 --> Total execution time: 0.2486
INFO - 2016-10-28 13:28:19 --> Config Class Initialized
INFO - 2016-10-28 13:28:19 --> Config Class Initialized
INFO - 2016-10-28 13:28:19 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:19 --> UTF-8 Support Enabled
DEBUG - 2016-10-28 13:28:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:19 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:19 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:19 --> URI Class Initialized
INFO - 2016-10-28 13:28:19 --> URI Class Initialized
INFO - 2016-10-28 13:28:19 --> Router Class Initialized
INFO - 2016-10-28 13:28:19 --> Output Class Initialized
INFO - 2016-10-28 13:28:19 --> Router Class Initialized
INFO - 2016-10-28 13:28:19 --> Security Class Initialized
INFO - 2016-10-28 13:28:19 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:19 --> Input Class Initialized
INFO - 2016-10-28 13:28:19 --> Security Class Initialized
INFO - 2016-10-28 13:28:19 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:19 --> Input Class Initialized
INFO - 2016-10-28 13:28:19 --> Language Class Initialized
INFO - 2016-10-28 13:28:19 --> Loader Class Initialized
INFO - 2016-10-28 13:28:19 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:19 --> Loader Class Initialized
INFO - 2016-10-28 13:28:19 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:19 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:19 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:19 --> Controller Class Initialized
INFO - 2016-10-28 13:28:19 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:19 --> Model Class Initialized
INFO - 2016-10-28 13:28:19 --> Model Class Initialized
INFO - 2016-10-28 13:28:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:19 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:19 --> Total execution time: 0.1157
INFO - 2016-10-28 13:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:19 --> Controller Class Initialized
INFO - 2016-10-28 13:28:19 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:19 --> Model Class Initialized
INFO - 2016-10-28 13:28:19 --> Model Class Initialized
INFO - 2016-10-28 13:28:19 --> Model Class Initialized
INFO - 2016-10-28 13:28:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:19 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:19 --> Total execution time: 0.2573
INFO - 2016-10-28 13:28:21 --> Config Class Initialized
INFO - 2016-10-28 13:28:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:21 --> Config Class Initialized
INFO - 2016-10-28 13:28:21 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:21 --> URI Class Initialized
INFO - 2016-10-28 13:28:21 --> Router Class Initialized
INFO - 2016-10-28 13:28:21 --> Output Class Initialized
INFO - 2016-10-28 13:28:21 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-28 13:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:21 --> Input Class Initialized
INFO - 2016-10-28 13:28:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:21 --> Language Class Initialized
INFO - 2016-10-28 13:28:21 --> URI Class Initialized
INFO - 2016-10-28 13:28:21 --> Loader Class Initialized
INFO - 2016-10-28 13:28:21 --> Router Class Initialized
INFO - 2016-10-28 13:28:21 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:21 --> Output Class Initialized
INFO - 2016-10-28 13:28:21 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:21 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:21 --> Input Class Initialized
INFO - 2016-10-28 13:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:21 --> Language Class Initialized
INFO - 2016-10-28 13:28:21 --> Controller Class Initialized
INFO - 2016-10-28 13:28:21 --> Loader Class Initialized
INFO - 2016-10-28 13:28:21 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:21 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:21 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:21 --> Model Class Initialized
INFO - 2016-10-28 13:28:21 --> Model Class Initialized
INFO - 2016-10-28 13:28:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:21 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:21 --> Total execution time: 0.0925
INFO - 2016-10-28 13:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:21 --> Controller Class Initialized
INFO - 2016-10-28 13:28:21 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:21 --> Model Class Initialized
INFO - 2016-10-28 13:28:21 --> Model Class Initialized
INFO - 2016-10-28 13:28:21 --> Model Class Initialized
INFO - 2016-10-28 13:28:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:21 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:21 --> Total execution time: 0.2167
INFO - 2016-10-28 13:28:23 --> Config Class Initialized
INFO - 2016-10-28 13:28:23 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:23 --> Config Class Initialized
INFO - 2016-10-28 13:28:23 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:23 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:23 --> URI Class Initialized
INFO - 2016-10-28 13:28:23 --> Router Class Initialized
DEBUG - 2016-10-28 13:28:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:23 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:23 --> Output Class Initialized
INFO - 2016-10-28 13:28:23 --> URI Class Initialized
INFO - 2016-10-28 13:28:23 --> Security Class Initialized
INFO - 2016-10-28 13:28:23 --> Router Class Initialized
DEBUG - 2016-10-28 13:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:23 --> Input Class Initialized
INFO - 2016-10-28 13:28:23 --> Output Class Initialized
INFO - 2016-10-28 13:28:23 --> Language Class Initialized
INFO - 2016-10-28 13:28:23 --> Security Class Initialized
INFO - 2016-10-28 13:28:23 --> Loader Class Initialized
DEBUG - 2016-10-28 13:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:23 --> Input Class Initialized
INFO - 2016-10-28 13:28:23 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:23 --> Language Class Initialized
INFO - 2016-10-28 13:28:23 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:23 --> Loader Class Initialized
INFO - 2016-10-28 13:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:23 --> Controller Class Initialized
INFO - 2016-10-28 13:28:23 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:23 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:23 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:23 --> Model Class Initialized
INFO - 2016-10-28 13:28:23 --> Model Class Initialized
INFO - 2016-10-28 13:28:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:23 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:23 --> Total execution time: 0.0888
INFO - 2016-10-28 13:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:23 --> Controller Class Initialized
INFO - 2016-10-28 13:28:23 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:23 --> Model Class Initialized
INFO - 2016-10-28 13:28:23 --> Model Class Initialized
INFO - 2016-10-28 13:28:23 --> Model Class Initialized
INFO - 2016-10-28 13:28:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:23 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:23 --> Total execution time: 0.2516
INFO - 2016-10-28 13:28:24 --> Config Class Initialized
INFO - 2016-10-28 13:28:24 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:24 --> Config Class Initialized
INFO - 2016-10-28 13:28:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:24 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:24 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:24 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:24 --> Router Class Initialized
INFO - 2016-10-28 13:28:24 --> URI Class Initialized
INFO - 2016-10-28 13:28:24 --> Output Class Initialized
INFO - 2016-10-28 13:28:24 --> Router Class Initialized
INFO - 2016-10-28 13:28:24 --> Security Class Initialized
INFO - 2016-10-28 13:28:24 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:24 --> Input Class Initialized
INFO - 2016-10-28 13:28:24 --> Security Class Initialized
INFO - 2016-10-28 13:28:24 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:24 --> Input Class Initialized
INFO - 2016-10-28 13:28:24 --> Loader Class Initialized
INFO - 2016-10-28 13:28:24 --> Language Class Initialized
INFO - 2016-10-28 13:28:24 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:24 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:24 --> Loader Class Initialized
INFO - 2016-10-28 13:28:24 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:24 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:24 --> Controller Class Initialized
INFO - 2016-10-28 13:28:24 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:24 --> Model Class Initialized
INFO - 2016-10-28 13:28:24 --> Model Class Initialized
INFO - 2016-10-28 13:28:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:24 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:24 --> Total execution time: 0.1043
INFO - 2016-10-28 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:24 --> Controller Class Initialized
INFO - 2016-10-28 13:28:24 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:24 --> Model Class Initialized
INFO - 2016-10-28 13:28:24 --> Model Class Initialized
INFO - 2016-10-28 13:28:24 --> Model Class Initialized
INFO - 2016-10-28 13:28:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:25 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:25 --> Total execution time: 0.2444
INFO - 2016-10-28 13:28:27 --> Config Class Initialized
INFO - 2016-10-28 13:28:27 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:27 --> Config Class Initialized
INFO - 2016-10-28 13:28:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:27 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:28:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:27 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:27 --> URI Class Initialized
INFO - 2016-10-28 13:28:27 --> URI Class Initialized
INFO - 2016-10-28 13:28:27 --> Router Class Initialized
INFO - 2016-10-28 13:28:27 --> Router Class Initialized
INFO - 2016-10-28 13:28:27 --> Output Class Initialized
INFO - 2016-10-28 13:28:27 --> Output Class Initialized
INFO - 2016-10-28 13:28:27 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:27 --> Input Class Initialized
INFO - 2016-10-28 13:28:27 --> Language Class Initialized
INFO - 2016-10-28 13:28:27 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:27 --> Loader Class Initialized
INFO - 2016-10-28 13:28:27 --> Input Class Initialized
INFO - 2016-10-28 13:28:27 --> Language Class Initialized
INFO - 2016-10-28 13:28:27 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:27 --> Loader Class Initialized
INFO - 2016-10-28 13:28:27 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:27 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:27 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:27 --> Controller Class Initialized
INFO - 2016-10-28 13:28:27 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:27 --> Model Class Initialized
INFO - 2016-10-28 13:28:27 --> Model Class Initialized
INFO - 2016-10-28 13:28:27 --> Model Class Initialized
INFO - 2016-10-28 13:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:27 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:27 --> Total execution time: 0.2091
INFO - 2016-10-28 13:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:27 --> Controller Class Initialized
INFO - 2016-10-28 13:28:27 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:27 --> Model Class Initialized
INFO - 2016-10-28 13:28:27 --> Model Class Initialized
INFO - 2016-10-28 13:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:27 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:27 --> Total execution time: 0.2435
INFO - 2016-10-28 13:28:29 --> Config Class Initialized
INFO - 2016-10-28 13:28:29 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:29 --> Config Class Initialized
INFO - 2016-10-28 13:28:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:29 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:29 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:29 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:29 --> URI Class Initialized
INFO - 2016-10-28 13:28:29 --> Router Class Initialized
INFO - 2016-10-28 13:28:29 --> Router Class Initialized
INFO - 2016-10-28 13:28:29 --> Output Class Initialized
INFO - 2016-10-28 13:28:29 --> Output Class Initialized
INFO - 2016-10-28 13:28:29 --> Security Class Initialized
INFO - 2016-10-28 13:28:29 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-28 13:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:29 --> Input Class Initialized
INFO - 2016-10-28 13:28:29 --> Input Class Initialized
INFO - 2016-10-28 13:28:29 --> Language Class Initialized
INFO - 2016-10-28 13:28:29 --> Language Class Initialized
INFO - 2016-10-28 13:28:29 --> Loader Class Initialized
INFO - 2016-10-28 13:28:29 --> Loader Class Initialized
INFO - 2016-10-28 13:28:29 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:29 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:29 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:29 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:29 --> Controller Class Initialized
INFO - 2016-10-28 13:28:29 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:29 --> Model Class Initialized
INFO - 2016-10-28 13:28:29 --> Model Class Initialized
INFO - 2016-10-28 13:28:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:29 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:29 --> Total execution time: 0.1104
INFO - 2016-10-28 13:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:29 --> Controller Class Initialized
INFO - 2016-10-28 13:28:29 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:29 --> Model Class Initialized
INFO - 2016-10-28 13:28:29 --> Model Class Initialized
INFO - 2016-10-28 13:28:29 --> Model Class Initialized
INFO - 2016-10-28 13:28:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:29 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:29 --> Total execution time: 0.2599
INFO - 2016-10-28 13:28:30 --> Config Class Initialized
INFO - 2016-10-28 13:28:30 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:30 --> Config Class Initialized
INFO - 2016-10-28 13:28:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:30 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:30 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:30 --> Router Class Initialized
INFO - 2016-10-28 13:28:30 --> URI Class Initialized
INFO - 2016-10-28 13:28:30 --> Router Class Initialized
INFO - 2016-10-28 13:28:30 --> Output Class Initialized
INFO - 2016-10-28 13:28:30 --> Output Class Initialized
INFO - 2016-10-28 13:28:30 --> Security Class Initialized
INFO - 2016-10-28 13:28:30 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:30 --> Input Class Initialized
DEBUG - 2016-10-28 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:30 --> Input Class Initialized
INFO - 2016-10-28 13:28:30 --> Language Class Initialized
INFO - 2016-10-28 13:28:30 --> Language Class Initialized
INFO - 2016-10-28 13:28:30 --> Loader Class Initialized
INFO - 2016-10-28 13:28:30 --> Loader Class Initialized
INFO - 2016-10-28 13:28:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:30 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:30 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:30 --> Controller Class Initialized
INFO - 2016-10-28 13:28:30 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:31 --> Model Class Initialized
INFO - 2016-10-28 13:28:31 --> Model Class Initialized
INFO - 2016-10-28 13:28:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:31 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:31 --> Total execution time: 0.0951
INFO - 2016-10-28 13:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:31 --> Controller Class Initialized
INFO - 2016-10-28 13:28:31 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:31 --> Model Class Initialized
INFO - 2016-10-28 13:28:31 --> Model Class Initialized
INFO - 2016-10-28 13:28:31 --> Model Class Initialized
INFO - 2016-10-28 13:28:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:31 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:31 --> Total execution time: 0.2119
INFO - 2016-10-28 13:28:32 --> Config Class Initialized
INFO - 2016-10-28 13:28:32 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:32 --> Config Class Initialized
INFO - 2016-10-28 13:28:32 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:32 --> Utf8 Class Initialized
DEBUG - 2016-10-28 13:28:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:32 --> URI Class Initialized
INFO - 2016-10-28 13:28:32 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:32 --> URI Class Initialized
INFO - 2016-10-28 13:28:32 --> Router Class Initialized
INFO - 2016-10-28 13:28:32 --> Router Class Initialized
INFO - 2016-10-28 13:28:32 --> Output Class Initialized
INFO - 2016-10-28 13:28:32 --> Security Class Initialized
INFO - 2016-10-28 13:28:32 --> Output Class Initialized
DEBUG - 2016-10-28 13:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:32 --> Security Class Initialized
INFO - 2016-10-28 13:28:32 --> Input Class Initialized
INFO - 2016-10-28 13:28:32 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:32 --> Input Class Initialized
INFO - 2016-10-28 13:28:32 --> Language Class Initialized
INFO - 2016-10-28 13:28:32 --> Loader Class Initialized
INFO - 2016-10-28 13:28:32 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:32 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:32 --> Loader Class Initialized
INFO - 2016-10-28 13:28:32 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:32 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:32 --> Controller Class Initialized
INFO - 2016-10-28 13:28:32 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:32 --> Model Class Initialized
INFO - 2016-10-28 13:28:32 --> Model Class Initialized
INFO - 2016-10-28 13:28:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:32 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:32 --> Total execution time: 0.1012
INFO - 2016-10-28 13:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:32 --> Controller Class Initialized
INFO - 2016-10-28 13:28:32 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:32 --> Model Class Initialized
INFO - 2016-10-28 13:28:32 --> Model Class Initialized
INFO - 2016-10-28 13:28:32 --> Model Class Initialized
INFO - 2016-10-28 13:28:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:32 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:32 --> Total execution time: 0.2524
INFO - 2016-10-28 13:28:34 --> Config Class Initialized
INFO - 2016-10-28 13:28:34 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:34 --> Config Class Initialized
INFO - 2016-10-28 13:28:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-28 13:28:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:34 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:34 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:34 --> URI Class Initialized
INFO - 2016-10-28 13:28:34 --> URI Class Initialized
INFO - 2016-10-28 13:28:34 --> Router Class Initialized
INFO - 2016-10-28 13:28:34 --> Router Class Initialized
INFO - 2016-10-28 13:28:34 --> Output Class Initialized
INFO - 2016-10-28 13:28:34 --> Output Class Initialized
INFO - 2016-10-28 13:28:34 --> Security Class Initialized
INFO - 2016-10-28 13:28:34 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:34 --> Input Class Initialized
DEBUG - 2016-10-28 13:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:34 --> Input Class Initialized
INFO - 2016-10-28 13:28:34 --> Language Class Initialized
INFO - 2016-10-28 13:28:34 --> Language Class Initialized
INFO - 2016-10-28 13:28:34 --> Loader Class Initialized
INFO - 2016-10-28 13:28:34 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:34 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:34 --> Loader Class Initialized
INFO - 2016-10-28 13:28:34 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:34 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:34 --> Controller Class Initialized
INFO - 2016-10-28 13:28:34 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:34 --> Model Class Initialized
INFO - 2016-10-28 13:28:34 --> Model Class Initialized
INFO - 2016-10-28 13:28:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:34 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:34 --> Total execution time: 0.1108
INFO - 2016-10-28 13:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:34 --> Controller Class Initialized
INFO - 2016-10-28 13:28:34 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:34 --> Model Class Initialized
INFO - 2016-10-28 13:28:34 --> Model Class Initialized
INFO - 2016-10-28 13:28:34 --> Model Class Initialized
INFO - 2016-10-28 13:28:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:34 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:34 --> Total execution time: 0.2845
INFO - 2016-10-28 13:28:36 --> Config Class Initialized
INFO - 2016-10-28 13:28:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:36 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:36 --> URI Class Initialized
INFO - 2016-10-28 13:28:36 --> Router Class Initialized
INFO - 2016-10-28 13:28:36 --> Output Class Initialized
INFO - 2016-10-28 13:28:36 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:36 --> Input Class Initialized
INFO - 2016-10-28 13:28:36 --> Language Class Initialized
INFO - 2016-10-28 13:28:36 --> Loader Class Initialized
INFO - 2016-10-28 13:28:36 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:36 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:36 --> Controller Class Initialized
INFO - 2016-10-28 13:28:36 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:36 --> Model Class Initialized
INFO - 2016-10-28 13:28:36 --> Model Class Initialized
INFO - 2016-10-28 13:28:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:36 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:36 --> Total execution time: 0.1828
INFO - 2016-10-28 13:28:37 --> Config Class Initialized
INFO - 2016-10-28 13:28:37 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:37 --> Config Class Initialized
INFO - 2016-10-28 13:28:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:37 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:37 --> Config Class Initialized
INFO - 2016-10-28 13:28:37 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:37 --> Router Class Initialized
INFO - 2016-10-28 13:28:37 --> URI Class Initialized
INFO - 2016-10-28 13:28:37 --> Output Class Initialized
INFO - 2016-10-28 13:28:37 --> Router Class Initialized
INFO - 2016-10-28 13:28:37 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:37 --> Output Class Initialized
INFO - 2016-10-28 13:28:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:37 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:37 --> URI Class Initialized
INFO - 2016-10-28 13:28:37 --> Input Class Initialized
INFO - 2016-10-28 13:28:37 --> Language Class Initialized
INFO - 2016-10-28 13:28:37 --> Router Class Initialized
DEBUG - 2016-10-28 13:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:37 --> Input Class Initialized
INFO - 2016-10-28 13:28:37 --> Language Class Initialized
INFO - 2016-10-28 13:28:37 --> Output Class Initialized
INFO - 2016-10-28 13:28:37 --> Security Class Initialized
INFO - 2016-10-28 13:28:37 --> Loader Class Initialized
DEBUG - 2016-10-28 13:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:37 --> Input Class Initialized
INFO - 2016-10-28 13:28:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:37 --> Language Class Initialized
INFO - 2016-10-28 13:28:37 --> Loader Class Initialized
INFO - 2016-10-28 13:28:37 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:37 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:37 --> Loader Class Initialized
INFO - 2016-10-28 13:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:37 --> Controller Class Initialized
INFO - 2016-10-28 13:28:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:37 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:37 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:37 --> Total execution time: 0.1019
INFO - 2016-10-28 13:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:37 --> Controller Class Initialized
INFO - 2016-10-28 13:28:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:37 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:37 --> Total execution time: 0.2107
INFO - 2016-10-28 13:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:37 --> Controller Class Initialized
INFO - 2016-10-28 13:28:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:37 --> Config Class Initialized
INFO - 2016-10-28 13:28:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:37 --> URI Class Initialized
INFO - 2016-10-28 13:28:37 --> Router Class Initialized
INFO - 2016-10-28 13:28:37 --> Output Class Initialized
INFO - 2016-10-28 13:28:37 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:37 --> Input Class Initialized
INFO - 2016-10-28 13:28:37 --> Language Class Initialized
INFO - 2016-10-28 13:28:37 --> Loader Class Initialized
INFO - 2016-10-28 13:28:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:37 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:37 --> Controller Class Initialized
INFO - 2016-10-28 13:28:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Model Class Initialized
INFO - 2016-10-28 13:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:28:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2016-10-28 13:28:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:28:37 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:37 --> Total execution time: 0.0928
INFO - 2016-10-28 13:28:41 --> Config Class Initialized
INFO - 2016-10-28 13:28:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:41 --> URI Class Initialized
INFO - 2016-10-28 13:28:41 --> Router Class Initialized
INFO - 2016-10-28 13:28:41 --> Output Class Initialized
INFO - 2016-10-28 13:28:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:41 --> Input Class Initialized
INFO - 2016-10-28 13:28:41 --> Language Class Initialized
INFO - 2016-10-28 13:28:41 --> Loader Class Initialized
INFO - 2016-10-28 13:28:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:41 --> Controller Class Initialized
INFO - 2016-10-28 13:28:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:41 --> Config Class Initialized
INFO - 2016-10-28 13:28:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:41 --> URI Class Initialized
INFO - 2016-10-28 13:28:41 --> Router Class Initialized
INFO - 2016-10-28 13:28:41 --> Output Class Initialized
INFO - 2016-10-28 13:28:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:41 --> Input Class Initialized
INFO - 2016-10-28 13:28:41 --> Language Class Initialized
INFO - 2016-10-28 13:28:41 --> Loader Class Initialized
INFO - 2016-10-28 13:28:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:41 --> Controller Class Initialized
INFO - 2016-10-28 13:28:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2016-10-28 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2016-10-28 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2016-10-28 13:28:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:41 --> Total execution time: 0.1240
INFO - 2016-10-28 13:28:41 --> Config Class Initialized
INFO - 2016-10-28 13:28:41 --> Hooks Class Initialized
INFO - 2016-10-28 13:28:41 --> Config Class Initialized
INFO - 2016-10-28 13:28:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:41 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:41 --> URI Class Initialized
INFO - 2016-10-28 13:28:41 --> Router Class Initialized
INFO - 2016-10-28 13:28:41 --> Router Class Initialized
INFO - 2016-10-28 13:28:41 --> Output Class Initialized
INFO - 2016-10-28 13:28:41 --> Output Class Initialized
INFO - 2016-10-28 13:28:41 --> Security Class Initialized
INFO - 2016-10-28 13:28:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:41 --> Input Class Initialized
INFO - 2016-10-28 13:28:41 --> Language Class Initialized
DEBUG - 2016-10-28 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:41 --> Input Class Initialized
INFO - 2016-10-28 13:28:41 --> Language Class Initialized
INFO - 2016-10-28 13:28:41 --> Loader Class Initialized
INFO - 2016-10-28 13:28:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:41 --> Loader Class Initialized
INFO - 2016-10-28 13:28:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:41 --> Controller Class Initialized
INFO - 2016-10-28 13:28:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:28:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:41 --> Total execution time: 0.1022
INFO - 2016-10-28 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:41 --> Controller Class Initialized
INFO - 2016-10-28 13:28:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Model Class Initialized
INFO - 2016-10-28 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2016-10-28 13:28:41 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2016-10-28 13:28:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2016-10-28 13:28:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:41 --> Total execution time: 0.1716
INFO - 2016-10-28 13:29:11 --> Config Class Initialized
INFO - 2016-10-28 13:29:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:29:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:29:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:29:11 --> URI Class Initialized
INFO - 2016-10-28 13:29:11 --> Router Class Initialized
INFO - 2016-10-28 13:29:11 --> Output Class Initialized
INFO - 2016-10-28 13:29:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:29:11 --> Input Class Initialized
INFO - 2016-10-28 13:29:11 --> Language Class Initialized
INFO - 2016-10-28 13:29:11 --> Loader Class Initialized
INFO - 2016-10-28 13:29:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:29:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:29:11 --> Controller Class Initialized
INFO - 2016-10-28 13:29:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:29:11 --> Model Class Initialized
INFO - 2016-10-28 13:29:11 --> Model Class Initialized
INFO - 2016-10-28 13:29:11 --> Model Class Initialized
INFO - 2016-10-28 13:29:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:29:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:29:11 --> Total execution time: 0.0936
INFO - 2016-10-28 13:29:41 --> Config Class Initialized
INFO - 2016-10-28 13:29:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:29:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:29:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:29:41 --> URI Class Initialized
INFO - 2016-10-28 13:29:41 --> Router Class Initialized
INFO - 2016-10-28 13:29:41 --> Output Class Initialized
INFO - 2016-10-28 13:29:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:29:41 --> Input Class Initialized
INFO - 2016-10-28 13:29:41 --> Language Class Initialized
INFO - 2016-10-28 13:29:41 --> Loader Class Initialized
INFO - 2016-10-28 13:29:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:29:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:29:41 --> Controller Class Initialized
INFO - 2016-10-28 13:29:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:29:41 --> Model Class Initialized
INFO - 2016-10-28 13:29:41 --> Model Class Initialized
INFO - 2016-10-28 13:29:41 --> Model Class Initialized
INFO - 2016-10-28 13:29:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:29:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:29:41 --> Total execution time: 0.0902
INFO - 2016-10-28 13:30:11 --> Config Class Initialized
INFO - 2016-10-28 13:30:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:30:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:30:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:30:11 --> URI Class Initialized
INFO - 2016-10-28 13:30:11 --> Router Class Initialized
INFO - 2016-10-28 13:30:11 --> Output Class Initialized
INFO - 2016-10-28 13:30:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:30:11 --> Input Class Initialized
INFO - 2016-10-28 13:30:11 --> Language Class Initialized
INFO - 2016-10-28 13:30:11 --> Loader Class Initialized
INFO - 2016-10-28 13:30:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:30:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:30:11 --> Controller Class Initialized
INFO - 2016-10-28 13:30:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:30:11 --> Model Class Initialized
INFO - 2016-10-28 13:30:11 --> Model Class Initialized
INFO - 2016-10-28 13:30:11 --> Model Class Initialized
INFO - 2016-10-28 13:30:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:30:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:30:11 --> Total execution time: 0.1380
INFO - 2016-10-28 13:30:41 --> Config Class Initialized
INFO - 2016-10-28 13:30:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:30:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:30:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:30:41 --> URI Class Initialized
INFO - 2016-10-28 13:30:41 --> Router Class Initialized
INFO - 2016-10-28 13:30:41 --> Output Class Initialized
INFO - 2016-10-28 13:30:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:30:41 --> Input Class Initialized
INFO - 2016-10-28 13:30:41 --> Language Class Initialized
INFO - 2016-10-28 13:30:41 --> Loader Class Initialized
INFO - 2016-10-28 13:30:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:30:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:30:41 --> Controller Class Initialized
INFO - 2016-10-28 13:30:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:30:41 --> Model Class Initialized
INFO - 2016-10-28 13:30:41 --> Model Class Initialized
INFO - 2016-10-28 13:30:41 --> Model Class Initialized
INFO - 2016-10-28 13:30:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:30:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:30:41 --> Total execution time: 0.0779
INFO - 2016-10-28 13:31:11 --> Config Class Initialized
INFO - 2016-10-28 13:31:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:31:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:31:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:31:11 --> URI Class Initialized
INFO - 2016-10-28 13:31:11 --> Router Class Initialized
INFO - 2016-10-28 13:31:11 --> Output Class Initialized
INFO - 2016-10-28 13:31:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:31:11 --> Input Class Initialized
INFO - 2016-10-28 13:31:11 --> Language Class Initialized
INFO - 2016-10-28 13:31:11 --> Loader Class Initialized
INFO - 2016-10-28 13:31:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:31:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:31:11 --> Controller Class Initialized
INFO - 2016-10-28 13:31:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:31:11 --> Model Class Initialized
INFO - 2016-10-28 13:31:11 --> Model Class Initialized
INFO - 2016-10-28 13:31:11 --> Model Class Initialized
INFO - 2016-10-28 13:31:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:31:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:31:11 --> Total execution time: 0.0708
INFO - 2016-10-28 13:31:41 --> Config Class Initialized
INFO - 2016-10-28 13:31:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:31:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:31:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:31:41 --> URI Class Initialized
INFO - 2016-10-28 13:31:41 --> Router Class Initialized
INFO - 2016-10-28 13:31:41 --> Output Class Initialized
INFO - 2016-10-28 13:31:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:31:41 --> Input Class Initialized
INFO - 2016-10-28 13:31:41 --> Language Class Initialized
INFO - 2016-10-28 13:31:41 --> Loader Class Initialized
INFO - 2016-10-28 13:31:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:31:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:31:41 --> Controller Class Initialized
INFO - 2016-10-28 13:31:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:31:41 --> Model Class Initialized
INFO - 2016-10-28 13:31:41 --> Model Class Initialized
INFO - 2016-10-28 13:31:41 --> Model Class Initialized
INFO - 2016-10-28 13:31:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:31:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:31:41 --> Total execution time: 0.0710
INFO - 2016-10-28 13:32:11 --> Config Class Initialized
INFO - 2016-10-28 13:32:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:32:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:32:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:32:11 --> URI Class Initialized
INFO - 2016-10-28 13:32:11 --> Router Class Initialized
INFO - 2016-10-28 13:32:11 --> Output Class Initialized
INFO - 2016-10-28 13:32:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:32:11 --> Input Class Initialized
INFO - 2016-10-28 13:32:11 --> Language Class Initialized
INFO - 2016-10-28 13:32:11 --> Loader Class Initialized
INFO - 2016-10-28 13:32:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:32:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:32:11 --> Controller Class Initialized
INFO - 2016-10-28 13:32:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:32:11 --> Model Class Initialized
INFO - 2016-10-28 13:32:11 --> Model Class Initialized
INFO - 2016-10-28 13:32:11 --> Model Class Initialized
INFO - 2016-10-28 13:32:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:32:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:32:11 --> Total execution time: 0.0775
INFO - 2016-10-28 13:32:41 --> Config Class Initialized
INFO - 2016-10-28 13:32:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:32:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:32:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:32:41 --> URI Class Initialized
INFO - 2016-10-28 13:32:41 --> Router Class Initialized
INFO - 2016-10-28 13:32:41 --> Output Class Initialized
INFO - 2016-10-28 13:32:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:32:41 --> Input Class Initialized
INFO - 2016-10-28 13:32:41 --> Language Class Initialized
INFO - 2016-10-28 13:32:41 --> Loader Class Initialized
INFO - 2016-10-28 13:32:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:32:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:32:41 --> Controller Class Initialized
INFO - 2016-10-28 13:32:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:32:41 --> Model Class Initialized
INFO - 2016-10-28 13:32:41 --> Model Class Initialized
INFO - 2016-10-28 13:32:41 --> Model Class Initialized
INFO - 2016-10-28 13:32:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:32:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:32:41 --> Total execution time: 0.0887
INFO - 2016-10-28 13:33:11 --> Config Class Initialized
INFO - 2016-10-28 13:33:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:33:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:33:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:33:11 --> URI Class Initialized
INFO - 2016-10-28 13:33:11 --> Router Class Initialized
INFO - 2016-10-28 13:33:11 --> Output Class Initialized
INFO - 2016-10-28 13:33:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:33:11 --> Input Class Initialized
INFO - 2016-10-28 13:33:11 --> Language Class Initialized
INFO - 2016-10-28 13:33:11 --> Loader Class Initialized
INFO - 2016-10-28 13:33:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:33:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:33:11 --> Controller Class Initialized
INFO - 2016-10-28 13:33:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:33:11 --> Model Class Initialized
INFO - 2016-10-28 13:33:11 --> Model Class Initialized
INFO - 2016-10-28 13:33:11 --> Model Class Initialized
INFO - 2016-10-28 13:33:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:33:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:33:11 --> Total execution time: 0.0655
INFO - 2016-10-28 13:33:41 --> Config Class Initialized
INFO - 2016-10-28 13:33:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:33:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:33:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:33:41 --> URI Class Initialized
INFO - 2016-10-28 13:33:41 --> Router Class Initialized
INFO - 2016-10-28 13:33:41 --> Output Class Initialized
INFO - 2016-10-28 13:33:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:33:41 --> Input Class Initialized
INFO - 2016-10-28 13:33:41 --> Language Class Initialized
INFO - 2016-10-28 13:33:41 --> Loader Class Initialized
INFO - 2016-10-28 13:33:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:33:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:33:41 --> Controller Class Initialized
INFO - 2016-10-28 13:33:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:33:41 --> Model Class Initialized
INFO - 2016-10-28 13:33:41 --> Model Class Initialized
INFO - 2016-10-28 13:33:41 --> Model Class Initialized
INFO - 2016-10-28 13:33:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:33:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:33:41 --> Total execution time: 0.0658
INFO - 2016-10-28 13:34:11 --> Config Class Initialized
INFO - 2016-10-28 13:34:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:34:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:34:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:34:11 --> URI Class Initialized
INFO - 2016-10-28 13:34:11 --> Router Class Initialized
INFO - 2016-10-28 13:34:11 --> Output Class Initialized
INFO - 2016-10-28 13:34:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:34:11 --> Input Class Initialized
INFO - 2016-10-28 13:34:11 --> Language Class Initialized
INFO - 2016-10-28 13:34:11 --> Loader Class Initialized
INFO - 2016-10-28 13:34:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:34:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:34:11 --> Controller Class Initialized
INFO - 2016-10-28 13:34:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:34:11 --> Model Class Initialized
INFO - 2016-10-28 13:34:11 --> Model Class Initialized
INFO - 2016-10-28 13:34:11 --> Model Class Initialized
INFO - 2016-10-28 13:34:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:34:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:34:11 --> Total execution time: 0.0707
INFO - 2016-10-28 13:34:41 --> Config Class Initialized
INFO - 2016-10-28 13:34:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:34:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:34:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:34:41 --> URI Class Initialized
INFO - 2016-10-28 13:34:41 --> Router Class Initialized
INFO - 2016-10-28 13:34:41 --> Output Class Initialized
INFO - 2016-10-28 13:34:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:34:41 --> Input Class Initialized
INFO - 2016-10-28 13:34:41 --> Language Class Initialized
INFO - 2016-10-28 13:34:41 --> Loader Class Initialized
INFO - 2016-10-28 13:34:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:34:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:34:41 --> Controller Class Initialized
INFO - 2016-10-28 13:34:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:34:41 --> Model Class Initialized
INFO - 2016-10-28 13:34:41 --> Model Class Initialized
INFO - 2016-10-28 13:34:41 --> Model Class Initialized
INFO - 2016-10-28 13:34:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:34:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:34:41 --> Total execution time: 0.1919
INFO - 2016-10-28 13:35:11 --> Config Class Initialized
INFO - 2016-10-28 13:35:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:35:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:35:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:35:11 --> URI Class Initialized
INFO - 2016-10-28 13:35:11 --> Router Class Initialized
INFO - 2016-10-28 13:35:11 --> Output Class Initialized
INFO - 2016-10-28 13:35:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:35:11 --> Input Class Initialized
INFO - 2016-10-28 13:35:11 --> Language Class Initialized
INFO - 2016-10-28 13:35:11 --> Loader Class Initialized
INFO - 2016-10-28 13:35:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:35:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:35:11 --> Controller Class Initialized
INFO - 2016-10-28 13:35:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:35:11 --> Model Class Initialized
INFO - 2016-10-28 13:35:11 --> Model Class Initialized
INFO - 2016-10-28 13:35:11 --> Model Class Initialized
INFO - 2016-10-28 13:35:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:35:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:35:11 --> Total execution time: 0.0782
INFO - 2016-10-28 13:35:41 --> Config Class Initialized
INFO - 2016-10-28 13:35:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:35:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:35:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:35:41 --> URI Class Initialized
INFO - 2016-10-28 13:35:41 --> Router Class Initialized
INFO - 2016-10-28 13:35:41 --> Output Class Initialized
INFO - 2016-10-28 13:35:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:35:41 --> Input Class Initialized
INFO - 2016-10-28 13:35:41 --> Language Class Initialized
INFO - 2016-10-28 13:35:41 --> Loader Class Initialized
INFO - 2016-10-28 13:35:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:35:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:35:41 --> Controller Class Initialized
INFO - 2016-10-28 13:35:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:35:41 --> Model Class Initialized
INFO - 2016-10-28 13:35:41 --> Model Class Initialized
INFO - 2016-10-28 13:35:41 --> Model Class Initialized
INFO - 2016-10-28 13:35:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:35:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:35:41 --> Total execution time: 0.0812
INFO - 2016-10-28 13:36:11 --> Config Class Initialized
INFO - 2016-10-28 13:36:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:36:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:36:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:36:11 --> URI Class Initialized
INFO - 2016-10-28 13:36:11 --> Router Class Initialized
INFO - 2016-10-28 13:36:11 --> Output Class Initialized
INFO - 2016-10-28 13:36:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:36:11 --> Input Class Initialized
INFO - 2016-10-28 13:36:11 --> Language Class Initialized
INFO - 2016-10-28 13:36:11 --> Loader Class Initialized
INFO - 2016-10-28 13:36:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:36:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:36:11 --> Controller Class Initialized
INFO - 2016-10-28 13:36:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:36:11 --> Model Class Initialized
INFO - 2016-10-28 13:36:11 --> Model Class Initialized
INFO - 2016-10-28 13:36:11 --> Model Class Initialized
INFO - 2016-10-28 13:36:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:36:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:36:11 --> Total execution time: 0.2215
INFO - 2016-10-28 13:36:41 --> Config Class Initialized
INFO - 2016-10-28 13:36:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:36:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:36:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:36:41 --> URI Class Initialized
INFO - 2016-10-28 13:36:41 --> Router Class Initialized
INFO - 2016-10-28 13:36:41 --> Output Class Initialized
INFO - 2016-10-28 13:36:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:36:41 --> Input Class Initialized
INFO - 2016-10-28 13:36:41 --> Language Class Initialized
INFO - 2016-10-28 13:36:41 --> Loader Class Initialized
INFO - 2016-10-28 13:36:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:36:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:36:41 --> Controller Class Initialized
INFO - 2016-10-28 13:36:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:36:41 --> Model Class Initialized
INFO - 2016-10-28 13:36:41 --> Model Class Initialized
INFO - 2016-10-28 13:36:41 --> Model Class Initialized
INFO - 2016-10-28 13:36:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:36:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:36:41 --> Total execution time: 0.0736
INFO - 2016-10-28 13:37:11 --> Config Class Initialized
INFO - 2016-10-28 13:37:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:37:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:37:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:37:11 --> URI Class Initialized
INFO - 2016-10-28 13:37:11 --> Router Class Initialized
INFO - 2016-10-28 13:37:11 --> Output Class Initialized
INFO - 2016-10-28 13:37:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:37:11 --> Input Class Initialized
INFO - 2016-10-28 13:37:11 --> Language Class Initialized
INFO - 2016-10-28 13:37:11 --> Loader Class Initialized
INFO - 2016-10-28 13:37:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:37:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:37:11 --> Controller Class Initialized
INFO - 2016-10-28 13:37:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:37:11 --> Model Class Initialized
INFO - 2016-10-28 13:37:11 --> Model Class Initialized
INFO - 2016-10-28 13:37:11 --> Model Class Initialized
INFO - 2016-10-28 13:37:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:37:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:37:11 --> Total execution time: 0.0824
INFO - 2016-10-28 13:37:41 --> Config Class Initialized
INFO - 2016-10-28 13:37:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:37:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:37:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:37:41 --> URI Class Initialized
INFO - 2016-10-28 13:37:41 --> Router Class Initialized
INFO - 2016-10-28 13:37:41 --> Output Class Initialized
INFO - 2016-10-28 13:37:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:37:41 --> Input Class Initialized
INFO - 2016-10-28 13:37:41 --> Language Class Initialized
INFO - 2016-10-28 13:37:41 --> Loader Class Initialized
INFO - 2016-10-28 13:37:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:37:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:37:41 --> Controller Class Initialized
INFO - 2016-10-28 13:37:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:37:41 --> Model Class Initialized
INFO - 2016-10-28 13:37:41 --> Model Class Initialized
INFO - 2016-10-28 13:37:41 --> Model Class Initialized
INFO - 2016-10-28 13:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:37:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:37:41 --> Total execution time: 0.0729
INFO - 2016-10-28 13:38:11 --> Config Class Initialized
INFO - 2016-10-28 13:38:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:38:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:38:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:38:11 --> URI Class Initialized
INFO - 2016-10-28 13:38:11 --> Router Class Initialized
INFO - 2016-10-28 13:38:11 --> Output Class Initialized
INFO - 2016-10-28 13:38:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:38:11 --> Input Class Initialized
INFO - 2016-10-28 13:38:11 --> Language Class Initialized
INFO - 2016-10-28 13:38:11 --> Loader Class Initialized
INFO - 2016-10-28 13:38:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:38:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:38:11 --> Controller Class Initialized
INFO - 2016-10-28 13:38:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:38:11 --> Model Class Initialized
INFO - 2016-10-28 13:38:11 --> Model Class Initialized
INFO - 2016-10-28 13:38:11 --> Model Class Initialized
INFO - 2016-10-28 13:38:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:38:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:38:11 --> Total execution time: 0.1281
INFO - 2016-10-28 13:38:41 --> Config Class Initialized
INFO - 2016-10-28 13:38:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:38:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:38:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:38:41 --> URI Class Initialized
INFO - 2016-10-28 13:38:41 --> Router Class Initialized
INFO - 2016-10-28 13:38:41 --> Output Class Initialized
INFO - 2016-10-28 13:38:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:38:41 --> Input Class Initialized
INFO - 2016-10-28 13:38:41 --> Language Class Initialized
INFO - 2016-10-28 13:38:41 --> Loader Class Initialized
INFO - 2016-10-28 13:38:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:38:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:38:41 --> Controller Class Initialized
INFO - 2016-10-28 13:38:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:38:41 --> Model Class Initialized
INFO - 2016-10-28 13:38:41 --> Model Class Initialized
INFO - 2016-10-28 13:38:41 --> Model Class Initialized
INFO - 2016-10-28 13:38:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:38:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:38:41 --> Total execution time: 0.0770
INFO - 2016-10-28 13:39:11 --> Config Class Initialized
INFO - 2016-10-28 13:39:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:39:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:39:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:39:11 --> URI Class Initialized
INFO - 2016-10-28 13:39:11 --> Router Class Initialized
INFO - 2016-10-28 13:39:11 --> Output Class Initialized
INFO - 2016-10-28 13:39:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:39:11 --> Input Class Initialized
INFO - 2016-10-28 13:39:11 --> Language Class Initialized
INFO - 2016-10-28 13:39:11 --> Loader Class Initialized
INFO - 2016-10-28 13:39:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:39:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:39:11 --> Controller Class Initialized
INFO - 2016-10-28 13:39:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:39:11 --> Model Class Initialized
INFO - 2016-10-28 13:39:11 --> Model Class Initialized
INFO - 2016-10-28 13:39:11 --> Model Class Initialized
INFO - 2016-10-28 13:39:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:39:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:39:11 --> Total execution time: 0.0828
INFO - 2016-10-28 13:39:41 --> Config Class Initialized
INFO - 2016-10-28 13:39:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:39:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:39:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:39:41 --> URI Class Initialized
INFO - 2016-10-28 13:39:41 --> Router Class Initialized
INFO - 2016-10-28 13:39:41 --> Output Class Initialized
INFO - 2016-10-28 13:39:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:39:41 --> Input Class Initialized
INFO - 2016-10-28 13:39:41 --> Language Class Initialized
INFO - 2016-10-28 13:39:41 --> Loader Class Initialized
INFO - 2016-10-28 13:39:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:39:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:39:41 --> Controller Class Initialized
INFO - 2016-10-28 13:39:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:39:41 --> Model Class Initialized
INFO - 2016-10-28 13:39:41 --> Model Class Initialized
INFO - 2016-10-28 13:39:41 --> Model Class Initialized
INFO - 2016-10-28 13:39:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:39:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:39:41 --> Total execution time: 0.2059
INFO - 2016-10-28 13:40:11 --> Config Class Initialized
INFO - 2016-10-28 13:40:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:40:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:40:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:40:11 --> URI Class Initialized
INFO - 2016-10-28 13:40:11 --> Router Class Initialized
INFO - 2016-10-28 13:40:11 --> Output Class Initialized
INFO - 2016-10-28 13:40:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:40:11 --> Input Class Initialized
INFO - 2016-10-28 13:40:11 --> Language Class Initialized
INFO - 2016-10-28 13:40:11 --> Loader Class Initialized
INFO - 2016-10-28 13:40:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:40:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:40:11 --> Controller Class Initialized
INFO - 2016-10-28 13:40:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:40:11 --> Model Class Initialized
INFO - 2016-10-28 13:40:11 --> Model Class Initialized
INFO - 2016-10-28 13:40:11 --> Model Class Initialized
INFO - 2016-10-28 13:40:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:40:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:40:11 --> Total execution time: 0.0678
INFO - 2016-10-28 13:40:41 --> Config Class Initialized
INFO - 2016-10-28 13:40:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:40:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:40:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:40:41 --> URI Class Initialized
INFO - 2016-10-28 13:40:41 --> Router Class Initialized
INFO - 2016-10-28 13:40:41 --> Output Class Initialized
INFO - 2016-10-28 13:40:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:40:41 --> Input Class Initialized
INFO - 2016-10-28 13:40:41 --> Language Class Initialized
INFO - 2016-10-28 13:40:41 --> Loader Class Initialized
INFO - 2016-10-28 13:40:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:40:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:40:41 --> Controller Class Initialized
INFO - 2016-10-28 13:40:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:40:41 --> Model Class Initialized
INFO - 2016-10-28 13:40:41 --> Model Class Initialized
INFO - 2016-10-28 13:40:41 --> Model Class Initialized
INFO - 2016-10-28 13:40:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:40:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:40:41 --> Total execution time: 0.0665
INFO - 2016-10-28 13:41:11 --> Config Class Initialized
INFO - 2016-10-28 13:41:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:41:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:41:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:41:11 --> URI Class Initialized
INFO - 2016-10-28 13:41:11 --> Router Class Initialized
INFO - 2016-10-28 13:41:11 --> Output Class Initialized
INFO - 2016-10-28 13:41:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:41:11 --> Input Class Initialized
INFO - 2016-10-28 13:41:11 --> Language Class Initialized
INFO - 2016-10-28 13:41:11 --> Loader Class Initialized
INFO - 2016-10-28 13:41:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:41:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:41:11 --> Controller Class Initialized
INFO - 2016-10-28 13:41:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:41:11 --> Model Class Initialized
INFO - 2016-10-28 13:41:11 --> Model Class Initialized
INFO - 2016-10-28 13:41:11 --> Model Class Initialized
INFO - 2016-10-28 13:41:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:41:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:41:11 --> Total execution time: 0.0651
INFO - 2016-10-28 13:41:41 --> Config Class Initialized
INFO - 2016-10-28 13:41:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:41:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:41:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:41:41 --> URI Class Initialized
INFO - 2016-10-28 13:41:41 --> Router Class Initialized
INFO - 2016-10-28 13:41:41 --> Output Class Initialized
INFO - 2016-10-28 13:41:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:41:41 --> Input Class Initialized
INFO - 2016-10-28 13:41:41 --> Language Class Initialized
INFO - 2016-10-28 13:41:41 --> Loader Class Initialized
INFO - 2016-10-28 13:41:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:41:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:41:41 --> Controller Class Initialized
INFO - 2016-10-28 13:41:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:41:41 --> Model Class Initialized
INFO - 2016-10-28 13:41:41 --> Model Class Initialized
INFO - 2016-10-28 13:41:41 --> Model Class Initialized
INFO - 2016-10-28 13:41:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:41:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:41:41 --> Total execution time: 0.0664
INFO - 2016-10-28 13:42:11 --> Config Class Initialized
INFO - 2016-10-28 13:42:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:42:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:42:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:42:11 --> URI Class Initialized
INFO - 2016-10-28 13:42:11 --> Router Class Initialized
INFO - 2016-10-28 13:42:11 --> Output Class Initialized
INFO - 2016-10-28 13:42:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:42:11 --> Input Class Initialized
INFO - 2016-10-28 13:42:11 --> Language Class Initialized
INFO - 2016-10-28 13:42:11 --> Loader Class Initialized
INFO - 2016-10-28 13:42:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:42:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:42:11 --> Controller Class Initialized
INFO - 2016-10-28 13:42:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:42:11 --> Model Class Initialized
INFO - 2016-10-28 13:42:11 --> Model Class Initialized
INFO - 2016-10-28 13:42:11 --> Model Class Initialized
INFO - 2016-10-28 13:42:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:42:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:42:11 --> Total execution time: 0.0787
INFO - 2016-10-28 13:42:41 --> Config Class Initialized
INFO - 2016-10-28 13:42:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:42:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:42:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:42:41 --> URI Class Initialized
INFO - 2016-10-28 13:42:41 --> Router Class Initialized
INFO - 2016-10-28 13:42:41 --> Output Class Initialized
INFO - 2016-10-28 13:42:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:42:41 --> Input Class Initialized
INFO - 2016-10-28 13:42:41 --> Language Class Initialized
INFO - 2016-10-28 13:42:41 --> Loader Class Initialized
INFO - 2016-10-28 13:42:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:42:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:42:41 --> Controller Class Initialized
INFO - 2016-10-28 13:42:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:42:41 --> Model Class Initialized
INFO - 2016-10-28 13:42:41 --> Model Class Initialized
INFO - 2016-10-28 13:42:41 --> Model Class Initialized
INFO - 2016-10-28 13:42:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:42:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:42:41 --> Total execution time: 0.0743
INFO - 2016-10-28 13:43:11 --> Config Class Initialized
INFO - 2016-10-28 13:43:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:43:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:43:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:43:11 --> URI Class Initialized
INFO - 2016-10-28 13:43:11 --> Router Class Initialized
INFO - 2016-10-28 13:43:11 --> Output Class Initialized
INFO - 2016-10-28 13:43:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:43:11 --> Input Class Initialized
INFO - 2016-10-28 13:43:11 --> Language Class Initialized
INFO - 2016-10-28 13:43:11 --> Loader Class Initialized
INFO - 2016-10-28 13:43:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:43:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:43:11 --> Controller Class Initialized
INFO - 2016-10-28 13:43:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:43:11 --> Model Class Initialized
INFO - 2016-10-28 13:43:11 --> Model Class Initialized
INFO - 2016-10-28 13:43:11 --> Model Class Initialized
INFO - 2016-10-28 13:43:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:43:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:43:11 --> Total execution time: 0.0796
INFO - 2016-10-28 13:43:41 --> Config Class Initialized
INFO - 2016-10-28 13:43:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:43:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:43:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:43:41 --> URI Class Initialized
INFO - 2016-10-28 13:43:41 --> Router Class Initialized
INFO - 2016-10-28 13:43:41 --> Output Class Initialized
INFO - 2016-10-28 13:43:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:43:41 --> Input Class Initialized
INFO - 2016-10-28 13:43:41 --> Language Class Initialized
INFO - 2016-10-28 13:43:41 --> Loader Class Initialized
INFO - 2016-10-28 13:43:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:43:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:43:41 --> Controller Class Initialized
INFO - 2016-10-28 13:43:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:43:41 --> Model Class Initialized
INFO - 2016-10-28 13:43:41 --> Model Class Initialized
INFO - 2016-10-28 13:43:41 --> Model Class Initialized
INFO - 2016-10-28 13:43:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:43:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:43:41 --> Total execution time: 0.0764
INFO - 2016-10-28 13:44:11 --> Config Class Initialized
INFO - 2016-10-28 13:44:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:44:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:44:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:44:11 --> URI Class Initialized
INFO - 2016-10-28 13:44:11 --> Router Class Initialized
INFO - 2016-10-28 13:44:11 --> Output Class Initialized
INFO - 2016-10-28 13:44:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:44:11 --> Input Class Initialized
INFO - 2016-10-28 13:44:11 --> Language Class Initialized
INFO - 2016-10-28 13:44:11 --> Loader Class Initialized
INFO - 2016-10-28 13:44:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:44:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:44:11 --> Controller Class Initialized
INFO - 2016-10-28 13:44:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:44:11 --> Model Class Initialized
INFO - 2016-10-28 13:44:11 --> Model Class Initialized
INFO - 2016-10-28 13:44:11 --> Model Class Initialized
INFO - 2016-10-28 13:44:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:44:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:44:11 --> Total execution time: 0.1018
INFO - 2016-10-28 13:44:41 --> Config Class Initialized
INFO - 2016-10-28 13:44:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:44:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:44:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:44:41 --> URI Class Initialized
INFO - 2016-10-28 13:44:41 --> Router Class Initialized
INFO - 2016-10-28 13:44:41 --> Output Class Initialized
INFO - 2016-10-28 13:44:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:44:41 --> Input Class Initialized
INFO - 2016-10-28 13:44:41 --> Language Class Initialized
INFO - 2016-10-28 13:44:41 --> Loader Class Initialized
INFO - 2016-10-28 13:44:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:44:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:44:41 --> Controller Class Initialized
INFO - 2016-10-28 13:44:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:44:41 --> Model Class Initialized
INFO - 2016-10-28 13:44:41 --> Model Class Initialized
INFO - 2016-10-28 13:44:41 --> Model Class Initialized
INFO - 2016-10-28 13:44:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:44:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:44:41 --> Total execution time: 0.2747
INFO - 2016-10-28 13:45:11 --> Config Class Initialized
INFO - 2016-10-28 13:45:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:45:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:45:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:45:11 --> URI Class Initialized
INFO - 2016-10-28 13:45:11 --> Router Class Initialized
INFO - 2016-10-28 13:45:11 --> Output Class Initialized
INFO - 2016-10-28 13:45:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:45:11 --> Input Class Initialized
INFO - 2016-10-28 13:45:11 --> Language Class Initialized
INFO - 2016-10-28 13:45:11 --> Loader Class Initialized
INFO - 2016-10-28 13:45:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:45:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:45:11 --> Controller Class Initialized
INFO - 2016-10-28 13:45:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:45:11 --> Model Class Initialized
INFO - 2016-10-28 13:45:11 --> Model Class Initialized
INFO - 2016-10-28 13:45:11 --> Model Class Initialized
INFO - 2016-10-28 13:45:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:45:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:45:11 --> Total execution time: 0.0767
INFO - 2016-10-28 13:45:41 --> Config Class Initialized
INFO - 2016-10-28 13:45:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:45:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:45:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:45:41 --> URI Class Initialized
INFO - 2016-10-28 13:45:41 --> Router Class Initialized
INFO - 2016-10-28 13:45:41 --> Output Class Initialized
INFO - 2016-10-28 13:45:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:45:41 --> Input Class Initialized
INFO - 2016-10-28 13:45:41 --> Language Class Initialized
INFO - 2016-10-28 13:45:41 --> Loader Class Initialized
INFO - 2016-10-28 13:45:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:45:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:45:41 --> Controller Class Initialized
INFO - 2016-10-28 13:45:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:45:41 --> Model Class Initialized
INFO - 2016-10-28 13:45:41 --> Model Class Initialized
INFO - 2016-10-28 13:45:41 --> Model Class Initialized
INFO - 2016-10-28 13:45:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:45:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:45:41 --> Total execution time: 0.0853
INFO - 2016-10-28 13:46:11 --> Config Class Initialized
INFO - 2016-10-28 13:46:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:46:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:46:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:46:11 --> URI Class Initialized
INFO - 2016-10-28 13:46:11 --> Router Class Initialized
INFO - 2016-10-28 13:46:11 --> Output Class Initialized
INFO - 2016-10-28 13:46:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:46:11 --> Input Class Initialized
INFO - 2016-10-28 13:46:11 --> Language Class Initialized
INFO - 2016-10-28 13:46:11 --> Loader Class Initialized
INFO - 2016-10-28 13:46:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:46:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:46:11 --> Controller Class Initialized
INFO - 2016-10-28 13:46:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:46:11 --> Model Class Initialized
INFO - 2016-10-28 13:46:11 --> Model Class Initialized
INFO - 2016-10-28 13:46:11 --> Model Class Initialized
INFO - 2016-10-28 13:46:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:46:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:46:11 --> Total execution time: 0.1102
INFO - 2016-10-28 13:46:41 --> Config Class Initialized
INFO - 2016-10-28 13:46:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:46:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:46:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:46:41 --> URI Class Initialized
INFO - 2016-10-28 13:46:41 --> Router Class Initialized
INFO - 2016-10-28 13:46:41 --> Output Class Initialized
INFO - 2016-10-28 13:46:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:46:41 --> Input Class Initialized
INFO - 2016-10-28 13:46:41 --> Language Class Initialized
INFO - 2016-10-28 13:46:41 --> Loader Class Initialized
INFO - 2016-10-28 13:46:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:46:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:46:41 --> Controller Class Initialized
INFO - 2016-10-28 13:46:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:46:41 --> Model Class Initialized
INFO - 2016-10-28 13:46:41 --> Model Class Initialized
INFO - 2016-10-28 13:46:41 --> Model Class Initialized
INFO - 2016-10-28 13:46:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:46:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:46:41 --> Total execution time: 0.1072
INFO - 2016-10-28 13:47:11 --> Config Class Initialized
INFO - 2016-10-28 13:47:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:47:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:47:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:47:11 --> URI Class Initialized
INFO - 2016-10-28 13:47:11 --> Router Class Initialized
INFO - 2016-10-28 13:47:11 --> Output Class Initialized
INFO - 2016-10-28 13:47:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:47:11 --> Input Class Initialized
INFO - 2016-10-28 13:47:11 --> Language Class Initialized
INFO - 2016-10-28 13:47:11 --> Loader Class Initialized
INFO - 2016-10-28 13:47:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:47:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:47:11 --> Controller Class Initialized
INFO - 2016-10-28 13:47:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:47:11 --> Model Class Initialized
INFO - 2016-10-28 13:47:11 --> Model Class Initialized
INFO - 2016-10-28 13:47:11 --> Model Class Initialized
INFO - 2016-10-28 13:47:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:47:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:47:11 --> Total execution time: 0.0906
INFO - 2016-10-28 13:47:41 --> Config Class Initialized
INFO - 2016-10-28 13:47:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:47:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:47:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:47:41 --> URI Class Initialized
INFO - 2016-10-28 13:47:41 --> Router Class Initialized
INFO - 2016-10-28 13:47:41 --> Output Class Initialized
INFO - 2016-10-28 13:47:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:47:41 --> Input Class Initialized
INFO - 2016-10-28 13:47:41 --> Language Class Initialized
INFO - 2016-10-28 13:47:41 --> Loader Class Initialized
INFO - 2016-10-28 13:47:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:47:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:47:41 --> Controller Class Initialized
INFO - 2016-10-28 13:47:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:47:41 --> Model Class Initialized
INFO - 2016-10-28 13:47:41 --> Model Class Initialized
INFO - 2016-10-28 13:47:41 --> Model Class Initialized
INFO - 2016-10-28 13:47:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:47:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:47:41 --> Total execution time: 0.0726
INFO - 2016-10-28 13:48:11 --> Config Class Initialized
INFO - 2016-10-28 13:48:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:48:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:48:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:48:11 --> URI Class Initialized
INFO - 2016-10-28 13:48:11 --> Router Class Initialized
INFO - 2016-10-28 13:48:11 --> Output Class Initialized
INFO - 2016-10-28 13:48:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:48:11 --> Input Class Initialized
INFO - 2016-10-28 13:48:11 --> Language Class Initialized
INFO - 2016-10-28 13:48:11 --> Loader Class Initialized
INFO - 2016-10-28 13:48:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:48:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:48:11 --> Controller Class Initialized
INFO - 2016-10-28 13:48:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:48:11 --> Model Class Initialized
INFO - 2016-10-28 13:48:11 --> Model Class Initialized
INFO - 2016-10-28 13:48:11 --> Model Class Initialized
INFO - 2016-10-28 13:48:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:48:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:48:11 --> Total execution time: 0.0877
INFO - 2016-10-28 13:48:41 --> Config Class Initialized
INFO - 2016-10-28 13:48:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:48:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:48:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:48:41 --> URI Class Initialized
INFO - 2016-10-28 13:48:41 --> Router Class Initialized
INFO - 2016-10-28 13:48:41 --> Output Class Initialized
INFO - 2016-10-28 13:48:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:48:41 --> Input Class Initialized
INFO - 2016-10-28 13:48:41 --> Language Class Initialized
INFO - 2016-10-28 13:48:41 --> Loader Class Initialized
INFO - 2016-10-28 13:48:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:48:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:48:41 --> Controller Class Initialized
INFO - 2016-10-28 13:48:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:48:41 --> Model Class Initialized
INFO - 2016-10-28 13:48:41 --> Model Class Initialized
INFO - 2016-10-28 13:48:41 --> Model Class Initialized
INFO - 2016-10-28 13:48:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:48:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:48:41 --> Total execution time: 0.0975
INFO - 2016-10-28 13:49:11 --> Config Class Initialized
INFO - 2016-10-28 13:49:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:49:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:49:11 --> Utf8 Class Initialized
INFO - 2016-10-28 13:49:11 --> URI Class Initialized
INFO - 2016-10-28 13:49:11 --> Router Class Initialized
INFO - 2016-10-28 13:49:11 --> Output Class Initialized
INFO - 2016-10-28 13:49:11 --> Security Class Initialized
DEBUG - 2016-10-28 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:49:11 --> Input Class Initialized
INFO - 2016-10-28 13:49:11 --> Language Class Initialized
INFO - 2016-10-28 13:49:11 --> Loader Class Initialized
INFO - 2016-10-28 13:49:11 --> Helper loaded: url_helper
INFO - 2016-10-28 13:49:11 --> Helper loaded: language_helper
INFO - 2016-10-28 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:49:11 --> Controller Class Initialized
INFO - 2016-10-28 13:49:11 --> Database Driver Class Initialized
INFO - 2016-10-28 13:49:11 --> Model Class Initialized
INFO - 2016-10-28 13:49:11 --> Model Class Initialized
INFO - 2016-10-28 13:49:11 --> Model Class Initialized
INFO - 2016-10-28 13:49:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:49:11 --> Final output sent to browser
DEBUG - 2016-10-28 13:49:11 --> Total execution time: 0.2660
INFO - 2016-10-28 13:49:41 --> Config Class Initialized
INFO - 2016-10-28 13:49:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:49:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:49:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:49:41 --> URI Class Initialized
INFO - 2016-10-28 13:49:41 --> Router Class Initialized
INFO - 2016-10-28 13:49:41 --> Output Class Initialized
INFO - 2016-10-28 13:49:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:49:41 --> Input Class Initialized
INFO - 2016-10-28 13:49:41 --> Language Class Initialized
INFO - 2016-10-28 13:49:41 --> Loader Class Initialized
INFO - 2016-10-28 13:49:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:49:41 --> Helper loaded: language_helper
INFO - 2016-10-28 13:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:49:41 --> Controller Class Initialized
INFO - 2016-10-28 13:49:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:49:41 --> Model Class Initialized
INFO - 2016-10-28 13:49:41 --> Model Class Initialized
INFO - 2016-10-28 13:49:41 --> Model Class Initialized
INFO - 2016-10-28 13:49:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:49:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:49:41 --> Total execution time: 0.0885
INFO - 2016-10-28 13:50:12 --> Config Class Initialized
INFO - 2016-10-28 13:50:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:50:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:50:12 --> Utf8 Class Initialized
INFO - 2016-10-28 13:50:12 --> URI Class Initialized
INFO - 2016-10-28 13:50:12 --> Router Class Initialized
INFO - 2016-10-28 13:50:12 --> Output Class Initialized
INFO - 2016-10-28 13:50:12 --> Security Class Initialized
DEBUG - 2016-10-28 13:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:50:12 --> Input Class Initialized
INFO - 2016-10-28 13:50:12 --> Language Class Initialized
INFO - 2016-10-28 13:50:12 --> Loader Class Initialized
INFO - 2016-10-28 13:50:12 --> Helper loaded: url_helper
INFO - 2016-10-28 13:50:12 --> Helper loaded: language_helper
INFO - 2016-10-28 13:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:50:12 --> Controller Class Initialized
INFO - 2016-10-28 13:50:12 --> Database Driver Class Initialized
INFO - 2016-10-28 13:50:12 --> Model Class Initialized
INFO - 2016-10-28 13:50:12 --> Model Class Initialized
INFO - 2016-10-28 13:50:12 --> Model Class Initialized
INFO - 2016-10-28 13:50:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:50:12 --> Final output sent to browser
DEBUG - 2016-10-28 13:50:12 --> Total execution time: 0.1208
INFO - 2016-10-28 13:50:42 --> Config Class Initialized
INFO - 2016-10-28 13:50:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:50:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:50:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:50:42 --> URI Class Initialized
INFO - 2016-10-28 13:50:42 --> Router Class Initialized
INFO - 2016-10-28 13:50:42 --> Output Class Initialized
INFO - 2016-10-28 13:50:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:50:42 --> Input Class Initialized
INFO - 2016-10-28 13:50:42 --> Language Class Initialized
INFO - 2016-10-28 13:50:42 --> Loader Class Initialized
INFO - 2016-10-28 13:50:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:50:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:50:42 --> Controller Class Initialized
INFO - 2016-10-28 13:50:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:50:42 --> Model Class Initialized
INFO - 2016-10-28 13:50:42 --> Model Class Initialized
INFO - 2016-10-28 13:50:42 --> Model Class Initialized
INFO - 2016-10-28 13:50:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:50:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:50:42 --> Total execution time: 0.0912
INFO - 2016-10-28 13:51:12 --> Config Class Initialized
INFO - 2016-10-28 13:51:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:51:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:51:12 --> Utf8 Class Initialized
INFO - 2016-10-28 13:51:12 --> URI Class Initialized
INFO - 2016-10-28 13:51:12 --> Router Class Initialized
INFO - 2016-10-28 13:51:12 --> Output Class Initialized
INFO - 2016-10-28 13:51:12 --> Security Class Initialized
DEBUG - 2016-10-28 13:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:51:12 --> Input Class Initialized
INFO - 2016-10-28 13:51:12 --> Language Class Initialized
INFO - 2016-10-28 13:51:12 --> Loader Class Initialized
INFO - 2016-10-28 13:51:12 --> Helper loaded: url_helper
INFO - 2016-10-28 13:51:12 --> Helper loaded: language_helper
INFO - 2016-10-28 13:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:51:12 --> Controller Class Initialized
INFO - 2016-10-28 13:51:12 --> Database Driver Class Initialized
INFO - 2016-10-28 13:51:12 --> Model Class Initialized
INFO - 2016-10-28 13:51:12 --> Model Class Initialized
INFO - 2016-10-28 13:51:12 --> Model Class Initialized
INFO - 2016-10-28 13:51:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:51:12 --> Final output sent to browser
DEBUG - 2016-10-28 13:51:12 --> Total execution time: 0.0677
INFO - 2016-10-28 13:51:42 --> Config Class Initialized
INFO - 2016-10-28 13:51:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:51:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:51:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:51:42 --> URI Class Initialized
INFO - 2016-10-28 13:51:42 --> Router Class Initialized
INFO - 2016-10-28 13:51:42 --> Output Class Initialized
INFO - 2016-10-28 13:51:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:51:42 --> Input Class Initialized
INFO - 2016-10-28 13:51:42 --> Language Class Initialized
INFO - 2016-10-28 13:51:42 --> Loader Class Initialized
INFO - 2016-10-28 13:51:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:51:42 --> Helper loaded: language_helper
INFO - 2016-10-28 13:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:51:42 --> Controller Class Initialized
INFO - 2016-10-28 13:51:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:51:42 --> Model Class Initialized
INFO - 2016-10-28 13:51:42 --> Model Class Initialized
INFO - 2016-10-28 13:51:42 --> Model Class Initialized
INFO - 2016-10-28 13:51:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2016-10-28 13:51:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:51:42 --> Total execution time: 0.0963
