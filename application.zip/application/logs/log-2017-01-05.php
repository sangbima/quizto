<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-05 08:19:12 --> Config Class Initialized
INFO - 2017-01-05 08:19:12 --> Hooks Class Initialized
DEBUG - 2017-01-05 08:19:12 --> UTF-8 Support Enabled
INFO - 2017-01-05 08:19:12 --> Utf8 Class Initialized
INFO - 2017-01-05 08:19:12 --> URI Class Initialized
DEBUG - 2017-01-05 08:19:12 --> No URI present. Default controller set.
INFO - 2017-01-05 08:19:12 --> Router Class Initialized
INFO - 2017-01-05 08:19:12 --> Output Class Initialized
INFO - 2017-01-05 08:19:12 --> Security Class Initialized
DEBUG - 2017-01-05 08:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 08:19:12 --> Input Class Initialized
INFO - 2017-01-05 08:19:12 --> Language Class Initialized
INFO - 2017-01-05 08:19:12 --> Loader Class Initialized
INFO - 2017-01-05 08:19:12 --> Helper loaded: url_helper
INFO - 2017-01-05 08:19:12 --> Helper loaded: language_helper
INFO - 2017-01-05 08:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 08:19:12 --> Controller Class Initialized
INFO - 2017-01-05 08:19:12 --> Database Driver Class Initialized
INFO - 2017-01-05 08:19:12 --> Model Class Initialized
INFO - 2017-01-05 08:19:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-05 08:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-05 08:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-05 08:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-05 08:19:12 --> Final output sent to browser
DEBUG - 2017-01-05 08:19:12 --> Total execution time: 0.1349
INFO - 2017-01-05 08:19:17 --> Config Class Initialized
INFO - 2017-01-05 08:19:17 --> Hooks Class Initialized
DEBUG - 2017-01-05 08:19:17 --> UTF-8 Support Enabled
INFO - 2017-01-05 08:19:17 --> Utf8 Class Initialized
INFO - 2017-01-05 08:19:17 --> URI Class Initialized
INFO - 2017-01-05 08:19:18 --> Router Class Initialized
INFO - 2017-01-05 08:19:18 --> Output Class Initialized
INFO - 2017-01-05 08:19:18 --> Security Class Initialized
DEBUG - 2017-01-05 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 08:19:18 --> Input Class Initialized
INFO - 2017-01-05 08:19:18 --> Language Class Initialized
INFO - 2017-01-05 08:19:18 --> Loader Class Initialized
INFO - 2017-01-05 08:19:18 --> Helper loaded: url_helper
INFO - 2017-01-05 08:19:18 --> Helper loaded: language_helper
INFO - 2017-01-05 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 08:19:18 --> Controller Class Initialized
INFO - 2017-01-05 08:19:18 --> Database Driver Class Initialized
INFO - 2017-01-05 08:19:18 --> Model Class Initialized
INFO - 2017-01-05 08:19:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-05 08:19:18 --> Config Class Initialized
INFO - 2017-01-05 08:19:18 --> Hooks Class Initialized
DEBUG - 2017-01-05 08:19:18 --> UTF-8 Support Enabled
INFO - 2017-01-05 08:19:18 --> Utf8 Class Initialized
INFO - 2017-01-05 08:19:18 --> URI Class Initialized
INFO - 2017-01-05 08:19:18 --> Router Class Initialized
INFO - 2017-01-05 08:19:18 --> Output Class Initialized
INFO - 2017-01-05 08:19:18 --> Security Class Initialized
DEBUG - 2017-01-05 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 08:19:18 --> Input Class Initialized
INFO - 2017-01-05 08:19:18 --> Language Class Initialized
INFO - 2017-01-05 08:19:18 --> Loader Class Initialized
INFO - 2017-01-05 08:19:18 --> Helper loaded: url_helper
INFO - 2017-01-05 08:19:18 --> Helper loaded: language_helper
INFO - 2017-01-05 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 08:19:18 --> Controller Class Initialized
INFO - 2017-01-05 08:19:18 --> Database Driver Class Initialized
INFO - 2017-01-05 08:19:18 --> Model Class Initialized
INFO - 2017-01-05 08:19:18 --> Model Class Initialized
INFO - 2017-01-05 08:19:18 --> Model Class Initialized
INFO - 2017-01-05 08:19:18 --> Model Class Initialized
INFO - 2017-01-05 08:19:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-05 08:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-05 08:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-05 08:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-05 08:19:18 --> Final output sent to browser
DEBUG - 2017-01-05 08:19:18 --> Total execution time: 0.0973
