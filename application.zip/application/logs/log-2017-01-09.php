<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-09 13:43:15 --> Config Class Initialized
INFO - 2017-01-09 13:43:15 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:43:15 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:43:15 --> Utf8 Class Initialized
INFO - 2017-01-09 13:43:15 --> URI Class Initialized
DEBUG - 2017-01-09 13:43:15 --> No URI present. Default controller set.
INFO - 2017-01-09 13:43:15 --> Router Class Initialized
INFO - 2017-01-09 13:43:15 --> Output Class Initialized
INFO - 2017-01-09 13:43:15 --> Security Class Initialized
DEBUG - 2017-01-09 13:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:43:15 --> Input Class Initialized
INFO - 2017-01-09 13:43:15 --> Language Class Initialized
INFO - 2017-01-09 13:43:15 --> Loader Class Initialized
INFO - 2017-01-09 13:43:15 --> Helper loaded: url_helper
INFO - 2017-01-09 13:43:15 --> Helper loaded: language_helper
INFO - 2017-01-09 13:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:43:15 --> Controller Class Initialized
INFO - 2017-01-09 13:43:15 --> Database Driver Class Initialized
INFO - 2017-01-09 13:43:15 --> Model Class Initialized
INFO - 2017-01-09 13:43:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:43:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 13:43:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 13:43:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 13:43:15 --> Final output sent to browser
DEBUG - 2017-01-09 13:43:15 --> Total execution time: 0.0950
INFO - 2017-01-09 13:43:25 --> Config Class Initialized
INFO - 2017-01-09 13:43:25 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:43:25 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:43:25 --> Utf8 Class Initialized
INFO - 2017-01-09 13:43:25 --> URI Class Initialized
DEBUG - 2017-01-09 13:43:25 --> No URI present. Default controller set.
INFO - 2017-01-09 13:43:25 --> Router Class Initialized
INFO - 2017-01-09 13:43:25 --> Output Class Initialized
INFO - 2017-01-09 13:43:25 --> Security Class Initialized
DEBUG - 2017-01-09 13:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:43:25 --> Input Class Initialized
INFO - 2017-01-09 13:43:25 --> Language Class Initialized
INFO - 2017-01-09 13:43:25 --> Loader Class Initialized
INFO - 2017-01-09 13:43:25 --> Helper loaded: url_helper
INFO - 2017-01-09 13:43:25 --> Helper loaded: language_helper
INFO - 2017-01-09 13:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:43:25 --> Controller Class Initialized
INFO - 2017-01-09 13:43:25 --> Database Driver Class Initialized
INFO - 2017-01-09 13:43:25 --> Model Class Initialized
INFO - 2017-01-09 13:43:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:43:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 13:43:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 13:43:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 13:43:25 --> Final output sent to browser
DEBUG - 2017-01-09 13:43:25 --> Total execution time: 0.0659
INFO - 2017-01-09 13:46:50 --> Config Class Initialized
INFO - 2017-01-09 13:46:50 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:46:50 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:46:50 --> Utf8 Class Initialized
INFO - 2017-01-09 13:46:50 --> URI Class Initialized
INFO - 2017-01-09 13:46:50 --> Router Class Initialized
INFO - 2017-01-09 13:46:50 --> Output Class Initialized
INFO - 2017-01-09 13:46:50 --> Security Class Initialized
DEBUG - 2017-01-09 13:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:46:50 --> Input Class Initialized
INFO - 2017-01-09 13:46:50 --> Language Class Initialized
INFO - 2017-01-09 13:46:50 --> Loader Class Initialized
INFO - 2017-01-09 13:46:50 --> Helper loaded: url_helper
INFO - 2017-01-09 13:46:50 --> Helper loaded: language_helper
INFO - 2017-01-09 13:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:46:50 --> Controller Class Initialized
INFO - 2017-01-09 13:46:50 --> Database Driver Class Initialized
INFO - 2017-01-09 13:46:50 --> Model Class Initialized
INFO - 2017-01-09 13:46:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:46:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:46:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register.php
INFO - 2017-01-09 13:46:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:46:50 --> Final output sent to browser
DEBUG - 2017-01-09 13:46:50 --> Total execution time: 0.0908
INFO - 2017-01-09 13:48:18 --> Config Class Initialized
INFO - 2017-01-09 13:48:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:48:18 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:48:18 --> Utf8 Class Initialized
INFO - 2017-01-09 13:48:18 --> URI Class Initialized
DEBUG - 2017-01-09 13:48:18 --> No URI present. Default controller set.
INFO - 2017-01-09 13:48:18 --> Router Class Initialized
INFO - 2017-01-09 13:48:18 --> Output Class Initialized
INFO - 2017-01-09 13:48:18 --> Security Class Initialized
DEBUG - 2017-01-09 13:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:48:18 --> Input Class Initialized
INFO - 2017-01-09 13:48:18 --> Language Class Initialized
INFO - 2017-01-09 13:48:18 --> Loader Class Initialized
INFO - 2017-01-09 13:48:18 --> Helper loaded: url_helper
INFO - 2017-01-09 13:48:18 --> Helper loaded: language_helper
INFO - 2017-01-09 13:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:48:18 --> Controller Class Initialized
INFO - 2017-01-09 13:48:18 --> Database Driver Class Initialized
INFO - 2017-01-09 13:48:18 --> Model Class Initialized
INFO - 2017-01-09 13:48:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:48:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 13:48:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 13:48:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 13:48:18 --> Final output sent to browser
DEBUG - 2017-01-09 13:48:18 --> Total execution time: 0.0650
INFO - 2017-01-09 13:49:11 --> Config Class Initialized
INFO - 2017-01-09 13:49:11 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:49:11 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:49:11 --> Utf8 Class Initialized
INFO - 2017-01-09 13:49:11 --> URI Class Initialized
INFO - 2017-01-09 13:49:11 --> Router Class Initialized
INFO - 2017-01-09 13:49:11 --> Output Class Initialized
INFO - 2017-01-09 13:49:11 --> Security Class Initialized
DEBUG - 2017-01-09 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:49:11 --> Input Class Initialized
INFO - 2017-01-09 13:49:11 --> Language Class Initialized
INFO - 2017-01-09 13:49:11 --> Loader Class Initialized
INFO - 2017-01-09 13:49:11 --> Helper loaded: url_helper
INFO - 2017-01-09 13:49:11 --> Helper loaded: language_helper
INFO - 2017-01-09 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:49:11 --> Controller Class Initialized
INFO - 2017-01-09 13:49:11 --> Database Driver Class Initialized
INFO - 2017-01-09 13:49:11 --> Model Class Initialized
INFO - 2017-01-09 13:49:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:49:11 --> Config Class Initialized
INFO - 2017-01-09 13:49:11 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:49:11 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:49:11 --> Utf8 Class Initialized
INFO - 2017-01-09 13:49:11 --> URI Class Initialized
INFO - 2017-01-09 13:49:11 --> Router Class Initialized
INFO - 2017-01-09 13:49:11 --> Output Class Initialized
INFO - 2017-01-09 13:49:11 --> Security Class Initialized
DEBUG - 2017-01-09 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:49:11 --> Input Class Initialized
INFO - 2017-01-09 13:49:11 --> Language Class Initialized
INFO - 2017-01-09 13:49:11 --> Loader Class Initialized
INFO - 2017-01-09 13:49:11 --> Helper loaded: url_helper
INFO - 2017-01-09 13:49:11 --> Helper loaded: language_helper
INFO - 2017-01-09 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:49:11 --> Controller Class Initialized
INFO - 2017-01-09 13:49:11 --> Database Driver Class Initialized
INFO - 2017-01-09 13:49:11 --> Model Class Initialized
INFO - 2017-01-09 13:49:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:49:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 13:49:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 13:49:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 13:49:11 --> Final output sent to browser
DEBUG - 2017-01-09 13:49:11 --> Total execution time: 0.0546
INFO - 2017-01-09 13:49:19 --> Config Class Initialized
INFO - 2017-01-09 13:49:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:49:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:49:19 --> Utf8 Class Initialized
INFO - 2017-01-09 13:49:19 --> URI Class Initialized
INFO - 2017-01-09 13:49:19 --> Router Class Initialized
INFO - 2017-01-09 13:49:19 --> Output Class Initialized
INFO - 2017-01-09 13:49:19 --> Security Class Initialized
DEBUG - 2017-01-09 13:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:49:19 --> Input Class Initialized
INFO - 2017-01-09 13:49:19 --> Language Class Initialized
INFO - 2017-01-09 13:49:19 --> Loader Class Initialized
INFO - 2017-01-09 13:49:19 --> Helper loaded: url_helper
INFO - 2017-01-09 13:49:19 --> Helper loaded: language_helper
INFO - 2017-01-09 13:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:49:19 --> Controller Class Initialized
INFO - 2017-01-09 13:49:19 --> Database Driver Class Initialized
INFO - 2017-01-09 13:49:19 --> Model Class Initialized
INFO - 2017-01-09 13:49:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:49:19 --> Config Class Initialized
INFO - 2017-01-09 13:49:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:49:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:49:19 --> Utf8 Class Initialized
INFO - 2017-01-09 13:49:19 --> URI Class Initialized
INFO - 2017-01-09 13:49:19 --> Router Class Initialized
INFO - 2017-01-09 13:49:19 --> Output Class Initialized
INFO - 2017-01-09 13:49:19 --> Security Class Initialized
DEBUG - 2017-01-09 13:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:49:19 --> Input Class Initialized
INFO - 2017-01-09 13:49:19 --> Language Class Initialized
INFO - 2017-01-09 13:49:19 --> Loader Class Initialized
INFO - 2017-01-09 13:49:19 --> Helper loaded: url_helper
INFO - 2017-01-09 13:49:19 --> Helper loaded: language_helper
INFO - 2017-01-09 13:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:49:19 --> Controller Class Initialized
INFO - 2017-01-09 13:49:19 --> Database Driver Class Initialized
INFO - 2017-01-09 13:49:19 --> Model Class Initialized
INFO - 2017-01-09 13:49:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:49:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 13:49:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 13:49:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 13:49:19 --> Final output sent to browser
DEBUG - 2017-01-09 13:49:19 --> Total execution time: 0.0551
INFO - 2017-01-09 13:49:34 --> Config Class Initialized
INFO - 2017-01-09 13:49:34 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:49:34 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:49:34 --> Utf8 Class Initialized
INFO - 2017-01-09 13:49:34 --> URI Class Initialized
INFO - 2017-01-09 13:49:34 --> Router Class Initialized
INFO - 2017-01-09 13:49:34 --> Output Class Initialized
INFO - 2017-01-09 13:49:34 --> Security Class Initialized
DEBUG - 2017-01-09 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:49:34 --> Input Class Initialized
INFO - 2017-01-09 13:49:34 --> Language Class Initialized
INFO - 2017-01-09 13:49:34 --> Loader Class Initialized
INFO - 2017-01-09 13:49:34 --> Helper loaded: url_helper
INFO - 2017-01-09 13:49:34 --> Helper loaded: language_helper
INFO - 2017-01-09 13:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:49:34 --> Controller Class Initialized
INFO - 2017-01-09 13:49:34 --> Database Driver Class Initialized
INFO - 2017-01-09 13:49:34 --> Model Class Initialized
INFO - 2017-01-09 13:49:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:49:34 --> Config Class Initialized
INFO - 2017-01-09 13:49:34 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:49:34 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:49:34 --> Utf8 Class Initialized
INFO - 2017-01-09 13:49:34 --> URI Class Initialized
INFO - 2017-01-09 13:49:34 --> Router Class Initialized
INFO - 2017-01-09 13:49:34 --> Output Class Initialized
INFO - 2017-01-09 13:49:34 --> Security Class Initialized
DEBUG - 2017-01-09 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:49:34 --> Input Class Initialized
INFO - 2017-01-09 13:49:34 --> Language Class Initialized
INFO - 2017-01-09 13:49:34 --> Loader Class Initialized
INFO - 2017-01-09 13:49:34 --> Helper loaded: url_helper
INFO - 2017-01-09 13:49:34 --> Helper loaded: language_helper
INFO - 2017-01-09 13:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:49:34 --> Controller Class Initialized
INFO - 2017-01-09 13:49:34 --> Database Driver Class Initialized
INFO - 2017-01-09 13:49:34 --> Model Class Initialized
INFO - 2017-01-09 13:49:34 --> Model Class Initialized
INFO - 2017-01-09 13:49:34 --> Model Class Initialized
INFO - 2017-01-09 13:49:34 --> Model Class Initialized
INFO - 2017-01-09 13:49:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:49:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:49:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 13:49:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:49:34 --> Final output sent to browser
DEBUG - 2017-01-09 13:49:34 --> Total execution time: 0.0814
INFO - 2017-01-09 13:50:06 --> Config Class Initialized
INFO - 2017-01-09 13:50:06 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:50:06 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:50:06 --> Utf8 Class Initialized
INFO - 2017-01-09 13:50:06 --> URI Class Initialized
INFO - 2017-01-09 13:50:06 --> Router Class Initialized
INFO - 2017-01-09 13:50:06 --> Output Class Initialized
INFO - 2017-01-09 13:50:06 --> Security Class Initialized
DEBUG - 2017-01-09 13:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:50:06 --> Input Class Initialized
INFO - 2017-01-09 13:50:06 --> Language Class Initialized
INFO - 2017-01-09 13:50:06 --> Loader Class Initialized
INFO - 2017-01-09 13:50:06 --> Helper loaded: url_helper
INFO - 2017-01-09 13:50:06 --> Helper loaded: language_helper
INFO - 2017-01-09 13:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:50:06 --> Controller Class Initialized
INFO - 2017-01-09 13:50:06 --> Database Driver Class Initialized
INFO - 2017-01-09 13:50:06 --> Model Class Initialized
INFO - 2017-01-09 13:50:06 --> Model Class Initialized
INFO - 2017-01-09 13:50:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:50:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:50:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-09 13:50:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:50:06 --> Final output sent to browser
DEBUG - 2017-01-09 13:50:06 --> Total execution time: 0.0659
INFO - 2017-01-09 13:50:47 --> Config Class Initialized
INFO - 2017-01-09 13:50:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:50:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:50:47 --> Utf8 Class Initialized
INFO - 2017-01-09 13:50:47 --> URI Class Initialized
INFO - 2017-01-09 13:50:47 --> Router Class Initialized
INFO - 2017-01-09 13:50:47 --> Output Class Initialized
INFO - 2017-01-09 13:50:47 --> Security Class Initialized
DEBUG - 2017-01-09 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:50:47 --> Input Class Initialized
INFO - 2017-01-09 13:50:47 --> Language Class Initialized
INFO - 2017-01-09 13:50:47 --> Loader Class Initialized
INFO - 2017-01-09 13:50:47 --> Helper loaded: url_helper
INFO - 2017-01-09 13:50:47 --> Helper loaded: language_helper
INFO - 2017-01-09 13:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:50:47 --> Controller Class Initialized
INFO - 2017-01-09 13:50:47 --> Database Driver Class Initialized
INFO - 2017-01-09 13:50:47 --> Model Class Initialized
INFO - 2017-01-09 13:50:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:50:47 --> Helper loaded: form_helper
INFO - 2017-01-09 13:50:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:50:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-09 13:50:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:50:47 --> Final output sent to browser
DEBUG - 2017-01-09 13:50:47 --> Total execution time: 0.1068
INFO - 2017-01-09 13:50:54 --> Config Class Initialized
INFO - 2017-01-09 13:50:54 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:50:54 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:50:54 --> Utf8 Class Initialized
INFO - 2017-01-09 13:50:54 --> URI Class Initialized
INFO - 2017-01-09 13:50:54 --> Router Class Initialized
INFO - 2017-01-09 13:50:54 --> Output Class Initialized
INFO - 2017-01-09 13:50:54 --> Security Class Initialized
DEBUG - 2017-01-09 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:50:54 --> Input Class Initialized
INFO - 2017-01-09 13:50:54 --> Language Class Initialized
INFO - 2017-01-09 13:50:54 --> Loader Class Initialized
INFO - 2017-01-09 13:50:54 --> Helper loaded: url_helper
INFO - 2017-01-09 13:50:54 --> Helper loaded: language_helper
INFO - 2017-01-09 13:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:50:54 --> Controller Class Initialized
INFO - 2017-01-09 13:50:54 --> Database Driver Class Initialized
INFO - 2017-01-09 13:50:54 --> Model Class Initialized
INFO - 2017-01-09 13:50:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:50:54 --> Model Class Initialized
INFO - 2017-01-09 13:50:54 --> Model Class Initialized
INFO - 2017-01-09 13:50:54 --> Helper loaded: form_helper
INFO - 2017-01-09 13:50:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:50:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-09 13:50:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:50:54 --> Final output sent to browser
DEBUG - 2017-01-09 13:50:54 --> Total execution time: 0.1198
INFO - 2017-01-09 13:51:01 --> Config Class Initialized
INFO - 2017-01-09 13:51:01 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:51:01 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:51:01 --> Utf8 Class Initialized
INFO - 2017-01-09 13:51:01 --> URI Class Initialized
INFO - 2017-01-09 13:51:01 --> Router Class Initialized
INFO - 2017-01-09 13:51:01 --> Output Class Initialized
INFO - 2017-01-09 13:51:01 --> Security Class Initialized
DEBUG - 2017-01-09 13:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:51:01 --> Input Class Initialized
INFO - 2017-01-09 13:51:01 --> Language Class Initialized
INFO - 2017-01-09 13:51:01 --> Loader Class Initialized
INFO - 2017-01-09 13:51:01 --> Helper loaded: url_helper
INFO - 2017-01-09 13:51:01 --> Helper loaded: language_helper
INFO - 2017-01-09 13:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:51:01 --> Controller Class Initialized
INFO - 2017-01-09 13:51:01 --> Database Driver Class Initialized
INFO - 2017-01-09 13:51:01 --> Model Class Initialized
INFO - 2017-01-09 13:51:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:51:01 --> Helper loaded: form_helper
INFO - 2017-01-09 13:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-09 13:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:51:01 --> Final output sent to browser
DEBUG - 2017-01-09 13:51:01 --> Total execution time: 0.0798
INFO - 2017-01-09 13:51:21 --> Config Class Initialized
INFO - 2017-01-09 13:51:21 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:51:21 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:51:21 --> Utf8 Class Initialized
INFO - 2017-01-09 13:51:21 --> URI Class Initialized
INFO - 2017-01-09 13:51:21 --> Router Class Initialized
INFO - 2017-01-09 13:51:21 --> Output Class Initialized
INFO - 2017-01-09 13:51:21 --> Security Class Initialized
DEBUG - 2017-01-09 13:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:51:21 --> Input Class Initialized
INFO - 2017-01-09 13:51:22 --> Language Class Initialized
INFO - 2017-01-09 13:51:22 --> Loader Class Initialized
INFO - 2017-01-09 13:51:22 --> Helper loaded: url_helper
INFO - 2017-01-09 13:51:22 --> Helper loaded: language_helper
INFO - 2017-01-09 13:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:51:22 --> Controller Class Initialized
INFO - 2017-01-09 13:51:22 --> Database Driver Class Initialized
INFO - 2017-01-09 13:51:22 --> Model Class Initialized
INFO - 2017-01-09 13:51:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:51:22 --> Helper loaded: form_helper
INFO - 2017-01-09 13:51:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:51:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-09 13:51:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:51:22 --> Final output sent to browser
DEBUG - 2017-01-09 13:51:22 --> Total execution time: 0.0859
INFO - 2017-01-09 13:51:35 --> Config Class Initialized
INFO - 2017-01-09 13:51:35 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:51:35 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:51:35 --> Utf8 Class Initialized
INFO - 2017-01-09 13:51:35 --> URI Class Initialized
INFO - 2017-01-09 13:51:35 --> Router Class Initialized
INFO - 2017-01-09 13:51:35 --> Output Class Initialized
INFO - 2017-01-09 13:51:35 --> Security Class Initialized
DEBUG - 2017-01-09 13:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:51:35 --> Input Class Initialized
INFO - 2017-01-09 13:51:35 --> Language Class Initialized
INFO - 2017-01-09 13:51:35 --> Loader Class Initialized
INFO - 2017-01-09 13:51:35 --> Helper loaded: url_helper
INFO - 2017-01-09 13:51:35 --> Helper loaded: language_helper
INFO - 2017-01-09 13:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:51:35 --> Controller Class Initialized
INFO - 2017-01-09 13:51:35 --> Database Driver Class Initialized
INFO - 2017-01-09 13:51:35 --> Model Class Initialized
INFO - 2017-01-09 13:51:35 --> Model Class Initialized
INFO - 2017-01-09 13:51:35 --> Model Class Initialized
INFO - 2017-01-09 13:51:35 --> Model Class Initialized
INFO - 2017-01-09 13:51:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 13:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:51:35 --> Final output sent to browser
DEBUG - 2017-01-09 13:51:35 --> Total execution time: 0.0763
INFO - 2017-01-09 13:51:46 --> Config Class Initialized
INFO - 2017-01-09 13:51:46 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:51:46 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:51:46 --> Utf8 Class Initialized
INFO - 2017-01-09 13:51:46 --> URI Class Initialized
INFO - 2017-01-09 13:51:46 --> Router Class Initialized
INFO - 2017-01-09 13:51:46 --> Output Class Initialized
INFO - 2017-01-09 13:51:46 --> Security Class Initialized
DEBUG - 2017-01-09 13:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:51:46 --> Input Class Initialized
INFO - 2017-01-09 13:51:46 --> Language Class Initialized
INFO - 2017-01-09 13:51:46 --> Loader Class Initialized
INFO - 2017-01-09 13:51:46 --> Helper loaded: url_helper
INFO - 2017-01-09 13:51:46 --> Helper loaded: language_helper
INFO - 2017-01-09 13:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:51:46 --> Controller Class Initialized
INFO - 2017-01-09 13:51:46 --> Database Driver Class Initialized
INFO - 2017-01-09 13:51:46 --> Model Class Initialized
INFO - 2017-01-09 13:51:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:51:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:51:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 13:51:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:51:46 --> Final output sent to browser
DEBUG - 2017-01-09 13:51:46 --> Total execution time: 0.0641
INFO - 2017-01-09 13:52:35 --> Config Class Initialized
INFO - 2017-01-09 13:52:35 --> Hooks Class Initialized
DEBUG - 2017-01-09 13:52:35 --> UTF-8 Support Enabled
INFO - 2017-01-09 13:52:35 --> Utf8 Class Initialized
INFO - 2017-01-09 13:52:35 --> URI Class Initialized
INFO - 2017-01-09 13:52:35 --> Router Class Initialized
INFO - 2017-01-09 13:52:35 --> Output Class Initialized
INFO - 2017-01-09 13:52:35 --> Security Class Initialized
DEBUG - 2017-01-09 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 13:52:35 --> Input Class Initialized
INFO - 2017-01-09 13:52:35 --> Language Class Initialized
INFO - 2017-01-09 13:52:35 --> Loader Class Initialized
INFO - 2017-01-09 13:52:35 --> Helper loaded: url_helper
INFO - 2017-01-09 13:52:35 --> Helper loaded: language_helper
INFO - 2017-01-09 13:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 13:52:35 --> Controller Class Initialized
INFO - 2017-01-09 13:52:35 --> Database Driver Class Initialized
INFO - 2017-01-09 13:52:35 --> Model Class Initialized
INFO - 2017-01-09 13:52:35 --> Model Class Initialized
INFO - 2017-01-09 13:52:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 13:52:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 13:52:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-09 13:52:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 13:52:35 --> Final output sent to browser
DEBUG - 2017-01-09 13:52:35 --> Total execution time: 0.0700
INFO - 2017-01-09 14:08:49 --> Config Class Initialized
INFO - 2017-01-09 14:08:49 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:08:49 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:08:49 --> Utf8 Class Initialized
INFO - 2017-01-09 14:08:49 --> URI Class Initialized
INFO - 2017-01-09 14:08:49 --> Router Class Initialized
INFO - 2017-01-09 14:08:49 --> Output Class Initialized
INFO - 2017-01-09 14:08:49 --> Security Class Initialized
DEBUG - 2017-01-09 14:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:08:49 --> Input Class Initialized
INFO - 2017-01-09 14:08:49 --> Language Class Initialized
INFO - 2017-01-09 14:08:49 --> Loader Class Initialized
INFO - 2017-01-09 14:08:49 --> Helper loaded: url_helper
INFO - 2017-01-09 14:08:49 --> Helper loaded: language_helper
INFO - 2017-01-09 14:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:08:49 --> Controller Class Initialized
INFO - 2017-01-09 14:08:49 --> Database Driver Class Initialized
INFO - 2017-01-09 14:08:49 --> Model Class Initialized
INFO - 2017-01-09 14:08:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:08:49 --> Helper loaded: form_helper
INFO - 2017-01-09 14:08:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:08:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-09 14:08:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:08:49 --> Final output sent to browser
DEBUG - 2017-01-09 14:08:49 --> Total execution time: 0.0788
INFO - 2017-01-09 14:09:32 --> Config Class Initialized
INFO - 2017-01-09 14:09:32 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:09:32 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:09:32 --> Utf8 Class Initialized
INFO - 2017-01-09 14:09:32 --> URI Class Initialized
INFO - 2017-01-09 14:09:32 --> Router Class Initialized
INFO - 2017-01-09 14:09:32 --> Output Class Initialized
INFO - 2017-01-09 14:09:32 --> Security Class Initialized
DEBUG - 2017-01-09 14:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:09:32 --> Input Class Initialized
INFO - 2017-01-09 14:09:32 --> Language Class Initialized
INFO - 2017-01-09 14:09:32 --> Loader Class Initialized
INFO - 2017-01-09 14:09:32 --> Helper loaded: url_helper
INFO - 2017-01-09 14:09:32 --> Helper loaded: language_helper
INFO - 2017-01-09 14:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:09:32 --> Controller Class Initialized
INFO - 2017-01-09 14:09:32 --> Database Driver Class Initialized
INFO - 2017-01-09 14:09:32 --> Model Class Initialized
INFO - 2017-01-09 14:09:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:09:32 --> Model Class Initialized
INFO - 2017-01-09 14:09:32 --> Model Class Initialized
INFO - 2017-01-09 14:09:32 --> Helper loaded: form_helper
INFO - 2017-01-09 14:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-09 14:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:09:32 --> Final output sent to browser
DEBUG - 2017-01-09 14:09:32 --> Total execution time: 0.0984
INFO - 2017-01-09 14:29:09 --> Config Class Initialized
INFO - 2017-01-09 14:29:09 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:29:09 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:29:09 --> Utf8 Class Initialized
INFO - 2017-01-09 14:29:09 --> URI Class Initialized
INFO - 2017-01-09 14:29:09 --> Router Class Initialized
INFO - 2017-01-09 14:29:09 --> Output Class Initialized
INFO - 2017-01-09 14:29:09 --> Security Class Initialized
DEBUG - 2017-01-09 14:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:29:09 --> Input Class Initialized
INFO - 2017-01-09 14:29:09 --> Language Class Initialized
INFO - 2017-01-09 14:29:09 --> Loader Class Initialized
INFO - 2017-01-09 14:29:09 --> Helper loaded: url_helper
INFO - 2017-01-09 14:29:09 --> Helper loaded: language_helper
INFO - 2017-01-09 14:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:29:09 --> Controller Class Initialized
INFO - 2017-01-09 14:29:09 --> Database Driver Class Initialized
INFO - 2017-01-09 14:29:09 --> Model Class Initialized
INFO - 2017-01-09 14:29:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:29:09 --> Helper loaded: form_helper
INFO - 2017-01-09 14:29:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:29:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-09 14:29:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:29:09 --> Final output sent to browser
DEBUG - 2017-01-09 14:29:09 --> Total execution time: 0.0722
INFO - 2017-01-09 14:29:11 --> Config Class Initialized
INFO - 2017-01-09 14:29:11 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:29:11 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:29:11 --> Utf8 Class Initialized
INFO - 2017-01-09 14:29:11 --> URI Class Initialized
INFO - 2017-01-09 14:29:11 --> Router Class Initialized
INFO - 2017-01-09 14:29:11 --> Output Class Initialized
INFO - 2017-01-09 14:29:11 --> Security Class Initialized
DEBUG - 2017-01-09 14:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:29:11 --> Input Class Initialized
INFO - 2017-01-09 14:29:11 --> Language Class Initialized
INFO - 2017-01-09 14:29:11 --> Loader Class Initialized
INFO - 2017-01-09 14:29:11 --> Helper loaded: url_helper
INFO - 2017-01-09 14:29:11 --> Helper loaded: language_helper
INFO - 2017-01-09 14:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:29:11 --> Controller Class Initialized
INFO - 2017-01-09 14:29:11 --> Database Driver Class Initialized
INFO - 2017-01-09 14:29:11 --> Model Class Initialized
INFO - 2017-01-09 14:29:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:29:11 --> Model Class Initialized
INFO - 2017-01-09 14:29:11 --> Model Class Initialized
INFO - 2017-01-09 14:29:11 --> Helper loaded: form_helper
INFO - 2017-01-09 14:29:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:29:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-09 14:29:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:29:11 --> Final output sent to browser
DEBUG - 2017-01-09 14:29:11 --> Total execution time: 0.1037
INFO - 2017-01-09 14:31:46 --> Config Class Initialized
INFO - 2017-01-09 14:31:46 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:31:46 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:31:46 --> Utf8 Class Initialized
INFO - 2017-01-09 14:31:46 --> URI Class Initialized
INFO - 2017-01-09 14:31:46 --> Router Class Initialized
INFO - 2017-01-09 14:31:46 --> Output Class Initialized
INFO - 2017-01-09 14:31:46 --> Security Class Initialized
DEBUG - 2017-01-09 14:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:31:46 --> Input Class Initialized
INFO - 2017-01-09 14:31:46 --> Language Class Initialized
INFO - 2017-01-09 14:31:46 --> Loader Class Initialized
INFO - 2017-01-09 14:31:46 --> Helper loaded: url_helper
INFO - 2017-01-09 14:31:46 --> Helper loaded: language_helper
INFO - 2017-01-09 14:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:31:46 --> Controller Class Initialized
INFO - 2017-01-09 14:31:46 --> Database Driver Class Initialized
INFO - 2017-01-09 14:31:46 --> Model Class Initialized
INFO - 2017-01-09 14:31:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:31:46 --> Model Class Initialized
INFO - 2017-01-09 14:31:46 --> Model Class Initialized
INFO - 2017-01-09 14:31:46 --> Helper loaded: form_helper
INFO - 2017-01-09 14:31:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-09 14:31:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `score_iq`.`max_ws` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `score_iq`
WHERE `score_iq`.`min_ws` < `IS` `NULL`
AND `score_iq`.`max_ws` > `IS` `NULL`
INFO - 2017-01-09 14:31:46 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-09 14:31:51 --> Config Class Initialized
INFO - 2017-01-09 14:31:51 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:31:51 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:31:51 --> Utf8 Class Initialized
INFO - 2017-01-09 14:31:51 --> URI Class Initialized
INFO - 2017-01-09 14:31:51 --> Router Class Initialized
INFO - 2017-01-09 14:31:51 --> Output Class Initialized
INFO - 2017-01-09 14:31:51 --> Security Class Initialized
DEBUG - 2017-01-09 14:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:31:51 --> Input Class Initialized
INFO - 2017-01-09 14:31:51 --> Language Class Initialized
INFO - 2017-01-09 14:31:51 --> Loader Class Initialized
INFO - 2017-01-09 14:31:51 --> Helper loaded: url_helper
INFO - 2017-01-09 14:31:51 --> Helper loaded: language_helper
INFO - 2017-01-09 14:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:31:51 --> Controller Class Initialized
INFO - 2017-01-09 14:31:51 --> Database Driver Class Initialized
INFO - 2017-01-09 14:31:51 --> Model Class Initialized
INFO - 2017-01-09 14:31:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:31:51 --> Model Class Initialized
INFO - 2017-01-09 14:31:51 --> Model Class Initialized
INFO - 2017-01-09 14:31:51 --> Helper loaded: form_helper
INFO - 2017-01-09 14:31:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-09 14:31:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `score_iq`.`max_ws` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `score_iq`
WHERE `score_iq`.`min_ws` < `IS` `NULL`
AND `score_iq`.`max_ws` > `IS` `NULL`
INFO - 2017-01-09 14:31:52 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-09 14:31:55 --> Config Class Initialized
INFO - 2017-01-09 14:31:55 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:31:55 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:31:55 --> Utf8 Class Initialized
INFO - 2017-01-09 14:31:55 --> URI Class Initialized
INFO - 2017-01-09 14:31:55 --> Router Class Initialized
INFO - 2017-01-09 14:31:55 --> Output Class Initialized
INFO - 2017-01-09 14:31:55 --> Security Class Initialized
DEBUG - 2017-01-09 14:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:31:55 --> Input Class Initialized
INFO - 2017-01-09 14:31:55 --> Language Class Initialized
INFO - 2017-01-09 14:31:55 --> Loader Class Initialized
INFO - 2017-01-09 14:31:55 --> Helper loaded: url_helper
INFO - 2017-01-09 14:31:55 --> Helper loaded: language_helper
INFO - 2017-01-09 14:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:31:55 --> Controller Class Initialized
INFO - 2017-01-09 14:31:55 --> Database Driver Class Initialized
INFO - 2017-01-09 14:31:55 --> Model Class Initialized
INFO - 2017-01-09 14:31:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:31:55 --> Model Class Initialized
INFO - 2017-01-09 14:31:55 --> Model Class Initialized
INFO - 2017-01-09 14:31:55 --> Helper loaded: form_helper
INFO - 2017-01-09 14:31:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:31:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-09 14:31:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:31:55 --> Final output sent to browser
DEBUG - 2017-01-09 14:31:55 --> Total execution time: 0.0968
INFO - 2017-01-09 14:49:00 --> Config Class Initialized
INFO - 2017-01-09 14:49:00 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:49:00 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:49:00 --> Utf8 Class Initialized
INFO - 2017-01-09 14:49:00 --> URI Class Initialized
INFO - 2017-01-09 14:49:00 --> Router Class Initialized
INFO - 2017-01-09 14:49:00 --> Output Class Initialized
INFO - 2017-01-09 14:49:00 --> Security Class Initialized
DEBUG - 2017-01-09 14:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:49:00 --> Input Class Initialized
INFO - 2017-01-09 14:49:00 --> Language Class Initialized
INFO - 2017-01-09 14:49:00 --> Loader Class Initialized
INFO - 2017-01-09 14:49:00 --> Helper loaded: url_helper
INFO - 2017-01-09 14:49:00 --> Helper loaded: language_helper
INFO - 2017-01-09 14:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:49:00 --> Controller Class Initialized
INFO - 2017-01-09 14:49:00 --> Database Driver Class Initialized
INFO - 2017-01-09 14:49:00 --> Model Class Initialized
INFO - 2017-01-09 14:49:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:49:00 --> Helper loaded: form_helper
INFO - 2017-01-09 14:49:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:49:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 14:49:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:49:00 --> Final output sent to browser
DEBUG - 2017-01-09 14:49:00 --> Total execution time: 0.0724
INFO - 2017-01-09 14:57:14 --> Config Class Initialized
INFO - 2017-01-09 14:57:14 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:57:14 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:57:14 --> Utf8 Class Initialized
INFO - 2017-01-09 14:57:14 --> URI Class Initialized
INFO - 2017-01-09 14:57:14 --> Router Class Initialized
INFO - 2017-01-09 14:57:14 --> Output Class Initialized
INFO - 2017-01-09 14:57:14 --> Security Class Initialized
DEBUG - 2017-01-09 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:57:14 --> Input Class Initialized
INFO - 2017-01-09 14:57:14 --> Language Class Initialized
INFO - 2017-01-09 14:57:14 --> Loader Class Initialized
INFO - 2017-01-09 14:57:14 --> Helper loaded: url_helper
INFO - 2017-01-09 14:57:14 --> Helper loaded: language_helper
INFO - 2017-01-09 14:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:57:14 --> Controller Class Initialized
INFO - 2017-01-09 14:57:14 --> Database Driver Class Initialized
INFO - 2017-01-09 14:57:14 --> Model Class Initialized
INFO - 2017-01-09 14:57:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:57:14 --> Helper loaded: form_helper
ERROR - 2017-01-09 14:57:14 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\wamp64\www\savsoftquiz\application\views\header.php 143
INFO - 2017-01-09 14:58:22 --> Config Class Initialized
INFO - 2017-01-09 14:58:22 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:58:22 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:58:22 --> Utf8 Class Initialized
INFO - 2017-01-09 14:58:22 --> URI Class Initialized
INFO - 2017-01-09 14:58:22 --> Router Class Initialized
INFO - 2017-01-09 14:58:22 --> Output Class Initialized
INFO - 2017-01-09 14:58:22 --> Security Class Initialized
DEBUG - 2017-01-09 14:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:58:22 --> Input Class Initialized
INFO - 2017-01-09 14:58:22 --> Language Class Initialized
INFO - 2017-01-09 14:58:22 --> Loader Class Initialized
INFO - 2017-01-09 14:58:22 --> Helper loaded: url_helper
INFO - 2017-01-09 14:58:22 --> Helper loaded: language_helper
INFO - 2017-01-09 14:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:58:22 --> Controller Class Initialized
INFO - 2017-01-09 14:58:22 --> Database Driver Class Initialized
INFO - 2017-01-09 14:58:22 --> Model Class Initialized
INFO - 2017-01-09 14:58:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:58:22 --> Helper loaded: form_helper
INFO - 2017-01-09 14:58:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:58:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 14:58:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:58:22 --> Final output sent to browser
DEBUG - 2017-01-09 14:58:22 --> Total execution time: 0.0742
INFO - 2017-01-09 14:59:21 --> Config Class Initialized
INFO - 2017-01-09 14:59:21 --> Hooks Class Initialized
DEBUG - 2017-01-09 14:59:21 --> UTF-8 Support Enabled
INFO - 2017-01-09 14:59:21 --> Utf8 Class Initialized
INFO - 2017-01-09 14:59:21 --> URI Class Initialized
INFO - 2017-01-09 14:59:21 --> Router Class Initialized
INFO - 2017-01-09 14:59:21 --> Output Class Initialized
INFO - 2017-01-09 14:59:21 --> Security Class Initialized
DEBUG - 2017-01-09 14:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 14:59:21 --> Input Class Initialized
INFO - 2017-01-09 14:59:21 --> Language Class Initialized
INFO - 2017-01-09 14:59:21 --> Loader Class Initialized
INFO - 2017-01-09 14:59:21 --> Helper loaded: url_helper
INFO - 2017-01-09 14:59:21 --> Helper loaded: language_helper
INFO - 2017-01-09 14:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 14:59:21 --> Controller Class Initialized
INFO - 2017-01-09 14:59:21 --> Database Driver Class Initialized
INFO - 2017-01-09 14:59:21 --> Model Class Initialized
INFO - 2017-01-09 14:59:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 14:59:21 --> Helper loaded: form_helper
INFO - 2017-01-09 14:59:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 14:59:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 14:59:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 14:59:21 --> Final output sent to browser
DEBUG - 2017-01-09 14:59:21 --> Total execution time: 0.0764
INFO - 2017-01-09 15:08:08 --> Config Class Initialized
INFO - 2017-01-09 15:08:08 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:08:08 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:08:08 --> Utf8 Class Initialized
INFO - 2017-01-09 15:08:08 --> URI Class Initialized
INFO - 2017-01-09 15:08:08 --> Router Class Initialized
INFO - 2017-01-09 15:08:08 --> Output Class Initialized
INFO - 2017-01-09 15:08:08 --> Security Class Initialized
DEBUG - 2017-01-09 15:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:08:08 --> Input Class Initialized
INFO - 2017-01-09 15:08:08 --> Language Class Initialized
INFO - 2017-01-09 15:08:08 --> Loader Class Initialized
INFO - 2017-01-09 15:08:08 --> Helper loaded: url_helper
INFO - 2017-01-09 15:08:08 --> Helper loaded: language_helper
INFO - 2017-01-09 15:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:08:08 --> Controller Class Initialized
INFO - 2017-01-09 15:08:08 --> Database Driver Class Initialized
INFO - 2017-01-09 15:08:08 --> Model Class Initialized
INFO - 2017-01-09 15:08:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:08:08 --> Helper loaded: form_helper
INFO - 2017-01-09 15:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 15:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:08:08 --> Final output sent to browser
DEBUG - 2017-01-09 15:08:08 --> Total execution time: 0.1271
INFO - 2017-01-09 15:08:50 --> Config Class Initialized
INFO - 2017-01-09 15:08:50 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:08:50 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:08:50 --> Utf8 Class Initialized
INFO - 2017-01-09 15:08:50 --> URI Class Initialized
INFO - 2017-01-09 15:08:50 --> Router Class Initialized
INFO - 2017-01-09 15:08:50 --> Output Class Initialized
INFO - 2017-01-09 15:08:50 --> Security Class Initialized
DEBUG - 2017-01-09 15:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:08:50 --> Input Class Initialized
INFO - 2017-01-09 15:08:50 --> Language Class Initialized
INFO - 2017-01-09 15:08:50 --> Loader Class Initialized
INFO - 2017-01-09 15:08:50 --> Helper loaded: url_helper
INFO - 2017-01-09 15:08:50 --> Helper loaded: language_helper
INFO - 2017-01-09 15:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:08:50 --> Controller Class Initialized
INFO - 2017-01-09 15:08:50 --> Database Driver Class Initialized
INFO - 2017-01-09 15:08:50 --> Model Class Initialized
INFO - 2017-01-09 15:08:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:08:50 --> Helper loaded: form_helper
ERROR - 2017-01-09 15:08:50 --> Severity: error --> Exception: syntax error, unexpected 'hasil' (T_STRING), expecting ',' or ')' C:\wamp64\www\savsoftquiz\application\views\header.php 99
INFO - 2017-01-09 15:09:25 --> Config Class Initialized
INFO - 2017-01-09 15:09:25 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:09:25 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:09:25 --> Utf8 Class Initialized
INFO - 2017-01-09 15:09:25 --> URI Class Initialized
INFO - 2017-01-09 15:09:25 --> Router Class Initialized
INFO - 2017-01-09 15:09:25 --> Output Class Initialized
INFO - 2017-01-09 15:09:25 --> Security Class Initialized
DEBUG - 2017-01-09 15:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:09:25 --> Input Class Initialized
INFO - 2017-01-09 15:09:25 --> Language Class Initialized
INFO - 2017-01-09 15:09:25 --> Loader Class Initialized
INFO - 2017-01-09 15:09:25 --> Helper loaded: url_helper
INFO - 2017-01-09 15:09:25 --> Helper loaded: language_helper
INFO - 2017-01-09 15:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:09:25 --> Controller Class Initialized
INFO - 2017-01-09 15:09:25 --> Database Driver Class Initialized
INFO - 2017-01-09 15:09:25 --> Model Class Initialized
INFO - 2017-01-09 15:09:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:09:25 --> Helper loaded: form_helper
ERROR - 2017-01-09 15:09:25 --> Severity: error --> Exception: syntax error, unexpected 'hasil' (T_STRING), expecting ',' or ')' C:\wamp64\www\savsoftquiz\application\views\header.php 99
INFO - 2017-01-09 15:09:35 --> Config Class Initialized
INFO - 2017-01-09 15:09:35 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:09:35 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:09:35 --> Utf8 Class Initialized
INFO - 2017-01-09 15:09:35 --> URI Class Initialized
INFO - 2017-01-09 15:09:35 --> Router Class Initialized
INFO - 2017-01-09 15:09:35 --> Output Class Initialized
INFO - 2017-01-09 15:09:35 --> Security Class Initialized
DEBUG - 2017-01-09 15:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:09:35 --> Input Class Initialized
INFO - 2017-01-09 15:09:35 --> Language Class Initialized
INFO - 2017-01-09 15:09:35 --> Loader Class Initialized
INFO - 2017-01-09 15:09:35 --> Helper loaded: url_helper
INFO - 2017-01-09 15:09:35 --> Helper loaded: language_helper
INFO - 2017-01-09 15:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:09:35 --> Controller Class Initialized
INFO - 2017-01-09 15:09:35 --> Database Driver Class Initialized
INFO - 2017-01-09 15:09:35 --> Model Class Initialized
INFO - 2017-01-09 15:09:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:09:35 --> Helper loaded: form_helper
ERROR - 2017-01-09 15:09:35 --> Severity: error --> Exception: syntax error, unexpected 'hasil' (T_STRING), expecting ',' or ')' C:\wamp64\www\savsoftquiz\application\views\header.php 99
INFO - 2017-01-09 15:09:58 --> Config Class Initialized
INFO - 2017-01-09 15:09:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:09:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:09:58 --> Utf8 Class Initialized
INFO - 2017-01-09 15:09:58 --> URI Class Initialized
INFO - 2017-01-09 15:09:58 --> Router Class Initialized
INFO - 2017-01-09 15:09:58 --> Output Class Initialized
INFO - 2017-01-09 15:09:58 --> Security Class Initialized
DEBUG - 2017-01-09 15:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:09:58 --> Input Class Initialized
INFO - 2017-01-09 15:09:58 --> Language Class Initialized
INFO - 2017-01-09 15:09:58 --> Loader Class Initialized
INFO - 2017-01-09 15:09:58 --> Helper loaded: url_helper
INFO - 2017-01-09 15:09:58 --> Helper loaded: language_helper
INFO - 2017-01-09 15:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:09:58 --> Controller Class Initialized
INFO - 2017-01-09 15:09:58 --> Database Driver Class Initialized
INFO - 2017-01-09 15:09:58 --> Model Class Initialized
INFO - 2017-01-09 15:09:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:09:58 --> Helper loaded: form_helper
INFO - 2017-01-09 15:09:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:09:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 15:09:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:09:58 --> Final output sent to browser
DEBUG - 2017-01-09 15:09:58 --> Total execution time: 0.0796
INFO - 2017-01-09 15:10:18 --> Config Class Initialized
INFO - 2017-01-09 15:10:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:10:18 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:10:18 --> Utf8 Class Initialized
INFO - 2017-01-09 15:10:18 --> URI Class Initialized
INFO - 2017-01-09 15:10:18 --> Router Class Initialized
INFO - 2017-01-09 15:10:18 --> Output Class Initialized
INFO - 2017-01-09 15:10:18 --> Security Class Initialized
DEBUG - 2017-01-09 15:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:10:18 --> Input Class Initialized
INFO - 2017-01-09 15:10:18 --> Language Class Initialized
INFO - 2017-01-09 15:10:18 --> Loader Class Initialized
INFO - 2017-01-09 15:10:18 --> Helper loaded: url_helper
INFO - 2017-01-09 15:10:18 --> Helper loaded: language_helper
INFO - 2017-01-09 15:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:10:18 --> Controller Class Initialized
INFO - 2017-01-09 15:10:18 --> Database Driver Class Initialized
INFO - 2017-01-09 15:10:18 --> Model Class Initialized
INFO - 2017-01-09 15:10:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:10:18 --> Helper loaded: form_helper
INFO - 2017-01-09 15:10:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:10:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 15:10:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:10:18 --> Final output sent to browser
DEBUG - 2017-01-09 15:10:18 --> Total execution time: 0.0864
INFO - 2017-01-09 15:10:24 --> Config Class Initialized
INFO - 2017-01-09 15:10:24 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:10:24 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:10:24 --> Utf8 Class Initialized
INFO - 2017-01-09 15:10:24 --> URI Class Initialized
INFO - 2017-01-09 15:10:24 --> Router Class Initialized
INFO - 2017-01-09 15:10:24 --> Output Class Initialized
INFO - 2017-01-09 15:10:24 --> Security Class Initialized
DEBUG - 2017-01-09 15:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:10:24 --> Input Class Initialized
INFO - 2017-01-09 15:10:24 --> Language Class Initialized
INFO - 2017-01-09 15:10:24 --> Loader Class Initialized
INFO - 2017-01-09 15:10:24 --> Helper loaded: url_helper
INFO - 2017-01-09 15:10:24 --> Helper loaded: language_helper
INFO - 2017-01-09 15:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:10:24 --> Controller Class Initialized
INFO - 2017-01-09 15:10:24 --> Database Driver Class Initialized
INFO - 2017-01-09 15:10:24 --> Model Class Initialized
INFO - 2017-01-09 15:10:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:10:24 --> Helper loaded: form_helper
INFO - 2017-01-09 15:10:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:10:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-09 15:10:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:10:24 --> Final output sent to browser
DEBUG - 2017-01-09 15:10:24 --> Total execution time: 0.0707
INFO - 2017-01-09 15:18:27 --> Config Class Initialized
INFO - 2017-01-09 15:18:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:18:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:18:27 --> Utf8 Class Initialized
INFO - 2017-01-09 15:18:27 --> URI Class Initialized
INFO - 2017-01-09 15:18:27 --> Router Class Initialized
INFO - 2017-01-09 15:18:27 --> Output Class Initialized
INFO - 2017-01-09 15:18:27 --> Security Class Initialized
DEBUG - 2017-01-09 15:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:18:27 --> Input Class Initialized
INFO - 2017-01-09 15:18:27 --> Language Class Initialized
INFO - 2017-01-09 15:18:27 --> Loader Class Initialized
INFO - 2017-01-09 15:18:27 --> Helper loaded: url_helper
INFO - 2017-01-09 15:18:27 --> Helper loaded: language_helper
INFO - 2017-01-09 15:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:18:27 --> Controller Class Initialized
INFO - 2017-01-09 15:18:27 --> Database Driver Class Initialized
INFO - 2017-01-09 15:18:27 --> Model Class Initialized
INFO - 2017-01-09 15:18:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 15:18:27 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 71
ERROR - 2017-01-09 15:18:27 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-09 15:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-09 15:18:27 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 72
INFO - 2017-01-09 15:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpa.php
ERROR - 2017-01-09 15:18:27 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 73
INFO - 2017-01-09 15:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:18:27 --> Final output sent to browser
DEBUG - 2017-01-09 15:18:27 --> Total execution time: 0.0693
INFO - 2017-01-09 15:19:08 --> Config Class Initialized
INFO - 2017-01-09 15:19:08 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:19:08 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:19:08 --> Utf8 Class Initialized
INFO - 2017-01-09 15:19:08 --> URI Class Initialized
INFO - 2017-01-09 15:19:08 --> Router Class Initialized
INFO - 2017-01-09 15:19:08 --> Output Class Initialized
INFO - 2017-01-09 15:19:08 --> Security Class Initialized
DEBUG - 2017-01-09 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:19:08 --> Input Class Initialized
INFO - 2017-01-09 15:19:08 --> Language Class Initialized
INFO - 2017-01-09 15:19:08 --> Loader Class Initialized
INFO - 2017-01-09 15:19:08 --> Helper loaded: url_helper
INFO - 2017-01-09 15:19:08 --> Helper loaded: language_helper
INFO - 2017-01-09 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:19:08 --> Controller Class Initialized
INFO - 2017-01-09 15:19:08 --> Database Driver Class Initialized
INFO - 2017-01-09 15:19:08 --> Model Class Initialized
INFO - 2017-01-09 15:19:08 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 15:19:08 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-09 15:19:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:19:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpa.php
INFO - 2017-01-09 15:19:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:19:08 --> Final output sent to browser
DEBUG - 2017-01-09 15:19:08 --> Total execution time: 0.0608
INFO - 2017-01-09 15:19:12 --> Config Class Initialized
INFO - 2017-01-09 15:19:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:19:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:19:12 --> Utf8 Class Initialized
INFO - 2017-01-09 15:19:12 --> URI Class Initialized
INFO - 2017-01-09 15:19:12 --> Router Class Initialized
INFO - 2017-01-09 15:19:12 --> Output Class Initialized
INFO - 2017-01-09 15:19:12 --> Security Class Initialized
DEBUG - 2017-01-09 15:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:19:12 --> Input Class Initialized
INFO - 2017-01-09 15:19:12 --> Language Class Initialized
INFO - 2017-01-09 15:19:12 --> Loader Class Initialized
INFO - 2017-01-09 15:19:12 --> Helper loaded: url_helper
INFO - 2017-01-09 15:19:12 --> Helper loaded: language_helper
INFO - 2017-01-09 15:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:19:12 --> Controller Class Initialized
INFO - 2017-01-09 15:19:12 --> Database Driver Class Initialized
INFO - 2017-01-09 15:19:12 --> Model Class Initialized
INFO - 2017-01-09 15:19:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 15:19:12 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-09 15:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu.php
INFO - 2017-01-09 15:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:19:12 --> Final output sent to browser
DEBUG - 2017-01-09 15:19:12 --> Total execution time: 0.0571
INFO - 2017-01-09 15:19:17 --> Config Class Initialized
INFO - 2017-01-09 15:19:17 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:19:17 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:19:17 --> Utf8 Class Initialized
INFO - 2017-01-09 15:19:17 --> URI Class Initialized
INFO - 2017-01-09 15:19:17 --> Router Class Initialized
INFO - 2017-01-09 15:19:17 --> Output Class Initialized
INFO - 2017-01-09 15:19:17 --> Security Class Initialized
DEBUG - 2017-01-09 15:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:19:17 --> Input Class Initialized
INFO - 2017-01-09 15:19:17 --> Language Class Initialized
INFO - 2017-01-09 15:19:17 --> Loader Class Initialized
INFO - 2017-01-09 15:19:17 --> Helper loaded: url_helper
INFO - 2017-01-09 15:19:17 --> Helper loaded: language_helper
INFO - 2017-01-09 15:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:19:17 --> Controller Class Initialized
INFO - 2017-01-09 15:19:17 --> Database Driver Class Initialized
INFO - 2017-01-09 15:19:17 --> Model Class Initialized
INFO - 2017-01-09 15:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:19:17 --> Helper loaded: form_helper
INFO - 2017-01-09 15:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 15:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:19:17 --> Final output sent to browser
DEBUG - 2017-01-09 15:19:17 --> Total execution time: 0.0659
INFO - 2017-01-09 15:19:22 --> Config Class Initialized
INFO - 2017-01-09 15:19:22 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:19:22 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:19:22 --> Utf8 Class Initialized
INFO - 2017-01-09 15:19:22 --> URI Class Initialized
INFO - 2017-01-09 15:19:22 --> Router Class Initialized
INFO - 2017-01-09 15:19:22 --> Output Class Initialized
INFO - 2017-01-09 15:19:22 --> Security Class Initialized
DEBUG - 2017-01-09 15:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:19:22 --> Input Class Initialized
INFO - 2017-01-09 15:19:22 --> Language Class Initialized
INFO - 2017-01-09 15:19:22 --> Loader Class Initialized
INFO - 2017-01-09 15:19:22 --> Helper loaded: url_helper
INFO - 2017-01-09 15:19:22 --> Helper loaded: language_helper
INFO - 2017-01-09 15:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:19:22 --> Controller Class Initialized
INFO - 2017-01-09 15:19:22 --> Database Driver Class Initialized
INFO - 2017-01-09 15:19:22 --> Model Class Initialized
INFO - 2017-01-09 15:19:22 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 15:19:22 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-09 15:19:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:19:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-09 15:19:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:19:22 --> Final output sent to browser
DEBUG - 2017-01-09 15:19:22 --> Total execution time: 0.0596
INFO - 2017-01-09 15:20:04 --> Config Class Initialized
INFO - 2017-01-09 15:20:04 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:20:04 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:20:04 --> Utf8 Class Initialized
INFO - 2017-01-09 15:20:04 --> URI Class Initialized
INFO - 2017-01-09 15:20:04 --> Router Class Initialized
INFO - 2017-01-09 15:20:04 --> Output Class Initialized
INFO - 2017-01-09 15:20:04 --> Security Class Initialized
DEBUG - 2017-01-09 15:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:20:04 --> Input Class Initialized
INFO - 2017-01-09 15:20:04 --> Language Class Initialized
INFO - 2017-01-09 15:20:04 --> Loader Class Initialized
INFO - 2017-01-09 15:20:04 --> Helper loaded: url_helper
INFO - 2017-01-09 15:20:04 --> Helper loaded: language_helper
INFO - 2017-01-09 15:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:20:05 --> Controller Class Initialized
INFO - 2017-01-09 15:20:05 --> Database Driver Class Initialized
INFO - 2017-01-09 15:20:05 --> Model Class Initialized
INFO - 2017-01-09 15:20:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:20:05 --> Helper loaded: form_helper
INFO - 2017-01-09 15:20:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:20:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 15:20:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:20:05 --> Final output sent to browser
DEBUG - 2017-01-09 15:20:05 --> Total execution time: 0.0683
INFO - 2017-01-09 15:21:05 --> Config Class Initialized
INFO - 2017-01-09 15:21:05 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:05 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:05 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:05 --> URI Class Initialized
INFO - 2017-01-09 15:21:05 --> Router Class Initialized
INFO - 2017-01-09 15:21:05 --> Output Class Initialized
INFO - 2017-01-09 15:21:05 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:05 --> Input Class Initialized
INFO - 2017-01-09 15:21:05 --> Language Class Initialized
ERROR - 2017-01-09 15:21:05 --> Severity: error --> Exception: syntax error, unexpected '-', expecting '(' C:\wamp64\www\savsoftquiz\application\controllers\Hasil.php 69
INFO - 2017-01-09 15:21:20 --> Config Class Initialized
INFO - 2017-01-09 15:21:20 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:20 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:20 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:20 --> URI Class Initialized
INFO - 2017-01-09 15:21:20 --> Router Class Initialized
INFO - 2017-01-09 15:21:20 --> Output Class Initialized
INFO - 2017-01-09 15:21:20 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:20 --> Input Class Initialized
INFO - 2017-01-09 15:21:20 --> Language Class Initialized
INFO - 2017-01-09 15:21:20 --> Loader Class Initialized
INFO - 2017-01-09 15:21:20 --> Helper loaded: url_helper
INFO - 2017-01-09 15:21:20 --> Helper loaded: language_helper
INFO - 2017-01-09 15:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:21:20 --> Controller Class Initialized
INFO - 2017-01-09 15:21:20 --> Database Driver Class Initialized
INFO - 2017-01-09 15:21:20 --> Model Class Initialized
INFO - 2017-01-09 15:21:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:21:20 --> Helper loaded: form_helper
INFO - 2017-01-09 15:21:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:21:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 15:21:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:21:20 --> Final output sent to browser
DEBUG - 2017-01-09 15:21:20 --> Total execution time: 0.0760
INFO - 2017-01-09 15:21:23 --> Config Class Initialized
INFO - 2017-01-09 15:21:23 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:23 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:23 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:23 --> URI Class Initialized
INFO - 2017-01-09 15:21:23 --> Router Class Initialized
INFO - 2017-01-09 15:21:23 --> Output Class Initialized
INFO - 2017-01-09 15:21:23 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:23 --> Input Class Initialized
INFO - 2017-01-09 15:21:23 --> Language Class Initialized
ERROR - 2017-01-09 15:21:23 --> 404 Page Not Found: Hasil/detail-ist
INFO - 2017-01-09 15:21:41 --> Config Class Initialized
INFO - 2017-01-09 15:21:41 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:41 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:41 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:41 --> URI Class Initialized
INFO - 2017-01-09 15:21:41 --> Router Class Initialized
INFO - 2017-01-09 15:21:41 --> Output Class Initialized
INFO - 2017-01-09 15:21:41 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:41 --> Input Class Initialized
INFO - 2017-01-09 15:21:41 --> Language Class Initialized
ERROR - 2017-01-09 15:21:41 --> 404 Page Not Found: Hasil/detail-ist
INFO - 2017-01-09 15:21:43 --> Config Class Initialized
INFO - 2017-01-09 15:21:43 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:43 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:43 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:43 --> URI Class Initialized
INFO - 2017-01-09 15:21:43 --> Router Class Initialized
INFO - 2017-01-09 15:21:43 --> Output Class Initialized
INFO - 2017-01-09 15:21:43 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:43 --> Input Class Initialized
INFO - 2017-01-09 15:21:43 --> Language Class Initialized
INFO - 2017-01-09 15:21:43 --> Loader Class Initialized
INFO - 2017-01-09 15:21:43 --> Helper loaded: url_helper
INFO - 2017-01-09 15:21:43 --> Helper loaded: language_helper
INFO - 2017-01-09 15:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:21:43 --> Controller Class Initialized
INFO - 2017-01-09 15:21:43 --> Database Driver Class Initialized
INFO - 2017-01-09 15:21:43 --> Model Class Initialized
INFO - 2017-01-09 15:21:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:21:43 --> Helper loaded: form_helper
INFO - 2017-01-09 15:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 15:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:21:43 --> Final output sent to browser
DEBUG - 2017-01-09 15:21:43 --> Total execution time: 0.0796
INFO - 2017-01-09 15:21:44 --> Config Class Initialized
INFO - 2017-01-09 15:21:44 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:44 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:44 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:44 --> URI Class Initialized
INFO - 2017-01-09 15:21:44 --> Router Class Initialized
INFO - 2017-01-09 15:21:44 --> Output Class Initialized
INFO - 2017-01-09 15:21:44 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:44 --> Input Class Initialized
INFO - 2017-01-09 15:21:44 --> Language Class Initialized
INFO - 2017-01-09 15:21:44 --> Loader Class Initialized
INFO - 2017-01-09 15:21:44 --> Helper loaded: url_helper
INFO - 2017-01-09 15:21:44 --> Helper loaded: language_helper
INFO - 2017-01-09 15:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:21:44 --> Controller Class Initialized
INFO - 2017-01-09 15:21:44 --> Database Driver Class Initialized
INFO - 2017-01-09 15:21:44 --> Model Class Initialized
INFO - 2017-01-09 15:21:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:21:44 --> Helper loaded: form_helper
INFO - 2017-01-09 15:21:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:21:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 15:21:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:21:44 --> Final output sent to browser
DEBUG - 2017-01-09 15:21:44 --> Total execution time: 0.0828
INFO - 2017-01-09 15:21:45 --> Config Class Initialized
INFO - 2017-01-09 15:21:45 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:21:45 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:21:45 --> Utf8 Class Initialized
INFO - 2017-01-09 15:21:45 --> URI Class Initialized
INFO - 2017-01-09 15:21:45 --> Router Class Initialized
INFO - 2017-01-09 15:21:45 --> Output Class Initialized
INFO - 2017-01-09 15:21:45 --> Security Class Initialized
DEBUG - 2017-01-09 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:21:45 --> Input Class Initialized
INFO - 2017-01-09 15:21:45 --> Language Class Initialized
INFO - 2017-01-09 15:21:45 --> Loader Class Initialized
INFO - 2017-01-09 15:21:45 --> Helper loaded: url_helper
INFO - 2017-01-09 15:21:45 --> Helper loaded: language_helper
INFO - 2017-01-09 15:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:21:45 --> Controller Class Initialized
INFO - 2017-01-09 15:21:45 --> Database Driver Class Initialized
INFO - 2017-01-09 15:21:45 --> Model Class Initialized
INFO - 2017-01-09 15:21:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:21:45 --> Model Class Initialized
INFO - 2017-01-09 15:21:45 --> Model Class Initialized
INFO - 2017-01-09 15:21:45 --> Helper loaded: form_helper
INFO - 2017-01-09 15:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-09 15:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:21:45 --> Final output sent to browser
DEBUG - 2017-01-09 15:21:45 --> Total execution time: 0.0908
INFO - 2017-01-09 15:23:19 --> Config Class Initialized
INFO - 2017-01-09 15:23:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:23:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:23:19 --> Utf8 Class Initialized
INFO - 2017-01-09 15:23:19 --> URI Class Initialized
INFO - 2017-01-09 15:23:19 --> Router Class Initialized
INFO - 2017-01-09 15:23:19 --> Output Class Initialized
INFO - 2017-01-09 15:23:19 --> Security Class Initialized
DEBUG - 2017-01-09 15:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:23:19 --> Input Class Initialized
INFO - 2017-01-09 15:23:19 --> Language Class Initialized
INFO - 2017-01-09 15:23:19 --> Loader Class Initialized
INFO - 2017-01-09 15:23:19 --> Helper loaded: url_helper
INFO - 2017-01-09 15:23:19 --> Helper loaded: language_helper
INFO - 2017-01-09 15:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:23:19 --> Controller Class Initialized
INFO - 2017-01-09 15:23:19 --> Database Driver Class Initialized
INFO - 2017-01-09 15:23:19 --> Model Class Initialized
INFO - 2017-01-09 15:23:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:23:19 --> Model Class Initialized
INFO - 2017-01-09 15:23:19 --> Model Class Initialized
INFO - 2017-01-09 15:23:19 --> Helper loaded: form_helper
INFO - 2017-01-09 15:23:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:23:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-09 15:23:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:23:19 --> Final output sent to browser
DEBUG - 2017-01-09 15:23:19 --> Total execution time: 0.1048
INFO - 2017-01-09 15:23:37 --> Config Class Initialized
INFO - 2017-01-09 15:23:37 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:23:37 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:23:37 --> Utf8 Class Initialized
INFO - 2017-01-09 15:23:37 --> URI Class Initialized
INFO - 2017-01-09 15:23:37 --> Router Class Initialized
INFO - 2017-01-09 15:23:37 --> Output Class Initialized
INFO - 2017-01-09 15:23:37 --> Security Class Initialized
DEBUG - 2017-01-09 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:23:37 --> Input Class Initialized
INFO - 2017-01-09 15:23:37 --> Language Class Initialized
INFO - 2017-01-09 15:23:37 --> Loader Class Initialized
INFO - 2017-01-09 15:23:37 --> Helper loaded: url_helper
INFO - 2017-01-09 15:23:37 --> Helper loaded: language_helper
INFO - 2017-01-09 15:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:23:37 --> Controller Class Initialized
INFO - 2017-01-09 15:23:38 --> Database Driver Class Initialized
INFO - 2017-01-09 15:23:38 --> Model Class Initialized
INFO - 2017-01-09 15:23:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:23:38 --> Model Class Initialized
INFO - 2017-01-09 15:23:38 --> Model Class Initialized
INFO - 2017-01-09 15:23:38 --> Helper loaded: form_helper
INFO - 2017-01-09 15:23:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:23:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-09 15:23:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:23:38 --> Final output sent to browser
DEBUG - 2017-01-09 15:23:38 --> Total execution time: 0.0982
INFO - 2017-01-09 15:24:43 --> Config Class Initialized
INFO - 2017-01-09 15:24:43 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:24:43 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:24:43 --> Utf8 Class Initialized
INFO - 2017-01-09 15:24:43 --> URI Class Initialized
INFO - 2017-01-09 15:24:43 --> Router Class Initialized
INFO - 2017-01-09 15:24:43 --> Output Class Initialized
INFO - 2017-01-09 15:24:43 --> Security Class Initialized
DEBUG - 2017-01-09 15:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:24:43 --> Input Class Initialized
INFO - 2017-01-09 15:24:43 --> Language Class Initialized
INFO - 2017-01-09 15:24:43 --> Loader Class Initialized
INFO - 2017-01-09 15:24:43 --> Helper loaded: url_helper
INFO - 2017-01-09 15:24:43 --> Helper loaded: language_helper
INFO - 2017-01-09 15:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:24:43 --> Controller Class Initialized
INFO - 2017-01-09 15:24:43 --> Database Driver Class Initialized
INFO - 2017-01-09 15:24:43 --> Model Class Initialized
INFO - 2017-01-09 15:24:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:24:43 --> Model Class Initialized
INFO - 2017-01-09 15:24:43 --> Model Class Initialized
INFO - 2017-01-09 15:24:43 --> Helper loaded: form_helper
INFO - 2017-01-09 15:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-09 15:24:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:24:43 --> Final output sent to browser
DEBUG - 2017-01-09 15:24:43 --> Total execution time: 0.0999
INFO - 2017-01-09 15:24:50 --> Config Class Initialized
INFO - 2017-01-09 15:24:50 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:24:50 --> Utf8 Class Initialized
INFO - 2017-01-09 15:24:50 --> URI Class Initialized
INFO - 2017-01-09 15:24:50 --> Router Class Initialized
INFO - 2017-01-09 15:24:50 --> Output Class Initialized
INFO - 2017-01-09 15:24:50 --> Security Class Initialized
DEBUG - 2017-01-09 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:24:50 --> Input Class Initialized
INFO - 2017-01-09 15:24:50 --> Language Class Initialized
INFO - 2017-01-09 15:24:50 --> Loader Class Initialized
INFO - 2017-01-09 15:24:50 --> Helper loaded: url_helper
INFO - 2017-01-09 15:24:50 --> Helper loaded: language_helper
INFO - 2017-01-09 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:24:50 --> Controller Class Initialized
INFO - 2017-01-09 15:24:50 --> Database Driver Class Initialized
INFO - 2017-01-09 15:24:50 --> Model Class Initialized
INFO - 2017-01-09 15:24:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:24:50 --> Helper loaded: form_helper
INFO - 2017-01-09 15:24:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:24:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 15:24:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:24:50 --> Final output sent to browser
DEBUG - 2017-01-09 15:24:50 --> Total execution time: 0.0631
INFO - 2017-01-09 15:24:52 --> Config Class Initialized
INFO - 2017-01-09 15:24:52 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:24:52 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:24:52 --> Utf8 Class Initialized
INFO - 2017-01-09 15:24:52 --> URI Class Initialized
INFO - 2017-01-09 15:24:52 --> Router Class Initialized
INFO - 2017-01-09 15:24:52 --> Output Class Initialized
INFO - 2017-01-09 15:24:52 --> Security Class Initialized
DEBUG - 2017-01-09 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:24:52 --> Input Class Initialized
INFO - 2017-01-09 15:24:52 --> Language Class Initialized
INFO - 2017-01-09 15:24:52 --> Loader Class Initialized
INFO - 2017-01-09 15:24:52 --> Helper loaded: url_helper
INFO - 2017-01-09 15:24:52 --> Helper loaded: language_helper
INFO - 2017-01-09 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:24:52 --> Controller Class Initialized
INFO - 2017-01-09 15:24:52 --> Database Driver Class Initialized
INFO - 2017-01-09 15:24:52 --> Model Class Initialized
INFO - 2017-01-09 15:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:24:52 --> Model Class Initialized
INFO - 2017-01-09 15:24:52 --> Model Class Initialized
INFO - 2017-01-09 15:24:52 --> Helper loaded: form_helper
INFO - 2017-01-09 15:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-09 15:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:24:52 --> Final output sent to browser
DEBUG - 2017-01-09 15:24:52 --> Total execution time: 0.0830
INFO - 2017-01-09 15:24:57 --> Config Class Initialized
INFO - 2017-01-09 15:24:57 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:24:57 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:24:57 --> Utf8 Class Initialized
INFO - 2017-01-09 15:24:57 --> URI Class Initialized
DEBUG - 2017-01-09 15:24:57 --> No URI present. Default controller set.
INFO - 2017-01-09 15:24:57 --> Router Class Initialized
INFO - 2017-01-09 15:24:57 --> Output Class Initialized
INFO - 2017-01-09 15:24:57 --> Security Class Initialized
DEBUG - 2017-01-09 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:24:57 --> Input Class Initialized
INFO - 2017-01-09 15:24:57 --> Language Class Initialized
INFO - 2017-01-09 15:24:57 --> Loader Class Initialized
INFO - 2017-01-09 15:24:57 --> Helper loaded: url_helper
INFO - 2017-01-09 15:24:57 --> Helper loaded: language_helper
INFO - 2017-01-09 15:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:24:57 --> Controller Class Initialized
INFO - 2017-01-09 15:24:57 --> Database Driver Class Initialized
INFO - 2017-01-09 15:24:57 --> Model Class Initialized
INFO - 2017-01-09 15:24:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:24:57 --> Config Class Initialized
INFO - 2017-01-09 15:24:57 --> Hooks Class Initialized
DEBUG - 2017-01-09 15:24:57 --> UTF-8 Support Enabled
INFO - 2017-01-09 15:24:57 --> Utf8 Class Initialized
INFO - 2017-01-09 15:24:57 --> URI Class Initialized
INFO - 2017-01-09 15:24:57 --> Router Class Initialized
INFO - 2017-01-09 15:24:57 --> Output Class Initialized
INFO - 2017-01-09 15:24:57 --> Security Class Initialized
DEBUG - 2017-01-09 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 15:24:57 --> Input Class Initialized
INFO - 2017-01-09 15:24:57 --> Language Class Initialized
INFO - 2017-01-09 15:24:57 --> Loader Class Initialized
INFO - 2017-01-09 15:24:57 --> Helper loaded: url_helper
INFO - 2017-01-09 15:24:57 --> Helper loaded: language_helper
INFO - 2017-01-09 15:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 15:24:57 --> Controller Class Initialized
INFO - 2017-01-09 15:24:57 --> Database Driver Class Initialized
INFO - 2017-01-09 15:24:57 --> Model Class Initialized
INFO - 2017-01-09 15:24:57 --> Model Class Initialized
INFO - 2017-01-09 15:24:57 --> Model Class Initialized
INFO - 2017-01-09 15:24:57 --> Model Class Initialized
INFO - 2017-01-09 15:24:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 15:24:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 15:24:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 15:24:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 15:24:57 --> Final output sent to browser
DEBUG - 2017-01-09 15:24:57 --> Total execution time: 0.0715
INFO - 2017-01-09 17:04:58 --> Config Class Initialized
INFO - 2017-01-09 17:04:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:04:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:04:58 --> Utf8 Class Initialized
INFO - 2017-01-09 17:04:58 --> URI Class Initialized
INFO - 2017-01-09 17:04:58 --> Router Class Initialized
INFO - 2017-01-09 17:04:58 --> Output Class Initialized
INFO - 2017-01-09 17:04:58 --> Security Class Initialized
DEBUG - 2017-01-09 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:04:58 --> Input Class Initialized
INFO - 2017-01-09 17:04:58 --> Language Class Initialized
INFO - 2017-01-09 17:04:58 --> Loader Class Initialized
INFO - 2017-01-09 17:04:58 --> Helper loaded: url_helper
INFO - 2017-01-09 17:04:58 --> Helper loaded: language_helper
INFO - 2017-01-09 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:04:58 --> Controller Class Initialized
INFO - 2017-01-09 17:04:58 --> Database Driver Class Initialized
INFO - 2017-01-09 17:04:58 --> Model Class Initialized
INFO - 2017-01-09 17:04:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 17:04:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:04:58 --> Final output sent to browser
DEBUG - 2017-01-09 17:04:58 --> Total execution time: 0.1080
INFO - 2017-01-09 17:05:12 --> Config Class Initialized
INFO - 2017-01-09 17:05:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:05:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:05:12 --> Utf8 Class Initialized
INFO - 2017-01-09 17:05:12 --> URI Class Initialized
INFO - 2017-01-09 17:05:12 --> Router Class Initialized
INFO - 2017-01-09 17:05:12 --> Output Class Initialized
INFO - 2017-01-09 17:05:12 --> Security Class Initialized
DEBUG - 2017-01-09 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:05:12 --> Input Class Initialized
INFO - 2017-01-09 17:05:12 --> Language Class Initialized
INFO - 2017-01-09 17:05:12 --> Loader Class Initialized
INFO - 2017-01-09 17:05:12 --> Helper loaded: url_helper
INFO - 2017-01-09 17:05:12 --> Helper loaded: language_helper
INFO - 2017-01-09 17:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:05:12 --> Controller Class Initialized
INFO - 2017-01-09 17:05:12 --> Database Driver Class Initialized
INFO - 2017-01-09 17:05:12 --> Model Class Initialized
INFO - 2017-01-09 17:05:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:05:12 --> Helper loaded: form_helper
INFO - 2017-01-09 17:05:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:05:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 17:05:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:05:12 --> Final output sent to browser
DEBUG - 2017-01-09 17:05:12 --> Total execution time: 0.0786
INFO - 2017-01-09 17:05:33 --> Config Class Initialized
INFO - 2017-01-09 17:05:33 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:05:33 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:05:33 --> Utf8 Class Initialized
INFO - 2017-01-09 17:05:33 --> URI Class Initialized
INFO - 2017-01-09 17:05:33 --> Router Class Initialized
INFO - 2017-01-09 17:05:33 --> Output Class Initialized
INFO - 2017-01-09 17:05:33 --> Security Class Initialized
DEBUG - 2017-01-09 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:05:33 --> Input Class Initialized
INFO - 2017-01-09 17:05:33 --> Language Class Initialized
INFO - 2017-01-09 17:05:33 --> Loader Class Initialized
INFO - 2017-01-09 17:05:33 --> Helper loaded: url_helper
INFO - 2017-01-09 17:05:33 --> Helper loaded: language_helper
INFO - 2017-01-09 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:05:33 --> Controller Class Initialized
INFO - 2017-01-09 17:05:33 --> Database Driver Class Initialized
INFO - 2017-01-09 17:05:33 --> Model Class Initialized
INFO - 2017-01-09 17:05:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:05:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:05:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 17:05:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:05:33 --> Final output sent to browser
DEBUG - 2017-01-09 17:05:33 --> Total execution time: 0.0646
INFO - 2017-01-09 17:06:27 --> Config Class Initialized
INFO - 2017-01-09 17:06:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:06:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:06:27 --> Utf8 Class Initialized
INFO - 2017-01-09 17:06:27 --> URI Class Initialized
INFO - 2017-01-09 17:06:27 --> Router Class Initialized
INFO - 2017-01-09 17:06:27 --> Output Class Initialized
INFO - 2017-01-09 17:06:27 --> Security Class Initialized
DEBUG - 2017-01-09 17:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:06:27 --> Input Class Initialized
INFO - 2017-01-09 17:06:27 --> Language Class Initialized
INFO - 2017-01-09 17:06:27 --> Loader Class Initialized
INFO - 2017-01-09 17:06:27 --> Helper loaded: url_helper
INFO - 2017-01-09 17:06:27 --> Helper loaded: language_helper
INFO - 2017-01-09 17:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:06:27 --> Controller Class Initialized
INFO - 2017-01-09 17:06:27 --> Database Driver Class Initialized
INFO - 2017-01-09 17:06:27 --> Model Class Initialized
INFO - 2017-01-09 17:06:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:06:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:06:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-09 17:06:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:06:27 --> Final output sent to browser
DEBUG - 2017-01-09 17:06:27 --> Total execution time: 0.0614
INFO - 2017-01-09 17:06:27 --> Config Class Initialized
INFO - 2017-01-09 17:06:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:06:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:06:27 --> Utf8 Class Initialized
INFO - 2017-01-09 17:06:27 --> URI Class Initialized
INFO - 2017-01-09 17:06:27 --> Router Class Initialized
INFO - 2017-01-09 17:06:27 --> Output Class Initialized
INFO - 2017-01-09 17:06:27 --> Security Class Initialized
DEBUG - 2017-01-09 17:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:06:27 --> Input Class Initialized
INFO - 2017-01-09 17:06:27 --> Language Class Initialized
INFO - 2017-01-09 17:06:27 --> Loader Class Initialized
INFO - 2017-01-09 17:06:27 --> Helper loaded: url_helper
INFO - 2017-01-09 17:06:27 --> Helper loaded: language_helper
INFO - 2017-01-09 17:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:06:27 --> Controller Class Initialized
INFO - 2017-01-09 17:06:27 --> Database Driver Class Initialized
INFO - 2017-01-09 17:06:27 --> Model Class Initialized
INFO - 2017-01-09 17:06:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:06:27 --> Final output sent to browser
DEBUG - 2017-01-09 17:06:27 --> Total execution time: 0.0755
INFO - 2017-01-09 17:11:26 --> Config Class Initialized
INFO - 2017-01-09 17:11:26 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:11:26 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:11:26 --> Utf8 Class Initialized
INFO - 2017-01-09 17:11:26 --> URI Class Initialized
INFO - 2017-01-09 17:11:26 --> Router Class Initialized
INFO - 2017-01-09 17:11:26 --> Output Class Initialized
INFO - 2017-01-09 17:11:26 --> Security Class Initialized
DEBUG - 2017-01-09 17:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:11:26 --> Input Class Initialized
INFO - 2017-01-09 17:11:26 --> Language Class Initialized
INFO - 2017-01-09 17:11:26 --> Loader Class Initialized
INFO - 2017-01-09 17:11:26 --> Helper loaded: url_helper
INFO - 2017-01-09 17:11:26 --> Helper loaded: language_helper
INFO - 2017-01-09 17:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:11:26 --> Controller Class Initialized
INFO - 2017-01-09 17:11:26 --> Database Driver Class Initialized
INFO - 2017-01-09 17:11:26 --> Model Class Initialized
INFO - 2017-01-09 17:11:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:11:26 --> Helper loaded: form_helper
INFO - 2017-01-09 17:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 17:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:11:26 --> Final output sent to browser
DEBUG - 2017-01-09 17:11:26 --> Total execution time: 0.0744
INFO - 2017-01-09 17:12:02 --> Config Class Initialized
INFO - 2017-01-09 17:12:02 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:12:02 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:12:02 --> Utf8 Class Initialized
INFO - 2017-01-09 17:12:02 --> URI Class Initialized
INFO - 2017-01-09 17:12:02 --> Router Class Initialized
INFO - 2017-01-09 17:12:02 --> Output Class Initialized
INFO - 2017-01-09 17:12:02 --> Security Class Initialized
DEBUG - 2017-01-09 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:12:02 --> Input Class Initialized
INFO - 2017-01-09 17:12:02 --> Language Class Initialized
INFO - 2017-01-09 17:12:02 --> Loader Class Initialized
INFO - 2017-01-09 17:12:02 --> Helper loaded: url_helper
INFO - 2017-01-09 17:12:02 --> Helper loaded: language_helper
INFO - 2017-01-09 17:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:12:02 --> Controller Class Initialized
INFO - 2017-01-09 17:12:02 --> Database Driver Class Initialized
INFO - 2017-01-09 17:12:02 --> Model Class Initialized
INFO - 2017-01-09 17:12:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:12:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:12:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 17:12:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:12:02 --> Final output sent to browser
DEBUG - 2017-01-09 17:12:02 --> Total execution time: 0.0592
INFO - 2017-01-09 17:13:49 --> Config Class Initialized
INFO - 2017-01-09 17:13:49 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:13:49 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:13:49 --> Utf8 Class Initialized
INFO - 2017-01-09 17:13:49 --> URI Class Initialized
INFO - 2017-01-09 17:13:49 --> Router Class Initialized
INFO - 2017-01-09 17:13:49 --> Output Class Initialized
INFO - 2017-01-09 17:13:49 --> Security Class Initialized
DEBUG - 2017-01-09 17:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:13:49 --> Input Class Initialized
INFO - 2017-01-09 17:13:49 --> Language Class Initialized
INFO - 2017-01-09 17:13:49 --> Loader Class Initialized
INFO - 2017-01-09 17:13:49 --> Helper loaded: url_helper
INFO - 2017-01-09 17:13:49 --> Helper loaded: language_helper
INFO - 2017-01-09 17:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:13:49 --> Controller Class Initialized
INFO - 2017-01-09 17:13:49 --> Database Driver Class Initialized
INFO - 2017-01-09 17:13:49 --> Model Class Initialized
INFO - 2017-01-09 17:13:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 17:13:49 --> Helper loaded: form_helper
INFO - 2017-01-09 17:13:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 17:13:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 17:13:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 17:13:49 --> Final output sent to browser
DEBUG - 2017-01-09 17:13:49 --> Total execution time: 0.0689
INFO - 2017-01-09 18:45:09 --> Config Class Initialized
INFO - 2017-01-09 18:45:09 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:09 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:09 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:09 --> URI Class Initialized
INFO - 2017-01-09 18:45:09 --> Router Class Initialized
INFO - 2017-01-09 18:45:09 --> Output Class Initialized
INFO - 2017-01-09 18:45:09 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:09 --> Input Class Initialized
INFO - 2017-01-09 18:45:09 --> Language Class Initialized
INFO - 2017-01-09 18:45:09 --> Loader Class Initialized
INFO - 2017-01-09 18:45:09 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:09 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:09 --> Controller Class Initialized
INFO - 2017-01-09 18:45:09 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:09 --> Model Class Initialized
INFO - 2017-01-09 18:45:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:45:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-09 18:45:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:45:09 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:09 --> Total execution time: 0.1554
INFO - 2017-01-09 18:45:09 --> Config Class Initialized
INFO - 2017-01-09 18:45:09 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:09 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:09 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:09 --> URI Class Initialized
INFO - 2017-01-09 18:45:09 --> Router Class Initialized
INFO - 2017-01-09 18:45:09 --> Output Class Initialized
INFO - 2017-01-09 18:45:09 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:09 --> Input Class Initialized
INFO - 2017-01-09 18:45:09 --> Language Class Initialized
INFO - 2017-01-09 18:45:09 --> Loader Class Initialized
INFO - 2017-01-09 18:45:09 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:09 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:09 --> Controller Class Initialized
INFO - 2017-01-09 18:45:09 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:09 --> Model Class Initialized
INFO - 2017-01-09 18:45:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:09 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:09 --> Total execution time: 0.1050
INFO - 2017-01-09 18:45:20 --> Config Class Initialized
INFO - 2017-01-09 18:45:20 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:20 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:20 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:20 --> URI Class Initialized
INFO - 2017-01-09 18:45:20 --> Router Class Initialized
INFO - 2017-01-09 18:45:20 --> Output Class Initialized
INFO - 2017-01-09 18:45:20 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:20 --> Input Class Initialized
INFO - 2017-01-09 18:45:20 --> Language Class Initialized
INFO - 2017-01-09 18:45:20 --> Loader Class Initialized
INFO - 2017-01-09 18:45:20 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:20 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:20 --> Controller Class Initialized
INFO - 2017-01-09 18:45:20 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:20 --> Model Class Initialized
INFO - 2017-01-09 18:45:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:45:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 18:45:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:45:20 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:20 --> Total execution time: 0.1127
INFO - 2017-01-09 18:45:27 --> Config Class Initialized
INFO - 2017-01-09 18:45:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:27 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:27 --> URI Class Initialized
INFO - 2017-01-09 18:45:27 --> Router Class Initialized
INFO - 2017-01-09 18:45:27 --> Output Class Initialized
INFO - 2017-01-09 18:45:27 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:27 --> Input Class Initialized
INFO - 2017-01-09 18:45:27 --> Language Class Initialized
INFO - 2017-01-09 18:45:27 --> Loader Class Initialized
INFO - 2017-01-09 18:45:27 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:27 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:27 --> Controller Class Initialized
INFO - 2017-01-09 18:45:27 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:27 --> Model Class Initialized
INFO - 2017-01-09 18:45:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:27 --> Config Class Initialized
INFO - 2017-01-09 18:45:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:27 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:27 --> URI Class Initialized
INFO - 2017-01-09 18:45:27 --> Router Class Initialized
INFO - 2017-01-09 18:45:27 --> Output Class Initialized
INFO - 2017-01-09 18:45:27 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:27 --> Input Class Initialized
INFO - 2017-01-09 18:45:27 --> Language Class Initialized
INFO - 2017-01-09 18:45:27 --> Loader Class Initialized
INFO - 2017-01-09 18:45:27 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:27 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:27 --> Controller Class Initialized
INFO - 2017-01-09 18:45:27 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:27 --> Model Class Initialized
INFO - 2017-01-09 18:45:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 18:45:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 18:45:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 18:45:27 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:27 --> Total execution time: 0.0890
INFO - 2017-01-09 18:45:36 --> Config Class Initialized
INFO - 2017-01-09 18:45:36 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:36 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:36 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:36 --> URI Class Initialized
INFO - 2017-01-09 18:45:36 --> Router Class Initialized
INFO - 2017-01-09 18:45:36 --> Output Class Initialized
INFO - 2017-01-09 18:45:36 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:36 --> Input Class Initialized
INFO - 2017-01-09 18:45:36 --> Language Class Initialized
INFO - 2017-01-09 18:45:36 --> Loader Class Initialized
INFO - 2017-01-09 18:45:36 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:36 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:36 --> Controller Class Initialized
INFO - 2017-01-09 18:45:36 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:36 --> Model Class Initialized
INFO - 2017-01-09 18:45:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:36 --> Config Class Initialized
INFO - 2017-01-09 18:45:36 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:36 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:36 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:36 --> URI Class Initialized
INFO - 2017-01-09 18:45:36 --> Router Class Initialized
INFO - 2017-01-09 18:45:36 --> Output Class Initialized
INFO - 2017-01-09 18:45:36 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:36 --> Input Class Initialized
INFO - 2017-01-09 18:45:36 --> Language Class Initialized
INFO - 2017-01-09 18:45:36 --> Loader Class Initialized
INFO - 2017-01-09 18:45:36 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:36 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:36 --> Controller Class Initialized
INFO - 2017-01-09 18:45:36 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:36 --> Model Class Initialized
INFO - 2017-01-09 18:45:36 --> Model Class Initialized
INFO - 2017-01-09 18:45:36 --> Model Class Initialized
INFO - 2017-01-09 18:45:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:45:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-09 18:45:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:45:36 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:36 --> Total execution time: 0.1247
INFO - 2017-01-09 18:45:42 --> Config Class Initialized
INFO - 2017-01-09 18:45:42 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:42 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:42 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:42 --> URI Class Initialized
INFO - 2017-01-09 18:45:42 --> Router Class Initialized
INFO - 2017-01-09 18:45:42 --> Output Class Initialized
INFO - 2017-01-09 18:45:42 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:42 --> Input Class Initialized
INFO - 2017-01-09 18:45:42 --> Language Class Initialized
INFO - 2017-01-09 18:45:42 --> Loader Class Initialized
INFO - 2017-01-09 18:45:42 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:42 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:42 --> Controller Class Initialized
INFO - 2017-01-09 18:45:42 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:42 --> Model Class Initialized
INFO - 2017-01-09 18:45:42 --> Model Class Initialized
INFO - 2017-01-09 18:45:42 --> Model Class Initialized
INFO - 2017-01-09 18:45:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:45:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-09 18:45:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:45:42 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:42 --> Total execution time: 0.1212
INFO - 2017-01-09 18:45:47 --> Config Class Initialized
INFO - 2017-01-09 18:45:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:47 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:47 --> URI Class Initialized
INFO - 2017-01-09 18:45:47 --> Router Class Initialized
INFO - 2017-01-09 18:45:47 --> Output Class Initialized
INFO - 2017-01-09 18:45:47 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:47 --> Input Class Initialized
INFO - 2017-01-09 18:45:47 --> Language Class Initialized
INFO - 2017-01-09 18:45:47 --> Loader Class Initialized
INFO - 2017-01-09 18:45:47 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:47 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:47 --> Controller Class Initialized
INFO - 2017-01-09 18:45:47 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:47 --> Model Class Initialized
INFO - 2017-01-09 18:45:47 --> Model Class Initialized
INFO - 2017-01-09 18:45:47 --> Model Class Initialized
INFO - 2017-01-09 18:45:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:47 --> Config Class Initialized
INFO - 2017-01-09 18:45:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:47 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:47 --> URI Class Initialized
INFO - 2017-01-09 18:45:47 --> Router Class Initialized
INFO - 2017-01-09 18:45:47 --> Output Class Initialized
INFO - 2017-01-09 18:45:47 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:47 --> Input Class Initialized
INFO - 2017-01-09 18:45:47 --> Language Class Initialized
INFO - 2017-01-09 18:45:47 --> Loader Class Initialized
INFO - 2017-01-09 18:45:47 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:47 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:47 --> Controller Class Initialized
INFO - 2017-01-09 18:45:47 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:47 --> Model Class Initialized
INFO - 2017-01-09 18:45:47 --> Model Class Initialized
INFO - 2017-01-09 18:45:47 --> Model Class Initialized
INFO - 2017-01-09 18:45:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:45:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-09 18:45:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:45:47 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:47 --> Total execution time: 0.1130
INFO - 2017-01-09 18:45:48 --> Config Class Initialized
INFO - 2017-01-09 18:45:48 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:45:48 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:48 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:48 --> URI Class Initialized
INFO - 2017-01-09 18:45:48 --> Router Class Initialized
INFO - 2017-01-09 18:45:48 --> Config Class Initialized
INFO - 2017-01-09 18:45:48 --> Hooks Class Initialized
INFO - 2017-01-09 18:45:48 --> Output Class Initialized
INFO - 2017-01-09 18:45:48 --> Security Class Initialized
DEBUG - 2017-01-09 18:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-09 18:45:48 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:45:48 --> Input Class Initialized
INFO - 2017-01-09 18:45:48 --> Utf8 Class Initialized
INFO - 2017-01-09 18:45:48 --> URI Class Initialized
INFO - 2017-01-09 18:45:48 --> Language Class Initialized
INFO - 2017-01-09 18:45:48 --> Router Class Initialized
INFO - 2017-01-09 18:45:48 --> Output Class Initialized
INFO - 2017-01-09 18:45:48 --> Loader Class Initialized
INFO - 2017-01-09 18:45:48 --> Security Class Initialized
INFO - 2017-01-09 18:45:48 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:48 --> Helper loaded: language_helper
DEBUG - 2017-01-09 18:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:45:48 --> Input Class Initialized
INFO - 2017-01-09 18:45:48 --> Language Class Initialized
INFO - 2017-01-09 18:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:48 --> Controller Class Initialized
INFO - 2017-01-09 18:45:48 --> Loader Class Initialized
INFO - 2017-01-09 18:45:48 --> Helper loaded: url_helper
INFO - 2017-01-09 18:45:48 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:48 --> Helper loaded: language_helper
INFO - 2017-01-09 18:45:48 --> Model Class Initialized
INFO - 2017-01-09 18:45:48 --> Model Class Initialized
INFO - 2017-01-09 18:45:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:45:48 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:48 --> Total execution time: 0.1317
INFO - 2017-01-09 18:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:45:48 --> Controller Class Initialized
INFO - 2017-01-09 18:45:48 --> Database Driver Class Initialized
INFO - 2017-01-09 18:45:48 --> Model Class Initialized
INFO - 2017-01-09 18:45:48 --> Model Class Initialized
INFO - 2017-01-09 18:45:48 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 18:45:48 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2017-01-09 18:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2017-01-09 18:45:48 --> Final output sent to browser
DEBUG - 2017-01-09 18:45:48 --> Total execution time: 0.1749
INFO - 2017-01-09 18:46:18 --> Config Class Initialized
INFO - 2017-01-09 18:46:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:46:18 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:46:18 --> Utf8 Class Initialized
INFO - 2017-01-09 18:46:18 --> URI Class Initialized
INFO - 2017-01-09 18:46:18 --> Router Class Initialized
INFO - 2017-01-09 18:46:18 --> Output Class Initialized
INFO - 2017-01-09 18:46:18 --> Security Class Initialized
DEBUG - 2017-01-09 18:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:46:18 --> Input Class Initialized
INFO - 2017-01-09 18:46:18 --> Language Class Initialized
INFO - 2017-01-09 18:46:18 --> Loader Class Initialized
INFO - 2017-01-09 18:46:18 --> Helper loaded: url_helper
INFO - 2017-01-09 18:46:18 --> Helper loaded: language_helper
INFO - 2017-01-09 18:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:46:18 --> Controller Class Initialized
INFO - 2017-01-09 18:46:18 --> Database Driver Class Initialized
INFO - 2017-01-09 18:46:18 --> Model Class Initialized
INFO - 2017-01-09 18:46:18 --> Model Class Initialized
INFO - 2017-01-09 18:46:18 --> Model Class Initialized
INFO - 2017-01-09 18:46:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:46:18 --> Final output sent to browser
DEBUG - 2017-01-09 18:46:18 --> Total execution time: 0.1084
INFO - 2017-01-09 18:46:48 --> Config Class Initialized
INFO - 2017-01-09 18:46:48 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:46:48 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:46:48 --> Utf8 Class Initialized
INFO - 2017-01-09 18:46:48 --> URI Class Initialized
INFO - 2017-01-09 18:46:48 --> Router Class Initialized
INFO - 2017-01-09 18:46:48 --> Output Class Initialized
INFO - 2017-01-09 18:46:48 --> Security Class Initialized
DEBUG - 2017-01-09 18:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:46:48 --> Input Class Initialized
INFO - 2017-01-09 18:46:48 --> Language Class Initialized
INFO - 2017-01-09 18:46:48 --> Loader Class Initialized
INFO - 2017-01-09 18:46:48 --> Helper loaded: url_helper
INFO - 2017-01-09 18:46:48 --> Helper loaded: language_helper
INFO - 2017-01-09 18:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:46:48 --> Controller Class Initialized
INFO - 2017-01-09 18:46:48 --> Database Driver Class Initialized
INFO - 2017-01-09 18:46:48 --> Model Class Initialized
INFO - 2017-01-09 18:46:48 --> Model Class Initialized
INFO - 2017-01-09 18:46:48 --> Model Class Initialized
INFO - 2017-01-09 18:46:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:46:48 --> Final output sent to browser
DEBUG - 2017-01-09 18:46:48 --> Total execution time: 0.0899
INFO - 2017-01-09 18:47:18 --> Config Class Initialized
INFO - 2017-01-09 18:47:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:47:18 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:47:18 --> Utf8 Class Initialized
INFO - 2017-01-09 18:47:18 --> URI Class Initialized
INFO - 2017-01-09 18:47:18 --> Router Class Initialized
INFO - 2017-01-09 18:47:18 --> Output Class Initialized
INFO - 2017-01-09 18:47:18 --> Security Class Initialized
DEBUG - 2017-01-09 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:47:18 --> Input Class Initialized
INFO - 2017-01-09 18:47:18 --> Language Class Initialized
INFO - 2017-01-09 18:47:18 --> Loader Class Initialized
INFO - 2017-01-09 18:47:18 --> Helper loaded: url_helper
INFO - 2017-01-09 18:47:18 --> Helper loaded: language_helper
INFO - 2017-01-09 18:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:47:18 --> Controller Class Initialized
INFO - 2017-01-09 18:47:18 --> Database Driver Class Initialized
INFO - 2017-01-09 18:47:18 --> Model Class Initialized
INFO - 2017-01-09 18:47:18 --> Model Class Initialized
INFO - 2017-01-09 18:47:18 --> Model Class Initialized
INFO - 2017-01-09 18:47:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:47:18 --> Final output sent to browser
DEBUG - 2017-01-09 18:47:18 --> Total execution time: 0.1098
INFO - 2017-01-09 18:47:30 --> Config Class Initialized
INFO - 2017-01-09 18:47:30 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:47:30 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:47:30 --> Utf8 Class Initialized
INFO - 2017-01-09 18:47:30 --> URI Class Initialized
INFO - 2017-01-09 18:47:30 --> Router Class Initialized
INFO - 2017-01-09 18:47:30 --> Output Class Initialized
INFO - 2017-01-09 18:47:30 --> Security Class Initialized
DEBUG - 2017-01-09 18:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:47:30 --> Input Class Initialized
INFO - 2017-01-09 18:47:30 --> Language Class Initialized
INFO - 2017-01-09 18:47:30 --> Loader Class Initialized
INFO - 2017-01-09 18:47:30 --> Helper loaded: url_helper
INFO - 2017-01-09 18:47:30 --> Helper loaded: language_helper
INFO - 2017-01-09 18:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:47:30 --> Controller Class Initialized
INFO - 2017-01-09 18:47:30 --> Database Driver Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:47:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:47:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-09 18:47:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:47:30 --> Final output sent to browser
DEBUG - 2017-01-09 18:47:30 --> Total execution time: 0.1280
INFO - 2017-01-09 18:47:30 --> Config Class Initialized
INFO - 2017-01-09 18:47:30 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:47:30 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:47:30 --> Utf8 Class Initialized
INFO - 2017-01-09 18:47:30 --> Config Class Initialized
INFO - 2017-01-09 18:47:30 --> Hooks Class Initialized
INFO - 2017-01-09 18:47:30 --> URI Class Initialized
INFO - 2017-01-09 18:47:30 --> Router Class Initialized
DEBUG - 2017-01-09 18:47:30 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:47:30 --> Utf8 Class Initialized
INFO - 2017-01-09 18:47:30 --> Output Class Initialized
INFO - 2017-01-09 18:47:30 --> URI Class Initialized
INFO - 2017-01-09 18:47:30 --> Security Class Initialized
INFO - 2017-01-09 18:47:30 --> Router Class Initialized
DEBUG - 2017-01-09 18:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:47:30 --> Input Class Initialized
INFO - 2017-01-09 18:47:30 --> Output Class Initialized
INFO - 2017-01-09 18:47:30 --> Language Class Initialized
INFO - 2017-01-09 18:47:30 --> Security Class Initialized
DEBUG - 2017-01-09 18:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:47:30 --> Input Class Initialized
INFO - 2017-01-09 18:47:30 --> Language Class Initialized
INFO - 2017-01-09 18:47:30 --> Loader Class Initialized
INFO - 2017-01-09 18:47:30 --> Helper loaded: url_helper
INFO - 2017-01-09 18:47:30 --> Loader Class Initialized
INFO - 2017-01-09 18:47:30 --> Helper loaded: language_helper
INFO - 2017-01-09 18:47:30 --> Helper loaded: url_helper
INFO - 2017-01-09 18:47:30 --> Helper loaded: language_helper
INFO - 2017-01-09 18:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:47:30 --> Controller Class Initialized
INFO - 2017-01-09 18:47:30 --> Database Driver Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:47:30 --> Final output sent to browser
DEBUG - 2017-01-09 18:47:30 --> Total execution time: 0.1375
INFO - 2017-01-09 18:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:47:30 --> Controller Class Initialized
INFO - 2017-01-09 18:47:30 --> Database Driver Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Model Class Initialized
INFO - 2017-01-09 18:47:30 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 18:47:30 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2017-01-09 18:47:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2017-01-09 18:47:30 --> Final output sent to browser
DEBUG - 2017-01-09 18:47:30 --> Total execution time: 0.2033
INFO - 2017-01-09 18:48:00 --> Config Class Initialized
INFO - 2017-01-09 18:48:00 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:00 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:00 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:00 --> URI Class Initialized
INFO - 2017-01-09 18:48:00 --> Router Class Initialized
INFO - 2017-01-09 18:48:00 --> Output Class Initialized
INFO - 2017-01-09 18:48:00 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:00 --> Input Class Initialized
INFO - 2017-01-09 18:48:00 --> Language Class Initialized
INFO - 2017-01-09 18:48:00 --> Loader Class Initialized
INFO - 2017-01-09 18:48:00 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:00 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:00 --> Controller Class Initialized
INFO - 2017-01-09 18:48:00 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:00 --> Model Class Initialized
INFO - 2017-01-09 18:48:00 --> Model Class Initialized
INFO - 2017-01-09 18:48:00 --> Model Class Initialized
INFO - 2017-01-09 18:48:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:00 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:00 --> Total execution time: 0.0959
INFO - 2017-01-09 18:48:19 --> Config Class Initialized
INFO - 2017-01-09 18:48:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:19 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:19 --> URI Class Initialized
INFO - 2017-01-09 18:48:19 --> Router Class Initialized
INFO - 2017-01-09 18:48:19 --> Output Class Initialized
INFO - 2017-01-09 18:48:19 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:19 --> Input Class Initialized
INFO - 2017-01-09 18:48:19 --> Language Class Initialized
INFO - 2017-01-09 18:48:19 --> Loader Class Initialized
INFO - 2017-01-09 18:48:19 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:19 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:19 --> Controller Class Initialized
INFO - 2017-01-09 18:48:19 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:19 --> Model Class Initialized
INFO - 2017-01-09 18:48:19 --> Model Class Initialized
INFO - 2017-01-09 18:48:19 --> Model Class Initialized
INFO - 2017-01-09 18:48:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:48:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-09 18:48:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:48:19 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:19 --> Total execution time: 0.1161
INFO - 2017-01-09 18:48:19 --> Config Class Initialized
INFO - 2017-01-09 18:48:19 --> Hooks Class Initialized
INFO - 2017-01-09 18:48:19 --> Config Class Initialized
INFO - 2017-01-09 18:48:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:19 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:19 --> URI Class Initialized
DEBUG - 2017-01-09 18:48:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:19 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:19 --> Router Class Initialized
INFO - 2017-01-09 18:48:19 --> URI Class Initialized
INFO - 2017-01-09 18:48:19 --> Output Class Initialized
INFO - 2017-01-09 18:48:19 --> Router Class Initialized
INFO - 2017-01-09 18:48:19 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:19 --> Input Class Initialized
INFO - 2017-01-09 18:48:19 --> Output Class Initialized
INFO - 2017-01-09 18:48:19 --> Language Class Initialized
INFO - 2017-01-09 18:48:19 --> Security Class Initialized
INFO - 2017-01-09 18:48:19 --> Loader Class Initialized
DEBUG - 2017-01-09 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:19 --> Input Class Initialized
INFO - 2017-01-09 18:48:19 --> Language Class Initialized
INFO - 2017-01-09 18:48:19 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:19 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:19 --> Loader Class Initialized
INFO - 2017-01-09 18:48:19 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:19 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:19 --> Controller Class Initialized
INFO - 2017-01-09 18:48:19 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:20 --> Model Class Initialized
INFO - 2017-01-09 18:48:20 --> Model Class Initialized
INFO - 2017-01-09 18:48:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:20 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:20 --> Total execution time: 0.1314
INFO - 2017-01-09 18:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:20 --> Controller Class Initialized
INFO - 2017-01-09 18:48:20 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:20 --> Model Class Initialized
INFO - 2017-01-09 18:48:20 --> Model Class Initialized
INFO - 2017-01-09 18:48:20 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 18:48:20 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
ERROR - 2017-01-09 18:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 596
INFO - 2017-01-09 18:48:20 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:20 --> Total execution time: 0.1837
INFO - 2017-01-09 18:48:24 --> Config Class Initialized
INFO - 2017-01-09 18:48:24 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:24 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:24 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:24 --> URI Class Initialized
INFO - 2017-01-09 18:48:24 --> Router Class Initialized
INFO - 2017-01-09 18:48:24 --> Output Class Initialized
INFO - 2017-01-09 18:48:24 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:24 --> Config Class Initialized
INFO - 2017-01-09 18:48:24 --> Hooks Class Initialized
INFO - 2017-01-09 18:48:24 --> Input Class Initialized
DEBUG - 2017-01-09 18:48:24 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:24 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:24 --> Language Class Initialized
INFO - 2017-01-09 18:48:24 --> URI Class Initialized
INFO - 2017-01-09 18:48:24 --> Loader Class Initialized
INFO - 2017-01-09 18:48:24 --> Router Class Initialized
INFO - 2017-01-09 18:48:24 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:24 --> Output Class Initialized
INFO - 2017-01-09 18:48:24 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:24 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:24 --> Input Class Initialized
INFO - 2017-01-09 18:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:24 --> Controller Class Initialized
INFO - 2017-01-09 18:48:24 --> Language Class Initialized
INFO - 2017-01-09 18:48:24 --> Loader Class Initialized
INFO - 2017-01-09 18:48:24 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:24 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:24 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:24 --> Model Class Initialized
INFO - 2017-01-09 18:48:24 --> Model Class Initialized
INFO - 2017-01-09 18:48:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:24 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:24 --> Total execution time: 0.1055
INFO - 2017-01-09 18:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:24 --> Controller Class Initialized
INFO - 2017-01-09 18:48:24 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:24 --> Model Class Initialized
INFO - 2017-01-09 18:48:24 --> Model Class Initialized
INFO - 2017-01-09 18:48:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:24 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:24 --> Total execution time: 0.1195
INFO - 2017-01-09 18:48:26 --> Config Class Initialized
INFO - 2017-01-09 18:48:26 --> Hooks Class Initialized
INFO - 2017-01-09 18:48:26 --> Config Class Initialized
INFO - 2017-01-09 18:48:26 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:26 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:26 --> Utf8 Class Initialized
DEBUG - 2017-01-09 18:48:26 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:26 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:26 --> URI Class Initialized
INFO - 2017-01-09 18:48:26 --> Router Class Initialized
INFO - 2017-01-09 18:48:26 --> Output Class Initialized
INFO - 2017-01-09 18:48:26 --> URI Class Initialized
INFO - 2017-01-09 18:48:26 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:26 --> Input Class Initialized
INFO - 2017-01-09 18:48:26 --> Router Class Initialized
INFO - 2017-01-09 18:48:26 --> Language Class Initialized
INFO - 2017-01-09 18:48:26 --> Output Class Initialized
INFO - 2017-01-09 18:48:26 --> Loader Class Initialized
INFO - 2017-01-09 18:48:26 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:26 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:26 --> Security Class Initialized
INFO - 2017-01-09 18:48:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-01-09 18:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:26 --> Controller Class Initialized
INFO - 2017-01-09 18:48:26 --> Input Class Initialized
INFO - 2017-01-09 18:48:26 --> Language Class Initialized
INFO - 2017-01-09 18:48:26 --> Loader Class Initialized
INFO - 2017-01-09 18:48:26 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:26 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:26 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:26 --> Model Class Initialized
INFO - 2017-01-09 18:48:26 --> Model Class Initialized
INFO - 2017-01-09 18:48:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:26 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:26 --> Total execution time: 0.1472
INFO - 2017-01-09 18:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:26 --> Controller Class Initialized
INFO - 2017-01-09 18:48:26 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:26 --> Model Class Initialized
INFO - 2017-01-09 18:48:26 --> Model Class Initialized
INFO - 2017-01-09 18:48:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:26 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:26 --> Total execution time: 0.2248
INFO - 2017-01-09 18:48:28 --> Config Class Initialized
INFO - 2017-01-09 18:48:28 --> Hooks Class Initialized
INFO - 2017-01-09 18:48:28 --> Config Class Initialized
INFO - 2017-01-09 18:48:28 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:28 --> UTF-8 Support Enabled
DEBUG - 2017-01-09 18:48:28 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:28 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:28 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:28 --> URI Class Initialized
INFO - 2017-01-09 18:48:28 --> Router Class Initialized
INFO - 2017-01-09 18:48:28 --> Output Class Initialized
INFO - 2017-01-09 18:48:28 --> Security Class Initialized
INFO - 2017-01-09 18:48:28 --> URI Class Initialized
DEBUG - 2017-01-09 18:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:28 --> Input Class Initialized
INFO - 2017-01-09 18:48:28 --> Language Class Initialized
INFO - 2017-01-09 18:48:28 --> Router Class Initialized
INFO - 2017-01-09 18:48:28 --> Output Class Initialized
INFO - 2017-01-09 18:48:28 --> Loader Class Initialized
INFO - 2017-01-09 18:48:28 --> Security Class Initialized
INFO - 2017-01-09 18:48:28 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:28 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:28 --> Controller Class Initialized
DEBUG - 2017-01-09 18:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:28 --> Input Class Initialized
INFO - 2017-01-09 18:48:28 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:28 --> Language Class Initialized
INFO - 2017-01-09 18:48:28 --> Model Class Initialized
INFO - 2017-01-09 18:48:28 --> Model Class Initialized
INFO - 2017-01-09 18:48:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:28 --> Loader Class Initialized
INFO - 2017-01-09 18:48:28 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:28 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:28 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:28 --> Total execution time: 0.1347
INFO - 2017-01-09 18:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:28 --> Controller Class Initialized
INFO - 2017-01-09 18:48:28 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:28 --> Model Class Initialized
INFO - 2017-01-09 18:48:28 --> Model Class Initialized
INFO - 2017-01-09 18:48:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:28 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:28 --> Total execution time: 0.1704
INFO - 2017-01-09 18:48:30 --> Config Class Initialized
INFO - 2017-01-09 18:48:30 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:30 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:30 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:30 --> URI Class Initialized
INFO - 2017-01-09 18:48:30 --> Config Class Initialized
INFO - 2017-01-09 18:48:30 --> Hooks Class Initialized
INFO - 2017-01-09 18:48:30 --> Router Class Initialized
DEBUG - 2017-01-09 18:48:30 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:30 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:30 --> Output Class Initialized
INFO - 2017-01-09 18:48:30 --> Security Class Initialized
INFO - 2017-01-09 18:48:30 --> URI Class Initialized
DEBUG - 2017-01-09 18:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:30 --> Input Class Initialized
INFO - 2017-01-09 18:48:30 --> Router Class Initialized
INFO - 2017-01-09 18:48:30 --> Language Class Initialized
INFO - 2017-01-09 18:48:30 --> Output Class Initialized
INFO - 2017-01-09 18:48:30 --> Security Class Initialized
INFO - 2017-01-09 18:48:30 --> Loader Class Initialized
DEBUG - 2017-01-09 18:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:30 --> Input Class Initialized
INFO - 2017-01-09 18:48:30 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:30 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:30 --> Language Class Initialized
INFO - 2017-01-09 18:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:30 --> Controller Class Initialized
INFO - 2017-01-09 18:48:30 --> Loader Class Initialized
INFO - 2017-01-09 18:48:30 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:30 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:30 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:30 --> Model Class Initialized
INFO - 2017-01-09 18:48:30 --> Model Class Initialized
INFO - 2017-01-09 18:48:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:30 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:30 --> Total execution time: 0.1042
INFO - 2017-01-09 18:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:30 --> Controller Class Initialized
INFO - 2017-01-09 18:48:30 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:30 --> Model Class Initialized
INFO - 2017-01-09 18:48:30 --> Model Class Initialized
INFO - 2017-01-09 18:48:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:30 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:30 --> Total execution time: 0.1811
INFO - 2017-01-09 18:48:49 --> Config Class Initialized
INFO - 2017-01-09 18:48:49 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:49 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:49 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:49 --> URI Class Initialized
INFO - 2017-01-09 18:48:49 --> Router Class Initialized
INFO - 2017-01-09 18:48:49 --> Output Class Initialized
INFO - 2017-01-09 18:48:49 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:49 --> Input Class Initialized
INFO - 2017-01-09 18:48:49 --> Language Class Initialized
INFO - 2017-01-09 18:48:49 --> Loader Class Initialized
INFO - 2017-01-09 18:48:49 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:49 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:49 --> Controller Class Initialized
INFO - 2017-01-09 18:48:49 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:49 --> Model Class Initialized
INFO - 2017-01-09 18:48:49 --> Model Class Initialized
INFO - 2017-01-09 18:48:49 --> Model Class Initialized
INFO - 2017-01-09 18:48:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:49 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:49 --> Total execution time: 0.0767
INFO - 2017-01-09 18:48:58 --> Config Class Initialized
INFO - 2017-01-09 18:48:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:58 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:58 --> URI Class Initialized
INFO - 2017-01-09 18:48:58 --> Router Class Initialized
INFO - 2017-01-09 18:48:58 --> Output Class Initialized
INFO - 2017-01-09 18:48:58 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:58 --> Input Class Initialized
INFO - 2017-01-09 18:48:58 --> Language Class Initialized
INFO - 2017-01-09 18:48:58 --> Loader Class Initialized
INFO - 2017-01-09 18:48:58 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:58 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:58 --> Controller Class Initialized
INFO - 2017-01-09 18:48:58 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 18:48:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-09 18:48:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 18:48:58 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:58 --> Total execution time: 0.1049
INFO - 2017-01-09 18:48:58 --> Config Class Initialized
INFO - 2017-01-09 18:48:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:48:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:58 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:58 --> URI Class Initialized
INFO - 2017-01-09 18:48:58 --> Config Class Initialized
INFO - 2017-01-09 18:48:58 --> Hooks Class Initialized
INFO - 2017-01-09 18:48:58 --> Router Class Initialized
DEBUG - 2017-01-09 18:48:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:48:58 --> Utf8 Class Initialized
INFO - 2017-01-09 18:48:58 --> Output Class Initialized
INFO - 2017-01-09 18:48:58 --> URI Class Initialized
INFO - 2017-01-09 18:48:58 --> Security Class Initialized
INFO - 2017-01-09 18:48:58 --> Router Class Initialized
DEBUG - 2017-01-09 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:58 --> Input Class Initialized
INFO - 2017-01-09 18:48:58 --> Output Class Initialized
INFO - 2017-01-09 18:48:58 --> Language Class Initialized
INFO - 2017-01-09 18:48:58 --> Security Class Initialized
DEBUG - 2017-01-09 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:48:58 --> Input Class Initialized
INFO - 2017-01-09 18:48:58 --> Language Class Initialized
INFO - 2017-01-09 18:48:58 --> Loader Class Initialized
INFO - 2017-01-09 18:48:58 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:58 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:58 --> Loader Class Initialized
INFO - 2017-01-09 18:48:58 --> Helper loaded: url_helper
INFO - 2017-01-09 18:48:58 --> Helper loaded: language_helper
INFO - 2017-01-09 18:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:58 --> Controller Class Initialized
INFO - 2017-01-09 18:48:58 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:58 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:58 --> Total execution time: 0.1277
INFO - 2017-01-09 18:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:48:58 --> Controller Class Initialized
INFO - 2017-01-09 18:48:58 --> Database Driver Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Model Class Initialized
INFO - 2017-01-09 18:48:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:48:58 --> Final output sent to browser
DEBUG - 2017-01-09 18:48:58 --> Total execution time: 0.1885
INFO - 2017-01-09 18:49:29 --> Config Class Initialized
INFO - 2017-01-09 18:49:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:49:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:49:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:49:29 --> URI Class Initialized
INFO - 2017-01-09 18:49:29 --> Router Class Initialized
INFO - 2017-01-09 18:49:29 --> Output Class Initialized
INFO - 2017-01-09 18:49:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:49:29 --> Input Class Initialized
INFO - 2017-01-09 18:49:29 --> Language Class Initialized
INFO - 2017-01-09 18:49:29 --> Loader Class Initialized
INFO - 2017-01-09 18:49:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:49:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:49:29 --> Controller Class Initialized
INFO - 2017-01-09 18:49:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:49:29 --> Model Class Initialized
INFO - 2017-01-09 18:49:29 --> Model Class Initialized
INFO - 2017-01-09 18:49:29 --> Model Class Initialized
INFO - 2017-01-09 18:49:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:49:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:49:29 --> Total execution time: 0.0768
INFO - 2017-01-09 18:49:59 --> Config Class Initialized
INFO - 2017-01-09 18:49:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:49:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:49:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:49:59 --> URI Class Initialized
INFO - 2017-01-09 18:49:59 --> Router Class Initialized
INFO - 2017-01-09 18:49:59 --> Output Class Initialized
INFO - 2017-01-09 18:49:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:49:59 --> Input Class Initialized
INFO - 2017-01-09 18:49:59 --> Language Class Initialized
INFO - 2017-01-09 18:49:59 --> Loader Class Initialized
INFO - 2017-01-09 18:49:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:49:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:49:59 --> Controller Class Initialized
INFO - 2017-01-09 18:49:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:49:59 --> Model Class Initialized
INFO - 2017-01-09 18:49:59 --> Model Class Initialized
INFO - 2017-01-09 18:49:59 --> Model Class Initialized
INFO - 2017-01-09 18:49:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:49:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:49:59 --> Total execution time: 0.0834
INFO - 2017-01-09 18:50:29 --> Config Class Initialized
INFO - 2017-01-09 18:50:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:50:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:50:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:50:29 --> URI Class Initialized
INFO - 2017-01-09 18:50:29 --> Router Class Initialized
INFO - 2017-01-09 18:50:29 --> Output Class Initialized
INFO - 2017-01-09 18:50:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:50:29 --> Input Class Initialized
INFO - 2017-01-09 18:50:29 --> Language Class Initialized
INFO - 2017-01-09 18:50:29 --> Loader Class Initialized
INFO - 2017-01-09 18:50:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:50:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:50:29 --> Controller Class Initialized
INFO - 2017-01-09 18:50:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:50:29 --> Model Class Initialized
INFO - 2017-01-09 18:50:29 --> Model Class Initialized
INFO - 2017-01-09 18:50:29 --> Model Class Initialized
INFO - 2017-01-09 18:50:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:50:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:50:29 --> Total execution time: 0.0737
INFO - 2017-01-09 18:50:59 --> Config Class Initialized
INFO - 2017-01-09 18:50:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:50:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:50:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:50:59 --> URI Class Initialized
INFO - 2017-01-09 18:50:59 --> Router Class Initialized
INFO - 2017-01-09 18:50:59 --> Output Class Initialized
INFO - 2017-01-09 18:50:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:50:59 --> Input Class Initialized
INFO - 2017-01-09 18:50:59 --> Language Class Initialized
INFO - 2017-01-09 18:50:59 --> Loader Class Initialized
INFO - 2017-01-09 18:50:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:50:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:50:59 --> Controller Class Initialized
INFO - 2017-01-09 18:50:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:50:59 --> Model Class Initialized
INFO - 2017-01-09 18:50:59 --> Model Class Initialized
INFO - 2017-01-09 18:50:59 --> Model Class Initialized
INFO - 2017-01-09 18:50:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:50:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:50:59 --> Total execution time: 0.0799
INFO - 2017-01-09 18:51:29 --> Config Class Initialized
INFO - 2017-01-09 18:51:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:51:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:51:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:51:29 --> URI Class Initialized
INFO - 2017-01-09 18:51:29 --> Router Class Initialized
INFO - 2017-01-09 18:51:29 --> Output Class Initialized
INFO - 2017-01-09 18:51:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:51:29 --> Input Class Initialized
INFO - 2017-01-09 18:51:29 --> Language Class Initialized
INFO - 2017-01-09 18:51:29 --> Loader Class Initialized
INFO - 2017-01-09 18:51:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:51:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:51:29 --> Controller Class Initialized
INFO - 2017-01-09 18:51:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:51:29 --> Model Class Initialized
INFO - 2017-01-09 18:51:29 --> Model Class Initialized
INFO - 2017-01-09 18:51:29 --> Model Class Initialized
INFO - 2017-01-09 18:51:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:51:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:51:29 --> Total execution time: 0.1147
INFO - 2017-01-09 18:51:59 --> Config Class Initialized
INFO - 2017-01-09 18:51:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:51:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:51:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:51:59 --> URI Class Initialized
INFO - 2017-01-09 18:51:59 --> Router Class Initialized
INFO - 2017-01-09 18:51:59 --> Output Class Initialized
INFO - 2017-01-09 18:51:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:51:59 --> Input Class Initialized
INFO - 2017-01-09 18:51:59 --> Language Class Initialized
INFO - 2017-01-09 18:51:59 --> Loader Class Initialized
INFO - 2017-01-09 18:51:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:51:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:51:59 --> Controller Class Initialized
INFO - 2017-01-09 18:51:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:51:59 --> Model Class Initialized
INFO - 2017-01-09 18:51:59 --> Model Class Initialized
INFO - 2017-01-09 18:51:59 --> Model Class Initialized
INFO - 2017-01-09 18:51:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:51:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:51:59 --> Total execution time: 0.0800
INFO - 2017-01-09 18:52:29 --> Config Class Initialized
INFO - 2017-01-09 18:52:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:52:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:52:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:52:29 --> URI Class Initialized
INFO - 2017-01-09 18:52:29 --> Router Class Initialized
INFO - 2017-01-09 18:52:29 --> Output Class Initialized
INFO - 2017-01-09 18:52:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:52:29 --> Input Class Initialized
INFO - 2017-01-09 18:52:29 --> Language Class Initialized
INFO - 2017-01-09 18:52:29 --> Loader Class Initialized
INFO - 2017-01-09 18:52:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:52:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:52:29 --> Controller Class Initialized
INFO - 2017-01-09 18:52:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:52:29 --> Model Class Initialized
INFO - 2017-01-09 18:52:29 --> Model Class Initialized
INFO - 2017-01-09 18:52:29 --> Model Class Initialized
INFO - 2017-01-09 18:52:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:52:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:52:29 --> Total execution time: 0.1660
INFO - 2017-01-09 18:52:59 --> Config Class Initialized
INFO - 2017-01-09 18:52:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:52:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:52:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:52:59 --> URI Class Initialized
INFO - 2017-01-09 18:52:59 --> Router Class Initialized
INFO - 2017-01-09 18:52:59 --> Output Class Initialized
INFO - 2017-01-09 18:52:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:52:59 --> Input Class Initialized
INFO - 2017-01-09 18:52:59 --> Language Class Initialized
INFO - 2017-01-09 18:52:59 --> Loader Class Initialized
INFO - 2017-01-09 18:52:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:52:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:52:59 --> Controller Class Initialized
INFO - 2017-01-09 18:52:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:52:59 --> Model Class Initialized
INFO - 2017-01-09 18:52:59 --> Model Class Initialized
INFO - 2017-01-09 18:52:59 --> Model Class Initialized
INFO - 2017-01-09 18:52:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:52:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:52:59 --> Total execution time: 0.1225
INFO - 2017-01-09 18:53:29 --> Config Class Initialized
INFO - 2017-01-09 18:53:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:53:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:53:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:53:29 --> URI Class Initialized
INFO - 2017-01-09 18:53:29 --> Router Class Initialized
INFO - 2017-01-09 18:53:29 --> Output Class Initialized
INFO - 2017-01-09 18:53:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:53:29 --> Input Class Initialized
INFO - 2017-01-09 18:53:29 --> Language Class Initialized
INFO - 2017-01-09 18:53:29 --> Loader Class Initialized
INFO - 2017-01-09 18:53:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:53:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:53:29 --> Controller Class Initialized
INFO - 2017-01-09 18:53:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:53:29 --> Model Class Initialized
INFO - 2017-01-09 18:53:29 --> Model Class Initialized
INFO - 2017-01-09 18:53:29 --> Model Class Initialized
INFO - 2017-01-09 18:53:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:53:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:53:29 --> Total execution time: 0.0959
INFO - 2017-01-09 18:53:59 --> Config Class Initialized
INFO - 2017-01-09 18:53:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:53:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:53:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:53:59 --> URI Class Initialized
INFO - 2017-01-09 18:53:59 --> Router Class Initialized
INFO - 2017-01-09 18:53:59 --> Output Class Initialized
INFO - 2017-01-09 18:53:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:53:59 --> Input Class Initialized
INFO - 2017-01-09 18:53:59 --> Language Class Initialized
INFO - 2017-01-09 18:53:59 --> Loader Class Initialized
INFO - 2017-01-09 18:53:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:53:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:53:59 --> Controller Class Initialized
INFO - 2017-01-09 18:53:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:53:59 --> Model Class Initialized
INFO - 2017-01-09 18:53:59 --> Model Class Initialized
INFO - 2017-01-09 18:53:59 --> Model Class Initialized
INFO - 2017-01-09 18:53:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:53:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:53:59 --> Total execution time: 0.0742
INFO - 2017-01-09 18:54:29 --> Config Class Initialized
INFO - 2017-01-09 18:54:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:54:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:54:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:54:29 --> URI Class Initialized
INFO - 2017-01-09 18:54:29 --> Router Class Initialized
INFO - 2017-01-09 18:54:29 --> Output Class Initialized
INFO - 2017-01-09 18:54:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:54:29 --> Input Class Initialized
INFO - 2017-01-09 18:54:29 --> Language Class Initialized
INFO - 2017-01-09 18:54:29 --> Loader Class Initialized
INFO - 2017-01-09 18:54:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:54:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:54:29 --> Controller Class Initialized
INFO - 2017-01-09 18:54:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:54:29 --> Model Class Initialized
INFO - 2017-01-09 18:54:29 --> Model Class Initialized
INFO - 2017-01-09 18:54:29 --> Model Class Initialized
INFO - 2017-01-09 18:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:54:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:54:29 --> Total execution time: 0.0813
INFO - 2017-01-09 18:54:59 --> Config Class Initialized
INFO - 2017-01-09 18:54:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:54:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:54:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:54:59 --> URI Class Initialized
INFO - 2017-01-09 18:54:59 --> Router Class Initialized
INFO - 2017-01-09 18:54:59 --> Output Class Initialized
INFO - 2017-01-09 18:54:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:54:59 --> Input Class Initialized
INFO - 2017-01-09 18:54:59 --> Language Class Initialized
INFO - 2017-01-09 18:54:59 --> Loader Class Initialized
INFO - 2017-01-09 18:54:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:54:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:54:59 --> Controller Class Initialized
INFO - 2017-01-09 18:54:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:54:59 --> Model Class Initialized
INFO - 2017-01-09 18:54:59 --> Model Class Initialized
INFO - 2017-01-09 18:54:59 --> Model Class Initialized
INFO - 2017-01-09 18:54:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:54:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:54:59 --> Total execution time: 0.0812
INFO - 2017-01-09 18:55:29 --> Config Class Initialized
INFO - 2017-01-09 18:55:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:55:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:55:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:55:29 --> URI Class Initialized
INFO - 2017-01-09 18:55:29 --> Router Class Initialized
INFO - 2017-01-09 18:55:29 --> Output Class Initialized
INFO - 2017-01-09 18:55:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:55:29 --> Input Class Initialized
INFO - 2017-01-09 18:55:29 --> Language Class Initialized
INFO - 2017-01-09 18:55:29 --> Loader Class Initialized
INFO - 2017-01-09 18:55:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:55:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:55:29 --> Controller Class Initialized
INFO - 2017-01-09 18:55:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:55:29 --> Model Class Initialized
INFO - 2017-01-09 18:55:29 --> Model Class Initialized
INFO - 2017-01-09 18:55:29 --> Model Class Initialized
INFO - 2017-01-09 18:55:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:55:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:55:29 --> Total execution time: 0.0795
INFO - 2017-01-09 18:55:59 --> Config Class Initialized
INFO - 2017-01-09 18:55:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:55:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:55:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:55:59 --> URI Class Initialized
INFO - 2017-01-09 18:55:59 --> Router Class Initialized
INFO - 2017-01-09 18:55:59 --> Output Class Initialized
INFO - 2017-01-09 18:55:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:55:59 --> Input Class Initialized
INFO - 2017-01-09 18:55:59 --> Language Class Initialized
INFO - 2017-01-09 18:55:59 --> Loader Class Initialized
INFO - 2017-01-09 18:55:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:55:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:55:59 --> Controller Class Initialized
INFO - 2017-01-09 18:55:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:55:59 --> Model Class Initialized
INFO - 2017-01-09 18:55:59 --> Model Class Initialized
INFO - 2017-01-09 18:55:59 --> Model Class Initialized
INFO - 2017-01-09 18:55:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:55:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:55:59 --> Total execution time: 0.0811
INFO - 2017-01-09 18:56:29 --> Config Class Initialized
INFO - 2017-01-09 18:56:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:56:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:56:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:56:29 --> URI Class Initialized
INFO - 2017-01-09 18:56:29 --> Router Class Initialized
INFO - 2017-01-09 18:56:29 --> Output Class Initialized
INFO - 2017-01-09 18:56:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:56:29 --> Input Class Initialized
INFO - 2017-01-09 18:56:29 --> Language Class Initialized
INFO - 2017-01-09 18:56:29 --> Loader Class Initialized
INFO - 2017-01-09 18:56:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:56:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:56:29 --> Controller Class Initialized
INFO - 2017-01-09 18:56:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:56:29 --> Model Class Initialized
INFO - 2017-01-09 18:56:29 --> Model Class Initialized
INFO - 2017-01-09 18:56:29 --> Model Class Initialized
INFO - 2017-01-09 18:56:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:56:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:56:29 --> Total execution time: 0.0814
INFO - 2017-01-09 18:56:59 --> Config Class Initialized
INFO - 2017-01-09 18:56:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:56:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:56:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:56:59 --> URI Class Initialized
INFO - 2017-01-09 18:56:59 --> Router Class Initialized
INFO - 2017-01-09 18:56:59 --> Output Class Initialized
INFO - 2017-01-09 18:56:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:56:59 --> Input Class Initialized
INFO - 2017-01-09 18:56:59 --> Language Class Initialized
INFO - 2017-01-09 18:56:59 --> Loader Class Initialized
INFO - 2017-01-09 18:56:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:56:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:56:59 --> Controller Class Initialized
INFO - 2017-01-09 18:56:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:56:59 --> Model Class Initialized
INFO - 2017-01-09 18:56:59 --> Model Class Initialized
INFO - 2017-01-09 18:56:59 --> Model Class Initialized
INFO - 2017-01-09 18:56:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:56:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:56:59 --> Total execution time: 0.0726
INFO - 2017-01-09 18:57:29 --> Config Class Initialized
INFO - 2017-01-09 18:57:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:57:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:57:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:57:29 --> URI Class Initialized
INFO - 2017-01-09 18:57:29 --> Router Class Initialized
INFO - 2017-01-09 18:57:29 --> Output Class Initialized
INFO - 2017-01-09 18:57:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:57:29 --> Input Class Initialized
INFO - 2017-01-09 18:57:29 --> Language Class Initialized
INFO - 2017-01-09 18:57:29 --> Loader Class Initialized
INFO - 2017-01-09 18:57:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:57:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:57:29 --> Controller Class Initialized
INFO - 2017-01-09 18:57:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:57:29 --> Model Class Initialized
INFO - 2017-01-09 18:57:29 --> Model Class Initialized
INFO - 2017-01-09 18:57:29 --> Model Class Initialized
INFO - 2017-01-09 18:57:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:57:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:57:29 --> Total execution time: 0.1649
INFO - 2017-01-09 18:57:59 --> Config Class Initialized
INFO - 2017-01-09 18:57:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:57:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:57:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:57:59 --> URI Class Initialized
INFO - 2017-01-09 18:57:59 --> Router Class Initialized
INFO - 2017-01-09 18:57:59 --> Output Class Initialized
INFO - 2017-01-09 18:57:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:57:59 --> Input Class Initialized
INFO - 2017-01-09 18:57:59 --> Language Class Initialized
INFO - 2017-01-09 18:57:59 --> Loader Class Initialized
INFO - 2017-01-09 18:57:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:57:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:57:59 --> Controller Class Initialized
INFO - 2017-01-09 18:57:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:57:59 --> Model Class Initialized
INFO - 2017-01-09 18:57:59 --> Model Class Initialized
INFO - 2017-01-09 18:57:59 --> Model Class Initialized
INFO - 2017-01-09 18:57:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:57:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:57:59 --> Total execution time: 0.0758
INFO - 2017-01-09 18:58:29 --> Config Class Initialized
INFO - 2017-01-09 18:58:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:58:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:58:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:58:29 --> URI Class Initialized
INFO - 2017-01-09 18:58:29 --> Router Class Initialized
INFO - 2017-01-09 18:58:29 --> Output Class Initialized
INFO - 2017-01-09 18:58:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:58:29 --> Input Class Initialized
INFO - 2017-01-09 18:58:29 --> Language Class Initialized
INFO - 2017-01-09 18:58:29 --> Loader Class Initialized
INFO - 2017-01-09 18:58:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:58:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:58:29 --> Controller Class Initialized
INFO - 2017-01-09 18:58:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:58:29 --> Model Class Initialized
INFO - 2017-01-09 18:58:29 --> Model Class Initialized
INFO - 2017-01-09 18:58:29 --> Model Class Initialized
INFO - 2017-01-09 18:58:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:58:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:58:29 --> Total execution time: 0.0899
INFO - 2017-01-09 18:58:59 --> Config Class Initialized
INFO - 2017-01-09 18:58:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:58:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:58:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:58:59 --> URI Class Initialized
INFO - 2017-01-09 18:58:59 --> Router Class Initialized
INFO - 2017-01-09 18:58:59 --> Output Class Initialized
INFO - 2017-01-09 18:58:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:58:59 --> Input Class Initialized
INFO - 2017-01-09 18:58:59 --> Language Class Initialized
INFO - 2017-01-09 18:58:59 --> Loader Class Initialized
INFO - 2017-01-09 18:58:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:58:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:58:59 --> Controller Class Initialized
INFO - 2017-01-09 18:58:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:58:59 --> Model Class Initialized
INFO - 2017-01-09 18:58:59 --> Model Class Initialized
INFO - 2017-01-09 18:58:59 --> Model Class Initialized
INFO - 2017-01-09 18:58:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:58:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:58:59 --> Total execution time: 0.0733
INFO - 2017-01-09 18:59:29 --> Config Class Initialized
INFO - 2017-01-09 18:59:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:59:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:59:29 --> Utf8 Class Initialized
INFO - 2017-01-09 18:59:29 --> URI Class Initialized
INFO - 2017-01-09 18:59:29 --> Router Class Initialized
INFO - 2017-01-09 18:59:29 --> Output Class Initialized
INFO - 2017-01-09 18:59:29 --> Security Class Initialized
DEBUG - 2017-01-09 18:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:59:29 --> Input Class Initialized
INFO - 2017-01-09 18:59:29 --> Language Class Initialized
INFO - 2017-01-09 18:59:29 --> Loader Class Initialized
INFO - 2017-01-09 18:59:29 --> Helper loaded: url_helper
INFO - 2017-01-09 18:59:29 --> Helper loaded: language_helper
INFO - 2017-01-09 18:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:59:29 --> Controller Class Initialized
INFO - 2017-01-09 18:59:29 --> Database Driver Class Initialized
INFO - 2017-01-09 18:59:29 --> Model Class Initialized
INFO - 2017-01-09 18:59:29 --> Model Class Initialized
INFO - 2017-01-09 18:59:29 --> Model Class Initialized
INFO - 2017-01-09 18:59:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:59:29 --> Final output sent to browser
DEBUG - 2017-01-09 18:59:29 --> Total execution time: 0.0749
INFO - 2017-01-09 18:59:59 --> Config Class Initialized
INFO - 2017-01-09 18:59:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:59:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:59:59 --> Utf8 Class Initialized
INFO - 2017-01-09 18:59:59 --> URI Class Initialized
INFO - 2017-01-09 18:59:59 --> Router Class Initialized
INFO - 2017-01-09 18:59:59 --> Output Class Initialized
INFO - 2017-01-09 18:59:59 --> Security Class Initialized
DEBUG - 2017-01-09 18:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:59:59 --> Input Class Initialized
INFO - 2017-01-09 18:59:59 --> Language Class Initialized
INFO - 2017-01-09 18:59:59 --> Loader Class Initialized
INFO - 2017-01-09 18:59:59 --> Helper loaded: url_helper
INFO - 2017-01-09 18:59:59 --> Helper loaded: language_helper
INFO - 2017-01-09 18:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:59:59 --> Controller Class Initialized
INFO - 2017-01-09 18:59:59 --> Database Driver Class Initialized
INFO - 2017-01-09 18:59:59 --> Model Class Initialized
INFO - 2017-01-09 18:59:59 --> Model Class Initialized
INFO - 2017-01-09 18:59:59 --> Model Class Initialized
INFO - 2017-01-09 18:59:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 18:59:59 --> Final output sent to browser
DEBUG - 2017-01-09 18:59:59 --> Total execution time: 0.0938
INFO - 2017-01-09 19:00:29 --> Config Class Initialized
INFO - 2017-01-09 19:00:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:00:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:00:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:00:29 --> URI Class Initialized
INFO - 2017-01-09 19:00:29 --> Router Class Initialized
INFO - 2017-01-09 19:00:29 --> Output Class Initialized
INFO - 2017-01-09 19:00:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:00:29 --> Input Class Initialized
INFO - 2017-01-09 19:00:29 --> Language Class Initialized
INFO - 2017-01-09 19:00:29 --> Loader Class Initialized
INFO - 2017-01-09 19:00:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:00:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:00:29 --> Controller Class Initialized
INFO - 2017-01-09 19:00:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:00:29 --> Model Class Initialized
INFO - 2017-01-09 19:00:29 --> Model Class Initialized
INFO - 2017-01-09 19:00:29 --> Model Class Initialized
INFO - 2017-01-09 19:00:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:00:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:00:29 --> Total execution time: 0.0917
INFO - 2017-01-09 19:00:59 --> Config Class Initialized
INFO - 2017-01-09 19:00:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:00:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:00:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:00:59 --> URI Class Initialized
INFO - 2017-01-09 19:00:59 --> Router Class Initialized
INFO - 2017-01-09 19:00:59 --> Output Class Initialized
INFO - 2017-01-09 19:00:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:00:59 --> Input Class Initialized
INFO - 2017-01-09 19:00:59 --> Language Class Initialized
INFO - 2017-01-09 19:00:59 --> Loader Class Initialized
INFO - 2017-01-09 19:00:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:00:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:00:59 --> Controller Class Initialized
INFO - 2017-01-09 19:00:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:00:59 --> Model Class Initialized
INFO - 2017-01-09 19:00:59 --> Model Class Initialized
INFO - 2017-01-09 19:00:59 --> Model Class Initialized
INFO - 2017-01-09 19:00:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:00:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:00:59 --> Total execution time: 0.0792
INFO - 2017-01-09 19:01:29 --> Config Class Initialized
INFO - 2017-01-09 19:01:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:01:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:01:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:01:29 --> URI Class Initialized
INFO - 2017-01-09 19:01:29 --> Router Class Initialized
INFO - 2017-01-09 19:01:29 --> Output Class Initialized
INFO - 2017-01-09 19:01:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:01:29 --> Input Class Initialized
INFO - 2017-01-09 19:01:29 --> Language Class Initialized
INFO - 2017-01-09 19:01:29 --> Loader Class Initialized
INFO - 2017-01-09 19:01:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:01:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:01:29 --> Controller Class Initialized
INFO - 2017-01-09 19:01:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:01:29 --> Model Class Initialized
INFO - 2017-01-09 19:01:29 --> Model Class Initialized
INFO - 2017-01-09 19:01:29 --> Model Class Initialized
INFO - 2017-01-09 19:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:01:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:01:29 --> Total execution time: 0.0740
INFO - 2017-01-09 19:01:59 --> Config Class Initialized
INFO - 2017-01-09 19:01:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:01:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:01:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:01:59 --> URI Class Initialized
INFO - 2017-01-09 19:01:59 --> Router Class Initialized
INFO - 2017-01-09 19:01:59 --> Output Class Initialized
INFO - 2017-01-09 19:01:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:01:59 --> Input Class Initialized
INFO - 2017-01-09 19:01:59 --> Language Class Initialized
INFO - 2017-01-09 19:01:59 --> Loader Class Initialized
INFO - 2017-01-09 19:01:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:01:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:01:59 --> Controller Class Initialized
INFO - 2017-01-09 19:01:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:01:59 --> Model Class Initialized
INFO - 2017-01-09 19:01:59 --> Model Class Initialized
INFO - 2017-01-09 19:01:59 --> Model Class Initialized
INFO - 2017-01-09 19:01:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:01:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:01:59 --> Total execution time: 0.0778
INFO - 2017-01-09 19:02:29 --> Config Class Initialized
INFO - 2017-01-09 19:02:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:02:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:02:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:02:29 --> URI Class Initialized
INFO - 2017-01-09 19:02:29 --> Router Class Initialized
INFO - 2017-01-09 19:02:29 --> Output Class Initialized
INFO - 2017-01-09 19:02:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:02:29 --> Input Class Initialized
INFO - 2017-01-09 19:02:29 --> Language Class Initialized
INFO - 2017-01-09 19:02:29 --> Loader Class Initialized
INFO - 2017-01-09 19:02:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:02:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:02:29 --> Controller Class Initialized
INFO - 2017-01-09 19:02:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:02:29 --> Model Class Initialized
INFO - 2017-01-09 19:02:29 --> Model Class Initialized
INFO - 2017-01-09 19:02:29 --> Model Class Initialized
INFO - 2017-01-09 19:02:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:02:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:02:29 --> Total execution time: 0.0837
INFO - 2017-01-09 19:02:59 --> Config Class Initialized
INFO - 2017-01-09 19:02:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:02:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:02:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:02:59 --> URI Class Initialized
INFO - 2017-01-09 19:02:59 --> Router Class Initialized
INFO - 2017-01-09 19:02:59 --> Output Class Initialized
INFO - 2017-01-09 19:02:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:02:59 --> Input Class Initialized
INFO - 2017-01-09 19:02:59 --> Language Class Initialized
INFO - 2017-01-09 19:02:59 --> Loader Class Initialized
INFO - 2017-01-09 19:02:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:02:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:02:59 --> Controller Class Initialized
INFO - 2017-01-09 19:02:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:02:59 --> Model Class Initialized
INFO - 2017-01-09 19:02:59 --> Model Class Initialized
INFO - 2017-01-09 19:02:59 --> Model Class Initialized
INFO - 2017-01-09 19:02:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:02:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:02:59 --> Total execution time: 0.0981
INFO - 2017-01-09 19:03:29 --> Config Class Initialized
INFO - 2017-01-09 19:03:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:03:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:03:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:03:29 --> URI Class Initialized
INFO - 2017-01-09 19:03:29 --> Router Class Initialized
INFO - 2017-01-09 19:03:29 --> Output Class Initialized
INFO - 2017-01-09 19:03:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:03:29 --> Input Class Initialized
INFO - 2017-01-09 19:03:29 --> Language Class Initialized
INFO - 2017-01-09 19:03:29 --> Loader Class Initialized
INFO - 2017-01-09 19:03:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:03:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:03:29 --> Controller Class Initialized
INFO - 2017-01-09 19:03:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:03:29 --> Model Class Initialized
INFO - 2017-01-09 19:03:29 --> Model Class Initialized
INFO - 2017-01-09 19:03:29 --> Model Class Initialized
INFO - 2017-01-09 19:03:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:03:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:03:29 --> Total execution time: 0.0723
INFO - 2017-01-09 19:03:59 --> Config Class Initialized
INFO - 2017-01-09 19:03:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:03:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:03:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:03:59 --> URI Class Initialized
INFO - 2017-01-09 19:03:59 --> Router Class Initialized
INFO - 2017-01-09 19:03:59 --> Output Class Initialized
INFO - 2017-01-09 19:03:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:03:59 --> Input Class Initialized
INFO - 2017-01-09 19:03:59 --> Language Class Initialized
INFO - 2017-01-09 19:03:59 --> Loader Class Initialized
INFO - 2017-01-09 19:03:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:03:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:03:59 --> Controller Class Initialized
INFO - 2017-01-09 19:03:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:03:59 --> Model Class Initialized
INFO - 2017-01-09 19:03:59 --> Model Class Initialized
INFO - 2017-01-09 19:03:59 --> Model Class Initialized
INFO - 2017-01-09 19:03:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:03:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:03:59 --> Total execution time: 0.1776
INFO - 2017-01-09 19:04:29 --> Config Class Initialized
INFO - 2017-01-09 19:04:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:04:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:04:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:04:29 --> URI Class Initialized
INFO - 2017-01-09 19:04:29 --> Router Class Initialized
INFO - 2017-01-09 19:04:29 --> Output Class Initialized
INFO - 2017-01-09 19:04:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:04:29 --> Input Class Initialized
INFO - 2017-01-09 19:04:29 --> Language Class Initialized
INFO - 2017-01-09 19:04:29 --> Loader Class Initialized
INFO - 2017-01-09 19:04:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:04:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:04:29 --> Controller Class Initialized
INFO - 2017-01-09 19:04:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:04:29 --> Model Class Initialized
INFO - 2017-01-09 19:04:29 --> Model Class Initialized
INFO - 2017-01-09 19:04:29 --> Model Class Initialized
INFO - 2017-01-09 19:04:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:04:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:04:29 --> Total execution time: 0.0879
INFO - 2017-01-09 19:04:59 --> Config Class Initialized
INFO - 2017-01-09 19:04:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:04:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:04:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:04:59 --> URI Class Initialized
INFO - 2017-01-09 19:04:59 --> Router Class Initialized
INFO - 2017-01-09 19:04:59 --> Output Class Initialized
INFO - 2017-01-09 19:04:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:04:59 --> Input Class Initialized
INFO - 2017-01-09 19:04:59 --> Language Class Initialized
INFO - 2017-01-09 19:04:59 --> Loader Class Initialized
INFO - 2017-01-09 19:04:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:04:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:04:59 --> Controller Class Initialized
INFO - 2017-01-09 19:04:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:04:59 --> Model Class Initialized
INFO - 2017-01-09 19:04:59 --> Model Class Initialized
INFO - 2017-01-09 19:04:59 --> Model Class Initialized
INFO - 2017-01-09 19:04:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:04:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:04:59 --> Total execution time: 0.0840
INFO - 2017-01-09 19:05:29 --> Config Class Initialized
INFO - 2017-01-09 19:05:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:05:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:05:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:05:29 --> URI Class Initialized
INFO - 2017-01-09 19:05:29 --> Router Class Initialized
INFO - 2017-01-09 19:05:29 --> Output Class Initialized
INFO - 2017-01-09 19:05:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:05:29 --> Input Class Initialized
INFO - 2017-01-09 19:05:29 --> Language Class Initialized
INFO - 2017-01-09 19:05:29 --> Loader Class Initialized
INFO - 2017-01-09 19:05:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:05:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:05:29 --> Controller Class Initialized
INFO - 2017-01-09 19:05:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:05:29 --> Model Class Initialized
INFO - 2017-01-09 19:05:29 --> Model Class Initialized
INFO - 2017-01-09 19:05:29 --> Model Class Initialized
INFO - 2017-01-09 19:05:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:05:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:05:29 --> Total execution time: 0.0802
INFO - 2017-01-09 19:05:59 --> Config Class Initialized
INFO - 2017-01-09 19:05:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:05:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:05:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:05:59 --> URI Class Initialized
INFO - 2017-01-09 19:05:59 --> Router Class Initialized
INFO - 2017-01-09 19:05:59 --> Output Class Initialized
INFO - 2017-01-09 19:05:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:05:59 --> Input Class Initialized
INFO - 2017-01-09 19:05:59 --> Language Class Initialized
INFO - 2017-01-09 19:05:59 --> Loader Class Initialized
INFO - 2017-01-09 19:05:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:05:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:05:59 --> Controller Class Initialized
INFO - 2017-01-09 19:05:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:05:59 --> Model Class Initialized
INFO - 2017-01-09 19:05:59 --> Model Class Initialized
INFO - 2017-01-09 19:05:59 --> Model Class Initialized
INFO - 2017-01-09 19:05:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:05:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:05:59 --> Total execution time: 0.1289
INFO - 2017-01-09 19:06:29 --> Config Class Initialized
INFO - 2017-01-09 19:06:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:06:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:06:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:06:29 --> URI Class Initialized
INFO - 2017-01-09 19:06:29 --> Router Class Initialized
INFO - 2017-01-09 19:06:29 --> Output Class Initialized
INFO - 2017-01-09 19:06:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:06:29 --> Input Class Initialized
INFO - 2017-01-09 19:06:29 --> Language Class Initialized
INFO - 2017-01-09 19:06:29 --> Loader Class Initialized
INFO - 2017-01-09 19:06:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:06:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:06:29 --> Controller Class Initialized
INFO - 2017-01-09 19:06:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:06:29 --> Model Class Initialized
INFO - 2017-01-09 19:06:29 --> Model Class Initialized
INFO - 2017-01-09 19:06:29 --> Model Class Initialized
INFO - 2017-01-09 19:06:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:06:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:06:29 --> Total execution time: 0.3637
INFO - 2017-01-09 19:06:59 --> Config Class Initialized
INFO - 2017-01-09 19:06:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:06:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:06:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:06:59 --> URI Class Initialized
INFO - 2017-01-09 19:06:59 --> Router Class Initialized
INFO - 2017-01-09 19:06:59 --> Output Class Initialized
INFO - 2017-01-09 19:06:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:06:59 --> Input Class Initialized
INFO - 2017-01-09 19:06:59 --> Language Class Initialized
INFO - 2017-01-09 19:06:59 --> Loader Class Initialized
INFO - 2017-01-09 19:06:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:06:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:06:59 --> Controller Class Initialized
INFO - 2017-01-09 19:06:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:06:59 --> Model Class Initialized
INFO - 2017-01-09 19:06:59 --> Model Class Initialized
INFO - 2017-01-09 19:06:59 --> Model Class Initialized
INFO - 2017-01-09 19:06:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:06:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:06:59 --> Total execution time: 0.1149
INFO - 2017-01-09 19:07:29 --> Config Class Initialized
INFO - 2017-01-09 19:07:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:07:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:07:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:07:29 --> URI Class Initialized
INFO - 2017-01-09 19:07:29 --> Router Class Initialized
INFO - 2017-01-09 19:07:29 --> Output Class Initialized
INFO - 2017-01-09 19:07:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:07:29 --> Input Class Initialized
INFO - 2017-01-09 19:07:29 --> Language Class Initialized
INFO - 2017-01-09 19:07:29 --> Loader Class Initialized
INFO - 2017-01-09 19:07:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:07:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:07:29 --> Controller Class Initialized
INFO - 2017-01-09 19:07:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:07:29 --> Model Class Initialized
INFO - 2017-01-09 19:07:29 --> Model Class Initialized
INFO - 2017-01-09 19:07:29 --> Model Class Initialized
INFO - 2017-01-09 19:07:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:07:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:07:29 --> Total execution time: 0.3680
INFO - 2017-01-09 19:07:59 --> Config Class Initialized
INFO - 2017-01-09 19:07:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:07:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:07:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:07:59 --> URI Class Initialized
INFO - 2017-01-09 19:07:59 --> Router Class Initialized
INFO - 2017-01-09 19:07:59 --> Output Class Initialized
INFO - 2017-01-09 19:07:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:07:59 --> Input Class Initialized
INFO - 2017-01-09 19:07:59 --> Language Class Initialized
INFO - 2017-01-09 19:07:59 --> Loader Class Initialized
INFO - 2017-01-09 19:07:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:07:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:07:59 --> Controller Class Initialized
INFO - 2017-01-09 19:07:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:07:59 --> Model Class Initialized
INFO - 2017-01-09 19:07:59 --> Model Class Initialized
INFO - 2017-01-09 19:07:59 --> Model Class Initialized
INFO - 2017-01-09 19:07:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:07:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:07:59 --> Total execution time: 0.0725
INFO - 2017-01-09 19:08:29 --> Config Class Initialized
INFO - 2017-01-09 19:08:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:08:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:08:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:08:29 --> URI Class Initialized
INFO - 2017-01-09 19:08:29 --> Router Class Initialized
INFO - 2017-01-09 19:08:29 --> Output Class Initialized
INFO - 2017-01-09 19:08:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:08:29 --> Input Class Initialized
INFO - 2017-01-09 19:08:29 --> Language Class Initialized
INFO - 2017-01-09 19:08:29 --> Loader Class Initialized
INFO - 2017-01-09 19:08:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:08:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:08:29 --> Controller Class Initialized
INFO - 2017-01-09 19:08:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:08:29 --> Model Class Initialized
INFO - 2017-01-09 19:08:29 --> Model Class Initialized
INFO - 2017-01-09 19:08:29 --> Model Class Initialized
INFO - 2017-01-09 19:08:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:08:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:08:29 --> Total execution time: 0.1076
INFO - 2017-01-09 19:08:59 --> Config Class Initialized
INFO - 2017-01-09 19:08:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:08:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:08:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:08:59 --> URI Class Initialized
INFO - 2017-01-09 19:08:59 --> Router Class Initialized
INFO - 2017-01-09 19:08:59 --> Output Class Initialized
INFO - 2017-01-09 19:08:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:08:59 --> Input Class Initialized
INFO - 2017-01-09 19:08:59 --> Language Class Initialized
INFO - 2017-01-09 19:08:59 --> Loader Class Initialized
INFO - 2017-01-09 19:08:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:08:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:08:59 --> Controller Class Initialized
INFO - 2017-01-09 19:08:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:08:59 --> Model Class Initialized
INFO - 2017-01-09 19:08:59 --> Model Class Initialized
INFO - 2017-01-09 19:08:59 --> Model Class Initialized
INFO - 2017-01-09 19:08:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:08:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:08:59 --> Total execution time: 0.1291
INFO - 2017-01-09 19:09:29 --> Config Class Initialized
INFO - 2017-01-09 19:09:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:09:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:09:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:09:29 --> URI Class Initialized
INFO - 2017-01-09 19:09:29 --> Router Class Initialized
INFO - 2017-01-09 19:09:29 --> Output Class Initialized
INFO - 2017-01-09 19:09:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:09:29 --> Input Class Initialized
INFO - 2017-01-09 19:09:29 --> Language Class Initialized
INFO - 2017-01-09 19:09:29 --> Loader Class Initialized
INFO - 2017-01-09 19:09:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:09:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:09:29 --> Controller Class Initialized
INFO - 2017-01-09 19:09:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:09:29 --> Model Class Initialized
INFO - 2017-01-09 19:09:29 --> Model Class Initialized
INFO - 2017-01-09 19:09:29 --> Model Class Initialized
INFO - 2017-01-09 19:09:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:09:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:09:29 --> Total execution time: 0.1205
INFO - 2017-01-09 19:09:59 --> Config Class Initialized
INFO - 2017-01-09 19:09:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:09:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:09:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:09:59 --> URI Class Initialized
INFO - 2017-01-09 19:09:59 --> Router Class Initialized
INFO - 2017-01-09 19:09:59 --> Output Class Initialized
INFO - 2017-01-09 19:09:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:09:59 --> Input Class Initialized
INFO - 2017-01-09 19:09:59 --> Language Class Initialized
INFO - 2017-01-09 19:09:59 --> Loader Class Initialized
INFO - 2017-01-09 19:09:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:09:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:09:59 --> Controller Class Initialized
INFO - 2017-01-09 19:09:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:09:59 --> Model Class Initialized
INFO - 2017-01-09 19:09:59 --> Model Class Initialized
INFO - 2017-01-09 19:09:59 --> Model Class Initialized
INFO - 2017-01-09 19:09:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:09:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:09:59 --> Total execution time: 0.0765
INFO - 2017-01-09 19:10:29 --> Config Class Initialized
INFO - 2017-01-09 19:10:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:10:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:10:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:10:29 --> URI Class Initialized
INFO - 2017-01-09 19:10:29 --> Router Class Initialized
INFO - 2017-01-09 19:10:29 --> Output Class Initialized
INFO - 2017-01-09 19:10:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:10:29 --> Input Class Initialized
INFO - 2017-01-09 19:10:29 --> Language Class Initialized
INFO - 2017-01-09 19:10:29 --> Loader Class Initialized
INFO - 2017-01-09 19:10:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:10:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:10:29 --> Controller Class Initialized
INFO - 2017-01-09 19:10:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:10:29 --> Model Class Initialized
INFO - 2017-01-09 19:10:29 --> Model Class Initialized
INFO - 2017-01-09 19:10:29 --> Model Class Initialized
INFO - 2017-01-09 19:10:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:10:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:10:29 --> Total execution time: 0.0901
INFO - 2017-01-09 19:10:59 --> Config Class Initialized
INFO - 2017-01-09 19:10:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:10:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:10:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:10:59 --> URI Class Initialized
INFO - 2017-01-09 19:10:59 --> Router Class Initialized
INFO - 2017-01-09 19:10:59 --> Output Class Initialized
INFO - 2017-01-09 19:10:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:10:59 --> Input Class Initialized
INFO - 2017-01-09 19:10:59 --> Language Class Initialized
INFO - 2017-01-09 19:10:59 --> Loader Class Initialized
INFO - 2017-01-09 19:10:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:10:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:10:59 --> Controller Class Initialized
INFO - 2017-01-09 19:10:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:10:59 --> Model Class Initialized
INFO - 2017-01-09 19:10:59 --> Model Class Initialized
INFO - 2017-01-09 19:10:59 --> Model Class Initialized
INFO - 2017-01-09 19:10:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:10:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:10:59 --> Total execution time: 0.0738
INFO - 2017-01-09 19:11:29 --> Config Class Initialized
INFO - 2017-01-09 19:11:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:11:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:11:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:11:29 --> URI Class Initialized
INFO - 2017-01-09 19:11:29 --> Router Class Initialized
INFO - 2017-01-09 19:11:29 --> Output Class Initialized
INFO - 2017-01-09 19:11:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:11:29 --> Input Class Initialized
INFO - 2017-01-09 19:11:29 --> Language Class Initialized
INFO - 2017-01-09 19:11:29 --> Loader Class Initialized
INFO - 2017-01-09 19:11:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:11:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:11:29 --> Controller Class Initialized
INFO - 2017-01-09 19:11:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:11:29 --> Model Class Initialized
INFO - 2017-01-09 19:11:29 --> Model Class Initialized
INFO - 2017-01-09 19:11:29 --> Model Class Initialized
INFO - 2017-01-09 19:11:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:11:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:11:29 --> Total execution time: 0.0873
INFO - 2017-01-09 19:11:59 --> Config Class Initialized
INFO - 2017-01-09 19:11:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:11:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:11:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:11:59 --> URI Class Initialized
INFO - 2017-01-09 19:11:59 --> Router Class Initialized
INFO - 2017-01-09 19:11:59 --> Output Class Initialized
INFO - 2017-01-09 19:11:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:11:59 --> Input Class Initialized
INFO - 2017-01-09 19:11:59 --> Language Class Initialized
INFO - 2017-01-09 19:11:59 --> Loader Class Initialized
INFO - 2017-01-09 19:11:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:11:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:11:59 --> Controller Class Initialized
INFO - 2017-01-09 19:11:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:11:59 --> Model Class Initialized
INFO - 2017-01-09 19:11:59 --> Model Class Initialized
INFO - 2017-01-09 19:11:59 --> Model Class Initialized
INFO - 2017-01-09 19:11:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:11:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:11:59 --> Total execution time: 0.0795
INFO - 2017-01-09 19:12:29 --> Config Class Initialized
INFO - 2017-01-09 19:12:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:12:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:12:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:12:29 --> URI Class Initialized
INFO - 2017-01-09 19:12:29 --> Router Class Initialized
INFO - 2017-01-09 19:12:29 --> Output Class Initialized
INFO - 2017-01-09 19:12:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:12:29 --> Input Class Initialized
INFO - 2017-01-09 19:12:29 --> Language Class Initialized
INFO - 2017-01-09 19:12:29 --> Loader Class Initialized
INFO - 2017-01-09 19:12:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:12:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:12:29 --> Controller Class Initialized
INFO - 2017-01-09 19:12:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:12:29 --> Model Class Initialized
INFO - 2017-01-09 19:12:29 --> Model Class Initialized
INFO - 2017-01-09 19:12:29 --> Model Class Initialized
INFO - 2017-01-09 19:12:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:12:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:12:29 --> Total execution time: 0.0850
INFO - 2017-01-09 19:12:59 --> Config Class Initialized
INFO - 2017-01-09 19:12:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:12:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:12:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:12:59 --> URI Class Initialized
INFO - 2017-01-09 19:12:59 --> Router Class Initialized
INFO - 2017-01-09 19:12:59 --> Output Class Initialized
INFO - 2017-01-09 19:12:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:12:59 --> Input Class Initialized
INFO - 2017-01-09 19:12:59 --> Language Class Initialized
INFO - 2017-01-09 19:12:59 --> Loader Class Initialized
INFO - 2017-01-09 19:12:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:12:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:12:59 --> Controller Class Initialized
INFO - 2017-01-09 19:12:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:12:59 --> Model Class Initialized
INFO - 2017-01-09 19:12:59 --> Model Class Initialized
INFO - 2017-01-09 19:12:59 --> Model Class Initialized
INFO - 2017-01-09 19:12:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:12:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:12:59 --> Total execution time: 0.0704
INFO - 2017-01-09 19:13:29 --> Config Class Initialized
INFO - 2017-01-09 19:13:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:13:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:13:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:13:29 --> URI Class Initialized
INFO - 2017-01-09 19:13:29 --> Router Class Initialized
INFO - 2017-01-09 19:13:29 --> Output Class Initialized
INFO - 2017-01-09 19:13:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:13:29 --> Input Class Initialized
INFO - 2017-01-09 19:13:29 --> Language Class Initialized
INFO - 2017-01-09 19:13:29 --> Loader Class Initialized
INFO - 2017-01-09 19:13:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:13:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:13:29 --> Controller Class Initialized
INFO - 2017-01-09 19:13:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:13:29 --> Model Class Initialized
INFO - 2017-01-09 19:13:29 --> Model Class Initialized
INFO - 2017-01-09 19:13:29 --> Model Class Initialized
INFO - 2017-01-09 19:13:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:13:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:13:29 --> Total execution time: 0.0779
INFO - 2017-01-09 19:13:59 --> Config Class Initialized
INFO - 2017-01-09 19:13:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:13:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:13:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:13:59 --> URI Class Initialized
INFO - 2017-01-09 19:13:59 --> Router Class Initialized
INFO - 2017-01-09 19:13:59 --> Output Class Initialized
INFO - 2017-01-09 19:13:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:13:59 --> Input Class Initialized
INFO - 2017-01-09 19:13:59 --> Language Class Initialized
INFO - 2017-01-09 19:13:59 --> Loader Class Initialized
INFO - 2017-01-09 19:13:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:13:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:13:59 --> Controller Class Initialized
INFO - 2017-01-09 19:13:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:13:59 --> Model Class Initialized
INFO - 2017-01-09 19:13:59 --> Model Class Initialized
INFO - 2017-01-09 19:13:59 --> Model Class Initialized
INFO - 2017-01-09 19:13:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:13:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:13:59 --> Total execution time: 0.0749
INFO - 2017-01-09 19:14:29 --> Config Class Initialized
INFO - 2017-01-09 19:14:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:14:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:14:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:14:29 --> URI Class Initialized
INFO - 2017-01-09 19:14:29 --> Router Class Initialized
INFO - 2017-01-09 19:14:29 --> Output Class Initialized
INFO - 2017-01-09 19:14:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:14:29 --> Input Class Initialized
INFO - 2017-01-09 19:14:29 --> Language Class Initialized
INFO - 2017-01-09 19:14:29 --> Loader Class Initialized
INFO - 2017-01-09 19:14:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:14:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:14:29 --> Controller Class Initialized
INFO - 2017-01-09 19:14:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:14:29 --> Model Class Initialized
INFO - 2017-01-09 19:14:29 --> Model Class Initialized
INFO - 2017-01-09 19:14:29 --> Model Class Initialized
INFO - 2017-01-09 19:14:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:14:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:14:29 --> Total execution time: 0.1187
INFO - 2017-01-09 19:14:59 --> Config Class Initialized
INFO - 2017-01-09 19:14:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:14:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:14:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:14:59 --> URI Class Initialized
INFO - 2017-01-09 19:14:59 --> Router Class Initialized
INFO - 2017-01-09 19:14:59 --> Output Class Initialized
INFO - 2017-01-09 19:14:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:14:59 --> Input Class Initialized
INFO - 2017-01-09 19:14:59 --> Language Class Initialized
INFO - 2017-01-09 19:14:59 --> Loader Class Initialized
INFO - 2017-01-09 19:14:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:14:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:14:59 --> Controller Class Initialized
INFO - 2017-01-09 19:14:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:14:59 --> Model Class Initialized
INFO - 2017-01-09 19:14:59 --> Model Class Initialized
INFO - 2017-01-09 19:14:59 --> Model Class Initialized
INFO - 2017-01-09 19:14:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:14:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:14:59 --> Total execution time: 0.0836
INFO - 2017-01-09 19:15:29 --> Config Class Initialized
INFO - 2017-01-09 19:15:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:15:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:15:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:15:29 --> URI Class Initialized
INFO - 2017-01-09 19:15:29 --> Router Class Initialized
INFO - 2017-01-09 19:15:29 --> Output Class Initialized
INFO - 2017-01-09 19:15:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:15:29 --> Input Class Initialized
INFO - 2017-01-09 19:15:29 --> Language Class Initialized
INFO - 2017-01-09 19:15:29 --> Loader Class Initialized
INFO - 2017-01-09 19:15:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:15:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:15:29 --> Controller Class Initialized
INFO - 2017-01-09 19:15:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:15:29 --> Model Class Initialized
INFO - 2017-01-09 19:15:29 --> Model Class Initialized
INFO - 2017-01-09 19:15:29 --> Model Class Initialized
INFO - 2017-01-09 19:15:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:15:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:15:29 --> Total execution time: 0.1098
INFO - 2017-01-09 19:15:59 --> Config Class Initialized
INFO - 2017-01-09 19:15:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:15:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:15:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:15:59 --> URI Class Initialized
INFO - 2017-01-09 19:15:59 --> Router Class Initialized
INFO - 2017-01-09 19:15:59 --> Output Class Initialized
INFO - 2017-01-09 19:15:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:15:59 --> Input Class Initialized
INFO - 2017-01-09 19:15:59 --> Language Class Initialized
INFO - 2017-01-09 19:15:59 --> Loader Class Initialized
INFO - 2017-01-09 19:15:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:15:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:15:59 --> Controller Class Initialized
INFO - 2017-01-09 19:15:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:15:59 --> Model Class Initialized
INFO - 2017-01-09 19:15:59 --> Model Class Initialized
INFO - 2017-01-09 19:15:59 --> Model Class Initialized
INFO - 2017-01-09 19:15:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:15:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:15:59 --> Total execution time: 0.0733
INFO - 2017-01-09 19:16:29 --> Config Class Initialized
INFO - 2017-01-09 19:16:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:16:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:16:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:16:29 --> URI Class Initialized
INFO - 2017-01-09 19:16:29 --> Router Class Initialized
INFO - 2017-01-09 19:16:29 --> Output Class Initialized
INFO - 2017-01-09 19:16:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:16:29 --> Input Class Initialized
INFO - 2017-01-09 19:16:29 --> Language Class Initialized
INFO - 2017-01-09 19:16:29 --> Loader Class Initialized
INFO - 2017-01-09 19:16:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:16:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:16:29 --> Controller Class Initialized
INFO - 2017-01-09 19:16:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:16:29 --> Model Class Initialized
INFO - 2017-01-09 19:16:29 --> Model Class Initialized
INFO - 2017-01-09 19:16:29 --> Model Class Initialized
INFO - 2017-01-09 19:16:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:16:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:16:29 --> Total execution time: 0.0757
INFO - 2017-01-09 19:16:59 --> Config Class Initialized
INFO - 2017-01-09 19:16:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:16:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:16:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:16:59 --> URI Class Initialized
INFO - 2017-01-09 19:16:59 --> Router Class Initialized
INFO - 2017-01-09 19:16:59 --> Output Class Initialized
INFO - 2017-01-09 19:16:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:16:59 --> Input Class Initialized
INFO - 2017-01-09 19:16:59 --> Language Class Initialized
INFO - 2017-01-09 19:16:59 --> Loader Class Initialized
INFO - 2017-01-09 19:16:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:16:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:16:59 --> Controller Class Initialized
INFO - 2017-01-09 19:16:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:16:59 --> Model Class Initialized
INFO - 2017-01-09 19:16:59 --> Model Class Initialized
INFO - 2017-01-09 19:16:59 --> Model Class Initialized
INFO - 2017-01-09 19:16:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:16:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:16:59 --> Total execution time: 0.0941
INFO - 2017-01-09 19:17:29 --> Config Class Initialized
INFO - 2017-01-09 19:17:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:17:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:17:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:17:29 --> URI Class Initialized
INFO - 2017-01-09 19:17:29 --> Router Class Initialized
INFO - 2017-01-09 19:17:29 --> Output Class Initialized
INFO - 2017-01-09 19:17:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:17:29 --> Input Class Initialized
INFO - 2017-01-09 19:17:29 --> Language Class Initialized
INFO - 2017-01-09 19:17:29 --> Loader Class Initialized
INFO - 2017-01-09 19:17:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:17:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:17:29 --> Controller Class Initialized
INFO - 2017-01-09 19:17:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:17:29 --> Model Class Initialized
INFO - 2017-01-09 19:17:29 --> Model Class Initialized
INFO - 2017-01-09 19:17:29 --> Model Class Initialized
INFO - 2017-01-09 19:17:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:17:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:17:29 --> Total execution time: 0.0851
INFO - 2017-01-09 19:17:58 --> Config Class Initialized
INFO - 2017-01-09 19:17:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:17:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:17:58 --> Utf8 Class Initialized
INFO - 2017-01-09 19:17:58 --> URI Class Initialized
INFO - 2017-01-09 19:17:58 --> Router Class Initialized
INFO - 2017-01-09 19:17:58 --> Output Class Initialized
INFO - 2017-01-09 19:17:58 --> Security Class Initialized
DEBUG - 2017-01-09 19:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:17:58 --> Input Class Initialized
INFO - 2017-01-09 19:17:58 --> Language Class Initialized
INFO - 2017-01-09 19:17:58 --> Loader Class Initialized
INFO - 2017-01-09 19:17:58 --> Helper loaded: url_helper
INFO - 2017-01-09 19:17:58 --> Helper loaded: language_helper
INFO - 2017-01-09 19:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:17:58 --> Controller Class Initialized
INFO - 2017-01-09 19:17:58 --> Database Driver Class Initialized
INFO - 2017-01-09 19:17:58 --> Model Class Initialized
INFO - 2017-01-09 19:17:58 --> Model Class Initialized
INFO - 2017-01-09 19:17:58 --> Model Class Initialized
INFO - 2017-01-09 19:17:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:17:58 --> Final output sent to browser
DEBUG - 2017-01-09 19:17:58 --> Total execution time: 0.1093
INFO - 2017-01-09 19:18:29 --> Config Class Initialized
INFO - 2017-01-09 19:18:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:18:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:18:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:18:29 --> URI Class Initialized
INFO - 2017-01-09 19:18:29 --> Router Class Initialized
INFO - 2017-01-09 19:18:29 --> Output Class Initialized
INFO - 2017-01-09 19:18:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:18:29 --> Input Class Initialized
INFO - 2017-01-09 19:18:29 --> Language Class Initialized
INFO - 2017-01-09 19:18:29 --> Loader Class Initialized
INFO - 2017-01-09 19:18:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:18:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:18:29 --> Controller Class Initialized
INFO - 2017-01-09 19:18:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:18:29 --> Model Class Initialized
INFO - 2017-01-09 19:18:29 --> Model Class Initialized
INFO - 2017-01-09 19:18:29 --> Model Class Initialized
INFO - 2017-01-09 19:18:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:18:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:18:29 --> Total execution time: 0.1963
INFO - 2017-01-09 19:18:59 --> Config Class Initialized
INFO - 2017-01-09 19:18:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:18:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:18:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:18:59 --> URI Class Initialized
INFO - 2017-01-09 19:18:59 --> Router Class Initialized
INFO - 2017-01-09 19:18:59 --> Output Class Initialized
INFO - 2017-01-09 19:18:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:18:59 --> Input Class Initialized
INFO - 2017-01-09 19:18:59 --> Language Class Initialized
INFO - 2017-01-09 19:18:59 --> Loader Class Initialized
INFO - 2017-01-09 19:18:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:18:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:18:59 --> Controller Class Initialized
INFO - 2017-01-09 19:18:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:18:59 --> Model Class Initialized
INFO - 2017-01-09 19:18:59 --> Model Class Initialized
INFO - 2017-01-09 19:18:59 --> Model Class Initialized
INFO - 2017-01-09 19:18:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:18:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:18:59 --> Total execution time: 0.0942
INFO - 2017-01-09 19:19:29 --> Config Class Initialized
INFO - 2017-01-09 19:19:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:19:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:19:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:19:29 --> URI Class Initialized
INFO - 2017-01-09 19:19:29 --> Router Class Initialized
INFO - 2017-01-09 19:19:29 --> Output Class Initialized
INFO - 2017-01-09 19:19:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:19:29 --> Input Class Initialized
INFO - 2017-01-09 19:19:29 --> Language Class Initialized
INFO - 2017-01-09 19:19:29 --> Loader Class Initialized
INFO - 2017-01-09 19:19:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:19:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:19:29 --> Controller Class Initialized
INFO - 2017-01-09 19:19:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:19:29 --> Model Class Initialized
INFO - 2017-01-09 19:19:29 --> Model Class Initialized
INFO - 2017-01-09 19:19:29 --> Model Class Initialized
INFO - 2017-01-09 19:19:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:19:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:19:29 --> Total execution time: 0.0816
INFO - 2017-01-09 19:19:59 --> Config Class Initialized
INFO - 2017-01-09 19:19:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:19:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:19:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:19:59 --> URI Class Initialized
INFO - 2017-01-09 19:19:59 --> Router Class Initialized
INFO - 2017-01-09 19:19:59 --> Output Class Initialized
INFO - 2017-01-09 19:19:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:19:59 --> Input Class Initialized
INFO - 2017-01-09 19:19:59 --> Language Class Initialized
INFO - 2017-01-09 19:19:59 --> Loader Class Initialized
INFO - 2017-01-09 19:19:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:19:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:19:59 --> Controller Class Initialized
INFO - 2017-01-09 19:19:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:19:59 --> Model Class Initialized
INFO - 2017-01-09 19:19:59 --> Model Class Initialized
INFO - 2017-01-09 19:19:59 --> Model Class Initialized
INFO - 2017-01-09 19:19:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:19:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:19:59 --> Total execution time: 0.1051
INFO - 2017-01-09 19:20:29 --> Config Class Initialized
INFO - 2017-01-09 19:20:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:20:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:20:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:20:29 --> URI Class Initialized
INFO - 2017-01-09 19:20:29 --> Router Class Initialized
INFO - 2017-01-09 19:20:29 --> Output Class Initialized
INFO - 2017-01-09 19:20:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:20:29 --> Input Class Initialized
INFO - 2017-01-09 19:20:29 --> Language Class Initialized
INFO - 2017-01-09 19:20:29 --> Loader Class Initialized
INFO - 2017-01-09 19:20:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:20:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:20:29 --> Controller Class Initialized
INFO - 2017-01-09 19:20:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:20:29 --> Model Class Initialized
INFO - 2017-01-09 19:20:29 --> Model Class Initialized
INFO - 2017-01-09 19:20:29 --> Model Class Initialized
INFO - 2017-01-09 19:20:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:20:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:20:29 --> Total execution time: 0.1089
INFO - 2017-01-09 19:20:59 --> Config Class Initialized
INFO - 2017-01-09 19:20:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:20:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:20:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:20:59 --> URI Class Initialized
INFO - 2017-01-09 19:20:59 --> Router Class Initialized
INFO - 2017-01-09 19:20:59 --> Output Class Initialized
INFO - 2017-01-09 19:20:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:20:59 --> Input Class Initialized
INFO - 2017-01-09 19:20:59 --> Language Class Initialized
INFO - 2017-01-09 19:20:59 --> Loader Class Initialized
INFO - 2017-01-09 19:20:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:20:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:20:59 --> Controller Class Initialized
INFO - 2017-01-09 19:20:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:20:59 --> Model Class Initialized
INFO - 2017-01-09 19:20:59 --> Model Class Initialized
INFO - 2017-01-09 19:20:59 --> Model Class Initialized
INFO - 2017-01-09 19:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:20:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:20:59 --> Total execution time: 0.0785
INFO - 2017-01-09 19:21:29 --> Config Class Initialized
INFO - 2017-01-09 19:21:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:21:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:21:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:21:29 --> URI Class Initialized
INFO - 2017-01-09 19:21:29 --> Router Class Initialized
INFO - 2017-01-09 19:21:29 --> Output Class Initialized
INFO - 2017-01-09 19:21:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:21:29 --> Input Class Initialized
INFO - 2017-01-09 19:21:29 --> Language Class Initialized
INFO - 2017-01-09 19:21:29 --> Loader Class Initialized
INFO - 2017-01-09 19:21:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:21:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:21:29 --> Controller Class Initialized
INFO - 2017-01-09 19:21:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:21:29 --> Model Class Initialized
INFO - 2017-01-09 19:21:29 --> Model Class Initialized
INFO - 2017-01-09 19:21:29 --> Model Class Initialized
INFO - 2017-01-09 19:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:21:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:21:29 --> Total execution time: 0.1041
INFO - 2017-01-09 19:21:59 --> Config Class Initialized
INFO - 2017-01-09 19:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:21:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:21:59 --> URI Class Initialized
INFO - 2017-01-09 19:21:59 --> Router Class Initialized
INFO - 2017-01-09 19:21:59 --> Output Class Initialized
INFO - 2017-01-09 19:21:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:21:59 --> Input Class Initialized
INFO - 2017-01-09 19:21:59 --> Language Class Initialized
INFO - 2017-01-09 19:21:59 --> Loader Class Initialized
INFO - 2017-01-09 19:21:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:21:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:21:59 --> Controller Class Initialized
INFO - 2017-01-09 19:21:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:21:59 --> Model Class Initialized
INFO - 2017-01-09 19:21:59 --> Model Class Initialized
INFO - 2017-01-09 19:21:59 --> Model Class Initialized
INFO - 2017-01-09 19:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:21:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:21:59 --> Total execution time: 0.1126
INFO - 2017-01-09 19:22:29 --> Config Class Initialized
INFO - 2017-01-09 19:22:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:22:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:22:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:22:29 --> URI Class Initialized
INFO - 2017-01-09 19:22:29 --> Router Class Initialized
INFO - 2017-01-09 19:22:29 --> Output Class Initialized
INFO - 2017-01-09 19:22:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:22:29 --> Input Class Initialized
INFO - 2017-01-09 19:22:29 --> Language Class Initialized
INFO - 2017-01-09 19:22:29 --> Loader Class Initialized
INFO - 2017-01-09 19:22:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:22:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:22:29 --> Controller Class Initialized
INFO - 2017-01-09 19:22:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:22:29 --> Model Class Initialized
INFO - 2017-01-09 19:22:29 --> Model Class Initialized
INFO - 2017-01-09 19:22:29 --> Model Class Initialized
INFO - 2017-01-09 19:22:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:22:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:22:29 --> Total execution time: 0.0808
INFO - 2017-01-09 19:22:59 --> Config Class Initialized
INFO - 2017-01-09 19:22:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:22:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:22:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:22:59 --> URI Class Initialized
INFO - 2017-01-09 19:22:59 --> Router Class Initialized
INFO - 2017-01-09 19:22:59 --> Output Class Initialized
INFO - 2017-01-09 19:22:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:22:59 --> Input Class Initialized
INFO - 2017-01-09 19:22:59 --> Language Class Initialized
INFO - 2017-01-09 19:22:59 --> Loader Class Initialized
INFO - 2017-01-09 19:22:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:22:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:22:59 --> Controller Class Initialized
INFO - 2017-01-09 19:22:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:22:59 --> Model Class Initialized
INFO - 2017-01-09 19:22:59 --> Model Class Initialized
INFO - 2017-01-09 19:22:59 --> Model Class Initialized
INFO - 2017-01-09 19:22:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:22:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:22:59 --> Total execution time: 0.0935
INFO - 2017-01-09 19:23:29 --> Config Class Initialized
INFO - 2017-01-09 19:23:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:23:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:23:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:23:29 --> URI Class Initialized
INFO - 2017-01-09 19:23:29 --> Router Class Initialized
INFO - 2017-01-09 19:23:29 --> Output Class Initialized
INFO - 2017-01-09 19:23:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:23:29 --> Input Class Initialized
INFO - 2017-01-09 19:23:29 --> Language Class Initialized
INFO - 2017-01-09 19:23:29 --> Loader Class Initialized
INFO - 2017-01-09 19:23:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:23:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:23:29 --> Controller Class Initialized
INFO - 2017-01-09 19:23:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:23:29 --> Model Class Initialized
INFO - 2017-01-09 19:23:29 --> Model Class Initialized
INFO - 2017-01-09 19:23:29 --> Model Class Initialized
INFO - 2017-01-09 19:23:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:23:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:23:29 --> Total execution time: 0.0943
INFO - 2017-01-09 19:23:59 --> Config Class Initialized
INFO - 2017-01-09 19:23:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:23:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:23:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:23:59 --> URI Class Initialized
INFO - 2017-01-09 19:23:59 --> Router Class Initialized
INFO - 2017-01-09 19:23:59 --> Output Class Initialized
INFO - 2017-01-09 19:23:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:23:59 --> Input Class Initialized
INFO - 2017-01-09 19:23:59 --> Language Class Initialized
INFO - 2017-01-09 19:23:59 --> Loader Class Initialized
INFO - 2017-01-09 19:23:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:23:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:23:59 --> Controller Class Initialized
INFO - 2017-01-09 19:23:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:23:59 --> Model Class Initialized
INFO - 2017-01-09 19:23:59 --> Model Class Initialized
INFO - 2017-01-09 19:23:59 --> Model Class Initialized
INFO - 2017-01-09 19:23:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:23:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:23:59 --> Total execution time: 0.1025
INFO - 2017-01-09 19:24:29 --> Config Class Initialized
INFO - 2017-01-09 19:24:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:24:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:24:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:24:29 --> URI Class Initialized
INFO - 2017-01-09 19:24:29 --> Router Class Initialized
INFO - 2017-01-09 19:24:29 --> Output Class Initialized
INFO - 2017-01-09 19:24:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:24:29 --> Input Class Initialized
INFO - 2017-01-09 19:24:29 --> Language Class Initialized
INFO - 2017-01-09 19:24:29 --> Loader Class Initialized
INFO - 2017-01-09 19:24:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:24:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:24:29 --> Controller Class Initialized
INFO - 2017-01-09 19:24:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:24:29 --> Model Class Initialized
INFO - 2017-01-09 19:24:29 --> Model Class Initialized
INFO - 2017-01-09 19:24:29 --> Model Class Initialized
INFO - 2017-01-09 19:24:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:24:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:24:29 --> Total execution time: 0.0843
INFO - 2017-01-09 19:24:59 --> Config Class Initialized
INFO - 2017-01-09 19:24:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:24:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:24:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:24:59 --> URI Class Initialized
INFO - 2017-01-09 19:24:59 --> Router Class Initialized
INFO - 2017-01-09 19:24:59 --> Output Class Initialized
INFO - 2017-01-09 19:24:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:24:59 --> Input Class Initialized
INFO - 2017-01-09 19:24:59 --> Language Class Initialized
INFO - 2017-01-09 19:24:59 --> Loader Class Initialized
INFO - 2017-01-09 19:24:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:24:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:24:59 --> Controller Class Initialized
INFO - 2017-01-09 19:24:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:24:59 --> Model Class Initialized
INFO - 2017-01-09 19:24:59 --> Model Class Initialized
INFO - 2017-01-09 19:24:59 --> Model Class Initialized
INFO - 2017-01-09 19:24:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:24:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:24:59 --> Total execution time: 0.1851
INFO - 2017-01-09 19:25:29 --> Config Class Initialized
INFO - 2017-01-09 19:25:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:25:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:25:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:25:29 --> URI Class Initialized
INFO - 2017-01-09 19:25:29 --> Router Class Initialized
INFO - 2017-01-09 19:25:29 --> Output Class Initialized
INFO - 2017-01-09 19:25:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:25:29 --> Input Class Initialized
INFO - 2017-01-09 19:25:29 --> Language Class Initialized
INFO - 2017-01-09 19:25:29 --> Loader Class Initialized
INFO - 2017-01-09 19:25:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:25:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:25:29 --> Controller Class Initialized
INFO - 2017-01-09 19:25:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:25:29 --> Model Class Initialized
INFO - 2017-01-09 19:25:29 --> Model Class Initialized
INFO - 2017-01-09 19:25:29 --> Model Class Initialized
INFO - 2017-01-09 19:25:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:25:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:25:29 --> Total execution time: 0.0967
INFO - 2017-01-09 19:25:59 --> Config Class Initialized
INFO - 2017-01-09 19:25:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:25:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:25:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:25:59 --> URI Class Initialized
INFO - 2017-01-09 19:25:59 --> Router Class Initialized
INFO - 2017-01-09 19:25:59 --> Output Class Initialized
INFO - 2017-01-09 19:25:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:25:59 --> Input Class Initialized
INFO - 2017-01-09 19:25:59 --> Language Class Initialized
INFO - 2017-01-09 19:25:59 --> Loader Class Initialized
INFO - 2017-01-09 19:25:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:25:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:25:59 --> Controller Class Initialized
INFO - 2017-01-09 19:25:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:25:59 --> Model Class Initialized
INFO - 2017-01-09 19:25:59 --> Model Class Initialized
INFO - 2017-01-09 19:25:59 --> Model Class Initialized
INFO - 2017-01-09 19:25:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:25:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:25:59 --> Total execution time: 0.1340
INFO - 2017-01-09 19:26:29 --> Config Class Initialized
INFO - 2017-01-09 19:26:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:26:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:26:29 --> URI Class Initialized
INFO - 2017-01-09 19:26:29 --> Router Class Initialized
INFO - 2017-01-09 19:26:29 --> Output Class Initialized
INFO - 2017-01-09 19:26:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:26:29 --> Input Class Initialized
INFO - 2017-01-09 19:26:29 --> Language Class Initialized
INFO - 2017-01-09 19:26:29 --> Loader Class Initialized
INFO - 2017-01-09 19:26:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:26:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:26:29 --> Controller Class Initialized
INFO - 2017-01-09 19:26:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:26:29 --> Model Class Initialized
INFO - 2017-01-09 19:26:29 --> Model Class Initialized
INFO - 2017-01-09 19:26:29 --> Model Class Initialized
INFO - 2017-01-09 19:26:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:26:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:26:29 --> Total execution time: 0.1035
INFO - 2017-01-09 19:26:59 --> Config Class Initialized
INFO - 2017-01-09 19:26:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:26:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:26:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:26:59 --> URI Class Initialized
INFO - 2017-01-09 19:26:59 --> Router Class Initialized
INFO - 2017-01-09 19:26:59 --> Output Class Initialized
INFO - 2017-01-09 19:26:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:26:59 --> Input Class Initialized
INFO - 2017-01-09 19:26:59 --> Language Class Initialized
INFO - 2017-01-09 19:26:59 --> Loader Class Initialized
INFO - 2017-01-09 19:26:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:26:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:26:59 --> Controller Class Initialized
INFO - 2017-01-09 19:26:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:26:59 --> Model Class Initialized
INFO - 2017-01-09 19:26:59 --> Model Class Initialized
INFO - 2017-01-09 19:26:59 --> Model Class Initialized
INFO - 2017-01-09 19:26:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:26:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:26:59 --> Total execution time: 0.0790
INFO - 2017-01-09 19:27:29 --> Config Class Initialized
INFO - 2017-01-09 19:27:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:27:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:27:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:27:29 --> URI Class Initialized
INFO - 2017-01-09 19:27:29 --> Router Class Initialized
INFO - 2017-01-09 19:27:29 --> Output Class Initialized
INFO - 2017-01-09 19:27:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:27:29 --> Input Class Initialized
INFO - 2017-01-09 19:27:29 --> Language Class Initialized
INFO - 2017-01-09 19:27:29 --> Loader Class Initialized
INFO - 2017-01-09 19:27:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:27:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:27:29 --> Controller Class Initialized
INFO - 2017-01-09 19:27:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:27:29 --> Model Class Initialized
INFO - 2017-01-09 19:27:29 --> Model Class Initialized
INFO - 2017-01-09 19:27:29 --> Model Class Initialized
INFO - 2017-01-09 19:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:27:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:27:29 --> Total execution time: 0.1169
INFO - 2017-01-09 19:27:59 --> Config Class Initialized
INFO - 2017-01-09 19:27:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:27:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:27:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:27:59 --> URI Class Initialized
INFO - 2017-01-09 19:27:59 --> Router Class Initialized
INFO - 2017-01-09 19:27:59 --> Output Class Initialized
INFO - 2017-01-09 19:27:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:27:59 --> Input Class Initialized
INFO - 2017-01-09 19:27:59 --> Language Class Initialized
INFO - 2017-01-09 19:27:59 --> Loader Class Initialized
INFO - 2017-01-09 19:27:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:27:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:27:59 --> Controller Class Initialized
INFO - 2017-01-09 19:27:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:27:59 --> Model Class Initialized
INFO - 2017-01-09 19:27:59 --> Model Class Initialized
INFO - 2017-01-09 19:27:59 --> Model Class Initialized
INFO - 2017-01-09 19:27:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:27:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:27:59 --> Total execution time: 0.1036
INFO - 2017-01-09 19:28:29 --> Config Class Initialized
INFO - 2017-01-09 19:28:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:28:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:28:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:28:29 --> URI Class Initialized
INFO - 2017-01-09 19:28:29 --> Router Class Initialized
INFO - 2017-01-09 19:28:29 --> Output Class Initialized
INFO - 2017-01-09 19:28:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:28:29 --> Input Class Initialized
INFO - 2017-01-09 19:28:29 --> Language Class Initialized
INFO - 2017-01-09 19:28:29 --> Loader Class Initialized
INFO - 2017-01-09 19:28:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:28:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:28:29 --> Controller Class Initialized
INFO - 2017-01-09 19:28:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:28:29 --> Model Class Initialized
INFO - 2017-01-09 19:28:29 --> Model Class Initialized
INFO - 2017-01-09 19:28:29 --> Model Class Initialized
INFO - 2017-01-09 19:28:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:28:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:28:29 --> Total execution time: 0.1492
INFO - 2017-01-09 19:28:59 --> Config Class Initialized
INFO - 2017-01-09 19:28:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:28:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:28:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:28:59 --> URI Class Initialized
INFO - 2017-01-09 19:28:59 --> Router Class Initialized
INFO - 2017-01-09 19:28:59 --> Output Class Initialized
INFO - 2017-01-09 19:28:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:28:59 --> Input Class Initialized
INFO - 2017-01-09 19:28:59 --> Language Class Initialized
INFO - 2017-01-09 19:28:59 --> Loader Class Initialized
INFO - 2017-01-09 19:28:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:28:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:28:59 --> Controller Class Initialized
INFO - 2017-01-09 19:28:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:28:59 --> Model Class Initialized
INFO - 2017-01-09 19:28:59 --> Model Class Initialized
INFO - 2017-01-09 19:28:59 --> Model Class Initialized
INFO - 2017-01-09 19:28:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:28:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:28:59 --> Total execution time: 0.1386
INFO - 2017-01-09 19:29:29 --> Config Class Initialized
INFO - 2017-01-09 19:29:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:29:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:29:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:29:29 --> URI Class Initialized
INFO - 2017-01-09 19:29:29 --> Router Class Initialized
INFO - 2017-01-09 19:29:29 --> Output Class Initialized
INFO - 2017-01-09 19:29:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:29:29 --> Input Class Initialized
INFO - 2017-01-09 19:29:29 --> Language Class Initialized
INFO - 2017-01-09 19:29:29 --> Loader Class Initialized
INFO - 2017-01-09 19:29:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:29:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:29:29 --> Controller Class Initialized
INFO - 2017-01-09 19:29:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:29:29 --> Model Class Initialized
INFO - 2017-01-09 19:29:29 --> Model Class Initialized
INFO - 2017-01-09 19:29:29 --> Model Class Initialized
INFO - 2017-01-09 19:29:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:29:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:29:29 --> Total execution time: 0.0709
INFO - 2017-01-09 19:29:59 --> Config Class Initialized
INFO - 2017-01-09 19:29:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:29:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:29:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:29:59 --> URI Class Initialized
INFO - 2017-01-09 19:29:59 --> Router Class Initialized
INFO - 2017-01-09 19:29:59 --> Output Class Initialized
INFO - 2017-01-09 19:29:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:29:59 --> Input Class Initialized
INFO - 2017-01-09 19:29:59 --> Language Class Initialized
INFO - 2017-01-09 19:29:59 --> Loader Class Initialized
INFO - 2017-01-09 19:29:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:29:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:29:59 --> Controller Class Initialized
INFO - 2017-01-09 19:29:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:29:59 --> Model Class Initialized
INFO - 2017-01-09 19:29:59 --> Model Class Initialized
INFO - 2017-01-09 19:29:59 --> Model Class Initialized
INFO - 2017-01-09 19:29:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:29:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:29:59 --> Total execution time: 0.0802
INFO - 2017-01-09 19:30:29 --> Config Class Initialized
INFO - 2017-01-09 19:30:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:30:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:30:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:30:29 --> URI Class Initialized
INFO - 2017-01-09 19:30:29 --> Router Class Initialized
INFO - 2017-01-09 19:30:29 --> Output Class Initialized
INFO - 2017-01-09 19:30:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:30:29 --> Input Class Initialized
INFO - 2017-01-09 19:30:29 --> Language Class Initialized
INFO - 2017-01-09 19:30:29 --> Loader Class Initialized
INFO - 2017-01-09 19:30:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:30:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:30:29 --> Controller Class Initialized
INFO - 2017-01-09 19:30:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:30:29 --> Model Class Initialized
INFO - 2017-01-09 19:30:29 --> Model Class Initialized
INFO - 2017-01-09 19:30:29 --> Model Class Initialized
INFO - 2017-01-09 19:30:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:30:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:30:29 --> Total execution time: 0.0764
INFO - 2017-01-09 19:30:59 --> Config Class Initialized
INFO - 2017-01-09 19:30:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:30:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:30:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:30:59 --> URI Class Initialized
INFO - 2017-01-09 19:30:59 --> Router Class Initialized
INFO - 2017-01-09 19:30:59 --> Output Class Initialized
INFO - 2017-01-09 19:30:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:30:59 --> Input Class Initialized
INFO - 2017-01-09 19:30:59 --> Language Class Initialized
INFO - 2017-01-09 19:30:59 --> Loader Class Initialized
INFO - 2017-01-09 19:30:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:30:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:30:59 --> Controller Class Initialized
INFO - 2017-01-09 19:30:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:30:59 --> Model Class Initialized
INFO - 2017-01-09 19:30:59 --> Model Class Initialized
INFO - 2017-01-09 19:30:59 --> Model Class Initialized
INFO - 2017-01-09 19:30:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:30:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:30:59 --> Total execution time: 0.0822
INFO - 2017-01-09 19:31:29 --> Config Class Initialized
INFO - 2017-01-09 19:31:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:31:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:31:29 --> URI Class Initialized
INFO - 2017-01-09 19:31:29 --> Router Class Initialized
INFO - 2017-01-09 19:31:29 --> Output Class Initialized
INFO - 2017-01-09 19:31:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:31:29 --> Input Class Initialized
INFO - 2017-01-09 19:31:29 --> Language Class Initialized
INFO - 2017-01-09 19:31:29 --> Loader Class Initialized
INFO - 2017-01-09 19:31:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:31:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:31:29 --> Controller Class Initialized
INFO - 2017-01-09 19:31:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:31:29 --> Model Class Initialized
INFO - 2017-01-09 19:31:29 --> Model Class Initialized
INFO - 2017-01-09 19:31:29 --> Model Class Initialized
INFO - 2017-01-09 19:31:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:31:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:31:29 --> Total execution time: 0.0871
INFO - 2017-01-09 19:31:59 --> Config Class Initialized
INFO - 2017-01-09 19:31:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:31:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:31:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:31:59 --> URI Class Initialized
INFO - 2017-01-09 19:31:59 --> Router Class Initialized
INFO - 2017-01-09 19:31:59 --> Output Class Initialized
INFO - 2017-01-09 19:31:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:31:59 --> Input Class Initialized
INFO - 2017-01-09 19:31:59 --> Language Class Initialized
INFO - 2017-01-09 19:31:59 --> Loader Class Initialized
INFO - 2017-01-09 19:31:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:31:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:31:59 --> Controller Class Initialized
INFO - 2017-01-09 19:31:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:31:59 --> Model Class Initialized
INFO - 2017-01-09 19:31:59 --> Model Class Initialized
INFO - 2017-01-09 19:31:59 --> Model Class Initialized
INFO - 2017-01-09 19:31:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:31:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:31:59 --> Total execution time: 0.1042
INFO - 2017-01-09 19:32:29 --> Config Class Initialized
INFO - 2017-01-09 19:32:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:32:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:32:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:32:29 --> URI Class Initialized
INFO - 2017-01-09 19:32:29 --> Router Class Initialized
INFO - 2017-01-09 19:32:29 --> Output Class Initialized
INFO - 2017-01-09 19:32:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:32:29 --> Input Class Initialized
INFO - 2017-01-09 19:32:29 --> Language Class Initialized
INFO - 2017-01-09 19:32:29 --> Loader Class Initialized
INFO - 2017-01-09 19:32:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:32:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:32:29 --> Controller Class Initialized
INFO - 2017-01-09 19:32:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:32:29 --> Model Class Initialized
INFO - 2017-01-09 19:32:29 --> Model Class Initialized
INFO - 2017-01-09 19:32:29 --> Model Class Initialized
INFO - 2017-01-09 19:32:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:32:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:32:29 --> Total execution time: 0.0725
INFO - 2017-01-09 19:32:59 --> Config Class Initialized
INFO - 2017-01-09 19:32:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:32:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:32:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:32:59 --> URI Class Initialized
INFO - 2017-01-09 19:32:59 --> Router Class Initialized
INFO - 2017-01-09 19:32:59 --> Output Class Initialized
INFO - 2017-01-09 19:32:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:32:59 --> Input Class Initialized
INFO - 2017-01-09 19:32:59 --> Language Class Initialized
INFO - 2017-01-09 19:32:59 --> Loader Class Initialized
INFO - 2017-01-09 19:32:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:32:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:32:59 --> Controller Class Initialized
INFO - 2017-01-09 19:32:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:32:59 --> Model Class Initialized
INFO - 2017-01-09 19:32:59 --> Model Class Initialized
INFO - 2017-01-09 19:32:59 --> Model Class Initialized
INFO - 2017-01-09 19:32:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:32:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:32:59 --> Total execution time: 0.0927
INFO - 2017-01-09 19:33:29 --> Config Class Initialized
INFO - 2017-01-09 19:33:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:33:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:33:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:33:29 --> URI Class Initialized
INFO - 2017-01-09 19:33:29 --> Router Class Initialized
INFO - 2017-01-09 19:33:29 --> Output Class Initialized
INFO - 2017-01-09 19:33:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:33:29 --> Input Class Initialized
INFO - 2017-01-09 19:33:29 --> Language Class Initialized
INFO - 2017-01-09 19:33:29 --> Loader Class Initialized
INFO - 2017-01-09 19:33:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:33:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:33:29 --> Controller Class Initialized
INFO - 2017-01-09 19:33:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:33:29 --> Model Class Initialized
INFO - 2017-01-09 19:33:29 --> Model Class Initialized
INFO - 2017-01-09 19:33:29 --> Model Class Initialized
INFO - 2017-01-09 19:33:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:33:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:33:29 --> Total execution time: 0.1170
INFO - 2017-01-09 19:33:59 --> Config Class Initialized
INFO - 2017-01-09 19:33:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:33:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:33:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:33:59 --> URI Class Initialized
INFO - 2017-01-09 19:33:59 --> Router Class Initialized
INFO - 2017-01-09 19:33:59 --> Output Class Initialized
INFO - 2017-01-09 19:33:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:33:59 --> Input Class Initialized
INFO - 2017-01-09 19:33:59 --> Language Class Initialized
INFO - 2017-01-09 19:33:59 --> Loader Class Initialized
INFO - 2017-01-09 19:33:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:33:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:33:59 --> Controller Class Initialized
INFO - 2017-01-09 19:33:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:33:59 --> Model Class Initialized
INFO - 2017-01-09 19:33:59 --> Model Class Initialized
INFO - 2017-01-09 19:33:59 --> Model Class Initialized
INFO - 2017-01-09 19:33:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:33:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:33:59 --> Total execution time: 0.1086
INFO - 2017-01-09 19:34:29 --> Config Class Initialized
INFO - 2017-01-09 19:34:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:34:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:34:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:34:29 --> URI Class Initialized
INFO - 2017-01-09 19:34:29 --> Router Class Initialized
INFO - 2017-01-09 19:34:29 --> Output Class Initialized
INFO - 2017-01-09 19:34:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:34:29 --> Input Class Initialized
INFO - 2017-01-09 19:34:29 --> Language Class Initialized
INFO - 2017-01-09 19:34:29 --> Loader Class Initialized
INFO - 2017-01-09 19:34:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:34:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:34:29 --> Controller Class Initialized
INFO - 2017-01-09 19:34:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:34:29 --> Model Class Initialized
INFO - 2017-01-09 19:34:29 --> Model Class Initialized
INFO - 2017-01-09 19:34:29 --> Model Class Initialized
INFO - 2017-01-09 19:34:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:34:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:34:29 --> Total execution time: 0.0830
INFO - 2017-01-09 19:34:59 --> Config Class Initialized
INFO - 2017-01-09 19:34:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:34:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:34:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:34:59 --> URI Class Initialized
INFO - 2017-01-09 19:34:59 --> Router Class Initialized
INFO - 2017-01-09 19:34:59 --> Output Class Initialized
INFO - 2017-01-09 19:34:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:34:59 --> Input Class Initialized
INFO - 2017-01-09 19:34:59 --> Language Class Initialized
INFO - 2017-01-09 19:34:59 --> Loader Class Initialized
INFO - 2017-01-09 19:34:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:34:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:34:59 --> Controller Class Initialized
INFO - 2017-01-09 19:34:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:34:59 --> Model Class Initialized
INFO - 2017-01-09 19:34:59 --> Model Class Initialized
INFO - 2017-01-09 19:34:59 --> Model Class Initialized
INFO - 2017-01-09 19:34:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:34:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:34:59 --> Total execution time: 0.0822
INFO - 2017-01-09 19:35:29 --> Config Class Initialized
INFO - 2017-01-09 19:35:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:35:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:35:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:35:29 --> URI Class Initialized
INFO - 2017-01-09 19:35:29 --> Router Class Initialized
INFO - 2017-01-09 19:35:29 --> Output Class Initialized
INFO - 2017-01-09 19:35:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:35:29 --> Input Class Initialized
INFO - 2017-01-09 19:35:29 --> Language Class Initialized
INFO - 2017-01-09 19:35:29 --> Loader Class Initialized
INFO - 2017-01-09 19:35:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:35:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:35:29 --> Controller Class Initialized
INFO - 2017-01-09 19:35:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:35:29 --> Model Class Initialized
INFO - 2017-01-09 19:35:29 --> Model Class Initialized
INFO - 2017-01-09 19:35:29 --> Model Class Initialized
INFO - 2017-01-09 19:35:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:35:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:35:29 --> Total execution time: 0.0800
INFO - 2017-01-09 19:35:59 --> Config Class Initialized
INFO - 2017-01-09 19:35:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:35:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:35:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:35:59 --> URI Class Initialized
INFO - 2017-01-09 19:35:59 --> Router Class Initialized
INFO - 2017-01-09 19:35:59 --> Output Class Initialized
INFO - 2017-01-09 19:35:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:35:59 --> Input Class Initialized
INFO - 2017-01-09 19:35:59 --> Language Class Initialized
INFO - 2017-01-09 19:35:59 --> Loader Class Initialized
INFO - 2017-01-09 19:35:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:35:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:35:59 --> Controller Class Initialized
INFO - 2017-01-09 19:35:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:35:59 --> Model Class Initialized
INFO - 2017-01-09 19:35:59 --> Model Class Initialized
INFO - 2017-01-09 19:35:59 --> Model Class Initialized
INFO - 2017-01-09 19:35:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:35:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:35:59 --> Total execution time: 0.1627
INFO - 2017-01-09 19:36:29 --> Config Class Initialized
INFO - 2017-01-09 19:36:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:36:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:36:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:36:29 --> URI Class Initialized
INFO - 2017-01-09 19:36:29 --> Router Class Initialized
INFO - 2017-01-09 19:36:29 --> Output Class Initialized
INFO - 2017-01-09 19:36:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:36:29 --> Input Class Initialized
INFO - 2017-01-09 19:36:29 --> Language Class Initialized
INFO - 2017-01-09 19:36:29 --> Loader Class Initialized
INFO - 2017-01-09 19:36:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:36:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:36:29 --> Controller Class Initialized
INFO - 2017-01-09 19:36:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:36:29 --> Model Class Initialized
INFO - 2017-01-09 19:36:29 --> Model Class Initialized
INFO - 2017-01-09 19:36:29 --> Model Class Initialized
INFO - 2017-01-09 19:36:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:36:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:36:29 --> Total execution time: 0.0953
INFO - 2017-01-09 19:36:59 --> Config Class Initialized
INFO - 2017-01-09 19:36:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:36:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:36:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:36:59 --> URI Class Initialized
INFO - 2017-01-09 19:36:59 --> Router Class Initialized
INFO - 2017-01-09 19:36:59 --> Output Class Initialized
INFO - 2017-01-09 19:36:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:36:59 --> Input Class Initialized
INFO - 2017-01-09 19:36:59 --> Language Class Initialized
INFO - 2017-01-09 19:36:59 --> Loader Class Initialized
INFO - 2017-01-09 19:36:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:36:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:36:59 --> Controller Class Initialized
INFO - 2017-01-09 19:36:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:36:59 --> Model Class Initialized
INFO - 2017-01-09 19:36:59 --> Model Class Initialized
INFO - 2017-01-09 19:36:59 --> Model Class Initialized
INFO - 2017-01-09 19:36:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:36:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:36:59 --> Total execution time: 0.1029
INFO - 2017-01-09 19:37:29 --> Config Class Initialized
INFO - 2017-01-09 19:37:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:37:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:37:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:37:29 --> URI Class Initialized
INFO - 2017-01-09 19:37:29 --> Router Class Initialized
INFO - 2017-01-09 19:37:29 --> Output Class Initialized
INFO - 2017-01-09 19:37:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:37:29 --> Input Class Initialized
INFO - 2017-01-09 19:37:29 --> Language Class Initialized
INFO - 2017-01-09 19:37:29 --> Loader Class Initialized
INFO - 2017-01-09 19:37:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:37:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:37:29 --> Controller Class Initialized
INFO - 2017-01-09 19:37:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:37:29 --> Model Class Initialized
INFO - 2017-01-09 19:37:29 --> Model Class Initialized
INFO - 2017-01-09 19:37:29 --> Model Class Initialized
INFO - 2017-01-09 19:37:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:37:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:37:29 --> Total execution time: 0.1106
INFO - 2017-01-09 19:37:59 --> Config Class Initialized
INFO - 2017-01-09 19:37:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:37:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:37:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:37:59 --> URI Class Initialized
INFO - 2017-01-09 19:37:59 --> Router Class Initialized
INFO - 2017-01-09 19:37:59 --> Output Class Initialized
INFO - 2017-01-09 19:37:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:37:59 --> Input Class Initialized
INFO - 2017-01-09 19:37:59 --> Language Class Initialized
INFO - 2017-01-09 19:37:59 --> Loader Class Initialized
INFO - 2017-01-09 19:37:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:37:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:37:59 --> Controller Class Initialized
INFO - 2017-01-09 19:37:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:37:59 --> Model Class Initialized
INFO - 2017-01-09 19:37:59 --> Model Class Initialized
INFO - 2017-01-09 19:37:59 --> Model Class Initialized
INFO - 2017-01-09 19:37:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:37:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:37:59 --> Total execution time: 0.1772
INFO - 2017-01-09 19:38:29 --> Config Class Initialized
INFO - 2017-01-09 19:38:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:38:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:38:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:38:29 --> URI Class Initialized
INFO - 2017-01-09 19:38:29 --> Router Class Initialized
INFO - 2017-01-09 19:38:29 --> Output Class Initialized
INFO - 2017-01-09 19:38:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:38:29 --> Input Class Initialized
INFO - 2017-01-09 19:38:29 --> Language Class Initialized
INFO - 2017-01-09 19:38:29 --> Loader Class Initialized
INFO - 2017-01-09 19:38:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:38:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:38:29 --> Controller Class Initialized
INFO - 2017-01-09 19:38:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:38:29 --> Model Class Initialized
INFO - 2017-01-09 19:38:29 --> Model Class Initialized
INFO - 2017-01-09 19:38:29 --> Model Class Initialized
INFO - 2017-01-09 19:38:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:38:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:38:29 --> Total execution time: 0.0854
INFO - 2017-01-09 19:38:59 --> Config Class Initialized
INFO - 2017-01-09 19:38:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:38:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:38:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:38:59 --> URI Class Initialized
INFO - 2017-01-09 19:38:59 --> Router Class Initialized
INFO - 2017-01-09 19:38:59 --> Output Class Initialized
INFO - 2017-01-09 19:38:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:38:59 --> Input Class Initialized
INFO - 2017-01-09 19:38:59 --> Language Class Initialized
INFO - 2017-01-09 19:38:59 --> Loader Class Initialized
INFO - 2017-01-09 19:38:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:38:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:38:59 --> Controller Class Initialized
INFO - 2017-01-09 19:38:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:38:59 --> Model Class Initialized
INFO - 2017-01-09 19:38:59 --> Model Class Initialized
INFO - 2017-01-09 19:38:59 --> Model Class Initialized
INFO - 2017-01-09 19:38:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:38:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:38:59 --> Total execution time: 0.0907
INFO - 2017-01-09 19:39:29 --> Config Class Initialized
INFO - 2017-01-09 19:39:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:39:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:39:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:39:29 --> URI Class Initialized
INFO - 2017-01-09 19:39:29 --> Router Class Initialized
INFO - 2017-01-09 19:39:29 --> Output Class Initialized
INFO - 2017-01-09 19:39:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:39:29 --> Input Class Initialized
INFO - 2017-01-09 19:39:29 --> Language Class Initialized
INFO - 2017-01-09 19:39:29 --> Loader Class Initialized
INFO - 2017-01-09 19:39:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:39:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:39:29 --> Controller Class Initialized
INFO - 2017-01-09 19:39:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:39:29 --> Model Class Initialized
INFO - 2017-01-09 19:39:29 --> Model Class Initialized
INFO - 2017-01-09 19:39:29 --> Model Class Initialized
INFO - 2017-01-09 19:39:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:39:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:39:29 --> Total execution time: 0.0805
INFO - 2017-01-09 19:39:59 --> Config Class Initialized
INFO - 2017-01-09 19:39:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:39:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:39:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:39:59 --> URI Class Initialized
INFO - 2017-01-09 19:39:59 --> Router Class Initialized
INFO - 2017-01-09 19:39:59 --> Output Class Initialized
INFO - 2017-01-09 19:39:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:39:59 --> Input Class Initialized
INFO - 2017-01-09 19:39:59 --> Language Class Initialized
INFO - 2017-01-09 19:39:59 --> Loader Class Initialized
INFO - 2017-01-09 19:39:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:39:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:39:59 --> Controller Class Initialized
INFO - 2017-01-09 19:39:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:39:59 --> Model Class Initialized
INFO - 2017-01-09 19:39:59 --> Model Class Initialized
INFO - 2017-01-09 19:39:59 --> Model Class Initialized
INFO - 2017-01-09 19:39:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:39:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:39:59 --> Total execution time: 0.1077
INFO - 2017-01-09 19:40:29 --> Config Class Initialized
INFO - 2017-01-09 19:40:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:40:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:40:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:40:29 --> URI Class Initialized
INFO - 2017-01-09 19:40:29 --> Router Class Initialized
INFO - 2017-01-09 19:40:29 --> Output Class Initialized
INFO - 2017-01-09 19:40:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:40:29 --> Input Class Initialized
INFO - 2017-01-09 19:40:29 --> Language Class Initialized
INFO - 2017-01-09 19:40:29 --> Loader Class Initialized
INFO - 2017-01-09 19:40:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:40:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:40:29 --> Controller Class Initialized
INFO - 2017-01-09 19:40:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:40:29 --> Model Class Initialized
INFO - 2017-01-09 19:40:29 --> Model Class Initialized
INFO - 2017-01-09 19:40:29 --> Model Class Initialized
INFO - 2017-01-09 19:40:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:40:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:40:29 --> Total execution time: 0.0978
INFO - 2017-01-09 19:40:59 --> Config Class Initialized
INFO - 2017-01-09 19:40:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:40:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:40:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:40:59 --> URI Class Initialized
INFO - 2017-01-09 19:40:59 --> Router Class Initialized
INFO - 2017-01-09 19:40:59 --> Output Class Initialized
INFO - 2017-01-09 19:40:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:40:59 --> Input Class Initialized
INFO - 2017-01-09 19:40:59 --> Language Class Initialized
INFO - 2017-01-09 19:40:59 --> Loader Class Initialized
INFO - 2017-01-09 19:40:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:40:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:40:59 --> Controller Class Initialized
INFO - 2017-01-09 19:40:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:40:59 --> Model Class Initialized
INFO - 2017-01-09 19:40:59 --> Model Class Initialized
INFO - 2017-01-09 19:40:59 --> Model Class Initialized
INFO - 2017-01-09 19:40:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:40:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:40:59 --> Total execution time: 0.0786
INFO - 2017-01-09 19:41:29 --> Config Class Initialized
INFO - 2017-01-09 19:41:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:41:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:41:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:41:29 --> URI Class Initialized
INFO - 2017-01-09 19:41:29 --> Router Class Initialized
INFO - 2017-01-09 19:41:29 --> Output Class Initialized
INFO - 2017-01-09 19:41:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:41:29 --> Input Class Initialized
INFO - 2017-01-09 19:41:29 --> Language Class Initialized
INFO - 2017-01-09 19:41:29 --> Loader Class Initialized
INFO - 2017-01-09 19:41:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:41:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:41:29 --> Controller Class Initialized
INFO - 2017-01-09 19:41:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:41:29 --> Model Class Initialized
INFO - 2017-01-09 19:41:29 --> Model Class Initialized
INFO - 2017-01-09 19:41:29 --> Model Class Initialized
INFO - 2017-01-09 19:41:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:41:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:41:29 --> Total execution time: 0.1043
INFO - 2017-01-09 19:41:59 --> Config Class Initialized
INFO - 2017-01-09 19:41:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:41:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:41:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:41:59 --> URI Class Initialized
INFO - 2017-01-09 19:41:59 --> Router Class Initialized
INFO - 2017-01-09 19:41:59 --> Output Class Initialized
INFO - 2017-01-09 19:41:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:41:59 --> Input Class Initialized
INFO - 2017-01-09 19:41:59 --> Language Class Initialized
INFO - 2017-01-09 19:41:59 --> Loader Class Initialized
INFO - 2017-01-09 19:41:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:41:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:41:59 --> Controller Class Initialized
INFO - 2017-01-09 19:41:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:41:59 --> Model Class Initialized
INFO - 2017-01-09 19:41:59 --> Model Class Initialized
INFO - 2017-01-09 19:41:59 --> Model Class Initialized
INFO - 2017-01-09 19:41:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:41:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:41:59 --> Total execution time: 0.0707
INFO - 2017-01-09 19:42:29 --> Config Class Initialized
INFO - 2017-01-09 19:42:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:42:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:42:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:42:29 --> URI Class Initialized
INFO - 2017-01-09 19:42:29 --> Router Class Initialized
INFO - 2017-01-09 19:42:29 --> Output Class Initialized
INFO - 2017-01-09 19:42:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:42:29 --> Input Class Initialized
INFO - 2017-01-09 19:42:29 --> Language Class Initialized
INFO - 2017-01-09 19:42:29 --> Loader Class Initialized
INFO - 2017-01-09 19:42:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:42:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:42:29 --> Controller Class Initialized
INFO - 2017-01-09 19:42:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:42:29 --> Model Class Initialized
INFO - 2017-01-09 19:42:29 --> Model Class Initialized
INFO - 2017-01-09 19:42:29 --> Model Class Initialized
INFO - 2017-01-09 19:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:42:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:42:29 --> Total execution time: 0.0724
INFO - 2017-01-09 19:42:59 --> Config Class Initialized
INFO - 2017-01-09 19:42:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:42:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:42:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:42:59 --> URI Class Initialized
INFO - 2017-01-09 19:42:59 --> Router Class Initialized
INFO - 2017-01-09 19:42:59 --> Output Class Initialized
INFO - 2017-01-09 19:42:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:42:59 --> Input Class Initialized
INFO - 2017-01-09 19:42:59 --> Language Class Initialized
INFO - 2017-01-09 19:42:59 --> Loader Class Initialized
INFO - 2017-01-09 19:42:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:42:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:42:59 --> Controller Class Initialized
INFO - 2017-01-09 19:42:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:42:59 --> Model Class Initialized
INFO - 2017-01-09 19:42:59 --> Model Class Initialized
INFO - 2017-01-09 19:42:59 --> Model Class Initialized
INFO - 2017-01-09 19:42:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:42:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:42:59 --> Total execution time: 0.0785
INFO - 2017-01-09 19:43:29 --> Config Class Initialized
INFO - 2017-01-09 19:43:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:43:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:43:29 --> Utf8 Class Initialized
INFO - 2017-01-09 19:43:29 --> URI Class Initialized
INFO - 2017-01-09 19:43:29 --> Router Class Initialized
INFO - 2017-01-09 19:43:29 --> Output Class Initialized
INFO - 2017-01-09 19:43:29 --> Security Class Initialized
DEBUG - 2017-01-09 19:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:43:29 --> Input Class Initialized
INFO - 2017-01-09 19:43:29 --> Language Class Initialized
INFO - 2017-01-09 19:43:29 --> Loader Class Initialized
INFO - 2017-01-09 19:43:29 --> Helper loaded: url_helper
INFO - 2017-01-09 19:43:29 --> Helper loaded: language_helper
INFO - 2017-01-09 19:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:43:29 --> Controller Class Initialized
INFO - 2017-01-09 19:43:29 --> Database Driver Class Initialized
INFO - 2017-01-09 19:43:29 --> Model Class Initialized
INFO - 2017-01-09 19:43:29 --> Model Class Initialized
INFO - 2017-01-09 19:43:29 --> Model Class Initialized
INFO - 2017-01-09 19:43:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:43:29 --> Final output sent to browser
DEBUG - 2017-01-09 19:43:29 --> Total execution time: 0.0881
INFO - 2017-01-09 19:43:59 --> Config Class Initialized
INFO - 2017-01-09 19:43:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:43:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:43:59 --> Utf8 Class Initialized
INFO - 2017-01-09 19:43:59 --> URI Class Initialized
INFO - 2017-01-09 19:43:59 --> Router Class Initialized
INFO - 2017-01-09 19:43:59 --> Output Class Initialized
INFO - 2017-01-09 19:43:59 --> Security Class Initialized
DEBUG - 2017-01-09 19:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:43:59 --> Input Class Initialized
INFO - 2017-01-09 19:43:59 --> Language Class Initialized
INFO - 2017-01-09 19:43:59 --> Loader Class Initialized
INFO - 2017-01-09 19:43:59 --> Helper loaded: url_helper
INFO - 2017-01-09 19:43:59 --> Helper loaded: language_helper
INFO - 2017-01-09 19:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:43:59 --> Controller Class Initialized
INFO - 2017-01-09 19:43:59 --> Database Driver Class Initialized
INFO - 2017-01-09 19:43:59 --> Model Class Initialized
INFO - 2017-01-09 19:43:59 --> Model Class Initialized
INFO - 2017-01-09 19:43:59 --> Model Class Initialized
INFO - 2017-01-09 19:43:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:43:59 --> Final output sent to browser
DEBUG - 2017-01-09 19:43:59 --> Total execution time: 0.0820
INFO - 2017-01-09 19:44:06 --> Config Class Initialized
INFO - 2017-01-09 19:44:06 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:44:06 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:44:06 --> Utf8 Class Initialized
INFO - 2017-01-09 19:44:06 --> URI Class Initialized
INFO - 2017-01-09 19:44:06 --> Router Class Initialized
INFO - 2017-01-09 19:44:06 --> Output Class Initialized
INFO - 2017-01-09 19:44:06 --> Security Class Initialized
DEBUG - 2017-01-09 19:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:44:06 --> Input Class Initialized
INFO - 2017-01-09 19:44:06 --> Language Class Initialized
INFO - 2017-01-09 19:44:06 --> Loader Class Initialized
INFO - 2017-01-09 19:44:06 --> Helper loaded: url_helper
INFO - 2017-01-09 19:44:06 --> Helper loaded: language_helper
INFO - 2017-01-09 19:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:44:06 --> Controller Class Initialized
INFO - 2017-01-09 19:44:06 --> Database Driver Class Initialized
INFO - 2017-01-09 19:44:06 --> Model Class Initialized
INFO - 2017-01-09 19:44:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:44:06 --> Config Class Initialized
INFO - 2017-01-09 19:44:06 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:44:06 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:44:06 --> Utf8 Class Initialized
INFO - 2017-01-09 19:44:06 --> URI Class Initialized
INFO - 2017-01-09 19:44:06 --> Router Class Initialized
INFO - 2017-01-09 19:44:06 --> Output Class Initialized
INFO - 2017-01-09 19:44:06 --> Security Class Initialized
DEBUG - 2017-01-09 19:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:44:06 --> Input Class Initialized
INFO - 2017-01-09 19:44:06 --> Language Class Initialized
INFO - 2017-01-09 19:44:06 --> Loader Class Initialized
INFO - 2017-01-09 19:44:06 --> Helper loaded: url_helper
INFO - 2017-01-09 19:44:06 --> Helper loaded: language_helper
INFO - 2017-01-09 19:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:44:06 --> Controller Class Initialized
INFO - 2017-01-09 19:44:07 --> Database Driver Class Initialized
INFO - 2017-01-09 19:44:07 --> Model Class Initialized
INFO - 2017-01-09 19:44:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:44:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 19:44:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 19:44:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 19:44:07 --> Final output sent to browser
DEBUG - 2017-01-09 19:44:07 --> Total execution time: 0.0716
INFO - 2017-01-09 19:44:12 --> Config Class Initialized
INFO - 2017-01-09 19:44:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:44:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:44:12 --> Utf8 Class Initialized
INFO - 2017-01-09 19:44:12 --> URI Class Initialized
INFO - 2017-01-09 19:44:12 --> Router Class Initialized
INFO - 2017-01-09 19:44:12 --> Output Class Initialized
INFO - 2017-01-09 19:44:12 --> Security Class Initialized
DEBUG - 2017-01-09 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:44:12 --> Input Class Initialized
INFO - 2017-01-09 19:44:12 --> Language Class Initialized
INFO - 2017-01-09 19:44:12 --> Loader Class Initialized
INFO - 2017-01-09 19:44:12 --> Helper loaded: url_helper
INFO - 2017-01-09 19:44:12 --> Helper loaded: language_helper
INFO - 2017-01-09 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:44:12 --> Controller Class Initialized
INFO - 2017-01-09 19:44:12 --> Database Driver Class Initialized
INFO - 2017-01-09 19:44:12 --> Model Class Initialized
INFO - 2017-01-09 19:44:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:44:12 --> Config Class Initialized
INFO - 2017-01-09 19:44:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:44:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:44:12 --> Utf8 Class Initialized
INFO - 2017-01-09 19:44:12 --> URI Class Initialized
INFO - 2017-01-09 19:44:12 --> Router Class Initialized
INFO - 2017-01-09 19:44:12 --> Output Class Initialized
INFO - 2017-01-09 19:44:12 --> Security Class Initialized
DEBUG - 2017-01-09 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:44:12 --> Input Class Initialized
INFO - 2017-01-09 19:44:12 --> Language Class Initialized
INFO - 2017-01-09 19:44:12 --> Loader Class Initialized
INFO - 2017-01-09 19:44:12 --> Helper loaded: url_helper
INFO - 2017-01-09 19:44:12 --> Helper loaded: language_helper
INFO - 2017-01-09 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:44:12 --> Controller Class Initialized
INFO - 2017-01-09 19:44:12 --> Database Driver Class Initialized
INFO - 2017-01-09 19:44:12 --> Model Class Initialized
INFO - 2017-01-09 19:44:12 --> Model Class Initialized
INFO - 2017-01-09 19:44:12 --> Model Class Initialized
INFO - 2017-01-09 19:44:12 --> Model Class Initialized
INFO - 2017-01-09 19:44:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:44:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 19:44:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 19:44:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 19:44:12 --> Final output sent to browser
DEBUG - 2017-01-09 19:44:12 --> Total execution time: 0.1365
INFO - 2017-01-09 19:59:56 --> Config Class Initialized
INFO - 2017-01-09 19:59:56 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:59:56 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:59:56 --> Utf8 Class Initialized
INFO - 2017-01-09 19:59:57 --> URI Class Initialized
INFO - 2017-01-09 19:59:57 --> Router Class Initialized
INFO - 2017-01-09 19:59:57 --> Output Class Initialized
INFO - 2017-01-09 19:59:57 --> Security Class Initialized
DEBUG - 2017-01-09 19:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:59:57 --> Input Class Initialized
INFO - 2017-01-09 19:59:57 --> Language Class Initialized
INFO - 2017-01-09 19:59:57 --> Loader Class Initialized
INFO - 2017-01-09 19:59:57 --> Helper loaded: url_helper
INFO - 2017-01-09 19:59:57 --> Helper loaded: language_helper
INFO - 2017-01-09 19:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:59:57 --> Controller Class Initialized
INFO - 2017-01-09 19:59:57 --> Database Driver Class Initialized
INFO - 2017-01-09 19:59:57 --> Model Class Initialized
INFO - 2017-01-09 19:59:57 --> Model Class Initialized
INFO - 2017-01-09 19:59:57 --> Model Class Initialized
INFO - 2017-01-09 19:59:57 --> Model Class Initialized
INFO - 2017-01-09 19:59:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:59:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 19:59:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 19:59:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 19:59:57 --> Final output sent to browser
DEBUG - 2017-01-09 19:59:57 --> Total execution time: 0.1455
INFO - 2017-01-09 19:59:58 --> Config Class Initialized
INFO - 2017-01-09 19:59:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:59:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:59:58 --> Utf8 Class Initialized
INFO - 2017-01-09 19:59:58 --> URI Class Initialized
INFO - 2017-01-09 19:59:58 --> Router Class Initialized
INFO - 2017-01-09 19:59:58 --> Output Class Initialized
INFO - 2017-01-09 19:59:58 --> Security Class Initialized
DEBUG - 2017-01-09 19:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:59:58 --> Input Class Initialized
INFO - 2017-01-09 19:59:58 --> Language Class Initialized
INFO - 2017-01-09 19:59:58 --> Loader Class Initialized
INFO - 2017-01-09 19:59:58 --> Helper loaded: url_helper
INFO - 2017-01-09 19:59:58 --> Helper loaded: language_helper
INFO - 2017-01-09 19:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:59:58 --> Controller Class Initialized
INFO - 2017-01-09 19:59:58 --> Database Driver Class Initialized
INFO - 2017-01-09 19:59:58 --> Model Class Initialized
INFO - 2017-01-09 19:59:58 --> Model Class Initialized
INFO - 2017-01-09 19:59:58 --> Model Class Initialized
INFO - 2017-01-09 19:59:58 --> Model Class Initialized
INFO - 2017-01-09 19:59:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 19:59:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 19:59:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 19:59:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 19:59:58 --> Final output sent to browser
DEBUG - 2017-01-09 19:59:58 --> Total execution time: 0.1867
INFO - 2017-01-09 20:06:18 --> Config Class Initialized
INFO - 2017-01-09 20:06:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:18 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:18 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:18 --> URI Class Initialized
INFO - 2017-01-09 20:06:18 --> Router Class Initialized
INFO - 2017-01-09 20:06:18 --> Output Class Initialized
INFO - 2017-01-09 20:06:18 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:18 --> Input Class Initialized
INFO - 2017-01-09 20:06:18 --> Language Class Initialized
INFO - 2017-01-09 20:06:18 --> Loader Class Initialized
INFO - 2017-01-09 20:06:18 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:18 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:18 --> Controller Class Initialized
INFO - 2017-01-09 20:06:18 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:18 --> Model Class Initialized
INFO - 2017-01-09 20:06:18 --> Model Class Initialized
INFO - 2017-01-09 20:06:18 --> Model Class Initialized
INFO - 2017-01-09 20:06:18 --> Model Class Initialized
INFO - 2017-01-09 20:06:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:06:18 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:18 --> Total execution time: 0.1102
INFO - 2017-01-09 20:06:21 --> Config Class Initialized
INFO - 2017-01-09 20:06:21 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:21 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:21 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:21 --> URI Class Initialized
DEBUG - 2017-01-09 20:06:21 --> No URI present. Default controller set.
INFO - 2017-01-09 20:06:21 --> Router Class Initialized
INFO - 2017-01-09 20:06:21 --> Output Class Initialized
INFO - 2017-01-09 20:06:21 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:21 --> Input Class Initialized
INFO - 2017-01-09 20:06:21 --> Language Class Initialized
INFO - 2017-01-09 20:06:21 --> Loader Class Initialized
INFO - 2017-01-09 20:06:21 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:21 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:21 --> Controller Class Initialized
INFO - 2017-01-09 20:06:21 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:21 --> Model Class Initialized
INFO - 2017-01-09 20:06:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:21 --> Config Class Initialized
INFO - 2017-01-09 20:06:21 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:21 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:21 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:21 --> URI Class Initialized
INFO - 2017-01-09 20:06:21 --> Router Class Initialized
INFO - 2017-01-09 20:06:21 --> Output Class Initialized
INFO - 2017-01-09 20:06:21 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:21 --> Input Class Initialized
INFO - 2017-01-09 20:06:21 --> Language Class Initialized
INFO - 2017-01-09 20:06:21 --> Loader Class Initialized
INFO - 2017-01-09 20:06:21 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:21 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:21 --> Controller Class Initialized
INFO - 2017-01-09 20:06:21 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:21 --> Model Class Initialized
INFO - 2017-01-09 20:06:21 --> Model Class Initialized
INFO - 2017-01-09 20:06:21 --> Model Class Initialized
INFO - 2017-01-09 20:06:21 --> Model Class Initialized
INFO - 2017-01-09 20:06:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:06:21 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:21 --> Total execution time: 0.1110
INFO - 2017-01-09 20:06:24 --> Config Class Initialized
INFO - 2017-01-09 20:06:24 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:24 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:24 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:24 --> URI Class Initialized
INFO - 2017-01-09 20:06:24 --> Router Class Initialized
INFO - 2017-01-09 20:06:24 --> Output Class Initialized
INFO - 2017-01-09 20:06:24 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:24 --> Input Class Initialized
INFO - 2017-01-09 20:06:24 --> Language Class Initialized
INFO - 2017-01-09 20:06:24 --> Loader Class Initialized
INFO - 2017-01-09 20:06:24 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:24 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:24 --> Controller Class Initialized
INFO - 2017-01-09 20:06:24 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:24 --> Model Class Initialized
INFO - 2017-01-09 20:06:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-09 20:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:06:24 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:24 --> Total execution time: 0.0929
INFO - 2017-01-09 20:06:25 --> Config Class Initialized
INFO - 2017-01-09 20:06:25 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:25 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:25 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:25 --> URI Class Initialized
INFO - 2017-01-09 20:06:25 --> Router Class Initialized
INFO - 2017-01-09 20:06:25 --> Output Class Initialized
INFO - 2017-01-09 20:06:25 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:25 --> Input Class Initialized
INFO - 2017-01-09 20:06:25 --> Language Class Initialized
INFO - 2017-01-09 20:06:25 --> Loader Class Initialized
INFO - 2017-01-09 20:06:25 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:25 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:25 --> Controller Class Initialized
INFO - 2017-01-09 20:06:25 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:25 --> Model Class Initialized
INFO - 2017-01-09 20:06:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:25 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:25 --> Total execution time: 0.1055
INFO - 2017-01-09 20:06:26 --> Config Class Initialized
INFO - 2017-01-09 20:06:26 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:26 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:26 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:26 --> URI Class Initialized
INFO - 2017-01-09 20:06:26 --> Router Class Initialized
INFO - 2017-01-09 20:06:26 --> Output Class Initialized
INFO - 2017-01-09 20:06:26 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:26 --> Input Class Initialized
INFO - 2017-01-09 20:06:26 --> Language Class Initialized
INFO - 2017-01-09 20:06:26 --> Loader Class Initialized
INFO - 2017-01-09 20:06:26 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:26 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:27 --> Controller Class Initialized
INFO - 2017-01-09 20:06:27 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:27 --> Model Class Initialized
INFO - 2017-01-09 20:06:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:06:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 20:06:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:06:27 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:27 --> Total execution time: 0.1197
INFO - 2017-01-09 20:06:29 --> Config Class Initialized
INFO - 2017-01-09 20:06:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:29 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:29 --> URI Class Initialized
INFO - 2017-01-09 20:06:29 --> Router Class Initialized
INFO - 2017-01-09 20:06:29 --> Output Class Initialized
INFO - 2017-01-09 20:06:29 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:29 --> Input Class Initialized
INFO - 2017-01-09 20:06:29 --> Language Class Initialized
INFO - 2017-01-09 20:06:29 --> Loader Class Initialized
INFO - 2017-01-09 20:06:29 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:29 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:29 --> Controller Class Initialized
INFO - 2017-01-09 20:06:30 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:30 --> Model Class Initialized
INFO - 2017-01-09 20:06:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:30 --> Helper loaded: form_helper
INFO - 2017-01-09 20:06:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:06:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 20:06:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:06:30 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:30 --> Total execution time: 0.1063
INFO - 2017-01-09 20:06:36 --> Config Class Initialized
INFO - 2017-01-09 20:06:36 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:36 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:36 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:36 --> URI Class Initialized
INFO - 2017-01-09 20:06:36 --> Router Class Initialized
INFO - 2017-01-09 20:06:36 --> Output Class Initialized
INFO - 2017-01-09 20:06:36 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:36 --> Input Class Initialized
INFO - 2017-01-09 20:06:36 --> Language Class Initialized
INFO - 2017-01-09 20:06:36 --> Loader Class Initialized
INFO - 2017-01-09 20:06:36 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:36 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:36 --> Controller Class Initialized
INFO - 2017-01-09 20:06:36 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:36 --> Model Class Initialized
INFO - 2017-01-09 20:06:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:36 --> Config Class Initialized
INFO - 2017-01-09 20:06:36 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:36 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:36 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:36 --> URI Class Initialized
INFO - 2017-01-09 20:06:36 --> Router Class Initialized
INFO - 2017-01-09 20:06:36 --> Output Class Initialized
INFO - 2017-01-09 20:06:36 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:36 --> Input Class Initialized
INFO - 2017-01-09 20:06:36 --> Language Class Initialized
INFO - 2017-01-09 20:06:36 --> Loader Class Initialized
INFO - 2017-01-09 20:06:36 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:36 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:36 --> Controller Class Initialized
INFO - 2017-01-09 20:06:36 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:36 --> Model Class Initialized
INFO - 2017-01-09 20:06:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 20:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 20:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 20:06:36 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:36 --> Total execution time: 0.1553
INFO - 2017-01-09 20:06:41 --> Config Class Initialized
INFO - 2017-01-09 20:06:41 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:41 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:41 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:41 --> URI Class Initialized
INFO - 2017-01-09 20:06:41 --> Router Class Initialized
INFO - 2017-01-09 20:06:41 --> Output Class Initialized
INFO - 2017-01-09 20:06:41 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:41 --> Input Class Initialized
INFO - 2017-01-09 20:06:41 --> Language Class Initialized
INFO - 2017-01-09 20:06:41 --> Loader Class Initialized
INFO - 2017-01-09 20:06:41 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:41 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:41 --> Controller Class Initialized
INFO - 2017-01-09 20:06:41 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:42 --> Model Class Initialized
INFO - 2017-01-09 20:06:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:42 --> Config Class Initialized
INFO - 2017-01-09 20:06:42 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:06:42 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:06:42 --> Utf8 Class Initialized
INFO - 2017-01-09 20:06:42 --> URI Class Initialized
INFO - 2017-01-09 20:06:42 --> Router Class Initialized
INFO - 2017-01-09 20:06:42 --> Output Class Initialized
INFO - 2017-01-09 20:06:42 --> Security Class Initialized
DEBUG - 2017-01-09 20:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:06:42 --> Input Class Initialized
INFO - 2017-01-09 20:06:42 --> Language Class Initialized
INFO - 2017-01-09 20:06:42 --> Loader Class Initialized
INFO - 2017-01-09 20:06:42 --> Helper loaded: url_helper
INFO - 2017-01-09 20:06:42 --> Helper loaded: language_helper
INFO - 2017-01-09 20:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:06:42 --> Controller Class Initialized
INFO - 2017-01-09 20:06:42 --> Database Driver Class Initialized
INFO - 2017-01-09 20:06:42 --> Model Class Initialized
INFO - 2017-01-09 20:06:42 --> Model Class Initialized
INFO - 2017-01-09 20:06:42 --> Model Class Initialized
INFO - 2017-01-09 20:06:42 --> Model Class Initialized
INFO - 2017-01-09 20:06:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:06:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:06:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:06:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:06:42 --> Final output sent to browser
DEBUG - 2017-01-09 20:06:42 --> Total execution time: 0.1541
INFO - 2017-01-09 20:10:21 --> Config Class Initialized
INFO - 2017-01-09 20:10:21 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:10:21 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:10:21 --> Utf8 Class Initialized
INFO - 2017-01-09 20:10:21 --> URI Class Initialized
INFO - 2017-01-09 20:10:21 --> Router Class Initialized
INFO - 2017-01-09 20:10:21 --> Output Class Initialized
INFO - 2017-01-09 20:10:21 --> Security Class Initialized
DEBUG - 2017-01-09 20:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:10:21 --> Input Class Initialized
INFO - 2017-01-09 20:10:21 --> Language Class Initialized
INFO - 2017-01-09 20:10:21 --> Loader Class Initialized
INFO - 2017-01-09 20:10:21 --> Helper loaded: url_helper
INFO - 2017-01-09 20:10:21 --> Helper loaded: language_helper
INFO - 2017-01-09 20:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:10:21 --> Controller Class Initialized
INFO - 2017-01-09 20:10:21 --> Database Driver Class Initialized
INFO - 2017-01-09 20:10:21 --> Model Class Initialized
INFO - 2017-01-09 20:10:21 --> Model Class Initialized
INFO - 2017-01-09 20:10:21 --> Model Class Initialized
INFO - 2017-01-09 20:10:21 --> Model Class Initialized
INFO - 2017-01-09 20:10:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-09 20:10:21 --> Query error: Table 'quizto.savsoft_users' doesn't exist - Invalid query: SELECT *
FROM `savsoft_users`
JOIN `savsoft_group` ON `savsoft_users`.`gid`=`savsoft_group`.`gid`
ORDER BY `savsoft_users`.`uid` DESC
 LIMIT 30
INFO - 2017-01-09 20:10:21 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-09 20:16:12 --> Config Class Initialized
INFO - 2017-01-09 20:16:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:12 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:12 --> URI Class Initialized
INFO - 2017-01-09 20:16:12 --> Router Class Initialized
INFO - 2017-01-09 20:16:12 --> Output Class Initialized
INFO - 2017-01-09 20:16:12 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:12 --> Input Class Initialized
INFO - 2017-01-09 20:16:12 --> Language Class Initialized
INFO - 2017-01-09 20:16:12 --> Loader Class Initialized
INFO - 2017-01-09 20:16:12 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:12 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:12 --> Controller Class Initialized
INFO - 2017-01-09 20:16:12 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:12 --> Model Class Initialized
INFO - 2017-01-09 20:16:12 --> Model Class Initialized
INFO - 2017-01-09 20:16:12 --> Model Class Initialized
INFO - 2017-01-09 20:16:12 --> Model Class Initialized
INFO - 2017-01-09 20:16:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:12 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:12 --> Total execution time: 0.1558
INFO - 2017-01-09 20:16:16 --> Config Class Initialized
INFO - 2017-01-09 20:16:16 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:16 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:16 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:16 --> URI Class Initialized
INFO - 2017-01-09 20:16:16 --> Router Class Initialized
INFO - 2017-01-09 20:16:16 --> Output Class Initialized
INFO - 2017-01-09 20:16:16 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:16 --> Input Class Initialized
INFO - 2017-01-09 20:16:16 --> Language Class Initialized
INFO - 2017-01-09 20:16:16 --> Loader Class Initialized
INFO - 2017-01-09 20:16:16 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:16 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:16 --> Controller Class Initialized
INFO - 2017-01-09 20:16:16 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:16 --> Model Class Initialized
INFO - 2017-01-09 20:16:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-09 20:16:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:16 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:16 --> Total execution time: 0.1133
INFO - 2017-01-09 20:16:17 --> Config Class Initialized
INFO - 2017-01-09 20:16:17 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:17 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:17 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:17 --> URI Class Initialized
INFO - 2017-01-09 20:16:17 --> Router Class Initialized
INFO - 2017-01-09 20:16:17 --> Output Class Initialized
INFO - 2017-01-09 20:16:17 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:17 --> Input Class Initialized
INFO - 2017-01-09 20:16:17 --> Language Class Initialized
INFO - 2017-01-09 20:16:17 --> Loader Class Initialized
INFO - 2017-01-09 20:16:17 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:17 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:17 --> Controller Class Initialized
INFO - 2017-01-09 20:16:17 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:17 --> Model Class Initialized
INFO - 2017-01-09 20:16:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:17 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:17 --> Total execution time: 0.1550
INFO - 2017-01-09 20:16:18 --> Config Class Initialized
INFO - 2017-01-09 20:16:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:18 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:18 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:18 --> URI Class Initialized
INFO - 2017-01-09 20:16:18 --> Router Class Initialized
INFO - 2017-01-09 20:16:18 --> Output Class Initialized
INFO - 2017-01-09 20:16:18 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:18 --> Input Class Initialized
INFO - 2017-01-09 20:16:18 --> Language Class Initialized
INFO - 2017-01-09 20:16:18 --> Loader Class Initialized
INFO - 2017-01-09 20:16:18 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:18 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:18 --> Controller Class Initialized
INFO - 2017-01-09 20:16:18 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:18 --> Model Class Initialized
INFO - 2017-01-09 20:16:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 20:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:18 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:18 --> Total execution time: 0.1395
INFO - 2017-01-09 20:16:20 --> Config Class Initialized
INFO - 2017-01-09 20:16:20 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:20 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:20 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:20 --> URI Class Initialized
INFO - 2017-01-09 20:16:20 --> Router Class Initialized
INFO - 2017-01-09 20:16:20 --> Output Class Initialized
INFO - 2017-01-09 20:16:20 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:20 --> Input Class Initialized
INFO - 2017-01-09 20:16:20 --> Language Class Initialized
INFO - 2017-01-09 20:16:20 --> Loader Class Initialized
INFO - 2017-01-09 20:16:20 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:20 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:20 --> Controller Class Initialized
INFO - 2017-01-09 20:16:20 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:20 --> Model Class Initialized
INFO - 2017-01-09 20:16:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2017-01-09 20:16:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:20 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:20 --> Total execution time: 0.0902
INFO - 2017-01-09 20:16:21 --> Config Class Initialized
INFO - 2017-01-09 20:16:21 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:22 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:22 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:22 --> URI Class Initialized
INFO - 2017-01-09 20:16:22 --> Router Class Initialized
INFO - 2017-01-09 20:16:22 --> Output Class Initialized
INFO - 2017-01-09 20:16:22 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:22 --> Input Class Initialized
INFO - 2017-01-09 20:16:22 --> Language Class Initialized
INFO - 2017-01-09 20:16:22 --> Loader Class Initialized
INFO - 2017-01-09 20:16:22 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:22 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:22 --> Controller Class Initialized
INFO - 2017-01-09 20:16:22 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:22 --> Model Class Initialized
INFO - 2017-01-09 20:16:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:22 --> Helper loaded: form_helper
INFO - 2017-01-09 20:16:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-09 20:16:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:22 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:22 --> Total execution time: 0.2069
INFO - 2017-01-09 20:16:23 --> Config Class Initialized
INFO - 2017-01-09 20:16:23 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:23 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:23 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:23 --> URI Class Initialized
INFO - 2017-01-09 20:16:23 --> Router Class Initialized
INFO - 2017-01-09 20:16:23 --> Output Class Initialized
INFO - 2017-01-09 20:16:23 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:23 --> Input Class Initialized
INFO - 2017-01-09 20:16:23 --> Language Class Initialized
INFO - 2017-01-09 20:16:23 --> Loader Class Initialized
INFO - 2017-01-09 20:16:23 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:23 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:23 --> Controller Class Initialized
INFO - 2017-01-09 20:16:23 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:23 --> Model Class Initialized
INFO - 2017-01-09 20:16:24 --> Model Class Initialized
INFO - 2017-01-09 20:16:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2017-01-09 20:16:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:24 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:24 --> Total execution time: 0.1696
INFO - 2017-01-09 20:16:25 --> Config Class Initialized
INFO - 2017-01-09 20:16:25 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:25 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:25 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:25 --> URI Class Initialized
INFO - 2017-01-09 20:16:25 --> Router Class Initialized
INFO - 2017-01-09 20:16:25 --> Output Class Initialized
INFO - 2017-01-09 20:16:25 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:25 --> Input Class Initialized
INFO - 2017-01-09 20:16:25 --> Language Class Initialized
INFO - 2017-01-09 20:16:25 --> Loader Class Initialized
INFO - 2017-01-09 20:16:25 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:25 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:25 --> Controller Class Initialized
INFO - 2017-01-09 20:16:25 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:25 --> Model Class Initialized
INFO - 2017-01-09 20:16:25 --> Model Class Initialized
INFO - 2017-01-09 20:16:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-09 20:16:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:25 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:25 --> Total execution time: 0.1104
INFO - 2017-01-09 20:16:27 --> Config Class Initialized
INFO - 2017-01-09 20:16:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:27 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:27 --> URI Class Initialized
DEBUG - 2017-01-09 20:16:27 --> No URI present. Default controller set.
INFO - 2017-01-09 20:16:27 --> Router Class Initialized
INFO - 2017-01-09 20:16:27 --> Output Class Initialized
INFO - 2017-01-09 20:16:27 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:27 --> Input Class Initialized
INFO - 2017-01-09 20:16:27 --> Language Class Initialized
INFO - 2017-01-09 20:16:27 --> Loader Class Initialized
INFO - 2017-01-09 20:16:27 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:27 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:27 --> Controller Class Initialized
INFO - 2017-01-09 20:16:27 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:27 --> Model Class Initialized
INFO - 2017-01-09 20:16:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:27 --> Config Class Initialized
INFO - 2017-01-09 20:16:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:27 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:27 --> URI Class Initialized
INFO - 2017-01-09 20:16:27 --> Router Class Initialized
INFO - 2017-01-09 20:16:27 --> Output Class Initialized
INFO - 2017-01-09 20:16:27 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:27 --> Input Class Initialized
INFO - 2017-01-09 20:16:27 --> Language Class Initialized
INFO - 2017-01-09 20:16:27 --> Loader Class Initialized
INFO - 2017-01-09 20:16:27 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:27 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:27 --> Controller Class Initialized
INFO - 2017-01-09 20:16:27 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:27 --> Model Class Initialized
INFO - 2017-01-09 20:16:27 --> Model Class Initialized
INFO - 2017-01-09 20:16:27 --> Model Class Initialized
INFO - 2017-01-09 20:16:27 --> Model Class Initialized
INFO - 2017-01-09 20:16:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:16:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:27 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:27 --> Total execution time: 0.1592
INFO - 2017-01-09 20:16:28 --> Config Class Initialized
INFO - 2017-01-09 20:16:28 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:28 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:28 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:28 --> URI Class Initialized
DEBUG - 2017-01-09 20:16:28 --> No URI present. Default controller set.
INFO - 2017-01-09 20:16:28 --> Router Class Initialized
INFO - 2017-01-09 20:16:28 --> Output Class Initialized
INFO - 2017-01-09 20:16:28 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:28 --> Input Class Initialized
INFO - 2017-01-09 20:16:28 --> Language Class Initialized
INFO - 2017-01-09 20:16:28 --> Loader Class Initialized
INFO - 2017-01-09 20:16:28 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:28 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:28 --> Controller Class Initialized
INFO - 2017-01-09 20:16:28 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:28 --> Model Class Initialized
INFO - 2017-01-09 20:16:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:29 --> Config Class Initialized
INFO - 2017-01-09 20:16:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:29 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:29 --> URI Class Initialized
INFO - 2017-01-09 20:16:29 --> Router Class Initialized
INFO - 2017-01-09 20:16:29 --> Output Class Initialized
INFO - 2017-01-09 20:16:29 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:29 --> Input Class Initialized
INFO - 2017-01-09 20:16:29 --> Language Class Initialized
INFO - 2017-01-09 20:16:29 --> Loader Class Initialized
INFO - 2017-01-09 20:16:29 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:29 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:29 --> Controller Class Initialized
INFO - 2017-01-09 20:16:29 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:29 --> Model Class Initialized
INFO - 2017-01-09 20:16:29 --> Model Class Initialized
INFO - 2017-01-09 20:16:29 --> Model Class Initialized
INFO - 2017-01-09 20:16:29 --> Model Class Initialized
INFO - 2017-01-09 20:16:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:16:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:16:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:16:29 --> Final output sent to browser
DEBUG - 2017-01-09 20:16:29 --> Total execution time: 0.1926
INFO - 2017-01-09 20:16:30 --> Config Class Initialized
INFO - 2017-01-09 20:16:30 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:16:30 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:16:30 --> Utf8 Class Initialized
INFO - 2017-01-09 20:16:30 --> URI Class Initialized
INFO - 2017-01-09 20:16:30 --> Router Class Initialized
INFO - 2017-01-09 20:16:30 --> Output Class Initialized
INFO - 2017-01-09 20:16:31 --> Security Class Initialized
DEBUG - 2017-01-09 20:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:16:31 --> Input Class Initialized
INFO - 2017-01-09 20:16:31 --> Language Class Initialized
INFO - 2017-01-09 20:16:31 --> Loader Class Initialized
INFO - 2017-01-09 20:16:31 --> Helper loaded: url_helper
INFO - 2017-01-09 20:16:31 --> Helper loaded: language_helper
INFO - 2017-01-09 20:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:16:31 --> Controller Class Initialized
INFO - 2017-01-09 20:16:31 --> Database Driver Class Initialized
INFO - 2017-01-09 20:16:31 --> Model Class Initialized
INFO - 2017-01-09 20:16:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:16:31 --> Helper loaded: form_helper
ERROR - 2017-01-09 20:16:31 --> Query error: Table 'quiz.answers' doesn't exist - Invalid query: SELECT d.uid,concat(d.first_name,' ',d.last_name) as fullname,round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum(case when c.cid=12 then a.score_u else null end), 0) as ist2,round(sum(case when c.cid=13 then a.score_u else null end), 0) as ist3,round(sum(case when c.cid=14 then a.score_u else null end), 0) as ist4,round(sum(case when c.cid=15 then a.score_u else null end), 0) as ist5,round(sum(case when c.cid=16 then a.score_u else null end), 0) as ist6,round(sum(case when c.cid=17 then a.score_u else null end), 0) as ist7,round(sum(case when c.cid=19 then a.score_u else null end), 0) as ist8,round(sum(case when c.cid=20 then a.score_u else null end), 0) as ist9,round(sum(case when c.cid=22 then a.score_u else null end), 0) as ist10,
                round(sum(a.score_u), 0) as total
                from quiz.answers a
                left join quiz.qbank b on b.qid = a.qid
                left join quiz.category c on c.cid = b.cid
                left join quiz.users d on d.uid = a.uid
                where su != 1
                group by d.uid
                order by total desc
INFO - 2017-01-09 20:16:31 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-09 20:18:47 --> Config Class Initialized
INFO - 2017-01-09 20:18:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:18:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:18:47 --> Utf8 Class Initialized
INFO - 2017-01-09 20:18:47 --> URI Class Initialized
INFO - 2017-01-09 20:18:47 --> Router Class Initialized
INFO - 2017-01-09 20:18:47 --> Output Class Initialized
INFO - 2017-01-09 20:18:47 --> Security Class Initialized
DEBUG - 2017-01-09 20:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:18:47 --> Input Class Initialized
INFO - 2017-01-09 20:18:47 --> Language Class Initialized
INFO - 2017-01-09 20:18:47 --> Loader Class Initialized
INFO - 2017-01-09 20:18:47 --> Helper loaded: url_helper
INFO - 2017-01-09 20:18:47 --> Helper loaded: language_helper
INFO - 2017-01-09 20:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:18:47 --> Controller Class Initialized
INFO - 2017-01-09 20:18:47 --> Database Driver Class Initialized
INFO - 2017-01-09 20:18:47 --> Model Class Initialized
INFO - 2017-01-09 20:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:18:47 --> Helper loaded: form_helper
INFO - 2017-01-09 20:18:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:18:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-09 20:18:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:18:47 --> Final output sent to browser
DEBUG - 2017-01-09 20:18:47 --> Total execution time: 0.1235
INFO - 2017-01-09 20:18:49 --> Config Class Initialized
INFO - 2017-01-09 20:18:49 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:18:49 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:18:49 --> Utf8 Class Initialized
INFO - 2017-01-09 20:18:49 --> URI Class Initialized
INFO - 2017-01-09 20:18:49 --> Router Class Initialized
INFO - 2017-01-09 20:18:49 --> Output Class Initialized
INFO - 2017-01-09 20:18:49 --> Security Class Initialized
DEBUG - 2017-01-09 20:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:18:49 --> Input Class Initialized
INFO - 2017-01-09 20:18:49 --> Language Class Initialized
INFO - 2017-01-09 20:18:49 --> Loader Class Initialized
INFO - 2017-01-09 20:18:49 --> Helper loaded: url_helper
INFO - 2017-01-09 20:18:49 --> Helper loaded: language_helper
INFO - 2017-01-09 20:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:18:49 --> Controller Class Initialized
INFO - 2017-01-09 20:18:49 --> Database Driver Class Initialized
INFO - 2017-01-09 20:18:49 --> Model Class Initialized
INFO - 2017-01-09 20:18:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:18:49 --> Model Class Initialized
INFO - 2017-01-09 20:18:49 --> Model Class Initialized
INFO - 2017-01-09 20:18:49 --> Helper loaded: form_helper
INFO - 2017-01-09 20:18:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:18:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-09 20:18:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:18:49 --> Final output sent to browser
DEBUG - 2017-01-09 20:18:49 --> Total execution time: 0.1935
INFO - 2017-01-09 20:18:55 --> Config Class Initialized
INFO - 2017-01-09 20:18:55 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:18:55 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:18:55 --> Utf8 Class Initialized
INFO - 2017-01-09 20:18:55 --> URI Class Initialized
INFO - 2017-01-09 20:18:55 --> Router Class Initialized
INFO - 2017-01-09 20:18:55 --> Output Class Initialized
INFO - 2017-01-09 20:18:55 --> Security Class Initialized
DEBUG - 2017-01-09 20:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:18:55 --> Input Class Initialized
INFO - 2017-01-09 20:18:55 --> Language Class Initialized
INFO - 2017-01-09 20:18:55 --> Loader Class Initialized
INFO - 2017-01-09 20:18:55 --> Helper loaded: url_helper
INFO - 2017-01-09 20:18:55 --> Helper loaded: language_helper
INFO - 2017-01-09 20:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:18:55 --> Controller Class Initialized
INFO - 2017-01-09 20:18:55 --> Database Driver Class Initialized
INFO - 2017-01-09 20:18:55 --> Model Class Initialized
INFO - 2017-01-09 20:18:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:18:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:18:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\group_list.php
INFO - 2017-01-09 20:18:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:18:55 --> Final output sent to browser
DEBUG - 2017-01-09 20:18:55 --> Total execution time: 0.1152
INFO - 2017-01-09 20:18:57 --> Config Class Initialized
INFO - 2017-01-09 20:18:57 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:18:57 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:18:57 --> Utf8 Class Initialized
INFO - 2017-01-09 20:18:57 --> URI Class Initialized
INFO - 2017-01-09 20:18:57 --> Router Class Initialized
INFO - 2017-01-09 20:18:57 --> Output Class Initialized
INFO - 2017-01-09 20:18:57 --> Security Class Initialized
DEBUG - 2017-01-09 20:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:18:57 --> Input Class Initialized
INFO - 2017-01-09 20:18:57 --> Language Class Initialized
INFO - 2017-01-09 20:18:57 --> Loader Class Initialized
INFO - 2017-01-09 20:18:57 --> Helper loaded: url_helper
INFO - 2017-01-09 20:18:57 --> Helper loaded: language_helper
INFO - 2017-01-09 20:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:18:57 --> Controller Class Initialized
INFO - 2017-01-09 20:18:57 --> Database Driver Class Initialized
INFO - 2017-01-09 20:18:57 --> Model Class Initialized
INFO - 2017-01-09 20:18:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:18:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:18:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2017-01-09 20:18:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:18:57 --> Final output sent to browser
DEBUG - 2017-01-09 20:18:57 --> Total execution time: 0.1063
INFO - 2017-01-09 20:18:59 --> Config Class Initialized
INFO - 2017-01-09 20:18:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:18:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:18:59 --> Utf8 Class Initialized
INFO - 2017-01-09 20:18:59 --> URI Class Initialized
INFO - 2017-01-09 20:18:59 --> Router Class Initialized
INFO - 2017-01-09 20:18:59 --> Output Class Initialized
INFO - 2017-01-09 20:18:59 --> Security Class Initialized
DEBUG - 2017-01-09 20:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:18:59 --> Input Class Initialized
INFO - 2017-01-09 20:18:59 --> Language Class Initialized
INFO - 2017-01-09 20:18:59 --> Loader Class Initialized
INFO - 2017-01-09 20:18:59 --> Helper loaded: url_helper
INFO - 2017-01-09 20:18:59 --> Helper loaded: language_helper
INFO - 2017-01-09 20:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:18:59 --> Controller Class Initialized
INFO - 2017-01-09 20:18:59 --> Database Driver Class Initialized
INFO - 2017-01-09 20:18:59 --> Model Class Initialized
INFO - 2017-01-09 20:18:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:18:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:18:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\level_list.php
INFO - 2017-01-09 20:18:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:18:59 --> Final output sent to browser
DEBUG - 2017-01-09 20:18:59 --> Total execution time: 0.1238
INFO - 2017-01-09 20:19:01 --> Config Class Initialized
INFO - 2017-01-09 20:19:01 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:01 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:01 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:01 --> URI Class Initialized
INFO - 2017-01-09 20:19:01 --> Router Class Initialized
INFO - 2017-01-09 20:19:01 --> Output Class Initialized
INFO - 2017-01-09 20:19:01 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:01 --> Input Class Initialized
INFO - 2017-01-09 20:19:01 --> Language Class Initialized
INFO - 2017-01-09 20:19:01 --> Loader Class Initialized
INFO - 2017-01-09 20:19:01 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:01 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:01 --> Controller Class Initialized
INFO - 2017-01-09 20:19:01 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:01 --> Model Class Initialized
INFO - 2017-01-09 20:19:01 --> Model Class Initialized
INFO - 2017-01-09 20:19:01 --> Model Class Initialized
INFO - 2017-01-09 20:19:01 --> Model Class Initialized
INFO - 2017-01-09 20:19:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\config.php
INFO - 2017-01-09 20:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:19:01 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:01 --> Total execution time: 0.1087
INFO - 2017-01-09 20:19:04 --> Config Class Initialized
INFO - 2017-01-09 20:19:04 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:04 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:04 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:04 --> URI Class Initialized
INFO - 2017-01-09 20:19:04 --> Router Class Initialized
INFO - 2017-01-09 20:19:04 --> Output Class Initialized
INFO - 2017-01-09 20:19:04 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:04 --> Input Class Initialized
INFO - 2017-01-09 20:19:04 --> Language Class Initialized
INFO - 2017-01-09 20:19:04 --> Loader Class Initialized
INFO - 2017-01-09 20:19:04 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:04 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:04 --> Controller Class Initialized
INFO - 2017-01-09 20:19:04 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:04 --> Model Class Initialized
INFO - 2017-01-09 20:19:04 --> Model Class Initialized
INFO - 2017-01-09 20:19:04 --> Model Class Initialized
INFO - 2017-01-09 20:19:04 --> Model Class Initialized
INFO - 2017-01-09 20:19:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\css.php
INFO - 2017-01-09 20:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:19:04 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:04 --> Total execution time: 0.1066
INFO - 2017-01-09 20:19:05 --> Config Class Initialized
INFO - 2017-01-09 20:19:05 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:05 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:05 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:05 --> URI Class Initialized
INFO - 2017-01-09 20:19:05 --> Router Class Initialized
INFO - 2017-01-09 20:19:05 --> Output Class Initialized
INFO - 2017-01-09 20:19:05 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:05 --> Input Class Initialized
INFO - 2017-01-09 20:19:05 --> Language Class Initialized
INFO - 2017-01-09 20:19:05 --> Loader Class Initialized
INFO - 2017-01-09 20:19:05 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:05 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:05 --> Controller Class Initialized
INFO - 2017-01-09 20:19:05 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:05 --> Model Class Initialized
INFO - 2017-01-09 20:19:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:06 --> Config Class Initialized
INFO - 2017-01-09 20:19:06 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:06 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:06 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:06 --> URI Class Initialized
INFO - 2017-01-09 20:19:06 --> Router Class Initialized
INFO - 2017-01-09 20:19:06 --> Output Class Initialized
INFO - 2017-01-09 20:19:06 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:06 --> Input Class Initialized
INFO - 2017-01-09 20:19:06 --> Language Class Initialized
INFO - 2017-01-09 20:19:06 --> Loader Class Initialized
INFO - 2017-01-09 20:19:06 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:06 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:06 --> Controller Class Initialized
INFO - 2017-01-09 20:19:06 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:06 --> Model Class Initialized
INFO - 2017-01-09 20:19:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-09 20:19:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-09 20:19:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-09 20:19:06 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:06 --> Total execution time: 0.0909
INFO - 2017-01-09 20:19:10 --> Config Class Initialized
INFO - 2017-01-09 20:19:10 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:10 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:10 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:10 --> URI Class Initialized
INFO - 2017-01-09 20:19:10 --> Router Class Initialized
INFO - 2017-01-09 20:19:10 --> Output Class Initialized
INFO - 2017-01-09 20:19:10 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:10 --> Input Class Initialized
INFO - 2017-01-09 20:19:10 --> Language Class Initialized
INFO - 2017-01-09 20:19:10 --> Loader Class Initialized
INFO - 2017-01-09 20:19:10 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:10 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:10 --> Controller Class Initialized
INFO - 2017-01-09 20:19:10 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:10 --> Model Class Initialized
INFO - 2017-01-09 20:19:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:10 --> Config Class Initialized
INFO - 2017-01-09 20:19:10 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:10 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:10 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:10 --> URI Class Initialized
INFO - 2017-01-09 20:19:10 --> Router Class Initialized
INFO - 2017-01-09 20:19:11 --> Output Class Initialized
INFO - 2017-01-09 20:19:11 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:11 --> Input Class Initialized
INFO - 2017-01-09 20:19:11 --> Language Class Initialized
INFO - 2017-01-09 20:19:11 --> Loader Class Initialized
INFO - 2017-01-09 20:19:11 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:11 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:11 --> Controller Class Initialized
INFO - 2017-01-09 20:19:11 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:11 --> Model Class Initialized
INFO - 2017-01-09 20:19:11 --> Model Class Initialized
INFO - 2017-01-09 20:19:11 --> Model Class Initialized
INFO - 2017-01-09 20:19:11 --> Model Class Initialized
INFO - 2017-01-09 20:19:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-09 20:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:19:11 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:11 --> Total execution time: 0.1085
INFO - 2017-01-09 20:19:14 --> Config Class Initialized
INFO - 2017-01-09 20:19:14 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:14 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:14 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:14 --> URI Class Initialized
INFO - 2017-01-09 20:19:14 --> Router Class Initialized
INFO - 2017-01-09 20:19:14 --> Output Class Initialized
INFO - 2017-01-09 20:19:14 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:14 --> Input Class Initialized
INFO - 2017-01-09 20:19:14 --> Language Class Initialized
INFO - 2017-01-09 20:19:14 --> Loader Class Initialized
INFO - 2017-01-09 20:19:14 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:14 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:14 --> Controller Class Initialized
INFO - 2017-01-09 20:19:14 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:14 --> Model Class Initialized
INFO - 2017-01-09 20:19:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:19:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 20:19:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:19:14 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:14 --> Total execution time: 0.0905
INFO - 2017-01-09 20:19:17 --> Config Class Initialized
INFO - 2017-01-09 20:19:17 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:17 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:17 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:17 --> URI Class Initialized
INFO - 2017-01-09 20:19:17 --> Router Class Initialized
INFO - 2017-01-09 20:19:17 --> Output Class Initialized
INFO - 2017-01-09 20:19:17 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:17 --> Input Class Initialized
INFO - 2017-01-09 20:19:17 --> Language Class Initialized
INFO - 2017-01-09 20:19:17 --> Loader Class Initialized
INFO - 2017-01-09 20:19:17 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:17 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:17 --> Controller Class Initialized
INFO - 2017-01-09 20:19:17 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:17 --> Model Class Initialized
INFO - 2017-01-09 20:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-09 20:19:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:19:17 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:17 --> Total execution time: 0.1239
INFO - 2017-01-09 20:19:17 --> Config Class Initialized
INFO - 2017-01-09 20:19:17 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:17 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:17 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:17 --> URI Class Initialized
INFO - 2017-01-09 20:19:17 --> Router Class Initialized
INFO - 2017-01-09 20:19:17 --> Output Class Initialized
INFO - 2017-01-09 20:19:17 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:17 --> Input Class Initialized
INFO - 2017-01-09 20:19:17 --> Language Class Initialized
INFO - 2017-01-09 20:19:17 --> Loader Class Initialized
INFO - 2017-01-09 20:19:17 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:17 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:17 --> Controller Class Initialized
INFO - 2017-01-09 20:19:17 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:17 --> Model Class Initialized
INFO - 2017-01-09 20:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:17 --> Final output sent to browser
DEBUG - 2017-01-09 20:19:17 --> Total execution time: 0.1040
INFO - 2017-01-09 20:19:46 --> Config Class Initialized
INFO - 2017-01-09 20:19:46 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:19:46 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:19:46 --> Utf8 Class Initialized
INFO - 2017-01-09 20:19:46 --> URI Class Initialized
INFO - 2017-01-09 20:19:46 --> Router Class Initialized
INFO - 2017-01-09 20:19:46 --> Output Class Initialized
INFO - 2017-01-09 20:19:46 --> Security Class Initialized
DEBUG - 2017-01-09 20:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:19:46 --> Input Class Initialized
INFO - 2017-01-09 20:19:46 --> Language Class Initialized
INFO - 2017-01-09 20:19:46 --> Loader Class Initialized
INFO - 2017-01-09 20:19:46 --> Helper loaded: url_helper
INFO - 2017-01-09 20:19:46 --> Helper loaded: language_helper
INFO - 2017-01-09 20:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:19:46 --> Controller Class Initialized
INFO - 2017-01-09 20:19:46 --> Database Driver Class Initialized
INFO - 2017-01-09 20:19:46 --> Model Class Initialized
INFO - 2017-01-09 20:19:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:19:46 --> Helper loaded: form_helper
INFO - 2017-01-09 20:19:46 --> Form Validation Class Initialized
INFO - 2017-01-09 20:19:46 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-01-09 20:19:46 --> Query error: Table 'quizto.savsoft_users' doesn't exist - Invalid query: SELECT *
FROM `savsoft_users`
WHERE `email` = 'email@yahoo.com'
 LIMIT 1
INFO - 2017-01-09 20:19:46 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-09 20:20:41 --> Config Class Initialized
INFO - 2017-01-09 20:20:41 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:20:41 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:20:41 --> Utf8 Class Initialized
INFO - 2017-01-09 20:20:41 --> URI Class Initialized
INFO - 2017-01-09 20:20:41 --> Router Class Initialized
INFO - 2017-01-09 20:20:41 --> Output Class Initialized
INFO - 2017-01-09 20:20:41 --> Security Class Initialized
DEBUG - 2017-01-09 20:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:20:41 --> Input Class Initialized
INFO - 2017-01-09 20:20:41 --> Language Class Initialized
INFO - 2017-01-09 20:20:41 --> Loader Class Initialized
INFO - 2017-01-09 20:20:41 --> Helper loaded: url_helper
INFO - 2017-01-09 20:20:41 --> Helper loaded: language_helper
INFO - 2017-01-09 20:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:20:41 --> Controller Class Initialized
INFO - 2017-01-09 20:20:41 --> Database Driver Class Initialized
INFO - 2017-01-09 20:20:41 --> Model Class Initialized
INFO - 2017-01-09 20:20:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:20:42 --> Helper loaded: form_helper
INFO - 2017-01-09 20:20:42 --> Form Validation Class Initialized
INFO - 2017-01-09 20:20:42 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-09 20:20:42 --> Config Class Initialized
INFO - 2017-01-09 20:20:42 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:20:42 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:20:42 --> Utf8 Class Initialized
INFO - 2017-01-09 20:20:42 --> URI Class Initialized
INFO - 2017-01-09 20:20:42 --> Router Class Initialized
INFO - 2017-01-09 20:20:42 --> Output Class Initialized
INFO - 2017-01-09 20:20:42 --> Security Class Initialized
DEBUG - 2017-01-09 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:20:42 --> Input Class Initialized
INFO - 2017-01-09 20:20:42 --> Language Class Initialized
INFO - 2017-01-09 20:20:42 --> Loader Class Initialized
INFO - 2017-01-09 20:20:42 --> Helper loaded: url_helper
INFO - 2017-01-09 20:20:42 --> Helper loaded: language_helper
INFO - 2017-01-09 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:20:42 --> Controller Class Initialized
INFO - 2017-01-09 20:20:42 --> Database Driver Class Initialized
INFO - 2017-01-09 20:20:42 --> Model Class Initialized
INFO - 2017-01-09 20:20:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:20:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:20:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-09 20:20:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:20:42 --> Final output sent to browser
DEBUG - 2017-01-09 20:20:42 --> Total execution time: 0.1192
INFO - 2017-01-09 20:20:42 --> Config Class Initialized
INFO - 2017-01-09 20:20:42 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:20:42 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:20:42 --> Utf8 Class Initialized
INFO - 2017-01-09 20:20:42 --> URI Class Initialized
INFO - 2017-01-09 20:20:42 --> Router Class Initialized
INFO - 2017-01-09 20:20:42 --> Output Class Initialized
INFO - 2017-01-09 20:20:42 --> Security Class Initialized
DEBUG - 2017-01-09 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:20:42 --> Input Class Initialized
INFO - 2017-01-09 20:20:42 --> Language Class Initialized
INFO - 2017-01-09 20:20:42 --> Loader Class Initialized
INFO - 2017-01-09 20:20:42 --> Helper loaded: url_helper
INFO - 2017-01-09 20:20:42 --> Helper loaded: language_helper
INFO - 2017-01-09 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:20:42 --> Controller Class Initialized
INFO - 2017-01-09 20:20:42 --> Database Driver Class Initialized
INFO - 2017-01-09 20:20:42 --> Model Class Initialized
INFO - 2017-01-09 20:20:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:20:42 --> Final output sent to browser
DEBUG - 2017-01-09 20:20:42 --> Total execution time: 0.1035
INFO - 2017-01-09 20:20:51 --> Config Class Initialized
INFO - 2017-01-09 20:20:51 --> Hooks Class Initialized
DEBUG - 2017-01-09 20:20:51 --> UTF-8 Support Enabled
INFO - 2017-01-09 20:20:51 --> Utf8 Class Initialized
INFO - 2017-01-09 20:20:51 --> URI Class Initialized
INFO - 2017-01-09 20:20:51 --> Router Class Initialized
INFO - 2017-01-09 20:20:51 --> Output Class Initialized
INFO - 2017-01-09 20:20:51 --> Security Class Initialized
DEBUG - 2017-01-09 20:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 20:20:51 --> Input Class Initialized
INFO - 2017-01-09 20:20:51 --> Language Class Initialized
INFO - 2017-01-09 20:20:51 --> Loader Class Initialized
INFO - 2017-01-09 20:20:51 --> Helper loaded: url_helper
INFO - 2017-01-09 20:20:51 --> Helper loaded: language_helper
INFO - 2017-01-09 20:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 20:20:51 --> Controller Class Initialized
INFO - 2017-01-09 20:20:51 --> Database Driver Class Initialized
INFO - 2017-01-09 20:20:51 --> Model Class Initialized
INFO - 2017-01-09 20:20:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-09 20:20:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-09 20:20:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-09 20:20:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-09 20:20:51 --> Final output sent to browser
DEBUG - 2017-01-09 20:20:51 --> Total execution time: 0.0988
