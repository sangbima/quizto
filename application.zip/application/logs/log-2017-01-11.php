<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-11 07:50:02 --> Config Class Initialized
INFO - 2017-01-11 07:50:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:50:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:50:02 --> Utf8 Class Initialized
INFO - 2017-01-11 07:50:02 --> URI Class Initialized
DEBUG - 2017-01-11 07:50:02 --> No URI present. Default controller set.
INFO - 2017-01-11 07:50:02 --> Router Class Initialized
INFO - 2017-01-11 07:50:02 --> Output Class Initialized
INFO - 2017-01-11 07:50:02 --> Security Class Initialized
DEBUG - 2017-01-11 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:50:02 --> Input Class Initialized
INFO - 2017-01-11 07:50:02 --> Language Class Initialized
INFO - 2017-01-11 07:50:02 --> Loader Class Initialized
INFO - 2017-01-11 07:50:02 --> Helper loaded: url_helper
INFO - 2017-01-11 07:50:02 --> Helper loaded: language_helper
INFO - 2017-01-11 07:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:50:02 --> Controller Class Initialized
INFO - 2017-01-11 07:50:02 --> Database Driver Class Initialized
INFO - 2017-01-11 07:50:02 --> Model Class Initialized
INFO - 2017-01-11 07:50:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 07:50:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 07:50:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 07:50:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 07:50:02 --> Final output sent to browser
DEBUG - 2017-01-11 07:50:02 --> Total execution time: 0.0885
INFO - 2017-01-11 07:50:03 --> Config Class Initialized
INFO - 2017-01-11 07:50:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:50:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:50:03 --> Utf8 Class Initialized
INFO - 2017-01-11 07:50:03 --> URI Class Initialized
INFO - 2017-01-11 07:50:03 --> Router Class Initialized
INFO - 2017-01-11 07:50:03 --> Output Class Initialized
INFO - 2017-01-11 07:50:03 --> Security Class Initialized
DEBUG - 2017-01-11 07:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:50:03 --> Input Class Initialized
INFO - 2017-01-11 07:50:03 --> Language Class Initialized
ERROR - 2017-01-11 07:50:03 --> 404 Page Not Found: Faviconico/index
INFO - 2017-01-11 07:59:45 --> Config Class Initialized
INFO - 2017-01-11 07:59:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:59:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:59:45 --> Utf8 Class Initialized
INFO - 2017-01-11 07:59:45 --> URI Class Initialized
INFO - 2017-01-11 07:59:45 --> Router Class Initialized
INFO - 2017-01-11 07:59:45 --> Output Class Initialized
INFO - 2017-01-11 07:59:45 --> Security Class Initialized
DEBUG - 2017-01-11 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:59:45 --> Input Class Initialized
INFO - 2017-01-11 07:59:45 --> Language Class Initialized
INFO - 2017-01-11 07:59:45 --> Loader Class Initialized
INFO - 2017-01-11 07:59:45 --> Helper loaded: url_helper
INFO - 2017-01-11 07:59:45 --> Helper loaded: language_helper
INFO - 2017-01-11 07:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:59:45 --> Controller Class Initialized
INFO - 2017-01-11 07:59:45 --> Database Driver Class Initialized
INFO - 2017-01-11 07:59:45 --> Model Class Initialized
INFO - 2017-01-11 07:59:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 07:59:45 --> Config Class Initialized
INFO - 2017-01-11 07:59:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:59:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:59:45 --> Utf8 Class Initialized
INFO - 2017-01-11 07:59:45 --> URI Class Initialized
INFO - 2017-01-11 07:59:45 --> Router Class Initialized
INFO - 2017-01-11 07:59:45 --> Output Class Initialized
INFO - 2017-01-11 07:59:45 --> Security Class Initialized
DEBUG - 2017-01-11 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:59:45 --> Input Class Initialized
INFO - 2017-01-11 07:59:45 --> Language Class Initialized
INFO - 2017-01-11 07:59:45 --> Loader Class Initialized
INFO - 2017-01-11 07:59:45 --> Helper loaded: url_helper
INFO - 2017-01-11 07:59:45 --> Helper loaded: language_helper
INFO - 2017-01-11 07:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:59:45 --> Controller Class Initialized
INFO - 2017-01-11 07:59:45 --> Database Driver Class Initialized
INFO - 2017-01-11 07:59:45 --> Model Class Initialized
INFO - 2017-01-11 07:59:45 --> Model Class Initialized
INFO - 2017-01-11 07:59:45 --> Model Class Initialized
INFO - 2017-01-11 07:59:45 --> Model Class Initialized
INFO - 2017-01-11 07:59:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 07:59:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 07:59:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 07:59:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 07:59:45 --> Final output sent to browser
DEBUG - 2017-01-11 07:59:45 --> Total execution time: 0.0681
INFO - 2017-01-11 07:59:50 --> Config Class Initialized
INFO - 2017-01-11 07:59:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:59:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:59:50 --> Utf8 Class Initialized
INFO - 2017-01-11 07:59:50 --> URI Class Initialized
INFO - 2017-01-11 07:59:50 --> Router Class Initialized
INFO - 2017-01-11 07:59:50 --> Output Class Initialized
INFO - 2017-01-11 07:59:50 --> Security Class Initialized
DEBUG - 2017-01-11 07:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:59:50 --> Input Class Initialized
INFO - 2017-01-11 07:59:50 --> Language Class Initialized
INFO - 2017-01-11 07:59:50 --> Loader Class Initialized
INFO - 2017-01-11 07:59:50 --> Helper loaded: url_helper
INFO - 2017-01-11 07:59:50 --> Helper loaded: language_helper
INFO - 2017-01-11 07:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:59:50 --> Controller Class Initialized
INFO - 2017-01-11 07:59:50 --> Database Driver Class Initialized
INFO - 2017-01-11 07:59:50 --> Model Class Initialized
INFO - 2017-01-11 07:59:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 07:59:50 --> Helper loaded: form_helper
INFO - 2017-01-11 07:59:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 07:59:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 07:59:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 07:59:50 --> Final output sent to browser
DEBUG - 2017-01-11 07:59:50 --> Total execution time: 0.0626
INFO - 2017-01-11 07:59:54 --> Config Class Initialized
INFO - 2017-01-11 07:59:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:59:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:59:54 --> Utf8 Class Initialized
INFO - 2017-01-11 07:59:54 --> URI Class Initialized
INFO - 2017-01-11 07:59:54 --> Router Class Initialized
INFO - 2017-01-11 07:59:54 --> Output Class Initialized
INFO - 2017-01-11 07:59:54 --> Security Class Initialized
DEBUG - 2017-01-11 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:59:55 --> Input Class Initialized
INFO - 2017-01-11 07:59:55 --> Language Class Initialized
INFO - 2017-01-11 07:59:55 --> Loader Class Initialized
INFO - 2017-01-11 07:59:55 --> Helper loaded: url_helper
INFO - 2017-01-11 07:59:55 --> Helper loaded: language_helper
INFO - 2017-01-11 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:59:55 --> Controller Class Initialized
INFO - 2017-01-11 07:59:55 --> Database Driver Class Initialized
INFO - 2017-01-11 07:59:55 --> Model Class Initialized
INFO - 2017-01-11 07:59:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 07:59:55 --> Helper loaded: form_helper
INFO - 2017-01-11 07:59:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 07:59:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 07:59:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 07:59:55 --> Final output sent to browser
DEBUG - 2017-01-11 07:59:55 --> Total execution time: 0.0600
INFO - 2017-01-11 07:59:56 --> Config Class Initialized
INFO - 2017-01-11 07:59:56 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:59:56 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:59:56 --> Utf8 Class Initialized
INFO - 2017-01-11 07:59:56 --> URI Class Initialized
INFO - 2017-01-11 07:59:56 --> Router Class Initialized
INFO - 2017-01-11 07:59:56 --> Output Class Initialized
INFO - 2017-01-11 07:59:56 --> Security Class Initialized
DEBUG - 2017-01-11 07:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:59:56 --> Input Class Initialized
INFO - 2017-01-11 07:59:56 --> Language Class Initialized
INFO - 2017-01-11 07:59:56 --> Loader Class Initialized
INFO - 2017-01-11 07:59:56 --> Helper loaded: url_helper
INFO - 2017-01-11 07:59:56 --> Helper loaded: language_helper
INFO - 2017-01-11 07:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:59:56 --> Controller Class Initialized
INFO - 2017-01-11 07:59:56 --> Database Driver Class Initialized
INFO - 2017-01-11 07:59:56 --> Model Class Initialized
INFO - 2017-01-11 07:59:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 07:59:56 --> Helper loaded: form_helper
INFO - 2017-01-11 07:59:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 07:59:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 07:59:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 07:59:56 --> Final output sent to browser
DEBUG - 2017-01-11 07:59:56 --> Total execution time: 0.0639
INFO - 2017-01-11 07:59:58 --> Config Class Initialized
INFO - 2017-01-11 07:59:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 07:59:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 07:59:58 --> Utf8 Class Initialized
INFO - 2017-01-11 07:59:58 --> URI Class Initialized
INFO - 2017-01-11 07:59:58 --> Router Class Initialized
INFO - 2017-01-11 07:59:58 --> Output Class Initialized
INFO - 2017-01-11 07:59:58 --> Security Class Initialized
DEBUG - 2017-01-11 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 07:59:58 --> Input Class Initialized
INFO - 2017-01-11 07:59:58 --> Language Class Initialized
INFO - 2017-01-11 07:59:58 --> Loader Class Initialized
INFO - 2017-01-11 07:59:58 --> Helper loaded: url_helper
INFO - 2017-01-11 07:59:58 --> Helper loaded: language_helper
INFO - 2017-01-11 07:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 07:59:58 --> Controller Class Initialized
INFO - 2017-01-11 07:59:58 --> Database Driver Class Initialized
INFO - 2017-01-11 07:59:58 --> Model Class Initialized
INFO - 2017-01-11 07:59:58 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 07:59:58 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:00:43 --> Config Class Initialized
INFO - 2017-01-11 08:00:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:00:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:00:43 --> Utf8 Class Initialized
INFO - 2017-01-11 08:00:43 --> URI Class Initialized
INFO - 2017-01-11 08:00:43 --> Router Class Initialized
INFO - 2017-01-11 08:00:43 --> Output Class Initialized
INFO - 2017-01-11 08:00:43 --> Security Class Initialized
DEBUG - 2017-01-11 08:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:00:43 --> Input Class Initialized
INFO - 2017-01-11 08:00:43 --> Language Class Initialized
INFO - 2017-01-11 08:00:43 --> Loader Class Initialized
INFO - 2017-01-11 08:00:43 --> Helper loaded: url_helper
INFO - 2017-01-11 08:00:43 --> Helper loaded: language_helper
INFO - 2017-01-11 08:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:00:43 --> Controller Class Initialized
INFO - 2017-01-11 08:00:43 --> Database Driver Class Initialized
INFO - 2017-01-11 08:00:43 --> Model Class Initialized
INFO - 2017-01-11 08:00:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:00:43 --> Helper loaded: form_helper
INFO - 2017-01-11 08:00:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:00:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:00:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:00:43 --> Final output sent to browser
DEBUG - 2017-01-11 08:00:43 --> Total execution time: 0.0746
INFO - 2017-01-11 08:00:45 --> Config Class Initialized
INFO - 2017-01-11 08:00:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:00:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:00:45 --> Utf8 Class Initialized
INFO - 2017-01-11 08:00:45 --> URI Class Initialized
INFO - 2017-01-11 08:00:45 --> Router Class Initialized
INFO - 2017-01-11 08:00:45 --> Output Class Initialized
INFO - 2017-01-11 08:00:45 --> Security Class Initialized
DEBUG - 2017-01-11 08:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:00:45 --> Input Class Initialized
INFO - 2017-01-11 08:00:45 --> Language Class Initialized
INFO - 2017-01-11 08:00:45 --> Loader Class Initialized
INFO - 2017-01-11 08:00:45 --> Helper loaded: url_helper
INFO - 2017-01-11 08:00:45 --> Helper loaded: language_helper
INFO - 2017-01-11 08:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:00:45 --> Controller Class Initialized
INFO - 2017-01-11 08:00:45 --> Database Driver Class Initialized
INFO - 2017-01-11 08:00:45 --> Model Class Initialized
INFO - 2017-01-11 08:00:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:00:45 --> Helper loaded: form_helper
INFO - 2017-01-11 08:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:00:45 --> Final output sent to browser
DEBUG - 2017-01-11 08:00:45 --> Total execution time: 0.0780
INFO - 2017-01-11 08:00:50 --> Config Class Initialized
INFO - 2017-01-11 08:00:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:00:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:00:50 --> Utf8 Class Initialized
INFO - 2017-01-11 08:00:50 --> URI Class Initialized
INFO - 2017-01-11 08:00:50 --> Router Class Initialized
INFO - 2017-01-11 08:00:50 --> Output Class Initialized
INFO - 2017-01-11 08:00:50 --> Security Class Initialized
DEBUG - 2017-01-11 08:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:00:50 --> Input Class Initialized
INFO - 2017-01-11 08:00:50 --> Language Class Initialized
INFO - 2017-01-11 08:00:50 --> Loader Class Initialized
INFO - 2017-01-11 08:00:50 --> Helper loaded: url_helper
INFO - 2017-01-11 08:00:50 --> Helper loaded: language_helper
INFO - 2017-01-11 08:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:00:50 --> Controller Class Initialized
INFO - 2017-01-11 08:00:50 --> Database Driver Class Initialized
INFO - 2017-01-11 08:00:50 --> Model Class Initialized
INFO - 2017-01-11 08:00:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:00:50 --> Model Class Initialized
INFO - 2017-01-11 08:00:50 --> Model Class Initialized
INFO - 2017-01-11 08:00:50 --> Helper loaded: form_helper
INFO - 2017-01-11 08:00:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:00:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-11 08:00:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:00:50 --> Final output sent to browser
DEBUG - 2017-01-11 08:00:50 --> Total execution time: 0.1012
INFO - 2017-01-11 08:00:52 --> Config Class Initialized
INFO - 2017-01-11 08:00:52 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:00:52 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:00:52 --> Utf8 Class Initialized
INFO - 2017-01-11 08:00:52 --> URI Class Initialized
INFO - 2017-01-11 08:00:52 --> Router Class Initialized
INFO - 2017-01-11 08:00:52 --> Output Class Initialized
INFO - 2017-01-11 08:00:52 --> Security Class Initialized
DEBUG - 2017-01-11 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:00:52 --> Input Class Initialized
INFO - 2017-01-11 08:00:52 --> Language Class Initialized
INFO - 2017-01-11 08:00:52 --> Loader Class Initialized
INFO - 2017-01-11 08:00:52 --> Helper loaded: url_helper
INFO - 2017-01-11 08:00:52 --> Helper loaded: language_helper
INFO - 2017-01-11 08:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:00:52 --> Controller Class Initialized
INFO - 2017-01-11 08:00:52 --> Database Driver Class Initialized
INFO - 2017-01-11 08:00:52 --> Model Class Initialized
INFO - 2017-01-11 08:00:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:00:52 --> Helper loaded: form_helper
INFO - 2017-01-11 08:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:00:52 --> Final output sent to browser
DEBUG - 2017-01-11 08:00:52 --> Total execution time: 0.0724
INFO - 2017-01-11 08:00:53 --> Config Class Initialized
INFO - 2017-01-11 08:00:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:00:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:00:53 --> Utf8 Class Initialized
INFO - 2017-01-11 08:00:53 --> URI Class Initialized
INFO - 2017-01-11 08:00:53 --> Router Class Initialized
INFO - 2017-01-11 08:00:53 --> Output Class Initialized
INFO - 2017-01-11 08:00:53 --> Security Class Initialized
DEBUG - 2017-01-11 08:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:00:53 --> Input Class Initialized
INFO - 2017-01-11 08:00:53 --> Language Class Initialized
INFO - 2017-01-11 08:00:53 --> Loader Class Initialized
INFO - 2017-01-11 08:00:53 --> Helper loaded: url_helper
INFO - 2017-01-11 08:00:53 --> Helper loaded: language_helper
INFO - 2017-01-11 08:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:00:53 --> Controller Class Initialized
INFO - 2017-01-11 08:00:53 --> Database Driver Class Initialized
INFO - 2017-01-11 08:00:53 --> Model Class Initialized
INFO - 2017-01-11 08:00:53 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:00:53 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:01:08 --> Config Class Initialized
INFO - 2017-01-11 08:01:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:01:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:01:08 --> Utf8 Class Initialized
INFO - 2017-01-11 08:01:08 --> URI Class Initialized
INFO - 2017-01-11 08:01:08 --> Router Class Initialized
INFO - 2017-01-11 08:01:08 --> Output Class Initialized
INFO - 2017-01-11 08:01:08 --> Security Class Initialized
DEBUG - 2017-01-11 08:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:01:08 --> Input Class Initialized
INFO - 2017-01-11 08:01:08 --> Language Class Initialized
INFO - 2017-01-11 08:01:08 --> Loader Class Initialized
INFO - 2017-01-11 08:01:08 --> Helper loaded: url_helper
INFO - 2017-01-11 08:01:08 --> Helper loaded: language_helper
INFO - 2017-01-11 08:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:01:08 --> Controller Class Initialized
INFO - 2017-01-11 08:01:08 --> Database Driver Class Initialized
INFO - 2017-01-11 08:01:08 --> Model Class Initialized
INFO - 2017-01-11 08:01:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:01:08 --> Helper loaded: form_helper
INFO - 2017-01-11 08:01:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:01:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:01:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:01:08 --> Final output sent to browser
DEBUG - 2017-01-11 08:01:08 --> Total execution time: 0.0621
INFO - 2017-01-11 08:03:50 --> Config Class Initialized
INFO - 2017-01-11 08:03:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:03:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:03:50 --> Utf8 Class Initialized
INFO - 2017-01-11 08:03:50 --> URI Class Initialized
INFO - 2017-01-11 08:03:50 --> Router Class Initialized
INFO - 2017-01-11 08:03:50 --> Output Class Initialized
INFO - 2017-01-11 08:03:50 --> Security Class Initialized
DEBUG - 2017-01-11 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:03:50 --> Input Class Initialized
INFO - 2017-01-11 08:03:50 --> Language Class Initialized
INFO - 2017-01-11 08:03:50 --> Loader Class Initialized
INFO - 2017-01-11 08:03:50 --> Helper loaded: url_helper
INFO - 2017-01-11 08:03:50 --> Helper loaded: language_helper
INFO - 2017-01-11 08:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:03:50 --> Controller Class Initialized
INFO - 2017-01-11 08:03:50 --> Database Driver Class Initialized
INFO - 2017-01-11 08:03:50 --> Model Class Initialized
INFO - 2017-01-11 08:03:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:03:50 --> Helper loaded: form_helper
INFO - 2017-01-11 08:03:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:03:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:03:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:03:50 --> Final output sent to browser
DEBUG - 2017-01-11 08:03:50 --> Total execution time: 0.0703
INFO - 2017-01-11 08:03:51 --> Config Class Initialized
INFO - 2017-01-11 08:03:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:03:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:03:51 --> Utf8 Class Initialized
INFO - 2017-01-11 08:03:51 --> URI Class Initialized
INFO - 2017-01-11 08:03:51 --> Router Class Initialized
INFO - 2017-01-11 08:03:51 --> Output Class Initialized
INFO - 2017-01-11 08:03:51 --> Security Class Initialized
DEBUG - 2017-01-11 08:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:03:51 --> Input Class Initialized
INFO - 2017-01-11 08:03:51 --> Language Class Initialized
INFO - 2017-01-11 08:03:51 --> Loader Class Initialized
INFO - 2017-01-11 08:03:51 --> Helper loaded: url_helper
INFO - 2017-01-11 08:03:51 --> Helper loaded: language_helper
INFO - 2017-01-11 08:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:03:51 --> Controller Class Initialized
INFO - 2017-01-11 08:03:51 --> Database Driver Class Initialized
INFO - 2017-01-11 08:03:51 --> Model Class Initialized
INFO - 2017-01-11 08:03:51 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:03:52 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:03:54 --> Config Class Initialized
INFO - 2017-01-11 08:03:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:03:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:03:54 --> Utf8 Class Initialized
INFO - 2017-01-11 08:03:54 --> URI Class Initialized
INFO - 2017-01-11 08:03:54 --> Router Class Initialized
INFO - 2017-01-11 08:03:54 --> Output Class Initialized
INFO - 2017-01-11 08:03:54 --> Security Class Initialized
DEBUG - 2017-01-11 08:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:03:54 --> Input Class Initialized
INFO - 2017-01-11 08:03:54 --> Language Class Initialized
INFO - 2017-01-11 08:03:54 --> Loader Class Initialized
INFO - 2017-01-11 08:03:54 --> Helper loaded: url_helper
INFO - 2017-01-11 08:03:54 --> Helper loaded: language_helper
INFO - 2017-01-11 08:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:03:54 --> Controller Class Initialized
INFO - 2017-01-11 08:03:54 --> Database Driver Class Initialized
INFO - 2017-01-11 08:03:54 --> Model Class Initialized
INFO - 2017-01-11 08:03:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:03:54 --> Helper loaded: form_helper
INFO - 2017-01-11 08:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:03:54 --> Final output sent to browser
DEBUG - 2017-01-11 08:03:54 --> Total execution time: 0.0623
INFO - 2017-01-11 08:04:40 --> Config Class Initialized
INFO - 2017-01-11 08:04:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:04:40 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:04:40 --> Utf8 Class Initialized
INFO - 2017-01-11 08:04:40 --> URI Class Initialized
INFO - 2017-01-11 08:04:40 --> Router Class Initialized
INFO - 2017-01-11 08:04:40 --> Output Class Initialized
INFO - 2017-01-11 08:04:40 --> Security Class Initialized
DEBUG - 2017-01-11 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:04:40 --> Input Class Initialized
INFO - 2017-01-11 08:04:40 --> Language Class Initialized
INFO - 2017-01-11 08:04:40 --> Loader Class Initialized
INFO - 2017-01-11 08:04:40 --> Helper loaded: url_helper
INFO - 2017-01-11 08:04:40 --> Helper loaded: language_helper
INFO - 2017-01-11 08:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:04:40 --> Controller Class Initialized
INFO - 2017-01-11 08:04:40 --> Database Driver Class Initialized
INFO - 2017-01-11 08:04:40 --> Model Class Initialized
INFO - 2017-01-11 08:04:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:04:40 --> Helper loaded: form_helper
INFO - 2017-01-11 08:04:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:04:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:04:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:04:40 --> Final output sent to browser
DEBUG - 2017-01-11 08:04:40 --> Total execution time: 0.0646
INFO - 2017-01-11 08:04:42 --> Config Class Initialized
INFO - 2017-01-11 08:04:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:04:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:04:42 --> Utf8 Class Initialized
INFO - 2017-01-11 08:04:42 --> URI Class Initialized
INFO - 2017-01-11 08:04:42 --> Router Class Initialized
INFO - 2017-01-11 08:04:42 --> Output Class Initialized
INFO - 2017-01-11 08:04:42 --> Security Class Initialized
DEBUG - 2017-01-11 08:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:04:42 --> Input Class Initialized
INFO - 2017-01-11 08:04:42 --> Language Class Initialized
INFO - 2017-01-11 08:04:42 --> Loader Class Initialized
INFO - 2017-01-11 08:04:42 --> Helper loaded: url_helper
INFO - 2017-01-11 08:04:42 --> Helper loaded: language_helper
INFO - 2017-01-11 08:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:04:43 --> Controller Class Initialized
INFO - 2017-01-11 08:04:43 --> Database Driver Class Initialized
INFO - 2017-01-11 08:04:43 --> Model Class Initialized
INFO - 2017-01-11 08:04:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:04:43 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:05:43 --> Config Class Initialized
INFO - 2017-01-11 08:05:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:05:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:05:43 --> Utf8 Class Initialized
INFO - 2017-01-11 08:05:43 --> URI Class Initialized
INFO - 2017-01-11 08:05:43 --> Router Class Initialized
INFO - 2017-01-11 08:05:43 --> Output Class Initialized
INFO - 2017-01-11 08:05:43 --> Security Class Initialized
DEBUG - 2017-01-11 08:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:05:43 --> Input Class Initialized
INFO - 2017-01-11 08:05:43 --> Language Class Initialized
INFO - 2017-01-11 08:05:43 --> Loader Class Initialized
INFO - 2017-01-11 08:05:43 --> Helper loaded: url_helper
INFO - 2017-01-11 08:05:43 --> Helper loaded: language_helper
INFO - 2017-01-11 08:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:05:43 --> Controller Class Initialized
INFO - 2017-01-11 08:05:43 --> Database Driver Class Initialized
INFO - 2017-01-11 08:05:43 --> Model Class Initialized
INFO - 2017-01-11 08:05:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:05:43 --> Helper loaded: form_helper
INFO - 2017-01-11 08:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:05:43 --> Final output sent to browser
DEBUG - 2017-01-11 08:05:43 --> Total execution time: 0.0645
INFO - 2017-01-11 08:05:44 --> Config Class Initialized
INFO - 2017-01-11 08:05:44 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:05:44 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:05:44 --> Utf8 Class Initialized
INFO - 2017-01-11 08:05:44 --> URI Class Initialized
INFO - 2017-01-11 08:05:44 --> Router Class Initialized
INFO - 2017-01-11 08:05:44 --> Output Class Initialized
INFO - 2017-01-11 08:05:44 --> Security Class Initialized
DEBUG - 2017-01-11 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:05:44 --> Input Class Initialized
INFO - 2017-01-11 08:05:44 --> Language Class Initialized
INFO - 2017-01-11 08:05:44 --> Loader Class Initialized
INFO - 2017-01-11 08:05:44 --> Helper loaded: url_helper
INFO - 2017-01-11 08:05:44 --> Helper loaded: language_helper
INFO - 2017-01-11 08:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:05:44 --> Controller Class Initialized
INFO - 2017-01-11 08:05:44 --> Database Driver Class Initialized
INFO - 2017-01-11 08:05:44 --> Model Class Initialized
INFO - 2017-01-11 08:05:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:05:44 --> Helper loaded: form_helper
INFO - 2017-01-11 08:05:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:05:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:05:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:05:44 --> Final output sent to browser
DEBUG - 2017-01-11 08:05:44 --> Total execution time: 0.0756
INFO - 2017-01-11 08:07:20 --> Config Class Initialized
INFO - 2017-01-11 08:07:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:07:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:07:20 --> Utf8 Class Initialized
INFO - 2017-01-11 08:07:20 --> URI Class Initialized
INFO - 2017-01-11 08:07:20 --> Router Class Initialized
INFO - 2017-01-11 08:07:20 --> Output Class Initialized
INFO - 2017-01-11 08:07:20 --> Security Class Initialized
DEBUG - 2017-01-11 08:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:07:20 --> Input Class Initialized
INFO - 2017-01-11 08:07:20 --> Language Class Initialized
INFO - 2017-01-11 08:07:20 --> Loader Class Initialized
INFO - 2017-01-11 08:07:20 --> Helper loaded: url_helper
INFO - 2017-01-11 08:07:20 --> Helper loaded: language_helper
INFO - 2017-01-11 08:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:07:20 --> Controller Class Initialized
INFO - 2017-01-11 08:07:20 --> Database Driver Class Initialized
INFO - 2017-01-11 08:07:20 --> Model Class Initialized
INFO - 2017-01-11 08:07:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:07:20 --> Helper loaded: form_helper
INFO - 2017-01-11 08:07:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:07:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:07:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:07:20 --> Final output sent to browser
DEBUG - 2017-01-11 08:07:20 --> Total execution time: 0.0611
INFO - 2017-01-11 08:07:21 --> Config Class Initialized
INFO - 2017-01-11 08:07:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:07:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:07:21 --> Utf8 Class Initialized
INFO - 2017-01-11 08:07:21 --> URI Class Initialized
INFO - 2017-01-11 08:07:21 --> Router Class Initialized
INFO - 2017-01-11 08:07:21 --> Output Class Initialized
INFO - 2017-01-11 08:07:21 --> Security Class Initialized
DEBUG - 2017-01-11 08:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:07:21 --> Input Class Initialized
INFO - 2017-01-11 08:07:21 --> Language Class Initialized
INFO - 2017-01-11 08:07:21 --> Loader Class Initialized
INFO - 2017-01-11 08:07:21 --> Helper loaded: url_helper
INFO - 2017-01-11 08:07:21 --> Helper loaded: language_helper
INFO - 2017-01-11 08:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:07:21 --> Controller Class Initialized
INFO - 2017-01-11 08:07:21 --> Database Driver Class Initialized
INFO - 2017-01-11 08:07:21 --> Model Class Initialized
INFO - 2017-01-11 08:07:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:07:21 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:07:29 --> Config Class Initialized
INFO - 2017-01-11 08:07:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:07:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:07:29 --> Utf8 Class Initialized
INFO - 2017-01-11 08:07:29 --> URI Class Initialized
INFO - 2017-01-11 08:07:29 --> Router Class Initialized
INFO - 2017-01-11 08:07:29 --> Output Class Initialized
INFO - 2017-01-11 08:07:29 --> Security Class Initialized
DEBUG - 2017-01-11 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:07:29 --> Input Class Initialized
INFO - 2017-01-11 08:07:29 --> Language Class Initialized
INFO - 2017-01-11 08:07:29 --> Loader Class Initialized
INFO - 2017-01-11 08:07:29 --> Helper loaded: url_helper
INFO - 2017-01-11 08:07:29 --> Helper loaded: language_helper
INFO - 2017-01-11 08:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:07:29 --> Controller Class Initialized
INFO - 2017-01-11 08:07:29 --> Database Driver Class Initialized
INFO - 2017-01-11 08:07:29 --> Model Class Initialized
INFO - 2017-01-11 08:07:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:07:29 --> Helper loaded: form_helper
INFO - 2017-01-11 08:07:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:07:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:07:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:07:29 --> Final output sent to browser
DEBUG - 2017-01-11 08:07:29 --> Total execution time: 0.0609
INFO - 2017-01-11 08:07:31 --> Config Class Initialized
INFO - 2017-01-11 08:07:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:07:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:07:31 --> Utf8 Class Initialized
INFO - 2017-01-11 08:07:31 --> URI Class Initialized
INFO - 2017-01-11 08:07:31 --> Router Class Initialized
INFO - 2017-01-11 08:07:31 --> Output Class Initialized
INFO - 2017-01-11 08:07:31 --> Security Class Initialized
DEBUG - 2017-01-11 08:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:07:31 --> Input Class Initialized
INFO - 2017-01-11 08:07:31 --> Language Class Initialized
INFO - 2017-01-11 08:07:31 --> Loader Class Initialized
INFO - 2017-01-11 08:07:31 --> Helper loaded: url_helper
INFO - 2017-01-11 08:07:31 --> Helper loaded: language_helper
INFO - 2017-01-11 08:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:07:31 --> Controller Class Initialized
INFO - 2017-01-11 08:07:31 --> Database Driver Class Initialized
INFO - 2017-01-11 08:07:31 --> Model Class Initialized
INFO - 2017-01-11 08:07:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:07:31 --> Helper loaded: form_helper
INFO - 2017-01-11 08:07:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:07:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:07:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:07:31 --> Final output sent to browser
DEBUG - 2017-01-11 08:07:31 --> Total execution time: 0.0802
INFO - 2017-01-11 08:10:32 --> Config Class Initialized
INFO - 2017-01-11 08:10:32 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:10:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:10:32 --> Utf8 Class Initialized
INFO - 2017-01-11 08:10:32 --> URI Class Initialized
INFO - 2017-01-11 08:10:32 --> Router Class Initialized
INFO - 2017-01-11 08:10:32 --> Output Class Initialized
INFO - 2017-01-11 08:10:32 --> Security Class Initialized
DEBUG - 2017-01-11 08:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:10:32 --> Input Class Initialized
INFO - 2017-01-11 08:10:32 --> Language Class Initialized
INFO - 2017-01-11 08:10:32 --> Loader Class Initialized
INFO - 2017-01-11 08:10:32 --> Helper loaded: url_helper
INFO - 2017-01-11 08:10:32 --> Helper loaded: language_helper
INFO - 2017-01-11 08:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:10:32 --> Controller Class Initialized
INFO - 2017-01-11 08:10:32 --> Database Driver Class Initialized
INFO - 2017-01-11 08:10:32 --> Model Class Initialized
INFO - 2017-01-11 08:10:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:10:32 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:14:54 --> Config Class Initialized
INFO - 2017-01-11 08:14:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:14:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:14:54 --> Utf8 Class Initialized
INFO - 2017-01-11 08:14:54 --> URI Class Initialized
INFO - 2017-01-11 08:14:54 --> Router Class Initialized
INFO - 2017-01-11 08:14:54 --> Output Class Initialized
INFO - 2017-01-11 08:14:54 --> Security Class Initialized
DEBUG - 2017-01-11 08:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:14:54 --> Input Class Initialized
INFO - 2017-01-11 08:14:54 --> Language Class Initialized
INFO - 2017-01-11 08:14:54 --> Loader Class Initialized
INFO - 2017-01-11 08:14:54 --> Helper loaded: url_helper
INFO - 2017-01-11 08:14:54 --> Helper loaded: language_helper
INFO - 2017-01-11 08:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:14:54 --> Controller Class Initialized
INFO - 2017-01-11 08:14:54 --> Database Driver Class Initialized
INFO - 2017-01-11 08:14:54 --> Model Class Initialized
INFO - 2017-01-11 08:14:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:14:54 --> Helper loaded: form_helper
INFO - 2017-01-11 08:14:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:14:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:14:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:14:54 --> Final output sent to browser
DEBUG - 2017-01-11 08:14:54 --> Total execution time: 0.0629
INFO - 2017-01-11 08:17:04 --> Config Class Initialized
INFO - 2017-01-11 08:17:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:17:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:17:04 --> Utf8 Class Initialized
INFO - 2017-01-11 08:17:04 --> URI Class Initialized
INFO - 2017-01-11 08:17:04 --> Router Class Initialized
INFO - 2017-01-11 08:17:04 --> Output Class Initialized
INFO - 2017-01-11 08:17:04 --> Security Class Initialized
DEBUG - 2017-01-11 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:17:04 --> Input Class Initialized
INFO - 2017-01-11 08:17:04 --> Language Class Initialized
INFO - 2017-01-11 08:17:04 --> Loader Class Initialized
INFO - 2017-01-11 08:17:04 --> Helper loaded: url_helper
INFO - 2017-01-11 08:17:04 --> Helper loaded: language_helper
INFO - 2017-01-11 08:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:17:04 --> Controller Class Initialized
INFO - 2017-01-11 08:17:04 --> Database Driver Class Initialized
INFO - 2017-01-11 08:17:04 --> Model Class Initialized
INFO - 2017-01-11 08:17:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:17:04 --> Helper loaded: form_helper
INFO - 2017-01-11 08:17:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:17:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:17:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:17:04 --> Final output sent to browser
DEBUG - 2017-01-11 08:17:04 --> Total execution time: 0.0634
INFO - 2017-01-11 08:17:34 --> Config Class Initialized
INFO - 2017-01-11 08:17:34 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:17:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:17:34 --> Utf8 Class Initialized
INFO - 2017-01-11 08:17:34 --> URI Class Initialized
INFO - 2017-01-11 08:17:34 --> Router Class Initialized
INFO - 2017-01-11 08:17:34 --> Output Class Initialized
INFO - 2017-01-11 08:17:34 --> Security Class Initialized
DEBUG - 2017-01-11 08:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:17:34 --> Input Class Initialized
INFO - 2017-01-11 08:17:34 --> Language Class Initialized
INFO - 2017-01-11 08:17:34 --> Loader Class Initialized
INFO - 2017-01-11 08:17:34 --> Helper loaded: url_helper
INFO - 2017-01-11 08:17:34 --> Helper loaded: language_helper
INFO - 2017-01-11 08:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:17:34 --> Controller Class Initialized
INFO - 2017-01-11 08:17:34 --> Database Driver Class Initialized
INFO - 2017-01-11 08:17:34 --> Model Class Initialized
INFO - 2017-01-11 08:17:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:17:34 --> Helper loaded: form_helper
INFO - 2017-01-11 08:17:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:17:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:17:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:17:34 --> Final output sent to browser
DEBUG - 2017-01-11 08:17:34 --> Total execution time: 0.0614
INFO - 2017-01-11 08:30:38 --> Config Class Initialized
INFO - 2017-01-11 08:30:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:30:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:30:38 --> Utf8 Class Initialized
INFO - 2017-01-11 08:30:38 --> URI Class Initialized
INFO - 2017-01-11 08:30:38 --> Router Class Initialized
INFO - 2017-01-11 08:30:38 --> Output Class Initialized
INFO - 2017-01-11 08:30:38 --> Security Class Initialized
DEBUG - 2017-01-11 08:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:30:38 --> Input Class Initialized
INFO - 2017-01-11 08:30:38 --> Language Class Initialized
INFO - 2017-01-11 08:30:38 --> Loader Class Initialized
INFO - 2017-01-11 08:30:38 --> Helper loaded: url_helper
INFO - 2017-01-11 08:30:38 --> Helper loaded: language_helper
INFO - 2017-01-11 08:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:30:38 --> Controller Class Initialized
INFO - 2017-01-11 08:30:38 --> Database Driver Class Initialized
INFO - 2017-01-11 08:30:38 --> Model Class Initialized
INFO - 2017-01-11 08:30:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:30:38 --> Config Class Initialized
INFO - 2017-01-11 08:30:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:30:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:30:38 --> Utf8 Class Initialized
INFO - 2017-01-11 08:30:38 --> URI Class Initialized
INFO - 2017-01-11 08:30:38 --> Router Class Initialized
INFO - 2017-01-11 08:30:38 --> Output Class Initialized
INFO - 2017-01-11 08:30:38 --> Security Class Initialized
DEBUG - 2017-01-11 08:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:30:38 --> Input Class Initialized
INFO - 2017-01-11 08:30:38 --> Language Class Initialized
INFO - 2017-01-11 08:30:38 --> Loader Class Initialized
INFO - 2017-01-11 08:30:38 --> Helper loaded: url_helper
INFO - 2017-01-11 08:30:38 --> Helper loaded: language_helper
INFO - 2017-01-11 08:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:30:38 --> Controller Class Initialized
INFO - 2017-01-11 08:30:38 --> Database Driver Class Initialized
INFO - 2017-01-11 08:30:38 --> Model Class Initialized
INFO - 2017-01-11 08:30:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:30:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 08:30:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 08:30:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 08:30:38 --> Final output sent to browser
DEBUG - 2017-01-11 08:30:38 --> Total execution time: 0.0515
INFO - 2017-01-11 08:30:45 --> Config Class Initialized
INFO - 2017-01-11 08:30:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:30:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:30:45 --> Utf8 Class Initialized
INFO - 2017-01-11 08:30:45 --> URI Class Initialized
INFO - 2017-01-11 08:30:45 --> Router Class Initialized
INFO - 2017-01-11 08:30:45 --> Output Class Initialized
INFO - 2017-01-11 08:30:45 --> Security Class Initialized
DEBUG - 2017-01-11 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:30:45 --> Input Class Initialized
INFO - 2017-01-11 08:30:45 --> Language Class Initialized
INFO - 2017-01-11 08:30:45 --> Loader Class Initialized
INFO - 2017-01-11 08:30:45 --> Helper loaded: url_helper
INFO - 2017-01-11 08:30:45 --> Helper loaded: language_helper
INFO - 2017-01-11 08:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:30:45 --> Controller Class Initialized
INFO - 2017-01-11 08:30:45 --> Database Driver Class Initialized
INFO - 2017-01-11 08:30:45 --> Model Class Initialized
INFO - 2017-01-11 08:30:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:30:45 --> Config Class Initialized
INFO - 2017-01-11 08:30:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:30:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:30:45 --> Utf8 Class Initialized
INFO - 2017-01-11 08:30:45 --> URI Class Initialized
INFO - 2017-01-11 08:30:45 --> Router Class Initialized
INFO - 2017-01-11 08:30:45 --> Output Class Initialized
INFO - 2017-01-11 08:30:45 --> Security Class Initialized
DEBUG - 2017-01-11 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:30:45 --> Input Class Initialized
INFO - 2017-01-11 08:30:45 --> Language Class Initialized
INFO - 2017-01-11 08:30:45 --> Loader Class Initialized
INFO - 2017-01-11 08:30:45 --> Helper loaded: url_helper
INFO - 2017-01-11 08:30:45 --> Helper loaded: language_helper
INFO - 2017-01-11 08:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:30:45 --> Controller Class Initialized
INFO - 2017-01-11 08:30:45 --> Database Driver Class Initialized
INFO - 2017-01-11 08:30:45 --> Model Class Initialized
INFO - 2017-01-11 08:30:45 --> Model Class Initialized
INFO - 2017-01-11 08:30:45 --> Model Class Initialized
INFO - 2017-01-11 08:30:45 --> Model Class Initialized
INFO - 2017-01-11 08:30:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:30:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:30:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 08:30:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:30:45 --> Final output sent to browser
DEBUG - 2017-01-11 08:30:45 --> Total execution time: 0.0618
INFO - 2017-01-11 08:37:02 --> Config Class Initialized
INFO - 2017-01-11 08:37:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:02 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:02 --> URI Class Initialized
INFO - 2017-01-11 08:37:02 --> Router Class Initialized
INFO - 2017-01-11 08:37:02 --> Output Class Initialized
INFO - 2017-01-11 08:37:02 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:02 --> Input Class Initialized
INFO - 2017-01-11 08:37:02 --> Language Class Initialized
INFO - 2017-01-11 08:37:02 --> Loader Class Initialized
INFO - 2017-01-11 08:37:02 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:02 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:02 --> Controller Class Initialized
INFO - 2017-01-11 08:37:02 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:02 --> Model Class Initialized
INFO - 2017-01-11 08:37:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:02 --> Helper loaded: form_helper
INFO - 2017-01-11 08:37:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:37:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:37:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:37:02 --> Final output sent to browser
DEBUG - 2017-01-11 08:37:02 --> Total execution time: 0.0707
INFO - 2017-01-11 08:37:04 --> Config Class Initialized
INFO - 2017-01-11 08:37:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:04 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:04 --> URI Class Initialized
INFO - 2017-01-11 08:37:04 --> Router Class Initialized
INFO - 2017-01-11 08:37:04 --> Output Class Initialized
INFO - 2017-01-11 08:37:04 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:04 --> Input Class Initialized
INFO - 2017-01-11 08:37:04 --> Language Class Initialized
INFO - 2017-01-11 08:37:04 --> Loader Class Initialized
INFO - 2017-01-11 08:37:04 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:04 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:04 --> Controller Class Initialized
INFO - 2017-01-11 08:37:04 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:04 --> Model Class Initialized
INFO - 2017-01-11 08:37:04 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:37:04 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:37:06 --> Config Class Initialized
INFO - 2017-01-11 08:37:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:06 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:06 --> URI Class Initialized
INFO - 2017-01-11 08:37:06 --> Router Class Initialized
INFO - 2017-01-11 08:37:06 --> Output Class Initialized
INFO - 2017-01-11 08:37:06 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:06 --> Input Class Initialized
INFO - 2017-01-11 08:37:06 --> Language Class Initialized
INFO - 2017-01-11 08:37:06 --> Loader Class Initialized
INFO - 2017-01-11 08:37:06 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:06 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:06 --> Controller Class Initialized
INFO - 2017-01-11 08:37:06 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:06 --> Model Class Initialized
INFO - 2017-01-11 08:37:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:06 --> Helper loaded: form_helper
INFO - 2017-01-11 08:37:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:37:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:37:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:37:06 --> Final output sent to browser
DEBUG - 2017-01-11 08:37:06 --> Total execution time: 0.0619
INFO - 2017-01-11 08:37:17 --> Config Class Initialized
INFO - 2017-01-11 08:37:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:17 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:17 --> URI Class Initialized
DEBUG - 2017-01-11 08:37:17 --> No URI present. Default controller set.
INFO - 2017-01-11 08:37:17 --> Router Class Initialized
INFO - 2017-01-11 08:37:17 --> Output Class Initialized
INFO - 2017-01-11 08:37:17 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:17 --> Input Class Initialized
INFO - 2017-01-11 08:37:17 --> Language Class Initialized
INFO - 2017-01-11 08:37:17 --> Loader Class Initialized
INFO - 2017-01-11 08:37:17 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:17 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:17 --> Controller Class Initialized
INFO - 2017-01-11 08:37:17 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:17 --> Model Class Initialized
INFO - 2017-01-11 08:37:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 08:37:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 08:37:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 08:37:17 --> Final output sent to browser
DEBUG - 2017-01-11 08:37:17 --> Total execution time: 0.0596
INFO - 2017-01-11 08:37:21 --> Config Class Initialized
INFO - 2017-01-11 08:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:21 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:21 --> URI Class Initialized
INFO - 2017-01-11 08:37:21 --> Router Class Initialized
INFO - 2017-01-11 08:37:21 --> Output Class Initialized
INFO - 2017-01-11 08:37:21 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:21 --> Input Class Initialized
INFO - 2017-01-11 08:37:21 --> Language Class Initialized
INFO - 2017-01-11 08:37:21 --> Loader Class Initialized
INFO - 2017-01-11 08:37:21 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:21 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:21 --> Controller Class Initialized
INFO - 2017-01-11 08:37:21 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:21 --> Model Class Initialized
INFO - 2017-01-11 08:37:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:21 --> Config Class Initialized
INFO - 2017-01-11 08:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:21 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:21 --> URI Class Initialized
INFO - 2017-01-11 08:37:21 --> Router Class Initialized
INFO - 2017-01-11 08:37:21 --> Output Class Initialized
INFO - 2017-01-11 08:37:21 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:21 --> Input Class Initialized
INFO - 2017-01-11 08:37:21 --> Language Class Initialized
INFO - 2017-01-11 08:37:21 --> Loader Class Initialized
INFO - 2017-01-11 08:37:21 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:21 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:21 --> Controller Class Initialized
INFO - 2017-01-11 08:37:21 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:21 --> Model Class Initialized
INFO - 2017-01-11 08:37:21 --> Model Class Initialized
INFO - 2017-01-11 08:37:21 --> Model Class Initialized
INFO - 2017-01-11 08:37:21 --> Model Class Initialized
INFO - 2017-01-11 08:37:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:37:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 08:37:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:37:21 --> Final output sent to browser
DEBUG - 2017-01-11 08:37:21 --> Total execution time: 0.0633
INFO - 2017-01-11 08:37:25 --> Config Class Initialized
INFO - 2017-01-11 08:37:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:25 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:25 --> URI Class Initialized
INFO - 2017-01-11 08:37:25 --> Router Class Initialized
INFO - 2017-01-11 08:37:25 --> Output Class Initialized
INFO - 2017-01-11 08:37:25 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:25 --> Input Class Initialized
INFO - 2017-01-11 08:37:25 --> Language Class Initialized
INFO - 2017-01-11 08:37:25 --> Loader Class Initialized
INFO - 2017-01-11 08:37:25 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:25 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:25 --> Controller Class Initialized
INFO - 2017-01-11 08:37:25 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:25 --> Model Class Initialized
INFO - 2017-01-11 08:37:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:25 --> Helper loaded: form_helper
INFO - 2017-01-11 08:37:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:37:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:37:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:37:25 --> Final output sent to browser
DEBUG - 2017-01-11 08:37:25 --> Total execution time: 0.0644
INFO - 2017-01-11 08:37:27 --> Config Class Initialized
INFO - 2017-01-11 08:37:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:27 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:27 --> URI Class Initialized
INFO - 2017-01-11 08:37:27 --> Router Class Initialized
INFO - 2017-01-11 08:37:27 --> Output Class Initialized
INFO - 2017-01-11 08:37:27 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:27 --> Input Class Initialized
INFO - 2017-01-11 08:37:27 --> Language Class Initialized
INFO - 2017-01-11 08:37:27 --> Loader Class Initialized
INFO - 2017-01-11 08:37:27 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:27 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:27 --> Controller Class Initialized
INFO - 2017-01-11 08:37:27 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:27 --> Model Class Initialized
INFO - 2017-01-11 08:37:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:37:27 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:37:29 --> Config Class Initialized
INFO - 2017-01-11 08:37:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:37:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:37:29 --> Utf8 Class Initialized
INFO - 2017-01-11 08:37:29 --> URI Class Initialized
INFO - 2017-01-11 08:37:29 --> Router Class Initialized
INFO - 2017-01-11 08:37:29 --> Output Class Initialized
INFO - 2017-01-11 08:37:29 --> Security Class Initialized
DEBUG - 2017-01-11 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:37:29 --> Input Class Initialized
INFO - 2017-01-11 08:37:29 --> Language Class Initialized
INFO - 2017-01-11 08:37:29 --> Loader Class Initialized
INFO - 2017-01-11 08:37:29 --> Helper loaded: url_helper
INFO - 2017-01-11 08:37:29 --> Helper loaded: language_helper
INFO - 2017-01-11 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:37:29 --> Controller Class Initialized
INFO - 2017-01-11 08:37:29 --> Database Driver Class Initialized
INFO - 2017-01-11 08:37:29 --> Model Class Initialized
INFO - 2017-01-11 08:37:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:37:29 --> Helper loaded: form_helper
INFO - 2017-01-11 08:37:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:37:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:37:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:37:29 --> Final output sent to browser
DEBUG - 2017-01-11 08:37:29 --> Total execution time: 0.0572
INFO - 2017-01-11 08:38:16 --> Config Class Initialized
INFO - 2017-01-11 08:38:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:38:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:38:16 --> Utf8 Class Initialized
INFO - 2017-01-11 08:38:16 --> URI Class Initialized
INFO - 2017-01-11 08:38:16 --> Router Class Initialized
INFO - 2017-01-11 08:38:16 --> Output Class Initialized
INFO - 2017-01-11 08:38:16 --> Security Class Initialized
DEBUG - 2017-01-11 08:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:38:16 --> Input Class Initialized
INFO - 2017-01-11 08:38:16 --> Language Class Initialized
INFO - 2017-01-11 08:38:16 --> Loader Class Initialized
INFO - 2017-01-11 08:38:16 --> Helper loaded: url_helper
INFO - 2017-01-11 08:38:16 --> Helper loaded: language_helper
INFO - 2017-01-11 08:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:38:16 --> Controller Class Initialized
INFO - 2017-01-11 08:38:17 --> Database Driver Class Initialized
INFO - 2017-01-11 08:38:17 --> Model Class Initialized
INFO - 2017-01-11 08:38:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:38:17 --> Helper loaded: form_helper
INFO - 2017-01-11 08:38:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:38:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:38:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:38:17 --> Final output sent to browser
DEBUG - 2017-01-11 08:38:17 --> Total execution time: 0.0900
INFO - 2017-01-11 08:38:19 --> Config Class Initialized
INFO - 2017-01-11 08:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:38:19 --> Utf8 Class Initialized
INFO - 2017-01-11 08:38:19 --> URI Class Initialized
INFO - 2017-01-11 08:38:19 --> Router Class Initialized
INFO - 2017-01-11 08:38:19 --> Output Class Initialized
INFO - 2017-01-11 08:38:19 --> Security Class Initialized
DEBUG - 2017-01-11 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:38:19 --> Input Class Initialized
INFO - 2017-01-11 08:38:19 --> Language Class Initialized
INFO - 2017-01-11 08:38:19 --> Loader Class Initialized
INFO - 2017-01-11 08:38:19 --> Helper loaded: url_helper
INFO - 2017-01-11 08:38:19 --> Helper loaded: language_helper
INFO - 2017-01-11 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:38:19 --> Controller Class Initialized
INFO - 2017-01-11 08:38:19 --> Database Driver Class Initialized
INFO - 2017-01-11 08:38:19 --> Model Class Initialized
INFO - 2017-01-11 08:38:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:38:19 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:38:23 --> Config Class Initialized
INFO - 2017-01-11 08:38:23 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:38:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:38:23 --> Utf8 Class Initialized
INFO - 2017-01-11 08:38:23 --> URI Class Initialized
INFO - 2017-01-11 08:38:23 --> Router Class Initialized
INFO - 2017-01-11 08:38:23 --> Output Class Initialized
INFO - 2017-01-11 08:38:23 --> Security Class Initialized
DEBUG - 2017-01-11 08:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:38:23 --> Input Class Initialized
INFO - 2017-01-11 08:38:23 --> Language Class Initialized
INFO - 2017-01-11 08:38:23 --> Loader Class Initialized
INFO - 2017-01-11 08:38:23 --> Helper loaded: url_helper
INFO - 2017-01-11 08:38:23 --> Helper loaded: language_helper
INFO - 2017-01-11 08:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:38:23 --> Controller Class Initialized
INFO - 2017-01-11 08:38:23 --> Database Driver Class Initialized
INFO - 2017-01-11 08:38:23 --> Model Class Initialized
INFO - 2017-01-11 08:38:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:38:23 --> Helper loaded: form_helper
INFO - 2017-01-11 08:38:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:38:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:38:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:38:23 --> Final output sent to browser
DEBUG - 2017-01-11 08:38:23 --> Total execution time: 0.0696
INFO - 2017-01-11 08:39:00 --> Config Class Initialized
INFO - 2017-01-11 08:39:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:39:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:39:00 --> Utf8 Class Initialized
INFO - 2017-01-11 08:39:00 --> URI Class Initialized
INFO - 2017-01-11 08:39:00 --> Router Class Initialized
INFO - 2017-01-11 08:39:00 --> Output Class Initialized
INFO - 2017-01-11 08:39:00 --> Security Class Initialized
DEBUG - 2017-01-11 08:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:39:00 --> Input Class Initialized
INFO - 2017-01-11 08:39:00 --> Language Class Initialized
INFO - 2017-01-11 08:39:00 --> Loader Class Initialized
INFO - 2017-01-11 08:39:00 --> Helper loaded: url_helper
INFO - 2017-01-11 08:39:00 --> Helper loaded: language_helper
INFO - 2017-01-11 08:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:39:00 --> Controller Class Initialized
INFO - 2017-01-11 08:39:00 --> Database Driver Class Initialized
INFO - 2017-01-11 08:39:00 --> Model Class Initialized
INFO - 2017-01-11 08:39:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:39:00 --> Helper loaded: form_helper
INFO - 2017-01-11 08:39:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:39:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:39:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:39:00 --> Final output sent to browser
DEBUG - 2017-01-11 08:39:00 --> Total execution time: 0.0684
INFO - 2017-01-11 08:41:11 --> Config Class Initialized
INFO - 2017-01-11 08:41:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:11 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:11 --> URI Class Initialized
DEBUG - 2017-01-11 08:41:11 --> No URI present. Default controller set.
INFO - 2017-01-11 08:41:11 --> Router Class Initialized
INFO - 2017-01-11 08:41:11 --> Output Class Initialized
INFO - 2017-01-11 08:41:11 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:11 --> Input Class Initialized
INFO - 2017-01-11 08:41:11 --> Language Class Initialized
INFO - 2017-01-11 08:41:11 --> Loader Class Initialized
INFO - 2017-01-11 08:41:11 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:11 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:11 --> Controller Class Initialized
INFO - 2017-01-11 08:41:11 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:11 --> Model Class Initialized
INFO - 2017-01-11 08:41:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 08:41:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 08:41:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 08:41:11 --> Final output sent to browser
DEBUG - 2017-01-11 08:41:11 --> Total execution time: 0.0543
INFO - 2017-01-11 08:41:16 --> Config Class Initialized
INFO - 2017-01-11 08:41:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:16 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:16 --> URI Class Initialized
INFO - 2017-01-11 08:41:16 --> Router Class Initialized
INFO - 2017-01-11 08:41:16 --> Output Class Initialized
INFO - 2017-01-11 08:41:16 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:16 --> Input Class Initialized
INFO - 2017-01-11 08:41:16 --> Language Class Initialized
INFO - 2017-01-11 08:41:16 --> Loader Class Initialized
INFO - 2017-01-11 08:41:16 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:16 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:16 --> Controller Class Initialized
INFO - 2017-01-11 08:41:16 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:16 --> Model Class Initialized
INFO - 2017-01-11 08:41:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:16 --> Config Class Initialized
INFO - 2017-01-11 08:41:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:16 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:16 --> URI Class Initialized
INFO - 2017-01-11 08:41:16 --> Router Class Initialized
INFO - 2017-01-11 08:41:16 --> Output Class Initialized
INFO - 2017-01-11 08:41:16 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:16 --> Input Class Initialized
INFO - 2017-01-11 08:41:16 --> Language Class Initialized
INFO - 2017-01-11 08:41:16 --> Loader Class Initialized
INFO - 2017-01-11 08:41:16 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:16 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:16 --> Controller Class Initialized
INFO - 2017-01-11 08:41:16 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:16 --> Model Class Initialized
INFO - 2017-01-11 08:41:16 --> Model Class Initialized
INFO - 2017-01-11 08:41:16 --> Model Class Initialized
INFO - 2017-01-11 08:41:16 --> Model Class Initialized
INFO - 2017-01-11 08:41:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:41:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 08:41:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:41:16 --> Final output sent to browser
DEBUG - 2017-01-11 08:41:16 --> Total execution time: 0.0739
INFO - 2017-01-11 08:41:18 --> Config Class Initialized
INFO - 2017-01-11 08:41:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:18 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:18 --> URI Class Initialized
INFO - 2017-01-11 08:41:18 --> Router Class Initialized
INFO - 2017-01-11 08:41:18 --> Output Class Initialized
INFO - 2017-01-11 08:41:18 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:18 --> Input Class Initialized
INFO - 2017-01-11 08:41:18 --> Language Class Initialized
INFO - 2017-01-11 08:41:18 --> Loader Class Initialized
INFO - 2017-01-11 08:41:18 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:18 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:18 --> Controller Class Initialized
INFO - 2017-01-11 08:41:18 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:18 --> Model Class Initialized
INFO - 2017-01-11 08:41:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:18 --> Helper loaded: form_helper
INFO - 2017-01-11 08:41:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:41:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:41:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:41:18 --> Final output sent to browser
DEBUG - 2017-01-11 08:41:18 --> Total execution time: 0.0767
INFO - 2017-01-11 08:41:20 --> Config Class Initialized
INFO - 2017-01-11 08:41:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:20 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:20 --> URI Class Initialized
INFO - 2017-01-11 08:41:20 --> Router Class Initialized
INFO - 2017-01-11 08:41:20 --> Output Class Initialized
INFO - 2017-01-11 08:41:20 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:20 --> Input Class Initialized
INFO - 2017-01-11 08:41:20 --> Language Class Initialized
INFO - 2017-01-11 08:41:20 --> Loader Class Initialized
INFO - 2017-01-11 08:41:20 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:20 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:20 --> Controller Class Initialized
INFO - 2017-01-11 08:41:20 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:20 --> Model Class Initialized
INFO - 2017-01-11 08:41:20 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:41:20 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:41:42 --> Config Class Initialized
INFO - 2017-01-11 08:41:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:42 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:42 --> URI Class Initialized
DEBUG - 2017-01-11 08:41:42 --> No URI present. Default controller set.
INFO - 2017-01-11 08:41:42 --> Router Class Initialized
INFO - 2017-01-11 08:41:42 --> Output Class Initialized
INFO - 2017-01-11 08:41:42 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:42 --> Input Class Initialized
INFO - 2017-01-11 08:41:42 --> Language Class Initialized
INFO - 2017-01-11 08:41:42 --> Loader Class Initialized
INFO - 2017-01-11 08:41:42 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:42 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:42 --> Controller Class Initialized
INFO - 2017-01-11 08:41:42 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:42 --> Model Class Initialized
INFO - 2017-01-11 08:41:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 08:41:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 08:41:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 08:41:42 --> Final output sent to browser
DEBUG - 2017-01-11 08:41:42 --> Total execution time: 0.0542
INFO - 2017-01-11 08:41:47 --> Config Class Initialized
INFO - 2017-01-11 08:41:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:47 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:47 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:47 --> URI Class Initialized
INFO - 2017-01-11 08:41:47 --> Router Class Initialized
INFO - 2017-01-11 08:41:47 --> Output Class Initialized
INFO - 2017-01-11 08:41:47 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:47 --> Input Class Initialized
INFO - 2017-01-11 08:41:47 --> Language Class Initialized
INFO - 2017-01-11 08:41:47 --> Loader Class Initialized
INFO - 2017-01-11 08:41:47 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:47 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:47 --> Controller Class Initialized
INFO - 2017-01-11 08:41:47 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:47 --> Model Class Initialized
INFO - 2017-01-11 08:41:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:47 --> Config Class Initialized
INFO - 2017-01-11 08:41:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:47 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:47 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:47 --> URI Class Initialized
INFO - 2017-01-11 08:41:47 --> Router Class Initialized
INFO - 2017-01-11 08:41:47 --> Output Class Initialized
INFO - 2017-01-11 08:41:47 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:47 --> Input Class Initialized
INFO - 2017-01-11 08:41:47 --> Language Class Initialized
INFO - 2017-01-11 08:41:47 --> Loader Class Initialized
INFO - 2017-01-11 08:41:47 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:47 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:47 --> Controller Class Initialized
INFO - 2017-01-11 08:41:47 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:47 --> Model Class Initialized
INFO - 2017-01-11 08:41:47 --> Model Class Initialized
INFO - 2017-01-11 08:41:47 --> Model Class Initialized
INFO - 2017-01-11 08:41:47 --> Model Class Initialized
INFO - 2017-01-11 08:41:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 08:41:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:41:47 --> Final output sent to browser
DEBUG - 2017-01-11 08:41:47 --> Total execution time: 0.0709
INFO - 2017-01-11 08:41:51 --> Config Class Initialized
INFO - 2017-01-11 08:41:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:51 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:51 --> URI Class Initialized
INFO - 2017-01-11 08:41:51 --> Router Class Initialized
INFO - 2017-01-11 08:41:51 --> Output Class Initialized
INFO - 2017-01-11 08:41:51 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:51 --> Input Class Initialized
INFO - 2017-01-11 08:41:51 --> Language Class Initialized
INFO - 2017-01-11 08:41:51 --> Loader Class Initialized
INFO - 2017-01-11 08:41:51 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:51 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:51 --> Controller Class Initialized
INFO - 2017-01-11 08:41:51 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:51 --> Model Class Initialized
INFO - 2017-01-11 08:41:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:41:51 --> Helper loaded: form_helper
INFO - 2017-01-11 08:41:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:41:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:41:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:41:51 --> Final output sent to browser
DEBUG - 2017-01-11 08:41:51 --> Total execution time: 0.0663
INFO - 2017-01-11 08:41:57 --> Config Class Initialized
INFO - 2017-01-11 08:41:57 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:41:57 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:41:57 --> Utf8 Class Initialized
INFO - 2017-01-11 08:41:57 --> URI Class Initialized
INFO - 2017-01-11 08:41:57 --> Router Class Initialized
INFO - 2017-01-11 08:41:57 --> Output Class Initialized
INFO - 2017-01-11 08:41:57 --> Security Class Initialized
DEBUG - 2017-01-11 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:41:57 --> Input Class Initialized
INFO - 2017-01-11 08:41:57 --> Language Class Initialized
INFO - 2017-01-11 08:41:57 --> Loader Class Initialized
INFO - 2017-01-11 08:41:57 --> Helper loaded: url_helper
INFO - 2017-01-11 08:41:57 --> Helper loaded: language_helper
INFO - 2017-01-11 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:41:57 --> Controller Class Initialized
INFO - 2017-01-11 08:41:57 --> Database Driver Class Initialized
INFO - 2017-01-11 08:41:57 --> Model Class Initialized
INFO - 2017-01-11 08:41:57 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:41:57 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:42:25 --> Config Class Initialized
INFO - 2017-01-11 08:42:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:42:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:42:25 --> Utf8 Class Initialized
INFO - 2017-01-11 08:42:25 --> URI Class Initialized
INFO - 2017-01-11 08:42:25 --> Router Class Initialized
INFO - 2017-01-11 08:42:25 --> Output Class Initialized
INFO - 2017-01-11 08:42:25 --> Security Class Initialized
DEBUG - 2017-01-11 08:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:42:25 --> Input Class Initialized
INFO - 2017-01-11 08:42:25 --> Language Class Initialized
INFO - 2017-01-11 08:42:25 --> Loader Class Initialized
INFO - 2017-01-11 08:42:25 --> Helper loaded: url_helper
INFO - 2017-01-11 08:42:25 --> Helper loaded: language_helper
INFO - 2017-01-11 08:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:42:25 --> Controller Class Initialized
INFO - 2017-01-11 08:42:25 --> Database Driver Class Initialized
INFO - 2017-01-11 08:42:25 --> Model Class Initialized
INFO - 2017-01-11 08:42:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:42:25 --> Helper loaded: form_helper
INFO - 2017-01-11 08:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:42:25 --> Final output sent to browser
DEBUG - 2017-01-11 08:42:25 --> Total execution time: 0.0694
INFO - 2017-01-11 08:42:27 --> Config Class Initialized
INFO - 2017-01-11 08:42:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:42:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:42:27 --> Utf8 Class Initialized
INFO - 2017-01-11 08:42:27 --> URI Class Initialized
INFO - 2017-01-11 08:42:27 --> Router Class Initialized
INFO - 2017-01-11 08:42:27 --> Output Class Initialized
INFO - 2017-01-11 08:42:27 --> Security Class Initialized
DEBUG - 2017-01-11 08:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:42:27 --> Input Class Initialized
INFO - 2017-01-11 08:42:27 --> Language Class Initialized
INFO - 2017-01-11 08:42:27 --> Loader Class Initialized
INFO - 2017-01-11 08:42:27 --> Helper loaded: url_helper
INFO - 2017-01-11 08:42:27 --> Helper loaded: language_helper
INFO - 2017-01-11 08:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:42:27 --> Controller Class Initialized
INFO - 2017-01-11 08:42:27 --> Database Driver Class Initialized
INFO - 2017-01-11 08:42:27 --> Model Class Initialized
INFO - 2017-01-11 08:42:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:42:27 --> Helper loaded: form_helper
INFO - 2017-01-11 08:42:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:42:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:42:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:42:27 --> Final output sent to browser
DEBUG - 2017-01-11 08:42:27 --> Total execution time: 0.0825
INFO - 2017-01-11 08:42:37 --> Config Class Initialized
INFO - 2017-01-11 08:42:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:42:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:42:37 --> Utf8 Class Initialized
INFO - 2017-01-11 08:42:37 --> URI Class Initialized
DEBUG - 2017-01-11 08:42:37 --> No URI present. Default controller set.
INFO - 2017-01-11 08:42:37 --> Router Class Initialized
INFO - 2017-01-11 08:42:37 --> Output Class Initialized
INFO - 2017-01-11 08:42:37 --> Security Class Initialized
DEBUG - 2017-01-11 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:42:37 --> Input Class Initialized
INFO - 2017-01-11 08:42:37 --> Language Class Initialized
INFO - 2017-01-11 08:42:37 --> Loader Class Initialized
INFO - 2017-01-11 08:42:37 --> Helper loaded: url_helper
INFO - 2017-01-11 08:42:37 --> Helper loaded: language_helper
INFO - 2017-01-11 08:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:42:37 --> Controller Class Initialized
INFO - 2017-01-11 08:42:37 --> Database Driver Class Initialized
INFO - 2017-01-11 08:42:37 --> Model Class Initialized
INFO - 2017-01-11 08:42:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:42:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 08:42:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 08:42:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 08:42:37 --> Final output sent to browser
DEBUG - 2017-01-11 08:42:37 --> Total execution time: 0.0548
INFO - 2017-01-11 08:42:43 --> Config Class Initialized
INFO - 2017-01-11 08:42:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:42:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:42:43 --> Utf8 Class Initialized
INFO - 2017-01-11 08:42:43 --> URI Class Initialized
INFO - 2017-01-11 08:42:43 --> Router Class Initialized
INFO - 2017-01-11 08:42:43 --> Output Class Initialized
INFO - 2017-01-11 08:42:43 --> Security Class Initialized
DEBUG - 2017-01-11 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:42:43 --> Input Class Initialized
INFO - 2017-01-11 08:42:43 --> Language Class Initialized
INFO - 2017-01-11 08:42:43 --> Loader Class Initialized
INFO - 2017-01-11 08:42:43 --> Helper loaded: url_helper
INFO - 2017-01-11 08:42:43 --> Helper loaded: language_helper
INFO - 2017-01-11 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:42:43 --> Controller Class Initialized
INFO - 2017-01-11 08:42:43 --> Database Driver Class Initialized
INFO - 2017-01-11 08:42:43 --> Model Class Initialized
INFO - 2017-01-11 08:42:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:42:43 --> Config Class Initialized
INFO - 2017-01-11 08:42:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:42:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:42:43 --> Utf8 Class Initialized
INFO - 2017-01-11 08:42:43 --> URI Class Initialized
INFO - 2017-01-11 08:42:43 --> Router Class Initialized
INFO - 2017-01-11 08:42:43 --> Output Class Initialized
INFO - 2017-01-11 08:42:43 --> Security Class Initialized
DEBUG - 2017-01-11 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:42:43 --> Input Class Initialized
INFO - 2017-01-11 08:42:43 --> Language Class Initialized
INFO - 2017-01-11 08:42:43 --> Loader Class Initialized
INFO - 2017-01-11 08:42:43 --> Helper loaded: url_helper
INFO - 2017-01-11 08:42:43 --> Helper loaded: language_helper
INFO - 2017-01-11 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:42:43 --> Controller Class Initialized
INFO - 2017-01-11 08:42:43 --> Database Driver Class Initialized
INFO - 2017-01-11 08:42:43 --> Model Class Initialized
INFO - 2017-01-11 08:42:43 --> Model Class Initialized
INFO - 2017-01-11 08:42:43 --> Model Class Initialized
INFO - 2017-01-11 08:42:43 --> Model Class Initialized
INFO - 2017-01-11 08:42:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:42:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:42:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 08:42:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:42:43 --> Final output sent to browser
DEBUG - 2017-01-11 08:42:43 --> Total execution time: 0.0656
INFO - 2017-01-11 08:46:33 --> Config Class Initialized
INFO - 2017-01-11 08:46:33 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:46:33 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:46:33 --> Utf8 Class Initialized
INFO - 2017-01-11 08:46:33 --> URI Class Initialized
INFO - 2017-01-11 08:46:33 --> Router Class Initialized
INFO - 2017-01-11 08:46:33 --> Output Class Initialized
INFO - 2017-01-11 08:46:33 --> Security Class Initialized
DEBUG - 2017-01-11 08:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:46:33 --> Input Class Initialized
INFO - 2017-01-11 08:46:33 --> Language Class Initialized
INFO - 2017-01-11 08:46:33 --> Loader Class Initialized
INFO - 2017-01-11 08:46:33 --> Helper loaded: url_helper
INFO - 2017-01-11 08:46:33 --> Helper loaded: language_helper
INFO - 2017-01-11 08:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:46:33 --> Controller Class Initialized
INFO - 2017-01-11 08:46:33 --> Database Driver Class Initialized
INFO - 2017-01-11 08:46:33 --> Model Class Initialized
INFO - 2017-01-11 08:46:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:46:33 --> Helper loaded: form_helper
INFO - 2017-01-11 08:46:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:46:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:46:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:46:33 --> Final output sent to browser
DEBUG - 2017-01-11 08:46:33 --> Total execution time: 0.0648
INFO - 2017-01-11 08:46:37 --> Config Class Initialized
INFO - 2017-01-11 08:46:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:46:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:46:37 --> Utf8 Class Initialized
INFO - 2017-01-11 08:46:37 --> URI Class Initialized
INFO - 2017-01-11 08:46:37 --> Router Class Initialized
INFO - 2017-01-11 08:46:37 --> Output Class Initialized
INFO - 2017-01-11 08:46:37 --> Security Class Initialized
DEBUG - 2017-01-11 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:46:37 --> Input Class Initialized
INFO - 2017-01-11 08:46:37 --> Language Class Initialized
INFO - 2017-01-11 08:46:37 --> Loader Class Initialized
INFO - 2017-01-11 08:46:37 --> Helper loaded: url_helper
INFO - 2017-01-11 08:46:37 --> Helper loaded: language_helper
INFO - 2017-01-11 08:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:46:37 --> Controller Class Initialized
INFO - 2017-01-11 08:46:37 --> Database Driver Class Initialized
INFO - 2017-01-11 08:46:37 --> Model Class Initialized
INFO - 2017-01-11 08:46:37 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:46:37 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:48:19 --> Config Class Initialized
INFO - 2017-01-11 08:48:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:48:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:48:19 --> Utf8 Class Initialized
INFO - 2017-01-11 08:48:19 --> URI Class Initialized
INFO - 2017-01-11 08:48:19 --> Router Class Initialized
INFO - 2017-01-11 08:48:19 --> Output Class Initialized
INFO - 2017-01-11 08:48:19 --> Security Class Initialized
DEBUG - 2017-01-11 08:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:48:19 --> Input Class Initialized
INFO - 2017-01-11 08:48:19 --> Language Class Initialized
INFO - 2017-01-11 08:48:19 --> Loader Class Initialized
INFO - 2017-01-11 08:48:19 --> Helper loaded: url_helper
INFO - 2017-01-11 08:48:19 --> Helper loaded: language_helper
INFO - 2017-01-11 08:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:48:19 --> Controller Class Initialized
INFO - 2017-01-11 08:48:19 --> Database Driver Class Initialized
INFO - 2017-01-11 08:48:19 --> Model Class Initialized
INFO - 2017-01-11 08:48:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:48:19 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:49:48 --> Config Class Initialized
INFO - 2017-01-11 08:49:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:49:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:49:48 --> Utf8 Class Initialized
INFO - 2017-01-11 08:49:48 --> URI Class Initialized
INFO - 2017-01-11 08:49:48 --> Router Class Initialized
INFO - 2017-01-11 08:49:48 --> Output Class Initialized
INFO - 2017-01-11 08:49:48 --> Security Class Initialized
DEBUG - 2017-01-11 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:49:48 --> Input Class Initialized
INFO - 2017-01-11 08:49:48 --> Language Class Initialized
INFO - 2017-01-11 08:49:48 --> Loader Class Initialized
INFO - 2017-01-11 08:49:48 --> Helper loaded: url_helper
INFO - 2017-01-11 08:49:48 --> Helper loaded: language_helper
INFO - 2017-01-11 08:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:49:48 --> Controller Class Initialized
INFO - 2017-01-11 08:49:48 --> Database Driver Class Initialized
INFO - 2017-01-11 08:49:48 --> Model Class Initialized
INFO - 2017-01-11 08:49:48 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:49:48 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:49:49 --> Config Class Initialized
INFO - 2017-01-11 08:49:49 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:49:49 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:49:49 --> Utf8 Class Initialized
INFO - 2017-01-11 08:49:49 --> URI Class Initialized
INFO - 2017-01-11 08:49:49 --> Router Class Initialized
INFO - 2017-01-11 08:49:49 --> Output Class Initialized
INFO - 2017-01-11 08:49:49 --> Security Class Initialized
DEBUG - 2017-01-11 08:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:49:49 --> Input Class Initialized
INFO - 2017-01-11 08:49:49 --> Language Class Initialized
INFO - 2017-01-11 08:49:49 --> Loader Class Initialized
INFO - 2017-01-11 08:49:49 --> Helper loaded: url_helper
INFO - 2017-01-11 08:49:49 --> Helper loaded: language_helper
INFO - 2017-01-11 08:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:49:49 --> Controller Class Initialized
INFO - 2017-01-11 08:49:49 --> Database Driver Class Initialized
INFO - 2017-01-11 08:49:49 --> Model Class Initialized
INFO - 2017-01-11 08:49:49 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:49:50 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:50:01 --> Config Class Initialized
INFO - 2017-01-11 08:50:01 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:50:01 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:50:01 --> Utf8 Class Initialized
INFO - 2017-01-11 08:50:01 --> URI Class Initialized
INFO - 2017-01-11 08:50:01 --> Router Class Initialized
INFO - 2017-01-11 08:50:01 --> Output Class Initialized
INFO - 2017-01-11 08:50:01 --> Security Class Initialized
DEBUG - 2017-01-11 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:50:01 --> Input Class Initialized
INFO - 2017-01-11 08:50:01 --> Language Class Initialized
INFO - 2017-01-11 08:50:01 --> Loader Class Initialized
INFO - 2017-01-11 08:50:01 --> Helper loaded: url_helper
INFO - 2017-01-11 08:50:01 --> Helper loaded: language_helper
INFO - 2017-01-11 08:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:50:01 --> Controller Class Initialized
INFO - 2017-01-11 08:50:01 --> Database Driver Class Initialized
INFO - 2017-01-11 08:50:01 --> Model Class Initialized
INFO - 2017-01-11 08:50:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:50:01 --> Helper loaded: form_helper
INFO - 2017-01-11 08:50:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:50:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-11 08:50:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:50:01 --> Final output sent to browser
DEBUG - 2017-01-11 08:50:01 --> Total execution time: 0.0615
INFO - 2017-01-11 08:50:03 --> Config Class Initialized
INFO - 2017-01-11 08:50:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:50:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:50:03 --> Utf8 Class Initialized
INFO - 2017-01-11 08:50:03 --> URI Class Initialized
INFO - 2017-01-11 08:50:03 --> Router Class Initialized
INFO - 2017-01-11 08:50:03 --> Output Class Initialized
INFO - 2017-01-11 08:50:03 --> Security Class Initialized
DEBUG - 2017-01-11 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:50:03 --> Input Class Initialized
INFO - 2017-01-11 08:50:03 --> Language Class Initialized
INFO - 2017-01-11 08:50:03 --> Loader Class Initialized
INFO - 2017-01-11 08:50:03 --> Helper loaded: url_helper
INFO - 2017-01-11 08:50:03 --> Helper loaded: language_helper
INFO - 2017-01-11 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:50:03 --> Controller Class Initialized
INFO - 2017-01-11 08:50:03 --> Database Driver Class Initialized
INFO - 2017-01-11 08:50:03 --> Model Class Initialized
INFO - 2017-01-11 08:50:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:50:03 --> Helper loaded: form_helper
INFO - 2017-01-11 08:50:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:50:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-11 08:50:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:50:03 --> Final output sent to browser
DEBUG - 2017-01-11 08:50:03 --> Total execution time: 0.0706
INFO - 2017-01-11 08:50:07 --> Config Class Initialized
INFO - 2017-01-11 08:50:07 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:50:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:50:07 --> Utf8 Class Initialized
INFO - 2017-01-11 08:50:07 --> URI Class Initialized
INFO - 2017-01-11 08:50:07 --> Router Class Initialized
INFO - 2017-01-11 08:50:07 --> Output Class Initialized
INFO - 2017-01-11 08:50:07 --> Security Class Initialized
DEBUG - 2017-01-11 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:50:07 --> Input Class Initialized
INFO - 2017-01-11 08:50:07 --> Language Class Initialized
INFO - 2017-01-11 08:50:07 --> Loader Class Initialized
INFO - 2017-01-11 08:50:07 --> Helper loaded: url_helper
INFO - 2017-01-11 08:50:07 --> Helper loaded: language_helper
INFO - 2017-01-11 08:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:50:07 --> Controller Class Initialized
INFO - 2017-01-11 08:50:07 --> Database Driver Class Initialized
INFO - 2017-01-11 08:50:07 --> Model Class Initialized
INFO - 2017-01-11 08:50:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:50:07 --> Helper loaded: form_helper
INFO - 2017-01-11 08:50:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:50:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:50:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:50:07 --> Final output sent to browser
DEBUG - 2017-01-11 08:50:07 --> Total execution time: 0.0648
INFO - 2017-01-11 08:50:10 --> Config Class Initialized
INFO - 2017-01-11 08:50:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:50:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:50:10 --> Utf8 Class Initialized
INFO - 2017-01-11 08:50:10 --> URI Class Initialized
INFO - 2017-01-11 08:50:10 --> Router Class Initialized
INFO - 2017-01-11 08:50:10 --> Output Class Initialized
INFO - 2017-01-11 08:50:10 --> Security Class Initialized
DEBUG - 2017-01-11 08:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:50:10 --> Input Class Initialized
INFO - 2017-01-11 08:50:10 --> Language Class Initialized
INFO - 2017-01-11 08:50:10 --> Loader Class Initialized
INFO - 2017-01-11 08:50:10 --> Helper loaded: url_helper
INFO - 2017-01-11 08:50:10 --> Helper loaded: language_helper
INFO - 2017-01-11 08:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:50:10 --> Controller Class Initialized
INFO - 2017-01-11 08:50:10 --> Database Driver Class Initialized
INFO - 2017-01-11 08:50:10 --> Model Class Initialized
INFO - 2017-01-11 08:50:10 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:50:10 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:53:37 --> Config Class Initialized
INFO - 2017-01-11 08:53:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:53:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:53:37 --> Utf8 Class Initialized
INFO - 2017-01-11 08:53:37 --> URI Class Initialized
INFO - 2017-01-11 08:53:37 --> Router Class Initialized
INFO - 2017-01-11 08:53:37 --> Output Class Initialized
INFO - 2017-01-11 08:53:37 --> Security Class Initialized
DEBUG - 2017-01-11 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:53:37 --> Input Class Initialized
INFO - 2017-01-11 08:53:37 --> Language Class Initialized
INFO - 2017-01-11 08:53:37 --> Loader Class Initialized
INFO - 2017-01-11 08:53:37 --> Helper loaded: url_helper
INFO - 2017-01-11 08:53:37 --> Helper loaded: language_helper
INFO - 2017-01-11 08:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:53:37 --> Controller Class Initialized
INFO - 2017-01-11 08:53:37 --> Database Driver Class Initialized
INFO - 2017-01-11 08:53:37 --> Model Class Initialized
INFO - 2017-01-11 08:53:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:53:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-11 08:53:37 --> Final output sent to browser
DEBUG - 2017-01-11 08:53:37 --> Total execution time: 0.2126
INFO - 2017-01-11 08:54:34 --> Config Class Initialized
INFO - 2017-01-11 08:54:34 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:54:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:54:34 --> Utf8 Class Initialized
INFO - 2017-01-11 08:54:34 --> URI Class Initialized
INFO - 2017-01-11 08:54:34 --> Router Class Initialized
INFO - 2017-01-11 08:54:34 --> Output Class Initialized
INFO - 2017-01-11 08:54:34 --> Security Class Initialized
DEBUG - 2017-01-11 08:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:54:34 --> Input Class Initialized
INFO - 2017-01-11 08:54:34 --> Language Class Initialized
INFO - 2017-01-11 08:54:34 --> Loader Class Initialized
INFO - 2017-01-11 08:54:34 --> Helper loaded: url_helper
INFO - 2017-01-11 08:54:34 --> Helper loaded: language_helper
INFO - 2017-01-11 08:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:54:34 --> Controller Class Initialized
INFO - 2017-01-11 08:54:34 --> Database Driver Class Initialized
INFO - 2017-01-11 08:54:34 --> Model Class Initialized
INFO - 2017-01-11 08:54:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:54:34 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:54:35 --> Config Class Initialized
INFO - 2017-01-11 08:54:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:54:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:54:35 --> Utf8 Class Initialized
INFO - 2017-01-11 08:54:35 --> URI Class Initialized
INFO - 2017-01-11 08:54:35 --> Router Class Initialized
INFO - 2017-01-11 08:54:35 --> Output Class Initialized
INFO - 2017-01-11 08:54:35 --> Security Class Initialized
DEBUG - 2017-01-11 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:54:35 --> Input Class Initialized
INFO - 2017-01-11 08:54:35 --> Language Class Initialized
INFO - 2017-01-11 08:54:35 --> Loader Class Initialized
INFO - 2017-01-11 08:54:35 --> Helper loaded: url_helper
INFO - 2017-01-11 08:54:35 --> Helper loaded: language_helper
INFO - 2017-01-11 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:54:35 --> Controller Class Initialized
INFO - 2017-01-11 08:54:35 --> Database Driver Class Initialized
INFO - 2017-01-11 08:54:35 --> Model Class Initialized
INFO - 2017-01-11 08:54:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 08:54:35 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\Calculation\Functions.php 581
INFO - 2017-01-11 08:57:40 --> Config Class Initialized
INFO - 2017-01-11 08:57:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:57:40 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:57:40 --> Utf8 Class Initialized
INFO - 2017-01-11 08:57:40 --> URI Class Initialized
INFO - 2017-01-11 08:57:40 --> Router Class Initialized
INFO - 2017-01-11 08:57:40 --> Output Class Initialized
INFO - 2017-01-11 08:57:40 --> Security Class Initialized
DEBUG - 2017-01-11 08:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:57:40 --> Input Class Initialized
INFO - 2017-01-11 08:57:40 --> Language Class Initialized
INFO - 2017-01-11 08:57:40 --> Loader Class Initialized
INFO - 2017-01-11 08:57:40 --> Helper loaded: url_helper
INFO - 2017-01-11 08:57:40 --> Helper loaded: language_helper
INFO - 2017-01-11 08:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:57:40 --> Controller Class Initialized
INFO - 2017-01-11 08:57:40 --> Database Driver Class Initialized
INFO - 2017-01-11 08:57:40 --> Model Class Initialized
INFO - 2017-01-11 08:57:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:57:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-11 08:57:40 --> Final output sent to browser
DEBUG - 2017-01-11 08:57:40 --> Total execution time: 0.1871
INFO - 2017-01-11 08:57:46 --> Config Class Initialized
INFO - 2017-01-11 08:57:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:57:46 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:57:46 --> Utf8 Class Initialized
INFO - 2017-01-11 08:57:46 --> URI Class Initialized
INFO - 2017-01-11 08:57:46 --> Router Class Initialized
INFO - 2017-01-11 08:57:46 --> Output Class Initialized
INFO - 2017-01-11 08:57:46 --> Security Class Initialized
DEBUG - 2017-01-11 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:57:46 --> Input Class Initialized
INFO - 2017-01-11 08:57:46 --> Language Class Initialized
INFO - 2017-01-11 08:57:46 --> Loader Class Initialized
INFO - 2017-01-11 08:57:46 --> Helper loaded: url_helper
INFO - 2017-01-11 08:57:46 --> Helper loaded: language_helper
INFO - 2017-01-11 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:57:46 --> Controller Class Initialized
INFO - 2017-01-11 08:57:46 --> Database Driver Class Initialized
INFO - 2017-01-11 08:57:46 --> Model Class Initialized
INFO - 2017-01-11 08:57:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:57:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-11 08:57:46 --> Final output sent to browser
DEBUG - 2017-01-11 08:57:46 --> Total execution time: 0.1776
INFO - 2017-01-11 08:57:50 --> Config Class Initialized
INFO - 2017-01-11 08:57:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:57:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:57:50 --> Utf8 Class Initialized
INFO - 2017-01-11 08:57:50 --> URI Class Initialized
DEBUG - 2017-01-11 08:57:50 --> No URI present. Default controller set.
INFO - 2017-01-11 08:57:50 --> Router Class Initialized
INFO - 2017-01-11 08:57:50 --> Output Class Initialized
INFO - 2017-01-11 08:57:50 --> Security Class Initialized
DEBUG - 2017-01-11 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:57:50 --> Input Class Initialized
INFO - 2017-01-11 08:57:50 --> Language Class Initialized
INFO - 2017-01-11 08:57:50 --> Loader Class Initialized
INFO - 2017-01-11 08:57:50 --> Helper loaded: url_helper
INFO - 2017-01-11 08:57:50 --> Helper loaded: language_helper
INFO - 2017-01-11 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:57:50 --> Controller Class Initialized
INFO - 2017-01-11 08:57:50 --> Database Driver Class Initialized
INFO - 2017-01-11 08:57:50 --> Model Class Initialized
INFO - 2017-01-11 08:57:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:57:51 --> Config Class Initialized
INFO - 2017-01-11 08:57:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:57:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:57:51 --> Utf8 Class Initialized
INFO - 2017-01-11 08:57:51 --> URI Class Initialized
INFO - 2017-01-11 08:57:51 --> Router Class Initialized
INFO - 2017-01-11 08:57:51 --> Output Class Initialized
INFO - 2017-01-11 08:57:51 --> Security Class Initialized
DEBUG - 2017-01-11 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:57:51 --> Input Class Initialized
INFO - 2017-01-11 08:57:51 --> Language Class Initialized
INFO - 2017-01-11 08:57:51 --> Loader Class Initialized
INFO - 2017-01-11 08:57:51 --> Helper loaded: url_helper
INFO - 2017-01-11 08:57:51 --> Helper loaded: language_helper
INFO - 2017-01-11 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:57:51 --> Controller Class Initialized
INFO - 2017-01-11 08:57:51 --> Database Driver Class Initialized
INFO - 2017-01-11 08:57:51 --> Model Class Initialized
INFO - 2017-01-11 08:57:51 --> Model Class Initialized
INFO - 2017-01-11 08:57:51 --> Model Class Initialized
INFO - 2017-01-11 08:57:51 --> Model Class Initialized
INFO - 2017-01-11 08:57:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 08:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:57:51 --> Final output sent to browser
DEBUG - 2017-01-11 08:57:51 --> Total execution time: 0.0616
INFO - 2017-01-11 08:57:53 --> Config Class Initialized
INFO - 2017-01-11 08:57:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:57:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:57:53 --> Utf8 Class Initialized
INFO - 2017-01-11 08:57:53 --> URI Class Initialized
INFO - 2017-01-11 08:57:53 --> Router Class Initialized
INFO - 2017-01-11 08:57:53 --> Output Class Initialized
INFO - 2017-01-11 08:57:53 --> Security Class Initialized
DEBUG - 2017-01-11 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:57:53 --> Input Class Initialized
INFO - 2017-01-11 08:57:53 --> Language Class Initialized
INFO - 2017-01-11 08:57:53 --> Loader Class Initialized
INFO - 2017-01-11 08:57:53 --> Helper loaded: url_helper
INFO - 2017-01-11 08:57:53 --> Helper loaded: language_helper
INFO - 2017-01-11 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:57:53 --> Controller Class Initialized
INFO - 2017-01-11 08:57:53 --> Database Driver Class Initialized
INFO - 2017-01-11 08:57:53 --> Model Class Initialized
INFO - 2017-01-11 08:57:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:57:53 --> Helper loaded: form_helper
INFO - 2017-01-11 08:57:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:57:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-11 08:57:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:57:53 --> Final output sent to browser
DEBUG - 2017-01-11 08:57:53 --> Total execution time: 0.0583
INFO - 2017-01-11 08:57:54 --> Config Class Initialized
INFO - 2017-01-11 08:57:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:57:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:57:54 --> Utf8 Class Initialized
INFO - 2017-01-11 08:57:54 --> URI Class Initialized
INFO - 2017-01-11 08:57:54 --> Router Class Initialized
INFO - 2017-01-11 08:57:54 --> Output Class Initialized
INFO - 2017-01-11 08:57:54 --> Security Class Initialized
DEBUG - 2017-01-11 08:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:57:54 --> Input Class Initialized
INFO - 2017-01-11 08:57:54 --> Language Class Initialized
INFO - 2017-01-11 08:57:54 --> Loader Class Initialized
INFO - 2017-01-11 08:57:54 --> Helper loaded: url_helper
INFO - 2017-01-11 08:57:54 --> Helper loaded: language_helper
INFO - 2017-01-11 08:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:57:54 --> Controller Class Initialized
INFO - 2017-01-11 08:57:54 --> Database Driver Class Initialized
INFO - 2017-01-11 08:57:54 --> Model Class Initialized
INFO - 2017-01-11 08:57:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:57:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-11 08:57:54 --> Final output sent to browser
DEBUG - 2017-01-11 08:57:54 --> Total execution time: 0.1987
INFO - 2017-01-11 08:58:36 --> Config Class Initialized
INFO - 2017-01-11 08:58:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:58:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 08:58:36 --> Utf8 Class Initialized
INFO - 2017-01-11 08:58:36 --> URI Class Initialized
INFO - 2017-01-11 08:58:36 --> Router Class Initialized
INFO - 2017-01-11 08:58:36 --> Output Class Initialized
INFO - 2017-01-11 08:58:36 --> Security Class Initialized
DEBUG - 2017-01-11 08:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 08:58:36 --> Input Class Initialized
INFO - 2017-01-11 08:58:36 --> Language Class Initialized
INFO - 2017-01-11 08:58:36 --> Loader Class Initialized
INFO - 2017-01-11 08:58:36 --> Helper loaded: url_helper
INFO - 2017-01-11 08:58:36 --> Helper loaded: language_helper
INFO - 2017-01-11 08:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 08:58:36 --> Controller Class Initialized
INFO - 2017-01-11 08:58:36 --> Database Driver Class Initialized
INFO - 2017-01-11 08:58:36 --> Model Class Initialized
INFO - 2017-01-11 08:58:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 08:58:36 --> Model Class Initialized
INFO - 2017-01-11 08:58:36 --> Model Class Initialized
INFO - 2017-01-11 08:58:36 --> Helper loaded: form_helper
INFO - 2017-01-11 08:58:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 08:58:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-11 08:58:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 08:58:37 --> Final output sent to browser
DEBUG - 2017-01-11 08:58:37 --> Total execution time: 0.0934
INFO - 2017-01-11 11:52:17 --> Config Class Initialized
INFO - 2017-01-11 11:52:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:52:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:52:17 --> Utf8 Class Initialized
INFO - 2017-01-11 11:52:17 --> URI Class Initialized
INFO - 2017-01-11 11:52:17 --> Router Class Initialized
INFO - 2017-01-11 11:52:17 --> Output Class Initialized
INFO - 2017-01-11 11:52:17 --> Security Class Initialized
DEBUG - 2017-01-11 11:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:52:17 --> Input Class Initialized
INFO - 2017-01-11 11:52:17 --> Language Class Initialized
INFO - 2017-01-11 11:52:17 --> Loader Class Initialized
INFO - 2017-01-11 11:52:17 --> Helper loaded: url_helper
INFO - 2017-01-11 11:52:17 --> Helper loaded: language_helper
INFO - 2017-01-11 11:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:52:17 --> Controller Class Initialized
INFO - 2017-01-11 11:52:17 --> Database Driver Class Initialized
INFO - 2017-01-11 11:52:17 --> Model Class Initialized
INFO - 2017-01-11 11:52:17 --> Model Class Initialized
INFO - 2017-01-11 11:52:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:52:17 --> Config Class Initialized
INFO - 2017-01-11 11:52:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:52:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:52:17 --> Utf8 Class Initialized
INFO - 2017-01-11 11:52:17 --> URI Class Initialized
INFO - 2017-01-11 11:52:17 --> Router Class Initialized
INFO - 2017-01-11 11:52:17 --> Output Class Initialized
INFO - 2017-01-11 11:52:17 --> Security Class Initialized
DEBUG - 2017-01-11 11:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:52:17 --> Input Class Initialized
INFO - 2017-01-11 11:52:17 --> Language Class Initialized
INFO - 2017-01-11 11:52:17 --> Loader Class Initialized
INFO - 2017-01-11 11:52:17 --> Helper loaded: url_helper
INFO - 2017-01-11 11:52:17 --> Helper loaded: language_helper
INFO - 2017-01-11 11:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:52:17 --> Controller Class Initialized
INFO - 2017-01-11 11:52:17 --> Database Driver Class Initialized
INFO - 2017-01-11 11:52:17 --> Model Class Initialized
INFO - 2017-01-11 11:52:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 11:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 11:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 11:52:17 --> Final output sent to browser
DEBUG - 2017-01-11 11:52:17 --> Total execution time: 0.1414
INFO - 2017-01-11 11:52:26 --> Config Class Initialized
INFO - 2017-01-11 11:52:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:52:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:52:26 --> Utf8 Class Initialized
INFO - 2017-01-11 11:52:26 --> URI Class Initialized
INFO - 2017-01-11 11:52:26 --> Router Class Initialized
INFO - 2017-01-11 11:52:26 --> Output Class Initialized
INFO - 2017-01-11 11:52:26 --> Security Class Initialized
DEBUG - 2017-01-11 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:52:26 --> Input Class Initialized
INFO - 2017-01-11 11:52:26 --> Language Class Initialized
INFO - 2017-01-11 11:52:26 --> Loader Class Initialized
INFO - 2017-01-11 11:52:26 --> Helper loaded: url_helper
INFO - 2017-01-11 11:52:26 --> Helper loaded: language_helper
INFO - 2017-01-11 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:52:26 --> Controller Class Initialized
INFO - 2017-01-11 11:52:26 --> Database Driver Class Initialized
INFO - 2017-01-11 11:52:26 --> Model Class Initialized
INFO - 2017-01-11 11:52:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:52:26 --> Config Class Initialized
INFO - 2017-01-11 11:52:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:52:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:52:26 --> Utf8 Class Initialized
INFO - 2017-01-11 11:52:26 --> URI Class Initialized
INFO - 2017-01-11 11:52:26 --> Router Class Initialized
INFO - 2017-01-11 11:52:26 --> Output Class Initialized
INFO - 2017-01-11 11:52:26 --> Security Class Initialized
DEBUG - 2017-01-11 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:52:26 --> Input Class Initialized
INFO - 2017-01-11 11:52:26 --> Language Class Initialized
INFO - 2017-01-11 11:52:26 --> Loader Class Initialized
INFO - 2017-01-11 11:52:26 --> Helper loaded: url_helper
INFO - 2017-01-11 11:52:26 --> Helper loaded: language_helper
INFO - 2017-01-11 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:52:26 --> Controller Class Initialized
INFO - 2017-01-11 11:52:26 --> Database Driver Class Initialized
INFO - 2017-01-11 11:52:26 --> Model Class Initialized
INFO - 2017-01-11 11:52:26 --> Model Class Initialized
INFO - 2017-01-11 11:52:26 --> Model Class Initialized
INFO - 2017-01-11 11:52:26 --> Model Class Initialized
INFO - 2017-01-11 11:52:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:52:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 11:52:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 11:52:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 11:52:26 --> Final output sent to browser
DEBUG - 2017-01-11 11:52:26 --> Total execution time: 0.0894
INFO - 2017-01-11 11:54:16 --> Config Class Initialized
INFO - 2017-01-11 11:54:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:54:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:54:16 --> Utf8 Class Initialized
INFO - 2017-01-11 11:54:16 --> URI Class Initialized
INFO - 2017-01-11 11:54:16 --> Router Class Initialized
INFO - 2017-01-11 11:54:16 --> Output Class Initialized
INFO - 2017-01-11 11:54:16 --> Security Class Initialized
DEBUG - 2017-01-11 11:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:54:16 --> Input Class Initialized
INFO - 2017-01-11 11:54:16 --> Language Class Initialized
INFO - 2017-01-11 11:54:16 --> Loader Class Initialized
INFO - 2017-01-11 11:54:16 --> Helper loaded: url_helper
INFO - 2017-01-11 11:54:16 --> Helper loaded: language_helper
INFO - 2017-01-11 11:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:54:16 --> Controller Class Initialized
INFO - 2017-01-11 11:54:16 --> Database Driver Class Initialized
INFO - 2017-01-11 11:54:16 --> Model Class Initialized
INFO - 2017-01-11 11:54:16 --> Model Class Initialized
INFO - 2017-01-11 11:54:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 11:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 11:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 11:54:16 --> Final output sent to browser
DEBUG - 2017-01-11 11:54:16 --> Total execution time: 0.1015
INFO - 2017-01-11 11:56:02 --> Config Class Initialized
INFO - 2017-01-11 11:56:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:56:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:56:02 --> Utf8 Class Initialized
INFO - 2017-01-11 11:56:02 --> URI Class Initialized
INFO - 2017-01-11 11:56:02 --> Router Class Initialized
INFO - 2017-01-11 11:56:02 --> Output Class Initialized
INFO - 2017-01-11 11:56:02 --> Security Class Initialized
DEBUG - 2017-01-11 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:56:02 --> Input Class Initialized
INFO - 2017-01-11 11:56:02 --> Language Class Initialized
INFO - 2017-01-11 11:56:02 --> Loader Class Initialized
INFO - 2017-01-11 11:56:02 --> Helper loaded: url_helper
INFO - 2017-01-11 11:56:02 --> Helper loaded: language_helper
INFO - 2017-01-11 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:56:02 --> Controller Class Initialized
INFO - 2017-01-11 11:56:02 --> Database Driver Class Initialized
INFO - 2017-01-11 11:56:02 --> Model Class Initialized
INFO - 2017-01-11 11:56:02 --> Model Class Initialized
INFO - 2017-01-11 11:56:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:56:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:56:02 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
INFO - 2017-01-11 11:56:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 11:56:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 11:56:02 --> Final output sent to browser
DEBUG - 2017-01-11 11:56:02 --> Total execution time: 0.1211
INFO - 2017-01-11 11:58:04 --> Config Class Initialized
INFO - 2017-01-11 11:58:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:58:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:58:04 --> Utf8 Class Initialized
INFO - 2017-01-11 11:58:04 --> URI Class Initialized
INFO - 2017-01-11 11:58:04 --> Router Class Initialized
INFO - 2017-01-11 11:58:04 --> Output Class Initialized
INFO - 2017-01-11 11:58:04 --> Security Class Initialized
DEBUG - 2017-01-11 11:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:58:04 --> Input Class Initialized
INFO - 2017-01-11 11:58:04 --> Language Class Initialized
INFO - 2017-01-11 11:58:04 --> Loader Class Initialized
INFO - 2017-01-11 11:58:04 --> Helper loaded: url_helper
INFO - 2017-01-11 11:58:04 --> Helper loaded: language_helper
INFO - 2017-01-11 11:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:58:04 --> Controller Class Initialized
INFO - 2017-01-11 11:58:04 --> Database Driver Class Initialized
INFO - 2017-01-11 11:58:04 --> Model Class Initialized
INFO - 2017-01-11 11:58:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:58:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 11:58:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2017-01-11 11:58:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 11:58:04 --> Final output sent to browser
DEBUG - 2017-01-11 11:58:04 --> Total execution time: 0.0677
INFO - 2017-01-11 11:58:10 --> Config Class Initialized
INFO - 2017-01-11 11:58:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:58:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:58:10 --> Utf8 Class Initialized
INFO - 2017-01-11 11:58:10 --> URI Class Initialized
INFO - 2017-01-11 11:58:10 --> Router Class Initialized
INFO - 2017-01-11 11:58:10 --> Output Class Initialized
INFO - 2017-01-11 11:58:10 --> Security Class Initialized
DEBUG - 2017-01-11 11:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:58:10 --> Input Class Initialized
INFO - 2017-01-11 11:58:10 --> Language Class Initialized
INFO - 2017-01-11 11:58:10 --> Loader Class Initialized
INFO - 2017-01-11 11:58:10 --> Helper loaded: url_helper
INFO - 2017-01-11 11:58:10 --> Helper loaded: language_helper
INFO - 2017-01-11 11:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:58:10 --> Controller Class Initialized
INFO - 2017-01-11 11:58:10 --> Database Driver Class Initialized
INFO - 2017-01-11 11:58:10 --> Model Class Initialized
INFO - 2017-01-11 11:58:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:58:10 --> Final output sent to browser
DEBUG - 2017-01-11 11:58:10 --> Total execution time: 0.0871
INFO - 2017-01-11 11:58:13 --> Config Class Initialized
INFO - 2017-01-11 11:58:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:58:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:58:13 --> Utf8 Class Initialized
INFO - 2017-01-11 11:58:13 --> URI Class Initialized
INFO - 2017-01-11 11:58:13 --> Router Class Initialized
INFO - 2017-01-11 11:58:13 --> Output Class Initialized
INFO - 2017-01-11 11:58:13 --> Security Class Initialized
DEBUG - 2017-01-11 11:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:58:13 --> Input Class Initialized
INFO - 2017-01-11 11:58:13 --> Language Class Initialized
INFO - 2017-01-11 11:58:13 --> Loader Class Initialized
INFO - 2017-01-11 11:58:13 --> Helper loaded: url_helper
INFO - 2017-01-11 11:58:13 --> Helper loaded: language_helper
INFO - 2017-01-11 11:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:58:13 --> Controller Class Initialized
INFO - 2017-01-11 11:58:13 --> Database Driver Class Initialized
INFO - 2017-01-11 11:58:13 --> Model Class Initialized
INFO - 2017-01-11 11:58:13 --> Model Class Initialized
INFO - 2017-01-11 11:58:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:58:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
ERROR - 2017-01-11 11:58:13 --> Severity: Notice --> Undefined index: status C:\wamp64\www\savsoftquiz\application\views\quiz_list.php 58
INFO - 2017-01-11 11:58:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 11:58:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 11:58:13 --> Final output sent to browser
DEBUG - 2017-01-11 11:58:13 --> Total execution time: 0.0967
INFO - 2017-01-11 11:59:10 --> Config Class Initialized
INFO - 2017-01-11 11:59:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 11:59:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 11:59:10 --> Utf8 Class Initialized
INFO - 2017-01-11 11:59:10 --> URI Class Initialized
INFO - 2017-01-11 11:59:10 --> Router Class Initialized
INFO - 2017-01-11 11:59:10 --> Output Class Initialized
INFO - 2017-01-11 11:59:10 --> Security Class Initialized
DEBUG - 2017-01-11 11:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 11:59:10 --> Input Class Initialized
INFO - 2017-01-11 11:59:10 --> Language Class Initialized
INFO - 2017-01-11 11:59:10 --> Loader Class Initialized
INFO - 2017-01-11 11:59:10 --> Helper loaded: url_helper
INFO - 2017-01-11 11:59:10 --> Helper loaded: language_helper
INFO - 2017-01-11 11:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 11:59:10 --> Controller Class Initialized
INFO - 2017-01-11 11:59:10 --> Database Driver Class Initialized
INFO - 2017-01-11 11:59:10 --> Model Class Initialized
INFO - 2017-01-11 11:59:10 --> Model Class Initialized
INFO - 2017-01-11 11:59:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 11:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 11:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 11:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 11:59:10 --> Final output sent to browser
DEBUG - 2017-01-11 11:59:10 --> Total execution time: 0.0817
INFO - 2017-01-11 12:00:45 --> Config Class Initialized
INFO - 2017-01-11 12:00:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:00:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:00:45 --> Utf8 Class Initialized
INFO - 2017-01-11 12:00:45 --> URI Class Initialized
INFO - 2017-01-11 12:00:45 --> Router Class Initialized
INFO - 2017-01-11 12:00:45 --> Output Class Initialized
INFO - 2017-01-11 12:00:45 --> Security Class Initialized
DEBUG - 2017-01-11 12:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:00:45 --> Input Class Initialized
INFO - 2017-01-11 12:00:45 --> Language Class Initialized
INFO - 2017-01-11 12:00:45 --> Loader Class Initialized
INFO - 2017-01-11 12:00:45 --> Helper loaded: url_helper
INFO - 2017-01-11 12:00:45 --> Helper loaded: language_helper
INFO - 2017-01-11 12:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:00:45 --> Controller Class Initialized
INFO - 2017-01-11 12:00:45 --> Database Driver Class Initialized
INFO - 2017-01-11 12:00:45 --> Model Class Initialized
INFO - 2017-01-11 12:00:45 --> Model Class Initialized
INFO - 2017-01-11 12:00:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:00:45 --> Final output sent to browser
DEBUG - 2017-01-11 12:00:45 --> Total execution time: 0.0885
INFO - 2017-01-11 12:02:07 --> Config Class Initialized
INFO - 2017-01-11 12:02:07 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:02:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:02:07 --> Utf8 Class Initialized
INFO - 2017-01-11 12:02:07 --> URI Class Initialized
INFO - 2017-01-11 12:02:07 --> Router Class Initialized
INFO - 2017-01-11 12:02:07 --> Output Class Initialized
INFO - 2017-01-11 12:02:07 --> Security Class Initialized
DEBUG - 2017-01-11 12:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:02:07 --> Input Class Initialized
INFO - 2017-01-11 12:02:07 --> Language Class Initialized
INFO - 2017-01-11 12:02:07 --> Loader Class Initialized
INFO - 2017-01-11 12:02:07 --> Helper loaded: url_helper
INFO - 2017-01-11 12:02:07 --> Helper loaded: language_helper
INFO - 2017-01-11 12:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:02:07 --> Controller Class Initialized
INFO - 2017-01-11 12:02:07 --> Database Driver Class Initialized
INFO - 2017-01-11 12:02:07 --> Model Class Initialized
INFO - 2017-01-11 12:02:07 --> Model Class Initialized
INFO - 2017-01-11 12:02:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:02:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:02:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:02:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:02:07 --> Final output sent to browser
DEBUG - 2017-01-11 12:02:07 --> Total execution time: 0.0787
INFO - 2017-01-11 12:03:28 --> Config Class Initialized
INFO - 2017-01-11 12:03:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:03:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:03:28 --> Utf8 Class Initialized
INFO - 2017-01-11 12:03:28 --> URI Class Initialized
INFO - 2017-01-11 12:03:28 --> Router Class Initialized
INFO - 2017-01-11 12:03:28 --> Output Class Initialized
INFO - 2017-01-11 12:03:28 --> Security Class Initialized
DEBUG - 2017-01-11 12:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:03:28 --> Input Class Initialized
INFO - 2017-01-11 12:03:28 --> Language Class Initialized
INFO - 2017-01-11 12:03:28 --> Loader Class Initialized
INFO - 2017-01-11 12:03:28 --> Helper loaded: url_helper
INFO - 2017-01-11 12:03:28 --> Helper loaded: language_helper
INFO - 2017-01-11 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:03:28 --> Controller Class Initialized
INFO - 2017-01-11 12:03:28 --> Database Driver Class Initialized
INFO - 2017-01-11 12:03:28 --> Model Class Initialized
INFO - 2017-01-11 12:03:28 --> Model Class Initialized
INFO - 2017-01-11 12:03:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:03:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:03:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:03:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:03:28 --> Final output sent to browser
DEBUG - 2017-01-11 12:03:28 --> Total execution time: 0.0946
INFO - 2017-01-11 12:03:45 --> Config Class Initialized
INFO - 2017-01-11 12:03:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:03:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:03:45 --> Utf8 Class Initialized
INFO - 2017-01-11 12:03:45 --> URI Class Initialized
INFO - 2017-01-11 12:03:45 --> Router Class Initialized
INFO - 2017-01-11 12:03:45 --> Output Class Initialized
INFO - 2017-01-11 12:03:45 --> Security Class Initialized
DEBUG - 2017-01-11 12:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:03:45 --> Input Class Initialized
INFO - 2017-01-11 12:03:45 --> Language Class Initialized
INFO - 2017-01-11 12:03:45 --> Loader Class Initialized
INFO - 2017-01-11 12:03:45 --> Helper loaded: url_helper
INFO - 2017-01-11 12:03:45 --> Helper loaded: language_helper
INFO - 2017-01-11 12:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:03:45 --> Controller Class Initialized
INFO - 2017-01-11 12:03:45 --> Database Driver Class Initialized
INFO - 2017-01-11 12:03:45 --> Model Class Initialized
INFO - 2017-01-11 12:03:45 --> Model Class Initialized
INFO - 2017-01-11 12:03:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:03:45 --> Model Class Initialized
INFO - 2017-01-11 12:03:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:03:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:03:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:03:45 --> Final output sent to browser
DEBUG - 2017-01-11 12:03:45 --> Total execution time: 0.0820
INFO - 2017-01-11 12:04:52 --> Config Class Initialized
INFO - 2017-01-11 12:04:52 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:04:52 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:04:52 --> Utf8 Class Initialized
INFO - 2017-01-11 12:04:52 --> URI Class Initialized
INFO - 2017-01-11 12:04:52 --> Router Class Initialized
INFO - 2017-01-11 12:04:52 --> Output Class Initialized
INFO - 2017-01-11 12:04:52 --> Security Class Initialized
DEBUG - 2017-01-11 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:04:52 --> Input Class Initialized
INFO - 2017-01-11 12:04:52 --> Language Class Initialized
INFO - 2017-01-11 12:04:52 --> Loader Class Initialized
INFO - 2017-01-11 12:04:52 --> Helper loaded: url_helper
INFO - 2017-01-11 12:04:52 --> Helper loaded: language_helper
INFO - 2017-01-11 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:04:52 --> Controller Class Initialized
INFO - 2017-01-11 12:04:52 --> Database Driver Class Initialized
INFO - 2017-01-11 12:04:52 --> Model Class Initialized
INFO - 2017-01-11 12:04:52 --> Model Class Initialized
INFO - 2017-01-11 12:04:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:04:52 --> Model Class Initialized
INFO - 2017-01-11 12:04:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 12:04:52 --> Could not find the language line "quiz_status"
INFO - 2017-01-11 12:04:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:04:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:04:53 --> Final output sent to browser
DEBUG - 2017-01-11 12:04:53 --> Total execution time: 0.1283
INFO - 2017-01-11 12:07:53 --> Config Class Initialized
INFO - 2017-01-11 12:07:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:07:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:07:53 --> Utf8 Class Initialized
INFO - 2017-01-11 12:07:53 --> URI Class Initialized
INFO - 2017-01-11 12:07:53 --> Router Class Initialized
INFO - 2017-01-11 12:07:53 --> Output Class Initialized
INFO - 2017-01-11 12:07:53 --> Security Class Initialized
DEBUG - 2017-01-11 12:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:07:53 --> Input Class Initialized
INFO - 2017-01-11 12:07:53 --> Language Class Initialized
INFO - 2017-01-11 12:07:53 --> Loader Class Initialized
INFO - 2017-01-11 12:07:53 --> Helper loaded: url_helper
INFO - 2017-01-11 12:07:53 --> Helper loaded: language_helper
INFO - 2017-01-11 12:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:07:53 --> Controller Class Initialized
INFO - 2017-01-11 12:07:53 --> Database Driver Class Initialized
INFO - 2017-01-11 12:07:53 --> Model Class Initialized
INFO - 2017-01-11 12:07:53 --> Model Class Initialized
INFO - 2017-01-11 12:07:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:07:53 --> Model Class Initialized
INFO - 2017-01-11 12:07:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:07:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:07:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:07:53 --> Final output sent to browser
DEBUG - 2017-01-11 12:07:53 --> Total execution time: 0.1006
INFO - 2017-01-11 12:08:22 --> Config Class Initialized
INFO - 2017-01-11 12:08:22 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:08:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:08:22 --> Utf8 Class Initialized
INFO - 2017-01-11 12:08:22 --> URI Class Initialized
INFO - 2017-01-11 12:08:22 --> Router Class Initialized
INFO - 2017-01-11 12:08:22 --> Output Class Initialized
INFO - 2017-01-11 12:08:22 --> Security Class Initialized
DEBUG - 2017-01-11 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:08:22 --> Input Class Initialized
INFO - 2017-01-11 12:08:22 --> Language Class Initialized
INFO - 2017-01-11 12:08:22 --> Loader Class Initialized
INFO - 2017-01-11 12:08:22 --> Helper loaded: url_helper
INFO - 2017-01-11 12:08:22 --> Helper loaded: language_helper
INFO - 2017-01-11 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:08:22 --> Controller Class Initialized
INFO - 2017-01-11 12:08:22 --> Database Driver Class Initialized
INFO - 2017-01-11 12:08:22 --> Model Class Initialized
INFO - 2017-01-11 12:08:22 --> Model Class Initialized
INFO - 2017-01-11 12:08:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:08:22 --> Model Class Initialized
INFO - 2017-01-11 12:08:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:08:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:08:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:08:22 --> Final output sent to browser
DEBUG - 2017-01-11 12:08:22 --> Total execution time: 0.1033
INFO - 2017-01-11 12:08:34 --> Config Class Initialized
INFO - 2017-01-11 12:08:34 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:08:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:08:34 --> Utf8 Class Initialized
INFO - 2017-01-11 12:08:34 --> URI Class Initialized
INFO - 2017-01-11 12:08:34 --> Router Class Initialized
INFO - 2017-01-11 12:08:34 --> Output Class Initialized
INFO - 2017-01-11 12:08:34 --> Security Class Initialized
DEBUG - 2017-01-11 12:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:08:34 --> Input Class Initialized
INFO - 2017-01-11 12:08:34 --> Language Class Initialized
INFO - 2017-01-11 12:08:34 --> Loader Class Initialized
INFO - 2017-01-11 12:08:34 --> Helper loaded: url_helper
INFO - 2017-01-11 12:08:34 --> Helper loaded: language_helper
INFO - 2017-01-11 12:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:08:34 --> Controller Class Initialized
INFO - 2017-01-11 12:08:34 --> Database Driver Class Initialized
INFO - 2017-01-11 12:08:34 --> Model Class Initialized
INFO - 2017-01-11 12:08:34 --> Model Class Initialized
INFO - 2017-01-11 12:08:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:08:34 --> Model Class Initialized
INFO - 2017-01-11 12:08:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:08:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:08:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:08:34 --> Final output sent to browser
DEBUG - 2017-01-11 12:08:34 --> Total execution time: 0.1452
INFO - 2017-01-11 12:09:04 --> Config Class Initialized
INFO - 2017-01-11 12:09:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:09:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:09:04 --> Utf8 Class Initialized
INFO - 2017-01-11 12:09:04 --> URI Class Initialized
INFO - 2017-01-11 12:09:04 --> Router Class Initialized
INFO - 2017-01-11 12:09:04 --> Output Class Initialized
INFO - 2017-01-11 12:09:04 --> Security Class Initialized
DEBUG - 2017-01-11 12:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:09:04 --> Input Class Initialized
INFO - 2017-01-11 12:09:04 --> Language Class Initialized
INFO - 2017-01-11 12:09:04 --> Loader Class Initialized
INFO - 2017-01-11 12:09:04 --> Helper loaded: url_helper
INFO - 2017-01-11 12:09:04 --> Helper loaded: language_helper
INFO - 2017-01-11 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:09:04 --> Controller Class Initialized
INFO - 2017-01-11 12:09:04 --> Database Driver Class Initialized
INFO - 2017-01-11 12:09:04 --> Model Class Initialized
INFO - 2017-01-11 12:09:04 --> Model Class Initialized
INFO - 2017-01-11 12:09:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:09:04 --> Model Class Initialized
INFO - 2017-01-11 12:09:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:09:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:09:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:09:04 --> Final output sent to browser
DEBUG - 2017-01-11 12:09:04 --> Total execution time: 0.1239
INFO - 2017-01-11 12:09:16 --> Config Class Initialized
INFO - 2017-01-11 12:09:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:09:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:09:16 --> Utf8 Class Initialized
INFO - 2017-01-11 12:09:16 --> URI Class Initialized
INFO - 2017-01-11 12:09:16 --> Router Class Initialized
INFO - 2017-01-11 12:09:16 --> Output Class Initialized
INFO - 2017-01-11 12:09:16 --> Security Class Initialized
DEBUG - 2017-01-11 12:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:09:16 --> Input Class Initialized
INFO - 2017-01-11 12:09:16 --> Language Class Initialized
INFO - 2017-01-11 12:09:16 --> Loader Class Initialized
INFO - 2017-01-11 12:09:16 --> Helper loaded: url_helper
INFO - 2017-01-11 12:09:16 --> Helper loaded: language_helper
INFO - 2017-01-11 12:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:09:16 --> Controller Class Initialized
INFO - 2017-01-11 12:09:16 --> Database Driver Class Initialized
INFO - 2017-01-11 12:09:16 --> Model Class Initialized
INFO - 2017-01-11 12:09:16 --> Model Class Initialized
INFO - 2017-01-11 12:09:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:09:16 --> Model Class Initialized
INFO - 2017-01-11 12:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:09:16 --> Final output sent to browser
DEBUG - 2017-01-11 12:09:16 --> Total execution time: 0.1269
INFO - 2017-01-11 12:09:47 --> Config Class Initialized
INFO - 2017-01-11 12:09:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:09:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:09:48 --> Utf8 Class Initialized
INFO - 2017-01-11 12:09:48 --> URI Class Initialized
INFO - 2017-01-11 12:09:48 --> Router Class Initialized
INFO - 2017-01-11 12:09:48 --> Output Class Initialized
INFO - 2017-01-11 12:09:48 --> Security Class Initialized
DEBUG - 2017-01-11 12:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:09:48 --> Input Class Initialized
INFO - 2017-01-11 12:09:48 --> Language Class Initialized
INFO - 2017-01-11 12:09:48 --> Loader Class Initialized
INFO - 2017-01-11 12:09:48 --> Helper loaded: url_helper
INFO - 2017-01-11 12:09:48 --> Helper loaded: language_helper
INFO - 2017-01-11 12:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:09:48 --> Controller Class Initialized
INFO - 2017-01-11 12:09:48 --> Database Driver Class Initialized
INFO - 2017-01-11 12:09:48 --> Model Class Initialized
INFO - 2017-01-11 12:09:48 --> Model Class Initialized
INFO - 2017-01-11 12:09:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:09:48 --> Model Class Initialized
INFO - 2017-01-11 12:09:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:09:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:09:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:09:48 --> Final output sent to browser
DEBUG - 2017-01-11 12:09:48 --> Total execution time: 0.1453
INFO - 2017-01-11 12:11:18 --> Config Class Initialized
INFO - 2017-01-11 12:11:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:11:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:11:18 --> Utf8 Class Initialized
INFO - 2017-01-11 12:11:18 --> URI Class Initialized
INFO - 2017-01-11 12:11:18 --> Router Class Initialized
INFO - 2017-01-11 12:11:18 --> Output Class Initialized
INFO - 2017-01-11 12:11:18 --> Security Class Initialized
DEBUG - 2017-01-11 12:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:11:18 --> Input Class Initialized
INFO - 2017-01-11 12:11:18 --> Language Class Initialized
INFO - 2017-01-11 12:11:18 --> Loader Class Initialized
INFO - 2017-01-11 12:11:18 --> Helper loaded: url_helper
INFO - 2017-01-11 12:11:18 --> Helper loaded: language_helper
INFO - 2017-01-11 12:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:11:18 --> Controller Class Initialized
INFO - 2017-01-11 12:11:18 --> Database Driver Class Initialized
INFO - 2017-01-11 12:11:18 --> Model Class Initialized
INFO - 2017-01-11 12:11:18 --> Model Class Initialized
INFO - 2017-01-11 12:11:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:11:18 --> Model Class Initialized
INFO - 2017-01-11 12:11:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:11:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:11:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:11:18 --> Final output sent to browser
DEBUG - 2017-01-11 12:11:18 --> Total execution time: 0.1626
INFO - 2017-01-11 12:11:35 --> Config Class Initialized
INFO - 2017-01-11 12:11:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:11:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:11:35 --> Utf8 Class Initialized
INFO - 2017-01-11 12:11:35 --> URI Class Initialized
INFO - 2017-01-11 12:11:35 --> Router Class Initialized
INFO - 2017-01-11 12:11:35 --> Output Class Initialized
INFO - 2017-01-11 12:11:35 --> Security Class Initialized
DEBUG - 2017-01-11 12:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:11:35 --> Input Class Initialized
INFO - 2017-01-11 12:11:35 --> Language Class Initialized
INFO - 2017-01-11 12:11:35 --> Loader Class Initialized
INFO - 2017-01-11 12:11:35 --> Helper loaded: url_helper
INFO - 2017-01-11 12:11:35 --> Helper loaded: language_helper
INFO - 2017-01-11 12:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:11:35 --> Controller Class Initialized
INFO - 2017-01-11 12:11:35 --> Database Driver Class Initialized
INFO - 2017-01-11 12:11:35 --> Model Class Initialized
INFO - 2017-01-11 12:11:35 --> Model Class Initialized
INFO - 2017-01-11 12:11:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:11:35 --> Model Class Initialized
INFO - 2017-01-11 12:11:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:11:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:11:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:11:35 --> Final output sent to browser
DEBUG - 2017-01-11 12:11:35 --> Total execution time: 0.1113
INFO - 2017-01-11 12:12:24 --> Config Class Initialized
INFO - 2017-01-11 12:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:12:24 --> Utf8 Class Initialized
INFO - 2017-01-11 12:12:24 --> URI Class Initialized
INFO - 2017-01-11 12:12:24 --> Router Class Initialized
INFO - 2017-01-11 12:12:24 --> Output Class Initialized
INFO - 2017-01-11 12:12:24 --> Security Class Initialized
DEBUG - 2017-01-11 12:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:12:24 --> Input Class Initialized
INFO - 2017-01-11 12:12:24 --> Language Class Initialized
INFO - 2017-01-11 12:12:24 --> Loader Class Initialized
INFO - 2017-01-11 12:12:24 --> Helper loaded: url_helper
INFO - 2017-01-11 12:12:24 --> Helper loaded: language_helper
INFO - 2017-01-11 12:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:12:24 --> Controller Class Initialized
INFO - 2017-01-11 12:12:24 --> Database Driver Class Initialized
INFO - 2017-01-11 12:12:24 --> Model Class Initialized
INFO - 2017-01-11 12:12:24 --> Model Class Initialized
INFO - 2017-01-11 12:12:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:12:24 --> Model Class Initialized
INFO - 2017-01-11 12:12:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:12:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:12:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:12:24 --> Final output sent to browser
DEBUG - 2017-01-11 12:12:24 --> Total execution time: 0.1517
INFO - 2017-01-11 12:15:42 --> Config Class Initialized
INFO - 2017-01-11 12:15:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:15:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:15:42 --> Utf8 Class Initialized
INFO - 2017-01-11 12:15:42 --> URI Class Initialized
INFO - 2017-01-11 12:15:42 --> Router Class Initialized
INFO - 2017-01-11 12:15:42 --> Output Class Initialized
INFO - 2017-01-11 12:15:42 --> Security Class Initialized
DEBUG - 2017-01-11 12:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:15:42 --> Input Class Initialized
INFO - 2017-01-11 12:15:42 --> Language Class Initialized
INFO - 2017-01-11 12:15:42 --> Loader Class Initialized
INFO - 2017-01-11 12:15:42 --> Helper loaded: url_helper
INFO - 2017-01-11 12:15:42 --> Helper loaded: language_helper
INFO - 2017-01-11 12:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:15:42 --> Controller Class Initialized
INFO - 2017-01-11 12:15:42 --> Database Driver Class Initialized
INFO - 2017-01-11 12:15:42 --> Model Class Initialized
INFO - 2017-01-11 12:15:42 --> Model Class Initialized
INFO - 2017-01-11 12:15:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:15:42 --> Model Class Initialized
INFO - 2017-01-11 12:15:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:15:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:15:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:15:42 --> Final output sent to browser
DEBUG - 2017-01-11 12:15:42 --> Total execution time: 0.1073
INFO - 2017-01-11 12:18:44 --> Config Class Initialized
INFO - 2017-01-11 12:18:44 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:18:44 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:18:44 --> Utf8 Class Initialized
INFO - 2017-01-11 12:18:44 --> URI Class Initialized
INFO - 2017-01-11 12:18:44 --> Router Class Initialized
INFO - 2017-01-11 12:18:44 --> Output Class Initialized
INFO - 2017-01-11 12:18:44 --> Security Class Initialized
DEBUG - 2017-01-11 12:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:18:44 --> Input Class Initialized
INFO - 2017-01-11 12:18:44 --> Language Class Initialized
INFO - 2017-01-11 12:18:44 --> Loader Class Initialized
INFO - 2017-01-11 12:18:44 --> Helper loaded: url_helper
INFO - 2017-01-11 12:18:44 --> Helper loaded: language_helper
INFO - 2017-01-11 12:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:18:44 --> Controller Class Initialized
INFO - 2017-01-11 12:18:44 --> Database Driver Class Initialized
INFO - 2017-01-11 12:18:44 --> Model Class Initialized
INFO - 2017-01-11 12:18:44 --> Model Class Initialized
INFO - 2017-01-11 12:18:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:18:44 --> Model Class Initialized
INFO - 2017-01-11 12:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:18:44 --> Final output sent to browser
DEBUG - 2017-01-11 12:18:44 --> Total execution time: 0.1019
INFO - 2017-01-11 12:19:03 --> Config Class Initialized
INFO - 2017-01-11 12:19:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:03 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:03 --> URI Class Initialized
INFO - 2017-01-11 12:19:03 --> Router Class Initialized
INFO - 2017-01-11 12:19:03 --> Output Class Initialized
INFO - 2017-01-11 12:19:03 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:03 --> Input Class Initialized
INFO - 2017-01-11 12:19:03 --> Language Class Initialized
INFO - 2017-01-11 12:19:03 --> Loader Class Initialized
INFO - 2017-01-11 12:19:03 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:03 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:03 --> Controller Class Initialized
INFO - 2017-01-11 12:19:03 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:03 --> Model Class Initialized
INFO - 2017-01-11 12:19:03 --> Model Class Initialized
INFO - 2017-01-11 12:19:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:03 --> Helper loaded: form_helper
INFO - 2017-01-11 12:19:03 --> Form Validation Class Initialized
INFO - 2017-01-11 12:19:03 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:19:03 --> Config Class Initialized
INFO - 2017-01-11 12:19:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:03 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:03 --> URI Class Initialized
INFO - 2017-01-11 12:19:03 --> Router Class Initialized
INFO - 2017-01-11 12:19:03 --> Output Class Initialized
INFO - 2017-01-11 12:19:03 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:03 --> Input Class Initialized
INFO - 2017-01-11 12:19:03 --> Language Class Initialized
INFO - 2017-01-11 12:19:03 --> Loader Class Initialized
INFO - 2017-01-11 12:19:03 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:03 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:03 --> Controller Class Initialized
INFO - 2017-01-11 12:19:03 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:03 --> Model Class Initialized
INFO - 2017-01-11 12:19:03 --> Model Class Initialized
INFO - 2017-01-11 12:19:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:03 --> Model Class Initialized
INFO - 2017-01-11 12:19:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:19:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:03 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:03 --> Total execution time: 0.1250
INFO - 2017-01-11 12:19:09 --> Config Class Initialized
INFO - 2017-01-11 12:19:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:09 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:09 --> URI Class Initialized
INFO - 2017-01-11 12:19:09 --> Router Class Initialized
INFO - 2017-01-11 12:19:09 --> Output Class Initialized
INFO - 2017-01-11 12:19:09 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:09 --> Input Class Initialized
INFO - 2017-01-11 12:19:09 --> Language Class Initialized
INFO - 2017-01-11 12:19:09 --> Loader Class Initialized
INFO - 2017-01-11 12:19:09 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:09 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:09 --> Controller Class Initialized
INFO - 2017-01-11 12:19:09 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:09 --> Model Class Initialized
INFO - 2017-01-11 12:19:09 --> Model Class Initialized
INFO - 2017-01-11 12:19:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:09 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:09 --> Total execution time: 0.0787
INFO - 2017-01-11 12:19:12 --> Config Class Initialized
INFO - 2017-01-11 12:19:12 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:12 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:12 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:12 --> URI Class Initialized
INFO - 2017-01-11 12:19:12 --> Router Class Initialized
INFO - 2017-01-11 12:19:12 --> Output Class Initialized
INFO - 2017-01-11 12:19:12 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:12 --> Input Class Initialized
INFO - 2017-01-11 12:19:12 --> Language Class Initialized
INFO - 2017-01-11 12:19:12 --> Loader Class Initialized
INFO - 2017-01-11 12:19:12 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:12 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:12 --> Controller Class Initialized
INFO - 2017-01-11 12:19:12 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:12 --> Model Class Initialized
INFO - 2017-01-11 12:19:12 --> Model Class Initialized
INFO - 2017-01-11 12:19:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:12 --> Model Class Initialized
INFO - 2017-01-11 12:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:19:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:12 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:12 --> Total execution time: 0.0861
INFO - 2017-01-11 12:19:16 --> Config Class Initialized
INFO - 2017-01-11 12:19:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:16 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:16 --> URI Class Initialized
INFO - 2017-01-11 12:19:16 --> Router Class Initialized
INFO - 2017-01-11 12:19:16 --> Output Class Initialized
INFO - 2017-01-11 12:19:16 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:16 --> Input Class Initialized
INFO - 2017-01-11 12:19:16 --> Language Class Initialized
INFO - 2017-01-11 12:19:16 --> Loader Class Initialized
INFO - 2017-01-11 12:19:16 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:16 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:16 --> Controller Class Initialized
INFO - 2017-01-11 12:19:16 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:16 --> Model Class Initialized
INFO - 2017-01-11 12:19:16 --> Model Class Initialized
INFO - 2017-01-11 12:19:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:16 --> Helper loaded: form_helper
INFO - 2017-01-11 12:19:16 --> Form Validation Class Initialized
INFO - 2017-01-11 12:19:16 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:19:16 --> Config Class Initialized
INFO - 2017-01-11 12:19:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:16 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:16 --> URI Class Initialized
INFO - 2017-01-11 12:19:16 --> Router Class Initialized
INFO - 2017-01-11 12:19:16 --> Output Class Initialized
INFO - 2017-01-11 12:19:16 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:16 --> Input Class Initialized
INFO - 2017-01-11 12:19:16 --> Language Class Initialized
INFO - 2017-01-11 12:19:16 --> Loader Class Initialized
INFO - 2017-01-11 12:19:16 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:16 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:16 --> Controller Class Initialized
INFO - 2017-01-11 12:19:16 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:16 --> Model Class Initialized
INFO - 2017-01-11 12:19:16 --> Model Class Initialized
INFO - 2017-01-11 12:19:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:16 --> Model Class Initialized
INFO - 2017-01-11 12:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:16 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:16 --> Total execution time: 0.1022
INFO - 2017-01-11 12:19:25 --> Config Class Initialized
INFO - 2017-01-11 12:19:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:25 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:25 --> URI Class Initialized
INFO - 2017-01-11 12:19:25 --> Router Class Initialized
INFO - 2017-01-11 12:19:25 --> Output Class Initialized
INFO - 2017-01-11 12:19:25 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:25 --> Input Class Initialized
INFO - 2017-01-11 12:19:25 --> Language Class Initialized
INFO - 2017-01-11 12:19:25 --> Loader Class Initialized
INFO - 2017-01-11 12:19:25 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:26 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:26 --> Controller Class Initialized
INFO - 2017-01-11 12:19:26 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:26 --> Model Class Initialized
INFO - 2017-01-11 12:19:26 --> Model Class Initialized
INFO - 2017-01-11 12:19:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:26 --> Helper loaded: form_helper
INFO - 2017-01-11 12:19:26 --> Form Validation Class Initialized
INFO - 2017-01-11 12:19:26 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:19:26 --> Config Class Initialized
INFO - 2017-01-11 12:19:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:26 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:26 --> URI Class Initialized
INFO - 2017-01-11 12:19:26 --> Router Class Initialized
INFO - 2017-01-11 12:19:26 --> Output Class Initialized
INFO - 2017-01-11 12:19:26 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:26 --> Input Class Initialized
INFO - 2017-01-11 12:19:26 --> Language Class Initialized
INFO - 2017-01-11 12:19:26 --> Loader Class Initialized
INFO - 2017-01-11 12:19:26 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:26 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:26 --> Controller Class Initialized
INFO - 2017-01-11 12:19:26 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:26 --> Model Class Initialized
INFO - 2017-01-11 12:19:26 --> Model Class Initialized
INFO - 2017-01-11 12:19:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:26 --> Model Class Initialized
INFO - 2017-01-11 12:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:26 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:26 --> Total execution time: 0.1097
INFO - 2017-01-11 12:19:29 --> Config Class Initialized
INFO - 2017-01-11 12:19:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:29 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:29 --> URI Class Initialized
INFO - 2017-01-11 12:19:29 --> Router Class Initialized
INFO - 2017-01-11 12:19:29 --> Output Class Initialized
INFO - 2017-01-11 12:19:29 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:29 --> Input Class Initialized
INFO - 2017-01-11 12:19:29 --> Language Class Initialized
INFO - 2017-01-11 12:19:29 --> Loader Class Initialized
INFO - 2017-01-11 12:19:29 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:29 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:29 --> Controller Class Initialized
INFO - 2017-01-11 12:19:29 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:29 --> Model Class Initialized
INFO - 2017-01-11 12:19:29 --> Model Class Initialized
INFO - 2017-01-11 12:19:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:29 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:29 --> Total execution time: 0.0828
INFO - 2017-01-11 12:19:33 --> Config Class Initialized
INFO - 2017-01-11 12:19:33 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:19:33 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:19:33 --> Utf8 Class Initialized
INFO - 2017-01-11 12:19:33 --> URI Class Initialized
INFO - 2017-01-11 12:19:33 --> Router Class Initialized
INFO - 2017-01-11 12:19:33 --> Output Class Initialized
INFO - 2017-01-11 12:19:33 --> Security Class Initialized
DEBUG - 2017-01-11 12:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:19:33 --> Input Class Initialized
INFO - 2017-01-11 12:19:33 --> Language Class Initialized
INFO - 2017-01-11 12:19:33 --> Loader Class Initialized
INFO - 2017-01-11 12:19:33 --> Helper loaded: url_helper
INFO - 2017-01-11 12:19:33 --> Helper loaded: language_helper
INFO - 2017-01-11 12:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:19:33 --> Controller Class Initialized
INFO - 2017-01-11 12:19:33 --> Database Driver Class Initialized
INFO - 2017-01-11 12:19:33 --> Model Class Initialized
INFO - 2017-01-11 12:19:33 --> Model Class Initialized
INFO - 2017-01-11 12:19:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:19:33 --> Model Class Initialized
INFO - 2017-01-11 12:19:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:19:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:19:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:19:33 --> Final output sent to browser
DEBUG - 2017-01-11 12:19:33 --> Total execution time: 0.0832
INFO - 2017-01-11 12:21:05 --> Config Class Initialized
INFO - 2017-01-11 12:21:05 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:21:05 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:21:05 --> Utf8 Class Initialized
INFO - 2017-01-11 12:21:05 --> URI Class Initialized
INFO - 2017-01-11 12:21:05 --> Router Class Initialized
INFO - 2017-01-11 12:21:05 --> Output Class Initialized
INFO - 2017-01-11 12:21:05 --> Security Class Initialized
DEBUG - 2017-01-11 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:21:05 --> Input Class Initialized
INFO - 2017-01-11 12:21:05 --> Language Class Initialized
INFO - 2017-01-11 12:21:05 --> Loader Class Initialized
INFO - 2017-01-11 12:21:05 --> Helper loaded: url_helper
INFO - 2017-01-11 12:21:05 --> Helper loaded: language_helper
INFO - 2017-01-11 12:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:21:05 --> Controller Class Initialized
INFO - 2017-01-11 12:21:05 --> Database Driver Class Initialized
INFO - 2017-01-11 12:21:05 --> Model Class Initialized
INFO - 2017-01-11 12:21:05 --> Model Class Initialized
INFO - 2017-01-11 12:21:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:21:05 --> Model Class Initialized
INFO - 2017-01-11 12:21:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:21:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:21:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:21:05 --> Final output sent to browser
DEBUG - 2017-01-11 12:21:05 --> Total execution time: 0.0928
INFO - 2017-01-11 12:21:09 --> Config Class Initialized
INFO - 2017-01-11 12:21:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:21:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:21:09 --> Utf8 Class Initialized
INFO - 2017-01-11 12:21:09 --> URI Class Initialized
INFO - 2017-01-11 12:21:09 --> Router Class Initialized
INFO - 2017-01-11 12:21:09 --> Output Class Initialized
INFO - 2017-01-11 12:21:09 --> Security Class Initialized
DEBUG - 2017-01-11 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:21:09 --> Input Class Initialized
INFO - 2017-01-11 12:21:09 --> Language Class Initialized
INFO - 2017-01-11 12:21:09 --> Loader Class Initialized
INFO - 2017-01-11 12:21:09 --> Helper loaded: url_helper
INFO - 2017-01-11 12:21:09 --> Helper loaded: language_helper
INFO - 2017-01-11 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:21:09 --> Controller Class Initialized
INFO - 2017-01-11 12:21:09 --> Database Driver Class Initialized
INFO - 2017-01-11 12:21:09 --> Model Class Initialized
INFO - 2017-01-11 12:21:09 --> Model Class Initialized
INFO - 2017-01-11 12:21:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:21:09 --> Helper loaded: form_helper
INFO - 2017-01-11 12:21:09 --> Form Validation Class Initialized
INFO - 2017-01-11 12:21:09 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:21:09 --> Config Class Initialized
INFO - 2017-01-11 12:21:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:21:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:21:09 --> Utf8 Class Initialized
INFO - 2017-01-11 12:21:09 --> URI Class Initialized
INFO - 2017-01-11 12:21:09 --> Router Class Initialized
INFO - 2017-01-11 12:21:09 --> Output Class Initialized
INFO - 2017-01-11 12:21:09 --> Security Class Initialized
DEBUG - 2017-01-11 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:21:09 --> Input Class Initialized
INFO - 2017-01-11 12:21:09 --> Language Class Initialized
INFO - 2017-01-11 12:21:09 --> Loader Class Initialized
INFO - 2017-01-11 12:21:09 --> Helper loaded: url_helper
INFO - 2017-01-11 12:21:09 --> Helper loaded: language_helper
INFO - 2017-01-11 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:21:09 --> Controller Class Initialized
INFO - 2017-01-11 12:21:10 --> Database Driver Class Initialized
INFO - 2017-01-11 12:21:10 --> Model Class Initialized
INFO - 2017-01-11 12:21:10 --> Model Class Initialized
INFO - 2017-01-11 12:21:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:21:10 --> Model Class Initialized
INFO - 2017-01-11 12:21:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:21:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:21:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:21:10 --> Final output sent to browser
DEBUG - 2017-01-11 12:21:10 --> Total execution time: 0.0957
INFO - 2017-01-11 12:23:28 --> Config Class Initialized
INFO - 2017-01-11 12:23:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:23:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:23:28 --> Utf8 Class Initialized
INFO - 2017-01-11 12:23:28 --> URI Class Initialized
INFO - 2017-01-11 12:23:28 --> Router Class Initialized
INFO - 2017-01-11 12:23:28 --> Output Class Initialized
INFO - 2017-01-11 12:23:28 --> Security Class Initialized
DEBUG - 2017-01-11 12:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:23:28 --> Input Class Initialized
INFO - 2017-01-11 12:23:28 --> Language Class Initialized
INFO - 2017-01-11 12:23:28 --> Loader Class Initialized
INFO - 2017-01-11 12:23:28 --> Helper loaded: url_helper
INFO - 2017-01-11 12:23:28 --> Helper loaded: language_helper
INFO - 2017-01-11 12:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:23:28 --> Controller Class Initialized
INFO - 2017-01-11 12:23:28 --> Database Driver Class Initialized
INFO - 2017-01-11 12:23:28 --> Model Class Initialized
INFO - 2017-01-11 12:23:28 --> Model Class Initialized
INFO - 2017-01-11 12:23:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:23:28 --> Helper loaded: form_helper
INFO - 2017-01-11 12:23:28 --> Form Validation Class Initialized
INFO - 2017-01-11 12:23:28 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:23:28 --> Config Class Initialized
INFO - 2017-01-11 12:23:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:23:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:23:28 --> Utf8 Class Initialized
INFO - 2017-01-11 12:23:28 --> URI Class Initialized
INFO - 2017-01-11 12:23:28 --> Router Class Initialized
INFO - 2017-01-11 12:23:28 --> Output Class Initialized
INFO - 2017-01-11 12:23:28 --> Security Class Initialized
DEBUG - 2017-01-11 12:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:23:28 --> Input Class Initialized
INFO - 2017-01-11 12:23:28 --> Language Class Initialized
INFO - 2017-01-11 12:23:28 --> Loader Class Initialized
INFO - 2017-01-11 12:23:28 --> Helper loaded: url_helper
INFO - 2017-01-11 12:23:28 --> Helper loaded: language_helper
INFO - 2017-01-11 12:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:23:28 --> Controller Class Initialized
INFO - 2017-01-11 12:23:28 --> Database Driver Class Initialized
INFO - 2017-01-11 12:23:28 --> Model Class Initialized
INFO - 2017-01-11 12:23:28 --> Model Class Initialized
INFO - 2017-01-11 12:23:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:23:28 --> Model Class Initialized
INFO - 2017-01-11 12:23:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:23:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:23:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:23:28 --> Final output sent to browser
DEBUG - 2017-01-11 12:23:28 --> Total execution time: 0.0874
INFO - 2017-01-11 12:24:12 --> Config Class Initialized
INFO - 2017-01-11 12:24:12 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:24:12 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:24:12 --> Utf8 Class Initialized
INFO - 2017-01-11 12:24:12 --> URI Class Initialized
INFO - 2017-01-11 12:24:12 --> Router Class Initialized
INFO - 2017-01-11 12:24:12 --> Output Class Initialized
INFO - 2017-01-11 12:24:12 --> Security Class Initialized
DEBUG - 2017-01-11 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:24:12 --> Input Class Initialized
INFO - 2017-01-11 12:24:12 --> Language Class Initialized
INFO - 2017-01-11 12:24:12 --> Loader Class Initialized
INFO - 2017-01-11 12:24:12 --> Helper loaded: url_helper
INFO - 2017-01-11 12:24:12 --> Helper loaded: language_helper
INFO - 2017-01-11 12:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:24:12 --> Controller Class Initialized
INFO - 2017-01-11 12:24:12 --> Database Driver Class Initialized
INFO - 2017-01-11 12:24:12 --> Model Class Initialized
INFO - 2017-01-11 12:24:12 --> Model Class Initialized
INFO - 2017-01-11 12:24:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:24:12 --> Final output sent to browser
DEBUG - 2017-01-11 12:24:12 --> Total execution time: 0.0801
INFO - 2017-01-11 12:24:14 --> Config Class Initialized
INFO - 2017-01-11 12:24:14 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:24:14 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:24:14 --> Utf8 Class Initialized
INFO - 2017-01-11 12:24:14 --> URI Class Initialized
INFO - 2017-01-11 12:24:14 --> Router Class Initialized
INFO - 2017-01-11 12:24:14 --> Output Class Initialized
INFO - 2017-01-11 12:24:14 --> Security Class Initialized
DEBUG - 2017-01-11 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:24:14 --> Input Class Initialized
INFO - 2017-01-11 12:24:14 --> Language Class Initialized
INFO - 2017-01-11 12:24:14 --> Loader Class Initialized
INFO - 2017-01-11 12:24:14 --> Helper loaded: url_helper
INFO - 2017-01-11 12:24:14 --> Helper loaded: language_helper
INFO - 2017-01-11 12:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:24:14 --> Controller Class Initialized
INFO - 2017-01-11 12:24:14 --> Database Driver Class Initialized
INFO - 2017-01-11 12:24:14 --> Model Class Initialized
INFO - 2017-01-11 12:24:14 --> Model Class Initialized
INFO - 2017-01-11 12:24:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:24:14 --> Model Class Initialized
INFO - 2017-01-11 12:24:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:24:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:24:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:24:14 --> Final output sent to browser
DEBUG - 2017-01-11 12:24:14 --> Total execution time: 0.1403
INFO - 2017-01-11 12:24:35 --> Config Class Initialized
INFO - 2017-01-11 12:24:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:24:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:24:35 --> Utf8 Class Initialized
INFO - 2017-01-11 12:24:35 --> URI Class Initialized
INFO - 2017-01-11 12:24:35 --> Router Class Initialized
INFO - 2017-01-11 12:24:35 --> Output Class Initialized
INFO - 2017-01-11 12:24:35 --> Security Class Initialized
DEBUG - 2017-01-11 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:24:35 --> Input Class Initialized
INFO - 2017-01-11 12:24:35 --> Language Class Initialized
INFO - 2017-01-11 12:24:35 --> Loader Class Initialized
INFO - 2017-01-11 12:24:35 --> Helper loaded: url_helper
INFO - 2017-01-11 12:24:35 --> Helper loaded: language_helper
INFO - 2017-01-11 12:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:24:35 --> Controller Class Initialized
INFO - 2017-01-11 12:24:35 --> Database Driver Class Initialized
INFO - 2017-01-11 12:24:35 --> Model Class Initialized
INFO - 2017-01-11 12:24:35 --> Model Class Initialized
INFO - 2017-01-11 12:24:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:24:35 --> Helper loaded: form_helper
INFO - 2017-01-11 12:24:35 --> Form Validation Class Initialized
INFO - 2017-01-11 12:24:35 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:24:35 --> Config Class Initialized
INFO - 2017-01-11 12:24:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:24:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:24:35 --> Utf8 Class Initialized
INFO - 2017-01-11 12:24:35 --> URI Class Initialized
INFO - 2017-01-11 12:24:35 --> Router Class Initialized
INFO - 2017-01-11 12:24:35 --> Output Class Initialized
INFO - 2017-01-11 12:24:35 --> Security Class Initialized
DEBUG - 2017-01-11 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:24:35 --> Input Class Initialized
INFO - 2017-01-11 12:24:35 --> Language Class Initialized
INFO - 2017-01-11 12:24:35 --> Loader Class Initialized
INFO - 2017-01-11 12:24:35 --> Helper loaded: url_helper
INFO - 2017-01-11 12:24:35 --> Helper loaded: language_helper
INFO - 2017-01-11 12:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:24:35 --> Controller Class Initialized
INFO - 2017-01-11 12:24:35 --> Database Driver Class Initialized
INFO - 2017-01-11 12:24:35 --> Model Class Initialized
INFO - 2017-01-11 12:24:35 --> Model Class Initialized
INFO - 2017-01-11 12:24:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:24:35 --> Model Class Initialized
INFO - 2017-01-11 12:24:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:24:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:24:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:24:35 --> Final output sent to browser
DEBUG - 2017-01-11 12:24:35 --> Total execution time: 0.0904
INFO - 2017-01-11 12:24:54 --> Config Class Initialized
INFO - 2017-01-11 12:24:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:24:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:24:54 --> Utf8 Class Initialized
INFO - 2017-01-11 12:24:54 --> URI Class Initialized
INFO - 2017-01-11 12:24:54 --> Router Class Initialized
INFO - 2017-01-11 12:24:54 --> Output Class Initialized
INFO - 2017-01-11 12:24:54 --> Security Class Initialized
DEBUG - 2017-01-11 12:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:24:54 --> Input Class Initialized
INFO - 2017-01-11 12:24:54 --> Language Class Initialized
INFO - 2017-01-11 12:24:54 --> Loader Class Initialized
INFO - 2017-01-11 12:24:54 --> Helper loaded: url_helper
INFO - 2017-01-11 12:24:54 --> Helper loaded: language_helper
INFO - 2017-01-11 12:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:24:54 --> Controller Class Initialized
INFO - 2017-01-11 12:24:54 --> Database Driver Class Initialized
INFO - 2017-01-11 12:24:54 --> Model Class Initialized
INFO - 2017-01-11 12:24:54 --> Model Class Initialized
INFO - 2017-01-11 12:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:24:54 --> Helper loaded: form_helper
INFO - 2017-01-11 12:24:54 --> Form Validation Class Initialized
INFO - 2017-01-11 12:24:54 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:24:54 --> Config Class Initialized
INFO - 2017-01-11 12:24:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:24:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:24:54 --> Utf8 Class Initialized
INFO - 2017-01-11 12:24:54 --> URI Class Initialized
INFO - 2017-01-11 12:24:54 --> Router Class Initialized
INFO - 2017-01-11 12:24:54 --> Output Class Initialized
INFO - 2017-01-11 12:24:54 --> Security Class Initialized
DEBUG - 2017-01-11 12:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:24:54 --> Input Class Initialized
INFO - 2017-01-11 12:24:54 --> Language Class Initialized
INFO - 2017-01-11 12:24:54 --> Loader Class Initialized
INFO - 2017-01-11 12:24:54 --> Helper loaded: url_helper
INFO - 2017-01-11 12:24:54 --> Helper loaded: language_helper
INFO - 2017-01-11 12:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:24:54 --> Controller Class Initialized
INFO - 2017-01-11 12:24:54 --> Database Driver Class Initialized
INFO - 2017-01-11 12:24:54 --> Model Class Initialized
INFO - 2017-01-11 12:24:54 --> Model Class Initialized
INFO - 2017-01-11 12:24:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:24:54 --> Model Class Initialized
INFO - 2017-01-11 12:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:24:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:24:54 --> Final output sent to browser
DEBUG - 2017-01-11 12:24:54 --> Total execution time: 0.0802
INFO - 2017-01-11 12:30:29 --> Config Class Initialized
INFO - 2017-01-11 12:30:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:30:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:30:29 --> Utf8 Class Initialized
INFO - 2017-01-11 12:30:29 --> URI Class Initialized
INFO - 2017-01-11 12:30:29 --> Router Class Initialized
INFO - 2017-01-11 12:30:29 --> Output Class Initialized
INFO - 2017-01-11 12:30:29 --> Security Class Initialized
DEBUG - 2017-01-11 12:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:30:29 --> Input Class Initialized
INFO - 2017-01-11 12:30:29 --> Language Class Initialized
INFO - 2017-01-11 12:30:29 --> Loader Class Initialized
INFO - 2017-01-11 12:30:29 --> Helper loaded: url_helper
INFO - 2017-01-11 12:30:29 --> Helper loaded: language_helper
INFO - 2017-01-11 12:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:30:29 --> Controller Class Initialized
INFO - 2017-01-11 12:30:29 --> Database Driver Class Initialized
INFO - 2017-01-11 12:30:29 --> Model Class Initialized
INFO - 2017-01-11 12:30:29 --> Model Class Initialized
INFO - 2017-01-11 12:30:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:30:29 --> Model Class Initialized
INFO - 2017-01-11 12:30:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:30:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:30:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:30:29 --> Final output sent to browser
DEBUG - 2017-01-11 12:30:29 --> Total execution time: 0.1405
INFO - 2017-01-11 12:30:36 --> Config Class Initialized
INFO - 2017-01-11 12:30:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:30:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:30:36 --> Utf8 Class Initialized
INFO - 2017-01-11 12:30:36 --> URI Class Initialized
INFO - 2017-01-11 12:30:36 --> Router Class Initialized
INFO - 2017-01-11 12:30:36 --> Output Class Initialized
INFO - 2017-01-11 12:30:36 --> Security Class Initialized
DEBUG - 2017-01-11 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:30:36 --> Input Class Initialized
INFO - 2017-01-11 12:30:36 --> Language Class Initialized
INFO - 2017-01-11 12:30:37 --> Loader Class Initialized
INFO - 2017-01-11 12:30:37 --> Helper loaded: url_helper
INFO - 2017-01-11 12:30:37 --> Helper loaded: language_helper
INFO - 2017-01-11 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:30:37 --> Controller Class Initialized
INFO - 2017-01-11 12:30:37 --> Database Driver Class Initialized
INFO - 2017-01-11 12:30:37 --> Model Class Initialized
INFO - 2017-01-11 12:30:37 --> Model Class Initialized
INFO - 2017-01-11 12:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:30:37 --> Helper loaded: form_helper
INFO - 2017-01-11 12:30:37 --> Form Validation Class Initialized
INFO - 2017-01-11 12:30:37 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:30:37 --> Config Class Initialized
INFO - 2017-01-11 12:30:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:30:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:30:37 --> Utf8 Class Initialized
INFO - 2017-01-11 12:30:37 --> URI Class Initialized
INFO - 2017-01-11 12:30:37 --> Router Class Initialized
INFO - 2017-01-11 12:30:37 --> Output Class Initialized
INFO - 2017-01-11 12:30:37 --> Security Class Initialized
DEBUG - 2017-01-11 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:30:37 --> Input Class Initialized
INFO - 2017-01-11 12:30:37 --> Language Class Initialized
INFO - 2017-01-11 12:30:37 --> Loader Class Initialized
INFO - 2017-01-11 12:30:37 --> Helper loaded: url_helper
INFO - 2017-01-11 12:30:37 --> Helper loaded: language_helper
INFO - 2017-01-11 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:30:37 --> Controller Class Initialized
INFO - 2017-01-11 12:30:37 --> Database Driver Class Initialized
INFO - 2017-01-11 12:30:37 --> Model Class Initialized
INFO - 2017-01-11 12:30:37 --> Model Class Initialized
INFO - 2017-01-11 12:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:30:37 --> Model Class Initialized
INFO - 2017-01-11 12:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:30:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:30:37 --> Final output sent to browser
DEBUG - 2017-01-11 12:30:37 --> Total execution time: 0.0977
INFO - 2017-01-11 12:54:24 --> Config Class Initialized
INFO - 2017-01-11 12:54:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:54:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:54:24 --> Utf8 Class Initialized
INFO - 2017-01-11 12:54:24 --> URI Class Initialized
INFO - 2017-01-11 12:54:24 --> Router Class Initialized
INFO - 2017-01-11 12:54:24 --> Output Class Initialized
INFO - 2017-01-11 12:54:24 --> Security Class Initialized
DEBUG - 2017-01-11 12:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:54:24 --> Input Class Initialized
INFO - 2017-01-11 12:54:24 --> Language Class Initialized
INFO - 2017-01-11 12:54:24 --> Loader Class Initialized
INFO - 2017-01-11 12:54:24 --> Helper loaded: url_helper
INFO - 2017-01-11 12:54:24 --> Helper loaded: language_helper
INFO - 2017-01-11 12:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:54:24 --> Controller Class Initialized
INFO - 2017-01-11 12:54:24 --> Database Driver Class Initialized
INFO - 2017-01-11 12:54:24 --> Model Class Initialized
INFO - 2017-01-11 12:54:24 --> Model Class Initialized
INFO - 2017-01-11 12:54:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:54:24 --> Model Class Initialized
INFO - 2017-01-11 12:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:54:24 --> Final output sent to browser
DEBUG - 2017-01-11 12:54:24 --> Total execution time: 0.1498
INFO - 2017-01-11 12:54:32 --> Config Class Initialized
INFO - 2017-01-11 12:54:32 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:54:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:54:32 --> Utf8 Class Initialized
INFO - 2017-01-11 12:54:32 --> URI Class Initialized
INFO - 2017-01-11 12:54:32 --> Router Class Initialized
INFO - 2017-01-11 12:54:32 --> Output Class Initialized
INFO - 2017-01-11 12:54:32 --> Security Class Initialized
DEBUG - 2017-01-11 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:54:32 --> Input Class Initialized
INFO - 2017-01-11 12:54:32 --> Language Class Initialized
INFO - 2017-01-11 12:54:32 --> Loader Class Initialized
INFO - 2017-01-11 12:54:32 --> Helper loaded: url_helper
INFO - 2017-01-11 12:54:32 --> Helper loaded: language_helper
INFO - 2017-01-11 12:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:54:32 --> Controller Class Initialized
INFO - 2017-01-11 12:54:32 --> Database Driver Class Initialized
INFO - 2017-01-11 12:54:32 --> Model Class Initialized
INFO - 2017-01-11 12:54:32 --> Model Class Initialized
INFO - 2017-01-11 12:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:54:32 --> Helper loaded: form_helper
INFO - 2017-01-11 12:54:32 --> Form Validation Class Initialized
INFO - 2017-01-11 12:54:32 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:55:58 --> Config Class Initialized
INFO - 2017-01-11 12:55:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:55:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:55:58 --> Utf8 Class Initialized
INFO - 2017-01-11 12:55:58 --> URI Class Initialized
INFO - 2017-01-11 12:55:58 --> Router Class Initialized
INFO - 2017-01-11 12:55:58 --> Output Class Initialized
INFO - 2017-01-11 12:55:58 --> Security Class Initialized
DEBUG - 2017-01-11 12:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:55:58 --> Input Class Initialized
INFO - 2017-01-11 12:55:58 --> Language Class Initialized
INFO - 2017-01-11 12:55:58 --> Loader Class Initialized
INFO - 2017-01-11 12:55:58 --> Helper loaded: url_helper
INFO - 2017-01-11 12:55:58 --> Helper loaded: language_helper
INFO - 2017-01-11 12:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:55:58 --> Controller Class Initialized
INFO - 2017-01-11 12:55:58 --> Database Driver Class Initialized
INFO - 2017-01-11 12:55:58 --> Model Class Initialized
INFO - 2017-01-11 12:55:58 --> Model Class Initialized
INFO - 2017-01-11 12:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:55:58 --> Helper loaded: form_helper
INFO - 2017-01-11 12:55:58 --> Form Validation Class Initialized
INFO - 2017-01-11 12:55:58 --> Config Class Initialized
INFO - 2017-01-11 12:55:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:55:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:55:58 --> Utf8 Class Initialized
INFO - 2017-01-11 12:55:58 --> URI Class Initialized
INFO - 2017-01-11 12:55:58 --> Router Class Initialized
INFO - 2017-01-11 12:55:58 --> Output Class Initialized
INFO - 2017-01-11 12:55:58 --> Security Class Initialized
DEBUG - 2017-01-11 12:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:55:58 --> Input Class Initialized
INFO - 2017-01-11 12:55:58 --> Language Class Initialized
INFO - 2017-01-11 12:55:58 --> Loader Class Initialized
INFO - 2017-01-11 12:55:58 --> Helper loaded: url_helper
INFO - 2017-01-11 12:55:58 --> Helper loaded: language_helper
INFO - 2017-01-11 12:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:55:58 --> Controller Class Initialized
INFO - 2017-01-11 12:55:58 --> Database Driver Class Initialized
INFO - 2017-01-11 12:55:58 --> Model Class Initialized
INFO - 2017-01-11 12:55:58 --> Model Class Initialized
INFO - 2017-01-11 12:55:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:55:58 --> Model Class Initialized
INFO - 2017-01-11 12:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:55:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:55:58 --> Final output sent to browser
DEBUG - 2017-01-11 12:55:58 --> Total execution time: 0.0965
INFO - 2017-01-11 12:56:08 --> Config Class Initialized
INFO - 2017-01-11 12:56:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:56:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:56:08 --> Utf8 Class Initialized
INFO - 2017-01-11 12:56:08 --> URI Class Initialized
INFO - 2017-01-11 12:56:08 --> Router Class Initialized
INFO - 2017-01-11 12:56:08 --> Output Class Initialized
INFO - 2017-01-11 12:56:08 --> Security Class Initialized
DEBUG - 2017-01-11 12:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:56:08 --> Input Class Initialized
INFO - 2017-01-11 12:56:08 --> Language Class Initialized
INFO - 2017-01-11 12:56:08 --> Loader Class Initialized
INFO - 2017-01-11 12:56:08 --> Helper loaded: url_helper
INFO - 2017-01-11 12:56:08 --> Helper loaded: language_helper
INFO - 2017-01-11 12:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:56:08 --> Controller Class Initialized
INFO - 2017-01-11 12:56:08 --> Database Driver Class Initialized
INFO - 2017-01-11 12:56:08 --> Model Class Initialized
INFO - 2017-01-11 12:56:08 --> Model Class Initialized
INFO - 2017-01-11 12:56:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:56:08 --> Model Class Initialized
INFO - 2017-01-11 12:56:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:56:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:56:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:56:08 --> Final output sent to browser
DEBUG - 2017-01-11 12:56:08 --> Total execution time: 0.0868
INFO - 2017-01-11 12:56:14 --> Config Class Initialized
INFO - 2017-01-11 12:56:14 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:56:14 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:56:14 --> Utf8 Class Initialized
INFO - 2017-01-11 12:56:14 --> URI Class Initialized
INFO - 2017-01-11 12:56:14 --> Router Class Initialized
INFO - 2017-01-11 12:56:14 --> Output Class Initialized
INFO - 2017-01-11 12:56:14 --> Security Class Initialized
DEBUG - 2017-01-11 12:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:56:14 --> Input Class Initialized
INFO - 2017-01-11 12:56:14 --> Language Class Initialized
INFO - 2017-01-11 12:56:14 --> Loader Class Initialized
INFO - 2017-01-11 12:56:14 --> Helper loaded: url_helper
INFO - 2017-01-11 12:56:14 --> Helper loaded: language_helper
INFO - 2017-01-11 12:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:56:14 --> Controller Class Initialized
INFO - 2017-01-11 12:56:14 --> Database Driver Class Initialized
INFO - 2017-01-11 12:56:14 --> Model Class Initialized
INFO - 2017-01-11 12:56:14 --> Model Class Initialized
INFO - 2017-01-11 12:56:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:56:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:56:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:56:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:56:14 --> Final output sent to browser
DEBUG - 2017-01-11 12:56:14 --> Total execution time: 0.0736
INFO - 2017-01-11 12:56:18 --> Config Class Initialized
INFO - 2017-01-11 12:56:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:56:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:56:18 --> Utf8 Class Initialized
INFO - 2017-01-11 12:56:18 --> URI Class Initialized
INFO - 2017-01-11 12:56:18 --> Router Class Initialized
INFO - 2017-01-11 12:56:18 --> Output Class Initialized
INFO - 2017-01-11 12:56:18 --> Security Class Initialized
DEBUG - 2017-01-11 12:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:56:18 --> Input Class Initialized
INFO - 2017-01-11 12:56:18 --> Language Class Initialized
INFO - 2017-01-11 12:56:18 --> Loader Class Initialized
INFO - 2017-01-11 12:56:18 --> Helper loaded: url_helper
INFO - 2017-01-11 12:56:18 --> Helper loaded: language_helper
INFO - 2017-01-11 12:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:56:18 --> Controller Class Initialized
INFO - 2017-01-11 12:56:18 --> Database Driver Class Initialized
INFO - 2017-01-11 12:56:18 --> Model Class Initialized
INFO - 2017-01-11 12:56:18 --> Model Class Initialized
INFO - 2017-01-11 12:56:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:56:18 --> Model Class Initialized
INFO - 2017-01-11 12:56:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:56:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:56:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:56:18 --> Final output sent to browser
DEBUG - 2017-01-11 12:56:18 --> Total execution time: 0.1107
INFO - 2017-01-11 12:58:00 --> Config Class Initialized
INFO - 2017-01-11 12:58:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:58:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:58:00 --> Utf8 Class Initialized
INFO - 2017-01-11 12:58:00 --> URI Class Initialized
INFO - 2017-01-11 12:58:00 --> Router Class Initialized
INFO - 2017-01-11 12:58:00 --> Output Class Initialized
INFO - 2017-01-11 12:58:00 --> Security Class Initialized
DEBUG - 2017-01-11 12:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:58:00 --> Input Class Initialized
INFO - 2017-01-11 12:58:00 --> Language Class Initialized
INFO - 2017-01-11 12:58:00 --> Loader Class Initialized
INFO - 2017-01-11 12:58:00 --> Helper loaded: url_helper
INFO - 2017-01-11 12:58:00 --> Helper loaded: language_helper
INFO - 2017-01-11 12:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:58:00 --> Controller Class Initialized
INFO - 2017-01-11 12:58:00 --> Database Driver Class Initialized
INFO - 2017-01-11 12:58:00 --> Model Class Initialized
INFO - 2017-01-11 12:58:00 --> Model Class Initialized
INFO - 2017-01-11 12:58:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:58:00 --> Model Class Initialized
INFO - 2017-01-11 12:58:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:58:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:58:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:58:00 --> Final output sent to browser
DEBUG - 2017-01-11 12:58:00 --> Total execution time: 0.1000
INFO - 2017-01-11 12:58:03 --> Config Class Initialized
INFO - 2017-01-11 12:58:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:58:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:58:03 --> Utf8 Class Initialized
INFO - 2017-01-11 12:58:03 --> URI Class Initialized
INFO - 2017-01-11 12:58:03 --> Router Class Initialized
INFO - 2017-01-11 12:58:03 --> Output Class Initialized
INFO - 2017-01-11 12:58:03 --> Security Class Initialized
DEBUG - 2017-01-11 12:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:58:03 --> Input Class Initialized
INFO - 2017-01-11 12:58:03 --> Language Class Initialized
INFO - 2017-01-11 12:58:03 --> Loader Class Initialized
INFO - 2017-01-11 12:58:03 --> Helper loaded: url_helper
INFO - 2017-01-11 12:58:03 --> Helper loaded: language_helper
INFO - 2017-01-11 12:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:58:03 --> Controller Class Initialized
INFO - 2017-01-11 12:58:03 --> Database Driver Class Initialized
INFO - 2017-01-11 12:58:03 --> Model Class Initialized
INFO - 2017-01-11 12:58:03 --> Model Class Initialized
INFO - 2017-01-11 12:58:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:58:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:58:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:58:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:58:03 --> Final output sent to browser
DEBUG - 2017-01-11 12:58:03 --> Total execution time: 0.1258
INFO - 2017-01-11 12:58:07 --> Config Class Initialized
INFO - 2017-01-11 12:58:07 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:58:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:58:07 --> Utf8 Class Initialized
INFO - 2017-01-11 12:58:07 --> URI Class Initialized
INFO - 2017-01-11 12:58:07 --> Router Class Initialized
INFO - 2017-01-11 12:58:07 --> Output Class Initialized
INFO - 2017-01-11 12:58:07 --> Security Class Initialized
DEBUG - 2017-01-11 12:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:58:07 --> Input Class Initialized
INFO - 2017-01-11 12:58:07 --> Language Class Initialized
INFO - 2017-01-11 12:58:07 --> Loader Class Initialized
INFO - 2017-01-11 12:58:07 --> Helper loaded: url_helper
INFO - 2017-01-11 12:58:07 --> Helper loaded: language_helper
INFO - 2017-01-11 12:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:58:07 --> Controller Class Initialized
INFO - 2017-01-11 12:58:07 --> Database Driver Class Initialized
INFO - 2017-01-11 12:58:07 --> Model Class Initialized
INFO - 2017-01-11 12:58:07 --> Model Class Initialized
INFO - 2017-01-11 12:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 12:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:58:07 --> Final output sent to browser
DEBUG - 2017-01-11 12:58:07 --> Total execution time: 0.0993
INFO - 2017-01-11 12:58:22 --> Config Class Initialized
INFO - 2017-01-11 12:58:22 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:58:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:58:22 --> Utf8 Class Initialized
INFO - 2017-01-11 12:58:22 --> URI Class Initialized
INFO - 2017-01-11 12:58:22 --> Router Class Initialized
INFO - 2017-01-11 12:58:22 --> Output Class Initialized
INFO - 2017-01-11 12:58:22 --> Security Class Initialized
DEBUG - 2017-01-11 12:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:58:22 --> Input Class Initialized
INFO - 2017-01-11 12:58:22 --> Language Class Initialized
INFO - 2017-01-11 12:58:22 --> Loader Class Initialized
INFO - 2017-01-11 12:58:22 --> Helper loaded: url_helper
INFO - 2017-01-11 12:58:22 --> Helper loaded: language_helper
INFO - 2017-01-11 12:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:58:22 --> Controller Class Initialized
INFO - 2017-01-11 12:58:22 --> Database Driver Class Initialized
INFO - 2017-01-11 12:58:22 --> Model Class Initialized
INFO - 2017-01-11 12:58:22 --> Model Class Initialized
INFO - 2017-01-11 12:58:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:58:22 --> Model Class Initialized
INFO - 2017-01-11 12:58:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:58:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:58:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:58:22 --> Final output sent to browser
DEBUG - 2017-01-11 12:58:22 --> Total execution time: 0.0913
INFO - 2017-01-11 12:58:37 --> Config Class Initialized
INFO - 2017-01-11 12:58:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:58:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:58:37 --> Utf8 Class Initialized
INFO - 2017-01-11 12:58:37 --> URI Class Initialized
INFO - 2017-01-11 12:58:37 --> Router Class Initialized
INFO - 2017-01-11 12:58:37 --> Output Class Initialized
INFO - 2017-01-11 12:58:37 --> Security Class Initialized
DEBUG - 2017-01-11 12:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:58:37 --> Input Class Initialized
INFO - 2017-01-11 12:58:37 --> Language Class Initialized
INFO - 2017-01-11 12:58:37 --> Loader Class Initialized
INFO - 2017-01-11 12:58:37 --> Helper loaded: url_helper
INFO - 2017-01-11 12:58:37 --> Helper loaded: language_helper
INFO - 2017-01-11 12:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:58:37 --> Controller Class Initialized
INFO - 2017-01-11 12:58:38 --> Database Driver Class Initialized
INFO - 2017-01-11 12:58:38 --> Model Class Initialized
INFO - 2017-01-11 12:58:38 --> Model Class Initialized
INFO - 2017-01-11 12:58:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:58:38 --> Helper loaded: form_helper
INFO - 2017-01-11 12:58:38 --> Form Validation Class Initialized
INFO - 2017-01-11 12:58:38 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:59:05 --> Config Class Initialized
INFO - 2017-01-11 12:59:05 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:59:05 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:59:05 --> Utf8 Class Initialized
INFO - 2017-01-11 12:59:05 --> URI Class Initialized
INFO - 2017-01-11 12:59:05 --> Router Class Initialized
INFO - 2017-01-11 12:59:05 --> Output Class Initialized
INFO - 2017-01-11 12:59:05 --> Security Class Initialized
DEBUG - 2017-01-11 12:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:59:05 --> Input Class Initialized
INFO - 2017-01-11 12:59:05 --> Language Class Initialized
INFO - 2017-01-11 12:59:05 --> Loader Class Initialized
INFO - 2017-01-11 12:59:05 --> Helper loaded: url_helper
INFO - 2017-01-11 12:59:05 --> Helper loaded: language_helper
INFO - 2017-01-11 12:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:59:05 --> Controller Class Initialized
INFO - 2017-01-11 12:59:05 --> Database Driver Class Initialized
INFO - 2017-01-11 12:59:05 --> Model Class Initialized
INFO - 2017-01-11 12:59:05 --> Model Class Initialized
INFO - 2017-01-11 12:59:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:59:05 --> Helper loaded: form_helper
INFO - 2017-01-11 12:59:05 --> Form Validation Class Initialized
INFO - 2017-01-11 12:59:05 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 12:59:08 --> Config Class Initialized
INFO - 2017-01-11 12:59:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:59:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:59:08 --> Utf8 Class Initialized
INFO - 2017-01-11 12:59:08 --> URI Class Initialized
INFO - 2017-01-11 12:59:08 --> Router Class Initialized
INFO - 2017-01-11 12:59:08 --> Output Class Initialized
INFO - 2017-01-11 12:59:08 --> Security Class Initialized
DEBUG - 2017-01-11 12:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:59:08 --> Input Class Initialized
INFO - 2017-01-11 12:59:08 --> Language Class Initialized
INFO - 2017-01-11 12:59:08 --> Loader Class Initialized
INFO - 2017-01-11 12:59:08 --> Helper loaded: url_helper
INFO - 2017-01-11 12:59:08 --> Helper loaded: language_helper
INFO - 2017-01-11 12:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:59:08 --> Controller Class Initialized
INFO - 2017-01-11 12:59:08 --> Database Driver Class Initialized
INFO - 2017-01-11 12:59:08 --> Model Class Initialized
INFO - 2017-01-11 12:59:08 --> Model Class Initialized
INFO - 2017-01-11 12:59:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:59:08 --> Model Class Initialized
INFO - 2017-01-11 12:59:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:59:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:59:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:59:08 --> Final output sent to browser
DEBUG - 2017-01-11 12:59:08 --> Total execution time: 0.0903
INFO - 2017-01-11 12:59:10 --> Config Class Initialized
INFO - 2017-01-11 12:59:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:59:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:59:10 --> Utf8 Class Initialized
INFO - 2017-01-11 12:59:10 --> URI Class Initialized
INFO - 2017-01-11 12:59:10 --> Router Class Initialized
INFO - 2017-01-11 12:59:10 --> Output Class Initialized
INFO - 2017-01-11 12:59:10 --> Security Class Initialized
DEBUG - 2017-01-11 12:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:59:10 --> Input Class Initialized
INFO - 2017-01-11 12:59:10 --> Language Class Initialized
INFO - 2017-01-11 12:59:10 --> Loader Class Initialized
INFO - 2017-01-11 12:59:10 --> Helper loaded: url_helper
INFO - 2017-01-11 12:59:10 --> Helper loaded: language_helper
INFO - 2017-01-11 12:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:59:10 --> Controller Class Initialized
INFO - 2017-01-11 12:59:10 --> Database Driver Class Initialized
INFO - 2017-01-11 12:59:10 --> Model Class Initialized
INFO - 2017-01-11 12:59:10 --> Model Class Initialized
INFO - 2017-01-11 12:59:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:59:10 --> Model Class Initialized
INFO - 2017-01-11 12:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 12:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 12:59:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 12:59:10 --> Final output sent to browser
DEBUG - 2017-01-11 12:59:10 --> Total execution time: 0.1278
INFO - 2017-01-11 12:59:16 --> Config Class Initialized
INFO - 2017-01-11 12:59:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 12:59:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 12:59:16 --> Utf8 Class Initialized
INFO - 2017-01-11 12:59:16 --> URI Class Initialized
INFO - 2017-01-11 12:59:16 --> Router Class Initialized
INFO - 2017-01-11 12:59:16 --> Output Class Initialized
INFO - 2017-01-11 12:59:16 --> Security Class Initialized
DEBUG - 2017-01-11 12:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 12:59:16 --> Input Class Initialized
INFO - 2017-01-11 12:59:16 --> Language Class Initialized
INFO - 2017-01-11 12:59:16 --> Loader Class Initialized
INFO - 2017-01-11 12:59:16 --> Helper loaded: url_helper
INFO - 2017-01-11 12:59:16 --> Helper loaded: language_helper
INFO - 2017-01-11 12:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 12:59:16 --> Controller Class Initialized
INFO - 2017-01-11 12:59:16 --> Database Driver Class Initialized
INFO - 2017-01-11 12:59:16 --> Model Class Initialized
INFO - 2017-01-11 12:59:16 --> Model Class Initialized
INFO - 2017-01-11 12:59:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 12:59:16 --> Helper loaded: form_helper
INFO - 2017-01-11 12:59:16 --> Form Validation Class Initialized
INFO - 2017-01-11 12:59:16 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:15 --> Config Class Initialized
INFO - 2017-01-11 13:00:15 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:15 --> URI Class Initialized
INFO - 2017-01-11 13:00:15 --> Router Class Initialized
INFO - 2017-01-11 13:00:15 --> Output Class Initialized
INFO - 2017-01-11 13:00:15 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:15 --> Input Class Initialized
INFO - 2017-01-11 13:00:15 --> Language Class Initialized
INFO - 2017-01-11 13:00:15 --> Loader Class Initialized
INFO - 2017-01-11 13:00:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:15 --> Controller Class Initialized
INFO - 2017-01-11 13:00:15 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:15 --> Model Class Initialized
INFO - 2017-01-11 13:00:15 --> Model Class Initialized
INFO - 2017-01-11 13:00:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:15 --> Helper loaded: form_helper
INFO - 2017-01-11 13:00:15 --> Form Validation Class Initialized
INFO - 2017-01-11 13:00:15 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:15 --> Config Class Initialized
INFO - 2017-01-11 13:00:15 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:15 --> URI Class Initialized
INFO - 2017-01-11 13:00:15 --> Router Class Initialized
INFO - 2017-01-11 13:00:15 --> Output Class Initialized
INFO - 2017-01-11 13:00:15 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:15 --> Input Class Initialized
INFO - 2017-01-11 13:00:15 --> Language Class Initialized
INFO - 2017-01-11 13:00:15 --> Loader Class Initialized
INFO - 2017-01-11 13:00:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:15 --> Controller Class Initialized
INFO - 2017-01-11 13:00:15 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:15 --> Model Class Initialized
INFO - 2017-01-11 13:00:15 --> Model Class Initialized
INFO - 2017-01-11 13:00:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:15 --> Model Class Initialized
INFO - 2017-01-11 13:00:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:15 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:15 --> Total execution time: 0.1086
INFO - 2017-01-11 13:00:21 --> Config Class Initialized
INFO - 2017-01-11 13:00:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:21 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:21 --> URI Class Initialized
INFO - 2017-01-11 13:00:21 --> Router Class Initialized
INFO - 2017-01-11 13:00:21 --> Output Class Initialized
INFO - 2017-01-11 13:00:21 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:21 --> Input Class Initialized
INFO - 2017-01-11 13:00:21 --> Language Class Initialized
INFO - 2017-01-11 13:00:21 --> Loader Class Initialized
INFO - 2017-01-11 13:00:21 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:21 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:21 --> Controller Class Initialized
INFO - 2017-01-11 13:00:21 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:21 --> Model Class Initialized
INFO - 2017-01-11 13:00:21 --> Model Class Initialized
INFO - 2017-01-11 13:00:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:21 --> Helper loaded: form_helper
INFO - 2017-01-11 13:00:21 --> Form Validation Class Initialized
INFO - 2017-01-11 13:00:21 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:21 --> Config Class Initialized
INFO - 2017-01-11 13:00:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:21 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:21 --> URI Class Initialized
INFO - 2017-01-11 13:00:21 --> Router Class Initialized
INFO - 2017-01-11 13:00:21 --> Output Class Initialized
INFO - 2017-01-11 13:00:21 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:21 --> Input Class Initialized
INFO - 2017-01-11 13:00:21 --> Language Class Initialized
INFO - 2017-01-11 13:00:21 --> Loader Class Initialized
INFO - 2017-01-11 13:00:21 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:21 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:21 --> Controller Class Initialized
INFO - 2017-01-11 13:00:21 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:21 --> Model Class Initialized
INFO - 2017-01-11 13:00:21 --> Model Class Initialized
INFO - 2017-01-11 13:00:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:21 --> Model Class Initialized
INFO - 2017-01-11 13:00:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:21 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:21 --> Total execution time: 0.1409
INFO - 2017-01-11 13:00:25 --> Config Class Initialized
INFO - 2017-01-11 13:00:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:25 --> URI Class Initialized
INFO - 2017-01-11 13:00:25 --> Router Class Initialized
INFO - 2017-01-11 13:00:25 --> Output Class Initialized
INFO - 2017-01-11 13:00:25 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:25 --> Input Class Initialized
INFO - 2017-01-11 13:00:25 --> Language Class Initialized
INFO - 2017-01-11 13:00:25 --> Loader Class Initialized
INFO - 2017-01-11 13:00:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:25 --> Controller Class Initialized
INFO - 2017-01-11 13:00:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:25 --> Model Class Initialized
INFO - 2017-01-11 13:00:25 --> Model Class Initialized
INFO - 2017-01-11 13:00:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:25 --> Helper loaded: form_helper
INFO - 2017-01-11 13:00:25 --> Form Validation Class Initialized
INFO - 2017-01-11 13:00:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:25 --> Config Class Initialized
INFO - 2017-01-11 13:00:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:25 --> URI Class Initialized
INFO - 2017-01-11 13:00:25 --> Router Class Initialized
INFO - 2017-01-11 13:00:25 --> Output Class Initialized
INFO - 2017-01-11 13:00:25 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:25 --> Input Class Initialized
INFO - 2017-01-11 13:00:25 --> Language Class Initialized
INFO - 2017-01-11 13:00:25 --> Loader Class Initialized
INFO - 2017-01-11 13:00:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:25 --> Controller Class Initialized
INFO - 2017-01-11 13:00:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:26 --> Model Class Initialized
INFO - 2017-01-11 13:00:26 --> Model Class Initialized
INFO - 2017-01-11 13:00:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:26 --> Model Class Initialized
INFO - 2017-01-11 13:00:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:26 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:26 --> Total execution time: 0.1010
INFO - 2017-01-11 13:00:31 --> Config Class Initialized
INFO - 2017-01-11 13:00:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:31 --> URI Class Initialized
INFO - 2017-01-11 13:00:31 --> Router Class Initialized
INFO - 2017-01-11 13:00:31 --> Output Class Initialized
INFO - 2017-01-11 13:00:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:31 --> Input Class Initialized
INFO - 2017-01-11 13:00:31 --> Language Class Initialized
INFO - 2017-01-11 13:00:31 --> Loader Class Initialized
INFO - 2017-01-11 13:00:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:31 --> Controller Class Initialized
INFO - 2017-01-11 13:00:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:31 --> Model Class Initialized
INFO - 2017-01-11 13:00:31 --> Model Class Initialized
INFO - 2017-01-11 13:00:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:31 --> Helper loaded: form_helper
INFO - 2017-01-11 13:00:31 --> Form Validation Class Initialized
INFO - 2017-01-11 13:00:31 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:31 --> Config Class Initialized
INFO - 2017-01-11 13:00:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:31 --> URI Class Initialized
INFO - 2017-01-11 13:00:31 --> Router Class Initialized
INFO - 2017-01-11 13:00:31 --> Output Class Initialized
INFO - 2017-01-11 13:00:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:31 --> Input Class Initialized
INFO - 2017-01-11 13:00:31 --> Language Class Initialized
INFO - 2017-01-11 13:00:31 --> Loader Class Initialized
INFO - 2017-01-11 13:00:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:31 --> Controller Class Initialized
INFO - 2017-01-11 13:00:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:31 --> Model Class Initialized
INFO - 2017-01-11 13:00:31 --> Model Class Initialized
INFO - 2017-01-11 13:00:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:31 --> Model Class Initialized
INFO - 2017-01-11 13:00:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:31 --> Total execution time: 0.0868
INFO - 2017-01-11 13:00:37 --> Config Class Initialized
INFO - 2017-01-11 13:00:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:37 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:37 --> URI Class Initialized
INFO - 2017-01-11 13:00:37 --> Router Class Initialized
INFO - 2017-01-11 13:00:37 --> Output Class Initialized
INFO - 2017-01-11 13:00:37 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:37 --> Input Class Initialized
INFO - 2017-01-11 13:00:37 --> Language Class Initialized
INFO - 2017-01-11 13:00:37 --> Loader Class Initialized
INFO - 2017-01-11 13:00:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:37 --> Controller Class Initialized
INFO - 2017-01-11 13:00:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:37 --> Model Class Initialized
INFO - 2017-01-11 13:00:37 --> Model Class Initialized
INFO - 2017-01-11 13:00:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:37 --> Helper loaded: form_helper
INFO - 2017-01-11 13:00:37 --> Form Validation Class Initialized
INFO - 2017-01-11 13:00:37 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:37 --> Config Class Initialized
INFO - 2017-01-11 13:00:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:37 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:37 --> URI Class Initialized
INFO - 2017-01-11 13:00:37 --> Router Class Initialized
INFO - 2017-01-11 13:00:37 --> Output Class Initialized
INFO - 2017-01-11 13:00:37 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:37 --> Input Class Initialized
INFO - 2017-01-11 13:00:37 --> Language Class Initialized
INFO - 2017-01-11 13:00:37 --> Loader Class Initialized
INFO - 2017-01-11 13:00:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:37 --> Controller Class Initialized
INFO - 2017-01-11 13:00:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:37 --> Model Class Initialized
INFO - 2017-01-11 13:00:37 --> Model Class Initialized
INFO - 2017-01-11 13:00:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:37 --> Model Class Initialized
INFO - 2017-01-11 13:00:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:37 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:37 --> Total execution time: 0.0876
INFO - 2017-01-11 13:00:41 --> Config Class Initialized
INFO - 2017-01-11 13:00:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:41 --> URI Class Initialized
INFO - 2017-01-11 13:00:41 --> Router Class Initialized
INFO - 2017-01-11 13:00:41 --> Output Class Initialized
INFO - 2017-01-11 13:00:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:41 --> Input Class Initialized
INFO - 2017-01-11 13:00:41 --> Language Class Initialized
INFO - 2017-01-11 13:00:41 --> Loader Class Initialized
INFO - 2017-01-11 13:00:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:41 --> Controller Class Initialized
INFO - 2017-01-11 13:00:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:41 --> Model Class Initialized
INFO - 2017-01-11 13:00:41 --> Model Class Initialized
INFO - 2017-01-11 13:00:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:00:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:41 --> Total execution time: 0.0795
INFO - 2017-01-11 13:00:43 --> Config Class Initialized
INFO - 2017-01-11 13:00:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:43 --> URI Class Initialized
INFO - 2017-01-11 13:00:43 --> Router Class Initialized
INFO - 2017-01-11 13:00:43 --> Output Class Initialized
INFO - 2017-01-11 13:00:43 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:43 --> Input Class Initialized
INFO - 2017-01-11 13:00:43 --> Language Class Initialized
INFO - 2017-01-11 13:00:43 --> Loader Class Initialized
INFO - 2017-01-11 13:00:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:43 --> Controller Class Initialized
INFO - 2017-01-11 13:00:43 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:43 --> Model Class Initialized
INFO - 2017-01-11 13:00:43 --> Model Class Initialized
INFO - 2017-01-11 13:00:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:44 --> Model Class Initialized
INFO - 2017-01-11 13:00:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:44 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:44 --> Total execution time: 0.1506
INFO - 2017-01-11 13:00:47 --> Config Class Initialized
INFO - 2017-01-11 13:00:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:47 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:47 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:47 --> URI Class Initialized
INFO - 2017-01-11 13:00:47 --> Router Class Initialized
INFO - 2017-01-11 13:00:47 --> Output Class Initialized
INFO - 2017-01-11 13:00:47 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:47 --> Input Class Initialized
INFO - 2017-01-11 13:00:47 --> Language Class Initialized
INFO - 2017-01-11 13:00:47 --> Loader Class Initialized
INFO - 2017-01-11 13:00:47 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:47 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:47 --> Controller Class Initialized
INFO - 2017-01-11 13:00:47 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:47 --> Model Class Initialized
INFO - 2017-01-11 13:00:47 --> Model Class Initialized
INFO - 2017-01-11 13:00:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:47 --> Helper loaded: form_helper
INFO - 2017-01-11 13:00:47 --> Form Validation Class Initialized
INFO - 2017-01-11 13:00:47 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:00:47 --> Config Class Initialized
INFO - 2017-01-11 13:00:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:47 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:47 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:47 --> URI Class Initialized
INFO - 2017-01-11 13:00:47 --> Router Class Initialized
INFO - 2017-01-11 13:00:47 --> Output Class Initialized
INFO - 2017-01-11 13:00:47 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:47 --> Input Class Initialized
INFO - 2017-01-11 13:00:47 --> Language Class Initialized
INFO - 2017-01-11 13:00:47 --> Loader Class Initialized
INFO - 2017-01-11 13:00:47 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:47 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:47 --> Controller Class Initialized
INFO - 2017-01-11 13:00:47 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:47 --> Model Class Initialized
INFO - 2017-01-11 13:00:47 --> Model Class Initialized
INFO - 2017-01-11 13:00:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:47 --> Model Class Initialized
INFO - 2017-01-11 13:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:47 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:47 --> Total execution time: 0.0864
INFO - 2017-01-11 13:00:50 --> Config Class Initialized
INFO - 2017-01-11 13:00:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:00:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:00:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:00:50 --> URI Class Initialized
INFO - 2017-01-11 13:00:50 --> Router Class Initialized
INFO - 2017-01-11 13:00:50 --> Output Class Initialized
INFO - 2017-01-11 13:00:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:00:50 --> Input Class Initialized
INFO - 2017-01-11 13:00:50 --> Language Class Initialized
INFO - 2017-01-11 13:00:50 --> Loader Class Initialized
INFO - 2017-01-11 13:00:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:00:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:00:50 --> Controller Class Initialized
INFO - 2017-01-11 13:00:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:00:50 --> Model Class Initialized
INFO - 2017-01-11 13:00:50 --> Model Class Initialized
INFO - 2017-01-11 13:00:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:00:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:00:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:00:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:00:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:00:50 --> Total execution time: 0.0969
INFO - 2017-01-11 13:12:02 --> Config Class Initialized
INFO - 2017-01-11 13:12:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:12:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:12:02 --> Utf8 Class Initialized
INFO - 2017-01-11 13:12:02 --> URI Class Initialized
INFO - 2017-01-11 13:12:02 --> Router Class Initialized
INFO - 2017-01-11 13:12:02 --> Output Class Initialized
INFO - 2017-01-11 13:12:02 --> Security Class Initialized
DEBUG - 2017-01-11 13:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:12:02 --> Input Class Initialized
INFO - 2017-01-11 13:12:02 --> Language Class Initialized
INFO - 2017-01-11 13:12:02 --> Loader Class Initialized
INFO - 2017-01-11 13:12:02 --> Helper loaded: url_helper
INFO - 2017-01-11 13:12:02 --> Helper loaded: language_helper
INFO - 2017-01-11 13:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:12:02 --> Controller Class Initialized
INFO - 2017-01-11 13:12:02 --> Database Driver Class Initialized
INFO - 2017-01-11 13:12:02 --> Model Class Initialized
INFO - 2017-01-11 13:12:02 --> Model Class Initialized
INFO - 2017-01-11 13:12:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:12:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:12:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2017-01-11 13:12:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:12:02 --> Final output sent to browser
DEBUG - 2017-01-11 13:12:02 --> Total execution time: 0.0781
INFO - 2017-01-11 13:13:48 --> Config Class Initialized
INFO - 2017-01-11 13:13:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:13:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:13:48 --> Utf8 Class Initialized
INFO - 2017-01-11 13:13:48 --> URI Class Initialized
INFO - 2017-01-11 13:13:48 --> Router Class Initialized
INFO - 2017-01-11 13:13:48 --> Output Class Initialized
INFO - 2017-01-11 13:13:48 --> Security Class Initialized
DEBUG - 2017-01-11 13:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:13:48 --> Input Class Initialized
INFO - 2017-01-11 13:13:48 --> Language Class Initialized
INFO - 2017-01-11 13:13:48 --> Loader Class Initialized
INFO - 2017-01-11 13:13:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:13:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:13:48 --> Controller Class Initialized
INFO - 2017-01-11 13:13:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:13:48 --> Model Class Initialized
INFO - 2017-01-11 13:13:48 --> Model Class Initialized
INFO - 2017-01-11 13:13:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:13:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:13:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2017-01-11 13:13:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:13:48 --> Final output sent to browser
DEBUG - 2017-01-11 13:13:48 --> Total execution time: 0.1068
INFO - 2017-01-11 13:15:04 --> Config Class Initialized
INFO - 2017-01-11 13:15:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:04 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:04 --> URI Class Initialized
INFO - 2017-01-11 13:15:04 --> Router Class Initialized
INFO - 2017-01-11 13:15:04 --> Output Class Initialized
INFO - 2017-01-11 13:15:04 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:04 --> Input Class Initialized
INFO - 2017-01-11 13:15:04 --> Language Class Initialized
INFO - 2017-01-11 13:15:04 --> Loader Class Initialized
INFO - 2017-01-11 13:15:04 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:04 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:04 --> Controller Class Initialized
INFO - 2017-01-11 13:15:04 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:04 --> Model Class Initialized
INFO - 2017-01-11 13:15:04 --> Model Class Initialized
INFO - 2017-01-11 13:15:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2017-01-11 13:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:04 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:04 --> Total execution time: 0.1054
INFO - 2017-01-11 13:15:23 --> Config Class Initialized
INFO - 2017-01-11 13:15:23 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:23 --> URI Class Initialized
INFO - 2017-01-11 13:15:23 --> Router Class Initialized
INFO - 2017-01-11 13:15:23 --> Output Class Initialized
INFO - 2017-01-11 13:15:23 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:23 --> Input Class Initialized
INFO - 2017-01-11 13:15:23 --> Language Class Initialized
INFO - 2017-01-11 13:15:23 --> Loader Class Initialized
INFO - 2017-01-11 13:15:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:23 --> Controller Class Initialized
INFO - 2017-01-11 13:15:23 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:23 --> Model Class Initialized
INFO - 2017-01-11 13:15:23 --> Model Class Initialized
INFO - 2017-01-11 13:15:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:23 --> Helper loaded: form_helper
INFO - 2017-01-11 13:15:23 --> Form Validation Class Initialized
INFO - 2017-01-11 13:15:23 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:15:23 --> Config Class Initialized
INFO - 2017-01-11 13:15:23 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:23 --> URI Class Initialized
INFO - 2017-01-11 13:15:23 --> Router Class Initialized
INFO - 2017-01-11 13:15:23 --> Output Class Initialized
INFO - 2017-01-11 13:15:23 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:23 --> Input Class Initialized
INFO - 2017-01-11 13:15:23 --> Language Class Initialized
INFO - 2017-01-11 13:15:23 --> Loader Class Initialized
INFO - 2017-01-11 13:15:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:23 --> Controller Class Initialized
INFO - 2017-01-11 13:15:23 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:23 --> Model Class Initialized
INFO - 2017-01-11 13:15:23 --> Model Class Initialized
INFO - 2017-01-11 13:15:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:15:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:23 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:23 --> Total execution time: 0.1206
INFO - 2017-01-11 13:15:29 --> Config Class Initialized
INFO - 2017-01-11 13:15:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:29 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:29 --> URI Class Initialized
INFO - 2017-01-11 13:15:29 --> Router Class Initialized
INFO - 2017-01-11 13:15:29 --> Output Class Initialized
INFO - 2017-01-11 13:15:29 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:29 --> Input Class Initialized
INFO - 2017-01-11 13:15:29 --> Language Class Initialized
INFO - 2017-01-11 13:15:29 --> Loader Class Initialized
INFO - 2017-01-11 13:15:29 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:29 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:29 --> Controller Class Initialized
INFO - 2017-01-11 13:15:29 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:29 --> Model Class Initialized
INFO - 2017-01-11 13:15:29 --> Model Class Initialized
INFO - 2017-01-11 13:15:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:29 --> Model Class Initialized
INFO - 2017-01-11 13:15:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 13:15:29 --> Severity: Notice --> Undefined variable: level_list C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
ERROR - 2017-01-11 13:15:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
INFO - 2017-01-11 13:15:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php
INFO - 2017-01-11 13:15:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:29 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:29 --> Total execution time: 0.1042
INFO - 2017-01-11 13:15:31 --> Config Class Initialized
INFO - 2017-01-11 13:15:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:31 --> URI Class Initialized
INFO - 2017-01-11 13:15:31 --> Router Class Initialized
INFO - 2017-01-11 13:15:31 --> Output Class Initialized
INFO - 2017-01-11 13:15:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:31 --> Input Class Initialized
INFO - 2017-01-11 13:15:31 --> Language Class Initialized
INFO - 2017-01-11 13:15:31 --> Loader Class Initialized
INFO - 2017-01-11 13:15:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:31 --> Controller Class Initialized
INFO - 2017-01-11 13:15:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:31 --> Model Class Initialized
INFO - 2017-01-11 13:15:31 --> Model Class Initialized
INFO - 2017-01-11 13:15:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:31 --> Total execution time: 0.1605
INFO - 2017-01-11 13:15:33 --> Config Class Initialized
INFO - 2017-01-11 13:15:33 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:33 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:33 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:33 --> URI Class Initialized
INFO - 2017-01-11 13:15:33 --> Router Class Initialized
INFO - 2017-01-11 13:15:33 --> Output Class Initialized
INFO - 2017-01-11 13:15:33 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:33 --> Input Class Initialized
INFO - 2017-01-11 13:15:33 --> Language Class Initialized
INFO - 2017-01-11 13:15:33 --> Loader Class Initialized
INFO - 2017-01-11 13:15:33 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:33 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:33 --> Controller Class Initialized
INFO - 2017-01-11 13:15:33 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:33 --> Model Class Initialized
INFO - 2017-01-11 13:15:33 --> Model Class Initialized
INFO - 2017-01-11 13:15:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:15:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:33 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:33 --> Total execution time: 0.0998
INFO - 2017-01-11 13:15:37 --> Config Class Initialized
INFO - 2017-01-11 13:15:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:37 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:37 --> URI Class Initialized
INFO - 2017-01-11 13:15:37 --> Router Class Initialized
INFO - 2017-01-11 13:15:37 --> Output Class Initialized
INFO - 2017-01-11 13:15:37 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:37 --> Input Class Initialized
INFO - 2017-01-11 13:15:37 --> Language Class Initialized
INFO - 2017-01-11 13:15:37 --> Loader Class Initialized
INFO - 2017-01-11 13:15:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:37 --> Controller Class Initialized
INFO - 2017-01-11 13:15:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:37 --> Model Class Initialized
INFO - 2017-01-11 13:15:37 --> Model Class Initialized
INFO - 2017-01-11 13:15:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:37 --> Helper loaded: form_helper
INFO - 2017-01-11 13:15:37 --> Form Validation Class Initialized
INFO - 2017-01-11 13:15:37 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:15:37 --> Config Class Initialized
INFO - 2017-01-11 13:15:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:37 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:37 --> URI Class Initialized
INFO - 2017-01-11 13:15:37 --> Router Class Initialized
INFO - 2017-01-11 13:15:37 --> Output Class Initialized
INFO - 2017-01-11 13:15:37 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:37 --> Input Class Initialized
INFO - 2017-01-11 13:15:37 --> Language Class Initialized
INFO - 2017-01-11 13:15:37 --> Loader Class Initialized
INFO - 2017-01-11 13:15:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:37 --> Controller Class Initialized
INFO - 2017-01-11 13:15:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:37 --> Model Class Initialized
INFO - 2017-01-11 13:15:37 --> Model Class Initialized
INFO - 2017-01-11 13:15:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:15:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:37 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:37 --> Total execution time: 0.0968
INFO - 2017-01-11 13:15:41 --> Config Class Initialized
INFO - 2017-01-11 13:15:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:41 --> URI Class Initialized
INFO - 2017-01-11 13:15:41 --> Router Class Initialized
INFO - 2017-01-11 13:15:41 --> Output Class Initialized
INFO - 2017-01-11 13:15:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:41 --> Input Class Initialized
INFO - 2017-01-11 13:15:41 --> Language Class Initialized
INFO - 2017-01-11 13:15:41 --> Loader Class Initialized
INFO - 2017-01-11 13:15:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:41 --> Controller Class Initialized
INFO - 2017-01-11 13:15:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:41 --> Model Class Initialized
INFO - 2017-01-11 13:15:41 --> Model Class Initialized
INFO - 2017-01-11 13:15:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:15:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:41 --> Total execution time: 0.0888
INFO - 2017-01-11 13:15:44 --> Config Class Initialized
INFO - 2017-01-11 13:15:44 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:44 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:44 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:44 --> URI Class Initialized
INFO - 2017-01-11 13:15:44 --> Router Class Initialized
INFO - 2017-01-11 13:15:44 --> Output Class Initialized
INFO - 2017-01-11 13:15:44 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:44 --> Input Class Initialized
INFO - 2017-01-11 13:15:44 --> Language Class Initialized
INFO - 2017-01-11 13:15:44 --> Loader Class Initialized
INFO - 2017-01-11 13:15:44 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:44 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:44 --> Controller Class Initialized
INFO - 2017-01-11 13:15:44 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:44 --> Model Class Initialized
INFO - 2017-01-11 13:15:44 --> Model Class Initialized
INFO - 2017-01-11 13:15:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:15:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:44 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:44 --> Total execution time: 0.0803
INFO - 2017-01-11 13:15:48 --> Config Class Initialized
INFO - 2017-01-11 13:15:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:48 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:48 --> URI Class Initialized
INFO - 2017-01-11 13:15:48 --> Router Class Initialized
INFO - 2017-01-11 13:15:48 --> Output Class Initialized
INFO - 2017-01-11 13:15:48 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:48 --> Input Class Initialized
INFO - 2017-01-11 13:15:48 --> Language Class Initialized
INFO - 2017-01-11 13:15:48 --> Loader Class Initialized
INFO - 2017-01-11 13:15:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:48 --> Controller Class Initialized
INFO - 2017-01-11 13:15:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:48 --> Model Class Initialized
INFO - 2017-01-11 13:15:48 --> Model Class Initialized
INFO - 2017-01-11 13:15:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:48 --> Helper loaded: form_helper
INFO - 2017-01-11 13:15:48 --> Form Validation Class Initialized
INFO - 2017-01-11 13:15:48 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:15:48 --> Config Class Initialized
INFO - 2017-01-11 13:15:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:48 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:48 --> URI Class Initialized
INFO - 2017-01-11 13:15:48 --> Router Class Initialized
INFO - 2017-01-11 13:15:48 --> Output Class Initialized
INFO - 2017-01-11 13:15:48 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:48 --> Input Class Initialized
INFO - 2017-01-11 13:15:48 --> Language Class Initialized
INFO - 2017-01-11 13:15:48 --> Loader Class Initialized
INFO - 2017-01-11 13:15:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:48 --> Controller Class Initialized
INFO - 2017-01-11 13:15:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:48 --> Model Class Initialized
INFO - 2017-01-11 13:15:48 --> Model Class Initialized
INFO - 2017-01-11 13:15:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:15:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:48 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:48 --> Total execution time: 0.0852
INFO - 2017-01-11 13:15:51 --> Config Class Initialized
INFO - 2017-01-11 13:15:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:51 --> URI Class Initialized
INFO - 2017-01-11 13:15:51 --> Router Class Initialized
INFO - 2017-01-11 13:15:51 --> Output Class Initialized
INFO - 2017-01-11 13:15:51 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:51 --> Input Class Initialized
INFO - 2017-01-11 13:15:51 --> Language Class Initialized
INFO - 2017-01-11 13:15:51 --> Loader Class Initialized
INFO - 2017-01-11 13:15:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:51 --> Controller Class Initialized
INFO - 2017-01-11 13:15:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:51 --> Model Class Initialized
INFO - 2017-01-11 13:15:51 --> Model Class Initialized
INFO - 2017-01-11 13:15:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:15:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:51 --> Total execution time: 0.0994
INFO - 2017-01-11 13:15:56 --> Config Class Initialized
INFO - 2017-01-11 13:15:56 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:56 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:56 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:56 --> URI Class Initialized
INFO - 2017-01-11 13:15:56 --> Router Class Initialized
INFO - 2017-01-11 13:15:56 --> Output Class Initialized
INFO - 2017-01-11 13:15:56 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:56 --> Input Class Initialized
INFO - 2017-01-11 13:15:56 --> Language Class Initialized
INFO - 2017-01-11 13:15:56 --> Loader Class Initialized
INFO - 2017-01-11 13:15:56 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:56 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:56 --> Controller Class Initialized
INFO - 2017-01-11 13:15:56 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:56 --> Model Class Initialized
INFO - 2017-01-11 13:15:56 --> Model Class Initialized
INFO - 2017-01-11 13:15:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:56 --> Config Class Initialized
INFO - 2017-01-11 13:15:56 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:15:56 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:15:56 --> Utf8 Class Initialized
INFO - 2017-01-11 13:15:56 --> URI Class Initialized
INFO - 2017-01-11 13:15:56 --> Router Class Initialized
INFO - 2017-01-11 13:15:56 --> Output Class Initialized
INFO - 2017-01-11 13:15:56 --> Security Class Initialized
DEBUG - 2017-01-11 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:15:56 --> Input Class Initialized
INFO - 2017-01-11 13:15:56 --> Language Class Initialized
INFO - 2017-01-11 13:15:56 --> Loader Class Initialized
INFO - 2017-01-11 13:15:56 --> Helper loaded: url_helper
INFO - 2017-01-11 13:15:56 --> Helper loaded: language_helper
INFO - 2017-01-11 13:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:15:56 --> Controller Class Initialized
INFO - 2017-01-11 13:15:56 --> Database Driver Class Initialized
INFO - 2017-01-11 13:15:56 --> Model Class Initialized
INFO - 2017-01-11 13:15:56 --> Model Class Initialized
INFO - 2017-01-11 13:15:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:15:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:15:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:15:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:15:56 --> Final output sent to browser
DEBUG - 2017-01-11 13:15:56 --> Total execution time: 0.0787
INFO - 2017-01-11 13:18:07 --> Config Class Initialized
INFO - 2017-01-11 13:18:07 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:18:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:18:07 --> Utf8 Class Initialized
INFO - 2017-01-11 13:18:07 --> URI Class Initialized
INFO - 2017-01-11 13:18:07 --> Router Class Initialized
INFO - 2017-01-11 13:18:07 --> Output Class Initialized
INFO - 2017-01-11 13:18:07 --> Security Class Initialized
DEBUG - 2017-01-11 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:18:07 --> Input Class Initialized
INFO - 2017-01-11 13:18:07 --> Language Class Initialized
INFO - 2017-01-11 13:18:07 --> Loader Class Initialized
INFO - 2017-01-11 13:18:07 --> Helper loaded: url_helper
INFO - 2017-01-11 13:18:07 --> Helper loaded: language_helper
INFO - 2017-01-11 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:18:07 --> Controller Class Initialized
INFO - 2017-01-11 13:18:07 --> Database Driver Class Initialized
INFO - 2017-01-11 13:18:07 --> Model Class Initialized
INFO - 2017-01-11 13:18:07 --> Model Class Initialized
INFO - 2017-01-11 13:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:18:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:18:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2017-01-11 13:18:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:18:08 --> Final output sent to browser
DEBUG - 2017-01-11 13:18:08 --> Total execution time: 0.1541
INFO - 2017-01-11 13:19:19 --> Config Class Initialized
INFO - 2017-01-11 13:19:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:19:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:19:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:19:19 --> URI Class Initialized
INFO - 2017-01-11 13:19:19 --> Router Class Initialized
INFO - 2017-01-11 13:19:19 --> Output Class Initialized
INFO - 2017-01-11 13:19:19 --> Security Class Initialized
DEBUG - 2017-01-11 13:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:19:19 --> Input Class Initialized
INFO - 2017-01-11 13:19:19 --> Language Class Initialized
INFO - 2017-01-11 13:19:19 --> Loader Class Initialized
INFO - 2017-01-11 13:19:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:19:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:19:19 --> Controller Class Initialized
INFO - 2017-01-11 13:19:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:19:19 --> Model Class Initialized
INFO - 2017-01-11 13:19:19 --> Model Class Initialized
INFO - 2017-01-11 13:19:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:19:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:19:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_quiz.php
INFO - 2017-01-11 13:19:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:19:19 --> Final output sent to browser
DEBUG - 2017-01-11 13:19:19 --> Total execution time: 0.1297
INFO - 2017-01-11 13:19:31 --> Config Class Initialized
INFO - 2017-01-11 13:19:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:19:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:19:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:19:31 --> URI Class Initialized
INFO - 2017-01-11 13:19:31 --> Router Class Initialized
INFO - 2017-01-11 13:19:31 --> Output Class Initialized
INFO - 2017-01-11 13:19:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:19:31 --> Input Class Initialized
INFO - 2017-01-11 13:19:31 --> Language Class Initialized
INFO - 2017-01-11 13:19:31 --> Loader Class Initialized
INFO - 2017-01-11 13:19:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:19:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:19:31 --> Controller Class Initialized
INFO - 2017-01-11 13:19:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:19:31 --> Model Class Initialized
INFO - 2017-01-11 13:19:31 --> Model Class Initialized
INFO - 2017-01-11 13:19:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:19:31 --> Helper loaded: form_helper
INFO - 2017-01-11 13:19:31 --> Form Validation Class Initialized
INFO - 2017-01-11 13:19:31 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:19:31 --> Config Class Initialized
INFO - 2017-01-11 13:19:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:19:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:19:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:19:31 --> URI Class Initialized
INFO - 2017-01-11 13:19:31 --> Router Class Initialized
INFO - 2017-01-11 13:19:31 --> Output Class Initialized
INFO - 2017-01-11 13:19:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:19:31 --> Input Class Initialized
INFO - 2017-01-11 13:19:31 --> Language Class Initialized
INFO - 2017-01-11 13:19:31 --> Loader Class Initialized
INFO - 2017-01-11 13:19:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:19:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:19:31 --> Controller Class Initialized
INFO - 2017-01-11 13:19:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:19:31 --> Model Class Initialized
INFO - 2017-01-11 13:19:31 --> Model Class Initialized
INFO - 2017-01-11 13:19:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:19:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:19:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:19:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:19:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:19:31 --> Total execution time: 0.1191
INFO - 2017-01-11 13:20:22 --> Config Class Initialized
INFO - 2017-01-11 13:20:22 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:22 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:22 --> URI Class Initialized
INFO - 2017-01-11 13:20:22 --> Router Class Initialized
INFO - 2017-01-11 13:20:22 --> Output Class Initialized
INFO - 2017-01-11 13:20:22 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:22 --> Input Class Initialized
INFO - 2017-01-11 13:20:22 --> Language Class Initialized
INFO - 2017-01-11 13:20:23 --> Loader Class Initialized
INFO - 2017-01-11 13:20:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:23 --> Controller Class Initialized
INFO - 2017-01-11 13:20:23 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:23 --> Model Class Initialized
INFO - 2017-01-11 13:20:23 --> Model Class Initialized
INFO - 2017-01-11 13:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:23 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:23 --> Total execution time: 0.1011
INFO - 2017-01-11 13:20:27 --> Config Class Initialized
INFO - 2017-01-11 13:20:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:27 --> URI Class Initialized
INFO - 2017-01-11 13:20:27 --> Router Class Initialized
INFO - 2017-01-11 13:20:27 --> Output Class Initialized
INFO - 2017-01-11 13:20:27 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:27 --> Input Class Initialized
INFO - 2017-01-11 13:20:27 --> Language Class Initialized
INFO - 2017-01-11 13:20:27 --> Loader Class Initialized
INFO - 2017-01-11 13:20:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:27 --> Controller Class Initialized
INFO - 2017-01-11 13:20:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:28 --> Model Class Initialized
INFO - 2017-01-11 13:20:28 --> Model Class Initialized
INFO - 2017-01-11 13:20:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:28 --> Model Class Initialized
INFO - 2017-01-11 13:20:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 13:20:28 --> Severity: Notice --> Undefined variable: level_list C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
ERROR - 2017-01-11 13:20:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php 43
INFO - 2017-01-11 13:20:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\add_question_into_quiz.php
INFO - 2017-01-11 13:20:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:28 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:28 --> Total execution time: 0.1063
INFO - 2017-01-11 13:20:30 --> Config Class Initialized
INFO - 2017-01-11 13:20:30 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:30 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:30 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:30 --> URI Class Initialized
INFO - 2017-01-11 13:20:30 --> Router Class Initialized
INFO - 2017-01-11 13:20:30 --> Output Class Initialized
INFO - 2017-01-11 13:20:30 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:30 --> Input Class Initialized
INFO - 2017-01-11 13:20:30 --> Language Class Initialized
INFO - 2017-01-11 13:20:30 --> Loader Class Initialized
INFO - 2017-01-11 13:20:30 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:30 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:30 --> Controller Class Initialized
INFO - 2017-01-11 13:20:30 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:30 --> Model Class Initialized
INFO - 2017-01-11 13:20:30 --> Model Class Initialized
INFO - 2017-01-11 13:20:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:30 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:30 --> Total execution time: 0.0974
INFO - 2017-01-11 13:20:31 --> Config Class Initialized
INFO - 2017-01-11 13:20:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:31 --> URI Class Initialized
INFO - 2017-01-11 13:20:31 --> Router Class Initialized
INFO - 2017-01-11 13:20:31 --> Output Class Initialized
INFO - 2017-01-11 13:20:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:31 --> Input Class Initialized
INFO - 2017-01-11 13:20:31 --> Language Class Initialized
INFO - 2017-01-11 13:20:31 --> Loader Class Initialized
INFO - 2017-01-11 13:20:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:31 --> Controller Class Initialized
INFO - 2017-01-11 13:20:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:31 --> Model Class Initialized
INFO - 2017-01-11 13:20:31 --> Model Class Initialized
INFO - 2017-01-11 13:20:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:20:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:20:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:31 --> Total execution time: 0.0967
INFO - 2017-01-11 13:20:35 --> Config Class Initialized
INFO - 2017-01-11 13:20:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:35 --> URI Class Initialized
INFO - 2017-01-11 13:20:35 --> Router Class Initialized
INFO - 2017-01-11 13:20:35 --> Output Class Initialized
INFO - 2017-01-11 13:20:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:35 --> Input Class Initialized
INFO - 2017-01-11 13:20:35 --> Language Class Initialized
INFO - 2017-01-11 13:20:35 --> Loader Class Initialized
INFO - 2017-01-11 13:20:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:35 --> Controller Class Initialized
INFO - 2017-01-11 13:20:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:35 --> Model Class Initialized
INFO - 2017-01-11 13:20:35 --> Model Class Initialized
INFO - 2017-01-11 13:20:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:35 --> Helper loaded: form_helper
INFO - 2017-01-11 13:20:35 --> Form Validation Class Initialized
INFO - 2017-01-11 13:20:35 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:20:35 --> Config Class Initialized
INFO - 2017-01-11 13:20:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:35 --> URI Class Initialized
INFO - 2017-01-11 13:20:35 --> Router Class Initialized
INFO - 2017-01-11 13:20:35 --> Output Class Initialized
INFO - 2017-01-11 13:20:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:35 --> Input Class Initialized
INFO - 2017-01-11 13:20:35 --> Language Class Initialized
INFO - 2017-01-11 13:20:35 --> Loader Class Initialized
INFO - 2017-01-11 13:20:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:35 --> Controller Class Initialized
INFO - 2017-01-11 13:20:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:35 --> Model Class Initialized
INFO - 2017-01-11 13:20:35 --> Model Class Initialized
INFO - 2017-01-11 13:20:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:35 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:35 --> Total execution time: 0.0914
INFO - 2017-01-11 13:20:43 --> Config Class Initialized
INFO - 2017-01-11 13:20:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:43 --> URI Class Initialized
INFO - 2017-01-11 13:20:43 --> Router Class Initialized
INFO - 2017-01-11 13:20:43 --> Output Class Initialized
INFO - 2017-01-11 13:20:43 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:43 --> Input Class Initialized
INFO - 2017-01-11 13:20:43 --> Language Class Initialized
INFO - 2017-01-11 13:20:43 --> Loader Class Initialized
INFO - 2017-01-11 13:20:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:43 --> Controller Class Initialized
INFO - 2017-01-11 13:20:43 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:43 --> Model Class Initialized
INFO - 2017-01-11 13:20:43 --> Model Class Initialized
INFO - 2017-01-11 13:20:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:43 --> Helper loaded: form_helper
INFO - 2017-01-11 13:20:43 --> Form Validation Class Initialized
INFO - 2017-01-11 13:20:43 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:20:43 --> Config Class Initialized
INFO - 2017-01-11 13:20:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:43 --> URI Class Initialized
INFO - 2017-01-11 13:20:43 --> Router Class Initialized
INFO - 2017-01-11 13:20:43 --> Output Class Initialized
INFO - 2017-01-11 13:20:43 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:43 --> Input Class Initialized
INFO - 2017-01-11 13:20:43 --> Language Class Initialized
INFO - 2017-01-11 13:20:43 --> Loader Class Initialized
INFO - 2017-01-11 13:20:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:44 --> Controller Class Initialized
INFO - 2017-01-11 13:20:44 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:44 --> Model Class Initialized
INFO - 2017-01-11 13:20:44 --> Model Class Initialized
INFO - 2017-01-11 13:20:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:20:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:44 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:44 --> Total execution time: 0.0998
INFO - 2017-01-11 13:20:46 --> Config Class Initialized
INFO - 2017-01-11 13:20:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:46 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:46 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:46 --> URI Class Initialized
INFO - 2017-01-11 13:20:46 --> Router Class Initialized
INFO - 2017-01-11 13:20:46 --> Output Class Initialized
INFO - 2017-01-11 13:20:46 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:46 --> Input Class Initialized
INFO - 2017-01-11 13:20:46 --> Language Class Initialized
INFO - 2017-01-11 13:20:46 --> Loader Class Initialized
INFO - 2017-01-11 13:20:46 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:46 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:46 --> Controller Class Initialized
INFO - 2017-01-11 13:20:46 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:46 --> Model Class Initialized
INFO - 2017-01-11 13:20:47 --> Model Class Initialized
INFO - 2017-01-11 13:20:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:47 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:47 --> Total execution time: 0.0922
INFO - 2017-01-11 13:20:58 --> Config Class Initialized
INFO - 2017-01-11 13:20:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:58 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:58 --> URI Class Initialized
INFO - 2017-01-11 13:20:58 --> Router Class Initialized
INFO - 2017-01-11 13:20:58 --> Output Class Initialized
INFO - 2017-01-11 13:20:58 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:58 --> Input Class Initialized
INFO - 2017-01-11 13:20:58 --> Language Class Initialized
INFO - 2017-01-11 13:20:58 --> Loader Class Initialized
INFO - 2017-01-11 13:20:58 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:58 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:58 --> Controller Class Initialized
INFO - 2017-01-11 13:20:58 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:58 --> Model Class Initialized
INFO - 2017-01-11 13:20:58 --> Model Class Initialized
INFO - 2017-01-11 13:20:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:58 --> Config Class Initialized
INFO - 2017-01-11 13:20:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:20:59 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:20:59 --> Utf8 Class Initialized
INFO - 2017-01-11 13:20:59 --> URI Class Initialized
INFO - 2017-01-11 13:20:59 --> Router Class Initialized
INFO - 2017-01-11 13:20:59 --> Output Class Initialized
INFO - 2017-01-11 13:20:59 --> Security Class Initialized
DEBUG - 2017-01-11 13:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:20:59 --> Input Class Initialized
INFO - 2017-01-11 13:20:59 --> Language Class Initialized
INFO - 2017-01-11 13:20:59 --> Loader Class Initialized
INFO - 2017-01-11 13:20:59 --> Helper loaded: url_helper
INFO - 2017-01-11 13:20:59 --> Helper loaded: language_helper
INFO - 2017-01-11 13:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:20:59 --> Controller Class Initialized
INFO - 2017-01-11 13:20:59 --> Database Driver Class Initialized
INFO - 2017-01-11 13:20:59 --> Model Class Initialized
INFO - 2017-01-11 13:20:59 --> Model Class Initialized
INFO - 2017-01-11 13:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:20:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:20:59 --> Final output sent to browser
DEBUG - 2017-01-11 13:20:59 --> Total execution time: 0.0738
INFO - 2017-01-11 13:26:37 --> Config Class Initialized
INFO - 2017-01-11 13:26:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:26:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:26:37 --> Utf8 Class Initialized
INFO - 2017-01-11 13:26:37 --> URI Class Initialized
INFO - 2017-01-11 13:26:37 --> Router Class Initialized
INFO - 2017-01-11 13:26:37 --> Output Class Initialized
INFO - 2017-01-11 13:26:37 --> Security Class Initialized
DEBUG - 2017-01-11 13:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:26:37 --> Input Class Initialized
INFO - 2017-01-11 13:26:37 --> Language Class Initialized
INFO - 2017-01-11 13:26:37 --> Loader Class Initialized
INFO - 2017-01-11 13:26:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:26:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:26:37 --> Controller Class Initialized
INFO - 2017-01-11 13:26:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:26:37 --> Model Class Initialized
INFO - 2017-01-11 13:26:37 --> Model Class Initialized
INFO - 2017-01-11 13:26:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:26:37 --> Final output sent to browser
DEBUG - 2017-01-11 13:26:37 --> Total execution time: 0.1172
INFO - 2017-01-11 13:31:15 --> Config Class Initialized
INFO - 2017-01-11 13:31:15 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:31:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:31:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:31:15 --> URI Class Initialized
INFO - 2017-01-11 13:31:15 --> Router Class Initialized
INFO - 2017-01-11 13:31:15 --> Output Class Initialized
INFO - 2017-01-11 13:31:15 --> Security Class Initialized
DEBUG - 2017-01-11 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:31:15 --> Input Class Initialized
INFO - 2017-01-11 13:31:15 --> Language Class Initialized
INFO - 2017-01-11 13:31:15 --> Loader Class Initialized
INFO - 2017-01-11 13:31:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:31:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:31:16 --> Controller Class Initialized
INFO - 2017-01-11 13:31:16 --> Database Driver Class Initialized
INFO - 2017-01-11 13:31:16 --> Model Class Initialized
INFO - 2017-01-11 13:31:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:31:16 --> Helper loaded: form_helper
INFO - 2017-01-11 13:31:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 13:31:16 --> Could not find the language line "import_user"
INFO - 2017-01-11 13:31:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-11 13:31:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:31:16 --> Final output sent to browser
DEBUG - 2017-01-11 13:31:16 --> Total execution time: 0.1428
INFO - 2017-01-11 13:31:19 --> Config Class Initialized
INFO - 2017-01-11 13:31:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:31:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:31:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:31:19 --> URI Class Initialized
INFO - 2017-01-11 13:31:19 --> Router Class Initialized
INFO - 2017-01-11 13:31:19 --> Output Class Initialized
INFO - 2017-01-11 13:31:19 --> Security Class Initialized
DEBUG - 2017-01-11 13:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:31:19 --> Input Class Initialized
INFO - 2017-01-11 13:31:19 --> Language Class Initialized
INFO - 2017-01-11 13:31:19 --> Loader Class Initialized
INFO - 2017-01-11 13:31:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:31:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:31:19 --> Controller Class Initialized
INFO - 2017-01-11 13:31:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:31:19 --> Model Class Initialized
INFO - 2017-01-11 13:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:31:19 --> Config Class Initialized
INFO - 2017-01-11 13:31:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:31:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:31:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:31:19 --> URI Class Initialized
INFO - 2017-01-11 13:31:19 --> Router Class Initialized
INFO - 2017-01-11 13:31:19 --> Output Class Initialized
INFO - 2017-01-11 13:31:19 --> Security Class Initialized
DEBUG - 2017-01-11 13:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:31:19 --> Input Class Initialized
INFO - 2017-01-11 13:31:19 --> Language Class Initialized
INFO - 2017-01-11 13:31:19 --> Loader Class Initialized
INFO - 2017-01-11 13:31:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:31:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:31:19 --> Controller Class Initialized
INFO - 2017-01-11 13:31:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:31:19 --> Model Class Initialized
INFO - 2017-01-11 13:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:31:19 --> Final output sent to browser
DEBUG - 2017-01-11 13:31:19 --> Total execution time: 0.0767
INFO - 2017-01-11 13:31:24 --> Config Class Initialized
INFO - 2017-01-11 13:31:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:31:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:31:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:31:24 --> URI Class Initialized
INFO - 2017-01-11 13:31:24 --> Router Class Initialized
INFO - 2017-01-11 13:31:24 --> Output Class Initialized
INFO - 2017-01-11 13:31:24 --> Security Class Initialized
DEBUG - 2017-01-11 13:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:31:24 --> Input Class Initialized
INFO - 2017-01-11 13:31:24 --> Language Class Initialized
INFO - 2017-01-11 13:31:24 --> Loader Class Initialized
INFO - 2017-01-11 13:31:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:31:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:31:25 --> Controller Class Initialized
INFO - 2017-01-11 13:31:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:31:25 --> Model Class Initialized
INFO - 2017-01-11 13:31:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:31:25 --> Config Class Initialized
INFO - 2017-01-11 13:31:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:31:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:31:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:31:25 --> URI Class Initialized
INFO - 2017-01-11 13:31:25 --> Router Class Initialized
INFO - 2017-01-11 13:31:25 --> Output Class Initialized
INFO - 2017-01-11 13:31:25 --> Security Class Initialized
DEBUG - 2017-01-11 13:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:31:25 --> Input Class Initialized
INFO - 2017-01-11 13:31:25 --> Language Class Initialized
INFO - 2017-01-11 13:31:25 --> Loader Class Initialized
INFO - 2017-01-11 13:31:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:31:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:31:25 --> Controller Class Initialized
INFO - 2017-01-11 13:31:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:31:25 --> Model Class Initialized
INFO - 2017-01-11 13:31:25 --> Model Class Initialized
INFO - 2017-01-11 13:31:25 --> Model Class Initialized
INFO - 2017-01-11 13:31:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:31:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:31:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-11 13:31:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:31:25 --> Final output sent to browser
DEBUG - 2017-01-11 13:31:25 --> Total execution time: 0.0910
INFO - 2017-01-11 13:32:08 --> Config Class Initialized
INFO - 2017-01-11 13:32:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:08 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:08 --> URI Class Initialized
INFO - 2017-01-11 13:32:08 --> Router Class Initialized
INFO - 2017-01-11 13:32:08 --> Output Class Initialized
INFO - 2017-01-11 13:32:08 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:08 --> Input Class Initialized
INFO - 2017-01-11 13:32:08 --> Language Class Initialized
INFO - 2017-01-11 13:32:08 --> Loader Class Initialized
INFO - 2017-01-11 13:32:08 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:08 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:08 --> Controller Class Initialized
INFO - 2017-01-11 13:32:08 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:08 --> Model Class Initialized
INFO - 2017-01-11 13:32:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:08 --> Config Class Initialized
INFO - 2017-01-11 13:32:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:08 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:08 --> URI Class Initialized
INFO - 2017-01-11 13:32:08 --> Router Class Initialized
INFO - 2017-01-11 13:32:08 --> Output Class Initialized
INFO - 2017-01-11 13:32:08 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:08 --> Input Class Initialized
INFO - 2017-01-11 13:32:08 --> Language Class Initialized
INFO - 2017-01-11 13:32:08 --> Loader Class Initialized
INFO - 2017-01-11 13:32:08 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:08 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:08 --> Controller Class Initialized
INFO - 2017-01-11 13:32:08 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:08 --> Model Class Initialized
INFO - 2017-01-11 13:32:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:32:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:32:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:32:08 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:08 --> Total execution time: 0.0787
INFO - 2017-01-11 13:32:14 --> Config Class Initialized
INFO - 2017-01-11 13:32:14 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:14 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:14 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:14 --> URI Class Initialized
INFO - 2017-01-11 13:32:14 --> Router Class Initialized
INFO - 2017-01-11 13:32:14 --> Output Class Initialized
INFO - 2017-01-11 13:32:14 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:14 --> Input Class Initialized
INFO - 2017-01-11 13:32:14 --> Language Class Initialized
INFO - 2017-01-11 13:32:14 --> Loader Class Initialized
INFO - 2017-01-11 13:32:14 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:14 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:14 --> Controller Class Initialized
INFO - 2017-01-11 13:32:14 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:14 --> Model Class Initialized
INFO - 2017-01-11 13:32:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:14 --> Config Class Initialized
INFO - 2017-01-11 13:32:14 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:14 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:14 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:14 --> URI Class Initialized
INFO - 2017-01-11 13:32:14 --> Router Class Initialized
INFO - 2017-01-11 13:32:14 --> Output Class Initialized
INFO - 2017-01-11 13:32:14 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:14 --> Input Class Initialized
INFO - 2017-01-11 13:32:15 --> Language Class Initialized
INFO - 2017-01-11 13:32:15 --> Loader Class Initialized
INFO - 2017-01-11 13:32:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:15 --> Controller Class Initialized
INFO - 2017-01-11 13:32:15 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:15 --> Model Class Initialized
INFO - 2017-01-11 13:32:15 --> Model Class Initialized
INFO - 2017-01-11 13:32:15 --> Model Class Initialized
INFO - 2017-01-11 13:32:15 --> Model Class Initialized
INFO - 2017-01-11 13:32:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:32:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 13:32:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:32:15 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:15 --> Total execution time: 0.0807
INFO - 2017-01-11 13:32:24 --> Config Class Initialized
INFO - 2017-01-11 13:32:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:24 --> URI Class Initialized
INFO - 2017-01-11 13:32:24 --> Router Class Initialized
INFO - 2017-01-11 13:32:24 --> Output Class Initialized
INFO - 2017-01-11 13:32:24 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:24 --> Input Class Initialized
INFO - 2017-01-11 13:32:24 --> Language Class Initialized
INFO - 2017-01-11 13:32:24 --> Loader Class Initialized
INFO - 2017-01-11 13:32:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:24 --> Controller Class Initialized
INFO - 2017-01-11 13:32:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:24 --> Model Class Initialized
INFO - 2017-01-11 13:32:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:24 --> Config Class Initialized
INFO - 2017-01-11 13:32:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:24 --> URI Class Initialized
INFO - 2017-01-11 13:32:24 --> Router Class Initialized
INFO - 2017-01-11 13:32:24 --> Output Class Initialized
INFO - 2017-01-11 13:32:24 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:24 --> Input Class Initialized
INFO - 2017-01-11 13:32:24 --> Language Class Initialized
INFO - 2017-01-11 13:32:24 --> Loader Class Initialized
INFO - 2017-01-11 13:32:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:24 --> Controller Class Initialized
INFO - 2017-01-11 13:32:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:24 --> Model Class Initialized
INFO - 2017-01-11 13:32:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:32:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:32:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:32:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:24 --> Total execution time: 0.0639
INFO - 2017-01-11 13:32:30 --> Config Class Initialized
INFO - 2017-01-11 13:32:30 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:30 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:30 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:30 --> URI Class Initialized
INFO - 2017-01-11 13:32:30 --> Router Class Initialized
INFO - 2017-01-11 13:32:30 --> Output Class Initialized
INFO - 2017-01-11 13:32:30 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:30 --> Input Class Initialized
INFO - 2017-01-11 13:32:30 --> Language Class Initialized
INFO - 2017-01-11 13:32:30 --> Loader Class Initialized
INFO - 2017-01-11 13:32:30 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:30 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:30 --> Controller Class Initialized
INFO - 2017-01-11 13:32:30 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:30 --> Model Class Initialized
INFO - 2017-01-11 13:32:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:30 --> Config Class Initialized
INFO - 2017-01-11 13:32:30 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:30 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:30 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:30 --> URI Class Initialized
INFO - 2017-01-11 13:32:30 --> Router Class Initialized
INFO - 2017-01-11 13:32:30 --> Output Class Initialized
INFO - 2017-01-11 13:32:30 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:30 --> Input Class Initialized
INFO - 2017-01-11 13:32:30 --> Language Class Initialized
INFO - 2017-01-11 13:32:30 --> Loader Class Initialized
INFO - 2017-01-11 13:32:30 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:30 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:30 --> Controller Class Initialized
INFO - 2017-01-11 13:32:30 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:30 --> Model Class Initialized
INFO - 2017-01-11 13:32:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:32:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:32:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:32:30 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:30 --> Total execution time: 0.1275
INFO - 2017-01-11 13:32:35 --> Config Class Initialized
INFO - 2017-01-11 13:32:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:35 --> URI Class Initialized
INFO - 2017-01-11 13:32:35 --> Router Class Initialized
INFO - 2017-01-11 13:32:35 --> Output Class Initialized
INFO - 2017-01-11 13:32:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:35 --> Input Class Initialized
INFO - 2017-01-11 13:32:35 --> Language Class Initialized
INFO - 2017-01-11 13:32:35 --> Loader Class Initialized
INFO - 2017-01-11 13:32:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:35 --> Controller Class Initialized
INFO - 2017-01-11 13:32:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:35 --> Model Class Initialized
INFO - 2017-01-11 13:32:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:35 --> Config Class Initialized
INFO - 2017-01-11 13:32:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:35 --> URI Class Initialized
INFO - 2017-01-11 13:32:35 --> Router Class Initialized
INFO - 2017-01-11 13:32:35 --> Output Class Initialized
INFO - 2017-01-11 13:32:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:35 --> Input Class Initialized
INFO - 2017-01-11 13:32:35 --> Language Class Initialized
INFO - 2017-01-11 13:32:35 --> Loader Class Initialized
INFO - 2017-01-11 13:32:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:35 --> Controller Class Initialized
INFO - 2017-01-11 13:32:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:35 --> Model Class Initialized
INFO - 2017-01-11 13:32:35 --> Model Class Initialized
INFO - 2017-01-11 13:32:35 --> Model Class Initialized
INFO - 2017-01-11 13:32:35 --> Model Class Initialized
INFO - 2017-01-11 13:32:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:32:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 13:32:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:32:35 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:35 --> Total execution time: 0.0882
INFO - 2017-01-11 13:32:40 --> Config Class Initialized
INFO - 2017-01-11 13:32:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:40 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:40 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:40 --> URI Class Initialized
INFO - 2017-01-11 13:32:40 --> Router Class Initialized
INFO - 2017-01-11 13:32:40 --> Output Class Initialized
INFO - 2017-01-11 13:32:40 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:40 --> Input Class Initialized
INFO - 2017-01-11 13:32:40 --> Language Class Initialized
INFO - 2017-01-11 13:32:40 --> Loader Class Initialized
INFO - 2017-01-11 13:32:40 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:40 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:40 --> Controller Class Initialized
INFO - 2017-01-11 13:32:40 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:40 --> Model Class Initialized
INFO - 2017-01-11 13:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:40 --> Helper loaded: form_helper
INFO - 2017-01-11 13:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 13:32:40 --> Could not find the language line "import_user"
INFO - 2017-01-11 13:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-11 13:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:32:40 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:40 --> Total execution time: 0.1717
INFO - 2017-01-11 13:32:42 --> Config Class Initialized
INFO - 2017-01-11 13:32:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:42 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:42 --> URI Class Initialized
INFO - 2017-01-11 13:32:42 --> Router Class Initialized
INFO - 2017-01-11 13:32:42 --> Output Class Initialized
INFO - 2017-01-11 13:32:42 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:42 --> Input Class Initialized
INFO - 2017-01-11 13:32:42 --> Language Class Initialized
INFO - 2017-01-11 13:32:42 --> Loader Class Initialized
INFO - 2017-01-11 13:32:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:42 --> Controller Class Initialized
INFO - 2017-01-11 13:32:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:42 --> Model Class Initialized
INFO - 2017-01-11 13:32:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:42 --> Model Class Initialized
INFO - 2017-01-11 13:32:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:32:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-01-11 13:32:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:32:42 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:42 --> Total execution time: 0.0803
INFO - 2017-01-11 13:32:49 --> Config Class Initialized
INFO - 2017-01-11 13:32:49 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:49 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:49 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:49 --> URI Class Initialized
INFO - 2017-01-11 13:32:49 --> Router Class Initialized
INFO - 2017-01-11 13:32:49 --> Output Class Initialized
INFO - 2017-01-11 13:32:49 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:49 --> Input Class Initialized
INFO - 2017-01-11 13:32:49 --> Language Class Initialized
INFO - 2017-01-11 13:32:49 --> Loader Class Initialized
INFO - 2017-01-11 13:32:49 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:49 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:49 --> Controller Class Initialized
INFO - 2017-01-11 13:32:49 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:49 --> Model Class Initialized
INFO - 2017-01-11 13:32:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:49 --> Helper loaded: form_helper
INFO - 2017-01-11 13:32:49 --> Form Validation Class Initialized
INFO - 2017-01-11 13:32:49 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:32:49 --> Config Class Initialized
INFO - 2017-01-11 13:32:49 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:49 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:49 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:49 --> URI Class Initialized
INFO - 2017-01-11 13:32:49 --> Router Class Initialized
INFO - 2017-01-11 13:32:49 --> Output Class Initialized
INFO - 2017-01-11 13:32:49 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:49 --> Input Class Initialized
INFO - 2017-01-11 13:32:49 --> Language Class Initialized
INFO - 2017-01-11 13:32:49 --> Loader Class Initialized
INFO - 2017-01-11 13:32:49 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:49 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:49 --> Controller Class Initialized
INFO - 2017-01-11 13:32:49 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:49 --> Model Class Initialized
INFO - 2017-01-11 13:32:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:49 --> Model Class Initialized
INFO - 2017-01-11 13:32:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:32:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-01-11 13:32:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:32:49 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:49 --> Total execution time: 0.0976
INFO - 2017-01-11 13:32:51 --> Config Class Initialized
INFO - 2017-01-11 13:32:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:51 --> URI Class Initialized
INFO - 2017-01-11 13:32:51 --> Router Class Initialized
INFO - 2017-01-11 13:32:51 --> Output Class Initialized
INFO - 2017-01-11 13:32:51 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:51 --> Input Class Initialized
INFO - 2017-01-11 13:32:51 --> Language Class Initialized
INFO - 2017-01-11 13:32:51 --> Loader Class Initialized
INFO - 2017-01-11 13:32:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:51 --> Controller Class Initialized
INFO - 2017-01-11 13:32:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:51 --> Model Class Initialized
INFO - 2017-01-11 13:32:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:51 --> Config Class Initialized
INFO - 2017-01-11 13:32:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:51 --> URI Class Initialized
INFO - 2017-01-11 13:32:51 --> Router Class Initialized
INFO - 2017-01-11 13:32:51 --> Output Class Initialized
INFO - 2017-01-11 13:32:51 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:51 --> Input Class Initialized
INFO - 2017-01-11 13:32:51 --> Language Class Initialized
INFO - 2017-01-11 13:32:51 --> Loader Class Initialized
INFO - 2017-01-11 13:32:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:51 --> Controller Class Initialized
INFO - 2017-01-11 13:32:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:51 --> Model Class Initialized
INFO - 2017-01-11 13:32:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:32:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:32:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:32:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:51 --> Total execution time: 0.1393
INFO - 2017-01-11 13:32:58 --> Config Class Initialized
INFO - 2017-01-11 13:32:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:58 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:58 --> URI Class Initialized
INFO - 2017-01-11 13:32:58 --> Router Class Initialized
INFO - 2017-01-11 13:32:58 --> Output Class Initialized
INFO - 2017-01-11 13:32:58 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:58 --> Input Class Initialized
INFO - 2017-01-11 13:32:58 --> Language Class Initialized
INFO - 2017-01-11 13:32:58 --> Loader Class Initialized
INFO - 2017-01-11 13:32:58 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:58 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:58 --> Controller Class Initialized
INFO - 2017-01-11 13:32:58 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:58 --> Model Class Initialized
INFO - 2017-01-11 13:32:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:58 --> Config Class Initialized
INFO - 2017-01-11 13:32:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:32:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:32:58 --> Utf8 Class Initialized
INFO - 2017-01-11 13:32:59 --> URI Class Initialized
INFO - 2017-01-11 13:32:59 --> Router Class Initialized
INFO - 2017-01-11 13:32:59 --> Output Class Initialized
INFO - 2017-01-11 13:32:59 --> Security Class Initialized
DEBUG - 2017-01-11 13:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:32:59 --> Input Class Initialized
INFO - 2017-01-11 13:32:59 --> Language Class Initialized
INFO - 2017-01-11 13:32:59 --> Loader Class Initialized
INFO - 2017-01-11 13:32:59 --> Helper loaded: url_helper
INFO - 2017-01-11 13:32:59 --> Helper loaded: language_helper
INFO - 2017-01-11 13:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:32:59 --> Controller Class Initialized
INFO - 2017-01-11 13:32:59 --> Database Driver Class Initialized
INFO - 2017-01-11 13:32:59 --> Model Class Initialized
INFO - 2017-01-11 13:32:59 --> Model Class Initialized
INFO - 2017-01-11 13:32:59 --> Model Class Initialized
INFO - 2017-01-11 13:32:59 --> Model Class Initialized
INFO - 2017-01-11 13:32:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:32:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:32:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 13:32:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:32:59 --> Final output sent to browser
DEBUG - 2017-01-11 13:32:59 --> Total execution time: 0.0939
INFO - 2017-01-11 13:33:04 --> Config Class Initialized
INFO - 2017-01-11 13:33:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:04 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:04 --> URI Class Initialized
INFO - 2017-01-11 13:33:04 --> Router Class Initialized
INFO - 2017-01-11 13:33:04 --> Output Class Initialized
INFO - 2017-01-11 13:33:04 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:04 --> Input Class Initialized
INFO - 2017-01-11 13:33:04 --> Language Class Initialized
INFO - 2017-01-11 13:33:04 --> Loader Class Initialized
INFO - 2017-01-11 13:33:04 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:04 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:04 --> Controller Class Initialized
INFO - 2017-01-11 13:33:04 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:04 --> Model Class Initialized
INFO - 2017-01-11 13:33:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:04 --> Helper loaded: form_helper
INFO - 2017-01-11 13:33:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 13:33:04 --> Could not find the language line "import_user"
INFO - 2017-01-11 13:33:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-11 13:33:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:04 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:04 --> Total execution time: 0.0722
INFO - 2017-01-11 13:33:11 --> Config Class Initialized
INFO - 2017-01-11 13:33:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:11 --> URI Class Initialized
INFO - 2017-01-11 13:33:11 --> Router Class Initialized
INFO - 2017-01-11 13:33:11 --> Output Class Initialized
INFO - 2017-01-11 13:33:11 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:11 --> Input Class Initialized
INFO - 2017-01-11 13:33:11 --> Language Class Initialized
INFO - 2017-01-11 13:33:11 --> Loader Class Initialized
INFO - 2017-01-11 13:33:11 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:11 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:11 --> Controller Class Initialized
INFO - 2017-01-11 13:33:11 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:11 --> Model Class Initialized
INFO - 2017-01-11 13:33:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:11 --> Model Class Initialized
INFO - 2017-01-11 13:33:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-01-11 13:33:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:11 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:11 --> Total execution time: 0.0910
INFO - 2017-01-11 13:33:19 --> Config Class Initialized
INFO - 2017-01-11 13:33:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:19 --> URI Class Initialized
INFO - 2017-01-11 13:33:19 --> Router Class Initialized
INFO - 2017-01-11 13:33:19 --> Output Class Initialized
INFO - 2017-01-11 13:33:19 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:19 --> Input Class Initialized
INFO - 2017-01-11 13:33:19 --> Language Class Initialized
INFO - 2017-01-11 13:33:19 --> Loader Class Initialized
INFO - 2017-01-11 13:33:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:19 --> Controller Class Initialized
INFO - 2017-01-11 13:33:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:19 --> Model Class Initialized
INFO - 2017-01-11 13:33:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:19 --> Helper loaded: form_helper
INFO - 2017-01-11 13:33:19 --> Form Validation Class Initialized
INFO - 2017-01-11 13:33:19 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:33:19 --> Config Class Initialized
INFO - 2017-01-11 13:33:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:19 --> URI Class Initialized
INFO - 2017-01-11 13:33:19 --> Router Class Initialized
INFO - 2017-01-11 13:33:19 --> Output Class Initialized
INFO - 2017-01-11 13:33:19 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:19 --> Input Class Initialized
INFO - 2017-01-11 13:33:19 --> Language Class Initialized
INFO - 2017-01-11 13:33:19 --> Loader Class Initialized
INFO - 2017-01-11 13:33:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:19 --> Controller Class Initialized
INFO - 2017-01-11 13:33:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:19 --> Model Class Initialized
INFO - 2017-01-11 13:33:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:19 --> Model Class Initialized
INFO - 2017-01-11 13:33:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-01-11 13:33:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:19 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:19 --> Total execution time: 0.1269
INFO - 2017-01-11 13:33:20 --> Config Class Initialized
INFO - 2017-01-11 13:33:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:20 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:20 --> URI Class Initialized
INFO - 2017-01-11 13:33:20 --> Router Class Initialized
INFO - 2017-01-11 13:33:20 --> Output Class Initialized
INFO - 2017-01-11 13:33:20 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:20 --> Input Class Initialized
INFO - 2017-01-11 13:33:20 --> Language Class Initialized
INFO - 2017-01-11 13:33:20 --> Loader Class Initialized
INFO - 2017-01-11 13:33:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:20 --> Controller Class Initialized
INFO - 2017-01-11 13:33:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:20 --> Model Class Initialized
INFO - 2017-01-11 13:33:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:20 --> Config Class Initialized
INFO - 2017-01-11 13:33:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:20 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:20 --> URI Class Initialized
INFO - 2017-01-11 13:33:20 --> Router Class Initialized
INFO - 2017-01-11 13:33:20 --> Output Class Initialized
INFO - 2017-01-11 13:33:20 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:20 --> Input Class Initialized
INFO - 2017-01-11 13:33:20 --> Language Class Initialized
INFO - 2017-01-11 13:33:20 --> Loader Class Initialized
INFO - 2017-01-11 13:33:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:20 --> Controller Class Initialized
INFO - 2017-01-11 13:33:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:20 --> Model Class Initialized
INFO - 2017-01-11 13:33:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:33:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:33:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:33:20 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:20 --> Total execution time: 0.0670
INFO - 2017-01-11 13:33:27 --> Config Class Initialized
INFO - 2017-01-11 13:33:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:27 --> URI Class Initialized
INFO - 2017-01-11 13:33:27 --> Router Class Initialized
INFO - 2017-01-11 13:33:27 --> Output Class Initialized
INFO - 2017-01-11 13:33:27 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:27 --> Input Class Initialized
INFO - 2017-01-11 13:33:27 --> Language Class Initialized
INFO - 2017-01-11 13:33:27 --> Loader Class Initialized
INFO - 2017-01-11 13:33:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:27 --> Controller Class Initialized
INFO - 2017-01-11 13:33:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:27 --> Model Class Initialized
INFO - 2017-01-11 13:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:27 --> Config Class Initialized
INFO - 2017-01-11 13:33:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:27 --> URI Class Initialized
INFO - 2017-01-11 13:33:27 --> Router Class Initialized
INFO - 2017-01-11 13:33:27 --> Output Class Initialized
INFO - 2017-01-11 13:33:27 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:27 --> Input Class Initialized
INFO - 2017-01-11 13:33:27 --> Language Class Initialized
INFO - 2017-01-11 13:33:27 --> Loader Class Initialized
INFO - 2017-01-11 13:33:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:27 --> Controller Class Initialized
INFO - 2017-01-11 13:33:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:27 --> Model Class Initialized
INFO - 2017-01-11 13:33:27 --> Model Class Initialized
INFO - 2017-01-11 13:33:27 --> Model Class Initialized
INFO - 2017-01-11 13:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-11 13:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:27 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:27 --> Total execution time: 0.1425
INFO - 2017-01-11 13:33:31 --> Config Class Initialized
INFO - 2017-01-11 13:33:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:31 --> URI Class Initialized
INFO - 2017-01-11 13:33:31 --> Router Class Initialized
INFO - 2017-01-11 13:33:31 --> Output Class Initialized
INFO - 2017-01-11 13:33:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:31 --> Input Class Initialized
INFO - 2017-01-11 13:33:31 --> Language Class Initialized
INFO - 2017-01-11 13:33:31 --> Loader Class Initialized
INFO - 2017-01-11 13:33:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:31 --> Controller Class Initialized
INFO - 2017-01-11 13:33:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:31 --> Model Class Initialized
INFO - 2017-01-11 13:33:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:31 --> Config Class Initialized
INFO - 2017-01-11 13:33:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:31 --> URI Class Initialized
INFO - 2017-01-11 13:33:31 --> Router Class Initialized
INFO - 2017-01-11 13:33:31 --> Output Class Initialized
INFO - 2017-01-11 13:33:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:31 --> Input Class Initialized
INFO - 2017-01-11 13:33:31 --> Language Class Initialized
INFO - 2017-01-11 13:33:31 --> Loader Class Initialized
INFO - 2017-01-11 13:33:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:31 --> Controller Class Initialized
INFO - 2017-01-11 13:33:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:31 --> Model Class Initialized
INFO - 2017-01-11 13:33:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:33:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:33:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:33:32 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:32 --> Total execution time: 0.0653
INFO - 2017-01-11 13:33:36 --> Config Class Initialized
INFO - 2017-01-11 13:33:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:36 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:36 --> URI Class Initialized
INFO - 2017-01-11 13:33:36 --> Router Class Initialized
INFO - 2017-01-11 13:33:36 --> Output Class Initialized
INFO - 2017-01-11 13:33:36 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:36 --> Input Class Initialized
INFO - 2017-01-11 13:33:36 --> Language Class Initialized
INFO - 2017-01-11 13:33:36 --> Loader Class Initialized
INFO - 2017-01-11 13:33:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:36 --> Controller Class Initialized
INFO - 2017-01-11 13:33:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:36 --> Model Class Initialized
INFO - 2017-01-11 13:33:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:36 --> Config Class Initialized
INFO - 2017-01-11 13:33:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:36 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:36 --> URI Class Initialized
INFO - 2017-01-11 13:33:36 --> Router Class Initialized
INFO - 2017-01-11 13:33:36 --> Output Class Initialized
INFO - 2017-01-11 13:33:36 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:36 --> Input Class Initialized
INFO - 2017-01-11 13:33:36 --> Language Class Initialized
INFO - 2017-01-11 13:33:36 --> Loader Class Initialized
INFO - 2017-01-11 13:33:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:36 --> Controller Class Initialized
INFO - 2017-01-11 13:33:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:36 --> Model Class Initialized
INFO - 2017-01-11 13:33:36 --> Model Class Initialized
INFO - 2017-01-11 13:33:36 --> Model Class Initialized
INFO - 2017-01-11 13:33:36 --> Model Class Initialized
INFO - 2017-01-11 13:33:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 13:33:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:36 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:36 --> Total execution time: 0.0940
INFO - 2017-01-11 13:33:41 --> Config Class Initialized
INFO - 2017-01-11 13:33:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:41 --> URI Class Initialized
INFO - 2017-01-11 13:33:41 --> Router Class Initialized
INFO - 2017-01-11 13:33:41 --> Output Class Initialized
INFO - 2017-01-11 13:33:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:41 --> Input Class Initialized
INFO - 2017-01-11 13:33:41 --> Language Class Initialized
INFO - 2017-01-11 13:33:41 --> Loader Class Initialized
INFO - 2017-01-11 13:33:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:41 --> Controller Class Initialized
INFO - 2017-01-11 13:33:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:41 --> Model Class Initialized
INFO - 2017-01-11 13:33:41 --> Model Class Initialized
INFO - 2017-01-11 13:33:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:33:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:41 --> Total execution time: 0.0750
INFO - 2017-01-11 13:33:45 --> Config Class Initialized
INFO - 2017-01-11 13:33:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:45 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:45 --> URI Class Initialized
INFO - 2017-01-11 13:33:45 --> Router Class Initialized
INFO - 2017-01-11 13:33:45 --> Output Class Initialized
INFO - 2017-01-11 13:33:45 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:45 --> Input Class Initialized
INFO - 2017-01-11 13:33:45 --> Language Class Initialized
INFO - 2017-01-11 13:33:45 --> Loader Class Initialized
INFO - 2017-01-11 13:33:45 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:45 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:45 --> Controller Class Initialized
INFO - 2017-01-11 13:33:45 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:45 --> Model Class Initialized
INFO - 2017-01-11 13:33:45 --> Model Class Initialized
INFO - 2017-01-11 13:33:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:45 --> Model Class Initialized
INFO - 2017-01-11 13:33:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:33:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:45 --> Total execution time: 0.0811
INFO - 2017-01-11 13:33:50 --> Config Class Initialized
INFO - 2017-01-11 13:33:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:50 --> URI Class Initialized
INFO - 2017-01-11 13:33:50 --> Router Class Initialized
INFO - 2017-01-11 13:33:50 --> Output Class Initialized
INFO - 2017-01-11 13:33:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:50 --> Input Class Initialized
INFO - 2017-01-11 13:33:50 --> Language Class Initialized
INFO - 2017-01-11 13:33:50 --> Loader Class Initialized
INFO - 2017-01-11 13:33:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:50 --> Controller Class Initialized
INFO - 2017-01-11 13:33:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:50 --> Model Class Initialized
INFO - 2017-01-11 13:33:50 --> Model Class Initialized
INFO - 2017-01-11 13:33:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:50 --> Helper loaded: form_helper
INFO - 2017-01-11 13:33:50 --> Form Validation Class Initialized
INFO - 2017-01-11 13:33:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:33:51 --> Config Class Initialized
INFO - 2017-01-11 13:33:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:51 --> URI Class Initialized
INFO - 2017-01-11 13:33:51 --> Router Class Initialized
INFO - 2017-01-11 13:33:51 --> Output Class Initialized
INFO - 2017-01-11 13:33:51 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:51 --> Input Class Initialized
INFO - 2017-01-11 13:33:51 --> Language Class Initialized
INFO - 2017-01-11 13:33:51 --> Loader Class Initialized
INFO - 2017-01-11 13:33:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:51 --> Controller Class Initialized
INFO - 2017-01-11 13:33:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:51 --> Model Class Initialized
INFO - 2017-01-11 13:33:51 --> Model Class Initialized
INFO - 2017-01-11 13:33:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:51 --> Model Class Initialized
INFO - 2017-01-11 13:33:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:33:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:51 --> Total execution time: 0.1011
INFO - 2017-01-11 13:33:54 --> Config Class Initialized
INFO - 2017-01-11 13:33:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:54 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:54 --> URI Class Initialized
INFO - 2017-01-11 13:33:54 --> Router Class Initialized
INFO - 2017-01-11 13:33:54 --> Output Class Initialized
INFO - 2017-01-11 13:33:54 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:54 --> Input Class Initialized
INFO - 2017-01-11 13:33:54 --> Language Class Initialized
INFO - 2017-01-11 13:33:54 --> Loader Class Initialized
INFO - 2017-01-11 13:33:54 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:54 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:54 --> Controller Class Initialized
INFO - 2017-01-11 13:33:54 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:54 --> Model Class Initialized
INFO - 2017-01-11 13:33:54 --> Model Class Initialized
INFO - 2017-01-11 13:33:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:33:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:54 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:54 --> Total execution time: 0.0867
INFO - 2017-01-11 13:33:55 --> Config Class Initialized
INFO - 2017-01-11 13:33:55 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:33:55 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:33:55 --> Utf8 Class Initialized
INFO - 2017-01-11 13:33:55 --> URI Class Initialized
INFO - 2017-01-11 13:33:55 --> Router Class Initialized
INFO - 2017-01-11 13:33:55 --> Output Class Initialized
INFO - 2017-01-11 13:33:55 --> Security Class Initialized
DEBUG - 2017-01-11 13:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:33:55 --> Input Class Initialized
INFO - 2017-01-11 13:33:55 --> Language Class Initialized
INFO - 2017-01-11 13:33:55 --> Loader Class Initialized
INFO - 2017-01-11 13:33:55 --> Helper loaded: url_helper
INFO - 2017-01-11 13:33:55 --> Helper loaded: language_helper
INFO - 2017-01-11 13:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:33:55 --> Controller Class Initialized
INFO - 2017-01-11 13:33:55 --> Database Driver Class Initialized
INFO - 2017-01-11 13:33:55 --> Model Class Initialized
INFO - 2017-01-11 13:33:55 --> Model Class Initialized
INFO - 2017-01-11 13:33:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:33:55 --> Model Class Initialized
INFO - 2017-01-11 13:33:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:33:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:33:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:33:55 --> Final output sent to browser
DEBUG - 2017-01-11 13:33:55 --> Total execution time: 0.1232
INFO - 2017-01-11 13:34:01 --> Config Class Initialized
INFO - 2017-01-11 13:34:01 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:01 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:01 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:01 --> URI Class Initialized
INFO - 2017-01-11 13:34:01 --> Router Class Initialized
INFO - 2017-01-11 13:34:01 --> Output Class Initialized
INFO - 2017-01-11 13:34:01 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:01 --> Input Class Initialized
INFO - 2017-01-11 13:34:01 --> Language Class Initialized
INFO - 2017-01-11 13:34:01 --> Loader Class Initialized
INFO - 2017-01-11 13:34:01 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:01 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:01 --> Controller Class Initialized
INFO - 2017-01-11 13:34:01 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:01 --> Model Class Initialized
INFO - 2017-01-11 13:34:01 --> Model Class Initialized
INFO - 2017-01-11 13:34:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:01 --> Helper loaded: form_helper
INFO - 2017-01-11 13:34:01 --> Form Validation Class Initialized
INFO - 2017-01-11 13:34:01 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:34:01 --> Config Class Initialized
INFO - 2017-01-11 13:34:01 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:01 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:01 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:01 --> URI Class Initialized
INFO - 2017-01-11 13:34:01 --> Router Class Initialized
INFO - 2017-01-11 13:34:01 --> Output Class Initialized
INFO - 2017-01-11 13:34:01 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:01 --> Input Class Initialized
INFO - 2017-01-11 13:34:01 --> Language Class Initialized
INFO - 2017-01-11 13:34:01 --> Loader Class Initialized
INFO - 2017-01-11 13:34:01 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:01 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:01 --> Controller Class Initialized
INFO - 2017-01-11 13:34:01 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:01 --> Model Class Initialized
INFO - 2017-01-11 13:34:01 --> Model Class Initialized
INFO - 2017-01-11 13:34:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:01 --> Model Class Initialized
INFO - 2017-01-11 13:34:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:01 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:01 --> Total execution time: 0.0867
INFO - 2017-01-11 13:34:04 --> Config Class Initialized
INFO - 2017-01-11 13:34:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:04 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:04 --> URI Class Initialized
INFO - 2017-01-11 13:34:04 --> Router Class Initialized
INFO - 2017-01-11 13:34:04 --> Output Class Initialized
INFO - 2017-01-11 13:34:04 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:04 --> Input Class Initialized
INFO - 2017-01-11 13:34:04 --> Language Class Initialized
INFO - 2017-01-11 13:34:04 --> Loader Class Initialized
INFO - 2017-01-11 13:34:04 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:04 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:04 --> Controller Class Initialized
INFO - 2017-01-11 13:34:04 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:04 --> Model Class Initialized
INFO - 2017-01-11 13:34:04 --> Model Class Initialized
INFO - 2017-01-11 13:34:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:34:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:04 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:04 --> Total execution time: 0.1149
INFO - 2017-01-11 13:34:06 --> Config Class Initialized
INFO - 2017-01-11 13:34:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:06 --> URI Class Initialized
INFO - 2017-01-11 13:34:06 --> Router Class Initialized
INFO - 2017-01-11 13:34:06 --> Output Class Initialized
INFO - 2017-01-11 13:34:06 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:06 --> Input Class Initialized
INFO - 2017-01-11 13:34:06 --> Language Class Initialized
INFO - 2017-01-11 13:34:06 --> Loader Class Initialized
INFO - 2017-01-11 13:34:06 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:06 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:06 --> Controller Class Initialized
INFO - 2017-01-11 13:34:06 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:06 --> Model Class Initialized
INFO - 2017-01-11 13:34:06 --> Model Class Initialized
INFO - 2017-01-11 13:34:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:06 --> Model Class Initialized
INFO - 2017-01-11 13:34:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:06 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:06 --> Total execution time: 0.1129
INFO - 2017-01-11 13:34:11 --> Config Class Initialized
INFO - 2017-01-11 13:34:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:11 --> URI Class Initialized
INFO - 2017-01-11 13:34:11 --> Router Class Initialized
INFO - 2017-01-11 13:34:11 --> Output Class Initialized
INFO - 2017-01-11 13:34:11 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:11 --> Input Class Initialized
INFO - 2017-01-11 13:34:11 --> Language Class Initialized
INFO - 2017-01-11 13:34:11 --> Loader Class Initialized
INFO - 2017-01-11 13:34:11 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:11 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:11 --> Controller Class Initialized
INFO - 2017-01-11 13:34:11 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:11 --> Model Class Initialized
INFO - 2017-01-11 13:34:11 --> Model Class Initialized
INFO - 2017-01-11 13:34:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:11 --> Helper loaded: form_helper
INFO - 2017-01-11 13:34:11 --> Form Validation Class Initialized
INFO - 2017-01-11 13:34:11 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:34:11 --> Config Class Initialized
INFO - 2017-01-11 13:34:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:11 --> URI Class Initialized
INFO - 2017-01-11 13:34:11 --> Router Class Initialized
INFO - 2017-01-11 13:34:11 --> Output Class Initialized
INFO - 2017-01-11 13:34:11 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:11 --> Input Class Initialized
INFO - 2017-01-11 13:34:11 --> Language Class Initialized
INFO - 2017-01-11 13:34:11 --> Loader Class Initialized
INFO - 2017-01-11 13:34:11 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:11 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:11 --> Controller Class Initialized
INFO - 2017-01-11 13:34:11 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:11 --> Model Class Initialized
INFO - 2017-01-11 13:34:11 --> Model Class Initialized
INFO - 2017-01-11 13:34:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:11 --> Model Class Initialized
INFO - 2017-01-11 13:34:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:11 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:11 --> Total execution time: 0.0906
INFO - 2017-01-11 13:34:16 --> Config Class Initialized
INFO - 2017-01-11 13:34:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:16 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:16 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:16 --> URI Class Initialized
INFO - 2017-01-11 13:34:16 --> Router Class Initialized
INFO - 2017-01-11 13:34:16 --> Output Class Initialized
INFO - 2017-01-11 13:34:16 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:16 --> Input Class Initialized
INFO - 2017-01-11 13:34:16 --> Language Class Initialized
INFO - 2017-01-11 13:34:16 --> Loader Class Initialized
INFO - 2017-01-11 13:34:16 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:16 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:16 --> Controller Class Initialized
INFO - 2017-01-11 13:34:16 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:16 --> Model Class Initialized
INFO - 2017-01-11 13:34:16 --> Model Class Initialized
INFO - 2017-01-11 13:34:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:34:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:16 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:16 --> Total execution time: 0.0836
INFO - 2017-01-11 13:34:20 --> Config Class Initialized
INFO - 2017-01-11 13:34:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:20 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:20 --> URI Class Initialized
INFO - 2017-01-11 13:34:20 --> Router Class Initialized
INFO - 2017-01-11 13:34:20 --> Output Class Initialized
INFO - 2017-01-11 13:34:20 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:20 --> Input Class Initialized
INFO - 2017-01-11 13:34:20 --> Language Class Initialized
INFO - 2017-01-11 13:34:20 --> Loader Class Initialized
INFO - 2017-01-11 13:34:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:20 --> Controller Class Initialized
INFO - 2017-01-11 13:34:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:20 --> Model Class Initialized
INFO - 2017-01-11 13:34:20 --> Model Class Initialized
INFO - 2017-01-11 13:34:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:20 --> Model Class Initialized
INFO - 2017-01-11 13:34:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:20 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:20 --> Total execution time: 0.1240
INFO - 2017-01-11 13:34:25 --> Config Class Initialized
INFO - 2017-01-11 13:34:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:25 --> URI Class Initialized
INFO - 2017-01-11 13:34:25 --> Router Class Initialized
INFO - 2017-01-11 13:34:25 --> Output Class Initialized
INFO - 2017-01-11 13:34:25 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:25 --> Input Class Initialized
INFO - 2017-01-11 13:34:25 --> Language Class Initialized
INFO - 2017-01-11 13:34:25 --> Loader Class Initialized
INFO - 2017-01-11 13:34:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:25 --> Controller Class Initialized
INFO - 2017-01-11 13:34:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:25 --> Model Class Initialized
INFO - 2017-01-11 13:34:25 --> Model Class Initialized
INFO - 2017-01-11 13:34:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:25 --> Helper loaded: form_helper
INFO - 2017-01-11 13:34:25 --> Form Validation Class Initialized
INFO - 2017-01-11 13:34:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:34:25 --> Config Class Initialized
INFO - 2017-01-11 13:34:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:25 --> URI Class Initialized
INFO - 2017-01-11 13:34:25 --> Router Class Initialized
INFO - 2017-01-11 13:34:25 --> Output Class Initialized
INFO - 2017-01-11 13:34:25 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:25 --> Input Class Initialized
INFO - 2017-01-11 13:34:25 --> Language Class Initialized
INFO - 2017-01-11 13:34:25 --> Loader Class Initialized
INFO - 2017-01-11 13:34:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:25 --> Controller Class Initialized
INFO - 2017-01-11 13:34:26 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:26 --> Model Class Initialized
INFO - 2017-01-11 13:34:26 --> Model Class Initialized
INFO - 2017-01-11 13:34:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:26 --> Model Class Initialized
INFO - 2017-01-11 13:34:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:26 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:26 --> Total execution time: 0.1642
INFO - 2017-01-11 13:34:28 --> Config Class Initialized
INFO - 2017-01-11 13:34:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:28 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:28 --> URI Class Initialized
INFO - 2017-01-11 13:34:28 --> Router Class Initialized
INFO - 2017-01-11 13:34:28 --> Output Class Initialized
INFO - 2017-01-11 13:34:28 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:28 --> Input Class Initialized
INFO - 2017-01-11 13:34:28 --> Language Class Initialized
INFO - 2017-01-11 13:34:28 --> Loader Class Initialized
INFO - 2017-01-11 13:34:28 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:28 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:28 --> Controller Class Initialized
INFO - 2017-01-11 13:34:29 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:29 --> Model Class Initialized
INFO - 2017-01-11 13:34:29 --> Model Class Initialized
INFO - 2017-01-11 13:34:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:34:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:29 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:29 --> Total execution time: 0.1224
INFO - 2017-01-11 13:34:31 --> Config Class Initialized
INFO - 2017-01-11 13:34:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:31 --> URI Class Initialized
INFO - 2017-01-11 13:34:31 --> Router Class Initialized
INFO - 2017-01-11 13:34:31 --> Output Class Initialized
INFO - 2017-01-11 13:34:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:31 --> Input Class Initialized
INFO - 2017-01-11 13:34:31 --> Language Class Initialized
INFO - 2017-01-11 13:34:31 --> Loader Class Initialized
INFO - 2017-01-11 13:34:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:31 --> Controller Class Initialized
INFO - 2017-01-11 13:34:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:31 --> Model Class Initialized
INFO - 2017-01-11 13:34:31 --> Model Class Initialized
INFO - 2017-01-11 13:34:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:31 --> Model Class Initialized
INFO - 2017-01-11 13:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:31 --> Total execution time: 0.1693
INFO - 2017-01-11 13:34:35 --> Config Class Initialized
INFO - 2017-01-11 13:34:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:35 --> URI Class Initialized
INFO - 2017-01-11 13:34:35 --> Router Class Initialized
INFO - 2017-01-11 13:34:35 --> Output Class Initialized
INFO - 2017-01-11 13:34:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:35 --> Input Class Initialized
INFO - 2017-01-11 13:34:35 --> Language Class Initialized
INFO - 2017-01-11 13:34:35 --> Loader Class Initialized
INFO - 2017-01-11 13:34:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:35 --> Controller Class Initialized
INFO - 2017-01-11 13:34:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:35 --> Model Class Initialized
INFO - 2017-01-11 13:34:35 --> Model Class Initialized
INFO - 2017-01-11 13:34:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:35 --> Helper loaded: form_helper
INFO - 2017-01-11 13:34:35 --> Form Validation Class Initialized
INFO - 2017-01-11 13:34:35 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:34:35 --> Config Class Initialized
INFO - 2017-01-11 13:34:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:35 --> URI Class Initialized
INFO - 2017-01-11 13:34:35 --> Router Class Initialized
INFO - 2017-01-11 13:34:35 --> Output Class Initialized
INFO - 2017-01-11 13:34:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:35 --> Input Class Initialized
INFO - 2017-01-11 13:34:35 --> Language Class Initialized
INFO - 2017-01-11 13:34:35 --> Loader Class Initialized
INFO - 2017-01-11 13:34:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:35 --> Controller Class Initialized
INFO - 2017-01-11 13:34:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:35 --> Model Class Initialized
INFO - 2017-01-11 13:34:35 --> Model Class Initialized
INFO - 2017-01-11 13:34:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:35 --> Model Class Initialized
INFO - 2017-01-11 13:34:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:35 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:35 --> Total execution time: 0.1086
INFO - 2017-01-11 13:34:40 --> Config Class Initialized
INFO - 2017-01-11 13:34:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:40 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:40 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:40 --> URI Class Initialized
INFO - 2017-01-11 13:34:40 --> Router Class Initialized
INFO - 2017-01-11 13:34:40 --> Output Class Initialized
INFO - 2017-01-11 13:34:40 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:40 --> Input Class Initialized
INFO - 2017-01-11 13:34:40 --> Language Class Initialized
INFO - 2017-01-11 13:34:40 --> Loader Class Initialized
INFO - 2017-01-11 13:34:40 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:40 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:40 --> Controller Class Initialized
INFO - 2017-01-11 13:34:40 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:40 --> Model Class Initialized
INFO - 2017-01-11 13:34:40 --> Model Class Initialized
INFO - 2017-01-11 13:34:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:34:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:40 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:40 --> Total execution time: 0.0758
INFO - 2017-01-11 13:34:46 --> Config Class Initialized
INFO - 2017-01-11 13:34:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:46 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:46 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:46 --> URI Class Initialized
INFO - 2017-01-11 13:34:46 --> Router Class Initialized
INFO - 2017-01-11 13:34:46 --> Output Class Initialized
INFO - 2017-01-11 13:34:46 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:46 --> Input Class Initialized
INFO - 2017-01-11 13:34:46 --> Language Class Initialized
INFO - 2017-01-11 13:34:46 --> Loader Class Initialized
INFO - 2017-01-11 13:34:46 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:46 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:46 --> Controller Class Initialized
INFO - 2017-01-11 13:34:46 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:46 --> Model Class Initialized
INFO - 2017-01-11 13:34:46 --> Model Class Initialized
INFO - 2017-01-11 13:34:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:46 --> Model Class Initialized
INFO - 2017-01-11 13:34:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:46 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:46 --> Total execution time: 0.1479
INFO - 2017-01-11 13:34:50 --> Config Class Initialized
INFO - 2017-01-11 13:34:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:50 --> URI Class Initialized
INFO - 2017-01-11 13:34:50 --> Router Class Initialized
INFO - 2017-01-11 13:34:50 --> Output Class Initialized
INFO - 2017-01-11 13:34:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:50 --> Input Class Initialized
INFO - 2017-01-11 13:34:50 --> Language Class Initialized
INFO - 2017-01-11 13:34:50 --> Loader Class Initialized
INFO - 2017-01-11 13:34:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:50 --> Controller Class Initialized
INFO - 2017-01-11 13:34:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:50 --> Model Class Initialized
INFO - 2017-01-11 13:34:50 --> Model Class Initialized
INFO - 2017-01-11 13:34:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:50 --> Helper loaded: form_helper
INFO - 2017-01-11 13:34:50 --> Form Validation Class Initialized
INFO - 2017-01-11 13:34:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:34:50 --> Config Class Initialized
INFO - 2017-01-11 13:34:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:50 --> URI Class Initialized
INFO - 2017-01-11 13:34:50 --> Router Class Initialized
INFO - 2017-01-11 13:34:50 --> Output Class Initialized
INFO - 2017-01-11 13:34:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:50 --> Input Class Initialized
INFO - 2017-01-11 13:34:50 --> Language Class Initialized
INFO - 2017-01-11 13:34:50 --> Loader Class Initialized
INFO - 2017-01-11 13:34:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:50 --> Controller Class Initialized
INFO - 2017-01-11 13:34:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:50 --> Model Class Initialized
INFO - 2017-01-11 13:34:50 --> Model Class Initialized
INFO - 2017-01-11 13:34:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:50 --> Model Class Initialized
INFO - 2017-01-11 13:34:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:50 --> Total execution time: 0.0915
INFO - 2017-01-11 13:34:53 --> Config Class Initialized
INFO - 2017-01-11 13:34:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:53 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:53 --> URI Class Initialized
INFO - 2017-01-11 13:34:53 --> Router Class Initialized
INFO - 2017-01-11 13:34:53 --> Output Class Initialized
INFO - 2017-01-11 13:34:53 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:53 --> Input Class Initialized
INFO - 2017-01-11 13:34:53 --> Language Class Initialized
INFO - 2017-01-11 13:34:53 --> Loader Class Initialized
INFO - 2017-01-11 13:34:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:53 --> Controller Class Initialized
INFO - 2017-01-11 13:34:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:53 --> Model Class Initialized
INFO - 2017-01-11 13:34:53 --> Model Class Initialized
INFO - 2017-01-11 13:34:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:34:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:53 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:53 --> Total execution time: 0.1086
INFO - 2017-01-11 13:34:56 --> Config Class Initialized
INFO - 2017-01-11 13:34:56 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:34:56 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:34:56 --> Utf8 Class Initialized
INFO - 2017-01-11 13:34:56 --> URI Class Initialized
INFO - 2017-01-11 13:34:56 --> Router Class Initialized
INFO - 2017-01-11 13:34:56 --> Output Class Initialized
INFO - 2017-01-11 13:34:56 --> Security Class Initialized
DEBUG - 2017-01-11 13:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:34:56 --> Input Class Initialized
INFO - 2017-01-11 13:34:56 --> Language Class Initialized
INFO - 2017-01-11 13:34:56 --> Loader Class Initialized
INFO - 2017-01-11 13:34:56 --> Helper loaded: url_helper
INFO - 2017-01-11 13:34:56 --> Helper loaded: language_helper
INFO - 2017-01-11 13:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:34:56 --> Controller Class Initialized
INFO - 2017-01-11 13:34:56 --> Database Driver Class Initialized
INFO - 2017-01-11 13:34:56 --> Model Class Initialized
INFO - 2017-01-11 13:34:56 --> Model Class Initialized
INFO - 2017-01-11 13:34:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:34:56 --> Model Class Initialized
INFO - 2017-01-11 13:34:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:34:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:34:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:34:56 --> Final output sent to browser
DEBUG - 2017-01-11 13:34:56 --> Total execution time: 0.0821
INFO - 2017-01-11 13:35:00 --> Config Class Initialized
INFO - 2017-01-11 13:35:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:00 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:00 --> URI Class Initialized
INFO - 2017-01-11 13:35:00 --> Router Class Initialized
INFO - 2017-01-11 13:35:00 --> Output Class Initialized
INFO - 2017-01-11 13:35:00 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:00 --> Input Class Initialized
INFO - 2017-01-11 13:35:00 --> Language Class Initialized
INFO - 2017-01-11 13:35:00 --> Loader Class Initialized
INFO - 2017-01-11 13:35:00 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:00 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:00 --> Controller Class Initialized
INFO - 2017-01-11 13:35:00 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:00 --> Model Class Initialized
INFO - 2017-01-11 13:35:00 --> Model Class Initialized
INFO - 2017-01-11 13:35:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:00 --> Helper loaded: form_helper
INFO - 2017-01-11 13:35:00 --> Form Validation Class Initialized
INFO - 2017-01-11 13:35:00 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:35:00 --> Config Class Initialized
INFO - 2017-01-11 13:35:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:00 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:00 --> URI Class Initialized
INFO - 2017-01-11 13:35:00 --> Router Class Initialized
INFO - 2017-01-11 13:35:00 --> Output Class Initialized
INFO - 2017-01-11 13:35:00 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:00 --> Input Class Initialized
INFO - 2017-01-11 13:35:00 --> Language Class Initialized
INFO - 2017-01-11 13:35:00 --> Loader Class Initialized
INFO - 2017-01-11 13:35:00 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:00 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:00 --> Controller Class Initialized
INFO - 2017-01-11 13:35:00 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:00 --> Model Class Initialized
INFO - 2017-01-11 13:35:00 --> Model Class Initialized
INFO - 2017-01-11 13:35:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:00 --> Model Class Initialized
INFO - 2017-01-11 13:35:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:00 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:00 --> Total execution time: 0.0915
INFO - 2017-01-11 13:35:04 --> Config Class Initialized
INFO - 2017-01-11 13:35:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:04 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:04 --> URI Class Initialized
INFO - 2017-01-11 13:35:04 --> Router Class Initialized
INFO - 2017-01-11 13:35:04 --> Output Class Initialized
INFO - 2017-01-11 13:35:04 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:04 --> Input Class Initialized
INFO - 2017-01-11 13:35:04 --> Language Class Initialized
INFO - 2017-01-11 13:35:04 --> Loader Class Initialized
INFO - 2017-01-11 13:35:04 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:04 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:04 --> Controller Class Initialized
INFO - 2017-01-11 13:35:04 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:04 --> Model Class Initialized
INFO - 2017-01-11 13:35:04 --> Model Class Initialized
INFO - 2017-01-11 13:35:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:04 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:04 --> Total execution time: 0.2941
INFO - 2017-01-11 13:35:06 --> Config Class Initialized
INFO - 2017-01-11 13:35:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:06 --> URI Class Initialized
INFO - 2017-01-11 13:35:06 --> Router Class Initialized
INFO - 2017-01-11 13:35:06 --> Output Class Initialized
INFO - 2017-01-11 13:35:06 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:06 --> Input Class Initialized
INFO - 2017-01-11 13:35:06 --> Language Class Initialized
INFO - 2017-01-11 13:35:06 --> Loader Class Initialized
INFO - 2017-01-11 13:35:06 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:06 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:06 --> Controller Class Initialized
INFO - 2017-01-11 13:35:06 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:06 --> Model Class Initialized
INFO - 2017-01-11 13:35:06 --> Model Class Initialized
INFO - 2017-01-11 13:35:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:06 --> Model Class Initialized
INFO - 2017-01-11 13:35:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:07 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:07 --> Total execution time: 0.0995
INFO - 2017-01-11 13:35:13 --> Config Class Initialized
INFO - 2017-01-11 13:35:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:13 --> URI Class Initialized
INFO - 2017-01-11 13:35:13 --> Router Class Initialized
INFO - 2017-01-11 13:35:13 --> Output Class Initialized
INFO - 2017-01-11 13:35:13 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:13 --> Input Class Initialized
INFO - 2017-01-11 13:35:13 --> Language Class Initialized
INFO - 2017-01-11 13:35:13 --> Loader Class Initialized
INFO - 2017-01-11 13:35:13 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:13 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:13 --> Controller Class Initialized
INFO - 2017-01-11 13:35:13 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:13 --> Model Class Initialized
INFO - 2017-01-11 13:35:13 --> Model Class Initialized
INFO - 2017-01-11 13:35:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:13 --> Helper loaded: form_helper
INFO - 2017-01-11 13:35:13 --> Form Validation Class Initialized
INFO - 2017-01-11 13:35:13 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:35:13 --> Config Class Initialized
INFO - 2017-01-11 13:35:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:13 --> URI Class Initialized
INFO - 2017-01-11 13:35:13 --> Router Class Initialized
INFO - 2017-01-11 13:35:13 --> Output Class Initialized
INFO - 2017-01-11 13:35:13 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:13 --> Input Class Initialized
INFO - 2017-01-11 13:35:13 --> Language Class Initialized
INFO - 2017-01-11 13:35:13 --> Loader Class Initialized
INFO - 2017-01-11 13:35:13 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:13 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:13 --> Controller Class Initialized
INFO - 2017-01-11 13:35:13 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:13 --> Model Class Initialized
INFO - 2017-01-11 13:35:13 --> Model Class Initialized
INFO - 2017-01-11 13:35:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:13 --> Model Class Initialized
INFO - 2017-01-11 13:35:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:13 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:13 --> Total execution time: 0.0892
INFO - 2017-01-11 13:35:15 --> Config Class Initialized
INFO - 2017-01-11 13:35:15 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:15 --> URI Class Initialized
INFO - 2017-01-11 13:35:15 --> Router Class Initialized
INFO - 2017-01-11 13:35:15 --> Output Class Initialized
INFO - 2017-01-11 13:35:15 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:15 --> Input Class Initialized
INFO - 2017-01-11 13:35:15 --> Language Class Initialized
INFO - 2017-01-11 13:35:15 --> Loader Class Initialized
INFO - 2017-01-11 13:35:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:15 --> Controller Class Initialized
INFO - 2017-01-11 13:35:15 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:15 --> Model Class Initialized
INFO - 2017-01-11 13:35:15 --> Model Class Initialized
INFO - 2017-01-11 13:35:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:35:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:15 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:15 --> Total execution time: 0.0933
INFO - 2017-01-11 13:35:18 --> Config Class Initialized
INFO - 2017-01-11 13:35:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:18 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:18 --> URI Class Initialized
INFO - 2017-01-11 13:35:18 --> Router Class Initialized
INFO - 2017-01-11 13:35:18 --> Output Class Initialized
INFO - 2017-01-11 13:35:18 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:18 --> Input Class Initialized
INFO - 2017-01-11 13:35:18 --> Language Class Initialized
INFO - 2017-01-11 13:35:18 --> Loader Class Initialized
INFO - 2017-01-11 13:35:18 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:18 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:18 --> Controller Class Initialized
INFO - 2017-01-11 13:35:18 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:18 --> Model Class Initialized
INFO - 2017-01-11 13:35:18 --> Model Class Initialized
INFO - 2017-01-11 13:35:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:18 --> Model Class Initialized
INFO - 2017-01-11 13:35:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:18 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:18 --> Total execution time: 0.0994
INFO - 2017-01-11 13:35:22 --> Config Class Initialized
INFO - 2017-01-11 13:35:22 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:22 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:22 --> URI Class Initialized
INFO - 2017-01-11 13:35:22 --> Router Class Initialized
INFO - 2017-01-11 13:35:22 --> Output Class Initialized
INFO - 2017-01-11 13:35:22 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:22 --> Input Class Initialized
INFO - 2017-01-11 13:35:22 --> Language Class Initialized
INFO - 2017-01-11 13:35:22 --> Loader Class Initialized
INFO - 2017-01-11 13:35:22 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:22 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:22 --> Controller Class Initialized
INFO - 2017-01-11 13:35:22 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:22 --> Model Class Initialized
INFO - 2017-01-11 13:35:22 --> Model Class Initialized
INFO - 2017-01-11 13:35:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:22 --> Helper loaded: form_helper
INFO - 2017-01-11 13:35:22 --> Form Validation Class Initialized
INFO - 2017-01-11 13:35:22 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:35:22 --> Config Class Initialized
INFO - 2017-01-11 13:35:22 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:22 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:22 --> URI Class Initialized
INFO - 2017-01-11 13:35:22 --> Router Class Initialized
INFO - 2017-01-11 13:35:22 --> Output Class Initialized
INFO - 2017-01-11 13:35:22 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:22 --> Input Class Initialized
INFO - 2017-01-11 13:35:22 --> Language Class Initialized
INFO - 2017-01-11 13:35:22 --> Loader Class Initialized
INFO - 2017-01-11 13:35:22 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:22 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:22 --> Controller Class Initialized
INFO - 2017-01-11 13:35:22 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:22 --> Model Class Initialized
INFO - 2017-01-11 13:35:22 --> Model Class Initialized
INFO - 2017-01-11 13:35:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:22 --> Model Class Initialized
INFO - 2017-01-11 13:35:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:22 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:22 --> Total execution time: 0.0903
INFO - 2017-01-11 13:35:25 --> Config Class Initialized
INFO - 2017-01-11 13:35:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:25 --> URI Class Initialized
INFO - 2017-01-11 13:35:25 --> Router Class Initialized
INFO - 2017-01-11 13:35:25 --> Output Class Initialized
INFO - 2017-01-11 13:35:25 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:25 --> Input Class Initialized
INFO - 2017-01-11 13:35:25 --> Language Class Initialized
INFO - 2017-01-11 13:35:25 --> Loader Class Initialized
INFO - 2017-01-11 13:35:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:25 --> Controller Class Initialized
INFO - 2017-01-11 13:35:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:25 --> Model Class Initialized
INFO - 2017-01-11 13:35:25 --> Model Class Initialized
INFO - 2017-01-11 13:35:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:35:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:25 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:25 --> Total execution time: 0.0801
INFO - 2017-01-11 13:35:27 --> Config Class Initialized
INFO - 2017-01-11 13:35:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:27 --> URI Class Initialized
INFO - 2017-01-11 13:35:27 --> Router Class Initialized
INFO - 2017-01-11 13:35:27 --> Output Class Initialized
INFO - 2017-01-11 13:35:27 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:27 --> Input Class Initialized
INFO - 2017-01-11 13:35:27 --> Language Class Initialized
INFO - 2017-01-11 13:35:27 --> Loader Class Initialized
INFO - 2017-01-11 13:35:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:27 --> Controller Class Initialized
INFO - 2017-01-11 13:35:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:27 --> Model Class Initialized
INFO - 2017-01-11 13:35:27 --> Model Class Initialized
INFO - 2017-01-11 13:35:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:27 --> Model Class Initialized
INFO - 2017-01-11 13:35:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:27 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:27 --> Total execution time: 0.1154
INFO - 2017-01-11 13:35:33 --> Config Class Initialized
INFO - 2017-01-11 13:35:33 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:33 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:33 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:33 --> URI Class Initialized
INFO - 2017-01-11 13:35:33 --> Router Class Initialized
INFO - 2017-01-11 13:35:33 --> Output Class Initialized
INFO - 2017-01-11 13:35:33 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:33 --> Input Class Initialized
INFO - 2017-01-11 13:35:33 --> Language Class Initialized
INFO - 2017-01-11 13:35:33 --> Loader Class Initialized
INFO - 2017-01-11 13:35:33 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:33 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:33 --> Controller Class Initialized
INFO - 2017-01-11 13:35:33 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:33 --> Model Class Initialized
INFO - 2017-01-11 13:35:33 --> Model Class Initialized
INFO - 2017-01-11 13:35:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:33 --> Helper loaded: form_helper
INFO - 2017-01-11 13:35:33 --> Form Validation Class Initialized
INFO - 2017-01-11 13:35:33 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-11 13:35:33 --> Config Class Initialized
INFO - 2017-01-11 13:35:33 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:33 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:33 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:33 --> URI Class Initialized
INFO - 2017-01-11 13:35:33 --> Router Class Initialized
INFO - 2017-01-11 13:35:33 --> Output Class Initialized
INFO - 2017-01-11 13:35:33 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:33 --> Input Class Initialized
INFO - 2017-01-11 13:35:33 --> Language Class Initialized
INFO - 2017-01-11 13:35:33 --> Loader Class Initialized
INFO - 2017-01-11 13:35:33 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:33 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:33 --> Controller Class Initialized
INFO - 2017-01-11 13:35:33 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:33 --> Model Class Initialized
INFO - 2017-01-11 13:35:33 --> Model Class Initialized
INFO - 2017-01-11 13:35:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:33 --> Model Class Initialized
INFO - 2017-01-11 13:35:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:33 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:33 --> Total execution time: 0.0980
INFO - 2017-01-11 13:35:36 --> Config Class Initialized
INFO - 2017-01-11 13:35:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:36 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:36 --> URI Class Initialized
INFO - 2017-01-11 13:35:36 --> Router Class Initialized
INFO - 2017-01-11 13:35:36 --> Output Class Initialized
INFO - 2017-01-11 13:35:36 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:36 --> Input Class Initialized
INFO - 2017-01-11 13:35:36 --> Language Class Initialized
INFO - 2017-01-11 13:35:36 --> Loader Class Initialized
INFO - 2017-01-11 13:35:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:36 --> Controller Class Initialized
INFO - 2017-01-11 13:35:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:36 --> Model Class Initialized
INFO - 2017-01-11 13:35:36 --> Model Class Initialized
INFO - 2017-01-11 13:35:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:35:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:36 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:36 --> Total execution time: 0.0750
INFO - 2017-01-11 13:35:38 --> Config Class Initialized
INFO - 2017-01-11 13:35:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:38 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:38 --> URI Class Initialized
INFO - 2017-01-11 13:35:38 --> Router Class Initialized
INFO - 2017-01-11 13:35:38 --> Output Class Initialized
INFO - 2017-01-11 13:35:38 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:38 --> Input Class Initialized
INFO - 2017-01-11 13:35:38 --> Language Class Initialized
INFO - 2017-01-11 13:35:38 --> Loader Class Initialized
INFO - 2017-01-11 13:35:38 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:38 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:38 --> Controller Class Initialized
INFO - 2017-01-11 13:35:38 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:38 --> Model Class Initialized
INFO - 2017-01-11 13:35:38 --> Model Class Initialized
INFO - 2017-01-11 13:35:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:38 --> Model Class Initialized
INFO - 2017-01-11 13:35:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:38 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:38 --> Total execution time: 0.1190
INFO - 2017-01-11 13:35:45 --> Config Class Initialized
INFO - 2017-01-11 13:35:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:45 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:45 --> URI Class Initialized
INFO - 2017-01-11 13:35:45 --> Router Class Initialized
INFO - 2017-01-11 13:35:45 --> Output Class Initialized
INFO - 2017-01-11 13:35:45 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:45 --> Input Class Initialized
INFO - 2017-01-11 13:35:45 --> Language Class Initialized
INFO - 2017-01-11 13:35:45 --> Loader Class Initialized
INFO - 2017-01-11 13:35:45 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:45 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:45 --> Controller Class Initialized
INFO - 2017-01-11 13:35:45 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:45 --> Model Class Initialized
INFO - 2017-01-11 13:35:45 --> Model Class Initialized
INFO - 2017-01-11 13:35:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:45 --> Model Class Initialized
INFO - 2017-01-11 13:35:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:45 --> Total execution time: 0.0962
INFO - 2017-01-11 13:35:49 --> Config Class Initialized
INFO - 2017-01-11 13:35:49 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:49 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:49 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:49 --> URI Class Initialized
INFO - 2017-01-11 13:35:49 --> Router Class Initialized
INFO - 2017-01-11 13:35:49 --> Output Class Initialized
INFO - 2017-01-11 13:35:49 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:49 --> Input Class Initialized
INFO - 2017-01-11 13:35:49 --> Language Class Initialized
INFO - 2017-01-11 13:35:49 --> Loader Class Initialized
INFO - 2017-01-11 13:35:49 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:49 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:49 --> Controller Class Initialized
INFO - 2017-01-11 13:35:49 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:49 --> Model Class Initialized
INFO - 2017-01-11 13:35:49 --> Model Class Initialized
INFO - 2017-01-11 13:35:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:49 --> Model Class Initialized
INFO - 2017-01-11 13:35:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:49 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:49 --> Total execution time: 0.1155
INFO - 2017-01-11 13:35:57 --> Config Class Initialized
INFO - 2017-01-11 13:35:57 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:35:57 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:35:57 --> Utf8 Class Initialized
INFO - 2017-01-11 13:35:57 --> URI Class Initialized
INFO - 2017-01-11 13:35:57 --> Router Class Initialized
INFO - 2017-01-11 13:35:57 --> Output Class Initialized
INFO - 2017-01-11 13:35:57 --> Security Class Initialized
DEBUG - 2017-01-11 13:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:35:57 --> Input Class Initialized
INFO - 2017-01-11 13:35:57 --> Language Class Initialized
INFO - 2017-01-11 13:35:57 --> Loader Class Initialized
INFO - 2017-01-11 13:35:57 --> Helper loaded: url_helper
INFO - 2017-01-11 13:35:57 --> Helper loaded: language_helper
INFO - 2017-01-11 13:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:35:57 --> Controller Class Initialized
INFO - 2017-01-11 13:35:57 --> Database Driver Class Initialized
INFO - 2017-01-11 13:35:57 --> Model Class Initialized
INFO - 2017-01-11 13:35:57 --> Model Class Initialized
INFO - 2017-01-11 13:35:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:35:57 --> Model Class Initialized
INFO - 2017-01-11 13:35:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:35:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:35:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:35:57 --> Final output sent to browser
DEBUG - 2017-01-11 13:35:57 --> Total execution time: 0.1111
INFO - 2017-01-11 13:36:01 --> Config Class Initialized
INFO - 2017-01-11 13:36:01 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:01 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:01 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:01 --> URI Class Initialized
INFO - 2017-01-11 13:36:01 --> Router Class Initialized
INFO - 2017-01-11 13:36:01 --> Output Class Initialized
INFO - 2017-01-11 13:36:01 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:01 --> Input Class Initialized
INFO - 2017-01-11 13:36:01 --> Language Class Initialized
INFO - 2017-01-11 13:36:01 --> Loader Class Initialized
INFO - 2017-01-11 13:36:01 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:01 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:01 --> Controller Class Initialized
INFO - 2017-01-11 13:36:01 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:01 --> Model Class Initialized
INFO - 2017-01-11 13:36:01 --> Model Class Initialized
INFO - 2017-01-11 13:36:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:01 --> Model Class Initialized
INFO - 2017-01-11 13:36:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:01 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:01 --> Total execution time: 0.1147
INFO - 2017-01-11 13:36:04 --> Config Class Initialized
INFO - 2017-01-11 13:36:04 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:04 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:04 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:04 --> URI Class Initialized
INFO - 2017-01-11 13:36:04 --> Router Class Initialized
INFO - 2017-01-11 13:36:04 --> Output Class Initialized
INFO - 2017-01-11 13:36:04 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:04 --> Input Class Initialized
INFO - 2017-01-11 13:36:04 --> Language Class Initialized
INFO - 2017-01-11 13:36:04 --> Loader Class Initialized
INFO - 2017-01-11 13:36:04 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:04 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:04 --> Controller Class Initialized
INFO - 2017-01-11 13:36:04 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:04 --> Model Class Initialized
INFO - 2017-01-11 13:36:04 --> Model Class Initialized
INFO - 2017-01-11 13:36:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:04 --> Model Class Initialized
INFO - 2017-01-11 13:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:04 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:04 --> Total execution time: 0.1085
INFO - 2017-01-11 13:36:13 --> Config Class Initialized
INFO - 2017-01-11 13:36:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:13 --> URI Class Initialized
INFO - 2017-01-11 13:36:13 --> Router Class Initialized
INFO - 2017-01-11 13:36:13 --> Output Class Initialized
INFO - 2017-01-11 13:36:13 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:13 --> Input Class Initialized
INFO - 2017-01-11 13:36:13 --> Language Class Initialized
INFO - 2017-01-11 13:36:13 --> Loader Class Initialized
INFO - 2017-01-11 13:36:13 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:13 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:13 --> Controller Class Initialized
INFO - 2017-01-11 13:36:13 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:13 --> Model Class Initialized
INFO - 2017-01-11 13:36:13 --> Model Class Initialized
INFO - 2017-01-11 13:36:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:13 --> Model Class Initialized
INFO - 2017-01-11 13:36:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:13 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:13 --> Total execution time: 0.2272
INFO - 2017-01-11 13:36:17 --> Config Class Initialized
INFO - 2017-01-11 13:36:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:17 --> URI Class Initialized
INFO - 2017-01-11 13:36:17 --> Router Class Initialized
INFO - 2017-01-11 13:36:17 --> Output Class Initialized
INFO - 2017-01-11 13:36:17 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:17 --> Input Class Initialized
INFO - 2017-01-11 13:36:17 --> Language Class Initialized
INFO - 2017-01-11 13:36:17 --> Loader Class Initialized
INFO - 2017-01-11 13:36:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:17 --> Controller Class Initialized
INFO - 2017-01-11 13:36:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:17 --> Model Class Initialized
INFO - 2017-01-11 13:36:17 --> Model Class Initialized
INFO - 2017-01-11 13:36:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:17 --> Model Class Initialized
INFO - 2017-01-11 13:36:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:17 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:17 --> Total execution time: 0.1261
INFO - 2017-01-11 13:36:21 --> Config Class Initialized
INFO - 2017-01-11 13:36:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:21 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:21 --> URI Class Initialized
INFO - 2017-01-11 13:36:21 --> Router Class Initialized
INFO - 2017-01-11 13:36:21 --> Output Class Initialized
INFO - 2017-01-11 13:36:21 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:21 --> Input Class Initialized
INFO - 2017-01-11 13:36:21 --> Language Class Initialized
INFO - 2017-01-11 13:36:21 --> Loader Class Initialized
INFO - 2017-01-11 13:36:21 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:21 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:21 --> Controller Class Initialized
INFO - 2017-01-11 13:36:21 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:21 --> Model Class Initialized
INFO - 2017-01-11 13:36:21 --> Model Class Initialized
INFO - 2017-01-11 13:36:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:21 --> Model Class Initialized
INFO - 2017-01-11 13:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:21 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:21 --> Total execution time: 0.0909
INFO - 2017-01-11 13:36:24 --> Config Class Initialized
INFO - 2017-01-11 13:36:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:24 --> URI Class Initialized
INFO - 2017-01-11 13:36:24 --> Router Class Initialized
INFO - 2017-01-11 13:36:24 --> Output Class Initialized
INFO - 2017-01-11 13:36:24 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:24 --> Input Class Initialized
INFO - 2017-01-11 13:36:24 --> Language Class Initialized
INFO - 2017-01-11 13:36:24 --> Loader Class Initialized
INFO - 2017-01-11 13:36:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:24 --> Controller Class Initialized
INFO - 2017-01-11 13:36:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:24 --> Model Class Initialized
INFO - 2017-01-11 13:36:24 --> Model Class Initialized
INFO - 2017-01-11 13:36:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:24 --> Model Class Initialized
INFO - 2017-01-11 13:36:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:24 --> Total execution time: 0.1373
INFO - 2017-01-11 13:36:27 --> Config Class Initialized
INFO - 2017-01-11 13:36:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:27 --> URI Class Initialized
INFO - 2017-01-11 13:36:27 --> Router Class Initialized
INFO - 2017-01-11 13:36:27 --> Output Class Initialized
INFO - 2017-01-11 13:36:27 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:27 --> Input Class Initialized
INFO - 2017-01-11 13:36:27 --> Language Class Initialized
INFO - 2017-01-11 13:36:27 --> Loader Class Initialized
INFO - 2017-01-11 13:36:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:27 --> Controller Class Initialized
INFO - 2017-01-11 13:36:28 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:28 --> Model Class Initialized
INFO - 2017-01-11 13:36:28 --> Model Class Initialized
INFO - 2017-01-11 13:36:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:28 --> Model Class Initialized
INFO - 2017-01-11 13:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:28 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:28 --> Total execution time: 0.1218
INFO - 2017-01-11 13:36:31 --> Config Class Initialized
INFO - 2017-01-11 13:36:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:31 --> URI Class Initialized
INFO - 2017-01-11 13:36:31 --> Router Class Initialized
INFO - 2017-01-11 13:36:31 --> Output Class Initialized
INFO - 2017-01-11 13:36:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:31 --> Input Class Initialized
INFO - 2017-01-11 13:36:31 --> Language Class Initialized
INFO - 2017-01-11 13:36:31 --> Loader Class Initialized
INFO - 2017-01-11 13:36:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:31 --> Controller Class Initialized
INFO - 2017-01-11 13:36:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:31 --> Model Class Initialized
INFO - 2017-01-11 13:36:31 --> Model Class Initialized
INFO - 2017-01-11 13:36:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:31 --> Model Class Initialized
INFO - 2017-01-11 13:36:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:31 --> Total execution time: 0.1449
INFO - 2017-01-11 13:36:35 --> Config Class Initialized
INFO - 2017-01-11 13:36:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:35 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:35 --> URI Class Initialized
INFO - 2017-01-11 13:36:35 --> Router Class Initialized
INFO - 2017-01-11 13:36:35 --> Output Class Initialized
INFO - 2017-01-11 13:36:35 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:35 --> Input Class Initialized
INFO - 2017-01-11 13:36:35 --> Language Class Initialized
INFO - 2017-01-11 13:36:35 --> Loader Class Initialized
INFO - 2017-01-11 13:36:35 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:35 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:35 --> Controller Class Initialized
INFO - 2017-01-11 13:36:35 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:35 --> Model Class Initialized
INFO - 2017-01-11 13:36:35 --> Model Class Initialized
INFO - 2017-01-11 13:36:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:35 --> Model Class Initialized
INFO - 2017-01-11 13:36:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:35 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:35 --> Total execution time: 0.1236
INFO - 2017-01-11 13:36:38 --> Config Class Initialized
INFO - 2017-01-11 13:36:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:38 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:38 --> URI Class Initialized
INFO - 2017-01-11 13:36:38 --> Router Class Initialized
INFO - 2017-01-11 13:36:38 --> Output Class Initialized
INFO - 2017-01-11 13:36:38 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:38 --> Input Class Initialized
INFO - 2017-01-11 13:36:38 --> Language Class Initialized
INFO - 2017-01-11 13:36:38 --> Loader Class Initialized
INFO - 2017-01-11 13:36:38 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:38 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:38 --> Controller Class Initialized
INFO - 2017-01-11 13:36:38 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:38 --> Model Class Initialized
INFO - 2017-01-11 13:36:38 --> Model Class Initialized
INFO - 2017-01-11 13:36:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:38 --> Model Class Initialized
INFO - 2017-01-11 13:36:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:38 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:38 --> Total execution time: 0.1189
INFO - 2017-01-11 13:36:41 --> Config Class Initialized
INFO - 2017-01-11 13:36:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:41 --> URI Class Initialized
INFO - 2017-01-11 13:36:41 --> Router Class Initialized
INFO - 2017-01-11 13:36:41 --> Output Class Initialized
INFO - 2017-01-11 13:36:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:41 --> Input Class Initialized
INFO - 2017-01-11 13:36:41 --> Language Class Initialized
INFO - 2017-01-11 13:36:41 --> Loader Class Initialized
INFO - 2017-01-11 13:36:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:41 --> Controller Class Initialized
INFO - 2017-01-11 13:36:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:41 --> Model Class Initialized
INFO - 2017-01-11 13:36:41 --> Model Class Initialized
INFO - 2017-01-11 13:36:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:41 --> Model Class Initialized
INFO - 2017-01-11 13:36:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:41 --> Total execution time: 0.1215
INFO - 2017-01-11 13:36:45 --> Config Class Initialized
INFO - 2017-01-11 13:36:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:45 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:45 --> URI Class Initialized
INFO - 2017-01-11 13:36:45 --> Router Class Initialized
INFO - 2017-01-11 13:36:45 --> Output Class Initialized
INFO - 2017-01-11 13:36:45 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:45 --> Input Class Initialized
INFO - 2017-01-11 13:36:45 --> Language Class Initialized
INFO - 2017-01-11 13:36:45 --> Loader Class Initialized
INFO - 2017-01-11 13:36:45 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:45 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:45 --> Controller Class Initialized
INFO - 2017-01-11 13:36:45 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:45 --> Model Class Initialized
INFO - 2017-01-11 13:36:45 --> Model Class Initialized
INFO - 2017-01-11 13:36:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:45 --> Model Class Initialized
INFO - 2017-01-11 13:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:45 --> Total execution time: 0.1259
INFO - 2017-01-11 13:36:50 --> Config Class Initialized
INFO - 2017-01-11 13:36:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:50 --> URI Class Initialized
INFO - 2017-01-11 13:36:50 --> Router Class Initialized
INFO - 2017-01-11 13:36:50 --> Output Class Initialized
INFO - 2017-01-11 13:36:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:50 --> Input Class Initialized
INFO - 2017-01-11 13:36:50 --> Language Class Initialized
INFO - 2017-01-11 13:36:50 --> Loader Class Initialized
INFO - 2017-01-11 13:36:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:50 --> Controller Class Initialized
INFO - 2017-01-11 13:36:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:50 --> Model Class Initialized
INFO - 2017-01-11 13:36:50 --> Model Class Initialized
INFO - 2017-01-11 13:36:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-11 13:36:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:50 --> Total execution time: 0.1487
INFO - 2017-01-11 13:36:53 --> Config Class Initialized
INFO - 2017-01-11 13:36:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:36:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:36:53 --> Utf8 Class Initialized
INFO - 2017-01-11 13:36:53 --> URI Class Initialized
INFO - 2017-01-11 13:36:53 --> Router Class Initialized
INFO - 2017-01-11 13:36:53 --> Output Class Initialized
INFO - 2017-01-11 13:36:53 --> Security Class Initialized
DEBUG - 2017-01-11 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:36:53 --> Input Class Initialized
INFO - 2017-01-11 13:36:53 --> Language Class Initialized
INFO - 2017-01-11 13:36:53 --> Loader Class Initialized
INFO - 2017-01-11 13:36:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:36:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:36:53 --> Controller Class Initialized
INFO - 2017-01-11 13:36:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:36:53 --> Model Class Initialized
INFO - 2017-01-11 13:36:53 --> Model Class Initialized
INFO - 2017-01-11 13:36:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:36:53 --> Model Class Initialized
INFO - 2017-01-11 13:36:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:36:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-11 13:36:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:36:53 --> Final output sent to browser
DEBUG - 2017-01-11 13:36:53 --> Total execution time: 0.0803
INFO - 2017-01-11 13:37:02 --> Config Class Initialized
INFO - 2017-01-11 13:37:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:02 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:02 --> URI Class Initialized
INFO - 2017-01-11 13:37:02 --> Router Class Initialized
INFO - 2017-01-11 13:37:02 --> Output Class Initialized
INFO - 2017-01-11 13:37:02 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:02 --> Input Class Initialized
INFO - 2017-01-11 13:37:02 --> Language Class Initialized
INFO - 2017-01-11 13:37:02 --> Loader Class Initialized
INFO - 2017-01-11 13:37:02 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:02 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:02 --> Controller Class Initialized
INFO - 2017-01-11 13:37:02 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:02 --> Model Class Initialized
INFO - 2017-01-11 13:37:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:02 --> Helper loaded: form_helper
INFO - 2017-01-11 13:37:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-11 13:37:02 --> Could not find the language line "import_user"
INFO - 2017-01-11 13:37:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-11 13:37:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:02 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:02 --> Total execution time: 0.0917
INFO - 2017-01-11 13:37:07 --> Config Class Initialized
INFO - 2017-01-11 13:37:07 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:07 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:07 --> URI Class Initialized
INFO - 2017-01-11 13:37:07 --> Router Class Initialized
INFO - 2017-01-11 13:37:07 --> Output Class Initialized
INFO - 2017-01-11 13:37:07 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:07 --> Input Class Initialized
INFO - 2017-01-11 13:37:07 --> Language Class Initialized
INFO - 2017-01-11 13:37:07 --> Loader Class Initialized
INFO - 2017-01-11 13:37:07 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:07 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:07 --> Controller Class Initialized
INFO - 2017-01-11 13:37:07 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:07 --> Model Class Initialized
INFO - 2017-01-11 13:37:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:07 --> Config Class Initialized
INFO - 2017-01-11 13:37:07 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:07 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:07 --> URI Class Initialized
INFO - 2017-01-11 13:37:07 --> Router Class Initialized
INFO - 2017-01-11 13:37:07 --> Output Class Initialized
INFO - 2017-01-11 13:37:07 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:07 --> Input Class Initialized
INFO - 2017-01-11 13:37:07 --> Language Class Initialized
INFO - 2017-01-11 13:37:07 --> Loader Class Initialized
INFO - 2017-01-11 13:37:07 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:07 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:07 --> Controller Class Initialized
INFO - 2017-01-11 13:37:07 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:07 --> Model Class Initialized
INFO - 2017-01-11 13:37:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:37:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:37:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:37:07 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:07 --> Total execution time: 0.0652
INFO - 2017-01-11 13:37:12 --> Config Class Initialized
INFO - 2017-01-11 13:37:12 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:12 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:12 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:12 --> URI Class Initialized
INFO - 2017-01-11 13:37:12 --> Router Class Initialized
INFO - 2017-01-11 13:37:12 --> Output Class Initialized
INFO - 2017-01-11 13:37:12 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:12 --> Input Class Initialized
INFO - 2017-01-11 13:37:12 --> Language Class Initialized
INFO - 2017-01-11 13:37:12 --> Loader Class Initialized
INFO - 2017-01-11 13:37:12 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:12 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:12 --> Controller Class Initialized
INFO - 2017-01-11 13:37:12 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:12 --> Model Class Initialized
INFO - 2017-01-11 13:37:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:12 --> Config Class Initialized
INFO - 2017-01-11 13:37:12 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:12 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:12 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:12 --> URI Class Initialized
INFO - 2017-01-11 13:37:12 --> Router Class Initialized
INFO - 2017-01-11 13:37:12 --> Output Class Initialized
INFO - 2017-01-11 13:37:12 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:12 --> Input Class Initialized
INFO - 2017-01-11 13:37:12 --> Language Class Initialized
INFO - 2017-01-11 13:37:12 --> Loader Class Initialized
INFO - 2017-01-11 13:37:12 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:12 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:12 --> Controller Class Initialized
INFO - 2017-01-11 13:37:12 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:12 --> Model Class Initialized
INFO - 2017-01-11 13:37:12 --> Model Class Initialized
INFO - 2017-01-11 13:37:12 --> Model Class Initialized
INFO - 2017-01-11 13:37:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-11 13:37:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:12 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:12 --> Total execution time: 0.0991
INFO - 2017-01-11 13:37:15 --> Config Class Initialized
INFO - 2017-01-11 13:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:15 --> URI Class Initialized
INFO - 2017-01-11 13:37:15 --> Router Class Initialized
INFO - 2017-01-11 13:37:15 --> Output Class Initialized
INFO - 2017-01-11 13:37:15 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:15 --> Input Class Initialized
INFO - 2017-01-11 13:37:15 --> Language Class Initialized
INFO - 2017-01-11 13:37:15 --> Loader Class Initialized
INFO - 2017-01-11 13:37:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:15 --> Controller Class Initialized
INFO - 2017-01-11 13:37:15 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:15 --> Model Class Initialized
INFO - 2017-01-11 13:37:15 --> Model Class Initialized
INFO - 2017-01-11 13:37:15 --> Model Class Initialized
INFO - 2017-01-11 13:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-11 13:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:15 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:15 --> Total execution time: 0.1272
INFO - 2017-01-11 13:37:18 --> Config Class Initialized
INFO - 2017-01-11 13:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:18 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:18 --> URI Class Initialized
INFO - 2017-01-11 13:37:18 --> Router Class Initialized
INFO - 2017-01-11 13:37:18 --> Output Class Initialized
INFO - 2017-01-11 13:37:18 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:18 --> Input Class Initialized
INFO - 2017-01-11 13:37:18 --> Language Class Initialized
INFO - 2017-01-11 13:37:18 --> Loader Class Initialized
INFO - 2017-01-11 13:37:18 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:18 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:18 --> Controller Class Initialized
INFO - 2017-01-11 13:37:18 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:18 --> Config Class Initialized
INFO - 2017-01-11 13:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:18 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:18 --> URI Class Initialized
INFO - 2017-01-11 13:37:18 --> Router Class Initialized
INFO - 2017-01-11 13:37:18 --> Output Class Initialized
INFO - 2017-01-11 13:37:18 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:18 --> Input Class Initialized
INFO - 2017-01-11 13:37:18 --> Language Class Initialized
INFO - 2017-01-11 13:37:18 --> Loader Class Initialized
INFO - 2017-01-11 13:37:18 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:18 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:18 --> Controller Class Initialized
INFO - 2017-01-11 13:37:18 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-11 13:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:18 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:18 --> Total execution time: 0.1189
INFO - 2017-01-11 13:37:18 --> Config Class Initialized
INFO - 2017-01-11 13:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:18 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:18 --> URI Class Initialized
INFO - 2017-01-11 13:37:18 --> Router Class Initialized
INFO - 2017-01-11 13:37:18 --> Output Class Initialized
INFO - 2017-01-11 13:37:18 --> Config Class Initialized
INFO - 2017-01-11 13:37:18 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:18 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:18 --> Input Class Initialized
INFO - 2017-01-11 13:37:18 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:18 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:18 --> URI Class Initialized
INFO - 2017-01-11 13:37:18 --> Loader Class Initialized
INFO - 2017-01-11 13:37:18 --> Router Class Initialized
INFO - 2017-01-11 13:37:18 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:18 --> Output Class Initialized
INFO - 2017-01-11 13:37:18 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:18 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:18 --> Input Class Initialized
INFO - 2017-01-11 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:18 --> Language Class Initialized
INFO - 2017-01-11 13:37:18 --> Controller Class Initialized
INFO - 2017-01-11 13:37:18 --> Loader Class Initialized
INFO - 2017-01-11 13:37:18 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:18 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:18 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Model Class Initialized
INFO - 2017-01-11 13:37:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:18 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:18 --> Total execution time: 0.1079
INFO - 2017-01-11 13:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:18 --> Controller Class Initialized
INFO - 2017-01-11 13:37:18 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:19 --> Model Class Initialized
INFO - 2017-01-11 13:37:19 --> Model Class Initialized
INFO - 2017-01-11 13:37:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:37:19 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:37:19 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:19 --> Total execution time: 0.1427
INFO - 2017-01-11 13:37:21 --> Config Class Initialized
INFO - 2017-01-11 13:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:21 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:21 --> Config Class Initialized
INFO - 2017-01-11 13:37:21 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:21 --> URI Class Initialized
INFO - 2017-01-11 13:37:21 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:21 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:21 --> Output Class Initialized
INFO - 2017-01-11 13:37:21 --> URI Class Initialized
INFO - 2017-01-11 13:37:21 --> Security Class Initialized
INFO - 2017-01-11 13:37:21 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:21 --> Input Class Initialized
INFO - 2017-01-11 13:37:21 --> Output Class Initialized
INFO - 2017-01-11 13:37:21 --> Language Class Initialized
INFO - 2017-01-11 13:37:21 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:21 --> Input Class Initialized
INFO - 2017-01-11 13:37:21 --> Loader Class Initialized
INFO - 2017-01-11 13:37:21 --> Language Class Initialized
INFO - 2017-01-11 13:37:21 --> Loader Class Initialized
INFO - 2017-01-11 13:37:21 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:21 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:21 --> Controller Class Initialized
INFO - 2017-01-11 13:37:21 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:21 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:21 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:21 --> Model Class Initialized
INFO - 2017-01-11 13:37:21 --> Model Class Initialized
INFO - 2017-01-11 13:37:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:21 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:21 --> Total execution time: 0.1243
INFO - 2017-01-11 13:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:21 --> Controller Class Initialized
INFO - 2017-01-11 13:37:21 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:21 --> Model Class Initialized
INFO - 2017-01-11 13:37:21 --> Model Class Initialized
INFO - 2017-01-11 13:37:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:21 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:21 --> Total execution time: 0.1697
INFO - 2017-01-11 13:37:23 --> Config Class Initialized
INFO - 2017-01-11 13:37:23 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:23 --> URI Class Initialized
INFO - 2017-01-11 13:37:23 --> Router Class Initialized
INFO - 2017-01-11 13:37:23 --> Output Class Initialized
INFO - 2017-01-11 13:37:23 --> Security Class Initialized
INFO - 2017-01-11 13:37:23 --> Config Class Initialized
DEBUG - 2017-01-11 13:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:23 --> Input Class Initialized
INFO - 2017-01-11 13:37:23 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:23 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:23 --> URI Class Initialized
INFO - 2017-01-11 13:37:23 --> Router Class Initialized
INFO - 2017-01-11 13:37:23 --> Loader Class Initialized
INFO - 2017-01-11 13:37:23 --> Output Class Initialized
INFO - 2017-01-11 13:37:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:23 --> Security Class Initialized
INFO - 2017-01-11 13:37:23 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:23 --> Input Class Initialized
INFO - 2017-01-11 13:37:23 --> Language Class Initialized
INFO - 2017-01-11 13:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:23 --> Controller Class Initialized
INFO - 2017-01-11 13:37:23 --> Loader Class Initialized
INFO - 2017-01-11 13:37:23 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:23 --> Model Class Initialized
INFO - 2017-01-11 13:37:23 --> Model Class Initialized
INFO - 2017-01-11 13:37:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:23 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:23 --> Total execution time: 0.1106
INFO - 2017-01-11 13:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:23 --> Controller Class Initialized
INFO - 2017-01-11 13:37:23 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:23 --> Model Class Initialized
INFO - 2017-01-11 13:37:23 --> Model Class Initialized
INFO - 2017-01-11 13:37:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:23 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:23 --> Total execution time: 0.1721
INFO - 2017-01-11 13:37:24 --> Config Class Initialized
INFO - 2017-01-11 13:37:24 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:24 --> Config Class Initialized
INFO - 2017-01-11 13:37:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:24 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:24 --> URI Class Initialized
INFO - 2017-01-11 13:37:24 --> URI Class Initialized
INFO - 2017-01-11 13:37:24 --> Router Class Initialized
INFO - 2017-01-11 13:37:24 --> Router Class Initialized
INFO - 2017-01-11 13:37:24 --> Output Class Initialized
INFO - 2017-01-11 13:37:24 --> Output Class Initialized
INFO - 2017-01-11 13:37:24 --> Security Class Initialized
INFO - 2017-01-11 13:37:24 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:24 --> Input Class Initialized
DEBUG - 2017-01-11 13:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:24 --> Input Class Initialized
INFO - 2017-01-11 13:37:24 --> Language Class Initialized
INFO - 2017-01-11 13:37:24 --> Language Class Initialized
INFO - 2017-01-11 13:37:24 --> Loader Class Initialized
INFO - 2017-01-11 13:37:24 --> Loader Class Initialized
INFO - 2017-01-11 13:37:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:24 --> Controller Class Initialized
INFO - 2017-01-11 13:37:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:24 --> Model Class Initialized
INFO - 2017-01-11 13:37:24 --> Model Class Initialized
INFO - 2017-01-11 13:37:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:24 --> Total execution time: 0.1347
INFO - 2017-01-11 13:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:24 --> Controller Class Initialized
INFO - 2017-01-11 13:37:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:24 --> Model Class Initialized
INFO - 2017-01-11 13:37:24 --> Model Class Initialized
INFO - 2017-01-11 13:37:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:24 --> Total execution time: 0.1850
INFO - 2017-01-11 13:37:26 --> Config Class Initialized
INFO - 2017-01-11 13:37:26 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:26 --> Config Class Initialized
INFO - 2017-01-11 13:37:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:26 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:26 --> URI Class Initialized
INFO - 2017-01-11 13:37:26 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:26 --> URI Class Initialized
INFO - 2017-01-11 13:37:26 --> Router Class Initialized
INFO - 2017-01-11 13:37:26 --> Router Class Initialized
INFO - 2017-01-11 13:37:26 --> Output Class Initialized
INFO - 2017-01-11 13:37:26 --> Output Class Initialized
INFO - 2017-01-11 13:37:26 --> Security Class Initialized
INFO - 2017-01-11 13:37:26 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:26 --> Input Class Initialized
INFO - 2017-01-11 13:37:26 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:26 --> Input Class Initialized
INFO - 2017-01-11 13:37:26 --> Language Class Initialized
INFO - 2017-01-11 13:37:26 --> Loader Class Initialized
INFO - 2017-01-11 13:37:26 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:26 --> Loader Class Initialized
INFO - 2017-01-11 13:37:26 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:26 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:26 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:26 --> Controller Class Initialized
INFO - 2017-01-11 13:37:26 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:26 --> Model Class Initialized
INFO - 2017-01-11 13:37:26 --> Model Class Initialized
INFO - 2017-01-11 13:37:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:26 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:26 --> Total execution time: 0.0933
INFO - 2017-01-11 13:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:26 --> Controller Class Initialized
INFO - 2017-01-11 13:37:26 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:26 --> Model Class Initialized
INFO - 2017-01-11 13:37:26 --> Model Class Initialized
INFO - 2017-01-11 13:37:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:26 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:26 --> Total execution time: 0.1631
INFO - 2017-01-11 13:37:28 --> Config Class Initialized
INFO - 2017-01-11 13:37:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:28 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:28 --> Config Class Initialized
INFO - 2017-01-11 13:37:28 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:28 --> URI Class Initialized
INFO - 2017-01-11 13:37:28 --> Router Class Initialized
INFO - 2017-01-11 13:37:28 --> Config Class Initialized
INFO - 2017-01-11 13:37:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:28 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:28 --> URI Class Initialized
DEBUG - 2017-01-11 13:37:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:28 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:28 --> Router Class Initialized
INFO - 2017-01-11 13:37:28 --> URI Class Initialized
INFO - 2017-01-11 13:37:28 --> Output Class Initialized
INFO - 2017-01-11 13:37:28 --> Output Class Initialized
INFO - 2017-01-11 13:37:28 --> Router Class Initialized
INFO - 2017-01-11 13:37:28 --> Security Class Initialized
INFO - 2017-01-11 13:37:28 --> Output Class Initialized
INFO - 2017-01-11 13:37:28 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:28 --> Security Class Initialized
INFO - 2017-01-11 13:37:28 --> Input Class Initialized
INFO - 2017-01-11 13:37:28 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:28 --> Input Class Initialized
INFO - 2017-01-11 13:37:28 --> Input Class Initialized
INFO - 2017-01-11 13:37:28 --> Language Class Initialized
INFO - 2017-01-11 13:37:28 --> Language Class Initialized
INFO - 2017-01-11 13:37:28 --> Loader Class Initialized
INFO - 2017-01-11 13:37:28 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:28 --> Loader Class Initialized
INFO - 2017-01-11 13:37:28 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:28 --> Loader Class Initialized
INFO - 2017-01-11 13:37:28 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:28 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:28 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:28 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:28 --> Controller Class Initialized
INFO - 2017-01-11 13:37:28 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:28 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:28 --> Total execution time: 0.1716
INFO - 2017-01-11 13:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:28 --> Controller Class Initialized
INFO - 2017-01-11 13:37:28 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:28 --> Controller Class Initialized
INFO - 2017-01-11 13:37:28 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:28 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:28 --> Total execution time: 0.2783
INFO - 2017-01-11 13:37:28 --> Config Class Initialized
INFO - 2017-01-11 13:37:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:28 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:28 --> URI Class Initialized
INFO - 2017-01-11 13:37:28 --> Router Class Initialized
INFO - 2017-01-11 13:37:28 --> Output Class Initialized
INFO - 2017-01-11 13:37:28 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:28 --> Input Class Initialized
INFO - 2017-01-11 13:37:28 --> Language Class Initialized
INFO - 2017-01-11 13:37:28 --> Loader Class Initialized
INFO - 2017-01-11 13:37:28 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:28 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:28 --> Controller Class Initialized
INFO - 2017-01-11 13:37:28 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Model Class Initialized
INFO - 2017-01-11 13:37:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2017-01-11 13:37:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:28 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:28 --> Total execution time: 0.1166
INFO - 2017-01-11 13:37:32 --> Config Class Initialized
INFO - 2017-01-11 13:37:32 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:32 --> URI Class Initialized
INFO - 2017-01-11 13:37:32 --> Router Class Initialized
INFO - 2017-01-11 13:37:32 --> Output Class Initialized
INFO - 2017-01-11 13:37:32 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:32 --> Input Class Initialized
INFO - 2017-01-11 13:37:32 --> Language Class Initialized
INFO - 2017-01-11 13:37:32 --> Loader Class Initialized
INFO - 2017-01-11 13:37:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:32 --> Controller Class Initialized
INFO - 2017-01-11 13:37:32 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:32 --> Config Class Initialized
INFO - 2017-01-11 13:37:32 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:32 --> URI Class Initialized
INFO - 2017-01-11 13:37:32 --> Router Class Initialized
INFO - 2017-01-11 13:37:32 --> Output Class Initialized
INFO - 2017-01-11 13:37:32 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:32 --> Input Class Initialized
INFO - 2017-01-11 13:37:32 --> Language Class Initialized
INFO - 2017-01-11 13:37:32 --> Loader Class Initialized
INFO - 2017-01-11 13:37:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:32 --> Controller Class Initialized
INFO - 2017-01-11 13:37:32 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2017-01-11 13:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:32 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:32 --> Total execution time: 0.0961
INFO - 2017-01-11 13:37:32 --> Config Class Initialized
INFO - 2017-01-11 13:37:32 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:32 --> Config Class Initialized
DEBUG - 2017-01-11 13:37:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:32 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:32 --> URI Class Initialized
DEBUG - 2017-01-11 13:37:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:32 --> Router Class Initialized
INFO - 2017-01-11 13:37:32 --> URI Class Initialized
INFO - 2017-01-11 13:37:32 --> Output Class Initialized
INFO - 2017-01-11 13:37:32 --> Router Class Initialized
INFO - 2017-01-11 13:37:32 --> Security Class Initialized
INFO - 2017-01-11 13:37:32 --> Output Class Initialized
DEBUG - 2017-01-11 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:32 --> Input Class Initialized
INFO - 2017-01-11 13:37:32 --> Security Class Initialized
INFO - 2017-01-11 13:37:32 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:32 --> Input Class Initialized
INFO - 2017-01-11 13:37:32 --> Language Class Initialized
INFO - 2017-01-11 13:37:32 --> Loader Class Initialized
INFO - 2017-01-11 13:37:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:32 --> Loader Class Initialized
INFO - 2017-01-11 13:37:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:32 --> Controller Class Initialized
INFO - 2017-01-11 13:37:32 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:32 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:32 --> Total execution time: 0.1191
INFO - 2017-01-11 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:32 --> Controller Class Initialized
INFO - 2017-01-11 13:37:32 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Model Class Initialized
INFO - 2017-01-11 13:37:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:37:32 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:37:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:37:32 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:32 --> Total execution time: 0.1976
INFO - 2017-01-11 13:37:34 --> Config Class Initialized
INFO - 2017-01-11 13:37:34 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:34 --> Config Class Initialized
DEBUG - 2017-01-11 13:37:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:34 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:34 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:34 --> URI Class Initialized
INFO - 2017-01-11 13:37:34 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:34 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:34 --> Output Class Initialized
INFO - 2017-01-11 13:37:34 --> URI Class Initialized
INFO - 2017-01-11 13:37:34 --> Security Class Initialized
INFO - 2017-01-11 13:37:34 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:34 --> Input Class Initialized
INFO - 2017-01-11 13:37:34 --> Language Class Initialized
INFO - 2017-01-11 13:37:34 --> Output Class Initialized
INFO - 2017-01-11 13:37:34 --> Loader Class Initialized
INFO - 2017-01-11 13:37:34 --> Security Class Initialized
INFO - 2017-01-11 13:37:34 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:34 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:34 --> Input Class Initialized
INFO - 2017-01-11 13:37:34 --> Language Class Initialized
INFO - 2017-01-11 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:34 --> Controller Class Initialized
INFO - 2017-01-11 13:37:34 --> Loader Class Initialized
INFO - 2017-01-11 13:37:34 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:34 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:34 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:34 --> Model Class Initialized
INFO - 2017-01-11 13:37:34 --> Model Class Initialized
INFO - 2017-01-11 13:37:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:34 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:34 --> Total execution time: 0.1039
INFO - 2017-01-11 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:34 --> Controller Class Initialized
INFO - 2017-01-11 13:37:34 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:34 --> Model Class Initialized
INFO - 2017-01-11 13:37:34 --> Model Class Initialized
INFO - 2017-01-11 13:37:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:34 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:34 --> Total execution time: 0.1887
INFO - 2017-01-11 13:37:36 --> Config Class Initialized
INFO - 2017-01-11 13:37:36 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:36 --> Config Class Initialized
INFO - 2017-01-11 13:37:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:36 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:36 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:36 --> URI Class Initialized
INFO - 2017-01-11 13:37:36 --> URI Class Initialized
INFO - 2017-01-11 13:37:36 --> Router Class Initialized
INFO - 2017-01-11 13:37:36 --> Router Class Initialized
INFO - 2017-01-11 13:37:36 --> Output Class Initialized
INFO - 2017-01-11 13:37:36 --> Output Class Initialized
INFO - 2017-01-11 13:37:36 --> Security Class Initialized
INFO - 2017-01-11 13:37:36 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:36 --> Input Class Initialized
INFO - 2017-01-11 13:37:36 --> Input Class Initialized
INFO - 2017-01-11 13:37:36 --> Language Class Initialized
INFO - 2017-01-11 13:37:36 --> Language Class Initialized
INFO - 2017-01-11 13:37:36 --> Loader Class Initialized
INFO - 2017-01-11 13:37:36 --> Loader Class Initialized
INFO - 2017-01-11 13:37:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:36 --> Controller Class Initialized
INFO - 2017-01-11 13:37:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:36 --> Model Class Initialized
INFO - 2017-01-11 13:37:36 --> Model Class Initialized
INFO - 2017-01-11 13:37:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:36 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:36 --> Total execution time: 0.0950
INFO - 2017-01-11 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:36 --> Controller Class Initialized
INFO - 2017-01-11 13:37:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:36 --> Model Class Initialized
INFO - 2017-01-11 13:37:36 --> Model Class Initialized
INFO - 2017-01-11 13:37:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:36 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:36 --> Total execution time: 0.1530
INFO - 2017-01-11 13:37:37 --> Config Class Initialized
INFO - 2017-01-11 13:37:37 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:37 --> Config Class Initialized
INFO - 2017-01-11 13:37:37 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:37 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:37 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:37 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:37 --> URI Class Initialized
INFO - 2017-01-11 13:37:37 --> URI Class Initialized
INFO - 2017-01-11 13:37:37 --> Router Class Initialized
INFO - 2017-01-11 13:37:37 --> Router Class Initialized
INFO - 2017-01-11 13:37:37 --> Output Class Initialized
INFO - 2017-01-11 13:37:37 --> Output Class Initialized
INFO - 2017-01-11 13:37:37 --> Security Class Initialized
INFO - 2017-01-11 13:37:37 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:37 --> Input Class Initialized
DEBUG - 2017-01-11 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:37 --> Input Class Initialized
INFO - 2017-01-11 13:37:37 --> Language Class Initialized
INFO - 2017-01-11 13:37:37 --> Language Class Initialized
INFO - 2017-01-11 13:37:37 --> Loader Class Initialized
INFO - 2017-01-11 13:37:37 --> Loader Class Initialized
INFO - 2017-01-11 13:37:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:37 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:37 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:37 --> Controller Class Initialized
INFO - 2017-01-11 13:37:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:37 --> Model Class Initialized
INFO - 2017-01-11 13:37:37 --> Model Class Initialized
INFO - 2017-01-11 13:37:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:37 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:37 --> Total execution time: 0.1330
INFO - 2017-01-11 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:37 --> Controller Class Initialized
INFO - 2017-01-11 13:37:37 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:37 --> Model Class Initialized
INFO - 2017-01-11 13:37:37 --> Model Class Initialized
INFO - 2017-01-11 13:37:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:37 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:37 --> Total execution time: 0.2009
INFO - 2017-01-11 13:37:39 --> Config Class Initialized
INFO - 2017-01-11 13:37:39 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:39 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:39 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:39 --> URI Class Initialized
INFO - 2017-01-11 13:37:39 --> Config Class Initialized
INFO - 2017-01-11 13:37:39 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:39 --> Router Class Initialized
INFO - 2017-01-11 13:37:39 --> Output Class Initialized
DEBUG - 2017-01-11 13:37:39 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:39 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:39 --> Security Class Initialized
INFO - 2017-01-11 13:37:39 --> URI Class Initialized
DEBUG - 2017-01-11 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:39 --> Input Class Initialized
INFO - 2017-01-11 13:37:39 --> Router Class Initialized
INFO - 2017-01-11 13:37:39 --> Language Class Initialized
INFO - 2017-01-11 13:37:39 --> Output Class Initialized
INFO - 2017-01-11 13:37:39 --> Loader Class Initialized
INFO - 2017-01-11 13:37:39 --> Security Class Initialized
INFO - 2017-01-11 13:37:39 --> Helper loaded: url_helper
DEBUG - 2017-01-11 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:39 --> Input Class Initialized
INFO - 2017-01-11 13:37:39 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:39 --> Language Class Initialized
INFO - 2017-01-11 13:37:39 --> Loader Class Initialized
INFO - 2017-01-11 13:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:39 --> Controller Class Initialized
INFO - 2017-01-11 13:37:39 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:39 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:39 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:39 --> Model Class Initialized
INFO - 2017-01-11 13:37:39 --> Model Class Initialized
INFO - 2017-01-11 13:37:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:39 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:39 --> Total execution time: 0.1198
INFO - 2017-01-11 13:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:39 --> Controller Class Initialized
INFO - 2017-01-11 13:37:39 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:39 --> Model Class Initialized
INFO - 2017-01-11 13:37:39 --> Model Class Initialized
INFO - 2017-01-11 13:37:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:39 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:39 --> Total execution time: 0.2121
INFO - 2017-01-11 13:37:40 --> Config Class Initialized
INFO - 2017-01-11 13:37:41 --> Config Class Initialized
INFO - 2017-01-11 13:37:41 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:41 --> URI Class Initialized
DEBUG - 2017-01-11 13:37:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:41 --> Router Class Initialized
INFO - 2017-01-11 13:37:41 --> URI Class Initialized
INFO - 2017-01-11 13:37:41 --> Output Class Initialized
INFO - 2017-01-11 13:37:41 --> Config Class Initialized
INFO - 2017-01-11 13:37:41 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:41 --> Router Class Initialized
INFO - 2017-01-11 13:37:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:41 --> Input Class Initialized
INFO - 2017-01-11 13:37:41 --> Output Class Initialized
INFO - 2017-01-11 13:37:41 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:41 --> Security Class Initialized
INFO - 2017-01-11 13:37:41 --> URI Class Initialized
DEBUG - 2017-01-11 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:41 --> Input Class Initialized
INFO - 2017-01-11 13:37:41 --> Language Class Initialized
INFO - 2017-01-11 13:37:41 --> Router Class Initialized
INFO - 2017-01-11 13:37:41 --> Loader Class Initialized
INFO - 2017-01-11 13:37:41 --> Output Class Initialized
INFO - 2017-01-11 13:37:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:41 --> Input Class Initialized
INFO - 2017-01-11 13:37:41 --> Loader Class Initialized
INFO - 2017-01-11 13:37:41 --> Language Class Initialized
INFO - 2017-01-11 13:37:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:41 --> Controller Class Initialized
INFO - 2017-01-11 13:37:41 --> Loader Class Initialized
INFO - 2017-01-11 13:37:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:41 --> Total execution time: 0.1525
INFO - 2017-01-11 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:41 --> Controller Class Initialized
INFO - 2017-01-11 13:37:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:41 --> Total execution time: 0.2288
INFO - 2017-01-11 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:41 --> Controller Class Initialized
INFO - 2017-01-11 13:37:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:41 --> Config Class Initialized
INFO - 2017-01-11 13:37:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:41 --> URI Class Initialized
INFO - 2017-01-11 13:37:41 --> Router Class Initialized
INFO - 2017-01-11 13:37:41 --> Output Class Initialized
INFO - 2017-01-11 13:37:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:41 --> Input Class Initialized
INFO - 2017-01-11 13:37:41 --> Language Class Initialized
INFO - 2017-01-11 13:37:41 --> Loader Class Initialized
INFO - 2017-01-11 13:37:41 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:41 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:41 --> Controller Class Initialized
INFO - 2017-01-11 13:37:41 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Model Class Initialized
INFO - 2017-01-11 13:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2017-01-11 13:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:41 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:41 --> Total execution time: 0.1180
INFO - 2017-01-11 13:37:43 --> Config Class Initialized
INFO - 2017-01-11 13:37:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:43 --> URI Class Initialized
INFO - 2017-01-11 13:37:43 --> Router Class Initialized
INFO - 2017-01-11 13:37:43 --> Output Class Initialized
INFO - 2017-01-11 13:37:43 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:43 --> Input Class Initialized
INFO - 2017-01-11 13:37:43 --> Language Class Initialized
INFO - 2017-01-11 13:37:43 --> Loader Class Initialized
INFO - 2017-01-11 13:37:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:43 --> Controller Class Initialized
INFO - 2017-01-11 13:37:43 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:43 --> Config Class Initialized
INFO - 2017-01-11 13:37:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:43 --> URI Class Initialized
INFO - 2017-01-11 13:37:43 --> Router Class Initialized
INFO - 2017-01-11 13:37:43 --> Output Class Initialized
INFO - 2017-01-11 13:37:43 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:43 --> Input Class Initialized
INFO - 2017-01-11 13:37:43 --> Language Class Initialized
INFO - 2017-01-11 13:37:43 --> Loader Class Initialized
INFO - 2017-01-11 13:37:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:43 --> Controller Class Initialized
INFO - 2017-01-11 13:37:43 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2017-01-11 13:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:43 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:43 --> Total execution time: 0.1172
INFO - 2017-01-11 13:37:43 --> Config Class Initialized
INFO - 2017-01-11 13:37:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:43 --> Config Class Initialized
INFO - 2017-01-11 13:37:43 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:43 --> URI Class Initialized
INFO - 2017-01-11 13:37:43 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:43 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:43 --> Output Class Initialized
INFO - 2017-01-11 13:37:43 --> URI Class Initialized
INFO - 2017-01-11 13:37:43 --> Security Class Initialized
INFO - 2017-01-11 13:37:43 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:43 --> Input Class Initialized
INFO - 2017-01-11 13:37:43 --> Output Class Initialized
INFO - 2017-01-11 13:37:43 --> Language Class Initialized
INFO - 2017-01-11 13:37:43 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:43 --> Input Class Initialized
INFO - 2017-01-11 13:37:43 --> Loader Class Initialized
INFO - 2017-01-11 13:37:43 --> Language Class Initialized
INFO - 2017-01-11 13:37:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:43 --> Loader Class Initialized
INFO - 2017-01-11 13:37:43 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:43 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:43 --> Controller Class Initialized
INFO - 2017-01-11 13:37:43 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:43 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:43 --> Total execution time: 0.0977
INFO - 2017-01-11 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:43 --> Controller Class Initialized
INFO - 2017-01-11 13:37:43 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Model Class Initialized
INFO - 2017-01-11 13:37:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:37:43 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:37:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:37:43 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:43 --> Total execution time: 0.1837
INFO - 2017-01-11 13:37:45 --> Config Class Initialized
INFO - 2017-01-11 13:37:45 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:45 --> Config Class Initialized
INFO - 2017-01-11 13:37:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:45 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:45 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:45 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:45 --> URI Class Initialized
INFO - 2017-01-11 13:37:45 --> URI Class Initialized
INFO - 2017-01-11 13:37:45 --> Router Class Initialized
INFO - 2017-01-11 13:37:45 --> Router Class Initialized
INFO - 2017-01-11 13:37:45 --> Output Class Initialized
INFO - 2017-01-11 13:37:45 --> Security Class Initialized
INFO - 2017-01-11 13:37:45 --> Output Class Initialized
DEBUG - 2017-01-11 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:45 --> Input Class Initialized
INFO - 2017-01-11 13:37:45 --> Security Class Initialized
INFO - 2017-01-11 13:37:45 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:45 --> Input Class Initialized
INFO - 2017-01-11 13:37:45 --> Language Class Initialized
INFO - 2017-01-11 13:37:45 --> Loader Class Initialized
INFO - 2017-01-11 13:37:45 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:45 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:45 --> Loader Class Initialized
INFO - 2017-01-11 13:37:45 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:45 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:45 --> Controller Class Initialized
INFO - 2017-01-11 13:37:45 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:45 --> Model Class Initialized
INFO - 2017-01-11 13:37:45 --> Model Class Initialized
INFO - 2017-01-11 13:37:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:45 --> Total execution time: 0.1024
INFO - 2017-01-11 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:45 --> Controller Class Initialized
INFO - 2017-01-11 13:37:45 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:45 --> Model Class Initialized
INFO - 2017-01-11 13:37:45 --> Model Class Initialized
INFO - 2017-01-11 13:37:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:45 --> Total execution time: 0.1819
INFO - 2017-01-11 13:37:47 --> Config Class Initialized
INFO - 2017-01-11 13:37:47 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:47 --> Config Class Initialized
INFO - 2017-01-11 13:37:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:47 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:47 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:47 --> URI Class Initialized
INFO - 2017-01-11 13:37:47 --> Router Class Initialized
INFO - 2017-01-11 13:37:47 --> Output Class Initialized
INFO - 2017-01-11 13:37:47 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:47 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:47 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:47 --> URI Class Initialized
INFO - 2017-01-11 13:37:47 --> Input Class Initialized
INFO - 2017-01-11 13:37:47 --> Language Class Initialized
INFO - 2017-01-11 13:37:47 --> Router Class Initialized
INFO - 2017-01-11 13:37:47 --> Output Class Initialized
INFO - 2017-01-11 13:37:47 --> Loader Class Initialized
INFO - 2017-01-11 13:37:47 --> Security Class Initialized
INFO - 2017-01-11 13:37:47 --> Helper loaded: url_helper
DEBUG - 2017-01-11 13:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:47 --> Input Class Initialized
INFO - 2017-01-11 13:37:47 --> Language Class Initialized
INFO - 2017-01-11 13:37:47 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:47 --> Loader Class Initialized
INFO - 2017-01-11 13:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:47 --> Controller Class Initialized
INFO - 2017-01-11 13:37:47 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:47 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:47 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:47 --> Model Class Initialized
INFO - 2017-01-11 13:37:47 --> Model Class Initialized
INFO - 2017-01-11 13:37:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:47 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:47 --> Total execution time: 0.1584
INFO - 2017-01-11 13:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:47 --> Controller Class Initialized
INFO - 2017-01-11 13:37:47 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:47 --> Model Class Initialized
INFO - 2017-01-11 13:37:47 --> Model Class Initialized
INFO - 2017-01-11 13:37:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:47 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:47 --> Total execution time: 0.2040
INFO - 2017-01-11 13:37:48 --> Config Class Initialized
INFO - 2017-01-11 13:37:48 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:48 --> Config Class Initialized
INFO - 2017-01-11 13:37:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:48 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:48 --> URI Class Initialized
INFO - 2017-01-11 13:37:48 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:48 --> URI Class Initialized
INFO - 2017-01-11 13:37:48 --> Router Class Initialized
INFO - 2017-01-11 13:37:48 --> Router Class Initialized
INFO - 2017-01-11 13:37:48 --> Output Class Initialized
INFO - 2017-01-11 13:37:48 --> Security Class Initialized
INFO - 2017-01-11 13:37:48 --> Output Class Initialized
DEBUG - 2017-01-11 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:48 --> Input Class Initialized
INFO - 2017-01-11 13:37:48 --> Language Class Initialized
INFO - 2017-01-11 13:37:48 --> Security Class Initialized
INFO - 2017-01-11 13:37:48 --> Loader Class Initialized
DEBUG - 2017-01-11 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:48 --> Input Class Initialized
INFO - 2017-01-11 13:37:48 --> Language Class Initialized
INFO - 2017-01-11 13:37:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:48 --> Loader Class Initialized
INFO - 2017-01-11 13:37:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:48 --> Controller Class Initialized
INFO - 2017-01-11 13:37:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:48 --> Model Class Initialized
INFO - 2017-01-11 13:37:48 --> Model Class Initialized
INFO - 2017-01-11 13:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:48 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:48 --> Total execution time: 0.1023
INFO - 2017-01-11 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:48 --> Controller Class Initialized
INFO - 2017-01-11 13:37:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:48 --> Model Class Initialized
INFO - 2017-01-11 13:37:48 --> Model Class Initialized
INFO - 2017-01-11 13:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:48 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:48 --> Total execution time: 0.1614
INFO - 2017-01-11 13:37:49 --> Config Class Initialized
INFO - 2017-01-11 13:37:49 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:49 --> Config Class Initialized
INFO - 2017-01-11 13:37:49 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:49 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:49 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:49 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:49 --> URI Class Initialized
INFO - 2017-01-11 13:37:49 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:49 --> Router Class Initialized
INFO - 2017-01-11 13:37:49 --> Output Class Initialized
INFO - 2017-01-11 13:37:49 --> Security Class Initialized
INFO - 2017-01-11 13:37:49 --> URI Class Initialized
DEBUG - 2017-01-11 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:49 --> Input Class Initialized
INFO - 2017-01-11 13:37:49 --> Language Class Initialized
INFO - 2017-01-11 13:37:49 --> Router Class Initialized
INFO - 2017-01-11 13:37:49 --> Output Class Initialized
INFO - 2017-01-11 13:37:49 --> Security Class Initialized
INFO - 2017-01-11 13:37:49 --> Loader Class Initialized
INFO - 2017-01-11 13:37:49 --> Helper loaded: url_helper
DEBUG - 2017-01-11 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:49 --> Input Class Initialized
INFO - 2017-01-11 13:37:49 --> Language Class Initialized
INFO - 2017-01-11 13:37:49 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:49 --> Loader Class Initialized
INFO - 2017-01-11 13:37:49 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:49 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:49 --> Controller Class Initialized
INFO - 2017-01-11 13:37:49 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:49 --> Model Class Initialized
INFO - 2017-01-11 13:37:50 --> Model Class Initialized
INFO - 2017-01-11 13:37:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:50 --> Total execution time: 0.1300
INFO - 2017-01-11 13:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:50 --> Controller Class Initialized
INFO - 2017-01-11 13:37:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:50 --> Model Class Initialized
INFO - 2017-01-11 13:37:50 --> Model Class Initialized
INFO - 2017-01-11 13:37:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:50 --> Total execution time: 0.1724
INFO - 2017-01-11 13:37:51 --> Config Class Initialized
INFO - 2017-01-11 13:37:51 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:51 --> Config Class Initialized
INFO - 2017-01-11 13:37:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:51 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:37:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:51 --> URI Class Initialized
INFO - 2017-01-11 13:37:51 --> Config Class Initialized
INFO - 2017-01-11 13:37:51 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:51 --> URI Class Initialized
INFO - 2017-01-11 13:37:51 --> Router Class Initialized
INFO - 2017-01-11 13:37:51 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:51 --> Output Class Initialized
INFO - 2017-01-11 13:37:51 --> URI Class Initialized
INFO - 2017-01-11 13:37:51 --> Security Class Initialized
INFO - 2017-01-11 13:37:51 --> Output Class Initialized
INFO - 2017-01-11 13:37:51 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:51 --> Input Class Initialized
INFO - 2017-01-11 13:37:51 --> Security Class Initialized
INFO - 2017-01-11 13:37:51 --> Output Class Initialized
INFO - 2017-01-11 13:37:51 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:51 --> Input Class Initialized
INFO - 2017-01-11 13:37:51 --> Security Class Initialized
INFO - 2017-01-11 13:37:51 --> Language Class Initialized
DEBUG - 2017-01-11 13:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:51 --> Input Class Initialized
INFO - 2017-01-11 13:37:51 --> Language Class Initialized
INFO - 2017-01-11 13:37:51 --> Loader Class Initialized
INFO - 2017-01-11 13:37:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:51 --> Loader Class Initialized
INFO - 2017-01-11 13:37:51 --> Loader Class Initialized
INFO - 2017-01-11 13:37:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:51 --> Controller Class Initialized
INFO - 2017-01-11 13:37:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:51 --> Total execution time: 0.1249
INFO - 2017-01-11 13:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:51 --> Controller Class Initialized
INFO - 2017-01-11 13:37:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:51 --> Total execution time: 0.2061
INFO - 2017-01-11 13:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:51 --> Controller Class Initialized
INFO - 2017-01-11 13:37:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:51 --> Config Class Initialized
INFO - 2017-01-11 13:37:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:51 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:51 --> URI Class Initialized
INFO - 2017-01-11 13:37:51 --> Router Class Initialized
INFO - 2017-01-11 13:37:51 --> Output Class Initialized
INFO - 2017-01-11 13:37:51 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:51 --> Input Class Initialized
INFO - 2017-01-11 13:37:51 --> Language Class Initialized
INFO - 2017-01-11 13:37:51 --> Loader Class Initialized
INFO - 2017-01-11 13:37:51 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:51 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:51 --> Controller Class Initialized
INFO - 2017-01-11 13:37:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Model Class Initialized
INFO - 2017-01-11 13:37:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2017-01-11 13:37:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:51 --> Total execution time: 0.0848
INFO - 2017-01-11 13:37:53 --> Config Class Initialized
INFO - 2017-01-11 13:37:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:53 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:53 --> URI Class Initialized
INFO - 2017-01-11 13:37:53 --> Router Class Initialized
INFO - 2017-01-11 13:37:53 --> Output Class Initialized
INFO - 2017-01-11 13:37:53 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:53 --> Input Class Initialized
INFO - 2017-01-11 13:37:53 --> Language Class Initialized
INFO - 2017-01-11 13:37:53 --> Loader Class Initialized
INFO - 2017-01-11 13:37:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:53 --> Controller Class Initialized
INFO - 2017-01-11 13:37:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:53 --> Model Class Initialized
INFO - 2017-01-11 13:37:53 --> Model Class Initialized
INFO - 2017-01-11 13:37:53 --> Model Class Initialized
INFO - 2017-01-11 13:37:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:54 --> Config Class Initialized
INFO - 2017-01-11 13:37:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:54 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:54 --> URI Class Initialized
INFO - 2017-01-11 13:37:54 --> Router Class Initialized
INFO - 2017-01-11 13:37:54 --> Output Class Initialized
INFO - 2017-01-11 13:37:54 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:54 --> Input Class Initialized
INFO - 2017-01-11 13:37:54 --> Language Class Initialized
INFO - 2017-01-11 13:37:54 --> Loader Class Initialized
INFO - 2017-01-11 13:37:54 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:54 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:54 --> Controller Class Initialized
INFO - 2017-01-11 13:37:54 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:37:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2017-01-11 13:37:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:37:54 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:54 --> Total execution time: 0.1244
INFO - 2017-01-11 13:37:54 --> Config Class Initialized
INFO - 2017-01-11 13:37:54 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:54 --> Config Class Initialized
INFO - 2017-01-11 13:37:54 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:54 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:54 --> URI Class Initialized
INFO - 2017-01-11 13:37:54 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:54 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:54 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:54 --> URI Class Initialized
INFO - 2017-01-11 13:37:54 --> Output Class Initialized
INFO - 2017-01-11 13:37:54 --> Security Class Initialized
INFO - 2017-01-11 13:37:54 --> Router Class Initialized
DEBUG - 2017-01-11 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:54 --> Input Class Initialized
INFO - 2017-01-11 13:37:54 --> Output Class Initialized
INFO - 2017-01-11 13:37:54 --> Language Class Initialized
INFO - 2017-01-11 13:37:54 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:54 --> Loader Class Initialized
INFO - 2017-01-11 13:37:54 --> Input Class Initialized
INFO - 2017-01-11 13:37:54 --> Language Class Initialized
INFO - 2017-01-11 13:37:54 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:54 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:54 --> Loader Class Initialized
INFO - 2017-01-11 13:37:54 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:54 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:54 --> Controller Class Initialized
INFO - 2017-01-11 13:37:54 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:54 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:54 --> Total execution time: 0.1224
INFO - 2017-01-11 13:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:54 --> Controller Class Initialized
INFO - 2017-01-11 13:37:54 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Model Class Initialized
INFO - 2017-01-11 13:37:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:54 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:54 --> Total execution time: 0.1680
INFO - 2017-01-11 13:37:58 --> Config Class Initialized
INFO - 2017-01-11 13:37:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:37:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:58 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:58 --> URI Class Initialized
INFO - 2017-01-11 13:37:58 --> Router Class Initialized
INFO - 2017-01-11 13:37:58 --> Output Class Initialized
INFO - 2017-01-11 13:37:58 --> Security Class Initialized
DEBUG - 2017-01-11 13:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:58 --> Input Class Initialized
INFO - 2017-01-11 13:37:58 --> Language Class Initialized
INFO - 2017-01-11 13:37:58 --> Config Class Initialized
INFO - 2017-01-11 13:37:58 --> Loader Class Initialized
INFO - 2017-01-11 13:37:58 --> Hooks Class Initialized
INFO - 2017-01-11 13:37:58 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:58 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:37:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:37:58 --> Utf8 Class Initialized
INFO - 2017-01-11 13:37:58 --> URI Class Initialized
INFO - 2017-01-11 13:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:58 --> Controller Class Initialized
INFO - 2017-01-11 13:37:58 --> Router Class Initialized
INFO - 2017-01-11 13:37:58 --> Output Class Initialized
INFO - 2017-01-11 13:37:58 --> Security Class Initialized
INFO - 2017-01-11 13:37:58 --> Database Driver Class Initialized
DEBUG - 2017-01-11 13:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:37:58 --> Input Class Initialized
INFO - 2017-01-11 13:37:58 --> Language Class Initialized
INFO - 2017-01-11 13:37:58 --> Model Class Initialized
INFO - 2017-01-11 13:37:58 --> Model Class Initialized
INFO - 2017-01-11 13:37:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:58 --> Loader Class Initialized
INFO - 2017-01-11 13:37:58 --> Helper loaded: url_helper
INFO - 2017-01-11 13:37:58 --> Helper loaded: language_helper
INFO - 2017-01-11 13:37:58 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:58 --> Total execution time: 0.0967
INFO - 2017-01-11 13:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:37:58 --> Controller Class Initialized
INFO - 2017-01-11 13:37:58 --> Database Driver Class Initialized
INFO - 2017-01-11 13:37:58 --> Model Class Initialized
INFO - 2017-01-11 13:37:58 --> Model Class Initialized
INFO - 2017-01-11 13:37:58 --> Model Class Initialized
INFO - 2017-01-11 13:37:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:37:58 --> Final output sent to browser
DEBUG - 2017-01-11 13:37:58 --> Total execution time: 0.1493
INFO - 2017-01-11 13:38:00 --> Config Class Initialized
INFO - 2017-01-11 13:38:00 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:00 --> Config Class Initialized
INFO - 2017-01-11 13:38:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:00 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:00 --> URI Class Initialized
INFO - 2017-01-11 13:38:00 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:00 --> URI Class Initialized
INFO - 2017-01-11 13:38:00 --> Router Class Initialized
INFO - 2017-01-11 13:38:00 --> Router Class Initialized
INFO - 2017-01-11 13:38:00 --> Output Class Initialized
INFO - 2017-01-11 13:38:00 --> Output Class Initialized
INFO - 2017-01-11 13:38:00 --> Security Class Initialized
INFO - 2017-01-11 13:38:00 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:00 --> Input Class Initialized
INFO - 2017-01-11 13:38:00 --> Input Class Initialized
INFO - 2017-01-11 13:38:00 --> Language Class Initialized
INFO - 2017-01-11 13:38:00 --> Language Class Initialized
INFO - 2017-01-11 13:38:00 --> Loader Class Initialized
INFO - 2017-01-11 13:38:00 --> Loader Class Initialized
INFO - 2017-01-11 13:38:00 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:00 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:00 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:00 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:00 --> Controller Class Initialized
INFO - 2017-01-11 13:38:00 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:00 --> Model Class Initialized
INFO - 2017-01-11 13:38:00 --> Model Class Initialized
INFO - 2017-01-11 13:38:00 --> Model Class Initialized
INFO - 2017-01-11 13:38:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:00 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:00 --> Total execution time: 0.2383
INFO - 2017-01-11 13:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:00 --> Controller Class Initialized
INFO - 2017-01-11 13:38:00 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:00 --> Model Class Initialized
INFO - 2017-01-11 13:38:00 --> Model Class Initialized
INFO - 2017-01-11 13:38:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:00 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:00 --> Total execution time: 0.2720
INFO - 2017-01-11 13:38:01 --> Config Class Initialized
INFO - 2017-01-11 13:38:01 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:01 --> Config Class Initialized
INFO - 2017-01-11 13:38:01 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:01 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:01 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:01 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:01 --> URI Class Initialized
INFO - 2017-01-11 13:38:01 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:01 --> URI Class Initialized
INFO - 2017-01-11 13:38:01 --> Router Class Initialized
INFO - 2017-01-11 13:38:01 --> Router Class Initialized
INFO - 2017-01-11 13:38:01 --> Output Class Initialized
INFO - 2017-01-11 13:38:01 --> Output Class Initialized
INFO - 2017-01-11 13:38:01 --> Security Class Initialized
INFO - 2017-01-11 13:38:01 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:01 --> Input Class Initialized
INFO - 2017-01-11 13:38:01 --> Input Class Initialized
INFO - 2017-01-11 13:38:01 --> Language Class Initialized
INFO - 2017-01-11 13:38:01 --> Language Class Initialized
INFO - 2017-01-11 13:38:01 --> Loader Class Initialized
INFO - 2017-01-11 13:38:01 --> Loader Class Initialized
INFO - 2017-01-11 13:38:01 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:01 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:01 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:01 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:01 --> Controller Class Initialized
INFO - 2017-01-11 13:38:01 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:01 --> Model Class Initialized
INFO - 2017-01-11 13:38:01 --> Model Class Initialized
INFO - 2017-01-11 13:38:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:01 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:01 --> Total execution time: 0.0958
INFO - 2017-01-11 13:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:01 --> Controller Class Initialized
INFO - 2017-01-11 13:38:01 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:01 --> Model Class Initialized
INFO - 2017-01-11 13:38:01 --> Model Class Initialized
INFO - 2017-01-11 13:38:01 --> Model Class Initialized
INFO - 2017-01-11 13:38:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:02 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:02 --> Total execution time: 0.2069
INFO - 2017-01-11 13:38:03 --> Config Class Initialized
INFO - 2017-01-11 13:38:03 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:03 --> Config Class Initialized
INFO - 2017-01-11 13:38:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:03 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:03 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:03 --> URI Class Initialized
INFO - 2017-01-11 13:38:03 --> URI Class Initialized
INFO - 2017-01-11 13:38:03 --> Router Class Initialized
INFO - 2017-01-11 13:38:03 --> Output Class Initialized
INFO - 2017-01-11 13:38:03 --> Router Class Initialized
INFO - 2017-01-11 13:38:03 --> Security Class Initialized
INFO - 2017-01-11 13:38:03 --> Output Class Initialized
INFO - 2017-01-11 13:38:03 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:03 --> Input Class Initialized
INFO - 2017-01-11 13:38:03 --> Input Class Initialized
INFO - 2017-01-11 13:38:03 --> Language Class Initialized
INFO - 2017-01-11 13:38:03 --> Language Class Initialized
INFO - 2017-01-11 13:38:03 --> Loader Class Initialized
INFO - 2017-01-11 13:38:03 --> Loader Class Initialized
INFO - 2017-01-11 13:38:03 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:03 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:03 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:03 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:03 --> Controller Class Initialized
INFO - 2017-01-11 13:38:03 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:03 --> Model Class Initialized
INFO - 2017-01-11 13:38:03 --> Model Class Initialized
INFO - 2017-01-11 13:38:03 --> Model Class Initialized
INFO - 2017-01-11 13:38:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:03 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:03 --> Total execution time: 0.1897
INFO - 2017-01-11 13:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:03 --> Controller Class Initialized
INFO - 2017-01-11 13:38:03 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:03 --> Model Class Initialized
INFO - 2017-01-11 13:38:03 --> Model Class Initialized
INFO - 2017-01-11 13:38:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:03 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:03 --> Total execution time: 0.2440
INFO - 2017-01-11 13:38:05 --> Config Class Initialized
INFO - 2017-01-11 13:38:05 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:05 --> Config Class Initialized
INFO - 2017-01-11 13:38:05 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:05 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:05 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:05 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:05 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:05 --> URI Class Initialized
INFO - 2017-01-11 13:38:05 --> URI Class Initialized
INFO - 2017-01-11 13:38:05 --> Router Class Initialized
INFO - 2017-01-11 13:38:05 --> Router Class Initialized
INFO - 2017-01-11 13:38:05 --> Output Class Initialized
INFO - 2017-01-11 13:38:05 --> Output Class Initialized
INFO - 2017-01-11 13:38:05 --> Security Class Initialized
INFO - 2017-01-11 13:38:05 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:05 --> Input Class Initialized
INFO - 2017-01-11 13:38:05 --> Input Class Initialized
INFO - 2017-01-11 13:38:05 --> Language Class Initialized
INFO - 2017-01-11 13:38:05 --> Language Class Initialized
INFO - 2017-01-11 13:38:05 --> Loader Class Initialized
INFO - 2017-01-11 13:38:05 --> Loader Class Initialized
INFO - 2017-01-11 13:38:05 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:05 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:05 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:05 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:05 --> Controller Class Initialized
INFO - 2017-01-11 13:38:05 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:05 --> Model Class Initialized
INFO - 2017-01-11 13:38:05 --> Model Class Initialized
INFO - 2017-01-11 13:38:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:05 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:05 --> Total execution time: 0.0981
INFO - 2017-01-11 13:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:05 --> Controller Class Initialized
INFO - 2017-01-11 13:38:05 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:05 --> Model Class Initialized
INFO - 2017-01-11 13:38:05 --> Model Class Initialized
INFO - 2017-01-11 13:38:05 --> Model Class Initialized
INFO - 2017-01-11 13:38:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:05 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:05 --> Total execution time: 0.2101
INFO - 2017-01-11 13:38:06 --> Config Class Initialized
INFO - 2017-01-11 13:38:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:07 --> Config Class Initialized
INFO - 2017-01-11 13:38:07 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:07 --> URI Class Initialized
INFO - 2017-01-11 13:38:07 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:07 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:07 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:07 --> Output Class Initialized
INFO - 2017-01-11 13:38:07 --> URI Class Initialized
INFO - 2017-01-11 13:38:07 --> Security Class Initialized
INFO - 2017-01-11 13:38:07 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:07 --> Input Class Initialized
INFO - 2017-01-11 13:38:07 --> Output Class Initialized
INFO - 2017-01-11 13:38:07 --> Language Class Initialized
INFO - 2017-01-11 13:38:07 --> Loader Class Initialized
INFO - 2017-01-11 13:38:07 --> Security Class Initialized
INFO - 2017-01-11 13:38:07 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:07 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:07 --> Input Class Initialized
INFO - 2017-01-11 13:38:07 --> Language Class Initialized
INFO - 2017-01-11 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:07 --> Controller Class Initialized
INFO - 2017-01-11 13:38:07 --> Loader Class Initialized
INFO - 2017-01-11 13:38:07 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:07 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:07 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:07 --> Model Class Initialized
INFO - 2017-01-11 13:38:07 --> Model Class Initialized
INFO - 2017-01-11 13:38:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:07 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:07 --> Total execution time: 0.1099
INFO - 2017-01-11 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:07 --> Controller Class Initialized
INFO - 2017-01-11 13:38:07 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:07 --> Model Class Initialized
INFO - 2017-01-11 13:38:07 --> Model Class Initialized
INFO - 2017-01-11 13:38:07 --> Model Class Initialized
INFO - 2017-01-11 13:38:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:07 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:07 --> Total execution time: 0.2684
INFO - 2017-01-11 13:38:08 --> Config Class Initialized
INFO - 2017-01-11 13:38:08 --> Config Class Initialized
INFO - 2017-01-11 13:38:08 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 13:38:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:08 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:08 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:08 --> URI Class Initialized
INFO - 2017-01-11 13:38:08 --> URI Class Initialized
INFO - 2017-01-11 13:38:08 --> Router Class Initialized
INFO - 2017-01-11 13:38:08 --> Router Class Initialized
INFO - 2017-01-11 13:38:08 --> Output Class Initialized
INFO - 2017-01-11 13:38:08 --> Output Class Initialized
INFO - 2017-01-11 13:38:08 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:08 --> Input Class Initialized
INFO - 2017-01-11 13:38:08 --> Security Class Initialized
INFO - 2017-01-11 13:38:08 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:08 --> Input Class Initialized
INFO - 2017-01-11 13:38:08 --> Language Class Initialized
INFO - 2017-01-11 13:38:08 --> Loader Class Initialized
INFO - 2017-01-11 13:38:08 --> Loader Class Initialized
INFO - 2017-01-11 13:38:08 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:08 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:08 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:08 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:08 --> Controller Class Initialized
INFO - 2017-01-11 13:38:08 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:08 --> Model Class Initialized
INFO - 2017-01-11 13:38:08 --> Model Class Initialized
INFO - 2017-01-11 13:38:08 --> Model Class Initialized
INFO - 2017-01-11 13:38:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:08 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:08 --> Total execution time: 0.1777
INFO - 2017-01-11 13:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:08 --> Controller Class Initialized
INFO - 2017-01-11 13:38:08 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:08 --> Model Class Initialized
INFO - 2017-01-11 13:38:08 --> Model Class Initialized
INFO - 2017-01-11 13:38:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:08 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:08 --> Total execution time: 0.2153
INFO - 2017-01-11 13:38:10 --> Config Class Initialized
INFO - 2017-01-11 13:38:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:10 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:10 --> URI Class Initialized
INFO - 2017-01-11 13:38:10 --> Router Class Initialized
INFO - 2017-01-11 13:38:10 --> Output Class Initialized
INFO - 2017-01-11 13:38:10 --> Config Class Initialized
INFO - 2017-01-11 13:38:10 --> Security Class Initialized
INFO - 2017-01-11 13:38:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:10 --> Input Class Initialized
INFO - 2017-01-11 13:38:10 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:10 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:10 --> URI Class Initialized
INFO - 2017-01-11 13:38:10 --> Loader Class Initialized
INFO - 2017-01-11 13:38:10 --> Router Class Initialized
INFO - 2017-01-11 13:38:10 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:10 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:10 --> Output Class Initialized
INFO - 2017-01-11 13:38:10 --> Security Class Initialized
INFO - 2017-01-11 13:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:10 --> Controller Class Initialized
DEBUG - 2017-01-11 13:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:10 --> Input Class Initialized
INFO - 2017-01-11 13:38:10 --> Language Class Initialized
INFO - 2017-01-11 13:38:10 --> Loader Class Initialized
INFO - 2017-01-11 13:38:10 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:10 --> Model Class Initialized
INFO - 2017-01-11 13:38:10 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:10 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:10 --> Model Class Initialized
INFO - 2017-01-11 13:38:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:10 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:10 --> Total execution time: 0.0972
INFO - 2017-01-11 13:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:10 --> Controller Class Initialized
INFO - 2017-01-11 13:38:10 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:10 --> Model Class Initialized
INFO - 2017-01-11 13:38:10 --> Model Class Initialized
INFO - 2017-01-11 13:38:10 --> Model Class Initialized
INFO - 2017-01-11 13:38:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:10 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:10 --> Total execution time: 0.2277
INFO - 2017-01-11 13:38:11 --> Config Class Initialized
INFO - 2017-01-11 13:38:11 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:11 --> Config Class Initialized
INFO - 2017-01-11 13:38:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:11 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:11 --> Router Class Initialized
INFO - 2017-01-11 13:38:11 --> URI Class Initialized
INFO - 2017-01-11 13:38:11 --> Output Class Initialized
INFO - 2017-01-11 13:38:11 --> Router Class Initialized
INFO - 2017-01-11 13:38:11 --> Output Class Initialized
INFO - 2017-01-11 13:38:11 --> Security Class Initialized
INFO - 2017-01-11 13:38:11 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:11 --> Input Class Initialized
INFO - 2017-01-11 13:38:11 --> Input Class Initialized
INFO - 2017-01-11 13:38:11 --> Language Class Initialized
INFO - 2017-01-11 13:38:11 --> Language Class Initialized
INFO - 2017-01-11 13:38:12 --> Loader Class Initialized
INFO - 2017-01-11 13:38:12 --> Loader Class Initialized
INFO - 2017-01-11 13:38:12 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:12 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:12 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:12 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:12 --> Controller Class Initialized
INFO - 2017-01-11 13:38:12 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:12 --> Model Class Initialized
INFO - 2017-01-11 13:38:12 --> Model Class Initialized
INFO - 2017-01-11 13:38:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:12 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:12 --> Total execution time: 0.1084
INFO - 2017-01-11 13:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:12 --> Controller Class Initialized
INFO - 2017-01-11 13:38:12 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:12 --> Model Class Initialized
INFO - 2017-01-11 13:38:12 --> Model Class Initialized
INFO - 2017-01-11 13:38:12 --> Model Class Initialized
INFO - 2017-01-11 13:38:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:12 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:12 --> Total execution time: 0.2109
INFO - 2017-01-11 13:38:14 --> Config Class Initialized
INFO - 2017-01-11 13:38:14 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:14 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:14 --> Config Class Initialized
INFO - 2017-01-11 13:38:14 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:14 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:14 --> URI Class Initialized
INFO - 2017-01-11 13:38:14 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:14 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:14 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:14 --> Output Class Initialized
INFO - 2017-01-11 13:38:14 --> URI Class Initialized
INFO - 2017-01-11 13:38:14 --> Security Class Initialized
INFO - 2017-01-11 13:38:14 --> Router Class Initialized
INFO - 2017-01-11 13:38:14 --> Output Class Initialized
DEBUG - 2017-01-11 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:14 --> Input Class Initialized
INFO - 2017-01-11 13:38:14 --> Language Class Initialized
INFO - 2017-01-11 13:38:14 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:14 --> Input Class Initialized
INFO - 2017-01-11 13:38:14 --> Language Class Initialized
INFO - 2017-01-11 13:38:14 --> Loader Class Initialized
INFO - 2017-01-11 13:38:14 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:14 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:14 --> Loader Class Initialized
INFO - 2017-01-11 13:38:14 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:14 --> Controller Class Initialized
INFO - 2017-01-11 13:38:14 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:14 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:14 --> Model Class Initialized
INFO - 2017-01-11 13:38:14 --> Model Class Initialized
INFO - 2017-01-11 13:38:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:14 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:14 --> Total execution time: 0.1112
INFO - 2017-01-11 13:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:14 --> Controller Class Initialized
INFO - 2017-01-11 13:38:14 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:14 --> Model Class Initialized
INFO - 2017-01-11 13:38:14 --> Model Class Initialized
INFO - 2017-01-11 13:38:14 --> Model Class Initialized
INFO - 2017-01-11 13:38:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:14 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:14 --> Total execution time: 0.2315
INFO - 2017-01-11 13:38:15 --> Config Class Initialized
INFO - 2017-01-11 13:38:15 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:15 --> URI Class Initialized
INFO - 2017-01-11 13:38:15 --> Config Class Initialized
INFO - 2017-01-11 13:38:15 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:15 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:15 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:15 --> Output Class Initialized
INFO - 2017-01-11 13:38:15 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:15 --> Security Class Initialized
INFO - 2017-01-11 13:38:15 --> URI Class Initialized
INFO - 2017-01-11 13:38:15 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:15 --> Input Class Initialized
INFO - 2017-01-11 13:38:15 --> Language Class Initialized
INFO - 2017-01-11 13:38:15 --> Output Class Initialized
INFO - 2017-01-11 13:38:15 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:15 --> Input Class Initialized
INFO - 2017-01-11 13:38:15 --> Loader Class Initialized
INFO - 2017-01-11 13:38:15 --> Language Class Initialized
INFO - 2017-01-11 13:38:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:15 --> Loader Class Initialized
INFO - 2017-01-11 13:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:15 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:15 --> Controller Class Initialized
INFO - 2017-01-11 13:38:15 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:15 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:15 --> Model Class Initialized
INFO - 2017-01-11 13:38:15 --> Model Class Initialized
INFO - 2017-01-11 13:38:15 --> Model Class Initialized
INFO - 2017-01-11 13:38:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:16 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:16 --> Total execution time: 0.2034
INFO - 2017-01-11 13:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:16 --> Controller Class Initialized
INFO - 2017-01-11 13:38:16 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:16 --> Model Class Initialized
INFO - 2017-01-11 13:38:16 --> Model Class Initialized
INFO - 2017-01-11 13:38:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:16 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:16 --> Total execution time: 0.2460
INFO - 2017-01-11 13:38:17 --> Config Class Initialized
INFO - 2017-01-11 13:38:17 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:17 --> Config Class Initialized
INFO - 2017-01-11 13:38:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:17 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:17 --> Router Class Initialized
INFO - 2017-01-11 13:38:17 --> URI Class Initialized
INFO - 2017-01-11 13:38:17 --> Router Class Initialized
INFO - 2017-01-11 13:38:17 --> Output Class Initialized
INFO - 2017-01-11 13:38:17 --> Security Class Initialized
INFO - 2017-01-11 13:38:17 --> Output Class Initialized
INFO - 2017-01-11 13:38:17 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:17 --> Input Class Initialized
INFO - 2017-01-11 13:38:17 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:17 --> Input Class Initialized
INFO - 2017-01-11 13:38:17 --> Language Class Initialized
INFO - 2017-01-11 13:38:17 --> Loader Class Initialized
INFO - 2017-01-11 13:38:17 --> Loader Class Initialized
INFO - 2017-01-11 13:38:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:17 --> Controller Class Initialized
INFO - 2017-01-11 13:38:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:17 --> Model Class Initialized
INFO - 2017-01-11 13:38:17 --> Model Class Initialized
INFO - 2017-01-11 13:38:17 --> Model Class Initialized
INFO - 2017-01-11 13:38:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:17 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:17 --> Total execution time: 0.1804
INFO - 2017-01-11 13:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:17 --> Controller Class Initialized
INFO - 2017-01-11 13:38:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:17 --> Model Class Initialized
INFO - 2017-01-11 13:38:17 --> Model Class Initialized
INFO - 2017-01-11 13:38:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:17 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:17 --> Total execution time: 0.2065
INFO - 2017-01-11 13:38:19 --> Config Class Initialized
INFO - 2017-01-11 13:38:19 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:19 --> Config Class Initialized
INFO - 2017-01-11 13:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 13:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:19 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:19 --> URI Class Initialized
INFO - 2017-01-11 13:38:19 --> URI Class Initialized
INFO - 2017-01-11 13:38:19 --> Router Class Initialized
INFO - 2017-01-11 13:38:19 --> Router Class Initialized
INFO - 2017-01-11 13:38:19 --> Output Class Initialized
INFO - 2017-01-11 13:38:19 --> Output Class Initialized
INFO - 2017-01-11 13:38:19 --> Security Class Initialized
INFO - 2017-01-11 13:38:19 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:19 --> Input Class Initialized
DEBUG - 2017-01-11 13:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:19 --> Language Class Initialized
INFO - 2017-01-11 13:38:19 --> Input Class Initialized
INFO - 2017-01-11 13:38:19 --> Language Class Initialized
INFO - 2017-01-11 13:38:19 --> Loader Class Initialized
INFO - 2017-01-11 13:38:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:19 --> Loader Class Initialized
INFO - 2017-01-11 13:38:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:19 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:19 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:19 --> Controller Class Initialized
INFO - 2017-01-11 13:38:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:19 --> Model Class Initialized
INFO - 2017-01-11 13:38:19 --> Model Class Initialized
INFO - 2017-01-11 13:38:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:19 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:19 --> Total execution time: 0.1155
INFO - 2017-01-11 13:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:19 --> Controller Class Initialized
INFO - 2017-01-11 13:38:19 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:19 --> Model Class Initialized
INFO - 2017-01-11 13:38:19 --> Model Class Initialized
INFO - 2017-01-11 13:38:19 --> Model Class Initialized
INFO - 2017-01-11 13:38:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:19 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:19 --> Total execution time: 0.2408
INFO - 2017-01-11 13:38:20 --> Config Class Initialized
INFO - 2017-01-11 13:38:20 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:20 --> Config Class Initialized
INFO - 2017-01-11 13:38:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:20 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:20 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:20 --> URI Class Initialized
INFO - 2017-01-11 13:38:20 --> URI Class Initialized
INFO - 2017-01-11 13:38:20 --> Router Class Initialized
INFO - 2017-01-11 13:38:20 --> Router Class Initialized
INFO - 2017-01-11 13:38:20 --> Output Class Initialized
INFO - 2017-01-11 13:38:20 --> Output Class Initialized
INFO - 2017-01-11 13:38:20 --> Security Class Initialized
INFO - 2017-01-11 13:38:20 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:20 --> Input Class Initialized
DEBUG - 2017-01-11 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:20 --> Input Class Initialized
INFO - 2017-01-11 13:38:20 --> Language Class Initialized
INFO - 2017-01-11 13:38:20 --> Language Class Initialized
INFO - 2017-01-11 13:38:20 --> Loader Class Initialized
INFO - 2017-01-11 13:38:20 --> Loader Class Initialized
INFO - 2017-01-11 13:38:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:20 --> Controller Class Initialized
INFO - 2017-01-11 13:38:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:20 --> Model Class Initialized
INFO - 2017-01-11 13:38:20 --> Model Class Initialized
INFO - 2017-01-11 13:38:20 --> Model Class Initialized
INFO - 2017-01-11 13:38:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:20 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:20 --> Total execution time: 0.1782
INFO - 2017-01-11 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:20 --> Controller Class Initialized
INFO - 2017-01-11 13:38:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:21 --> Model Class Initialized
INFO - 2017-01-11 13:38:21 --> Model Class Initialized
INFO - 2017-01-11 13:38:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:21 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:21 --> Total execution time: 0.2275
INFO - 2017-01-11 13:38:22 --> Config Class Initialized
INFO - 2017-01-11 13:38:22 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:22 --> Config Class Initialized
INFO - 2017-01-11 13:38:22 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:22 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:22 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:22 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:22 --> Router Class Initialized
INFO - 2017-01-11 13:38:22 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:22 --> URI Class Initialized
INFO - 2017-01-11 13:38:22 --> Output Class Initialized
INFO - 2017-01-11 13:38:22 --> Router Class Initialized
INFO - 2017-01-11 13:38:22 --> Output Class Initialized
INFO - 2017-01-11 13:38:22 --> Security Class Initialized
INFO - 2017-01-11 13:38:22 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:22 --> Input Class Initialized
DEBUG - 2017-01-11 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:22 --> Input Class Initialized
INFO - 2017-01-11 13:38:22 --> Language Class Initialized
INFO - 2017-01-11 13:38:22 --> Language Class Initialized
INFO - 2017-01-11 13:38:22 --> Loader Class Initialized
INFO - 2017-01-11 13:38:22 --> Loader Class Initialized
INFO - 2017-01-11 13:38:22 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:22 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:22 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:22 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:22 --> Controller Class Initialized
INFO - 2017-01-11 13:38:22 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:22 --> Model Class Initialized
INFO - 2017-01-11 13:38:22 --> Model Class Initialized
INFO - 2017-01-11 13:38:22 --> Model Class Initialized
INFO - 2017-01-11 13:38:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:22 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:22 --> Total execution time: 0.1879
INFO - 2017-01-11 13:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:22 --> Controller Class Initialized
INFO - 2017-01-11 13:38:22 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:22 --> Model Class Initialized
INFO - 2017-01-11 13:38:22 --> Model Class Initialized
INFO - 2017-01-11 13:38:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:22 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:22 --> Total execution time: 0.2317
INFO - 2017-01-11 13:38:23 --> Config Class Initialized
INFO - 2017-01-11 13:38:23 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:23 --> Config Class Initialized
INFO - 2017-01-11 13:38:23 --> URI Class Initialized
INFO - 2017-01-11 13:38:23 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:23 --> Config Class Initialized
INFO - 2017-01-11 13:38:23 --> Router Class Initialized
INFO - 2017-01-11 13:38:23 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:23 --> Output Class Initialized
INFO - 2017-01-11 13:38:23 --> URI Class Initialized
INFO - 2017-01-11 13:38:23 --> Security Class Initialized
INFO - 2017-01-11 13:38:23 --> Router Class Initialized
INFO - 2017-01-11 13:38:23 --> Output Class Initialized
DEBUG - 2017-01-11 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:23 --> Input Class Initialized
DEBUG - 2017-01-11 13:38:23 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:23 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:23 --> Language Class Initialized
INFO - 2017-01-11 13:38:23 --> URI Class Initialized
INFO - 2017-01-11 13:38:23 --> Security Class Initialized
INFO - 2017-01-11 13:38:23 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:23 --> Input Class Initialized
INFO - 2017-01-11 13:38:23 --> Loader Class Initialized
INFO - 2017-01-11 13:38:23 --> Language Class Initialized
INFO - 2017-01-11 13:38:23 --> Output Class Initialized
INFO - 2017-01-11 13:38:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:23 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:23 --> Input Class Initialized
INFO - 2017-01-11 13:38:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:23 --> Language Class Initialized
INFO - 2017-01-11 13:38:23 --> Loader Class Initialized
INFO - 2017-01-11 13:38:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:23 --> Controller Class Initialized
INFO - 2017-01-11 13:38:23 --> Loader Class Initialized
INFO - 2017-01-11 13:38:23 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:23 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:23 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:23 --> Model Class Initialized
INFO - 2017-01-11 13:38:23 --> Model Class Initialized
INFO - 2017-01-11 13:38:23 --> Model Class Initialized
INFO - 2017-01-11 13:38:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:24 --> Total execution time: 0.1905
INFO - 2017-01-11 13:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:24 --> Controller Class Initialized
INFO - 2017-01-11 13:38:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:24 --> Total execution time: 0.2250
INFO - 2017-01-11 13:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:24 --> Controller Class Initialized
INFO - 2017-01-11 13:38:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:24 --> Config Class Initialized
INFO - 2017-01-11 13:38:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:24 --> URI Class Initialized
INFO - 2017-01-11 13:38:24 --> Router Class Initialized
INFO - 2017-01-11 13:38:24 --> Output Class Initialized
INFO - 2017-01-11 13:38:24 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:24 --> Input Class Initialized
INFO - 2017-01-11 13:38:24 --> Language Class Initialized
INFO - 2017-01-11 13:38:24 --> Loader Class Initialized
INFO - 2017-01-11 13:38:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:24 --> Config Class Initialized
INFO - 2017-01-11 13:38:24 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:24 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:24 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:24 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:24 --> URI Class Initialized
INFO - 2017-01-11 13:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:24 --> Controller Class Initialized
INFO - 2017-01-11 13:38:24 --> Router Class Initialized
INFO - 2017-01-11 13:38:24 --> Output Class Initialized
INFO - 2017-01-11 13:38:24 --> Security Class Initialized
INFO - 2017-01-11 13:38:24 --> Database Driver Class Initialized
DEBUG - 2017-01-11 13:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:24 --> Input Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Language Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:24 --> Loader Class Initialized
INFO - 2017-01-11 13:38:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:38:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2017-01-11 13:38:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:38:24 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:24 --> Final output sent to browser
INFO - 2017-01-11 13:38:24 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:38:24 --> Total execution time: 0.1090
INFO - 2017-01-11 13:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:24 --> Controller Class Initialized
INFO - 2017-01-11 13:38:24 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Model Class Initialized
INFO - 2017-01-11 13:38:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:24 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:24 --> Total execution time: 0.1353
INFO - 2017-01-11 13:38:26 --> Config Class Initialized
INFO - 2017-01-11 13:38:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:26 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:26 --> URI Class Initialized
INFO - 2017-01-11 13:38:26 --> Router Class Initialized
INFO - 2017-01-11 13:38:26 --> Output Class Initialized
INFO - 2017-01-11 13:38:26 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:26 --> Input Class Initialized
INFO - 2017-01-11 13:38:26 --> Language Class Initialized
INFO - 2017-01-11 13:38:26 --> Loader Class Initialized
INFO - 2017-01-11 13:38:26 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:26 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:26 --> Controller Class Initialized
INFO - 2017-01-11 13:38:26 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:26 --> Model Class Initialized
INFO - 2017-01-11 13:38:26 --> Model Class Initialized
INFO - 2017-01-11 13:38:26 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:27 --> Config Class Initialized
INFO - 2017-01-11 13:38:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:27 --> URI Class Initialized
INFO - 2017-01-11 13:38:27 --> Router Class Initialized
INFO - 2017-01-11 13:38:27 --> Output Class Initialized
INFO - 2017-01-11 13:38:27 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:27 --> Input Class Initialized
INFO - 2017-01-11 13:38:27 --> Language Class Initialized
INFO - 2017-01-11 13:38:27 --> Loader Class Initialized
INFO - 2017-01-11 13:38:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:27 --> Controller Class Initialized
INFO - 2017-01-11 13:38:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:38:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2017-01-11 13:38:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:38:27 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:27 --> Total execution time: 0.1626
INFO - 2017-01-11 13:38:27 --> Config Class Initialized
INFO - 2017-01-11 13:38:27 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:27 --> Config Class Initialized
INFO - 2017-01-11 13:38:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:27 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:27 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:27 --> URI Class Initialized
INFO - 2017-01-11 13:38:27 --> Router Class Initialized
INFO - 2017-01-11 13:38:27 --> Router Class Initialized
INFO - 2017-01-11 13:38:27 --> Output Class Initialized
INFO - 2017-01-11 13:38:27 --> Security Class Initialized
INFO - 2017-01-11 13:38:27 --> Output Class Initialized
DEBUG - 2017-01-11 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:27 --> Security Class Initialized
INFO - 2017-01-11 13:38:27 --> Input Class Initialized
INFO - 2017-01-11 13:38:27 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:27 --> Input Class Initialized
INFO - 2017-01-11 13:38:27 --> Language Class Initialized
INFO - 2017-01-11 13:38:27 --> Loader Class Initialized
INFO - 2017-01-11 13:38:27 --> Loader Class Initialized
INFO - 2017-01-11 13:38:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:27 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:27 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:27 --> Controller Class Initialized
INFO - 2017-01-11 13:38:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:38:27 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:38:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:38:27 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:27 --> Total execution time: 0.1421
INFO - 2017-01-11 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:27 --> Controller Class Initialized
INFO - 2017-01-11 13:38:27 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Model Class Initialized
INFO - 2017-01-11 13:38:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:27 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:27 --> Total execution time: 0.1878
INFO - 2017-01-11 13:38:30 --> Config Class Initialized
INFO - 2017-01-11 13:38:30 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:30 --> Config Class Initialized
INFO - 2017-01-11 13:38:30 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:30 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:30 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:30 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:30 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:30 --> URI Class Initialized
INFO - 2017-01-11 13:38:30 --> URI Class Initialized
INFO - 2017-01-11 13:38:30 --> Router Class Initialized
INFO - 2017-01-11 13:38:30 --> Router Class Initialized
INFO - 2017-01-11 13:38:30 --> Output Class Initialized
INFO - 2017-01-11 13:38:30 --> Output Class Initialized
INFO - 2017-01-11 13:38:30 --> Security Class Initialized
INFO - 2017-01-11 13:38:30 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:30 --> Input Class Initialized
DEBUG - 2017-01-11 13:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:30 --> Input Class Initialized
INFO - 2017-01-11 13:38:30 --> Language Class Initialized
INFO - 2017-01-11 13:38:30 --> Language Class Initialized
INFO - 2017-01-11 13:38:30 --> Loader Class Initialized
INFO - 2017-01-11 13:38:30 --> Loader Class Initialized
INFO - 2017-01-11 13:38:30 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:30 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:30 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:30 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:30 --> Controller Class Initialized
INFO - 2017-01-11 13:38:30 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:30 --> Model Class Initialized
INFO - 2017-01-11 13:38:30 --> Model Class Initialized
INFO - 2017-01-11 13:38:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:30 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:30 --> Total execution time: 0.0968
INFO - 2017-01-11 13:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:30 --> Controller Class Initialized
INFO - 2017-01-11 13:38:30 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:30 --> Model Class Initialized
INFO - 2017-01-11 13:38:30 --> Model Class Initialized
INFO - 2017-01-11 13:38:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:30 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:30 --> Total execution time: 0.1720
INFO - 2017-01-11 13:38:32 --> Config Class Initialized
INFO - 2017-01-11 13:38:32 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:32 --> Config Class Initialized
INFO - 2017-01-11 13:38:32 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:32 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:32 --> Router Class Initialized
INFO - 2017-01-11 13:38:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:32 --> URI Class Initialized
INFO - 2017-01-11 13:38:32 --> Output Class Initialized
INFO - 2017-01-11 13:38:32 --> Router Class Initialized
INFO - 2017-01-11 13:38:32 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:32 --> Output Class Initialized
INFO - 2017-01-11 13:38:32 --> Input Class Initialized
INFO - 2017-01-11 13:38:32 --> Language Class Initialized
INFO - 2017-01-11 13:38:32 --> Security Class Initialized
INFO - 2017-01-11 13:38:32 --> Loader Class Initialized
DEBUG - 2017-01-11 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:32 --> Input Class Initialized
INFO - 2017-01-11 13:38:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:32 --> Language Class Initialized
INFO - 2017-01-11 13:38:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:32 --> Loader Class Initialized
INFO - 2017-01-11 13:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:32 --> Controller Class Initialized
INFO - 2017-01-11 13:38:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:32 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:32 --> Model Class Initialized
INFO - 2017-01-11 13:38:32 --> Model Class Initialized
INFO - 2017-01-11 13:38:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:32 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:32 --> Total execution time: 0.1291
INFO - 2017-01-11 13:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:32 --> Controller Class Initialized
INFO - 2017-01-11 13:38:32 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:32 --> Model Class Initialized
INFO - 2017-01-11 13:38:32 --> Model Class Initialized
INFO - 2017-01-11 13:38:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:32 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:32 --> Total execution time: 0.1771
INFO - 2017-01-11 13:38:34 --> Config Class Initialized
INFO - 2017-01-11 13:38:34 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:34 --> Config Class Initialized
INFO - 2017-01-11 13:38:34 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:34 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:34 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:34 --> Router Class Initialized
INFO - 2017-01-11 13:38:34 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:34 --> Output Class Initialized
INFO - 2017-01-11 13:38:34 --> URI Class Initialized
INFO - 2017-01-11 13:38:34 --> Security Class Initialized
INFO - 2017-01-11 13:38:34 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:34 --> Input Class Initialized
INFO - 2017-01-11 13:38:34 --> Output Class Initialized
INFO - 2017-01-11 13:38:34 --> Language Class Initialized
INFO - 2017-01-11 13:38:34 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:34 --> Input Class Initialized
INFO - 2017-01-11 13:38:34 --> Loader Class Initialized
INFO - 2017-01-11 13:38:34 --> Language Class Initialized
INFO - 2017-01-11 13:38:34 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:34 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:34 --> Loader Class Initialized
INFO - 2017-01-11 13:38:34 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:34 --> Controller Class Initialized
INFO - 2017-01-11 13:38:34 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:34 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:34 --> Model Class Initialized
INFO - 2017-01-11 13:38:34 --> Model Class Initialized
INFO - 2017-01-11 13:38:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:34 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:34 --> Total execution time: 0.1649
INFO - 2017-01-11 13:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:34 --> Controller Class Initialized
INFO - 2017-01-11 13:38:34 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:34 --> Model Class Initialized
INFO - 2017-01-11 13:38:34 --> Model Class Initialized
INFO - 2017-01-11 13:38:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:34 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:34 --> Total execution time: 0.2280
INFO - 2017-01-11 13:38:36 --> Config Class Initialized
INFO - 2017-01-11 13:38:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:36 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:36 --> URI Class Initialized
INFO - 2017-01-11 13:38:36 --> Router Class Initialized
INFO - 2017-01-11 13:38:36 --> Output Class Initialized
INFO - 2017-01-11 13:38:36 --> Security Class Initialized
INFO - 2017-01-11 13:38:36 --> Config Class Initialized
INFO - 2017-01-11 13:38:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:36 --> Input Class Initialized
INFO - 2017-01-11 13:38:36 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:36 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:36 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:36 --> Loader Class Initialized
INFO - 2017-01-11 13:38:36 --> URI Class Initialized
INFO - 2017-01-11 13:38:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:36 --> Router Class Initialized
INFO - 2017-01-11 13:38:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:36 --> Output Class Initialized
INFO - 2017-01-11 13:38:36 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:36 --> Input Class Initialized
INFO - 2017-01-11 13:38:36 --> Language Class Initialized
INFO - 2017-01-11 13:38:36 --> Loader Class Initialized
INFO - 2017-01-11 13:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:36 --> Controller Class Initialized
INFO - 2017-01-11 13:38:36 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:36 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:36 --> Model Class Initialized
INFO - 2017-01-11 13:38:36 --> Model Class Initialized
INFO - 2017-01-11 13:38:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:36 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:36 --> Total execution time: 0.1176
INFO - 2017-01-11 13:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:36 --> Controller Class Initialized
INFO - 2017-01-11 13:38:36 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:36 --> Model Class Initialized
INFO - 2017-01-11 13:38:36 --> Model Class Initialized
INFO - 2017-01-11 13:38:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:36 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:36 --> Total execution time: 0.1780
INFO - 2017-01-11 13:38:39 --> Config Class Initialized
INFO - 2017-01-11 13:38:39 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:39 --> Config Class Initialized
DEBUG - 2017-01-11 13:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:39 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:39 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:39 --> URI Class Initialized
INFO - 2017-01-11 13:38:39 --> Config Class Initialized
INFO - 2017-01-11 13:38:39 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:39 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:39 --> Output Class Initialized
INFO - 2017-01-11 13:38:39 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:39 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:39 --> Security Class Initialized
INFO - 2017-01-11 13:38:39 --> URI Class Initialized
INFO - 2017-01-11 13:38:39 --> URI Class Initialized
INFO - 2017-01-11 13:38:39 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:39 --> Input Class Initialized
INFO - 2017-01-11 13:38:39 --> Router Class Initialized
INFO - 2017-01-11 13:38:39 --> Language Class Initialized
INFO - 2017-01-11 13:38:39 --> Output Class Initialized
INFO - 2017-01-11 13:38:39 --> Output Class Initialized
INFO - 2017-01-11 13:38:39 --> Security Class Initialized
INFO - 2017-01-11 13:38:39 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:39 --> Input Class Initialized
INFO - 2017-01-11 13:38:39 --> Input Class Initialized
INFO - 2017-01-11 13:38:39 --> Loader Class Initialized
INFO - 2017-01-11 13:38:39 --> Language Class Initialized
INFO - 2017-01-11 13:38:39 --> Language Class Initialized
INFO - 2017-01-11 13:38:39 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:39 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:39 --> Loader Class Initialized
INFO - 2017-01-11 13:38:39 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:39 --> Controller Class Initialized
INFO - 2017-01-11 13:38:39 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:39 --> Loader Class Initialized
INFO - 2017-01-11 13:38:39 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:39 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:39 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:39 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:39 --> Total execution time: 0.1109
INFO - 2017-01-11 13:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:39 --> Controller Class Initialized
INFO - 2017-01-11 13:38:39 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:39 --> Controller Class Initialized
INFO - 2017-01-11 13:38:39 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:39 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:39 --> Total execution time: 0.2010
INFO - 2017-01-11 13:38:39 --> Config Class Initialized
INFO - 2017-01-11 13:38:39 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:39 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:39 --> URI Class Initialized
INFO - 2017-01-11 13:38:39 --> Router Class Initialized
INFO - 2017-01-11 13:38:39 --> Output Class Initialized
INFO - 2017-01-11 13:38:39 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:39 --> Input Class Initialized
INFO - 2017-01-11 13:38:39 --> Language Class Initialized
INFO - 2017-01-11 13:38:39 --> Loader Class Initialized
INFO - 2017-01-11 13:38:39 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:39 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:39 --> Controller Class Initialized
INFO - 2017-01-11 13:38:39 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Model Class Initialized
INFO - 2017-01-11 13:38:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:38:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2017-01-11 13:38:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:38:39 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:39 --> Total execution time: 0.0953
INFO - 2017-01-11 13:38:41 --> Config Class Initialized
INFO - 2017-01-11 13:38:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:41 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:41 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:41 --> URI Class Initialized
INFO - 2017-01-11 13:38:41 --> Router Class Initialized
INFO - 2017-01-11 13:38:41 --> Output Class Initialized
INFO - 2017-01-11 13:38:41 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:41 --> Input Class Initialized
INFO - 2017-01-11 13:38:41 --> Language Class Initialized
INFO - 2017-01-11 13:38:42 --> Loader Class Initialized
INFO - 2017-01-11 13:38:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:42 --> Controller Class Initialized
INFO - 2017-01-11 13:38:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:42 --> Config Class Initialized
INFO - 2017-01-11 13:38:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:42 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:42 --> URI Class Initialized
INFO - 2017-01-11 13:38:42 --> Router Class Initialized
INFO - 2017-01-11 13:38:42 --> Output Class Initialized
INFO - 2017-01-11 13:38:42 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:42 --> Input Class Initialized
INFO - 2017-01-11 13:38:42 --> Language Class Initialized
INFO - 2017-01-11 13:38:42 --> Loader Class Initialized
INFO - 2017-01-11 13:38:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:42 --> Controller Class Initialized
INFO - 2017-01-11 13:38:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:38:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06_attempt.php
INFO - 2017-01-11 13:38:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:38:42 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:42 --> Total execution time: 0.0937
INFO - 2017-01-11 13:38:42 --> Config Class Initialized
INFO - 2017-01-11 13:38:42 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:42 --> Config Class Initialized
INFO - 2017-01-11 13:38:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:42 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:42 --> URI Class Initialized
INFO - 2017-01-11 13:38:42 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:42 --> Router Class Initialized
INFO - 2017-01-11 13:38:42 --> URI Class Initialized
INFO - 2017-01-11 13:38:42 --> Router Class Initialized
INFO - 2017-01-11 13:38:42 --> Output Class Initialized
INFO - 2017-01-11 13:38:42 --> Security Class Initialized
INFO - 2017-01-11 13:38:42 --> Output Class Initialized
INFO - 2017-01-11 13:38:42 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:42 --> Input Class Initialized
INFO - 2017-01-11 13:38:42 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:42 --> Input Class Initialized
INFO - 2017-01-11 13:38:42 --> Language Class Initialized
INFO - 2017-01-11 13:38:42 --> Loader Class Initialized
INFO - 2017-01-11 13:38:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:42 --> Loader Class Initialized
INFO - 2017-01-11 13:38:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:42 --> Controller Class Initialized
INFO - 2017-01-11 13:38:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:42 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:42 --> Total execution time: 0.1056
INFO - 2017-01-11 13:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:42 --> Controller Class Initialized
INFO - 2017-01-11 13:38:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Model Class Initialized
INFO - 2017-01-11 13:38:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:38:42 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:38:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:38:42 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:42 --> Total execution time: 0.1683
INFO - 2017-01-11 13:38:44 --> Config Class Initialized
INFO - 2017-01-11 13:38:44 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:44 --> Config Class Initialized
DEBUG - 2017-01-11 13:38:44 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:44 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:44 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:44 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:44 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:44 --> Router Class Initialized
INFO - 2017-01-11 13:38:44 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:44 --> Output Class Initialized
INFO - 2017-01-11 13:38:44 --> Security Class Initialized
INFO - 2017-01-11 13:38:44 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:44 --> Input Class Initialized
INFO - 2017-01-11 13:38:44 --> Language Class Initialized
INFO - 2017-01-11 13:38:44 --> Router Class Initialized
INFO - 2017-01-11 13:38:44 --> Loader Class Initialized
INFO - 2017-01-11 13:38:44 --> Output Class Initialized
INFO - 2017-01-11 13:38:44 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:44 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:44 --> Input Class Initialized
INFO - 2017-01-11 13:38:44 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:44 --> Language Class Initialized
INFO - 2017-01-11 13:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:44 --> Controller Class Initialized
INFO - 2017-01-11 13:38:44 --> Loader Class Initialized
INFO - 2017-01-11 13:38:44 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:44 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:44 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:44 --> Model Class Initialized
INFO - 2017-01-11 13:38:45 --> Model Class Initialized
INFO - 2017-01-11 13:38:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:45 --> Total execution time: 0.1139
INFO - 2017-01-11 13:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:45 --> Controller Class Initialized
INFO - 2017-01-11 13:38:45 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:45 --> Model Class Initialized
INFO - 2017-01-11 13:38:45 --> Model Class Initialized
INFO - 2017-01-11 13:38:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:45 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:45 --> Total execution time: 0.1342
INFO - 2017-01-11 13:38:46 --> Config Class Initialized
INFO - 2017-01-11 13:38:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:46 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:46 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:46 --> Config Class Initialized
INFO - 2017-01-11 13:38:46 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:46 --> URI Class Initialized
INFO - 2017-01-11 13:38:46 --> Router Class Initialized
INFO - 2017-01-11 13:38:46 --> Output Class Initialized
INFO - 2017-01-11 13:38:46 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:46 --> Input Class Initialized
INFO - 2017-01-11 13:38:46 --> Language Class Initialized
INFO - 2017-01-11 13:38:46 --> Loader Class Initialized
INFO - 2017-01-11 13:38:46 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:46 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:38:46 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:46 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:46 --> URI Class Initialized
INFO - 2017-01-11 13:38:46 --> Router Class Initialized
INFO - 2017-01-11 13:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:46 --> Controller Class Initialized
INFO - 2017-01-11 13:38:46 --> Output Class Initialized
INFO - 2017-01-11 13:38:46 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:46 --> Input Class Initialized
INFO - 2017-01-11 13:38:46 --> Language Class Initialized
INFO - 2017-01-11 13:38:46 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:46 --> Loader Class Initialized
INFO - 2017-01-11 13:38:46 --> Model Class Initialized
INFO - 2017-01-11 13:38:46 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:46 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:46 --> Model Class Initialized
INFO - 2017-01-11 13:38:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:46 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:46 --> Total execution time: 0.1059
INFO - 2017-01-11 13:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:46 --> Controller Class Initialized
INFO - 2017-01-11 13:38:46 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:46 --> Model Class Initialized
INFO - 2017-01-11 13:38:46 --> Model Class Initialized
INFO - 2017-01-11 13:38:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:46 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:46 --> Total execution time: 0.1466
INFO - 2017-01-11 13:38:48 --> Config Class Initialized
INFO - 2017-01-11 13:38:48 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:48 --> Config Class Initialized
INFO - 2017-01-11 13:38:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:48 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:48 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:48 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:48 --> Router Class Initialized
INFO - 2017-01-11 13:38:48 --> URI Class Initialized
INFO - 2017-01-11 13:38:48 --> Output Class Initialized
INFO - 2017-01-11 13:38:48 --> Router Class Initialized
INFO - 2017-01-11 13:38:48 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:48 --> Output Class Initialized
INFO - 2017-01-11 13:38:48 --> Input Class Initialized
INFO - 2017-01-11 13:38:48 --> Language Class Initialized
INFO - 2017-01-11 13:38:48 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:48 --> Input Class Initialized
INFO - 2017-01-11 13:38:48 --> Language Class Initialized
INFO - 2017-01-11 13:38:48 --> Loader Class Initialized
INFO - 2017-01-11 13:38:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:48 --> Loader Class Initialized
INFO - 2017-01-11 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:48 --> Controller Class Initialized
INFO - 2017-01-11 13:38:48 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:48 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:48 --> Model Class Initialized
INFO - 2017-01-11 13:38:48 --> Model Class Initialized
INFO - 2017-01-11 13:38:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:48 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:48 --> Total execution time: 0.0976
INFO - 2017-01-11 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:48 --> Controller Class Initialized
INFO - 2017-01-11 13:38:48 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:48 --> Model Class Initialized
INFO - 2017-01-11 13:38:48 --> Model Class Initialized
INFO - 2017-01-11 13:38:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:48 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:48 --> Total execution time: 0.1548
INFO - 2017-01-11 13:38:50 --> Config Class Initialized
INFO - 2017-01-11 13:38:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:50 --> URI Class Initialized
INFO - 2017-01-11 13:38:50 --> Config Class Initialized
INFO - 2017-01-11 13:38:50 --> Router Class Initialized
INFO - 2017-01-11 13:38:50 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:50 --> Output Class Initialized
INFO - 2017-01-11 13:38:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:50 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:50 --> Input Class Initialized
INFO - 2017-01-11 13:38:50 --> URI Class Initialized
INFO - 2017-01-11 13:38:50 --> Language Class Initialized
INFO - 2017-01-11 13:38:50 --> Router Class Initialized
INFO - 2017-01-11 13:38:50 --> Output Class Initialized
INFO - 2017-01-11 13:38:50 --> Loader Class Initialized
INFO - 2017-01-11 13:38:50 --> Security Class Initialized
INFO - 2017-01-11 13:38:50 --> Helper loaded: url_helper
DEBUG - 2017-01-11 13:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:50 --> Input Class Initialized
INFO - 2017-01-11 13:38:50 --> Language Class Initialized
INFO - 2017-01-11 13:38:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:50 --> Loader Class Initialized
INFO - 2017-01-11 13:38:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:50 --> Controller Class Initialized
INFO - 2017-01-11 13:38:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:50 --> Model Class Initialized
INFO - 2017-01-11 13:38:50 --> Model Class Initialized
INFO - 2017-01-11 13:38:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:50 --> Total execution time: 0.1532
INFO - 2017-01-11 13:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:50 --> Controller Class Initialized
INFO - 2017-01-11 13:38:51 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:51 --> Model Class Initialized
INFO - 2017-01-11 13:38:51 --> Model Class Initialized
INFO - 2017-01-11 13:38:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:51 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:51 --> Total execution time: 0.2422
INFO - 2017-01-11 13:38:52 --> Config Class Initialized
INFO - 2017-01-11 13:38:52 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:52 --> Config Class Initialized
INFO - 2017-01-11 13:38:52 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:52 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:52 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:52 --> Config Class Initialized
INFO - 2017-01-11 13:38:52 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:52 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:52 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:52 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:53 --> URI Class Initialized
INFO - 2017-01-11 13:38:53 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:53 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:53 --> Router Class Initialized
INFO - 2017-01-11 13:38:53 --> Output Class Initialized
INFO - 2017-01-11 13:38:53 --> URI Class Initialized
INFO - 2017-01-11 13:38:53 --> Security Class Initialized
INFO - 2017-01-11 13:38:53 --> Output Class Initialized
INFO - 2017-01-11 13:38:53 --> Router Class Initialized
INFO - 2017-01-11 13:38:53 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:53 --> Output Class Initialized
INFO - 2017-01-11 13:38:53 --> Input Class Initialized
DEBUG - 2017-01-11 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:53 --> Input Class Initialized
INFO - 2017-01-11 13:38:53 --> Language Class Initialized
INFO - 2017-01-11 13:38:53 --> Security Class Initialized
INFO - 2017-01-11 13:38:53 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:53 --> Input Class Initialized
INFO - 2017-01-11 13:38:53 --> Language Class Initialized
INFO - 2017-01-11 13:38:53 --> Loader Class Initialized
INFO - 2017-01-11 13:38:53 --> Loader Class Initialized
INFO - 2017-01-11 13:38:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:53 --> Loader Class Initialized
INFO - 2017-01-11 13:38:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:53 --> Controller Class Initialized
INFO - 2017-01-11 13:38:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:53 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:53 --> Total execution time: 0.1664
INFO - 2017-01-11 13:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:53 --> Controller Class Initialized
INFO - 2017-01-11 13:38:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:53 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:53 --> Total execution time: 0.2097
INFO - 2017-01-11 13:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:53 --> Controller Class Initialized
INFO - 2017-01-11 13:38:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:53 --> Config Class Initialized
INFO - 2017-01-11 13:38:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:53 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:53 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:53 --> URI Class Initialized
INFO - 2017-01-11 13:38:53 --> Router Class Initialized
INFO - 2017-01-11 13:38:53 --> Output Class Initialized
INFO - 2017-01-11 13:38:53 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:53 --> Input Class Initialized
INFO - 2017-01-11 13:38:53 --> Language Class Initialized
INFO - 2017-01-11 13:38:53 --> Loader Class Initialized
INFO - 2017-01-11 13:38:53 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:53 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:53 --> Controller Class Initialized
INFO - 2017-01-11 13:38:53 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Model Class Initialized
INFO - 2017-01-11 13:38:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:38:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2017-01-11 13:38:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:38:53 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:53 --> Total execution time: 0.1065
INFO - 2017-01-11 13:38:55 --> Config Class Initialized
INFO - 2017-01-11 13:38:55 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:55 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:55 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:55 --> URI Class Initialized
INFO - 2017-01-11 13:38:55 --> Router Class Initialized
INFO - 2017-01-11 13:38:55 --> Output Class Initialized
INFO - 2017-01-11 13:38:55 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:55 --> Input Class Initialized
INFO - 2017-01-11 13:38:55 --> Language Class Initialized
INFO - 2017-01-11 13:38:55 --> Loader Class Initialized
INFO - 2017-01-11 13:38:55 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:55 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:55 --> Controller Class Initialized
INFO - 2017-01-11 13:38:55 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:55 --> Model Class Initialized
INFO - 2017-01-11 13:38:55 --> Model Class Initialized
INFO - 2017-01-11 13:38:55 --> Model Class Initialized
INFO - 2017-01-11 13:38:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:55 --> Config Class Initialized
INFO - 2017-01-11 13:38:55 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:55 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:55 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:55 --> URI Class Initialized
INFO - 2017-01-11 13:38:55 --> Router Class Initialized
INFO - 2017-01-11 13:38:55 --> Output Class Initialized
INFO - 2017-01-11 13:38:55 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:55 --> Input Class Initialized
INFO - 2017-01-11 13:38:55 --> Language Class Initialized
INFO - 2017-01-11 13:38:55 --> Loader Class Initialized
INFO - 2017-01-11 13:38:55 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:55 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:55 --> Controller Class Initialized
INFO - 2017-01-11 13:38:55 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:55 --> Model Class Initialized
INFO - 2017-01-11 13:38:55 --> Model Class Initialized
INFO - 2017-01-11 13:38:55 --> Model Class Initialized
INFO - 2017-01-11 13:38:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:38:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07_attempt.php
INFO - 2017-01-11 13:38:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:38:55 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:55 --> Total execution time: 0.1136
INFO - 2017-01-11 13:38:56 --> Config Class Initialized
INFO - 2017-01-11 13:38:56 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:56 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:56 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:56 --> Config Class Initialized
INFO - 2017-01-11 13:38:56 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:56 --> URI Class Initialized
INFO - 2017-01-11 13:38:56 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:56 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:56 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:56 --> URI Class Initialized
INFO - 2017-01-11 13:38:56 --> Output Class Initialized
INFO - 2017-01-11 13:38:56 --> Security Class Initialized
INFO - 2017-01-11 13:38:56 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:56 --> Input Class Initialized
INFO - 2017-01-11 13:38:56 --> Language Class Initialized
INFO - 2017-01-11 13:38:56 --> Output Class Initialized
INFO - 2017-01-11 13:38:56 --> Security Class Initialized
INFO - 2017-01-11 13:38:56 --> Loader Class Initialized
DEBUG - 2017-01-11 13:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:56 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:56 --> Input Class Initialized
INFO - 2017-01-11 13:38:56 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:56 --> Language Class Initialized
INFO - 2017-01-11 13:38:56 --> Loader Class Initialized
INFO - 2017-01-11 13:38:56 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:56 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:56 --> Controller Class Initialized
INFO - 2017-01-11 13:38:56 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:56 --> Model Class Initialized
INFO - 2017-01-11 13:38:56 --> Model Class Initialized
INFO - 2017-01-11 13:38:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:56 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:56 --> Total execution time: 0.1260
INFO - 2017-01-11 13:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:56 --> Controller Class Initialized
INFO - 2017-01-11 13:38:56 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:56 --> Model Class Initialized
INFO - 2017-01-11 13:38:56 --> Model Class Initialized
INFO - 2017-01-11 13:38:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:38:56 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:38:56 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:56 --> Total execution time: 0.1767
INFO - 2017-01-11 13:38:57 --> Config Class Initialized
INFO - 2017-01-11 13:38:57 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:57 --> Config Class Initialized
INFO - 2017-01-11 13:38:57 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:57 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:57 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:57 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:57 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:57 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:57 --> Router Class Initialized
INFO - 2017-01-11 13:38:57 --> URI Class Initialized
INFO - 2017-01-11 13:38:57 --> Output Class Initialized
INFO - 2017-01-11 13:38:57 --> Security Class Initialized
INFO - 2017-01-11 13:38:57 --> Router Class Initialized
DEBUG - 2017-01-11 13:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:57 --> Input Class Initialized
INFO - 2017-01-11 13:38:57 --> Language Class Initialized
INFO - 2017-01-11 13:38:57 --> Output Class Initialized
INFO - 2017-01-11 13:38:57 --> Security Class Initialized
INFO - 2017-01-11 13:38:57 --> Loader Class Initialized
DEBUG - 2017-01-11 13:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:57 --> Input Class Initialized
INFO - 2017-01-11 13:38:57 --> Language Class Initialized
INFO - 2017-01-11 13:38:57 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:57 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:57 --> Loader Class Initialized
INFO - 2017-01-11 13:38:57 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:57 --> Controller Class Initialized
INFO - 2017-01-11 13:38:57 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:57 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:57 --> Model Class Initialized
INFO - 2017-01-11 13:38:57 --> Model Class Initialized
INFO - 2017-01-11 13:38:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:57 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:57 --> Total execution time: 0.0931
INFO - 2017-01-11 13:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:57 --> Controller Class Initialized
INFO - 2017-01-11 13:38:57 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:57 --> Model Class Initialized
INFO - 2017-01-11 13:38:57 --> Model Class Initialized
INFO - 2017-01-11 13:38:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:58 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:58 --> Total execution time: 0.1336
INFO - 2017-01-11 13:38:59 --> Config Class Initialized
INFO - 2017-01-11 13:38:59 --> Hooks Class Initialized
INFO - 2017-01-11 13:38:59 --> Config Class Initialized
INFO - 2017-01-11 13:38:59 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:38:59 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:59 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:59 --> URI Class Initialized
DEBUG - 2017-01-11 13:38:59 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:38:59 --> Utf8 Class Initialized
INFO - 2017-01-11 13:38:59 --> Router Class Initialized
INFO - 2017-01-11 13:38:59 --> URI Class Initialized
INFO - 2017-01-11 13:38:59 --> Router Class Initialized
INFO - 2017-01-11 13:38:59 --> Output Class Initialized
INFO - 2017-01-11 13:38:59 --> Security Class Initialized
INFO - 2017-01-11 13:38:59 --> Output Class Initialized
INFO - 2017-01-11 13:38:59 --> Security Class Initialized
DEBUG - 2017-01-11 13:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:59 --> Input Class Initialized
INFO - 2017-01-11 13:38:59 --> Language Class Initialized
DEBUG - 2017-01-11 13:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:38:59 --> Input Class Initialized
INFO - 2017-01-11 13:38:59 --> Language Class Initialized
INFO - 2017-01-11 13:38:59 --> Loader Class Initialized
INFO - 2017-01-11 13:38:59 --> Loader Class Initialized
INFO - 2017-01-11 13:38:59 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:59 --> Helper loaded: url_helper
INFO - 2017-01-11 13:38:59 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:59 --> Helper loaded: language_helper
INFO - 2017-01-11 13:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:59 --> Controller Class Initialized
INFO - 2017-01-11 13:38:59 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:59 --> Model Class Initialized
INFO - 2017-01-11 13:38:59 --> Model Class Initialized
INFO - 2017-01-11 13:38:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:59 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:59 --> Total execution time: 0.1025
INFO - 2017-01-11 13:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:38:59 --> Controller Class Initialized
INFO - 2017-01-11 13:38:59 --> Database Driver Class Initialized
INFO - 2017-01-11 13:38:59 --> Model Class Initialized
INFO - 2017-01-11 13:38:59 --> Model Class Initialized
INFO - 2017-01-11 13:38:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:38:59 --> Final output sent to browser
DEBUG - 2017-01-11 13:38:59 --> Total execution time: 0.1784
INFO - 2017-01-11 13:39:00 --> Config Class Initialized
INFO - 2017-01-11 13:39:00 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:00 --> Config Class Initialized
INFO - 2017-01-11 13:39:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:00 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:00 --> URI Class Initialized
DEBUG - 2017-01-11 13:39:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:00 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:00 --> Router Class Initialized
INFO - 2017-01-11 13:39:00 --> URI Class Initialized
INFO - 2017-01-11 13:39:00 --> Output Class Initialized
INFO - 2017-01-11 13:39:00 --> Router Class Initialized
INFO - 2017-01-11 13:39:00 --> Security Class Initialized
INFO - 2017-01-11 13:39:00 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:00 --> Input Class Initialized
INFO - 2017-01-11 13:39:00 --> Security Class Initialized
INFO - 2017-01-11 13:39:00 --> Language Class Initialized
DEBUG - 2017-01-11 13:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:00 --> Input Class Initialized
INFO - 2017-01-11 13:39:00 --> Language Class Initialized
INFO - 2017-01-11 13:39:00 --> Loader Class Initialized
INFO - 2017-01-11 13:39:00 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:00 --> Loader Class Initialized
INFO - 2017-01-11 13:39:00 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:00 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:00 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:00 --> Controller Class Initialized
INFO - 2017-01-11 13:39:00 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:00 --> Model Class Initialized
INFO - 2017-01-11 13:39:00 --> Model Class Initialized
INFO - 2017-01-11 13:39:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:00 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:00 --> Total execution time: 0.1089
INFO - 2017-01-11 13:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:00 --> Controller Class Initialized
INFO - 2017-01-11 13:39:00 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:00 --> Model Class Initialized
INFO - 2017-01-11 13:39:00 --> Model Class Initialized
INFO - 2017-01-11 13:39:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:00 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:00 --> Total execution time: 0.2327
INFO - 2017-01-11 13:39:02 --> Config Class Initialized
INFO - 2017-01-11 13:39:02 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:02 --> Config Class Initialized
INFO - 2017-01-11 13:39:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:02 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:39:02 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:02 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:02 --> URI Class Initialized
INFO - 2017-01-11 13:39:02 --> URI Class Initialized
INFO - 2017-01-11 13:39:02 --> Router Class Initialized
INFO - 2017-01-11 13:39:02 --> Router Class Initialized
INFO - 2017-01-11 13:39:02 --> Output Class Initialized
INFO - 2017-01-11 13:39:02 --> Output Class Initialized
INFO - 2017-01-11 13:39:02 --> Security Class Initialized
INFO - 2017-01-11 13:39:02 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:02 --> Input Class Initialized
INFO - 2017-01-11 13:39:02 --> Language Class Initialized
DEBUG - 2017-01-11 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:02 --> Input Class Initialized
INFO - 2017-01-11 13:39:02 --> Language Class Initialized
INFO - 2017-01-11 13:39:02 --> Loader Class Initialized
INFO - 2017-01-11 13:39:02 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:02 --> Loader Class Initialized
INFO - 2017-01-11 13:39:02 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:02 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:02 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:02 --> Controller Class Initialized
INFO - 2017-01-11 13:39:02 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:02 --> Model Class Initialized
INFO - 2017-01-11 13:39:02 --> Model Class Initialized
INFO - 2017-01-11 13:39:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:02 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:02 --> Total execution time: 0.0981
INFO - 2017-01-11 13:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:02 --> Controller Class Initialized
INFO - 2017-01-11 13:39:02 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:02 --> Model Class Initialized
INFO - 2017-01-11 13:39:02 --> Model Class Initialized
INFO - 2017-01-11 13:39:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:02 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:02 --> Total execution time: 0.1823
INFO - 2017-01-11 13:39:03 --> Config Class Initialized
INFO - 2017-01-11 13:39:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:03 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:03 --> URI Class Initialized
INFO - 2017-01-11 13:39:03 --> Config Class Initialized
INFO - 2017-01-11 13:39:03 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:03 --> Router Class Initialized
INFO - 2017-01-11 13:39:03 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:03 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:03 --> Security Class Initialized
INFO - 2017-01-11 13:39:03 --> URI Class Initialized
INFO - 2017-01-11 13:39:03 --> Config Class Initialized
INFO - 2017-01-11 13:39:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:03 --> Input Class Initialized
INFO - 2017-01-11 13:39:03 --> Router Class Initialized
INFO - 2017-01-11 13:39:03 --> Language Class Initialized
INFO - 2017-01-11 13:39:03 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:03 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:03 --> Security Class Initialized
INFO - 2017-01-11 13:39:03 --> URI Class Initialized
DEBUG - 2017-01-11 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:03 --> Input Class Initialized
INFO - 2017-01-11 13:39:03 --> Router Class Initialized
INFO - 2017-01-11 13:39:03 --> Language Class Initialized
INFO - 2017-01-11 13:39:03 --> Loader Class Initialized
INFO - 2017-01-11 13:39:03 --> Output Class Initialized
INFO - 2017-01-11 13:39:03 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:03 --> Security Class Initialized
INFO - 2017-01-11 13:39:03 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:03 --> Loader Class Initialized
DEBUG - 2017-01-11 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:03 --> Input Class Initialized
INFO - 2017-01-11 13:39:03 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:03 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:03 --> Language Class Initialized
INFO - 2017-01-11 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:03 --> Controller Class Initialized
INFO - 2017-01-11 13:39:03 --> Loader Class Initialized
INFO - 2017-01-11 13:39:03 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:03 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:03 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:03 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:03 --> Total execution time: 0.1567
INFO - 2017-01-11 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:03 --> Controller Class Initialized
INFO - 2017-01-11 13:39:03 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:03 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:03 --> Total execution time: 0.2042
INFO - 2017-01-11 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:03 --> Controller Class Initialized
INFO - 2017-01-11 13:39:03 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:03 --> Config Class Initialized
INFO - 2017-01-11 13:39:03 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:03 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:03 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:03 --> URI Class Initialized
INFO - 2017-01-11 13:39:03 --> Router Class Initialized
INFO - 2017-01-11 13:39:03 --> Output Class Initialized
INFO - 2017-01-11 13:39:03 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:03 --> Input Class Initialized
INFO - 2017-01-11 13:39:03 --> Language Class Initialized
INFO - 2017-01-11 13:39:03 --> Loader Class Initialized
INFO - 2017-01-11 13:39:03 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:03 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:03 --> Controller Class Initialized
INFO - 2017-01-11 13:39:03 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Model Class Initialized
INFO - 2017-01-11 13:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2017-01-11 13:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:39:03 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:03 --> Total execution time: 0.1439
INFO - 2017-01-11 13:39:06 --> Config Class Initialized
INFO - 2017-01-11 13:39:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:06 --> URI Class Initialized
INFO - 2017-01-11 13:39:06 --> Router Class Initialized
INFO - 2017-01-11 13:39:06 --> Output Class Initialized
INFO - 2017-01-11 13:39:06 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:06 --> Input Class Initialized
INFO - 2017-01-11 13:39:06 --> Language Class Initialized
INFO - 2017-01-11 13:39:06 --> Loader Class Initialized
INFO - 2017-01-11 13:39:06 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:06 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:06 --> Controller Class Initialized
INFO - 2017-01-11 13:39:06 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:06 --> Config Class Initialized
INFO - 2017-01-11 13:39:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:06 --> URI Class Initialized
INFO - 2017-01-11 13:39:06 --> Router Class Initialized
INFO - 2017-01-11 13:39:06 --> Output Class Initialized
INFO - 2017-01-11 13:39:06 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:06 --> Input Class Initialized
INFO - 2017-01-11 13:39:06 --> Language Class Initialized
INFO - 2017-01-11 13:39:06 --> Loader Class Initialized
INFO - 2017-01-11 13:39:06 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:06 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:06 --> Controller Class Initialized
INFO - 2017-01-11 13:39:06 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08_attempt.php
INFO - 2017-01-11 13:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:39:06 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:06 --> Total execution time: 0.1113
INFO - 2017-01-11 13:39:06 --> Config Class Initialized
INFO - 2017-01-11 13:39:06 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:06 --> Config Class Initialized
INFO - 2017-01-11 13:39:06 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:06 --> URI Class Initialized
DEBUG - 2017-01-11 13:39:06 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:06 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:06 --> Router Class Initialized
INFO - 2017-01-11 13:39:06 --> URI Class Initialized
INFO - 2017-01-11 13:39:06 --> Output Class Initialized
INFO - 2017-01-11 13:39:06 --> Router Class Initialized
INFO - 2017-01-11 13:39:06 --> Security Class Initialized
INFO - 2017-01-11 13:39:06 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:06 --> Input Class Initialized
INFO - 2017-01-11 13:39:06 --> Security Class Initialized
INFO - 2017-01-11 13:39:06 --> Language Class Initialized
DEBUG - 2017-01-11 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:06 --> Input Class Initialized
INFO - 2017-01-11 13:39:06 --> Language Class Initialized
INFO - 2017-01-11 13:39:06 --> Loader Class Initialized
INFO - 2017-01-11 13:39:06 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:06 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:06 --> Loader Class Initialized
INFO - 2017-01-11 13:39:06 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:06 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:06 --> Controller Class Initialized
INFO - 2017-01-11 13:39:06 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:06 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:06 --> Total execution time: 0.1299
INFO - 2017-01-11 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:06 --> Controller Class Initialized
INFO - 2017-01-11 13:39:06 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Model Class Initialized
INFO - 2017-01-11 13:39:06 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:39:06 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:39:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:39:06 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:06 --> Total execution time: 0.1866
INFO - 2017-01-11 13:39:08 --> Config Class Initialized
INFO - 2017-01-11 13:39:08 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:08 --> Config Class Initialized
INFO - 2017-01-11 13:39:08 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:08 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:08 --> URI Class Initialized
INFO - 2017-01-11 13:39:08 --> Router Class Initialized
INFO - 2017-01-11 13:39:08 --> Output Class Initialized
INFO - 2017-01-11 13:39:08 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:39:08 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:08 --> Input Class Initialized
INFO - 2017-01-11 13:39:08 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:08 --> Language Class Initialized
INFO - 2017-01-11 13:39:08 --> URI Class Initialized
INFO - 2017-01-11 13:39:08 --> Loader Class Initialized
INFO - 2017-01-11 13:39:08 --> Router Class Initialized
INFO - 2017-01-11 13:39:08 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:08 --> Output Class Initialized
INFO - 2017-01-11 13:39:08 --> Security Class Initialized
INFO - 2017-01-11 13:39:08 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:08 --> Input Class Initialized
INFO - 2017-01-11 13:39:08 --> Language Class Initialized
INFO - 2017-01-11 13:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:08 --> Loader Class Initialized
INFO - 2017-01-11 13:39:08 --> Controller Class Initialized
INFO - 2017-01-11 13:39:08 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:08 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:08 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:08 --> Model Class Initialized
INFO - 2017-01-11 13:39:08 --> Model Class Initialized
INFO - 2017-01-11 13:39:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:08 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:08 --> Total execution time: 0.1333
INFO - 2017-01-11 13:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:08 --> Controller Class Initialized
INFO - 2017-01-11 13:39:08 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:08 --> Model Class Initialized
INFO - 2017-01-11 13:39:08 --> Model Class Initialized
INFO - 2017-01-11 13:39:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:08 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:08 --> Total execution time: 0.1776
INFO - 2017-01-11 13:39:09 --> Config Class Initialized
INFO - 2017-01-11 13:39:09 --> Config Class Initialized
INFO - 2017-01-11 13:39:09 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:09 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:09 --> URI Class Initialized
DEBUG - 2017-01-11 13:39:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:09 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:09 --> Router Class Initialized
INFO - 2017-01-11 13:39:09 --> URI Class Initialized
INFO - 2017-01-11 13:39:09 --> Router Class Initialized
INFO - 2017-01-11 13:39:09 --> Output Class Initialized
INFO - 2017-01-11 13:39:09 --> Output Class Initialized
INFO - 2017-01-11 13:39:09 --> Security Class Initialized
INFO - 2017-01-11 13:39:09 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:09 --> Input Class Initialized
INFO - 2017-01-11 13:39:09 --> Language Class Initialized
DEBUG - 2017-01-11 13:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:09 --> Input Class Initialized
INFO - 2017-01-11 13:39:09 --> Language Class Initialized
INFO - 2017-01-11 13:39:09 --> Loader Class Initialized
INFO - 2017-01-11 13:39:09 --> Loader Class Initialized
INFO - 2017-01-11 13:39:09 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:09 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:09 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:09 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:09 --> Controller Class Initialized
INFO - 2017-01-11 13:39:09 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:09 --> Model Class Initialized
INFO - 2017-01-11 13:39:09 --> Model Class Initialized
INFO - 2017-01-11 13:39:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:09 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:09 --> Total execution time: 0.1236
INFO - 2017-01-11 13:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:09 --> Controller Class Initialized
INFO - 2017-01-11 13:39:09 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:09 --> Model Class Initialized
INFO - 2017-01-11 13:39:09 --> Model Class Initialized
INFO - 2017-01-11 13:39:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:09 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:09 --> Total execution time: 0.1620
INFO - 2017-01-11 13:39:11 --> Config Class Initialized
INFO - 2017-01-11 13:39:11 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:11 --> Config Class Initialized
INFO - 2017-01-11 13:39:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:11 --> URI Class Initialized
DEBUG - 2017-01-11 13:39:11 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:11 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:11 --> Router Class Initialized
INFO - 2017-01-11 13:39:11 --> URI Class Initialized
INFO - 2017-01-11 13:39:11 --> Output Class Initialized
INFO - 2017-01-11 13:39:11 --> Router Class Initialized
INFO - 2017-01-11 13:39:11 --> Security Class Initialized
INFO - 2017-01-11 13:39:11 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:11 --> Input Class Initialized
INFO - 2017-01-11 13:39:11 --> Security Class Initialized
INFO - 2017-01-11 13:39:11 --> Language Class Initialized
DEBUG - 2017-01-11 13:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:11 --> Input Class Initialized
INFO - 2017-01-11 13:39:11 --> Language Class Initialized
INFO - 2017-01-11 13:39:11 --> Loader Class Initialized
INFO - 2017-01-11 13:39:11 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:11 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:11 --> Loader Class Initialized
INFO - 2017-01-11 13:39:11 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:11 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:11 --> Controller Class Initialized
INFO - 2017-01-11 13:39:11 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:11 --> Model Class Initialized
INFO - 2017-01-11 13:39:11 --> Model Class Initialized
INFO - 2017-01-11 13:39:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:11 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:11 --> Total execution time: 0.1172
INFO - 2017-01-11 13:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:11 --> Controller Class Initialized
INFO - 2017-01-11 13:39:11 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:11 --> Model Class Initialized
INFO - 2017-01-11 13:39:11 --> Model Class Initialized
INFO - 2017-01-11 13:39:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:11 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:11 --> Total execution time: 0.1872
INFO - 2017-01-11 13:39:12 --> Config Class Initialized
INFO - 2017-01-11 13:39:12 --> Config Class Initialized
INFO - 2017-01-11 13:39:12 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:12 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:12 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:12 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:39:12 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:12 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:12 --> URI Class Initialized
INFO - 2017-01-11 13:39:12 --> URI Class Initialized
INFO - 2017-01-11 13:39:12 --> Router Class Initialized
INFO - 2017-01-11 13:39:12 --> Router Class Initialized
INFO - 2017-01-11 13:39:12 --> Output Class Initialized
INFO - 2017-01-11 13:39:12 --> Security Class Initialized
INFO - 2017-01-11 13:39:12 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:12 --> Security Class Initialized
INFO - 2017-01-11 13:39:12 --> Input Class Initialized
INFO - 2017-01-11 13:39:12 --> Language Class Initialized
DEBUG - 2017-01-11 13:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:12 --> Input Class Initialized
INFO - 2017-01-11 13:39:12 --> Language Class Initialized
INFO - 2017-01-11 13:39:12 --> Loader Class Initialized
INFO - 2017-01-11 13:39:12 --> Loader Class Initialized
INFO - 2017-01-11 13:39:12 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:12 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:12 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:12 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:12 --> Controller Class Initialized
INFO - 2017-01-11 13:39:12 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:12 --> Model Class Initialized
INFO - 2017-01-11 13:39:12 --> Model Class Initialized
INFO - 2017-01-11 13:39:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:12 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:12 --> Total execution time: 0.1365
INFO - 2017-01-11 13:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:12 --> Controller Class Initialized
INFO - 2017-01-11 13:39:12 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:12 --> Model Class Initialized
INFO - 2017-01-11 13:39:12 --> Model Class Initialized
INFO - 2017-01-11 13:39:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:12 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:12 --> Total execution time: 0.1780
INFO - 2017-01-11 13:39:13 --> Config Class Initialized
INFO - 2017-01-11 13:39:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:39:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:13 --> Config Class Initialized
INFO - 2017-01-11 13:39:13 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:13 --> URI Class Initialized
INFO - 2017-01-11 13:39:13 --> Config Class Initialized
INFO - 2017-01-11 13:39:13 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:13 --> Router Class Initialized
DEBUG - 2017-01-11 13:39:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:13 --> Output Class Initialized
DEBUG - 2017-01-11 13:39:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:13 --> Security Class Initialized
INFO - 2017-01-11 13:39:13 --> URI Class Initialized
INFO - 2017-01-11 13:39:13 --> URI Class Initialized
DEBUG - 2017-01-11 13:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:13 --> Input Class Initialized
INFO - 2017-01-11 13:39:13 --> Language Class Initialized
INFO - 2017-01-11 13:39:13 --> Router Class Initialized
INFO - 2017-01-11 13:39:13 --> Router Class Initialized
INFO - 2017-01-11 13:39:13 --> Output Class Initialized
INFO - 2017-01-11 13:39:13 --> Output Class Initialized
INFO - 2017-01-11 13:39:13 --> Security Class Initialized
INFO - 2017-01-11 13:39:13 --> Loader Class Initialized
INFO - 2017-01-11 13:39:13 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:13 --> Input Class Initialized
INFO - 2017-01-11 13:39:13 --> Helper loaded: url_helper
DEBUG - 2017-01-11 13:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:13 --> Input Class Initialized
INFO - 2017-01-11 13:39:13 --> Language Class Initialized
INFO - 2017-01-11 13:39:13 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:13 --> Language Class Initialized
INFO - 2017-01-11 13:39:13 --> Loader Class Initialized
INFO - 2017-01-11 13:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:13 --> Controller Class Initialized
INFO - 2017-01-11 13:39:13 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:13 --> Loader Class Initialized
INFO - 2017-01-11 13:39:13 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:13 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:13 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:13 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:13 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:13 --> Total execution time: 0.1177
INFO - 2017-01-11 13:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:13 --> Controller Class Initialized
INFO - 2017-01-11 13:39:13 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:13 --> Controller Class Initialized
INFO - 2017-01-11 13:39:13 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Model Class Initialized
INFO - 2017-01-11 13:39:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:13 --> Config Class Initialized
INFO - 2017-01-11 13:39:13 --> Hooks Class Initialized
INFO - 2017-01-11 13:39:13 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:13 --> Total execution time: 0.2022
DEBUG - 2017-01-11 13:39:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:39:13 --> Utf8 Class Initialized
INFO - 2017-01-11 13:39:13 --> URI Class Initialized
INFO - 2017-01-11 13:39:14 --> Router Class Initialized
INFO - 2017-01-11 13:39:14 --> Output Class Initialized
INFO - 2017-01-11 13:39:14 --> Security Class Initialized
DEBUG - 2017-01-11 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:39:14 --> Input Class Initialized
INFO - 2017-01-11 13:39:14 --> Language Class Initialized
INFO - 2017-01-11 13:39:14 --> Loader Class Initialized
INFO - 2017-01-11 13:39:14 --> Helper loaded: url_helper
INFO - 2017-01-11 13:39:14 --> Helper loaded: language_helper
INFO - 2017-01-11 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:39:14 --> Controller Class Initialized
INFO - 2017-01-11 13:39:14 --> Database Driver Class Initialized
INFO - 2017-01-11 13:39:14 --> Model Class Initialized
INFO - 2017-01-11 13:39:14 --> Model Class Initialized
INFO - 2017-01-11 13:39:14 --> Model Class Initialized
INFO - 2017-01-11 13:39:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:39:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:39:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2017-01-11 13:39:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:39:14 --> Final output sent to browser
DEBUG - 2017-01-11 13:39:14 --> Total execution time: 0.1171
INFO - 2017-01-11 13:42:17 --> Config Class Initialized
INFO - 2017-01-11 13:42:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:17 --> URI Class Initialized
INFO - 2017-01-11 13:42:17 --> Router Class Initialized
INFO - 2017-01-11 13:42:17 --> Output Class Initialized
INFO - 2017-01-11 13:42:17 --> Security Class Initialized
DEBUG - 2017-01-11 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:17 --> Input Class Initialized
INFO - 2017-01-11 13:42:17 --> Language Class Initialized
INFO - 2017-01-11 13:42:17 --> Loader Class Initialized
INFO - 2017-01-11 13:42:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:17 --> Controller Class Initialized
INFO - 2017-01-11 13:42:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:17 --> Config Class Initialized
INFO - 2017-01-11 13:42:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:17 --> URI Class Initialized
INFO - 2017-01-11 13:42:17 --> Router Class Initialized
INFO - 2017-01-11 13:42:17 --> Output Class Initialized
INFO - 2017-01-11 13:42:17 --> Security Class Initialized
DEBUG - 2017-01-11 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:17 --> Input Class Initialized
INFO - 2017-01-11 13:42:17 --> Language Class Initialized
INFO - 2017-01-11 13:42:17 --> Loader Class Initialized
INFO - 2017-01-11 13:42:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:17 --> Controller Class Initialized
INFO - 2017-01-11 13:42:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2017-01-11 13:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:42:17 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:17 --> Total execution time: 0.0993
INFO - 2017-01-11 13:42:17 --> Config Class Initialized
INFO - 2017-01-11 13:42:17 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:17 --> URI Class Initialized
INFO - 2017-01-11 13:42:17 --> Config Class Initialized
INFO - 2017-01-11 13:42:17 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:17 --> Router Class Initialized
INFO - 2017-01-11 13:42:17 --> Output Class Initialized
DEBUG - 2017-01-11 13:42:17 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:17 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:17 --> URI Class Initialized
INFO - 2017-01-11 13:42:17 --> Security Class Initialized
INFO - 2017-01-11 13:42:17 --> Router Class Initialized
DEBUG - 2017-01-11 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:17 --> Input Class Initialized
INFO - 2017-01-11 13:42:17 --> Output Class Initialized
INFO - 2017-01-11 13:42:17 --> Language Class Initialized
INFO - 2017-01-11 13:42:17 --> Security Class Initialized
DEBUG - 2017-01-11 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:17 --> Input Class Initialized
INFO - 2017-01-11 13:42:17 --> Loader Class Initialized
INFO - 2017-01-11 13:42:17 --> Language Class Initialized
INFO - 2017-01-11 13:42:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:17 --> Loader Class Initialized
INFO - 2017-01-11 13:42:17 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:17 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:17 --> Controller Class Initialized
INFO - 2017-01-11 13:42:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:17 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:17 --> Total execution time: 0.1004
INFO - 2017-01-11 13:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:17 --> Controller Class Initialized
INFO - 2017-01-11 13:42:17 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Model Class Initialized
INFO - 2017-01-11 13:42:17 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:42:17 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:42:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:42:17 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:17 --> Total execution time: 0.1614
INFO - 2017-01-11 13:42:25 --> Config Class Initialized
INFO - 2017-01-11 13:42:25 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:25 --> Config Class Initialized
INFO - 2017-01-11 13:42:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:25 --> Utf8 Class Initialized
DEBUG - 2017-01-11 13:42:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:25 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:25 --> URI Class Initialized
INFO - 2017-01-11 13:42:25 --> URI Class Initialized
INFO - 2017-01-11 13:42:25 --> Router Class Initialized
INFO - 2017-01-11 13:42:25 --> Router Class Initialized
INFO - 2017-01-11 13:42:25 --> Output Class Initialized
INFO - 2017-01-11 13:42:25 --> Security Class Initialized
INFO - 2017-01-11 13:42:25 --> Output Class Initialized
DEBUG - 2017-01-11 13:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:25 --> Security Class Initialized
INFO - 2017-01-11 13:42:25 --> Input Class Initialized
DEBUG - 2017-01-11 13:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:25 --> Language Class Initialized
INFO - 2017-01-11 13:42:25 --> Input Class Initialized
INFO - 2017-01-11 13:42:25 --> Language Class Initialized
INFO - 2017-01-11 13:42:25 --> Loader Class Initialized
INFO - 2017-01-11 13:42:25 --> Loader Class Initialized
INFO - 2017-01-11 13:42:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:25 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:25 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:25 --> Controller Class Initialized
INFO - 2017-01-11 13:42:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:25 --> Model Class Initialized
INFO - 2017-01-11 13:42:25 --> Model Class Initialized
INFO - 2017-01-11 13:42:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:25 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:25 --> Total execution time: 0.1045
INFO - 2017-01-11 13:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:25 --> Controller Class Initialized
INFO - 2017-01-11 13:42:25 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:25 --> Model Class Initialized
INFO - 2017-01-11 13:42:25 --> Model Class Initialized
INFO - 2017-01-11 13:42:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:25 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:25 --> Total execution time: 0.1286
INFO - 2017-01-11 13:42:26 --> Config Class Initialized
INFO - 2017-01-11 13:42:26 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:26 --> Config Class Initialized
INFO - 2017-01-11 13:42:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:26 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:26 --> URI Class Initialized
INFO - 2017-01-11 13:42:26 --> Router Class Initialized
DEBUG - 2017-01-11 13:42:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:26 --> Output Class Initialized
INFO - 2017-01-11 13:42:26 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:26 --> Security Class Initialized
INFO - 2017-01-11 13:42:26 --> URI Class Initialized
DEBUG - 2017-01-11 13:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:26 --> Input Class Initialized
INFO - 2017-01-11 13:42:26 --> Language Class Initialized
INFO - 2017-01-11 13:42:26 --> Router Class Initialized
INFO - 2017-01-11 13:42:26 --> Loader Class Initialized
INFO - 2017-01-11 13:42:26 --> Output Class Initialized
INFO - 2017-01-11 13:42:26 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:26 --> Security Class Initialized
INFO - 2017-01-11 13:42:26 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:26 --> Input Class Initialized
INFO - 2017-01-11 13:42:26 --> Language Class Initialized
INFO - 2017-01-11 13:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:26 --> Controller Class Initialized
INFO - 2017-01-11 13:42:26 --> Loader Class Initialized
INFO - 2017-01-11 13:42:26 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:26 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:26 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:26 --> Model Class Initialized
INFO - 2017-01-11 13:42:26 --> Model Class Initialized
INFO - 2017-01-11 13:42:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:26 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:26 --> Total execution time: 0.0974
INFO - 2017-01-11 13:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:26 --> Controller Class Initialized
INFO - 2017-01-11 13:42:26 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:26 --> Model Class Initialized
INFO - 2017-01-11 13:42:26 --> Model Class Initialized
INFO - 2017-01-11 13:42:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:26 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:26 --> Total execution time: 0.1506
INFO - 2017-01-11 13:42:29 --> Config Class Initialized
INFO - 2017-01-11 13:42:29 --> Config Class Initialized
INFO - 2017-01-11 13:42:29 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 13:42:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:29 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:29 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:29 --> URI Class Initialized
INFO - 2017-01-11 13:42:29 --> URI Class Initialized
INFO - 2017-01-11 13:42:29 --> Router Class Initialized
INFO - 2017-01-11 13:42:29 --> Router Class Initialized
INFO - 2017-01-11 13:42:29 --> Output Class Initialized
INFO - 2017-01-11 13:42:29 --> Security Class Initialized
INFO - 2017-01-11 13:42:29 --> Output Class Initialized
DEBUG - 2017-01-11 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:29 --> Input Class Initialized
INFO - 2017-01-11 13:42:29 --> Security Class Initialized
INFO - 2017-01-11 13:42:29 --> Language Class Initialized
DEBUG - 2017-01-11 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:29 --> Input Class Initialized
INFO - 2017-01-11 13:42:29 --> Language Class Initialized
INFO - 2017-01-11 13:42:29 --> Loader Class Initialized
INFO - 2017-01-11 13:42:29 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:29 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:29 --> Loader Class Initialized
INFO - 2017-01-11 13:42:29 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:29 --> Controller Class Initialized
INFO - 2017-01-11 13:42:29 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:29 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:29 --> Model Class Initialized
INFO - 2017-01-11 13:42:29 --> Model Class Initialized
INFO - 2017-01-11 13:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:29 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:29 --> Total execution time: 0.0914
INFO - 2017-01-11 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:29 --> Controller Class Initialized
INFO - 2017-01-11 13:42:29 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:29 --> Model Class Initialized
INFO - 2017-01-11 13:42:29 --> Model Class Initialized
INFO - 2017-01-11 13:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:29 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:29 --> Total execution time: 0.1351
INFO - 2017-01-11 13:42:31 --> Config Class Initialized
INFO - 2017-01-11 13:42:31 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:31 --> Config Class Initialized
INFO - 2017-01-11 13:42:31 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:31 --> URI Class Initialized
DEBUG - 2017-01-11 13:42:31 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:31 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:31 --> Router Class Initialized
INFO - 2017-01-11 13:42:31 --> Output Class Initialized
INFO - 2017-01-11 13:42:31 --> URI Class Initialized
INFO - 2017-01-11 13:42:31 --> Security Class Initialized
INFO - 2017-01-11 13:42:31 --> Router Class Initialized
INFO - 2017-01-11 13:42:31 --> Output Class Initialized
INFO - 2017-01-11 13:42:31 --> Security Class Initialized
DEBUG - 2017-01-11 13:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-11 13:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:31 --> Input Class Initialized
INFO - 2017-01-11 13:42:31 --> Input Class Initialized
INFO - 2017-01-11 13:42:31 --> Language Class Initialized
INFO - 2017-01-11 13:42:31 --> Language Class Initialized
INFO - 2017-01-11 13:42:31 --> Loader Class Initialized
INFO - 2017-01-11 13:42:31 --> Loader Class Initialized
INFO - 2017-01-11 13:42:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:31 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:31 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:31 --> Controller Class Initialized
INFO - 2017-01-11 13:42:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:31 --> Model Class Initialized
INFO - 2017-01-11 13:42:31 --> Model Class Initialized
INFO - 2017-01-11 13:42:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:31 --> Total execution time: 0.1367
INFO - 2017-01-11 13:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:31 --> Controller Class Initialized
INFO - 2017-01-11 13:42:31 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:31 --> Model Class Initialized
INFO - 2017-01-11 13:42:31 --> Model Class Initialized
INFO - 2017-01-11 13:42:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:31 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:31 --> Total execution time: 0.2384
INFO - 2017-01-11 13:42:38 --> Config Class Initialized
INFO - 2017-01-11 13:42:38 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:38 --> Config Class Initialized
INFO - 2017-01-11 13:42:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:38 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:38 --> URI Class Initialized
DEBUG - 2017-01-11 13:42:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:38 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:38 --> URI Class Initialized
INFO - 2017-01-11 13:42:38 --> Router Class Initialized
INFO - 2017-01-11 13:42:38 --> Config Class Initialized
INFO - 2017-01-11 13:42:38 --> Hooks Class Initialized
INFO - 2017-01-11 13:42:38 --> Output Class Initialized
INFO - 2017-01-11 13:42:38 --> Router Class Initialized
DEBUG - 2017-01-11 13:42:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:38 --> Security Class Initialized
INFO - 2017-01-11 13:42:38 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:38 --> Output Class Initialized
INFO - 2017-01-11 13:42:38 --> URI Class Initialized
DEBUG - 2017-01-11 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:38 --> Security Class Initialized
INFO - 2017-01-11 13:42:38 --> Input Class Initialized
INFO - 2017-01-11 13:42:38 --> Language Class Initialized
INFO - 2017-01-11 13:42:38 --> Router Class Initialized
DEBUG - 2017-01-11 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:38 --> Input Class Initialized
INFO - 2017-01-11 13:42:38 --> Language Class Initialized
INFO - 2017-01-11 13:42:38 --> Output Class Initialized
INFO - 2017-01-11 13:42:38 --> Security Class Initialized
INFO - 2017-01-11 13:42:38 --> Loader Class Initialized
DEBUG - 2017-01-11 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:38 --> Input Class Initialized
INFO - 2017-01-11 13:42:38 --> Loader Class Initialized
INFO - 2017-01-11 13:42:38 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:38 --> Language Class Initialized
INFO - 2017-01-11 13:42:38 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:38 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:38 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:38 --> Controller Class Initialized
INFO - 2017-01-11 13:42:38 --> Loader Class Initialized
INFO - 2017-01-11 13:42:38 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:38 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:38 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:38 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:38 --> Total execution time: 0.1082
INFO - 2017-01-11 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:38 --> Controller Class Initialized
INFO - 2017-01-11 13:42:38 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:38 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:38 --> Total execution time: 0.1660
INFO - 2017-01-11 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:38 --> Controller Class Initialized
INFO - 2017-01-11 13:42:38 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:38 --> Config Class Initialized
INFO - 2017-01-11 13:42:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:42:38 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:42:38 --> Utf8 Class Initialized
INFO - 2017-01-11 13:42:38 --> URI Class Initialized
INFO - 2017-01-11 13:42:38 --> Router Class Initialized
INFO - 2017-01-11 13:42:38 --> Output Class Initialized
INFO - 2017-01-11 13:42:38 --> Security Class Initialized
DEBUG - 2017-01-11 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:42:38 --> Input Class Initialized
INFO - 2017-01-11 13:42:38 --> Language Class Initialized
INFO - 2017-01-11 13:42:38 --> Loader Class Initialized
INFO - 2017-01-11 13:42:38 --> Helper loaded: url_helper
INFO - 2017-01-11 13:42:38 --> Helper loaded: language_helper
INFO - 2017-01-11 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:42:38 --> Controller Class Initialized
INFO - 2017-01-11 13:42:38 --> Database Driver Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Model Class Initialized
INFO - 2017-01-11 13:42:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:42:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:42:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-01-11 13:42:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:42:38 --> Final output sent to browser
DEBUG - 2017-01-11 13:42:38 --> Total execution time: 0.0840
INFO - 2017-01-11 13:43:09 --> Config Class Initialized
INFO - 2017-01-11 13:43:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:43:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:43:09 --> Utf8 Class Initialized
INFO - 2017-01-11 13:43:09 --> URI Class Initialized
INFO - 2017-01-11 13:43:09 --> Router Class Initialized
INFO - 2017-01-11 13:43:09 --> Output Class Initialized
INFO - 2017-01-11 13:43:09 --> Security Class Initialized
DEBUG - 2017-01-11 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:43:09 --> Input Class Initialized
INFO - 2017-01-11 13:43:09 --> Language Class Initialized
INFO - 2017-01-11 13:43:09 --> Loader Class Initialized
INFO - 2017-01-11 13:43:09 --> Helper loaded: url_helper
INFO - 2017-01-11 13:43:09 --> Helper loaded: language_helper
INFO - 2017-01-11 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:43:09 --> Controller Class Initialized
INFO - 2017-01-11 13:43:09 --> Database Driver Class Initialized
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:43:09 --> Config Class Initialized
INFO - 2017-01-11 13:43:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:43:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:43:09 --> Utf8 Class Initialized
INFO - 2017-01-11 13:43:09 --> URI Class Initialized
INFO - 2017-01-11 13:43:09 --> Router Class Initialized
INFO - 2017-01-11 13:43:09 --> Output Class Initialized
INFO - 2017-01-11 13:43:09 --> Security Class Initialized
DEBUG - 2017-01-11 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:43:09 --> Input Class Initialized
INFO - 2017-01-11 13:43:09 --> Language Class Initialized
INFO - 2017-01-11 13:43:09 --> Loader Class Initialized
INFO - 2017-01-11 13:43:09 --> Helper loaded: url_helper
INFO - 2017-01-11 13:43:09 --> Helper loaded: language_helper
INFO - 2017-01-11 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:43:09 --> Controller Class Initialized
INFO - 2017-01-11 13:43:09 --> Database Driver Class Initialized
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:43:09 --> Model Class Initialized
INFO - 2017-01-11 13:43:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:43:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-01-11 13:43:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:43:09 --> Final output sent to browser
DEBUG - 2017-01-11 13:43:09 --> Total execution time: 0.1896
INFO - 2017-01-11 13:43:10 --> Config Class Initialized
INFO - 2017-01-11 13:43:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:43:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:43:10 --> Utf8 Class Initialized
INFO - 2017-01-11 13:43:10 --> Config Class Initialized
INFO - 2017-01-11 13:43:10 --> Hooks Class Initialized
INFO - 2017-01-11 13:43:10 --> URI Class Initialized
INFO - 2017-01-11 13:43:10 --> Router Class Initialized
INFO - 2017-01-11 13:43:10 --> Output Class Initialized
INFO - 2017-01-11 13:43:10 --> Security Class Initialized
DEBUG - 2017-01-11 13:43:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:43:10 --> Utf8 Class Initialized
INFO - 2017-01-11 13:43:10 --> URI Class Initialized
DEBUG - 2017-01-11 13:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:43:10 --> Input Class Initialized
INFO - 2017-01-11 13:43:10 --> Language Class Initialized
INFO - 2017-01-11 13:43:10 --> Router Class Initialized
INFO - 2017-01-11 13:43:10 --> Output Class Initialized
INFO - 2017-01-11 13:43:10 --> Loader Class Initialized
INFO - 2017-01-11 13:43:10 --> Security Class Initialized
INFO - 2017-01-11 13:43:10 --> Helper loaded: url_helper
INFO - 2017-01-11 13:43:10 --> Helper loaded: language_helper
DEBUG - 2017-01-11 13:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:43:10 --> Input Class Initialized
INFO - 2017-01-11 13:43:10 --> Language Class Initialized
INFO - 2017-01-11 13:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:43:10 --> Controller Class Initialized
INFO - 2017-01-11 13:43:10 --> Loader Class Initialized
INFO - 2017-01-11 13:43:10 --> Helper loaded: url_helper
INFO - 2017-01-11 13:43:10 --> Helper loaded: language_helper
INFO - 2017-01-11 13:43:10 --> Database Driver Class Initialized
INFO - 2017-01-11 13:43:10 --> Model Class Initialized
INFO - 2017-01-11 13:43:10 --> Model Class Initialized
INFO - 2017-01-11 13:43:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:43:10 --> Final output sent to browser
DEBUG - 2017-01-11 13:43:10 --> Total execution time: 0.1093
INFO - 2017-01-11 13:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:43:10 --> Controller Class Initialized
INFO - 2017-01-11 13:43:10 --> Database Driver Class Initialized
INFO - 2017-01-11 13:43:10 --> Model Class Initialized
INFO - 2017-01-11 13:43:10 --> Model Class Initialized
INFO - 2017-01-11 13:43:10 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:43:10 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-11 13:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-11 13:43:10 --> Final output sent to browser
DEBUG - 2017-01-11 13:43:10 --> Total execution time: 0.1460
INFO - 2017-01-11 13:43:40 --> Config Class Initialized
INFO - 2017-01-11 13:43:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:43:40 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:43:40 --> Utf8 Class Initialized
INFO - 2017-01-11 13:43:40 --> URI Class Initialized
INFO - 2017-01-11 13:43:40 --> Router Class Initialized
INFO - 2017-01-11 13:43:40 --> Output Class Initialized
INFO - 2017-01-11 13:43:40 --> Security Class Initialized
DEBUG - 2017-01-11 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:43:40 --> Input Class Initialized
INFO - 2017-01-11 13:43:40 --> Language Class Initialized
INFO - 2017-01-11 13:43:40 --> Loader Class Initialized
INFO - 2017-01-11 13:43:40 --> Helper loaded: url_helper
INFO - 2017-01-11 13:43:40 --> Helper loaded: language_helper
INFO - 2017-01-11 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:43:40 --> Controller Class Initialized
INFO - 2017-01-11 13:43:40 --> Database Driver Class Initialized
INFO - 2017-01-11 13:43:40 --> Model Class Initialized
INFO - 2017-01-11 13:43:40 --> Model Class Initialized
INFO - 2017-01-11 13:43:40 --> Model Class Initialized
INFO - 2017-01-11 13:43:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:43:40 --> Final output sent to browser
DEBUG - 2017-01-11 13:43:40 --> Total execution time: 0.0810
INFO - 2017-01-11 13:44:10 --> Config Class Initialized
INFO - 2017-01-11 13:44:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:10 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:10 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:10 --> URI Class Initialized
INFO - 2017-01-11 13:44:10 --> Router Class Initialized
INFO - 2017-01-11 13:44:10 --> Output Class Initialized
INFO - 2017-01-11 13:44:10 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:10 --> Input Class Initialized
INFO - 2017-01-11 13:44:10 --> Language Class Initialized
INFO - 2017-01-11 13:44:10 --> Loader Class Initialized
INFO - 2017-01-11 13:44:10 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:10 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:10 --> Controller Class Initialized
INFO - 2017-01-11 13:44:10 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:10 --> Model Class Initialized
INFO - 2017-01-11 13:44:10 --> Model Class Initialized
INFO - 2017-01-11 13:44:10 --> Model Class Initialized
INFO - 2017-01-11 13:44:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:10 --> Final output sent to browser
DEBUG - 2017-01-11 13:44:10 --> Total execution time: 0.0655
INFO - 2017-01-11 13:44:20 --> Config Class Initialized
INFO - 2017-01-11 13:44:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:20 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:20 --> URI Class Initialized
INFO - 2017-01-11 13:44:20 --> Router Class Initialized
INFO - 2017-01-11 13:44:20 --> Output Class Initialized
INFO - 2017-01-11 13:44:20 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:20 --> Input Class Initialized
INFO - 2017-01-11 13:44:20 --> Language Class Initialized
INFO - 2017-01-11 13:44:20 --> Loader Class Initialized
INFO - 2017-01-11 13:44:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:20 --> Controller Class Initialized
INFO - 2017-01-11 13:44:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:20 --> Model Class Initialized
INFO - 2017-01-11 13:44:20 --> Model Class Initialized
INFO - 2017-01-11 13:44:20 --> Model Class Initialized
INFO - 2017-01-11 13:44:20 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-11 13:44:20 --> Severity: Notice --> Undefined index: correct_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 175
ERROR - 2017-01-11 13:44:20 --> Severity: Notice --> Undefined index: incorrect_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 176
ERROR - 2017-01-11 13:44:20 --> Severity: Notice --> Undefined index: pass_percentage C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 193
INFO - 2017-01-11 13:44:20 --> Config Class Initialized
INFO - 2017-01-11 13:44:20 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:20 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:20 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:20 --> URI Class Initialized
INFO - 2017-01-11 13:44:20 --> Router Class Initialized
INFO - 2017-01-11 13:44:20 --> Output Class Initialized
INFO - 2017-01-11 13:44:20 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:20 --> Input Class Initialized
INFO - 2017-01-11 13:44:20 --> Language Class Initialized
INFO - 2017-01-11 13:44:20 --> Loader Class Initialized
INFO - 2017-01-11 13:44:20 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:20 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:20 --> Controller Class Initialized
INFO - 2017-01-11 13:44:20 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:20 --> Model Class Initialized
INFO - 2017-01-11 13:44:20 --> Model Class Initialized
INFO - 2017-01-11 13:44:20 --> Model Class Initialized
INFO - 2017-01-11 13:44:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:44:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-11 13:44:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:44:20 --> Final output sent to browser
DEBUG - 2017-01-11 13:44:20 --> Total execution time: 0.0886
INFO - 2017-01-11 13:44:32 --> Config Class Initialized
INFO - 2017-01-11 13:44:32 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:32 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:32 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:32 --> URI Class Initialized
INFO - 2017-01-11 13:44:32 --> Router Class Initialized
INFO - 2017-01-11 13:44:32 --> Output Class Initialized
INFO - 2017-01-11 13:44:32 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:32 --> Input Class Initialized
INFO - 2017-01-11 13:44:32 --> Language Class Initialized
INFO - 2017-01-11 13:44:32 --> Loader Class Initialized
INFO - 2017-01-11 13:44:32 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:32 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:32 --> Controller Class Initialized
INFO - 2017-01-11 13:44:33 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:33 --> Model Class Initialized
INFO - 2017-01-11 13:44:33 --> Model Class Initialized
INFO - 2017-01-11 13:44:33 --> Model Class Initialized
INFO - 2017-01-11 13:44:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:44:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-11 13:44:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:44:33 --> Final output sent to browser
DEBUG - 2017-01-11 13:44:33 --> Total execution time: 0.1371
INFO - 2017-01-11 13:44:42 --> Config Class Initialized
INFO - 2017-01-11 13:44:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:42 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:42 --> URI Class Initialized
INFO - 2017-01-11 13:44:42 --> Router Class Initialized
INFO - 2017-01-11 13:44:42 --> Output Class Initialized
INFO - 2017-01-11 13:44:42 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:42 --> Input Class Initialized
INFO - 2017-01-11 13:44:42 --> Language Class Initialized
INFO - 2017-01-11 13:44:42 --> Loader Class Initialized
INFO - 2017-01-11 13:44:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:42 --> Controller Class Initialized
INFO - 2017-01-11 13:44:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:42 --> Model Class Initialized
INFO - 2017-01-11 13:44:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:42 --> Config Class Initialized
INFO - 2017-01-11 13:44:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:42 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:42 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:42 --> URI Class Initialized
INFO - 2017-01-11 13:44:42 --> Router Class Initialized
INFO - 2017-01-11 13:44:42 --> Output Class Initialized
INFO - 2017-01-11 13:44:42 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:42 --> Input Class Initialized
INFO - 2017-01-11 13:44:42 --> Language Class Initialized
INFO - 2017-01-11 13:44:42 --> Loader Class Initialized
INFO - 2017-01-11 13:44:42 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:42 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:42 --> Controller Class Initialized
INFO - 2017-01-11 13:44:42 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:42 --> Model Class Initialized
INFO - 2017-01-11 13:44:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-11 13:44:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-11 13:44:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-11 13:44:42 --> Final output sent to browser
DEBUG - 2017-01-11 13:44:42 --> Total execution time: 0.0645
INFO - 2017-01-11 13:44:50 --> Config Class Initialized
INFO - 2017-01-11 13:44:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:50 --> URI Class Initialized
INFO - 2017-01-11 13:44:50 --> Router Class Initialized
INFO - 2017-01-11 13:44:50 --> Output Class Initialized
INFO - 2017-01-11 13:44:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:50 --> Input Class Initialized
INFO - 2017-01-11 13:44:50 --> Language Class Initialized
INFO - 2017-01-11 13:44:50 --> Loader Class Initialized
INFO - 2017-01-11 13:44:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:50 --> Controller Class Initialized
INFO - 2017-01-11 13:44:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:50 --> Model Class Initialized
INFO - 2017-01-11 13:44:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:50 --> Config Class Initialized
INFO - 2017-01-11 13:44:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 13:44:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 13:44:50 --> Utf8 Class Initialized
INFO - 2017-01-11 13:44:50 --> URI Class Initialized
INFO - 2017-01-11 13:44:50 --> Router Class Initialized
INFO - 2017-01-11 13:44:50 --> Output Class Initialized
INFO - 2017-01-11 13:44:50 --> Security Class Initialized
DEBUG - 2017-01-11 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 13:44:50 --> Input Class Initialized
INFO - 2017-01-11 13:44:50 --> Language Class Initialized
INFO - 2017-01-11 13:44:50 --> Loader Class Initialized
INFO - 2017-01-11 13:44:50 --> Helper loaded: url_helper
INFO - 2017-01-11 13:44:50 --> Helper loaded: language_helper
INFO - 2017-01-11 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 13:44:50 --> Controller Class Initialized
INFO - 2017-01-11 13:44:50 --> Database Driver Class Initialized
INFO - 2017-01-11 13:44:50 --> Model Class Initialized
INFO - 2017-01-11 13:44:50 --> Model Class Initialized
INFO - 2017-01-11 13:44:50 --> Model Class Initialized
INFO - 2017-01-11 13:44:50 --> Model Class Initialized
INFO - 2017-01-11 13:44:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-11 13:44:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-11 13:44:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-11 13:44:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-11 13:44:50 --> Final output sent to browser
DEBUG - 2017-01-11 13:44:50 --> Total execution time: 0.0909
