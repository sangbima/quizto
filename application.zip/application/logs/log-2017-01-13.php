<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-13 09:48:43 --> Config Class Initialized
INFO - 2017-01-13 09:48:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 09:48:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 09:48:43 --> Utf8 Class Initialized
INFO - 2017-01-13 09:48:43 --> URI Class Initialized
INFO - 2017-01-13 09:48:43 --> Router Class Initialized
INFO - 2017-01-13 09:48:43 --> Output Class Initialized
INFO - 2017-01-13 09:48:43 --> Security Class Initialized
DEBUG - 2017-01-13 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 09:48:43 --> Input Class Initialized
INFO - 2017-01-13 09:48:43 --> Language Class Initialized
INFO - 2017-01-13 09:48:43 --> Loader Class Initialized
INFO - 2017-01-13 09:48:43 --> Helper loaded: url_helper
INFO - 2017-01-13 09:48:43 --> Helper loaded: language_helper
INFO - 2017-01-13 09:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 09:48:43 --> Controller Class Initialized
INFO - 2017-01-13 09:48:43 --> Database Driver Class Initialized
INFO - 2017-01-13 09:48:43 --> Model Class Initialized
INFO - 2017-01-13 09:48:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 09:48:43 --> Config Class Initialized
INFO - 2017-01-13 09:48:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 09:48:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 09:48:43 --> Utf8 Class Initialized
INFO - 2017-01-13 09:48:43 --> URI Class Initialized
INFO - 2017-01-13 09:48:43 --> Router Class Initialized
INFO - 2017-01-13 09:48:43 --> Output Class Initialized
INFO - 2017-01-13 09:48:43 --> Security Class Initialized
DEBUG - 2017-01-13 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 09:48:43 --> Input Class Initialized
INFO - 2017-01-13 09:48:43 --> Language Class Initialized
INFO - 2017-01-13 09:48:43 --> Loader Class Initialized
INFO - 2017-01-13 09:48:43 --> Helper loaded: url_helper
INFO - 2017-01-13 09:48:43 --> Helper loaded: language_helper
INFO - 2017-01-13 09:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 09:48:43 --> Controller Class Initialized
INFO - 2017-01-13 09:48:43 --> Database Driver Class Initialized
INFO - 2017-01-13 09:48:43 --> Model Class Initialized
INFO - 2017-01-13 09:48:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 09:48:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-13 09:48:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-13 09:48:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-13 09:48:43 --> Final output sent to browser
DEBUG - 2017-01-13 09:48:43 --> Total execution time: 0.0680
INFO - 2017-01-13 10:00:07 --> Config Class Initialized
INFO - 2017-01-13 10:00:07 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:00:07 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:00:07 --> Utf8 Class Initialized
INFO - 2017-01-13 10:00:07 --> URI Class Initialized
INFO - 2017-01-13 10:00:07 --> Router Class Initialized
INFO - 2017-01-13 10:00:07 --> Output Class Initialized
INFO - 2017-01-13 10:00:07 --> Security Class Initialized
DEBUG - 2017-01-13 10:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:00:07 --> Input Class Initialized
INFO - 2017-01-13 10:00:07 --> Language Class Initialized
INFO - 2017-01-13 10:00:07 --> Loader Class Initialized
INFO - 2017-01-13 10:00:07 --> Helper loaded: url_helper
INFO - 2017-01-13 10:00:07 --> Helper loaded: language_helper
INFO - 2017-01-13 10:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:00:07 --> Controller Class Initialized
INFO - 2017-01-13 10:00:07 --> Database Driver Class Initialized
INFO - 2017-01-13 10:00:07 --> Model Class Initialized
INFO - 2017-01-13 10:00:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 10:00:08 --> Config Class Initialized
INFO - 2017-01-13 10:00:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:00:08 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:00:08 --> Utf8 Class Initialized
INFO - 2017-01-13 10:00:08 --> URI Class Initialized
INFO - 2017-01-13 10:00:08 --> Router Class Initialized
INFO - 2017-01-13 10:00:08 --> Output Class Initialized
INFO - 2017-01-13 10:00:08 --> Security Class Initialized
DEBUG - 2017-01-13 10:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:00:08 --> Input Class Initialized
INFO - 2017-01-13 10:00:08 --> Language Class Initialized
INFO - 2017-01-13 10:00:08 --> Loader Class Initialized
INFO - 2017-01-13 10:00:08 --> Helper loaded: url_helper
INFO - 2017-01-13 10:00:08 --> Helper loaded: language_helper
INFO - 2017-01-13 10:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:00:08 --> Controller Class Initialized
INFO - 2017-01-13 10:00:08 --> Database Driver Class Initialized
INFO - 2017-01-13 10:00:08 --> Model Class Initialized
INFO - 2017-01-13 10:00:08 --> Model Class Initialized
INFO - 2017-01-13 10:00:08 --> Model Class Initialized
INFO - 2017-01-13 10:00:08 --> Model Class Initialized
INFO - 2017-01-13 10:00:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 10:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 10:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-13 10:00:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 10:00:08 --> Final output sent to browser
DEBUG - 2017-01-13 10:00:08 --> Total execution time: 0.0759
INFO - 2017-01-13 10:00:11 --> Config Class Initialized
INFO - 2017-01-13 10:00:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:00:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:00:11 --> Utf8 Class Initialized
INFO - 2017-01-13 10:00:11 --> URI Class Initialized
INFO - 2017-01-13 10:00:11 --> Router Class Initialized
INFO - 2017-01-13 10:00:11 --> Output Class Initialized
INFO - 2017-01-13 10:00:11 --> Security Class Initialized
DEBUG - 2017-01-13 10:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:00:11 --> Input Class Initialized
INFO - 2017-01-13 10:00:11 --> Language Class Initialized
INFO - 2017-01-13 10:00:11 --> Loader Class Initialized
INFO - 2017-01-13 10:00:11 --> Helper loaded: url_helper
INFO - 2017-01-13 10:00:11 --> Helper loaded: language_helper
INFO - 2017-01-13 10:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:00:11 --> Controller Class Initialized
INFO - 2017-01-13 10:00:11 --> Database Driver Class Initialized
INFO - 2017-01-13 10:00:11 --> Model Class Initialized
INFO - 2017-01-13 10:00:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 10:00:11 --> Helper loaded: form_helper
INFO - 2017-01-13 10:00:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 10:00:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 10:00:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 10:00:11 --> Final output sent to browser
DEBUG - 2017-01-13 10:00:11 --> Total execution time: 0.0770
INFO - 2017-01-13 10:01:56 --> Config Class Initialized
INFO - 2017-01-13 10:01:56 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:01:56 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:01:56 --> Utf8 Class Initialized
INFO - 2017-01-13 10:01:56 --> URI Class Initialized
INFO - 2017-01-13 10:01:56 --> Router Class Initialized
INFO - 2017-01-13 10:01:56 --> Output Class Initialized
INFO - 2017-01-13 10:01:56 --> Security Class Initialized
DEBUG - 2017-01-13 10:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:01:56 --> Input Class Initialized
INFO - 2017-01-13 10:01:56 --> Language Class Initialized
INFO - 2017-01-13 10:01:56 --> Loader Class Initialized
INFO - 2017-01-13 10:01:56 --> Helper loaded: url_helper
INFO - 2017-01-13 10:01:56 --> Helper loaded: language_helper
INFO - 2017-01-13 10:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:01:56 --> Controller Class Initialized
INFO - 2017-01-13 10:01:56 --> Database Driver Class Initialized
INFO - 2017-01-13 10:01:56 --> Model Class Initialized
INFO - 2017-01-13 10:01:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 10:01:56 --> Helper loaded: form_helper
INFO - 2017-01-13 10:01:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 10:01:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 10:01:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 10:01:56 --> Final output sent to browser
DEBUG - 2017-01-13 10:01:56 --> Total execution time: 0.0655
INFO - 2017-01-13 10:02:20 --> Config Class Initialized
INFO - 2017-01-13 10:02:20 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:02:20 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:02:20 --> Utf8 Class Initialized
INFO - 2017-01-13 10:02:20 --> URI Class Initialized
INFO - 2017-01-13 10:02:20 --> Router Class Initialized
INFO - 2017-01-13 10:02:20 --> Output Class Initialized
INFO - 2017-01-13 10:02:20 --> Security Class Initialized
DEBUG - 2017-01-13 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:02:20 --> Input Class Initialized
INFO - 2017-01-13 10:02:20 --> Language Class Initialized
INFO - 2017-01-13 10:02:20 --> Loader Class Initialized
INFO - 2017-01-13 10:02:20 --> Helper loaded: url_helper
INFO - 2017-01-13 10:02:20 --> Helper loaded: language_helper
INFO - 2017-01-13 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:02:20 --> Controller Class Initialized
INFO - 2017-01-13 10:02:20 --> Database Driver Class Initialized
INFO - 2017-01-13 10:02:20 --> Model Class Initialized
INFO - 2017-01-13 10:02:20 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 10:02:20 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 10:02:20 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 10:02:20 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 10:02:20 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-01-13 10:02:20 --> Config Class Initialized
INFO - 2017-01-13 10:02:20 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:02:20 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:02:20 --> Utf8 Class Initialized
INFO - 2017-01-13 10:02:20 --> URI Class Initialized
INFO - 2017-01-13 10:02:20 --> Router Class Initialized
INFO - 2017-01-13 10:02:20 --> Output Class Initialized
INFO - 2017-01-13 10:02:20 --> Security Class Initialized
DEBUG - 2017-01-13 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:02:20 --> Input Class Initialized
INFO - 2017-01-13 10:02:20 --> Language Class Initialized
INFO - 2017-01-13 10:02:20 --> Loader Class Initialized
INFO - 2017-01-13 10:02:20 --> Helper loaded: url_helper
INFO - 2017-01-13 10:02:20 --> Helper loaded: language_helper
INFO - 2017-01-13 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:02:20 --> Controller Class Initialized
INFO - 2017-01-13 10:02:20 --> Database Driver Class Initialized
INFO - 2017-01-13 10:02:20 --> Model Class Initialized
INFO - 2017-01-13 10:02:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 10:02:20 --> Helper loaded: form_helper
INFO - 2017-01-13 10:02:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 10:02:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 10:02:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 10:02:20 --> Final output sent to browser
DEBUG - 2017-01-13 10:02:20 --> Total execution time: 0.0656
INFO - 2017-01-13 10:12:33 --> Config Class Initialized
INFO - 2017-01-13 10:12:33 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:12:33 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:12:33 --> Utf8 Class Initialized
INFO - 2017-01-13 10:12:33 --> URI Class Initialized
INFO - 2017-01-13 10:12:33 --> Router Class Initialized
INFO - 2017-01-13 10:12:33 --> Output Class Initialized
INFO - 2017-01-13 10:12:33 --> Security Class Initialized
DEBUG - 2017-01-13 10:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:12:33 --> Input Class Initialized
INFO - 2017-01-13 10:12:33 --> Language Class Initialized
INFO - 2017-01-13 10:12:33 --> Loader Class Initialized
INFO - 2017-01-13 10:12:33 --> Helper loaded: url_helper
INFO - 2017-01-13 10:12:33 --> Helper loaded: language_helper
INFO - 2017-01-13 10:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:12:33 --> Controller Class Initialized
INFO - 2017-01-13 10:12:33 --> Database Driver Class Initialized
INFO - 2017-01-13 10:12:33 --> Model Class Initialized
INFO - 2017-01-13 10:12:33 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 10:12:33 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 10:12:33 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 10:12:33 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 10:12:33 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-01-13 10:12:33 --> Config Class Initialized
INFO - 2017-01-13 10:12:33 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:12:33 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:12:33 --> Utf8 Class Initialized
INFO - 2017-01-13 10:12:33 --> URI Class Initialized
INFO - 2017-01-13 10:12:33 --> Router Class Initialized
INFO - 2017-01-13 10:12:33 --> Output Class Initialized
INFO - 2017-01-13 10:12:33 --> Security Class Initialized
DEBUG - 2017-01-13 10:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:12:33 --> Input Class Initialized
INFO - 2017-01-13 10:12:33 --> Language Class Initialized
INFO - 2017-01-13 10:12:33 --> Loader Class Initialized
INFO - 2017-01-13 10:12:33 --> Helper loaded: url_helper
INFO - 2017-01-13 10:12:33 --> Helper loaded: language_helper
INFO - 2017-01-13 10:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 10:12:33 --> Controller Class Initialized
INFO - 2017-01-13 10:12:33 --> Database Driver Class Initialized
INFO - 2017-01-13 10:12:33 --> Model Class Initialized
INFO - 2017-01-13 10:12:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 10:12:33 --> Helper loaded: form_helper
INFO - 2017-01-13 10:12:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 10:12:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 10:12:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 10:12:34 --> Final output sent to browser
DEBUG - 2017-01-13 10:12:34 --> Total execution time: 0.0679
INFO - 2017-01-13 10:12:58 --> Config Class Initialized
INFO - 2017-01-13 10:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-13 10:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:12:58 --> Utf8 Class Initialized
INFO - 2017-01-13 10:12:58 --> URI Class Initialized
INFO - 2017-01-13 10:12:58 --> Config Class Initialized
INFO - 2017-01-13 10:12:58 --> Hooks Class Initialized
INFO - 2017-01-13 10:12:58 --> Router Class Initialized
DEBUG - 2017-01-13 10:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-13 10:12:58 --> Output Class Initialized
INFO - 2017-01-13 10:12:58 --> Utf8 Class Initialized
INFO - 2017-01-13 10:12:58 --> Security Class Initialized
INFO - 2017-01-13 10:12:58 --> URI Class Initialized
DEBUG - 2017-01-13 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:12:58 --> Input Class Initialized
INFO - 2017-01-13 10:12:58 --> Router Class Initialized
INFO - 2017-01-13 10:12:58 --> Language Class Initialized
ERROR - 2017-01-13 10:12:58 --> 404 Page Not Found: Bootstrap-datepicker/css
INFO - 2017-01-13 10:12:58 --> Output Class Initialized
INFO - 2017-01-13 10:12:58 --> Security Class Initialized
DEBUG - 2017-01-13 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 10:12:58 --> Input Class Initialized
INFO - 2017-01-13 10:12:58 --> Language Class Initialized
ERROR - 2017-01-13 10:12:58 --> 404 Page Not Found: Bootstrap-datepicker/css
INFO - 2017-01-13 11:58:56 --> Config Class Initialized
INFO - 2017-01-13 11:58:56 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:58:56 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:58:56 --> Utf8 Class Initialized
INFO - 2017-01-13 11:58:56 --> URI Class Initialized
INFO - 2017-01-13 11:58:56 --> Router Class Initialized
INFO - 2017-01-13 11:58:56 --> Output Class Initialized
INFO - 2017-01-13 11:58:56 --> Security Class Initialized
DEBUG - 2017-01-13 11:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:58:56 --> Input Class Initialized
INFO - 2017-01-13 11:58:56 --> Language Class Initialized
INFO - 2017-01-13 11:58:56 --> Loader Class Initialized
INFO - 2017-01-13 11:58:56 --> Helper loaded: url_helper
INFO - 2017-01-13 11:58:56 --> Helper loaded: language_helper
INFO - 2017-01-13 11:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:58:56 --> Controller Class Initialized
INFO - 2017-01-13 11:58:56 --> Database Driver Class Initialized
INFO - 2017-01-13 11:58:56 --> Model Class Initialized
INFO - 2017-01-13 11:58:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:58:56 --> Helper loaded: form_helper
INFO - 2017-01-13 11:58:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 11:58:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 11:58:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 11:58:56 --> Final output sent to browser
DEBUG - 2017-01-13 11:58:56 --> Total execution time: 0.0822
INFO - 2017-01-13 11:59:09 --> Config Class Initialized
INFO - 2017-01-13 11:59:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:09 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:09 --> URI Class Initialized
INFO - 2017-01-13 11:59:09 --> Router Class Initialized
INFO - 2017-01-13 11:59:09 --> Output Class Initialized
INFO - 2017-01-13 11:59:09 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:09 --> Input Class Initialized
INFO - 2017-01-13 11:59:09 --> Language Class Initialized
INFO - 2017-01-13 11:59:09 --> Loader Class Initialized
INFO - 2017-01-13 11:59:09 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:09 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:09 --> Controller Class Initialized
INFO - 2017-01-13 11:59:09 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:09 --> Model Class Initialized
INFO - 2017-01-13 11:59:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 11:59:09 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 11:59:09 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 11:59:09 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 11:59:09 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-01-13 11:59:09 --> Config Class Initialized
INFO - 2017-01-13 11:59:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:09 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:09 --> URI Class Initialized
INFO - 2017-01-13 11:59:09 --> Router Class Initialized
INFO - 2017-01-13 11:59:09 --> Output Class Initialized
INFO - 2017-01-13 11:59:09 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:09 --> Input Class Initialized
INFO - 2017-01-13 11:59:09 --> Language Class Initialized
INFO - 2017-01-13 11:59:09 --> Loader Class Initialized
INFO - 2017-01-13 11:59:09 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:09 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:09 --> Controller Class Initialized
INFO - 2017-01-13 11:59:09 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:09 --> Model Class Initialized
INFO - 2017-01-13 11:59:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:59:09 --> Helper loaded: form_helper
INFO - 2017-01-13 11:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 11:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 11:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 11:59:09 --> Final output sent to browser
DEBUG - 2017-01-13 11:59:09 --> Total execution time: 0.0639
INFO - 2017-01-13 11:59:32 --> Config Class Initialized
INFO - 2017-01-13 11:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:32 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:32 --> URI Class Initialized
INFO - 2017-01-13 11:59:32 --> Router Class Initialized
INFO - 2017-01-13 11:59:32 --> Output Class Initialized
INFO - 2017-01-13 11:59:32 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:32 --> Input Class Initialized
INFO - 2017-01-13 11:59:32 --> Language Class Initialized
INFO - 2017-01-13 11:59:32 --> Loader Class Initialized
INFO - 2017-01-13 11:59:32 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:32 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:32 --> Controller Class Initialized
INFO - 2017-01-13 11:59:32 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:32 --> Model Class Initialized
INFO - 2017-01-13 11:59:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:59:32 --> Config Class Initialized
INFO - 2017-01-13 11:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:32 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:32 --> URI Class Initialized
INFO - 2017-01-13 11:59:32 --> Router Class Initialized
INFO - 2017-01-13 11:59:32 --> Output Class Initialized
INFO - 2017-01-13 11:59:32 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:32 --> Input Class Initialized
INFO - 2017-01-13 11:59:32 --> Language Class Initialized
INFO - 2017-01-13 11:59:32 --> Loader Class Initialized
INFO - 2017-01-13 11:59:32 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:32 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:32 --> Controller Class Initialized
INFO - 2017-01-13 11:59:32 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:32 --> Model Class Initialized
INFO - 2017-01-13 11:59:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:59:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-13 11:59:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-13 11:59:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-13 11:59:32 --> Final output sent to browser
DEBUG - 2017-01-13 11:59:32 --> Total execution time: 0.0604
INFO - 2017-01-13 11:59:32 --> Config Class Initialized
INFO - 2017-01-13 11:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:32 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:32 --> URI Class Initialized
INFO - 2017-01-13 11:59:32 --> Router Class Initialized
INFO - 2017-01-13 11:59:32 --> Output Class Initialized
INFO - 2017-01-13 11:59:32 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:32 --> Input Class Initialized
INFO - 2017-01-13 11:59:32 --> Language Class Initialized
ERROR - 2017-01-13 11:59:32 --> 404 Page Not Found: Faviconico/index
INFO - 2017-01-13 11:59:32 --> Config Class Initialized
INFO - 2017-01-13 11:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:32 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:32 --> URI Class Initialized
INFO - 2017-01-13 11:59:32 --> Router Class Initialized
INFO - 2017-01-13 11:59:32 --> Output Class Initialized
INFO - 2017-01-13 11:59:32 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:32 --> Input Class Initialized
INFO - 2017-01-13 11:59:32 --> Language Class Initialized
ERROR - 2017-01-13 11:59:32 --> 404 Page Not Found: Faviconico/index
INFO - 2017-01-13 11:59:39 --> Config Class Initialized
INFO - 2017-01-13 11:59:39 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:39 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:39 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:39 --> URI Class Initialized
INFO - 2017-01-13 11:59:39 --> Router Class Initialized
INFO - 2017-01-13 11:59:39 --> Output Class Initialized
INFO - 2017-01-13 11:59:39 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:39 --> Input Class Initialized
INFO - 2017-01-13 11:59:39 --> Language Class Initialized
INFO - 2017-01-13 11:59:39 --> Loader Class Initialized
INFO - 2017-01-13 11:59:39 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:39 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:39 --> Controller Class Initialized
INFO - 2017-01-13 11:59:39 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:39 --> Model Class Initialized
INFO - 2017-01-13 11:59:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:59:39 --> Config Class Initialized
INFO - 2017-01-13 11:59:39 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:39 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:39 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:39 --> URI Class Initialized
INFO - 2017-01-13 11:59:39 --> Router Class Initialized
INFO - 2017-01-13 11:59:39 --> Output Class Initialized
INFO - 2017-01-13 11:59:39 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:39 --> Input Class Initialized
INFO - 2017-01-13 11:59:39 --> Language Class Initialized
INFO - 2017-01-13 11:59:39 --> Loader Class Initialized
INFO - 2017-01-13 11:59:39 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:39 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:39 --> Controller Class Initialized
INFO - 2017-01-13 11:59:39 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:39 --> Model Class Initialized
INFO - 2017-01-13 11:59:39 --> Model Class Initialized
INFO - 2017-01-13 11:59:39 --> Model Class Initialized
INFO - 2017-01-13 11:59:39 --> Model Class Initialized
INFO - 2017-01-13 11:59:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:59:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 11:59:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-13 11:59:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 11:59:39 --> Final output sent to browser
DEBUG - 2017-01-13 11:59:39 --> Total execution time: 0.0795
INFO - 2017-01-13 11:59:42 --> Config Class Initialized
INFO - 2017-01-13 11:59:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:59:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:59:42 --> Utf8 Class Initialized
INFO - 2017-01-13 11:59:42 --> URI Class Initialized
INFO - 2017-01-13 11:59:42 --> Router Class Initialized
INFO - 2017-01-13 11:59:42 --> Output Class Initialized
INFO - 2017-01-13 11:59:42 --> Security Class Initialized
DEBUG - 2017-01-13 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:59:42 --> Input Class Initialized
INFO - 2017-01-13 11:59:42 --> Language Class Initialized
INFO - 2017-01-13 11:59:42 --> Loader Class Initialized
INFO - 2017-01-13 11:59:42 --> Helper loaded: url_helper
INFO - 2017-01-13 11:59:42 --> Helper loaded: language_helper
INFO - 2017-01-13 11:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:59:42 --> Controller Class Initialized
INFO - 2017-01-13 11:59:42 --> Database Driver Class Initialized
INFO - 2017-01-13 11:59:42 --> Model Class Initialized
INFO - 2017-01-13 11:59:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 11:59:42 --> Helper loaded: form_helper
INFO - 2017-01-13 11:59:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 11:59:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 11:59:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 11:59:42 --> Final output sent to browser
DEBUG - 2017-01-13 11:59:42 --> Total execution time: 0.0660
INFO - 2017-01-13 12:00:02 --> Config Class Initialized
INFO - 2017-01-13 12:00:02 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:00:02 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:00:02 --> Utf8 Class Initialized
INFO - 2017-01-13 12:00:02 --> URI Class Initialized
INFO - 2017-01-13 12:00:02 --> Router Class Initialized
INFO - 2017-01-13 12:00:02 --> Output Class Initialized
INFO - 2017-01-13 12:00:02 --> Security Class Initialized
DEBUG - 2017-01-13 12:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:00:02 --> Input Class Initialized
INFO - 2017-01-13 12:00:02 --> Language Class Initialized
INFO - 2017-01-13 12:00:02 --> Loader Class Initialized
INFO - 2017-01-13 12:00:02 --> Helper loaded: url_helper
INFO - 2017-01-13 12:00:02 --> Helper loaded: language_helper
INFO - 2017-01-13 12:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:00:02 --> Controller Class Initialized
INFO - 2017-01-13 12:00:02 --> Database Driver Class Initialized
INFO - 2017-01-13 12:00:02 --> Model Class Initialized
INFO - 2017-01-13 12:00:02 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 12:00:02 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 12:00:02 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 12:00:02 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 12:00:02 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 06:30:02 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 06:30:02 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 12:00:32 --> Config Class Initialized
INFO - 2017-01-13 12:00:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:00:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:00:32 --> Utf8 Class Initialized
INFO - 2017-01-13 12:00:32 --> URI Class Initialized
INFO - 2017-01-13 12:00:32 --> Router Class Initialized
INFO - 2017-01-13 12:00:32 --> Output Class Initialized
INFO - 2017-01-13 12:00:32 --> Security Class Initialized
DEBUG - 2017-01-13 12:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:00:32 --> Input Class Initialized
INFO - 2017-01-13 12:00:32 --> Language Class Initialized
INFO - 2017-01-13 12:00:32 --> Loader Class Initialized
INFO - 2017-01-13 12:00:32 --> Helper loaded: url_helper
INFO - 2017-01-13 12:00:32 --> Helper loaded: language_helper
INFO - 2017-01-13 12:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:00:32 --> Controller Class Initialized
INFO - 2017-01-13 12:00:32 --> Database Driver Class Initialized
INFO - 2017-01-13 12:00:32 --> Model Class Initialized
INFO - 2017-01-13 12:00:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 12:00:32 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 12:00:32 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 12:00:32 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 12:00:32 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 06:30:32 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 06:30:32 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 12:01:40 --> Config Class Initialized
INFO - 2017-01-13 12:01:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:01:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:01:40 --> Utf8 Class Initialized
INFO - 2017-01-13 12:01:40 --> URI Class Initialized
DEBUG - 2017-01-13 12:01:40 --> No URI present. Default controller set.
INFO - 2017-01-13 12:01:40 --> Router Class Initialized
INFO - 2017-01-13 12:01:40 --> Output Class Initialized
INFO - 2017-01-13 12:01:40 --> Security Class Initialized
DEBUG - 2017-01-13 12:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:01:40 --> Input Class Initialized
INFO - 2017-01-13 12:01:40 --> Language Class Initialized
INFO - 2017-01-13 12:01:40 --> Loader Class Initialized
INFO - 2017-01-13 12:01:40 --> Helper loaded: url_helper
INFO - 2017-01-13 12:01:40 --> Helper loaded: language_helper
INFO - 2017-01-13 12:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:01:40 --> Controller Class Initialized
INFO - 2017-01-13 12:01:40 --> Database Driver Class Initialized
INFO - 2017-01-13 12:01:40 --> Model Class Initialized
INFO - 2017-01-13 12:01:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:01:40 --> Config Class Initialized
INFO - 2017-01-13 12:01:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:01:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:01:40 --> Utf8 Class Initialized
INFO - 2017-01-13 12:01:40 --> URI Class Initialized
INFO - 2017-01-13 12:01:40 --> Router Class Initialized
INFO - 2017-01-13 12:01:40 --> Output Class Initialized
INFO - 2017-01-13 12:01:40 --> Security Class Initialized
DEBUG - 2017-01-13 12:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:01:40 --> Input Class Initialized
INFO - 2017-01-13 12:01:40 --> Language Class Initialized
INFO - 2017-01-13 12:01:40 --> Loader Class Initialized
INFO - 2017-01-13 12:01:40 --> Helper loaded: url_helper
INFO - 2017-01-13 12:01:40 --> Helper loaded: language_helper
INFO - 2017-01-13 12:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:01:40 --> Controller Class Initialized
INFO - 2017-01-13 12:01:40 --> Database Driver Class Initialized
INFO - 2017-01-13 12:01:40 --> Model Class Initialized
INFO - 2017-01-13 12:01:40 --> Model Class Initialized
INFO - 2017-01-13 12:01:40 --> Model Class Initialized
INFO - 2017-01-13 12:01:40 --> Model Class Initialized
INFO - 2017-01-13 12:01:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:01:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:01:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-13 12:01:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:01:40 --> Final output sent to browser
DEBUG - 2017-01-13 12:01:40 --> Total execution time: 0.0737
INFO - 2017-01-13 12:01:42 --> Config Class Initialized
INFO - 2017-01-13 12:01:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:01:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:01:42 --> Utf8 Class Initialized
INFO - 2017-01-13 12:01:42 --> URI Class Initialized
INFO - 2017-01-13 12:01:42 --> Router Class Initialized
INFO - 2017-01-13 12:01:42 --> Output Class Initialized
INFO - 2017-01-13 12:01:42 --> Security Class Initialized
DEBUG - 2017-01-13 12:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:01:42 --> Input Class Initialized
INFO - 2017-01-13 12:01:42 --> Language Class Initialized
INFO - 2017-01-13 12:01:42 --> Loader Class Initialized
INFO - 2017-01-13 12:01:42 --> Helper loaded: url_helper
INFO - 2017-01-13 12:01:42 --> Helper loaded: language_helper
INFO - 2017-01-13 12:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:01:42 --> Controller Class Initialized
INFO - 2017-01-13 12:01:42 --> Database Driver Class Initialized
INFO - 2017-01-13 12:01:42 --> Model Class Initialized
INFO - 2017-01-13 12:01:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:01:42 --> Helper loaded: form_helper
INFO - 2017-01-13 12:01:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:01:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 12:01:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:01:42 --> Final output sent to browser
DEBUG - 2017-01-13 12:01:42 --> Total execution time: 0.0699
INFO - 2017-01-13 12:02:27 --> Config Class Initialized
INFO - 2017-01-13 12:02:27 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:27 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:27 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:27 --> URI Class Initialized
INFO - 2017-01-13 12:02:27 --> Router Class Initialized
INFO - 2017-01-13 12:02:27 --> Output Class Initialized
INFO - 2017-01-13 12:02:27 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:27 --> Input Class Initialized
INFO - 2017-01-13 12:02:27 --> Language Class Initialized
INFO - 2017-01-13 12:02:27 --> Loader Class Initialized
INFO - 2017-01-13 12:02:27 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:27 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:27 --> Controller Class Initialized
INFO - 2017-01-13 12:02:27 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:27 --> Model Class Initialized
INFO - 2017-01-13 12:02:27 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 12:02:27 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 12:02:27 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 12:02:27 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 12:02:27 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 06:32:27 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 06:32:27 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 12:02:28 --> Config Class Initialized
INFO - 2017-01-13 12:02:28 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:28 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:28 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:28 --> URI Class Initialized
INFO - 2017-01-13 12:02:28 --> Router Class Initialized
INFO - 2017-01-13 12:02:28 --> Output Class Initialized
INFO - 2017-01-13 12:02:28 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:28 --> Input Class Initialized
INFO - 2017-01-13 12:02:28 --> Language Class Initialized
INFO - 2017-01-13 12:02:28 --> Loader Class Initialized
INFO - 2017-01-13 12:02:28 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:28 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:28 --> Controller Class Initialized
INFO - 2017-01-13 12:02:28 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:28 --> Model Class Initialized
INFO - 2017-01-13 12:02:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:02:28 --> Helper loaded: form_helper
INFO - 2017-01-13 12:02:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:02:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 12:02:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:02:28 --> Final output sent to browser
DEBUG - 2017-01-13 12:02:28 --> Total execution time: 0.0678
INFO - 2017-01-13 12:02:42 --> Config Class Initialized
INFO - 2017-01-13 12:02:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:42 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:42 --> URI Class Initialized
INFO - 2017-01-13 12:02:42 --> Router Class Initialized
INFO - 2017-01-13 12:02:42 --> Output Class Initialized
INFO - 2017-01-13 12:02:42 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:42 --> Input Class Initialized
INFO - 2017-01-13 12:02:42 --> Language Class Initialized
INFO - 2017-01-13 12:02:42 --> Loader Class Initialized
INFO - 2017-01-13 12:02:42 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:42 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:42 --> Controller Class Initialized
INFO - 2017-01-13 12:02:42 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:42 --> Model Class Initialized
INFO - 2017-01-13 12:02:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:02:42 --> Config Class Initialized
INFO - 2017-01-13 12:02:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:42 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:42 --> URI Class Initialized
INFO - 2017-01-13 12:02:42 --> Router Class Initialized
INFO - 2017-01-13 12:02:42 --> Output Class Initialized
INFO - 2017-01-13 12:02:42 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:42 --> Input Class Initialized
INFO - 2017-01-13 12:02:42 --> Language Class Initialized
INFO - 2017-01-13 12:02:42 --> Loader Class Initialized
INFO - 2017-01-13 12:02:42 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:42 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:42 --> Controller Class Initialized
INFO - 2017-01-13 12:02:42 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:42 --> Model Class Initialized
INFO - 2017-01-13 12:02:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:02:42 --> Helper loaded: form_helper
INFO - 2017-01-13 12:02:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:02:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 12:02:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:02:42 --> Final output sent to browser
DEBUG - 2017-01-13 12:02:42 --> Total execution time: 0.0641
INFO - 2017-01-13 12:02:46 --> Config Class Initialized
INFO - 2017-01-13 12:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:46 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:46 --> URI Class Initialized
INFO - 2017-01-13 12:02:46 --> Router Class Initialized
INFO - 2017-01-13 12:02:46 --> Output Class Initialized
INFO - 2017-01-13 12:02:46 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:46 --> Input Class Initialized
INFO - 2017-01-13 12:02:46 --> Language Class Initialized
INFO - 2017-01-13 12:02:46 --> Loader Class Initialized
INFO - 2017-01-13 12:02:46 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:46 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:46 --> Controller Class Initialized
INFO - 2017-01-13 12:02:46 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:46 --> Model Class Initialized
INFO - 2017-01-13 12:02:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:02:46 --> Config Class Initialized
INFO - 2017-01-13 12:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:46 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:46 --> URI Class Initialized
INFO - 2017-01-13 12:02:46 --> Router Class Initialized
INFO - 2017-01-13 12:02:46 --> Output Class Initialized
INFO - 2017-01-13 12:02:46 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:46 --> Input Class Initialized
INFO - 2017-01-13 12:02:46 --> Language Class Initialized
INFO - 2017-01-13 12:02:46 --> Loader Class Initialized
INFO - 2017-01-13 12:02:46 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:46 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:46 --> Controller Class Initialized
INFO - 2017-01-13 12:02:46 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:46 --> Model Class Initialized
INFO - 2017-01-13 12:02:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:02:46 --> Helper loaded: form_helper
INFO - 2017-01-13 12:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 12:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:02:46 --> Final output sent to browser
DEBUG - 2017-01-13 12:02:46 --> Total execution time: 0.0649
INFO - 2017-01-13 12:02:52 --> Config Class Initialized
INFO - 2017-01-13 12:02:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:02:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:02:52 --> Utf8 Class Initialized
INFO - 2017-01-13 12:02:52 --> URI Class Initialized
DEBUG - 2017-01-13 12:02:52 --> No URI present. Default controller set.
INFO - 2017-01-13 12:02:52 --> Router Class Initialized
INFO - 2017-01-13 12:02:52 --> Output Class Initialized
INFO - 2017-01-13 12:02:52 --> Security Class Initialized
DEBUG - 2017-01-13 12:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:02:52 --> Input Class Initialized
INFO - 2017-01-13 12:02:52 --> Language Class Initialized
INFO - 2017-01-13 12:02:52 --> Loader Class Initialized
INFO - 2017-01-13 12:02:52 --> Helper loaded: url_helper
INFO - 2017-01-13 12:02:52 --> Helper loaded: language_helper
INFO - 2017-01-13 12:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:02:52 --> Controller Class Initialized
INFO - 2017-01-13 12:02:52 --> Database Driver Class Initialized
INFO - 2017-01-13 12:02:52 --> Model Class Initialized
INFO - 2017-01-13 12:02:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:02:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-13 12:02:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-13 12:02:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-13 12:02:52 --> Final output sent to browser
DEBUG - 2017-01-13 12:02:52 --> Total execution time: 0.0713
INFO - 2017-01-13 12:19:18 --> Config Class Initialized
INFO - 2017-01-13 12:19:18 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:19:18 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:19:18 --> Utf8 Class Initialized
INFO - 2017-01-13 12:19:18 --> URI Class Initialized
INFO - 2017-01-13 12:19:18 --> Router Class Initialized
INFO - 2017-01-13 12:19:18 --> Output Class Initialized
INFO - 2017-01-13 12:19:18 --> Security Class Initialized
DEBUG - 2017-01-13 12:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:19:18 --> Input Class Initialized
INFO - 2017-01-13 12:19:18 --> Language Class Initialized
INFO - 2017-01-13 12:19:18 --> Loader Class Initialized
INFO - 2017-01-13 12:19:18 --> Helper loaded: url_helper
INFO - 2017-01-13 12:19:18 --> Helper loaded: language_helper
INFO - 2017-01-13 12:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:19:18 --> Controller Class Initialized
INFO - 2017-01-13 12:19:18 --> Database Driver Class Initialized
INFO - 2017-01-13 12:19:18 --> Model Class Initialized
INFO - 2017-01-13 12:19:18 --> Model Class Initialized
INFO - 2017-01-13 12:19:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-13 12:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:19:18 --> Final output sent to browser
DEBUG - 2017-01-13 12:19:18 --> Total execution time: 0.0655
INFO - 2017-01-13 12:21:44 --> Config Class Initialized
INFO - 2017-01-13 12:21:44 --> Hooks Class Initialized
DEBUG - 2017-01-13 12:21:44 --> UTF-8 Support Enabled
INFO - 2017-01-13 12:21:44 --> Utf8 Class Initialized
INFO - 2017-01-13 12:21:44 --> URI Class Initialized
INFO - 2017-01-13 12:21:44 --> Router Class Initialized
INFO - 2017-01-13 12:21:44 --> Output Class Initialized
INFO - 2017-01-13 12:21:44 --> Security Class Initialized
DEBUG - 2017-01-13 12:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 12:21:44 --> Input Class Initialized
INFO - 2017-01-13 12:21:44 --> Language Class Initialized
INFO - 2017-01-13 12:21:44 --> Loader Class Initialized
INFO - 2017-01-13 12:21:44 --> Helper loaded: url_helper
INFO - 2017-01-13 12:21:44 --> Helper loaded: language_helper
INFO - 2017-01-13 12:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 12:21:44 --> Controller Class Initialized
INFO - 2017-01-13 12:21:44 --> Database Driver Class Initialized
INFO - 2017-01-13 12:21:44 --> Model Class Initialized
INFO - 2017-01-13 12:21:44 --> Model Class Initialized
INFO - 2017-01-13 12:21:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 12:21:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 12:21:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-13 12:21:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 12:21:44 --> Final output sent to browser
DEBUG - 2017-01-13 12:21:44 --> Total execution time: 0.0616
INFO - 2017-01-13 13:06:14 --> Config Class Initialized
INFO - 2017-01-13 13:06:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:06:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:06:14 --> Utf8 Class Initialized
INFO - 2017-01-13 13:06:14 --> URI Class Initialized
INFO - 2017-01-13 13:06:14 --> Router Class Initialized
INFO - 2017-01-13 13:06:14 --> Output Class Initialized
INFO - 2017-01-13 13:06:14 --> Security Class Initialized
DEBUG - 2017-01-13 13:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:06:14 --> Input Class Initialized
INFO - 2017-01-13 13:06:14 --> Language Class Initialized
INFO - 2017-01-13 13:06:14 --> Loader Class Initialized
INFO - 2017-01-13 13:06:14 --> Helper loaded: url_helper
INFO - 2017-01-13 13:06:14 --> Helper loaded: language_helper
INFO - 2017-01-13 13:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:06:14 --> Controller Class Initialized
INFO - 2017-01-13 13:06:14 --> Database Driver Class Initialized
INFO - 2017-01-13 13:06:14 --> Model Class Initialized
INFO - 2017-01-13 13:06:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:06:14 --> Helper loaded: form_helper
INFO - 2017-01-13 13:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:06:14 --> Final output sent to browser
DEBUG - 2017-01-13 13:06:14 --> Total execution time: 0.0858
INFO - 2017-01-13 13:20:28 --> Config Class Initialized
INFO - 2017-01-13 13:20:28 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:20:28 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:20:28 --> Utf8 Class Initialized
INFO - 2017-01-13 13:20:28 --> URI Class Initialized
INFO - 2017-01-13 13:20:28 --> Router Class Initialized
INFO - 2017-01-13 13:20:28 --> Output Class Initialized
INFO - 2017-01-13 13:20:28 --> Security Class Initialized
DEBUG - 2017-01-13 13:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:20:28 --> Input Class Initialized
INFO - 2017-01-13 13:20:28 --> Language Class Initialized
INFO - 2017-01-13 13:20:28 --> Loader Class Initialized
INFO - 2017-01-13 13:20:28 --> Helper loaded: url_helper
INFO - 2017-01-13 13:20:28 --> Helper loaded: language_helper
INFO - 2017-01-13 13:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:20:28 --> Controller Class Initialized
INFO - 2017-01-13 13:20:28 --> Database Driver Class Initialized
INFO - 2017-01-13 13:20:28 --> Model Class Initialized
INFO - 2017-01-13 13:20:28 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 13:20:28 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 13:20:28 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 13:20:28 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 13:20:28 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 07:50:28 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 07:50:28 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 13:20:29 --> Config Class Initialized
INFO - 2017-01-13 13:20:29 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:20:29 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:20:29 --> Utf8 Class Initialized
INFO - 2017-01-13 13:20:29 --> URI Class Initialized
INFO - 2017-01-13 13:20:29 --> Router Class Initialized
INFO - 2017-01-13 13:20:29 --> Output Class Initialized
INFO - 2017-01-13 13:20:29 --> Security Class Initialized
DEBUG - 2017-01-13 13:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:20:29 --> Input Class Initialized
INFO - 2017-01-13 13:20:29 --> Language Class Initialized
INFO - 2017-01-13 13:20:29 --> Loader Class Initialized
INFO - 2017-01-13 13:20:29 --> Helper loaded: url_helper
INFO - 2017-01-13 13:20:29 --> Helper loaded: language_helper
INFO - 2017-01-13 13:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:20:29 --> Controller Class Initialized
INFO - 2017-01-13 13:20:29 --> Database Driver Class Initialized
INFO - 2017-01-13 13:20:29 --> Model Class Initialized
INFO - 2017-01-13 13:20:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:20:29 --> Helper loaded: form_helper
INFO - 2017-01-13 13:20:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:20:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:20:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:20:29 --> Final output sent to browser
DEBUG - 2017-01-13 13:20:29 --> Total execution time: 0.0666
INFO - 2017-01-13 13:21:32 --> Config Class Initialized
INFO - 2017-01-13 13:21:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:21:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:21:32 --> Utf8 Class Initialized
INFO - 2017-01-13 13:21:32 --> URI Class Initialized
INFO - 2017-01-13 13:21:32 --> Router Class Initialized
INFO - 2017-01-13 13:21:32 --> Output Class Initialized
INFO - 2017-01-13 13:21:32 --> Security Class Initialized
DEBUG - 2017-01-13 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:21:32 --> Input Class Initialized
INFO - 2017-01-13 13:21:32 --> Language Class Initialized
INFO - 2017-01-13 13:21:32 --> Loader Class Initialized
INFO - 2017-01-13 13:21:32 --> Helper loaded: url_helper
INFO - 2017-01-13 13:21:32 --> Helper loaded: language_helper
INFO - 2017-01-13 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:21:32 --> Controller Class Initialized
INFO - 2017-01-13 13:21:32 --> Database Driver Class Initialized
INFO - 2017-01-13 13:21:32 --> Model Class Initialized
INFO - 2017-01-13 13:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:21:32 --> Config Class Initialized
INFO - 2017-01-13 13:21:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:21:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:21:32 --> Utf8 Class Initialized
INFO - 2017-01-13 13:21:32 --> URI Class Initialized
INFO - 2017-01-13 13:21:32 --> Router Class Initialized
INFO - 2017-01-13 13:21:32 --> Output Class Initialized
INFO - 2017-01-13 13:21:32 --> Security Class Initialized
DEBUG - 2017-01-13 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:21:32 --> Input Class Initialized
INFO - 2017-01-13 13:21:32 --> Language Class Initialized
INFO - 2017-01-13 13:21:32 --> Loader Class Initialized
INFO - 2017-01-13 13:21:32 --> Helper loaded: url_helper
INFO - 2017-01-13 13:21:32 --> Helper loaded: language_helper
INFO - 2017-01-13 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:21:32 --> Controller Class Initialized
INFO - 2017-01-13 13:21:32 --> Database Driver Class Initialized
INFO - 2017-01-13 13:21:32 --> Model Class Initialized
INFO - 2017-01-13 13:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:21:32 --> Helper loaded: form_helper
INFO - 2017-01-13 13:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:21:32 --> Final output sent to browser
DEBUG - 2017-01-13 13:21:32 --> Total execution time: 0.0673
INFO - 2017-01-13 13:21:42 --> Config Class Initialized
INFO - 2017-01-13 13:21:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:21:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:21:42 --> Utf8 Class Initialized
INFO - 2017-01-13 13:21:42 --> URI Class Initialized
INFO - 2017-01-13 13:21:42 --> Router Class Initialized
INFO - 2017-01-13 13:21:42 --> Output Class Initialized
INFO - 2017-01-13 13:21:42 --> Security Class Initialized
DEBUG - 2017-01-13 13:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:21:42 --> Input Class Initialized
INFO - 2017-01-13 13:21:42 --> Language Class Initialized
INFO - 2017-01-13 13:21:42 --> Loader Class Initialized
INFO - 2017-01-13 13:21:42 --> Helper loaded: url_helper
INFO - 2017-01-13 13:21:42 --> Helper loaded: language_helper
INFO - 2017-01-13 13:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:21:42 --> Controller Class Initialized
INFO - 2017-01-13 13:21:42 --> Database Driver Class Initialized
INFO - 2017-01-13 13:21:42 --> Model Class Initialized
INFO - 2017-01-13 13:21:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 13:21:42 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 13:21:42 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 13:21:42 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 13:21:42 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 07:51:42 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 07:51:42 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 13:21:43 --> Config Class Initialized
INFO - 2017-01-13 13:21:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:21:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:21:43 --> Utf8 Class Initialized
INFO - 2017-01-13 13:21:43 --> URI Class Initialized
INFO - 2017-01-13 13:21:43 --> Router Class Initialized
INFO - 2017-01-13 13:21:43 --> Output Class Initialized
INFO - 2017-01-13 13:21:43 --> Security Class Initialized
DEBUG - 2017-01-13 13:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:21:43 --> Input Class Initialized
INFO - 2017-01-13 13:21:43 --> Language Class Initialized
INFO - 2017-01-13 13:21:43 --> Loader Class Initialized
INFO - 2017-01-13 13:21:43 --> Helper loaded: url_helper
INFO - 2017-01-13 13:21:43 --> Helper loaded: language_helper
INFO - 2017-01-13 13:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:21:43 --> Controller Class Initialized
INFO - 2017-01-13 13:21:43 --> Database Driver Class Initialized
INFO - 2017-01-13 13:21:43 --> Model Class Initialized
INFO - 2017-01-13 13:21:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:21:43 --> Helper loaded: form_helper
INFO - 2017-01-13 13:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:21:43 --> Final output sent to browser
DEBUG - 2017-01-13 13:21:43 --> Total execution time: 0.0683
INFO - 2017-01-13 13:21:49 --> Config Class Initialized
INFO - 2017-01-13 13:21:49 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:21:49 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:21:49 --> Utf8 Class Initialized
INFO - 2017-01-13 13:21:49 --> URI Class Initialized
INFO - 2017-01-13 13:21:49 --> Router Class Initialized
INFO - 2017-01-13 13:21:49 --> Output Class Initialized
INFO - 2017-01-13 13:21:49 --> Security Class Initialized
DEBUG - 2017-01-13 13:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:21:49 --> Input Class Initialized
INFO - 2017-01-13 13:21:49 --> Language Class Initialized
INFO - 2017-01-13 13:21:49 --> Loader Class Initialized
INFO - 2017-01-13 13:21:49 --> Helper loaded: url_helper
INFO - 2017-01-13 13:21:49 --> Helper loaded: language_helper
INFO - 2017-01-13 13:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:21:49 --> Controller Class Initialized
INFO - 2017-01-13 13:21:49 --> Database Driver Class Initialized
INFO - 2017-01-13 13:21:49 --> Model Class Initialized
INFO - 2017-01-13 13:21:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:21:49 --> Config Class Initialized
INFO - 2017-01-13 13:21:49 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:21:49 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:21:49 --> Utf8 Class Initialized
INFO - 2017-01-13 13:21:49 --> URI Class Initialized
INFO - 2017-01-13 13:21:49 --> Router Class Initialized
INFO - 2017-01-13 13:21:49 --> Output Class Initialized
INFO - 2017-01-13 13:21:49 --> Security Class Initialized
DEBUG - 2017-01-13 13:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:21:49 --> Input Class Initialized
INFO - 2017-01-13 13:21:49 --> Language Class Initialized
INFO - 2017-01-13 13:21:49 --> Loader Class Initialized
INFO - 2017-01-13 13:21:49 --> Helper loaded: url_helper
INFO - 2017-01-13 13:21:49 --> Helper loaded: language_helper
INFO - 2017-01-13 13:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:21:49 --> Controller Class Initialized
INFO - 2017-01-13 13:21:49 --> Database Driver Class Initialized
INFO - 2017-01-13 13:21:49 --> Model Class Initialized
INFO - 2017-01-13 13:21:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:21:49 --> Helper loaded: form_helper
INFO - 2017-01-13 13:21:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:21:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:21:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:21:49 --> Final output sent to browser
DEBUG - 2017-01-13 13:21:49 --> Total execution time: 0.0654
INFO - 2017-01-13 13:25:18 --> Config Class Initialized
INFO - 2017-01-13 13:25:18 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:25:18 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:25:18 --> Utf8 Class Initialized
INFO - 2017-01-13 13:25:18 --> URI Class Initialized
INFO - 2017-01-13 13:25:18 --> Router Class Initialized
INFO - 2017-01-13 13:25:18 --> Output Class Initialized
INFO - 2017-01-13 13:25:18 --> Security Class Initialized
DEBUG - 2017-01-13 13:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:25:18 --> Input Class Initialized
INFO - 2017-01-13 13:25:18 --> Language Class Initialized
INFO - 2017-01-13 13:25:18 --> Loader Class Initialized
INFO - 2017-01-13 13:25:18 --> Helper loaded: url_helper
INFO - 2017-01-13 13:25:18 --> Helper loaded: language_helper
INFO - 2017-01-13 13:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:25:18 --> Controller Class Initialized
INFO - 2017-01-13 13:25:18 --> Database Driver Class Initialized
INFO - 2017-01-13 13:25:18 --> Model Class Initialized
INFO - 2017-01-13 13:25:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:25:18 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 13:25:18 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 07:55:18 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 07:55:18 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 13:25:18 --> Config Class Initialized
INFO - 2017-01-13 13:25:18 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:25:18 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:25:18 --> Utf8 Class Initialized
INFO - 2017-01-13 13:25:18 --> URI Class Initialized
INFO - 2017-01-13 13:25:18 --> Router Class Initialized
INFO - 2017-01-13 13:25:18 --> Output Class Initialized
INFO - 2017-01-13 13:25:18 --> Security Class Initialized
DEBUG - 2017-01-13 13:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:25:18 --> Input Class Initialized
INFO - 2017-01-13 13:25:18 --> Language Class Initialized
INFO - 2017-01-13 13:25:18 --> Loader Class Initialized
INFO - 2017-01-13 13:25:18 --> Helper loaded: url_helper
INFO - 2017-01-13 13:25:18 --> Helper loaded: language_helper
INFO - 2017-01-13 13:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:25:18 --> Controller Class Initialized
INFO - 2017-01-13 13:25:18 --> Database Driver Class Initialized
INFO - 2017-01-13 13:25:18 --> Model Class Initialized
INFO - 2017-01-13 13:25:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:25:18 --> Helper loaded: form_helper
INFO - 2017-01-13 13:25:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:25:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:25:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:25:18 --> Final output sent to browser
DEBUG - 2017-01-13 13:25:18 --> Total execution time: 0.0825
INFO - 2017-01-13 13:28:30 --> Config Class Initialized
INFO - 2017-01-13 13:28:30 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:28:30 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:28:30 --> Utf8 Class Initialized
INFO - 2017-01-13 13:28:30 --> URI Class Initialized
INFO - 2017-01-13 13:28:30 --> Router Class Initialized
INFO - 2017-01-13 13:28:30 --> Output Class Initialized
INFO - 2017-01-13 13:28:30 --> Security Class Initialized
DEBUG - 2017-01-13 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:28:30 --> Input Class Initialized
INFO - 2017-01-13 13:28:30 --> Language Class Initialized
INFO - 2017-01-13 13:28:30 --> Loader Class Initialized
INFO - 2017-01-13 13:28:30 --> Helper loaded: url_helper
INFO - 2017-01-13 13:28:30 --> Helper loaded: language_helper
INFO - 2017-01-13 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:28:30 --> Controller Class Initialized
INFO - 2017-01-13 13:28:30 --> Database Driver Class Initialized
INFO - 2017-01-13 13:28:30 --> Model Class Initialized
INFO - 2017-01-13 13:28:31 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-13 13:28:31 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; OLERead has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 95
ERROR - 2017-01-13 13:28:31 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Spreadsheet_Excel_Reader has a deprecated constructor C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\php-excel-reader\excel_reader2_helper.php 312
INFO - 2017-01-13 13:28:31 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-01-13 13:28:31 --> Helper loaded: xlsimport/spreadsheetreader_helper
ERROR - 2017-01-13 07:58:31 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
ERROR - 2017-01-13 07:58:31 --> Severity: Notice --> Undefined index: cells C:\wamp64\www\savsoftquiz\application\helpers\xlsimport\SpreadsheetReader_XLS.php 133
INFO - 2017-01-13 13:28:31 --> Config Class Initialized
INFO - 2017-01-13 13:28:31 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:28:31 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:28:31 --> Utf8 Class Initialized
INFO - 2017-01-13 13:28:31 --> URI Class Initialized
INFO - 2017-01-13 13:28:31 --> Router Class Initialized
INFO - 2017-01-13 13:28:31 --> Output Class Initialized
INFO - 2017-01-13 13:28:31 --> Security Class Initialized
DEBUG - 2017-01-13 13:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:28:31 --> Input Class Initialized
INFO - 2017-01-13 13:28:31 --> Language Class Initialized
INFO - 2017-01-13 13:28:31 --> Loader Class Initialized
INFO - 2017-01-13 13:28:31 --> Helper loaded: url_helper
INFO - 2017-01-13 13:28:31 --> Helper loaded: language_helper
INFO - 2017-01-13 13:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:28:31 --> Controller Class Initialized
INFO - 2017-01-13 13:28:31 --> Database Driver Class Initialized
INFO - 2017-01-13 13:28:31 --> Model Class Initialized
INFO - 2017-01-13 13:28:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:28:31 --> Helper loaded: form_helper
INFO - 2017-01-13 13:28:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:28:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 13:28:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:28:31 --> Final output sent to browser
DEBUG - 2017-01-13 13:28:31 --> Total execution time: 0.0718
INFO - 2017-01-13 13:49:20 --> Config Class Initialized
INFO - 2017-01-13 13:49:20 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:49:20 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:49:20 --> Utf8 Class Initialized
INFO - 2017-01-13 13:49:20 --> URI Class Initialized
INFO - 2017-01-13 13:49:20 --> Router Class Initialized
INFO - 2017-01-13 13:49:20 --> Output Class Initialized
INFO - 2017-01-13 13:49:20 --> Security Class Initialized
DEBUG - 2017-01-13 13:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:49:20 --> Input Class Initialized
INFO - 2017-01-13 13:49:20 --> Language Class Initialized
INFO - 2017-01-13 13:49:20 --> Loader Class Initialized
INFO - 2017-01-13 13:49:20 --> Helper loaded: url_helper
INFO - 2017-01-13 13:49:20 --> Helper loaded: language_helper
INFO - 2017-01-13 13:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:49:20 --> Controller Class Initialized
INFO - 2017-01-13 13:49:20 --> Database Driver Class Initialized
INFO - 2017-01-13 13:49:20 --> Model Class Initialized
INFO - 2017-01-13 13:49:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:49:20 --> Helper loaded: form_helper
INFO - 2017-01-13 13:49:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-13 13:49:20 --> Could not find the language line "import_user"
INFO - 2017-01-13 13:49:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-13 13:49:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:49:20 --> Final output sent to browser
DEBUG - 2017-01-13 13:49:20 --> Total execution time: 0.0703
INFO - 2017-01-13 13:49:28 --> Config Class Initialized
INFO - 2017-01-13 13:49:28 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:49:28 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:49:28 --> Utf8 Class Initialized
INFO - 2017-01-13 13:49:28 --> URI Class Initialized
INFO - 2017-01-13 13:49:28 --> Router Class Initialized
INFO - 2017-01-13 13:49:28 --> Output Class Initialized
INFO - 2017-01-13 13:49:28 --> Security Class Initialized
DEBUG - 2017-01-13 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:49:28 --> Input Class Initialized
INFO - 2017-01-13 13:49:28 --> Language Class Initialized
INFO - 2017-01-13 13:49:28 --> Loader Class Initialized
INFO - 2017-01-13 13:49:28 --> Helper loaded: url_helper
INFO - 2017-01-13 13:49:28 --> Helper loaded: language_helper
INFO - 2017-01-13 13:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:49:28 --> Controller Class Initialized
INFO - 2017-01-13 13:49:28 --> Database Driver Class Initialized
INFO - 2017-01-13 13:49:28 --> Model Class Initialized
INFO - 2017-01-13 13:49:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:49:28 --> Config Class Initialized
INFO - 2017-01-13 13:49:28 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:49:28 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:49:28 --> Utf8 Class Initialized
INFO - 2017-01-13 13:49:28 --> URI Class Initialized
INFO - 2017-01-13 13:49:28 --> Router Class Initialized
INFO - 2017-01-13 13:49:28 --> Output Class Initialized
INFO - 2017-01-13 13:49:28 --> Security Class Initialized
DEBUG - 2017-01-13 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:49:28 --> Input Class Initialized
INFO - 2017-01-13 13:49:28 --> Language Class Initialized
INFO - 2017-01-13 13:49:29 --> Loader Class Initialized
INFO - 2017-01-13 13:49:29 --> Helper loaded: url_helper
INFO - 2017-01-13 13:49:29 --> Helper loaded: language_helper
INFO - 2017-01-13 13:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:49:29 --> Controller Class Initialized
INFO - 2017-01-13 13:49:29 --> Database Driver Class Initialized
INFO - 2017-01-13 13:49:29 --> Model Class Initialized
INFO - 2017-01-13 13:49:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:49:29 --> Helper loaded: form_helper
INFO - 2017-01-13 13:49:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-13 13:49:29 --> Could not find the language line "import_user"
INFO - 2017-01-13 13:49:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-13 13:49:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:49:29 --> Final output sent to browser
DEBUG - 2017-01-13 13:49:29 --> Total execution time: 0.0625
INFO - 2017-01-13 13:50:30 --> Config Class Initialized
INFO - 2017-01-13 13:50:30 --> Hooks Class Initialized
DEBUG - 2017-01-13 13:50:30 --> UTF-8 Support Enabled
INFO - 2017-01-13 13:50:30 --> Utf8 Class Initialized
INFO - 2017-01-13 13:50:30 --> URI Class Initialized
INFO - 2017-01-13 13:50:30 --> Router Class Initialized
INFO - 2017-01-13 13:50:30 --> Output Class Initialized
INFO - 2017-01-13 13:50:30 --> Security Class Initialized
DEBUG - 2017-01-13 13:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 13:50:30 --> Input Class Initialized
INFO - 2017-01-13 13:50:30 --> Language Class Initialized
INFO - 2017-01-13 13:50:30 --> Loader Class Initialized
INFO - 2017-01-13 13:50:30 --> Helper loaded: url_helper
INFO - 2017-01-13 13:50:30 --> Helper loaded: language_helper
INFO - 2017-01-13 13:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 13:50:30 --> Controller Class Initialized
INFO - 2017-01-13 13:50:30 --> Database Driver Class Initialized
INFO - 2017-01-13 13:50:30 --> Model Class Initialized
INFO - 2017-01-13 13:50:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 13:50:30 --> Helper loaded: form_helper
INFO - 2017-01-13 13:50:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 13:50:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-13 13:50:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 13:50:30 --> Final output sent to browser
DEBUG - 2017-01-13 13:50:30 --> Total execution time: 0.0650
INFO - 2017-01-13 14:26:21 --> Config Class Initialized
INFO - 2017-01-13 14:26:21 --> Hooks Class Initialized
DEBUG - 2017-01-13 14:26:21 --> UTF-8 Support Enabled
INFO - 2017-01-13 14:26:21 --> Utf8 Class Initialized
INFO - 2017-01-13 14:26:21 --> URI Class Initialized
INFO - 2017-01-13 14:26:21 --> Router Class Initialized
INFO - 2017-01-13 14:26:21 --> Output Class Initialized
INFO - 2017-01-13 14:26:21 --> Security Class Initialized
DEBUG - 2017-01-13 14:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 14:26:21 --> Input Class Initialized
INFO - 2017-01-13 14:26:21 --> Language Class Initialized
INFO - 2017-01-13 14:26:21 --> Loader Class Initialized
INFO - 2017-01-13 14:26:21 --> Helper loaded: url_helper
INFO - 2017-01-13 14:26:21 --> Helper loaded: language_helper
INFO - 2017-01-13 14:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 14:26:21 --> Controller Class Initialized
INFO - 2017-01-13 14:26:21 --> Database Driver Class Initialized
INFO - 2017-01-13 14:26:21 --> Model Class Initialized
INFO - 2017-01-13 14:26:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-13 14:26:21 --> Helper loaded: form_helper
INFO - 2017-01-13 14:26:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-13 14:26:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-13 14:26:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-13 14:26:21 --> Final output sent to browser
DEBUG - 2017-01-13 14:26:21 --> Total execution time: 0.1206
