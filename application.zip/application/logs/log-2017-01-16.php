<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-16 09:16:32 --> Config Class Initialized
INFO - 2017-01-16 09:16:32 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:16:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:16:32 --> Utf8 Class Initialized
INFO - 2017-01-16 09:16:32 --> URI Class Initialized
INFO - 2017-01-16 09:16:32 --> Router Class Initialized
INFO - 2017-01-16 09:16:32 --> Output Class Initialized
INFO - 2017-01-16 09:16:32 --> Security Class Initialized
DEBUG - 2017-01-16 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:16:32 --> Input Class Initialized
INFO - 2017-01-16 09:16:32 --> Language Class Initialized
INFO - 2017-01-16 09:16:32 --> Loader Class Initialized
INFO - 2017-01-16 09:16:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:16:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:16:32 --> Controller Class Initialized
INFO - 2017-01-16 09:16:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:16:32 --> Model Class Initialized
INFO - 2017-01-16 09:16:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:16:32 --> Config Class Initialized
INFO - 2017-01-16 09:16:32 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:16:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:16:32 --> Utf8 Class Initialized
INFO - 2017-01-16 09:16:32 --> URI Class Initialized
INFO - 2017-01-16 09:16:32 --> Router Class Initialized
INFO - 2017-01-16 09:16:32 --> Output Class Initialized
INFO - 2017-01-16 09:16:32 --> Security Class Initialized
DEBUG - 2017-01-16 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:16:32 --> Input Class Initialized
INFO - 2017-01-16 09:16:32 --> Language Class Initialized
INFO - 2017-01-16 09:16:32 --> Loader Class Initialized
INFO - 2017-01-16 09:16:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:16:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:16:32 --> Controller Class Initialized
INFO - 2017-01-16 09:16:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:16:32 --> Model Class Initialized
INFO - 2017-01-16 09:16:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:16:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-16 09:16:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-16 09:16:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-16 09:16:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:16:32 --> Total execution time: 0.0612
INFO - 2017-01-16 09:16:37 --> Config Class Initialized
INFO - 2017-01-16 09:16:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:16:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:16:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:16:37 --> URI Class Initialized
INFO - 2017-01-16 09:16:37 --> Router Class Initialized
INFO - 2017-01-16 09:16:37 --> Output Class Initialized
INFO - 2017-01-16 09:16:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:16:37 --> Input Class Initialized
INFO - 2017-01-16 09:16:37 --> Language Class Initialized
INFO - 2017-01-16 09:16:37 --> Loader Class Initialized
INFO - 2017-01-16 09:16:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:16:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:16:37 --> Controller Class Initialized
INFO - 2017-01-16 09:16:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:16:37 --> Model Class Initialized
INFO - 2017-01-16 09:16:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:16:37 --> Config Class Initialized
INFO - 2017-01-16 09:16:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:16:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:16:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:16:37 --> URI Class Initialized
INFO - 2017-01-16 09:16:37 --> Router Class Initialized
INFO - 2017-01-16 09:16:37 --> Output Class Initialized
INFO - 2017-01-16 09:16:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:16:37 --> Input Class Initialized
INFO - 2017-01-16 09:16:37 --> Language Class Initialized
INFO - 2017-01-16 09:16:37 --> Loader Class Initialized
INFO - 2017-01-16 09:16:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:16:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:16:37 --> Controller Class Initialized
INFO - 2017-01-16 09:16:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:16:37 --> Model Class Initialized
INFO - 2017-01-16 09:16:37 --> Model Class Initialized
INFO - 2017-01-16 09:16:37 --> Model Class Initialized
INFO - 2017-01-16 09:16:37 --> Model Class Initialized
INFO - 2017-01-16 09:16:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:16:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:16:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-16 09:16:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:16:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:16:37 --> Total execution time: 0.0754
INFO - 2017-01-16 09:16:42 --> Config Class Initialized
INFO - 2017-01-16 09:16:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:16:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:16:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:16:42 --> URI Class Initialized
INFO - 2017-01-16 09:16:42 --> Router Class Initialized
INFO - 2017-01-16 09:16:42 --> Output Class Initialized
INFO - 2017-01-16 09:16:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:16:42 --> Input Class Initialized
INFO - 2017-01-16 09:16:42 --> Language Class Initialized
INFO - 2017-01-16 09:16:42 --> Loader Class Initialized
INFO - 2017-01-16 09:16:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:16:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:16:42 --> Controller Class Initialized
INFO - 2017-01-16 09:16:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:16:42 --> Model Class Initialized
INFO - 2017-01-16 09:16:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:16:42 --> Helper loaded: form_helper
INFO - 2017-01-16 09:16:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:16:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-16 09:16:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:16:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:16:42 --> Total execution time: 0.0672
INFO - 2017-01-16 09:17:26 --> Config Class Initialized
INFO - 2017-01-16 09:17:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:17:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:17:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:17:26 --> URI Class Initialized
INFO - 2017-01-16 09:17:26 --> Router Class Initialized
INFO - 2017-01-16 09:17:26 --> Output Class Initialized
INFO - 2017-01-16 09:17:26 --> Security Class Initialized
DEBUG - 2017-01-16 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:17:26 --> Input Class Initialized
INFO - 2017-01-16 09:17:26 --> Language Class Initialized
INFO - 2017-01-16 09:17:26 --> Loader Class Initialized
INFO - 2017-01-16 09:17:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:17:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:17:26 --> Controller Class Initialized
INFO - 2017-01-16 09:17:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:17:26 --> Model Class Initialized
INFO - 2017-01-16 09:17:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:17:26 --> Helper loaded: form_helper
INFO - 2017-01-16 09:17:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:17:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:17:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:17:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:17:26 --> Total execution time: 0.0623
INFO - 2017-01-16 09:21:41 --> Config Class Initialized
INFO - 2017-01-16 09:21:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:21:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:21:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:21:41 --> URI Class Initialized
INFO - 2017-01-16 09:21:41 --> Router Class Initialized
INFO - 2017-01-16 09:21:41 --> Output Class Initialized
INFO - 2017-01-16 09:21:41 --> Security Class Initialized
DEBUG - 2017-01-16 09:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:21:41 --> Input Class Initialized
INFO - 2017-01-16 09:21:41 --> Language Class Initialized
INFO - 2017-01-16 09:21:41 --> Loader Class Initialized
INFO - 2017-01-16 09:21:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:21:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:21:41 --> Controller Class Initialized
INFO - 2017-01-16 09:21:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:21:41 --> Model Class Initialized
INFO - 2017-01-16 09:21:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:21:42 --> Helper loaded: form_helper
INFO - 2017-01-16 09:21:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:21:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:21:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:21:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:21:42 --> Total execution time: 0.0655
INFO - 2017-01-16 09:21:48 --> Config Class Initialized
INFO - 2017-01-16 09:21:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:21:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:21:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:21:48 --> URI Class Initialized
INFO - 2017-01-16 09:21:48 --> Router Class Initialized
INFO - 2017-01-16 09:21:48 --> Output Class Initialized
INFO - 2017-01-16 09:21:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:21:48 --> Input Class Initialized
INFO - 2017-01-16 09:21:48 --> Language Class Initialized
INFO - 2017-01-16 09:21:48 --> Loader Class Initialized
INFO - 2017-01-16 09:21:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:21:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:21:48 --> Controller Class Initialized
INFO - 2017-01-16 09:21:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:21:48 --> Model Class Initialized
INFO - 2017-01-16 09:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:21:48 --> Config Class Initialized
INFO - 2017-01-16 09:21:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:21:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:21:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:21:48 --> URI Class Initialized
INFO - 2017-01-16 09:21:48 --> Router Class Initialized
INFO - 2017-01-16 09:21:48 --> Output Class Initialized
INFO - 2017-01-16 09:21:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:21:48 --> Input Class Initialized
INFO - 2017-01-16 09:21:48 --> Language Class Initialized
INFO - 2017-01-16 09:21:48 --> Loader Class Initialized
INFO - 2017-01-16 09:21:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:21:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:21:48 --> Controller Class Initialized
INFO - 2017-01-16 09:21:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:21:48 --> Model Class Initialized
INFO - 2017-01-16 09:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:21:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-16 09:21:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-16 09:21:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-16 09:21:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:21:48 --> Total execution time: 0.0563
INFO - 2017-01-16 09:22:00 --> Config Class Initialized
INFO - 2017-01-16 09:22:00 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:00 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:00 --> URI Class Initialized
INFO - 2017-01-16 09:22:00 --> Router Class Initialized
INFO - 2017-01-16 09:22:00 --> Output Class Initialized
INFO - 2017-01-16 09:22:00 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:00 --> Input Class Initialized
INFO - 2017-01-16 09:22:00 --> Language Class Initialized
INFO - 2017-01-16 09:22:00 --> Loader Class Initialized
INFO - 2017-01-16 09:22:00 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:00 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:00 --> Controller Class Initialized
INFO - 2017-01-16 09:22:00 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:00 --> Model Class Initialized
INFO - 2017-01-16 09:22:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:00 --> Config Class Initialized
INFO - 2017-01-16 09:22:00 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:00 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:00 --> URI Class Initialized
INFO - 2017-01-16 09:22:00 --> Router Class Initialized
INFO - 2017-01-16 09:22:00 --> Output Class Initialized
INFO - 2017-01-16 09:22:00 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:00 --> Input Class Initialized
INFO - 2017-01-16 09:22:00 --> Language Class Initialized
INFO - 2017-01-16 09:22:00 --> Loader Class Initialized
INFO - 2017-01-16 09:22:00 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:00 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:00 --> Controller Class Initialized
INFO - 2017-01-16 09:22:00 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:00 --> Model Class Initialized
INFO - 2017-01-16 09:22:00 --> Model Class Initialized
INFO - 2017-01-16 09:22:00 --> Model Class Initialized
INFO - 2017-01-16 09:22:00 --> Model Class Initialized
INFO - 2017-01-16 09:22:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:22:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-16 09:22:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:22:00 --> Final output sent to browser
DEBUG - 2017-01-16 09:22:00 --> Total execution time: 0.0668
INFO - 2017-01-16 09:22:05 --> Config Class Initialized
INFO - 2017-01-16 09:22:05 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:05 --> URI Class Initialized
INFO - 2017-01-16 09:22:05 --> Router Class Initialized
INFO - 2017-01-16 09:22:05 --> Output Class Initialized
INFO - 2017-01-16 09:22:05 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:05 --> Input Class Initialized
INFO - 2017-01-16 09:22:05 --> Language Class Initialized
INFO - 2017-01-16 09:22:05 --> Loader Class Initialized
INFO - 2017-01-16 09:22:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:05 --> Controller Class Initialized
INFO - 2017-01-16 09:22:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:05 --> Model Class Initialized
INFO - 2017-01-16 09:22:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:05 --> Helper loaded: form_helper
INFO - 2017-01-16 09:22:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 09:22:05 --> Could not find the language line "import_user"
INFO - 2017-01-16 09:22:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-16 09:22:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:22:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:22:05 --> Total execution time: 0.0632
INFO - 2017-01-16 09:22:16 --> Config Class Initialized
INFO - 2017-01-16 09:22:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:16 --> URI Class Initialized
INFO - 2017-01-16 09:22:16 --> Router Class Initialized
INFO - 2017-01-16 09:22:16 --> Output Class Initialized
INFO - 2017-01-16 09:22:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:16 --> Input Class Initialized
INFO - 2017-01-16 09:22:16 --> Language Class Initialized
INFO - 2017-01-16 09:22:16 --> Loader Class Initialized
INFO - 2017-01-16 09:22:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:16 --> Controller Class Initialized
INFO - 2017-01-16 09:22:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:16 --> Model Class Initialized
INFO - 2017-01-16 09:22:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:22:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-16 09:22:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:22:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:22:16 --> Total execution time: 0.0584
INFO - 2017-01-16 09:22:16 --> Config Class Initialized
INFO - 2017-01-16 09:22:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:16 --> URI Class Initialized
INFO - 2017-01-16 09:22:16 --> Router Class Initialized
INFO - 2017-01-16 09:22:16 --> Output Class Initialized
INFO - 2017-01-16 09:22:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:16 --> Input Class Initialized
INFO - 2017-01-16 09:22:16 --> Language Class Initialized
INFO - 2017-01-16 09:22:16 --> Loader Class Initialized
INFO - 2017-01-16 09:22:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:16 --> Controller Class Initialized
INFO - 2017-01-16 09:22:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:16 --> Model Class Initialized
INFO - 2017-01-16 09:22:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:22:16 --> Total execution time: 0.0680
INFO - 2017-01-16 09:22:37 --> Config Class Initialized
INFO - 2017-01-16 09:22:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:37 --> URI Class Initialized
INFO - 2017-01-16 09:22:37 --> Router Class Initialized
INFO - 2017-01-16 09:22:37 --> Output Class Initialized
INFO - 2017-01-16 09:22:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:37 --> Input Class Initialized
INFO - 2017-01-16 09:22:37 --> Language Class Initialized
INFO - 2017-01-16 09:22:37 --> Loader Class Initialized
INFO - 2017-01-16 09:22:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:37 --> Controller Class Initialized
INFO - 2017-01-16 09:22:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:37 --> Model Class Initialized
INFO - 2017-01-16 09:22:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:37 --> Helper loaded: form_helper
INFO - 2017-01-16 09:22:37 --> Form Validation Class Initialized
INFO - 2017-01-16 09:22:37 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-16 09:22:37 --> Config Class Initialized
INFO - 2017-01-16 09:22:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:37 --> URI Class Initialized
INFO - 2017-01-16 09:22:37 --> Router Class Initialized
INFO - 2017-01-16 09:22:37 --> Output Class Initialized
INFO - 2017-01-16 09:22:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:37 --> Input Class Initialized
INFO - 2017-01-16 09:22:37 --> Language Class Initialized
INFO - 2017-01-16 09:22:37 --> Loader Class Initialized
INFO - 2017-01-16 09:22:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:37 --> Controller Class Initialized
INFO - 2017-01-16 09:22:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:37 --> Model Class Initialized
INFO - 2017-01-16 09:22:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:22:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-16 09:22:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:22:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:22:37 --> Total execution time: 0.0571
INFO - 2017-01-16 09:22:37 --> Config Class Initialized
INFO - 2017-01-16 09:22:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:22:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:22:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:22:37 --> URI Class Initialized
INFO - 2017-01-16 09:22:37 --> Router Class Initialized
INFO - 2017-01-16 09:22:37 --> Output Class Initialized
INFO - 2017-01-16 09:22:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:22:37 --> Input Class Initialized
INFO - 2017-01-16 09:22:37 --> Language Class Initialized
INFO - 2017-01-16 09:22:37 --> Loader Class Initialized
INFO - 2017-01-16 09:22:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:22:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:22:37 --> Controller Class Initialized
INFO - 2017-01-16 09:22:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:22:37 --> Model Class Initialized
INFO - 2017-01-16 09:22:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:22:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:22:37 --> Total execution time: 0.0845
INFO - 2017-01-16 09:24:06 --> Config Class Initialized
INFO - 2017-01-16 09:24:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:06 --> URI Class Initialized
INFO - 2017-01-16 09:24:06 --> Router Class Initialized
INFO - 2017-01-16 09:24:06 --> Output Class Initialized
INFO - 2017-01-16 09:24:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:06 --> Input Class Initialized
INFO - 2017-01-16 09:24:06 --> Language Class Initialized
INFO - 2017-01-16 09:24:06 --> Loader Class Initialized
INFO - 2017-01-16 09:24:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:06 --> Controller Class Initialized
INFO - 2017-01-16 09:24:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:06 --> Model Class Initialized
INFO - 2017-01-16 09:24:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:06 --> Helper loaded: form_helper
INFO - 2017-01-16 09:24:06 --> Form Validation Class Initialized
INFO - 2017-01-16 09:24:06 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-16 09:24:06 --> Config Class Initialized
INFO - 2017-01-16 09:24:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:06 --> URI Class Initialized
INFO - 2017-01-16 09:24:06 --> Router Class Initialized
INFO - 2017-01-16 09:24:06 --> Output Class Initialized
INFO - 2017-01-16 09:24:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:06 --> Input Class Initialized
INFO - 2017-01-16 09:24:06 --> Language Class Initialized
INFO - 2017-01-16 09:24:06 --> Loader Class Initialized
INFO - 2017-01-16 09:24:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:06 --> Controller Class Initialized
INFO - 2017-01-16 09:24:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:06 --> Model Class Initialized
INFO - 2017-01-16 09:24:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-01-16 09:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:06 --> Total execution time: 0.0560
INFO - 2017-01-16 09:24:06 --> Config Class Initialized
INFO - 2017-01-16 09:24:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:06 --> URI Class Initialized
INFO - 2017-01-16 09:24:06 --> Router Class Initialized
INFO - 2017-01-16 09:24:06 --> Output Class Initialized
INFO - 2017-01-16 09:24:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:06 --> Input Class Initialized
INFO - 2017-01-16 09:24:06 --> Language Class Initialized
INFO - 2017-01-16 09:24:06 --> Loader Class Initialized
INFO - 2017-01-16 09:24:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:06 --> Controller Class Initialized
INFO - 2017-01-16 09:24:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:06 --> Model Class Initialized
INFO - 2017-01-16 09:24:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:06 --> Total execution time: 0.0701
INFO - 2017-01-16 09:24:09 --> Config Class Initialized
INFO - 2017-01-16 09:24:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:09 --> URI Class Initialized
INFO - 2017-01-16 09:24:09 --> Router Class Initialized
INFO - 2017-01-16 09:24:09 --> Output Class Initialized
INFO - 2017-01-16 09:24:09 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:09 --> Input Class Initialized
INFO - 2017-01-16 09:24:09 --> Language Class Initialized
INFO - 2017-01-16 09:24:09 --> Loader Class Initialized
INFO - 2017-01-16 09:24:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:09 --> Controller Class Initialized
INFO - 2017-01-16 09:24:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:09 --> Model Class Initialized
INFO - 2017-01-16 09:24:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:09 --> Helper loaded: form_helper
INFO - 2017-01-16 09:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 09:24:09 --> Could not find the language line "import_user"
INFO - 2017-01-16 09:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-16 09:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:09 --> Total execution time: 0.0611
INFO - 2017-01-16 09:24:12 --> Config Class Initialized
INFO - 2017-01-16 09:24:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:12 --> URI Class Initialized
INFO - 2017-01-16 09:24:12 --> Router Class Initialized
INFO - 2017-01-16 09:24:12 --> Output Class Initialized
INFO - 2017-01-16 09:24:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:12 --> Input Class Initialized
INFO - 2017-01-16 09:24:12 --> Language Class Initialized
INFO - 2017-01-16 09:24:12 --> Loader Class Initialized
INFO - 2017-01-16 09:24:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:12 --> Controller Class Initialized
INFO - 2017-01-16 09:24:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:12 --> Model Class Initialized
INFO - 2017-01-16 09:24:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:12 --> Config Class Initialized
INFO - 2017-01-16 09:24:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:12 --> URI Class Initialized
INFO - 2017-01-16 09:24:12 --> Router Class Initialized
INFO - 2017-01-16 09:24:12 --> Output Class Initialized
INFO - 2017-01-16 09:24:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:12 --> Input Class Initialized
INFO - 2017-01-16 09:24:12 --> Language Class Initialized
INFO - 2017-01-16 09:24:12 --> Loader Class Initialized
INFO - 2017-01-16 09:24:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:12 --> Controller Class Initialized
INFO - 2017-01-16 09:24:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:12 --> Model Class Initialized
INFO - 2017-01-16 09:24:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-16 09:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-16 09:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-16 09:24:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:12 --> Total execution time: 0.0540
INFO - 2017-01-16 09:24:18 --> Config Class Initialized
INFO - 2017-01-16 09:24:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:18 --> URI Class Initialized
INFO - 2017-01-16 09:24:18 --> Router Class Initialized
INFO - 2017-01-16 09:24:18 --> Output Class Initialized
INFO - 2017-01-16 09:24:18 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:18 --> Input Class Initialized
INFO - 2017-01-16 09:24:18 --> Language Class Initialized
INFO - 2017-01-16 09:24:18 --> Loader Class Initialized
INFO - 2017-01-16 09:24:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:18 --> Controller Class Initialized
INFO - 2017-01-16 09:24:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:18 --> Model Class Initialized
INFO - 2017-01-16 09:24:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:18 --> Config Class Initialized
INFO - 2017-01-16 09:24:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:18 --> URI Class Initialized
INFO - 2017-01-16 09:24:18 --> Router Class Initialized
INFO - 2017-01-16 09:24:18 --> Output Class Initialized
INFO - 2017-01-16 09:24:18 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:18 --> Input Class Initialized
INFO - 2017-01-16 09:24:18 --> Language Class Initialized
INFO - 2017-01-16 09:24:18 --> Loader Class Initialized
INFO - 2017-01-16 09:24:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:18 --> Controller Class Initialized
INFO - 2017-01-16 09:24:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:18 --> Model Class Initialized
INFO - 2017-01-16 09:24:18 --> Model Class Initialized
INFO - 2017-01-16 09:24:18 --> Model Class Initialized
INFO - 2017-01-16 09:24:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-16 09:24:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:19 --> Total execution time: 0.0647
INFO - 2017-01-16 09:24:26 --> Config Class Initialized
INFO - 2017-01-16 09:24:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:26 --> URI Class Initialized
INFO - 2017-01-16 09:24:26 --> Router Class Initialized
INFO - 2017-01-16 09:24:26 --> Output Class Initialized
INFO - 2017-01-16 09:24:26 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:26 --> Input Class Initialized
INFO - 2017-01-16 09:24:26 --> Language Class Initialized
INFO - 2017-01-16 09:24:26 --> Loader Class Initialized
INFO - 2017-01-16 09:24:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:26 --> Controller Class Initialized
INFO - 2017-01-16 09:24:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:26 --> Model Class Initialized
INFO - 2017-01-16 09:24:26 --> Model Class Initialized
INFO - 2017-01-16 09:24:26 --> Model Class Initialized
INFO - 2017-01-16 09:24:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpu.php
INFO - 2017-01-16 09:24:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:26 --> Total execution time: 0.0640
INFO - 2017-01-16 09:24:28 --> Config Class Initialized
INFO - 2017-01-16 09:24:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:28 --> URI Class Initialized
INFO - 2017-01-16 09:24:28 --> Router Class Initialized
INFO - 2017-01-16 09:24:28 --> Output Class Initialized
INFO - 2017-01-16 09:24:28 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:28 --> Input Class Initialized
INFO - 2017-01-16 09:24:28 --> Language Class Initialized
INFO - 2017-01-16 09:24:28 --> Loader Class Initialized
INFO - 2017-01-16 09:24:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:28 --> Controller Class Initialized
INFO - 2017-01-16 09:24:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:28 --> Config Class Initialized
INFO - 2017-01-16 09:24:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:28 --> URI Class Initialized
INFO - 2017-01-16 09:24:28 --> Router Class Initialized
INFO - 2017-01-16 09:24:28 --> Output Class Initialized
INFO - 2017-01-16 09:24:28 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:28 --> Input Class Initialized
INFO - 2017-01-16 09:24:28 --> Language Class Initialized
INFO - 2017-01-16 09:24:28 --> Loader Class Initialized
INFO - 2017-01-16 09:24:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:28 --> Controller Class Initialized
INFO - 2017-01-16 09:24:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpu_attempt.php
INFO - 2017-01-16 09:24:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:28 --> Total execution time: 0.0800
INFO - 2017-01-16 09:24:28 --> Config Class Initialized
INFO - 2017-01-16 09:24:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:28 --> URI Class Initialized
INFO - 2017-01-16 09:24:28 --> Router Class Initialized
INFO - 2017-01-16 09:24:28 --> Output Class Initialized
INFO - 2017-01-16 09:24:28 --> Config Class Initialized
INFO - 2017-01-16 09:24:28 --> Security Class Initialized
INFO - 2017-01-16 09:24:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:28 --> Input Class Initialized
INFO - 2017-01-16 09:24:28 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:28 --> URI Class Initialized
INFO - 2017-01-16 09:24:28 --> Loader Class Initialized
INFO - 2017-01-16 09:24:28 --> Router Class Initialized
INFO - 2017-01-16 09:24:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:28 --> Output Class Initialized
INFO - 2017-01-16 09:24:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:28 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:28 --> Input Class Initialized
INFO - 2017-01-16 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:28 --> Controller Class Initialized
INFO - 2017-01-16 09:24:28 --> Language Class Initialized
INFO - 2017-01-16 09:24:28 --> Loader Class Initialized
INFO - 2017-01-16 09:24:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:28 --> Total execution time: 0.0804
INFO - 2017-01-16 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:28 --> Controller Class Initialized
INFO - 2017-01-16 09:24:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Model Class Initialized
INFO - 2017-01-16 09:24:28 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:24:28 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:24:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:28 --> Total execution time: 0.1043
INFO - 2017-01-16 09:24:30 --> Config Class Initialized
INFO - 2017-01-16 09:24:30 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:30 --> Config Class Initialized
INFO - 2017-01-16 09:24:30 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:30 --> URI Class Initialized
DEBUG - 2017-01-16 09:24:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:30 --> Router Class Initialized
INFO - 2017-01-16 09:24:30 --> URI Class Initialized
INFO - 2017-01-16 09:24:30 --> Output Class Initialized
INFO - 2017-01-16 09:24:30 --> Router Class Initialized
INFO - 2017-01-16 09:24:30 --> Security Class Initialized
INFO - 2017-01-16 09:24:30 --> Output Class Initialized
DEBUG - 2017-01-16 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:30 --> Input Class Initialized
INFO - 2017-01-16 09:24:30 --> Language Class Initialized
INFO - 2017-01-16 09:24:30 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:30 --> Input Class Initialized
INFO - 2017-01-16 09:24:30 --> Loader Class Initialized
INFO - 2017-01-16 09:24:30 --> Language Class Initialized
INFO - 2017-01-16 09:24:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:30 --> Loader Class Initialized
INFO - 2017-01-16 09:24:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:30 --> Controller Class Initialized
INFO - 2017-01-16 09:24:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:30 --> Model Class Initialized
INFO - 2017-01-16 09:24:30 --> Model Class Initialized
INFO - 2017-01-16 09:24:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:30 --> Total execution time: 0.0685
INFO - 2017-01-16 09:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:30 --> Controller Class Initialized
INFO - 2017-01-16 09:24:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:30 --> Model Class Initialized
INFO - 2017-01-16 09:24:30 --> Model Class Initialized
INFO - 2017-01-16 09:24:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:30 --> Total execution time: 0.0947
INFO - 2017-01-16 09:24:32 --> Config Class Initialized
INFO - 2017-01-16 09:24:32 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:32 --> Config Class Initialized
INFO - 2017-01-16 09:24:32 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:32 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:32 --> URI Class Initialized
DEBUG - 2017-01-16 09:24:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:32 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:32 --> Router Class Initialized
INFO - 2017-01-16 09:24:32 --> URI Class Initialized
INFO - 2017-01-16 09:24:32 --> Output Class Initialized
INFO - 2017-01-16 09:24:32 --> Security Class Initialized
INFO - 2017-01-16 09:24:32 --> Router Class Initialized
DEBUG - 2017-01-16 09:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:32 --> Input Class Initialized
INFO - 2017-01-16 09:24:32 --> Output Class Initialized
INFO - 2017-01-16 09:24:32 --> Language Class Initialized
INFO - 2017-01-16 09:24:32 --> Security Class Initialized
INFO - 2017-01-16 09:24:32 --> Loader Class Initialized
DEBUG - 2017-01-16 09:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:32 --> Input Class Initialized
INFO - 2017-01-16 09:24:32 --> Language Class Initialized
INFO - 2017-01-16 09:24:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:32 --> Loader Class Initialized
INFO - 2017-01-16 09:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:32 --> Controller Class Initialized
INFO - 2017-01-16 09:24:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:32 --> Model Class Initialized
INFO - 2017-01-16 09:24:32 --> Model Class Initialized
INFO - 2017-01-16 09:24:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:32 --> Total execution time: 0.0696
INFO - 2017-01-16 09:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:32 --> Controller Class Initialized
INFO - 2017-01-16 09:24:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:32 --> Model Class Initialized
INFO - 2017-01-16 09:24:32 --> Model Class Initialized
INFO - 2017-01-16 09:24:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:32 --> Total execution time: 0.1072
INFO - 2017-01-16 09:24:33 --> Config Class Initialized
INFO - 2017-01-16 09:24:33 --> Config Class Initialized
INFO - 2017-01-16 09:24:33 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:24:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:33 --> URI Class Initialized
INFO - 2017-01-16 09:24:33 --> URI Class Initialized
INFO - 2017-01-16 09:24:33 --> Router Class Initialized
INFO - 2017-01-16 09:24:33 --> Router Class Initialized
INFO - 2017-01-16 09:24:33 --> Output Class Initialized
INFO - 2017-01-16 09:24:33 --> Output Class Initialized
INFO - 2017-01-16 09:24:33 --> Security Class Initialized
INFO - 2017-01-16 09:24:33 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:33 --> Input Class Initialized
DEBUG - 2017-01-16 09:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:33 --> Input Class Initialized
INFO - 2017-01-16 09:24:33 --> Language Class Initialized
INFO - 2017-01-16 09:24:33 --> Language Class Initialized
INFO - 2017-01-16 09:24:33 --> Loader Class Initialized
INFO - 2017-01-16 09:24:33 --> Loader Class Initialized
INFO - 2017-01-16 09:24:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:33 --> Controller Class Initialized
INFO - 2017-01-16 09:24:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:33 --> Model Class Initialized
INFO - 2017-01-16 09:24:33 --> Model Class Initialized
INFO - 2017-01-16 09:24:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:33 --> Total execution time: 0.0712
INFO - 2017-01-16 09:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:33 --> Controller Class Initialized
INFO - 2017-01-16 09:24:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:33 --> Model Class Initialized
INFO - 2017-01-16 09:24:33 --> Model Class Initialized
INFO - 2017-01-16 09:24:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:33 --> Total execution time: 0.1195
INFO - 2017-01-16 09:24:35 --> Config Class Initialized
INFO - 2017-01-16 09:24:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:35 --> Config Class Initialized
INFO - 2017-01-16 09:24:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:35 --> URI Class Initialized
DEBUG - 2017-01-16 09:24:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:35 --> URI Class Initialized
INFO - 2017-01-16 09:24:35 --> Router Class Initialized
INFO - 2017-01-16 09:24:35 --> Router Class Initialized
INFO - 2017-01-16 09:24:35 --> Output Class Initialized
INFO - 2017-01-16 09:24:35 --> Security Class Initialized
INFO - 2017-01-16 09:24:35 --> Output Class Initialized
DEBUG - 2017-01-16 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:35 --> Input Class Initialized
INFO - 2017-01-16 09:24:35 --> Security Class Initialized
INFO - 2017-01-16 09:24:35 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:35 --> Input Class Initialized
INFO - 2017-01-16 09:24:35 --> Language Class Initialized
INFO - 2017-01-16 09:24:35 --> Loader Class Initialized
INFO - 2017-01-16 09:24:35 --> Loader Class Initialized
INFO - 2017-01-16 09:24:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:35 --> Controller Class Initialized
INFO - 2017-01-16 09:24:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:35 --> Model Class Initialized
INFO - 2017-01-16 09:24:35 --> Model Class Initialized
INFO - 2017-01-16 09:24:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:35 --> Total execution time: 0.0736
INFO - 2017-01-16 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:35 --> Controller Class Initialized
INFO - 2017-01-16 09:24:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:35 --> Model Class Initialized
INFO - 2017-01-16 09:24:35 --> Model Class Initialized
INFO - 2017-01-16 09:24:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:35 --> Total execution time: 0.1259
INFO - 2017-01-16 09:24:36 --> Config Class Initialized
INFO - 2017-01-16 09:24:36 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:36 --> Config Class Initialized
INFO - 2017-01-16 09:24:36 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:36 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:24:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:36 --> URI Class Initialized
INFO - 2017-01-16 09:24:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:36 --> URI Class Initialized
INFO - 2017-01-16 09:24:36 --> Router Class Initialized
INFO - 2017-01-16 09:24:36 --> Router Class Initialized
INFO - 2017-01-16 09:24:36 --> Output Class Initialized
INFO - 2017-01-16 09:24:36 --> Output Class Initialized
INFO - 2017-01-16 09:24:36 --> Security Class Initialized
INFO - 2017-01-16 09:24:36 --> Config Class Initialized
INFO - 2017-01-16 09:24:36 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:36 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:36 --> Input Class Initialized
DEBUG - 2017-01-16 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:36 --> Language Class Initialized
INFO - 2017-01-16 09:24:36 --> Input Class Initialized
DEBUG - 2017-01-16 09:24:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:36 --> Language Class Initialized
INFO - 2017-01-16 09:24:36 --> URI Class Initialized
INFO - 2017-01-16 09:24:36 --> Router Class Initialized
INFO - 2017-01-16 09:24:36 --> Loader Class Initialized
INFO - 2017-01-16 09:24:36 --> Output Class Initialized
INFO - 2017-01-16 09:24:36 --> Loader Class Initialized
INFO - 2017-01-16 09:24:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:36 --> Security Class Initialized
INFO - 2017-01-16 09:24:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:37 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:37 --> Input Class Initialized
INFO - 2017-01-16 09:24:37 --> Language Class Initialized
INFO - 2017-01-16 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:37 --> Controller Class Initialized
INFO - 2017-01-16 09:24:37 --> Loader Class Initialized
INFO - 2017-01-16 09:24:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:37 --> Total execution time: 0.1176
INFO - 2017-01-16 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:37 --> Controller Class Initialized
INFO - 2017-01-16 09:24:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:37 --> Total execution time: 0.1486
INFO - 2017-01-16 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:37 --> Controller Class Initialized
INFO - 2017-01-16 09:24:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:37 --> Config Class Initialized
INFO - 2017-01-16 09:24:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:37 --> URI Class Initialized
INFO - 2017-01-16 09:24:37 --> Router Class Initialized
INFO - 2017-01-16 09:24:37 --> Output Class Initialized
INFO - 2017-01-16 09:24:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:37 --> Input Class Initialized
INFO - 2017-01-16 09:24:37 --> Language Class Initialized
INFO - 2017-01-16 09:24:37 --> Loader Class Initialized
INFO - 2017-01-16 09:24:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:37 --> Controller Class Initialized
INFO - 2017-01-16 09:24:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Model Class Initialized
INFO - 2017-01-16 09:24:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpa.php
INFO - 2017-01-16 09:24:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:37 --> Total execution time: 0.0791
INFO - 2017-01-16 09:24:38 --> Config Class Initialized
INFO - 2017-01-16 09:24:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:38 --> URI Class Initialized
INFO - 2017-01-16 09:24:38 --> Router Class Initialized
INFO - 2017-01-16 09:24:38 --> Output Class Initialized
INFO - 2017-01-16 09:24:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:38 --> Input Class Initialized
INFO - 2017-01-16 09:24:38 --> Language Class Initialized
INFO - 2017-01-16 09:24:38 --> Loader Class Initialized
INFO - 2017-01-16 09:24:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:38 --> Controller Class Initialized
INFO - 2017-01-16 09:24:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:38 --> Config Class Initialized
INFO - 2017-01-16 09:24:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:38 --> URI Class Initialized
INFO - 2017-01-16 09:24:38 --> Router Class Initialized
INFO - 2017-01-16 09:24:38 --> Output Class Initialized
INFO - 2017-01-16 09:24:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:38 --> Input Class Initialized
INFO - 2017-01-16 09:24:38 --> Language Class Initialized
INFO - 2017-01-16 09:24:38 --> Loader Class Initialized
INFO - 2017-01-16 09:24:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:38 --> Controller Class Initialized
INFO - 2017-01-16 09:24:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpa_attempt.php
INFO - 2017-01-16 09:24:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:38 --> Total execution time: 0.0821
INFO - 2017-01-16 09:24:38 --> Config Class Initialized
INFO - 2017-01-16 09:24:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:38 --> Config Class Initialized
INFO - 2017-01-16 09:24:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:38 --> URI Class Initialized
DEBUG - 2017-01-16 09:24:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:38 --> Router Class Initialized
INFO - 2017-01-16 09:24:38 --> URI Class Initialized
INFO - 2017-01-16 09:24:38 --> Router Class Initialized
INFO - 2017-01-16 09:24:38 --> Output Class Initialized
INFO - 2017-01-16 09:24:38 --> Security Class Initialized
INFO - 2017-01-16 09:24:38 --> Output Class Initialized
DEBUG - 2017-01-16 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:38 --> Input Class Initialized
INFO - 2017-01-16 09:24:38 --> Security Class Initialized
INFO - 2017-01-16 09:24:38 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:38 --> Input Class Initialized
INFO - 2017-01-16 09:24:38 --> Language Class Initialized
INFO - 2017-01-16 09:24:38 --> Loader Class Initialized
INFO - 2017-01-16 09:24:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:38 --> Loader Class Initialized
INFO - 2017-01-16 09:24:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:38 --> Controller Class Initialized
INFO - 2017-01-16 09:24:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:38 --> Total execution time: 0.0857
INFO - 2017-01-16 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:38 --> Controller Class Initialized
INFO - 2017-01-16 09:24:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Model Class Initialized
INFO - 2017-01-16 09:24:38 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:24:38 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:24:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:24:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:39 --> Total execution time: 0.1247
INFO - 2017-01-16 09:24:41 --> Config Class Initialized
INFO - 2017-01-16 09:24:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:41 --> Config Class Initialized
INFO - 2017-01-16 09:24:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:41 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:24:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:41 --> URI Class Initialized
INFO - 2017-01-16 09:24:41 --> URI Class Initialized
INFO - 2017-01-16 09:24:41 --> Router Class Initialized
INFO - 2017-01-16 09:24:41 --> Router Class Initialized
INFO - 2017-01-16 09:24:41 --> Output Class Initialized
INFO - 2017-01-16 09:24:41 --> Output Class Initialized
INFO - 2017-01-16 09:24:41 --> Security Class Initialized
INFO - 2017-01-16 09:24:41 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:41 --> Input Class Initialized
DEBUG - 2017-01-16 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:41 --> Input Class Initialized
INFO - 2017-01-16 09:24:41 --> Language Class Initialized
INFO - 2017-01-16 09:24:41 --> Language Class Initialized
INFO - 2017-01-16 09:24:41 --> Loader Class Initialized
INFO - 2017-01-16 09:24:41 --> Loader Class Initialized
INFO - 2017-01-16 09:24:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:41 --> Controller Class Initialized
INFO - 2017-01-16 09:24:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:41 --> Model Class Initialized
INFO - 2017-01-16 09:24:41 --> Model Class Initialized
INFO - 2017-01-16 09:24:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:41 --> Total execution time: 0.0693
INFO - 2017-01-16 09:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:41 --> Controller Class Initialized
INFO - 2017-01-16 09:24:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:41 --> Model Class Initialized
INFO - 2017-01-16 09:24:41 --> Model Class Initialized
INFO - 2017-01-16 09:24:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:41 --> Total execution time: 0.0941
INFO - 2017-01-16 09:24:42 --> Config Class Initialized
INFO - 2017-01-16 09:24:42 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:42 --> Config Class Initialized
INFO - 2017-01-16 09:24:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:42 --> URI Class Initialized
DEBUG - 2017-01-16 09:24:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:42 --> Router Class Initialized
INFO - 2017-01-16 09:24:42 --> URI Class Initialized
INFO - 2017-01-16 09:24:42 --> Output Class Initialized
INFO - 2017-01-16 09:24:42 --> Security Class Initialized
INFO - 2017-01-16 09:24:42 --> Router Class Initialized
DEBUG - 2017-01-16 09:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:42 --> Input Class Initialized
INFO - 2017-01-16 09:24:42 --> Output Class Initialized
INFO - 2017-01-16 09:24:42 --> Language Class Initialized
INFO - 2017-01-16 09:24:42 --> Security Class Initialized
INFO - 2017-01-16 09:24:42 --> Loader Class Initialized
DEBUG - 2017-01-16 09:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:42 --> Input Class Initialized
INFO - 2017-01-16 09:24:42 --> Language Class Initialized
INFO - 2017-01-16 09:24:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:42 --> Loader Class Initialized
INFO - 2017-01-16 09:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:42 --> Controller Class Initialized
INFO - 2017-01-16 09:24:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:42 --> Model Class Initialized
INFO - 2017-01-16 09:24:42 --> Model Class Initialized
INFO - 2017-01-16 09:24:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:42 --> Total execution time: 0.0857
INFO - 2017-01-16 09:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:42 --> Controller Class Initialized
INFO - 2017-01-16 09:24:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:42 --> Model Class Initialized
INFO - 2017-01-16 09:24:42 --> Model Class Initialized
INFO - 2017-01-16 09:24:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:42 --> Total execution time: 0.1070
INFO - 2017-01-16 09:24:44 --> Config Class Initialized
INFO - 2017-01-16 09:24:44 --> Config Class Initialized
INFO - 2017-01-16 09:24:44 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:24:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:44 --> URI Class Initialized
INFO - 2017-01-16 09:24:44 --> URI Class Initialized
INFO - 2017-01-16 09:24:44 --> Router Class Initialized
INFO - 2017-01-16 09:24:44 --> Router Class Initialized
INFO - 2017-01-16 09:24:44 --> Output Class Initialized
INFO - 2017-01-16 09:24:44 --> Output Class Initialized
INFO - 2017-01-16 09:24:44 --> Security Class Initialized
INFO - 2017-01-16 09:24:44 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:44 --> Input Class Initialized
INFO - 2017-01-16 09:24:44 --> Input Class Initialized
INFO - 2017-01-16 09:24:44 --> Language Class Initialized
INFO - 2017-01-16 09:24:44 --> Language Class Initialized
INFO - 2017-01-16 09:24:44 --> Loader Class Initialized
INFO - 2017-01-16 09:24:44 --> Loader Class Initialized
INFO - 2017-01-16 09:24:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:44 --> Controller Class Initialized
INFO - 2017-01-16 09:24:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:44 --> Model Class Initialized
INFO - 2017-01-16 09:24:44 --> Model Class Initialized
INFO - 2017-01-16 09:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:44 --> Total execution time: 0.0957
INFO - 2017-01-16 09:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:44 --> Controller Class Initialized
INFO - 2017-01-16 09:24:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:44 --> Model Class Initialized
INFO - 2017-01-16 09:24:44 --> Model Class Initialized
INFO - 2017-01-16 09:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:44 --> Total execution time: 0.1220
INFO - 2017-01-16 09:24:46 --> Config Class Initialized
INFO - 2017-01-16 09:24:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:46 --> Config Class Initialized
INFO - 2017-01-16 09:24:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:46 --> URI Class Initialized
DEBUG - 2017-01-16 09:24:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:46 --> Router Class Initialized
INFO - 2017-01-16 09:24:46 --> URI Class Initialized
INFO - 2017-01-16 09:24:46 --> Output Class Initialized
INFO - 2017-01-16 09:24:46 --> Router Class Initialized
INFO - 2017-01-16 09:24:46 --> Security Class Initialized
INFO - 2017-01-16 09:24:46 --> Output Class Initialized
DEBUG - 2017-01-16 09:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:46 --> Input Class Initialized
INFO - 2017-01-16 09:24:46 --> Security Class Initialized
INFO - 2017-01-16 09:24:46 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:46 --> Input Class Initialized
INFO - 2017-01-16 09:24:46 --> Language Class Initialized
INFO - 2017-01-16 09:24:46 --> Loader Class Initialized
INFO - 2017-01-16 09:24:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:46 --> Loader Class Initialized
INFO - 2017-01-16 09:24:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:46 --> Controller Class Initialized
INFO - 2017-01-16 09:24:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:46 --> Model Class Initialized
INFO - 2017-01-16 09:24:46 --> Model Class Initialized
INFO - 2017-01-16 09:24:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:46 --> Total execution time: 0.0731
INFO - 2017-01-16 09:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:46 --> Controller Class Initialized
INFO - 2017-01-16 09:24:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:46 --> Model Class Initialized
INFO - 2017-01-16 09:24:46 --> Model Class Initialized
INFO - 2017-01-16 09:24:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:46 --> Total execution time: 0.1257
INFO - 2017-01-16 09:24:48 --> Config Class Initialized
INFO - 2017-01-16 09:24:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:48 --> Config Class Initialized
INFO - 2017-01-16 09:24:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:48 --> Config Class Initialized
INFO - 2017-01-16 09:24:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:48 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:48 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:48 --> URI Class Initialized
INFO - 2017-01-16 09:24:48 --> URI Class Initialized
INFO - 2017-01-16 09:24:48 --> URI Class Initialized
INFO - 2017-01-16 09:24:48 --> Router Class Initialized
INFO - 2017-01-16 09:24:48 --> Router Class Initialized
INFO - 2017-01-16 09:24:48 --> Router Class Initialized
INFO - 2017-01-16 09:24:48 --> Output Class Initialized
INFO - 2017-01-16 09:24:48 --> Output Class Initialized
INFO - 2017-01-16 09:24:48 --> Security Class Initialized
INFO - 2017-01-16 09:24:48 --> Output Class Initialized
INFO - 2017-01-16 09:24:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:48 --> Input Class Initialized
INFO - 2017-01-16 09:24:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:48 --> Language Class Initialized
INFO - 2017-01-16 09:24:48 --> Input Class Initialized
INFO - 2017-01-16 09:24:48 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:48 --> Input Class Initialized
INFO - 2017-01-16 09:24:48 --> Language Class Initialized
INFO - 2017-01-16 09:24:48 --> Loader Class Initialized
INFO - 2017-01-16 09:24:48 --> Loader Class Initialized
INFO - 2017-01-16 09:24:48 --> Loader Class Initialized
INFO - 2017-01-16 09:24:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:48 --> Controller Class Initialized
INFO - 2017-01-16 09:24:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:48 --> Controller Class Initialized
INFO - 2017-01-16 09:24:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Config Class Initialized
INFO - 2017-01-16 09:24:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:48 --> Total execution time: 0.1333
DEBUG - 2017-01-16 09:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:48 --> Controller Class Initialized
INFO - 2017-01-16 09:24:48 --> URI Class Initialized
INFO - 2017-01-16 09:24:48 --> Router Class Initialized
INFO - 2017-01-16 09:24:48 --> Output Class Initialized
INFO - 2017-01-16 09:24:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:48 --> Input Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Language Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:48 --> Total execution time: 0.1615
INFO - 2017-01-16 09:24:48 --> Loader Class Initialized
INFO - 2017-01-16 09:24:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:48 --> Controller Class Initialized
INFO - 2017-01-16 09:24:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Model Class Initialized
INFO - 2017-01-16 09:24:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-16 09:24:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:48 --> Total execution time: 0.0823
INFO - 2017-01-16 09:24:50 --> Config Class Initialized
INFO - 2017-01-16 09:24:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:50 --> Config Class Initialized
INFO - 2017-01-16 09:24:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:50 --> Config Class Initialized
INFO - 2017-01-16 09:24:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:50 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:50 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:50 --> URI Class Initialized
INFO - 2017-01-16 09:24:50 --> URI Class Initialized
INFO - 2017-01-16 09:24:50 --> Router Class Initialized
INFO - 2017-01-16 09:24:50 --> URI Class Initialized
INFO - 2017-01-16 09:24:50 --> Router Class Initialized
INFO - 2017-01-16 09:24:50 --> Output Class Initialized
INFO - 2017-01-16 09:24:50 --> Config Class Initialized
INFO - 2017-01-16 09:24:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:50 --> Security Class Initialized
INFO - 2017-01-16 09:24:50 --> Output Class Initialized
INFO - 2017-01-16 09:24:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:50 --> Config Class Initialized
DEBUG - 2017-01-16 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:50 --> Security Class Initialized
INFO - 2017-01-16 09:24:50 --> Input Class Initialized
INFO - 2017-01-16 09:24:50 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:50 --> Input Class Initialized
INFO - 2017-01-16 09:24:50 --> Language Class Initialized
DEBUG - 2017-01-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:50 --> URI Class Initialized
INFO - 2017-01-16 09:24:50 --> Router Class Initialized
INFO - 2017-01-16 09:24:50 --> Loader Class Initialized
INFO - 2017-01-16 09:24:50 --> Loader Class Initialized
INFO - 2017-01-16 09:24:50 --> Config Class Initialized
INFO - 2017-01-16 09:24:50 --> Output Class Initialized
INFO - 2017-01-16 09:24:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:24:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:50 --> Security Class Initialized
INFO - 2017-01-16 09:24:50 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:50 --> Input Class Initialized
DEBUG - 2017-01-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:24:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:24:50 --> Language Class Initialized
INFO - 2017-01-16 09:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:50 --> URI Class Initialized
INFO - 2017-01-16 09:24:50 --> Controller Class Initialized
INFO - 2017-01-16 09:24:50 --> Output Class Initialized
INFO - 2017-01-16 09:24:51 --> Router Class Initialized
INFO - 2017-01-16 09:24:51 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:51 --> Loader Class Initialized
INFO - 2017-01-16 09:24:51 --> Input Class Initialized
INFO - 2017-01-16 09:24:51 --> Language Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:51 --> Output Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:51 --> Security Class Initialized
DEBUG - 2017-01-16 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:51 --> URI Class Initialized
INFO - 2017-01-16 09:24:51 --> Input Class Initialized
INFO - 2017-01-16 09:24:51 --> Language Class Initialized
INFO - 2017-01-16 09:24:51 --> Router Class Initialized
INFO - 2017-01-16 09:24:51 --> Loader Class Initialized
INFO - 2017-01-16 09:24:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:51 --> Output Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:51 --> Security Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:51 --> Loader Class Initialized
DEBUG - 2017-01-16 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Input Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:51 --> Language Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:51 --> Total execution time: 0.1116
INFO - 2017-01-16 09:24:51 --> Loader Class Initialized
INFO - 2017-01-16 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:51 --> Controller Class Initialized
INFO - 2017-01-16 09:24:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:24:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:24:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:24:51 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 301
ERROR - 2017-01-16 09:24:51 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `result` SET `total_time` = 0, `end_time` = 1484538891, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-16 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:51 --> Controller Class Initialized
INFO - 2017-01-16 09:24:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:51 --> Total execution time: 0.1988
INFO - 2017-01-16 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:51 --> Controller Class Initialized
INFO - 2017-01-16 09:24:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:24:51 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 301
ERROR - 2017-01-16 09:24:51 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `result` SET `total_time` = 0, `end_time` = 1484538891, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-16 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:51 --> Controller Class Initialized
INFO - 2017-01-16 09:24:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:24:51 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 301
ERROR - 2017-01-16 09:24:51 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `result` SET `total_time` = 0, `end_time` = 1484538891, `score_obtained` = 0, `percentage_obtained` = NAN, `manual_valuation` = 0, `result_status` = 'Abaikan'
WHERE `rid` IS NULL
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-16 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:24:51 --> Controller Class Initialized
INFO - 2017-01-16 09:24:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Model Class Initialized
INFO - 2017-01-16 09:24:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:24:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:24:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-16 09:24:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:24:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:24:51 --> Total execution time: 0.2738
INFO - 2017-01-16 09:26:13 --> Config Class Initialized
INFO - 2017-01-16 09:26:13 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:13 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:13 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:13 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:13 --> No URI present. Default controller set.
INFO - 2017-01-16 09:26:13 --> Router Class Initialized
INFO - 2017-01-16 09:26:13 --> Output Class Initialized
INFO - 2017-01-16 09:26:13 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:13 --> Input Class Initialized
INFO - 2017-01-16 09:26:13 --> Language Class Initialized
INFO - 2017-01-16 09:26:13 --> Loader Class Initialized
INFO - 2017-01-16 09:26:13 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:13 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:13 --> Controller Class Initialized
INFO - 2017-01-16 09:26:13 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:13 --> Model Class Initialized
INFO - 2017-01-16 09:26:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:13 --> Config Class Initialized
INFO - 2017-01-16 09:26:13 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:13 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:13 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:13 --> URI Class Initialized
INFO - 2017-01-16 09:26:13 --> Router Class Initialized
INFO - 2017-01-16 09:26:13 --> Output Class Initialized
INFO - 2017-01-16 09:26:13 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:13 --> Input Class Initialized
INFO - 2017-01-16 09:26:13 --> Language Class Initialized
INFO - 2017-01-16 09:26:13 --> Loader Class Initialized
INFO - 2017-01-16 09:26:13 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:13 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:13 --> Controller Class Initialized
INFO - 2017-01-16 09:26:13 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:13 --> Model Class Initialized
INFO - 2017-01-16 09:26:13 --> Model Class Initialized
INFO - 2017-01-16 09:26:13 --> Model Class Initialized
INFO - 2017-01-16 09:26:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-16 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:13 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:13 --> Total execution time: 0.0656
INFO - 2017-01-16 09:26:16 --> Config Class Initialized
INFO - 2017-01-16 09:26:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:16 --> URI Class Initialized
INFO - 2017-01-16 09:26:16 --> Router Class Initialized
INFO - 2017-01-16 09:26:16 --> Output Class Initialized
INFO - 2017-01-16 09:26:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:16 --> Input Class Initialized
INFO - 2017-01-16 09:26:16 --> Language Class Initialized
INFO - 2017-01-16 09:26:16 --> Loader Class Initialized
INFO - 2017-01-16 09:26:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:16 --> Controller Class Initialized
INFO - 2017-01-16 09:26:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:16 --> Model Class Initialized
INFO - 2017-01-16 09:26:16 --> Model Class Initialized
INFO - 2017-01-16 09:26:16 --> Model Class Initialized
INFO - 2017-01-16 09:26:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpu.php
INFO - 2017-01-16 09:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:16 --> Total execution time: 0.0720
INFO - 2017-01-16 09:26:19 --> Config Class Initialized
INFO - 2017-01-16 09:26:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:19 --> URI Class Initialized
INFO - 2017-01-16 09:26:19 --> Router Class Initialized
INFO - 2017-01-16 09:26:19 --> Output Class Initialized
INFO - 2017-01-16 09:26:19 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:19 --> Input Class Initialized
INFO - 2017-01-16 09:26:19 --> Language Class Initialized
INFO - 2017-01-16 09:26:19 --> Loader Class Initialized
INFO - 2017-01-16 09:26:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:19 --> Controller Class Initialized
INFO - 2017-01-16 09:26:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:19 --> Config Class Initialized
INFO - 2017-01-16 09:26:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:19 --> URI Class Initialized
INFO - 2017-01-16 09:26:19 --> Router Class Initialized
INFO - 2017-01-16 09:26:19 --> Output Class Initialized
INFO - 2017-01-16 09:26:19 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:19 --> Input Class Initialized
INFO - 2017-01-16 09:26:19 --> Language Class Initialized
INFO - 2017-01-16 09:26:19 --> Loader Class Initialized
INFO - 2017-01-16 09:26:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:19 --> Controller Class Initialized
INFO - 2017-01-16 09:26:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpu_attempt.php
INFO - 2017-01-16 09:26:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:19 --> Total execution time: 0.0683
INFO - 2017-01-16 09:26:19 --> Config Class Initialized
INFO - 2017-01-16 09:26:19 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:19 --> Config Class Initialized
DEBUG - 2017-01-16 09:26:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:19 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:19 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:19 --> Router Class Initialized
INFO - 2017-01-16 09:26:19 --> URI Class Initialized
INFO - 2017-01-16 09:26:19 --> Output Class Initialized
INFO - 2017-01-16 09:26:19 --> Router Class Initialized
INFO - 2017-01-16 09:26:19 --> Security Class Initialized
INFO - 2017-01-16 09:26:19 --> Output Class Initialized
DEBUG - 2017-01-16 09:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:19 --> Security Class Initialized
INFO - 2017-01-16 09:26:19 --> Input Class Initialized
INFO - 2017-01-16 09:26:19 --> Language Class Initialized
DEBUG - 2017-01-16 09:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:19 --> Input Class Initialized
INFO - 2017-01-16 09:26:19 --> Language Class Initialized
INFO - 2017-01-16 09:26:19 --> Loader Class Initialized
INFO - 2017-01-16 09:26:19 --> Loader Class Initialized
INFO - 2017-01-16 09:26:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:19 --> Controller Class Initialized
INFO - 2017-01-16 09:26:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:19 --> Total execution time: 0.0826
INFO - 2017-01-16 09:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:19 --> Controller Class Initialized
INFO - 2017-01-16 09:26:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Model Class Initialized
INFO - 2017-01-16 09:26:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:26:19 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:26:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:26:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:19 --> Total execution time: 0.1137
INFO - 2017-01-16 09:26:21 --> Config Class Initialized
INFO - 2017-01-16 09:26:21 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:21 --> Config Class Initialized
INFO - 2017-01-16 09:26:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:21 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:21 --> URI Class Initialized
INFO - 2017-01-16 09:26:21 --> URI Class Initialized
INFO - 2017-01-16 09:26:21 --> Router Class Initialized
INFO - 2017-01-16 09:26:21 --> Router Class Initialized
INFO - 2017-01-16 09:26:21 --> Output Class Initialized
INFO - 2017-01-16 09:26:21 --> Output Class Initialized
INFO - 2017-01-16 09:26:21 --> Security Class Initialized
INFO - 2017-01-16 09:26:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:21 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:21 --> Input Class Initialized
INFO - 2017-01-16 09:26:21 --> Language Class Initialized
INFO - 2017-01-16 09:26:21 --> Language Class Initialized
INFO - 2017-01-16 09:26:21 --> Loader Class Initialized
INFO - 2017-01-16 09:26:21 --> Loader Class Initialized
INFO - 2017-01-16 09:26:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:21 --> Controller Class Initialized
INFO - 2017-01-16 09:26:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:21 --> Model Class Initialized
INFO - 2017-01-16 09:26:21 --> Model Class Initialized
INFO - 2017-01-16 09:26:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:21 --> Total execution time: 0.0742
INFO - 2017-01-16 09:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:21 --> Controller Class Initialized
INFO - 2017-01-16 09:26:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:21 --> Model Class Initialized
INFO - 2017-01-16 09:26:21 --> Model Class Initialized
INFO - 2017-01-16 09:26:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:21 --> Total execution time: 0.1059
INFO - 2017-01-16 09:26:23 --> Config Class Initialized
INFO - 2017-01-16 09:26:23 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:23 --> Config Class Initialized
INFO - 2017-01-16 09:26:23 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:23 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:23 --> Router Class Initialized
INFO - 2017-01-16 09:26:23 --> URI Class Initialized
INFO - 2017-01-16 09:26:23 --> Output Class Initialized
INFO - 2017-01-16 09:26:23 --> Router Class Initialized
INFO - 2017-01-16 09:26:23 --> Security Class Initialized
INFO - 2017-01-16 09:26:23 --> Output Class Initialized
DEBUG - 2017-01-16 09:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:23 --> Input Class Initialized
INFO - 2017-01-16 09:26:23 --> Security Class Initialized
INFO - 2017-01-16 09:26:23 --> Language Class Initialized
DEBUG - 2017-01-16 09:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:23 --> Input Class Initialized
INFO - 2017-01-16 09:26:23 --> Language Class Initialized
INFO - 2017-01-16 09:26:23 --> Loader Class Initialized
INFO - 2017-01-16 09:26:23 --> Loader Class Initialized
INFO - 2017-01-16 09:26:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:23 --> Controller Class Initialized
INFO - 2017-01-16 09:26:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:23 --> Model Class Initialized
INFO - 2017-01-16 09:26:23 --> Model Class Initialized
INFO - 2017-01-16 09:26:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:23 --> Total execution time: 0.1006
INFO - 2017-01-16 09:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:23 --> Controller Class Initialized
INFO - 2017-01-16 09:26:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:23 --> Model Class Initialized
INFO - 2017-01-16 09:26:23 --> Model Class Initialized
INFO - 2017-01-16 09:26:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:23 --> Total execution time: 0.1303
INFO - 2017-01-16 09:26:24 --> Config Class Initialized
INFO - 2017-01-16 09:26:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:24 --> URI Class Initialized
INFO - 2017-01-16 09:26:24 --> Router Class Initialized
INFO - 2017-01-16 09:26:24 --> Output Class Initialized
INFO - 2017-01-16 09:26:24 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:24 --> Input Class Initialized
INFO - 2017-01-16 09:26:24 --> Language Class Initialized
INFO - 2017-01-16 09:26:24 --> Loader Class Initialized
INFO - 2017-01-16 09:26:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:24 --> Controller Class Initialized
INFO - 2017-01-16 09:26:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:24 --> Model Class Initialized
INFO - 2017-01-16 09:26:24 --> Model Class Initialized
INFO - 2017-01-16 09:26:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:24 --> Total execution time: 0.0736
INFO - 2017-01-16 09:26:25 --> Config Class Initialized
INFO - 2017-01-16 09:26:25 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:25 --> Config Class Initialized
INFO - 2017-01-16 09:26:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:25 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:25 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:25 --> URI Class Initialized
INFO - 2017-01-16 09:26:25 --> URI Class Initialized
INFO - 2017-01-16 09:26:25 --> Router Class Initialized
INFO - 2017-01-16 09:26:25 --> Router Class Initialized
INFO - 2017-01-16 09:26:25 --> Output Class Initialized
INFO - 2017-01-16 09:26:25 --> Output Class Initialized
INFO - 2017-01-16 09:26:25 --> Security Class Initialized
INFO - 2017-01-16 09:26:25 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:25 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:25 --> Language Class Initialized
INFO - 2017-01-16 09:26:25 --> Input Class Initialized
INFO - 2017-01-16 09:26:25 --> Language Class Initialized
INFO - 2017-01-16 09:26:25 --> Loader Class Initialized
INFO - 2017-01-16 09:26:25 --> Loader Class Initialized
INFO - 2017-01-16 09:26:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:25 --> Controller Class Initialized
INFO - 2017-01-16 09:26:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:25 --> Model Class Initialized
INFO - 2017-01-16 09:26:25 --> Model Class Initialized
INFO - 2017-01-16 09:26:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:25 --> Total execution time: 0.0686
INFO - 2017-01-16 09:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:25 --> Controller Class Initialized
INFO - 2017-01-16 09:26:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:25 --> Model Class Initialized
INFO - 2017-01-16 09:26:25 --> Model Class Initialized
INFO - 2017-01-16 09:26:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:25 --> Total execution time: 0.1146
INFO - 2017-01-16 09:26:26 --> Config Class Initialized
INFO - 2017-01-16 09:26:26 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:26 --> Config Class Initialized
INFO - 2017-01-16 09:26:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:26 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:26 --> Router Class Initialized
INFO - 2017-01-16 09:26:26 --> URI Class Initialized
INFO - 2017-01-16 09:26:26 --> Output Class Initialized
INFO - 2017-01-16 09:26:26 --> Router Class Initialized
INFO - 2017-01-16 09:26:26 --> Output Class Initialized
INFO - 2017-01-16 09:26:26 --> Security Class Initialized
INFO - 2017-01-16 09:26:26 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:26 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:26 --> Input Class Initialized
INFO - 2017-01-16 09:26:26 --> Language Class Initialized
INFO - 2017-01-16 09:26:26 --> Language Class Initialized
INFO - 2017-01-16 09:26:26 --> Loader Class Initialized
INFO - 2017-01-16 09:26:26 --> Loader Class Initialized
INFO - 2017-01-16 09:26:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:26 --> Controller Class Initialized
INFO - 2017-01-16 09:26:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:27 --> Model Class Initialized
INFO - 2017-01-16 09:26:27 --> Model Class Initialized
INFO - 2017-01-16 09:26:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:27 --> Total execution time: 0.1058
INFO - 2017-01-16 09:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:27 --> Controller Class Initialized
INFO - 2017-01-16 09:26:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:27 --> Model Class Initialized
INFO - 2017-01-16 09:26:27 --> Model Class Initialized
INFO - 2017-01-16 09:26:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:27 --> Total execution time: 0.1315
INFO - 2017-01-16 09:26:29 --> Config Class Initialized
INFO - 2017-01-16 09:26:29 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:29 --> Config Class Initialized
INFO - 2017-01-16 09:26:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:29 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:29 --> URI Class Initialized
INFO - 2017-01-16 09:26:29 --> URI Class Initialized
INFO - 2017-01-16 09:26:29 --> Router Class Initialized
INFO - 2017-01-16 09:26:29 --> Router Class Initialized
INFO - 2017-01-16 09:26:29 --> Output Class Initialized
INFO - 2017-01-16 09:26:29 --> Config Class Initialized
INFO - 2017-01-16 09:26:29 --> Output Class Initialized
INFO - 2017-01-16 09:26:29 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:29 --> Security Class Initialized
INFO - 2017-01-16 09:26:29 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:29 --> Input Class Initialized
INFO - 2017-01-16 09:26:29 --> Language Class Initialized
DEBUG - 2017-01-16 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:29 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:29 --> Language Class Initialized
INFO - 2017-01-16 09:26:29 --> URI Class Initialized
INFO - 2017-01-16 09:26:29 --> Router Class Initialized
INFO - 2017-01-16 09:26:29 --> Loader Class Initialized
INFO - 2017-01-16 09:26:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:29 --> Loader Class Initialized
INFO - 2017-01-16 09:26:29 --> Output Class Initialized
INFO - 2017-01-16 09:26:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:29 --> Security Class Initialized
INFO - 2017-01-16 09:26:29 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:29 --> Input Class Initialized
INFO - 2017-01-16 09:26:29 --> Language Class Initialized
INFO - 2017-01-16 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:29 --> Controller Class Initialized
INFO - 2017-01-16 09:26:29 --> Loader Class Initialized
INFO - 2017-01-16 09:26:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:29 --> Total execution time: 0.0979
INFO - 2017-01-16 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:29 --> Controller Class Initialized
INFO - 2017-01-16 09:26:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:29 --> Total execution time: 0.1542
INFO - 2017-01-16 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:29 --> Controller Class Initialized
INFO - 2017-01-16 09:26:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:29 --> Config Class Initialized
INFO - 2017-01-16 09:26:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:29 --> URI Class Initialized
INFO - 2017-01-16 09:26:29 --> Router Class Initialized
INFO - 2017-01-16 09:26:29 --> Output Class Initialized
INFO - 2017-01-16 09:26:29 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:29 --> Input Class Initialized
INFO - 2017-01-16 09:26:29 --> Language Class Initialized
INFO - 2017-01-16 09:26:29 --> Loader Class Initialized
INFO - 2017-01-16 09:26:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:29 --> Controller Class Initialized
INFO - 2017-01-16 09:26:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Model Class Initialized
INFO - 2017-01-16 09:26:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpa.php
INFO - 2017-01-16 09:26:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:29 --> Total execution time: 0.0669
INFO - 2017-01-16 09:26:34 --> Config Class Initialized
INFO - 2017-01-16 09:26:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:34 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:34 --> URI Class Initialized
INFO - 2017-01-16 09:26:34 --> Router Class Initialized
INFO - 2017-01-16 09:26:34 --> Output Class Initialized
INFO - 2017-01-16 09:26:34 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:34 --> Input Class Initialized
INFO - 2017-01-16 09:26:34 --> Language Class Initialized
INFO - 2017-01-16 09:26:34 --> Loader Class Initialized
INFO - 2017-01-16 09:26:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:34 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:34 --> Controller Class Initialized
INFO - 2017-01-16 09:26:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:34 --> Model Class Initialized
INFO - 2017-01-16 09:26:34 --> Model Class Initialized
INFO - 2017-01-16 09:26:34 --> Model Class Initialized
INFO - 2017-01-16 09:26:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:34 --> Config Class Initialized
INFO - 2017-01-16 09:26:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:35 --> URI Class Initialized
INFO - 2017-01-16 09:26:35 --> Router Class Initialized
INFO - 2017-01-16 09:26:35 --> Output Class Initialized
INFO - 2017-01-16 09:26:35 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:35 --> Input Class Initialized
INFO - 2017-01-16 09:26:35 --> Language Class Initialized
INFO - 2017-01-16 09:26:35 --> Loader Class Initialized
INFO - 2017-01-16 09:26:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:35 --> Controller Class Initialized
INFO - 2017-01-16 09:26:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_tpa_attempt.php
INFO - 2017-01-16 09:26:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:35 --> Total execution time: 0.0720
INFO - 2017-01-16 09:26:35 --> Config Class Initialized
INFO - 2017-01-16 09:26:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:35 --> Config Class Initialized
INFO - 2017-01-16 09:26:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:35 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:35 --> URI Class Initialized
INFO - 2017-01-16 09:26:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:35 --> URI Class Initialized
INFO - 2017-01-16 09:26:35 --> Router Class Initialized
INFO - 2017-01-16 09:26:35 --> Router Class Initialized
INFO - 2017-01-16 09:26:35 --> Output Class Initialized
INFO - 2017-01-16 09:26:35 --> Output Class Initialized
INFO - 2017-01-16 09:26:35 --> Security Class Initialized
INFO - 2017-01-16 09:26:35 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:35 --> Input Class Initialized
INFO - 2017-01-16 09:26:35 --> Language Class Initialized
DEBUG - 2017-01-16 09:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:35 --> Input Class Initialized
INFO - 2017-01-16 09:26:35 --> Language Class Initialized
INFO - 2017-01-16 09:26:35 --> Loader Class Initialized
INFO - 2017-01-16 09:26:35 --> Loader Class Initialized
INFO - 2017-01-16 09:26:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:35 --> Controller Class Initialized
INFO - 2017-01-16 09:26:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:35 --> Total execution time: 0.0927
INFO - 2017-01-16 09:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:35 --> Controller Class Initialized
INFO - 2017-01-16 09:26:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Model Class Initialized
INFO - 2017-01-16 09:26:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:26:35 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:26:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:35 --> Total execution time: 0.1319
INFO - 2017-01-16 09:26:37 --> Config Class Initialized
INFO - 2017-01-16 09:26:37 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:37 --> Config Class Initialized
INFO - 2017-01-16 09:26:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:37 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:37 --> URI Class Initialized
INFO - 2017-01-16 09:26:37 --> Router Class Initialized
INFO - 2017-01-16 09:26:37 --> Router Class Initialized
INFO - 2017-01-16 09:26:37 --> Output Class Initialized
INFO - 2017-01-16 09:26:37 --> Output Class Initialized
INFO - 2017-01-16 09:26:37 --> Security Class Initialized
INFO - 2017-01-16 09:26:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:37 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:37 --> Input Class Initialized
INFO - 2017-01-16 09:26:37 --> Language Class Initialized
INFO - 2017-01-16 09:26:37 --> Language Class Initialized
INFO - 2017-01-16 09:26:37 --> Loader Class Initialized
INFO - 2017-01-16 09:26:37 --> Loader Class Initialized
INFO - 2017-01-16 09:26:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:37 --> Controller Class Initialized
INFO - 2017-01-16 09:26:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:37 --> Model Class Initialized
INFO - 2017-01-16 09:26:37 --> Model Class Initialized
INFO - 2017-01-16 09:26:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:37 --> Total execution time: 0.0696
INFO - 2017-01-16 09:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:37 --> Controller Class Initialized
INFO - 2017-01-16 09:26:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:37 --> Model Class Initialized
INFO - 2017-01-16 09:26:37 --> Model Class Initialized
INFO - 2017-01-16 09:26:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:37 --> Total execution time: 0.1012
INFO - 2017-01-16 09:26:41 --> Config Class Initialized
INFO - 2017-01-16 09:26:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:41 --> Config Class Initialized
INFO - 2017-01-16 09:26:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:41 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:41 --> URI Class Initialized
INFO - 2017-01-16 09:26:41 --> URI Class Initialized
INFO - 2017-01-16 09:26:41 --> Router Class Initialized
INFO - 2017-01-16 09:26:41 --> Router Class Initialized
INFO - 2017-01-16 09:26:41 --> Output Class Initialized
INFO - 2017-01-16 09:26:41 --> Output Class Initialized
INFO - 2017-01-16 09:26:41 --> Security Class Initialized
INFO - 2017-01-16 09:26:41 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:41 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:41 --> Input Class Initialized
INFO - 2017-01-16 09:26:41 --> Language Class Initialized
INFO - 2017-01-16 09:26:41 --> Language Class Initialized
INFO - 2017-01-16 09:26:41 --> Loader Class Initialized
INFO - 2017-01-16 09:26:41 --> Loader Class Initialized
INFO - 2017-01-16 09:26:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:41 --> Controller Class Initialized
INFO - 2017-01-16 09:26:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:41 --> Model Class Initialized
INFO - 2017-01-16 09:26:41 --> Model Class Initialized
INFO - 2017-01-16 09:26:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:41 --> Total execution time: 0.0973
INFO - 2017-01-16 09:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:41 --> Controller Class Initialized
INFO - 2017-01-16 09:26:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:41 --> Model Class Initialized
INFO - 2017-01-16 09:26:41 --> Model Class Initialized
INFO - 2017-01-16 09:26:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:41 --> Total execution time: 0.1251
INFO - 2017-01-16 09:26:42 --> Config Class Initialized
INFO - 2017-01-16 09:26:42 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:42 --> Config Class Initialized
INFO - 2017-01-16 09:26:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:42 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:42 --> URI Class Initialized
INFO - 2017-01-16 09:26:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:42 --> URI Class Initialized
INFO - 2017-01-16 09:26:42 --> Router Class Initialized
INFO - 2017-01-16 09:26:42 --> Router Class Initialized
INFO - 2017-01-16 09:26:42 --> Output Class Initialized
INFO - 2017-01-16 09:26:42 --> Output Class Initialized
INFO - 2017-01-16 09:26:42 --> Security Class Initialized
INFO - 2017-01-16 09:26:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:42 --> Input Class Initialized
INFO - 2017-01-16 09:26:42 --> Input Class Initialized
INFO - 2017-01-16 09:26:42 --> Language Class Initialized
INFO - 2017-01-16 09:26:42 --> Language Class Initialized
INFO - 2017-01-16 09:26:42 --> Loader Class Initialized
INFO - 2017-01-16 09:26:42 --> Loader Class Initialized
INFO - 2017-01-16 09:26:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:42 --> Controller Class Initialized
INFO - 2017-01-16 09:26:43 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:43 --> Model Class Initialized
INFO - 2017-01-16 09:26:43 --> Model Class Initialized
INFO - 2017-01-16 09:26:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:43 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:43 --> Total execution time: 0.0696
INFO - 2017-01-16 09:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:43 --> Controller Class Initialized
INFO - 2017-01-16 09:26:43 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:43 --> Model Class Initialized
INFO - 2017-01-16 09:26:43 --> Model Class Initialized
INFO - 2017-01-16 09:26:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:43 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:43 --> Total execution time: 0.1176
INFO - 2017-01-16 09:26:44 --> Config Class Initialized
INFO - 2017-01-16 09:26:44 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:44 --> Config Class Initialized
INFO - 2017-01-16 09:26:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:44 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:44 --> URI Class Initialized
INFO - 2017-01-16 09:26:44 --> URI Class Initialized
INFO - 2017-01-16 09:26:44 --> Router Class Initialized
INFO - 2017-01-16 09:26:44 --> Output Class Initialized
INFO - 2017-01-16 09:26:44 --> Router Class Initialized
INFO - 2017-01-16 09:26:44 --> Security Class Initialized
INFO - 2017-01-16 09:26:44 --> Output Class Initialized
DEBUG - 2017-01-16 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:44 --> Input Class Initialized
INFO - 2017-01-16 09:26:44 --> Language Class Initialized
INFO - 2017-01-16 09:26:44 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:44 --> Input Class Initialized
INFO - 2017-01-16 09:26:44 --> Language Class Initialized
INFO - 2017-01-16 09:26:44 --> Loader Class Initialized
INFO - 2017-01-16 09:26:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:44 --> Loader Class Initialized
INFO - 2017-01-16 09:26:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:44 --> Controller Class Initialized
INFO - 2017-01-16 09:26:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:44 --> Model Class Initialized
INFO - 2017-01-16 09:26:44 --> Model Class Initialized
INFO - 2017-01-16 09:26:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:44 --> Total execution time: 0.0707
INFO - 2017-01-16 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:44 --> Controller Class Initialized
INFO - 2017-01-16 09:26:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:44 --> Model Class Initialized
INFO - 2017-01-16 09:26:44 --> Model Class Initialized
INFO - 2017-01-16 09:26:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:44 --> Total execution time: 0.1276
INFO - 2017-01-16 09:26:46 --> Config Class Initialized
INFO - 2017-01-16 09:26:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:46 --> Config Class Initialized
INFO - 2017-01-16 09:26:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:46 --> Config Class Initialized
DEBUG - 2017-01-16 09:26:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:46 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:46 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:46 --> Router Class Initialized
INFO - 2017-01-16 09:26:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:46 --> URI Class Initialized
INFO - 2017-01-16 09:26:46 --> URI Class Initialized
INFO - 2017-01-16 09:26:46 --> Router Class Initialized
INFO - 2017-01-16 09:26:46 --> Output Class Initialized
INFO - 2017-01-16 09:26:46 --> Router Class Initialized
INFO - 2017-01-16 09:26:46 --> Security Class Initialized
INFO - 2017-01-16 09:26:46 --> Output Class Initialized
INFO - 2017-01-16 09:26:46 --> Output Class Initialized
INFO - 2017-01-16 09:26:46 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:46 --> Security Class Initialized
INFO - 2017-01-16 09:26:46 --> Input Class Initialized
INFO - 2017-01-16 09:26:46 --> Language Class Initialized
DEBUG - 2017-01-16 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:46 --> Input Class Initialized
INFO - 2017-01-16 09:26:46 --> Input Class Initialized
INFO - 2017-01-16 09:26:46 --> Language Class Initialized
INFO - 2017-01-16 09:26:46 --> Language Class Initialized
INFO - 2017-01-16 09:26:46 --> Loader Class Initialized
INFO - 2017-01-16 09:26:46 --> Loader Class Initialized
INFO - 2017-01-16 09:26:46 --> Loader Class Initialized
INFO - 2017-01-16 09:26:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:46 --> Controller Class Initialized
INFO - 2017-01-16 09:26:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:46 --> Total execution time: 0.1262
INFO - 2017-01-16 09:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:46 --> Controller Class Initialized
INFO - 2017-01-16 09:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:46 --> Controller Class Initialized
INFO - 2017-01-16 09:26:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Model Class Initialized
INFO - 2017-01-16 09:26:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:46 --> Total execution time: 0.1578
INFO - 2017-01-16 09:26:47 --> Config Class Initialized
INFO - 2017-01-16 09:26:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:47 --> URI Class Initialized
INFO - 2017-01-16 09:26:47 --> Router Class Initialized
INFO - 2017-01-16 09:26:47 --> Output Class Initialized
INFO - 2017-01-16 09:26:47 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:47 --> Input Class Initialized
INFO - 2017-01-16 09:26:47 --> Language Class Initialized
INFO - 2017-01-16 09:26:47 --> Loader Class Initialized
INFO - 2017-01-16 09:26:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:47 --> Controller Class Initialized
INFO - 2017-01-16 09:26:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:47 --> Model Class Initialized
INFO - 2017-01-16 09:26:47 --> Model Class Initialized
INFO - 2017-01-16 09:26:47 --> Model Class Initialized
INFO - 2017-01-16 09:26:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-16 09:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:47 --> Total execution time: 0.0742
INFO - 2017-01-16 09:26:50 --> Config Class Initialized
INFO - 2017-01-16 09:26:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:50 --> URI Class Initialized
INFO - 2017-01-16 09:26:50 --> Router Class Initialized
INFO - 2017-01-16 09:26:50 --> Output Class Initialized
INFO - 2017-01-16 09:26:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:50 --> Input Class Initialized
INFO - 2017-01-16 09:26:50 --> Language Class Initialized
INFO - 2017-01-16 09:26:50 --> Loader Class Initialized
INFO - 2017-01-16 09:26:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:50 --> Controller Class Initialized
INFO - 2017-01-16 09:26:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:50 --> Config Class Initialized
INFO - 2017-01-16 09:26:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:50 --> URI Class Initialized
INFO - 2017-01-16 09:26:50 --> Router Class Initialized
INFO - 2017-01-16 09:26:50 --> Output Class Initialized
INFO - 2017-01-16 09:26:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:50 --> Input Class Initialized
INFO - 2017-01-16 09:26:50 --> Language Class Initialized
INFO - 2017-01-16 09:26:50 --> Loader Class Initialized
INFO - 2017-01-16 09:26:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:50 --> Controller Class Initialized
INFO - 2017-01-16 09:26:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:26:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-16 09:26:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:26:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:50 --> Total execution time: 0.0727
INFO - 2017-01-16 09:26:50 --> Config Class Initialized
INFO - 2017-01-16 09:26:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:50 --> Config Class Initialized
INFO - 2017-01-16 09:26:50 --> URI Class Initialized
INFO - 2017-01-16 09:26:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:26:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:50 --> Output Class Initialized
INFO - 2017-01-16 09:26:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:50 --> URI Class Initialized
INFO - 2017-01-16 09:26:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:50 --> Input Class Initialized
INFO - 2017-01-16 09:26:50 --> Router Class Initialized
INFO - 2017-01-16 09:26:50 --> Language Class Initialized
INFO - 2017-01-16 09:26:50 --> Output Class Initialized
INFO - 2017-01-16 09:26:50 --> Security Class Initialized
INFO - 2017-01-16 09:26:50 --> Loader Class Initialized
DEBUG - 2017-01-16 09:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:50 --> Input Class Initialized
INFO - 2017-01-16 09:26:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:50 --> Language Class Initialized
INFO - 2017-01-16 09:26:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:50 --> Loader Class Initialized
INFO - 2017-01-16 09:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:50 --> Controller Class Initialized
INFO - 2017-01-16 09:26:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:50 --> Total execution time: 0.0800
INFO - 2017-01-16 09:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:50 --> Controller Class Initialized
INFO - 2017-01-16 09:26:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Model Class Initialized
INFO - 2017-01-16 09:26:50 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:26:50 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:26:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:50 --> Total execution time: 0.1093
INFO - 2017-01-16 09:26:52 --> Config Class Initialized
INFO - 2017-01-16 09:26:52 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:52 --> Config Class Initialized
INFO - 2017-01-16 09:26:52 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:52 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:52 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:52 --> URI Class Initialized
INFO - 2017-01-16 09:26:52 --> URI Class Initialized
INFO - 2017-01-16 09:26:52 --> Router Class Initialized
INFO - 2017-01-16 09:26:52 --> Router Class Initialized
INFO - 2017-01-16 09:26:52 --> Output Class Initialized
INFO - 2017-01-16 09:26:52 --> Output Class Initialized
INFO - 2017-01-16 09:26:52 --> Security Class Initialized
INFO - 2017-01-16 09:26:52 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:52 --> Input Class Initialized
INFO - 2017-01-16 09:26:52 --> Input Class Initialized
INFO - 2017-01-16 09:26:52 --> Language Class Initialized
INFO - 2017-01-16 09:26:52 --> Language Class Initialized
INFO - 2017-01-16 09:26:52 --> Loader Class Initialized
INFO - 2017-01-16 09:26:52 --> Loader Class Initialized
INFO - 2017-01-16 09:26:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:52 --> Controller Class Initialized
INFO - 2017-01-16 09:26:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:52 --> Model Class Initialized
INFO - 2017-01-16 09:26:52 --> Model Class Initialized
INFO - 2017-01-16 09:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:52 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:52 --> Total execution time: 0.0709
INFO - 2017-01-16 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:52 --> Controller Class Initialized
INFO - 2017-01-16 09:26:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:52 --> Model Class Initialized
INFO - 2017-01-16 09:26:52 --> Model Class Initialized
INFO - 2017-01-16 09:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:52 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:52 --> Total execution time: 0.1013
INFO - 2017-01-16 09:26:54 --> Config Class Initialized
INFO - 2017-01-16 09:26:54 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:54 --> Config Class Initialized
INFO - 2017-01-16 09:26:54 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:54 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:54 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:54 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:54 --> Router Class Initialized
INFO - 2017-01-16 09:26:54 --> URI Class Initialized
INFO - 2017-01-16 09:26:54 --> Output Class Initialized
INFO - 2017-01-16 09:26:54 --> Router Class Initialized
INFO - 2017-01-16 09:26:54 --> Security Class Initialized
INFO - 2017-01-16 09:26:54 --> Output Class Initialized
DEBUG - 2017-01-16 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:54 --> Input Class Initialized
INFO - 2017-01-16 09:26:54 --> Language Class Initialized
INFO - 2017-01-16 09:26:54 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:54 --> Loader Class Initialized
INFO - 2017-01-16 09:26:54 --> Input Class Initialized
INFO - 2017-01-16 09:26:54 --> Language Class Initialized
INFO - 2017-01-16 09:26:54 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:54 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:54 --> Loader Class Initialized
INFO - 2017-01-16 09:26:54 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:54 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:54 --> Controller Class Initialized
INFO - 2017-01-16 09:26:54 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:54 --> Model Class Initialized
INFO - 2017-01-16 09:26:54 --> Model Class Initialized
INFO - 2017-01-16 09:26:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:54 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:54 --> Total execution time: 0.0751
INFO - 2017-01-16 09:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:54 --> Controller Class Initialized
INFO - 2017-01-16 09:26:54 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:54 --> Model Class Initialized
INFO - 2017-01-16 09:26:54 --> Model Class Initialized
INFO - 2017-01-16 09:26:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:54 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:54 --> Total execution time: 0.1145
INFO - 2017-01-16 09:26:55 --> Config Class Initialized
INFO - 2017-01-16 09:26:55 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:55 --> Config Class Initialized
INFO - 2017-01-16 09:26:55 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:55 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:55 --> URI Class Initialized
INFO - 2017-01-16 09:26:55 --> Router Class Initialized
INFO - 2017-01-16 09:26:55 --> Router Class Initialized
INFO - 2017-01-16 09:26:55 --> Output Class Initialized
INFO - 2017-01-16 09:26:55 --> Output Class Initialized
INFO - 2017-01-16 09:26:55 --> Security Class Initialized
INFO - 2017-01-16 09:26:55 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:55 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:55 --> Input Class Initialized
INFO - 2017-01-16 09:26:55 --> Language Class Initialized
INFO - 2017-01-16 09:26:55 --> Language Class Initialized
INFO - 2017-01-16 09:26:55 --> Loader Class Initialized
INFO - 2017-01-16 09:26:55 --> Loader Class Initialized
INFO - 2017-01-16 09:26:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:55 --> Controller Class Initialized
INFO - 2017-01-16 09:26:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:55 --> Model Class Initialized
INFO - 2017-01-16 09:26:55 --> Model Class Initialized
INFO - 2017-01-16 09:26:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:56 --> Total execution time: 0.0782
INFO - 2017-01-16 09:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:56 --> Controller Class Initialized
INFO - 2017-01-16 09:26:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:56 --> Model Class Initialized
INFO - 2017-01-16 09:26:56 --> Model Class Initialized
INFO - 2017-01-16 09:26:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:56 --> Total execution time: 0.1184
INFO - 2017-01-16 09:26:57 --> Config Class Initialized
INFO - 2017-01-16 09:26:57 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:57 --> Config Class Initialized
INFO - 2017-01-16 09:26:57 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:57 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:57 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:26:57 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:57 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:57 --> URI Class Initialized
INFO - 2017-01-16 09:26:57 --> URI Class Initialized
INFO - 2017-01-16 09:26:57 --> Router Class Initialized
INFO - 2017-01-16 09:26:57 --> Router Class Initialized
INFO - 2017-01-16 09:26:57 --> Output Class Initialized
INFO - 2017-01-16 09:26:57 --> Output Class Initialized
INFO - 2017-01-16 09:26:57 --> Security Class Initialized
INFO - 2017-01-16 09:26:57 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:57 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:57 --> Input Class Initialized
INFO - 2017-01-16 09:26:57 --> Language Class Initialized
INFO - 2017-01-16 09:26:57 --> Language Class Initialized
INFO - 2017-01-16 09:26:57 --> Loader Class Initialized
INFO - 2017-01-16 09:26:57 --> Loader Class Initialized
INFO - 2017-01-16 09:26:57 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:57 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:57 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:57 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:57 --> Controller Class Initialized
INFO - 2017-01-16 09:26:57 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:57 --> Model Class Initialized
INFO - 2017-01-16 09:26:57 --> Model Class Initialized
INFO - 2017-01-16 09:26:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:57 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:57 --> Total execution time: 0.0769
INFO - 2017-01-16 09:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:57 --> Controller Class Initialized
INFO - 2017-01-16 09:26:57 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:57 --> Model Class Initialized
INFO - 2017-01-16 09:26:57 --> Model Class Initialized
INFO - 2017-01-16 09:26:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:57 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:57 --> Total execution time: 0.1287
INFO - 2017-01-16 09:26:58 --> Config Class Initialized
INFO - 2017-01-16 09:26:58 --> Hooks Class Initialized
INFO - 2017-01-16 09:26:58 --> Config Class Initialized
INFO - 2017-01-16 09:26:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:26:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:58 --> URI Class Initialized
DEBUG - 2017-01-16 09:26:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:26:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:26:58 --> URI Class Initialized
INFO - 2017-01-16 09:26:58 --> Router Class Initialized
INFO - 2017-01-16 09:26:58 --> Router Class Initialized
INFO - 2017-01-16 09:26:58 --> Output Class Initialized
INFO - 2017-01-16 09:26:58 --> Output Class Initialized
INFO - 2017-01-16 09:26:58 --> Security Class Initialized
INFO - 2017-01-16 09:26:58 --> Security Class Initialized
DEBUG - 2017-01-16 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:58 --> Input Class Initialized
DEBUG - 2017-01-16 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:26:58 --> Input Class Initialized
INFO - 2017-01-16 09:26:58 --> Language Class Initialized
INFO - 2017-01-16 09:26:58 --> Language Class Initialized
INFO - 2017-01-16 09:26:58 --> Loader Class Initialized
INFO - 2017-01-16 09:26:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:58 --> Loader Class Initialized
INFO - 2017-01-16 09:26:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:26:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:58 --> Controller Class Initialized
INFO - 2017-01-16 09:26:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:58 --> Model Class Initialized
INFO - 2017-01-16 09:26:58 --> Model Class Initialized
INFO - 2017-01-16 09:26:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:58 --> Total execution time: 0.0701
INFO - 2017-01-16 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:26:58 --> Controller Class Initialized
INFO - 2017-01-16 09:26:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:26:58 --> Model Class Initialized
INFO - 2017-01-16 09:26:58 --> Model Class Initialized
INFO - 2017-01-16 09:26:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:26:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:26:58 --> Total execution time: 0.1335
INFO - 2017-01-16 09:27:01 --> Config Class Initialized
INFO - 2017-01-16 09:27:01 --> Config Class Initialized
INFO - 2017-01-16 09:27:01 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:01 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:01 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:01 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:01 --> URI Class Initialized
INFO - 2017-01-16 09:27:01 --> URI Class Initialized
INFO - 2017-01-16 09:27:02 --> Router Class Initialized
INFO - 2017-01-16 09:27:02 --> Router Class Initialized
INFO - 2017-01-16 09:27:02 --> Output Class Initialized
INFO - 2017-01-16 09:27:02 --> Output Class Initialized
INFO - 2017-01-16 09:27:02 --> Security Class Initialized
INFO - 2017-01-16 09:27:02 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:02 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:02 --> Input Class Initialized
INFO - 2017-01-16 09:27:02 --> Language Class Initialized
INFO - 2017-01-16 09:27:02 --> Language Class Initialized
INFO - 2017-01-16 09:27:02 --> Loader Class Initialized
INFO - 2017-01-16 09:27:02 --> Loader Class Initialized
INFO - 2017-01-16 09:27:02 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:02 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:02 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:02 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:02 --> Controller Class Initialized
INFO - 2017-01-16 09:27:02 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:02 --> Model Class Initialized
INFO - 2017-01-16 09:27:02 --> Model Class Initialized
INFO - 2017-01-16 09:27:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:02 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:02 --> Total execution time: 0.0632
INFO - 2017-01-16 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:02 --> Controller Class Initialized
INFO - 2017-01-16 09:27:02 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:02 --> Model Class Initialized
INFO - 2017-01-16 09:27:02 --> Model Class Initialized
INFO - 2017-01-16 09:27:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:02 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:02 --> Total execution time: 0.1188
INFO - 2017-01-16 09:27:03 --> Config Class Initialized
INFO - 2017-01-16 09:27:03 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:03 --> Config Class Initialized
INFO - 2017-01-16 09:27:03 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:03 --> URI Class Initialized
INFO - 2017-01-16 09:27:03 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:03 --> Output Class Initialized
INFO - 2017-01-16 09:27:03 --> URI Class Initialized
INFO - 2017-01-16 09:27:03 --> Security Class Initialized
INFO - 2017-01-16 09:27:03 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:03 --> Input Class Initialized
INFO - 2017-01-16 09:27:03 --> Language Class Initialized
INFO - 2017-01-16 09:27:03 --> Output Class Initialized
INFO - 2017-01-16 09:27:03 --> Security Class Initialized
INFO - 2017-01-16 09:27:03 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:03 --> Input Class Initialized
INFO - 2017-01-16 09:27:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:03 --> Language Class Initialized
INFO - 2017-01-16 09:27:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:03 --> Loader Class Initialized
INFO - 2017-01-16 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:03 --> Controller Class Initialized
INFO - 2017-01-16 09:27:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:03 --> Model Class Initialized
INFO - 2017-01-16 09:27:03 --> Model Class Initialized
INFO - 2017-01-16 09:27:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:03 --> Total execution time: 0.0749
INFO - 2017-01-16 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:03 --> Controller Class Initialized
INFO - 2017-01-16 09:27:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:03 --> Model Class Initialized
INFO - 2017-01-16 09:27:03 --> Model Class Initialized
INFO - 2017-01-16 09:27:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:03 --> Total execution time: 0.1424
INFO - 2017-01-16 09:27:07 --> Config Class Initialized
INFO - 2017-01-16 09:27:07 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:07 --> Config Class Initialized
INFO - 2017-01-16 09:27:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:07 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:07 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:07 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:07 --> Router Class Initialized
INFO - 2017-01-16 09:27:07 --> URI Class Initialized
INFO - 2017-01-16 09:27:07 --> Output Class Initialized
INFO - 2017-01-16 09:27:07 --> Router Class Initialized
INFO - 2017-01-16 09:27:07 --> Security Class Initialized
INFO - 2017-01-16 09:27:07 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:07 --> Input Class Initialized
INFO - 2017-01-16 09:27:07 --> Security Class Initialized
INFO - 2017-01-16 09:27:07 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:07 --> Input Class Initialized
INFO - 2017-01-16 09:27:07 --> Language Class Initialized
INFO - 2017-01-16 09:27:07 --> Loader Class Initialized
INFO - 2017-01-16 09:27:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:07 --> Loader Class Initialized
INFO - 2017-01-16 09:27:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:07 --> Controller Class Initialized
INFO - 2017-01-16 09:27:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:07 --> Model Class Initialized
INFO - 2017-01-16 09:27:07 --> Model Class Initialized
INFO - 2017-01-16 09:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:07 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:07 --> Total execution time: 0.0742
INFO - 2017-01-16 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:07 --> Controller Class Initialized
INFO - 2017-01-16 09:27:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:07 --> Model Class Initialized
INFO - 2017-01-16 09:27:07 --> Model Class Initialized
INFO - 2017-01-16 09:27:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:07 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:07 --> Total execution time: 0.1347
INFO - 2017-01-16 09:27:09 --> Config Class Initialized
INFO - 2017-01-16 09:27:09 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:09 --> Config Class Initialized
INFO - 2017-01-16 09:27:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:09 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:27:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:09 --> URI Class Initialized
INFO - 2017-01-16 09:27:09 --> URI Class Initialized
INFO - 2017-01-16 09:27:09 --> Router Class Initialized
INFO - 2017-01-16 09:27:09 --> Router Class Initialized
INFO - 2017-01-16 09:27:09 --> Output Class Initialized
INFO - 2017-01-16 09:27:09 --> Output Class Initialized
INFO - 2017-01-16 09:27:09 --> Security Class Initialized
INFO - 2017-01-16 09:27:09 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:09 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:09 --> Input Class Initialized
INFO - 2017-01-16 09:27:09 --> Language Class Initialized
INFO - 2017-01-16 09:27:09 --> Language Class Initialized
INFO - 2017-01-16 09:27:09 --> Loader Class Initialized
INFO - 2017-01-16 09:27:09 --> Loader Class Initialized
INFO - 2017-01-16 09:27:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:09 --> Controller Class Initialized
INFO - 2017-01-16 09:27:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:09 --> Model Class Initialized
INFO - 2017-01-16 09:27:09 --> Model Class Initialized
INFO - 2017-01-16 09:27:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:09 --> Total execution time: 0.1527
INFO - 2017-01-16 09:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:09 --> Controller Class Initialized
INFO - 2017-01-16 09:27:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:09 --> Model Class Initialized
INFO - 2017-01-16 09:27:09 --> Model Class Initialized
INFO - 2017-01-16 09:27:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:09 --> Total execution time: 0.1826
INFO - 2017-01-16 09:27:11 --> Config Class Initialized
INFO - 2017-01-16 09:27:11 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:11 --> Config Class Initialized
INFO - 2017-01-16 09:27:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:11 --> URI Class Initialized
INFO - 2017-01-16 09:27:11 --> URI Class Initialized
INFO - 2017-01-16 09:27:11 --> Router Class Initialized
INFO - 2017-01-16 09:27:11 --> Router Class Initialized
INFO - 2017-01-16 09:27:11 --> Output Class Initialized
INFO - 2017-01-16 09:27:11 --> Output Class Initialized
INFO - 2017-01-16 09:27:11 --> Security Class Initialized
INFO - 2017-01-16 09:27:11 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:11 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:11 --> Input Class Initialized
INFO - 2017-01-16 09:27:11 --> Language Class Initialized
INFO - 2017-01-16 09:27:11 --> Language Class Initialized
INFO - 2017-01-16 09:27:11 --> Loader Class Initialized
INFO - 2017-01-16 09:27:11 --> Loader Class Initialized
INFO - 2017-01-16 09:27:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:11 --> Controller Class Initialized
INFO - 2017-01-16 09:27:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:11 --> Model Class Initialized
INFO - 2017-01-16 09:27:11 --> Model Class Initialized
INFO - 2017-01-16 09:27:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:11 --> Total execution time: 0.1417
INFO - 2017-01-16 09:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:11 --> Controller Class Initialized
INFO - 2017-01-16 09:27:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:11 --> Model Class Initialized
INFO - 2017-01-16 09:27:11 --> Model Class Initialized
INFO - 2017-01-16 09:27:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:11 --> Total execution time: 0.1672
INFO - 2017-01-16 09:27:12 --> Config Class Initialized
INFO - 2017-01-16 09:27:12 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:12 --> Config Class Initialized
INFO - 2017-01-16 09:27:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:12 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:27:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:12 --> URI Class Initialized
INFO - 2017-01-16 09:27:12 --> URI Class Initialized
INFO - 2017-01-16 09:27:12 --> Router Class Initialized
INFO - 2017-01-16 09:27:12 --> Router Class Initialized
INFO - 2017-01-16 09:27:12 --> Output Class Initialized
INFO - 2017-01-16 09:27:12 --> Output Class Initialized
INFO - 2017-01-16 09:27:12 --> Security Class Initialized
INFO - 2017-01-16 09:27:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:12 --> Input Class Initialized
INFO - 2017-01-16 09:27:12 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:12 --> Input Class Initialized
INFO - 2017-01-16 09:27:12 --> Language Class Initialized
INFO - 2017-01-16 09:27:12 --> Loader Class Initialized
INFO - 2017-01-16 09:27:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:12 --> Loader Class Initialized
INFO - 2017-01-16 09:27:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:12 --> Controller Class Initialized
INFO - 2017-01-16 09:27:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:12 --> Model Class Initialized
INFO - 2017-01-16 09:27:12 --> Model Class Initialized
INFO - 2017-01-16 09:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:12 --> Total execution time: 0.0757
INFO - 2017-01-16 09:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:12 --> Controller Class Initialized
INFO - 2017-01-16 09:27:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:12 --> Model Class Initialized
INFO - 2017-01-16 09:27:12 --> Model Class Initialized
INFO - 2017-01-16 09:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:13 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:13 --> Total execution time: 0.1652
INFO - 2017-01-16 09:27:14 --> Config Class Initialized
INFO - 2017-01-16 09:27:14 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:14 --> Config Class Initialized
INFO - 2017-01-16 09:27:14 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:14 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:14 --> Router Class Initialized
INFO - 2017-01-16 09:27:14 --> URI Class Initialized
INFO - 2017-01-16 09:27:14 --> Output Class Initialized
INFO - 2017-01-16 09:27:14 --> Router Class Initialized
INFO - 2017-01-16 09:27:14 --> Security Class Initialized
INFO - 2017-01-16 09:27:14 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:14 --> Input Class Initialized
INFO - 2017-01-16 09:27:14 --> Security Class Initialized
INFO - 2017-01-16 09:27:14 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:14 --> Input Class Initialized
INFO - 2017-01-16 09:27:14 --> Language Class Initialized
INFO - 2017-01-16 09:27:14 --> Loader Class Initialized
INFO - 2017-01-16 09:27:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:14 --> Loader Class Initialized
INFO - 2017-01-16 09:27:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:14 --> Controller Class Initialized
INFO - 2017-01-16 09:27:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:14 --> Model Class Initialized
INFO - 2017-01-16 09:27:14 --> Model Class Initialized
INFO - 2017-01-16 09:27:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:14 --> Total execution time: 0.0749
INFO - 2017-01-16 09:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:14 --> Controller Class Initialized
INFO - 2017-01-16 09:27:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:14 --> Model Class Initialized
INFO - 2017-01-16 09:27:14 --> Model Class Initialized
INFO - 2017-01-16 09:27:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:14 --> Total execution time: 0.1749
INFO - 2017-01-16 09:27:16 --> Config Class Initialized
INFO - 2017-01-16 09:27:16 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:16 --> Config Class Initialized
INFO - 2017-01-16 09:27:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:16 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:16 --> URI Class Initialized
INFO - 2017-01-16 09:27:16 --> Router Class Initialized
INFO - 2017-01-16 09:27:16 --> Router Class Initialized
INFO - 2017-01-16 09:27:16 --> Output Class Initialized
INFO - 2017-01-16 09:27:16 --> Output Class Initialized
INFO - 2017-01-16 09:27:16 --> Security Class Initialized
INFO - 2017-01-16 09:27:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:16 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:16 --> Language Class Initialized
INFO - 2017-01-16 09:27:16 --> Input Class Initialized
INFO - 2017-01-16 09:27:16 --> Language Class Initialized
INFO - 2017-01-16 09:27:16 --> Loader Class Initialized
INFO - 2017-01-16 09:27:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:16 --> Loader Class Initialized
INFO - 2017-01-16 09:27:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:16 --> Controller Class Initialized
INFO - 2017-01-16 09:27:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:16 --> Model Class Initialized
INFO - 2017-01-16 09:27:16 --> Model Class Initialized
INFO - 2017-01-16 09:27:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:16 --> Total execution time: 0.0766
INFO - 2017-01-16 09:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:16 --> Controller Class Initialized
INFO - 2017-01-16 09:27:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:16 --> Model Class Initialized
INFO - 2017-01-16 09:27:16 --> Model Class Initialized
INFO - 2017-01-16 09:27:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:16 --> Total execution time: 0.1741
INFO - 2017-01-16 09:27:18 --> Config Class Initialized
INFO - 2017-01-16 09:27:18 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:18 --> Config Class Initialized
INFO - 2017-01-16 09:27:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:18 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:27:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:18 --> URI Class Initialized
INFO - 2017-01-16 09:27:18 --> URI Class Initialized
INFO - 2017-01-16 09:27:18 --> Router Class Initialized
INFO - 2017-01-16 09:27:18 --> Router Class Initialized
INFO - 2017-01-16 09:27:18 --> Output Class Initialized
INFO - 2017-01-16 09:27:18 --> Output Class Initialized
INFO - 2017-01-16 09:27:18 --> Security Class Initialized
INFO - 2017-01-16 09:27:18 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:18 --> Input Class Initialized
INFO - 2017-01-16 09:27:18 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:18 --> Input Class Initialized
INFO - 2017-01-16 09:27:18 --> Language Class Initialized
INFO - 2017-01-16 09:27:18 --> Loader Class Initialized
INFO - 2017-01-16 09:27:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:18 --> Loader Class Initialized
INFO - 2017-01-16 09:27:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:18 --> Controller Class Initialized
INFO - 2017-01-16 09:27:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:18 --> Model Class Initialized
INFO - 2017-01-16 09:27:18 --> Model Class Initialized
INFO - 2017-01-16 09:27:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:18 --> Total execution time: 0.1634
INFO - 2017-01-16 09:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:18 --> Controller Class Initialized
INFO - 2017-01-16 09:27:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:18 --> Model Class Initialized
INFO - 2017-01-16 09:27:18 --> Model Class Initialized
INFO - 2017-01-16 09:27:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:18 --> Total execution time: 0.1911
INFO - 2017-01-16 09:27:20 --> Config Class Initialized
INFO - 2017-01-16 09:27:20 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:20 --> Config Class Initialized
INFO - 2017-01-16 09:27:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:20 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:20 --> Router Class Initialized
INFO - 2017-01-16 09:27:20 --> URI Class Initialized
INFO - 2017-01-16 09:27:20 --> Output Class Initialized
INFO - 2017-01-16 09:27:20 --> Router Class Initialized
INFO - 2017-01-16 09:27:20 --> Security Class Initialized
INFO - 2017-01-16 09:27:20 --> Output Class Initialized
INFO - 2017-01-16 09:27:20 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:20 --> Input Class Initialized
INFO - 2017-01-16 09:27:20 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:20 --> Input Class Initialized
INFO - 2017-01-16 09:27:20 --> Language Class Initialized
INFO - 2017-01-16 09:27:20 --> Loader Class Initialized
INFO - 2017-01-16 09:27:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:20 --> Loader Class Initialized
INFO - 2017-01-16 09:27:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:20 --> Controller Class Initialized
INFO - 2017-01-16 09:27:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:20 --> Total execution time: 0.0729
INFO - 2017-01-16 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:20 --> Controller Class Initialized
INFO - 2017-01-16 09:27:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:20 --> Total execution time: 0.1901
INFO - 2017-01-16 09:27:20 --> Config Class Initialized
INFO - 2017-01-16 09:27:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:20 --> URI Class Initialized
INFO - 2017-01-16 09:27:20 --> Router Class Initialized
INFO - 2017-01-16 09:27:20 --> Output Class Initialized
INFO - 2017-01-16 09:27:20 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:20 --> Input Class Initialized
INFO - 2017-01-16 09:27:20 --> Language Class Initialized
INFO - 2017-01-16 09:27:20 --> Loader Class Initialized
INFO - 2017-01-16 09:27:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:20 --> Controller Class Initialized
INFO - 2017-01-16 09:27:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Model Class Initialized
INFO - 2017-01-16 09:27:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:20 --> Total execution time: 0.0714
INFO - 2017-01-16 09:27:23 --> Config Class Initialized
INFO - 2017-01-16 09:27:23 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:23 --> Config Class Initialized
INFO - 2017-01-16 09:27:23 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:23 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:23 --> Router Class Initialized
INFO - 2017-01-16 09:27:23 --> URI Class Initialized
INFO - 2017-01-16 09:27:23 --> Output Class Initialized
INFO - 2017-01-16 09:27:23 --> Router Class Initialized
INFO - 2017-01-16 09:27:23 --> Security Class Initialized
INFO - 2017-01-16 09:27:23 --> Output Class Initialized
INFO - 2017-01-16 09:27:23 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:23 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:23 --> Language Class Initialized
INFO - 2017-01-16 09:27:23 --> Input Class Initialized
INFO - 2017-01-16 09:27:23 --> Language Class Initialized
INFO - 2017-01-16 09:27:23 --> Loader Class Initialized
INFO - 2017-01-16 09:27:23 --> Loader Class Initialized
INFO - 2017-01-16 09:27:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:23 --> Controller Class Initialized
INFO - 2017-01-16 09:27:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:23 --> Model Class Initialized
INFO - 2017-01-16 09:27:23 --> Model Class Initialized
INFO - 2017-01-16 09:27:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:23 --> Total execution time: 0.1532
INFO - 2017-01-16 09:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:23 --> Controller Class Initialized
INFO - 2017-01-16 09:27:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:23 --> Model Class Initialized
INFO - 2017-01-16 09:27:23 --> Model Class Initialized
INFO - 2017-01-16 09:27:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:23 --> Total execution time: 0.1806
INFO - 2017-01-16 09:27:25 --> Config Class Initialized
INFO - 2017-01-16 09:27:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:25 --> Config Class Initialized
INFO - 2017-01-16 09:27:25 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:25 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:25 --> URI Class Initialized
INFO - 2017-01-16 09:27:25 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:25 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:25 --> URI Class Initialized
INFO - 2017-01-16 09:27:25 --> Output Class Initialized
INFO - 2017-01-16 09:27:25 --> Router Class Initialized
INFO - 2017-01-16 09:27:25 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:25 --> Input Class Initialized
INFO - 2017-01-16 09:27:25 --> Output Class Initialized
INFO - 2017-01-16 09:27:25 --> Language Class Initialized
INFO - 2017-01-16 09:27:25 --> Security Class Initialized
INFO - 2017-01-16 09:27:25 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:25 --> Input Class Initialized
INFO - 2017-01-16 09:27:25 --> Language Class Initialized
INFO - 2017-01-16 09:27:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:25 --> Loader Class Initialized
INFO - 2017-01-16 09:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:25 --> Controller Class Initialized
INFO - 2017-01-16 09:27:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:25 --> Model Class Initialized
INFO - 2017-01-16 09:27:25 --> Model Class Initialized
INFO - 2017-01-16 09:27:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:25 --> Total execution time: 0.0731
INFO - 2017-01-16 09:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:25 --> Controller Class Initialized
INFO - 2017-01-16 09:27:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:25 --> Model Class Initialized
INFO - 2017-01-16 09:27:25 --> Model Class Initialized
INFO - 2017-01-16 09:27:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:25 --> Total execution time: 0.1945
INFO - 2017-01-16 09:27:27 --> Config Class Initialized
INFO - 2017-01-16 09:27:27 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:27 --> Config Class Initialized
INFO - 2017-01-16 09:27:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:27 --> URI Class Initialized
INFO - 2017-01-16 09:27:27 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:27 --> URI Class Initialized
INFO - 2017-01-16 09:27:27 --> Output Class Initialized
INFO - 2017-01-16 09:27:27 --> Router Class Initialized
INFO - 2017-01-16 09:27:27 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:27 --> Input Class Initialized
INFO - 2017-01-16 09:27:27 --> Output Class Initialized
INFO - 2017-01-16 09:27:27 --> Language Class Initialized
INFO - 2017-01-16 09:27:27 --> Security Class Initialized
INFO - 2017-01-16 09:27:27 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:27 --> Input Class Initialized
INFO - 2017-01-16 09:27:27 --> Language Class Initialized
INFO - 2017-01-16 09:27:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:27 --> Loader Class Initialized
INFO - 2017-01-16 09:27:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:27 --> Controller Class Initialized
INFO - 2017-01-16 09:27:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:27 --> Model Class Initialized
INFO - 2017-01-16 09:27:27 --> Model Class Initialized
INFO - 2017-01-16 09:27:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:27 --> Total execution time: 0.0756
INFO - 2017-01-16 09:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:27 --> Controller Class Initialized
INFO - 2017-01-16 09:27:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:27 --> Model Class Initialized
INFO - 2017-01-16 09:27:27 --> Model Class Initialized
INFO - 2017-01-16 09:27:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:27 --> Total execution time: 0.1996
INFO - 2017-01-16 09:27:29 --> Config Class Initialized
INFO - 2017-01-16 09:27:29 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:29 --> Config Class Initialized
INFO - 2017-01-16 09:27:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:29 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:29 --> Router Class Initialized
INFO - 2017-01-16 09:27:29 --> URI Class Initialized
INFO - 2017-01-16 09:27:29 --> Output Class Initialized
INFO - 2017-01-16 09:27:29 --> Router Class Initialized
INFO - 2017-01-16 09:27:29 --> Security Class Initialized
INFO - 2017-01-16 09:27:29 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:29 --> Input Class Initialized
INFO - 2017-01-16 09:27:29 --> Security Class Initialized
INFO - 2017-01-16 09:27:29 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:29 --> Input Class Initialized
INFO - 2017-01-16 09:27:29 --> Language Class Initialized
INFO - 2017-01-16 09:27:29 --> Loader Class Initialized
INFO - 2017-01-16 09:27:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:29 --> Loader Class Initialized
INFO - 2017-01-16 09:27:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:29 --> Controller Class Initialized
INFO - 2017-01-16 09:27:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:29 --> Model Class Initialized
INFO - 2017-01-16 09:27:29 --> Model Class Initialized
INFO - 2017-01-16 09:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:29 --> Total execution time: 0.1941
INFO - 2017-01-16 09:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:29 --> Controller Class Initialized
INFO - 2017-01-16 09:27:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:29 --> Model Class Initialized
INFO - 2017-01-16 09:27:29 --> Model Class Initialized
INFO - 2017-01-16 09:27:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:29 --> Total execution time: 0.2216
INFO - 2017-01-16 09:27:31 --> Config Class Initialized
INFO - 2017-01-16 09:27:31 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:31 --> Config Class Initialized
INFO - 2017-01-16 09:27:31 --> Config Class Initialized
DEBUG - 2017-01-16 09:27:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:31 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:31 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:31 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:31 --> Router Class Initialized
INFO - 2017-01-16 09:27:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:31 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:31 --> Output Class Initialized
INFO - 2017-01-16 09:27:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:31 --> Router Class Initialized
INFO - 2017-01-16 09:27:31 --> Security Class Initialized
INFO - 2017-01-16 09:27:31 --> URI Class Initialized
INFO - 2017-01-16 09:27:31 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:31 --> Input Class Initialized
INFO - 2017-01-16 09:27:31 --> Router Class Initialized
INFO - 2017-01-16 09:27:31 --> Security Class Initialized
INFO - 2017-01-16 09:27:31 --> Language Class Initialized
INFO - 2017-01-16 09:27:31 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:31 --> Input Class Initialized
INFO - 2017-01-16 09:27:31 --> Security Class Initialized
INFO - 2017-01-16 09:27:31 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:31 --> Input Class Initialized
INFO - 2017-01-16 09:27:31 --> Loader Class Initialized
INFO - 2017-01-16 09:27:31 --> Language Class Initialized
INFO - 2017-01-16 09:27:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:31 --> Loader Class Initialized
INFO - 2017-01-16 09:27:31 --> Loader Class Initialized
INFO - 2017-01-16 09:27:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:31 --> Controller Class Initialized
INFO - 2017-01-16 09:27:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:31 --> Total execution time: 0.0827
INFO - 2017-01-16 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:31 --> Controller Class Initialized
INFO - 2017-01-16 09:27:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:31 --> Total execution time: 0.1988
INFO - 2017-01-16 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:31 --> Controller Class Initialized
INFO - 2017-01-16 09:27:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:31 --> Config Class Initialized
INFO - 2017-01-16 09:27:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:31 --> URI Class Initialized
INFO - 2017-01-16 09:27:31 --> Router Class Initialized
INFO - 2017-01-16 09:27:31 --> Output Class Initialized
INFO - 2017-01-16 09:27:31 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:31 --> Input Class Initialized
INFO - 2017-01-16 09:27:31 --> Language Class Initialized
INFO - 2017-01-16 09:27:31 --> Loader Class Initialized
INFO - 2017-01-16 09:27:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:31 --> Controller Class Initialized
INFO - 2017-01-16 09:27:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Model Class Initialized
INFO - 2017-01-16 09:27:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:27:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2017-01-16 09:27:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:27:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:31 --> Total execution time: 0.0650
INFO - 2017-01-16 09:27:34 --> Config Class Initialized
INFO - 2017-01-16 09:27:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:34 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:34 --> URI Class Initialized
INFO - 2017-01-16 09:27:34 --> Router Class Initialized
INFO - 2017-01-16 09:27:34 --> Output Class Initialized
INFO - 2017-01-16 09:27:34 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:34 --> Input Class Initialized
INFO - 2017-01-16 09:27:34 --> Language Class Initialized
INFO - 2017-01-16 09:27:34 --> Loader Class Initialized
INFO - 2017-01-16 09:27:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:34 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:34 --> Controller Class Initialized
INFO - 2017-01-16 09:27:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:34 --> Config Class Initialized
INFO - 2017-01-16 09:27:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:34 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:34 --> URI Class Initialized
INFO - 2017-01-16 09:27:34 --> Router Class Initialized
INFO - 2017-01-16 09:27:34 --> Output Class Initialized
INFO - 2017-01-16 09:27:34 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:34 --> Input Class Initialized
INFO - 2017-01-16 09:27:34 --> Language Class Initialized
INFO - 2017-01-16 09:27:34 --> Loader Class Initialized
INFO - 2017-01-16 09:27:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:34 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:34 --> Controller Class Initialized
INFO - 2017-01-16 09:27:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:27:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2017-01-16 09:27:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:27:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:34 --> Total execution time: 0.0747
INFO - 2017-01-16 09:27:34 --> Config Class Initialized
INFO - 2017-01-16 09:27:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:34 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:34 --> URI Class Initialized
INFO - 2017-01-16 09:27:34 --> Config Class Initialized
INFO - 2017-01-16 09:27:34 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:34 --> Router Class Initialized
INFO - 2017-01-16 09:27:34 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:34 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:34 --> Security Class Initialized
INFO - 2017-01-16 09:27:34 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:34 --> Input Class Initialized
INFO - 2017-01-16 09:27:34 --> Router Class Initialized
INFO - 2017-01-16 09:27:34 --> Language Class Initialized
INFO - 2017-01-16 09:27:34 --> Output Class Initialized
INFO - 2017-01-16 09:27:34 --> Loader Class Initialized
INFO - 2017-01-16 09:27:34 --> Security Class Initialized
INFO - 2017-01-16 09:27:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:34 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:34 --> Input Class Initialized
INFO - 2017-01-16 09:27:34 --> Language Class Initialized
INFO - 2017-01-16 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:34 --> Controller Class Initialized
INFO - 2017-01-16 09:27:34 --> Loader Class Initialized
INFO - 2017-01-16 09:27:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:34 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:34 --> Total execution time: 0.0879
INFO - 2017-01-16 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:34 --> Controller Class Initialized
INFO - 2017-01-16 09:27:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Model Class Initialized
INFO - 2017-01-16 09:27:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:27:34 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:27:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:34 --> Total execution time: 0.1143
INFO - 2017-01-16 09:27:36 --> Config Class Initialized
INFO - 2017-01-16 09:27:36 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:36 --> Config Class Initialized
INFO - 2017-01-16 09:27:36 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:36 --> URI Class Initialized
INFO - 2017-01-16 09:27:36 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:36 --> Output Class Initialized
INFO - 2017-01-16 09:27:36 --> URI Class Initialized
INFO - 2017-01-16 09:27:36 --> Security Class Initialized
INFO - 2017-01-16 09:27:36 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:36 --> Input Class Initialized
INFO - 2017-01-16 09:27:36 --> Output Class Initialized
INFO - 2017-01-16 09:27:36 --> Language Class Initialized
INFO - 2017-01-16 09:27:36 --> Security Class Initialized
INFO - 2017-01-16 09:27:36 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:36 --> Input Class Initialized
INFO - 2017-01-16 09:27:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:36 --> Language Class Initialized
INFO - 2017-01-16 09:27:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:36 --> Loader Class Initialized
INFO - 2017-01-16 09:27:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:36 --> Controller Class Initialized
INFO - 2017-01-16 09:27:36 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:36 --> Model Class Initialized
INFO - 2017-01-16 09:27:36 --> Model Class Initialized
INFO - 2017-01-16 09:27:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:36 --> Total execution time: 0.0752
INFO - 2017-01-16 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:36 --> Controller Class Initialized
INFO - 2017-01-16 09:27:36 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:36 --> Model Class Initialized
INFO - 2017-01-16 09:27:36 --> Model Class Initialized
INFO - 2017-01-16 09:27:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:36 --> Total execution time: 0.1010
INFO - 2017-01-16 09:27:38 --> Config Class Initialized
INFO - 2017-01-16 09:27:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:38 --> Config Class Initialized
INFO - 2017-01-16 09:27:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:38 --> URI Class Initialized
INFO - 2017-01-16 09:27:38 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:38 --> Output Class Initialized
INFO - 2017-01-16 09:27:38 --> URI Class Initialized
INFO - 2017-01-16 09:27:38 --> Security Class Initialized
INFO - 2017-01-16 09:27:38 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:38 --> Input Class Initialized
INFO - 2017-01-16 09:27:38 --> Language Class Initialized
INFO - 2017-01-16 09:27:38 --> Output Class Initialized
INFO - 2017-01-16 09:27:38 --> Security Class Initialized
INFO - 2017-01-16 09:27:38 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:38 --> Input Class Initialized
INFO - 2017-01-16 09:27:38 --> Language Class Initialized
INFO - 2017-01-16 09:27:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:38 --> Loader Class Initialized
INFO - 2017-01-16 09:27:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:38 --> Controller Class Initialized
INFO - 2017-01-16 09:27:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:38 --> Model Class Initialized
INFO - 2017-01-16 09:27:38 --> Model Class Initialized
INFO - 2017-01-16 09:27:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:38 --> Total execution time: 0.0731
INFO - 2017-01-16 09:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:38 --> Controller Class Initialized
INFO - 2017-01-16 09:27:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:38 --> Model Class Initialized
INFO - 2017-01-16 09:27:38 --> Model Class Initialized
INFO - 2017-01-16 09:27:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:38 --> Total execution time: 0.1051
INFO - 2017-01-16 09:27:39 --> Config Class Initialized
INFO - 2017-01-16 09:27:39 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:39 --> Config Class Initialized
INFO - 2017-01-16 09:27:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:39 --> URI Class Initialized
INFO - 2017-01-16 09:27:39 --> URI Class Initialized
INFO - 2017-01-16 09:27:39 --> Router Class Initialized
INFO - 2017-01-16 09:27:39 --> Router Class Initialized
INFO - 2017-01-16 09:27:39 --> Output Class Initialized
INFO - 2017-01-16 09:27:39 --> Output Class Initialized
INFO - 2017-01-16 09:27:39 --> Security Class Initialized
INFO - 2017-01-16 09:27:39 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:39 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:39 --> Input Class Initialized
INFO - 2017-01-16 09:27:39 --> Language Class Initialized
INFO - 2017-01-16 09:27:39 --> Language Class Initialized
INFO - 2017-01-16 09:27:39 --> Loader Class Initialized
INFO - 2017-01-16 09:27:39 --> Loader Class Initialized
INFO - 2017-01-16 09:27:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:39 --> Controller Class Initialized
INFO - 2017-01-16 09:27:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:39 --> Model Class Initialized
INFO - 2017-01-16 09:27:39 --> Model Class Initialized
INFO - 2017-01-16 09:27:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:39 --> Total execution time: 0.0686
INFO - 2017-01-16 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:39 --> Controller Class Initialized
INFO - 2017-01-16 09:27:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:39 --> Model Class Initialized
INFO - 2017-01-16 09:27:39 --> Model Class Initialized
INFO - 2017-01-16 09:27:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:39 --> Total execution time: 0.1130
INFO - 2017-01-16 09:27:41 --> Config Class Initialized
INFO - 2017-01-16 09:27:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:41 --> Config Class Initialized
INFO - 2017-01-16 09:27:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:41 --> URI Class Initialized
INFO - 2017-01-16 09:27:41 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:41 --> Output Class Initialized
INFO - 2017-01-16 09:27:41 --> URI Class Initialized
INFO - 2017-01-16 09:27:41 --> Security Class Initialized
INFO - 2017-01-16 09:27:41 --> Router Class Initialized
DEBUG - 2017-01-16 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:41 --> Input Class Initialized
INFO - 2017-01-16 09:27:41 --> Language Class Initialized
INFO - 2017-01-16 09:27:41 --> Output Class Initialized
INFO - 2017-01-16 09:27:41 --> Security Class Initialized
INFO - 2017-01-16 09:27:41 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:41 --> Input Class Initialized
INFO - 2017-01-16 09:27:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:41 --> Language Class Initialized
INFO - 2017-01-16 09:27:41 --> Loader Class Initialized
INFO - 2017-01-16 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:41 --> Controller Class Initialized
INFO - 2017-01-16 09:27:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:41 --> Model Class Initialized
INFO - 2017-01-16 09:27:41 --> Model Class Initialized
INFO - 2017-01-16 09:27:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:41 --> Total execution time: 0.0761
INFO - 2017-01-16 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:41 --> Controller Class Initialized
INFO - 2017-01-16 09:27:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:41 --> Model Class Initialized
INFO - 2017-01-16 09:27:41 --> Model Class Initialized
INFO - 2017-01-16 09:27:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:41 --> Total execution time: 0.1128
INFO - 2017-01-16 09:27:42 --> Config Class Initialized
INFO - 2017-01-16 09:27:42 --> Config Class Initialized
INFO - 2017-01-16 09:27:42 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:42 --> URI Class Initialized
INFO - 2017-01-16 09:27:42 --> URI Class Initialized
INFO - 2017-01-16 09:27:42 --> Router Class Initialized
INFO - 2017-01-16 09:27:42 --> Router Class Initialized
INFO - 2017-01-16 09:27:42 --> Output Class Initialized
INFO - 2017-01-16 09:27:42 --> Output Class Initialized
INFO - 2017-01-16 09:27:42 --> Security Class Initialized
INFO - 2017-01-16 09:27:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:42 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:42 --> Input Class Initialized
INFO - 2017-01-16 09:27:42 --> Language Class Initialized
INFO - 2017-01-16 09:27:42 --> Language Class Initialized
INFO - 2017-01-16 09:27:42 --> Loader Class Initialized
INFO - 2017-01-16 09:27:42 --> Loader Class Initialized
INFO - 2017-01-16 09:27:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:42 --> Controller Class Initialized
INFO - 2017-01-16 09:27:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:42 --> Model Class Initialized
INFO - 2017-01-16 09:27:42 --> Model Class Initialized
INFO - 2017-01-16 09:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:42 --> Total execution time: 0.0784
INFO - 2017-01-16 09:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:42 --> Controller Class Initialized
INFO - 2017-01-16 09:27:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:42 --> Model Class Initialized
INFO - 2017-01-16 09:27:42 --> Model Class Initialized
INFO - 2017-01-16 09:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:42 --> Total execution time: 0.1357
INFO - 2017-01-16 09:27:44 --> Config Class Initialized
INFO - 2017-01-16 09:27:44 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:44 --> Config Class Initialized
INFO - 2017-01-16 09:27:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:44 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:44 --> Router Class Initialized
INFO - 2017-01-16 09:27:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:44 --> URI Class Initialized
INFO - 2017-01-16 09:27:44 --> Output Class Initialized
INFO - 2017-01-16 09:27:44 --> Router Class Initialized
INFO - 2017-01-16 09:27:44 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:44 --> Output Class Initialized
INFO - 2017-01-16 09:27:44 --> Input Class Initialized
INFO - 2017-01-16 09:27:44 --> Language Class Initialized
INFO - 2017-01-16 09:27:44 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:44 --> Loader Class Initialized
INFO - 2017-01-16 09:27:44 --> Input Class Initialized
INFO - 2017-01-16 09:27:44 --> Language Class Initialized
INFO - 2017-01-16 09:27:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:44 --> Loader Class Initialized
INFO - 2017-01-16 09:27:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:44 --> Controller Class Initialized
INFO - 2017-01-16 09:27:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:44 --> Model Class Initialized
INFO - 2017-01-16 09:27:44 --> Model Class Initialized
INFO - 2017-01-16 09:27:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:44 --> Total execution time: 0.0746
INFO - 2017-01-16 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:44 --> Controller Class Initialized
INFO - 2017-01-16 09:27:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:44 --> Model Class Initialized
INFO - 2017-01-16 09:27:44 --> Model Class Initialized
INFO - 2017-01-16 09:27:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:44 --> Total execution time: 0.1309
INFO - 2017-01-16 09:27:46 --> Config Class Initialized
INFO - 2017-01-16 09:27:46 --> Config Class Initialized
INFO - 2017-01-16 09:27:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:46 --> URI Class Initialized
INFO - 2017-01-16 09:27:46 --> URI Class Initialized
INFO - 2017-01-16 09:27:46 --> Router Class Initialized
INFO - 2017-01-16 09:27:46 --> Router Class Initialized
INFO - 2017-01-16 09:27:46 --> Output Class Initialized
INFO - 2017-01-16 09:27:46 --> Output Class Initialized
INFO - 2017-01-16 09:27:46 --> Security Class Initialized
INFO - 2017-01-16 09:27:46 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:46 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:46 --> Input Class Initialized
INFO - 2017-01-16 09:27:46 --> Language Class Initialized
INFO - 2017-01-16 09:27:46 --> Language Class Initialized
INFO - 2017-01-16 09:27:46 --> Loader Class Initialized
INFO - 2017-01-16 09:27:46 --> Loader Class Initialized
INFO - 2017-01-16 09:27:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:46 --> Controller Class Initialized
INFO - 2017-01-16 09:27:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:46 --> Model Class Initialized
INFO - 2017-01-16 09:27:46 --> Model Class Initialized
INFO - 2017-01-16 09:27:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:46 --> Total execution time: 0.0768
INFO - 2017-01-16 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:46 --> Controller Class Initialized
INFO - 2017-01-16 09:27:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:46 --> Model Class Initialized
INFO - 2017-01-16 09:27:46 --> Model Class Initialized
INFO - 2017-01-16 09:27:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:46 --> Total execution time: 0.1483
INFO - 2017-01-16 09:27:48 --> Config Class Initialized
INFO - 2017-01-16 09:27:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:48 --> Config Class Initialized
INFO - 2017-01-16 09:27:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:48 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:27:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:48 --> URI Class Initialized
INFO - 2017-01-16 09:27:48 --> URI Class Initialized
INFO - 2017-01-16 09:27:48 --> Router Class Initialized
INFO - 2017-01-16 09:27:48 --> Router Class Initialized
INFO - 2017-01-16 09:27:48 --> Output Class Initialized
INFO - 2017-01-16 09:27:48 --> Output Class Initialized
INFO - 2017-01-16 09:27:48 --> Security Class Initialized
INFO - 2017-01-16 09:27:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:48 --> Input Class Initialized
INFO - 2017-01-16 09:27:48 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:48 --> Input Class Initialized
INFO - 2017-01-16 09:27:48 --> Language Class Initialized
INFO - 2017-01-16 09:27:48 --> Loader Class Initialized
INFO - 2017-01-16 09:27:48 --> Loader Class Initialized
INFO - 2017-01-16 09:27:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:48 --> Controller Class Initialized
INFO - 2017-01-16 09:27:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:48 --> Model Class Initialized
INFO - 2017-01-16 09:27:48 --> Model Class Initialized
INFO - 2017-01-16 09:27:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:48 --> Total execution time: 0.0740
INFO - 2017-01-16 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:48 --> Controller Class Initialized
INFO - 2017-01-16 09:27:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:48 --> Model Class Initialized
INFO - 2017-01-16 09:27:48 --> Model Class Initialized
INFO - 2017-01-16 09:27:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:48 --> Total execution time: 0.1416
INFO - 2017-01-16 09:27:49 --> Config Class Initialized
INFO - 2017-01-16 09:27:49 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:49 --> Config Class Initialized
INFO - 2017-01-16 09:27:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:49 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:49 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:49 --> URI Class Initialized
INFO - 2017-01-16 09:27:49 --> URI Class Initialized
INFO - 2017-01-16 09:27:49 --> Router Class Initialized
INFO - 2017-01-16 09:27:49 --> Router Class Initialized
INFO - 2017-01-16 09:27:49 --> Output Class Initialized
INFO - 2017-01-16 09:27:49 --> Output Class Initialized
INFO - 2017-01-16 09:27:49 --> Security Class Initialized
INFO - 2017-01-16 09:27:49 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:49 --> Input Class Initialized
INFO - 2017-01-16 09:27:49 --> Input Class Initialized
INFO - 2017-01-16 09:27:49 --> Language Class Initialized
INFO - 2017-01-16 09:27:49 --> Language Class Initialized
INFO - 2017-01-16 09:27:49 --> Loader Class Initialized
INFO - 2017-01-16 09:27:49 --> Loader Class Initialized
INFO - 2017-01-16 09:27:49 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:49 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:49 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:49 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:49 --> Controller Class Initialized
INFO - 2017-01-16 09:27:49 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:49 --> Model Class Initialized
INFO - 2017-01-16 09:27:49 --> Model Class Initialized
INFO - 2017-01-16 09:27:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:49 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:49 --> Total execution time: 0.1368
INFO - 2017-01-16 09:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:49 --> Controller Class Initialized
INFO - 2017-01-16 09:27:49 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:49 --> Model Class Initialized
INFO - 2017-01-16 09:27:49 --> Model Class Initialized
INFO - 2017-01-16 09:27:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:49 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:49 --> Total execution time: 0.1667
INFO - 2017-01-16 09:27:51 --> Config Class Initialized
INFO - 2017-01-16 09:27:51 --> Config Class Initialized
INFO - 2017-01-16 09:27:51 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:51 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:51 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:27:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:51 --> URI Class Initialized
INFO - 2017-01-16 09:27:51 --> URI Class Initialized
INFO - 2017-01-16 09:27:51 --> Router Class Initialized
INFO - 2017-01-16 09:27:51 --> Router Class Initialized
INFO - 2017-01-16 09:27:51 --> Output Class Initialized
INFO - 2017-01-16 09:27:51 --> Output Class Initialized
INFO - 2017-01-16 09:27:51 --> Security Class Initialized
INFO - 2017-01-16 09:27:51 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:51 --> Input Class Initialized
INFO - 2017-01-16 09:27:51 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:51 --> Input Class Initialized
INFO - 2017-01-16 09:27:51 --> Language Class Initialized
INFO - 2017-01-16 09:27:51 --> Loader Class Initialized
INFO - 2017-01-16 09:27:51 --> Loader Class Initialized
INFO - 2017-01-16 09:27:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:51 --> Controller Class Initialized
INFO - 2017-01-16 09:27:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:51 --> Model Class Initialized
INFO - 2017-01-16 09:27:51 --> Model Class Initialized
INFO - 2017-01-16 09:27:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:51 --> Total execution time: 0.0782
INFO - 2017-01-16 09:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:51 --> Controller Class Initialized
INFO - 2017-01-16 09:27:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:51 --> Model Class Initialized
INFO - 2017-01-16 09:27:51 --> Model Class Initialized
INFO - 2017-01-16 09:27:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:51 --> Total execution time: 0.1685
INFO - 2017-01-16 09:27:52 --> Config Class Initialized
INFO - 2017-01-16 09:27:52 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:52 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:52 --> URI Class Initialized
INFO - 2017-01-16 09:27:52 --> Router Class Initialized
INFO - 2017-01-16 09:27:52 --> Output Class Initialized
INFO - 2017-01-16 09:27:52 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:52 --> Input Class Initialized
INFO - 2017-01-16 09:27:52 --> Language Class Initialized
INFO - 2017-01-16 09:27:52 --> Loader Class Initialized
INFO - 2017-01-16 09:27:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:52 --> Controller Class Initialized
INFO - 2017-01-16 09:27:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:52 --> Model Class Initialized
INFO - 2017-01-16 09:27:52 --> Model Class Initialized
INFO - 2017-01-16 09:27:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:52 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:52 --> Total execution time: 0.1403
INFO - 2017-01-16 09:27:52 --> Config Class Initialized
INFO - 2017-01-16 09:27:52 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:52 --> Config Class Initialized
INFO - 2017-01-16 09:27:52 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:52 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:52 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:52 --> Router Class Initialized
INFO - 2017-01-16 09:27:52 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:52 --> URI Class Initialized
INFO - 2017-01-16 09:27:52 --> Output Class Initialized
INFO - 2017-01-16 09:27:52 --> Router Class Initialized
INFO - 2017-01-16 09:27:52 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:52 --> Output Class Initialized
INFO - 2017-01-16 09:27:52 --> Input Class Initialized
INFO - 2017-01-16 09:27:52 --> Language Class Initialized
INFO - 2017-01-16 09:27:52 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:52 --> Loader Class Initialized
INFO - 2017-01-16 09:27:52 --> Input Class Initialized
INFO - 2017-01-16 09:27:52 --> Language Class Initialized
INFO - 2017-01-16 09:27:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:52 --> Loader Class Initialized
INFO - 2017-01-16 09:27:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:52 --> Controller Class Initialized
INFO - 2017-01-16 09:27:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:52 --> Model Class Initialized
INFO - 2017-01-16 09:27:52 --> Model Class Initialized
INFO - 2017-01-16 09:27:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:53 --> Total execution time: 0.0741
INFO - 2017-01-16 09:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:53 --> Controller Class Initialized
INFO - 2017-01-16 09:27:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:53 --> Model Class Initialized
INFO - 2017-01-16 09:27:53 --> Model Class Initialized
INFO - 2017-01-16 09:27:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:53 --> Total execution time: 0.1635
INFO - 2017-01-16 09:27:55 --> Config Class Initialized
INFO - 2017-01-16 09:27:55 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:55 --> Config Class Initialized
INFO - 2017-01-16 09:27:55 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:55 --> URI Class Initialized
DEBUG - 2017-01-16 09:27:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:55 --> Router Class Initialized
INFO - 2017-01-16 09:27:55 --> URI Class Initialized
INFO - 2017-01-16 09:27:55 --> Output Class Initialized
INFO - 2017-01-16 09:27:55 --> Router Class Initialized
INFO - 2017-01-16 09:27:55 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:55 --> Input Class Initialized
INFO - 2017-01-16 09:27:55 --> Output Class Initialized
INFO - 2017-01-16 09:27:55 --> Language Class Initialized
INFO - 2017-01-16 09:27:55 --> Security Class Initialized
INFO - 2017-01-16 09:27:55 --> Loader Class Initialized
DEBUG - 2017-01-16 09:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:55 --> Input Class Initialized
INFO - 2017-01-16 09:27:55 --> Language Class Initialized
INFO - 2017-01-16 09:27:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:55 --> Loader Class Initialized
INFO - 2017-01-16 09:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:55 --> Controller Class Initialized
INFO - 2017-01-16 09:27:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:55 --> Model Class Initialized
INFO - 2017-01-16 09:27:55 --> Model Class Initialized
INFO - 2017-01-16 09:27:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:55 --> Total execution time: 0.0713
INFO - 2017-01-16 09:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:55 --> Controller Class Initialized
INFO - 2017-01-16 09:27:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:55 --> Model Class Initialized
INFO - 2017-01-16 09:27:55 --> Model Class Initialized
INFO - 2017-01-16 09:27:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:55 --> Total execution time: 0.1661
INFO - 2017-01-16 09:27:56 --> Config Class Initialized
INFO - 2017-01-16 09:27:56 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:56 --> Config Class Initialized
INFO - 2017-01-16 09:27:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:56 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:27:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:56 --> URI Class Initialized
INFO - 2017-01-16 09:27:56 --> URI Class Initialized
INFO - 2017-01-16 09:27:56 --> Router Class Initialized
INFO - 2017-01-16 09:27:56 --> Output Class Initialized
INFO - 2017-01-16 09:27:56 --> Router Class Initialized
INFO - 2017-01-16 09:27:56 --> Security Class Initialized
INFO - 2017-01-16 09:27:56 --> Output Class Initialized
DEBUG - 2017-01-16 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:56 --> Input Class Initialized
INFO - 2017-01-16 09:27:56 --> Security Class Initialized
INFO - 2017-01-16 09:27:56 --> Language Class Initialized
DEBUG - 2017-01-16 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:56 --> Input Class Initialized
INFO - 2017-01-16 09:27:56 --> Loader Class Initialized
INFO - 2017-01-16 09:27:56 --> Language Class Initialized
INFO - 2017-01-16 09:27:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:56 --> Loader Class Initialized
INFO - 2017-01-16 09:27:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:56 --> Controller Class Initialized
INFO - 2017-01-16 09:27:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:56 --> Model Class Initialized
INFO - 2017-01-16 09:27:56 --> Model Class Initialized
INFO - 2017-01-16 09:27:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:56 --> Total execution time: 0.0777
INFO - 2017-01-16 09:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:56 --> Controller Class Initialized
INFO - 2017-01-16 09:27:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:56 --> Model Class Initialized
INFO - 2017-01-16 09:27:56 --> Model Class Initialized
INFO - 2017-01-16 09:27:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:56 --> Total execution time: 0.2004
INFO - 2017-01-16 09:27:58 --> Config Class Initialized
INFO - 2017-01-16 09:27:58 --> Hooks Class Initialized
INFO - 2017-01-16 09:27:58 --> Config Class Initialized
INFO - 2017-01-16 09:27:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:27:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:58 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:27:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:27:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:27:58 --> URI Class Initialized
INFO - 2017-01-16 09:27:58 --> URI Class Initialized
INFO - 2017-01-16 09:27:58 --> Router Class Initialized
INFO - 2017-01-16 09:27:58 --> Router Class Initialized
INFO - 2017-01-16 09:27:58 --> Output Class Initialized
INFO - 2017-01-16 09:27:58 --> Output Class Initialized
INFO - 2017-01-16 09:27:58 --> Security Class Initialized
INFO - 2017-01-16 09:27:58 --> Security Class Initialized
DEBUG - 2017-01-16 09:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:58 --> Input Class Initialized
DEBUG - 2017-01-16 09:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:27:58 --> Input Class Initialized
INFO - 2017-01-16 09:27:58 --> Language Class Initialized
INFO - 2017-01-16 09:27:58 --> Language Class Initialized
INFO - 2017-01-16 09:27:58 --> Loader Class Initialized
INFO - 2017-01-16 09:27:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:58 --> Loader Class Initialized
INFO - 2017-01-16 09:27:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:27:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:58 --> Controller Class Initialized
INFO - 2017-01-16 09:27:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:58 --> Model Class Initialized
INFO - 2017-01-16 09:27:58 --> Model Class Initialized
INFO - 2017-01-16 09:27:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:58 --> Total execution time: 0.0736
INFO - 2017-01-16 09:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:27:58 --> Controller Class Initialized
INFO - 2017-01-16 09:27:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:27:58 --> Model Class Initialized
INFO - 2017-01-16 09:27:58 --> Model Class Initialized
INFO - 2017-01-16 09:27:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:27:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:27:58 --> Total execution time: 0.1942
INFO - 2017-01-16 09:28:00 --> Config Class Initialized
INFO - 2017-01-16 09:28:00 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:00 --> Config Class Initialized
INFO - 2017-01-16 09:28:00 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:00 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:00 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:00 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:00 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:00 --> URI Class Initialized
INFO - 2017-01-16 09:28:00 --> URI Class Initialized
INFO - 2017-01-16 09:28:00 --> Router Class Initialized
INFO - 2017-01-16 09:28:00 --> Router Class Initialized
INFO - 2017-01-16 09:28:00 --> Output Class Initialized
INFO - 2017-01-16 09:28:00 --> Output Class Initialized
INFO - 2017-01-16 09:28:00 --> Security Class Initialized
INFO - 2017-01-16 09:28:00 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:00 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:00 --> Input Class Initialized
INFO - 2017-01-16 09:28:00 --> Language Class Initialized
INFO - 2017-01-16 09:28:00 --> Language Class Initialized
INFO - 2017-01-16 09:28:00 --> Loader Class Initialized
INFO - 2017-01-16 09:28:00 --> Loader Class Initialized
INFO - 2017-01-16 09:28:00 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:00 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:00 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:00 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:00 --> Controller Class Initialized
INFO - 2017-01-16 09:28:00 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:00 --> Model Class Initialized
INFO - 2017-01-16 09:28:00 --> Model Class Initialized
INFO - 2017-01-16 09:28:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:00 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:00 --> Total execution time: 0.0724
INFO - 2017-01-16 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:00 --> Controller Class Initialized
INFO - 2017-01-16 09:28:00 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:00 --> Model Class Initialized
INFO - 2017-01-16 09:28:00 --> Model Class Initialized
INFO - 2017-01-16 09:28:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:00 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:00 --> Total execution time: 0.1924
INFO - 2017-01-16 09:28:01 --> Config Class Initialized
INFO - 2017-01-16 09:28:01 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:01 --> Config Class Initialized
INFO - 2017-01-16 09:28:01 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:01 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:01 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:01 --> URI Class Initialized
INFO - 2017-01-16 09:28:01 --> URI Class Initialized
INFO - 2017-01-16 09:28:01 --> Router Class Initialized
INFO - 2017-01-16 09:28:01 --> Router Class Initialized
INFO - 2017-01-16 09:28:01 --> Output Class Initialized
INFO - 2017-01-16 09:28:01 --> Output Class Initialized
INFO - 2017-01-16 09:28:01 --> Security Class Initialized
INFO - 2017-01-16 09:28:01 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:01 --> Input Class Initialized
INFO - 2017-01-16 09:28:01 --> Input Class Initialized
INFO - 2017-01-16 09:28:01 --> Language Class Initialized
INFO - 2017-01-16 09:28:01 --> Language Class Initialized
INFO - 2017-01-16 09:28:01 --> Loader Class Initialized
INFO - 2017-01-16 09:28:01 --> Loader Class Initialized
INFO - 2017-01-16 09:28:01 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:01 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:01 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:01 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:01 --> Controller Class Initialized
INFO - 2017-01-16 09:28:01 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:01 --> Model Class Initialized
INFO - 2017-01-16 09:28:01 --> Model Class Initialized
INFO - 2017-01-16 09:28:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:01 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:01 --> Total execution time: 0.1767
INFO - 2017-01-16 09:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:01 --> Controller Class Initialized
INFO - 2017-01-16 09:28:01 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:01 --> Model Class Initialized
INFO - 2017-01-16 09:28:01 --> Model Class Initialized
INFO - 2017-01-16 09:28:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:01 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:01 --> Total execution time: 0.2086
INFO - 2017-01-16 09:28:03 --> Config Class Initialized
INFO - 2017-01-16 09:28:03 --> Config Class Initialized
INFO - 2017-01-16 09:28:03 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:03 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:28:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:03 --> URI Class Initialized
INFO - 2017-01-16 09:28:03 --> URI Class Initialized
INFO - 2017-01-16 09:28:03 --> Router Class Initialized
INFO - 2017-01-16 09:28:03 --> Router Class Initialized
INFO - 2017-01-16 09:28:03 --> Output Class Initialized
INFO - 2017-01-16 09:28:03 --> Output Class Initialized
INFO - 2017-01-16 09:28:03 --> Security Class Initialized
INFO - 2017-01-16 09:28:03 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:03 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:03 --> Input Class Initialized
INFO - 2017-01-16 09:28:03 --> Language Class Initialized
INFO - 2017-01-16 09:28:03 --> Language Class Initialized
INFO - 2017-01-16 09:28:03 --> Loader Class Initialized
INFO - 2017-01-16 09:28:03 --> Loader Class Initialized
INFO - 2017-01-16 09:28:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:03 --> Controller Class Initialized
INFO - 2017-01-16 09:28:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:03 --> Model Class Initialized
INFO - 2017-01-16 09:28:03 --> Model Class Initialized
INFO - 2017-01-16 09:28:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:03 --> Total execution time: 0.0752
INFO - 2017-01-16 09:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:03 --> Controller Class Initialized
INFO - 2017-01-16 09:28:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:03 --> Model Class Initialized
INFO - 2017-01-16 09:28:03 --> Model Class Initialized
INFO - 2017-01-16 09:28:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:03 --> Total execution time: 0.2029
INFO - 2017-01-16 09:28:04 --> Config Class Initialized
INFO - 2017-01-16 09:28:04 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:04 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:04 --> URI Class Initialized
INFO - 2017-01-16 09:28:04 --> Router Class Initialized
INFO - 2017-01-16 09:28:04 --> Output Class Initialized
INFO - 2017-01-16 09:28:04 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:04 --> Input Class Initialized
INFO - 2017-01-16 09:28:04 --> Language Class Initialized
INFO - 2017-01-16 09:28:04 --> Loader Class Initialized
INFO - 2017-01-16 09:28:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:04 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:04 --> Controller Class Initialized
INFO - 2017-01-16 09:28:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:04 --> Model Class Initialized
INFO - 2017-01-16 09:28:04 --> Model Class Initialized
INFO - 2017-01-16 09:28:04 --> Model Class Initialized
INFO - 2017-01-16 09:28:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:04 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:04 --> Total execution time: 0.0719
INFO - 2017-01-16 09:28:05 --> Config Class Initialized
INFO - 2017-01-16 09:28:05 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:05 --> URI Class Initialized
INFO - 2017-01-16 09:28:05 --> Config Class Initialized
INFO - 2017-01-16 09:28:05 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:05 --> Router Class Initialized
INFO - 2017-01-16 09:28:05 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:05 --> Security Class Initialized
INFO - 2017-01-16 09:28:05 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:05 --> Input Class Initialized
INFO - 2017-01-16 09:28:05 --> Router Class Initialized
INFO - 2017-01-16 09:28:05 --> Language Class Initialized
INFO - 2017-01-16 09:28:05 --> Output Class Initialized
INFO - 2017-01-16 09:28:05 --> Security Class Initialized
INFO - 2017-01-16 09:28:05 --> Loader Class Initialized
INFO - 2017-01-16 09:28:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:05 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:05 --> Input Class Initialized
INFO - 2017-01-16 09:28:05 --> Language Class Initialized
INFO - 2017-01-16 09:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:05 --> Controller Class Initialized
INFO - 2017-01-16 09:28:05 --> Loader Class Initialized
INFO - 2017-01-16 09:28:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:05 --> Model Class Initialized
INFO - 2017-01-16 09:28:05 --> Model Class Initialized
INFO - 2017-01-16 09:28:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:05 --> Total execution time: 0.0706
INFO - 2017-01-16 09:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:05 --> Controller Class Initialized
INFO - 2017-01-16 09:28:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:05 --> Model Class Initialized
INFO - 2017-01-16 09:28:05 --> Model Class Initialized
INFO - 2017-01-16 09:28:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:05 --> Total execution time: 0.1865
INFO - 2017-01-16 09:28:07 --> Config Class Initialized
INFO - 2017-01-16 09:28:07 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:07 --> Config Class Initialized
INFO - 2017-01-16 09:28:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:07 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:07 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:07 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:07 --> Router Class Initialized
INFO - 2017-01-16 09:28:07 --> URI Class Initialized
INFO - 2017-01-16 09:28:07 --> Router Class Initialized
INFO - 2017-01-16 09:28:07 --> Output Class Initialized
INFO - 2017-01-16 09:28:07 --> Output Class Initialized
INFO - 2017-01-16 09:28:07 --> Security Class Initialized
INFO - 2017-01-16 09:28:07 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:07 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:07 --> Input Class Initialized
INFO - 2017-01-16 09:28:07 --> Language Class Initialized
INFO - 2017-01-16 09:28:07 --> Language Class Initialized
INFO - 2017-01-16 09:28:07 --> Loader Class Initialized
INFO - 2017-01-16 09:28:07 --> Loader Class Initialized
INFO - 2017-01-16 09:28:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:07 --> Controller Class Initialized
INFO - 2017-01-16 09:28:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:07 --> Model Class Initialized
INFO - 2017-01-16 09:28:07 --> Model Class Initialized
INFO - 2017-01-16 09:28:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:08 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:08 --> Total execution time: 0.1706
INFO - 2017-01-16 09:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:08 --> Controller Class Initialized
INFO - 2017-01-16 09:28:08 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:08 --> Model Class Initialized
INFO - 2017-01-16 09:28:08 --> Model Class Initialized
INFO - 2017-01-16 09:28:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:08 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:08 --> Total execution time: 0.1973
INFO - 2017-01-16 09:28:09 --> Config Class Initialized
INFO - 2017-01-16 09:28:09 --> Config Class Initialized
INFO - 2017-01-16 09:28:09 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:09 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:09 --> URI Class Initialized
INFO - 2017-01-16 09:28:09 --> URI Class Initialized
INFO - 2017-01-16 09:28:09 --> Router Class Initialized
INFO - 2017-01-16 09:28:09 --> Router Class Initialized
INFO - 2017-01-16 09:28:09 --> Config Class Initialized
INFO - 2017-01-16 09:28:09 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:09 --> Output Class Initialized
INFO - 2017-01-16 09:28:09 --> Output Class Initialized
INFO - 2017-01-16 09:28:09 --> Security Class Initialized
INFO - 2017-01-16 09:28:09 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:09 --> Input Class Initialized
INFO - 2017-01-16 09:28:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:09 --> Language Class Initialized
INFO - 2017-01-16 09:28:09 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:09 --> Input Class Initialized
INFO - 2017-01-16 09:28:09 --> Router Class Initialized
INFO - 2017-01-16 09:28:09 --> Language Class Initialized
INFO - 2017-01-16 09:28:09 --> Output Class Initialized
INFO - 2017-01-16 09:28:09 --> Loader Class Initialized
INFO - 2017-01-16 09:28:10 --> Security Class Initialized
INFO - 2017-01-16 09:28:10 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:10 --> Loader Class Initialized
DEBUG - 2017-01-16 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:10 --> Input Class Initialized
INFO - 2017-01-16 09:28:10 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:10 --> Language Class Initialized
INFO - 2017-01-16 09:28:10 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:10 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:10 --> Controller Class Initialized
INFO - 2017-01-16 09:28:10 --> Loader Class Initialized
INFO - 2017-01-16 09:28:10 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:10 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:10 --> Total execution time: 0.0861
INFO - 2017-01-16 09:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:10 --> Controller Class Initialized
INFO - 2017-01-16 09:28:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:10 --> Total execution time: 0.2288
INFO - 2017-01-16 09:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:10 --> Controller Class Initialized
INFO - 2017-01-16 09:28:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:10 --> Config Class Initialized
INFO - 2017-01-16 09:28:10 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:10 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:10 --> URI Class Initialized
INFO - 2017-01-16 09:28:10 --> Router Class Initialized
INFO - 2017-01-16 09:28:10 --> Output Class Initialized
INFO - 2017-01-16 09:28:10 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:10 --> Input Class Initialized
INFO - 2017-01-16 09:28:10 --> Language Class Initialized
INFO - 2017-01-16 09:28:10 --> Loader Class Initialized
INFO - 2017-01-16 09:28:10 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:10 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:10 --> Controller Class Initialized
INFO - 2017-01-16 09:28:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Model Class Initialized
INFO - 2017-01-16 09:28:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:28:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2017-01-16 09:28:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:28:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:10 --> Total execution time: 0.0783
INFO - 2017-01-16 09:28:12 --> Config Class Initialized
INFO - 2017-01-16 09:28:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:12 --> URI Class Initialized
INFO - 2017-01-16 09:28:12 --> Router Class Initialized
INFO - 2017-01-16 09:28:12 --> Output Class Initialized
INFO - 2017-01-16 09:28:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:12 --> Input Class Initialized
INFO - 2017-01-16 09:28:12 --> Language Class Initialized
INFO - 2017-01-16 09:28:12 --> Loader Class Initialized
INFO - 2017-01-16 09:28:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:12 --> Controller Class Initialized
INFO - 2017-01-16 09:28:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:12 --> Config Class Initialized
INFO - 2017-01-16 09:28:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:12 --> URI Class Initialized
INFO - 2017-01-16 09:28:12 --> Router Class Initialized
INFO - 2017-01-16 09:28:12 --> Output Class Initialized
INFO - 2017-01-16 09:28:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:12 --> Input Class Initialized
INFO - 2017-01-16 09:28:12 --> Language Class Initialized
INFO - 2017-01-16 09:28:12 --> Loader Class Initialized
INFO - 2017-01-16 09:28:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:12 --> Controller Class Initialized
INFO - 2017-01-16 09:28:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:28:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2017-01-16 09:28:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:28:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:12 --> Total execution time: 0.0790
INFO - 2017-01-16 09:28:12 --> Config Class Initialized
INFO - 2017-01-16 09:28:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:12 --> Config Class Initialized
INFO - 2017-01-16 09:28:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:12 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:12 --> URI Class Initialized
INFO - 2017-01-16 09:28:12 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:12 --> URI Class Initialized
INFO - 2017-01-16 09:28:12 --> Output Class Initialized
INFO - 2017-01-16 09:28:12 --> Router Class Initialized
INFO - 2017-01-16 09:28:12 --> Security Class Initialized
INFO - 2017-01-16 09:28:12 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:12 --> Input Class Initialized
INFO - 2017-01-16 09:28:12 --> Security Class Initialized
INFO - 2017-01-16 09:28:12 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:12 --> Input Class Initialized
INFO - 2017-01-16 09:28:12 --> Language Class Initialized
INFO - 2017-01-16 09:28:12 --> Loader Class Initialized
INFO - 2017-01-16 09:28:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:12 --> Loader Class Initialized
INFO - 2017-01-16 09:28:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:12 --> Controller Class Initialized
INFO - 2017-01-16 09:28:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:12 --> Total execution time: 0.0797
INFO - 2017-01-16 09:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:12 --> Controller Class Initialized
INFO - 2017-01-16 09:28:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Model Class Initialized
INFO - 2017-01-16 09:28:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:28:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:28:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:28:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:12 --> Total execution time: 0.1071
INFO - 2017-01-16 09:28:14 --> Config Class Initialized
INFO - 2017-01-16 09:28:14 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:14 --> Config Class Initialized
DEBUG - 2017-01-16 09:28:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:14 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:14 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:14 --> Router Class Initialized
INFO - 2017-01-16 09:28:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:14 --> URI Class Initialized
INFO - 2017-01-16 09:28:14 --> Output Class Initialized
INFO - 2017-01-16 09:28:14 --> Router Class Initialized
INFO - 2017-01-16 09:28:14 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:14 --> Input Class Initialized
INFO - 2017-01-16 09:28:14 --> Output Class Initialized
INFO - 2017-01-16 09:28:14 --> Language Class Initialized
INFO - 2017-01-16 09:28:14 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:14 --> Input Class Initialized
INFO - 2017-01-16 09:28:14 --> Loader Class Initialized
INFO - 2017-01-16 09:28:14 --> Language Class Initialized
INFO - 2017-01-16 09:28:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:14 --> Loader Class Initialized
INFO - 2017-01-16 09:28:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:14 --> Controller Class Initialized
INFO - 2017-01-16 09:28:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:14 --> Model Class Initialized
INFO - 2017-01-16 09:28:14 --> Model Class Initialized
INFO - 2017-01-16 09:28:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:14 --> Total execution time: 0.0853
INFO - 2017-01-16 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:14 --> Controller Class Initialized
INFO - 2017-01-16 09:28:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:14 --> Model Class Initialized
INFO - 2017-01-16 09:28:14 --> Model Class Initialized
INFO - 2017-01-16 09:28:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:14 --> Total execution time: 0.1119
INFO - 2017-01-16 09:28:16 --> Config Class Initialized
INFO - 2017-01-16 09:28:16 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:16 --> Config Class Initialized
INFO - 2017-01-16 09:28:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:16 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:16 --> URI Class Initialized
INFO - 2017-01-16 09:28:16 --> URI Class Initialized
INFO - 2017-01-16 09:28:16 --> Router Class Initialized
INFO - 2017-01-16 09:28:16 --> Router Class Initialized
INFO - 2017-01-16 09:28:16 --> Output Class Initialized
INFO - 2017-01-16 09:28:16 --> Output Class Initialized
INFO - 2017-01-16 09:28:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:16 --> Security Class Initialized
INFO - 2017-01-16 09:28:16 --> Input Class Initialized
INFO - 2017-01-16 09:28:16 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:16 --> Input Class Initialized
INFO - 2017-01-16 09:28:16 --> Language Class Initialized
INFO - 2017-01-16 09:28:16 --> Loader Class Initialized
INFO - 2017-01-16 09:28:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:16 --> Loader Class Initialized
INFO - 2017-01-16 09:28:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:16 --> Controller Class Initialized
INFO - 2017-01-16 09:28:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:16 --> Model Class Initialized
INFO - 2017-01-16 09:28:16 --> Model Class Initialized
INFO - 2017-01-16 09:28:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:16 --> Total execution time: 0.0777
INFO - 2017-01-16 09:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:16 --> Controller Class Initialized
INFO - 2017-01-16 09:28:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:16 --> Model Class Initialized
INFO - 2017-01-16 09:28:16 --> Model Class Initialized
INFO - 2017-01-16 09:28:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:16 --> Total execution time: 0.1135
INFO - 2017-01-16 09:28:17 --> Config Class Initialized
INFO - 2017-01-16 09:28:17 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:17 --> Config Class Initialized
INFO - 2017-01-16 09:28:17 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:17 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:17 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:17 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:17 --> Router Class Initialized
INFO - 2017-01-16 09:28:17 --> URI Class Initialized
INFO - 2017-01-16 09:28:17 --> Output Class Initialized
INFO - 2017-01-16 09:28:17 --> Router Class Initialized
INFO - 2017-01-16 09:28:17 --> Security Class Initialized
INFO - 2017-01-16 09:28:17 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:17 --> Input Class Initialized
INFO - 2017-01-16 09:28:17 --> Security Class Initialized
INFO - 2017-01-16 09:28:17 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:17 --> Input Class Initialized
INFO - 2017-01-16 09:28:17 --> Language Class Initialized
INFO - 2017-01-16 09:28:17 --> Loader Class Initialized
INFO - 2017-01-16 09:28:17 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:17 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:17 --> Loader Class Initialized
INFO - 2017-01-16 09:28:17 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:17 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:17 --> Controller Class Initialized
INFO - 2017-01-16 09:28:17 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:17 --> Model Class Initialized
INFO - 2017-01-16 09:28:17 --> Model Class Initialized
INFO - 2017-01-16 09:28:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:17 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:17 --> Total execution time: 0.0891
INFO - 2017-01-16 09:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:17 --> Controller Class Initialized
INFO - 2017-01-16 09:28:17 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:17 --> Model Class Initialized
INFO - 2017-01-16 09:28:17 --> Model Class Initialized
INFO - 2017-01-16 09:28:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:17 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:17 --> Total execution time: 0.1504
INFO - 2017-01-16 09:28:19 --> Config Class Initialized
INFO - 2017-01-16 09:28:19 --> Config Class Initialized
INFO - 2017-01-16 09:28:19 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:28:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:19 --> URI Class Initialized
INFO - 2017-01-16 09:28:19 --> URI Class Initialized
INFO - 2017-01-16 09:28:19 --> Router Class Initialized
INFO - 2017-01-16 09:28:19 --> Router Class Initialized
INFO - 2017-01-16 09:28:19 --> Output Class Initialized
INFO - 2017-01-16 09:28:19 --> Output Class Initialized
INFO - 2017-01-16 09:28:19 --> Security Class Initialized
INFO - 2017-01-16 09:28:19 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:19 --> Input Class Initialized
INFO - 2017-01-16 09:28:19 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:19 --> Input Class Initialized
INFO - 2017-01-16 09:28:19 --> Language Class Initialized
INFO - 2017-01-16 09:28:19 --> Loader Class Initialized
INFO - 2017-01-16 09:28:19 --> Loader Class Initialized
INFO - 2017-01-16 09:28:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:19 --> Controller Class Initialized
INFO - 2017-01-16 09:28:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:19 --> Model Class Initialized
INFO - 2017-01-16 09:28:19 --> Model Class Initialized
INFO - 2017-01-16 09:28:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:19 --> Total execution time: 0.0841
INFO - 2017-01-16 09:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:19 --> Controller Class Initialized
INFO - 2017-01-16 09:28:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:19 --> Model Class Initialized
INFO - 2017-01-16 09:28:19 --> Model Class Initialized
INFO - 2017-01-16 09:28:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:19 --> Total execution time: 0.1379
INFO - 2017-01-16 09:28:20 --> Config Class Initialized
INFO - 2017-01-16 09:28:20 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:20 --> Config Class Initialized
INFO - 2017-01-16 09:28:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:20 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:20 --> URI Class Initialized
INFO - 2017-01-16 09:28:20 --> URI Class Initialized
INFO - 2017-01-16 09:28:20 --> Router Class Initialized
INFO - 2017-01-16 09:28:20 --> Router Class Initialized
INFO - 2017-01-16 09:28:20 --> Output Class Initialized
INFO - 2017-01-16 09:28:20 --> Security Class Initialized
INFO - 2017-01-16 09:28:20 --> Output Class Initialized
INFO - 2017-01-16 09:28:20 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:20 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:20 --> Language Class Initialized
INFO - 2017-01-16 09:28:20 --> Input Class Initialized
INFO - 2017-01-16 09:28:20 --> Language Class Initialized
INFO - 2017-01-16 09:28:20 --> Loader Class Initialized
INFO - 2017-01-16 09:28:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:20 --> Loader Class Initialized
INFO - 2017-01-16 09:28:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:20 --> Controller Class Initialized
INFO - 2017-01-16 09:28:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:20 --> Model Class Initialized
INFO - 2017-01-16 09:28:20 --> Model Class Initialized
INFO - 2017-01-16 09:28:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:20 --> Total execution time: 0.1381
INFO - 2017-01-16 09:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:20 --> Controller Class Initialized
INFO - 2017-01-16 09:28:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:20 --> Model Class Initialized
INFO - 2017-01-16 09:28:20 --> Model Class Initialized
INFO - 2017-01-16 09:28:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:20 --> Total execution time: 0.1706
INFO - 2017-01-16 09:28:22 --> Config Class Initialized
INFO - 2017-01-16 09:28:22 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:22 --> Config Class Initialized
INFO - 2017-01-16 09:28:22 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:22 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:22 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:22 --> URI Class Initialized
INFO - 2017-01-16 09:28:22 --> URI Class Initialized
INFO - 2017-01-16 09:28:22 --> Router Class Initialized
INFO - 2017-01-16 09:28:22 --> Router Class Initialized
INFO - 2017-01-16 09:28:22 --> Output Class Initialized
INFO - 2017-01-16 09:28:22 --> Output Class Initialized
INFO - 2017-01-16 09:28:22 --> Security Class Initialized
INFO - 2017-01-16 09:28:22 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:22 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:22 --> Input Class Initialized
INFO - 2017-01-16 09:28:22 --> Language Class Initialized
INFO - 2017-01-16 09:28:22 --> Language Class Initialized
INFO - 2017-01-16 09:28:22 --> Loader Class Initialized
INFO - 2017-01-16 09:28:22 --> Loader Class Initialized
INFO - 2017-01-16 09:28:22 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:22 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:22 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:22 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:22 --> Controller Class Initialized
INFO - 2017-01-16 09:28:22 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:22 --> Model Class Initialized
INFO - 2017-01-16 09:28:22 --> Model Class Initialized
INFO - 2017-01-16 09:28:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:22 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:22 --> Total execution time: 0.1114
INFO - 2017-01-16 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:22 --> Controller Class Initialized
INFO - 2017-01-16 09:28:22 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:22 --> Model Class Initialized
INFO - 2017-01-16 09:28:22 --> Model Class Initialized
INFO - 2017-01-16 09:28:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:22 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:22 --> Total execution time: 0.1382
INFO - 2017-01-16 09:28:24 --> Config Class Initialized
INFO - 2017-01-16 09:28:24 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:24 --> Config Class Initialized
INFO - 2017-01-16 09:28:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:24 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:24 --> Router Class Initialized
INFO - 2017-01-16 09:28:24 --> URI Class Initialized
INFO - 2017-01-16 09:28:24 --> Output Class Initialized
INFO - 2017-01-16 09:28:24 --> Router Class Initialized
INFO - 2017-01-16 09:28:24 --> Security Class Initialized
INFO - 2017-01-16 09:28:24 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:24 --> Input Class Initialized
INFO - 2017-01-16 09:28:24 --> Language Class Initialized
INFO - 2017-01-16 09:28:24 --> Security Class Initialized
INFO - 2017-01-16 09:28:24 --> Loader Class Initialized
DEBUG - 2017-01-16 09:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:24 --> Input Class Initialized
INFO - 2017-01-16 09:28:24 --> Language Class Initialized
INFO - 2017-01-16 09:28:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:24 --> Loader Class Initialized
INFO - 2017-01-16 09:28:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:24 --> Controller Class Initialized
INFO - 2017-01-16 09:28:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:24 --> Model Class Initialized
INFO - 2017-01-16 09:28:24 --> Model Class Initialized
INFO - 2017-01-16 09:28:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:24 --> Total execution time: 0.0716
INFO - 2017-01-16 09:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:24 --> Controller Class Initialized
INFO - 2017-01-16 09:28:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:24 --> Model Class Initialized
INFO - 2017-01-16 09:28:24 --> Model Class Initialized
INFO - 2017-01-16 09:28:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:24 --> Total execution time: 0.1392
INFO - 2017-01-16 09:28:25 --> Config Class Initialized
INFO - 2017-01-16 09:28:25 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:25 --> Config Class Initialized
INFO - 2017-01-16 09:28:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:25 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:25 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:25 --> URI Class Initialized
INFO - 2017-01-16 09:28:25 --> URI Class Initialized
INFO - 2017-01-16 09:28:25 --> Router Class Initialized
INFO - 2017-01-16 09:28:25 --> Router Class Initialized
INFO - 2017-01-16 09:28:25 --> Output Class Initialized
INFO - 2017-01-16 09:28:25 --> Output Class Initialized
INFO - 2017-01-16 09:28:25 --> Security Class Initialized
INFO - 2017-01-16 09:28:25 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:25 --> Input Class Initialized
INFO - 2017-01-16 09:28:25 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:25 --> Input Class Initialized
INFO - 2017-01-16 09:28:25 --> Language Class Initialized
INFO - 2017-01-16 09:28:25 --> Loader Class Initialized
INFO - 2017-01-16 09:28:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:25 --> Loader Class Initialized
INFO - 2017-01-16 09:28:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:25 --> Controller Class Initialized
INFO - 2017-01-16 09:28:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:25 --> Model Class Initialized
INFO - 2017-01-16 09:28:25 --> Model Class Initialized
INFO - 2017-01-16 09:28:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:25 --> Total execution time: 0.0751
INFO - 2017-01-16 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:25 --> Controller Class Initialized
INFO - 2017-01-16 09:28:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:25 --> Model Class Initialized
INFO - 2017-01-16 09:28:25 --> Model Class Initialized
INFO - 2017-01-16 09:28:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:25 --> Total execution time: 0.1378
INFO - 2017-01-16 09:28:27 --> Config Class Initialized
INFO - 2017-01-16 09:28:27 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:27 --> Config Class Initialized
INFO - 2017-01-16 09:28:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:27 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:27 --> URI Class Initialized
INFO - 2017-01-16 09:28:27 --> URI Class Initialized
INFO - 2017-01-16 09:28:27 --> Router Class Initialized
INFO - 2017-01-16 09:28:27 --> Router Class Initialized
INFO - 2017-01-16 09:28:27 --> Output Class Initialized
INFO - 2017-01-16 09:28:27 --> Output Class Initialized
INFO - 2017-01-16 09:28:27 --> Security Class Initialized
INFO - 2017-01-16 09:28:27 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:27 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:27 --> Input Class Initialized
INFO - 2017-01-16 09:28:27 --> Language Class Initialized
INFO - 2017-01-16 09:28:27 --> Language Class Initialized
INFO - 2017-01-16 09:28:27 --> Loader Class Initialized
INFO - 2017-01-16 09:28:27 --> Loader Class Initialized
INFO - 2017-01-16 09:28:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:27 --> Controller Class Initialized
INFO - 2017-01-16 09:28:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:27 --> Model Class Initialized
INFO - 2017-01-16 09:28:27 --> Model Class Initialized
INFO - 2017-01-16 09:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:27 --> Total execution time: 0.1437
INFO - 2017-01-16 09:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:27 --> Controller Class Initialized
INFO - 2017-01-16 09:28:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:27 --> Model Class Initialized
INFO - 2017-01-16 09:28:27 --> Model Class Initialized
INFO - 2017-01-16 09:28:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:27 --> Total execution time: 0.1720
INFO - 2017-01-16 09:28:28 --> Config Class Initialized
INFO - 2017-01-16 09:28:28 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:28 --> Config Class Initialized
INFO - 2017-01-16 09:28:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:28 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:28 --> URI Class Initialized
INFO - 2017-01-16 09:28:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:28 --> URI Class Initialized
INFO - 2017-01-16 09:28:28 --> Router Class Initialized
INFO - 2017-01-16 09:28:28 --> Router Class Initialized
INFO - 2017-01-16 09:28:28 --> Output Class Initialized
INFO - 2017-01-16 09:28:28 --> Output Class Initialized
INFO - 2017-01-16 09:28:28 --> Security Class Initialized
INFO - 2017-01-16 09:28:28 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:28 --> Input Class Initialized
INFO - 2017-01-16 09:28:28 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:28 --> Input Class Initialized
INFO - 2017-01-16 09:28:28 --> Language Class Initialized
INFO - 2017-01-16 09:28:28 --> Loader Class Initialized
INFO - 2017-01-16 09:28:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:28 --> Loader Class Initialized
INFO - 2017-01-16 09:28:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:28 --> Controller Class Initialized
INFO - 2017-01-16 09:28:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:28 --> Model Class Initialized
INFO - 2017-01-16 09:28:28 --> Model Class Initialized
INFO - 2017-01-16 09:28:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:28 --> Total execution time: 0.0734
INFO - 2017-01-16 09:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:28 --> Controller Class Initialized
INFO - 2017-01-16 09:28:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:28 --> Model Class Initialized
INFO - 2017-01-16 09:28:28 --> Model Class Initialized
INFO - 2017-01-16 09:28:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:28 --> Total execution time: 0.1669
INFO - 2017-01-16 09:28:30 --> Config Class Initialized
INFO - 2017-01-16 09:28:30 --> Config Class Initialized
INFO - 2017-01-16 09:28:30 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:30 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:28:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:30 --> URI Class Initialized
INFO - 2017-01-16 09:28:30 --> URI Class Initialized
INFO - 2017-01-16 09:28:30 --> Router Class Initialized
INFO - 2017-01-16 09:28:30 --> Router Class Initialized
INFO - 2017-01-16 09:28:30 --> Output Class Initialized
INFO - 2017-01-16 09:28:30 --> Output Class Initialized
INFO - 2017-01-16 09:28:30 --> Security Class Initialized
INFO - 2017-01-16 09:28:30 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:30 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:30 --> Input Class Initialized
INFO - 2017-01-16 09:28:30 --> Language Class Initialized
INFO - 2017-01-16 09:28:30 --> Language Class Initialized
INFO - 2017-01-16 09:28:30 --> Loader Class Initialized
INFO - 2017-01-16 09:28:30 --> Loader Class Initialized
INFO - 2017-01-16 09:28:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:30 --> Controller Class Initialized
INFO - 2017-01-16 09:28:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:30 --> Model Class Initialized
INFO - 2017-01-16 09:28:30 --> Model Class Initialized
INFO - 2017-01-16 09:28:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:30 --> Total execution time: 0.0718
INFO - 2017-01-16 09:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:30 --> Controller Class Initialized
INFO - 2017-01-16 09:28:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:30 --> Model Class Initialized
INFO - 2017-01-16 09:28:30 --> Model Class Initialized
INFO - 2017-01-16 09:28:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:30 --> Total execution time: 0.1666
INFO - 2017-01-16 09:28:32 --> Config Class Initialized
INFO - 2017-01-16 09:28:32 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:32 --> Config Class Initialized
INFO - 2017-01-16 09:28:32 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:32 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:32 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:32 --> URI Class Initialized
INFO - 2017-01-16 09:28:32 --> URI Class Initialized
INFO - 2017-01-16 09:28:32 --> Router Class Initialized
INFO - 2017-01-16 09:28:32 --> Router Class Initialized
INFO - 2017-01-16 09:28:32 --> Output Class Initialized
INFO - 2017-01-16 09:28:32 --> Security Class Initialized
INFO - 2017-01-16 09:28:32 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:32 --> Input Class Initialized
INFO - 2017-01-16 09:28:32 --> Security Class Initialized
INFO - 2017-01-16 09:28:32 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:32 --> Input Class Initialized
INFO - 2017-01-16 09:28:32 --> Language Class Initialized
INFO - 2017-01-16 09:28:32 --> Loader Class Initialized
INFO - 2017-01-16 09:28:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:32 --> Loader Class Initialized
INFO - 2017-01-16 09:28:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:32 --> Controller Class Initialized
INFO - 2017-01-16 09:28:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:32 --> Model Class Initialized
INFO - 2017-01-16 09:28:32 --> Model Class Initialized
INFO - 2017-01-16 09:28:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:32 --> Total execution time: 0.0732
INFO - 2017-01-16 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:32 --> Controller Class Initialized
INFO - 2017-01-16 09:28:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:32 --> Model Class Initialized
INFO - 2017-01-16 09:28:32 --> Model Class Initialized
INFO - 2017-01-16 09:28:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:32 --> Total execution time: 0.1627
INFO - 2017-01-16 09:28:33 --> Config Class Initialized
INFO - 2017-01-16 09:28:33 --> Config Class Initialized
INFO - 2017-01-16 09:28:33 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:33 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:33 --> URI Class Initialized
INFO - 2017-01-16 09:28:33 --> URI Class Initialized
INFO - 2017-01-16 09:28:33 --> Router Class Initialized
INFO - 2017-01-16 09:28:33 --> Router Class Initialized
INFO - 2017-01-16 09:28:33 --> Output Class Initialized
INFO - 2017-01-16 09:28:33 --> Output Class Initialized
INFO - 2017-01-16 09:28:33 --> Security Class Initialized
INFO - 2017-01-16 09:28:33 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:33 --> Input Class Initialized
INFO - 2017-01-16 09:28:33 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:33 --> Input Class Initialized
INFO - 2017-01-16 09:28:33 --> Language Class Initialized
INFO - 2017-01-16 09:28:33 --> Loader Class Initialized
INFO - 2017-01-16 09:28:33 --> Loader Class Initialized
INFO - 2017-01-16 09:28:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:33 --> Controller Class Initialized
INFO - 2017-01-16 09:28:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:33 --> Model Class Initialized
INFO - 2017-01-16 09:28:33 --> Model Class Initialized
INFO - 2017-01-16 09:28:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:34 --> Total execution time: 0.1494
INFO - 2017-01-16 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:34 --> Controller Class Initialized
INFO - 2017-01-16 09:28:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:34 --> Model Class Initialized
INFO - 2017-01-16 09:28:34 --> Model Class Initialized
INFO - 2017-01-16 09:28:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:34 --> Total execution time: 0.1784
INFO - 2017-01-16 09:28:35 --> Config Class Initialized
INFO - 2017-01-16 09:28:35 --> Config Class Initialized
INFO - 2017-01-16 09:28:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:35 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:28:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:35 --> URI Class Initialized
INFO - 2017-01-16 09:28:35 --> URI Class Initialized
INFO - 2017-01-16 09:28:35 --> Router Class Initialized
INFO - 2017-01-16 09:28:35 --> Router Class Initialized
INFO - 2017-01-16 09:28:35 --> Output Class Initialized
INFO - 2017-01-16 09:28:35 --> Output Class Initialized
INFO - 2017-01-16 09:28:35 --> Security Class Initialized
INFO - 2017-01-16 09:28:35 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:35 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:35 --> Input Class Initialized
INFO - 2017-01-16 09:28:35 --> Language Class Initialized
INFO - 2017-01-16 09:28:35 --> Language Class Initialized
INFO - 2017-01-16 09:28:35 --> Loader Class Initialized
INFO - 2017-01-16 09:28:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:35 --> Loader Class Initialized
INFO - 2017-01-16 09:28:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:35 --> Controller Class Initialized
INFO - 2017-01-16 09:28:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:35 --> Model Class Initialized
INFO - 2017-01-16 09:28:35 --> Model Class Initialized
INFO - 2017-01-16 09:28:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:35 --> Total execution time: 0.0771
INFO - 2017-01-16 09:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:35 --> Controller Class Initialized
INFO - 2017-01-16 09:28:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:35 --> Model Class Initialized
INFO - 2017-01-16 09:28:35 --> Model Class Initialized
INFO - 2017-01-16 09:28:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:35 --> Total execution time: 0.2062
INFO - 2017-01-16 09:28:37 --> Config Class Initialized
INFO - 2017-01-16 09:28:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:37 --> URI Class Initialized
INFO - 2017-01-16 09:28:37 --> Router Class Initialized
INFO - 2017-01-16 09:28:37 --> Output Class Initialized
INFO - 2017-01-16 09:28:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:37 --> Input Class Initialized
INFO - 2017-01-16 09:28:37 --> Language Class Initialized
INFO - 2017-01-16 09:28:37 --> Loader Class Initialized
INFO - 2017-01-16 09:28:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:37 --> Controller Class Initialized
INFO - 2017-01-16 09:28:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:37 --> Model Class Initialized
INFO - 2017-01-16 09:28:37 --> Model Class Initialized
INFO - 2017-01-16 09:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:37 --> Total execution time: 0.1683
INFO - 2017-01-16 09:28:37 --> Config Class Initialized
INFO - 2017-01-16 09:28:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:37 --> URI Class Initialized
INFO - 2017-01-16 09:28:37 --> Config Class Initialized
INFO - 2017-01-16 09:28:37 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:37 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:37 --> Output Class Initialized
INFO - 2017-01-16 09:28:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:37 --> URI Class Initialized
INFO - 2017-01-16 09:28:37 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:37 --> Input Class Initialized
INFO - 2017-01-16 09:28:37 --> Router Class Initialized
INFO - 2017-01-16 09:28:37 --> Language Class Initialized
INFO - 2017-01-16 09:28:37 --> Output Class Initialized
INFO - 2017-01-16 09:28:37 --> Security Class Initialized
INFO - 2017-01-16 09:28:37 --> Loader Class Initialized
INFO - 2017-01-16 09:28:37 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:37 --> Input Class Initialized
INFO - 2017-01-16 09:28:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:37 --> Language Class Initialized
INFO - 2017-01-16 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:37 --> Loader Class Initialized
INFO - 2017-01-16 09:28:37 --> Controller Class Initialized
INFO - 2017-01-16 09:28:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:37 --> Model Class Initialized
INFO - 2017-01-16 09:28:37 --> Model Class Initialized
INFO - 2017-01-16 09:28:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:37 --> Total execution time: 0.0705
INFO - 2017-01-16 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:37 --> Controller Class Initialized
INFO - 2017-01-16 09:28:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:37 --> Model Class Initialized
INFO - 2017-01-16 09:28:38 --> Model Class Initialized
INFO - 2017-01-16 09:28:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:38 --> Total execution time: 0.1634
INFO - 2017-01-16 09:28:39 --> Config Class Initialized
INFO - 2017-01-16 09:28:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:39 --> Config Class Initialized
INFO - 2017-01-16 09:28:39 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:39 --> URI Class Initialized
INFO - 2017-01-16 09:28:39 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:39 --> Output Class Initialized
INFO - 2017-01-16 09:28:39 --> URI Class Initialized
INFO - 2017-01-16 09:28:39 --> Security Class Initialized
INFO - 2017-01-16 09:28:39 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:39 --> Input Class Initialized
INFO - 2017-01-16 09:28:39 --> Language Class Initialized
INFO - 2017-01-16 09:28:39 --> Output Class Initialized
INFO - 2017-01-16 09:28:39 --> Security Class Initialized
INFO - 2017-01-16 09:28:39 --> Loader Class Initialized
DEBUG - 2017-01-16 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:39 --> Input Class Initialized
INFO - 2017-01-16 09:28:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:39 --> Language Class Initialized
INFO - 2017-01-16 09:28:39 --> Loader Class Initialized
INFO - 2017-01-16 09:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:39 --> Controller Class Initialized
INFO - 2017-01-16 09:28:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:39 --> Model Class Initialized
INFO - 2017-01-16 09:28:39 --> Model Class Initialized
INFO - 2017-01-16 09:28:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:39 --> Total execution time: 0.0831
INFO - 2017-01-16 09:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:39 --> Controller Class Initialized
INFO - 2017-01-16 09:28:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:39 --> Model Class Initialized
INFO - 2017-01-16 09:28:39 --> Model Class Initialized
INFO - 2017-01-16 09:28:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:39 --> Total execution time: 0.1992
INFO - 2017-01-16 09:28:41 --> Config Class Initialized
INFO - 2017-01-16 09:28:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:41 --> Config Class Initialized
DEBUG - 2017-01-16 09:28:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:41 --> URI Class Initialized
INFO - 2017-01-16 09:28:41 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:41 --> Output Class Initialized
INFO - 2017-01-16 09:28:41 --> URI Class Initialized
INFO - 2017-01-16 09:28:41 --> Security Class Initialized
INFO - 2017-01-16 09:28:41 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:41 --> Input Class Initialized
INFO - 2017-01-16 09:28:41 --> Output Class Initialized
INFO - 2017-01-16 09:28:41 --> Language Class Initialized
INFO - 2017-01-16 09:28:41 --> Security Class Initialized
INFO - 2017-01-16 09:28:41 --> Loader Class Initialized
DEBUG - 2017-01-16 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:41 --> Input Class Initialized
INFO - 2017-01-16 09:28:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:41 --> Language Class Initialized
INFO - 2017-01-16 09:28:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:41 --> Loader Class Initialized
INFO - 2017-01-16 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:41 --> Controller Class Initialized
INFO - 2017-01-16 09:28:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:41 --> Model Class Initialized
INFO - 2017-01-16 09:28:41 --> Model Class Initialized
INFO - 2017-01-16 09:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:41 --> Total execution time: 0.0676
INFO - 2017-01-16 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:41 --> Controller Class Initialized
INFO - 2017-01-16 09:28:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:41 --> Model Class Initialized
INFO - 2017-01-16 09:28:41 --> Model Class Initialized
INFO - 2017-01-16 09:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:41 --> Total execution time: 0.1803
INFO - 2017-01-16 09:28:42 --> Config Class Initialized
INFO - 2017-01-16 09:28:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:42 --> URI Class Initialized
INFO - 2017-01-16 09:28:42 --> Router Class Initialized
INFO - 2017-01-16 09:28:42 --> Output Class Initialized
INFO - 2017-01-16 09:28:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:42 --> Input Class Initialized
INFO - 2017-01-16 09:28:42 --> Language Class Initialized
INFO - 2017-01-16 09:28:42 --> Loader Class Initialized
INFO - 2017-01-16 09:28:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:42 --> Controller Class Initialized
INFO - 2017-01-16 09:28:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:42 --> Model Class Initialized
INFO - 2017-01-16 09:28:42 --> Model Class Initialized
INFO - 2017-01-16 09:28:42 --> Model Class Initialized
INFO - 2017-01-16 09:28:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:42 --> Total execution time: 0.0783
INFO - 2017-01-16 09:28:43 --> Config Class Initialized
INFO - 2017-01-16 09:28:43 --> Config Class Initialized
INFO - 2017-01-16 09:28:43 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:43 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:28:43 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:43 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:43 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:43 --> URI Class Initialized
INFO - 2017-01-16 09:28:43 --> URI Class Initialized
INFO - 2017-01-16 09:28:43 --> Router Class Initialized
INFO - 2017-01-16 09:28:43 --> Router Class Initialized
INFO - 2017-01-16 09:28:43 --> Output Class Initialized
INFO - 2017-01-16 09:28:43 --> Output Class Initialized
INFO - 2017-01-16 09:28:43 --> Security Class Initialized
INFO - 2017-01-16 09:28:43 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:43 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:43 --> Language Class Initialized
INFO - 2017-01-16 09:28:43 --> Input Class Initialized
INFO - 2017-01-16 09:28:43 --> Language Class Initialized
INFO - 2017-01-16 09:28:43 --> Loader Class Initialized
INFO - 2017-01-16 09:28:43 --> Loader Class Initialized
INFO - 2017-01-16 09:28:43 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:43 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:43 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:43 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:43 --> Controller Class Initialized
INFO - 2017-01-16 09:28:43 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:43 --> Model Class Initialized
INFO - 2017-01-16 09:28:43 --> Model Class Initialized
INFO - 2017-01-16 09:28:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:43 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:43 --> Total execution time: 0.0684
INFO - 2017-01-16 09:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:43 --> Controller Class Initialized
INFO - 2017-01-16 09:28:43 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:43 --> Model Class Initialized
INFO - 2017-01-16 09:28:43 --> Model Class Initialized
INFO - 2017-01-16 09:28:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:43 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:43 --> Total execution time: 0.1884
INFO - 2017-01-16 09:28:45 --> Config Class Initialized
INFO - 2017-01-16 09:28:45 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:45 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:45 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:45 --> Config Class Initialized
INFO - 2017-01-16 09:28:45 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:45 --> URI Class Initialized
INFO - 2017-01-16 09:28:45 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:45 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:45 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:45 --> Output Class Initialized
INFO - 2017-01-16 09:28:45 --> URI Class Initialized
INFO - 2017-01-16 09:28:45 --> Security Class Initialized
INFO - 2017-01-16 09:28:45 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:45 --> Input Class Initialized
INFO - 2017-01-16 09:28:45 --> Language Class Initialized
INFO - 2017-01-16 09:28:45 --> Output Class Initialized
INFO - 2017-01-16 09:28:45 --> Security Class Initialized
INFO - 2017-01-16 09:28:45 --> Loader Class Initialized
INFO - 2017-01-16 09:28:45 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:45 --> Input Class Initialized
INFO - 2017-01-16 09:28:45 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:45 --> Language Class Initialized
INFO - 2017-01-16 09:28:45 --> Loader Class Initialized
INFO - 2017-01-16 09:28:45 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:45 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:45 --> Controller Class Initialized
INFO - 2017-01-16 09:28:45 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:45 --> Model Class Initialized
INFO - 2017-01-16 09:28:45 --> Model Class Initialized
INFO - 2017-01-16 09:28:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:45 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:45 --> Total execution time: 0.0742
INFO - 2017-01-16 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:45 --> Controller Class Initialized
INFO - 2017-01-16 09:28:45 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:45 --> Model Class Initialized
INFO - 2017-01-16 09:28:45 --> Model Class Initialized
INFO - 2017-01-16 09:28:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:45 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:45 --> Total execution time: 0.2102
INFO - 2017-01-16 09:28:47 --> Config Class Initialized
INFO - 2017-01-16 09:28:47 --> Config Class Initialized
INFO - 2017-01-16 09:28:47 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:47 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:28:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:47 --> URI Class Initialized
INFO - 2017-01-16 09:28:47 --> URI Class Initialized
INFO - 2017-01-16 09:28:47 --> Router Class Initialized
INFO - 2017-01-16 09:28:47 --> Router Class Initialized
INFO - 2017-01-16 09:28:47 --> Config Class Initialized
INFO - 2017-01-16 09:28:47 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:47 --> Output Class Initialized
INFO - 2017-01-16 09:28:47 --> Output Class Initialized
INFO - 2017-01-16 09:28:47 --> Security Class Initialized
INFO - 2017-01-16 09:28:47 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:47 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:47 --> Input Class Initialized
INFO - 2017-01-16 09:28:47 --> URI Class Initialized
INFO - 2017-01-16 09:28:47 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:47 --> Input Class Initialized
INFO - 2017-01-16 09:28:47 --> Router Class Initialized
INFO - 2017-01-16 09:28:47 --> Language Class Initialized
INFO - 2017-01-16 09:28:47 --> Output Class Initialized
INFO - 2017-01-16 09:28:47 --> Loader Class Initialized
INFO - 2017-01-16 09:28:47 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:47 --> Input Class Initialized
INFO - 2017-01-16 09:28:47 --> Loader Class Initialized
INFO - 2017-01-16 09:28:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:47 --> Language Class Initialized
INFO - 2017-01-16 09:28:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:47 --> Loader Class Initialized
INFO - 2017-01-16 09:28:47 --> Controller Class Initialized
INFO - 2017-01-16 09:28:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:47 --> Total execution time: 0.0899
INFO - 2017-01-16 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:47 --> Controller Class Initialized
INFO - 2017-01-16 09:28:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:47 --> Total execution time: 0.2544
INFO - 2017-01-16 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:47 --> Controller Class Initialized
INFO - 2017-01-16 09:28:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:47 --> Config Class Initialized
INFO - 2017-01-16 09:28:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:47 --> URI Class Initialized
INFO - 2017-01-16 09:28:47 --> Router Class Initialized
INFO - 2017-01-16 09:28:47 --> Output Class Initialized
INFO - 2017-01-16 09:28:47 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:47 --> Input Class Initialized
INFO - 2017-01-16 09:28:47 --> Language Class Initialized
INFO - 2017-01-16 09:28:47 --> Loader Class Initialized
INFO - 2017-01-16 09:28:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:47 --> Controller Class Initialized
INFO - 2017-01-16 09:28:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Model Class Initialized
INFO - 2017-01-16 09:28:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:28:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2017-01-16 09:28:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:28:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:47 --> Total execution time: 0.0782
INFO - 2017-01-16 09:28:49 --> Config Class Initialized
INFO - 2017-01-16 09:28:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:49 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:49 --> URI Class Initialized
INFO - 2017-01-16 09:28:49 --> Router Class Initialized
INFO - 2017-01-16 09:28:49 --> Output Class Initialized
INFO - 2017-01-16 09:28:49 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:49 --> Input Class Initialized
INFO - 2017-01-16 09:28:49 --> Language Class Initialized
INFO - 2017-01-16 09:28:49 --> Loader Class Initialized
INFO - 2017-01-16 09:28:49 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:49 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:49 --> Controller Class Initialized
INFO - 2017-01-16 09:28:49 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:49 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:50 --> Config Class Initialized
INFO - 2017-01-16 09:28:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:50 --> URI Class Initialized
INFO - 2017-01-16 09:28:50 --> Router Class Initialized
INFO - 2017-01-16 09:28:50 --> Output Class Initialized
INFO - 2017-01-16 09:28:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:50 --> Input Class Initialized
INFO - 2017-01-16 09:28:50 --> Language Class Initialized
INFO - 2017-01-16 09:28:50 --> Loader Class Initialized
INFO - 2017-01-16 09:28:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:50 --> Controller Class Initialized
INFO - 2017-01-16 09:28:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:28:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2017-01-16 09:28:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:28:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:50 --> Total execution time: 0.0723
INFO - 2017-01-16 09:28:50 --> Config Class Initialized
INFO - 2017-01-16 09:28:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:50 --> Config Class Initialized
INFO - 2017-01-16 09:28:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:50 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:50 --> Router Class Initialized
INFO - 2017-01-16 09:28:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:50 --> URI Class Initialized
INFO - 2017-01-16 09:28:50 --> Output Class Initialized
INFO - 2017-01-16 09:28:50 --> Security Class Initialized
INFO - 2017-01-16 09:28:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:50 --> Input Class Initialized
INFO - 2017-01-16 09:28:50 --> Output Class Initialized
INFO - 2017-01-16 09:28:50 --> Language Class Initialized
INFO - 2017-01-16 09:28:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:50 --> Input Class Initialized
INFO - 2017-01-16 09:28:50 --> Loader Class Initialized
INFO - 2017-01-16 09:28:50 --> Language Class Initialized
INFO - 2017-01-16 09:28:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:50 --> Loader Class Initialized
INFO - 2017-01-16 09:28:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:50 --> Controller Class Initialized
INFO - 2017-01-16 09:28:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:50 --> Total execution time: 0.0823
INFO - 2017-01-16 09:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:50 --> Controller Class Initialized
INFO - 2017-01-16 09:28:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Model Class Initialized
INFO - 2017-01-16 09:28:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:50 --> Total execution time: 0.1590
INFO - 2017-01-16 09:28:52 --> Config Class Initialized
INFO - 2017-01-16 09:28:52 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:52 --> Config Class Initialized
INFO - 2017-01-16 09:28:52 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:52 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:52 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:52 --> URI Class Initialized
INFO - 2017-01-16 09:28:52 --> URI Class Initialized
INFO - 2017-01-16 09:28:52 --> Router Class Initialized
INFO - 2017-01-16 09:28:52 --> Router Class Initialized
INFO - 2017-01-16 09:28:52 --> Output Class Initialized
INFO - 2017-01-16 09:28:52 --> Output Class Initialized
INFO - 2017-01-16 09:28:52 --> Security Class Initialized
INFO - 2017-01-16 09:28:52 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:52 --> Input Class Initialized
INFO - 2017-01-16 09:28:52 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:52 --> Input Class Initialized
INFO - 2017-01-16 09:28:52 --> Language Class Initialized
INFO - 2017-01-16 09:28:52 --> Loader Class Initialized
INFO - 2017-01-16 09:28:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:52 --> Loader Class Initialized
INFO - 2017-01-16 09:28:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:52 --> Controller Class Initialized
INFO - 2017-01-16 09:28:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:52 --> Model Class Initialized
INFO - 2017-01-16 09:28:52 --> Model Class Initialized
INFO - 2017-01-16 09:28:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:52 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:52 --> Total execution time: 0.0655
INFO - 2017-01-16 09:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:52 --> Controller Class Initialized
INFO - 2017-01-16 09:28:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:52 --> Model Class Initialized
INFO - 2017-01-16 09:28:52 --> Model Class Initialized
INFO - 2017-01-16 09:28:52 --> Model Class Initialized
INFO - 2017-01-16 09:28:52 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:28:52 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:52 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:28:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:53 --> Total execution time: 0.1786
INFO - 2017-01-16 09:28:54 --> Config Class Initialized
INFO - 2017-01-16 09:28:54 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:54 --> Config Class Initialized
INFO - 2017-01-16 09:28:54 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:54 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:54 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:54 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:54 --> Router Class Initialized
INFO - 2017-01-16 09:28:54 --> URI Class Initialized
INFO - 2017-01-16 09:28:54 --> Output Class Initialized
INFO - 2017-01-16 09:28:54 --> Router Class Initialized
INFO - 2017-01-16 09:28:54 --> Security Class Initialized
INFO - 2017-01-16 09:28:54 --> Output Class Initialized
INFO - 2017-01-16 09:28:54 --> Security Class Initialized
DEBUG - 2017-01-16 09:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:54 --> Input Class Initialized
DEBUG - 2017-01-16 09:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:54 --> Input Class Initialized
INFO - 2017-01-16 09:28:54 --> Language Class Initialized
INFO - 2017-01-16 09:28:54 --> Language Class Initialized
INFO - 2017-01-16 09:28:54 --> Loader Class Initialized
INFO - 2017-01-16 09:28:54 --> Loader Class Initialized
INFO - 2017-01-16 09:28:54 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:54 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:54 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:54 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:54 --> Controller Class Initialized
INFO - 2017-01-16 09:28:54 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:54 --> Model Class Initialized
INFO - 2017-01-16 09:28:54 --> Model Class Initialized
INFO - 2017-01-16 09:28:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:54 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:54 --> Total execution time: 0.0698
INFO - 2017-01-16 09:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:54 --> Controller Class Initialized
INFO - 2017-01-16 09:28:54 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:54 --> Model Class Initialized
INFO - 2017-01-16 09:28:54 --> Model Class Initialized
INFO - 2017-01-16 09:28:54 --> Model Class Initialized
INFO - 2017-01-16 09:28:54 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:28:54 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:28:54 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:54 --> Total execution time: 0.2149
INFO - 2017-01-16 09:28:56 --> Config Class Initialized
INFO - 2017-01-16 09:28:56 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:56 --> Config Class Initialized
INFO - 2017-01-16 09:28:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:56 --> URI Class Initialized
DEBUG - 2017-01-16 09:28:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:56 --> Router Class Initialized
INFO - 2017-01-16 09:28:56 --> URI Class Initialized
INFO - 2017-01-16 09:28:56 --> Output Class Initialized
INFO - 2017-01-16 09:28:56 --> Router Class Initialized
INFO - 2017-01-16 09:28:56 --> Security Class Initialized
INFO - 2017-01-16 09:28:56 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:56 --> Input Class Initialized
INFO - 2017-01-16 09:28:56 --> Security Class Initialized
INFO - 2017-01-16 09:28:56 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:56 --> Input Class Initialized
INFO - 2017-01-16 09:28:56 --> Loader Class Initialized
INFO - 2017-01-16 09:28:56 --> Language Class Initialized
INFO - 2017-01-16 09:28:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:56 --> Loader Class Initialized
INFO - 2017-01-16 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:56 --> Controller Class Initialized
INFO - 2017-01-16 09:28:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:56 --> Model Class Initialized
INFO - 2017-01-16 09:28:56 --> Model Class Initialized
INFO - 2017-01-16 09:28:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:56 --> Total execution time: 0.0740
INFO - 2017-01-16 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:56 --> Controller Class Initialized
INFO - 2017-01-16 09:28:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:56 --> Model Class Initialized
INFO - 2017-01-16 09:28:56 --> Model Class Initialized
INFO - 2017-01-16 09:28:56 --> Model Class Initialized
INFO - 2017-01-16 09:28:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:28:56 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:28:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:56 --> Total execution time: 0.2298
INFO - 2017-01-16 09:28:58 --> Config Class Initialized
INFO - 2017-01-16 09:28:58 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:58 --> Config Class Initialized
INFO - 2017-01-16 09:28:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:58 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:58 --> URI Class Initialized
INFO - 2017-01-16 09:28:58 --> URI Class Initialized
INFO - 2017-01-16 09:28:58 --> Router Class Initialized
INFO - 2017-01-16 09:28:58 --> Router Class Initialized
INFO - 2017-01-16 09:28:58 --> Output Class Initialized
INFO - 2017-01-16 09:28:58 --> Security Class Initialized
INFO - 2017-01-16 09:28:58 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:58 --> Input Class Initialized
INFO - 2017-01-16 09:28:58 --> Security Class Initialized
INFO - 2017-01-16 09:28:58 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:58 --> Input Class Initialized
INFO - 2017-01-16 09:28:58 --> Language Class Initialized
INFO - 2017-01-16 09:28:58 --> Loader Class Initialized
INFO - 2017-01-16 09:28:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:58 --> Loader Class Initialized
INFO - 2017-01-16 09:28:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:58 --> Controller Class Initialized
INFO - 2017-01-16 09:28:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:58 --> Model Class Initialized
INFO - 2017-01-16 09:28:58 --> Model Class Initialized
INFO - 2017-01-16 09:28:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:58 --> Total execution time: 0.0723
INFO - 2017-01-16 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:58 --> Controller Class Initialized
INFO - 2017-01-16 09:28:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:58 --> Model Class Initialized
INFO - 2017-01-16 09:28:58 --> Model Class Initialized
INFO - 2017-01-16 09:28:58 --> Model Class Initialized
INFO - 2017-01-16 09:28:58 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:28:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:58 --> Total execution time: 0.2222
INFO - 2017-01-16 09:28:59 --> Config Class Initialized
INFO - 2017-01-16 09:28:59 --> Hooks Class Initialized
INFO - 2017-01-16 09:28:59 --> Config Class Initialized
INFO - 2017-01-16 09:28:59 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:28:59 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:59 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:28:59 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:28:59 --> URI Class Initialized
INFO - 2017-01-16 09:28:59 --> Utf8 Class Initialized
INFO - 2017-01-16 09:28:59 --> URI Class Initialized
INFO - 2017-01-16 09:28:59 --> Router Class Initialized
INFO - 2017-01-16 09:28:59 --> Output Class Initialized
INFO - 2017-01-16 09:28:59 --> Router Class Initialized
INFO - 2017-01-16 09:28:59 --> Security Class Initialized
INFO - 2017-01-16 09:28:59 --> Output Class Initialized
DEBUG - 2017-01-16 09:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:59 --> Input Class Initialized
INFO - 2017-01-16 09:28:59 --> Security Class Initialized
INFO - 2017-01-16 09:28:59 --> Language Class Initialized
DEBUG - 2017-01-16 09:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:28:59 --> Input Class Initialized
INFO - 2017-01-16 09:28:59 --> Loader Class Initialized
INFO - 2017-01-16 09:28:59 --> Language Class Initialized
INFO - 2017-01-16 09:28:59 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:59 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:59 --> Loader Class Initialized
INFO - 2017-01-16 09:28:59 --> Helper loaded: url_helper
INFO - 2017-01-16 09:28:59 --> Helper loaded: language_helper
INFO - 2017-01-16 09:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:59 --> Controller Class Initialized
INFO - 2017-01-16 09:28:59 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:59 --> Model Class Initialized
INFO - 2017-01-16 09:28:59 --> Model Class Initialized
INFO - 2017-01-16 09:28:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:28:59 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:59 --> Total execution time: 0.0738
INFO - 2017-01-16 09:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:28:59 --> Controller Class Initialized
INFO - 2017-01-16 09:28:59 --> Database Driver Class Initialized
INFO - 2017-01-16 09:28:59 --> Model Class Initialized
INFO - 2017-01-16 09:28:59 --> Model Class Initialized
INFO - 2017-01-16 09:28:59 --> Model Class Initialized
INFO - 2017-01-16 09:28:59 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:28:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:28:59 --> Final output sent to browser
DEBUG - 2017-01-16 09:28:59 --> Total execution time: 0.2289
INFO - 2017-01-16 09:29:01 --> Config Class Initialized
INFO - 2017-01-16 09:29:01 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:01 --> Config Class Initialized
INFO - 2017-01-16 09:29:01 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:01 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:01 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:01 --> URI Class Initialized
INFO - 2017-01-16 09:29:01 --> URI Class Initialized
INFO - 2017-01-16 09:29:01 --> Router Class Initialized
INFO - 2017-01-16 09:29:01 --> Router Class Initialized
INFO - 2017-01-16 09:29:01 --> Output Class Initialized
INFO - 2017-01-16 09:29:01 --> Output Class Initialized
INFO - 2017-01-16 09:29:01 --> Security Class Initialized
INFO - 2017-01-16 09:29:01 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:01 --> Input Class Initialized
DEBUG - 2017-01-16 09:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:01 --> Language Class Initialized
INFO - 2017-01-16 09:29:01 --> Input Class Initialized
INFO - 2017-01-16 09:29:01 --> Language Class Initialized
INFO - 2017-01-16 09:29:01 --> Loader Class Initialized
INFO - 2017-01-16 09:29:01 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:01 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:01 --> Loader Class Initialized
INFO - 2017-01-16 09:29:01 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:01 --> Controller Class Initialized
INFO - 2017-01-16 09:29:01 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:01 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:01 --> Model Class Initialized
INFO - 2017-01-16 09:29:01 --> Model Class Initialized
INFO - 2017-01-16 09:29:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:01 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:01 --> Total execution time: 0.0703
INFO - 2017-01-16 09:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:01 --> Controller Class Initialized
INFO - 2017-01-16 09:29:01 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:01 --> Model Class Initialized
INFO - 2017-01-16 09:29:01 --> Model Class Initialized
INFO - 2017-01-16 09:29:01 --> Model Class Initialized
INFO - 2017-01-16 09:29:01 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:01 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:01 --> Total execution time: 0.2329
INFO - 2017-01-16 09:29:02 --> Config Class Initialized
INFO - 2017-01-16 09:29:02 --> Config Class Initialized
INFO - 2017-01-16 09:29:02 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:02 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:29:02 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:02 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:02 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:03 --> URI Class Initialized
INFO - 2017-01-16 09:29:03 --> URI Class Initialized
INFO - 2017-01-16 09:29:03 --> Router Class Initialized
INFO - 2017-01-16 09:29:03 --> Router Class Initialized
INFO - 2017-01-16 09:29:03 --> Output Class Initialized
INFO - 2017-01-16 09:29:03 --> Output Class Initialized
INFO - 2017-01-16 09:29:03 --> Security Class Initialized
INFO - 2017-01-16 09:29:03 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:03 --> Input Class Initialized
DEBUG - 2017-01-16 09:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:03 --> Language Class Initialized
INFO - 2017-01-16 09:29:03 --> Input Class Initialized
INFO - 2017-01-16 09:29:03 --> Language Class Initialized
INFO - 2017-01-16 09:29:03 --> Loader Class Initialized
INFO - 2017-01-16 09:29:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:03 --> Loader Class Initialized
INFO - 2017-01-16 09:29:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:03 --> Controller Class Initialized
INFO - 2017-01-16 09:29:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:03 --> Model Class Initialized
INFO - 2017-01-16 09:29:03 --> Model Class Initialized
INFO - 2017-01-16 09:29:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:03 --> Total execution time: 0.0765
INFO - 2017-01-16 09:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:03 --> Controller Class Initialized
INFO - 2017-01-16 09:29:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:03 --> Model Class Initialized
INFO - 2017-01-16 09:29:03 --> Model Class Initialized
INFO - 2017-01-16 09:29:03 --> Model Class Initialized
INFO - 2017-01-16 09:29:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:03 --> Total execution time: 0.2372
INFO - 2017-01-16 09:29:04 --> Config Class Initialized
INFO - 2017-01-16 09:29:04 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:04 --> Config Class Initialized
INFO - 2017-01-16 09:29:04 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:29:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:04 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:04 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:04 --> URI Class Initialized
INFO - 2017-01-16 09:29:04 --> URI Class Initialized
INFO - 2017-01-16 09:29:04 --> Router Class Initialized
INFO - 2017-01-16 09:29:04 --> Router Class Initialized
INFO - 2017-01-16 09:29:04 --> Output Class Initialized
INFO - 2017-01-16 09:29:04 --> Output Class Initialized
INFO - 2017-01-16 09:29:04 --> Security Class Initialized
INFO - 2017-01-16 09:29:04 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:04 --> Input Class Initialized
DEBUG - 2017-01-16 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:04 --> Language Class Initialized
INFO - 2017-01-16 09:29:04 --> Input Class Initialized
INFO - 2017-01-16 09:29:04 --> Language Class Initialized
INFO - 2017-01-16 09:29:04 --> Loader Class Initialized
INFO - 2017-01-16 09:29:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:04 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:04 --> Loader Class Initialized
INFO - 2017-01-16 09:29:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:04 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:04 --> Controller Class Initialized
INFO - 2017-01-16 09:29:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:04 --> Model Class Initialized
INFO - 2017-01-16 09:29:04 --> Model Class Initialized
INFO - 2017-01-16 09:29:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:04 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:04 --> Total execution time: 0.0720
INFO - 2017-01-16 09:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:04 --> Controller Class Initialized
INFO - 2017-01-16 09:29:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:04 --> Model Class Initialized
INFO - 2017-01-16 09:29:04 --> Model Class Initialized
INFO - 2017-01-16 09:29:04 --> Model Class Initialized
INFO - 2017-01-16 09:29:04 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:04 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:04 --> Total execution time: 0.2606
INFO - 2017-01-16 09:29:06 --> Config Class Initialized
INFO - 2017-01-16 09:29:06 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:06 --> Config Class Initialized
INFO - 2017-01-16 09:29:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:06 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:06 --> URI Class Initialized
INFO - 2017-01-16 09:29:06 --> URI Class Initialized
INFO - 2017-01-16 09:29:06 --> Router Class Initialized
INFO - 2017-01-16 09:29:06 --> Router Class Initialized
INFO - 2017-01-16 09:29:06 --> Output Class Initialized
INFO - 2017-01-16 09:29:06 --> Output Class Initialized
INFO - 2017-01-16 09:29:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:06 --> Input Class Initialized
INFO - 2017-01-16 09:29:06 --> Security Class Initialized
INFO - 2017-01-16 09:29:06 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:06 --> Input Class Initialized
INFO - 2017-01-16 09:29:06 --> Loader Class Initialized
INFO - 2017-01-16 09:29:06 --> Language Class Initialized
INFO - 2017-01-16 09:29:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:06 --> Loader Class Initialized
INFO - 2017-01-16 09:29:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:06 --> Controller Class Initialized
INFO - 2017-01-16 09:29:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:06 --> Model Class Initialized
INFO - 2017-01-16 09:29:06 --> Model Class Initialized
INFO - 2017-01-16 09:29:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:06 --> Total execution time: 0.0724
INFO - 2017-01-16 09:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:06 --> Controller Class Initialized
INFO - 2017-01-16 09:29:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:06 --> Model Class Initialized
INFO - 2017-01-16 09:29:06 --> Model Class Initialized
INFO - 2017-01-16 09:29:06 --> Model Class Initialized
INFO - 2017-01-16 09:29:06 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:06 --> Total execution time: 0.3101
INFO - 2017-01-16 09:29:08 --> Config Class Initialized
INFO - 2017-01-16 09:29:08 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:08 --> Config Class Initialized
INFO - 2017-01-16 09:29:08 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:08 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:08 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:08 --> URI Class Initialized
DEBUG - 2017-01-16 09:29:08 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:08 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:08 --> Router Class Initialized
INFO - 2017-01-16 09:29:08 --> URI Class Initialized
INFO - 2017-01-16 09:29:08 --> Output Class Initialized
INFO - 2017-01-16 09:29:08 --> Router Class Initialized
INFO - 2017-01-16 09:29:08 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:08 --> Input Class Initialized
INFO - 2017-01-16 09:29:08 --> Output Class Initialized
INFO - 2017-01-16 09:29:08 --> Language Class Initialized
INFO - 2017-01-16 09:29:08 --> Security Class Initialized
INFO - 2017-01-16 09:29:08 --> Loader Class Initialized
DEBUG - 2017-01-16 09:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:08 --> Input Class Initialized
INFO - 2017-01-16 09:29:08 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:08 --> Language Class Initialized
INFO - 2017-01-16 09:29:08 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:08 --> Loader Class Initialized
INFO - 2017-01-16 09:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:08 --> Controller Class Initialized
INFO - 2017-01-16 09:29:08 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:08 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:08 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:08 --> Model Class Initialized
INFO - 2017-01-16 09:29:08 --> Model Class Initialized
INFO - 2017-01-16 09:29:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:08 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:08 --> Total execution time: 0.0764
INFO - 2017-01-16 09:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:08 --> Controller Class Initialized
INFO - 2017-01-16 09:29:08 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:08 --> Model Class Initialized
INFO - 2017-01-16 09:29:08 --> Model Class Initialized
INFO - 2017-01-16 09:29:08 --> Model Class Initialized
INFO - 2017-01-16 09:29:08 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:08 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:08 --> Total execution time: 0.2763
INFO - 2017-01-16 09:29:09 --> Config Class Initialized
INFO - 2017-01-16 09:29:09 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:09 --> Config Class Initialized
INFO - 2017-01-16 09:29:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:09 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:09 --> URI Class Initialized
INFO - 2017-01-16 09:29:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:09 --> URI Class Initialized
INFO - 2017-01-16 09:29:09 --> Router Class Initialized
INFO - 2017-01-16 09:29:09 --> Router Class Initialized
INFO - 2017-01-16 09:29:09 --> Output Class Initialized
INFO - 2017-01-16 09:29:09 --> Security Class Initialized
INFO - 2017-01-16 09:29:09 --> Output Class Initialized
DEBUG - 2017-01-16 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:09 --> Input Class Initialized
INFO - 2017-01-16 09:29:09 --> Security Class Initialized
INFO - 2017-01-16 09:29:09 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:09 --> Input Class Initialized
INFO - 2017-01-16 09:29:09 --> Language Class Initialized
INFO - 2017-01-16 09:29:09 --> Loader Class Initialized
INFO - 2017-01-16 09:29:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:09 --> Loader Class Initialized
INFO - 2017-01-16 09:29:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:09 --> Controller Class Initialized
INFO - 2017-01-16 09:29:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:09 --> Model Class Initialized
INFO - 2017-01-16 09:29:09 --> Model Class Initialized
INFO - 2017-01-16 09:29:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:09 --> Total execution time: 0.0766
INFO - 2017-01-16 09:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:09 --> Controller Class Initialized
INFO - 2017-01-16 09:29:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:09 --> Model Class Initialized
INFO - 2017-01-16 09:29:09 --> Model Class Initialized
INFO - 2017-01-16 09:29:09 --> Model Class Initialized
INFO - 2017-01-16 09:29:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:09 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:09 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:09 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:09 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:10 --> Total execution time: 0.2709
INFO - 2017-01-16 09:29:11 --> Config Class Initialized
INFO - 2017-01-16 09:29:11 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:11 --> Config Class Initialized
INFO - 2017-01-16 09:29:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:11 --> URI Class Initialized
DEBUG - 2017-01-16 09:29:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:11 --> Router Class Initialized
INFO - 2017-01-16 09:29:11 --> URI Class Initialized
INFO - 2017-01-16 09:29:11 --> Output Class Initialized
INFO - 2017-01-16 09:29:11 --> Router Class Initialized
INFO - 2017-01-16 09:29:11 --> Security Class Initialized
INFO - 2017-01-16 09:29:11 --> Output Class Initialized
DEBUG - 2017-01-16 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:11 --> Input Class Initialized
INFO - 2017-01-16 09:29:11 --> Security Class Initialized
INFO - 2017-01-16 09:29:11 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:11 --> Loader Class Initialized
INFO - 2017-01-16 09:29:11 --> Input Class Initialized
INFO - 2017-01-16 09:29:11 --> Language Class Initialized
INFO - 2017-01-16 09:29:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:11 --> Loader Class Initialized
INFO - 2017-01-16 09:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:11 --> Controller Class Initialized
INFO - 2017-01-16 09:29:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:11 --> Model Class Initialized
INFO - 2017-01-16 09:29:11 --> Model Class Initialized
INFO - 2017-01-16 09:29:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:11 --> Total execution time: 0.0781
INFO - 2017-01-16 09:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:11 --> Controller Class Initialized
INFO - 2017-01-16 09:29:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:11 --> Model Class Initialized
INFO - 2017-01-16 09:29:11 --> Model Class Initialized
INFO - 2017-01-16 09:29:11 --> Model Class Initialized
INFO - 2017-01-16 09:29:11 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:11 --> Total execution time: 0.2778
INFO - 2017-01-16 09:29:12 --> Config Class Initialized
INFO - 2017-01-16 09:29:12 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:12 --> Config Class Initialized
INFO - 2017-01-16 09:29:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:12 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:12 --> URI Class Initialized
INFO - 2017-01-16 09:29:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:12 --> URI Class Initialized
INFO - 2017-01-16 09:29:12 --> Router Class Initialized
INFO - 2017-01-16 09:29:12 --> Router Class Initialized
INFO - 2017-01-16 09:29:12 --> Output Class Initialized
INFO - 2017-01-16 09:29:12 --> Security Class Initialized
INFO - 2017-01-16 09:29:12 --> Output Class Initialized
INFO - 2017-01-16 09:29:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:12 --> Input Class Initialized
INFO - 2017-01-16 09:29:12 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:12 --> Input Class Initialized
INFO - 2017-01-16 09:29:12 --> Language Class Initialized
INFO - 2017-01-16 09:29:12 --> Loader Class Initialized
INFO - 2017-01-16 09:29:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:12 --> Loader Class Initialized
INFO - 2017-01-16 09:29:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:12 --> Controller Class Initialized
INFO - 2017-01-16 09:29:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:12 --> Model Class Initialized
INFO - 2017-01-16 09:29:12 --> Model Class Initialized
INFO - 2017-01-16 09:29:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:13 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:13 --> Total execution time: 0.0794
INFO - 2017-01-16 09:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:13 --> Controller Class Initialized
INFO - 2017-01-16 09:29:13 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:13 --> Model Class Initialized
INFO - 2017-01-16 09:29:13 --> Model Class Initialized
INFO - 2017-01-16 09:29:13 --> Model Class Initialized
INFO - 2017-01-16 09:29:13 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:13 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:13 --> Total execution time: 0.2746
INFO - 2017-01-16 09:29:14 --> Config Class Initialized
INFO - 2017-01-16 09:29:14 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:14 --> Config Class Initialized
INFO - 2017-01-16 09:29:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:14 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:14 --> URI Class Initialized
INFO - 2017-01-16 09:29:14 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:14 --> Output Class Initialized
INFO - 2017-01-16 09:29:14 --> URI Class Initialized
INFO - 2017-01-16 09:29:14 --> Security Class Initialized
INFO - 2017-01-16 09:29:14 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:14 --> Output Class Initialized
INFO - 2017-01-16 09:29:14 --> Input Class Initialized
INFO - 2017-01-16 09:29:14 --> Language Class Initialized
INFO - 2017-01-16 09:29:14 --> Security Class Initialized
INFO - 2017-01-16 09:29:14 --> Loader Class Initialized
DEBUG - 2017-01-16 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:14 --> Input Class Initialized
INFO - 2017-01-16 09:29:14 --> Language Class Initialized
INFO - 2017-01-16 09:29:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:14 --> Loader Class Initialized
INFO - 2017-01-16 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:14 --> Controller Class Initialized
INFO - 2017-01-16 09:29:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:14 --> Model Class Initialized
INFO - 2017-01-16 09:29:14 --> Model Class Initialized
INFO - 2017-01-16 09:29:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:14 --> Total execution time: 0.0772
INFO - 2017-01-16 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:14 --> Controller Class Initialized
INFO - 2017-01-16 09:29:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:14 --> Model Class Initialized
INFO - 2017-01-16 09:29:14 --> Model Class Initialized
INFO - 2017-01-16 09:29:14 --> Model Class Initialized
INFO - 2017-01-16 09:29:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:14 --> Total execution time: 0.2880
INFO - 2017-01-16 09:29:15 --> Config Class Initialized
INFO - 2017-01-16 09:29:15 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:15 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:15 --> Config Class Initialized
INFO - 2017-01-16 09:29:15 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:15 --> URI Class Initialized
INFO - 2017-01-16 09:29:15 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:15 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:15 --> Output Class Initialized
INFO - 2017-01-16 09:29:15 --> URI Class Initialized
INFO - 2017-01-16 09:29:15 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:15 --> Router Class Initialized
INFO - 2017-01-16 09:29:15 --> Input Class Initialized
INFO - 2017-01-16 09:29:15 --> Language Class Initialized
INFO - 2017-01-16 09:29:15 --> Output Class Initialized
INFO - 2017-01-16 09:29:15 --> Security Class Initialized
INFO - 2017-01-16 09:29:15 --> Loader Class Initialized
DEBUG - 2017-01-16 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:15 --> Input Class Initialized
INFO - 2017-01-16 09:29:15 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:15 --> Language Class Initialized
INFO - 2017-01-16 09:29:15 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:16 --> Loader Class Initialized
INFO - 2017-01-16 09:29:16 --> Controller Class Initialized
INFO - 2017-01-16 09:29:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:16 --> Model Class Initialized
INFO - 2017-01-16 09:29:16 --> Model Class Initialized
INFO - 2017-01-16 09:29:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:16 --> Total execution time: 0.0876
INFO - 2017-01-16 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:16 --> Controller Class Initialized
INFO - 2017-01-16 09:29:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:16 --> Model Class Initialized
INFO - 2017-01-16 09:29:16 --> Model Class Initialized
INFO - 2017-01-16 09:29:16 --> Model Class Initialized
INFO - 2017-01-16 09:29:16 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:16 --> Total execution time: 0.3111
INFO - 2017-01-16 09:29:18 --> Config Class Initialized
INFO - 2017-01-16 09:29:18 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:18 --> Config Class Initialized
INFO - 2017-01-16 09:29:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:18 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:18 --> URI Class Initialized
INFO - 2017-01-16 09:29:18 --> URI Class Initialized
INFO - 2017-01-16 09:29:18 --> Config Class Initialized
INFO - 2017-01-16 09:29:18 --> Router Class Initialized
INFO - 2017-01-16 09:29:18 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:18 --> Router Class Initialized
INFO - 2017-01-16 09:29:18 --> Output Class Initialized
INFO - 2017-01-16 09:29:18 --> Output Class Initialized
INFO - 2017-01-16 09:29:18 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:18 --> Security Class Initialized
INFO - 2017-01-16 09:29:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:18 --> URI Class Initialized
DEBUG - 2017-01-16 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:18 --> Input Class Initialized
INFO - 2017-01-16 09:29:18 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:18 --> Input Class Initialized
INFO - 2017-01-16 09:29:18 --> Router Class Initialized
INFO - 2017-01-16 09:29:18 --> Language Class Initialized
INFO - 2017-01-16 09:29:18 --> Output Class Initialized
INFO - 2017-01-16 09:29:18 --> Loader Class Initialized
INFO - 2017-01-16 09:29:18 --> Security Class Initialized
INFO - 2017-01-16 09:29:18 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:18 --> Loader Class Initialized
INFO - 2017-01-16 09:29:18 --> Input Class Initialized
INFO - 2017-01-16 09:29:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:18 --> Language Class Initialized
INFO - 2017-01-16 09:29:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:18 --> Controller Class Initialized
INFO - 2017-01-16 09:29:18 --> Loader Class Initialized
INFO - 2017-01-16 09:29:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:18 --> Total execution time: 0.0810
INFO - 2017-01-16 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:18 --> Controller Class Initialized
INFO - 2017-01-16 09:29:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
ERROR - 2017-01-16 09:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 524
INFO - 2017-01-16 09:29:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:18 --> Total execution time: 0.3027
INFO - 2017-01-16 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:18 --> Controller Class Initialized
INFO - 2017-01-16 09:29:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:18 --> Config Class Initialized
INFO - 2017-01-16 09:29:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:18 --> URI Class Initialized
INFO - 2017-01-16 09:29:18 --> Router Class Initialized
INFO - 2017-01-16 09:29:18 --> Output Class Initialized
INFO - 2017-01-16 09:29:18 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:18 --> Input Class Initialized
INFO - 2017-01-16 09:29:18 --> Language Class Initialized
INFO - 2017-01-16 09:29:18 --> Loader Class Initialized
INFO - 2017-01-16 09:29:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:18 --> Controller Class Initialized
INFO - 2017-01-16 09:29:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Model Class Initialized
INFO - 2017-01-16 09:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2017-01-16 09:29:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:29:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:18 --> Total execution time: 0.0651
INFO - 2017-01-16 09:29:21 --> Config Class Initialized
INFO - 2017-01-16 09:29:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:21 --> URI Class Initialized
INFO - 2017-01-16 09:29:21 --> Router Class Initialized
INFO - 2017-01-16 09:29:21 --> Output Class Initialized
INFO - 2017-01-16 09:29:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:21 --> Input Class Initialized
INFO - 2017-01-16 09:29:21 --> Language Class Initialized
INFO - 2017-01-16 09:29:21 --> Loader Class Initialized
INFO - 2017-01-16 09:29:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:21 --> Controller Class Initialized
INFO - 2017-01-16 09:29:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:21 --> Config Class Initialized
INFO - 2017-01-16 09:29:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:21 --> URI Class Initialized
INFO - 2017-01-16 09:29:21 --> Router Class Initialized
INFO - 2017-01-16 09:29:21 --> Output Class Initialized
INFO - 2017-01-16 09:29:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:21 --> Input Class Initialized
INFO - 2017-01-16 09:29:21 --> Language Class Initialized
INFO - 2017-01-16 09:29:21 --> Loader Class Initialized
INFO - 2017-01-16 09:29:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:21 --> Controller Class Initialized
INFO - 2017-01-16 09:29:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2017-01-16 09:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:29:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:21 --> Total execution time: 0.0764
INFO - 2017-01-16 09:29:21 --> Config Class Initialized
INFO - 2017-01-16 09:29:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:21 --> Config Class Initialized
INFO - 2017-01-16 09:29:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:21 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:21 --> URI Class Initialized
DEBUG - 2017-01-16 09:29:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:21 --> Router Class Initialized
INFO - 2017-01-16 09:29:21 --> URI Class Initialized
INFO - 2017-01-16 09:29:21 --> Output Class Initialized
INFO - 2017-01-16 09:29:21 --> Security Class Initialized
INFO - 2017-01-16 09:29:21 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:21 --> Output Class Initialized
INFO - 2017-01-16 09:29:21 --> Input Class Initialized
INFO - 2017-01-16 09:29:21 --> Language Class Initialized
INFO - 2017-01-16 09:29:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:21 --> Input Class Initialized
INFO - 2017-01-16 09:29:21 --> Loader Class Initialized
INFO - 2017-01-16 09:29:21 --> Language Class Initialized
INFO - 2017-01-16 09:29:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:21 --> Loader Class Initialized
INFO - 2017-01-16 09:29:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:21 --> Controller Class Initialized
INFO - 2017-01-16 09:29:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:21 --> Total execution time: 0.0817
INFO - 2017-01-16 09:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:21 --> Controller Class Initialized
INFO - 2017-01-16 09:29:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Model Class Initialized
INFO - 2017-01-16 09:29:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:29:21 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:29:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:29:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:21 --> Total execution time: 0.1135
INFO - 2017-01-16 09:29:24 --> Config Class Initialized
INFO - 2017-01-16 09:29:24 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:24 --> Config Class Initialized
INFO - 2017-01-16 09:29:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:24 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:24 --> URI Class Initialized
INFO - 2017-01-16 09:29:24 --> URI Class Initialized
INFO - 2017-01-16 09:29:24 --> Router Class Initialized
INFO - 2017-01-16 09:29:24 --> Router Class Initialized
INFO - 2017-01-16 09:29:24 --> Output Class Initialized
INFO - 2017-01-16 09:29:24 --> Output Class Initialized
INFO - 2017-01-16 09:29:24 --> Security Class Initialized
INFO - 2017-01-16 09:29:24 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:24 --> Input Class Initialized
INFO - 2017-01-16 09:29:24 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:24 --> Input Class Initialized
INFO - 2017-01-16 09:29:24 --> Language Class Initialized
INFO - 2017-01-16 09:29:24 --> Loader Class Initialized
INFO - 2017-01-16 09:29:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:24 --> Loader Class Initialized
INFO - 2017-01-16 09:29:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:24 --> Controller Class Initialized
INFO - 2017-01-16 09:29:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:24 --> Model Class Initialized
INFO - 2017-01-16 09:29:24 --> Model Class Initialized
INFO - 2017-01-16 09:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:24 --> Total execution time: 0.0744
INFO - 2017-01-16 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:24 --> Controller Class Initialized
INFO - 2017-01-16 09:29:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:24 --> Model Class Initialized
INFO - 2017-01-16 09:29:24 --> Model Class Initialized
INFO - 2017-01-16 09:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:24 --> Total execution time: 0.1076
INFO - 2017-01-16 09:29:26 --> Config Class Initialized
INFO - 2017-01-16 09:29:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:26 --> Config Class Initialized
INFO - 2017-01-16 09:29:26 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:26 --> URI Class Initialized
INFO - 2017-01-16 09:29:26 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:27 --> Output Class Initialized
INFO - 2017-01-16 09:29:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:27 --> URI Class Initialized
INFO - 2017-01-16 09:29:27 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:27 --> Input Class Initialized
INFO - 2017-01-16 09:29:27 --> Router Class Initialized
INFO - 2017-01-16 09:29:27 --> Language Class Initialized
INFO - 2017-01-16 09:29:27 --> Output Class Initialized
INFO - 2017-01-16 09:29:27 --> Security Class Initialized
INFO - 2017-01-16 09:29:27 --> Loader Class Initialized
DEBUG - 2017-01-16 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:27 --> Input Class Initialized
INFO - 2017-01-16 09:29:27 --> Language Class Initialized
INFO - 2017-01-16 09:29:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:27 --> Loader Class Initialized
INFO - 2017-01-16 09:29:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:27 --> Controller Class Initialized
INFO - 2017-01-16 09:29:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:27 --> Model Class Initialized
INFO - 2017-01-16 09:29:27 --> Model Class Initialized
INFO - 2017-01-16 09:29:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:27 --> Total execution time: 0.0758
INFO - 2017-01-16 09:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:27 --> Controller Class Initialized
INFO - 2017-01-16 09:29:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:27 --> Model Class Initialized
INFO - 2017-01-16 09:29:27 --> Model Class Initialized
INFO - 2017-01-16 09:29:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:27 --> Total execution time: 0.1127
INFO - 2017-01-16 09:29:29 --> Config Class Initialized
INFO - 2017-01-16 09:29:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:29 --> Config Class Initialized
INFO - 2017-01-16 09:29:29 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:29 --> URI Class Initialized
INFO - 2017-01-16 09:29:29 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:29 --> Output Class Initialized
INFO - 2017-01-16 09:29:29 --> URI Class Initialized
INFO - 2017-01-16 09:29:29 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:29 --> Input Class Initialized
INFO - 2017-01-16 09:29:29 --> Router Class Initialized
INFO - 2017-01-16 09:29:29 --> Language Class Initialized
INFO - 2017-01-16 09:29:29 --> Output Class Initialized
INFO - 2017-01-16 09:29:29 --> Loader Class Initialized
INFO - 2017-01-16 09:29:29 --> Security Class Initialized
INFO - 2017-01-16 09:29:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:29 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:29 --> Input Class Initialized
INFO - 2017-01-16 09:29:29 --> Language Class Initialized
INFO - 2017-01-16 09:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:29 --> Controller Class Initialized
INFO - 2017-01-16 09:29:29 --> Loader Class Initialized
INFO - 2017-01-16 09:29:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:29 --> Model Class Initialized
INFO - 2017-01-16 09:29:29 --> Model Class Initialized
INFO - 2017-01-16 09:29:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:29 --> Total execution time: 0.0734
INFO - 2017-01-16 09:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:29 --> Controller Class Initialized
INFO - 2017-01-16 09:29:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:29 --> Model Class Initialized
INFO - 2017-01-16 09:29:29 --> Model Class Initialized
INFO - 2017-01-16 09:29:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:29 --> Total execution time: 0.1169
INFO - 2017-01-16 09:29:31 --> Config Class Initialized
INFO - 2017-01-16 09:29:31 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:31 --> Config Class Initialized
INFO - 2017-01-16 09:29:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:31 --> URI Class Initialized
DEBUG - 2017-01-16 09:29:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:31 --> Router Class Initialized
INFO - 2017-01-16 09:29:31 --> URI Class Initialized
INFO - 2017-01-16 09:29:31 --> Output Class Initialized
INFO - 2017-01-16 09:29:31 --> Router Class Initialized
INFO - 2017-01-16 09:29:31 --> Security Class Initialized
INFO - 2017-01-16 09:29:31 --> Output Class Initialized
DEBUG - 2017-01-16 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:31 --> Input Class Initialized
INFO - 2017-01-16 09:29:31 --> Security Class Initialized
INFO - 2017-01-16 09:29:31 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:31 --> Input Class Initialized
INFO - 2017-01-16 09:29:31 --> Language Class Initialized
INFO - 2017-01-16 09:29:31 --> Loader Class Initialized
INFO - 2017-01-16 09:29:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:31 --> Loader Class Initialized
INFO - 2017-01-16 09:29:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:31 --> Controller Class Initialized
INFO - 2017-01-16 09:29:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:31 --> Model Class Initialized
INFO - 2017-01-16 09:29:31 --> Model Class Initialized
INFO - 2017-01-16 09:29:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:31 --> Total execution time: 0.0703
INFO - 2017-01-16 09:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:31 --> Controller Class Initialized
INFO - 2017-01-16 09:29:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:31 --> Model Class Initialized
INFO - 2017-01-16 09:29:31 --> Model Class Initialized
INFO - 2017-01-16 09:29:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:31 --> Total execution time: 0.1269
INFO - 2017-01-16 09:29:33 --> Config Class Initialized
INFO - 2017-01-16 09:29:33 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:33 --> Config Class Initialized
INFO - 2017-01-16 09:29:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:33 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:33 --> URI Class Initialized
INFO - 2017-01-16 09:29:33 --> URI Class Initialized
INFO - 2017-01-16 09:29:33 --> Router Class Initialized
INFO - 2017-01-16 09:29:33 --> Router Class Initialized
INFO - 2017-01-16 09:29:33 --> Output Class Initialized
INFO - 2017-01-16 09:29:33 --> Output Class Initialized
INFO - 2017-01-16 09:29:33 --> Security Class Initialized
INFO - 2017-01-16 09:29:33 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:33 --> Input Class Initialized
DEBUG - 2017-01-16 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:33 --> Language Class Initialized
INFO - 2017-01-16 09:29:33 --> Input Class Initialized
INFO - 2017-01-16 09:29:33 --> Language Class Initialized
INFO - 2017-01-16 09:29:33 --> Loader Class Initialized
INFO - 2017-01-16 09:29:33 --> Loader Class Initialized
INFO - 2017-01-16 09:29:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:33 --> Controller Class Initialized
INFO - 2017-01-16 09:29:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:33 --> Model Class Initialized
INFO - 2017-01-16 09:29:33 --> Model Class Initialized
INFO - 2017-01-16 09:29:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:33 --> Total execution time: 0.0845
INFO - 2017-01-16 09:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:33 --> Controller Class Initialized
INFO - 2017-01-16 09:29:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:33 --> Model Class Initialized
INFO - 2017-01-16 09:29:33 --> Model Class Initialized
INFO - 2017-01-16 09:29:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:33 --> Total execution time: 0.1484
INFO - 2017-01-16 09:29:36 --> Config Class Initialized
INFO - 2017-01-16 09:29:36 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:36 --> Config Class Initialized
INFO - 2017-01-16 09:29:36 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:29:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:36 --> URI Class Initialized
INFO - 2017-01-16 09:29:36 --> URI Class Initialized
INFO - 2017-01-16 09:29:36 --> Router Class Initialized
INFO - 2017-01-16 09:29:36 --> Router Class Initialized
INFO - 2017-01-16 09:29:36 --> Output Class Initialized
INFO - 2017-01-16 09:29:36 --> Output Class Initialized
INFO - 2017-01-16 09:29:36 --> Security Class Initialized
INFO - 2017-01-16 09:29:36 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:36 --> Input Class Initialized
DEBUG - 2017-01-16 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:36 --> Input Class Initialized
INFO - 2017-01-16 09:29:36 --> Language Class Initialized
INFO - 2017-01-16 09:29:36 --> Language Class Initialized
INFO - 2017-01-16 09:29:36 --> Loader Class Initialized
INFO - 2017-01-16 09:29:36 --> Loader Class Initialized
INFO - 2017-01-16 09:29:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:36 --> Controller Class Initialized
INFO - 2017-01-16 09:29:36 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:36 --> Model Class Initialized
INFO - 2017-01-16 09:29:36 --> Model Class Initialized
INFO - 2017-01-16 09:29:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:36 --> Total execution time: 0.0689
INFO - 2017-01-16 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:36 --> Controller Class Initialized
INFO - 2017-01-16 09:29:36 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:36 --> Model Class Initialized
INFO - 2017-01-16 09:29:36 --> Model Class Initialized
INFO - 2017-01-16 09:29:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:36 --> Total execution time: 0.1382
INFO - 2017-01-16 09:29:38 --> Config Class Initialized
INFO - 2017-01-16 09:29:38 --> Config Class Initialized
INFO - 2017-01-16 09:29:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:29:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:38 --> URI Class Initialized
INFO - 2017-01-16 09:29:38 --> URI Class Initialized
INFO - 2017-01-16 09:29:38 --> Router Class Initialized
INFO - 2017-01-16 09:29:38 --> Router Class Initialized
INFO - 2017-01-16 09:29:38 --> Output Class Initialized
INFO - 2017-01-16 09:29:38 --> Output Class Initialized
INFO - 2017-01-16 09:29:38 --> Security Class Initialized
INFO - 2017-01-16 09:29:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:38 --> Input Class Initialized
INFO - 2017-01-16 09:29:38 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:38 --> Input Class Initialized
INFO - 2017-01-16 09:29:38 --> Language Class Initialized
INFO - 2017-01-16 09:29:38 --> Loader Class Initialized
INFO - 2017-01-16 09:29:38 --> Loader Class Initialized
INFO - 2017-01-16 09:29:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:38 --> Controller Class Initialized
INFO - 2017-01-16 09:29:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:38 --> Model Class Initialized
INFO - 2017-01-16 09:29:38 --> Model Class Initialized
INFO - 2017-01-16 09:29:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:38 --> Total execution time: 0.0813
INFO - 2017-01-16 09:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:38 --> Controller Class Initialized
INFO - 2017-01-16 09:29:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:38 --> Model Class Initialized
INFO - 2017-01-16 09:29:38 --> Model Class Initialized
INFO - 2017-01-16 09:29:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:39 --> Total execution time: 0.1581
INFO - 2017-01-16 09:29:41 --> Config Class Initialized
INFO - 2017-01-16 09:29:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:41 --> Config Class Initialized
INFO - 2017-01-16 09:29:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:41 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:41 --> URI Class Initialized
INFO - 2017-01-16 09:29:41 --> URI Class Initialized
INFO - 2017-01-16 09:29:41 --> Router Class Initialized
INFO - 2017-01-16 09:29:41 --> Router Class Initialized
INFO - 2017-01-16 09:29:41 --> Output Class Initialized
INFO - 2017-01-16 09:29:41 --> Output Class Initialized
INFO - 2017-01-16 09:29:41 --> Security Class Initialized
INFO - 2017-01-16 09:29:41 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:41 --> Input Class Initialized
INFO - 2017-01-16 09:29:41 --> Input Class Initialized
INFO - 2017-01-16 09:29:41 --> Language Class Initialized
INFO - 2017-01-16 09:29:41 --> Language Class Initialized
INFO - 2017-01-16 09:29:41 --> Loader Class Initialized
INFO - 2017-01-16 09:29:41 --> Loader Class Initialized
INFO - 2017-01-16 09:29:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:41 --> Controller Class Initialized
INFO - 2017-01-16 09:29:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:41 --> Model Class Initialized
INFO - 2017-01-16 09:29:41 --> Model Class Initialized
INFO - 2017-01-16 09:29:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:41 --> Total execution time: 0.1298
INFO - 2017-01-16 09:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:41 --> Controller Class Initialized
INFO - 2017-01-16 09:29:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:41 --> Model Class Initialized
INFO - 2017-01-16 09:29:41 --> Model Class Initialized
INFO - 2017-01-16 09:29:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:41 --> Total execution time: 0.1549
INFO - 2017-01-16 09:29:46 --> Config Class Initialized
INFO - 2017-01-16 09:29:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:46 --> Config Class Initialized
INFO - 2017-01-16 09:29:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:46 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:46 --> URI Class Initialized
INFO - 2017-01-16 09:29:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:46 --> URI Class Initialized
INFO - 2017-01-16 09:29:46 --> Router Class Initialized
INFO - 2017-01-16 09:29:46 --> Output Class Initialized
INFO - 2017-01-16 09:29:46 --> Router Class Initialized
INFO - 2017-01-16 09:29:46 --> Security Class Initialized
INFO - 2017-01-16 09:29:46 --> Output Class Initialized
DEBUG - 2017-01-16 09:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:46 --> Input Class Initialized
INFO - 2017-01-16 09:29:46 --> Security Class Initialized
INFO - 2017-01-16 09:29:46 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:46 --> Input Class Initialized
INFO - 2017-01-16 09:29:46 --> Language Class Initialized
INFO - 2017-01-16 09:29:46 --> Loader Class Initialized
INFO - 2017-01-16 09:29:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:46 --> Loader Class Initialized
INFO - 2017-01-16 09:29:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:46 --> Controller Class Initialized
INFO - 2017-01-16 09:29:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:46 --> Model Class Initialized
INFO - 2017-01-16 09:29:46 --> Model Class Initialized
INFO - 2017-01-16 09:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:46 --> Total execution time: 0.0689
INFO - 2017-01-16 09:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:46 --> Controller Class Initialized
INFO - 2017-01-16 09:29:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:46 --> Model Class Initialized
INFO - 2017-01-16 09:29:46 --> Model Class Initialized
INFO - 2017-01-16 09:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:46 --> Total execution time: 0.1602
INFO - 2017-01-16 09:29:47 --> Config Class Initialized
INFO - 2017-01-16 09:29:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:47 --> URI Class Initialized
INFO - 2017-01-16 09:29:47 --> Router Class Initialized
INFO - 2017-01-16 09:29:47 --> Output Class Initialized
INFO - 2017-01-16 09:29:47 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:47 --> Input Class Initialized
INFO - 2017-01-16 09:29:47 --> Language Class Initialized
INFO - 2017-01-16 09:29:47 --> Loader Class Initialized
INFO - 2017-01-16 09:29:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:47 --> Controller Class Initialized
INFO - 2017-01-16 09:29:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:47 --> Model Class Initialized
INFO - 2017-01-16 09:29:47 --> Model Class Initialized
INFO - 2017-01-16 09:29:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:47 --> Total execution time: 0.1623
INFO - 2017-01-16 09:29:48 --> Config Class Initialized
INFO - 2017-01-16 09:29:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:48 --> Config Class Initialized
INFO - 2017-01-16 09:29:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:48 --> URI Class Initialized
INFO - 2017-01-16 09:29:48 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:48 --> Output Class Initialized
INFO - 2017-01-16 09:29:48 --> URI Class Initialized
INFO - 2017-01-16 09:29:48 --> Security Class Initialized
INFO - 2017-01-16 09:29:48 --> Router Class Initialized
DEBUG - 2017-01-16 09:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:48 --> Input Class Initialized
INFO - 2017-01-16 09:29:48 --> Language Class Initialized
INFO - 2017-01-16 09:29:48 --> Output Class Initialized
INFO - 2017-01-16 09:29:48 --> Security Class Initialized
INFO - 2017-01-16 09:29:48 --> Loader Class Initialized
DEBUG - 2017-01-16 09:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:48 --> Input Class Initialized
INFO - 2017-01-16 09:29:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:48 --> Language Class Initialized
INFO - 2017-01-16 09:29:48 --> Loader Class Initialized
INFO - 2017-01-16 09:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:48 --> Controller Class Initialized
INFO - 2017-01-16 09:29:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:48 --> Model Class Initialized
INFO - 2017-01-16 09:29:48 --> Model Class Initialized
INFO - 2017-01-16 09:29:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:48 --> Total execution time: 0.0712
INFO - 2017-01-16 09:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:48 --> Controller Class Initialized
INFO - 2017-01-16 09:29:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:48 --> Model Class Initialized
INFO - 2017-01-16 09:29:48 --> Model Class Initialized
INFO - 2017-01-16 09:29:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:48 --> Total execution time: 0.1696
INFO - 2017-01-16 09:29:50 --> Config Class Initialized
INFO - 2017-01-16 09:29:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:50 --> Config Class Initialized
INFO - 2017-01-16 09:29:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:50 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:50 --> URI Class Initialized
INFO - 2017-01-16 09:29:50 --> URI Class Initialized
INFO - 2017-01-16 09:29:50 --> Router Class Initialized
INFO - 2017-01-16 09:29:50 --> Router Class Initialized
INFO - 2017-01-16 09:29:50 --> Output Class Initialized
INFO - 2017-01-16 09:29:50 --> Output Class Initialized
INFO - 2017-01-16 09:29:50 --> Security Class Initialized
INFO - 2017-01-16 09:29:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:50 --> Input Class Initialized
INFO - 2017-01-16 09:29:50 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:50 --> Input Class Initialized
INFO - 2017-01-16 09:29:50 --> Language Class Initialized
INFO - 2017-01-16 09:29:50 --> Loader Class Initialized
INFO - 2017-01-16 09:29:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:50 --> Loader Class Initialized
INFO - 2017-01-16 09:29:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:50 --> Controller Class Initialized
INFO - 2017-01-16 09:29:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:50 --> Model Class Initialized
INFO - 2017-01-16 09:29:50 --> Model Class Initialized
INFO - 2017-01-16 09:29:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:50 --> Total execution time: 0.0739
INFO - 2017-01-16 09:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:50 --> Controller Class Initialized
INFO - 2017-01-16 09:29:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:50 --> Model Class Initialized
INFO - 2017-01-16 09:29:50 --> Model Class Initialized
INFO - 2017-01-16 09:29:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:50 --> Total execution time: 0.1817
INFO - 2017-01-16 09:29:51 --> Config Class Initialized
INFO - 2017-01-16 09:29:51 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:51 --> URI Class Initialized
INFO - 2017-01-16 09:29:51 --> Router Class Initialized
INFO - 2017-01-16 09:29:51 --> Output Class Initialized
INFO - 2017-01-16 09:29:51 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:51 --> Input Class Initialized
INFO - 2017-01-16 09:29:51 --> Language Class Initialized
INFO - 2017-01-16 09:29:51 --> Loader Class Initialized
INFO - 2017-01-16 09:29:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:51 --> Controller Class Initialized
INFO - 2017-01-16 09:29:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:51 --> Model Class Initialized
INFO - 2017-01-16 09:29:51 --> Model Class Initialized
INFO - 2017-01-16 09:29:51 --> Model Class Initialized
INFO - 2017-01-16 09:29:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:51 --> Total execution time: 0.0682
INFO - 2017-01-16 09:29:53 --> Config Class Initialized
INFO - 2017-01-16 09:29:53 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:53 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:53 --> URI Class Initialized
INFO - 2017-01-16 09:29:53 --> Config Class Initialized
INFO - 2017-01-16 09:29:53 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:53 --> Router Class Initialized
INFO - 2017-01-16 09:29:53 --> Output Class Initialized
DEBUG - 2017-01-16 09:29:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:53 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:53 --> Security Class Initialized
INFO - 2017-01-16 09:29:53 --> URI Class Initialized
DEBUG - 2017-01-16 09:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:53 --> Input Class Initialized
INFO - 2017-01-16 09:29:53 --> Router Class Initialized
INFO - 2017-01-16 09:29:53 --> Language Class Initialized
INFO - 2017-01-16 09:29:53 --> Output Class Initialized
INFO - 2017-01-16 09:29:53 --> Security Class Initialized
INFO - 2017-01-16 09:29:53 --> Loader Class Initialized
INFO - 2017-01-16 09:29:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:53 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:53 --> Input Class Initialized
INFO - 2017-01-16 09:29:53 --> Language Class Initialized
INFO - 2017-01-16 09:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:53 --> Controller Class Initialized
INFO - 2017-01-16 09:29:53 --> Loader Class Initialized
INFO - 2017-01-16 09:29:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:53 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:53 --> Model Class Initialized
INFO - 2017-01-16 09:29:53 --> Model Class Initialized
INFO - 2017-01-16 09:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:53 --> Total execution time: 0.0808
INFO - 2017-01-16 09:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:53 --> Controller Class Initialized
INFO - 2017-01-16 09:29:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:53 --> Model Class Initialized
INFO - 2017-01-16 09:29:53 --> Model Class Initialized
INFO - 2017-01-16 09:29:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:53 --> Total execution time: 0.2069
INFO - 2017-01-16 09:29:56 --> Config Class Initialized
INFO - 2017-01-16 09:29:56 --> Config Class Initialized
INFO - 2017-01-16 09:29:56 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:56 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:56 --> URI Class Initialized
INFO - 2017-01-16 09:29:56 --> URI Class Initialized
INFO - 2017-01-16 09:29:56 --> Router Class Initialized
INFO - 2017-01-16 09:29:56 --> Router Class Initialized
INFO - 2017-01-16 09:29:56 --> Output Class Initialized
INFO - 2017-01-16 09:29:56 --> Output Class Initialized
INFO - 2017-01-16 09:29:56 --> Security Class Initialized
INFO - 2017-01-16 09:29:56 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:56 --> Input Class Initialized
INFO - 2017-01-16 09:29:56 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:56 --> Input Class Initialized
INFO - 2017-01-16 09:29:56 --> Language Class Initialized
INFO - 2017-01-16 09:29:56 --> Loader Class Initialized
INFO - 2017-01-16 09:29:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:56 --> Loader Class Initialized
INFO - 2017-01-16 09:29:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:56 --> Controller Class Initialized
INFO - 2017-01-16 09:29:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:56 --> Model Class Initialized
INFO - 2017-01-16 09:29:56 --> Model Class Initialized
INFO - 2017-01-16 09:29:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:56 --> Total execution time: 0.0699
INFO - 2017-01-16 09:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:56 --> Controller Class Initialized
INFO - 2017-01-16 09:29:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:56 --> Model Class Initialized
INFO - 2017-01-16 09:29:56 --> Model Class Initialized
INFO - 2017-01-16 09:29:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:56 --> Total execution time: 0.1847
INFO - 2017-01-16 09:29:58 --> Config Class Initialized
INFO - 2017-01-16 09:29:58 --> Hooks Class Initialized
INFO - 2017-01-16 09:29:58 --> Config Class Initialized
INFO - 2017-01-16 09:29:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:29:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:58 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:29:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:29:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:29:58 --> URI Class Initialized
INFO - 2017-01-16 09:29:58 --> URI Class Initialized
INFO - 2017-01-16 09:29:58 --> Router Class Initialized
INFO - 2017-01-16 09:29:58 --> Router Class Initialized
INFO - 2017-01-16 09:29:58 --> Output Class Initialized
INFO - 2017-01-16 09:29:58 --> Output Class Initialized
INFO - 2017-01-16 09:29:58 --> Security Class Initialized
INFO - 2017-01-16 09:29:58 --> Security Class Initialized
DEBUG - 2017-01-16 09:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:58 --> Input Class Initialized
INFO - 2017-01-16 09:29:58 --> Language Class Initialized
DEBUG - 2017-01-16 09:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:29:58 --> Input Class Initialized
INFO - 2017-01-16 09:29:58 --> Language Class Initialized
INFO - 2017-01-16 09:29:58 --> Loader Class Initialized
INFO - 2017-01-16 09:29:58 --> Loader Class Initialized
INFO - 2017-01-16 09:29:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:29:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:58 --> Controller Class Initialized
INFO - 2017-01-16 09:29:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:58 --> Model Class Initialized
INFO - 2017-01-16 09:29:58 --> Model Class Initialized
INFO - 2017-01-16 09:29:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:58 --> Total execution time: 0.0685
INFO - 2017-01-16 09:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:29:58 --> Controller Class Initialized
INFO - 2017-01-16 09:29:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:29:58 --> Model Class Initialized
INFO - 2017-01-16 09:29:58 --> Model Class Initialized
INFO - 2017-01-16 09:29:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:29:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:29:58 --> Total execution time: 0.1896
INFO - 2017-01-16 09:30:04 --> Config Class Initialized
INFO - 2017-01-16 09:30:04 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:04 --> Config Class Initialized
INFO - 2017-01-16 09:30:04 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:04 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:30:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:04 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:04 --> URI Class Initialized
INFO - 2017-01-16 09:30:04 --> URI Class Initialized
INFO - 2017-01-16 09:30:04 --> Router Class Initialized
INFO - 2017-01-16 09:30:04 --> Router Class Initialized
INFO - 2017-01-16 09:30:04 --> Output Class Initialized
INFO - 2017-01-16 09:30:04 --> Output Class Initialized
INFO - 2017-01-16 09:30:04 --> Security Class Initialized
INFO - 2017-01-16 09:30:04 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:04 --> Input Class Initialized
INFO - 2017-01-16 09:30:04 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:04 --> Input Class Initialized
INFO - 2017-01-16 09:30:04 --> Language Class Initialized
INFO - 2017-01-16 09:30:04 --> Loader Class Initialized
INFO - 2017-01-16 09:30:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:04 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:04 --> Loader Class Initialized
INFO - 2017-01-16 09:30:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:04 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:04 --> Controller Class Initialized
INFO - 2017-01-16 09:30:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:04 --> Model Class Initialized
INFO - 2017-01-16 09:30:04 --> Model Class Initialized
INFO - 2017-01-16 09:30:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:04 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:04 --> Total execution time: 0.0772
INFO - 2017-01-16 09:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:04 --> Controller Class Initialized
INFO - 2017-01-16 09:30:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:04 --> Model Class Initialized
INFO - 2017-01-16 09:30:04 --> Model Class Initialized
INFO - 2017-01-16 09:30:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:04 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:04 --> Total execution time: 0.2129
INFO - 2017-01-16 09:30:06 --> Config Class Initialized
INFO - 2017-01-16 09:30:06 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:06 --> Config Class Initialized
INFO - 2017-01-16 09:30:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:30:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:06 --> URI Class Initialized
INFO - 2017-01-16 09:30:06 --> URI Class Initialized
INFO - 2017-01-16 09:30:06 --> Router Class Initialized
INFO - 2017-01-16 09:30:06 --> Router Class Initialized
INFO - 2017-01-16 09:30:06 --> Output Class Initialized
INFO - 2017-01-16 09:30:06 --> Output Class Initialized
INFO - 2017-01-16 09:30:06 --> Security Class Initialized
INFO - 2017-01-16 09:30:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:06 --> Input Class Initialized
INFO - 2017-01-16 09:30:06 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:06 --> Input Class Initialized
INFO - 2017-01-16 09:30:06 --> Language Class Initialized
INFO - 2017-01-16 09:30:06 --> Loader Class Initialized
INFO - 2017-01-16 09:30:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:06 --> Loader Class Initialized
INFO - 2017-01-16 09:30:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:06 --> Controller Class Initialized
INFO - 2017-01-16 09:30:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:06 --> Model Class Initialized
INFO - 2017-01-16 09:30:06 --> Model Class Initialized
INFO - 2017-01-16 09:30:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:06 --> Total execution time: 0.0764
INFO - 2017-01-16 09:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:06 --> Controller Class Initialized
INFO - 2017-01-16 09:30:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:06 --> Model Class Initialized
INFO - 2017-01-16 09:30:06 --> Model Class Initialized
INFO - 2017-01-16 09:30:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:06 --> Total execution time: 0.2271
INFO - 2017-01-16 09:30:10 --> Config Class Initialized
INFO - 2017-01-16 09:30:10 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:10 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:10 --> Config Class Initialized
INFO - 2017-01-16 09:30:10 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:10 --> URI Class Initialized
INFO - 2017-01-16 09:30:10 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:10 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:10 --> Output Class Initialized
INFO - 2017-01-16 09:30:10 --> URI Class Initialized
INFO - 2017-01-16 09:30:10 --> Security Class Initialized
INFO - 2017-01-16 09:30:10 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:10 --> Input Class Initialized
INFO - 2017-01-16 09:30:10 --> Output Class Initialized
INFO - 2017-01-16 09:30:10 --> Language Class Initialized
INFO - 2017-01-16 09:30:10 --> Security Class Initialized
INFO - 2017-01-16 09:30:10 --> Loader Class Initialized
DEBUG - 2017-01-16 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:10 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:10 --> Input Class Initialized
INFO - 2017-01-16 09:30:10 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:10 --> Language Class Initialized
INFO - 2017-01-16 09:30:10 --> Loader Class Initialized
INFO - 2017-01-16 09:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:10 --> Controller Class Initialized
INFO - 2017-01-16 09:30:10 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:10 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:10 --> Model Class Initialized
INFO - 2017-01-16 09:30:10 --> Model Class Initialized
INFO - 2017-01-16 09:30:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:10 --> Total execution time: 0.0733
INFO - 2017-01-16 09:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:10 --> Controller Class Initialized
INFO - 2017-01-16 09:30:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:10 --> Model Class Initialized
INFO - 2017-01-16 09:30:10 --> Model Class Initialized
INFO - 2017-01-16 09:30:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:10 --> Total execution time: 0.2312
INFO - 2017-01-16 09:30:12 --> Config Class Initialized
INFO - 2017-01-16 09:30:12 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:12 --> Config Class Initialized
DEBUG - 2017-01-16 09:30:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:12 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:12 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:12 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:12 --> Router Class Initialized
INFO - 2017-01-16 09:30:12 --> URI Class Initialized
INFO - 2017-01-16 09:30:12 --> Output Class Initialized
INFO - 2017-01-16 09:30:12 --> Router Class Initialized
INFO - 2017-01-16 09:30:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:12 --> Input Class Initialized
INFO - 2017-01-16 09:30:12 --> Output Class Initialized
INFO - 2017-01-16 09:30:12 --> Language Class Initialized
INFO - 2017-01-16 09:30:12 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:12 --> Loader Class Initialized
INFO - 2017-01-16 09:30:12 --> Input Class Initialized
INFO - 2017-01-16 09:30:12 --> Language Class Initialized
INFO - 2017-01-16 09:30:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:12 --> Loader Class Initialized
INFO - 2017-01-16 09:30:12 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:12 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:12 --> Controller Class Initialized
INFO - 2017-01-16 09:30:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:12 --> Model Class Initialized
INFO - 2017-01-16 09:30:12 --> Model Class Initialized
INFO - 2017-01-16 09:30:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:12 --> Total execution time: 0.0769
INFO - 2017-01-16 09:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:12 --> Controller Class Initialized
INFO - 2017-01-16 09:30:12 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:12 --> Model Class Initialized
INFO - 2017-01-16 09:30:12 --> Model Class Initialized
INFO - 2017-01-16 09:30:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:12 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:12 --> Total execution time: 0.2531
INFO - 2017-01-16 09:30:16 --> Config Class Initialized
INFO - 2017-01-16 09:30:16 --> Config Class Initialized
INFO - 2017-01-16 09:30:16 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:30:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:16 --> URI Class Initialized
INFO - 2017-01-16 09:30:16 --> URI Class Initialized
INFO - 2017-01-16 09:30:16 --> Router Class Initialized
INFO - 2017-01-16 09:30:16 --> Router Class Initialized
INFO - 2017-01-16 09:30:16 --> Output Class Initialized
INFO - 2017-01-16 09:30:16 --> Output Class Initialized
INFO - 2017-01-16 09:30:16 --> Security Class Initialized
INFO - 2017-01-16 09:30:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:16 --> Input Class Initialized
DEBUG - 2017-01-16 09:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:16 --> Input Class Initialized
INFO - 2017-01-16 09:30:16 --> Language Class Initialized
INFO - 2017-01-16 09:30:16 --> Language Class Initialized
INFO - 2017-01-16 09:30:16 --> Loader Class Initialized
INFO - 2017-01-16 09:30:16 --> Loader Class Initialized
INFO - 2017-01-16 09:30:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:16 --> Controller Class Initialized
INFO - 2017-01-16 09:30:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:16 --> Model Class Initialized
INFO - 2017-01-16 09:30:16 --> Model Class Initialized
INFO - 2017-01-16 09:30:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:16 --> Total execution time: 0.0762
INFO - 2017-01-16 09:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:16 --> Controller Class Initialized
INFO - 2017-01-16 09:30:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:16 --> Model Class Initialized
INFO - 2017-01-16 09:30:16 --> Model Class Initialized
INFO - 2017-01-16 09:30:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:16 --> Total execution time: 0.2441
INFO - 2017-01-16 09:30:18 --> Config Class Initialized
INFO - 2017-01-16 09:30:18 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:18 --> Config Class Initialized
INFO - 2017-01-16 09:30:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:18 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:18 --> URI Class Initialized
INFO - 2017-01-16 09:30:18 --> Router Class Initialized
INFO - 2017-01-16 09:30:18 --> Config Class Initialized
INFO - 2017-01-16 09:30:18 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:18 --> Output Class Initialized
INFO - 2017-01-16 09:30:18 --> Router Class Initialized
INFO - 2017-01-16 09:30:18 --> Security Class Initialized
INFO - 2017-01-16 09:30:18 --> Output Class Initialized
DEBUG - 2017-01-16 09:30:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:18 --> Security Class Initialized
INFO - 2017-01-16 09:30:18 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:18 --> Input Class Initialized
INFO - 2017-01-16 09:30:18 --> Input Class Initialized
INFO - 2017-01-16 09:30:18 --> Language Class Initialized
INFO - 2017-01-16 09:30:18 --> Router Class Initialized
INFO - 2017-01-16 09:30:18 --> Language Class Initialized
INFO - 2017-01-16 09:30:18 --> Output Class Initialized
INFO - 2017-01-16 09:30:18 --> Security Class Initialized
INFO - 2017-01-16 09:30:18 --> Loader Class Initialized
INFO - 2017-01-16 09:30:18 --> Loader Class Initialized
DEBUG - 2017-01-16 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:18 --> Input Class Initialized
INFO - 2017-01-16 09:30:18 --> Language Class Initialized
INFO - 2017-01-16 09:30:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:18 --> Loader Class Initialized
INFO - 2017-01-16 09:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:18 --> Controller Class Initialized
INFO - 2017-01-16 09:30:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:18 --> Model Class Initialized
INFO - 2017-01-16 09:30:18 --> Model Class Initialized
INFO - 2017-01-16 09:30:18 --> Model Class Initialized
INFO - 2017-01-16 09:30:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:19 --> Total execution time: 0.2650
INFO - 2017-01-16 09:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:19 --> Controller Class Initialized
INFO - 2017-01-16 09:30:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:19 --> Total execution time: 0.2910
INFO - 2017-01-16 09:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:19 --> Controller Class Initialized
INFO - 2017-01-16 09:30:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:19 --> Config Class Initialized
INFO - 2017-01-16 09:30:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:19 --> URI Class Initialized
INFO - 2017-01-16 09:30:19 --> Router Class Initialized
INFO - 2017-01-16 09:30:19 --> Output Class Initialized
INFO - 2017-01-16 09:30:19 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:19 --> Input Class Initialized
INFO - 2017-01-16 09:30:19 --> Language Class Initialized
INFO - 2017-01-16 09:30:19 --> Loader Class Initialized
INFO - 2017-01-16 09:30:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:19 --> Controller Class Initialized
INFO - 2017-01-16 09:30:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Model Class Initialized
INFO - 2017-01-16 09:30:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:30:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2017-01-16 09:30:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:30:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:19 --> Total execution time: 0.0666
INFO - 2017-01-16 09:30:21 --> Config Class Initialized
INFO - 2017-01-16 09:30:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:21 --> URI Class Initialized
INFO - 2017-01-16 09:30:21 --> Router Class Initialized
INFO - 2017-01-16 09:30:21 --> Output Class Initialized
INFO - 2017-01-16 09:30:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:21 --> Input Class Initialized
INFO - 2017-01-16 09:30:21 --> Language Class Initialized
INFO - 2017-01-16 09:30:21 --> Loader Class Initialized
INFO - 2017-01-16 09:30:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:21 --> Controller Class Initialized
INFO - 2017-01-16 09:30:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:21 --> Config Class Initialized
INFO - 2017-01-16 09:30:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:21 --> URI Class Initialized
INFO - 2017-01-16 09:30:21 --> Router Class Initialized
INFO - 2017-01-16 09:30:21 --> Output Class Initialized
INFO - 2017-01-16 09:30:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:21 --> Input Class Initialized
INFO - 2017-01-16 09:30:21 --> Language Class Initialized
INFO - 2017-01-16 09:30:21 --> Loader Class Initialized
INFO - 2017-01-16 09:30:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:21 --> Controller Class Initialized
INFO - 2017-01-16 09:30:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06_attempt.php
INFO - 2017-01-16 09:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:30:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:21 --> Total execution time: 0.0771
INFO - 2017-01-16 09:30:21 --> Config Class Initialized
INFO - 2017-01-16 09:30:21 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:21 --> Config Class Initialized
INFO - 2017-01-16 09:30:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:21 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:30:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:21 --> URI Class Initialized
INFO - 2017-01-16 09:30:21 --> URI Class Initialized
INFO - 2017-01-16 09:30:21 --> Router Class Initialized
INFO - 2017-01-16 09:30:21 --> Router Class Initialized
INFO - 2017-01-16 09:30:21 --> Output Class Initialized
INFO - 2017-01-16 09:30:21 --> Output Class Initialized
INFO - 2017-01-16 09:30:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:21 --> Security Class Initialized
INFO - 2017-01-16 09:30:21 --> Input Class Initialized
INFO - 2017-01-16 09:30:21 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:21 --> Input Class Initialized
INFO - 2017-01-16 09:30:21 --> Language Class Initialized
INFO - 2017-01-16 09:30:21 --> Loader Class Initialized
INFO - 2017-01-16 09:30:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:21 --> Loader Class Initialized
INFO - 2017-01-16 09:30:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:21 --> Controller Class Initialized
INFO - 2017-01-16 09:30:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:21 --> Total execution time: 0.0933
INFO - 2017-01-16 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:21 --> Controller Class Initialized
INFO - 2017-01-16 09:30:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Model Class Initialized
INFO - 2017-01-16 09:30:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:30:21 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:30:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:30:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:21 --> Total execution time: 0.1173
INFO - 2017-01-16 09:30:24 --> Config Class Initialized
INFO - 2017-01-16 09:30:24 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:24 --> Config Class Initialized
INFO - 2017-01-16 09:30:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:24 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:24 --> Router Class Initialized
INFO - 2017-01-16 09:30:24 --> URI Class Initialized
INFO - 2017-01-16 09:30:24 --> Output Class Initialized
INFO - 2017-01-16 09:30:24 --> Router Class Initialized
INFO - 2017-01-16 09:30:24 --> Security Class Initialized
INFO - 2017-01-16 09:30:24 --> Output Class Initialized
DEBUG - 2017-01-16 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:24 --> Input Class Initialized
INFO - 2017-01-16 09:30:24 --> Security Class Initialized
INFO - 2017-01-16 09:30:24 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:24 --> Input Class Initialized
INFO - 2017-01-16 09:30:24 --> Language Class Initialized
INFO - 2017-01-16 09:30:24 --> Loader Class Initialized
INFO - 2017-01-16 09:30:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:24 --> Loader Class Initialized
INFO - 2017-01-16 09:30:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:24 --> Controller Class Initialized
INFO - 2017-01-16 09:30:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:24 --> Model Class Initialized
INFO - 2017-01-16 09:30:24 --> Model Class Initialized
INFO - 2017-01-16 09:30:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:24 --> Total execution time: 0.0714
INFO - 2017-01-16 09:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:24 --> Controller Class Initialized
INFO - 2017-01-16 09:30:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:24 --> Model Class Initialized
INFO - 2017-01-16 09:30:24 --> Model Class Initialized
INFO - 2017-01-16 09:30:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:24 --> Total execution time: 0.0971
INFO - 2017-01-16 09:30:26 --> Config Class Initialized
INFO - 2017-01-16 09:30:26 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:26 --> Config Class Initialized
INFO - 2017-01-16 09:30:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:26 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:26 --> URI Class Initialized
INFO - 2017-01-16 09:30:26 --> Router Class Initialized
INFO - 2017-01-16 09:30:26 --> Router Class Initialized
INFO - 2017-01-16 09:30:26 --> Output Class Initialized
INFO - 2017-01-16 09:30:26 --> Output Class Initialized
INFO - 2017-01-16 09:30:26 --> Security Class Initialized
INFO - 2017-01-16 09:30:26 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:26 --> Input Class Initialized
INFO - 2017-01-16 09:30:26 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:26 --> Input Class Initialized
INFO - 2017-01-16 09:30:26 --> Language Class Initialized
INFO - 2017-01-16 09:30:26 --> Loader Class Initialized
INFO - 2017-01-16 09:30:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:26 --> Loader Class Initialized
INFO - 2017-01-16 09:30:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:26 --> Controller Class Initialized
INFO - 2017-01-16 09:30:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:26 --> Model Class Initialized
INFO - 2017-01-16 09:30:26 --> Model Class Initialized
INFO - 2017-01-16 09:30:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:26 --> Total execution time: 0.0759
INFO - 2017-01-16 09:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:26 --> Controller Class Initialized
INFO - 2017-01-16 09:30:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:26 --> Model Class Initialized
INFO - 2017-01-16 09:30:26 --> Model Class Initialized
INFO - 2017-01-16 09:30:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:26 --> Total execution time: 0.1098
INFO - 2017-01-16 09:30:28 --> Config Class Initialized
INFO - 2017-01-16 09:30:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:28 --> URI Class Initialized
INFO - 2017-01-16 09:30:28 --> Router Class Initialized
INFO - 2017-01-16 09:30:28 --> Config Class Initialized
INFO - 2017-01-16 09:30:28 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:28 --> Output Class Initialized
INFO - 2017-01-16 09:30:28 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:28 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:28 --> Input Class Initialized
INFO - 2017-01-16 09:30:28 --> URI Class Initialized
INFO - 2017-01-16 09:30:28 --> Language Class Initialized
INFO - 2017-01-16 09:30:28 --> Router Class Initialized
INFO - 2017-01-16 09:30:28 --> Loader Class Initialized
INFO - 2017-01-16 09:30:28 --> Output Class Initialized
INFO - 2017-01-16 09:30:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:28 --> Security Class Initialized
INFO - 2017-01-16 09:30:28 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:28 --> Input Class Initialized
INFO - 2017-01-16 09:30:28 --> Language Class Initialized
INFO - 2017-01-16 09:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:28 --> Controller Class Initialized
INFO - 2017-01-16 09:30:28 --> Loader Class Initialized
INFO - 2017-01-16 09:30:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:28 --> Model Class Initialized
INFO - 2017-01-16 09:30:28 --> Model Class Initialized
INFO - 2017-01-16 09:30:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:28 --> Total execution time: 0.0785
INFO - 2017-01-16 09:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:28 --> Controller Class Initialized
INFO - 2017-01-16 09:30:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:28 --> Model Class Initialized
INFO - 2017-01-16 09:30:28 --> Model Class Initialized
INFO - 2017-01-16 09:30:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:28 --> Total execution time: 0.1251
INFO - 2017-01-16 09:30:30 --> Config Class Initialized
INFO - 2017-01-16 09:30:30 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:30 --> Config Class Initialized
INFO - 2017-01-16 09:30:30 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:30 --> URI Class Initialized
INFO - 2017-01-16 09:30:30 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:30 --> URI Class Initialized
INFO - 2017-01-16 09:30:30 --> Output Class Initialized
INFO - 2017-01-16 09:30:30 --> Security Class Initialized
INFO - 2017-01-16 09:30:30 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:30 --> Input Class Initialized
INFO - 2017-01-16 09:30:30 --> Output Class Initialized
INFO - 2017-01-16 09:30:30 --> Language Class Initialized
INFO - 2017-01-16 09:30:30 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:30 --> Loader Class Initialized
INFO - 2017-01-16 09:30:30 --> Input Class Initialized
INFO - 2017-01-16 09:30:30 --> Language Class Initialized
INFO - 2017-01-16 09:30:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:30 --> Loader Class Initialized
INFO - 2017-01-16 09:30:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:30 --> Controller Class Initialized
INFO - 2017-01-16 09:30:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:30 --> Model Class Initialized
INFO - 2017-01-16 09:30:30 --> Model Class Initialized
INFO - 2017-01-16 09:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:30 --> Total execution time: 0.0803
INFO - 2017-01-16 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:30 --> Controller Class Initialized
INFO - 2017-01-16 09:30:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:30 --> Model Class Initialized
INFO - 2017-01-16 09:30:30 --> Model Class Initialized
INFO - 2017-01-16 09:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:30 --> Total execution time: 0.1314
INFO - 2017-01-16 09:30:33 --> Config Class Initialized
INFO - 2017-01-16 09:30:33 --> Config Class Initialized
INFO - 2017-01-16 09:30:33 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:30:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:33 --> URI Class Initialized
INFO - 2017-01-16 09:30:33 --> URI Class Initialized
INFO - 2017-01-16 09:30:33 --> Router Class Initialized
INFO - 2017-01-16 09:30:33 --> Router Class Initialized
INFO - 2017-01-16 09:30:33 --> Output Class Initialized
INFO - 2017-01-16 09:30:33 --> Output Class Initialized
INFO - 2017-01-16 09:30:33 --> Security Class Initialized
INFO - 2017-01-16 09:30:33 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:33 --> Input Class Initialized
DEBUG - 2017-01-16 09:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:33 --> Input Class Initialized
INFO - 2017-01-16 09:30:33 --> Language Class Initialized
INFO - 2017-01-16 09:30:33 --> Language Class Initialized
INFO - 2017-01-16 09:30:33 --> Loader Class Initialized
INFO - 2017-01-16 09:30:33 --> Loader Class Initialized
INFO - 2017-01-16 09:30:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:33 --> Controller Class Initialized
INFO - 2017-01-16 09:30:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:33 --> Model Class Initialized
INFO - 2017-01-16 09:30:33 --> Model Class Initialized
INFO - 2017-01-16 09:30:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:33 --> Total execution time: 0.0702
INFO - 2017-01-16 09:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:33 --> Controller Class Initialized
INFO - 2017-01-16 09:30:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:33 --> Model Class Initialized
INFO - 2017-01-16 09:30:33 --> Model Class Initialized
INFO - 2017-01-16 09:30:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:33 --> Total execution time: 0.1290
INFO - 2017-01-16 09:30:35 --> Config Class Initialized
INFO - 2017-01-16 09:30:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:35 --> Config Class Initialized
INFO - 2017-01-16 09:30:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:35 --> URI Class Initialized
INFO - 2017-01-16 09:30:35 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:35 --> Output Class Initialized
INFO - 2017-01-16 09:30:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:35 --> Security Class Initialized
INFO - 2017-01-16 09:30:35 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:35 --> Input Class Initialized
INFO - 2017-01-16 09:30:35 --> Router Class Initialized
INFO - 2017-01-16 09:30:35 --> Language Class Initialized
INFO - 2017-01-16 09:30:35 --> Output Class Initialized
INFO - 2017-01-16 09:30:35 --> Security Class Initialized
INFO - 2017-01-16 09:30:35 --> Loader Class Initialized
INFO - 2017-01-16 09:30:35 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:35 --> Input Class Initialized
INFO - 2017-01-16 09:30:35 --> Language Class Initialized
INFO - 2017-01-16 09:30:35 --> Loader Class Initialized
INFO - 2017-01-16 09:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:35 --> Controller Class Initialized
INFO - 2017-01-16 09:30:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:35 --> Model Class Initialized
INFO - 2017-01-16 09:30:35 --> Model Class Initialized
INFO - 2017-01-16 09:30:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:35 --> Total execution time: 0.0745
INFO - 2017-01-16 09:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:35 --> Controller Class Initialized
INFO - 2017-01-16 09:30:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:35 --> Model Class Initialized
INFO - 2017-01-16 09:30:35 --> Model Class Initialized
INFO - 2017-01-16 09:30:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:35 --> Total execution time: 0.1369
INFO - 2017-01-16 09:30:37 --> Config Class Initialized
INFO - 2017-01-16 09:30:37 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:37 --> Config Class Initialized
INFO - 2017-01-16 09:30:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:37 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:37 --> Router Class Initialized
INFO - 2017-01-16 09:30:37 --> URI Class Initialized
INFO - 2017-01-16 09:30:37 --> Output Class Initialized
INFO - 2017-01-16 09:30:37 --> Router Class Initialized
INFO - 2017-01-16 09:30:37 --> Security Class Initialized
INFO - 2017-01-16 09:30:37 --> Output Class Initialized
DEBUG - 2017-01-16 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:37 --> Input Class Initialized
INFO - 2017-01-16 09:30:37 --> Security Class Initialized
INFO - 2017-01-16 09:30:37 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:37 --> Input Class Initialized
INFO - 2017-01-16 09:30:37 --> Language Class Initialized
INFO - 2017-01-16 09:30:37 --> Loader Class Initialized
INFO - 2017-01-16 09:30:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:37 --> Loader Class Initialized
INFO - 2017-01-16 09:30:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:37 --> Controller Class Initialized
INFO - 2017-01-16 09:30:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:37 --> Model Class Initialized
INFO - 2017-01-16 09:30:37 --> Model Class Initialized
INFO - 2017-01-16 09:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:37 --> Total execution time: 0.0794
INFO - 2017-01-16 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:37 --> Controller Class Initialized
INFO - 2017-01-16 09:30:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:37 --> Model Class Initialized
INFO - 2017-01-16 09:30:37 --> Model Class Initialized
INFO - 2017-01-16 09:30:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:37 --> Total execution time: 0.1618
INFO - 2017-01-16 09:30:39 --> Config Class Initialized
INFO - 2017-01-16 09:30:39 --> Config Class Initialized
INFO - 2017-01-16 09:30:39 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:30:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:39 --> URI Class Initialized
INFO - 2017-01-16 09:30:39 --> URI Class Initialized
INFO - 2017-01-16 09:30:39 --> Router Class Initialized
INFO - 2017-01-16 09:30:39 --> Router Class Initialized
INFO - 2017-01-16 09:30:39 --> Output Class Initialized
INFO - 2017-01-16 09:30:39 --> Output Class Initialized
INFO - 2017-01-16 09:30:39 --> Security Class Initialized
INFO - 2017-01-16 09:30:39 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:39 --> Input Class Initialized
INFO - 2017-01-16 09:30:39 --> Input Class Initialized
INFO - 2017-01-16 09:30:39 --> Language Class Initialized
INFO - 2017-01-16 09:30:39 --> Language Class Initialized
INFO - 2017-01-16 09:30:39 --> Loader Class Initialized
INFO - 2017-01-16 09:30:39 --> Loader Class Initialized
INFO - 2017-01-16 09:30:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:39 --> Controller Class Initialized
INFO - 2017-01-16 09:30:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:39 --> Model Class Initialized
INFO - 2017-01-16 09:30:39 --> Model Class Initialized
INFO - 2017-01-16 09:30:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:39 --> Total execution time: 0.0807
INFO - 2017-01-16 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:39 --> Controller Class Initialized
INFO - 2017-01-16 09:30:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:39 --> Model Class Initialized
INFO - 2017-01-16 09:30:39 --> Model Class Initialized
INFO - 2017-01-16 09:30:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:39 --> Total execution time: 0.1789
INFO - 2017-01-16 09:30:41 --> Config Class Initialized
INFO - 2017-01-16 09:30:41 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:41 --> Config Class Initialized
INFO - 2017-01-16 09:30:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:41 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:30:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:41 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:41 --> URI Class Initialized
INFO - 2017-01-16 09:30:41 --> URI Class Initialized
INFO - 2017-01-16 09:30:41 --> Router Class Initialized
INFO - 2017-01-16 09:30:41 --> Router Class Initialized
INFO - 2017-01-16 09:30:41 --> Output Class Initialized
INFO - 2017-01-16 09:30:41 --> Output Class Initialized
INFO - 2017-01-16 09:30:41 --> Security Class Initialized
INFO - 2017-01-16 09:30:41 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:41 --> Input Class Initialized
INFO - 2017-01-16 09:30:41 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:41 --> Input Class Initialized
INFO - 2017-01-16 09:30:41 --> Language Class Initialized
INFO - 2017-01-16 09:30:41 --> Loader Class Initialized
INFO - 2017-01-16 09:30:41 --> Loader Class Initialized
INFO - 2017-01-16 09:30:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:41 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:41 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:41 --> Controller Class Initialized
INFO - 2017-01-16 09:30:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:41 --> Model Class Initialized
INFO - 2017-01-16 09:30:41 --> Model Class Initialized
INFO - 2017-01-16 09:30:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:41 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:41 --> Total execution time: 0.0682
INFO - 2017-01-16 09:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:41 --> Controller Class Initialized
INFO - 2017-01-16 09:30:41 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:41 --> Model Class Initialized
INFO - 2017-01-16 09:30:41 --> Model Class Initialized
INFO - 2017-01-16 09:30:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:42 --> Total execution time: 0.1542
INFO - 2017-01-16 09:30:44 --> Config Class Initialized
INFO - 2017-01-16 09:30:44 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:44 --> Config Class Initialized
INFO - 2017-01-16 09:30:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:44 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:30:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:44 --> URI Class Initialized
INFO - 2017-01-16 09:30:44 --> URI Class Initialized
INFO - 2017-01-16 09:30:44 --> Router Class Initialized
INFO - 2017-01-16 09:30:44 --> Router Class Initialized
INFO - 2017-01-16 09:30:44 --> Output Class Initialized
INFO - 2017-01-16 09:30:44 --> Security Class Initialized
INFO - 2017-01-16 09:30:44 --> Output Class Initialized
INFO - 2017-01-16 09:30:44 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:44 --> Input Class Initialized
INFO - 2017-01-16 09:30:44 --> Input Class Initialized
INFO - 2017-01-16 09:30:44 --> Language Class Initialized
INFO - 2017-01-16 09:30:44 --> Language Class Initialized
INFO - 2017-01-16 09:30:44 --> Loader Class Initialized
INFO - 2017-01-16 09:30:44 --> Loader Class Initialized
INFO - 2017-01-16 09:30:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:44 --> Controller Class Initialized
INFO - 2017-01-16 09:30:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:44 --> Model Class Initialized
INFO - 2017-01-16 09:30:44 --> Model Class Initialized
INFO - 2017-01-16 09:30:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:44 --> Total execution time: 0.1625
INFO - 2017-01-16 09:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:44 --> Controller Class Initialized
INFO - 2017-01-16 09:30:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:44 --> Model Class Initialized
INFO - 2017-01-16 09:30:44 --> Model Class Initialized
INFO - 2017-01-16 09:30:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:44 --> Total execution time: 0.1897
INFO - 2017-01-16 09:30:46 --> Config Class Initialized
INFO - 2017-01-16 09:30:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:46 --> Config Class Initialized
INFO - 2017-01-16 09:30:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:46 --> URI Class Initialized
INFO - 2017-01-16 09:30:46 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:46 --> Output Class Initialized
INFO - 2017-01-16 09:30:46 --> URI Class Initialized
INFO - 2017-01-16 09:30:46 --> Security Class Initialized
INFO - 2017-01-16 09:30:46 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:46 --> Input Class Initialized
INFO - 2017-01-16 09:30:46 --> Output Class Initialized
INFO - 2017-01-16 09:30:46 --> Language Class Initialized
INFO - 2017-01-16 09:30:46 --> Security Class Initialized
INFO - 2017-01-16 09:30:46 --> Loader Class Initialized
DEBUG - 2017-01-16 09:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:46 --> Input Class Initialized
INFO - 2017-01-16 09:30:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:46 --> Language Class Initialized
INFO - 2017-01-16 09:30:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:46 --> Loader Class Initialized
INFO - 2017-01-16 09:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:46 --> Controller Class Initialized
INFO - 2017-01-16 09:30:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:46 --> Model Class Initialized
INFO - 2017-01-16 09:30:46 --> Model Class Initialized
INFO - 2017-01-16 09:30:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:46 --> Total execution time: 0.0670
INFO - 2017-01-16 09:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:46 --> Controller Class Initialized
INFO - 2017-01-16 09:30:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:46 --> Model Class Initialized
INFO - 2017-01-16 09:30:46 --> Model Class Initialized
INFO - 2017-01-16 09:30:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:46 --> Total execution time: 0.1622
INFO - 2017-01-16 09:30:48 --> Config Class Initialized
INFO - 2017-01-16 09:30:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:48 --> Config Class Initialized
INFO - 2017-01-16 09:30:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:48 --> URI Class Initialized
INFO - 2017-01-16 09:30:48 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:48 --> Output Class Initialized
INFO - 2017-01-16 09:30:48 --> URI Class Initialized
INFO - 2017-01-16 09:30:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:48 --> Input Class Initialized
INFO - 2017-01-16 09:30:48 --> Router Class Initialized
INFO - 2017-01-16 09:30:48 --> Language Class Initialized
INFO - 2017-01-16 09:30:48 --> Output Class Initialized
INFO - 2017-01-16 09:30:48 --> Loader Class Initialized
INFO - 2017-01-16 09:30:48 --> Security Class Initialized
INFO - 2017-01-16 09:30:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:48 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:48 --> Input Class Initialized
INFO - 2017-01-16 09:30:48 --> Language Class Initialized
INFO - 2017-01-16 09:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:48 --> Controller Class Initialized
INFO - 2017-01-16 09:30:48 --> Loader Class Initialized
INFO - 2017-01-16 09:30:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:48 --> Model Class Initialized
INFO - 2017-01-16 09:30:48 --> Model Class Initialized
INFO - 2017-01-16 09:30:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:48 --> Total execution time: 0.0828
INFO - 2017-01-16 09:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:48 --> Controller Class Initialized
INFO - 2017-01-16 09:30:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:48 --> Model Class Initialized
INFO - 2017-01-16 09:30:48 --> Model Class Initialized
INFO - 2017-01-16 09:30:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:48 --> Total execution time: 0.1987
INFO - 2017-01-16 09:30:50 --> Config Class Initialized
INFO - 2017-01-16 09:30:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:51 --> Config Class Initialized
DEBUG - 2017-01-16 09:30:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:51 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:51 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:51 --> URI Class Initialized
INFO - 2017-01-16 09:30:51 --> Router Class Initialized
INFO - 2017-01-16 09:30:51 --> Router Class Initialized
INFO - 2017-01-16 09:30:51 --> Output Class Initialized
INFO - 2017-01-16 09:30:51 --> Output Class Initialized
INFO - 2017-01-16 09:30:51 --> Security Class Initialized
INFO - 2017-01-16 09:30:51 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:51 --> Input Class Initialized
INFO - 2017-01-16 09:30:51 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:51 --> Input Class Initialized
INFO - 2017-01-16 09:30:51 --> Language Class Initialized
INFO - 2017-01-16 09:30:51 --> Loader Class Initialized
INFO - 2017-01-16 09:30:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:51 --> Loader Class Initialized
INFO - 2017-01-16 09:30:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:51 --> Controller Class Initialized
INFO - 2017-01-16 09:30:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:51 --> Total execution time: 0.0746
INFO - 2017-01-16 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:51 --> Controller Class Initialized
INFO - 2017-01-16 09:30:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:51 --> Total execution time: 0.1793
INFO - 2017-01-16 09:30:51 --> Config Class Initialized
INFO - 2017-01-16 09:30:51 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:51 --> URI Class Initialized
INFO - 2017-01-16 09:30:51 --> Router Class Initialized
INFO - 2017-01-16 09:30:51 --> Output Class Initialized
INFO - 2017-01-16 09:30:51 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:51 --> Input Class Initialized
INFO - 2017-01-16 09:30:51 --> Language Class Initialized
INFO - 2017-01-16 09:30:51 --> Loader Class Initialized
INFO - 2017-01-16 09:30:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:51 --> Controller Class Initialized
INFO - 2017-01-16 09:30:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Model Class Initialized
INFO - 2017-01-16 09:30:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:51 --> Total execution time: 0.0622
INFO - 2017-01-16 09:30:53 --> Config Class Initialized
INFO - 2017-01-16 09:30:53 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:53 --> Config Class Initialized
INFO - 2017-01-16 09:30:53 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:53 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:30:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:53 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:53 --> URI Class Initialized
INFO - 2017-01-16 09:30:53 --> URI Class Initialized
INFO - 2017-01-16 09:30:53 --> Router Class Initialized
INFO - 2017-01-16 09:30:53 --> Router Class Initialized
INFO - 2017-01-16 09:30:53 --> Output Class Initialized
INFO - 2017-01-16 09:30:53 --> Output Class Initialized
INFO - 2017-01-16 09:30:53 --> Security Class Initialized
INFO - 2017-01-16 09:30:53 --> Security Class Initialized
DEBUG - 2017-01-16 09:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:53 --> Input Class Initialized
INFO - 2017-01-16 09:30:53 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:53 --> Input Class Initialized
INFO - 2017-01-16 09:30:53 --> Loader Class Initialized
INFO - 2017-01-16 09:30:53 --> Language Class Initialized
INFO - 2017-01-16 09:30:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:53 --> Loader Class Initialized
INFO - 2017-01-16 09:30:53 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:53 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:53 --> Controller Class Initialized
INFO - 2017-01-16 09:30:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:53 --> Model Class Initialized
INFO - 2017-01-16 09:30:53 --> Model Class Initialized
INFO - 2017-01-16 09:30:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:53 --> Total execution time: 0.0752
INFO - 2017-01-16 09:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:53 --> Controller Class Initialized
INFO - 2017-01-16 09:30:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:53 --> Model Class Initialized
INFO - 2017-01-16 09:30:53 --> Model Class Initialized
INFO - 2017-01-16 09:30:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:53 --> Total execution time: 0.1981
INFO - 2017-01-16 09:30:55 --> Config Class Initialized
INFO - 2017-01-16 09:30:55 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:55 --> Config Class Initialized
INFO - 2017-01-16 09:30:55 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:55 --> URI Class Initialized
DEBUG - 2017-01-16 09:30:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:55 --> Router Class Initialized
INFO - 2017-01-16 09:30:55 --> URI Class Initialized
INFO - 2017-01-16 09:30:55 --> Router Class Initialized
INFO - 2017-01-16 09:30:55 --> Output Class Initialized
INFO - 2017-01-16 09:30:55 --> Security Class Initialized
INFO - 2017-01-16 09:30:55 --> Output Class Initialized
DEBUG - 2017-01-16 09:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:55 --> Security Class Initialized
INFO - 2017-01-16 09:30:55 --> Input Class Initialized
INFO - 2017-01-16 09:30:55 --> Language Class Initialized
DEBUG - 2017-01-16 09:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:55 --> Input Class Initialized
INFO - 2017-01-16 09:30:55 --> Loader Class Initialized
INFO - 2017-01-16 09:30:55 --> Language Class Initialized
INFO - 2017-01-16 09:30:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:55 --> Loader Class Initialized
INFO - 2017-01-16 09:30:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:55 --> Controller Class Initialized
INFO - 2017-01-16 09:30:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:55 --> Model Class Initialized
INFO - 2017-01-16 09:30:55 --> Model Class Initialized
INFO - 2017-01-16 09:30:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:55 --> Total execution time: 0.0758
INFO - 2017-01-16 09:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:55 --> Controller Class Initialized
INFO - 2017-01-16 09:30:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:55 --> Model Class Initialized
INFO - 2017-01-16 09:30:55 --> Model Class Initialized
INFO - 2017-01-16 09:30:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:55 --> Total execution time: 0.2260
INFO - 2017-01-16 09:30:58 --> Config Class Initialized
INFO - 2017-01-16 09:30:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:30:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:58 --> Config Class Initialized
INFO - 2017-01-16 09:30:58 --> Hooks Class Initialized
INFO - 2017-01-16 09:30:58 --> URI Class Initialized
INFO - 2017-01-16 09:30:58 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:30:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:30:58 --> Output Class Initialized
INFO - 2017-01-16 09:30:58 --> URI Class Initialized
INFO - 2017-01-16 09:30:58 --> Security Class Initialized
INFO - 2017-01-16 09:30:58 --> Router Class Initialized
DEBUG - 2017-01-16 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:58 --> Input Class Initialized
INFO - 2017-01-16 09:30:58 --> Language Class Initialized
INFO - 2017-01-16 09:30:58 --> Output Class Initialized
INFO - 2017-01-16 09:30:58 --> Security Class Initialized
INFO - 2017-01-16 09:30:58 --> Loader Class Initialized
DEBUG - 2017-01-16 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:30:58 --> Input Class Initialized
INFO - 2017-01-16 09:30:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:58 --> Language Class Initialized
INFO - 2017-01-16 09:30:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:58 --> Loader Class Initialized
INFO - 2017-01-16 09:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:58 --> Controller Class Initialized
INFO - 2017-01-16 09:30:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:30:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:30:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:58 --> Model Class Initialized
INFO - 2017-01-16 09:30:58 --> Model Class Initialized
INFO - 2017-01-16 09:30:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:58 --> Total execution time: 0.0677
INFO - 2017-01-16 09:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:30:58 --> Controller Class Initialized
INFO - 2017-01-16 09:30:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:30:58 --> Model Class Initialized
INFO - 2017-01-16 09:30:58 --> Model Class Initialized
INFO - 2017-01-16 09:30:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:30:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:30:58 --> Total execution time: 0.2028
INFO - 2017-01-16 09:31:00 --> Config Class Initialized
INFO - 2017-01-16 09:31:00 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:00 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:00 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:00 --> Config Class Initialized
INFO - 2017-01-16 09:31:00 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:00 --> URI Class Initialized
INFO - 2017-01-16 09:31:00 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:00 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:00 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:00 --> Output Class Initialized
INFO - 2017-01-16 09:31:00 --> URI Class Initialized
INFO - 2017-01-16 09:31:00 --> Security Class Initialized
INFO - 2017-01-16 09:31:00 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:00 --> Input Class Initialized
INFO - 2017-01-16 09:31:00 --> Output Class Initialized
INFO - 2017-01-16 09:31:00 --> Language Class Initialized
INFO - 2017-01-16 09:31:00 --> Security Class Initialized
INFO - 2017-01-16 09:31:00 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:00 --> Input Class Initialized
INFO - 2017-01-16 09:31:00 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:00 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:00 --> Language Class Initialized
INFO - 2017-01-16 09:31:00 --> Loader Class Initialized
INFO - 2017-01-16 09:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:00 --> Controller Class Initialized
INFO - 2017-01-16 09:31:00 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:00 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:00 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:00 --> Model Class Initialized
INFO - 2017-01-16 09:31:00 --> Model Class Initialized
INFO - 2017-01-16 09:31:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:00 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:00 --> Total execution time: 0.0755
INFO - 2017-01-16 09:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:00 --> Controller Class Initialized
INFO - 2017-01-16 09:31:00 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:00 --> Model Class Initialized
INFO - 2017-01-16 09:31:00 --> Model Class Initialized
INFO - 2017-01-16 09:31:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:00 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:00 --> Total execution time: 0.2248
INFO - 2017-01-16 09:31:02 --> Config Class Initialized
INFO - 2017-01-16 09:31:02 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:02 --> Config Class Initialized
INFO - 2017-01-16 09:31:02 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:02 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:31:02 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:02 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:02 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:02 --> URI Class Initialized
INFO - 2017-01-16 09:31:02 --> URI Class Initialized
INFO - 2017-01-16 09:31:02 --> Router Class Initialized
INFO - 2017-01-16 09:31:02 --> Router Class Initialized
INFO - 2017-01-16 09:31:02 --> Output Class Initialized
INFO - 2017-01-16 09:31:02 --> Output Class Initialized
INFO - 2017-01-16 09:31:02 --> Security Class Initialized
INFO - 2017-01-16 09:31:02 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:02 --> Input Class Initialized
DEBUG - 2017-01-16 09:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:02 --> Language Class Initialized
INFO - 2017-01-16 09:31:02 --> Input Class Initialized
INFO - 2017-01-16 09:31:02 --> Language Class Initialized
INFO - 2017-01-16 09:31:02 --> Loader Class Initialized
INFO - 2017-01-16 09:31:02 --> Loader Class Initialized
INFO - 2017-01-16 09:31:02 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:02 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:02 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:02 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:02 --> Controller Class Initialized
INFO - 2017-01-16 09:31:02 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:02 --> Model Class Initialized
INFO - 2017-01-16 09:31:02 --> Model Class Initialized
INFO - 2017-01-16 09:31:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:02 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:02 --> Total execution time: 0.0720
INFO - 2017-01-16 09:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:02 --> Controller Class Initialized
INFO - 2017-01-16 09:31:02 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:02 --> Model Class Initialized
INFO - 2017-01-16 09:31:02 --> Model Class Initialized
INFO - 2017-01-16 09:31:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:02 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:02 --> Total execution time: 0.2332
INFO - 2017-01-16 09:31:04 --> Config Class Initialized
INFO - 2017-01-16 09:31:04 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:04 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:04 --> URI Class Initialized
INFO - 2017-01-16 09:31:04 --> Router Class Initialized
INFO - 2017-01-16 09:31:04 --> Config Class Initialized
INFO - 2017-01-16 09:31:04 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:04 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:04 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:04 --> Security Class Initialized
INFO - 2017-01-16 09:31:04 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:04 --> Input Class Initialized
INFO - 2017-01-16 09:31:04 --> Language Class Initialized
INFO - 2017-01-16 09:31:04 --> Router Class Initialized
INFO - 2017-01-16 09:31:04 --> Output Class Initialized
INFO - 2017-01-16 09:31:04 --> Security Class Initialized
INFO - 2017-01-16 09:31:04 --> Loader Class Initialized
INFO - 2017-01-16 09:31:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:04 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:04 --> Input Class Initialized
INFO - 2017-01-16 09:31:04 --> Language Class Initialized
INFO - 2017-01-16 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:04 --> Controller Class Initialized
INFO - 2017-01-16 09:31:04 --> Loader Class Initialized
INFO - 2017-01-16 09:31:04 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:04 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:04 --> Model Class Initialized
INFO - 2017-01-16 09:31:04 --> Model Class Initialized
INFO - 2017-01-16 09:31:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:04 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:04 --> Total execution time: 0.0754
INFO - 2017-01-16 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:04 --> Controller Class Initialized
INFO - 2017-01-16 09:31:04 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:04 --> Model Class Initialized
INFO - 2017-01-16 09:31:04 --> Model Class Initialized
INFO - 2017-01-16 09:31:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:05 --> Total execution time: 0.2223
INFO - 2017-01-16 09:31:06 --> Config Class Initialized
INFO - 2017-01-16 09:31:06 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:06 --> Config Class Initialized
INFO - 2017-01-16 09:31:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:06 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:06 --> URI Class Initialized
INFO - 2017-01-16 09:31:06 --> URI Class Initialized
INFO - 2017-01-16 09:31:06 --> Router Class Initialized
INFO - 2017-01-16 09:31:06 --> Router Class Initialized
INFO - 2017-01-16 09:31:06 --> Config Class Initialized
INFO - 2017-01-16 09:31:06 --> Output Class Initialized
INFO - 2017-01-16 09:31:06 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:06 --> Security Class Initialized
INFO - 2017-01-16 09:31:06 --> Output Class Initialized
INFO - 2017-01-16 09:31:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:06 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:06 --> URI Class Initialized
INFO - 2017-01-16 09:31:06 --> Input Class Initialized
DEBUG - 2017-01-16 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:06 --> Input Class Initialized
INFO - 2017-01-16 09:31:06 --> Language Class Initialized
INFO - 2017-01-16 09:31:06 --> Language Class Initialized
INFO - 2017-01-16 09:31:06 --> Router Class Initialized
INFO - 2017-01-16 09:31:06 --> Output Class Initialized
INFO - 2017-01-16 09:31:06 --> Security Class Initialized
INFO - 2017-01-16 09:31:07 --> Loader Class Initialized
INFO - 2017-01-16 09:31:07 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:07 --> Input Class Initialized
INFO - 2017-01-16 09:31:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:07 --> Language Class Initialized
INFO - 2017-01-16 09:31:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:07 --> Loader Class Initialized
INFO - 2017-01-16 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:07 --> Controller Class Initialized
INFO - 2017-01-16 09:31:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:07 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:07 --> Total execution time: 0.2945
INFO - 2017-01-16 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:07 --> Controller Class Initialized
INFO - 2017-01-16 09:31:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:07 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:07 --> Total execution time: 0.3258
INFO - 2017-01-16 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:07 --> Controller Class Initialized
INFO - 2017-01-16 09:31:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:07 --> Config Class Initialized
INFO - 2017-01-16 09:31:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:07 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:07 --> URI Class Initialized
INFO - 2017-01-16 09:31:07 --> Router Class Initialized
INFO - 2017-01-16 09:31:07 --> Output Class Initialized
INFO - 2017-01-16 09:31:07 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:07 --> Input Class Initialized
INFO - 2017-01-16 09:31:07 --> Language Class Initialized
INFO - 2017-01-16 09:31:07 --> Loader Class Initialized
INFO - 2017-01-16 09:31:07 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:07 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:07 --> Controller Class Initialized
INFO - 2017-01-16 09:31:07 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Model Class Initialized
INFO - 2017-01-16 09:31:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2017-01-16 09:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:31:07 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:07 --> Total execution time: 0.0788
INFO - 2017-01-16 09:31:09 --> Config Class Initialized
INFO - 2017-01-16 09:31:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:09 --> URI Class Initialized
INFO - 2017-01-16 09:31:09 --> Router Class Initialized
INFO - 2017-01-16 09:31:09 --> Output Class Initialized
INFO - 2017-01-16 09:31:09 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:09 --> Input Class Initialized
INFO - 2017-01-16 09:31:09 --> Language Class Initialized
INFO - 2017-01-16 09:31:09 --> Loader Class Initialized
INFO - 2017-01-16 09:31:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:09 --> Controller Class Initialized
INFO - 2017-01-16 09:31:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:09 --> Config Class Initialized
INFO - 2017-01-16 09:31:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:09 --> URI Class Initialized
INFO - 2017-01-16 09:31:09 --> Router Class Initialized
INFO - 2017-01-16 09:31:09 --> Output Class Initialized
INFO - 2017-01-16 09:31:09 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:09 --> Input Class Initialized
INFO - 2017-01-16 09:31:09 --> Language Class Initialized
INFO - 2017-01-16 09:31:09 --> Loader Class Initialized
INFO - 2017-01-16 09:31:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:09 --> Controller Class Initialized
INFO - 2017-01-16 09:31:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:31:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07_attempt.php
INFO - 2017-01-16 09:31:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:31:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:09 --> Total execution time: 0.0725
INFO - 2017-01-16 09:31:09 --> Config Class Initialized
INFO - 2017-01-16 09:31:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:09 --> URI Class Initialized
INFO - 2017-01-16 09:31:09 --> Router Class Initialized
INFO - 2017-01-16 09:31:09 --> Config Class Initialized
INFO - 2017-01-16 09:31:09 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:09 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:09 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:09 --> Input Class Initialized
INFO - 2017-01-16 09:31:09 --> URI Class Initialized
INFO - 2017-01-16 09:31:09 --> Language Class Initialized
INFO - 2017-01-16 09:31:09 --> Router Class Initialized
INFO - 2017-01-16 09:31:09 --> Output Class Initialized
INFO - 2017-01-16 09:31:09 --> Loader Class Initialized
INFO - 2017-01-16 09:31:09 --> Security Class Initialized
INFO - 2017-01-16 09:31:09 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:09 --> Input Class Initialized
INFO - 2017-01-16 09:31:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:09 --> Language Class Initialized
INFO - 2017-01-16 09:31:09 --> Loader Class Initialized
INFO - 2017-01-16 09:31:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:09 --> Controller Class Initialized
INFO - 2017-01-16 09:31:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Model Class Initialized
INFO - 2017-01-16 09:31:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:09 --> Total execution time: 0.1743
INFO - 2017-01-16 09:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:09 --> Controller Class Initialized
INFO - 2017-01-16 09:31:10 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:10 --> Model Class Initialized
INFO - 2017-01-16 09:31:10 --> Model Class Initialized
INFO - 2017-01-16 09:31:10 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:31:10 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:31:10 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:10 --> Total execution time: 0.2094
INFO - 2017-01-16 09:31:11 --> Config Class Initialized
INFO - 2017-01-16 09:31:11 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:11 --> Config Class Initialized
INFO - 2017-01-16 09:31:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:11 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:11 --> URI Class Initialized
INFO - 2017-01-16 09:31:11 --> URI Class Initialized
INFO - 2017-01-16 09:31:11 --> Router Class Initialized
INFO - 2017-01-16 09:31:11 --> Router Class Initialized
INFO - 2017-01-16 09:31:11 --> Output Class Initialized
INFO - 2017-01-16 09:31:11 --> Output Class Initialized
INFO - 2017-01-16 09:31:11 --> Security Class Initialized
INFO - 2017-01-16 09:31:11 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:11 --> Input Class Initialized
INFO - 2017-01-16 09:31:11 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:11 --> Input Class Initialized
INFO - 2017-01-16 09:31:11 --> Language Class Initialized
INFO - 2017-01-16 09:31:11 --> Loader Class Initialized
INFO - 2017-01-16 09:31:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:11 --> Loader Class Initialized
INFO - 2017-01-16 09:31:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:11 --> Controller Class Initialized
INFO - 2017-01-16 09:31:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:11 --> Model Class Initialized
INFO - 2017-01-16 09:31:11 --> Model Class Initialized
INFO - 2017-01-16 09:31:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:11 --> Total execution time: 0.0772
INFO - 2017-01-16 09:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:11 --> Controller Class Initialized
INFO - 2017-01-16 09:31:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:11 --> Model Class Initialized
INFO - 2017-01-16 09:31:11 --> Model Class Initialized
INFO - 2017-01-16 09:31:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:11 --> Total execution time: 0.1171
INFO - 2017-01-16 09:31:13 --> Config Class Initialized
INFO - 2017-01-16 09:31:13 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:13 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:13 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:13 --> URI Class Initialized
INFO - 2017-01-16 09:31:13 --> Config Class Initialized
INFO - 2017-01-16 09:31:13 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:13 --> Router Class Initialized
INFO - 2017-01-16 09:31:13 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:13 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:13 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:13 --> Security Class Initialized
INFO - 2017-01-16 09:31:13 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:13 --> Router Class Initialized
INFO - 2017-01-16 09:31:13 --> Input Class Initialized
INFO - 2017-01-16 09:31:13 --> Language Class Initialized
INFO - 2017-01-16 09:31:13 --> Output Class Initialized
INFO - 2017-01-16 09:31:13 --> Security Class Initialized
INFO - 2017-01-16 09:31:13 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:13 --> Input Class Initialized
INFO - 2017-01-16 09:31:13 --> Language Class Initialized
INFO - 2017-01-16 09:31:13 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:13 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:13 --> Loader Class Initialized
INFO - 2017-01-16 09:31:13 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:13 --> Controller Class Initialized
INFO - 2017-01-16 09:31:13 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:13 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:13 --> Model Class Initialized
INFO - 2017-01-16 09:31:13 --> Model Class Initialized
INFO - 2017-01-16 09:31:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:13 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:13 --> Total execution time: 0.0770
INFO - 2017-01-16 09:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:13 --> Controller Class Initialized
INFO - 2017-01-16 09:31:13 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:13 --> Model Class Initialized
INFO - 2017-01-16 09:31:13 --> Model Class Initialized
INFO - 2017-01-16 09:31:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:13 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:13 --> Total execution time: 0.1221
INFO - 2017-01-16 09:31:14 --> Config Class Initialized
INFO - 2017-01-16 09:31:14 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:14 --> Config Class Initialized
INFO - 2017-01-16 09:31:14 --> URI Class Initialized
INFO - 2017-01-16 09:31:14 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:14 --> Router Class Initialized
INFO - 2017-01-16 09:31:14 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:14 --> Security Class Initialized
INFO - 2017-01-16 09:31:14 --> URI Class Initialized
INFO - 2017-01-16 09:31:14 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:14 --> Input Class Initialized
INFO - 2017-01-16 09:31:14 --> Language Class Initialized
INFO - 2017-01-16 09:31:14 --> Output Class Initialized
INFO - 2017-01-16 09:31:14 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:14 --> Loader Class Initialized
INFO - 2017-01-16 09:31:14 --> Input Class Initialized
INFO - 2017-01-16 09:31:14 --> Language Class Initialized
INFO - 2017-01-16 09:31:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:14 --> Loader Class Initialized
INFO - 2017-01-16 09:31:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:14 --> Controller Class Initialized
INFO - 2017-01-16 09:31:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:14 --> Model Class Initialized
INFO - 2017-01-16 09:31:14 --> Model Class Initialized
INFO - 2017-01-16 09:31:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:14 --> Total execution time: 0.1012
INFO - 2017-01-16 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:14 --> Controller Class Initialized
INFO - 2017-01-16 09:31:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:14 --> Model Class Initialized
INFO - 2017-01-16 09:31:14 --> Model Class Initialized
INFO - 2017-01-16 09:31:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:14 --> Total execution time: 0.1171
INFO - 2017-01-16 09:31:15 --> Config Class Initialized
INFO - 2017-01-16 09:31:15 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:15 --> Config Class Initialized
INFO - 2017-01-16 09:31:15 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:15 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:15 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:15 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:15 --> Router Class Initialized
INFO - 2017-01-16 09:31:15 --> URI Class Initialized
INFO - 2017-01-16 09:31:15 --> Output Class Initialized
INFO - 2017-01-16 09:31:15 --> Router Class Initialized
INFO - 2017-01-16 09:31:15 --> Security Class Initialized
INFO - 2017-01-16 09:31:15 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:15 --> Security Class Initialized
INFO - 2017-01-16 09:31:15 --> Input Class Initialized
INFO - 2017-01-16 09:31:15 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:15 --> Input Class Initialized
INFO - 2017-01-16 09:31:15 --> Language Class Initialized
INFO - 2017-01-16 09:31:15 --> Loader Class Initialized
INFO - 2017-01-16 09:31:15 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:15 --> Loader Class Initialized
INFO - 2017-01-16 09:31:15 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:15 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:15 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:15 --> Controller Class Initialized
INFO - 2017-01-16 09:31:15 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:15 --> Model Class Initialized
INFO - 2017-01-16 09:31:15 --> Model Class Initialized
INFO - 2017-01-16 09:31:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:15 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:15 --> Total execution time: 0.0863
INFO - 2017-01-16 09:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:15 --> Controller Class Initialized
INFO - 2017-01-16 09:31:15 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:15 --> Model Class Initialized
INFO - 2017-01-16 09:31:15 --> Model Class Initialized
INFO - 2017-01-16 09:31:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:15 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:15 --> Total execution time: 0.1348
INFO - 2017-01-16 09:31:17 --> Config Class Initialized
INFO - 2017-01-16 09:31:17 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:17 --> Config Class Initialized
INFO - 2017-01-16 09:31:17 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:17 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:17 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:17 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:17 --> Router Class Initialized
INFO - 2017-01-16 09:31:17 --> URI Class Initialized
INFO - 2017-01-16 09:31:17 --> Output Class Initialized
INFO - 2017-01-16 09:31:17 --> Router Class Initialized
INFO - 2017-01-16 09:31:17 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:17 --> Input Class Initialized
INFO - 2017-01-16 09:31:17 --> Output Class Initialized
INFO - 2017-01-16 09:31:17 --> Language Class Initialized
INFO - 2017-01-16 09:31:17 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:17 --> Input Class Initialized
INFO - 2017-01-16 09:31:17 --> Language Class Initialized
INFO - 2017-01-16 09:31:17 --> Loader Class Initialized
INFO - 2017-01-16 09:31:17 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:17 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:17 --> Loader Class Initialized
INFO - 2017-01-16 09:31:17 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:17 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:17 --> Controller Class Initialized
INFO - 2017-01-16 09:31:17 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:17 --> Model Class Initialized
INFO - 2017-01-16 09:31:17 --> Model Class Initialized
INFO - 2017-01-16 09:31:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:17 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:17 --> Total execution time: 0.0714
INFO - 2017-01-16 09:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:17 --> Controller Class Initialized
INFO - 2017-01-16 09:31:17 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:17 --> Model Class Initialized
INFO - 2017-01-16 09:31:17 --> Model Class Initialized
INFO - 2017-01-16 09:31:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:17 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:17 --> Total execution time: 0.1239
INFO - 2017-01-16 09:31:18 --> Config Class Initialized
INFO - 2017-01-16 09:31:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:18 --> Config Class Initialized
INFO - 2017-01-16 09:31:18 --> URI Class Initialized
INFO - 2017-01-16 09:31:18 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:18 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:18 --> Output Class Initialized
INFO - 2017-01-16 09:31:18 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:18 --> URI Class Initialized
INFO - 2017-01-16 09:31:18 --> Security Class Initialized
INFO - 2017-01-16 09:31:18 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:18 --> Input Class Initialized
INFO - 2017-01-16 09:31:18 --> Language Class Initialized
INFO - 2017-01-16 09:31:18 --> Output Class Initialized
INFO - 2017-01-16 09:31:18 --> Security Class Initialized
INFO - 2017-01-16 09:31:18 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:18 --> Input Class Initialized
INFO - 2017-01-16 09:31:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:18 --> Language Class Initialized
INFO - 2017-01-16 09:31:18 --> Loader Class Initialized
INFO - 2017-01-16 09:31:18 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:18 --> Controller Class Initialized
INFO - 2017-01-16 09:31:18 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:18 --> Model Class Initialized
INFO - 2017-01-16 09:31:18 --> Model Class Initialized
INFO - 2017-01-16 09:31:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:18 --> Total execution time: 0.0884
INFO - 2017-01-16 09:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:18 --> Controller Class Initialized
INFO - 2017-01-16 09:31:18 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:18 --> Model Class Initialized
INFO - 2017-01-16 09:31:18 --> Model Class Initialized
INFO - 2017-01-16 09:31:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:18 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:18 --> Total execution time: 0.1390
INFO - 2017-01-16 09:31:20 --> Config Class Initialized
INFO - 2017-01-16 09:31:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:20 --> Config Class Initialized
INFO - 2017-01-16 09:31:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:20 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:20 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:20 --> Router Class Initialized
INFO - 2017-01-16 09:31:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:20 --> URI Class Initialized
INFO - 2017-01-16 09:31:20 --> Output Class Initialized
INFO - 2017-01-16 09:31:20 --> Router Class Initialized
INFO - 2017-01-16 09:31:20 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:20 --> Input Class Initialized
INFO - 2017-01-16 09:31:20 --> Output Class Initialized
INFO - 2017-01-16 09:31:20 --> Language Class Initialized
INFO - 2017-01-16 09:31:20 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:20 --> Input Class Initialized
INFO - 2017-01-16 09:31:20 --> Loader Class Initialized
INFO - 2017-01-16 09:31:20 --> Language Class Initialized
INFO - 2017-01-16 09:31:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:20 --> Loader Class Initialized
INFO - 2017-01-16 09:31:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:20 --> Controller Class Initialized
INFO - 2017-01-16 09:31:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:20 --> Model Class Initialized
INFO - 2017-01-16 09:31:20 --> Model Class Initialized
INFO - 2017-01-16 09:31:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:20 --> Total execution time: 0.0768
INFO - 2017-01-16 09:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:20 --> Controller Class Initialized
INFO - 2017-01-16 09:31:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:20 --> Model Class Initialized
INFO - 2017-01-16 09:31:20 --> Model Class Initialized
INFO - 2017-01-16 09:31:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:20 --> Total execution time: 0.1422
INFO - 2017-01-16 09:31:21 --> Config Class Initialized
INFO - 2017-01-16 09:31:21 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:21 --> Config Class Initialized
INFO - 2017-01-16 09:31:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:21 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:21 --> URI Class Initialized
INFO - 2017-01-16 09:31:21 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:21 --> URI Class Initialized
INFO - 2017-01-16 09:31:21 --> Router Class Initialized
INFO - 2017-01-16 09:31:21 --> Router Class Initialized
INFO - 2017-01-16 09:31:21 --> Output Class Initialized
INFO - 2017-01-16 09:31:21 --> Output Class Initialized
INFO - 2017-01-16 09:31:21 --> Security Class Initialized
INFO - 2017-01-16 09:31:21 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:21 --> Input Class Initialized
INFO - 2017-01-16 09:31:21 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:21 --> Input Class Initialized
INFO - 2017-01-16 09:31:21 --> Language Class Initialized
INFO - 2017-01-16 09:31:21 --> Loader Class Initialized
INFO - 2017-01-16 09:31:21 --> Loader Class Initialized
INFO - 2017-01-16 09:31:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:21 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:21 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:21 --> Controller Class Initialized
INFO - 2017-01-16 09:31:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:21 --> Model Class Initialized
INFO - 2017-01-16 09:31:21 --> Model Class Initialized
INFO - 2017-01-16 09:31:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:21 --> Total execution time: 0.0789
INFO - 2017-01-16 09:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:21 --> Controller Class Initialized
INFO - 2017-01-16 09:31:21 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:21 --> Model Class Initialized
INFO - 2017-01-16 09:31:21 --> Model Class Initialized
INFO - 2017-01-16 09:31:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:21 --> Total execution time: 0.1449
INFO - 2017-01-16 09:31:22 --> Config Class Initialized
INFO - 2017-01-16 09:31:22 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:22 --> Config Class Initialized
INFO - 2017-01-16 09:31:22 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:22 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:22 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:22 --> URI Class Initialized
INFO - 2017-01-16 09:31:22 --> URI Class Initialized
INFO - 2017-01-16 09:31:22 --> Router Class Initialized
INFO - 2017-01-16 09:31:22 --> Router Class Initialized
INFO - 2017-01-16 09:31:22 --> Output Class Initialized
INFO - 2017-01-16 09:31:22 --> Output Class Initialized
INFO - 2017-01-16 09:31:22 --> Security Class Initialized
INFO - 2017-01-16 09:31:22 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:22 --> Input Class Initialized
INFO - 2017-01-16 09:31:22 --> Input Class Initialized
INFO - 2017-01-16 09:31:22 --> Language Class Initialized
INFO - 2017-01-16 09:31:22 --> Language Class Initialized
INFO - 2017-01-16 09:31:22 --> Loader Class Initialized
INFO - 2017-01-16 09:31:22 --> Loader Class Initialized
INFO - 2017-01-16 09:31:22 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:22 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:22 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:22 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:22 --> Controller Class Initialized
INFO - 2017-01-16 09:31:22 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:22 --> Model Class Initialized
INFO - 2017-01-16 09:31:22 --> Model Class Initialized
INFO - 2017-01-16 09:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:22 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:22 --> Total execution time: 0.0715
INFO - 2017-01-16 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:22 --> Controller Class Initialized
INFO - 2017-01-16 09:31:22 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:22 --> Model Class Initialized
INFO - 2017-01-16 09:31:22 --> Model Class Initialized
INFO - 2017-01-16 09:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:23 --> Total execution time: 0.1520
INFO - 2017-01-16 09:31:24 --> Config Class Initialized
INFO - 2017-01-16 09:31:24 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:24 --> Config Class Initialized
INFO - 2017-01-16 09:31:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:24 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:24 --> Router Class Initialized
INFO - 2017-01-16 09:31:24 --> URI Class Initialized
INFO - 2017-01-16 09:31:24 --> Output Class Initialized
INFO - 2017-01-16 09:31:24 --> Router Class Initialized
INFO - 2017-01-16 09:31:24 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:24 --> Input Class Initialized
INFO - 2017-01-16 09:31:24 --> Output Class Initialized
INFO - 2017-01-16 09:31:24 --> Language Class Initialized
INFO - 2017-01-16 09:31:24 --> Security Class Initialized
INFO - 2017-01-16 09:31:24 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:24 --> Input Class Initialized
INFO - 2017-01-16 09:31:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:24 --> Language Class Initialized
INFO - 2017-01-16 09:31:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:24 --> Loader Class Initialized
INFO - 2017-01-16 09:31:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:24 --> Controller Class Initialized
INFO - 2017-01-16 09:31:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:24 --> Model Class Initialized
INFO - 2017-01-16 09:31:24 --> Model Class Initialized
INFO - 2017-01-16 09:31:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:24 --> Total execution time: 0.0751
INFO - 2017-01-16 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:24 --> Controller Class Initialized
INFO - 2017-01-16 09:31:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:24 --> Model Class Initialized
INFO - 2017-01-16 09:31:24 --> Model Class Initialized
INFO - 2017-01-16 09:31:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:24 --> Total execution time: 0.1590
INFO - 2017-01-16 09:31:25 --> Config Class Initialized
INFO - 2017-01-16 09:31:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:25 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:25 --> Config Class Initialized
INFO - 2017-01-16 09:31:25 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:25 --> URI Class Initialized
INFO - 2017-01-16 09:31:25 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:25 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:25 --> Output Class Initialized
INFO - 2017-01-16 09:31:25 --> URI Class Initialized
INFO - 2017-01-16 09:31:25 --> Security Class Initialized
INFO - 2017-01-16 09:31:25 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:25 --> Input Class Initialized
INFO - 2017-01-16 09:31:25 --> Language Class Initialized
INFO - 2017-01-16 09:31:25 --> Output Class Initialized
INFO - 2017-01-16 09:31:25 --> Security Class Initialized
INFO - 2017-01-16 09:31:25 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:25 --> Input Class Initialized
INFO - 2017-01-16 09:31:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:25 --> Language Class Initialized
INFO - 2017-01-16 09:31:25 --> Loader Class Initialized
INFO - 2017-01-16 09:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:25 --> Controller Class Initialized
INFO - 2017-01-16 09:31:25 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:25 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:25 --> Model Class Initialized
INFO - 2017-01-16 09:31:25 --> Model Class Initialized
INFO - 2017-01-16 09:31:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:25 --> Total execution time: 0.0729
INFO - 2017-01-16 09:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:25 --> Controller Class Initialized
INFO - 2017-01-16 09:31:25 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:25 --> Model Class Initialized
INFO - 2017-01-16 09:31:25 --> Model Class Initialized
INFO - 2017-01-16 09:31:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:25 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:25 --> Total execution time: 0.1757
INFO - 2017-01-16 09:31:27 --> Config Class Initialized
INFO - 2017-01-16 09:31:27 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:27 --> Config Class Initialized
INFO - 2017-01-16 09:31:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:27 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:27 --> Router Class Initialized
INFO - 2017-01-16 09:31:27 --> URI Class Initialized
INFO - 2017-01-16 09:31:27 --> Output Class Initialized
INFO - 2017-01-16 09:31:27 --> Router Class Initialized
INFO - 2017-01-16 09:31:27 --> Security Class Initialized
INFO - 2017-01-16 09:31:27 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:27 --> Input Class Initialized
INFO - 2017-01-16 09:31:27 --> Security Class Initialized
INFO - 2017-01-16 09:31:27 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:27 --> Input Class Initialized
INFO - 2017-01-16 09:31:27 --> Loader Class Initialized
INFO - 2017-01-16 09:31:27 --> Language Class Initialized
INFO - 2017-01-16 09:31:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:27 --> Loader Class Initialized
INFO - 2017-01-16 09:31:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:27 --> Controller Class Initialized
INFO - 2017-01-16 09:31:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:27 --> Model Class Initialized
INFO - 2017-01-16 09:31:27 --> Model Class Initialized
INFO - 2017-01-16 09:31:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:27 --> Total execution time: 0.0661
INFO - 2017-01-16 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:27 --> Controller Class Initialized
INFO - 2017-01-16 09:31:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:27 --> Model Class Initialized
INFO - 2017-01-16 09:31:27 --> Model Class Initialized
INFO - 2017-01-16 09:31:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:27 --> Total execution time: 0.1595
INFO - 2017-01-16 09:31:28 --> Config Class Initialized
INFO - 2017-01-16 09:31:28 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:28 --> Config Class Initialized
INFO - 2017-01-16 09:31:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:31:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:28 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:28 --> URI Class Initialized
INFO - 2017-01-16 09:31:28 --> URI Class Initialized
INFO - 2017-01-16 09:31:28 --> Router Class Initialized
INFO - 2017-01-16 09:31:28 --> Router Class Initialized
INFO - 2017-01-16 09:31:28 --> Output Class Initialized
INFO - 2017-01-16 09:31:28 --> Output Class Initialized
INFO - 2017-01-16 09:31:28 --> Security Class Initialized
INFO - 2017-01-16 09:31:28 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:28 --> Input Class Initialized
INFO - 2017-01-16 09:31:28 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:28 --> Input Class Initialized
INFO - 2017-01-16 09:31:28 --> Language Class Initialized
INFO - 2017-01-16 09:31:28 --> Loader Class Initialized
INFO - 2017-01-16 09:31:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:28 --> Loader Class Initialized
INFO - 2017-01-16 09:31:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:28 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:28 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:28 --> Controller Class Initialized
INFO - 2017-01-16 09:31:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:28 --> Model Class Initialized
INFO - 2017-01-16 09:31:28 --> Model Class Initialized
INFO - 2017-01-16 09:31:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:28 --> Total execution time: 0.0826
INFO - 2017-01-16 09:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:28 --> Controller Class Initialized
INFO - 2017-01-16 09:31:28 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:28 --> Model Class Initialized
INFO - 2017-01-16 09:31:28 --> Model Class Initialized
INFO - 2017-01-16 09:31:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:28 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:28 --> Total execution time: 0.1912
INFO - 2017-01-16 09:31:29 --> Config Class Initialized
INFO - 2017-01-16 09:31:29 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:29 --> Config Class Initialized
INFO - 2017-01-16 09:31:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:29 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:29 --> URI Class Initialized
INFO - 2017-01-16 09:31:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:29 --> URI Class Initialized
INFO - 2017-01-16 09:31:29 --> Router Class Initialized
INFO - 2017-01-16 09:31:29 --> Router Class Initialized
INFO - 2017-01-16 09:31:29 --> Output Class Initialized
INFO - 2017-01-16 09:31:29 --> Output Class Initialized
INFO - 2017-01-16 09:31:29 --> Security Class Initialized
INFO - 2017-01-16 09:31:29 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:29 --> Input Class Initialized
INFO - 2017-01-16 09:31:29 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:29 --> Input Class Initialized
INFO - 2017-01-16 09:31:29 --> Loader Class Initialized
INFO - 2017-01-16 09:31:29 --> Language Class Initialized
INFO - 2017-01-16 09:31:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:29 --> Loader Class Initialized
INFO - 2017-01-16 09:31:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:29 --> Controller Class Initialized
INFO - 2017-01-16 09:31:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:29 --> Model Class Initialized
INFO - 2017-01-16 09:31:29 --> Model Class Initialized
INFO - 2017-01-16 09:31:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:29 --> Total execution time: 0.0789
INFO - 2017-01-16 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:29 --> Controller Class Initialized
INFO - 2017-01-16 09:31:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:29 --> Model Class Initialized
INFO - 2017-01-16 09:31:29 --> Model Class Initialized
INFO - 2017-01-16 09:31:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:29 --> Total execution time: 0.1886
INFO - 2017-01-16 09:31:31 --> Config Class Initialized
INFO - 2017-01-16 09:31:31 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:31 --> Config Class Initialized
INFO - 2017-01-16 09:31:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:31 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:31 --> URI Class Initialized
INFO - 2017-01-16 09:31:31 --> URI Class Initialized
INFO - 2017-01-16 09:31:31 --> Router Class Initialized
INFO - 2017-01-16 09:31:31 --> Router Class Initialized
INFO - 2017-01-16 09:31:31 --> Output Class Initialized
INFO - 2017-01-16 09:31:31 --> Output Class Initialized
INFO - 2017-01-16 09:31:31 --> Security Class Initialized
INFO - 2017-01-16 09:31:31 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:31 --> Input Class Initialized
DEBUG - 2017-01-16 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:31 --> Language Class Initialized
INFO - 2017-01-16 09:31:31 --> Input Class Initialized
INFO - 2017-01-16 09:31:31 --> Language Class Initialized
INFO - 2017-01-16 09:31:31 --> Loader Class Initialized
INFO - 2017-01-16 09:31:31 --> Loader Class Initialized
INFO - 2017-01-16 09:31:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:31 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:31 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:31 --> Controller Class Initialized
INFO - 2017-01-16 09:31:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:31 --> Model Class Initialized
INFO - 2017-01-16 09:31:31 --> Model Class Initialized
INFO - 2017-01-16 09:31:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:31 --> Total execution time: 0.0715
INFO - 2017-01-16 09:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:31 --> Controller Class Initialized
INFO - 2017-01-16 09:31:31 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:31 --> Model Class Initialized
INFO - 2017-01-16 09:31:31 --> Model Class Initialized
INFO - 2017-01-16 09:31:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:31 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:31 --> Total execution time: 0.1986
INFO - 2017-01-16 09:31:32 --> Config Class Initialized
INFO - 2017-01-16 09:31:32 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:32 --> Config Class Initialized
INFO - 2017-01-16 09:31:32 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:32 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:32 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:32 --> URI Class Initialized
INFO - 2017-01-16 09:31:32 --> URI Class Initialized
INFO - 2017-01-16 09:31:32 --> Router Class Initialized
INFO - 2017-01-16 09:31:32 --> Router Class Initialized
INFO - 2017-01-16 09:31:32 --> Output Class Initialized
INFO - 2017-01-16 09:31:32 --> Output Class Initialized
INFO - 2017-01-16 09:31:32 --> Security Class Initialized
INFO - 2017-01-16 09:31:32 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:32 --> Input Class Initialized
DEBUG - 2017-01-16 09:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:32 --> Input Class Initialized
INFO - 2017-01-16 09:31:32 --> Language Class Initialized
INFO - 2017-01-16 09:31:32 --> Language Class Initialized
INFO - 2017-01-16 09:31:32 --> Loader Class Initialized
INFO - 2017-01-16 09:31:32 --> Loader Class Initialized
INFO - 2017-01-16 09:31:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:32 --> Controller Class Initialized
INFO - 2017-01-16 09:31:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:32 --> Model Class Initialized
INFO - 2017-01-16 09:31:32 --> Model Class Initialized
INFO - 2017-01-16 09:31:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:32 --> Total execution time: 0.0667
INFO - 2017-01-16 09:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:32 --> Controller Class Initialized
INFO - 2017-01-16 09:31:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:32 --> Model Class Initialized
INFO - 2017-01-16 09:31:32 --> Model Class Initialized
INFO - 2017-01-16 09:31:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:32 --> Total execution time: 0.1779
INFO - 2017-01-16 09:31:33 --> Config Class Initialized
INFO - 2017-01-16 09:31:33 --> Config Class Initialized
INFO - 2017-01-16 09:31:33 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:33 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:33 --> URI Class Initialized
INFO - 2017-01-16 09:31:33 --> URI Class Initialized
INFO - 2017-01-16 09:31:33 --> Router Class Initialized
INFO - 2017-01-16 09:31:33 --> Router Class Initialized
INFO - 2017-01-16 09:31:33 --> Output Class Initialized
INFO - 2017-01-16 09:31:33 --> Security Class Initialized
INFO - 2017-01-16 09:31:33 --> Output Class Initialized
INFO - 2017-01-16 09:31:33 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:33 --> Input Class Initialized
INFO - 2017-01-16 09:31:33 --> Input Class Initialized
INFO - 2017-01-16 09:31:33 --> Language Class Initialized
INFO - 2017-01-16 09:31:33 --> Language Class Initialized
INFO - 2017-01-16 09:31:33 --> Loader Class Initialized
INFO - 2017-01-16 09:31:33 --> Loader Class Initialized
INFO - 2017-01-16 09:31:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:33 --> Controller Class Initialized
INFO - 2017-01-16 09:31:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:33 --> Model Class Initialized
INFO - 2017-01-16 09:31:33 --> Model Class Initialized
INFO - 2017-01-16 09:31:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:34 --> Total execution time: 0.0811
INFO - 2017-01-16 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:34 --> Controller Class Initialized
INFO - 2017-01-16 09:31:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:34 --> Model Class Initialized
INFO - 2017-01-16 09:31:34 --> Model Class Initialized
INFO - 2017-01-16 09:31:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:34 --> Total execution time: 0.2109
INFO - 2017-01-16 09:31:35 --> Config Class Initialized
INFO - 2017-01-16 09:31:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:35 --> Config Class Initialized
INFO - 2017-01-16 09:31:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:35 --> Config Class Initialized
INFO - 2017-01-16 09:31:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:35 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:35 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:35 --> URI Class Initialized
INFO - 2017-01-16 09:31:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:35 --> Router Class Initialized
INFO - 2017-01-16 09:31:35 --> URI Class Initialized
INFO - 2017-01-16 09:31:35 --> Router Class Initialized
INFO - 2017-01-16 09:31:35 --> Output Class Initialized
INFO - 2017-01-16 09:31:35 --> Router Class Initialized
INFO - 2017-01-16 09:31:35 --> Output Class Initialized
INFO - 2017-01-16 09:31:35 --> Security Class Initialized
INFO - 2017-01-16 09:31:35 --> Output Class Initialized
INFO - 2017-01-16 09:31:35 --> Security Class Initialized
INFO - 2017-01-16 09:31:35 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:35 --> Input Class Initialized
INFO - 2017-01-16 09:31:35 --> Input Class Initialized
INFO - 2017-01-16 09:31:35 --> Input Class Initialized
INFO - 2017-01-16 09:31:35 --> Language Class Initialized
INFO - 2017-01-16 09:31:35 --> Language Class Initialized
INFO - 2017-01-16 09:31:35 --> Language Class Initialized
INFO - 2017-01-16 09:31:35 --> Loader Class Initialized
INFO - 2017-01-16 09:31:35 --> Loader Class Initialized
INFO - 2017-01-16 09:31:35 --> Loader Class Initialized
INFO - 2017-01-16 09:31:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:35 --> Controller Class Initialized
INFO - 2017-01-16 09:31:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:35 --> Model Class Initialized
INFO - 2017-01-16 09:31:35 --> Model Class Initialized
INFO - 2017-01-16 09:31:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:35 --> Total execution time: 0.0844
INFO - 2017-01-16 09:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:35 --> Controller Class Initialized
INFO - 2017-01-16 09:31:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:35 --> Model Class Initialized
INFO - 2017-01-16 09:31:35 --> Model Class Initialized
INFO - 2017-01-16 09:31:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:35 --> Total execution time: 0.2219
INFO - 2017-01-16 09:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:35 --> Controller Class Initialized
INFO - 2017-01-16 09:31:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:35 --> Model Class Initialized
INFO - 2017-01-16 09:31:35 --> Model Class Initialized
INFO - 2017-01-16 09:31:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:35 --> Total execution time: 0.3398
INFO - 2017-01-16 09:31:36 --> Config Class Initialized
INFO - 2017-01-16 09:31:36 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:36 --> Config Class Initialized
INFO - 2017-01-16 09:31:36 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:36 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:36 --> Router Class Initialized
INFO - 2017-01-16 09:31:36 --> URI Class Initialized
INFO - 2017-01-16 09:31:36 --> Output Class Initialized
INFO - 2017-01-16 09:31:36 --> Router Class Initialized
INFO - 2017-01-16 09:31:36 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:36 --> Output Class Initialized
INFO - 2017-01-16 09:31:36 --> Input Class Initialized
INFO - 2017-01-16 09:31:36 --> Language Class Initialized
INFO - 2017-01-16 09:31:36 --> Security Class Initialized
INFO - 2017-01-16 09:31:36 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:36 --> Input Class Initialized
INFO - 2017-01-16 09:31:36 --> Language Class Initialized
INFO - 2017-01-16 09:31:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:36 --> Loader Class Initialized
INFO - 2017-01-16 09:31:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:36 --> Controller Class Initialized
INFO - 2017-01-16 09:31:36 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:36 --> Model Class Initialized
INFO - 2017-01-16 09:31:36 --> Model Class Initialized
INFO - 2017-01-16 09:31:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:36 --> Total execution time: 0.2056
INFO - 2017-01-16 09:31:37 --> Config Class Initialized
INFO - 2017-01-16 09:31:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:38 --> URI Class Initialized
INFO - 2017-01-16 09:31:38 --> Router Class Initialized
INFO - 2017-01-16 09:31:38 --> Output Class Initialized
INFO - 2017-01-16 09:31:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:38 --> Input Class Initialized
INFO - 2017-01-16 09:31:38 --> Language Class Initialized
INFO - 2017-01-16 09:31:38 --> Loader Class Initialized
INFO - 2017-01-16 09:31:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:38 --> Controller Class Initialized
INFO - 2017-01-16 09:31:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:38 --> Total execution time: 0.0585
INFO - 2017-01-16 09:31:38 --> Config Class Initialized
INFO - 2017-01-16 09:31:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:38 --> URI Class Initialized
INFO - 2017-01-16 09:31:38 --> Router Class Initialized
INFO - 2017-01-16 09:31:38 --> Config Class Initialized
INFO - 2017-01-16 09:31:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:38 --> Config Class Initialized
INFO - 2017-01-16 09:31:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:38 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:38 --> URI Class Initialized
INFO - 2017-01-16 09:31:38 --> URI Class Initialized
INFO - 2017-01-16 09:31:38 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:38 --> Input Class Initialized
INFO - 2017-01-16 09:31:38 --> Router Class Initialized
INFO - 2017-01-16 09:31:38 --> Language Class Initialized
INFO - 2017-01-16 09:31:38 --> Output Class Initialized
INFO - 2017-01-16 09:31:38 --> Output Class Initialized
INFO - 2017-01-16 09:31:38 --> Security Class Initialized
INFO - 2017-01-16 09:31:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:38 --> Input Class Initialized
INFO - 2017-01-16 09:31:38 --> Input Class Initialized
INFO - 2017-01-16 09:31:38 --> Loader Class Initialized
INFO - 2017-01-16 09:31:38 --> Language Class Initialized
INFO - 2017-01-16 09:31:38 --> Language Class Initialized
INFO - 2017-01-16 09:31:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:38 --> Loader Class Initialized
INFO - 2017-01-16 09:31:38 --> Loader Class Initialized
INFO - 2017-01-16 09:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:38 --> Controller Class Initialized
INFO - 2017-01-16 09:31:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:38 --> Total execution time: 0.2296
INFO - 2017-01-16 09:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:38 --> Controller Class Initialized
INFO - 2017-01-16 09:31:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:38 --> Controller Class Initialized
INFO - 2017-01-16 09:31:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Config Class Initialized
INFO - 2017-01-16 09:31:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
DEBUG - 2017-01-16 09:31:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:38 --> Final output sent to browser
INFO - 2017-01-16 09:31:38 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:38 --> Total execution time: 0.3034
INFO - 2017-01-16 09:31:38 --> Router Class Initialized
INFO - 2017-01-16 09:31:38 --> Output Class Initialized
INFO - 2017-01-16 09:31:38 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:38 --> Input Class Initialized
INFO - 2017-01-16 09:31:38 --> Language Class Initialized
INFO - 2017-01-16 09:31:38 --> Loader Class Initialized
INFO - 2017-01-16 09:31:38 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:38 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:38 --> Controller Class Initialized
INFO - 2017-01-16 09:31:38 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Model Class Initialized
INFO - 2017-01-16 09:31:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:31:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2017-01-16 09:31:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:31:38 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:38 --> Total execution time: 0.0712
INFO - 2017-01-16 09:31:42 --> Config Class Initialized
INFO - 2017-01-16 09:31:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:42 --> URI Class Initialized
INFO - 2017-01-16 09:31:42 --> Router Class Initialized
INFO - 2017-01-16 09:31:42 --> Output Class Initialized
INFO - 2017-01-16 09:31:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:42 --> Input Class Initialized
INFO - 2017-01-16 09:31:42 --> Language Class Initialized
INFO - 2017-01-16 09:31:42 --> Loader Class Initialized
INFO - 2017-01-16 09:31:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:42 --> Controller Class Initialized
INFO - 2017-01-16 09:31:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:42 --> Config Class Initialized
INFO - 2017-01-16 09:31:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:42 --> URI Class Initialized
INFO - 2017-01-16 09:31:42 --> Router Class Initialized
INFO - 2017-01-16 09:31:42 --> Output Class Initialized
INFO - 2017-01-16 09:31:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:42 --> Input Class Initialized
INFO - 2017-01-16 09:31:42 --> Language Class Initialized
INFO - 2017-01-16 09:31:42 --> Loader Class Initialized
INFO - 2017-01-16 09:31:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:42 --> Controller Class Initialized
INFO - 2017-01-16 09:31:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:31:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08_attempt.php
INFO - 2017-01-16 09:31:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:31:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:42 --> Total execution time: 0.0745
INFO - 2017-01-16 09:31:42 --> Config Class Initialized
INFO - 2017-01-16 09:31:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:42 --> URI Class Initialized
INFO - 2017-01-16 09:31:42 --> Config Class Initialized
INFO - 2017-01-16 09:31:42 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:42 --> Router Class Initialized
INFO - 2017-01-16 09:31:42 --> Output Class Initialized
INFO - 2017-01-16 09:31:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:42 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:42 --> Input Class Initialized
INFO - 2017-01-16 09:31:42 --> Router Class Initialized
INFO - 2017-01-16 09:31:42 --> Language Class Initialized
INFO - 2017-01-16 09:31:42 --> Output Class Initialized
INFO - 2017-01-16 09:31:42 --> Security Class Initialized
INFO - 2017-01-16 09:31:42 --> Loader Class Initialized
INFO - 2017-01-16 09:31:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:42 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:42 --> Input Class Initialized
INFO - 2017-01-16 09:31:42 --> Language Class Initialized
INFO - 2017-01-16 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:42 --> Controller Class Initialized
INFO - 2017-01-16 09:31:42 --> Loader Class Initialized
INFO - 2017-01-16 09:31:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:42 --> Total execution time: 0.1487
INFO - 2017-01-16 09:31:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:42 --> Controller Class Initialized
INFO - 2017-01-16 09:31:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Model Class Initialized
INFO - 2017-01-16 09:31:42 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:31:42 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:31:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:42 --> Total execution time: 0.2404
INFO - 2017-01-16 09:31:44 --> Config Class Initialized
INFO - 2017-01-16 09:31:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:44 --> Config Class Initialized
INFO - 2017-01-16 09:31:44 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:44 --> URI Class Initialized
INFO - 2017-01-16 09:31:44 --> Router Class Initialized
INFO - 2017-01-16 09:31:44 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:44 --> Security Class Initialized
INFO - 2017-01-16 09:31:44 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:44 --> Router Class Initialized
INFO - 2017-01-16 09:31:44 --> Input Class Initialized
INFO - 2017-01-16 09:31:44 --> Language Class Initialized
INFO - 2017-01-16 09:31:44 --> Output Class Initialized
INFO - 2017-01-16 09:31:44 --> Security Class Initialized
INFO - 2017-01-16 09:31:44 --> Loader Class Initialized
INFO - 2017-01-16 09:31:44 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:44 --> Input Class Initialized
INFO - 2017-01-16 09:31:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:44 --> Language Class Initialized
INFO - 2017-01-16 09:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:44 --> Loader Class Initialized
INFO - 2017-01-16 09:31:44 --> Controller Class Initialized
INFO - 2017-01-16 09:31:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:44 --> Model Class Initialized
INFO - 2017-01-16 09:31:44 --> Model Class Initialized
INFO - 2017-01-16 09:31:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:44 --> Total execution time: 0.0755
INFO - 2017-01-16 09:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:44 --> Controller Class Initialized
INFO - 2017-01-16 09:31:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:44 --> Model Class Initialized
INFO - 2017-01-16 09:31:44 --> Model Class Initialized
INFO - 2017-01-16 09:31:44 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:31:44 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:31:44 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:44 --> Total execution time: 0.0999
INFO - 2017-01-16 09:31:46 --> Config Class Initialized
INFO - 2017-01-16 09:31:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:46 --> Config Class Initialized
INFO - 2017-01-16 09:31:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:46 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:46 --> Router Class Initialized
INFO - 2017-01-16 09:31:46 --> URI Class Initialized
INFO - 2017-01-16 09:31:46 --> Output Class Initialized
INFO - 2017-01-16 09:31:46 --> Router Class Initialized
INFO - 2017-01-16 09:31:46 --> Security Class Initialized
INFO - 2017-01-16 09:31:46 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:46 --> Input Class Initialized
INFO - 2017-01-16 09:31:46 --> Security Class Initialized
INFO - 2017-01-16 09:31:46 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:46 --> Input Class Initialized
INFO - 2017-01-16 09:31:46 --> Loader Class Initialized
INFO - 2017-01-16 09:31:46 --> Language Class Initialized
INFO - 2017-01-16 09:31:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:46 --> Loader Class Initialized
INFO - 2017-01-16 09:31:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:46 --> Controller Class Initialized
INFO - 2017-01-16 09:31:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:46 --> Model Class Initialized
INFO - 2017-01-16 09:31:46 --> Model Class Initialized
INFO - 2017-01-16 09:31:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:46 --> Total execution time: 0.0745
INFO - 2017-01-16 09:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:46 --> Controller Class Initialized
INFO - 2017-01-16 09:31:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:46 --> Model Class Initialized
INFO - 2017-01-16 09:31:46 --> Model Class Initialized
INFO - 2017-01-16 09:31:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:46 --> Total execution time: 0.1047
INFO - 2017-01-16 09:31:47 --> Config Class Initialized
INFO - 2017-01-16 09:31:47 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:47 --> Config Class Initialized
INFO - 2017-01-16 09:31:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:47 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:47 --> Router Class Initialized
INFO - 2017-01-16 09:31:47 --> URI Class Initialized
INFO - 2017-01-16 09:31:47 --> Output Class Initialized
INFO - 2017-01-16 09:31:47 --> Router Class Initialized
INFO - 2017-01-16 09:31:47 --> Security Class Initialized
INFO - 2017-01-16 09:31:47 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:47 --> Input Class Initialized
INFO - 2017-01-16 09:31:47 --> Security Class Initialized
INFO - 2017-01-16 09:31:47 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:47 --> Input Class Initialized
INFO - 2017-01-16 09:31:47 --> Language Class Initialized
INFO - 2017-01-16 09:31:47 --> Loader Class Initialized
INFO - 2017-01-16 09:31:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:47 --> Loader Class Initialized
INFO - 2017-01-16 09:31:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:47 --> Controller Class Initialized
INFO - 2017-01-16 09:31:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:47 --> Model Class Initialized
INFO - 2017-01-16 09:31:47 --> Model Class Initialized
INFO - 2017-01-16 09:31:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:47 --> Total execution time: 0.1054
INFO - 2017-01-16 09:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:47 --> Controller Class Initialized
INFO - 2017-01-16 09:31:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:47 --> Model Class Initialized
INFO - 2017-01-16 09:31:47 --> Model Class Initialized
INFO - 2017-01-16 09:31:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:47 --> Total execution time: 0.1344
INFO - 2017-01-16 09:31:49 --> Config Class Initialized
INFO - 2017-01-16 09:31:49 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:49 --> Config Class Initialized
INFO - 2017-01-16 09:31:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:31:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:49 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:49 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:49 --> URI Class Initialized
INFO - 2017-01-16 09:31:49 --> URI Class Initialized
INFO - 2017-01-16 09:31:49 --> Router Class Initialized
INFO - 2017-01-16 09:31:49 --> Router Class Initialized
INFO - 2017-01-16 09:31:49 --> Output Class Initialized
INFO - 2017-01-16 09:31:49 --> Output Class Initialized
INFO - 2017-01-16 09:31:49 --> Security Class Initialized
INFO - 2017-01-16 09:31:49 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:49 --> Input Class Initialized
INFO - 2017-01-16 09:31:49 --> Input Class Initialized
INFO - 2017-01-16 09:31:49 --> Language Class Initialized
INFO - 2017-01-16 09:31:49 --> Language Class Initialized
INFO - 2017-01-16 09:31:49 --> Loader Class Initialized
INFO - 2017-01-16 09:31:49 --> Loader Class Initialized
INFO - 2017-01-16 09:31:49 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:49 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:49 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:49 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:49 --> Controller Class Initialized
INFO - 2017-01-16 09:31:49 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:49 --> Model Class Initialized
INFO - 2017-01-16 09:31:49 --> Model Class Initialized
INFO - 2017-01-16 09:31:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:49 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:49 --> Total execution time: 0.0780
INFO - 2017-01-16 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:49 --> Controller Class Initialized
INFO - 2017-01-16 09:31:49 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:49 --> Model Class Initialized
INFO - 2017-01-16 09:31:49 --> Model Class Initialized
INFO - 2017-01-16 09:31:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:49 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:49 --> Total execution time: 0.1247
INFO - 2017-01-16 09:31:50 --> Config Class Initialized
INFO - 2017-01-16 09:31:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:50 --> Config Class Initialized
INFO - 2017-01-16 09:31:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:50 --> URI Class Initialized
INFO - 2017-01-16 09:31:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:50 --> Output Class Initialized
INFO - 2017-01-16 09:31:50 --> URI Class Initialized
INFO - 2017-01-16 09:31:50 --> Security Class Initialized
INFO - 2017-01-16 09:31:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:50 --> Input Class Initialized
INFO - 2017-01-16 09:31:50 --> Output Class Initialized
INFO - 2017-01-16 09:31:50 --> Language Class Initialized
INFO - 2017-01-16 09:31:50 --> Security Class Initialized
INFO - 2017-01-16 09:31:50 --> Loader Class Initialized
DEBUG - 2017-01-16 09:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:50 --> Input Class Initialized
INFO - 2017-01-16 09:31:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:50 --> Language Class Initialized
INFO - 2017-01-16 09:31:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:50 --> Loader Class Initialized
INFO - 2017-01-16 09:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:50 --> Controller Class Initialized
INFO - 2017-01-16 09:31:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:50 --> Model Class Initialized
INFO - 2017-01-16 09:31:50 --> Model Class Initialized
INFO - 2017-01-16 09:31:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:50 --> Total execution time: 0.0743
INFO - 2017-01-16 09:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:50 --> Controller Class Initialized
INFO - 2017-01-16 09:31:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:50 --> Model Class Initialized
INFO - 2017-01-16 09:31:50 --> Model Class Initialized
INFO - 2017-01-16 09:31:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:50 --> Total execution time: 0.1224
INFO - 2017-01-16 09:31:51 --> Config Class Initialized
INFO - 2017-01-16 09:31:51 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:51 --> Config Class Initialized
INFO - 2017-01-16 09:31:51 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:51 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:51 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:51 --> Router Class Initialized
INFO - 2017-01-16 09:31:51 --> URI Class Initialized
INFO - 2017-01-16 09:31:51 --> Output Class Initialized
INFO - 2017-01-16 09:31:51 --> Router Class Initialized
INFO - 2017-01-16 09:31:51 --> Security Class Initialized
INFO - 2017-01-16 09:31:51 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:51 --> Input Class Initialized
INFO - 2017-01-16 09:31:51 --> Security Class Initialized
INFO - 2017-01-16 09:31:51 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:51 --> Input Class Initialized
INFO - 2017-01-16 09:31:51 --> Language Class Initialized
INFO - 2017-01-16 09:31:51 --> Loader Class Initialized
INFO - 2017-01-16 09:31:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:51 --> Loader Class Initialized
INFO - 2017-01-16 09:31:51 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:51 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:51 --> Controller Class Initialized
INFO - 2017-01-16 09:31:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:51 --> Model Class Initialized
INFO - 2017-01-16 09:31:51 --> Model Class Initialized
INFO - 2017-01-16 09:31:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:51 --> Total execution time: 0.0660
INFO - 2017-01-16 09:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:51 --> Controller Class Initialized
INFO - 2017-01-16 09:31:51 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:51 --> Model Class Initialized
INFO - 2017-01-16 09:31:51 --> Model Class Initialized
INFO - 2017-01-16 09:31:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:51 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:51 --> Total execution time: 0.1110
INFO - 2017-01-16 09:31:53 --> Config Class Initialized
INFO - 2017-01-16 09:31:53 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:53 --> Config Class Initialized
INFO - 2017-01-16 09:31:53 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:53 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:53 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:53 --> URI Class Initialized
INFO - 2017-01-16 09:31:53 --> URI Class Initialized
INFO - 2017-01-16 09:31:53 --> Router Class Initialized
INFO - 2017-01-16 09:31:53 --> Router Class Initialized
INFO - 2017-01-16 09:31:53 --> Output Class Initialized
INFO - 2017-01-16 09:31:53 --> Output Class Initialized
INFO - 2017-01-16 09:31:53 --> Security Class Initialized
INFO - 2017-01-16 09:31:53 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:53 --> Input Class Initialized
INFO - 2017-01-16 09:31:53 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:53 --> Input Class Initialized
INFO - 2017-01-16 09:31:53 --> Language Class Initialized
INFO - 2017-01-16 09:31:53 --> Loader Class Initialized
INFO - 2017-01-16 09:31:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:53 --> Loader Class Initialized
INFO - 2017-01-16 09:31:53 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:53 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:53 --> Controller Class Initialized
INFO - 2017-01-16 09:31:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:53 --> Model Class Initialized
INFO - 2017-01-16 09:31:53 --> Model Class Initialized
INFO - 2017-01-16 09:31:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:53 --> Total execution time: 0.0848
INFO - 2017-01-16 09:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:53 --> Controller Class Initialized
INFO - 2017-01-16 09:31:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:53 --> Model Class Initialized
INFO - 2017-01-16 09:31:53 --> Model Class Initialized
INFO - 2017-01-16 09:31:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:53 --> Total execution time: 0.1522
INFO - 2017-01-16 09:31:54 --> Config Class Initialized
INFO - 2017-01-16 09:31:54 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:54 --> Config Class Initialized
INFO - 2017-01-16 09:31:54 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:54 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:54 --> URI Class Initialized
INFO - 2017-01-16 09:31:54 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:54 --> URI Class Initialized
INFO - 2017-01-16 09:31:54 --> Router Class Initialized
INFO - 2017-01-16 09:31:54 --> Router Class Initialized
INFO - 2017-01-16 09:31:54 --> Output Class Initialized
INFO - 2017-01-16 09:31:54 --> Output Class Initialized
INFO - 2017-01-16 09:31:54 --> Security Class Initialized
INFO - 2017-01-16 09:31:54 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:54 --> Input Class Initialized
INFO - 2017-01-16 09:31:54 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:54 --> Input Class Initialized
INFO - 2017-01-16 09:31:54 --> Language Class Initialized
INFO - 2017-01-16 09:31:54 --> Loader Class Initialized
INFO - 2017-01-16 09:31:54 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:54 --> Loader Class Initialized
INFO - 2017-01-16 09:31:54 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:54 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:54 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:54 --> Controller Class Initialized
INFO - 2017-01-16 09:31:54 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:54 --> Model Class Initialized
INFO - 2017-01-16 09:31:54 --> Model Class Initialized
INFO - 2017-01-16 09:31:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:54 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:54 --> Total execution time: 0.0676
INFO - 2017-01-16 09:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:54 --> Controller Class Initialized
INFO - 2017-01-16 09:31:54 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:54 --> Model Class Initialized
INFO - 2017-01-16 09:31:54 --> Model Class Initialized
INFO - 2017-01-16 09:31:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:54 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:54 --> Total execution time: 0.1256
INFO - 2017-01-16 09:31:55 --> Config Class Initialized
INFO - 2017-01-16 09:31:55 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:55 --> URI Class Initialized
INFO - 2017-01-16 09:31:55 --> Router Class Initialized
INFO - 2017-01-16 09:31:55 --> Config Class Initialized
INFO - 2017-01-16 09:31:55 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:55 --> Output Class Initialized
INFO - 2017-01-16 09:31:55 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:55 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:55 --> Input Class Initialized
INFO - 2017-01-16 09:31:55 --> Language Class Initialized
INFO - 2017-01-16 09:31:55 --> URI Class Initialized
INFO - 2017-01-16 09:31:55 --> Router Class Initialized
INFO - 2017-01-16 09:31:55 --> Loader Class Initialized
INFO - 2017-01-16 09:31:55 --> Output Class Initialized
INFO - 2017-01-16 09:31:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:55 --> Security Class Initialized
INFO - 2017-01-16 09:31:55 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:55 --> Input Class Initialized
INFO - 2017-01-16 09:31:55 --> Language Class Initialized
INFO - 2017-01-16 09:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:55 --> Controller Class Initialized
INFO - 2017-01-16 09:31:55 --> Loader Class Initialized
INFO - 2017-01-16 09:31:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:55 --> Model Class Initialized
INFO - 2017-01-16 09:31:55 --> Model Class Initialized
INFO - 2017-01-16 09:31:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:55 --> Total execution time: 0.0853
INFO - 2017-01-16 09:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:55 --> Controller Class Initialized
INFO - 2017-01-16 09:31:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:55 --> Model Class Initialized
INFO - 2017-01-16 09:31:55 --> Model Class Initialized
INFO - 2017-01-16 09:31:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:55 --> Total execution time: 0.1651
INFO - 2017-01-16 09:31:57 --> Config Class Initialized
INFO - 2017-01-16 09:31:57 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:57 --> Config Class Initialized
INFO - 2017-01-16 09:31:57 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:57 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:31:57 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:57 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:57 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:57 --> URI Class Initialized
INFO - 2017-01-16 09:31:57 --> URI Class Initialized
INFO - 2017-01-16 09:31:57 --> Router Class Initialized
INFO - 2017-01-16 09:31:57 --> Router Class Initialized
INFO - 2017-01-16 09:31:57 --> Output Class Initialized
INFO - 2017-01-16 09:31:57 --> Output Class Initialized
INFO - 2017-01-16 09:31:57 --> Security Class Initialized
INFO - 2017-01-16 09:31:57 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:57 --> Input Class Initialized
DEBUG - 2017-01-16 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:57 --> Input Class Initialized
INFO - 2017-01-16 09:31:57 --> Language Class Initialized
INFO - 2017-01-16 09:31:57 --> Language Class Initialized
INFO - 2017-01-16 09:31:57 --> Loader Class Initialized
INFO - 2017-01-16 09:31:57 --> Loader Class Initialized
INFO - 2017-01-16 09:31:57 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:57 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:57 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:57 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:57 --> Controller Class Initialized
INFO - 2017-01-16 09:31:57 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:57 --> Model Class Initialized
INFO - 2017-01-16 09:31:57 --> Model Class Initialized
INFO - 2017-01-16 09:31:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:57 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:57 --> Total execution time: 0.1426
INFO - 2017-01-16 09:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:57 --> Controller Class Initialized
INFO - 2017-01-16 09:31:57 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:57 --> Model Class Initialized
INFO - 2017-01-16 09:31:57 --> Model Class Initialized
INFO - 2017-01-16 09:31:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:57 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:57 --> Total execution time: 0.1704
INFO - 2017-01-16 09:31:58 --> Config Class Initialized
INFO - 2017-01-16 09:31:58 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:58 --> Config Class Initialized
INFO - 2017-01-16 09:31:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:58 --> URI Class Initialized
DEBUG - 2017-01-16 09:31:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:58 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:58 --> Router Class Initialized
INFO - 2017-01-16 09:31:58 --> URI Class Initialized
INFO - 2017-01-16 09:31:58 --> Output Class Initialized
INFO - 2017-01-16 09:31:58 --> Router Class Initialized
INFO - 2017-01-16 09:31:58 --> Security Class Initialized
INFO - 2017-01-16 09:31:58 --> Output Class Initialized
DEBUG - 2017-01-16 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:58 --> Security Class Initialized
INFO - 2017-01-16 09:31:58 --> Input Class Initialized
INFO - 2017-01-16 09:31:58 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:58 --> Input Class Initialized
INFO - 2017-01-16 09:31:58 --> Language Class Initialized
INFO - 2017-01-16 09:31:58 --> Loader Class Initialized
INFO - 2017-01-16 09:31:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:58 --> Loader Class Initialized
INFO - 2017-01-16 09:31:58 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:58 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:58 --> Controller Class Initialized
INFO - 2017-01-16 09:31:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:58 --> Model Class Initialized
INFO - 2017-01-16 09:31:58 --> Model Class Initialized
INFO - 2017-01-16 09:31:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:58 --> Total execution time: 0.0714
INFO - 2017-01-16 09:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:58 --> Controller Class Initialized
INFO - 2017-01-16 09:31:58 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:58 --> Model Class Initialized
INFO - 2017-01-16 09:31:58 --> Model Class Initialized
INFO - 2017-01-16 09:31:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:58 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:58 --> Total execution time: 0.1461
INFO - 2017-01-16 09:31:59 --> Config Class Initialized
INFO - 2017-01-16 09:31:59 --> Hooks Class Initialized
INFO - 2017-01-16 09:31:59 --> Config Class Initialized
INFO - 2017-01-16 09:31:59 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:31:59 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:31:59 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:59 --> Utf8 Class Initialized
INFO - 2017-01-16 09:31:59 --> URI Class Initialized
INFO - 2017-01-16 09:31:59 --> URI Class Initialized
INFO - 2017-01-16 09:31:59 --> Router Class Initialized
INFO - 2017-01-16 09:31:59 --> Router Class Initialized
INFO - 2017-01-16 09:31:59 --> Output Class Initialized
INFO - 2017-01-16 09:31:59 --> Output Class Initialized
INFO - 2017-01-16 09:31:59 --> Security Class Initialized
INFO - 2017-01-16 09:31:59 --> Security Class Initialized
DEBUG - 2017-01-16 09:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:59 --> Input Class Initialized
INFO - 2017-01-16 09:31:59 --> Language Class Initialized
DEBUG - 2017-01-16 09:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:31:59 --> Input Class Initialized
INFO - 2017-01-16 09:31:59 --> Language Class Initialized
INFO - 2017-01-16 09:31:59 --> Loader Class Initialized
INFO - 2017-01-16 09:31:59 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:59 --> Loader Class Initialized
INFO - 2017-01-16 09:31:59 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:59 --> Helper loaded: url_helper
INFO - 2017-01-16 09:31:59 --> Helper loaded: language_helper
INFO - 2017-01-16 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:59 --> Controller Class Initialized
INFO - 2017-01-16 09:31:59 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:59 --> Model Class Initialized
INFO - 2017-01-16 09:31:59 --> Model Class Initialized
INFO - 2017-01-16 09:31:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:59 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:59 --> Total execution time: 0.0768
INFO - 2017-01-16 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:31:59 --> Controller Class Initialized
INFO - 2017-01-16 09:31:59 --> Database Driver Class Initialized
INFO - 2017-01-16 09:31:59 --> Model Class Initialized
INFO - 2017-01-16 09:31:59 --> Model Class Initialized
INFO - 2017-01-16 09:31:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:31:59 --> Final output sent to browser
DEBUG - 2017-01-16 09:31:59 --> Total execution time: 0.1822
INFO - 2017-01-16 09:32:01 --> Config Class Initialized
INFO - 2017-01-16 09:32:01 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:01 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:01 --> Config Class Initialized
INFO - 2017-01-16 09:32:01 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:01 --> URI Class Initialized
INFO - 2017-01-16 09:32:01 --> Router Class Initialized
DEBUG - 2017-01-16 09:32:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:01 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:01 --> Output Class Initialized
INFO - 2017-01-16 09:32:01 --> URI Class Initialized
INFO - 2017-01-16 09:32:01 --> Security Class Initialized
INFO - 2017-01-16 09:32:01 --> Router Class Initialized
INFO - 2017-01-16 09:32:01 --> Output Class Initialized
DEBUG - 2017-01-16 09:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:01 --> Input Class Initialized
INFO - 2017-01-16 09:32:01 --> Security Class Initialized
INFO - 2017-01-16 09:32:01 --> Language Class Initialized
DEBUG - 2017-01-16 09:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:01 --> Input Class Initialized
INFO - 2017-01-16 09:32:01 --> Language Class Initialized
INFO - 2017-01-16 09:32:01 --> Loader Class Initialized
INFO - 2017-01-16 09:32:01 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:01 --> Loader Class Initialized
INFO - 2017-01-16 09:32:01 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:01 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:01 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:01 --> Controller Class Initialized
INFO - 2017-01-16 09:32:01 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:01 --> Model Class Initialized
INFO - 2017-01-16 09:32:01 --> Model Class Initialized
INFO - 2017-01-16 09:32:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:01 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:01 --> Total execution time: 0.1571
INFO - 2017-01-16 09:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:01 --> Controller Class Initialized
INFO - 2017-01-16 09:32:01 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:01 --> Model Class Initialized
INFO - 2017-01-16 09:32:01 --> Model Class Initialized
INFO - 2017-01-16 09:32:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:01 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:01 --> Total execution time: 0.1820
INFO - 2017-01-16 09:32:02 --> Config Class Initialized
INFO - 2017-01-16 09:32:02 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:02 --> Config Class Initialized
INFO - 2017-01-16 09:32:02 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:02 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:02 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:02 --> URI Class Initialized
DEBUG - 2017-01-16 09:32:02 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:02 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:02 --> Router Class Initialized
INFO - 2017-01-16 09:32:02 --> URI Class Initialized
INFO - 2017-01-16 09:32:02 --> Output Class Initialized
INFO - 2017-01-16 09:32:02 --> Router Class Initialized
INFO - 2017-01-16 09:32:02 --> Security Class Initialized
DEBUG - 2017-01-16 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:02 --> Input Class Initialized
INFO - 2017-01-16 09:32:02 --> Output Class Initialized
INFO - 2017-01-16 09:32:02 --> Language Class Initialized
INFO - 2017-01-16 09:32:02 --> Security Class Initialized
INFO - 2017-01-16 09:32:02 --> Loader Class Initialized
DEBUG - 2017-01-16 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:02 --> Input Class Initialized
INFO - 2017-01-16 09:32:02 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:02 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:02 --> Language Class Initialized
INFO - 2017-01-16 09:32:02 --> Loader Class Initialized
INFO - 2017-01-16 09:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:02 --> Controller Class Initialized
INFO - 2017-01-16 09:32:02 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:02 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:02 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:02 --> Model Class Initialized
INFO - 2017-01-16 09:32:02 --> Model Class Initialized
INFO - 2017-01-16 09:32:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:02 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:02 --> Total execution time: 0.0806
INFO - 2017-01-16 09:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:02 --> Controller Class Initialized
INFO - 2017-01-16 09:32:02 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:02 --> Model Class Initialized
INFO - 2017-01-16 09:32:02 --> Model Class Initialized
INFO - 2017-01-16 09:32:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:02 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:02 --> Total execution time: 0.1835
INFO - 2017-01-16 09:32:03 --> Config Class Initialized
INFO - 2017-01-16 09:32:03 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:03 --> Config Class Initialized
INFO - 2017-01-16 09:32:03 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:03 --> URI Class Initialized
DEBUG - 2017-01-16 09:32:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:03 --> Router Class Initialized
INFO - 2017-01-16 09:32:03 --> URI Class Initialized
INFO - 2017-01-16 09:32:03 --> Output Class Initialized
INFO - 2017-01-16 09:32:03 --> Router Class Initialized
INFO - 2017-01-16 09:32:03 --> Security Class Initialized
INFO - 2017-01-16 09:32:03 --> Output Class Initialized
DEBUG - 2017-01-16 09:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:03 --> Input Class Initialized
INFO - 2017-01-16 09:32:03 --> Security Class Initialized
INFO - 2017-01-16 09:32:03 --> Language Class Initialized
DEBUG - 2017-01-16 09:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:03 --> Input Class Initialized
INFO - 2017-01-16 09:32:03 --> Loader Class Initialized
INFO - 2017-01-16 09:32:03 --> Language Class Initialized
INFO - 2017-01-16 09:32:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:03 --> Loader Class Initialized
INFO - 2017-01-16 09:32:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:03 --> Controller Class Initialized
INFO - 2017-01-16 09:32:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:03 --> Model Class Initialized
INFO - 2017-01-16 09:32:03 --> Model Class Initialized
INFO - 2017-01-16 09:32:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:03 --> Total execution time: 0.0681
INFO - 2017-01-16 09:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:03 --> Controller Class Initialized
INFO - 2017-01-16 09:32:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:03 --> Model Class Initialized
INFO - 2017-01-16 09:32:03 --> Model Class Initialized
INFO - 2017-01-16 09:32:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:03 --> Total execution time: 0.1659
INFO - 2017-01-16 09:32:05 --> Config Class Initialized
INFO - 2017-01-16 09:32:05 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:05 --> Config Class Initialized
INFO - 2017-01-16 09:32:05 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:05 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:32:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:05 --> URI Class Initialized
INFO - 2017-01-16 09:32:05 --> URI Class Initialized
INFO - 2017-01-16 09:32:05 --> Router Class Initialized
INFO - 2017-01-16 09:32:05 --> Router Class Initialized
INFO - 2017-01-16 09:32:05 --> Output Class Initialized
INFO - 2017-01-16 09:32:05 --> Output Class Initialized
INFO - 2017-01-16 09:32:05 --> Security Class Initialized
INFO - 2017-01-16 09:32:05 --> Security Class Initialized
DEBUG - 2017-01-16 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:05 --> Input Class Initialized
INFO - 2017-01-16 09:32:05 --> Language Class Initialized
DEBUG - 2017-01-16 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:05 --> Input Class Initialized
INFO - 2017-01-16 09:32:05 --> Language Class Initialized
INFO - 2017-01-16 09:32:05 --> Loader Class Initialized
INFO - 2017-01-16 09:32:05 --> Loader Class Initialized
INFO - 2017-01-16 09:32:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:05 --> Controller Class Initialized
INFO - 2017-01-16 09:32:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:05 --> Model Class Initialized
INFO - 2017-01-16 09:32:05 --> Model Class Initialized
INFO - 2017-01-16 09:32:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:05 --> Total execution time: 0.0809
INFO - 2017-01-16 09:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:05 --> Controller Class Initialized
INFO - 2017-01-16 09:32:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:05 --> Model Class Initialized
INFO - 2017-01-16 09:32:05 --> Model Class Initialized
INFO - 2017-01-16 09:32:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:05 --> Total execution time: 0.1898
INFO - 2017-01-16 09:32:06 --> Config Class Initialized
INFO - 2017-01-16 09:32:06 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:06 --> Config Class Initialized
INFO - 2017-01-16 09:32:06 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:32:06 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:06 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:06 --> URI Class Initialized
INFO - 2017-01-16 09:32:06 --> URI Class Initialized
INFO - 2017-01-16 09:32:06 --> Router Class Initialized
INFO - 2017-01-16 09:32:06 --> Router Class Initialized
INFO - 2017-01-16 09:32:06 --> Output Class Initialized
INFO - 2017-01-16 09:32:06 --> Output Class Initialized
INFO - 2017-01-16 09:32:06 --> Security Class Initialized
INFO - 2017-01-16 09:32:06 --> Security Class Initialized
DEBUG - 2017-01-16 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:06 --> Input Class Initialized
INFO - 2017-01-16 09:32:06 --> Language Class Initialized
DEBUG - 2017-01-16 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:06 --> Input Class Initialized
INFO - 2017-01-16 09:32:06 --> Language Class Initialized
INFO - 2017-01-16 09:32:06 --> Loader Class Initialized
INFO - 2017-01-16 09:32:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:06 --> Loader Class Initialized
INFO - 2017-01-16 09:32:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:06 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:06 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:06 --> Controller Class Initialized
INFO - 2017-01-16 09:32:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:06 --> Model Class Initialized
INFO - 2017-01-16 09:32:06 --> Model Class Initialized
INFO - 2017-01-16 09:32:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:06 --> Total execution time: 0.0787
INFO - 2017-01-16 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:06 --> Controller Class Initialized
INFO - 2017-01-16 09:32:06 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:06 --> Model Class Initialized
INFO - 2017-01-16 09:32:06 --> Model Class Initialized
INFO - 2017-01-16 09:32:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:06 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:06 --> Total execution time: 0.2069
INFO - 2017-01-16 09:32:08 --> Config Class Initialized
INFO - 2017-01-16 09:32:08 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:08 --> Config Class Initialized
INFO - 2017-01-16 09:32:08 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:08 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:08 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:08 --> URI Class Initialized
DEBUG - 2017-01-16 09:32:08 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:08 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:08 --> Router Class Initialized
INFO - 2017-01-16 09:32:08 --> URI Class Initialized
INFO - 2017-01-16 09:32:08 --> Router Class Initialized
INFO - 2017-01-16 09:32:08 --> Output Class Initialized
INFO - 2017-01-16 09:32:08 --> Output Class Initialized
INFO - 2017-01-16 09:32:08 --> Security Class Initialized
DEBUG - 2017-01-16 09:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:08 --> Input Class Initialized
INFO - 2017-01-16 09:32:08 --> Security Class Initialized
INFO - 2017-01-16 09:32:08 --> Language Class Initialized
DEBUG - 2017-01-16 09:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:08 --> Input Class Initialized
INFO - 2017-01-16 09:32:08 --> Language Class Initialized
INFO - 2017-01-16 09:32:08 --> Loader Class Initialized
INFO - 2017-01-16 09:32:08 --> Loader Class Initialized
INFO - 2017-01-16 09:32:08 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:08 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:08 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:08 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:08 --> Controller Class Initialized
INFO - 2017-01-16 09:32:08 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:08 --> Model Class Initialized
INFO - 2017-01-16 09:32:08 --> Model Class Initialized
INFO - 2017-01-16 09:32:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:08 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:08 --> Total execution time: 0.0731
INFO - 2017-01-16 09:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:08 --> Controller Class Initialized
INFO - 2017-01-16 09:32:08 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:08 --> Model Class Initialized
INFO - 2017-01-16 09:32:08 --> Model Class Initialized
INFO - 2017-01-16 09:32:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:08 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:08 --> Total execution time: 0.1985
INFO - 2017-01-16 09:32:09 --> Config Class Initialized
INFO - 2017-01-16 09:32:09 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:09 --> Config Class Initialized
INFO - 2017-01-16 09:32:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:09 --> URI Class Initialized
DEBUG - 2017-01-16 09:32:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:09 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:09 --> Router Class Initialized
INFO - 2017-01-16 09:32:09 --> URI Class Initialized
INFO - 2017-01-16 09:32:09 --> Output Class Initialized
INFO - 2017-01-16 09:32:09 --> Router Class Initialized
INFO - 2017-01-16 09:32:09 --> Security Class Initialized
INFO - 2017-01-16 09:32:09 --> Output Class Initialized
DEBUG - 2017-01-16 09:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:09 --> Input Class Initialized
INFO - 2017-01-16 09:32:09 --> Security Class Initialized
INFO - 2017-01-16 09:32:09 --> Language Class Initialized
DEBUG - 2017-01-16 09:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:09 --> Input Class Initialized
INFO - 2017-01-16 09:32:09 --> Language Class Initialized
INFO - 2017-01-16 09:32:09 --> Loader Class Initialized
INFO - 2017-01-16 09:32:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:09 --> Loader Class Initialized
INFO - 2017-01-16 09:32:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:09 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:09 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:09 --> Controller Class Initialized
INFO - 2017-01-16 09:32:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:09 --> Model Class Initialized
INFO - 2017-01-16 09:32:09 --> Model Class Initialized
INFO - 2017-01-16 09:32:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:09 --> Total execution time: 0.1683
INFO - 2017-01-16 09:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:09 --> Controller Class Initialized
INFO - 2017-01-16 09:32:09 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:09 --> Model Class Initialized
INFO - 2017-01-16 09:32:09 --> Model Class Initialized
INFO - 2017-01-16 09:32:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:09 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:09 --> Total execution time: 0.1885
INFO - 2017-01-16 09:32:11 --> Config Class Initialized
INFO - 2017-01-16 09:32:11 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:11 --> Config Class Initialized
INFO - 2017-01-16 09:32:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:11 --> URI Class Initialized
DEBUG - 2017-01-16 09:32:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:11 --> Router Class Initialized
INFO - 2017-01-16 09:32:11 --> URI Class Initialized
INFO - 2017-01-16 09:32:11 --> Output Class Initialized
INFO - 2017-01-16 09:32:11 --> Config Class Initialized
INFO - 2017-01-16 09:32:11 --> Router Class Initialized
INFO - 2017-01-16 09:32:11 --> Hooks Class Initialized
INFO - 2017-01-16 09:32:11 --> Security Class Initialized
INFO - 2017-01-16 09:32:11 --> Output Class Initialized
DEBUG - 2017-01-16 09:32:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:11 --> Security Class Initialized
INFO - 2017-01-16 09:32:11 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:11 --> URI Class Initialized
INFO - 2017-01-16 09:32:11 --> Input Class Initialized
INFO - 2017-01-16 09:32:11 --> Input Class Initialized
INFO - 2017-01-16 09:32:11 --> Language Class Initialized
INFO - 2017-01-16 09:32:11 --> Language Class Initialized
INFO - 2017-01-16 09:32:11 --> Router Class Initialized
INFO - 2017-01-16 09:32:11 --> Output Class Initialized
INFO - 2017-01-16 09:32:11 --> Security Class Initialized
INFO - 2017-01-16 09:32:11 --> Loader Class Initialized
DEBUG - 2017-01-16 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:11 --> Input Class Initialized
INFO - 2017-01-16 09:32:11 --> Loader Class Initialized
INFO - 2017-01-16 09:32:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:11 --> Language Class Initialized
INFO - 2017-01-16 09:32:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:11 --> Controller Class Initialized
INFO - 2017-01-16 09:32:11 --> Loader Class Initialized
INFO - 2017-01-16 09:32:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:11 --> Total execution time: 0.0957
INFO - 2017-01-16 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:11 --> Controller Class Initialized
INFO - 2017-01-16 09:32:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:11 --> Total execution time: 0.2552
INFO - 2017-01-16 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:11 --> Controller Class Initialized
INFO - 2017-01-16 09:32:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:11 --> Config Class Initialized
INFO - 2017-01-16 09:32:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:32:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:32:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:32:11 --> URI Class Initialized
INFO - 2017-01-16 09:32:11 --> Router Class Initialized
INFO - 2017-01-16 09:32:11 --> Output Class Initialized
INFO - 2017-01-16 09:32:11 --> Security Class Initialized
DEBUG - 2017-01-16 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:32:11 --> Input Class Initialized
INFO - 2017-01-16 09:32:11 --> Language Class Initialized
INFO - 2017-01-16 09:32:11 --> Loader Class Initialized
INFO - 2017-01-16 09:32:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:32:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:32:11 --> Controller Class Initialized
INFO - 2017-01-16 09:32:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Model Class Initialized
INFO - 2017-01-16 09:32:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:32:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:32:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2017-01-16 09:32:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:32:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:32:11 --> Total execution time: 0.0898
INFO - 2017-01-16 09:35:16 --> Config Class Initialized
INFO - 2017-01-16 09:35:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:16 --> URI Class Initialized
INFO - 2017-01-16 09:35:16 --> Router Class Initialized
INFO - 2017-01-16 09:35:16 --> Output Class Initialized
INFO - 2017-01-16 09:35:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:16 --> Input Class Initialized
INFO - 2017-01-16 09:35:16 --> Language Class Initialized
INFO - 2017-01-16 09:35:16 --> Loader Class Initialized
INFO - 2017-01-16 09:35:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:16 --> Controller Class Initialized
INFO - 2017-01-16 09:35:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:16 --> Config Class Initialized
INFO - 2017-01-16 09:35:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:16 --> URI Class Initialized
INFO - 2017-01-16 09:35:16 --> Router Class Initialized
INFO - 2017-01-16 09:35:16 --> Output Class Initialized
INFO - 2017-01-16 09:35:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:16 --> Input Class Initialized
INFO - 2017-01-16 09:35:16 --> Language Class Initialized
INFO - 2017-01-16 09:35:16 --> Loader Class Initialized
INFO - 2017-01-16 09:35:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:16 --> Controller Class Initialized
INFO - 2017-01-16 09:35:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:35:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2017-01-16 09:35:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:35:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:16 --> Total execution time: 0.0762
INFO - 2017-01-16 09:35:16 --> Config Class Initialized
INFO - 2017-01-16 09:35:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:16 --> Config Class Initialized
INFO - 2017-01-16 09:35:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:16 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:16 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:16 --> Router Class Initialized
INFO - 2017-01-16 09:35:16 --> URI Class Initialized
INFO - 2017-01-16 09:35:16 --> Output Class Initialized
INFO - 2017-01-16 09:35:16 --> Router Class Initialized
INFO - 2017-01-16 09:35:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:16 --> Input Class Initialized
INFO - 2017-01-16 09:35:16 --> Output Class Initialized
INFO - 2017-01-16 09:35:16 --> Language Class Initialized
INFO - 2017-01-16 09:35:16 --> Security Class Initialized
INFO - 2017-01-16 09:35:16 --> Loader Class Initialized
DEBUG - 2017-01-16 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:16 --> Input Class Initialized
INFO - 2017-01-16 09:35:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:16 --> Language Class Initialized
INFO - 2017-01-16 09:35:16 --> Loader Class Initialized
INFO - 2017-01-16 09:35:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:16 --> Controller Class Initialized
INFO - 2017-01-16 09:35:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:16 --> Total execution time: 0.0745
INFO - 2017-01-16 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:16 --> Controller Class Initialized
INFO - 2017-01-16 09:35:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Model Class Initialized
INFO - 2017-01-16 09:35:16 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:35:16 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:35:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:16 --> Total execution time: 0.1017
INFO - 2017-01-16 09:35:19 --> Config Class Initialized
INFO - 2017-01-16 09:35:19 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:19 --> Config Class Initialized
INFO - 2017-01-16 09:35:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:19 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:19 --> URI Class Initialized
INFO - 2017-01-16 09:35:19 --> URI Class Initialized
INFO - 2017-01-16 09:35:19 --> Router Class Initialized
INFO - 2017-01-16 09:35:19 --> Router Class Initialized
INFO - 2017-01-16 09:35:19 --> Output Class Initialized
INFO - 2017-01-16 09:35:19 --> Output Class Initialized
INFO - 2017-01-16 09:35:19 --> Security Class Initialized
INFO - 2017-01-16 09:35:19 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:19 --> Input Class Initialized
DEBUG - 2017-01-16 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:19 --> Language Class Initialized
INFO - 2017-01-16 09:35:19 --> Input Class Initialized
INFO - 2017-01-16 09:35:19 --> Language Class Initialized
INFO - 2017-01-16 09:35:19 --> Loader Class Initialized
INFO - 2017-01-16 09:35:19 --> Loader Class Initialized
INFO - 2017-01-16 09:35:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:19 --> Controller Class Initialized
INFO - 2017-01-16 09:35:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:19 --> Model Class Initialized
INFO - 2017-01-16 09:35:19 --> Model Class Initialized
INFO - 2017-01-16 09:35:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:19 --> Total execution time: 0.0722
INFO - 2017-01-16 09:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:19 --> Controller Class Initialized
INFO - 2017-01-16 09:35:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:19 --> Model Class Initialized
INFO - 2017-01-16 09:35:19 --> Model Class Initialized
INFO - 2017-01-16 09:35:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:19 --> Total execution time: 0.1027
INFO - 2017-01-16 09:35:20 --> Config Class Initialized
INFO - 2017-01-16 09:35:20 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:20 --> Config Class Initialized
INFO - 2017-01-16 09:35:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:20 --> URI Class Initialized
INFO - 2017-01-16 09:35:20 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:20 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:20 --> URI Class Initialized
INFO - 2017-01-16 09:35:20 --> Output Class Initialized
INFO - 2017-01-16 09:35:20 --> Router Class Initialized
INFO - 2017-01-16 09:35:20 --> Security Class Initialized
INFO - 2017-01-16 09:35:20 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:20 --> Input Class Initialized
INFO - 2017-01-16 09:35:20 --> Language Class Initialized
INFO - 2017-01-16 09:35:20 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:20 --> Input Class Initialized
INFO - 2017-01-16 09:35:20 --> Loader Class Initialized
INFO - 2017-01-16 09:35:20 --> Language Class Initialized
INFO - 2017-01-16 09:35:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:20 --> Loader Class Initialized
INFO - 2017-01-16 09:35:20 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:20 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:20 --> Controller Class Initialized
INFO - 2017-01-16 09:35:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:20 --> Model Class Initialized
INFO - 2017-01-16 09:35:20 --> Model Class Initialized
INFO - 2017-01-16 09:35:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:20 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:20 --> Total execution time: 0.0727
INFO - 2017-01-16 09:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:20 --> Controller Class Initialized
INFO - 2017-01-16 09:35:20 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:20 --> Model Class Initialized
INFO - 2017-01-16 09:35:20 --> Model Class Initialized
INFO - 2017-01-16 09:35:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:21 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:21 --> Total execution time: 0.1059
INFO - 2017-01-16 09:35:23 --> Config Class Initialized
INFO - 2017-01-16 09:35:23 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:23 --> Config Class Initialized
INFO - 2017-01-16 09:35:23 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:23 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:23 --> Router Class Initialized
INFO - 2017-01-16 09:35:23 --> URI Class Initialized
INFO - 2017-01-16 09:35:23 --> Output Class Initialized
INFO - 2017-01-16 09:35:23 --> Router Class Initialized
INFO - 2017-01-16 09:35:23 --> Security Class Initialized
INFO - 2017-01-16 09:35:23 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:23 --> Input Class Initialized
INFO - 2017-01-16 09:35:23 --> Security Class Initialized
INFO - 2017-01-16 09:35:23 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:23 --> Input Class Initialized
INFO - 2017-01-16 09:35:23 --> Language Class Initialized
INFO - 2017-01-16 09:35:23 --> Loader Class Initialized
INFO - 2017-01-16 09:35:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:23 --> Loader Class Initialized
INFO - 2017-01-16 09:35:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:23 --> Controller Class Initialized
INFO - 2017-01-16 09:35:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:23 --> Model Class Initialized
INFO - 2017-01-16 09:35:23 --> Model Class Initialized
INFO - 2017-01-16 09:35:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:23 --> Total execution time: 0.0662
INFO - 2017-01-16 09:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:23 --> Controller Class Initialized
INFO - 2017-01-16 09:35:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:23 --> Model Class Initialized
INFO - 2017-01-16 09:35:23 --> Model Class Initialized
INFO - 2017-01-16 09:35:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:23 --> Total execution time: 0.1137
INFO - 2017-01-16 09:35:24 --> Config Class Initialized
INFO - 2017-01-16 09:35:24 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:24 --> Config Class Initialized
INFO - 2017-01-16 09:35:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:24 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:24 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:24 --> URI Class Initialized
INFO - 2017-01-16 09:35:24 --> URI Class Initialized
INFO - 2017-01-16 09:35:24 --> Router Class Initialized
INFO - 2017-01-16 09:35:24 --> Router Class Initialized
INFO - 2017-01-16 09:35:24 --> Output Class Initialized
INFO - 2017-01-16 09:35:24 --> Output Class Initialized
INFO - 2017-01-16 09:35:24 --> Security Class Initialized
INFO - 2017-01-16 09:35:24 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-16 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:24 --> Input Class Initialized
INFO - 2017-01-16 09:35:24 --> Input Class Initialized
INFO - 2017-01-16 09:35:24 --> Language Class Initialized
INFO - 2017-01-16 09:35:24 --> Language Class Initialized
INFO - 2017-01-16 09:35:24 --> Loader Class Initialized
INFO - 2017-01-16 09:35:24 --> Loader Class Initialized
INFO - 2017-01-16 09:35:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:24 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:24 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:24 --> Controller Class Initialized
INFO - 2017-01-16 09:35:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:24 --> Model Class Initialized
INFO - 2017-01-16 09:35:24 --> Model Class Initialized
INFO - 2017-01-16 09:35:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:24 --> Total execution time: 0.1118
INFO - 2017-01-16 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:24 --> Controller Class Initialized
INFO - 2017-01-16 09:35:24 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:24 --> Model Class Initialized
INFO - 2017-01-16 09:35:24 --> Model Class Initialized
INFO - 2017-01-16 09:35:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:24 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:24 --> Total execution time: 0.1442
INFO - 2017-01-16 09:35:26 --> Config Class Initialized
INFO - 2017-01-16 09:35:26 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:26 --> Config Class Initialized
INFO - 2017-01-16 09:35:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:26 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:26 --> Router Class Initialized
INFO - 2017-01-16 09:35:26 --> URI Class Initialized
INFO - 2017-01-16 09:35:26 --> Output Class Initialized
INFO - 2017-01-16 09:35:26 --> Router Class Initialized
INFO - 2017-01-16 09:35:26 --> Security Class Initialized
INFO - 2017-01-16 09:35:26 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:26 --> Input Class Initialized
INFO - 2017-01-16 09:35:26 --> Security Class Initialized
INFO - 2017-01-16 09:35:26 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:26 --> Input Class Initialized
INFO - 2017-01-16 09:35:26 --> Language Class Initialized
INFO - 2017-01-16 09:35:26 --> Loader Class Initialized
INFO - 2017-01-16 09:35:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:26 --> Loader Class Initialized
INFO - 2017-01-16 09:35:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:26 --> Controller Class Initialized
INFO - 2017-01-16 09:35:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:26 --> Model Class Initialized
INFO - 2017-01-16 09:35:26 --> Model Class Initialized
INFO - 2017-01-16 09:35:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:26 --> Total execution time: 0.0729
INFO - 2017-01-16 09:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:26 --> Controller Class Initialized
INFO - 2017-01-16 09:35:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:26 --> Model Class Initialized
INFO - 2017-01-16 09:35:26 --> Model Class Initialized
INFO - 2017-01-16 09:35:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:26 --> Total execution time: 0.1256
INFO - 2017-01-16 09:35:27 --> Config Class Initialized
INFO - 2017-01-16 09:35:27 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:27 --> Config Class Initialized
INFO - 2017-01-16 09:35:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:27 --> URI Class Initialized
INFO - 2017-01-16 09:35:27 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:27 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:27 --> Output Class Initialized
INFO - 2017-01-16 09:35:27 --> URI Class Initialized
INFO - 2017-01-16 09:35:27 --> Security Class Initialized
INFO - 2017-01-16 09:35:27 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:27 --> Input Class Initialized
INFO - 2017-01-16 09:35:27 --> Output Class Initialized
INFO - 2017-01-16 09:35:27 --> Language Class Initialized
INFO - 2017-01-16 09:35:27 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:27 --> Input Class Initialized
INFO - 2017-01-16 09:35:27 --> Loader Class Initialized
INFO - 2017-01-16 09:35:27 --> Language Class Initialized
INFO - 2017-01-16 09:35:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:27 --> Loader Class Initialized
INFO - 2017-01-16 09:35:27 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:27 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:27 --> Controller Class Initialized
INFO - 2017-01-16 09:35:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:27 --> Model Class Initialized
INFO - 2017-01-16 09:35:27 --> Model Class Initialized
INFO - 2017-01-16 09:35:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:27 --> Total execution time: 0.0875
INFO - 2017-01-16 09:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:27 --> Controller Class Initialized
INFO - 2017-01-16 09:35:27 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:27 --> Model Class Initialized
INFO - 2017-01-16 09:35:27 --> Model Class Initialized
INFO - 2017-01-16 09:35:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:27 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:27 --> Total execution time: 0.1588
INFO - 2017-01-16 09:35:29 --> Config Class Initialized
INFO - 2017-01-16 09:35:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:29 --> URI Class Initialized
INFO - 2017-01-16 09:35:29 --> Config Class Initialized
INFO - 2017-01-16 09:35:29 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:29 --> Router Class Initialized
INFO - 2017-01-16 09:35:29 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:29 --> Security Class Initialized
INFO - 2017-01-16 09:35:29 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:29 --> Input Class Initialized
INFO - 2017-01-16 09:35:29 --> Router Class Initialized
INFO - 2017-01-16 09:35:29 --> Language Class Initialized
INFO - 2017-01-16 09:35:29 --> Output Class Initialized
INFO - 2017-01-16 09:35:29 --> Security Class Initialized
INFO - 2017-01-16 09:35:29 --> Loader Class Initialized
INFO - 2017-01-16 09:35:29 --> Helper loaded: url_helper
DEBUG - 2017-01-16 09:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:29 --> Input Class Initialized
INFO - 2017-01-16 09:35:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:29 --> Language Class Initialized
INFO - 2017-01-16 09:35:29 --> Loader Class Initialized
INFO - 2017-01-16 09:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:29 --> Controller Class Initialized
INFO - 2017-01-16 09:35:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:29 --> Model Class Initialized
INFO - 2017-01-16 09:35:29 --> Model Class Initialized
INFO - 2017-01-16 09:35:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:29 --> Total execution time: 0.0759
INFO - 2017-01-16 09:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:29 --> Controller Class Initialized
INFO - 2017-01-16 09:35:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:29 --> Model Class Initialized
INFO - 2017-01-16 09:35:29 --> Model Class Initialized
INFO - 2017-01-16 09:35:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:29 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:29 --> Total execution time: 0.1381
INFO - 2017-01-16 09:35:30 --> Config Class Initialized
INFO - 2017-01-16 09:35:30 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:30 --> URI Class Initialized
INFO - 2017-01-16 09:35:30 --> Router Class Initialized
INFO - 2017-01-16 09:35:30 --> Config Class Initialized
INFO - 2017-01-16 09:35:30 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:30 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:30 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:30 --> Security Class Initialized
INFO - 2017-01-16 09:35:30 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:30 --> Input Class Initialized
INFO - 2017-01-16 09:35:30 --> Router Class Initialized
INFO - 2017-01-16 09:35:30 --> Language Class Initialized
INFO - 2017-01-16 09:35:30 --> Output Class Initialized
INFO - 2017-01-16 09:35:30 --> Loader Class Initialized
INFO - 2017-01-16 09:35:30 --> Security Class Initialized
INFO - 2017-01-16 09:35:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:30 --> Helper loaded: language_helper
DEBUG - 2017-01-16 09:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:30 --> Input Class Initialized
INFO - 2017-01-16 09:35:30 --> Language Class Initialized
INFO - 2017-01-16 09:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:30 --> Controller Class Initialized
INFO - 2017-01-16 09:35:30 --> Loader Class Initialized
INFO - 2017-01-16 09:35:30 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:30 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:30 --> Model Class Initialized
INFO - 2017-01-16 09:35:30 --> Model Class Initialized
INFO - 2017-01-16 09:35:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:30 --> Total execution time: 0.0751
INFO - 2017-01-16 09:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:30 --> Controller Class Initialized
INFO - 2017-01-16 09:35:30 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:30 --> Model Class Initialized
INFO - 2017-01-16 09:35:30 --> Model Class Initialized
INFO - 2017-01-16 09:35:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:30 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:30 --> Total execution time: 0.1355
INFO - 2017-01-16 09:35:31 --> Config Class Initialized
INFO - 2017-01-16 09:35:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:31 --> Config Class Initialized
INFO - 2017-01-16 09:35:31 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:31 --> URI Class Initialized
INFO - 2017-01-16 09:35:31 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:31 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:31 --> URI Class Initialized
INFO - 2017-01-16 09:35:31 --> Output Class Initialized
INFO - 2017-01-16 09:35:31 --> Security Class Initialized
INFO - 2017-01-16 09:35:31 --> Router Class Initialized
INFO - 2017-01-16 09:35:31 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:31 --> Input Class Initialized
INFO - 2017-01-16 09:35:31 --> Security Class Initialized
INFO - 2017-01-16 09:35:31 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:31 --> Input Class Initialized
INFO - 2017-01-16 09:35:31 --> Language Class Initialized
INFO - 2017-01-16 09:35:32 --> Loader Class Initialized
INFO - 2017-01-16 09:35:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:32 --> Loader Class Initialized
INFO - 2017-01-16 09:35:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:32 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:32 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:32 --> Controller Class Initialized
INFO - 2017-01-16 09:35:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:32 --> Model Class Initialized
INFO - 2017-01-16 09:35:32 --> Model Class Initialized
INFO - 2017-01-16 09:35:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:32 --> Total execution time: 0.1432
INFO - 2017-01-16 09:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:32 --> Controller Class Initialized
INFO - 2017-01-16 09:35:32 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:32 --> Model Class Initialized
INFO - 2017-01-16 09:35:32 --> Model Class Initialized
INFO - 2017-01-16 09:35:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:32 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:32 --> Total execution time: 0.1630
INFO - 2017-01-16 09:35:34 --> Config Class Initialized
INFO - 2017-01-16 09:35:34 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:34 --> Config Class Initialized
INFO - 2017-01-16 09:35:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:34 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:34 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:34 --> URI Class Initialized
INFO - 2017-01-16 09:35:34 --> URI Class Initialized
INFO - 2017-01-16 09:35:34 --> Router Class Initialized
INFO - 2017-01-16 09:35:34 --> Router Class Initialized
INFO - 2017-01-16 09:35:34 --> Output Class Initialized
INFO - 2017-01-16 09:35:34 --> Output Class Initialized
INFO - 2017-01-16 09:35:34 --> Security Class Initialized
INFO - 2017-01-16 09:35:34 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:34 --> Input Class Initialized
INFO - 2017-01-16 09:35:34 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:34 --> Input Class Initialized
INFO - 2017-01-16 09:35:34 --> Language Class Initialized
INFO - 2017-01-16 09:35:34 --> Loader Class Initialized
INFO - 2017-01-16 09:35:34 --> Loader Class Initialized
INFO - 2017-01-16 09:35:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:34 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:34 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:34 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:34 --> Controller Class Initialized
INFO - 2017-01-16 09:35:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:34 --> Model Class Initialized
INFO - 2017-01-16 09:35:34 --> Model Class Initialized
INFO - 2017-01-16 09:35:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:34 --> Total execution time: 0.0871
INFO - 2017-01-16 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:34 --> Controller Class Initialized
INFO - 2017-01-16 09:35:34 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:34 --> Model Class Initialized
INFO - 2017-01-16 09:35:34 --> Model Class Initialized
INFO - 2017-01-16 09:35:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:34 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:34 --> Total execution time: 0.1694
INFO - 2017-01-16 09:35:35 --> Config Class Initialized
INFO - 2017-01-16 09:35:35 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:35 --> Config Class Initialized
INFO - 2017-01-16 09:35:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:35 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:35 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:35 --> URI Class Initialized
INFO - 2017-01-16 09:35:35 --> Router Class Initialized
INFO - 2017-01-16 09:35:35 --> Output Class Initialized
INFO - 2017-01-16 09:35:35 --> Router Class Initialized
INFO - 2017-01-16 09:35:35 --> Security Class Initialized
INFO - 2017-01-16 09:35:35 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:35 --> Security Class Initialized
INFO - 2017-01-16 09:35:35 --> Input Class Initialized
INFO - 2017-01-16 09:35:35 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:35 --> Input Class Initialized
INFO - 2017-01-16 09:35:35 --> Language Class Initialized
INFO - 2017-01-16 09:35:35 --> Loader Class Initialized
INFO - 2017-01-16 09:35:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:35 --> Loader Class Initialized
INFO - 2017-01-16 09:35:35 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:35 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:35 --> Controller Class Initialized
INFO - 2017-01-16 09:35:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:35 --> Model Class Initialized
INFO - 2017-01-16 09:35:35 --> Model Class Initialized
INFO - 2017-01-16 09:35:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:35 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:35 --> Total execution time: 0.0754
INFO - 2017-01-16 09:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:35 --> Controller Class Initialized
INFO - 2017-01-16 09:35:35 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:35 --> Model Class Initialized
INFO - 2017-01-16 09:35:35 --> Model Class Initialized
INFO - 2017-01-16 09:35:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:36 --> Total execution time: 0.1606
INFO - 2017-01-16 09:35:37 --> Config Class Initialized
INFO - 2017-01-16 09:35:37 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:37 --> Config Class Initialized
INFO - 2017-01-16 09:35:37 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:37 --> URI Class Initialized
INFO - 2017-01-16 09:35:37 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:37 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:37 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:37 --> Output Class Initialized
INFO - 2017-01-16 09:35:37 --> URI Class Initialized
INFO - 2017-01-16 09:35:37 --> Security Class Initialized
INFO - 2017-01-16 09:35:37 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:37 --> Input Class Initialized
INFO - 2017-01-16 09:35:37 --> Output Class Initialized
INFO - 2017-01-16 09:35:37 --> Language Class Initialized
INFO - 2017-01-16 09:35:37 --> Security Class Initialized
INFO - 2017-01-16 09:35:37 --> Loader Class Initialized
DEBUG - 2017-01-16 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:37 --> Input Class Initialized
INFO - 2017-01-16 09:35:37 --> Language Class Initialized
INFO - 2017-01-16 09:35:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:37 --> Loader Class Initialized
INFO - 2017-01-16 09:35:37 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:37 --> Controller Class Initialized
INFO - 2017-01-16 09:35:37 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:37 --> Model Class Initialized
INFO - 2017-01-16 09:35:37 --> Model Class Initialized
INFO - 2017-01-16 09:35:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:37 --> Total execution time: 0.0786
INFO - 2017-01-16 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:37 --> Controller Class Initialized
INFO - 2017-01-16 09:35:37 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:37 --> Model Class Initialized
INFO - 2017-01-16 09:35:37 --> Model Class Initialized
INFO - 2017-01-16 09:35:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:37 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:37 --> Total execution time: 0.1681
INFO - 2017-01-16 09:35:38 --> Config Class Initialized
INFO - 2017-01-16 09:35:38 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:38 --> Config Class Initialized
INFO - 2017-01-16 09:35:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:38 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:38 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:38 --> URI Class Initialized
INFO - 2017-01-16 09:35:38 --> URI Class Initialized
INFO - 2017-01-16 09:35:38 --> Router Class Initialized
INFO - 2017-01-16 09:35:38 --> Router Class Initialized
INFO - 2017-01-16 09:35:38 --> Output Class Initialized
INFO - 2017-01-16 09:35:39 --> Security Class Initialized
INFO - 2017-01-16 09:35:39 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:39 --> Input Class Initialized
INFO - 2017-01-16 09:35:39 --> Security Class Initialized
INFO - 2017-01-16 09:35:39 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:39 --> Input Class Initialized
INFO - 2017-01-16 09:35:39 --> Loader Class Initialized
INFO - 2017-01-16 09:35:39 --> Language Class Initialized
INFO - 2017-01-16 09:35:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:39 --> Loader Class Initialized
INFO - 2017-01-16 09:35:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:39 --> Controller Class Initialized
INFO - 2017-01-16 09:35:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:39 --> Model Class Initialized
INFO - 2017-01-16 09:35:39 --> Model Class Initialized
INFO - 2017-01-16 09:35:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:39 --> Total execution time: 0.0727
INFO - 2017-01-16 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:39 --> Controller Class Initialized
INFO - 2017-01-16 09:35:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:39 --> Model Class Initialized
INFO - 2017-01-16 09:35:39 --> Model Class Initialized
INFO - 2017-01-16 09:35:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:39 --> Total execution time: 0.1833
INFO - 2017-01-16 09:35:40 --> Config Class Initialized
INFO - 2017-01-16 09:35:40 --> Config Class Initialized
INFO - 2017-01-16 09:35:40 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:40 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-16 09:35:40 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:40 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:40 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:40 --> URI Class Initialized
INFO - 2017-01-16 09:35:40 --> URI Class Initialized
INFO - 2017-01-16 09:35:40 --> Router Class Initialized
INFO - 2017-01-16 09:35:40 --> Router Class Initialized
INFO - 2017-01-16 09:35:40 --> Output Class Initialized
INFO - 2017-01-16 09:35:40 --> Output Class Initialized
INFO - 2017-01-16 09:35:40 --> Security Class Initialized
INFO - 2017-01-16 09:35:40 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:40 --> Input Class Initialized
DEBUG - 2017-01-16 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:40 --> Language Class Initialized
INFO - 2017-01-16 09:35:40 --> Input Class Initialized
INFO - 2017-01-16 09:35:40 --> Language Class Initialized
INFO - 2017-01-16 09:35:40 --> Loader Class Initialized
INFO - 2017-01-16 09:35:40 --> Loader Class Initialized
INFO - 2017-01-16 09:35:40 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:40 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:40 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:40 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:40 --> Controller Class Initialized
INFO - 2017-01-16 09:35:40 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:40 --> Model Class Initialized
INFO - 2017-01-16 09:35:40 --> Model Class Initialized
INFO - 2017-01-16 09:35:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:40 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:40 --> Total execution time: 0.0834
INFO - 2017-01-16 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:40 --> Controller Class Initialized
INFO - 2017-01-16 09:35:40 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:40 --> Model Class Initialized
INFO - 2017-01-16 09:35:40 --> Model Class Initialized
INFO - 2017-01-16 09:35:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:40 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:40 --> Total execution time: 0.1893
INFO - 2017-01-16 09:35:42 --> Config Class Initialized
INFO - 2017-01-16 09:35:42 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:42 --> Config Class Initialized
INFO - 2017-01-16 09:35:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:42 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:42 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:42 --> URI Class Initialized
INFO - 2017-01-16 09:35:42 --> URI Class Initialized
INFO - 2017-01-16 09:35:42 --> Router Class Initialized
INFO - 2017-01-16 09:35:42 --> Router Class Initialized
INFO - 2017-01-16 09:35:42 --> Output Class Initialized
INFO - 2017-01-16 09:35:42 --> Output Class Initialized
INFO - 2017-01-16 09:35:42 --> Security Class Initialized
INFO - 2017-01-16 09:35:42 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:42 --> Input Class Initialized
DEBUG - 2017-01-16 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:42 --> Input Class Initialized
INFO - 2017-01-16 09:35:42 --> Language Class Initialized
INFO - 2017-01-16 09:35:42 --> Language Class Initialized
INFO - 2017-01-16 09:35:42 --> Loader Class Initialized
INFO - 2017-01-16 09:35:42 --> Loader Class Initialized
INFO - 2017-01-16 09:35:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:42 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:42 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:42 --> Controller Class Initialized
INFO - 2017-01-16 09:35:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:42 --> Model Class Initialized
INFO - 2017-01-16 09:35:42 --> Model Class Initialized
INFO - 2017-01-16 09:35:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:42 --> Total execution time: 0.0778
INFO - 2017-01-16 09:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:42 --> Controller Class Initialized
INFO - 2017-01-16 09:35:42 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:42 --> Model Class Initialized
INFO - 2017-01-16 09:35:42 --> Model Class Initialized
INFO - 2017-01-16 09:35:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:42 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:42 --> Total execution time: 0.1905
INFO - 2017-01-16 09:35:43 --> Config Class Initialized
INFO - 2017-01-16 09:35:43 --> Config Class Initialized
INFO - 2017-01-16 09:35:43 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:43 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:43 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:43 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:43 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:43 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:43 --> URI Class Initialized
INFO - 2017-01-16 09:35:43 --> URI Class Initialized
INFO - 2017-01-16 09:35:43 --> Router Class Initialized
INFO - 2017-01-16 09:35:43 --> Router Class Initialized
INFO - 2017-01-16 09:35:43 --> Output Class Initialized
INFO - 2017-01-16 09:35:43 --> Security Class Initialized
INFO - 2017-01-16 09:35:43 --> Output Class Initialized
INFO - 2017-01-16 09:35:43 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:43 --> Input Class Initialized
INFO - 2017-01-16 09:35:43 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:43 --> Input Class Initialized
INFO - 2017-01-16 09:35:43 --> Language Class Initialized
INFO - 2017-01-16 09:35:43 --> Loader Class Initialized
INFO - 2017-01-16 09:35:43 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:43 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:43 --> Loader Class Initialized
INFO - 2017-01-16 09:35:43 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:43 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:43 --> Controller Class Initialized
INFO - 2017-01-16 09:35:43 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:43 --> Model Class Initialized
INFO - 2017-01-16 09:35:43 --> Model Class Initialized
INFO - 2017-01-16 09:35:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:43 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:43 --> Total execution time: 0.0842
INFO - 2017-01-16 09:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:43 --> Controller Class Initialized
INFO - 2017-01-16 09:35:43 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:43 --> Model Class Initialized
INFO - 2017-01-16 09:35:43 --> Model Class Initialized
INFO - 2017-01-16 09:35:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:43 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:43 --> Total execution time: 0.2366
INFO - 2017-01-16 09:35:44 --> Config Class Initialized
INFO - 2017-01-16 09:35:44 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:44 --> Config Class Initialized
INFO - 2017-01-16 09:35:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:44 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:44 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:44 --> URI Class Initialized
INFO - 2017-01-16 09:35:44 --> URI Class Initialized
INFO - 2017-01-16 09:35:44 --> Router Class Initialized
INFO - 2017-01-16 09:35:44 --> Router Class Initialized
INFO - 2017-01-16 09:35:44 --> Output Class Initialized
INFO - 2017-01-16 09:35:44 --> Output Class Initialized
INFO - 2017-01-16 09:35:44 --> Security Class Initialized
INFO - 2017-01-16 09:35:44 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:44 --> Input Class Initialized
DEBUG - 2017-01-16 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:44 --> Input Class Initialized
INFO - 2017-01-16 09:35:44 --> Language Class Initialized
INFO - 2017-01-16 09:35:44 --> Language Class Initialized
INFO - 2017-01-16 09:35:44 --> Loader Class Initialized
INFO - 2017-01-16 09:35:44 --> Loader Class Initialized
INFO - 2017-01-16 09:35:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:44 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:44 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:44 --> Controller Class Initialized
INFO - 2017-01-16 09:35:44 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:44 --> Model Class Initialized
INFO - 2017-01-16 09:35:44 --> Model Class Initialized
INFO - 2017-01-16 09:35:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:45 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:45 --> Total execution time: 0.1904
INFO - 2017-01-16 09:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:45 --> Controller Class Initialized
INFO - 2017-01-16 09:35:45 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:45 --> Model Class Initialized
INFO - 2017-01-16 09:35:45 --> Model Class Initialized
INFO - 2017-01-16 09:35:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:45 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:45 --> Total execution time: 0.2213
INFO - 2017-01-16 09:35:46 --> Config Class Initialized
INFO - 2017-01-16 09:35:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:46 --> URI Class Initialized
INFO - 2017-01-16 09:35:46 --> Router Class Initialized
INFO - 2017-01-16 09:35:46 --> Output Class Initialized
INFO - 2017-01-16 09:35:46 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:46 --> Input Class Initialized
INFO - 2017-01-16 09:35:46 --> Language Class Initialized
INFO - 2017-01-16 09:35:46 --> Loader Class Initialized
INFO - 2017-01-16 09:35:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:46 --> Controller Class Initialized
INFO - 2017-01-16 09:35:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:46 --> Total execution time: 0.0714
INFO - 2017-01-16 09:35:46 --> Config Class Initialized
INFO - 2017-01-16 09:35:46 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:46 --> Config Class Initialized
INFO - 2017-01-16 09:35:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:46 --> Utf8 Class Initialized
DEBUG - 2017-01-16 09:35:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:46 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:46 --> URI Class Initialized
INFO - 2017-01-16 09:35:46 --> URI Class Initialized
INFO - 2017-01-16 09:35:46 --> Router Class Initialized
INFO - 2017-01-16 09:35:46 --> Router Class Initialized
INFO - 2017-01-16 09:35:46 --> Output Class Initialized
INFO - 2017-01-16 09:35:46 --> Output Class Initialized
INFO - 2017-01-16 09:35:46 --> Security Class Initialized
INFO - 2017-01-16 09:35:46 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:46 --> Input Class Initialized
INFO - 2017-01-16 09:35:46 --> Language Class Initialized
DEBUG - 2017-01-16 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:46 --> Input Class Initialized
INFO - 2017-01-16 09:35:46 --> Loader Class Initialized
INFO - 2017-01-16 09:35:46 --> Language Class Initialized
INFO - 2017-01-16 09:35:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:46 --> Loader Class Initialized
INFO - 2017-01-16 09:35:46 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:46 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:46 --> Controller Class Initialized
INFO - 2017-01-16 09:35:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:46 --> Total execution time: 0.0678
INFO - 2017-01-16 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:46 --> Controller Class Initialized
INFO - 2017-01-16 09:35:46 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Model Class Initialized
INFO - 2017-01-16 09:35:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:46 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:46 --> Total execution time: 0.1787
INFO - 2017-01-16 09:35:48 --> Config Class Initialized
INFO - 2017-01-16 09:35:48 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:48 --> Config Class Initialized
INFO - 2017-01-16 09:35:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:48 --> URI Class Initialized
DEBUG - 2017-01-16 09:35:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:48 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:48 --> Router Class Initialized
INFO - 2017-01-16 09:35:48 --> URI Class Initialized
INFO - 2017-01-16 09:35:48 --> Output Class Initialized
INFO - 2017-01-16 09:35:48 --> Router Class Initialized
INFO - 2017-01-16 09:35:48 --> Security Class Initialized
INFO - 2017-01-16 09:35:48 --> Output Class Initialized
INFO - 2017-01-16 09:35:48 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:48 --> Input Class Initialized
DEBUG - 2017-01-16 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:48 --> Language Class Initialized
INFO - 2017-01-16 09:35:48 --> Input Class Initialized
INFO - 2017-01-16 09:35:48 --> Language Class Initialized
INFO - 2017-01-16 09:35:48 --> Loader Class Initialized
INFO - 2017-01-16 09:35:48 --> Loader Class Initialized
INFO - 2017-01-16 09:35:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:48 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:48 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:48 --> Controller Class Initialized
INFO - 2017-01-16 09:35:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:48 --> Model Class Initialized
INFO - 2017-01-16 09:35:48 --> Model Class Initialized
INFO - 2017-01-16 09:35:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:48 --> Total execution time: 0.1820
INFO - 2017-01-16 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:48 --> Controller Class Initialized
INFO - 2017-01-16 09:35:48 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:48 --> Model Class Initialized
INFO - 2017-01-16 09:35:48 --> Model Class Initialized
INFO - 2017-01-16 09:35:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:48 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:48 --> Total execution time: 0.2100
INFO - 2017-01-16 09:35:50 --> Config Class Initialized
INFO - 2017-01-16 09:35:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:50 --> Config Class Initialized
INFO - 2017-01-16 09:35:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:50 --> URI Class Initialized
INFO - 2017-01-16 09:35:50 --> Config Class Initialized
INFO - 2017-01-16 09:35:50 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:50 --> URI Class Initialized
INFO - 2017-01-16 09:35:50 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:50 --> Security Class Initialized
INFO - 2017-01-16 09:35:50 --> Router Class Initialized
INFO - 2017-01-16 09:35:50 --> URI Class Initialized
INFO - 2017-01-16 09:35:50 --> Output Class Initialized
INFO - 2017-01-16 09:35:50 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:50 --> Input Class Initialized
INFO - 2017-01-16 09:35:50 --> Security Class Initialized
INFO - 2017-01-16 09:35:50 --> Language Class Initialized
INFO - 2017-01-16 09:35:50 --> Output Class Initialized
DEBUG - 2017-01-16 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:50 --> Input Class Initialized
INFO - 2017-01-16 09:35:50 --> Language Class Initialized
INFO - 2017-01-16 09:35:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:50 --> Input Class Initialized
INFO - 2017-01-16 09:35:50 --> Language Class Initialized
INFO - 2017-01-16 09:35:50 --> Loader Class Initialized
INFO - 2017-01-16 09:35:50 --> Loader Class Initialized
INFO - 2017-01-16 09:35:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:50 --> Loader Class Initialized
INFO - 2017-01-16 09:35:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:50 --> Controller Class Initialized
INFO - 2017-01-16 09:35:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:50 --> Total execution time: 0.2175
INFO - 2017-01-16 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:50 --> Controller Class Initialized
INFO - 2017-01-16 09:35:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:50 --> Total execution time: 0.2365
INFO - 2017-01-16 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:50 --> Controller Class Initialized
INFO - 2017-01-16 09:35:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:50 --> Config Class Initialized
INFO - 2017-01-16 09:35:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:50 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:50 --> URI Class Initialized
INFO - 2017-01-16 09:35:50 --> Router Class Initialized
INFO - 2017-01-16 09:35:50 --> Output Class Initialized
INFO - 2017-01-16 09:35:50 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:50 --> Input Class Initialized
INFO - 2017-01-16 09:35:50 --> Language Class Initialized
INFO - 2017-01-16 09:35:50 --> Loader Class Initialized
INFO - 2017-01-16 09:35:50 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:50 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:50 --> Controller Class Initialized
INFO - 2017-01-16 09:35:50 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Model Class Initialized
INFO - 2017-01-16 09:35:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:35:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-01-16 09:35:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:35:50 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:50 --> Total execution time: 0.0660
INFO - 2017-01-16 09:35:56 --> Config Class Initialized
INFO - 2017-01-16 09:35:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:56 --> URI Class Initialized
INFO - 2017-01-16 09:35:56 --> Router Class Initialized
INFO - 2017-01-16 09:35:56 --> Output Class Initialized
INFO - 2017-01-16 09:35:56 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:56 --> Input Class Initialized
INFO - 2017-01-16 09:35:56 --> Language Class Initialized
INFO - 2017-01-16 09:35:56 --> Loader Class Initialized
INFO - 2017-01-16 09:35:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:56 --> Controller Class Initialized
INFO - 2017-01-16 09:35:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:56 --> Config Class Initialized
INFO - 2017-01-16 09:35:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:56 --> URI Class Initialized
INFO - 2017-01-16 09:35:56 --> Router Class Initialized
INFO - 2017-01-16 09:35:56 --> Output Class Initialized
INFO - 2017-01-16 09:35:56 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:56 --> Input Class Initialized
INFO - 2017-01-16 09:35:56 --> Language Class Initialized
INFO - 2017-01-16 09:35:56 --> Loader Class Initialized
INFO - 2017-01-16 09:35:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:56 --> Controller Class Initialized
INFO - 2017-01-16 09:35:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:35:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-01-16 09:35:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:35:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:56 --> Total execution time: 0.0875
INFO - 2017-01-16 09:35:56 --> Config Class Initialized
INFO - 2017-01-16 09:35:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:35:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:56 --> Config Class Initialized
INFO - 2017-01-16 09:35:56 --> URI Class Initialized
INFO - 2017-01-16 09:35:56 --> Hooks Class Initialized
INFO - 2017-01-16 09:35:56 --> Router Class Initialized
DEBUG - 2017-01-16 09:35:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:35:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:35:56 --> Output Class Initialized
INFO - 2017-01-16 09:35:56 --> URI Class Initialized
INFO - 2017-01-16 09:35:56 --> Security Class Initialized
DEBUG - 2017-01-16 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:56 --> Input Class Initialized
INFO - 2017-01-16 09:35:56 --> Router Class Initialized
INFO - 2017-01-16 09:35:56 --> Language Class Initialized
INFO - 2017-01-16 09:35:56 --> Output Class Initialized
INFO - 2017-01-16 09:35:56 --> Security Class Initialized
INFO - 2017-01-16 09:35:56 --> Loader Class Initialized
DEBUG - 2017-01-16 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:35:56 --> Input Class Initialized
INFO - 2017-01-16 09:35:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:56 --> Language Class Initialized
INFO - 2017-01-16 09:35:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:56 --> Loader Class Initialized
INFO - 2017-01-16 09:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:56 --> Controller Class Initialized
INFO - 2017-01-16 09:35:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:35:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:35:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:35:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:56 --> Total execution time: 0.0846
INFO - 2017-01-16 09:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:35:56 --> Controller Class Initialized
INFO - 2017-01-16 09:35:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Model Class Initialized
INFO - 2017-01-16 09:35:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:35:56 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-16 09:35:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-16 09:35:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:35:56 --> Total execution time: 0.1115
INFO - 2017-01-16 09:36:26 --> Config Class Initialized
INFO - 2017-01-16 09:36:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:36:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:36:26 --> Utf8 Class Initialized
INFO - 2017-01-16 09:36:26 --> URI Class Initialized
INFO - 2017-01-16 09:36:26 --> Router Class Initialized
INFO - 2017-01-16 09:36:26 --> Output Class Initialized
INFO - 2017-01-16 09:36:26 --> Security Class Initialized
DEBUG - 2017-01-16 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:36:26 --> Input Class Initialized
INFO - 2017-01-16 09:36:26 --> Language Class Initialized
INFO - 2017-01-16 09:36:26 --> Loader Class Initialized
INFO - 2017-01-16 09:36:26 --> Helper loaded: url_helper
INFO - 2017-01-16 09:36:26 --> Helper loaded: language_helper
INFO - 2017-01-16 09:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:36:26 --> Controller Class Initialized
INFO - 2017-01-16 09:36:26 --> Database Driver Class Initialized
INFO - 2017-01-16 09:36:26 --> Model Class Initialized
INFO - 2017-01-16 09:36:26 --> Model Class Initialized
INFO - 2017-01-16 09:36:26 --> Model Class Initialized
INFO - 2017-01-16 09:36:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:36:26 --> Final output sent to browser
DEBUG - 2017-01-16 09:36:26 --> Total execution time: 0.0574
INFO - 2017-01-16 09:36:55 --> Config Class Initialized
INFO - 2017-01-16 09:36:55 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:36:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:36:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:36:56 --> URI Class Initialized
INFO - 2017-01-16 09:36:56 --> Router Class Initialized
INFO - 2017-01-16 09:36:56 --> Output Class Initialized
INFO - 2017-01-16 09:36:56 --> Security Class Initialized
DEBUG - 2017-01-16 09:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:36:56 --> Input Class Initialized
INFO - 2017-01-16 09:36:56 --> Language Class Initialized
INFO - 2017-01-16 09:36:56 --> Loader Class Initialized
INFO - 2017-01-16 09:36:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:36:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:36:56 --> Controller Class Initialized
INFO - 2017-01-16 09:36:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:36:56 --> Model Class Initialized
INFO - 2017-01-16 09:36:56 --> Model Class Initialized
INFO - 2017-01-16 09:36:56 --> Model Class Initialized
INFO - 2017-01-16 09:36:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 09:36:56 --> Severity: Notice --> Undefined index: correct_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 175
ERROR - 2017-01-16 09:36:56 --> Severity: Notice --> Undefined index: incorrect_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 176
ERROR - 2017-01-16 09:36:56 --> Severity: Notice --> Undefined index: pass_percentage C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 193
INFO - 2017-01-16 09:36:56 --> Config Class Initialized
INFO - 2017-01-16 09:36:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:36:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:36:56 --> Utf8 Class Initialized
INFO - 2017-01-16 09:36:56 --> URI Class Initialized
INFO - 2017-01-16 09:36:56 --> Router Class Initialized
INFO - 2017-01-16 09:36:56 --> Output Class Initialized
INFO - 2017-01-16 09:36:56 --> Security Class Initialized
DEBUG - 2017-01-16 09:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:36:56 --> Input Class Initialized
INFO - 2017-01-16 09:36:56 --> Language Class Initialized
INFO - 2017-01-16 09:36:56 --> Loader Class Initialized
INFO - 2017-01-16 09:36:56 --> Helper loaded: url_helper
INFO - 2017-01-16 09:36:56 --> Helper loaded: language_helper
INFO - 2017-01-16 09:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:36:56 --> Controller Class Initialized
INFO - 2017-01-16 09:36:56 --> Database Driver Class Initialized
INFO - 2017-01-16 09:36:56 --> Model Class Initialized
INFO - 2017-01-16 09:36:56 --> Model Class Initialized
INFO - 2017-01-16 09:36:56 --> Model Class Initialized
INFO - 2017-01-16 09:36:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:36:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:36:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-16 09:36:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:36:56 --> Final output sent to browser
DEBUG - 2017-01-16 09:36:56 --> Total execution time: 0.0638
INFO - 2017-01-16 09:37:05 --> Config Class Initialized
INFO - 2017-01-16 09:37:05 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:05 --> URI Class Initialized
INFO - 2017-01-16 09:37:05 --> Router Class Initialized
INFO - 2017-01-16 09:37:05 --> Output Class Initialized
INFO - 2017-01-16 09:37:05 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:05 --> Input Class Initialized
INFO - 2017-01-16 09:37:05 --> Language Class Initialized
INFO - 2017-01-16 09:37:05 --> Loader Class Initialized
INFO - 2017-01-16 09:37:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:05 --> Controller Class Initialized
INFO - 2017-01-16 09:37:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:05 --> Model Class Initialized
INFO - 2017-01-16 09:37:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:05 --> Config Class Initialized
INFO - 2017-01-16 09:37:05 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:05 --> URI Class Initialized
INFO - 2017-01-16 09:37:05 --> Router Class Initialized
INFO - 2017-01-16 09:37:05 --> Output Class Initialized
INFO - 2017-01-16 09:37:05 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:05 --> Input Class Initialized
INFO - 2017-01-16 09:37:05 --> Language Class Initialized
INFO - 2017-01-16 09:37:05 --> Loader Class Initialized
INFO - 2017-01-16 09:37:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:05 --> Controller Class Initialized
INFO - 2017-01-16 09:37:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:05 --> Model Class Initialized
INFO - 2017-01-16 09:37:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-16 09:37:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-16 09:37:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-16 09:37:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:37:05 --> Total execution time: 0.0528
INFO - 2017-01-16 09:37:11 --> Config Class Initialized
INFO - 2017-01-16 09:37:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:11 --> URI Class Initialized
INFO - 2017-01-16 09:37:11 --> Router Class Initialized
INFO - 2017-01-16 09:37:11 --> Output Class Initialized
INFO - 2017-01-16 09:37:11 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:11 --> Input Class Initialized
INFO - 2017-01-16 09:37:11 --> Language Class Initialized
INFO - 2017-01-16 09:37:11 --> Loader Class Initialized
INFO - 2017-01-16 09:37:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:11 --> Controller Class Initialized
INFO - 2017-01-16 09:37:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:11 --> Model Class Initialized
INFO - 2017-01-16 09:37:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:11 --> Config Class Initialized
INFO - 2017-01-16 09:37:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:11 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:11 --> URI Class Initialized
INFO - 2017-01-16 09:37:11 --> Router Class Initialized
INFO - 2017-01-16 09:37:11 --> Output Class Initialized
INFO - 2017-01-16 09:37:11 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:11 --> Input Class Initialized
INFO - 2017-01-16 09:37:11 --> Language Class Initialized
INFO - 2017-01-16 09:37:11 --> Loader Class Initialized
INFO - 2017-01-16 09:37:11 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:11 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:11 --> Controller Class Initialized
INFO - 2017-01-16 09:37:11 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:11 --> Model Class Initialized
INFO - 2017-01-16 09:37:11 --> Model Class Initialized
INFO - 2017-01-16 09:37:11 --> Model Class Initialized
INFO - 2017-01-16 09:37:11 --> Model Class Initialized
INFO - 2017-01-16 09:37:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:37:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-16 09:37:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:37:11 --> Final output sent to browser
DEBUG - 2017-01-16 09:37:11 --> Total execution time: 0.0673
INFO - 2017-01-16 09:37:14 --> Config Class Initialized
INFO - 2017-01-16 09:37:14 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:14 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:14 --> URI Class Initialized
INFO - 2017-01-16 09:37:14 --> Router Class Initialized
INFO - 2017-01-16 09:37:14 --> Output Class Initialized
INFO - 2017-01-16 09:37:14 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:14 --> Input Class Initialized
INFO - 2017-01-16 09:37:14 --> Language Class Initialized
INFO - 2017-01-16 09:37:14 --> Loader Class Initialized
INFO - 2017-01-16 09:37:14 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:14 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:14 --> Controller Class Initialized
INFO - 2017-01-16 09:37:14 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:14 --> Model Class Initialized
INFO - 2017-01-16 09:37:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:14 --> Helper loaded: form_helper
INFO - 2017-01-16 09:37:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:37:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:37:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:37:14 --> Final output sent to browser
DEBUG - 2017-01-16 09:37:14 --> Total execution time: 0.0635
INFO - 2017-01-16 09:37:16 --> Config Class Initialized
INFO - 2017-01-16 09:37:16 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:16 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:16 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:16 --> URI Class Initialized
INFO - 2017-01-16 09:37:16 --> Router Class Initialized
INFO - 2017-01-16 09:37:16 --> Output Class Initialized
INFO - 2017-01-16 09:37:16 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:16 --> Input Class Initialized
INFO - 2017-01-16 09:37:16 --> Language Class Initialized
INFO - 2017-01-16 09:37:16 --> Loader Class Initialized
INFO - 2017-01-16 09:37:16 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:16 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:16 --> Controller Class Initialized
INFO - 2017-01-16 09:37:16 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:16 --> Model Class Initialized
INFO - 2017-01-16 09:37:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:16 --> Model Class Initialized
INFO - 2017-01-16 09:37:16 --> Model Class Initialized
INFO - 2017-01-16 09:37:16 --> Helper loaded: form_helper
INFO - 2017-01-16 09:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 09:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:37:16 --> Final output sent to browser
DEBUG - 2017-01-16 09:37:16 --> Total execution time: 0.1061
INFO - 2017-01-16 09:37:33 --> Config Class Initialized
INFO - 2017-01-16 09:37:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:37:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:37:33 --> Utf8 Class Initialized
INFO - 2017-01-16 09:37:33 --> URI Class Initialized
INFO - 2017-01-16 09:37:33 --> Router Class Initialized
INFO - 2017-01-16 09:37:33 --> Output Class Initialized
INFO - 2017-01-16 09:37:33 --> Security Class Initialized
DEBUG - 2017-01-16 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:37:33 --> Input Class Initialized
INFO - 2017-01-16 09:37:33 --> Language Class Initialized
INFO - 2017-01-16 09:37:33 --> Loader Class Initialized
INFO - 2017-01-16 09:37:33 --> Helper loaded: url_helper
INFO - 2017-01-16 09:37:33 --> Helper loaded: language_helper
INFO - 2017-01-16 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:37:33 --> Controller Class Initialized
INFO - 2017-01-16 09:37:33 --> Database Driver Class Initialized
INFO - 2017-01-16 09:37:33 --> Model Class Initialized
INFO - 2017-01-16 09:37:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:37:33 --> Helper loaded: form_helper
INFO - 2017-01-16 09:37:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:37:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:37:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:37:33 --> Final output sent to browser
DEBUG - 2017-01-16 09:37:33 --> Total execution time: 0.0639
INFO - 2017-01-16 09:38:23 --> Config Class Initialized
INFO - 2017-01-16 09:38:23 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:38:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:38:23 --> Utf8 Class Initialized
INFO - 2017-01-16 09:38:23 --> URI Class Initialized
INFO - 2017-01-16 09:38:23 --> Router Class Initialized
INFO - 2017-01-16 09:38:23 --> Output Class Initialized
INFO - 2017-01-16 09:38:23 --> Security Class Initialized
DEBUG - 2017-01-16 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:38:23 --> Input Class Initialized
INFO - 2017-01-16 09:38:23 --> Language Class Initialized
INFO - 2017-01-16 09:38:23 --> Loader Class Initialized
INFO - 2017-01-16 09:38:23 --> Helper loaded: url_helper
INFO - 2017-01-16 09:38:23 --> Helper loaded: language_helper
INFO - 2017-01-16 09:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:38:23 --> Controller Class Initialized
INFO - 2017-01-16 09:38:23 --> Database Driver Class Initialized
INFO - 2017-01-16 09:38:23 --> Model Class Initialized
INFO - 2017-01-16 09:38:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:38:23 --> Helper loaded: form_helper
ERROR - 2017-01-16 09:38:23 --> Could not find the language line "result_tpu_tpa"
INFO - 2017-01-16 09:38:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:38:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:38:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:38:23 --> Final output sent to browser
DEBUG - 2017-01-16 09:38:23 --> Total execution time: 0.0727
INFO - 2017-01-16 09:38:39 --> Config Class Initialized
INFO - 2017-01-16 09:38:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:38:39 --> Utf8 Class Initialized
INFO - 2017-01-16 09:38:39 --> URI Class Initialized
INFO - 2017-01-16 09:38:39 --> Router Class Initialized
INFO - 2017-01-16 09:38:39 --> Output Class Initialized
INFO - 2017-01-16 09:38:39 --> Security Class Initialized
DEBUG - 2017-01-16 09:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:38:39 --> Input Class Initialized
INFO - 2017-01-16 09:38:39 --> Language Class Initialized
INFO - 2017-01-16 09:38:39 --> Loader Class Initialized
INFO - 2017-01-16 09:38:39 --> Helper loaded: url_helper
INFO - 2017-01-16 09:38:39 --> Helper loaded: language_helper
INFO - 2017-01-16 09:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:38:39 --> Controller Class Initialized
INFO - 2017-01-16 09:38:39 --> Database Driver Class Initialized
INFO - 2017-01-16 09:38:39 --> Model Class Initialized
INFO - 2017-01-16 09:38:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:38:39 --> Helper loaded: form_helper
INFO - 2017-01-16 09:38:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:38:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:38:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:38:39 --> Final output sent to browser
DEBUG - 2017-01-16 09:38:39 --> Total execution time: 0.0699
INFO - 2017-01-16 09:38:52 --> Config Class Initialized
INFO - 2017-01-16 09:38:52 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:38:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:38:52 --> Utf8 Class Initialized
INFO - 2017-01-16 09:38:52 --> URI Class Initialized
INFO - 2017-01-16 09:38:52 --> Router Class Initialized
INFO - 2017-01-16 09:38:52 --> Output Class Initialized
INFO - 2017-01-16 09:38:52 --> Security Class Initialized
DEBUG - 2017-01-16 09:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:38:52 --> Input Class Initialized
INFO - 2017-01-16 09:38:52 --> Language Class Initialized
INFO - 2017-01-16 09:38:52 --> Loader Class Initialized
INFO - 2017-01-16 09:38:52 --> Helper loaded: url_helper
INFO - 2017-01-16 09:38:52 --> Helper loaded: language_helper
INFO - 2017-01-16 09:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:38:52 --> Controller Class Initialized
INFO - 2017-01-16 09:38:52 --> Database Driver Class Initialized
INFO - 2017-01-16 09:38:52 --> Model Class Initialized
INFO - 2017-01-16 09:38:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:38:52 --> Helper loaded: form_helper
INFO - 2017-01-16 09:38:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:38:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:38:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:38:52 --> Final output sent to browser
DEBUG - 2017-01-16 09:38:52 --> Total execution time: 0.0674
INFO - 2017-01-16 09:43:05 --> Config Class Initialized
INFO - 2017-01-16 09:43:05 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:43:05 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:43:05 --> Utf8 Class Initialized
INFO - 2017-01-16 09:43:05 --> URI Class Initialized
INFO - 2017-01-16 09:43:05 --> Router Class Initialized
INFO - 2017-01-16 09:43:05 --> Output Class Initialized
INFO - 2017-01-16 09:43:05 --> Security Class Initialized
DEBUG - 2017-01-16 09:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:43:05 --> Input Class Initialized
INFO - 2017-01-16 09:43:05 --> Language Class Initialized
INFO - 2017-01-16 09:43:05 --> Loader Class Initialized
INFO - 2017-01-16 09:43:05 --> Helper loaded: url_helper
INFO - 2017-01-16 09:43:05 --> Helper loaded: language_helper
INFO - 2017-01-16 09:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:43:05 --> Controller Class Initialized
INFO - 2017-01-16 09:43:05 --> Database Driver Class Initialized
INFO - 2017-01-16 09:43:05 --> Model Class Initialized
INFO - 2017-01-16 09:43:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:43:05 --> Model Class Initialized
INFO - 2017-01-16 09:43:05 --> Model Class Initialized
INFO - 2017-01-16 09:43:05 --> Helper loaded: form_helper
INFO - 2017-01-16 09:43:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:43:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 09:43:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:43:05 --> Final output sent to browser
DEBUG - 2017-01-16 09:43:05 --> Total execution time: 0.0968
INFO - 2017-01-16 09:43:19 --> Config Class Initialized
INFO - 2017-01-16 09:43:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:43:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:43:19 --> Utf8 Class Initialized
INFO - 2017-01-16 09:43:19 --> URI Class Initialized
INFO - 2017-01-16 09:43:19 --> Router Class Initialized
INFO - 2017-01-16 09:43:19 --> Output Class Initialized
INFO - 2017-01-16 09:43:19 --> Security Class Initialized
DEBUG - 2017-01-16 09:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:43:19 --> Input Class Initialized
INFO - 2017-01-16 09:43:19 --> Language Class Initialized
INFO - 2017-01-16 09:43:19 --> Loader Class Initialized
INFO - 2017-01-16 09:43:19 --> Helper loaded: url_helper
INFO - 2017-01-16 09:43:19 --> Helper loaded: language_helper
INFO - 2017-01-16 09:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:43:19 --> Controller Class Initialized
INFO - 2017-01-16 09:43:19 --> Database Driver Class Initialized
INFO - 2017-01-16 09:43:19 --> Model Class Initialized
INFO - 2017-01-16 09:43:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:43:19 --> Helper loaded: form_helper
INFO - 2017-01-16 09:43:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:43:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:43:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:43:19 --> Final output sent to browser
DEBUG - 2017-01-16 09:43:19 --> Total execution time: 0.0613
INFO - 2017-01-16 09:43:55 --> Config Class Initialized
INFO - 2017-01-16 09:43:55 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:43:55 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:43:55 --> Utf8 Class Initialized
INFO - 2017-01-16 09:43:55 --> URI Class Initialized
INFO - 2017-01-16 09:43:55 --> Router Class Initialized
INFO - 2017-01-16 09:43:55 --> Output Class Initialized
INFO - 2017-01-16 09:43:55 --> Security Class Initialized
DEBUG - 2017-01-16 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:43:55 --> Input Class Initialized
INFO - 2017-01-16 09:43:55 --> Language Class Initialized
INFO - 2017-01-16 09:43:55 --> Loader Class Initialized
INFO - 2017-01-16 09:43:55 --> Helper loaded: url_helper
INFO - 2017-01-16 09:43:55 --> Helper loaded: language_helper
INFO - 2017-01-16 09:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:43:55 --> Controller Class Initialized
INFO - 2017-01-16 09:43:55 --> Database Driver Class Initialized
INFO - 2017-01-16 09:43:55 --> Model Class Initialized
INFO - 2017-01-16 09:43:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:43:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:43:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\category_list.php
INFO - 2017-01-16 09:43:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:43:55 --> Final output sent to browser
DEBUG - 2017-01-16 09:43:55 --> Total execution time: 0.0620
INFO - 2017-01-16 09:44:03 --> Config Class Initialized
INFO - 2017-01-16 09:44:03 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:44:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:44:03 --> Utf8 Class Initialized
INFO - 2017-01-16 09:44:03 --> URI Class Initialized
INFO - 2017-01-16 09:44:03 --> Router Class Initialized
INFO - 2017-01-16 09:44:03 --> Output Class Initialized
INFO - 2017-01-16 09:44:03 --> Security Class Initialized
DEBUG - 2017-01-16 09:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:44:03 --> Input Class Initialized
INFO - 2017-01-16 09:44:03 --> Language Class Initialized
INFO - 2017-01-16 09:44:03 --> Loader Class Initialized
INFO - 2017-01-16 09:44:03 --> Helper loaded: url_helper
INFO - 2017-01-16 09:44:03 --> Helper loaded: language_helper
INFO - 2017-01-16 09:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:44:03 --> Controller Class Initialized
INFO - 2017-01-16 09:44:03 --> Database Driver Class Initialized
INFO - 2017-01-16 09:44:03 --> Model Class Initialized
INFO - 2017-01-16 09:44:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:44:03 --> Helper loaded: form_helper
INFO - 2017-01-16 09:44:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:44:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:44:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:44:03 --> Final output sent to browser
DEBUG - 2017-01-16 09:44:03 --> Total execution time: 0.0655
INFO - 2017-01-16 09:50:36 --> Config Class Initialized
INFO - 2017-01-16 09:50:36 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:50:36 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:50:36 --> Utf8 Class Initialized
INFO - 2017-01-16 09:50:36 --> URI Class Initialized
INFO - 2017-01-16 09:50:36 --> Router Class Initialized
INFO - 2017-01-16 09:50:36 --> Output Class Initialized
INFO - 2017-01-16 09:50:36 --> Security Class Initialized
DEBUG - 2017-01-16 09:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:50:36 --> Input Class Initialized
INFO - 2017-01-16 09:50:36 --> Language Class Initialized
INFO - 2017-01-16 09:50:36 --> Loader Class Initialized
INFO - 2017-01-16 09:50:36 --> Helper loaded: url_helper
INFO - 2017-01-16 09:50:36 --> Helper loaded: language_helper
INFO - 2017-01-16 09:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:50:36 --> Controller Class Initialized
INFO - 2017-01-16 09:50:36 --> Database Driver Class Initialized
INFO - 2017-01-16 09:50:36 --> Model Class Initialized
INFO - 2017-01-16 09:50:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:50:36 --> Helper loaded: form_helper
INFO - 2017-01-16 09:50:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:50:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:50:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:50:36 --> Final output sent to browser
DEBUG - 2017-01-16 09:50:36 --> Total execution time: 0.0706
INFO - 2017-01-16 09:56:29 --> Config Class Initialized
INFO - 2017-01-16 09:56:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:56:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:56:29 --> Utf8 Class Initialized
INFO - 2017-01-16 09:56:29 --> URI Class Initialized
INFO - 2017-01-16 09:56:29 --> Router Class Initialized
INFO - 2017-01-16 09:56:29 --> Output Class Initialized
INFO - 2017-01-16 09:56:29 --> Security Class Initialized
DEBUG - 2017-01-16 09:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:56:29 --> Input Class Initialized
INFO - 2017-01-16 09:56:29 --> Language Class Initialized
INFO - 2017-01-16 09:56:29 --> Loader Class Initialized
INFO - 2017-01-16 09:56:29 --> Helper loaded: url_helper
INFO - 2017-01-16 09:56:29 --> Helper loaded: language_helper
INFO - 2017-01-16 09:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:56:29 --> Controller Class Initialized
INFO - 2017-01-16 09:56:29 --> Database Driver Class Initialized
INFO - 2017-01-16 09:56:29 --> Model Class Initialized
INFO - 2017-01-16 09:56:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:56:29 --> Helper loaded: form_helper
ERROR - 2017-01-16 09:56:29 --> Query error: Unknown column 'group' in 'where clause' - Invalid query: SELECT *
FROM `quizto`.`category`
WHERE `group` = '1'
ORDER BY `cid` ASC
INFO - 2017-01-16 09:56:29 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-16 09:56:49 --> Config Class Initialized
INFO - 2017-01-16 09:56:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:56:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:56:49 --> Utf8 Class Initialized
INFO - 2017-01-16 09:56:49 --> URI Class Initialized
INFO - 2017-01-16 09:56:49 --> Router Class Initialized
INFO - 2017-01-16 09:56:49 --> Output Class Initialized
INFO - 2017-01-16 09:56:49 --> Security Class Initialized
DEBUG - 2017-01-16 09:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:56:49 --> Input Class Initialized
INFO - 2017-01-16 09:56:49 --> Language Class Initialized
INFO - 2017-01-16 09:56:49 --> Loader Class Initialized
INFO - 2017-01-16 09:56:49 --> Helper loaded: url_helper
INFO - 2017-01-16 09:56:49 --> Helper loaded: language_helper
INFO - 2017-01-16 09:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:56:49 --> Controller Class Initialized
INFO - 2017-01-16 09:56:49 --> Database Driver Class Initialized
INFO - 2017-01-16 09:56:49 --> Model Class Initialized
INFO - 2017-01-16 09:56:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:56:49 --> Helper loaded: form_helper
INFO - 2017-01-16 09:56:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:56:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 09:56:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:56:49 --> Final output sent to browser
DEBUG - 2017-01-16 09:56:49 --> Total execution time: 0.0683
INFO - 2017-01-16 09:56:53 --> Config Class Initialized
INFO - 2017-01-16 09:56:53 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:56:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:56:53 --> Utf8 Class Initialized
INFO - 2017-01-16 09:56:53 --> URI Class Initialized
INFO - 2017-01-16 09:56:53 --> Router Class Initialized
INFO - 2017-01-16 09:56:53 --> Output Class Initialized
INFO - 2017-01-16 09:56:53 --> Security Class Initialized
DEBUG - 2017-01-16 09:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:56:53 --> Input Class Initialized
INFO - 2017-01-16 09:56:53 --> Language Class Initialized
INFO - 2017-01-16 09:56:53 --> Loader Class Initialized
INFO - 2017-01-16 09:56:53 --> Helper loaded: url_helper
INFO - 2017-01-16 09:56:53 --> Helper loaded: language_helper
INFO - 2017-01-16 09:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:56:53 --> Controller Class Initialized
INFO - 2017-01-16 09:56:53 --> Database Driver Class Initialized
INFO - 2017-01-16 09:56:53 --> Model Class Initialized
INFO - 2017-01-16 09:56:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:56:53 --> Model Class Initialized
INFO - 2017-01-16 09:56:53 --> Model Class Initialized
INFO - 2017-01-16 09:56:53 --> Helper loaded: form_helper
INFO - 2017-01-16 09:56:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:56:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 09:56:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:56:53 --> Final output sent to browser
DEBUG - 2017-01-16 09:56:53 --> Total execution time: 0.0852
INFO - 2017-01-16 09:57:17 --> Config Class Initialized
INFO - 2017-01-16 09:57:17 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:57:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:57:17 --> Utf8 Class Initialized
INFO - 2017-01-16 09:57:17 --> URI Class Initialized
INFO - 2017-01-16 09:57:17 --> Router Class Initialized
INFO - 2017-01-16 09:57:17 --> Output Class Initialized
INFO - 2017-01-16 09:57:17 --> Security Class Initialized
DEBUG - 2017-01-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:57:17 --> Input Class Initialized
INFO - 2017-01-16 09:57:17 --> Language Class Initialized
INFO - 2017-01-16 09:57:17 --> Loader Class Initialized
INFO - 2017-01-16 09:57:17 --> Helper loaded: url_helper
INFO - 2017-01-16 09:57:17 --> Helper loaded: language_helper
INFO - 2017-01-16 09:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:57:17 --> Controller Class Initialized
INFO - 2017-01-16 09:57:17 --> Database Driver Class Initialized
INFO - 2017-01-16 09:57:17 --> Model Class Initialized
INFO - 2017-01-16 09:57:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:57:17 --> Model Class Initialized
INFO - 2017-01-16 09:57:17 --> Model Class Initialized
INFO - 2017-01-16 09:57:17 --> Helper loaded: form_helper
INFO - 2017-01-16 09:57:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:57:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 09:57:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:57:17 --> Final output sent to browser
DEBUG - 2017-01-16 09:57:17 --> Total execution time: 0.0902
INFO - 2017-01-16 09:58:47 --> Config Class Initialized
INFO - 2017-01-16 09:58:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 09:58:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 09:58:47 --> Utf8 Class Initialized
INFO - 2017-01-16 09:58:47 --> URI Class Initialized
INFO - 2017-01-16 09:58:47 --> Router Class Initialized
INFO - 2017-01-16 09:58:47 --> Output Class Initialized
INFO - 2017-01-16 09:58:47 --> Security Class Initialized
DEBUG - 2017-01-16 09:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 09:58:47 --> Input Class Initialized
INFO - 2017-01-16 09:58:47 --> Language Class Initialized
INFO - 2017-01-16 09:58:47 --> Loader Class Initialized
INFO - 2017-01-16 09:58:47 --> Helper loaded: url_helper
INFO - 2017-01-16 09:58:47 --> Helper loaded: language_helper
INFO - 2017-01-16 09:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 09:58:47 --> Controller Class Initialized
INFO - 2017-01-16 09:58:47 --> Database Driver Class Initialized
INFO - 2017-01-16 09:58:47 --> Model Class Initialized
INFO - 2017-01-16 09:58:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 09:58:47 --> Model Class Initialized
INFO - 2017-01-16 09:58:47 --> Model Class Initialized
INFO - 2017-01-16 09:58:47 --> Helper loaded: form_helper
INFO - 2017-01-16 09:58:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 09:58:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 09:58:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 09:58:47 --> Final output sent to browser
DEBUG - 2017-01-16 09:58:47 --> Total execution time: 0.0920
INFO - 2017-01-16 10:05:47 --> Config Class Initialized
INFO - 2017-01-16 10:05:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:05:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:05:47 --> Utf8 Class Initialized
INFO - 2017-01-16 10:05:47 --> URI Class Initialized
INFO - 2017-01-16 10:05:47 --> Router Class Initialized
INFO - 2017-01-16 10:05:47 --> Output Class Initialized
INFO - 2017-01-16 10:05:47 --> Security Class Initialized
DEBUG - 2017-01-16 10:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:05:47 --> Input Class Initialized
INFO - 2017-01-16 10:05:47 --> Language Class Initialized
INFO - 2017-01-16 10:05:47 --> Loader Class Initialized
INFO - 2017-01-16 10:05:47 --> Helper loaded: url_helper
INFO - 2017-01-16 10:05:47 --> Helper loaded: language_helper
INFO - 2017-01-16 10:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:05:47 --> Controller Class Initialized
INFO - 2017-01-16 10:05:47 --> Database Driver Class Initialized
INFO - 2017-01-16 10:05:47 --> Model Class Initialized
INFO - 2017-01-16 10:05:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:05:48 --> Model Class Initialized
INFO - 2017-01-16 10:05:48 --> Model Class Initialized
INFO - 2017-01-16 10:05:48 --> Helper loaded: form_helper
INFO - 2017-01-16 10:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 10:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:05:48 --> Final output sent to browser
DEBUG - 2017-01-16 10:05:48 --> Total execution time: 0.1074
INFO - 2017-01-16 10:06:43 --> Config Class Initialized
INFO - 2017-01-16 10:06:43 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:06:43 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:06:43 --> Utf8 Class Initialized
INFO - 2017-01-16 10:06:43 --> URI Class Initialized
INFO - 2017-01-16 10:06:43 --> Router Class Initialized
INFO - 2017-01-16 10:06:43 --> Output Class Initialized
INFO - 2017-01-16 10:06:43 --> Security Class Initialized
DEBUG - 2017-01-16 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:06:43 --> Input Class Initialized
INFO - 2017-01-16 10:06:43 --> Language Class Initialized
INFO - 2017-01-16 10:06:43 --> Loader Class Initialized
INFO - 2017-01-16 10:06:43 --> Helper loaded: url_helper
INFO - 2017-01-16 10:06:43 --> Helper loaded: language_helper
INFO - 2017-01-16 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:06:43 --> Controller Class Initialized
INFO - 2017-01-16 10:06:43 --> Database Driver Class Initialized
INFO - 2017-01-16 10:06:43 --> Model Class Initialized
INFO - 2017-01-16 10:06:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:06:43 --> Model Class Initialized
INFO - 2017-01-16 10:06:43 --> Model Class Initialized
INFO - 2017-01-16 10:06:43 --> Helper loaded: form_helper
INFO - 2017-01-16 10:06:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:06:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 10:06:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:06:43 --> Final output sent to browser
DEBUG - 2017-01-16 10:06:43 --> Total execution time: 0.0986
INFO - 2017-01-16 10:07:17 --> Config Class Initialized
INFO - 2017-01-16 10:07:17 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:07:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:07:17 --> Utf8 Class Initialized
INFO - 2017-01-16 10:07:17 --> URI Class Initialized
INFO - 2017-01-16 10:07:17 --> Router Class Initialized
INFO - 2017-01-16 10:07:17 --> Output Class Initialized
INFO - 2017-01-16 10:07:17 --> Security Class Initialized
DEBUG - 2017-01-16 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:07:17 --> Input Class Initialized
INFO - 2017-01-16 10:07:17 --> Language Class Initialized
INFO - 2017-01-16 10:07:17 --> Loader Class Initialized
INFO - 2017-01-16 10:07:17 --> Helper loaded: url_helper
INFO - 2017-01-16 10:07:17 --> Helper loaded: language_helper
INFO - 2017-01-16 10:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:07:17 --> Controller Class Initialized
INFO - 2017-01-16 10:07:17 --> Database Driver Class Initialized
INFO - 2017-01-16 10:07:17 --> Model Class Initialized
INFO - 2017-01-16 10:07:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:07:17 --> Model Class Initialized
INFO - 2017-01-16 10:07:17 --> Model Class Initialized
INFO - 2017-01-16 10:07:17 --> Helper loaded: form_helper
INFO - 2017-01-16 10:07:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:07:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 10:07:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:07:17 --> Final output sent to browser
DEBUG - 2017-01-16 10:07:17 --> Total execution time: 0.0906
INFO - 2017-01-16 10:13:44 --> Config Class Initialized
INFO - 2017-01-16 10:13:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:13:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:13:44 --> Utf8 Class Initialized
INFO - 2017-01-16 10:13:44 --> URI Class Initialized
INFO - 2017-01-16 10:13:44 --> Router Class Initialized
INFO - 2017-01-16 10:13:44 --> Output Class Initialized
INFO - 2017-01-16 10:13:44 --> Security Class Initialized
DEBUG - 2017-01-16 10:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:13:44 --> Input Class Initialized
INFO - 2017-01-16 10:13:44 --> Language Class Initialized
INFO - 2017-01-16 10:13:44 --> Loader Class Initialized
INFO - 2017-01-16 10:13:44 --> Helper loaded: url_helper
INFO - 2017-01-16 10:13:44 --> Helper loaded: language_helper
INFO - 2017-01-16 10:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:13:44 --> Controller Class Initialized
INFO - 2017-01-16 10:13:44 --> Database Driver Class Initialized
INFO - 2017-01-16 10:13:44 --> Model Class Initialized
INFO - 2017-01-16 10:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:13:44 --> Model Class Initialized
INFO - 2017-01-16 10:13:44 --> Model Class Initialized
INFO - 2017-01-16 10:13:44 --> Helper loaded: form_helper
INFO - 2017-01-16 10:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 10:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:13:44 --> Final output sent to browser
DEBUG - 2017-01-16 10:13:44 --> Total execution time: 0.0888
INFO - 2017-01-16 10:16:10 --> Config Class Initialized
INFO - 2017-01-16 10:16:10 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:16:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:16:10 --> Utf8 Class Initialized
INFO - 2017-01-16 10:16:10 --> URI Class Initialized
INFO - 2017-01-16 10:16:10 --> Router Class Initialized
INFO - 2017-01-16 10:16:10 --> Output Class Initialized
INFO - 2017-01-16 10:16:10 --> Security Class Initialized
DEBUG - 2017-01-16 10:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:16:10 --> Input Class Initialized
INFO - 2017-01-16 10:16:10 --> Language Class Initialized
INFO - 2017-01-16 10:16:10 --> Loader Class Initialized
INFO - 2017-01-16 10:16:10 --> Helper loaded: url_helper
INFO - 2017-01-16 10:16:10 --> Helper loaded: language_helper
INFO - 2017-01-16 10:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:16:10 --> Controller Class Initialized
INFO - 2017-01-16 10:16:10 --> Database Driver Class Initialized
INFO - 2017-01-16 10:16:10 --> Model Class Initialized
INFO - 2017-01-16 10:16:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:16:10 --> Helper loaded: form_helper
INFO - 2017-01-16 10:16:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:16:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 10:16:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:16:10 --> Final output sent to browser
DEBUG - 2017-01-16 10:16:10 --> Total execution time: 0.0675
INFO - 2017-01-16 10:16:12 --> Config Class Initialized
INFO - 2017-01-16 10:16:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:16:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:16:12 --> Utf8 Class Initialized
INFO - 2017-01-16 10:16:12 --> URI Class Initialized
INFO - 2017-01-16 10:16:12 --> Router Class Initialized
INFO - 2017-01-16 10:16:12 --> Output Class Initialized
INFO - 2017-01-16 10:16:12 --> Security Class Initialized
DEBUG - 2017-01-16 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:16:12 --> Input Class Initialized
INFO - 2017-01-16 10:16:12 --> Language Class Initialized
INFO - 2017-01-16 10:16:12 --> Loader Class Initialized
INFO - 2017-01-16 10:16:12 --> Helper loaded: url_helper
INFO - 2017-01-16 10:16:12 --> Helper loaded: language_helper
INFO - 2017-01-16 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:16:12 --> Controller Class Initialized
INFO - 2017-01-16 10:16:12 --> Database Driver Class Initialized
INFO - 2017-01-16 10:16:12 --> Model Class Initialized
INFO - 2017-01-16 10:16:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:16:12 --> Model Class Initialized
INFO - 2017-01-16 10:16:12 --> Model Class Initialized
INFO - 2017-01-16 10:16:12 --> Helper loaded: form_helper
INFO - 2017-01-16 10:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 10:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:16:12 --> Final output sent to browser
DEBUG - 2017-01-16 10:16:12 --> Total execution time: 0.1116
INFO - 2017-01-16 10:16:18 --> Config Class Initialized
INFO - 2017-01-16 10:16:18 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:16:18 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:16:18 --> Utf8 Class Initialized
INFO - 2017-01-16 10:16:18 --> URI Class Initialized
INFO - 2017-01-16 10:16:18 --> Router Class Initialized
INFO - 2017-01-16 10:16:18 --> Output Class Initialized
INFO - 2017-01-16 10:16:18 --> Security Class Initialized
DEBUG - 2017-01-16 10:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:16:18 --> Input Class Initialized
INFO - 2017-01-16 10:16:18 --> Language Class Initialized
INFO - 2017-01-16 10:16:18 --> Loader Class Initialized
INFO - 2017-01-16 10:16:18 --> Helper loaded: url_helper
INFO - 2017-01-16 10:16:18 --> Helper loaded: language_helper
INFO - 2017-01-16 10:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:16:18 --> Controller Class Initialized
INFO - 2017-01-16 10:16:18 --> Database Driver Class Initialized
INFO - 2017-01-16 10:16:18 --> Model Class Initialized
INFO - 2017-01-16 10:16:18 --> Model Class Initialized
INFO - 2017-01-16 10:16:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-16 10:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:16:18 --> Final output sent to browser
DEBUG - 2017-01-16 10:16:18 --> Total execution time: 0.0712
INFO - 2017-01-16 10:16:23 --> Config Class Initialized
INFO - 2017-01-16 10:16:23 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:16:23 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:16:23 --> Utf8 Class Initialized
INFO - 2017-01-16 10:16:23 --> URI Class Initialized
INFO - 2017-01-16 10:16:23 --> Router Class Initialized
INFO - 2017-01-16 10:16:23 --> Output Class Initialized
INFO - 2017-01-16 10:16:23 --> Security Class Initialized
DEBUG - 2017-01-16 10:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:16:23 --> Input Class Initialized
INFO - 2017-01-16 10:16:23 --> Language Class Initialized
INFO - 2017-01-16 10:16:23 --> Loader Class Initialized
INFO - 2017-01-16 10:16:23 --> Helper loaded: url_helper
INFO - 2017-01-16 10:16:23 --> Helper loaded: language_helper
INFO - 2017-01-16 10:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:16:23 --> Controller Class Initialized
INFO - 2017-01-16 10:16:23 --> Database Driver Class Initialized
INFO - 2017-01-16 10:16:23 --> Model Class Initialized
INFO - 2017-01-16 10:16:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:16:23 --> Helper loaded: form_helper
INFO - 2017-01-16 10:16:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:16:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-16 10:16:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:16:23 --> Final output sent to browser
DEBUG - 2017-01-16 10:16:23 --> Total execution time: 0.0708
INFO - 2017-01-16 10:16:27 --> Config Class Initialized
INFO - 2017-01-16 10:16:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:16:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:16:27 --> Utf8 Class Initialized
INFO - 2017-01-16 10:16:27 --> URI Class Initialized
INFO - 2017-01-16 10:16:27 --> Router Class Initialized
INFO - 2017-01-16 10:16:27 --> Output Class Initialized
INFO - 2017-01-16 10:16:27 --> Security Class Initialized
DEBUG - 2017-01-16 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:16:27 --> Input Class Initialized
INFO - 2017-01-16 10:16:27 --> Language Class Initialized
INFO - 2017-01-16 10:16:27 --> Loader Class Initialized
INFO - 2017-01-16 10:16:27 --> Helper loaded: url_helper
INFO - 2017-01-16 10:16:27 --> Helper loaded: language_helper
INFO - 2017-01-16 10:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:16:27 --> Controller Class Initialized
INFO - 2017-01-16 10:16:27 --> Database Driver Class Initialized
INFO - 2017-01-16 10:16:27 --> Model Class Initialized
INFO - 2017-01-16 10:16:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:16:27 --> Helper loaded: form_helper
INFO - 2017-01-16 10:16:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 10:16:27 --> Could not find the language line "import_user"
INFO - 2017-01-16 10:16:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-16 10:16:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:16:27 --> Final output sent to browser
DEBUG - 2017-01-16 10:16:27 --> Total execution time: 0.0671
INFO - 2017-01-16 10:17:39 --> Config Class Initialized
INFO - 2017-01-16 10:17:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:17:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:17:39 --> Utf8 Class Initialized
INFO - 2017-01-16 10:17:39 --> URI Class Initialized
DEBUG - 2017-01-16 10:17:39 --> No URI present. Default controller set.
INFO - 2017-01-16 10:17:39 --> Router Class Initialized
INFO - 2017-01-16 10:17:39 --> Output Class Initialized
INFO - 2017-01-16 10:17:39 --> Security Class Initialized
DEBUG - 2017-01-16 10:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:17:39 --> Input Class Initialized
INFO - 2017-01-16 10:17:39 --> Language Class Initialized
INFO - 2017-01-16 10:17:39 --> Loader Class Initialized
INFO - 2017-01-16 10:17:39 --> Helper loaded: url_helper
INFO - 2017-01-16 10:17:39 --> Helper loaded: language_helper
INFO - 2017-01-16 10:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:17:39 --> Controller Class Initialized
INFO - 2017-01-16 10:17:39 --> Database Driver Class Initialized
INFO - 2017-01-16 10:17:39 --> Model Class Initialized
INFO - 2017-01-16 10:17:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:17:39 --> Config Class Initialized
INFO - 2017-01-16 10:17:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:17:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:17:39 --> Utf8 Class Initialized
INFO - 2017-01-16 10:17:39 --> URI Class Initialized
INFO - 2017-01-16 10:17:39 --> Router Class Initialized
INFO - 2017-01-16 10:17:39 --> Output Class Initialized
INFO - 2017-01-16 10:17:39 --> Security Class Initialized
DEBUG - 2017-01-16 10:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:17:39 --> Input Class Initialized
INFO - 2017-01-16 10:17:39 --> Language Class Initialized
INFO - 2017-01-16 10:17:39 --> Loader Class Initialized
INFO - 2017-01-16 10:17:39 --> Helper loaded: url_helper
INFO - 2017-01-16 10:17:39 --> Helper loaded: language_helper
INFO - 2017-01-16 10:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:17:39 --> Controller Class Initialized
INFO - 2017-01-16 10:17:39 --> Database Driver Class Initialized
INFO - 2017-01-16 10:17:39 --> Model Class Initialized
INFO - 2017-01-16 10:17:39 --> Model Class Initialized
INFO - 2017-01-16 10:17:39 --> Model Class Initialized
INFO - 2017-01-16 10:17:39 --> Model Class Initialized
INFO - 2017-01-16 10:17:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:17:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:17:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-16 10:17:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:17:39 --> Final output sent to browser
DEBUG - 2017-01-16 10:17:39 --> Total execution time: 0.0664
INFO - 2017-01-16 10:17:54 --> Config Class Initialized
INFO - 2017-01-16 10:17:54 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:17:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:17:54 --> Utf8 Class Initialized
INFO - 2017-01-16 10:17:54 --> URI Class Initialized
INFO - 2017-01-16 10:17:54 --> Router Class Initialized
INFO - 2017-01-16 10:17:54 --> Output Class Initialized
INFO - 2017-01-16 10:17:54 --> Security Class Initialized
DEBUG - 2017-01-16 10:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:17:54 --> Input Class Initialized
INFO - 2017-01-16 10:17:54 --> Language Class Initialized
INFO - 2017-01-16 10:17:54 --> Loader Class Initialized
INFO - 2017-01-16 10:17:54 --> Helper loaded: url_helper
INFO - 2017-01-16 10:17:54 --> Helper loaded: language_helper
INFO - 2017-01-16 10:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:17:54 --> Controller Class Initialized
INFO - 2017-01-16 10:17:54 --> Database Driver Class Initialized
INFO - 2017-01-16 10:17:54 --> Model Class Initialized
INFO - 2017-01-16 10:17:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:17:54 --> Helper loaded: form_helper
INFO - 2017-01-16 10:17:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:17:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 10:17:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:17:54 --> Final output sent to browser
DEBUG - 2017-01-16 10:17:54 --> Total execution time: 0.0625
INFO - 2017-01-16 10:19:11 --> Config Class Initialized
INFO - 2017-01-16 10:19:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:19:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:19:11 --> Utf8 Class Initialized
INFO - 2017-01-16 10:19:11 --> URI Class Initialized
INFO - 2017-01-16 10:19:11 --> Router Class Initialized
INFO - 2017-01-16 10:19:11 --> Output Class Initialized
INFO - 2017-01-16 10:19:11 --> Security Class Initialized
DEBUG - 2017-01-16 10:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:19:11 --> Input Class Initialized
INFO - 2017-01-16 10:19:11 --> Language Class Initialized
INFO - 2017-01-16 10:19:11 --> Loader Class Initialized
INFO - 2017-01-16 10:19:11 --> Helper loaded: url_helper
INFO - 2017-01-16 10:19:11 --> Helper loaded: language_helper
INFO - 2017-01-16 10:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:19:11 --> Controller Class Initialized
INFO - 2017-01-16 10:19:11 --> Database Driver Class Initialized
INFO - 2017-01-16 10:19:11 --> Model Class Initialized
INFO - 2017-01-16 10:19:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:19:11 --> Helper loaded: form_helper
INFO - 2017-01-16 10:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 10:19:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:19:11 --> Final output sent to browser
DEBUG - 2017-01-16 10:19:11 --> Total execution time: 0.0667
INFO - 2017-01-16 10:19:14 --> Config Class Initialized
INFO - 2017-01-16 10:19:14 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:19:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:19:14 --> Utf8 Class Initialized
INFO - 2017-01-16 10:19:14 --> URI Class Initialized
INFO - 2017-01-16 10:19:14 --> Router Class Initialized
INFO - 2017-01-16 10:19:14 --> Output Class Initialized
INFO - 2017-01-16 10:19:14 --> Security Class Initialized
DEBUG - 2017-01-16 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:19:14 --> Input Class Initialized
INFO - 2017-01-16 10:19:14 --> Language Class Initialized
INFO - 2017-01-16 10:19:14 --> Loader Class Initialized
INFO - 2017-01-16 10:19:14 --> Helper loaded: url_helper
INFO - 2017-01-16 10:19:14 --> Helper loaded: language_helper
INFO - 2017-01-16 10:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:19:14 --> Controller Class Initialized
INFO - 2017-01-16 10:19:14 --> Database Driver Class Initialized
INFO - 2017-01-16 10:19:14 --> Model Class Initialized
INFO - 2017-01-16 10:19:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:19:14 --> Helper loaded: form_helper
ERROR - 2017-01-16 10:19:14 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-16 10:19:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:19:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:19:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:19:14 --> Final output sent to browser
DEBUG - 2017-01-16 10:19:14 --> Total execution time: 0.0652
INFO - 2017-01-16 10:20:31 --> Config Class Initialized
INFO - 2017-01-16 10:20:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:20:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:20:31 --> Utf8 Class Initialized
INFO - 2017-01-16 10:20:31 --> URI Class Initialized
INFO - 2017-01-16 10:20:31 --> Router Class Initialized
INFO - 2017-01-16 10:20:31 --> Output Class Initialized
INFO - 2017-01-16 10:20:31 --> Security Class Initialized
DEBUG - 2017-01-16 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:20:31 --> Input Class Initialized
INFO - 2017-01-16 10:20:31 --> Language Class Initialized
INFO - 2017-01-16 10:20:31 --> Loader Class Initialized
INFO - 2017-01-16 10:20:31 --> Helper loaded: url_helper
INFO - 2017-01-16 10:20:31 --> Helper loaded: language_helper
INFO - 2017-01-16 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:20:31 --> Controller Class Initialized
INFO - 2017-01-16 10:20:31 --> Database Driver Class Initialized
INFO - 2017-01-16 10:20:31 --> Model Class Initialized
INFO - 2017-01-16 10:20:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:20:31 --> Helper loaded: form_helper
ERROR - 2017-01-16 10:20:31 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-16 10:20:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 10:20:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php 22
ERROR - 2017-01-16 10:20:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php 22
INFO - 2017-01-16 10:20:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:20:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:20:31 --> Final output sent to browser
DEBUG - 2017-01-16 10:20:31 --> Total execution time: 0.0681
INFO - 2017-01-16 10:22:09 --> Config Class Initialized
INFO - 2017-01-16 10:22:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:22:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:22:09 --> Utf8 Class Initialized
INFO - 2017-01-16 10:22:09 --> URI Class Initialized
INFO - 2017-01-16 10:22:09 --> Router Class Initialized
INFO - 2017-01-16 10:22:09 --> Output Class Initialized
INFO - 2017-01-16 10:22:09 --> Security Class Initialized
DEBUG - 2017-01-16 10:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:22:09 --> Input Class Initialized
INFO - 2017-01-16 10:22:09 --> Language Class Initialized
INFO - 2017-01-16 10:22:09 --> Loader Class Initialized
INFO - 2017-01-16 10:22:09 --> Helper loaded: url_helper
INFO - 2017-01-16 10:22:09 --> Helper loaded: language_helper
INFO - 2017-01-16 10:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:22:09 --> Controller Class Initialized
INFO - 2017-01-16 10:22:09 --> Database Driver Class Initialized
INFO - 2017-01-16 10:22:09 --> Model Class Initialized
INFO - 2017-01-16 10:22:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:22:09 --> Helper loaded: form_helper
ERROR - 2017-01-16 10:22:09 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-16 10:22:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 10:22:09 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php 22
ERROR - 2017-01-16 10:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php 22
INFO - 2017-01-16 10:22:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:22:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:22:09 --> Final output sent to browser
DEBUG - 2017-01-16 10:22:09 --> Total execution time: 0.0717
INFO - 2017-01-16 10:22:47 --> Config Class Initialized
INFO - 2017-01-16 10:22:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:22:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:22:47 --> Utf8 Class Initialized
INFO - 2017-01-16 10:22:47 --> URI Class Initialized
INFO - 2017-01-16 10:22:47 --> Router Class Initialized
INFO - 2017-01-16 10:22:47 --> Output Class Initialized
INFO - 2017-01-16 10:22:47 --> Security Class Initialized
DEBUG - 2017-01-16 10:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:22:47 --> Input Class Initialized
INFO - 2017-01-16 10:22:47 --> Language Class Initialized
INFO - 2017-01-16 10:22:47 --> Loader Class Initialized
INFO - 2017-01-16 10:22:47 --> Helper loaded: url_helper
INFO - 2017-01-16 10:22:47 --> Helper loaded: language_helper
INFO - 2017-01-16 10:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:22:47 --> Controller Class Initialized
INFO - 2017-01-16 10:22:47 --> Database Driver Class Initialized
INFO - 2017-01-16 10:22:47 --> Model Class Initialized
INFO - 2017-01-16 10:22:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:22:47 --> Helper loaded: form_helper
ERROR - 2017-01-16 10:22:47 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-16 10:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 10:22:47 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php 22
ERROR - 2017-01-16 10:22:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php 22
INFO - 2017-01-16 10:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:22:47 --> Final output sent to browser
DEBUG - 2017-01-16 10:22:47 --> Total execution time: 0.0835
INFO - 2017-01-16 10:25:15 --> Config Class Initialized
INFO - 2017-01-16 10:25:15 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:25:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:25:15 --> Utf8 Class Initialized
INFO - 2017-01-16 10:25:15 --> URI Class Initialized
INFO - 2017-01-16 10:25:15 --> Router Class Initialized
INFO - 2017-01-16 10:25:15 --> Output Class Initialized
INFO - 2017-01-16 10:25:15 --> Security Class Initialized
DEBUG - 2017-01-16 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:25:15 --> Input Class Initialized
INFO - 2017-01-16 10:25:15 --> Language Class Initialized
INFO - 2017-01-16 10:25:15 --> Loader Class Initialized
INFO - 2017-01-16 10:25:15 --> Helper loaded: url_helper
INFO - 2017-01-16 10:25:15 --> Helper loaded: language_helper
INFO - 2017-01-16 10:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:25:15 --> Controller Class Initialized
INFO - 2017-01-16 10:25:15 --> Database Driver Class Initialized
INFO - 2017-01-16 10:25:15 --> Model Class Initialized
INFO - 2017-01-16 10:25:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:25:15 --> Helper loaded: form_helper
INFO - 2017-01-16 10:25:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:25:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:25:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:25:15 --> Final output sent to browser
DEBUG - 2017-01-16 10:25:15 --> Total execution time: 0.0684
INFO - 2017-01-16 10:25:41 --> Config Class Initialized
INFO - 2017-01-16 10:25:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:25:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:25:41 --> Utf8 Class Initialized
INFO - 2017-01-16 10:25:41 --> URI Class Initialized
INFO - 2017-01-16 10:25:41 --> Router Class Initialized
INFO - 2017-01-16 10:25:41 --> Output Class Initialized
INFO - 2017-01-16 10:25:41 --> Security Class Initialized
DEBUG - 2017-01-16 10:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:25:41 --> Input Class Initialized
INFO - 2017-01-16 10:25:41 --> Language Class Initialized
INFO - 2017-01-16 10:25:41 --> Loader Class Initialized
INFO - 2017-01-16 10:25:41 --> Helper loaded: url_helper
INFO - 2017-01-16 10:25:41 --> Helper loaded: language_helper
INFO - 2017-01-16 10:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:25:41 --> Controller Class Initialized
INFO - 2017-01-16 10:25:41 --> Database Driver Class Initialized
INFO - 2017-01-16 10:25:41 --> Model Class Initialized
INFO - 2017-01-16 10:25:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:25:41 --> Helper loaded: form_helper
INFO - 2017-01-16 10:25:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:25:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:25:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:25:41 --> Final output sent to browser
DEBUG - 2017-01-16 10:25:41 --> Total execution time: 0.0648
INFO - 2017-01-16 10:27:28 --> Config Class Initialized
INFO - 2017-01-16 10:27:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:27:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:27:28 --> Utf8 Class Initialized
INFO - 2017-01-16 10:27:28 --> URI Class Initialized
INFO - 2017-01-16 10:27:28 --> Router Class Initialized
INFO - 2017-01-16 10:27:28 --> Output Class Initialized
INFO - 2017-01-16 10:27:28 --> Security Class Initialized
DEBUG - 2017-01-16 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:27:28 --> Input Class Initialized
INFO - 2017-01-16 10:27:28 --> Language Class Initialized
INFO - 2017-01-16 10:27:28 --> Loader Class Initialized
INFO - 2017-01-16 10:27:28 --> Helper loaded: url_helper
INFO - 2017-01-16 10:27:28 --> Helper loaded: language_helper
INFO - 2017-01-16 10:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:27:28 --> Controller Class Initialized
INFO - 2017-01-16 10:27:28 --> Database Driver Class Initialized
INFO - 2017-01-16 10:27:28 --> Model Class Initialized
INFO - 2017-01-16 10:27:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:27:28 --> Helper loaded: form_helper
ERROR - 2017-01-16 10:27:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'from answers a
                left join qbank b on b.qid = a.qid
              ' at line 2 - Invalid query: SELECT d.uid,concat(d.first_name,' ',d.last_name) as fullname,round(sum(case when c.cid=9 then a.score_u else null end), 0) as ist1,round(sum(case when c.cid=10 then a.score_u else null end), 0) as ist2,
                from answers a
                left join qbank b on b.qid = a.qid
                left join category c on c.cid = b.cid
                left join users d on d.uid = a.uid
                where su != 1
                group by d.uid
                order by total desc limit 30 offset 0
INFO - 2017-01-16 10:27:28 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-16 10:27:58 --> Config Class Initialized
INFO - 2017-01-16 10:27:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:27:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:27:58 --> Utf8 Class Initialized
INFO - 2017-01-16 10:27:58 --> URI Class Initialized
INFO - 2017-01-16 10:27:58 --> Router Class Initialized
INFO - 2017-01-16 10:27:58 --> Output Class Initialized
INFO - 2017-01-16 10:27:58 --> Security Class Initialized
DEBUG - 2017-01-16 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:27:58 --> Input Class Initialized
INFO - 2017-01-16 10:27:58 --> Language Class Initialized
INFO - 2017-01-16 10:27:58 --> Loader Class Initialized
INFO - 2017-01-16 10:27:58 --> Helper loaded: url_helper
INFO - 2017-01-16 10:27:58 --> Helper loaded: language_helper
INFO - 2017-01-16 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:27:58 --> Controller Class Initialized
INFO - 2017-01-16 10:27:59 --> Database Driver Class Initialized
INFO - 2017-01-16 10:27:59 --> Model Class Initialized
INFO - 2017-01-16 10:27:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:27:59 --> Helper loaded: form_helper
ERROR - 2017-01-16 10:27:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(sum(case when c.cid=10 then a.score_u else null end), 0) as ist2
              ' at line 1 - Invalid query: SELECT d.uid,concat(d.first_name,' ',d.last_name) as fullname,round(sum(case when c.cid=9 then a.score_u else null end), 0) as ist1round(sum(case when c.cid=10 then a.score_u else null end), 0) as ist2
                from answers a
                left join qbank b on b.qid = a.qid
                left join category c on c.cid = b.cid
                left join users d on d.uid = a.uid
                where su != 1
                group by d.uid
                order by total desc limit 30 offset 0
INFO - 2017-01-16 10:27:59 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-16 10:28:44 --> Config Class Initialized
INFO - 2017-01-16 10:28:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:28:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:28:44 --> Utf8 Class Initialized
INFO - 2017-01-16 10:28:44 --> URI Class Initialized
INFO - 2017-01-16 10:28:45 --> Router Class Initialized
INFO - 2017-01-16 10:28:45 --> Output Class Initialized
INFO - 2017-01-16 10:28:45 --> Security Class Initialized
DEBUG - 2017-01-16 10:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:28:45 --> Input Class Initialized
INFO - 2017-01-16 10:28:45 --> Language Class Initialized
INFO - 2017-01-16 10:28:45 --> Loader Class Initialized
INFO - 2017-01-16 10:28:45 --> Helper loaded: url_helper
INFO - 2017-01-16 10:28:45 --> Helper loaded: language_helper
INFO - 2017-01-16 10:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:28:45 --> Controller Class Initialized
INFO - 2017-01-16 10:28:45 --> Database Driver Class Initialized
INFO - 2017-01-16 10:28:45 --> Model Class Initialized
INFO - 2017-01-16 10:28:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:28:45 --> Helper loaded: form_helper
INFO - 2017-01-16 10:28:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:28:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:28:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:28:45 --> Final output sent to browser
DEBUG - 2017-01-16 10:28:45 --> Total execution time: 0.0647
INFO - 2017-01-16 10:29:27 --> Config Class Initialized
INFO - 2017-01-16 10:29:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:29:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:29:27 --> Utf8 Class Initialized
INFO - 2017-01-16 10:29:27 --> URI Class Initialized
INFO - 2017-01-16 10:29:27 --> Router Class Initialized
INFO - 2017-01-16 10:29:27 --> Output Class Initialized
INFO - 2017-01-16 10:29:27 --> Security Class Initialized
DEBUG - 2017-01-16 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:29:27 --> Input Class Initialized
INFO - 2017-01-16 10:29:27 --> Language Class Initialized
INFO - 2017-01-16 10:29:27 --> Loader Class Initialized
INFO - 2017-01-16 10:29:27 --> Helper loaded: url_helper
INFO - 2017-01-16 10:29:27 --> Helper loaded: language_helper
INFO - 2017-01-16 10:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:29:27 --> Controller Class Initialized
INFO - 2017-01-16 10:29:27 --> Database Driver Class Initialized
INFO - 2017-01-16 10:29:27 --> Model Class Initialized
INFO - 2017-01-16 10:29:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:29:27 --> Helper loaded: form_helper
INFO - 2017-01-16 10:29:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:29:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:29:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:29:27 --> Final output sent to browser
DEBUG - 2017-01-16 10:29:27 --> Total execution time: 0.0638
INFO - 2017-01-16 10:29:59 --> Config Class Initialized
INFO - 2017-01-16 10:29:59 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:29:59 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:29:59 --> Utf8 Class Initialized
INFO - 2017-01-16 10:29:59 --> URI Class Initialized
INFO - 2017-01-16 10:29:59 --> Router Class Initialized
INFO - 2017-01-16 10:29:59 --> Output Class Initialized
INFO - 2017-01-16 10:29:59 --> Security Class Initialized
DEBUG - 2017-01-16 10:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:29:59 --> Input Class Initialized
INFO - 2017-01-16 10:29:59 --> Language Class Initialized
INFO - 2017-01-16 10:29:59 --> Loader Class Initialized
INFO - 2017-01-16 10:29:59 --> Helper loaded: url_helper
INFO - 2017-01-16 10:29:59 --> Helper loaded: language_helper
INFO - 2017-01-16 10:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:29:59 --> Controller Class Initialized
INFO - 2017-01-16 10:29:59 --> Database Driver Class Initialized
INFO - 2017-01-16 10:29:59 --> Model Class Initialized
INFO - 2017-01-16 10:29:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:29:59 --> Helper loaded: form_helper
INFO - 2017-01-16 10:29:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:29:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-16 10:29:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:29:59 --> Final output sent to browser
DEBUG - 2017-01-16 10:29:59 --> Total execution time: 0.0654
INFO - 2017-01-16 10:30:33 --> Config Class Initialized
INFO - 2017-01-16 10:30:33 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:30:33 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:30:33 --> Utf8 Class Initialized
INFO - 2017-01-16 10:30:33 --> URI Class Initialized
INFO - 2017-01-16 10:30:33 --> Router Class Initialized
INFO - 2017-01-16 10:30:33 --> Output Class Initialized
INFO - 2017-01-16 10:30:33 --> Security Class Initialized
DEBUG - 2017-01-16 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:30:33 --> Input Class Initialized
INFO - 2017-01-16 10:30:33 --> Language Class Initialized
INFO - 2017-01-16 10:30:33 --> Loader Class Initialized
INFO - 2017-01-16 10:30:33 --> Helper loaded: url_helper
INFO - 2017-01-16 10:30:33 --> Helper loaded: language_helper
INFO - 2017-01-16 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:30:33 --> Controller Class Initialized
INFO - 2017-01-16 10:30:33 --> Database Driver Class Initialized
INFO - 2017-01-16 10:30:33 --> Model Class Initialized
INFO - 2017-01-16 10:30:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:30:33 --> Helper loaded: form_helper
INFO - 2017-01-16 10:30:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:30:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-16 10:30:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:30:33 --> Final output sent to browser
DEBUG - 2017-01-16 10:30:33 --> Total execution time: 0.0734
INFO - 2017-01-16 10:30:41 --> Config Class Initialized
INFO - 2017-01-16 10:30:41 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:30:41 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:30:41 --> Utf8 Class Initialized
INFO - 2017-01-16 10:30:41 --> URI Class Initialized
INFO - 2017-01-16 10:30:41 --> Router Class Initialized
INFO - 2017-01-16 10:30:41 --> Output Class Initialized
INFO - 2017-01-16 10:30:41 --> Security Class Initialized
DEBUG - 2017-01-16 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:30:41 --> Input Class Initialized
INFO - 2017-01-16 10:30:41 --> Language Class Initialized
INFO - 2017-01-16 10:30:41 --> Loader Class Initialized
INFO - 2017-01-16 10:30:41 --> Helper loaded: url_helper
INFO - 2017-01-16 10:30:41 --> Helper loaded: language_helper
INFO - 2017-01-16 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:30:41 --> Controller Class Initialized
INFO - 2017-01-16 10:30:41 --> Database Driver Class Initialized
INFO - 2017-01-16 10:30:41 --> Model Class Initialized
INFO - 2017-01-16 10:30:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:30:41 --> Helper loaded: form_helper
INFO - 2017-01-16 10:30:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:30:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 10:30:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:30:41 --> Final output sent to browser
DEBUG - 2017-01-16 10:30:41 --> Total execution time: 0.0609
INFO - 2017-01-16 10:30:46 --> Config Class Initialized
INFO - 2017-01-16 10:30:46 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:30:46 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:30:46 --> Utf8 Class Initialized
INFO - 2017-01-16 10:30:46 --> URI Class Initialized
INFO - 2017-01-16 10:30:46 --> Router Class Initialized
INFO - 2017-01-16 10:30:46 --> Output Class Initialized
INFO - 2017-01-16 10:30:46 --> Security Class Initialized
DEBUG - 2017-01-16 10:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:30:46 --> Input Class Initialized
INFO - 2017-01-16 10:30:46 --> Language Class Initialized
INFO - 2017-01-16 10:30:46 --> Loader Class Initialized
INFO - 2017-01-16 10:30:46 --> Helper loaded: url_helper
INFO - 2017-01-16 10:30:46 --> Helper loaded: language_helper
INFO - 2017-01-16 10:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:30:46 --> Controller Class Initialized
INFO - 2017-01-16 10:30:46 --> Database Driver Class Initialized
INFO - 2017-01-16 10:30:46 --> Model Class Initialized
INFO - 2017-01-16 10:30:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:30:46 --> Helper loaded: form_helper
INFO - 2017-01-16 10:30:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:30:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-16 10:30:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:30:46 --> Final output sent to browser
DEBUG - 2017-01-16 10:30:46 --> Total execution time: 0.0625
INFO - 2017-01-16 10:32:26 --> Config Class Initialized
INFO - 2017-01-16 10:32:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:32:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:32:26 --> Utf8 Class Initialized
INFO - 2017-01-16 10:32:26 --> URI Class Initialized
INFO - 2017-01-16 10:32:26 --> Router Class Initialized
INFO - 2017-01-16 10:32:26 --> Output Class Initialized
INFO - 2017-01-16 10:32:26 --> Security Class Initialized
DEBUG - 2017-01-16 10:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:32:26 --> Input Class Initialized
INFO - 2017-01-16 10:32:26 --> Language Class Initialized
INFO - 2017-01-16 10:32:26 --> Loader Class Initialized
INFO - 2017-01-16 10:32:26 --> Helper loaded: url_helper
INFO - 2017-01-16 10:32:26 --> Helper loaded: language_helper
INFO - 2017-01-16 10:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:32:26 --> Controller Class Initialized
INFO - 2017-01-16 10:32:26 --> Database Driver Class Initialized
INFO - 2017-01-16 10:32:26 --> Model Class Initialized
INFO - 2017-01-16 10:32:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:32:26 --> Helper loaded: form_helper
INFO - 2017-01-16 10:32:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:32:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-16 10:32:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:32:26 --> Final output sent to browser
DEBUG - 2017-01-16 10:32:26 --> Total execution time: 0.0665
INFO - 2017-01-16 10:33:22 --> Config Class Initialized
INFO - 2017-01-16 10:33:22 --> Hooks Class Initialized
DEBUG - 2017-01-16 10:33:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 10:33:22 --> Utf8 Class Initialized
INFO - 2017-01-16 10:33:22 --> URI Class Initialized
INFO - 2017-01-16 10:33:22 --> Router Class Initialized
INFO - 2017-01-16 10:33:22 --> Output Class Initialized
INFO - 2017-01-16 10:33:22 --> Security Class Initialized
DEBUG - 2017-01-16 10:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 10:33:22 --> Input Class Initialized
INFO - 2017-01-16 10:33:22 --> Language Class Initialized
INFO - 2017-01-16 10:33:22 --> Loader Class Initialized
INFO - 2017-01-16 10:33:22 --> Helper loaded: url_helper
INFO - 2017-01-16 10:33:22 --> Helper loaded: language_helper
INFO - 2017-01-16 10:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 10:33:22 --> Controller Class Initialized
INFO - 2017-01-16 10:33:22 --> Database Driver Class Initialized
INFO - 2017-01-16 10:33:22 --> Model Class Initialized
INFO - 2017-01-16 10:33:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 10:33:22 --> Helper loaded: form_helper
INFO - 2017-01-16 10:33:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 10:33:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-16 10:33:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 10:33:22 --> Final output sent to browser
DEBUG - 2017-01-16 10:33:22 --> Total execution time: 0.0637
INFO - 2017-01-16 12:34:24 --> Config Class Initialized
INFO - 2017-01-16 12:34:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:34:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:34:24 --> Utf8 Class Initialized
INFO - 2017-01-16 12:34:24 --> URI Class Initialized
INFO - 2017-01-16 12:34:24 --> Router Class Initialized
INFO - 2017-01-16 12:34:24 --> Output Class Initialized
INFO - 2017-01-16 12:34:24 --> Security Class Initialized
DEBUG - 2017-01-16 12:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:34:24 --> Input Class Initialized
INFO - 2017-01-16 12:34:24 --> Language Class Initialized
INFO - 2017-01-16 12:34:24 --> Loader Class Initialized
INFO - 2017-01-16 12:34:24 --> Helper loaded: url_helper
INFO - 2017-01-16 12:34:24 --> Helper loaded: language_helper
INFO - 2017-01-16 12:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:34:24 --> Controller Class Initialized
INFO - 2017-01-16 12:34:24 --> Database Driver Class Initialized
INFO - 2017-01-16 12:34:24 --> Model Class Initialized
INFO - 2017-01-16 12:34:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:34:24 --> Config Class Initialized
INFO - 2017-01-16 12:34:24 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:34:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:34:24 --> Utf8 Class Initialized
INFO - 2017-01-16 12:34:24 --> URI Class Initialized
INFO - 2017-01-16 12:34:24 --> Router Class Initialized
INFO - 2017-01-16 12:34:24 --> Output Class Initialized
INFO - 2017-01-16 12:34:24 --> Security Class Initialized
DEBUG - 2017-01-16 12:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:34:24 --> Input Class Initialized
INFO - 2017-01-16 12:34:24 --> Language Class Initialized
INFO - 2017-01-16 12:34:24 --> Loader Class Initialized
INFO - 2017-01-16 12:34:24 --> Helper loaded: url_helper
INFO - 2017-01-16 12:34:24 --> Helper loaded: language_helper
INFO - 2017-01-16 12:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:34:24 --> Controller Class Initialized
INFO - 2017-01-16 12:34:24 --> Database Driver Class Initialized
INFO - 2017-01-16 12:34:24 --> Model Class Initialized
INFO - 2017-01-16 12:34:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:34:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-16 12:34:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-16 12:34:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-16 12:34:24 --> Final output sent to browser
DEBUG - 2017-01-16 12:34:24 --> Total execution time: 0.0602
INFO - 2017-01-16 12:34:31 --> Config Class Initialized
INFO - 2017-01-16 12:34:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:34:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:34:31 --> Utf8 Class Initialized
INFO - 2017-01-16 12:34:31 --> URI Class Initialized
INFO - 2017-01-16 12:34:31 --> Router Class Initialized
INFO - 2017-01-16 12:34:31 --> Output Class Initialized
INFO - 2017-01-16 12:34:31 --> Security Class Initialized
DEBUG - 2017-01-16 12:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:34:31 --> Input Class Initialized
INFO - 2017-01-16 12:34:31 --> Language Class Initialized
INFO - 2017-01-16 12:34:31 --> Loader Class Initialized
INFO - 2017-01-16 12:34:31 --> Helper loaded: url_helper
INFO - 2017-01-16 12:34:31 --> Helper loaded: language_helper
INFO - 2017-01-16 12:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:34:31 --> Controller Class Initialized
INFO - 2017-01-16 12:34:31 --> Database Driver Class Initialized
INFO - 2017-01-16 12:34:31 --> Model Class Initialized
INFO - 2017-01-16 12:34:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:34:31 --> Config Class Initialized
INFO - 2017-01-16 12:34:31 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:34:31 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:34:31 --> Utf8 Class Initialized
INFO - 2017-01-16 12:34:31 --> URI Class Initialized
INFO - 2017-01-16 12:34:31 --> Router Class Initialized
INFO - 2017-01-16 12:34:31 --> Output Class Initialized
INFO - 2017-01-16 12:34:31 --> Security Class Initialized
DEBUG - 2017-01-16 12:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:34:31 --> Input Class Initialized
INFO - 2017-01-16 12:34:31 --> Language Class Initialized
INFO - 2017-01-16 12:34:31 --> Loader Class Initialized
INFO - 2017-01-16 12:34:31 --> Helper loaded: url_helper
INFO - 2017-01-16 12:34:31 --> Helper loaded: language_helper
INFO - 2017-01-16 12:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:34:31 --> Controller Class Initialized
INFO - 2017-01-16 12:34:31 --> Database Driver Class Initialized
INFO - 2017-01-16 12:34:31 --> Model Class Initialized
INFO - 2017-01-16 12:34:31 --> Model Class Initialized
INFO - 2017-01-16 12:34:31 --> Model Class Initialized
INFO - 2017-01-16 12:34:31 --> Model Class Initialized
INFO - 2017-01-16 12:34:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-16 12:34:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:34:31 --> Final output sent to browser
DEBUG - 2017-01-16 12:34:31 --> Total execution time: 0.0742
INFO - 2017-01-16 12:34:34 --> Config Class Initialized
INFO - 2017-01-16 12:34:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:34:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:34:34 --> Utf8 Class Initialized
INFO - 2017-01-16 12:34:34 --> URI Class Initialized
INFO - 2017-01-16 12:34:34 --> Router Class Initialized
INFO - 2017-01-16 12:34:34 --> Output Class Initialized
INFO - 2017-01-16 12:34:34 --> Security Class Initialized
DEBUG - 2017-01-16 12:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:34:34 --> Input Class Initialized
INFO - 2017-01-16 12:34:34 --> Language Class Initialized
INFO - 2017-01-16 12:34:34 --> Loader Class Initialized
INFO - 2017-01-16 12:34:34 --> Helper loaded: url_helper
INFO - 2017-01-16 12:34:34 --> Helper loaded: language_helper
INFO - 2017-01-16 12:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:34:34 --> Controller Class Initialized
INFO - 2017-01-16 12:34:34 --> Database Driver Class Initialized
INFO - 2017-01-16 12:34:34 --> Model Class Initialized
INFO - 2017-01-16 12:34:34 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-16 12:34:34 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\savsoftquiz\application\views\header.php 3
INFO - 2017-01-16 12:34:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:34:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:34:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:34:34 --> Final output sent to browser
DEBUG - 2017-01-16 12:34:34 --> Total execution time: 0.0626
INFO - 2017-01-16 12:35:20 --> Config Class Initialized
INFO - 2017-01-16 12:35:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:35:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:35:20 --> Utf8 Class Initialized
INFO - 2017-01-16 12:35:20 --> URI Class Initialized
INFO - 2017-01-16 12:35:20 --> Router Class Initialized
INFO - 2017-01-16 12:35:20 --> Output Class Initialized
INFO - 2017-01-16 12:35:20 --> Security Class Initialized
DEBUG - 2017-01-16 12:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:35:20 --> Input Class Initialized
INFO - 2017-01-16 12:35:20 --> Language Class Initialized
INFO - 2017-01-16 12:35:20 --> Loader Class Initialized
INFO - 2017-01-16 12:35:20 --> Helper loaded: url_helper
INFO - 2017-01-16 12:35:20 --> Helper loaded: language_helper
INFO - 2017-01-16 12:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:35:20 --> Controller Class Initialized
INFO - 2017-01-16 12:35:20 --> Database Driver Class Initialized
INFO - 2017-01-16 12:35:20 --> Model Class Initialized
INFO - 2017-01-16 12:35:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:35:20 --> Helper loaded: form_helper
INFO - 2017-01-16 12:35:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:35:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 12:35:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:35:20 --> Final output sent to browser
DEBUG - 2017-01-16 12:35:20 --> Total execution time: 0.0659
INFO - 2017-01-16 12:35:23 --> Config Class Initialized
INFO - 2017-01-16 12:35:23 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:35:24 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:35:24 --> Utf8 Class Initialized
INFO - 2017-01-16 12:35:24 --> URI Class Initialized
INFO - 2017-01-16 12:35:24 --> Router Class Initialized
INFO - 2017-01-16 12:35:24 --> Output Class Initialized
INFO - 2017-01-16 12:35:24 --> Security Class Initialized
DEBUG - 2017-01-16 12:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:35:24 --> Input Class Initialized
INFO - 2017-01-16 12:35:24 --> Language Class Initialized
INFO - 2017-01-16 12:35:24 --> Loader Class Initialized
INFO - 2017-01-16 12:35:24 --> Helper loaded: url_helper
INFO - 2017-01-16 12:35:24 --> Helper loaded: language_helper
INFO - 2017-01-16 12:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:35:24 --> Controller Class Initialized
INFO - 2017-01-16 12:35:24 --> Database Driver Class Initialized
INFO - 2017-01-16 12:35:24 --> Model Class Initialized
INFO - 2017-01-16 12:35:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:35:24 --> Model Class Initialized
INFO - 2017-01-16 12:35:24 --> Model Class Initialized
INFO - 2017-01-16 12:35:24 --> Helper loaded: form_helper
INFO - 2017-01-16 12:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 12:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:35:24 --> Final output sent to browser
DEBUG - 2017-01-16 12:35:24 --> Total execution time: 0.1032
INFO - 2017-01-16 12:40:48 --> Config Class Initialized
INFO - 2017-01-16 12:40:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:40:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:40:48 --> Utf8 Class Initialized
INFO - 2017-01-16 12:40:48 --> URI Class Initialized
INFO - 2017-01-16 12:40:48 --> Router Class Initialized
INFO - 2017-01-16 12:40:48 --> Output Class Initialized
INFO - 2017-01-16 12:40:48 --> Security Class Initialized
DEBUG - 2017-01-16 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:40:48 --> Input Class Initialized
INFO - 2017-01-16 12:40:48 --> Language Class Initialized
INFO - 2017-01-16 12:40:48 --> Loader Class Initialized
INFO - 2017-01-16 12:40:48 --> Helper loaded: url_helper
INFO - 2017-01-16 12:40:48 --> Helper loaded: language_helper
INFO - 2017-01-16 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:40:48 --> Controller Class Initialized
INFO - 2017-01-16 12:40:48 --> Database Driver Class Initialized
INFO - 2017-01-16 12:40:48 --> Model Class Initialized
INFO - 2017-01-16 12:40:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:40:48 --> Helper loaded: form_helper
INFO - 2017-01-16 12:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist4' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist4' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist5' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 31
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist5' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 31
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist6' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 32
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist6' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 32
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist7' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 33
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist7' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 33
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist8' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 34
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist8' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 34
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist9' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 35
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist9' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 35
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'total' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 36
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 37
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist4' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist4' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist5' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 31
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist5' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 31
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist6' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 32
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist6' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 32
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist7' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 33
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist7' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 33
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist8' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 34
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist8' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 34
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist9' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 35
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist9' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 35
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'total' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 36
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 37
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist4' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist4' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist5' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 31
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist5' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 31
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist6' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 32
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist6' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 32
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist7' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 33
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist7' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 33
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist8' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 34
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist8' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 34
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist9' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 35
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'ist9' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 35
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'total' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 36
ERROR - 2017-01-16 12:40:48 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 37
INFO - 2017-01-16 12:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:40:48 --> Final output sent to browser
DEBUG - 2017-01-16 12:40:48 --> Total execution time: 0.1458
INFO - 2017-01-16 12:44:57 --> Config Class Initialized
INFO - 2017-01-16 12:44:57 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:44:57 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:44:57 --> Utf8 Class Initialized
INFO - 2017-01-16 12:44:57 --> URI Class Initialized
INFO - 2017-01-16 12:44:57 --> Router Class Initialized
INFO - 2017-01-16 12:44:57 --> Output Class Initialized
INFO - 2017-01-16 12:44:57 --> Security Class Initialized
DEBUG - 2017-01-16 12:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:44:57 --> Input Class Initialized
INFO - 2017-01-16 12:44:57 --> Language Class Initialized
INFO - 2017-01-16 12:44:57 --> Loader Class Initialized
INFO - 2017-01-16 12:44:57 --> Helper loaded: url_helper
INFO - 2017-01-16 12:44:57 --> Helper loaded: language_helper
INFO - 2017-01-16 12:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:44:57 --> Controller Class Initialized
INFO - 2017-01-16 12:44:57 --> Database Driver Class Initialized
INFO - 2017-01-16 12:44:57 --> Model Class Initialized
INFO - 2017-01-16 12:44:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:44:57 --> Helper loaded: form_helper
INFO - 2017-01-16 12:44:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:57 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
INFO - 2017-01-16 12:44:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:44:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:44:57 --> Final output sent to browser
DEBUG - 2017-01-16 12:44:57 --> Total execution time: 0.1029
INFO - 2017-01-16 12:44:58 --> Config Class Initialized
INFO - 2017-01-16 12:44:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:44:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:44:58 --> Utf8 Class Initialized
INFO - 2017-01-16 12:44:58 --> URI Class Initialized
INFO - 2017-01-16 12:44:58 --> Router Class Initialized
INFO - 2017-01-16 12:44:58 --> Output Class Initialized
INFO - 2017-01-16 12:44:58 --> Security Class Initialized
DEBUG - 2017-01-16 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:44:58 --> Input Class Initialized
INFO - 2017-01-16 12:44:58 --> Language Class Initialized
INFO - 2017-01-16 12:44:58 --> Loader Class Initialized
INFO - 2017-01-16 12:44:58 --> Helper loaded: url_helper
INFO - 2017-01-16 12:44:58 --> Helper loaded: language_helper
INFO - 2017-01-16 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:44:58 --> Controller Class Initialized
INFO - 2017-01-16 12:44:58 --> Database Driver Class Initialized
INFO - 2017-01-16 12:44:58 --> Model Class Initialized
INFO - 2017-01-16 12:44:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:44:58 --> Helper loaded: form_helper
INFO - 2017-01-16 12:44:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 12:44:58 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:44:58 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:58 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist1' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 27
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist2' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 28
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'ist3' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 29
ERROR - 2017-01-16 12:44:59 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
INFO - 2017-01-16 12:44:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:44:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:44:59 --> Final output sent to browser
DEBUG - 2017-01-16 12:44:59 --> Total execution time: 0.1076
INFO - 2017-01-16 12:45:39 --> Config Class Initialized
INFO - 2017-01-16 12:45:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:45:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:45:39 --> Utf8 Class Initialized
INFO - 2017-01-16 12:45:39 --> URI Class Initialized
INFO - 2017-01-16 12:45:39 --> Router Class Initialized
INFO - 2017-01-16 12:45:39 --> Output Class Initialized
INFO - 2017-01-16 12:45:39 --> Security Class Initialized
DEBUG - 2017-01-16 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:45:39 --> Input Class Initialized
INFO - 2017-01-16 12:45:39 --> Language Class Initialized
INFO - 2017-01-16 12:45:39 --> Loader Class Initialized
INFO - 2017-01-16 12:45:39 --> Helper loaded: url_helper
INFO - 2017-01-16 12:45:39 --> Helper loaded: language_helper
INFO - 2017-01-16 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:45:39 --> Controller Class Initialized
INFO - 2017-01-16 12:45:39 --> Database Driver Class Initialized
INFO - 2017-01-16 12:45:39 --> Model Class Initialized
INFO - 2017-01-16 12:45:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:45:39 --> Helper loaded: form_helper
INFO - 2017-01-16 12:45:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 12:45:39 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:45:39 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:45:39 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:45:39 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:45:39 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:45:39 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
INFO - 2017-01-16 12:45:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:45:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:45:39 --> Final output sent to browser
DEBUG - 2017-01-16 12:45:39 --> Total execution time: 0.0864
INFO - 2017-01-16 12:47:07 --> Config Class Initialized
INFO - 2017-01-16 12:47:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:47:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:47:07 --> Utf8 Class Initialized
INFO - 2017-01-16 12:47:07 --> URI Class Initialized
INFO - 2017-01-16 12:47:07 --> Router Class Initialized
INFO - 2017-01-16 12:47:07 --> Output Class Initialized
INFO - 2017-01-16 12:47:07 --> Security Class Initialized
DEBUG - 2017-01-16 12:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:47:07 --> Input Class Initialized
INFO - 2017-01-16 12:47:07 --> Language Class Initialized
INFO - 2017-01-16 12:47:07 --> Loader Class Initialized
INFO - 2017-01-16 12:47:07 --> Helper loaded: url_helper
INFO - 2017-01-16 12:47:07 --> Helper loaded: language_helper
INFO - 2017-01-16 12:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:47:07 --> Controller Class Initialized
INFO - 2017-01-16 12:47:07 --> Database Driver Class Initialized
INFO - 2017-01-16 12:47:07 --> Model Class Initialized
INFO - 2017-01-16 12:47:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:47:07 --> Helper loaded: form_helper
INFO - 2017-01-16 12:47:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-16 12:47:07 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:47:07 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:47:07 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:47:07 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
ERROR - 2017-01-16 12:47:07 --> Severity: Warning --> Illegal string offset 'fullname' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 26
ERROR - 2017-01-16 12:47:07 --> Severity: Warning --> Illegal string offset 'uid' C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php 30
INFO - 2017-01-16 12:47:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:47:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:47:07 --> Final output sent to browser
DEBUG - 2017-01-16 12:47:07 --> Total execution time: 0.0777
INFO - 2017-01-16 12:47:51 --> Config Class Initialized
INFO - 2017-01-16 12:47:51 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:47:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:47:51 --> Utf8 Class Initialized
INFO - 2017-01-16 12:47:51 --> URI Class Initialized
INFO - 2017-01-16 12:47:51 --> Router Class Initialized
INFO - 2017-01-16 12:47:51 --> Output Class Initialized
INFO - 2017-01-16 12:47:51 --> Security Class Initialized
DEBUG - 2017-01-16 12:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:47:51 --> Input Class Initialized
INFO - 2017-01-16 12:47:51 --> Language Class Initialized
INFO - 2017-01-16 12:47:51 --> Loader Class Initialized
INFO - 2017-01-16 12:47:51 --> Helper loaded: url_helper
INFO - 2017-01-16 12:47:51 --> Helper loaded: language_helper
INFO - 2017-01-16 12:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:47:51 --> Controller Class Initialized
INFO - 2017-01-16 12:47:51 --> Database Driver Class Initialized
INFO - 2017-01-16 12:47:51 --> Model Class Initialized
INFO - 2017-01-16 12:47:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:47:51 --> Helper loaded: form_helper
INFO - 2017-01-16 12:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:47:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:47:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:47:52 --> Final output sent to browser
DEBUG - 2017-01-16 12:47:52 --> Total execution time: 0.0650
INFO - 2017-01-16 12:47:57 --> Config Class Initialized
INFO - 2017-01-16 12:47:57 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:47:57 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:47:57 --> Utf8 Class Initialized
INFO - 2017-01-16 12:47:57 --> URI Class Initialized
INFO - 2017-01-16 12:47:57 --> Router Class Initialized
INFO - 2017-01-16 12:47:57 --> Output Class Initialized
INFO - 2017-01-16 12:47:57 --> Security Class Initialized
DEBUG - 2017-01-16 12:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:47:57 --> Input Class Initialized
INFO - 2017-01-16 12:47:57 --> Language Class Initialized
INFO - 2017-01-16 12:47:57 --> Loader Class Initialized
INFO - 2017-01-16 12:47:57 --> Helper loaded: url_helper
INFO - 2017-01-16 12:47:57 --> Helper loaded: language_helper
INFO - 2017-01-16 12:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:47:57 --> Controller Class Initialized
INFO - 2017-01-16 12:47:57 --> Database Driver Class Initialized
INFO - 2017-01-16 12:47:57 --> Model Class Initialized
INFO - 2017-01-16 12:47:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:47:57 --> Model Class Initialized
INFO - 2017-01-16 12:47:57 --> Model Class Initialized
INFO - 2017-01-16 12:47:57 --> Helper loaded: form_helper
INFO - 2017-01-16 12:47:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:47:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_disc.php
INFO - 2017-01-16 12:47:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:47:57 --> Final output sent to browser
DEBUG - 2017-01-16 12:47:57 --> Total execution time: 0.0724
INFO - 2017-01-16 12:48:08 --> Config Class Initialized
INFO - 2017-01-16 12:48:08 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:48:08 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:48:08 --> Utf8 Class Initialized
INFO - 2017-01-16 12:48:08 --> URI Class Initialized
INFO - 2017-01-16 12:48:08 --> Router Class Initialized
INFO - 2017-01-16 12:48:08 --> Output Class Initialized
INFO - 2017-01-16 12:48:08 --> Security Class Initialized
DEBUG - 2017-01-16 12:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:48:08 --> Input Class Initialized
INFO - 2017-01-16 12:48:08 --> Language Class Initialized
INFO - 2017-01-16 12:48:08 --> Loader Class Initialized
INFO - 2017-01-16 12:48:08 --> Helper loaded: url_helper
INFO - 2017-01-16 12:48:08 --> Helper loaded: language_helper
INFO - 2017-01-16 12:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:48:08 --> Controller Class Initialized
INFO - 2017-01-16 12:48:08 --> Database Driver Class Initialized
INFO - 2017-01-16 12:48:08 --> Model Class Initialized
INFO - 2017-01-16 12:48:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:48:08 --> Helper loaded: form_helper
INFO - 2017-01-16 12:48:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:48:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-16 12:48:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:48:08 --> Final output sent to browser
DEBUG - 2017-01-16 12:48:08 --> Total execution time: 0.0633
INFO - 2017-01-16 12:48:09 --> Config Class Initialized
INFO - 2017-01-16 12:48:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:48:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:48:09 --> Utf8 Class Initialized
INFO - 2017-01-16 12:48:09 --> URI Class Initialized
INFO - 2017-01-16 12:48:09 --> Router Class Initialized
INFO - 2017-01-16 12:48:09 --> Output Class Initialized
INFO - 2017-01-16 12:48:09 --> Security Class Initialized
DEBUG - 2017-01-16 12:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:48:09 --> Input Class Initialized
INFO - 2017-01-16 12:48:09 --> Language Class Initialized
INFO - 2017-01-16 12:48:09 --> Loader Class Initialized
INFO - 2017-01-16 12:48:09 --> Helper loaded: url_helper
INFO - 2017-01-16 12:48:09 --> Helper loaded: language_helper
INFO - 2017-01-16 12:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:48:09 --> Controller Class Initialized
INFO - 2017-01-16 12:48:09 --> Database Driver Class Initialized
INFO - 2017-01-16 12:48:09 --> Model Class Initialized
INFO - 2017-01-16 12:48:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:48:09 --> Model Class Initialized
INFO - 2017-01-16 12:48:09 --> Model Class Initialized
INFO - 2017-01-16 12:48:09 --> Helper loaded: form_helper
INFO - 2017-01-16 12:48:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:48:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-16 12:48:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:48:09 --> Final output sent to browser
DEBUG - 2017-01-16 12:48:09 --> Total execution time: 0.0883
INFO - 2017-01-16 12:48:20 --> Config Class Initialized
INFO - 2017-01-16 12:48:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:48:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:48:20 --> Utf8 Class Initialized
INFO - 2017-01-16 12:48:20 --> URI Class Initialized
INFO - 2017-01-16 12:48:20 --> Router Class Initialized
INFO - 2017-01-16 12:48:20 --> Output Class Initialized
INFO - 2017-01-16 12:48:20 --> Security Class Initialized
DEBUG - 2017-01-16 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:48:20 --> Input Class Initialized
INFO - 2017-01-16 12:48:20 --> Language Class Initialized
INFO - 2017-01-16 12:48:20 --> Loader Class Initialized
INFO - 2017-01-16 12:48:20 --> Helper loaded: url_helper
INFO - 2017-01-16 12:48:20 --> Helper loaded: language_helper
INFO - 2017-01-16 12:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:48:20 --> Controller Class Initialized
INFO - 2017-01-16 12:48:20 --> Database Driver Class Initialized
INFO - 2017-01-16 12:48:20 --> Model Class Initialized
INFO - 2017-01-16 12:48:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-16 12:48:20 --> Helper loaded: form_helper
INFO - 2017-01-16 12:48:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-16 12:48:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-16 12:48:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-16 12:48:20 --> Final output sent to browser
DEBUG - 2017-01-16 12:48:20 --> Total execution time: 0.0629
