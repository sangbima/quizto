<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-19 09:42:24 --> Config Class Initialized
INFO - 2017-01-19 09:42:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:42:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:42:24 --> Utf8 Class Initialized
INFO - 2017-01-19 09:42:24 --> URI Class Initialized
INFO - 2017-01-19 09:42:24 --> Router Class Initialized
INFO - 2017-01-19 09:42:24 --> Output Class Initialized
INFO - 2017-01-19 09:42:24 --> Security Class Initialized
DEBUG - 2017-01-19 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:42:24 --> Input Class Initialized
INFO - 2017-01-19 09:42:24 --> Language Class Initialized
INFO - 2017-01-19 09:42:24 --> Loader Class Initialized
INFO - 2017-01-19 09:42:24 --> Helper loaded: url_helper
INFO - 2017-01-19 09:42:24 --> Helper loaded: language_helper
INFO - 2017-01-19 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:42:24 --> Controller Class Initialized
INFO - 2017-01-19 09:42:24 --> Database Driver Class Initialized
INFO - 2017-01-19 09:42:24 --> Model Class Initialized
INFO - 2017-01-19 09:42:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:42:24 --> Config Class Initialized
INFO - 2017-01-19 09:42:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:42:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:42:24 --> Utf8 Class Initialized
INFO - 2017-01-19 09:42:24 --> URI Class Initialized
INFO - 2017-01-19 09:42:24 --> Router Class Initialized
INFO - 2017-01-19 09:42:24 --> Output Class Initialized
INFO - 2017-01-19 09:42:24 --> Security Class Initialized
DEBUG - 2017-01-19 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:42:24 --> Input Class Initialized
INFO - 2017-01-19 09:42:24 --> Language Class Initialized
INFO - 2017-01-19 09:42:24 --> Loader Class Initialized
INFO - 2017-01-19 09:42:24 --> Helper loaded: url_helper
INFO - 2017-01-19 09:42:24 --> Helper loaded: language_helper
INFO - 2017-01-19 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:42:24 --> Controller Class Initialized
INFO - 2017-01-19 09:42:24 --> Database Driver Class Initialized
INFO - 2017-01-19 09:42:24 --> Model Class Initialized
INFO - 2017-01-19 09:42:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:42:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 09:42:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 09:42:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 09:42:24 --> Final output sent to browser
DEBUG - 2017-01-19 09:42:24 --> Total execution time: 0.1004
INFO - 2017-01-19 09:42:29 --> Config Class Initialized
INFO - 2017-01-19 09:42:29 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:42:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:42:29 --> Utf8 Class Initialized
INFO - 2017-01-19 09:42:29 --> URI Class Initialized
INFO - 2017-01-19 09:42:29 --> Router Class Initialized
INFO - 2017-01-19 09:42:29 --> Output Class Initialized
INFO - 2017-01-19 09:42:29 --> Security Class Initialized
DEBUG - 2017-01-19 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:42:29 --> Input Class Initialized
INFO - 2017-01-19 09:42:29 --> Language Class Initialized
INFO - 2017-01-19 09:42:29 --> Loader Class Initialized
INFO - 2017-01-19 09:42:29 --> Helper loaded: url_helper
INFO - 2017-01-19 09:42:29 --> Helper loaded: language_helper
INFO - 2017-01-19 09:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:42:29 --> Controller Class Initialized
INFO - 2017-01-19 09:42:29 --> Database Driver Class Initialized
INFO - 2017-01-19 09:42:29 --> Model Class Initialized
INFO - 2017-01-19 09:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:42:29 --> Config Class Initialized
INFO - 2017-01-19 09:42:29 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:42:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:42:29 --> Utf8 Class Initialized
INFO - 2017-01-19 09:42:29 --> URI Class Initialized
INFO - 2017-01-19 09:42:29 --> Router Class Initialized
INFO - 2017-01-19 09:42:29 --> Output Class Initialized
INFO - 2017-01-19 09:42:29 --> Security Class Initialized
DEBUG - 2017-01-19 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:42:29 --> Input Class Initialized
INFO - 2017-01-19 09:42:29 --> Language Class Initialized
INFO - 2017-01-19 09:42:29 --> Loader Class Initialized
INFO - 2017-01-19 09:42:29 --> Helper loaded: url_helper
INFO - 2017-01-19 09:42:29 --> Helper loaded: language_helper
INFO - 2017-01-19 09:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:42:29 --> Controller Class Initialized
INFO - 2017-01-19 09:42:29 --> Database Driver Class Initialized
INFO - 2017-01-19 09:42:29 --> Model Class Initialized
INFO - 2017-01-19 09:42:29 --> Model Class Initialized
INFO - 2017-01-19 09:42:29 --> Model Class Initialized
INFO - 2017-01-19 09:42:29 --> Model Class Initialized
INFO - 2017-01-19 09:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 09:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-19 09:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 09:42:29 --> Final output sent to browser
DEBUG - 2017-01-19 09:42:29 --> Total execution time: 0.1552
INFO - 2017-01-19 09:42:32 --> Config Class Initialized
INFO - 2017-01-19 09:42:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:42:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:42:32 --> Utf8 Class Initialized
INFO - 2017-01-19 09:42:32 --> URI Class Initialized
INFO - 2017-01-19 09:42:32 --> Router Class Initialized
INFO - 2017-01-19 09:42:32 --> Output Class Initialized
INFO - 2017-01-19 09:42:32 --> Security Class Initialized
DEBUG - 2017-01-19 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:42:32 --> Input Class Initialized
INFO - 2017-01-19 09:42:32 --> Language Class Initialized
INFO - 2017-01-19 09:42:32 --> Loader Class Initialized
INFO - 2017-01-19 09:42:32 --> Helper loaded: url_helper
INFO - 2017-01-19 09:42:32 --> Helper loaded: language_helper
INFO - 2017-01-19 09:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:42:32 --> Controller Class Initialized
INFO - 2017-01-19 09:42:32 --> Database Driver Class Initialized
INFO - 2017-01-19 09:42:32 --> Model Class Initialized
INFO - 2017-01-19 09:42:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:42:32 --> Helper loaded: form_helper
INFO - 2017-01-19 09:42:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 09:42:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 09:42:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 09:42:32 --> Final output sent to browser
DEBUG - 2017-01-19 09:42:32 --> Total execution time: 0.0987
INFO - 2017-01-19 09:42:34 --> Config Class Initialized
INFO - 2017-01-19 09:42:34 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:42:34 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:42:34 --> Utf8 Class Initialized
INFO - 2017-01-19 09:42:34 --> URI Class Initialized
INFO - 2017-01-19 09:42:34 --> Router Class Initialized
INFO - 2017-01-19 09:42:34 --> Output Class Initialized
INFO - 2017-01-19 09:42:34 --> Security Class Initialized
DEBUG - 2017-01-19 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:42:34 --> Input Class Initialized
INFO - 2017-01-19 09:42:34 --> Language Class Initialized
INFO - 2017-01-19 09:42:34 --> Loader Class Initialized
INFO - 2017-01-19 09:42:34 --> Helper loaded: url_helper
INFO - 2017-01-19 09:42:34 --> Helper loaded: language_helper
INFO - 2017-01-19 09:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:42:34 --> Controller Class Initialized
INFO - 2017-01-19 09:42:34 --> Database Driver Class Initialized
INFO - 2017-01-19 09:42:34 --> Model Class Initialized
INFO - 2017-01-19 09:42:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:42:34 --> Model Class Initialized
INFO - 2017-01-19 09:42:34 --> Model Class Initialized
INFO - 2017-01-19 09:42:34 --> Helper loaded: form_helper
INFO - 2017-01-19 09:42:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 09:42:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 09:42:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 09:42:34 --> Final output sent to browser
DEBUG - 2017-01-19 09:42:34 --> Total execution time: 0.2436
INFO - 2017-01-19 09:43:16 --> Config Class Initialized
INFO - 2017-01-19 09:43:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 09:43:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 09:43:16 --> Utf8 Class Initialized
INFO - 2017-01-19 09:43:16 --> URI Class Initialized
INFO - 2017-01-19 09:43:16 --> Router Class Initialized
INFO - 2017-01-19 09:43:16 --> Output Class Initialized
INFO - 2017-01-19 09:43:16 --> Security Class Initialized
DEBUG - 2017-01-19 09:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 09:43:16 --> Input Class Initialized
INFO - 2017-01-19 09:43:16 --> Language Class Initialized
INFO - 2017-01-19 09:43:16 --> Loader Class Initialized
INFO - 2017-01-19 09:43:16 --> Helper loaded: url_helper
INFO - 2017-01-19 09:43:16 --> Helper loaded: language_helper
INFO - 2017-01-19 09:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 09:43:16 --> Controller Class Initialized
INFO - 2017-01-19 09:43:16 --> Database Driver Class Initialized
INFO - 2017-01-19 09:43:16 --> Model Class Initialized
INFO - 2017-01-19 09:43:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 09:43:16 --> Model Class Initialized
INFO - 2017-01-19 09:43:16 --> Model Class Initialized
INFO - 2017-01-19 09:43:16 --> Helper loaded: form_helper
INFO - 2017-01-19 09:43:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 09:43:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 09:43:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 09:43:16 --> Final output sent to browser
DEBUG - 2017-01-19 09:43:16 --> Total execution time: 0.1582
INFO - 2017-01-19 10:06:23 --> Config Class Initialized
INFO - 2017-01-19 10:06:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:06:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:06:24 --> Utf8 Class Initialized
INFO - 2017-01-19 10:06:24 --> URI Class Initialized
INFO - 2017-01-19 10:06:24 --> Router Class Initialized
INFO - 2017-01-19 10:06:24 --> Output Class Initialized
INFO - 2017-01-19 10:06:24 --> Security Class Initialized
DEBUG - 2017-01-19 10:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:06:24 --> Input Class Initialized
INFO - 2017-01-19 10:06:24 --> Language Class Initialized
INFO - 2017-01-19 10:06:24 --> Loader Class Initialized
INFO - 2017-01-19 10:06:24 --> Helper loaded: url_helper
INFO - 2017-01-19 10:06:24 --> Helper loaded: language_helper
INFO - 2017-01-19 10:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:06:24 --> Controller Class Initialized
INFO - 2017-01-19 10:06:24 --> Database Driver Class Initialized
INFO - 2017-01-19 10:06:24 --> Model Class Initialized
INFO - 2017-01-19 10:06:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:06:24 --> Model Class Initialized
INFO - 2017-01-19 10:06:24 --> Model Class Initialized
INFO - 2017-01-19 10:06:24 --> Helper loaded: form_helper
INFO - 2017-01-19 10:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:06:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:06:24 --> Final output sent to browser
DEBUG - 2017-01-19 10:06:24 --> Total execution time: 0.1899
INFO - 2017-01-19 10:06:28 --> Config Class Initialized
INFO - 2017-01-19 10:06:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:06:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:06:28 --> Utf8 Class Initialized
INFO - 2017-01-19 10:06:28 --> URI Class Initialized
INFO - 2017-01-19 10:06:28 --> Router Class Initialized
INFO - 2017-01-19 10:06:28 --> Output Class Initialized
INFO - 2017-01-19 10:06:28 --> Security Class Initialized
DEBUG - 2017-01-19 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:06:28 --> Input Class Initialized
INFO - 2017-01-19 10:06:28 --> Language Class Initialized
INFO - 2017-01-19 10:06:28 --> Loader Class Initialized
INFO - 2017-01-19 10:06:28 --> Helper loaded: url_helper
INFO - 2017-01-19 10:06:28 --> Helper loaded: language_helper
INFO - 2017-01-19 10:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:06:28 --> Controller Class Initialized
INFO - 2017-01-19 10:06:28 --> Database Driver Class Initialized
INFO - 2017-01-19 10:06:28 --> Model Class Initialized
INFO - 2017-01-19 10:06:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:06:28 --> Helper loaded: form_helper
INFO - 2017-01-19 10:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:06:28 --> Final output sent to browser
DEBUG - 2017-01-19 10:06:28 --> Total execution time: 0.1991
INFO - 2017-01-19 10:15:43 --> Config Class Initialized
INFO - 2017-01-19 10:15:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:15:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:15:43 --> Utf8 Class Initialized
INFO - 2017-01-19 10:15:43 --> URI Class Initialized
INFO - 2017-01-19 10:15:43 --> Router Class Initialized
INFO - 2017-01-19 10:15:43 --> Output Class Initialized
INFO - 2017-01-19 10:15:43 --> Security Class Initialized
DEBUG - 2017-01-19 10:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:15:43 --> Input Class Initialized
INFO - 2017-01-19 10:15:43 --> Language Class Initialized
INFO - 2017-01-19 10:15:43 --> Loader Class Initialized
INFO - 2017-01-19 10:15:43 --> Helper loaded: url_helper
INFO - 2017-01-19 10:15:43 --> Helper loaded: language_helper
INFO - 2017-01-19 10:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:15:43 --> Controller Class Initialized
INFO - 2017-01-19 10:15:43 --> Database Driver Class Initialized
INFO - 2017-01-19 10:15:43 --> Model Class Initialized
INFO - 2017-01-19 10:15:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:15:43 --> Helper loaded: form_helper
INFO - 2017-01-19 10:15:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:15:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:15:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:15:43 --> Final output sent to browser
DEBUG - 2017-01-19 10:15:43 --> Total execution time: 0.1239
INFO - 2017-01-19 10:15:46 --> Config Class Initialized
INFO - 2017-01-19 10:15:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:15:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:15:46 --> Utf8 Class Initialized
INFO - 2017-01-19 10:15:46 --> URI Class Initialized
INFO - 2017-01-19 10:15:46 --> Router Class Initialized
INFO - 2017-01-19 10:15:46 --> Output Class Initialized
INFO - 2017-01-19 10:15:46 --> Security Class Initialized
DEBUG - 2017-01-19 10:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:15:46 --> Input Class Initialized
INFO - 2017-01-19 10:15:46 --> Language Class Initialized
INFO - 2017-01-19 10:15:46 --> Loader Class Initialized
INFO - 2017-01-19 10:15:46 --> Helper loaded: url_helper
INFO - 2017-01-19 10:15:46 --> Helper loaded: language_helper
INFO - 2017-01-19 10:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:15:46 --> Controller Class Initialized
INFO - 2017-01-19 10:15:46 --> Database Driver Class Initialized
INFO - 2017-01-19 10:15:46 --> Model Class Initialized
INFO - 2017-01-19 10:15:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:15:46 --> Model Class Initialized
INFO - 2017-01-19 10:15:46 --> Model Class Initialized
INFO - 2017-01-19 10:15:46 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:15:46 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:15:46 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 247
INFO - 2017-01-19 10:15:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:15:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:15:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:15:47 --> Final output sent to browser
DEBUG - 2017-01-19 10:15:47 --> Total execution time: 0.1955
INFO - 2017-01-19 10:16:21 --> Config Class Initialized
INFO - 2017-01-19 10:16:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:16:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:16:21 --> Utf8 Class Initialized
INFO - 2017-01-19 10:16:21 --> URI Class Initialized
INFO - 2017-01-19 10:16:21 --> Router Class Initialized
INFO - 2017-01-19 10:16:21 --> Output Class Initialized
INFO - 2017-01-19 10:16:21 --> Security Class Initialized
DEBUG - 2017-01-19 10:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:16:21 --> Input Class Initialized
INFO - 2017-01-19 10:16:21 --> Language Class Initialized
INFO - 2017-01-19 10:16:21 --> Loader Class Initialized
INFO - 2017-01-19 10:16:21 --> Helper loaded: url_helper
INFO - 2017-01-19 10:16:21 --> Helper loaded: language_helper
INFO - 2017-01-19 10:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:16:21 --> Controller Class Initialized
INFO - 2017-01-19 10:16:21 --> Database Driver Class Initialized
INFO - 2017-01-19 10:16:21 --> Model Class Initialized
INFO - 2017-01-19 10:16:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:16:21 --> Model Class Initialized
INFO - 2017-01-19 10:16:21 --> Model Class Initialized
INFO - 2017-01-19 10:16:21 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:16:21 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:16:21 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 248
INFO - 2017-01-19 10:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:16:21 --> Final output sent to browser
DEBUG - 2017-01-19 10:16:21 --> Total execution time: 0.2171
INFO - 2017-01-19 10:17:06 --> Config Class Initialized
INFO - 2017-01-19 10:17:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:17:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:17:06 --> Utf8 Class Initialized
INFO - 2017-01-19 10:17:06 --> URI Class Initialized
INFO - 2017-01-19 10:17:06 --> Router Class Initialized
INFO - 2017-01-19 10:17:06 --> Output Class Initialized
INFO - 2017-01-19 10:17:06 --> Security Class Initialized
DEBUG - 2017-01-19 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:17:06 --> Input Class Initialized
INFO - 2017-01-19 10:17:06 --> Language Class Initialized
INFO - 2017-01-19 10:17:06 --> Loader Class Initialized
INFO - 2017-01-19 10:17:06 --> Helper loaded: url_helper
INFO - 2017-01-19 10:17:06 --> Helper loaded: language_helper
INFO - 2017-01-19 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:17:06 --> Controller Class Initialized
INFO - 2017-01-19 10:17:06 --> Database Driver Class Initialized
INFO - 2017-01-19 10:17:06 --> Model Class Initialized
INFO - 2017-01-19 10:17:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:17:06 --> Model Class Initialized
INFO - 2017-01-19 10:17:06 --> Model Class Initialized
INFO - 2017-01-19 10:17:06 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:17:06 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:17:06 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 251
INFO - 2017-01-19 10:17:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:17:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:17:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:17:06 --> Final output sent to browser
DEBUG - 2017-01-19 10:17:06 --> Total execution time: 0.1690
INFO - 2017-01-19 10:17:40 --> Config Class Initialized
INFO - 2017-01-19 10:17:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:17:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:17:40 --> Utf8 Class Initialized
INFO - 2017-01-19 10:17:40 --> URI Class Initialized
INFO - 2017-01-19 10:17:40 --> Router Class Initialized
INFO - 2017-01-19 10:17:40 --> Output Class Initialized
INFO - 2017-01-19 10:17:40 --> Security Class Initialized
DEBUG - 2017-01-19 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:17:40 --> Input Class Initialized
INFO - 2017-01-19 10:17:40 --> Language Class Initialized
INFO - 2017-01-19 10:17:40 --> Loader Class Initialized
INFO - 2017-01-19 10:17:40 --> Helper loaded: url_helper
INFO - 2017-01-19 10:17:40 --> Helper loaded: language_helper
INFO - 2017-01-19 10:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:17:40 --> Controller Class Initialized
INFO - 2017-01-19 10:17:40 --> Database Driver Class Initialized
INFO - 2017-01-19 10:17:40 --> Model Class Initialized
INFO - 2017-01-19 10:17:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:17:40 --> Model Class Initialized
INFO - 2017-01-19 10:17:40 --> Model Class Initialized
INFO - 2017-01-19 10:17:40 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:17:40 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:17:40 --> Severity: Notice --> Undefined variable: var_dump C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 251
ERROR - 2017-01-19 10:17:40 --> Severity: Error --> Function name must be a string C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 251
INFO - 2017-01-19 10:18:09 --> Config Class Initialized
INFO - 2017-01-19 10:18:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:18:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:18:09 --> Utf8 Class Initialized
INFO - 2017-01-19 10:18:09 --> URI Class Initialized
INFO - 2017-01-19 10:18:09 --> Router Class Initialized
INFO - 2017-01-19 10:18:09 --> Output Class Initialized
INFO - 2017-01-19 10:18:09 --> Security Class Initialized
DEBUG - 2017-01-19 10:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:18:09 --> Input Class Initialized
INFO - 2017-01-19 10:18:09 --> Language Class Initialized
INFO - 2017-01-19 10:18:09 --> Loader Class Initialized
INFO - 2017-01-19 10:18:09 --> Helper loaded: url_helper
INFO - 2017-01-19 10:18:09 --> Helper loaded: language_helper
INFO - 2017-01-19 10:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:18:09 --> Controller Class Initialized
INFO - 2017-01-19 10:18:09 --> Database Driver Class Initialized
INFO - 2017-01-19 10:18:09 --> Model Class Initialized
INFO - 2017-01-19 10:18:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:18:09 --> Model Class Initialized
INFO - 2017-01-19 10:18:09 --> Model Class Initialized
INFO - 2017-01-19 10:18:09 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:18:09 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:18:09 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:18:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:18:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:18:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:18:09 --> Final output sent to browser
DEBUG - 2017-01-19 10:18:09 --> Total execution time: 0.1967
INFO - 2017-01-19 10:18:32 --> Config Class Initialized
INFO - 2017-01-19 10:18:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:18:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:18:32 --> Utf8 Class Initialized
INFO - 2017-01-19 10:18:32 --> URI Class Initialized
INFO - 2017-01-19 10:18:32 --> Router Class Initialized
INFO - 2017-01-19 10:18:32 --> Output Class Initialized
INFO - 2017-01-19 10:18:32 --> Security Class Initialized
DEBUG - 2017-01-19 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:18:32 --> Input Class Initialized
INFO - 2017-01-19 10:18:32 --> Language Class Initialized
INFO - 2017-01-19 10:18:32 --> Loader Class Initialized
INFO - 2017-01-19 10:18:32 --> Helper loaded: url_helper
INFO - 2017-01-19 10:18:32 --> Helper loaded: language_helper
INFO - 2017-01-19 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:18:32 --> Controller Class Initialized
INFO - 2017-01-19 10:18:32 --> Database Driver Class Initialized
INFO - 2017-01-19 10:18:32 --> Model Class Initialized
INFO - 2017-01-19 10:18:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:18:32 --> Model Class Initialized
INFO - 2017-01-19 10:18:32 --> Model Class Initialized
INFO - 2017-01-19 10:18:32 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:18:32 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:18:32 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:18:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:18:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:18:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:18:32 --> Final output sent to browser
DEBUG - 2017-01-19 10:18:32 --> Total execution time: 0.1902
INFO - 2017-01-19 10:18:46 --> Config Class Initialized
INFO - 2017-01-19 10:18:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:18:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:18:46 --> Utf8 Class Initialized
INFO - 2017-01-19 10:18:46 --> URI Class Initialized
INFO - 2017-01-19 10:18:46 --> Router Class Initialized
INFO - 2017-01-19 10:18:46 --> Output Class Initialized
INFO - 2017-01-19 10:18:46 --> Security Class Initialized
DEBUG - 2017-01-19 10:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:18:46 --> Input Class Initialized
INFO - 2017-01-19 10:18:46 --> Language Class Initialized
INFO - 2017-01-19 10:18:46 --> Loader Class Initialized
INFO - 2017-01-19 10:18:46 --> Helper loaded: url_helper
INFO - 2017-01-19 10:18:46 --> Helper loaded: language_helper
INFO - 2017-01-19 10:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:18:46 --> Controller Class Initialized
INFO - 2017-01-19 10:18:46 --> Database Driver Class Initialized
INFO - 2017-01-19 10:18:46 --> Model Class Initialized
INFO - 2017-01-19 10:18:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:18:46 --> Model Class Initialized
INFO - 2017-01-19 10:18:46 --> Model Class Initialized
INFO - 2017-01-19 10:18:46 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:18:46 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:18:46 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:18:46 --> Final output sent to browser
DEBUG - 2017-01-19 10:18:46 --> Total execution time: 0.1836
INFO - 2017-01-19 10:19:06 --> Config Class Initialized
INFO - 2017-01-19 10:19:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:19:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:19:06 --> Utf8 Class Initialized
INFO - 2017-01-19 10:19:06 --> URI Class Initialized
INFO - 2017-01-19 10:19:06 --> Router Class Initialized
INFO - 2017-01-19 10:19:06 --> Output Class Initialized
INFO - 2017-01-19 10:19:06 --> Security Class Initialized
DEBUG - 2017-01-19 10:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:19:06 --> Input Class Initialized
INFO - 2017-01-19 10:19:06 --> Language Class Initialized
INFO - 2017-01-19 10:19:06 --> Loader Class Initialized
INFO - 2017-01-19 10:19:06 --> Helper loaded: url_helper
INFO - 2017-01-19 10:19:06 --> Helper loaded: language_helper
INFO - 2017-01-19 10:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:19:06 --> Controller Class Initialized
INFO - 2017-01-19 10:19:07 --> Database Driver Class Initialized
INFO - 2017-01-19 10:19:07 --> Model Class Initialized
INFO - 2017-01-19 10:19:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:19:07 --> Model Class Initialized
INFO - 2017-01-19 10:19:07 --> Model Class Initialized
INFO - 2017-01-19 10:19:07 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:19:07 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:19:07 --> Severity: Notice --> Undefined variable: var_dump C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 251
ERROR - 2017-01-19 10:19:07 --> Severity: Error --> Function name must be a string C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 251
INFO - 2017-01-19 10:19:39 --> Config Class Initialized
INFO - 2017-01-19 10:19:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:19:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:19:39 --> Utf8 Class Initialized
INFO - 2017-01-19 10:19:39 --> URI Class Initialized
INFO - 2017-01-19 10:19:39 --> Router Class Initialized
INFO - 2017-01-19 10:19:39 --> Output Class Initialized
INFO - 2017-01-19 10:19:39 --> Security Class Initialized
DEBUG - 2017-01-19 10:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:19:39 --> Input Class Initialized
INFO - 2017-01-19 10:19:39 --> Language Class Initialized
INFO - 2017-01-19 10:19:39 --> Loader Class Initialized
INFO - 2017-01-19 10:19:39 --> Helper loaded: url_helper
INFO - 2017-01-19 10:19:39 --> Helper loaded: language_helper
INFO - 2017-01-19 10:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:19:39 --> Controller Class Initialized
INFO - 2017-01-19 10:19:39 --> Database Driver Class Initialized
INFO - 2017-01-19 10:19:39 --> Model Class Initialized
INFO - 2017-01-19 10:19:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:19:39 --> Model Class Initialized
INFO - 2017-01-19 10:19:39 --> Model Class Initialized
INFO - 2017-01-19 10:19:39 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:19:39 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:19:39 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:19:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:19:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:19:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:19:39 --> Final output sent to browser
DEBUG - 2017-01-19 10:19:39 --> Total execution time: 0.1697
INFO - 2017-01-19 10:20:38 --> Config Class Initialized
INFO - 2017-01-19 10:20:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:20:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:20:38 --> Utf8 Class Initialized
INFO - 2017-01-19 10:20:38 --> URI Class Initialized
INFO - 2017-01-19 10:20:38 --> Router Class Initialized
INFO - 2017-01-19 10:20:38 --> Output Class Initialized
INFO - 2017-01-19 10:20:38 --> Security Class Initialized
DEBUG - 2017-01-19 10:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:20:38 --> Input Class Initialized
INFO - 2017-01-19 10:20:38 --> Language Class Initialized
INFO - 2017-01-19 10:20:38 --> Loader Class Initialized
INFO - 2017-01-19 10:20:38 --> Helper loaded: url_helper
INFO - 2017-01-19 10:20:38 --> Helper loaded: language_helper
INFO - 2017-01-19 10:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:20:38 --> Controller Class Initialized
INFO - 2017-01-19 10:20:38 --> Database Driver Class Initialized
INFO - 2017-01-19 10:20:38 --> Model Class Initialized
INFO - 2017-01-19 10:20:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:20:38 --> Model Class Initialized
INFO - 2017-01-19 10:20:38 --> Model Class Initialized
INFO - 2017-01-19 10:20:38 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:20:38 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:20:38 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:20:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:20:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:20:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:20:38 --> Final output sent to browser
DEBUG - 2017-01-19 10:20:38 --> Total execution time: 0.1767
INFO - 2017-01-19 10:21:01 --> Config Class Initialized
INFO - 2017-01-19 10:21:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:21:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:21:01 --> Utf8 Class Initialized
INFO - 2017-01-19 10:21:01 --> URI Class Initialized
INFO - 2017-01-19 10:21:01 --> Router Class Initialized
INFO - 2017-01-19 10:21:01 --> Output Class Initialized
INFO - 2017-01-19 10:21:01 --> Security Class Initialized
DEBUG - 2017-01-19 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:21:01 --> Input Class Initialized
INFO - 2017-01-19 10:21:01 --> Language Class Initialized
INFO - 2017-01-19 10:21:01 --> Loader Class Initialized
INFO - 2017-01-19 10:21:01 --> Helper loaded: url_helper
INFO - 2017-01-19 10:21:01 --> Helper loaded: language_helper
INFO - 2017-01-19 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:21:01 --> Controller Class Initialized
INFO - 2017-01-19 10:21:02 --> Database Driver Class Initialized
INFO - 2017-01-19 10:21:02 --> Model Class Initialized
INFO - 2017-01-19 10:21:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:21:02 --> Model Class Initialized
INFO - 2017-01-19 10:21:02 --> Model Class Initialized
INFO - 2017-01-19 10:21:02 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:21:02 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:21:02 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:21:02 --> Final output sent to browser
DEBUG - 2017-01-19 10:21:02 --> Total execution time: 0.2932
INFO - 2017-01-19 10:21:43 --> Config Class Initialized
INFO - 2017-01-19 10:21:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:21:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:21:43 --> Utf8 Class Initialized
INFO - 2017-01-19 10:21:43 --> URI Class Initialized
INFO - 2017-01-19 10:21:43 --> Router Class Initialized
INFO - 2017-01-19 10:21:43 --> Output Class Initialized
INFO - 2017-01-19 10:21:43 --> Security Class Initialized
DEBUG - 2017-01-19 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:21:43 --> Input Class Initialized
INFO - 2017-01-19 10:21:43 --> Language Class Initialized
INFO - 2017-01-19 10:21:43 --> Loader Class Initialized
INFO - 2017-01-19 10:21:43 --> Helper loaded: url_helper
INFO - 2017-01-19 10:21:43 --> Helper loaded: language_helper
INFO - 2017-01-19 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:21:43 --> Controller Class Initialized
INFO - 2017-01-19 10:21:43 --> Database Driver Class Initialized
INFO - 2017-01-19 10:21:43 --> Model Class Initialized
INFO - 2017-01-19 10:21:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:21:43 --> Model Class Initialized
INFO - 2017-01-19 10:21:43 --> Model Class Initialized
INFO - 2017-01-19 10:21:43 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:21:43 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:21:43 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:21:43 --> Final output sent to browser
DEBUG - 2017-01-19 10:21:43 --> Total execution time: 0.2432
INFO - 2017-01-19 10:22:14 --> Config Class Initialized
INFO - 2017-01-19 10:22:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:14 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:14 --> URI Class Initialized
INFO - 2017-01-19 10:22:14 --> Router Class Initialized
INFO - 2017-01-19 10:22:14 --> Output Class Initialized
INFO - 2017-01-19 10:22:14 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:14 --> Input Class Initialized
INFO - 2017-01-19 10:22:14 --> Language Class Initialized
INFO - 2017-01-19 10:22:15 --> Loader Class Initialized
INFO - 2017-01-19 10:22:15 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:15 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:15 --> Controller Class Initialized
INFO - 2017-01-19 10:22:15 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:15 --> Model Class Initialized
INFO - 2017-01-19 10:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:15 --> Model Class Initialized
INFO - 2017-01-19 10:22:15 --> Model Class Initialized
INFO - 2017-01-19 10:22:15 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:22:15 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:22:15 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:15 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:15 --> Total execution time: 0.2658
INFO - 2017-01-19 10:22:26 --> Config Class Initialized
INFO - 2017-01-19 10:22:26 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:26 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:26 --> URI Class Initialized
INFO - 2017-01-19 10:22:26 --> Router Class Initialized
INFO - 2017-01-19 10:22:26 --> Output Class Initialized
INFO - 2017-01-19 10:22:26 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:26 --> Input Class Initialized
INFO - 2017-01-19 10:22:26 --> Language Class Initialized
INFO - 2017-01-19 10:22:26 --> Loader Class Initialized
INFO - 2017-01-19 10:22:26 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:26 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:26 --> Controller Class Initialized
INFO - 2017-01-19 10:22:26 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:26 --> Model Class Initialized
INFO - 2017-01-19 10:22:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:26 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:26 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:26 --> Total execution time: 0.1303
INFO - 2017-01-19 10:22:28 --> Config Class Initialized
INFO - 2017-01-19 10:22:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:28 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:28 --> URI Class Initialized
INFO - 2017-01-19 10:22:28 --> Router Class Initialized
INFO - 2017-01-19 10:22:28 --> Output Class Initialized
INFO - 2017-01-19 10:22:28 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:28 --> Input Class Initialized
INFO - 2017-01-19 10:22:28 --> Language Class Initialized
INFO - 2017-01-19 10:22:28 --> Loader Class Initialized
INFO - 2017-01-19 10:22:28 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:28 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:28 --> Controller Class Initialized
INFO - 2017-01-19 10:22:28 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:28 --> Model Class Initialized
INFO - 2017-01-19 10:22:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:28 --> Model Class Initialized
INFO - 2017-01-19 10:22:28 --> Model Class Initialized
INFO - 2017-01-19 10:22:28 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:28 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:28 --> Total execution time: 0.2577
INFO - 2017-01-19 10:22:36 --> Config Class Initialized
INFO - 2017-01-19 10:22:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:36 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:36 --> URI Class Initialized
INFO - 2017-01-19 10:22:36 --> Router Class Initialized
INFO - 2017-01-19 10:22:36 --> Output Class Initialized
INFO - 2017-01-19 10:22:36 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:36 --> Input Class Initialized
INFO - 2017-01-19 10:22:36 --> Language Class Initialized
INFO - 2017-01-19 10:22:36 --> Loader Class Initialized
INFO - 2017-01-19 10:22:36 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:36 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:36 --> Controller Class Initialized
INFO - 2017-01-19 10:22:36 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:36 --> Model Class Initialized
INFO - 2017-01-19 10:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:36 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:36 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:36 --> Total execution time: 0.1032
INFO - 2017-01-19 10:22:38 --> Config Class Initialized
INFO - 2017-01-19 10:22:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:38 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:38 --> URI Class Initialized
INFO - 2017-01-19 10:22:38 --> Router Class Initialized
INFO - 2017-01-19 10:22:38 --> Output Class Initialized
INFO - 2017-01-19 10:22:38 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:38 --> Input Class Initialized
INFO - 2017-01-19 10:22:38 --> Language Class Initialized
INFO - 2017-01-19 10:22:38 --> Loader Class Initialized
INFO - 2017-01-19 10:22:38 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:38 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:38 --> Controller Class Initialized
INFO - 2017-01-19 10:22:38 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:38 --> Model Class Initialized
INFO - 2017-01-19 10:22:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:38 --> Model Class Initialized
INFO - 2017-01-19 10:22:38 --> Model Class Initialized
INFO - 2017-01-19 10:22:38 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:38 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:38 --> Total execution time: 0.2602
INFO - 2017-01-19 10:22:40 --> Config Class Initialized
INFO - 2017-01-19 10:22:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:40 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:40 --> URI Class Initialized
INFO - 2017-01-19 10:22:40 --> Router Class Initialized
INFO - 2017-01-19 10:22:40 --> Output Class Initialized
INFO - 2017-01-19 10:22:40 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:40 --> Input Class Initialized
INFO - 2017-01-19 10:22:40 --> Language Class Initialized
INFO - 2017-01-19 10:22:40 --> Loader Class Initialized
INFO - 2017-01-19 10:22:40 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:40 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:40 --> Controller Class Initialized
INFO - 2017-01-19 10:22:40 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:40 --> Model Class Initialized
INFO - 2017-01-19 10:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:40 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:40 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:40 --> Total execution time: 0.1140
INFO - 2017-01-19 10:22:43 --> Config Class Initialized
INFO - 2017-01-19 10:22:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:43 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:43 --> URI Class Initialized
INFO - 2017-01-19 10:22:43 --> Router Class Initialized
INFO - 2017-01-19 10:22:43 --> Output Class Initialized
INFO - 2017-01-19 10:22:43 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:43 --> Input Class Initialized
INFO - 2017-01-19 10:22:43 --> Language Class Initialized
INFO - 2017-01-19 10:22:43 --> Loader Class Initialized
INFO - 2017-01-19 10:22:43 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:43 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:43 --> Controller Class Initialized
INFO - 2017-01-19 10:22:43 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:43 --> Model Class Initialized
INFO - 2017-01-19 10:22:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:43 --> Model Class Initialized
INFO - 2017-01-19 10:22:43 --> Model Class Initialized
INFO - 2017-01-19 10:22:43 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:43 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:43 --> Total execution time: 0.2364
INFO - 2017-01-19 10:22:45 --> Config Class Initialized
INFO - 2017-01-19 10:22:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:45 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:45 --> URI Class Initialized
INFO - 2017-01-19 10:22:45 --> Router Class Initialized
INFO - 2017-01-19 10:22:45 --> Output Class Initialized
INFO - 2017-01-19 10:22:45 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:45 --> Input Class Initialized
INFO - 2017-01-19 10:22:45 --> Language Class Initialized
INFO - 2017-01-19 10:22:45 --> Loader Class Initialized
INFO - 2017-01-19 10:22:45 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:45 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:45 --> Controller Class Initialized
INFO - 2017-01-19 10:22:45 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:45 --> Model Class Initialized
INFO - 2017-01-19 10:22:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:45 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:45 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:45 --> Total execution time: 0.1695
INFO - 2017-01-19 10:22:46 --> Config Class Initialized
INFO - 2017-01-19 10:22:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:46 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:46 --> URI Class Initialized
INFO - 2017-01-19 10:22:46 --> Router Class Initialized
INFO - 2017-01-19 10:22:46 --> Output Class Initialized
INFO - 2017-01-19 10:22:46 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:46 --> Input Class Initialized
INFO - 2017-01-19 10:22:46 --> Language Class Initialized
INFO - 2017-01-19 10:22:46 --> Loader Class Initialized
INFO - 2017-01-19 10:22:46 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:46 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:46 --> Controller Class Initialized
INFO - 2017-01-19 10:22:46 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:46 --> Model Class Initialized
INFO - 2017-01-19 10:22:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:46 --> Model Class Initialized
INFO - 2017-01-19 10:22:46 --> Model Class Initialized
INFO - 2017-01-19 10:22:46 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:47 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:47 --> Total execution time: 0.2078
INFO - 2017-01-19 10:22:48 --> Config Class Initialized
INFO - 2017-01-19 10:22:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:48 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:48 --> URI Class Initialized
INFO - 2017-01-19 10:22:49 --> Router Class Initialized
INFO - 2017-01-19 10:22:49 --> Output Class Initialized
INFO - 2017-01-19 10:22:49 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:49 --> Input Class Initialized
INFO - 2017-01-19 10:22:49 --> Language Class Initialized
INFO - 2017-01-19 10:22:49 --> Loader Class Initialized
INFO - 2017-01-19 10:22:49 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:49 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:49 --> Controller Class Initialized
INFO - 2017-01-19 10:22:49 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:49 --> Model Class Initialized
INFO - 2017-01-19 10:22:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:49 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:49 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:49 --> Total execution time: 0.1549
INFO - 2017-01-19 10:22:51 --> Config Class Initialized
INFO - 2017-01-19 10:22:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:51 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:51 --> URI Class Initialized
INFO - 2017-01-19 10:22:51 --> Router Class Initialized
INFO - 2017-01-19 10:22:51 --> Output Class Initialized
INFO - 2017-01-19 10:22:51 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:51 --> Input Class Initialized
INFO - 2017-01-19 10:22:51 --> Language Class Initialized
INFO - 2017-01-19 10:22:51 --> Loader Class Initialized
INFO - 2017-01-19 10:22:51 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:51 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:51 --> Controller Class Initialized
INFO - 2017-01-19 10:22:51 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:51 --> Model Class Initialized
INFO - 2017-01-19 10:22:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:51 --> Model Class Initialized
INFO - 2017-01-19 10:22:51 --> Model Class Initialized
INFO - 2017-01-19 10:22:51 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:51 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:51 --> Total execution time: 0.2779
INFO - 2017-01-19 10:22:53 --> Config Class Initialized
INFO - 2017-01-19 10:22:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:53 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:53 --> URI Class Initialized
INFO - 2017-01-19 10:22:53 --> Router Class Initialized
INFO - 2017-01-19 10:22:53 --> Output Class Initialized
INFO - 2017-01-19 10:22:53 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:53 --> Input Class Initialized
INFO - 2017-01-19 10:22:53 --> Language Class Initialized
INFO - 2017-01-19 10:22:53 --> Loader Class Initialized
INFO - 2017-01-19 10:22:53 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:53 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:53 --> Controller Class Initialized
INFO - 2017-01-19 10:22:53 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:53 --> Model Class Initialized
INFO - 2017-01-19 10:22:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:53 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:53 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:53 --> Total execution time: 0.1496
INFO - 2017-01-19 10:22:54 --> Config Class Initialized
INFO - 2017-01-19 10:22:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:54 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:54 --> URI Class Initialized
INFO - 2017-01-19 10:22:54 --> Router Class Initialized
INFO - 2017-01-19 10:22:54 --> Output Class Initialized
INFO - 2017-01-19 10:22:54 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:54 --> Input Class Initialized
INFO - 2017-01-19 10:22:54 --> Language Class Initialized
INFO - 2017-01-19 10:22:54 --> Loader Class Initialized
INFO - 2017-01-19 10:22:54 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:54 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:54 --> Controller Class Initialized
INFO - 2017-01-19 10:22:54 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:54 --> Model Class Initialized
INFO - 2017-01-19 10:22:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:54 --> Model Class Initialized
INFO - 2017-01-19 10:22:54 --> Model Class Initialized
INFO - 2017-01-19 10:22:54 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:54 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:54 --> Total execution time: 0.1905
INFO - 2017-01-19 10:22:56 --> Config Class Initialized
INFO - 2017-01-19 10:22:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:56 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:56 --> URI Class Initialized
INFO - 2017-01-19 10:22:56 --> Router Class Initialized
INFO - 2017-01-19 10:22:56 --> Output Class Initialized
INFO - 2017-01-19 10:22:56 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:56 --> Input Class Initialized
INFO - 2017-01-19 10:22:56 --> Language Class Initialized
INFO - 2017-01-19 10:22:56 --> Loader Class Initialized
INFO - 2017-01-19 10:22:56 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:56 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:56 --> Controller Class Initialized
INFO - 2017-01-19 10:22:56 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:56 --> Model Class Initialized
INFO - 2017-01-19 10:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:56 --> Helper loaded: form_helper
INFO - 2017-01-19 10:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 10:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:56 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:56 --> Total execution time: 0.1317
INFO - 2017-01-19 10:22:59 --> Config Class Initialized
INFO - 2017-01-19 10:22:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:22:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:22:59 --> Utf8 Class Initialized
INFO - 2017-01-19 10:22:59 --> URI Class Initialized
INFO - 2017-01-19 10:22:59 --> Router Class Initialized
INFO - 2017-01-19 10:22:59 --> Output Class Initialized
INFO - 2017-01-19 10:22:59 --> Security Class Initialized
DEBUG - 2017-01-19 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:22:59 --> Input Class Initialized
INFO - 2017-01-19 10:22:59 --> Language Class Initialized
INFO - 2017-01-19 10:22:59 --> Loader Class Initialized
INFO - 2017-01-19 10:22:59 --> Helper loaded: url_helper
INFO - 2017-01-19 10:22:59 --> Helper loaded: language_helper
INFO - 2017-01-19 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:22:59 --> Controller Class Initialized
INFO - 2017-01-19 10:22:59 --> Database Driver Class Initialized
INFO - 2017-01-19 10:22:59 --> Model Class Initialized
INFO - 2017-01-19 10:22:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:22:59 --> Model Class Initialized
INFO - 2017-01-19 10:22:59 --> Model Class Initialized
INFO - 2017-01-19 10:22:59 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:22:59 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 193
ERROR - 2017-01-19 10:22:59 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 253
INFO - 2017-01-19 10:22:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:22:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:22:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:22:59 --> Final output sent to browser
DEBUG - 2017-01-19 10:22:59 --> Total execution time: 0.2137
INFO - 2017-01-19 10:25:36 --> Config Class Initialized
INFO - 2017-01-19 10:25:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:25:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:25:36 --> Utf8 Class Initialized
INFO - 2017-01-19 10:25:36 --> URI Class Initialized
INFO - 2017-01-19 10:25:36 --> Router Class Initialized
INFO - 2017-01-19 10:25:36 --> Output Class Initialized
INFO - 2017-01-19 10:25:36 --> Security Class Initialized
DEBUG - 2017-01-19 10:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:25:36 --> Input Class Initialized
INFO - 2017-01-19 10:25:36 --> Language Class Initialized
INFO - 2017-01-19 10:25:36 --> Loader Class Initialized
INFO - 2017-01-19 10:25:36 --> Helper loaded: url_helper
INFO - 2017-01-19 10:25:36 --> Helper loaded: language_helper
INFO - 2017-01-19 10:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:25:36 --> Controller Class Initialized
INFO - 2017-01-19 10:25:36 --> Database Driver Class Initialized
INFO - 2017-01-19 10:25:36 --> Model Class Initialized
INFO - 2017-01-19 10:25:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:25:36 --> Model Class Initialized
INFO - 2017-01-19 10:25:36 --> Model Class Initialized
INFO - 2017-01-19 10:25:36 --> Helper loaded: form_helper
INFO - 2017-01-19 10:25:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:25:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:25:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:25:36 --> Final output sent to browser
DEBUG - 2017-01-19 10:25:36 --> Total execution time: 0.1781
INFO - 2017-01-19 10:26:30 --> Config Class Initialized
INFO - 2017-01-19 10:26:30 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:26:30 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:26:30 --> Utf8 Class Initialized
INFO - 2017-01-19 10:26:30 --> URI Class Initialized
INFO - 2017-01-19 10:26:30 --> Router Class Initialized
INFO - 2017-01-19 10:26:30 --> Output Class Initialized
INFO - 2017-01-19 10:26:30 --> Security Class Initialized
DEBUG - 2017-01-19 10:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:26:30 --> Input Class Initialized
INFO - 2017-01-19 10:26:30 --> Language Class Initialized
INFO - 2017-01-19 10:26:30 --> Loader Class Initialized
INFO - 2017-01-19 10:26:30 --> Helper loaded: url_helper
INFO - 2017-01-19 10:26:30 --> Helper loaded: language_helper
INFO - 2017-01-19 10:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:26:30 --> Controller Class Initialized
INFO - 2017-01-19 10:26:30 --> Database Driver Class Initialized
INFO - 2017-01-19 10:26:30 --> Model Class Initialized
INFO - 2017-01-19 10:26:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:26:30 --> Model Class Initialized
INFO - 2017-01-19 10:26:30 --> Model Class Initialized
INFO - 2017-01-19 10:26:30 --> Helper loaded: form_helper
INFO - 2017-01-19 10:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:26:30 --> Final output sent to browser
DEBUG - 2017-01-19 10:26:30 --> Total execution time: 0.1695
INFO - 2017-01-19 10:27:17 --> Config Class Initialized
INFO - 2017-01-19 10:27:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:27:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:27:17 --> Utf8 Class Initialized
INFO - 2017-01-19 10:27:17 --> URI Class Initialized
INFO - 2017-01-19 10:27:17 --> Router Class Initialized
INFO - 2017-01-19 10:27:17 --> Output Class Initialized
INFO - 2017-01-19 10:27:17 --> Security Class Initialized
DEBUG - 2017-01-19 10:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:27:17 --> Input Class Initialized
INFO - 2017-01-19 10:27:17 --> Language Class Initialized
INFO - 2017-01-19 10:27:17 --> Loader Class Initialized
INFO - 2017-01-19 10:27:17 --> Helper loaded: url_helper
INFO - 2017-01-19 10:27:17 --> Helper loaded: language_helper
INFO - 2017-01-19 10:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:27:17 --> Controller Class Initialized
INFO - 2017-01-19 10:27:17 --> Database Driver Class Initialized
INFO - 2017-01-19 10:27:17 --> Model Class Initialized
INFO - 2017-01-19 10:27:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:27:17 --> Model Class Initialized
INFO - 2017-01-19 10:27:17 --> Model Class Initialized
INFO - 2017-01-19 10:27:17 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:27:17 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 194
ERROR - 2017-01-19 10:27:17 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 249
INFO - 2017-01-19 10:27:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:27:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:27:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:27:17 --> Final output sent to browser
DEBUG - 2017-01-19 10:27:17 --> Total execution time: 0.1957
INFO - 2017-01-19 10:28:38 --> Config Class Initialized
INFO - 2017-01-19 10:28:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:28:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:28:38 --> Utf8 Class Initialized
INFO - 2017-01-19 10:28:38 --> URI Class Initialized
INFO - 2017-01-19 10:28:38 --> Router Class Initialized
INFO - 2017-01-19 10:28:38 --> Output Class Initialized
INFO - 2017-01-19 10:28:38 --> Security Class Initialized
DEBUG - 2017-01-19 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:28:38 --> Input Class Initialized
INFO - 2017-01-19 10:28:38 --> Language Class Initialized
INFO - 2017-01-19 10:28:38 --> Loader Class Initialized
INFO - 2017-01-19 10:28:38 --> Helper loaded: url_helper
INFO - 2017-01-19 10:28:38 --> Helper loaded: language_helper
INFO - 2017-01-19 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:28:38 --> Controller Class Initialized
INFO - 2017-01-19 10:28:38 --> Database Driver Class Initialized
INFO - 2017-01-19 10:28:38 --> Model Class Initialized
INFO - 2017-01-19 10:28:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:28:38 --> Model Class Initialized
INFO - 2017-01-19 10:28:38 --> Model Class Initialized
INFO - 2017-01-19 10:28:38 --> Helper loaded: form_helper
ERROR - 2017-01-19 10:28:38 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 195
ERROR - 2017-01-19 10:28:38 --> Severity: Warning --> array_merge(): Argument #3 is not an array C:\wamp64\www\savsoftquiz\application\models\Norma_model.php 250
INFO - 2017-01-19 10:28:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:28:39 --> Final output sent to browser
DEBUG - 2017-01-19 10:28:39 --> Total execution time: 0.1767
INFO - 2017-01-19 10:38:05 --> Config Class Initialized
INFO - 2017-01-19 10:38:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:38:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:38:05 --> Utf8 Class Initialized
INFO - 2017-01-19 10:38:05 --> URI Class Initialized
INFO - 2017-01-19 10:38:05 --> Router Class Initialized
INFO - 2017-01-19 10:38:05 --> Output Class Initialized
INFO - 2017-01-19 10:38:05 --> Security Class Initialized
DEBUG - 2017-01-19 10:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:38:05 --> Input Class Initialized
INFO - 2017-01-19 10:38:05 --> Language Class Initialized
INFO - 2017-01-19 10:38:05 --> Loader Class Initialized
INFO - 2017-01-19 10:38:05 --> Helper loaded: url_helper
INFO - 2017-01-19 10:38:05 --> Helper loaded: language_helper
INFO - 2017-01-19 10:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:38:05 --> Controller Class Initialized
INFO - 2017-01-19 10:38:05 --> Database Driver Class Initialized
INFO - 2017-01-19 10:38:05 --> Model Class Initialized
INFO - 2017-01-19 10:38:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:38:05 --> Model Class Initialized
INFO - 2017-01-19 10:38:05 --> Model Class Initialized
INFO - 2017-01-19 10:38:05 --> Helper loaded: form_helper
INFO - 2017-01-19 10:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:38:05 --> Final output sent to browser
DEBUG - 2017-01-19 10:38:05 --> Total execution time: 0.1688
INFO - 2017-01-19 10:57:05 --> Config Class Initialized
INFO - 2017-01-19 10:57:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:57:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:57:05 --> Utf8 Class Initialized
INFO - 2017-01-19 10:57:05 --> URI Class Initialized
INFO - 2017-01-19 10:57:05 --> Router Class Initialized
INFO - 2017-01-19 10:57:05 --> Output Class Initialized
INFO - 2017-01-19 10:57:05 --> Security Class Initialized
DEBUG - 2017-01-19 10:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:57:05 --> Input Class Initialized
INFO - 2017-01-19 10:57:05 --> Language Class Initialized
INFO - 2017-01-19 10:57:05 --> Loader Class Initialized
INFO - 2017-01-19 10:57:05 --> Helper loaded: url_helper
INFO - 2017-01-19 10:57:05 --> Helper loaded: language_helper
INFO - 2017-01-19 10:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:57:05 --> Controller Class Initialized
INFO - 2017-01-19 10:57:05 --> Database Driver Class Initialized
INFO - 2017-01-19 10:57:05 --> Model Class Initialized
INFO - 2017-01-19 10:57:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:57:05 --> Model Class Initialized
INFO - 2017-01-19 10:57:05 --> Model Class Initialized
INFO - 2017-01-19 10:57:05 --> Helper loaded: form_helper
INFO - 2017-01-19 10:57:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 10:57:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-19 10:57:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:57:06 --> Final output sent to browser
DEBUG - 2017-01-19 10:57:06 --> Total execution time: 0.1690
INFO - 2017-01-19 10:57:09 --> Config Class Initialized
INFO - 2017-01-19 10:57:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 10:57:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 10:57:09 --> Utf8 Class Initialized
INFO - 2017-01-19 10:57:09 --> URI Class Initialized
INFO - 2017-01-19 10:57:09 --> Router Class Initialized
INFO - 2017-01-19 10:57:09 --> Output Class Initialized
INFO - 2017-01-19 10:57:09 --> Security Class Initialized
DEBUG - 2017-01-19 10:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 10:57:09 --> Input Class Initialized
INFO - 2017-01-19 10:57:09 --> Language Class Initialized
INFO - 2017-01-19 10:57:09 --> Loader Class Initialized
INFO - 2017-01-19 10:57:09 --> Helper loaded: url_helper
INFO - 2017-01-19 10:57:09 --> Helper loaded: language_helper
INFO - 2017-01-19 10:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 10:57:09 --> Controller Class Initialized
INFO - 2017-01-19 10:57:09 --> Database Driver Class Initialized
INFO - 2017-01-19 10:57:09 --> Model Class Initialized
INFO - 2017-01-19 10:57:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 10:57:09 --> Helper loaded: form_helper
INFO - 2017-01-19 10:57:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 10:57:09 --> Could not find the language line "import_user"
INFO - 2017-01-19 10:57:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 10:57:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 10:57:09 --> Final output sent to browser
DEBUG - 2017-01-19 10:57:09 --> Total execution time: 0.1357
INFO - 2017-01-19 11:00:00 --> Config Class Initialized
INFO - 2017-01-19 11:00:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:00:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:00:00 --> Utf8 Class Initialized
INFO - 2017-01-19 11:00:00 --> URI Class Initialized
INFO - 2017-01-19 11:00:00 --> Router Class Initialized
INFO - 2017-01-19 11:00:00 --> Output Class Initialized
INFO - 2017-01-19 11:00:00 --> Security Class Initialized
DEBUG - 2017-01-19 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:00:00 --> Input Class Initialized
INFO - 2017-01-19 11:00:00 --> Language Class Initialized
INFO - 2017-01-19 11:00:00 --> Loader Class Initialized
INFO - 2017-01-19 11:00:00 --> Helper loaded: url_helper
INFO - 2017-01-19 11:00:00 --> Helper loaded: language_helper
INFO - 2017-01-19 11:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:00:00 --> Controller Class Initialized
INFO - 2017-01-19 11:00:00 --> Database Driver Class Initialized
INFO - 2017-01-19 11:00:00 --> Model Class Initialized
INFO - 2017-01-19 11:00:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:00:00 --> Helper loaded: form_helper
INFO - 2017-01-19 11:00:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:00:00 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:00:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:00:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:00:00 --> Final output sent to browser
DEBUG - 2017-01-19 11:00:00 --> Total execution time: 0.1033
INFO - 2017-01-19 11:10:14 --> Config Class Initialized
INFO - 2017-01-19 11:10:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:10:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:10:14 --> Utf8 Class Initialized
INFO - 2017-01-19 11:10:14 --> URI Class Initialized
INFO - 2017-01-19 11:10:14 --> Router Class Initialized
INFO - 2017-01-19 11:10:14 --> Output Class Initialized
INFO - 2017-01-19 11:10:14 --> Security Class Initialized
DEBUG - 2017-01-19 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:10:14 --> Input Class Initialized
INFO - 2017-01-19 11:10:14 --> Language Class Initialized
INFO - 2017-01-19 11:10:14 --> Loader Class Initialized
INFO - 2017-01-19 11:10:14 --> Helper loaded: url_helper
INFO - 2017-01-19 11:10:14 --> Helper loaded: language_helper
INFO - 2017-01-19 11:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:10:14 --> Controller Class Initialized
INFO - 2017-01-19 11:10:14 --> Database Driver Class Initialized
INFO - 2017-01-19 11:10:14 --> Model Class Initialized
INFO - 2017-01-19 11:10:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:10:14 --> Helper loaded: form_helper
INFO - 2017-01-19 11:10:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:10:14 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:10:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:10:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:10:14 --> Final output sent to browser
DEBUG - 2017-01-19 11:10:14 --> Total execution time: 0.1110
INFO - 2017-01-19 11:10:19 --> Config Class Initialized
INFO - 2017-01-19 11:10:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:10:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:10:19 --> Utf8 Class Initialized
INFO - 2017-01-19 11:10:19 --> URI Class Initialized
INFO - 2017-01-19 11:10:19 --> Router Class Initialized
INFO - 2017-01-19 11:10:19 --> Output Class Initialized
INFO - 2017-01-19 11:10:19 --> Security Class Initialized
DEBUG - 2017-01-19 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:10:19 --> Input Class Initialized
INFO - 2017-01-19 11:10:19 --> Language Class Initialized
INFO - 2017-01-19 11:10:19 --> Loader Class Initialized
INFO - 2017-01-19 11:10:19 --> Helper loaded: url_helper
INFO - 2017-01-19 11:10:19 --> Helper loaded: language_helper
INFO - 2017-01-19 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:10:19 --> Controller Class Initialized
INFO - 2017-01-19 11:10:19 --> Database Driver Class Initialized
INFO - 2017-01-19 11:10:19 --> Model Class Initialized
INFO - 2017-01-19 11:10:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:10:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:17:13 --> Config Class Initialized
INFO - 2017-01-19 11:17:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:17:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:17:13 --> Utf8 Class Initialized
INFO - 2017-01-19 11:17:13 --> URI Class Initialized
INFO - 2017-01-19 11:17:13 --> Router Class Initialized
INFO - 2017-01-19 11:17:13 --> Output Class Initialized
INFO - 2017-01-19 11:17:13 --> Security Class Initialized
DEBUG - 2017-01-19 11:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:17:13 --> Input Class Initialized
INFO - 2017-01-19 11:17:13 --> Language Class Initialized
INFO - 2017-01-19 11:17:13 --> Loader Class Initialized
INFO - 2017-01-19 11:17:13 --> Helper loaded: url_helper
INFO - 2017-01-19 11:17:13 --> Helper loaded: language_helper
INFO - 2017-01-19 11:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:17:13 --> Controller Class Initialized
INFO - 2017-01-19 11:17:13 --> Database Driver Class Initialized
INFO - 2017-01-19 11:17:13 --> Model Class Initialized
INFO - 2017-01-19 11:17:13 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:17:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:03 --> Config Class Initialized
INFO - 2017-01-19 11:18:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:03 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:03 --> URI Class Initialized
INFO - 2017-01-19 11:18:03 --> Router Class Initialized
INFO - 2017-01-19 11:18:03 --> Output Class Initialized
INFO - 2017-01-19 11:18:03 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:03 --> Input Class Initialized
INFO - 2017-01-19 11:18:03 --> Language Class Initialized
INFO - 2017-01-19 11:18:03 --> Loader Class Initialized
INFO - 2017-01-19 11:18:03 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:03 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:03 --> Controller Class Initialized
INFO - 2017-01-19 11:18:03 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:03 --> Model Class Initialized
INFO - 2017-01-19 11:18:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:33 --> Config Class Initialized
INFO - 2017-01-19 11:18:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:33 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:33 --> URI Class Initialized
INFO - 2017-01-19 11:18:33 --> Router Class Initialized
INFO - 2017-01-19 11:18:33 --> Output Class Initialized
INFO - 2017-01-19 11:18:33 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:33 --> Input Class Initialized
INFO - 2017-01-19 11:18:33 --> Language Class Initialized
INFO - 2017-01-19 11:18:33 --> Loader Class Initialized
INFO - 2017-01-19 11:18:33 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:33 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:33 --> Controller Class Initialized
INFO - 2017-01-19 11:18:33 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:33 --> Model Class Initialized
INFO - 2017-01-19 11:18:33 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:35 --> Config Class Initialized
INFO - 2017-01-19 11:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:35 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:35 --> URI Class Initialized
INFO - 2017-01-19 11:18:35 --> Router Class Initialized
INFO - 2017-01-19 11:18:35 --> Output Class Initialized
INFO - 2017-01-19 11:18:35 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:35 --> Input Class Initialized
INFO - 2017-01-19 11:18:35 --> Language Class Initialized
INFO - 2017-01-19 11:18:35 --> Loader Class Initialized
INFO - 2017-01-19 11:18:35 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:35 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:35 --> Controller Class Initialized
INFO - 2017-01-19 11:18:35 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:35 --> Model Class Initialized
INFO - 2017-01-19 11:18:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:35 --> Config Class Initialized
INFO - 2017-01-19 11:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:35 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:35 --> URI Class Initialized
INFO - 2017-01-19 11:18:35 --> Router Class Initialized
INFO - 2017-01-19 11:18:35 --> Output Class Initialized
INFO - 2017-01-19 11:18:35 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:35 --> Input Class Initialized
INFO - 2017-01-19 11:18:35 --> Language Class Initialized
INFO - 2017-01-19 11:18:35 --> Loader Class Initialized
INFO - 2017-01-19 11:18:35 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:35 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:35 --> Controller Class Initialized
INFO - 2017-01-19 11:18:35 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:35 --> Model Class Initialized
INFO - 2017-01-19 11:18:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:35 --> Config Class Initialized
INFO - 2017-01-19 11:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:35 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:35 --> URI Class Initialized
INFO - 2017-01-19 11:18:35 --> Router Class Initialized
INFO - 2017-01-19 11:18:35 --> Output Class Initialized
INFO - 2017-01-19 11:18:35 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:35 --> Input Class Initialized
INFO - 2017-01-19 11:18:35 --> Language Class Initialized
INFO - 2017-01-19 11:18:35 --> Loader Class Initialized
INFO - 2017-01-19 11:18:35 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:35 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:35 --> Controller Class Initialized
INFO - 2017-01-19 11:18:35 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:35 --> Model Class Initialized
INFO - 2017-01-19 11:18:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:39 --> Config Class Initialized
INFO - 2017-01-19 11:18:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:39 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:39 --> URI Class Initialized
INFO - 2017-01-19 11:18:39 --> Router Class Initialized
INFO - 2017-01-19 11:18:39 --> Output Class Initialized
INFO - 2017-01-19 11:18:39 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:39 --> Input Class Initialized
INFO - 2017-01-19 11:18:39 --> Language Class Initialized
INFO - 2017-01-19 11:18:39 --> Loader Class Initialized
INFO - 2017-01-19 11:18:39 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:39 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:39 --> Controller Class Initialized
INFO - 2017-01-19 11:18:39 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:39 --> Model Class Initialized
INFO - 2017-01-19 11:18:39 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:40 --> Config Class Initialized
INFO - 2017-01-19 11:18:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:40 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:40 --> URI Class Initialized
INFO - 2017-01-19 11:18:40 --> Router Class Initialized
INFO - 2017-01-19 11:18:40 --> Output Class Initialized
INFO - 2017-01-19 11:18:40 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:40 --> Input Class Initialized
INFO - 2017-01-19 11:18:40 --> Language Class Initialized
INFO - 2017-01-19 11:18:40 --> Loader Class Initialized
INFO - 2017-01-19 11:18:40 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:40 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:40 --> Controller Class Initialized
INFO - 2017-01-19 11:18:40 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:40 --> Model Class Initialized
INFO - 2017-01-19 11:18:40 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Disc_answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:18:58 --> Config Class Initialized
INFO - 2017-01-19 11:18:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:18:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:18:58 --> Utf8 Class Initialized
INFO - 2017-01-19 11:18:58 --> URI Class Initialized
INFO - 2017-01-19 11:18:58 --> Router Class Initialized
INFO - 2017-01-19 11:18:58 --> Output Class Initialized
INFO - 2017-01-19 11:18:58 --> Security Class Initialized
DEBUG - 2017-01-19 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:18:58 --> Input Class Initialized
INFO - 2017-01-19 11:18:58 --> Language Class Initialized
INFO - 2017-01-19 11:18:58 --> Loader Class Initialized
INFO - 2017-01-19 11:18:58 --> Helper loaded: url_helper
INFO - 2017-01-19 11:18:58 --> Helper loaded: language_helper
INFO - 2017-01-19 11:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:18:58 --> Controller Class Initialized
INFO - 2017-01-19 11:18:58 --> Database Driver Class Initialized
INFO - 2017-01-19 11:18:58 --> Model Class Initialized
INFO - 2017-01-19 11:18:58 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:18:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Answers C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:19:41 --> Config Class Initialized
INFO - 2017-01-19 11:19:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:19:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:19:41 --> Utf8 Class Initialized
INFO - 2017-01-19 11:19:41 --> URI Class Initialized
INFO - 2017-01-19 11:19:41 --> Router Class Initialized
INFO - 2017-01-19 11:19:41 --> Output Class Initialized
INFO - 2017-01-19 11:19:41 --> Security Class Initialized
DEBUG - 2017-01-19 11:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:19:41 --> Input Class Initialized
INFO - 2017-01-19 11:19:41 --> Language Class Initialized
INFO - 2017-01-19 11:19:41 --> Loader Class Initialized
INFO - 2017-01-19 11:19:41 --> Helper loaded: url_helper
INFO - 2017-01-19 11:19:41 --> Helper loaded: language_helper
INFO - 2017-01-19 11:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:19:41 --> Controller Class Initialized
INFO - 2017-01-19 11:19:41 --> Database Driver Class Initialized
INFO - 2017-01-19 11:19:41 --> Model Class Initialized
INFO - 2017-01-19 11:19:41 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:19:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Result C:\wamp64\www\savsoftquiz\system\core\Loader.php 344
INFO - 2017-01-19 11:25:50 --> Config Class Initialized
INFO - 2017-01-19 11:25:50 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:25:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:25:50 --> Utf8 Class Initialized
INFO - 2017-01-19 11:25:50 --> URI Class Initialized
INFO - 2017-01-19 11:25:50 --> Router Class Initialized
INFO - 2017-01-19 11:25:50 --> Output Class Initialized
INFO - 2017-01-19 11:25:50 --> Security Class Initialized
DEBUG - 2017-01-19 11:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:25:50 --> Input Class Initialized
INFO - 2017-01-19 11:25:50 --> Language Class Initialized
INFO - 2017-01-19 11:25:50 --> Loader Class Initialized
INFO - 2017-01-19 11:25:50 --> Helper loaded: url_helper
INFO - 2017-01-19 11:25:50 --> Helper loaded: language_helper
INFO - 2017-01-19 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:25:50 --> Controller Class Initialized
INFO - 2017-01-19 11:25:50 --> Database Driver Class Initialized
INFO - 2017-01-19 11:25:50 --> Model Class Initialized
INFO - 2017-01-19 11:25:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:25:50 --> Helper loaded: form_helper
INFO - 2017-01-19 11:25:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:25:50 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:25:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:25:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:25:50 --> Final output sent to browser
DEBUG - 2017-01-19 11:25:50 --> Total execution time: 0.1184
INFO - 2017-01-19 11:25:54 --> Config Class Initialized
INFO - 2017-01-19 11:25:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:25:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:25:54 --> Utf8 Class Initialized
INFO - 2017-01-19 11:25:54 --> URI Class Initialized
INFO - 2017-01-19 11:25:54 --> Router Class Initialized
INFO - 2017-01-19 11:25:54 --> Output Class Initialized
INFO - 2017-01-19 11:25:54 --> Security Class Initialized
DEBUG - 2017-01-19 11:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:25:54 --> Input Class Initialized
INFO - 2017-01-19 11:25:54 --> Language Class Initialized
INFO - 2017-01-19 11:25:54 --> Loader Class Initialized
INFO - 2017-01-19 11:25:54 --> Helper loaded: url_helper
INFO - 2017-01-19 11:25:54 --> Helper loaded: language_helper
INFO - 2017-01-19 11:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:25:54 --> Controller Class Initialized
INFO - 2017-01-19 11:25:54 --> Database Driver Class Initialized
INFO - 2017-01-19 11:25:54 --> Model Class Initialized
INFO - 2017-01-19 11:25:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:25:54 --> Helper loaded: form_helper
INFO - 2017-01-19 11:25:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:25:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 11:25:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:25:54 --> Final output sent to browser
DEBUG - 2017-01-19 11:25:54 --> Total execution time: 0.1445
INFO - 2017-01-19 11:26:14 --> Config Class Initialized
INFO - 2017-01-19 11:26:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:26:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:26:14 --> Utf8 Class Initialized
INFO - 2017-01-19 11:26:14 --> URI Class Initialized
INFO - 2017-01-19 11:26:14 --> Router Class Initialized
INFO - 2017-01-19 11:26:14 --> Output Class Initialized
INFO - 2017-01-19 11:26:14 --> Security Class Initialized
DEBUG - 2017-01-19 11:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:26:14 --> Input Class Initialized
INFO - 2017-01-19 11:26:14 --> Language Class Initialized
INFO - 2017-01-19 11:26:14 --> Loader Class Initialized
INFO - 2017-01-19 11:26:14 --> Helper loaded: url_helper
INFO - 2017-01-19 11:26:14 --> Helper loaded: language_helper
INFO - 2017-01-19 11:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:26:14 --> Controller Class Initialized
INFO - 2017-01-19 11:26:14 --> Database Driver Class Initialized
INFO - 2017-01-19 11:26:14 --> Model Class Initialized
INFO - 2017-01-19 11:26:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:26:14 --> Helper loaded: form_helper
INFO - 2017-01-19 11:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:26:14 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:26:14 --> Final output sent to browser
DEBUG - 2017-01-19 11:26:14 --> Total execution time: 0.1254
INFO - 2017-01-19 11:26:57 --> Config Class Initialized
INFO - 2017-01-19 11:26:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:26:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:26:57 --> Utf8 Class Initialized
INFO - 2017-01-19 11:26:57 --> URI Class Initialized
INFO - 2017-01-19 11:26:57 --> Router Class Initialized
INFO - 2017-01-19 11:26:57 --> Output Class Initialized
INFO - 2017-01-19 11:26:57 --> Security Class Initialized
DEBUG - 2017-01-19 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:26:57 --> Input Class Initialized
INFO - 2017-01-19 11:26:57 --> Language Class Initialized
INFO - 2017-01-19 11:26:57 --> Loader Class Initialized
INFO - 2017-01-19 11:26:57 --> Helper loaded: url_helper
INFO - 2017-01-19 11:26:57 --> Helper loaded: language_helper
INFO - 2017-01-19 11:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:26:57 --> Controller Class Initialized
INFO - 2017-01-19 11:26:57 --> Database Driver Class Initialized
INFO - 2017-01-19 11:26:57 --> Model Class Initialized
INFO - 2017-01-19 11:26:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:26:57 --> Config Class Initialized
INFO - 2017-01-19 11:26:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:26:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:26:57 --> Utf8 Class Initialized
INFO - 2017-01-19 11:26:57 --> URI Class Initialized
INFO - 2017-01-19 11:26:57 --> Router Class Initialized
INFO - 2017-01-19 11:26:57 --> Output Class Initialized
INFO - 2017-01-19 11:26:57 --> Security Class Initialized
DEBUG - 2017-01-19 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:26:57 --> Input Class Initialized
INFO - 2017-01-19 11:26:57 --> Language Class Initialized
INFO - 2017-01-19 11:26:57 --> Loader Class Initialized
INFO - 2017-01-19 11:26:57 --> Helper loaded: url_helper
INFO - 2017-01-19 11:26:57 --> Helper loaded: language_helper
INFO - 2017-01-19 11:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:26:57 --> Controller Class Initialized
INFO - 2017-01-19 11:26:57 --> Database Driver Class Initialized
INFO - 2017-01-19 11:26:57 --> Model Class Initialized
INFO - 2017-01-19 11:26:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:26:57 --> Helper loaded: form_helper
INFO - 2017-01-19 11:26:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:26:57 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:26:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:26:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:26:57 --> Final output sent to browser
DEBUG - 2017-01-19 11:26:57 --> Total execution time: 0.1056
INFO - 2017-01-19 11:28:09 --> Config Class Initialized
INFO - 2017-01-19 11:28:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:28:09 --> Utf8 Class Initialized
INFO - 2017-01-19 11:28:09 --> URI Class Initialized
INFO - 2017-01-19 11:28:09 --> Router Class Initialized
INFO - 2017-01-19 11:28:09 --> Output Class Initialized
INFO - 2017-01-19 11:28:09 --> Security Class Initialized
DEBUG - 2017-01-19 11:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:28:09 --> Input Class Initialized
INFO - 2017-01-19 11:28:09 --> Language Class Initialized
INFO - 2017-01-19 11:28:09 --> Loader Class Initialized
INFO - 2017-01-19 11:28:09 --> Helper loaded: url_helper
INFO - 2017-01-19 11:28:09 --> Helper loaded: language_helper
INFO - 2017-01-19 11:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:28:09 --> Controller Class Initialized
INFO - 2017-01-19 11:28:09 --> Database Driver Class Initialized
INFO - 2017-01-19 11:28:09 --> Model Class Initialized
INFO - 2017-01-19 11:28:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:28:09 --> Config Class Initialized
INFO - 2017-01-19 11:28:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:28:09 --> Utf8 Class Initialized
INFO - 2017-01-19 11:28:09 --> URI Class Initialized
INFO - 2017-01-19 11:28:09 --> Router Class Initialized
INFO - 2017-01-19 11:28:09 --> Output Class Initialized
INFO - 2017-01-19 11:28:09 --> Security Class Initialized
DEBUG - 2017-01-19 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:28:10 --> Input Class Initialized
INFO - 2017-01-19 11:28:10 --> Language Class Initialized
INFO - 2017-01-19 11:28:10 --> Loader Class Initialized
INFO - 2017-01-19 11:28:10 --> Helper loaded: url_helper
INFO - 2017-01-19 11:28:10 --> Helper loaded: language_helper
INFO - 2017-01-19 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:28:10 --> Controller Class Initialized
INFO - 2017-01-19 11:28:10 --> Database Driver Class Initialized
INFO - 2017-01-19 11:28:10 --> Model Class Initialized
INFO - 2017-01-19 11:28:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:28:10 --> Helper loaded: form_helper
INFO - 2017-01-19 11:28:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:28:10 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:28:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:28:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:28:10 --> Final output sent to browser
DEBUG - 2017-01-19 11:28:10 --> Total execution time: 0.1142
INFO - 2017-01-19 11:29:04 --> Config Class Initialized
INFO - 2017-01-19 11:29:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:29:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:29:04 --> Utf8 Class Initialized
INFO - 2017-01-19 11:29:04 --> URI Class Initialized
INFO - 2017-01-19 11:29:04 --> Router Class Initialized
INFO - 2017-01-19 11:29:04 --> Output Class Initialized
INFO - 2017-01-19 11:29:04 --> Security Class Initialized
DEBUG - 2017-01-19 11:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:29:04 --> Input Class Initialized
INFO - 2017-01-19 11:29:04 --> Language Class Initialized
INFO - 2017-01-19 11:29:04 --> Loader Class Initialized
INFO - 2017-01-19 11:29:04 --> Helper loaded: url_helper
INFO - 2017-01-19 11:29:04 --> Helper loaded: language_helper
INFO - 2017-01-19 11:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:29:04 --> Controller Class Initialized
INFO - 2017-01-19 11:29:04 --> Database Driver Class Initialized
INFO - 2017-01-19 11:29:04 --> Model Class Initialized
INFO - 2017-01-19 11:29:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:29:04 --> Helper loaded: form_helper
INFO - 2017-01-19 11:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:29:04 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:29:04 --> Final output sent to browser
DEBUG - 2017-01-19 11:29:04 --> Total execution time: 0.1051
INFO - 2017-01-19 11:29:07 --> Config Class Initialized
INFO - 2017-01-19 11:29:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:29:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:29:07 --> Utf8 Class Initialized
INFO - 2017-01-19 11:29:07 --> URI Class Initialized
INFO - 2017-01-19 11:29:07 --> Router Class Initialized
INFO - 2017-01-19 11:29:07 --> Output Class Initialized
INFO - 2017-01-19 11:29:08 --> Security Class Initialized
DEBUG - 2017-01-19 11:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:29:08 --> Input Class Initialized
INFO - 2017-01-19 11:29:08 --> Language Class Initialized
INFO - 2017-01-19 11:29:08 --> Loader Class Initialized
INFO - 2017-01-19 11:29:08 --> Helper loaded: url_helper
INFO - 2017-01-19 11:29:08 --> Helper loaded: language_helper
INFO - 2017-01-19 11:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:29:08 --> Controller Class Initialized
INFO - 2017-01-19 11:29:08 --> Database Driver Class Initialized
INFO - 2017-01-19 11:29:08 --> Model Class Initialized
INFO - 2017-01-19 11:29:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:29:08 --> Config Class Initialized
INFO - 2017-01-19 11:29:08 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:29:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:29:08 --> Utf8 Class Initialized
INFO - 2017-01-19 11:29:08 --> URI Class Initialized
INFO - 2017-01-19 11:29:08 --> Router Class Initialized
INFO - 2017-01-19 11:29:08 --> Output Class Initialized
INFO - 2017-01-19 11:29:08 --> Security Class Initialized
DEBUG - 2017-01-19 11:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:29:08 --> Input Class Initialized
INFO - 2017-01-19 11:29:08 --> Language Class Initialized
INFO - 2017-01-19 11:29:08 --> Loader Class Initialized
INFO - 2017-01-19 11:29:08 --> Helper loaded: url_helper
INFO - 2017-01-19 11:29:08 --> Helper loaded: language_helper
INFO - 2017-01-19 11:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:29:08 --> Controller Class Initialized
INFO - 2017-01-19 11:29:08 --> Database Driver Class Initialized
INFO - 2017-01-19 11:29:08 --> Model Class Initialized
INFO - 2017-01-19 11:29:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:29:08 --> Helper loaded: form_helper
INFO - 2017-01-19 11:29:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:29:08 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:29:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:29:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:29:08 --> Final output sent to browser
DEBUG - 2017-01-19 11:29:08 --> Total execution time: 0.1028
INFO - 2017-01-19 11:29:45 --> Config Class Initialized
INFO - 2017-01-19 11:29:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:29:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:29:45 --> Utf8 Class Initialized
INFO - 2017-01-19 11:29:45 --> URI Class Initialized
INFO - 2017-01-19 11:29:45 --> Router Class Initialized
INFO - 2017-01-19 11:29:45 --> Output Class Initialized
INFO - 2017-01-19 11:29:45 --> Security Class Initialized
DEBUG - 2017-01-19 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:29:45 --> Input Class Initialized
INFO - 2017-01-19 11:29:45 --> Language Class Initialized
INFO - 2017-01-19 11:29:45 --> Loader Class Initialized
INFO - 2017-01-19 11:29:45 --> Helper loaded: url_helper
INFO - 2017-01-19 11:29:45 --> Helper loaded: language_helper
INFO - 2017-01-19 11:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:29:45 --> Controller Class Initialized
INFO - 2017-01-19 11:29:45 --> Database Driver Class Initialized
INFO - 2017-01-19 11:29:45 --> Model Class Initialized
INFO - 2017-01-19 11:29:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:29:45 --> Helper loaded: form_helper
INFO - 2017-01-19 11:29:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:29:45 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:29:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:29:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:29:45 --> Final output sent to browser
DEBUG - 2017-01-19 11:29:45 --> Total execution time: 0.1860
INFO - 2017-01-19 11:29:49 --> Config Class Initialized
INFO - 2017-01-19 11:29:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:29:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:29:49 --> Utf8 Class Initialized
INFO - 2017-01-19 11:29:49 --> URI Class Initialized
INFO - 2017-01-19 11:29:49 --> Router Class Initialized
INFO - 2017-01-19 11:29:49 --> Output Class Initialized
INFO - 2017-01-19 11:29:49 --> Security Class Initialized
DEBUG - 2017-01-19 11:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:29:49 --> Input Class Initialized
INFO - 2017-01-19 11:29:49 --> Language Class Initialized
INFO - 2017-01-19 11:29:49 --> Loader Class Initialized
INFO - 2017-01-19 11:29:49 --> Helper loaded: url_helper
INFO - 2017-01-19 11:29:49 --> Helper loaded: language_helper
INFO - 2017-01-19 11:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:29:49 --> Controller Class Initialized
INFO - 2017-01-19 11:29:49 --> Database Driver Class Initialized
INFO - 2017-01-19 11:29:49 --> Model Class Initialized
INFO - 2017-01-19 11:29:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:29:49 --> Config Class Initialized
INFO - 2017-01-19 11:29:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:29:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:29:49 --> Utf8 Class Initialized
INFO - 2017-01-19 11:29:49 --> URI Class Initialized
INFO - 2017-01-19 11:29:49 --> Router Class Initialized
INFO - 2017-01-19 11:29:49 --> Output Class Initialized
INFO - 2017-01-19 11:29:49 --> Security Class Initialized
DEBUG - 2017-01-19 11:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:29:49 --> Input Class Initialized
INFO - 2017-01-19 11:29:49 --> Language Class Initialized
INFO - 2017-01-19 11:29:49 --> Loader Class Initialized
INFO - 2017-01-19 11:29:49 --> Helper loaded: url_helper
INFO - 2017-01-19 11:29:49 --> Helper loaded: language_helper
INFO - 2017-01-19 11:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:29:49 --> Controller Class Initialized
INFO - 2017-01-19 11:29:49 --> Database Driver Class Initialized
INFO - 2017-01-19 11:29:49 --> Model Class Initialized
INFO - 2017-01-19 11:29:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:29:49 --> Helper loaded: form_helper
INFO - 2017-01-19 11:29:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:29:49 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:29:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:29:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:29:49 --> Final output sent to browser
DEBUG - 2017-01-19 11:29:49 --> Total execution time: 0.1121
INFO - 2017-01-19 11:30:32 --> Config Class Initialized
INFO - 2017-01-19 11:30:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:30:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:30:32 --> Utf8 Class Initialized
INFO - 2017-01-19 11:30:32 --> URI Class Initialized
INFO - 2017-01-19 11:30:32 --> Router Class Initialized
INFO - 2017-01-19 11:30:32 --> Output Class Initialized
INFO - 2017-01-19 11:30:32 --> Security Class Initialized
DEBUG - 2017-01-19 11:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:30:32 --> Input Class Initialized
INFO - 2017-01-19 11:30:32 --> Language Class Initialized
INFO - 2017-01-19 11:30:32 --> Loader Class Initialized
INFO - 2017-01-19 11:30:32 --> Helper loaded: url_helper
INFO - 2017-01-19 11:30:32 --> Helper loaded: language_helper
INFO - 2017-01-19 11:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:30:32 --> Controller Class Initialized
INFO - 2017-01-19 11:30:32 --> Database Driver Class Initialized
INFO - 2017-01-19 11:30:32 --> Model Class Initialized
INFO - 2017-01-19 11:30:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:30:32 --> Helper loaded: form_helper
INFO - 2017-01-19 11:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 11:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:30:32 --> Final output sent to browser
DEBUG - 2017-01-19 11:30:32 --> Total execution time: 0.1254
INFO - 2017-01-19 11:31:24 --> Config Class Initialized
INFO - 2017-01-19 11:31:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:31:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:31:24 --> Utf8 Class Initialized
INFO - 2017-01-19 11:31:24 --> URI Class Initialized
INFO - 2017-01-19 11:31:24 --> Router Class Initialized
INFO - 2017-01-19 11:31:24 --> Output Class Initialized
INFO - 2017-01-19 11:31:24 --> Security Class Initialized
DEBUG - 2017-01-19 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:31:24 --> Input Class Initialized
INFO - 2017-01-19 11:31:24 --> Language Class Initialized
INFO - 2017-01-19 11:31:24 --> Loader Class Initialized
INFO - 2017-01-19 11:31:24 --> Helper loaded: url_helper
INFO - 2017-01-19 11:31:24 --> Helper loaded: language_helper
INFO - 2017-01-19 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:31:24 --> Controller Class Initialized
INFO - 2017-01-19 11:31:24 --> Database Driver Class Initialized
INFO - 2017-01-19 11:31:24 --> Model Class Initialized
INFO - 2017-01-19 11:31:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:31:24 --> Helper loaded: form_helper
INFO - 2017-01-19 11:31:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:31:24 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:31:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:31:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:31:24 --> Final output sent to browser
DEBUG - 2017-01-19 11:31:24 --> Total execution time: 0.1068
INFO - 2017-01-19 11:31:40 --> Config Class Initialized
INFO - 2017-01-19 11:31:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:31:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:31:40 --> Utf8 Class Initialized
INFO - 2017-01-19 11:31:40 --> URI Class Initialized
INFO - 2017-01-19 11:31:40 --> Router Class Initialized
INFO - 2017-01-19 11:31:40 --> Output Class Initialized
INFO - 2017-01-19 11:31:40 --> Security Class Initialized
DEBUG - 2017-01-19 11:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:31:40 --> Input Class Initialized
INFO - 2017-01-19 11:31:40 --> Language Class Initialized
INFO - 2017-01-19 11:31:40 --> Loader Class Initialized
INFO - 2017-01-19 11:31:40 --> Helper loaded: url_helper
INFO - 2017-01-19 11:31:40 --> Helper loaded: language_helper
INFO - 2017-01-19 11:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:31:40 --> Controller Class Initialized
INFO - 2017-01-19 11:31:40 --> Database Driver Class Initialized
INFO - 2017-01-19 11:31:40 --> Model Class Initialized
INFO - 2017-01-19 11:31:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:31:40 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-19 11:32:12 --> Config Class Initialized
INFO - 2017-01-19 11:32:12 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:32:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:32:12 --> Utf8 Class Initialized
INFO - 2017-01-19 11:32:12 --> URI Class Initialized
INFO - 2017-01-19 11:32:12 --> Router Class Initialized
INFO - 2017-01-19 11:32:12 --> Output Class Initialized
INFO - 2017-01-19 11:32:12 --> Security Class Initialized
DEBUG - 2017-01-19 11:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:32:12 --> Input Class Initialized
INFO - 2017-01-19 11:32:12 --> Language Class Initialized
INFO - 2017-01-19 11:32:12 --> Loader Class Initialized
INFO - 2017-01-19 11:32:12 --> Helper loaded: url_helper
INFO - 2017-01-19 11:32:12 --> Helper loaded: language_helper
INFO - 2017-01-19 11:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:32:12 --> Controller Class Initialized
INFO - 2017-01-19 11:32:12 --> Database Driver Class Initialized
INFO - 2017-01-19 11:32:12 --> Model Class Initialized
INFO - 2017-01-19 11:32:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:32:12 --> Helper loaded: form_helper
INFO - 2017-01-19 11:32:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:32:12 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:32:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:32:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:32:12 --> Final output sent to browser
DEBUG - 2017-01-19 11:32:12 --> Total execution time: 0.1329
INFO - 2017-01-19 11:32:17 --> Config Class Initialized
INFO - 2017-01-19 11:32:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:32:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:32:17 --> Utf8 Class Initialized
INFO - 2017-01-19 11:32:17 --> URI Class Initialized
INFO - 2017-01-19 11:32:17 --> Router Class Initialized
INFO - 2017-01-19 11:32:17 --> Output Class Initialized
INFO - 2017-01-19 11:32:17 --> Security Class Initialized
DEBUG - 2017-01-19 11:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:32:17 --> Input Class Initialized
INFO - 2017-01-19 11:32:17 --> Language Class Initialized
INFO - 2017-01-19 11:32:17 --> Loader Class Initialized
INFO - 2017-01-19 11:32:17 --> Helper loaded: url_helper
INFO - 2017-01-19 11:32:17 --> Helper loaded: language_helper
INFO - 2017-01-19 11:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:32:17 --> Controller Class Initialized
INFO - 2017-01-19 11:32:17 --> Database Driver Class Initialized
INFO - 2017-01-19 11:32:17 --> Model Class Initialized
INFO - 2017-01-19 11:32:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:32:17 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-19 11:35:39 --> Config Class Initialized
INFO - 2017-01-19 11:35:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:35:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:35:39 --> Utf8 Class Initialized
INFO - 2017-01-19 11:35:39 --> URI Class Initialized
INFO - 2017-01-19 11:35:39 --> Router Class Initialized
INFO - 2017-01-19 11:35:39 --> Output Class Initialized
INFO - 2017-01-19 11:35:39 --> Security Class Initialized
DEBUG - 2017-01-19 11:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:35:39 --> Input Class Initialized
INFO - 2017-01-19 11:35:39 --> Language Class Initialized
INFO - 2017-01-19 11:35:39 --> Loader Class Initialized
INFO - 2017-01-19 11:35:39 --> Helper loaded: url_helper
INFO - 2017-01-19 11:35:39 --> Helper loaded: language_helper
INFO - 2017-01-19 11:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:35:39 --> Controller Class Initialized
INFO - 2017-01-19 11:35:39 --> Database Driver Class Initialized
INFO - 2017-01-19 11:35:39 --> Model Class Initialized
INFO - 2017-01-19 11:35:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:35:39 --> Helper loaded: form_helper
INFO - 2017-01-19 11:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:35:39 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:35:39 --> Final output sent to browser
DEBUG - 2017-01-19 11:35:39 --> Total execution time: 0.1367
INFO - 2017-01-19 11:35:44 --> Config Class Initialized
INFO - 2017-01-19 11:35:44 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:35:44 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:35:44 --> Utf8 Class Initialized
INFO - 2017-01-19 11:35:44 --> URI Class Initialized
INFO - 2017-01-19 11:35:44 --> Router Class Initialized
INFO - 2017-01-19 11:35:44 --> Output Class Initialized
INFO - 2017-01-19 11:35:44 --> Security Class Initialized
DEBUG - 2017-01-19 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:35:44 --> Input Class Initialized
INFO - 2017-01-19 11:35:44 --> Language Class Initialized
INFO - 2017-01-19 11:35:44 --> Loader Class Initialized
INFO - 2017-01-19 11:35:44 --> Helper loaded: url_helper
INFO - 2017-01-19 11:35:44 --> Helper loaded: language_helper
INFO - 2017-01-19 11:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:35:44 --> Controller Class Initialized
INFO - 2017-01-19 11:35:44 --> Database Driver Class Initialized
INFO - 2017-01-19 11:35:44 --> Model Class Initialized
INFO - 2017-01-19 11:35:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:35:44 --> Config Class Initialized
INFO - 2017-01-19 11:35:44 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:35:44 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:35:44 --> Utf8 Class Initialized
INFO - 2017-01-19 11:35:44 --> URI Class Initialized
INFO - 2017-01-19 11:35:44 --> Router Class Initialized
INFO - 2017-01-19 11:35:44 --> Output Class Initialized
INFO - 2017-01-19 11:35:44 --> Security Class Initialized
DEBUG - 2017-01-19 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:35:44 --> Input Class Initialized
INFO - 2017-01-19 11:35:44 --> Language Class Initialized
INFO - 2017-01-19 11:35:44 --> Loader Class Initialized
INFO - 2017-01-19 11:35:44 --> Helper loaded: url_helper
INFO - 2017-01-19 11:35:44 --> Helper loaded: language_helper
INFO - 2017-01-19 11:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:35:44 --> Controller Class Initialized
INFO - 2017-01-19 11:35:44 --> Database Driver Class Initialized
INFO - 2017-01-19 11:35:44 --> Model Class Initialized
INFO - 2017-01-19 11:35:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:35:44 --> Helper loaded: form_helper
INFO - 2017-01-19 11:35:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:35:44 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:35:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:35:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:35:44 --> Final output sent to browser
DEBUG - 2017-01-19 11:35:44 --> Total execution time: 0.0969
INFO - 2017-01-19 11:36:20 --> Config Class Initialized
INFO - 2017-01-19 11:36:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:20 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:20 --> URI Class Initialized
INFO - 2017-01-19 11:36:20 --> Router Class Initialized
INFO - 2017-01-19 11:36:20 --> Output Class Initialized
INFO - 2017-01-19 11:36:20 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:20 --> Input Class Initialized
INFO - 2017-01-19 11:36:20 --> Language Class Initialized
INFO - 2017-01-19 11:36:20 --> Loader Class Initialized
INFO - 2017-01-19 11:36:20 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:20 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:20 --> Controller Class Initialized
INFO - 2017-01-19 11:36:20 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:20 --> Model Class Initialized
INFO - 2017-01-19 11:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:20 --> Config Class Initialized
INFO - 2017-01-19 11:36:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:20 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:20 --> URI Class Initialized
INFO - 2017-01-19 11:36:20 --> Router Class Initialized
INFO - 2017-01-19 11:36:20 --> Output Class Initialized
INFO - 2017-01-19 11:36:20 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:20 --> Input Class Initialized
INFO - 2017-01-19 11:36:20 --> Language Class Initialized
INFO - 2017-01-19 11:36:20 --> Loader Class Initialized
INFO - 2017-01-19 11:36:20 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:20 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:20 --> Controller Class Initialized
INFO - 2017-01-19 11:36:20 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:20 --> Model Class Initialized
INFO - 2017-01-19 11:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:20 --> Helper loaded: form_helper
INFO - 2017-01-19 11:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:36:20 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:36:20 --> Final output sent to browser
DEBUG - 2017-01-19 11:36:20 --> Total execution time: 0.0966
INFO - 2017-01-19 11:36:28 --> Config Class Initialized
INFO - 2017-01-19 11:36:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:28 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:28 --> URI Class Initialized
INFO - 2017-01-19 11:36:28 --> Router Class Initialized
INFO - 2017-01-19 11:36:28 --> Output Class Initialized
INFO - 2017-01-19 11:36:28 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:28 --> Input Class Initialized
INFO - 2017-01-19 11:36:28 --> Language Class Initialized
INFO - 2017-01-19 11:36:28 --> Loader Class Initialized
INFO - 2017-01-19 11:36:28 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:28 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:28 --> Controller Class Initialized
INFO - 2017-01-19 11:36:28 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:28 --> Model Class Initialized
INFO - 2017-01-19 11:36:28 --> Model Class Initialized
INFO - 2017-01-19 11:36:28 --> Model Class Initialized
INFO - 2017-01-19 11:36:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:28 --> Config Class Initialized
INFO - 2017-01-19 11:36:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:28 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:28 --> URI Class Initialized
INFO - 2017-01-19 11:36:28 --> Router Class Initialized
INFO - 2017-01-19 11:36:28 --> Output Class Initialized
INFO - 2017-01-19 11:36:28 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:28 --> Input Class Initialized
INFO - 2017-01-19 11:36:28 --> Language Class Initialized
INFO - 2017-01-19 11:36:28 --> Loader Class Initialized
INFO - 2017-01-19 11:36:28 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:28 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:28 --> Controller Class Initialized
INFO - 2017-01-19 11:36:28 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:28 --> Model Class Initialized
INFO - 2017-01-19 11:36:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 11:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 11:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 11:36:28 --> Final output sent to browser
DEBUG - 2017-01-19 11:36:28 --> Total execution time: 0.1262
INFO - 2017-01-19 11:36:40 --> Config Class Initialized
INFO - 2017-01-19 11:36:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:40 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:40 --> URI Class Initialized
INFO - 2017-01-19 11:36:40 --> Router Class Initialized
INFO - 2017-01-19 11:36:40 --> Output Class Initialized
INFO - 2017-01-19 11:36:40 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:40 --> Input Class Initialized
INFO - 2017-01-19 11:36:40 --> Language Class Initialized
INFO - 2017-01-19 11:36:40 --> Loader Class Initialized
INFO - 2017-01-19 11:36:40 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:40 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:40 --> Controller Class Initialized
INFO - 2017-01-19 11:36:40 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:40 --> Model Class Initialized
INFO - 2017-01-19 11:36:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:40 --> Config Class Initialized
INFO - 2017-01-19 11:36:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:40 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:40 --> URI Class Initialized
INFO - 2017-01-19 11:36:40 --> Router Class Initialized
INFO - 2017-01-19 11:36:40 --> Output Class Initialized
INFO - 2017-01-19 11:36:40 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:40 --> Input Class Initialized
INFO - 2017-01-19 11:36:40 --> Language Class Initialized
INFO - 2017-01-19 11:36:40 --> Loader Class Initialized
INFO - 2017-01-19 11:36:40 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:40 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:40 --> Controller Class Initialized
INFO - 2017-01-19 11:36:40 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:40 --> Model Class Initialized
INFO - 2017-01-19 11:36:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 11:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 11:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 11:36:40 --> Final output sent to browser
DEBUG - 2017-01-19 11:36:40 --> Total execution time: 0.1275
INFO - 2017-01-19 11:36:51 --> Config Class Initialized
INFO - 2017-01-19 11:36:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:51 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:51 --> URI Class Initialized
INFO - 2017-01-19 11:36:51 --> Router Class Initialized
INFO - 2017-01-19 11:36:51 --> Output Class Initialized
INFO - 2017-01-19 11:36:51 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:51 --> Input Class Initialized
INFO - 2017-01-19 11:36:51 --> Language Class Initialized
INFO - 2017-01-19 11:36:51 --> Loader Class Initialized
INFO - 2017-01-19 11:36:51 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:51 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:51 --> Controller Class Initialized
INFO - 2017-01-19 11:36:51 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:51 --> Model Class Initialized
INFO - 2017-01-19 11:36:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:51 --> Config Class Initialized
INFO - 2017-01-19 11:36:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:51 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:51 --> URI Class Initialized
INFO - 2017-01-19 11:36:51 --> Router Class Initialized
INFO - 2017-01-19 11:36:51 --> Output Class Initialized
INFO - 2017-01-19 11:36:51 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:51 --> Input Class Initialized
INFO - 2017-01-19 11:36:51 --> Language Class Initialized
INFO - 2017-01-19 11:36:51 --> Loader Class Initialized
INFO - 2017-01-19 11:36:51 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:51 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:51 --> Controller Class Initialized
INFO - 2017-01-19 11:36:51 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:51 --> Model Class Initialized
INFO - 2017-01-19 11:36:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 11:36:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 11:36:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 11:36:51 --> Final output sent to browser
DEBUG - 2017-01-19 11:36:51 --> Total execution time: 0.1745
INFO - 2017-01-19 11:36:55 --> Config Class Initialized
INFO - 2017-01-19 11:36:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:55 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:55 --> URI Class Initialized
INFO - 2017-01-19 11:36:55 --> Router Class Initialized
INFO - 2017-01-19 11:36:55 --> Output Class Initialized
INFO - 2017-01-19 11:36:55 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:55 --> Input Class Initialized
INFO - 2017-01-19 11:36:55 --> Language Class Initialized
INFO - 2017-01-19 11:36:55 --> Loader Class Initialized
INFO - 2017-01-19 11:36:55 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:55 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:55 --> Controller Class Initialized
INFO - 2017-01-19 11:36:55 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:55 --> Model Class Initialized
INFO - 2017-01-19 11:36:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:55 --> Model Class Initialized
INFO - 2017-01-19 11:36:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:36:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-01-19 11:36:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:36:55 --> Final output sent to browser
DEBUG - 2017-01-19 11:36:55 --> Total execution time: 0.1234
INFO - 2017-01-19 11:36:59 --> Config Class Initialized
INFO - 2017-01-19 11:36:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:59 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:59 --> URI Class Initialized
INFO - 2017-01-19 11:36:59 --> Router Class Initialized
INFO - 2017-01-19 11:36:59 --> Output Class Initialized
INFO - 2017-01-19 11:36:59 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:59 --> Input Class Initialized
INFO - 2017-01-19 11:36:59 --> Language Class Initialized
INFO - 2017-01-19 11:36:59 --> Loader Class Initialized
INFO - 2017-01-19 11:36:59 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:59 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:59 --> Controller Class Initialized
INFO - 2017-01-19 11:36:59 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:59 --> Model Class Initialized
INFO - 2017-01-19 11:36:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:59 --> Helper loaded: form_helper
INFO - 2017-01-19 11:36:59 --> Form Validation Class Initialized
INFO - 2017-01-19 11:36:59 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-19 11:36:59 --> Config Class Initialized
INFO - 2017-01-19 11:36:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:36:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:36:59 --> Utf8 Class Initialized
INFO - 2017-01-19 11:36:59 --> URI Class Initialized
INFO - 2017-01-19 11:36:59 --> Router Class Initialized
INFO - 2017-01-19 11:36:59 --> Output Class Initialized
INFO - 2017-01-19 11:36:59 --> Security Class Initialized
DEBUG - 2017-01-19 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:36:59 --> Input Class Initialized
INFO - 2017-01-19 11:36:59 --> Language Class Initialized
INFO - 2017-01-19 11:36:59 --> Loader Class Initialized
INFO - 2017-01-19 11:36:59 --> Helper loaded: url_helper
INFO - 2017-01-19 11:36:59 --> Helper loaded: language_helper
INFO - 2017-01-19 11:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:36:59 --> Controller Class Initialized
INFO - 2017-01-19 11:36:59 --> Database Driver Class Initialized
INFO - 2017-01-19 11:36:59 --> Model Class Initialized
INFO - 2017-01-19 11:36:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:36:59 --> Model Class Initialized
INFO - 2017-01-19 11:36:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:36:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-01-19 11:36:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:36:59 --> Final output sent to browser
DEBUG - 2017-01-19 11:36:59 --> Total execution time: 0.1036
INFO - 2017-01-19 11:37:05 --> Config Class Initialized
INFO - 2017-01-19 11:37:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:05 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:05 --> URI Class Initialized
INFO - 2017-01-19 11:37:05 --> Router Class Initialized
INFO - 2017-01-19 11:37:05 --> Output Class Initialized
INFO - 2017-01-19 11:37:06 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:06 --> Input Class Initialized
INFO - 2017-01-19 11:37:06 --> Language Class Initialized
INFO - 2017-01-19 11:37:06 --> Loader Class Initialized
INFO - 2017-01-19 11:37:06 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:06 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:06 --> Controller Class Initialized
INFO - 2017-01-19 11:37:06 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:06 --> Model Class Initialized
INFO - 2017-01-19 11:37:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:06 --> Helper loaded: form_helper
INFO - 2017-01-19 11:37:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:37:06 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:37:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:37:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:06 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:06 --> Total execution time: 0.1669
INFO - 2017-01-19 11:37:11 --> Config Class Initialized
INFO - 2017-01-19 11:37:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:11 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:11 --> URI Class Initialized
INFO - 2017-01-19 11:37:11 --> Router Class Initialized
INFO - 2017-01-19 11:37:11 --> Output Class Initialized
INFO - 2017-01-19 11:37:11 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:11 --> Input Class Initialized
INFO - 2017-01-19 11:37:11 --> Language Class Initialized
INFO - 2017-01-19 11:37:11 --> Loader Class Initialized
INFO - 2017-01-19 11:37:11 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:11 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:11 --> Controller Class Initialized
INFO - 2017-01-19 11:37:11 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:11 --> Model Class Initialized
INFO - 2017-01-19 11:37:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:12 --> Config Class Initialized
INFO - 2017-01-19 11:37:12 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:12 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:12 --> URI Class Initialized
INFO - 2017-01-19 11:37:12 --> Router Class Initialized
INFO - 2017-01-19 11:37:12 --> Output Class Initialized
INFO - 2017-01-19 11:37:12 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:12 --> Input Class Initialized
INFO - 2017-01-19 11:37:12 --> Language Class Initialized
INFO - 2017-01-19 11:37:12 --> Loader Class Initialized
INFO - 2017-01-19 11:37:12 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:12 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:12 --> Controller Class Initialized
INFO - 2017-01-19 11:37:12 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:12 --> Model Class Initialized
INFO - 2017-01-19 11:37:12 --> Model Class Initialized
INFO - 2017-01-19 11:37:12 --> Model Class Initialized
INFO - 2017-01-19 11:37:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:37:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 11:37:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:12 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:12 --> Total execution time: 0.1273
INFO - 2017-01-19 11:37:15 --> Config Class Initialized
INFO - 2017-01-19 11:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:15 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:15 --> URI Class Initialized
INFO - 2017-01-19 11:37:15 --> Router Class Initialized
INFO - 2017-01-19 11:37:15 --> Output Class Initialized
INFO - 2017-01-19 11:37:15 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:15 --> Input Class Initialized
INFO - 2017-01-19 11:37:15 --> Language Class Initialized
INFO - 2017-01-19 11:37:15 --> Loader Class Initialized
INFO - 2017-01-19 11:37:15 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:15 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:15 --> Controller Class Initialized
INFO - 2017-01-19 11:37:15 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:15 --> Config Class Initialized
INFO - 2017-01-19 11:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:15 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:15 --> URI Class Initialized
INFO - 2017-01-19 11:37:15 --> Router Class Initialized
INFO - 2017-01-19 11:37:15 --> Output Class Initialized
INFO - 2017-01-19 11:37:15 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:15 --> Input Class Initialized
INFO - 2017-01-19 11:37:15 --> Language Class Initialized
INFO - 2017-01-19 11:37:15 --> Loader Class Initialized
INFO - 2017-01-19 11:37:15 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:15 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:15 --> Controller Class Initialized
INFO - 2017-01-19 11:37:15 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:15 --> Config Class Initialized
INFO - 2017-01-19 11:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:15 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:15 --> URI Class Initialized
INFO - 2017-01-19 11:37:15 --> Router Class Initialized
INFO - 2017-01-19 11:37:15 --> Output Class Initialized
INFO - 2017-01-19 11:37:15 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:15 --> Input Class Initialized
INFO - 2017-01-19 11:37:15 --> Language Class Initialized
INFO - 2017-01-19 11:37:15 --> Loader Class Initialized
INFO - 2017-01-19 11:37:15 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:15 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:15 --> Controller Class Initialized
INFO - 2017-01-19 11:37:15 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Model Class Initialized
INFO - 2017-01-19 11:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-19 11:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:15 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:15 --> Total execution time: 0.1374
INFO - 2017-01-19 11:37:17 --> Config Class Initialized
INFO - 2017-01-19 11:37:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:17 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:17 --> URI Class Initialized
INFO - 2017-01-19 11:37:17 --> Router Class Initialized
INFO - 2017-01-19 11:37:17 --> Output Class Initialized
INFO - 2017-01-19 11:37:17 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:17 --> Input Class Initialized
INFO - 2017-01-19 11:37:17 --> Language Class Initialized
INFO - 2017-01-19 11:37:17 --> Loader Class Initialized
INFO - 2017-01-19 11:37:17 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:17 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:17 --> Controller Class Initialized
INFO - 2017-01-19 11:37:17 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:17 --> Model Class Initialized
INFO - 2017-01-19 11:37:17 --> Model Class Initialized
INFO - 2017-01-19 11:37:17 --> Model Class Initialized
INFO - 2017-01-19 11:37:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:18 --> Config Class Initialized
INFO - 2017-01-19 11:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:18 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:18 --> URI Class Initialized
INFO - 2017-01-19 11:37:18 --> Router Class Initialized
INFO - 2017-01-19 11:37:18 --> Output Class Initialized
INFO - 2017-01-19 11:37:18 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:18 --> Input Class Initialized
INFO - 2017-01-19 11:37:18 --> Language Class Initialized
INFO - 2017-01-19 11:37:18 --> Loader Class Initialized
INFO - 2017-01-19 11:37:18 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:18 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:18 --> Controller Class Initialized
INFO - 2017-01-19 11:37:18 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-19 11:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:18 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:18 --> Total execution time: 0.1957
INFO - 2017-01-19 11:37:18 --> Config Class Initialized
INFO - 2017-01-19 11:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:18 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:18 --> Config Class Initialized
INFO - 2017-01-19 11:37:18 --> Hooks Class Initialized
INFO - 2017-01-19 11:37:18 --> URI Class Initialized
INFO - 2017-01-19 11:37:18 --> Router Class Initialized
DEBUG - 2017-01-19 11:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:18 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:18 --> Output Class Initialized
INFO - 2017-01-19 11:37:18 --> URI Class Initialized
INFO - 2017-01-19 11:37:18 --> Security Class Initialized
INFO - 2017-01-19 11:37:18 --> Router Class Initialized
DEBUG - 2017-01-19 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:18 --> Input Class Initialized
INFO - 2017-01-19 11:37:18 --> Language Class Initialized
INFO - 2017-01-19 11:37:18 --> Output Class Initialized
INFO - 2017-01-19 11:37:18 --> Loader Class Initialized
INFO - 2017-01-19 11:37:18 --> Security Class Initialized
INFO - 2017-01-19 11:37:18 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:18 --> Helper loaded: language_helper
DEBUG - 2017-01-19 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:18 --> Input Class Initialized
INFO - 2017-01-19 11:37:18 --> Language Class Initialized
INFO - 2017-01-19 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:18 --> Controller Class Initialized
INFO - 2017-01-19 11:37:18 --> Loader Class Initialized
INFO - 2017-01-19 11:37:18 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:18 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:18 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:18 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:18 --> Total execution time: 0.1337
INFO - 2017-01-19 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:18 --> Controller Class Initialized
INFO - 2017-01-19 11:37:18 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Model Class Initialized
INFO - 2017-01-19 11:37:18 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 11:37:18 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 11:37:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 11:37:18 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:18 --> Total execution time: 0.1990
INFO - 2017-01-19 11:37:22 --> Config Class Initialized
INFO - 2017-01-19 11:37:22 --> Hooks Class Initialized
INFO - 2017-01-19 11:37:22 --> Config Class Initialized
INFO - 2017-01-19 11:37:22 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:22 --> Utf8 Class Initialized
DEBUG - 2017-01-19 11:37:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:22 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:22 --> URI Class Initialized
INFO - 2017-01-19 11:37:22 --> URI Class Initialized
INFO - 2017-01-19 11:37:22 --> Router Class Initialized
INFO - 2017-01-19 11:37:22 --> Router Class Initialized
INFO - 2017-01-19 11:37:22 --> Output Class Initialized
INFO - 2017-01-19 11:37:22 --> Output Class Initialized
INFO - 2017-01-19 11:37:22 --> Security Class Initialized
INFO - 2017-01-19 11:37:22 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:22 --> Input Class Initialized
INFO - 2017-01-19 11:37:22 --> Language Class Initialized
INFO - 2017-01-19 11:37:22 --> Loader Class Initialized
DEBUG - 2017-01-19 11:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:22 --> Input Class Initialized
INFO - 2017-01-19 11:37:22 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:22 --> Language Class Initialized
INFO - 2017-01-19 11:37:22 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:22 --> Loader Class Initialized
INFO - 2017-01-19 11:37:22 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:22 --> Controller Class Initialized
INFO - 2017-01-19 11:37:22 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:22 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:22 --> Model Class Initialized
INFO - 2017-01-19 11:37:22 --> Model Class Initialized
INFO - 2017-01-19 11:37:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:22 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:22 --> Total execution time: 0.1368
INFO - 2017-01-19 11:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:23 --> Controller Class Initialized
INFO - 2017-01-19 11:37:23 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:23 --> Model Class Initialized
INFO - 2017-01-19 11:37:23 --> Model Class Initialized
INFO - 2017-01-19 11:37:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:23 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:23 --> Total execution time: 0.2351
INFO - 2017-01-19 11:37:25 --> Config Class Initialized
INFO - 2017-01-19 11:37:25 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:25 --> Config Class Initialized
INFO - 2017-01-19 11:37:25 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:25 --> Hooks Class Initialized
INFO - 2017-01-19 11:37:25 --> URI Class Initialized
INFO - 2017-01-19 11:37:25 --> Router Class Initialized
INFO - 2017-01-19 11:37:25 --> Output Class Initialized
DEBUG - 2017-01-19 11:37:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:25 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:25 --> Security Class Initialized
INFO - 2017-01-19 11:37:25 --> URI Class Initialized
INFO - 2017-01-19 11:37:25 --> Router Class Initialized
INFO - 2017-01-19 11:37:25 --> Output Class Initialized
INFO - 2017-01-19 11:37:25 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:25 --> Input Class Initialized
INFO - 2017-01-19 11:37:25 --> Language Class Initialized
DEBUG - 2017-01-19 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:25 --> Input Class Initialized
INFO - 2017-01-19 11:37:25 --> Loader Class Initialized
INFO - 2017-01-19 11:37:25 --> Language Class Initialized
INFO - 2017-01-19 11:37:25 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:25 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:25 --> Loader Class Initialized
INFO - 2017-01-19 11:37:25 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:25 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:25 --> Controller Class Initialized
INFO - 2017-01-19 11:37:25 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:25 --> Model Class Initialized
INFO - 2017-01-19 11:37:25 --> Model Class Initialized
INFO - 2017-01-19 11:37:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:25 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:25 --> Total execution time: 0.1382
INFO - 2017-01-19 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:25 --> Controller Class Initialized
INFO - 2017-01-19 11:37:25 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:25 --> Model Class Initialized
INFO - 2017-01-19 11:37:25 --> Model Class Initialized
INFO - 2017-01-19 11:37:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:25 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:25 --> Total execution time: 0.2509
INFO - 2017-01-19 11:37:27 --> Config Class Initialized
INFO - 2017-01-19 11:37:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:27 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:27 --> URI Class Initialized
DEBUG - 2017-01-19 11:37:27 --> No URI present. Default controller set.
INFO - 2017-01-19 11:37:27 --> Router Class Initialized
INFO - 2017-01-19 11:37:27 --> Output Class Initialized
INFO - 2017-01-19 11:37:27 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:27 --> Input Class Initialized
INFO - 2017-01-19 11:37:27 --> Language Class Initialized
INFO - 2017-01-19 11:37:27 --> Loader Class Initialized
INFO - 2017-01-19 11:37:27 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:27 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:27 --> Controller Class Initialized
INFO - 2017-01-19 11:37:27 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:27 --> Model Class Initialized
INFO - 2017-01-19 11:37:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:27 --> Config Class Initialized
INFO - 2017-01-19 11:37:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:27 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:27 --> URI Class Initialized
INFO - 2017-01-19 11:37:27 --> Router Class Initialized
INFO - 2017-01-19 11:37:27 --> Output Class Initialized
INFO - 2017-01-19 11:37:27 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:27 --> Input Class Initialized
INFO - 2017-01-19 11:37:27 --> Language Class Initialized
INFO - 2017-01-19 11:37:27 --> Loader Class Initialized
INFO - 2017-01-19 11:37:27 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:27 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:27 --> Controller Class Initialized
INFO - 2017-01-19 11:37:27 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:27 --> Model Class Initialized
INFO - 2017-01-19 11:37:27 --> Model Class Initialized
INFO - 2017-01-19 11:37:27 --> Model Class Initialized
INFO - 2017-01-19 11:37:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:37:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 11:37:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:27 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:27 --> Total execution time: 0.1524
INFO - 2017-01-19 11:37:37 --> Config Class Initialized
INFO - 2017-01-19 11:37:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:37 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:37 --> URI Class Initialized
INFO - 2017-01-19 11:37:37 --> Router Class Initialized
INFO - 2017-01-19 11:37:37 --> Output Class Initialized
INFO - 2017-01-19 11:37:37 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:37 --> Input Class Initialized
INFO - 2017-01-19 11:37:37 --> Language Class Initialized
INFO - 2017-01-19 11:37:37 --> Loader Class Initialized
INFO - 2017-01-19 11:37:37 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:37 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:37 --> Controller Class Initialized
INFO - 2017-01-19 11:37:37 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:37 --> Model Class Initialized
INFO - 2017-01-19 11:37:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:37 --> Config Class Initialized
INFO - 2017-01-19 11:37:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:37 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:37 --> URI Class Initialized
INFO - 2017-01-19 11:37:37 --> Router Class Initialized
INFO - 2017-01-19 11:37:37 --> Output Class Initialized
INFO - 2017-01-19 11:37:37 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:37 --> Input Class Initialized
INFO - 2017-01-19 11:37:37 --> Language Class Initialized
INFO - 2017-01-19 11:37:37 --> Loader Class Initialized
INFO - 2017-01-19 11:37:37 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:37 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:37 --> Controller Class Initialized
INFO - 2017-01-19 11:37:37 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:37 --> Model Class Initialized
INFO - 2017-01-19 11:37:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:37 --> Helper loaded: form_helper
INFO - 2017-01-19 11:37:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 11:37:37 --> Could not find the language line "import_user"
INFO - 2017-01-19 11:37:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 11:37:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:37 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:37 --> Total execution time: 0.0999
INFO - 2017-01-19 11:37:43 --> Config Class Initialized
INFO - 2017-01-19 11:37:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:37:43 --> Utf8 Class Initialized
INFO - 2017-01-19 11:37:43 --> URI Class Initialized
INFO - 2017-01-19 11:37:43 --> Router Class Initialized
INFO - 2017-01-19 11:37:43 --> Output Class Initialized
INFO - 2017-01-19 11:37:43 --> Security Class Initialized
DEBUG - 2017-01-19 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:37:43 --> Input Class Initialized
INFO - 2017-01-19 11:37:43 --> Language Class Initialized
INFO - 2017-01-19 11:37:43 --> Loader Class Initialized
INFO - 2017-01-19 11:37:43 --> Helper loaded: url_helper
INFO - 2017-01-19 11:37:43 --> Helper loaded: language_helper
INFO - 2017-01-19 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:37:43 --> Controller Class Initialized
INFO - 2017-01-19 11:37:43 --> Database Driver Class Initialized
INFO - 2017-01-19 11:37:43 --> Model Class Initialized
INFO - 2017-01-19 11:37:43 --> Model Class Initialized
INFO - 2017-01-19 11:37:43 --> Model Class Initialized
INFO - 2017-01-19 11:37:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 11:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 11:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 11:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 11:37:43 --> Final output sent to browser
DEBUG - 2017-01-19 11:37:43 --> Total execution time: 0.1116
INFO - 2017-01-19 13:16:21 --> Config Class Initialized
INFO - 2017-01-19 13:16:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:16:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:16:21 --> Utf8 Class Initialized
INFO - 2017-01-19 13:16:21 --> URI Class Initialized
INFO - 2017-01-19 13:16:21 --> Router Class Initialized
INFO - 2017-01-19 13:16:21 --> Output Class Initialized
INFO - 2017-01-19 13:16:21 --> Security Class Initialized
DEBUG - 2017-01-19 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:16:21 --> Input Class Initialized
INFO - 2017-01-19 13:16:21 --> Language Class Initialized
INFO - 2017-01-19 13:16:21 --> Loader Class Initialized
INFO - 2017-01-19 13:16:21 --> Helper loaded: url_helper
INFO - 2017-01-19 13:16:21 --> Helper loaded: language_helper
INFO - 2017-01-19 13:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:16:21 --> Controller Class Initialized
INFO - 2017-01-19 13:16:21 --> Database Driver Class Initialized
INFO - 2017-01-19 13:16:21 --> Model Class Initialized
INFO - 2017-01-19 13:16:21 --> Model Class Initialized
INFO - 2017-01-19 13:16:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 13:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:16:21 --> Final output sent to browser
DEBUG - 2017-01-19 13:16:21 --> Total execution time: 0.1415
INFO - 2017-01-19 13:17:24 --> Config Class Initialized
INFO - 2017-01-19 13:17:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:17:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:17:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:17:24 --> URI Class Initialized
INFO - 2017-01-19 13:17:24 --> Router Class Initialized
INFO - 2017-01-19 13:17:24 --> Output Class Initialized
INFO - 2017-01-19 13:17:24 --> Security Class Initialized
DEBUG - 2017-01-19 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:17:24 --> Input Class Initialized
INFO - 2017-01-19 13:17:24 --> Language Class Initialized
INFO - 2017-01-19 13:17:24 --> Loader Class Initialized
INFO - 2017-01-19 13:17:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:17:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:17:24 --> Controller Class Initialized
INFO - 2017-01-19 13:17:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:17:24 --> Model Class Initialized
INFO - 2017-01-19 13:17:24 --> Model Class Initialized
INFO - 2017-01-19 13:17:24 --> Model Class Initialized
INFO - 2017-01-19 13:17:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:17:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:17:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:17:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:17:25 --> Final output sent to browser
DEBUG - 2017-01-19 13:17:25 --> Total execution time: 0.1413
INFO - 2017-01-19 13:18:24 --> Config Class Initialized
INFO - 2017-01-19 13:18:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:24 --> URI Class Initialized
INFO - 2017-01-19 13:18:24 --> Router Class Initialized
INFO - 2017-01-19 13:18:24 --> Output Class Initialized
INFO - 2017-01-19 13:18:24 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:24 --> Input Class Initialized
INFO - 2017-01-19 13:18:24 --> Language Class Initialized
INFO - 2017-01-19 13:18:24 --> Loader Class Initialized
INFO - 2017-01-19 13:18:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:24 --> Controller Class Initialized
INFO - 2017-01-19 13:18:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:24 --> Model Class Initialized
INFO - 2017-01-19 13:18:24 --> Model Class Initialized
INFO - 2017-01-19 13:18:24 --> Model Class Initialized
INFO - 2017-01-19 13:18:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:18:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:18:24 --> Final output sent to browser
DEBUG - 2017-01-19 13:18:24 --> Total execution time: 0.1615
INFO - 2017-01-19 13:18:45 --> Config Class Initialized
INFO - 2017-01-19 13:18:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:45 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:45 --> URI Class Initialized
INFO - 2017-01-19 13:18:45 --> Router Class Initialized
INFO - 2017-01-19 13:18:45 --> Output Class Initialized
INFO - 2017-01-19 13:18:45 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:45 --> Input Class Initialized
INFO - 2017-01-19 13:18:45 --> Language Class Initialized
INFO - 2017-01-19 13:18:45 --> Loader Class Initialized
INFO - 2017-01-19 13:18:45 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:45 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:45 --> Controller Class Initialized
INFO - 2017-01-19 13:18:45 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:45 --> Model Class Initialized
INFO - 2017-01-19 13:18:45 --> Model Class Initialized
INFO - 2017-01-19 13:18:45 --> Model Class Initialized
INFO - 2017-01-19 13:18:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:45 --> Config Class Initialized
INFO - 2017-01-19 13:18:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:45 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:45 --> URI Class Initialized
INFO - 2017-01-19 13:18:45 --> Router Class Initialized
INFO - 2017-01-19 13:18:45 --> Output Class Initialized
INFO - 2017-01-19 13:18:45 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:45 --> Input Class Initialized
INFO - 2017-01-19 13:18:45 --> Language Class Initialized
INFO - 2017-01-19 13:18:45 --> Loader Class Initialized
INFO - 2017-01-19 13:18:45 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:45 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:45 --> Controller Class Initialized
INFO - 2017-01-19 13:18:46 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:46 --> Model Class Initialized
INFO - 2017-01-19 13:18:46 --> Model Class Initialized
INFO - 2017-01-19 13:18:46 --> Model Class Initialized
INFO - 2017-01-19 13:18:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:46 --> Config Class Initialized
INFO - 2017-01-19 13:18:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:46 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:46 --> URI Class Initialized
INFO - 2017-01-19 13:18:46 --> Router Class Initialized
INFO - 2017-01-19 13:18:46 --> Output Class Initialized
INFO - 2017-01-19 13:18:46 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:46 --> Input Class Initialized
INFO - 2017-01-19 13:18:46 --> Language Class Initialized
INFO - 2017-01-19 13:18:46 --> Loader Class Initialized
INFO - 2017-01-19 13:18:46 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:46 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:46 --> Controller Class Initialized
INFO - 2017-01-19 13:18:46 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:46 --> Model Class Initialized
INFO - 2017-01-19 13:18:46 --> Model Class Initialized
INFO - 2017-01-19 13:18:46 --> Model Class Initialized
INFO - 2017-01-19 13:18:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-01-19 13:18:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:18:46 --> Final output sent to browser
DEBUG - 2017-01-19 13:18:46 --> Total execution time: 0.1604
INFO - 2017-01-19 13:18:53 --> Config Class Initialized
INFO - 2017-01-19 13:18:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:53 --> URI Class Initialized
INFO - 2017-01-19 13:18:53 --> Router Class Initialized
INFO - 2017-01-19 13:18:53 --> Output Class Initialized
INFO - 2017-01-19 13:18:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:53 --> Input Class Initialized
INFO - 2017-01-19 13:18:53 --> Language Class Initialized
INFO - 2017-01-19 13:18:53 --> Loader Class Initialized
INFO - 2017-01-19 13:18:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:53 --> Controller Class Initialized
INFO - 2017-01-19 13:18:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:53 --> Model Class Initialized
INFO - 2017-01-19 13:18:53 --> Model Class Initialized
INFO - 2017-01-19 13:18:53 --> Model Class Initialized
INFO - 2017-01-19 13:18:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:53 --> Config Class Initialized
INFO - 2017-01-19 13:18:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:53 --> URI Class Initialized
INFO - 2017-01-19 13:18:53 --> Router Class Initialized
INFO - 2017-01-19 13:18:53 --> Output Class Initialized
INFO - 2017-01-19 13:18:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:53 --> Input Class Initialized
INFO - 2017-01-19 13:18:53 --> Language Class Initialized
INFO - 2017-01-19 13:18:53 --> Loader Class Initialized
INFO - 2017-01-19 13:18:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:53 --> Controller Class Initialized
INFO - 2017-01-19 13:18:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:53 --> Model Class Initialized
INFO - 2017-01-19 13:18:53 --> Model Class Initialized
INFO - 2017-01-19 13:18:53 --> Model Class Initialized
INFO - 2017-01-19 13:18:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:18:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-01-19 13:18:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:18:53 --> Final output sent to browser
DEBUG - 2017-01-19 13:18:53 --> Total execution time: 0.1639
INFO - 2017-01-19 13:18:53 --> Config Class Initialized
INFO - 2017-01-19 13:18:53 --> Hooks Class Initialized
INFO - 2017-01-19 13:18:53 --> Config Class Initialized
INFO - 2017-01-19 13:18:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:18:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:53 --> URI Class Initialized
DEBUG - 2017-01-19 13:18:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:18:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:18:53 --> URI Class Initialized
INFO - 2017-01-19 13:18:53 --> Router Class Initialized
INFO - 2017-01-19 13:18:53 --> Router Class Initialized
INFO - 2017-01-19 13:18:53 --> Output Class Initialized
INFO - 2017-01-19 13:18:53 --> Output Class Initialized
INFO - 2017-01-19 13:18:53 --> Security Class Initialized
INFO - 2017-01-19 13:18:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:53 --> Input Class Initialized
INFO - 2017-01-19 13:18:53 --> Language Class Initialized
DEBUG - 2017-01-19 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:18:54 --> Input Class Initialized
INFO - 2017-01-19 13:18:54 --> Language Class Initialized
INFO - 2017-01-19 13:18:54 --> Loader Class Initialized
INFO - 2017-01-19 13:18:54 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:54 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:54 --> Loader Class Initialized
INFO - 2017-01-19 13:18:54 --> Helper loaded: url_helper
INFO - 2017-01-19 13:18:54 --> Helper loaded: language_helper
INFO - 2017-01-19 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:54 --> Controller Class Initialized
INFO - 2017-01-19 13:18:54 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:54 --> Model Class Initialized
INFO - 2017-01-19 13:18:54 --> Model Class Initialized
INFO - 2017-01-19 13:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:18:54 --> Final output sent to browser
DEBUG - 2017-01-19 13:18:54 --> Total execution time: 0.1371
INFO - 2017-01-19 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:18:54 --> Controller Class Initialized
INFO - 2017-01-19 13:18:54 --> Database Driver Class Initialized
INFO - 2017-01-19 13:18:54 --> Model Class Initialized
INFO - 2017-01-19 13:18:54 --> Model Class Initialized
INFO - 2017-01-19 13:18:54 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 13:18:54 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 13:18:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 13:18:54 --> Final output sent to browser
DEBUG - 2017-01-19 13:18:54 --> Total execution time: 0.2232
INFO - 2017-01-19 13:19:07 --> Config Class Initialized
INFO - 2017-01-19 13:19:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:08 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:08 --> URI Class Initialized
INFO - 2017-01-19 13:19:08 --> Router Class Initialized
INFO - 2017-01-19 13:19:08 --> Output Class Initialized
INFO - 2017-01-19 13:19:08 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:08 --> Input Class Initialized
INFO - 2017-01-19 13:19:08 --> Language Class Initialized
INFO - 2017-01-19 13:19:08 --> Loader Class Initialized
INFO - 2017-01-19 13:19:08 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:08 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:08 --> Controller Class Initialized
INFO - 2017-01-19 13:19:08 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:08 --> Model Class Initialized
INFO - 2017-01-19 13:19:08 --> Model Class Initialized
INFO - 2017-01-19 13:19:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 13:19:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:08 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:08 --> Total execution time: 0.1528
INFO - 2017-01-19 13:19:16 --> Config Class Initialized
INFO - 2017-01-19 13:19:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:16 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:16 --> URI Class Initialized
INFO - 2017-01-19 13:19:16 --> Router Class Initialized
INFO - 2017-01-19 13:19:16 --> Output Class Initialized
INFO - 2017-01-19 13:19:16 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:16 --> Input Class Initialized
INFO - 2017-01-19 13:19:16 --> Language Class Initialized
INFO - 2017-01-19 13:19:16 --> Loader Class Initialized
INFO - 2017-01-19 13:19:16 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:16 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:16 --> Controller Class Initialized
INFO - 2017-01-19 13:19:16 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:16 --> Model Class Initialized
INFO - 2017-01-19 13:19:16 --> Model Class Initialized
INFO - 2017-01-19 13:19:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:16 --> Model Class Initialized
INFO - 2017-01-19 13:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:16 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:16 --> Total execution time: 0.1627
INFO - 2017-01-19 13:19:18 --> Config Class Initialized
INFO - 2017-01-19 13:19:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:18 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:18 --> URI Class Initialized
INFO - 2017-01-19 13:19:18 --> Router Class Initialized
INFO - 2017-01-19 13:19:18 --> Output Class Initialized
INFO - 2017-01-19 13:19:18 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:18 --> Input Class Initialized
INFO - 2017-01-19 13:19:18 --> Language Class Initialized
INFO - 2017-01-19 13:19:18 --> Loader Class Initialized
INFO - 2017-01-19 13:19:18 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:18 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:18 --> Controller Class Initialized
INFO - 2017-01-19 13:19:18 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:18 --> Model Class Initialized
INFO - 2017-01-19 13:19:18 --> Model Class Initialized
INFO - 2017-01-19 13:19:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:18 --> Model Class Initialized
INFO - 2017-01-19 13:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:18 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:18 --> Total execution time: 0.2055
INFO - 2017-01-19 13:19:19 --> Config Class Initialized
INFO - 2017-01-19 13:19:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:19 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:19 --> URI Class Initialized
INFO - 2017-01-19 13:19:19 --> Router Class Initialized
INFO - 2017-01-19 13:19:19 --> Output Class Initialized
INFO - 2017-01-19 13:19:19 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:19 --> Input Class Initialized
INFO - 2017-01-19 13:19:19 --> Language Class Initialized
INFO - 2017-01-19 13:19:19 --> Loader Class Initialized
INFO - 2017-01-19 13:19:19 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:19 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:19 --> Controller Class Initialized
INFO - 2017-01-19 13:19:19 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:19 --> Model Class Initialized
INFO - 2017-01-19 13:19:19 --> Model Class Initialized
INFO - 2017-01-19 13:19:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:19 --> Model Class Initialized
INFO - 2017-01-19 13:19:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:20 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:20 --> Total execution time: 0.2175
INFO - 2017-01-19 13:19:22 --> Config Class Initialized
INFO - 2017-01-19 13:19:22 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:22 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:22 --> URI Class Initialized
INFO - 2017-01-19 13:19:22 --> Router Class Initialized
INFO - 2017-01-19 13:19:22 --> Output Class Initialized
INFO - 2017-01-19 13:19:22 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:22 --> Input Class Initialized
INFO - 2017-01-19 13:19:22 --> Language Class Initialized
INFO - 2017-01-19 13:19:22 --> Loader Class Initialized
INFO - 2017-01-19 13:19:22 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:22 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:22 --> Controller Class Initialized
INFO - 2017-01-19 13:19:22 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:22 --> Model Class Initialized
INFO - 2017-01-19 13:19:22 --> Model Class Initialized
INFO - 2017-01-19 13:19:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:22 --> Model Class Initialized
INFO - 2017-01-19 13:19:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:22 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:22 --> Total execution time: 0.1645
INFO - 2017-01-19 13:19:23 --> Config Class Initialized
INFO - 2017-01-19 13:19:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:23 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:23 --> URI Class Initialized
INFO - 2017-01-19 13:19:23 --> Router Class Initialized
INFO - 2017-01-19 13:19:23 --> Output Class Initialized
INFO - 2017-01-19 13:19:23 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:23 --> Input Class Initialized
INFO - 2017-01-19 13:19:23 --> Language Class Initialized
INFO - 2017-01-19 13:19:23 --> Loader Class Initialized
INFO - 2017-01-19 13:19:23 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:23 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:23 --> Controller Class Initialized
INFO - 2017-01-19 13:19:23 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:23 --> Model Class Initialized
INFO - 2017-01-19 13:19:23 --> Model Class Initialized
INFO - 2017-01-19 13:19:23 --> Model Class Initialized
INFO - 2017-01-19 13:19:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:23 --> Total execution time: 0.1409
INFO - 2017-01-19 13:19:24 --> Config Class Initialized
INFO - 2017-01-19 13:19:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:24 --> URI Class Initialized
INFO - 2017-01-19 13:19:24 --> Router Class Initialized
INFO - 2017-01-19 13:19:24 --> Output Class Initialized
INFO - 2017-01-19 13:19:24 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:24 --> Input Class Initialized
INFO - 2017-01-19 13:19:24 --> Language Class Initialized
INFO - 2017-01-19 13:19:24 --> Loader Class Initialized
INFO - 2017-01-19 13:19:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:24 --> Controller Class Initialized
INFO - 2017-01-19 13:19:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:24 --> Model Class Initialized
INFO - 2017-01-19 13:19:24 --> Model Class Initialized
INFO - 2017-01-19 13:19:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:24 --> Model Class Initialized
INFO - 2017-01-19 13:19:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:24 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:24 --> Total execution time: 0.1813
INFO - 2017-01-19 13:19:29 --> Config Class Initialized
INFO - 2017-01-19 13:19:29 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:29 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:29 --> URI Class Initialized
INFO - 2017-01-19 13:19:29 --> Router Class Initialized
INFO - 2017-01-19 13:19:29 --> Output Class Initialized
INFO - 2017-01-19 13:19:29 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:29 --> Input Class Initialized
INFO - 2017-01-19 13:19:29 --> Language Class Initialized
INFO - 2017-01-19 13:19:29 --> Loader Class Initialized
INFO - 2017-01-19 13:19:29 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:29 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:29 --> Controller Class Initialized
INFO - 2017-01-19 13:19:29 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:29 --> Model Class Initialized
INFO - 2017-01-19 13:19:29 --> Model Class Initialized
INFO - 2017-01-19 13:19:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:29 --> Model Class Initialized
INFO - 2017-01-19 13:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:29 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:29 --> Total execution time: 0.1690
INFO - 2017-01-19 13:19:31 --> Config Class Initialized
INFO - 2017-01-19 13:19:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:31 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:31 --> URI Class Initialized
INFO - 2017-01-19 13:19:31 --> Router Class Initialized
INFO - 2017-01-19 13:19:31 --> Output Class Initialized
INFO - 2017-01-19 13:19:31 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:31 --> Input Class Initialized
INFO - 2017-01-19 13:19:31 --> Language Class Initialized
INFO - 2017-01-19 13:19:31 --> Loader Class Initialized
INFO - 2017-01-19 13:19:31 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:31 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:31 --> Controller Class Initialized
INFO - 2017-01-19 13:19:31 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:31 --> Model Class Initialized
INFO - 2017-01-19 13:19:31 --> Model Class Initialized
INFO - 2017-01-19 13:19:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:32 --> Model Class Initialized
INFO - 2017-01-19 13:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:32 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:32 --> Total execution time: 0.1656
INFO - 2017-01-19 13:19:36 --> Config Class Initialized
INFO - 2017-01-19 13:19:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:36 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:36 --> URI Class Initialized
INFO - 2017-01-19 13:19:36 --> Router Class Initialized
INFO - 2017-01-19 13:19:36 --> Output Class Initialized
INFO - 2017-01-19 13:19:36 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:36 --> Input Class Initialized
INFO - 2017-01-19 13:19:36 --> Language Class Initialized
INFO - 2017-01-19 13:19:36 --> Loader Class Initialized
INFO - 2017-01-19 13:19:36 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:36 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:36 --> Controller Class Initialized
INFO - 2017-01-19 13:19:36 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:36 --> Model Class Initialized
INFO - 2017-01-19 13:19:36 --> Model Class Initialized
INFO - 2017-01-19 13:19:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:36 --> Model Class Initialized
INFO - 2017-01-19 13:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:36 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:36 --> Total execution time: 0.1751
INFO - 2017-01-19 13:19:40 --> Config Class Initialized
INFO - 2017-01-19 13:19:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:40 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:40 --> URI Class Initialized
INFO - 2017-01-19 13:19:40 --> Router Class Initialized
INFO - 2017-01-19 13:19:40 --> Output Class Initialized
INFO - 2017-01-19 13:19:40 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:40 --> Input Class Initialized
INFO - 2017-01-19 13:19:40 --> Language Class Initialized
INFO - 2017-01-19 13:19:40 --> Loader Class Initialized
INFO - 2017-01-19 13:19:40 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:40 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:40 --> Controller Class Initialized
INFO - 2017-01-19 13:19:40 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:40 --> Model Class Initialized
INFO - 2017-01-19 13:19:40 --> Model Class Initialized
INFO - 2017-01-19 13:19:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:40 --> Model Class Initialized
INFO - 2017-01-19 13:19:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:40 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:40 --> Total execution time: 0.1951
INFO - 2017-01-19 13:19:43 --> Config Class Initialized
INFO - 2017-01-19 13:19:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:43 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:43 --> URI Class Initialized
INFO - 2017-01-19 13:19:43 --> Router Class Initialized
INFO - 2017-01-19 13:19:43 --> Output Class Initialized
INFO - 2017-01-19 13:19:43 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:43 --> Input Class Initialized
INFO - 2017-01-19 13:19:43 --> Language Class Initialized
INFO - 2017-01-19 13:19:43 --> Loader Class Initialized
INFO - 2017-01-19 13:19:43 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:43 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:43 --> Controller Class Initialized
INFO - 2017-01-19 13:19:43 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:43 --> Model Class Initialized
INFO - 2017-01-19 13:19:43 --> Model Class Initialized
INFO - 2017-01-19 13:19:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:43 --> Model Class Initialized
INFO - 2017-01-19 13:19:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:43 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:43 --> Total execution time: 0.1599
INFO - 2017-01-19 13:19:46 --> Config Class Initialized
INFO - 2017-01-19 13:19:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:46 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:46 --> URI Class Initialized
INFO - 2017-01-19 13:19:46 --> Router Class Initialized
INFO - 2017-01-19 13:19:46 --> Output Class Initialized
INFO - 2017-01-19 13:19:46 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:46 --> Input Class Initialized
INFO - 2017-01-19 13:19:46 --> Language Class Initialized
INFO - 2017-01-19 13:19:46 --> Loader Class Initialized
INFO - 2017-01-19 13:19:46 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:46 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:46 --> Controller Class Initialized
INFO - 2017-01-19 13:19:46 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:46 --> Model Class Initialized
INFO - 2017-01-19 13:19:46 --> Model Class Initialized
INFO - 2017-01-19 13:19:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:46 --> Model Class Initialized
INFO - 2017-01-19 13:19:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:46 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:46 --> Total execution time: 0.1690
INFO - 2017-01-19 13:19:48 --> Config Class Initialized
INFO - 2017-01-19 13:19:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:48 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:48 --> URI Class Initialized
INFO - 2017-01-19 13:19:48 --> Router Class Initialized
INFO - 2017-01-19 13:19:48 --> Output Class Initialized
INFO - 2017-01-19 13:19:48 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:48 --> Input Class Initialized
INFO - 2017-01-19 13:19:48 --> Language Class Initialized
INFO - 2017-01-19 13:19:48 --> Loader Class Initialized
INFO - 2017-01-19 13:19:48 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:48 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:48 --> Controller Class Initialized
INFO - 2017-01-19 13:19:48 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:48 --> Model Class Initialized
INFO - 2017-01-19 13:19:48 --> Model Class Initialized
INFO - 2017-01-19 13:19:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:48 --> Model Class Initialized
INFO - 2017-01-19 13:19:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:19:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:19:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:19:48 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:48 --> Total execution time: 0.1928
INFO - 2017-01-19 13:19:53 --> Config Class Initialized
INFO - 2017-01-19 13:19:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:19:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:19:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:19:53 --> URI Class Initialized
INFO - 2017-01-19 13:19:53 --> Router Class Initialized
INFO - 2017-01-19 13:19:53 --> Output Class Initialized
INFO - 2017-01-19 13:19:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:19:53 --> Input Class Initialized
INFO - 2017-01-19 13:19:53 --> Language Class Initialized
INFO - 2017-01-19 13:19:53 --> Loader Class Initialized
INFO - 2017-01-19 13:19:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:19:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:19:53 --> Controller Class Initialized
INFO - 2017-01-19 13:19:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:19:53 --> Model Class Initialized
INFO - 2017-01-19 13:19:53 --> Model Class Initialized
INFO - 2017-01-19 13:19:53 --> Model Class Initialized
INFO - 2017-01-19 13:19:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:19:53 --> Final output sent to browser
DEBUG - 2017-01-19 13:19:53 --> Total execution time: 0.0931
INFO - 2017-01-19 13:20:23 --> Config Class Initialized
INFO - 2017-01-19 13:20:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:20:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:20:23 --> Utf8 Class Initialized
INFO - 2017-01-19 13:20:23 --> URI Class Initialized
INFO - 2017-01-19 13:20:23 --> Router Class Initialized
INFO - 2017-01-19 13:20:23 --> Output Class Initialized
INFO - 2017-01-19 13:20:23 --> Security Class Initialized
DEBUG - 2017-01-19 13:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:20:23 --> Input Class Initialized
INFO - 2017-01-19 13:20:23 --> Language Class Initialized
INFO - 2017-01-19 13:20:23 --> Loader Class Initialized
INFO - 2017-01-19 13:20:23 --> Helper loaded: url_helper
INFO - 2017-01-19 13:20:23 --> Helper loaded: language_helper
INFO - 2017-01-19 13:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:20:23 --> Controller Class Initialized
INFO - 2017-01-19 13:20:23 --> Database Driver Class Initialized
INFO - 2017-01-19 13:20:23 --> Model Class Initialized
INFO - 2017-01-19 13:20:23 --> Model Class Initialized
INFO - 2017-01-19 13:20:23 --> Model Class Initialized
INFO - 2017-01-19 13:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:20:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:20:23 --> Total execution time: 0.0983
INFO - 2017-01-19 13:20:53 --> Config Class Initialized
INFO - 2017-01-19 13:20:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:20:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:20:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:20:53 --> URI Class Initialized
INFO - 2017-01-19 13:20:53 --> Router Class Initialized
INFO - 2017-01-19 13:20:53 --> Output Class Initialized
INFO - 2017-01-19 13:20:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:20:53 --> Input Class Initialized
INFO - 2017-01-19 13:20:53 --> Language Class Initialized
INFO - 2017-01-19 13:20:53 --> Loader Class Initialized
INFO - 2017-01-19 13:20:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:20:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:20:53 --> Controller Class Initialized
INFO - 2017-01-19 13:20:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:20:53 --> Model Class Initialized
INFO - 2017-01-19 13:20:53 --> Model Class Initialized
INFO - 2017-01-19 13:20:53 --> Model Class Initialized
INFO - 2017-01-19 13:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:20:53 --> Final output sent to browser
DEBUG - 2017-01-19 13:20:53 --> Total execution time: 0.1048
INFO - 2017-01-19 13:20:57 --> Config Class Initialized
INFO - 2017-01-19 13:20:57 --> Config Class Initialized
INFO - 2017-01-19 13:20:57 --> Hooks Class Initialized
INFO - 2017-01-19 13:20:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:20:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:20:57 --> Utf8 Class Initialized
INFO - 2017-01-19 13:20:57 --> URI Class Initialized
INFO - 2017-01-19 13:20:57 --> Router Class Initialized
DEBUG - 2017-01-19 13:20:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:20:57 --> Utf8 Class Initialized
INFO - 2017-01-19 13:20:57 --> URI Class Initialized
INFO - 2017-01-19 13:20:57 --> Output Class Initialized
INFO - 2017-01-19 13:20:57 --> Router Class Initialized
INFO - 2017-01-19 13:20:57 --> Security Class Initialized
INFO - 2017-01-19 13:20:57 --> Output Class Initialized
DEBUG - 2017-01-19 13:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:20:57 --> Input Class Initialized
INFO - 2017-01-19 13:20:57 --> Security Class Initialized
INFO - 2017-01-19 13:20:57 --> Language Class Initialized
DEBUG - 2017-01-19 13:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:20:57 --> Input Class Initialized
INFO - 2017-01-19 13:20:57 --> Language Class Initialized
INFO - 2017-01-19 13:20:57 --> Loader Class Initialized
INFO - 2017-01-19 13:20:57 --> Helper loaded: url_helper
INFO - 2017-01-19 13:20:57 --> Loader Class Initialized
INFO - 2017-01-19 13:20:57 --> Helper loaded: language_helper
INFO - 2017-01-19 13:20:57 --> Helper loaded: url_helper
INFO - 2017-01-19 13:20:57 --> Helper loaded: language_helper
INFO - 2017-01-19 13:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:20:57 --> Controller Class Initialized
INFO - 2017-01-19 13:20:57 --> Database Driver Class Initialized
INFO - 2017-01-19 13:20:57 --> Model Class Initialized
INFO - 2017-01-19 13:20:57 --> Model Class Initialized
INFO - 2017-01-19 13:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:20:57 --> Final output sent to browser
DEBUG - 2017-01-19 13:20:57 --> Total execution time: 0.1402
INFO - 2017-01-19 13:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:20:57 --> Controller Class Initialized
INFO - 2017-01-19 13:20:57 --> Database Driver Class Initialized
INFO - 2017-01-19 13:20:57 --> Model Class Initialized
INFO - 2017-01-19 13:20:57 --> Model Class Initialized
INFO - 2017-01-19 13:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:20:57 --> Final output sent to browser
DEBUG - 2017-01-19 13:20:57 --> Total execution time: 0.1825
INFO - 2017-01-19 13:20:59 --> Config Class Initialized
INFO - 2017-01-19 13:20:59 --> Hooks Class Initialized
INFO - 2017-01-19 13:20:59 --> Config Class Initialized
INFO - 2017-01-19 13:20:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:20:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:20:59 --> Utf8 Class Initialized
INFO - 2017-01-19 13:20:59 --> URI Class Initialized
DEBUG - 2017-01-19 13:20:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:20:59 --> Utf8 Class Initialized
INFO - 2017-01-19 13:20:59 --> Router Class Initialized
INFO - 2017-01-19 13:20:59 --> URI Class Initialized
INFO - 2017-01-19 13:20:59 --> Output Class Initialized
INFO - 2017-01-19 13:20:59 --> Router Class Initialized
INFO - 2017-01-19 13:20:59 --> Security Class Initialized
INFO - 2017-01-19 13:20:59 --> Output Class Initialized
INFO - 2017-01-19 13:20:59 --> Security Class Initialized
DEBUG - 2017-01-19 13:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:20:59 --> Input Class Initialized
INFO - 2017-01-19 13:20:59 --> Language Class Initialized
DEBUG - 2017-01-19 13:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:20:59 --> Input Class Initialized
INFO - 2017-01-19 13:20:59 --> Language Class Initialized
INFO - 2017-01-19 13:20:59 --> Loader Class Initialized
INFO - 2017-01-19 13:20:59 --> Loader Class Initialized
INFO - 2017-01-19 13:20:59 --> Helper loaded: url_helper
INFO - 2017-01-19 13:20:59 --> Helper loaded: language_helper
INFO - 2017-01-19 13:20:59 --> Helper loaded: url_helper
INFO - 2017-01-19 13:20:59 --> Helper loaded: language_helper
INFO - 2017-01-19 13:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:20:59 --> Controller Class Initialized
INFO - 2017-01-19 13:20:59 --> Database Driver Class Initialized
INFO - 2017-01-19 13:20:59 --> Model Class Initialized
INFO - 2017-01-19 13:20:59 --> Model Class Initialized
INFO - 2017-01-19 13:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:20:59 --> Final output sent to browser
DEBUG - 2017-01-19 13:20:59 --> Total execution time: 0.1618
INFO - 2017-01-19 13:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:20:59 --> Controller Class Initialized
INFO - 2017-01-19 13:20:59 --> Database Driver Class Initialized
INFO - 2017-01-19 13:20:59 --> Model Class Initialized
INFO - 2017-01-19 13:20:59 --> Model Class Initialized
INFO - 2017-01-19 13:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:00 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:00 --> Total execution time: 0.2452
INFO - 2017-01-19 13:21:01 --> Config Class Initialized
INFO - 2017-01-19 13:21:01 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:01 --> Config Class Initialized
INFO - 2017-01-19 13:21:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:01 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:01 --> URI Class Initialized
DEBUG - 2017-01-19 13:21:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:01 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:01 --> Router Class Initialized
INFO - 2017-01-19 13:21:01 --> URI Class Initialized
INFO - 2017-01-19 13:21:01 --> Output Class Initialized
INFO - 2017-01-19 13:21:01 --> Router Class Initialized
INFO - 2017-01-19 13:21:01 --> Security Class Initialized
INFO - 2017-01-19 13:21:01 --> Output Class Initialized
INFO - 2017-01-19 13:21:01 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:01 --> Input Class Initialized
INFO - 2017-01-19 13:21:01 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:01 --> Input Class Initialized
INFO - 2017-01-19 13:21:01 --> Language Class Initialized
INFO - 2017-01-19 13:21:01 --> Loader Class Initialized
INFO - 2017-01-19 13:21:01 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:01 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:01 --> Loader Class Initialized
INFO - 2017-01-19 13:21:01 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:01 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:01 --> Controller Class Initialized
INFO - 2017-01-19 13:21:01 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:01 --> Model Class Initialized
INFO - 2017-01-19 13:21:01 --> Model Class Initialized
INFO - 2017-01-19 13:21:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:01 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:01 --> Total execution time: 0.1273
INFO - 2017-01-19 13:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:01 --> Controller Class Initialized
INFO - 2017-01-19 13:21:01 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:01 --> Model Class Initialized
INFO - 2017-01-19 13:21:01 --> Model Class Initialized
INFO - 2017-01-19 13:21:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:01 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:01 --> Total execution time: 0.2652
INFO - 2017-01-19 13:21:03 --> Config Class Initialized
INFO - 2017-01-19 13:21:03 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:03 --> Config Class Initialized
INFO - 2017-01-19 13:21:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:03 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:03 --> URI Class Initialized
INFO - 2017-01-19 13:21:03 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:03 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:03 --> Output Class Initialized
INFO - 2017-01-19 13:21:03 --> URI Class Initialized
INFO - 2017-01-19 13:21:03 --> Security Class Initialized
INFO - 2017-01-19 13:21:03 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:03 --> Input Class Initialized
INFO - 2017-01-19 13:21:03 --> Output Class Initialized
INFO - 2017-01-19 13:21:03 --> Language Class Initialized
INFO - 2017-01-19 13:21:03 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:03 --> Input Class Initialized
INFO - 2017-01-19 13:21:03 --> Loader Class Initialized
INFO - 2017-01-19 13:21:03 --> Language Class Initialized
INFO - 2017-01-19 13:21:03 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:03 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:03 --> Loader Class Initialized
INFO - 2017-01-19 13:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:03 --> Controller Class Initialized
INFO - 2017-01-19 13:21:03 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:03 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:03 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:03 --> Model Class Initialized
INFO - 2017-01-19 13:21:03 --> Model Class Initialized
INFO - 2017-01-19 13:21:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:03 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:03 --> Total execution time: 0.1326
INFO - 2017-01-19 13:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:03 --> Controller Class Initialized
INFO - 2017-01-19 13:21:03 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:03 --> Model Class Initialized
INFO - 2017-01-19 13:21:03 --> Model Class Initialized
INFO - 2017-01-19 13:21:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:03 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:03 --> Total execution time: 0.2561
INFO - 2017-01-19 13:21:05 --> Config Class Initialized
INFO - 2017-01-19 13:21:05 --> Config Class Initialized
INFO - 2017-01-19 13:21:05 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:05 --> UTF-8 Support Enabled
DEBUG - 2017-01-19 13:21:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:05 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:05 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:05 --> URI Class Initialized
INFO - 2017-01-19 13:21:05 --> URI Class Initialized
INFO - 2017-01-19 13:21:05 --> Router Class Initialized
INFO - 2017-01-19 13:21:05 --> Router Class Initialized
INFO - 2017-01-19 13:21:05 --> Output Class Initialized
INFO - 2017-01-19 13:21:05 --> Output Class Initialized
INFO - 2017-01-19 13:21:05 --> Security Class Initialized
INFO - 2017-01-19 13:21:05 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:05 --> Input Class Initialized
INFO - 2017-01-19 13:21:05 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:05 --> Input Class Initialized
INFO - 2017-01-19 13:21:05 --> Language Class Initialized
INFO - 2017-01-19 13:21:05 --> Loader Class Initialized
INFO - 2017-01-19 13:21:05 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:05 --> Loader Class Initialized
INFO - 2017-01-19 13:21:05 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:05 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:05 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:05 --> Controller Class Initialized
INFO - 2017-01-19 13:21:05 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:05 --> Model Class Initialized
INFO - 2017-01-19 13:21:05 --> Model Class Initialized
INFO - 2017-01-19 13:21:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:05 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:05 --> Total execution time: 0.1312
INFO - 2017-01-19 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:05 --> Controller Class Initialized
INFO - 2017-01-19 13:21:05 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:05 --> Model Class Initialized
INFO - 2017-01-19 13:21:05 --> Model Class Initialized
INFO - 2017-01-19 13:21:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:05 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:05 --> Total execution time: 0.2374
INFO - 2017-01-19 13:21:06 --> Config Class Initialized
INFO - 2017-01-19 13:21:06 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:06 --> Config Class Initialized
INFO - 2017-01-19 13:21:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:06 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:06 --> URI Class Initialized
INFO - 2017-01-19 13:21:06 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:06 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:06 --> Output Class Initialized
INFO - 2017-01-19 13:21:06 --> URI Class Initialized
INFO - 2017-01-19 13:21:06 --> Security Class Initialized
INFO - 2017-01-19 13:21:06 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:06 --> Input Class Initialized
INFO - 2017-01-19 13:21:06 --> Language Class Initialized
INFO - 2017-01-19 13:21:06 --> Output Class Initialized
INFO - 2017-01-19 13:21:06 --> Security Class Initialized
INFO - 2017-01-19 13:21:06 --> Loader Class Initialized
DEBUG - 2017-01-19 13:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:06 --> Input Class Initialized
INFO - 2017-01-19 13:21:07 --> Language Class Initialized
INFO - 2017-01-19 13:21:07 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:07 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:07 --> Loader Class Initialized
INFO - 2017-01-19 13:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:07 --> Controller Class Initialized
INFO - 2017-01-19 13:21:07 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:07 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:07 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:07 --> Model Class Initialized
INFO - 2017-01-19 13:21:07 --> Model Class Initialized
INFO - 2017-01-19 13:21:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:07 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:07 --> Total execution time: 0.2148
INFO - 2017-01-19 13:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:07 --> Controller Class Initialized
INFO - 2017-01-19 13:21:07 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:07 --> Model Class Initialized
INFO - 2017-01-19 13:21:07 --> Model Class Initialized
INFO - 2017-01-19 13:21:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:07 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:07 --> Total execution time: 0.2816
INFO - 2017-01-19 13:21:08 --> Config Class Initialized
INFO - 2017-01-19 13:21:08 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:08 --> Config Class Initialized
INFO - 2017-01-19 13:21:08 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:08 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:08 --> URI Class Initialized
INFO - 2017-01-19 13:21:08 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:08 --> Router Class Initialized
INFO - 2017-01-19 13:21:08 --> Output Class Initialized
INFO - 2017-01-19 13:21:08 --> URI Class Initialized
INFO - 2017-01-19 13:21:08 --> Security Class Initialized
INFO - 2017-01-19 13:21:08 --> Router Class Initialized
INFO - 2017-01-19 13:21:08 --> Output Class Initialized
DEBUG - 2017-01-19 13:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:08 --> Input Class Initialized
INFO - 2017-01-19 13:21:08 --> Security Class Initialized
INFO - 2017-01-19 13:21:08 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:08 --> Input Class Initialized
INFO - 2017-01-19 13:21:08 --> Language Class Initialized
INFO - 2017-01-19 13:21:08 --> Loader Class Initialized
INFO - 2017-01-19 13:21:08 --> Loader Class Initialized
INFO - 2017-01-19 13:21:08 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:08 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:08 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:08 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:08 --> Controller Class Initialized
INFO - 2017-01-19 13:21:08 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:08 --> Model Class Initialized
INFO - 2017-01-19 13:21:08 --> Model Class Initialized
INFO - 2017-01-19 13:21:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:08 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:08 --> Total execution time: 0.2315
INFO - 2017-01-19 13:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:08 --> Controller Class Initialized
INFO - 2017-01-19 13:21:08 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:08 --> Model Class Initialized
INFO - 2017-01-19 13:21:08 --> Model Class Initialized
INFO - 2017-01-19 13:21:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:08 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:08 --> Total execution time: 0.2741
INFO - 2017-01-19 13:21:10 --> Config Class Initialized
INFO - 2017-01-19 13:21:10 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:10 --> Config Class Initialized
INFO - 2017-01-19 13:21:10 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:10 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:10 --> URI Class Initialized
INFO - 2017-01-19 13:21:10 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:10 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:10 --> Output Class Initialized
INFO - 2017-01-19 13:21:10 --> URI Class Initialized
INFO - 2017-01-19 13:21:10 --> Router Class Initialized
INFO - 2017-01-19 13:21:10 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:10 --> Input Class Initialized
INFO - 2017-01-19 13:21:10 --> Output Class Initialized
INFO - 2017-01-19 13:21:10 --> Language Class Initialized
INFO - 2017-01-19 13:21:10 --> Security Class Initialized
INFO - 2017-01-19 13:21:10 --> Loader Class Initialized
INFO - 2017-01-19 13:21:10 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:10 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:10 --> Input Class Initialized
INFO - 2017-01-19 13:21:10 --> Language Class Initialized
INFO - 2017-01-19 13:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:10 --> Controller Class Initialized
INFO - 2017-01-19 13:21:10 --> Loader Class Initialized
INFO - 2017-01-19 13:21:10 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:10 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:10 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:10 --> Model Class Initialized
INFO - 2017-01-19 13:21:10 --> Model Class Initialized
INFO - 2017-01-19 13:21:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:10 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:10 --> Total execution time: 0.1274
INFO - 2017-01-19 13:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:10 --> Controller Class Initialized
INFO - 2017-01-19 13:21:10 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:10 --> Model Class Initialized
INFO - 2017-01-19 13:21:10 --> Model Class Initialized
INFO - 2017-01-19 13:21:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:10 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:10 --> Total execution time: 0.2791
INFO - 2017-01-19 13:21:11 --> Config Class Initialized
INFO - 2017-01-19 13:21:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:11 --> Config Class Initialized
INFO - 2017-01-19 13:21:11 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:11 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:11 --> URI Class Initialized
INFO - 2017-01-19 13:21:11 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:11 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:11 --> URI Class Initialized
INFO - 2017-01-19 13:21:11 --> Output Class Initialized
INFO - 2017-01-19 13:21:11 --> Security Class Initialized
INFO - 2017-01-19 13:21:11 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:11 --> Output Class Initialized
INFO - 2017-01-19 13:21:11 --> Input Class Initialized
INFO - 2017-01-19 13:21:11 --> Language Class Initialized
INFO - 2017-01-19 13:21:11 --> Security Class Initialized
INFO - 2017-01-19 13:21:11 --> Loader Class Initialized
INFO - 2017-01-19 13:21:11 --> Helper loaded: url_helper
DEBUG - 2017-01-19 13:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:11 --> Input Class Initialized
INFO - 2017-01-19 13:21:11 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:11 --> Language Class Initialized
INFO - 2017-01-19 13:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:11 --> Loader Class Initialized
INFO - 2017-01-19 13:21:11 --> Controller Class Initialized
INFO - 2017-01-19 13:21:11 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:11 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:11 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:11 --> Model Class Initialized
INFO - 2017-01-19 13:21:11 --> Model Class Initialized
INFO - 2017-01-19 13:21:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:11 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:11 --> Total execution time: 0.1692
INFO - 2017-01-19 13:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:11 --> Controller Class Initialized
INFO - 2017-01-19 13:21:11 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:11 --> Model Class Initialized
INFO - 2017-01-19 13:21:11 --> Model Class Initialized
INFO - 2017-01-19 13:21:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:11 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:11 --> Total execution time: 0.3633
INFO - 2017-01-19 13:21:12 --> Config Class Initialized
INFO - 2017-01-19 13:21:12 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:12 --> Config Class Initialized
INFO - 2017-01-19 13:21:12 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:12 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:12 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:12 --> URI Class Initialized
INFO - 2017-01-19 13:21:12 --> URI Class Initialized
INFO - 2017-01-19 13:21:12 --> Router Class Initialized
INFO - 2017-01-19 13:21:12 --> Router Class Initialized
INFO - 2017-01-19 13:21:12 --> Output Class Initialized
INFO - 2017-01-19 13:21:12 --> Output Class Initialized
INFO - 2017-01-19 13:21:12 --> Security Class Initialized
INFO - 2017-01-19 13:21:12 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:12 --> Input Class Initialized
INFO - 2017-01-19 13:21:12 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:12 --> Input Class Initialized
INFO - 2017-01-19 13:21:12 --> Language Class Initialized
INFO - 2017-01-19 13:21:12 --> Loader Class Initialized
INFO - 2017-01-19 13:21:13 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:13 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:13 --> Loader Class Initialized
INFO - 2017-01-19 13:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:13 --> Controller Class Initialized
INFO - 2017-01-19 13:21:13 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:13 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:13 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:13 --> Model Class Initialized
INFO - 2017-01-19 13:21:13 --> Model Class Initialized
INFO - 2017-01-19 13:21:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:13 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:13 --> Total execution time: 0.1242
INFO - 2017-01-19 13:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:13 --> Controller Class Initialized
INFO - 2017-01-19 13:21:13 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:13 --> Model Class Initialized
INFO - 2017-01-19 13:21:13 --> Model Class Initialized
INFO - 2017-01-19 13:21:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:13 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:13 --> Total execution time: 0.3463
INFO - 2017-01-19 13:21:14 --> Config Class Initialized
INFO - 2017-01-19 13:21:14 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:14 --> Config Class Initialized
INFO - 2017-01-19 13:21:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:14 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:14 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:14 --> URI Class Initialized
INFO - 2017-01-19 13:21:14 --> URI Class Initialized
INFO - 2017-01-19 13:21:14 --> Router Class Initialized
INFO - 2017-01-19 13:21:14 --> Router Class Initialized
INFO - 2017-01-19 13:21:14 --> Output Class Initialized
INFO - 2017-01-19 13:21:14 --> Output Class Initialized
INFO - 2017-01-19 13:21:14 --> Security Class Initialized
INFO - 2017-01-19 13:21:14 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:14 --> Input Class Initialized
INFO - 2017-01-19 13:21:14 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:14 --> Input Class Initialized
INFO - 2017-01-19 13:21:14 --> Language Class Initialized
INFO - 2017-01-19 13:21:14 --> Loader Class Initialized
INFO - 2017-01-19 13:21:14 --> Loader Class Initialized
INFO - 2017-01-19 13:21:14 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:14 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:14 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:14 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:14 --> Controller Class Initialized
INFO - 2017-01-19 13:21:14 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:14 --> Model Class Initialized
INFO - 2017-01-19 13:21:14 --> Model Class Initialized
INFO - 2017-01-19 13:21:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:14 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:14 --> Total execution time: 0.2204
INFO - 2017-01-19 13:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:14 --> Controller Class Initialized
INFO - 2017-01-19 13:21:14 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:14 --> Model Class Initialized
INFO - 2017-01-19 13:21:14 --> Model Class Initialized
INFO - 2017-01-19 13:21:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:14 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:14 --> Total execution time: 0.2578
INFO - 2017-01-19 13:21:16 --> Config Class Initialized
INFO - 2017-01-19 13:21:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:16 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:16 --> URI Class Initialized
INFO - 2017-01-19 13:21:16 --> Config Class Initialized
INFO - 2017-01-19 13:21:16 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:16 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:16 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:16 --> Output Class Initialized
INFO - 2017-01-19 13:21:16 --> URI Class Initialized
INFO - 2017-01-19 13:21:16 --> Security Class Initialized
INFO - 2017-01-19 13:21:16 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:16 --> Input Class Initialized
INFO - 2017-01-19 13:21:16 --> Output Class Initialized
INFO - 2017-01-19 13:21:16 --> Language Class Initialized
INFO - 2017-01-19 13:21:16 --> Security Class Initialized
INFO - 2017-01-19 13:21:16 --> Loader Class Initialized
INFO - 2017-01-19 13:21:16 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:16 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:16 --> Input Class Initialized
INFO - 2017-01-19 13:21:16 --> Language Class Initialized
INFO - 2017-01-19 13:21:16 --> Loader Class Initialized
INFO - 2017-01-19 13:21:16 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:16 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:16 --> Controller Class Initialized
INFO - 2017-01-19 13:21:16 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:16 --> Model Class Initialized
INFO - 2017-01-19 13:21:16 --> Model Class Initialized
INFO - 2017-01-19 13:21:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:16 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:16 --> Total execution time: 0.1486
INFO - 2017-01-19 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:16 --> Controller Class Initialized
INFO - 2017-01-19 13:21:16 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:16 --> Model Class Initialized
INFO - 2017-01-19 13:21:16 --> Model Class Initialized
INFO - 2017-01-19 13:21:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:16 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:16 --> Total execution time: 0.3672
INFO - 2017-01-19 13:21:18 --> Config Class Initialized
INFO - 2017-01-19 13:21:18 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:18 --> Config Class Initialized
INFO - 2017-01-19 13:21:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:18 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:18 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:18 --> URI Class Initialized
INFO - 2017-01-19 13:21:18 --> URI Class Initialized
INFO - 2017-01-19 13:21:18 --> Router Class Initialized
INFO - 2017-01-19 13:21:18 --> Router Class Initialized
INFO - 2017-01-19 13:21:18 --> Output Class Initialized
INFO - 2017-01-19 13:21:18 --> Output Class Initialized
INFO - 2017-01-19 13:21:18 --> Security Class Initialized
INFO - 2017-01-19 13:21:18 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:18 --> Input Class Initialized
INFO - 2017-01-19 13:21:18 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:18 --> Input Class Initialized
INFO - 2017-01-19 13:21:18 --> Loader Class Initialized
INFO - 2017-01-19 13:21:18 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:18 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:18 --> Language Class Initialized
INFO - 2017-01-19 13:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:18 --> Controller Class Initialized
INFO - 2017-01-19 13:21:18 --> Loader Class Initialized
INFO - 2017-01-19 13:21:18 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:18 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:18 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:18 --> Model Class Initialized
INFO - 2017-01-19 13:21:18 --> Model Class Initialized
INFO - 2017-01-19 13:21:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:18 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:18 --> Total execution time: 0.1252
INFO - 2017-01-19 13:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:18 --> Controller Class Initialized
INFO - 2017-01-19 13:21:18 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:18 --> Model Class Initialized
INFO - 2017-01-19 13:21:18 --> Model Class Initialized
INFO - 2017-01-19 13:21:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:18 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:18 --> Total execution time: 0.3902
INFO - 2017-01-19 13:21:20 --> Config Class Initialized
INFO - 2017-01-19 13:21:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:20 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:20 --> Config Class Initialized
INFO - 2017-01-19 13:21:20 --> URI Class Initialized
INFO - 2017-01-19 13:21:20 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:20 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:20 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:20 --> Output Class Initialized
INFO - 2017-01-19 13:21:20 --> URI Class Initialized
INFO - 2017-01-19 13:21:20 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:20 --> Input Class Initialized
INFO - 2017-01-19 13:21:20 --> Language Class Initialized
INFO - 2017-01-19 13:21:20 --> Router Class Initialized
INFO - 2017-01-19 13:21:20 --> Loader Class Initialized
INFO - 2017-01-19 13:21:20 --> Output Class Initialized
INFO - 2017-01-19 13:21:20 --> Security Class Initialized
INFO - 2017-01-19 13:21:20 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:20 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:20 --> Input Class Initialized
INFO - 2017-01-19 13:21:20 --> Language Class Initialized
INFO - 2017-01-19 13:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:20 --> Controller Class Initialized
INFO - 2017-01-19 13:21:20 --> Loader Class Initialized
INFO - 2017-01-19 13:21:20 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:20 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:20 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:20 --> Model Class Initialized
INFO - 2017-01-19 13:21:20 --> Model Class Initialized
INFO - 2017-01-19 13:21:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:20 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:20 --> Total execution time: 0.1428
INFO - 2017-01-19 13:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:20 --> Controller Class Initialized
INFO - 2017-01-19 13:21:20 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:20 --> Model Class Initialized
INFO - 2017-01-19 13:21:20 --> Model Class Initialized
INFO - 2017-01-19 13:21:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:20 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:20 --> Total execution time: 0.3082
INFO - 2017-01-19 13:21:21 --> Config Class Initialized
INFO - 2017-01-19 13:21:21 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:21 --> Config Class Initialized
DEBUG - 2017-01-19 13:21:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:21 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:21 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:21 --> URI Class Initialized
DEBUG - 2017-01-19 13:21:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:21 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:21 --> Router Class Initialized
INFO - 2017-01-19 13:21:21 --> URI Class Initialized
INFO - 2017-01-19 13:21:21 --> Output Class Initialized
INFO - 2017-01-19 13:21:21 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:21 --> Input Class Initialized
INFO - 2017-01-19 13:21:21 --> Language Class Initialized
INFO - 2017-01-19 13:21:21 --> Router Class Initialized
INFO - 2017-01-19 13:21:21 --> Loader Class Initialized
INFO - 2017-01-19 13:21:21 --> Output Class Initialized
INFO - 2017-01-19 13:21:21 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:21 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:21 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:21 --> Input Class Initialized
INFO - 2017-01-19 13:21:21 --> Controller Class Initialized
INFO - 2017-01-19 13:21:21 --> Language Class Initialized
INFO - 2017-01-19 13:21:21 --> Loader Class Initialized
INFO - 2017-01-19 13:21:21 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:21 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:21 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:21 --> Model Class Initialized
INFO - 2017-01-19 13:21:21 --> Model Class Initialized
INFO - 2017-01-19 13:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:21 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:21 --> Total execution time: 0.1513
INFO - 2017-01-19 13:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:21 --> Controller Class Initialized
INFO - 2017-01-19 13:21:21 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:21 --> Model Class Initialized
INFO - 2017-01-19 13:21:21 --> Model Class Initialized
INFO - 2017-01-19 13:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:22 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:22 --> Total execution time: 0.3948
INFO - 2017-01-19 13:21:23 --> Config Class Initialized
INFO - 2017-01-19 13:21:23 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:23 --> Config Class Initialized
INFO - 2017-01-19 13:21:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:23 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:23 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:23 --> URI Class Initialized
INFO - 2017-01-19 13:21:23 --> URI Class Initialized
INFO - 2017-01-19 13:21:23 --> Router Class Initialized
INFO - 2017-01-19 13:21:23 --> Router Class Initialized
INFO - 2017-01-19 13:21:23 --> Output Class Initialized
INFO - 2017-01-19 13:21:23 --> Output Class Initialized
INFO - 2017-01-19 13:21:23 --> Security Class Initialized
INFO - 2017-01-19 13:21:23 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:23 --> Input Class Initialized
INFO - 2017-01-19 13:21:23 --> Language Class Initialized
INFO - 2017-01-19 13:21:23 --> Loader Class Initialized
INFO - 2017-01-19 13:21:23 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:23 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:23 --> Input Class Initialized
INFO - 2017-01-19 13:21:23 --> Language Class Initialized
INFO - 2017-01-19 13:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:23 --> Controller Class Initialized
INFO - 2017-01-19 13:21:23 --> Loader Class Initialized
INFO - 2017-01-19 13:21:23 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:23 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:23 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:23 --> Total execution time: 0.1229
INFO - 2017-01-19 13:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:23 --> Controller Class Initialized
INFO - 2017-01-19 13:21:23 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:23 --> Total execution time: 0.3392
INFO - 2017-01-19 13:21:23 --> Config Class Initialized
INFO - 2017-01-19 13:21:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:23 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:23 --> URI Class Initialized
INFO - 2017-01-19 13:21:23 --> Router Class Initialized
INFO - 2017-01-19 13:21:23 --> Output Class Initialized
INFO - 2017-01-19 13:21:23 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:23 --> Input Class Initialized
INFO - 2017-01-19 13:21:23 --> Language Class Initialized
INFO - 2017-01-19 13:21:23 --> Loader Class Initialized
INFO - 2017-01-19 13:21:23 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:23 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:23 --> Controller Class Initialized
INFO - 2017-01-19 13:21:23 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Model Class Initialized
INFO - 2017-01-19 13:21:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:23 --> Total execution time: 0.1174
INFO - 2017-01-19 13:21:24 --> Config Class Initialized
INFO - 2017-01-19 13:21:24 --> Config Class Initialized
INFO - 2017-01-19 13:21:24 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:24 --> URI Class Initialized
DEBUG - 2017-01-19 13:21:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:24 --> URI Class Initialized
INFO - 2017-01-19 13:21:24 --> Router Class Initialized
INFO - 2017-01-19 13:21:24 --> Router Class Initialized
INFO - 2017-01-19 13:21:24 --> Output Class Initialized
INFO - 2017-01-19 13:21:24 --> Output Class Initialized
INFO - 2017-01-19 13:21:24 --> Security Class Initialized
INFO - 2017-01-19 13:21:24 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:24 --> Input Class Initialized
DEBUG - 2017-01-19 13:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:24 --> Input Class Initialized
INFO - 2017-01-19 13:21:24 --> Language Class Initialized
INFO - 2017-01-19 13:21:24 --> Language Class Initialized
INFO - 2017-01-19 13:21:24 --> Loader Class Initialized
INFO - 2017-01-19 13:21:24 --> Loader Class Initialized
INFO - 2017-01-19 13:21:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:24 --> Controller Class Initialized
INFO - 2017-01-19 13:21:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:24 --> Model Class Initialized
INFO - 2017-01-19 13:21:24 --> Model Class Initialized
INFO - 2017-01-19 13:21:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:24 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:24 --> Total execution time: 0.2675
INFO - 2017-01-19 13:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:24 --> Controller Class Initialized
INFO - 2017-01-19 13:21:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:24 --> Model Class Initialized
INFO - 2017-01-19 13:21:24 --> Model Class Initialized
INFO - 2017-01-19 13:21:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:24 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:24 --> Total execution time: 0.3104
INFO - 2017-01-19 13:21:26 --> Config Class Initialized
INFO - 2017-01-19 13:21:26 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:26 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:26 --> URI Class Initialized
INFO - 2017-01-19 13:21:26 --> Config Class Initialized
INFO - 2017-01-19 13:21:26 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:26 --> Router Class Initialized
DEBUG - 2017-01-19 13:21:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:26 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:26 --> URI Class Initialized
INFO - 2017-01-19 13:21:26 --> Output Class Initialized
INFO - 2017-01-19 13:21:26 --> Router Class Initialized
INFO - 2017-01-19 13:21:26 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:26 --> Input Class Initialized
INFO - 2017-01-19 13:21:26 --> Output Class Initialized
INFO - 2017-01-19 13:21:26 --> Language Class Initialized
INFO - 2017-01-19 13:21:26 --> Security Class Initialized
INFO - 2017-01-19 13:21:26 --> Loader Class Initialized
INFO - 2017-01-19 13:21:26 --> Helper loaded: url_helper
DEBUG - 2017-01-19 13:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:26 --> Input Class Initialized
INFO - 2017-01-19 13:21:26 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:26 --> Language Class Initialized
INFO - 2017-01-19 13:21:26 --> Loader Class Initialized
INFO - 2017-01-19 13:21:26 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:26 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:26 --> Controller Class Initialized
INFO - 2017-01-19 13:21:26 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:26 --> Model Class Initialized
INFO - 2017-01-19 13:21:26 --> Model Class Initialized
INFO - 2017-01-19 13:21:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:26 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:26 --> Total execution time: 0.1394
INFO - 2017-01-19 13:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:26 --> Controller Class Initialized
INFO - 2017-01-19 13:21:26 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:26 --> Model Class Initialized
INFO - 2017-01-19 13:21:26 --> Model Class Initialized
INFO - 2017-01-19 13:21:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:26 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:26 --> Total execution time: 0.4257
INFO - 2017-01-19 13:21:28 --> Config Class Initialized
INFO - 2017-01-19 13:21:28 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:28 --> Config Class Initialized
INFO - 2017-01-19 13:21:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:28 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:28 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:28 --> URI Class Initialized
INFO - 2017-01-19 13:21:28 --> URI Class Initialized
INFO - 2017-01-19 13:21:28 --> Router Class Initialized
INFO - 2017-01-19 13:21:28 --> Router Class Initialized
INFO - 2017-01-19 13:21:28 --> Output Class Initialized
INFO - 2017-01-19 13:21:28 --> Output Class Initialized
INFO - 2017-01-19 13:21:28 --> Security Class Initialized
INFO - 2017-01-19 13:21:28 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:28 --> Input Class Initialized
INFO - 2017-01-19 13:21:28 --> Language Class Initialized
INFO - 2017-01-19 13:21:28 --> Loader Class Initialized
DEBUG - 2017-01-19 13:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:28 --> Input Class Initialized
INFO - 2017-01-19 13:21:28 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:28 --> Language Class Initialized
INFO - 2017-01-19 13:21:28 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:28 --> Loader Class Initialized
INFO - 2017-01-19 13:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:28 --> Controller Class Initialized
INFO - 2017-01-19 13:21:28 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:28 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:28 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:28 --> Model Class Initialized
INFO - 2017-01-19 13:21:28 --> Model Class Initialized
INFO - 2017-01-19 13:21:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:28 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:28 --> Total execution time: 0.1340
INFO - 2017-01-19 13:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:28 --> Controller Class Initialized
INFO - 2017-01-19 13:21:28 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:28 --> Model Class Initialized
INFO - 2017-01-19 13:21:28 --> Model Class Initialized
INFO - 2017-01-19 13:21:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:28 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:28 --> Total execution time: 0.3633
INFO - 2017-01-19 13:21:32 --> Config Class Initialized
INFO - 2017-01-19 13:21:32 --> Config Class Initialized
INFO - 2017-01-19 13:21:32 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:32 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:32 --> Config Class Initialized
INFO - 2017-01-19 13:21:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:32 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:32 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:32 --> URI Class Initialized
INFO - 2017-01-19 13:21:32 --> URI Class Initialized
INFO - 2017-01-19 13:21:32 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:32 --> Router Class Initialized
INFO - 2017-01-19 13:21:32 --> URI Class Initialized
INFO - 2017-01-19 13:21:32 --> Router Class Initialized
INFO - 2017-01-19 13:21:32 --> Router Class Initialized
INFO - 2017-01-19 13:21:32 --> Output Class Initialized
INFO - 2017-01-19 13:21:32 --> Security Class Initialized
INFO - 2017-01-19 13:21:32 --> Output Class Initialized
INFO - 2017-01-19 13:21:32 --> Output Class Initialized
INFO - 2017-01-19 13:21:32 --> Security Class Initialized
INFO - 2017-01-19 13:21:32 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-19 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:32 --> Input Class Initialized
INFO - 2017-01-19 13:21:32 --> Input Class Initialized
INFO - 2017-01-19 13:21:32 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:32 --> Input Class Initialized
INFO - 2017-01-19 13:21:32 --> Language Class Initialized
INFO - 2017-01-19 13:21:32 --> Language Class Initialized
INFO - 2017-01-19 13:21:32 --> Loader Class Initialized
INFO - 2017-01-19 13:21:32 --> Loader Class Initialized
INFO - 2017-01-19 13:21:32 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:32 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:32 --> Loader Class Initialized
INFO - 2017-01-19 13:21:32 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:32 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:32 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:32 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:32 --> Controller Class Initialized
INFO - 2017-01-19 13:21:32 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:32 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:32 --> Total execution time: 0.1412
INFO - 2017-01-19 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:32 --> Controller Class Initialized
INFO - 2017-01-19 13:21:32 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:32 --> Controller Class Initialized
INFO - 2017-01-19 13:21:32 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:32 --> Config Class Initialized
INFO - 2017-01-19 13:21:32 --> Final output sent to browser
INFO - 2017-01-19 13:21:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:32 --> Total execution time: 0.2724
DEBUG - 2017-01-19 13:21:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:32 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:32 --> URI Class Initialized
INFO - 2017-01-19 13:21:32 --> Router Class Initialized
INFO - 2017-01-19 13:21:32 --> Output Class Initialized
INFO - 2017-01-19 13:21:32 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:32 --> Input Class Initialized
INFO - 2017-01-19 13:21:32 --> Language Class Initialized
INFO - 2017-01-19 13:21:32 --> Loader Class Initialized
INFO - 2017-01-19 13:21:32 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:32 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:32 --> Controller Class Initialized
INFO - 2017-01-19 13:21:32 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Model Class Initialized
INFO - 2017-01-19 13:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2017-01-19 13:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:21:32 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:32 --> Total execution time: 0.1351
INFO - 2017-01-19 13:21:52 --> Config Class Initialized
INFO - 2017-01-19 13:21:52 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:52 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:52 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:52 --> URI Class Initialized
INFO - 2017-01-19 13:21:52 --> Router Class Initialized
INFO - 2017-01-19 13:21:52 --> Output Class Initialized
INFO - 2017-01-19 13:21:52 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:52 --> Input Class Initialized
INFO - 2017-01-19 13:21:52 --> Language Class Initialized
INFO - 2017-01-19 13:21:52 --> Loader Class Initialized
INFO - 2017-01-19 13:21:52 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:52 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:52 --> Controller Class Initialized
INFO - 2017-01-19 13:21:52 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:52 --> Model Class Initialized
INFO - 2017-01-19 13:21:52 --> Model Class Initialized
INFO - 2017-01-19 13:21:52 --> Model Class Initialized
INFO - 2017-01-19 13:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:52 --> Config Class Initialized
INFO - 2017-01-19 13:21:52 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:52 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:52 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:52 --> URI Class Initialized
INFO - 2017-01-19 13:21:52 --> Router Class Initialized
INFO - 2017-01-19 13:21:52 --> Output Class Initialized
INFO - 2017-01-19 13:21:52 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:52 --> Input Class Initialized
INFO - 2017-01-19 13:21:52 --> Language Class Initialized
INFO - 2017-01-19 13:21:52 --> Loader Class Initialized
INFO - 2017-01-19 13:21:52 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:52 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:52 --> Controller Class Initialized
INFO - 2017-01-19 13:21:52 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:52 --> Model Class Initialized
INFO - 2017-01-19 13:21:52 --> Model Class Initialized
INFO - 2017-01-19 13:21:52 --> Model Class Initialized
INFO - 2017-01-19 13:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2017-01-19 13:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:21:52 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:52 --> Total execution time: 0.2044
INFO - 2017-01-19 13:21:53 --> Config Class Initialized
INFO - 2017-01-19 13:21:53 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:53 --> Config Class Initialized
INFO - 2017-01-19 13:21:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:53 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:53 --> URI Class Initialized
INFO - 2017-01-19 13:21:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:53 --> URI Class Initialized
INFO - 2017-01-19 13:21:53 --> Router Class Initialized
INFO - 2017-01-19 13:21:53 --> Router Class Initialized
INFO - 2017-01-19 13:21:53 --> Output Class Initialized
INFO - 2017-01-19 13:21:53 --> Security Class Initialized
INFO - 2017-01-19 13:21:53 --> Output Class Initialized
INFO - 2017-01-19 13:21:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:53 --> Input Class Initialized
INFO - 2017-01-19 13:21:53 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:53 --> Input Class Initialized
INFO - 2017-01-19 13:21:53 --> Language Class Initialized
INFO - 2017-01-19 13:21:53 --> Loader Class Initialized
INFO - 2017-01-19 13:21:53 --> Loader Class Initialized
INFO - 2017-01-19 13:21:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:53 --> Controller Class Initialized
INFO - 2017-01-19 13:21:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:53 --> Model Class Initialized
INFO - 2017-01-19 13:21:53 --> Model Class Initialized
INFO - 2017-01-19 13:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:53 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:53 --> Total execution time: 0.1664
INFO - 2017-01-19 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:53 --> Controller Class Initialized
INFO - 2017-01-19 13:21:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:53 --> Model Class Initialized
INFO - 2017-01-19 13:21:53 --> Model Class Initialized
INFO - 2017-01-19 13:21:53 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 13:21:53 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 13:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 13:21:53 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:53 --> Total execution time: 0.2474
INFO - 2017-01-19 13:21:56 --> Config Class Initialized
INFO - 2017-01-19 13:21:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:56 --> Config Class Initialized
INFO - 2017-01-19 13:21:56 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:56 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:56 --> URI Class Initialized
DEBUG - 2017-01-19 13:21:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:56 --> Router Class Initialized
INFO - 2017-01-19 13:21:56 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:56 --> Output Class Initialized
INFO - 2017-01-19 13:21:57 --> URI Class Initialized
INFO - 2017-01-19 13:21:57 --> Router Class Initialized
INFO - 2017-01-19 13:21:57 --> Output Class Initialized
INFO - 2017-01-19 13:21:57 --> Security Class Initialized
INFO - 2017-01-19 13:21:57 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:57 --> Input Class Initialized
INFO - 2017-01-19 13:21:57 --> Language Class Initialized
INFO - 2017-01-19 13:21:57 --> Loader Class Initialized
DEBUG - 2017-01-19 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:57 --> Input Class Initialized
INFO - 2017-01-19 13:21:57 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:57 --> Language Class Initialized
INFO - 2017-01-19 13:21:57 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:57 --> Loader Class Initialized
INFO - 2017-01-19 13:21:57 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:57 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:57 --> Controller Class Initialized
INFO - 2017-01-19 13:21:57 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:57 --> Model Class Initialized
INFO - 2017-01-19 13:21:57 --> Model Class Initialized
INFO - 2017-01-19 13:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:57 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:57 --> Total execution time: 0.1698
INFO - 2017-01-19 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:57 --> Controller Class Initialized
INFO - 2017-01-19 13:21:57 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:57 --> Model Class Initialized
INFO - 2017-01-19 13:21:57 --> Model Class Initialized
INFO - 2017-01-19 13:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:57 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:57 --> Total execution time: 0.2251
INFO - 2017-01-19 13:21:58 --> Config Class Initialized
INFO - 2017-01-19 13:21:58 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:58 --> Config Class Initialized
INFO - 2017-01-19 13:21:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:58 --> UTF-8 Support Enabled
DEBUG - 2017-01-19 13:21:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:58 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:58 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:58 --> URI Class Initialized
INFO - 2017-01-19 13:21:58 --> URI Class Initialized
INFO - 2017-01-19 13:21:58 --> Router Class Initialized
INFO - 2017-01-19 13:21:58 --> Router Class Initialized
INFO - 2017-01-19 13:21:58 --> Output Class Initialized
INFO - 2017-01-19 13:21:58 --> Output Class Initialized
INFO - 2017-01-19 13:21:58 --> Security Class Initialized
INFO - 2017-01-19 13:21:58 --> Security Class Initialized
DEBUG - 2017-01-19 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:58 --> Input Class Initialized
INFO - 2017-01-19 13:21:58 --> Language Class Initialized
DEBUG - 2017-01-19 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:58 --> Input Class Initialized
INFO - 2017-01-19 13:21:58 --> Language Class Initialized
INFO - 2017-01-19 13:21:58 --> Loader Class Initialized
INFO - 2017-01-19 13:21:58 --> Loader Class Initialized
INFO - 2017-01-19 13:21:58 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:58 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:58 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:58 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:58 --> Controller Class Initialized
INFO - 2017-01-19 13:21:58 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:58 --> Model Class Initialized
INFO - 2017-01-19 13:21:58 --> Model Class Initialized
INFO - 2017-01-19 13:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:58 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:58 --> Total execution time: 0.1371
INFO - 2017-01-19 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:58 --> Controller Class Initialized
INFO - 2017-01-19 13:21:58 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:58 --> Model Class Initialized
INFO - 2017-01-19 13:21:58 --> Model Class Initialized
INFO - 2017-01-19 13:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:58 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:58 --> Total execution time: 0.2659
INFO - 2017-01-19 13:21:59 --> Config Class Initialized
INFO - 2017-01-19 13:21:59 --> Hooks Class Initialized
INFO - 2017-01-19 13:21:59 --> Config Class Initialized
INFO - 2017-01-19 13:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:59 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:21:59 --> Utf8 Class Initialized
INFO - 2017-01-19 13:21:59 --> URI Class Initialized
INFO - 2017-01-19 13:21:59 --> URI Class Initialized
INFO - 2017-01-19 13:21:59 --> Router Class Initialized
INFO - 2017-01-19 13:21:59 --> Router Class Initialized
INFO - 2017-01-19 13:21:59 --> Output Class Initialized
INFO - 2017-01-19 13:21:59 --> Security Class Initialized
INFO - 2017-01-19 13:21:59 --> Output Class Initialized
DEBUG - 2017-01-19 13:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:59 --> Input Class Initialized
INFO - 2017-01-19 13:21:59 --> Language Class Initialized
INFO - 2017-01-19 13:21:59 --> Security Class Initialized
INFO - 2017-01-19 13:21:59 --> Loader Class Initialized
INFO - 2017-01-19 13:21:59 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:59 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:21:59 --> Input Class Initialized
INFO - 2017-01-19 13:21:59 --> Language Class Initialized
INFO - 2017-01-19 13:21:59 --> Loader Class Initialized
INFO - 2017-01-19 13:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:59 --> Controller Class Initialized
INFO - 2017-01-19 13:21:59 --> Helper loaded: url_helper
INFO - 2017-01-19 13:21:59 --> Helper loaded: language_helper
INFO - 2017-01-19 13:21:59 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:59 --> Model Class Initialized
INFO - 2017-01-19 13:21:59 --> Model Class Initialized
INFO - 2017-01-19 13:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:59 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:59 --> Total execution time: 0.1617
INFO - 2017-01-19 13:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:21:59 --> Controller Class Initialized
INFO - 2017-01-19 13:21:59 --> Database Driver Class Initialized
INFO - 2017-01-19 13:21:59 --> Model Class Initialized
INFO - 2017-01-19 13:21:59 --> Model Class Initialized
INFO - 2017-01-19 13:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:21:59 --> Final output sent to browser
DEBUG - 2017-01-19 13:21:59 --> Total execution time: 0.2194
INFO - 2017-01-19 13:22:00 --> Config Class Initialized
INFO - 2017-01-19 13:22:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:00 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:00 --> URI Class Initialized
INFO - 2017-01-19 13:22:00 --> Router Class Initialized
INFO - 2017-01-19 13:22:00 --> Config Class Initialized
INFO - 2017-01-19 13:22:00 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:00 --> Output Class Initialized
INFO - 2017-01-19 13:22:00 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:00 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:00 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:00 --> Input Class Initialized
INFO - 2017-01-19 13:22:00 --> Router Class Initialized
INFO - 2017-01-19 13:22:00 --> Language Class Initialized
INFO - 2017-01-19 13:22:00 --> Loader Class Initialized
INFO - 2017-01-19 13:22:01 --> Output Class Initialized
INFO - 2017-01-19 13:22:01 --> Security Class Initialized
INFO - 2017-01-19 13:22:01 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:01 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:01 --> Input Class Initialized
INFO - 2017-01-19 13:22:01 --> Language Class Initialized
INFO - 2017-01-19 13:22:01 --> Loader Class Initialized
INFO - 2017-01-19 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:01 --> Controller Class Initialized
INFO - 2017-01-19 13:22:01 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:01 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:01 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:01 --> Model Class Initialized
INFO - 2017-01-19 13:22:01 --> Model Class Initialized
INFO - 2017-01-19 13:22:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:01 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:01 --> Total execution time: 0.2139
INFO - 2017-01-19 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:01 --> Controller Class Initialized
INFO - 2017-01-19 13:22:01 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:01 --> Model Class Initialized
INFO - 2017-01-19 13:22:01 --> Model Class Initialized
INFO - 2017-01-19 13:22:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:01 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:01 --> Total execution time: 0.2655
INFO - 2017-01-19 13:22:02 --> Config Class Initialized
INFO - 2017-01-19 13:22:02 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:02 --> Config Class Initialized
INFO - 2017-01-19 13:22:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:02 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:02 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:02 --> URI Class Initialized
INFO - 2017-01-19 13:22:02 --> URI Class Initialized
INFO - 2017-01-19 13:22:02 --> Router Class Initialized
INFO - 2017-01-19 13:22:02 --> Router Class Initialized
INFO - 2017-01-19 13:22:02 --> Output Class Initialized
INFO - 2017-01-19 13:22:02 --> Output Class Initialized
INFO - 2017-01-19 13:22:02 --> Security Class Initialized
INFO - 2017-01-19 13:22:02 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:02 --> Input Class Initialized
INFO - 2017-01-19 13:22:02 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:02 --> Input Class Initialized
INFO - 2017-01-19 13:22:02 --> Language Class Initialized
INFO - 2017-01-19 13:22:02 --> Loader Class Initialized
INFO - 2017-01-19 13:22:02 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:02 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:02 --> Loader Class Initialized
INFO - 2017-01-19 13:22:02 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:02 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:02 --> Controller Class Initialized
INFO - 2017-01-19 13:22:02 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:02 --> Model Class Initialized
INFO - 2017-01-19 13:22:02 --> Model Class Initialized
INFO - 2017-01-19 13:22:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:02 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:02 --> Total execution time: 0.1227
INFO - 2017-01-19 13:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:02 --> Controller Class Initialized
INFO - 2017-01-19 13:22:02 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:02 --> Model Class Initialized
INFO - 2017-01-19 13:22:02 --> Model Class Initialized
INFO - 2017-01-19 13:22:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:02 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:02 --> Total execution time: 0.2373
INFO - 2017-01-19 13:22:03 --> Config Class Initialized
INFO - 2017-01-19 13:22:03 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:03 --> Config Class Initialized
INFO - 2017-01-19 13:22:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:03 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:03 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:03 --> URI Class Initialized
INFO - 2017-01-19 13:22:03 --> URI Class Initialized
INFO - 2017-01-19 13:22:03 --> Router Class Initialized
INFO - 2017-01-19 13:22:03 --> Router Class Initialized
INFO - 2017-01-19 13:22:03 --> Output Class Initialized
INFO - 2017-01-19 13:22:03 --> Output Class Initialized
INFO - 2017-01-19 13:22:03 --> Security Class Initialized
INFO - 2017-01-19 13:22:03 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:03 --> Input Class Initialized
INFO - 2017-01-19 13:22:03 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:03 --> Input Class Initialized
INFO - 2017-01-19 13:22:03 --> Language Class Initialized
INFO - 2017-01-19 13:22:03 --> Loader Class Initialized
INFO - 2017-01-19 13:22:03 --> Loader Class Initialized
INFO - 2017-01-19 13:22:03 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:03 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:03 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:03 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:03 --> Controller Class Initialized
INFO - 2017-01-19 13:22:03 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:03 --> Model Class Initialized
INFO - 2017-01-19 13:22:03 --> Model Class Initialized
INFO - 2017-01-19 13:22:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:03 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:03 --> Total execution time: 0.1289
INFO - 2017-01-19 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:03 --> Controller Class Initialized
INFO - 2017-01-19 13:22:03 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:03 --> Model Class Initialized
INFO - 2017-01-19 13:22:03 --> Model Class Initialized
INFO - 2017-01-19 13:22:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:03 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:03 --> Total execution time: 0.2552
INFO - 2017-01-19 13:22:04 --> Config Class Initialized
INFO - 2017-01-19 13:22:04 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:04 --> Config Class Initialized
INFO - 2017-01-19 13:22:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:04 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:04 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:04 --> URI Class Initialized
INFO - 2017-01-19 13:22:04 --> URI Class Initialized
INFO - 2017-01-19 13:22:04 --> Router Class Initialized
INFO - 2017-01-19 13:22:04 --> Router Class Initialized
INFO - 2017-01-19 13:22:04 --> Output Class Initialized
INFO - 2017-01-19 13:22:04 --> Output Class Initialized
INFO - 2017-01-19 13:22:04 --> Security Class Initialized
INFO - 2017-01-19 13:22:04 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:04 --> Input Class Initialized
INFO - 2017-01-19 13:22:04 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:04 --> Input Class Initialized
INFO - 2017-01-19 13:22:04 --> Loader Class Initialized
INFO - 2017-01-19 13:22:04 --> Language Class Initialized
INFO - 2017-01-19 13:22:04 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:04 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:04 --> Loader Class Initialized
INFO - 2017-01-19 13:22:04 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:04 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:04 --> Controller Class Initialized
INFO - 2017-01-19 13:22:04 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:04 --> Model Class Initialized
INFO - 2017-01-19 13:22:04 --> Model Class Initialized
INFO - 2017-01-19 13:22:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:04 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:04 --> Total execution time: 0.1215
INFO - 2017-01-19 13:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:04 --> Controller Class Initialized
INFO - 2017-01-19 13:22:04 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:04 --> Model Class Initialized
INFO - 2017-01-19 13:22:04 --> Model Class Initialized
INFO - 2017-01-19 13:22:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:05 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:05 --> Total execution time: 0.2412
INFO - 2017-01-19 13:22:06 --> Config Class Initialized
INFO - 2017-01-19 13:22:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:06 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:06 --> Config Class Initialized
INFO - 2017-01-19 13:22:06 --> URI Class Initialized
INFO - 2017-01-19 13:22:06 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:06 --> Router Class Initialized
DEBUG - 2017-01-19 13:22:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:06 --> Output Class Initialized
INFO - 2017-01-19 13:22:06 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:06 --> Security Class Initialized
INFO - 2017-01-19 13:22:06 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:06 --> Input Class Initialized
INFO - 2017-01-19 13:22:06 --> Router Class Initialized
INFO - 2017-01-19 13:22:06 --> Language Class Initialized
INFO - 2017-01-19 13:22:06 --> Output Class Initialized
INFO - 2017-01-19 13:22:06 --> Loader Class Initialized
INFO - 2017-01-19 13:22:06 --> Security Class Initialized
INFO - 2017-01-19 13:22:06 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:06 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:06 --> Input Class Initialized
INFO - 2017-01-19 13:22:06 --> Language Class Initialized
INFO - 2017-01-19 13:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:06 --> Controller Class Initialized
INFO - 2017-01-19 13:22:06 --> Loader Class Initialized
INFO - 2017-01-19 13:22:06 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:06 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:06 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:06 --> Model Class Initialized
INFO - 2017-01-19 13:22:06 --> Model Class Initialized
INFO - 2017-01-19 13:22:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:06 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:06 --> Total execution time: 0.1348
INFO - 2017-01-19 13:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:06 --> Controller Class Initialized
INFO - 2017-01-19 13:22:06 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:06 --> Model Class Initialized
INFO - 2017-01-19 13:22:06 --> Model Class Initialized
INFO - 2017-01-19 13:22:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:06 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:06 --> Total execution time: 0.3280
INFO - 2017-01-19 13:22:07 --> Config Class Initialized
INFO - 2017-01-19 13:22:07 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:07 --> Config Class Initialized
INFO - 2017-01-19 13:22:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:07 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:07 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:07 --> URI Class Initialized
INFO - 2017-01-19 13:22:07 --> URI Class Initialized
INFO - 2017-01-19 13:22:07 --> Router Class Initialized
INFO - 2017-01-19 13:22:07 --> Output Class Initialized
INFO - 2017-01-19 13:22:07 --> Router Class Initialized
INFO - 2017-01-19 13:22:07 --> Security Class Initialized
INFO - 2017-01-19 13:22:07 --> Output Class Initialized
DEBUG - 2017-01-19 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:07 --> Input Class Initialized
INFO - 2017-01-19 13:22:07 --> Security Class Initialized
INFO - 2017-01-19 13:22:07 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:07 --> Loader Class Initialized
INFO - 2017-01-19 13:22:07 --> Input Class Initialized
INFO - 2017-01-19 13:22:07 --> Language Class Initialized
INFO - 2017-01-19 13:22:07 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:07 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:07 --> Loader Class Initialized
INFO - 2017-01-19 13:22:07 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:07 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:07 --> Controller Class Initialized
INFO - 2017-01-19 13:22:07 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:07 --> Model Class Initialized
INFO - 2017-01-19 13:22:07 --> Model Class Initialized
INFO - 2017-01-19 13:22:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:07 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:07 --> Total execution time: 0.1251
INFO - 2017-01-19 13:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:07 --> Controller Class Initialized
INFO - 2017-01-19 13:22:07 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:07 --> Model Class Initialized
INFO - 2017-01-19 13:22:07 --> Model Class Initialized
INFO - 2017-01-19 13:22:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:07 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:07 --> Total execution time: 0.3102
INFO - 2017-01-19 13:22:09 --> Config Class Initialized
INFO - 2017-01-19 13:22:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:09 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:09 --> URI Class Initialized
INFO - 2017-01-19 13:22:09 --> Config Class Initialized
INFO - 2017-01-19 13:22:09 --> Router Class Initialized
INFO - 2017-01-19 13:22:09 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:09 --> Output Class Initialized
DEBUG - 2017-01-19 13:22:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:09 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:09 --> Security Class Initialized
INFO - 2017-01-19 13:22:09 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:09 --> Input Class Initialized
INFO - 2017-01-19 13:22:09 --> Router Class Initialized
INFO - 2017-01-19 13:22:09 --> Language Class Initialized
INFO - 2017-01-19 13:22:09 --> Loader Class Initialized
INFO - 2017-01-19 13:22:09 --> Output Class Initialized
INFO - 2017-01-19 13:22:09 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:09 --> Security Class Initialized
INFO - 2017-01-19 13:22:09 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:09 --> Input Class Initialized
INFO - 2017-01-19 13:22:09 --> Controller Class Initialized
INFO - 2017-01-19 13:22:09 --> Language Class Initialized
INFO - 2017-01-19 13:22:09 --> Loader Class Initialized
INFO - 2017-01-19 13:22:09 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:09 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:09 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:09 --> Model Class Initialized
INFO - 2017-01-19 13:22:09 --> Model Class Initialized
INFO - 2017-01-19 13:22:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:09 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:09 --> Total execution time: 0.1492
INFO - 2017-01-19 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:09 --> Controller Class Initialized
INFO - 2017-01-19 13:22:09 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:09 --> Model Class Initialized
INFO - 2017-01-19 13:22:09 --> Model Class Initialized
INFO - 2017-01-19 13:22:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:09 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:09 --> Total execution time: 0.3080
INFO - 2017-01-19 13:22:10 --> Config Class Initialized
INFO - 2017-01-19 13:22:10 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:10 --> Config Class Initialized
INFO - 2017-01-19 13:22:10 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:10 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:10 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:10 --> URI Class Initialized
INFO - 2017-01-19 13:22:10 --> URI Class Initialized
INFO - 2017-01-19 13:22:10 --> Router Class Initialized
INFO - 2017-01-19 13:22:10 --> Router Class Initialized
INFO - 2017-01-19 13:22:10 --> Output Class Initialized
INFO - 2017-01-19 13:22:10 --> Output Class Initialized
INFO - 2017-01-19 13:22:10 --> Security Class Initialized
INFO - 2017-01-19 13:22:10 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-19 13:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:10 --> Input Class Initialized
INFO - 2017-01-19 13:22:10 --> Input Class Initialized
INFO - 2017-01-19 13:22:10 --> Language Class Initialized
INFO - 2017-01-19 13:22:10 --> Language Class Initialized
INFO - 2017-01-19 13:22:10 --> Loader Class Initialized
INFO - 2017-01-19 13:22:10 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:10 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:10 --> Loader Class Initialized
INFO - 2017-01-19 13:22:10 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:10 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:10 --> Controller Class Initialized
INFO - 2017-01-19 13:22:10 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:10 --> Model Class Initialized
INFO - 2017-01-19 13:22:10 --> Model Class Initialized
INFO - 2017-01-19 13:22:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:11 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:11 --> Total execution time: 0.2894
INFO - 2017-01-19 13:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:11 --> Controller Class Initialized
INFO - 2017-01-19 13:22:11 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:11 --> Model Class Initialized
INFO - 2017-01-19 13:22:11 --> Model Class Initialized
INFO - 2017-01-19 13:22:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:11 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:11 --> Total execution time: 0.3495
INFO - 2017-01-19 13:22:12 --> Config Class Initialized
INFO - 2017-01-19 13:22:12 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:12 --> Config Class Initialized
INFO - 2017-01-19 13:22:12 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:12 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:12 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:12 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:12 --> Router Class Initialized
INFO - 2017-01-19 13:22:12 --> URI Class Initialized
INFO - 2017-01-19 13:22:12 --> Output Class Initialized
INFO - 2017-01-19 13:22:12 --> Router Class Initialized
INFO - 2017-01-19 13:22:12 --> Security Class Initialized
INFO - 2017-01-19 13:22:12 --> Output Class Initialized
INFO - 2017-01-19 13:22:12 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:12 --> Input Class Initialized
DEBUG - 2017-01-19 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:12 --> Input Class Initialized
INFO - 2017-01-19 13:22:12 --> Language Class Initialized
INFO - 2017-01-19 13:22:12 --> Language Class Initialized
INFO - 2017-01-19 13:22:12 --> Loader Class Initialized
INFO - 2017-01-19 13:22:12 --> Loader Class Initialized
INFO - 2017-01-19 13:22:12 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:12 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:12 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:12 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:12 --> Controller Class Initialized
INFO - 2017-01-19 13:22:12 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:12 --> Model Class Initialized
INFO - 2017-01-19 13:22:12 --> Model Class Initialized
INFO - 2017-01-19 13:22:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:12 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:12 --> Total execution time: 0.1386
INFO - 2017-01-19 13:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:12 --> Controller Class Initialized
INFO - 2017-01-19 13:22:12 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:12 --> Model Class Initialized
INFO - 2017-01-19 13:22:12 --> Model Class Initialized
INFO - 2017-01-19 13:22:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:12 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:12 --> Total execution time: 0.3625
INFO - 2017-01-19 13:22:13 --> Config Class Initialized
INFO - 2017-01-19 13:22:13 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:13 --> Config Class Initialized
INFO - 2017-01-19 13:22:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-01-19 13:22:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:13 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:13 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:13 --> URI Class Initialized
INFO - 2017-01-19 13:22:13 --> Router Class Initialized
INFO - 2017-01-19 13:22:13 --> Output Class Initialized
INFO - 2017-01-19 13:22:13 --> URI Class Initialized
INFO - 2017-01-19 13:22:13 --> Router Class Initialized
INFO - 2017-01-19 13:22:13 --> Security Class Initialized
INFO - 2017-01-19 13:22:13 --> Output Class Initialized
INFO - 2017-01-19 13:22:13 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:13 --> Input Class Initialized
INFO - 2017-01-19 13:22:13 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:13 --> Input Class Initialized
INFO - 2017-01-19 13:22:13 --> Loader Class Initialized
INFO - 2017-01-19 13:22:13 --> Language Class Initialized
INFO - 2017-01-19 13:22:13 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:13 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:13 --> Loader Class Initialized
INFO - 2017-01-19 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:13 --> Controller Class Initialized
INFO - 2017-01-19 13:22:13 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:13 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:13 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:13 --> Model Class Initialized
INFO - 2017-01-19 13:22:13 --> Model Class Initialized
INFO - 2017-01-19 13:22:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:13 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:13 --> Total execution time: 0.1207
INFO - 2017-01-19 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:13 --> Controller Class Initialized
INFO - 2017-01-19 13:22:13 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:13 --> Model Class Initialized
INFO - 2017-01-19 13:22:13 --> Model Class Initialized
INFO - 2017-01-19 13:22:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:13 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:13 --> Total execution time: 0.2578
INFO - 2017-01-19 13:22:15 --> Config Class Initialized
INFO - 2017-01-19 13:22:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:15 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:15 --> URI Class Initialized
INFO - 2017-01-19 13:22:15 --> Router Class Initialized
INFO - 2017-01-19 13:22:15 --> Output Class Initialized
INFO - 2017-01-19 13:22:15 --> Config Class Initialized
INFO - 2017-01-19 13:22:15 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:15 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:15 --> Input Class Initialized
DEBUG - 2017-01-19 13:22:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:15 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:15 --> Language Class Initialized
INFO - 2017-01-19 13:22:15 --> URI Class Initialized
INFO - 2017-01-19 13:22:15 --> Router Class Initialized
INFO - 2017-01-19 13:22:15 --> Output Class Initialized
INFO - 2017-01-19 13:22:15 --> Loader Class Initialized
INFO - 2017-01-19 13:22:15 --> Security Class Initialized
INFO - 2017-01-19 13:22:15 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:15 --> Helper loaded: language_helper
DEBUG - 2017-01-19 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:15 --> Input Class Initialized
INFO - 2017-01-19 13:22:15 --> Language Class Initialized
INFO - 2017-01-19 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:15 --> Controller Class Initialized
INFO - 2017-01-19 13:22:15 --> Loader Class Initialized
INFO - 2017-01-19 13:22:15 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:15 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:15 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:15 --> Model Class Initialized
INFO - 2017-01-19 13:22:15 --> Model Class Initialized
INFO - 2017-01-19 13:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:15 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:15 --> Total execution time: 0.1491
INFO - 2017-01-19 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:15 --> Controller Class Initialized
INFO - 2017-01-19 13:22:15 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:15 --> Model Class Initialized
INFO - 2017-01-19 13:22:15 --> Model Class Initialized
INFO - 2017-01-19 13:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:15 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:15 --> Total execution time: 0.3612
INFO - 2017-01-19 13:22:16 --> Config Class Initialized
INFO - 2017-01-19 13:22:16 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:16 --> Config Class Initialized
INFO - 2017-01-19 13:22:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:16 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:16 --> URI Class Initialized
INFO - 2017-01-19 13:22:16 --> Router Class Initialized
INFO - 2017-01-19 13:22:16 --> Output Class Initialized
INFO - 2017-01-19 13:22:16 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:16 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:16 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:16 --> Router Class Initialized
INFO - 2017-01-19 13:22:16 --> Input Class Initialized
INFO - 2017-01-19 13:22:16 --> Language Class Initialized
INFO - 2017-01-19 13:22:16 --> Output Class Initialized
INFO - 2017-01-19 13:22:16 --> Loader Class Initialized
INFO - 2017-01-19 13:22:16 --> Security Class Initialized
INFO - 2017-01-19 13:22:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 13:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:16 --> Input Class Initialized
INFO - 2017-01-19 13:22:16 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:16 --> Language Class Initialized
INFO - 2017-01-19 13:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:16 --> Controller Class Initialized
INFO - 2017-01-19 13:22:16 --> Loader Class Initialized
INFO - 2017-01-19 13:22:16 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:16 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:16 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:16 --> Model Class Initialized
INFO - 2017-01-19 13:22:16 --> Model Class Initialized
INFO - 2017-01-19 13:22:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:16 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:16 --> Total execution time: 0.2483
INFO - 2017-01-19 13:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:16 --> Controller Class Initialized
INFO - 2017-01-19 13:22:16 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:16 --> Model Class Initialized
INFO - 2017-01-19 13:22:16 --> Model Class Initialized
INFO - 2017-01-19 13:22:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:16 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:16 --> Total execution time: 0.3126
INFO - 2017-01-19 13:22:18 --> Config Class Initialized
INFO - 2017-01-19 13:22:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:18 --> Config Class Initialized
INFO - 2017-01-19 13:22:18 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:18 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:18 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:18 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:18 --> URI Class Initialized
INFO - 2017-01-19 13:22:18 --> Router Class Initialized
INFO - 2017-01-19 13:22:18 --> Output Class Initialized
INFO - 2017-01-19 13:22:18 --> Router Class Initialized
INFO - 2017-01-19 13:22:18 --> Output Class Initialized
INFO - 2017-01-19 13:22:18 --> Security Class Initialized
INFO - 2017-01-19 13:22:18 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:18 --> Input Class Initialized
INFO - 2017-01-19 13:22:18 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:18 --> Input Class Initialized
INFO - 2017-01-19 13:22:18 --> Language Class Initialized
INFO - 2017-01-19 13:22:18 --> Loader Class Initialized
INFO - 2017-01-19 13:22:18 --> Loader Class Initialized
INFO - 2017-01-19 13:22:18 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:18 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:18 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:18 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:18 --> Controller Class Initialized
INFO - 2017-01-19 13:22:18 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:18 --> Model Class Initialized
INFO - 2017-01-19 13:22:18 --> Model Class Initialized
INFO - 2017-01-19 13:22:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:18 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:18 --> Total execution time: 0.3441
INFO - 2017-01-19 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:18 --> Controller Class Initialized
INFO - 2017-01-19 13:22:18 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:18 --> Model Class Initialized
INFO - 2017-01-19 13:22:18 --> Model Class Initialized
INFO - 2017-01-19 13:22:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:18 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:18 --> Total execution time: 0.4068
INFO - 2017-01-19 13:22:19 --> Config Class Initialized
INFO - 2017-01-19 13:22:19 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:19 --> Config Class Initialized
INFO - 2017-01-19 13:22:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-19 13:22:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:19 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:19 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:19 --> URI Class Initialized
INFO - 2017-01-19 13:22:19 --> URI Class Initialized
INFO - 2017-01-19 13:22:19 --> Router Class Initialized
INFO - 2017-01-19 13:22:19 --> Output Class Initialized
INFO - 2017-01-19 13:22:19 --> Router Class Initialized
INFO - 2017-01-19 13:22:19 --> Security Class Initialized
INFO - 2017-01-19 13:22:19 --> Output Class Initialized
DEBUG - 2017-01-19 13:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:19 --> Input Class Initialized
INFO - 2017-01-19 13:22:19 --> Language Class Initialized
INFO - 2017-01-19 13:22:19 --> Security Class Initialized
INFO - 2017-01-19 13:22:19 --> Loader Class Initialized
DEBUG - 2017-01-19 13:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:19 --> Input Class Initialized
INFO - 2017-01-19 13:22:19 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:19 --> Language Class Initialized
INFO - 2017-01-19 13:22:19 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:19 --> Loader Class Initialized
INFO - 2017-01-19 13:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:19 --> Controller Class Initialized
INFO - 2017-01-19 13:22:19 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:19 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:19 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:19 --> Model Class Initialized
INFO - 2017-01-19 13:22:19 --> Model Class Initialized
INFO - 2017-01-19 13:22:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:19 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:19 --> Total execution time: 0.1146
INFO - 2017-01-19 13:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:19 --> Controller Class Initialized
INFO - 2017-01-19 13:22:19 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:19 --> Model Class Initialized
INFO - 2017-01-19 13:22:19 --> Model Class Initialized
INFO - 2017-01-19 13:22:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:19 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:19 --> Total execution time: 0.3361
INFO - 2017-01-19 13:22:20 --> Config Class Initialized
INFO - 2017-01-19 13:22:20 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:20 --> Config Class Initialized
INFO - 2017-01-19 13:22:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:20 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:20 --> URI Class Initialized
INFO - 2017-01-19 13:22:20 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:20 --> Router Class Initialized
INFO - 2017-01-19 13:22:20 --> URI Class Initialized
INFO - 2017-01-19 13:22:20 --> Output Class Initialized
INFO - 2017-01-19 13:22:20 --> Router Class Initialized
INFO - 2017-01-19 13:22:20 --> Security Class Initialized
INFO - 2017-01-19 13:22:20 --> Output Class Initialized
INFO - 2017-01-19 13:22:20 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:20 --> Input Class Initialized
DEBUG - 2017-01-19 13:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:20 --> Input Class Initialized
INFO - 2017-01-19 13:22:20 --> Language Class Initialized
INFO - 2017-01-19 13:22:20 --> Language Class Initialized
INFO - 2017-01-19 13:22:20 --> Loader Class Initialized
INFO - 2017-01-19 13:22:20 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:20 --> Loader Class Initialized
INFO - 2017-01-19 13:22:20 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:20 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:20 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:21 --> Controller Class Initialized
INFO - 2017-01-19 13:22:21 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:21 --> Model Class Initialized
INFO - 2017-01-19 13:22:21 --> Model Class Initialized
INFO - 2017-01-19 13:22:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:21 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:21 --> Total execution time: 0.1361
INFO - 2017-01-19 13:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:21 --> Controller Class Initialized
INFO - 2017-01-19 13:22:21 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:21 --> Model Class Initialized
INFO - 2017-01-19 13:22:21 --> Model Class Initialized
INFO - 2017-01-19 13:22:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:21 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:21 --> Total execution time: 0.4279
INFO - 2017-01-19 13:22:22 --> Config Class Initialized
INFO - 2017-01-19 13:22:22 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:22 --> Config Class Initialized
INFO - 2017-01-19 13:22:22 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:22 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:22 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:22 --> URI Class Initialized
INFO - 2017-01-19 13:22:22 --> URI Class Initialized
INFO - 2017-01-19 13:22:22 --> Router Class Initialized
INFO - 2017-01-19 13:22:22 --> Router Class Initialized
INFO - 2017-01-19 13:22:22 --> Output Class Initialized
INFO - 2017-01-19 13:22:22 --> Output Class Initialized
INFO - 2017-01-19 13:22:22 --> Security Class Initialized
INFO - 2017-01-19 13:22:22 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:22 --> Input Class Initialized
INFO - 2017-01-19 13:22:22 --> Language Class Initialized
DEBUG - 2017-01-19 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:22 --> Input Class Initialized
INFO - 2017-01-19 13:22:22 --> Language Class Initialized
INFO - 2017-01-19 13:22:22 --> Loader Class Initialized
INFO - 2017-01-19 13:22:22 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:22 --> Loader Class Initialized
INFO - 2017-01-19 13:22:22 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:22 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:22 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:22 --> Controller Class Initialized
INFO - 2017-01-19 13:22:22 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:22 --> Model Class Initialized
INFO - 2017-01-19 13:22:22 --> Model Class Initialized
INFO - 2017-01-19 13:22:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:22 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:22 --> Total execution time: 0.1353
INFO - 2017-01-19 13:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:22 --> Controller Class Initialized
INFO - 2017-01-19 13:22:22 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:22 --> Model Class Initialized
INFO - 2017-01-19 13:22:22 --> Model Class Initialized
INFO - 2017-01-19 13:22:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:23 --> Config Class Initialized
INFO - 2017-01-19 13:22:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:23 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:23 --> URI Class Initialized
INFO - 2017-01-19 13:22:23 --> Router Class Initialized
INFO - 2017-01-19 13:22:23 --> Output Class Initialized
INFO - 2017-01-19 13:22:23 --> Security Class Initialized
INFO - 2017-01-19 13:22:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-19 13:22:23 --> Total execution time: 0.4405
INFO - 2017-01-19 13:22:23 --> Input Class Initialized
INFO - 2017-01-19 13:22:23 --> Language Class Initialized
INFO - 2017-01-19 13:22:23 --> Loader Class Initialized
INFO - 2017-01-19 13:22:23 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:23 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:23 --> Controller Class Initialized
INFO - 2017-01-19 13:22:23 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:23 --> Model Class Initialized
INFO - 2017-01-19 13:22:23 --> Model Class Initialized
INFO - 2017-01-19 13:22:23 --> Model Class Initialized
INFO - 2017-01-19 13:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:23 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:23 --> Total execution time: 0.1454
INFO - 2017-01-19 13:22:24 --> Config Class Initialized
INFO - 2017-01-19 13:22:24 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:24 --> Config Class Initialized
INFO - 2017-01-19 13:22:24 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:24 --> Config Class Initialized
INFO - 2017-01-19 13:22:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:24 --> Utf8 Class Initialized
DEBUG - 2017-01-19 13:22:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:24 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:24 --> URI Class Initialized
INFO - 2017-01-19 13:22:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:24 --> Router Class Initialized
INFO - 2017-01-19 13:22:24 --> URI Class Initialized
INFO - 2017-01-19 13:22:24 --> Router Class Initialized
INFO - 2017-01-19 13:22:24 --> Output Class Initialized
INFO - 2017-01-19 13:22:24 --> Router Class Initialized
INFO - 2017-01-19 13:22:24 --> Security Class Initialized
INFO - 2017-01-19 13:22:24 --> Output Class Initialized
INFO - 2017-01-19 13:22:24 --> Output Class Initialized
INFO - 2017-01-19 13:22:24 --> Security Class Initialized
INFO - 2017-01-19 13:22:24 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:24 --> Input Class Initialized
DEBUG - 2017-01-19 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:24 --> Input Class Initialized
DEBUG - 2017-01-19 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:24 --> Input Class Initialized
INFO - 2017-01-19 13:22:24 --> Language Class Initialized
INFO - 2017-01-19 13:22:24 --> Language Class Initialized
INFO - 2017-01-19 13:22:24 --> Language Class Initialized
INFO - 2017-01-19 13:22:24 --> Loader Class Initialized
INFO - 2017-01-19 13:22:24 --> Loader Class Initialized
INFO - 2017-01-19 13:22:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:24 --> Loader Class Initialized
INFO - 2017-01-19 13:22:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:24 --> Controller Class Initialized
INFO - 2017-01-19 13:22:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:24 --> Controller Class Initialized
INFO - 2017-01-19 13:22:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Config Class Initialized
INFO - 2017-01-19 13:22:24 --> Hooks Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Language file loaded: language/indonesia/basic_lang.php
DEBUG - 2017-01-19 13:22:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:24 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:24 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:24 --> Total execution time: 0.2622
INFO - 2017-01-19 13:22:24 --> URI Class Initialized
INFO - 2017-01-19 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:24 --> Controller Class Initialized
INFO - 2017-01-19 13:22:24 --> Router Class Initialized
INFO - 2017-01-19 13:22:24 --> Output Class Initialized
INFO - 2017-01-19 13:22:24 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:24 --> Input Class Initialized
INFO - 2017-01-19 13:22:24 --> Language Class Initialized
INFO - 2017-01-19 13:22:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Loader Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:24 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:24 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:24 --> Total execution time: 0.3153
INFO - 2017-01-19 13:22:24 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:24 --> Controller Class Initialized
INFO - 2017-01-19 13:22:24 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Model Class Initialized
INFO - 2017-01-19 13:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:22:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2017-01-19 13:22:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:22:25 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:25 --> Total execution time: 0.1465
INFO - 2017-01-19 13:22:27 --> Config Class Initialized
INFO - 2017-01-19 13:22:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:27 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:27 --> URI Class Initialized
DEBUG - 2017-01-19 13:22:27 --> No URI present. Default controller set.
INFO - 2017-01-19 13:22:27 --> Router Class Initialized
INFO - 2017-01-19 13:22:27 --> Output Class Initialized
INFO - 2017-01-19 13:22:27 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:27 --> Input Class Initialized
INFO - 2017-01-19 13:22:27 --> Language Class Initialized
INFO - 2017-01-19 13:22:27 --> Loader Class Initialized
INFO - 2017-01-19 13:22:27 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:27 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:27 --> Controller Class Initialized
INFO - 2017-01-19 13:22:27 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:27 --> Model Class Initialized
INFO - 2017-01-19 13:22:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:27 --> Config Class Initialized
INFO - 2017-01-19 13:22:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:22:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:22:27 --> Utf8 Class Initialized
INFO - 2017-01-19 13:22:27 --> URI Class Initialized
INFO - 2017-01-19 13:22:27 --> Router Class Initialized
INFO - 2017-01-19 13:22:27 --> Output Class Initialized
INFO - 2017-01-19 13:22:27 --> Security Class Initialized
DEBUG - 2017-01-19 13:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:22:27 --> Input Class Initialized
INFO - 2017-01-19 13:22:27 --> Language Class Initialized
INFO - 2017-01-19 13:22:27 --> Loader Class Initialized
INFO - 2017-01-19 13:22:27 --> Helper loaded: url_helper
INFO - 2017-01-19 13:22:27 --> Helper loaded: language_helper
INFO - 2017-01-19 13:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:22:27 --> Controller Class Initialized
INFO - 2017-01-19 13:22:27 --> Database Driver Class Initialized
INFO - 2017-01-19 13:22:27 --> Model Class Initialized
INFO - 2017-01-19 13:22:27 --> Model Class Initialized
INFO - 2017-01-19 13:22:27 --> Model Class Initialized
INFO - 2017-01-19 13:22:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:22:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:22:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:22:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:22:27 --> Final output sent to browser
DEBUG - 2017-01-19 13:22:27 --> Total execution time: 0.1462
INFO - 2017-01-19 13:26:26 --> Config Class Initialized
INFO - 2017-01-19 13:26:26 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:26:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:26:26 --> Utf8 Class Initialized
INFO - 2017-01-19 13:26:26 --> URI Class Initialized
INFO - 2017-01-19 13:26:26 --> Router Class Initialized
INFO - 2017-01-19 13:26:26 --> Output Class Initialized
INFO - 2017-01-19 13:26:26 --> Security Class Initialized
DEBUG - 2017-01-19 13:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:26:26 --> Input Class Initialized
INFO - 2017-01-19 13:26:26 --> Language Class Initialized
INFO - 2017-01-19 13:26:26 --> Loader Class Initialized
INFO - 2017-01-19 13:26:26 --> Helper loaded: url_helper
INFO - 2017-01-19 13:26:26 --> Helper loaded: language_helper
INFO - 2017-01-19 13:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:26:26 --> Controller Class Initialized
INFO - 2017-01-19 13:26:26 --> Database Driver Class Initialized
INFO - 2017-01-19 13:26:26 --> Model Class Initialized
INFO - 2017-01-19 13:26:26 --> Model Class Initialized
INFO - 2017-01-19 13:26:26 --> Model Class Initialized
INFO - 2017-01-19 13:26:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:26:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:26:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:26:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:26:26 --> Final output sent to browser
DEBUG - 2017-01-19 13:26:26 --> Total execution time: 0.1725
INFO - 2017-01-19 13:27:46 --> Config Class Initialized
INFO - 2017-01-19 13:27:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:27:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:27:46 --> Utf8 Class Initialized
INFO - 2017-01-19 13:27:46 --> URI Class Initialized
INFO - 2017-01-19 13:27:46 --> Router Class Initialized
INFO - 2017-01-19 13:27:46 --> Output Class Initialized
INFO - 2017-01-19 13:27:46 --> Security Class Initialized
DEBUG - 2017-01-19 13:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:27:46 --> Input Class Initialized
INFO - 2017-01-19 13:27:46 --> Language Class Initialized
INFO - 2017-01-19 13:27:46 --> Loader Class Initialized
INFO - 2017-01-19 13:27:46 --> Helper loaded: url_helper
INFO - 2017-01-19 13:27:46 --> Helper loaded: language_helper
INFO - 2017-01-19 13:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:27:46 --> Controller Class Initialized
INFO - 2017-01-19 13:27:46 --> Database Driver Class Initialized
INFO - 2017-01-19 13:27:46 --> Model Class Initialized
INFO - 2017-01-19 13:27:46 --> Model Class Initialized
INFO - 2017-01-19 13:27:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:27:46 --> Model Class Initialized
INFO - 2017-01-19 13:27:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:27:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:27:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:27:46 --> Final output sent to browser
DEBUG - 2017-01-19 13:27:46 --> Total execution time: 0.1876
INFO - 2017-01-19 13:27:53 --> Config Class Initialized
INFO - 2017-01-19 13:27:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:27:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:27:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:27:53 --> URI Class Initialized
INFO - 2017-01-19 13:27:53 --> Router Class Initialized
INFO - 2017-01-19 13:27:53 --> Output Class Initialized
INFO - 2017-01-19 13:27:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:27:53 --> Input Class Initialized
INFO - 2017-01-19 13:27:53 --> Language Class Initialized
INFO - 2017-01-19 13:27:53 --> Loader Class Initialized
INFO - 2017-01-19 13:27:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:27:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:27:53 --> Controller Class Initialized
INFO - 2017-01-19 13:27:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:27:53 --> Model Class Initialized
INFO - 2017-01-19 13:27:53 --> Model Class Initialized
INFO - 2017-01-19 13:27:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:27:53 --> Helper loaded: form_helper
INFO - 2017-01-19 13:27:53 --> Form Validation Class Initialized
INFO - 2017-01-19 13:27:53 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-19 13:27:53 --> Config Class Initialized
INFO - 2017-01-19 13:27:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:27:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:27:53 --> Utf8 Class Initialized
INFO - 2017-01-19 13:27:53 --> URI Class Initialized
INFO - 2017-01-19 13:27:53 --> Router Class Initialized
INFO - 2017-01-19 13:27:53 --> Output Class Initialized
INFO - 2017-01-19 13:27:53 --> Security Class Initialized
DEBUG - 2017-01-19 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:27:53 --> Input Class Initialized
INFO - 2017-01-19 13:27:53 --> Language Class Initialized
INFO - 2017-01-19 13:27:53 --> Loader Class Initialized
INFO - 2017-01-19 13:27:53 --> Helper loaded: url_helper
INFO - 2017-01-19 13:27:53 --> Helper loaded: language_helper
INFO - 2017-01-19 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:27:53 --> Controller Class Initialized
INFO - 2017-01-19 13:27:53 --> Database Driver Class Initialized
INFO - 2017-01-19 13:27:53 --> Model Class Initialized
INFO - 2017-01-19 13:27:53 --> Model Class Initialized
INFO - 2017-01-19 13:27:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 13:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:27:53 --> Final output sent to browser
DEBUG - 2017-01-19 13:27:53 --> Total execution time: 0.1260
INFO - 2017-01-19 13:27:58 --> Config Class Initialized
INFO - 2017-01-19 13:27:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:27:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:27:58 --> Utf8 Class Initialized
INFO - 2017-01-19 13:27:58 --> URI Class Initialized
INFO - 2017-01-19 13:27:58 --> Router Class Initialized
INFO - 2017-01-19 13:27:58 --> Output Class Initialized
INFO - 2017-01-19 13:27:58 --> Security Class Initialized
DEBUG - 2017-01-19 13:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:27:58 --> Input Class Initialized
INFO - 2017-01-19 13:27:58 --> Language Class Initialized
INFO - 2017-01-19 13:27:58 --> Loader Class Initialized
INFO - 2017-01-19 13:27:58 --> Helper loaded: url_helper
INFO - 2017-01-19 13:27:58 --> Helper loaded: language_helper
INFO - 2017-01-19 13:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:27:58 --> Controller Class Initialized
INFO - 2017-01-19 13:27:58 --> Database Driver Class Initialized
INFO - 2017-01-19 13:27:58 --> Model Class Initialized
INFO - 2017-01-19 13:27:58 --> Model Class Initialized
INFO - 2017-01-19 13:27:58 --> Model Class Initialized
INFO - 2017-01-19 13:27:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:27:58 --> Final output sent to browser
DEBUG - 2017-01-19 13:27:58 --> Total execution time: 0.1744
INFO - 2017-01-19 13:28:09 --> Config Class Initialized
INFO - 2017-01-19 13:28:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:28:09 --> Utf8 Class Initialized
INFO - 2017-01-19 13:28:09 --> URI Class Initialized
INFO - 2017-01-19 13:28:09 --> Router Class Initialized
INFO - 2017-01-19 13:28:09 --> Output Class Initialized
INFO - 2017-01-19 13:28:09 --> Security Class Initialized
DEBUG - 2017-01-19 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:28:09 --> Input Class Initialized
INFO - 2017-01-19 13:28:09 --> Language Class Initialized
INFO - 2017-01-19 13:28:09 --> Loader Class Initialized
INFO - 2017-01-19 13:28:09 --> Helper loaded: url_helper
INFO - 2017-01-19 13:28:09 --> Helper loaded: language_helper
INFO - 2017-01-19 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:28:09 --> Controller Class Initialized
INFO - 2017-01-19 13:28:09 --> Database Driver Class Initialized
INFO - 2017-01-19 13:28:09 --> Model Class Initialized
INFO - 2017-01-19 13:28:09 --> Model Class Initialized
INFO - 2017-01-19 13:28:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:28:09 --> Model Class Initialized
INFO - 2017-01-19 13:28:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:28:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:28:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:28:09 --> Final output sent to browser
DEBUG - 2017-01-19 13:28:09 --> Total execution time: 0.1276
INFO - 2017-01-19 13:28:15 --> Config Class Initialized
INFO - 2017-01-19 13:28:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:28:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:28:15 --> Utf8 Class Initialized
INFO - 2017-01-19 13:28:15 --> URI Class Initialized
INFO - 2017-01-19 13:28:15 --> Router Class Initialized
INFO - 2017-01-19 13:28:15 --> Output Class Initialized
INFO - 2017-01-19 13:28:15 --> Security Class Initialized
DEBUG - 2017-01-19 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:28:15 --> Input Class Initialized
INFO - 2017-01-19 13:28:15 --> Language Class Initialized
INFO - 2017-01-19 13:28:15 --> Loader Class Initialized
INFO - 2017-01-19 13:28:15 --> Helper loaded: url_helper
INFO - 2017-01-19 13:28:15 --> Helper loaded: language_helper
INFO - 2017-01-19 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:28:15 --> Controller Class Initialized
INFO - 2017-01-19 13:28:15 --> Database Driver Class Initialized
INFO - 2017-01-19 13:28:15 --> Model Class Initialized
INFO - 2017-01-19 13:28:15 --> Model Class Initialized
INFO - 2017-01-19 13:28:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:28:15 --> Helper loaded: form_helper
INFO - 2017-01-19 13:28:15 --> Form Validation Class Initialized
INFO - 2017-01-19 13:28:15 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-19 13:28:15 --> Config Class Initialized
INFO - 2017-01-19 13:28:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:28:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:28:15 --> Utf8 Class Initialized
INFO - 2017-01-19 13:28:15 --> URI Class Initialized
INFO - 2017-01-19 13:28:15 --> Router Class Initialized
INFO - 2017-01-19 13:28:15 --> Output Class Initialized
INFO - 2017-01-19 13:28:15 --> Security Class Initialized
DEBUG - 2017-01-19 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:28:15 --> Input Class Initialized
INFO - 2017-01-19 13:28:15 --> Language Class Initialized
INFO - 2017-01-19 13:28:15 --> Loader Class Initialized
INFO - 2017-01-19 13:28:15 --> Helper loaded: url_helper
INFO - 2017-01-19 13:28:15 --> Helper loaded: language_helper
INFO - 2017-01-19 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:28:15 --> Controller Class Initialized
INFO - 2017-01-19 13:28:15 --> Database Driver Class Initialized
INFO - 2017-01-19 13:28:15 --> Model Class Initialized
INFO - 2017-01-19 13:28:15 --> Model Class Initialized
INFO - 2017-01-19 13:28:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:28:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:28:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 13:28:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:28:15 --> Final output sent to browser
DEBUG - 2017-01-19 13:28:15 --> Total execution time: 0.1182
INFO - 2017-01-19 13:28:18 --> Config Class Initialized
INFO - 2017-01-19 13:28:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:28:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:28:18 --> Utf8 Class Initialized
INFO - 2017-01-19 13:28:19 --> URI Class Initialized
INFO - 2017-01-19 13:28:19 --> Router Class Initialized
INFO - 2017-01-19 13:28:19 --> Output Class Initialized
INFO - 2017-01-19 13:28:19 --> Security Class Initialized
DEBUG - 2017-01-19 13:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:28:19 --> Input Class Initialized
INFO - 2017-01-19 13:28:19 --> Language Class Initialized
INFO - 2017-01-19 13:28:19 --> Loader Class Initialized
INFO - 2017-01-19 13:28:19 --> Helper loaded: url_helper
INFO - 2017-01-19 13:28:19 --> Helper loaded: language_helper
INFO - 2017-01-19 13:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:28:19 --> Controller Class Initialized
INFO - 2017-01-19 13:28:19 --> Database Driver Class Initialized
INFO - 2017-01-19 13:28:19 --> Model Class Initialized
INFO - 2017-01-19 13:28:19 --> Model Class Initialized
INFO - 2017-01-19 13:28:19 --> Model Class Initialized
INFO - 2017-01-19 13:28:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:28:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:28:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:28:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:28:19 --> Final output sent to browser
DEBUG - 2017-01-19 13:28:19 --> Total execution time: 0.1768
INFO - 2017-01-19 13:29:58 --> Config Class Initialized
INFO - 2017-01-19 13:29:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:29:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:29:58 --> Utf8 Class Initialized
INFO - 2017-01-19 13:29:58 --> URI Class Initialized
INFO - 2017-01-19 13:29:58 --> Router Class Initialized
INFO - 2017-01-19 13:29:58 --> Output Class Initialized
INFO - 2017-01-19 13:29:58 --> Security Class Initialized
DEBUG - 2017-01-19 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:29:58 --> Input Class Initialized
INFO - 2017-01-19 13:29:58 --> Language Class Initialized
INFO - 2017-01-19 13:29:58 --> Loader Class Initialized
INFO - 2017-01-19 13:29:58 --> Helper loaded: url_helper
INFO - 2017-01-19 13:29:58 --> Helper loaded: language_helper
INFO - 2017-01-19 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:29:58 --> Controller Class Initialized
INFO - 2017-01-19 13:29:58 --> Database Driver Class Initialized
INFO - 2017-01-19 13:29:58 --> Model Class Initialized
INFO - 2017-01-19 13:29:58 --> Model Class Initialized
INFO - 2017-01-19 13:29:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:29:58 --> Model Class Initialized
INFO - 2017-01-19 13:29:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:29:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:29:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:29:58 --> Final output sent to browser
DEBUG - 2017-01-19 13:29:58 --> Total execution time: 0.1248
INFO - 2017-01-19 13:30:03 --> Config Class Initialized
INFO - 2017-01-19 13:30:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:30:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:30:03 --> Utf8 Class Initialized
INFO - 2017-01-19 13:30:03 --> URI Class Initialized
INFO - 2017-01-19 13:30:03 --> Router Class Initialized
INFO - 2017-01-19 13:30:03 --> Output Class Initialized
INFO - 2017-01-19 13:30:03 --> Security Class Initialized
DEBUG - 2017-01-19 13:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:30:03 --> Input Class Initialized
INFO - 2017-01-19 13:30:03 --> Language Class Initialized
INFO - 2017-01-19 13:30:03 --> Loader Class Initialized
INFO - 2017-01-19 13:30:03 --> Helper loaded: url_helper
INFO - 2017-01-19 13:30:03 --> Helper loaded: language_helper
INFO - 2017-01-19 13:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:30:03 --> Controller Class Initialized
INFO - 2017-01-19 13:30:03 --> Database Driver Class Initialized
INFO - 2017-01-19 13:30:04 --> Model Class Initialized
INFO - 2017-01-19 13:30:04 --> Model Class Initialized
INFO - 2017-01-19 13:30:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:30:04 --> Helper loaded: form_helper
INFO - 2017-01-19 13:30:04 --> Form Validation Class Initialized
INFO - 2017-01-19 13:30:04 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-19 13:30:04 --> Config Class Initialized
INFO - 2017-01-19 13:30:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:30:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:30:04 --> Utf8 Class Initialized
INFO - 2017-01-19 13:30:04 --> URI Class Initialized
INFO - 2017-01-19 13:30:04 --> Router Class Initialized
INFO - 2017-01-19 13:30:04 --> Output Class Initialized
INFO - 2017-01-19 13:30:04 --> Security Class Initialized
DEBUG - 2017-01-19 13:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:30:04 --> Input Class Initialized
INFO - 2017-01-19 13:30:04 --> Language Class Initialized
INFO - 2017-01-19 13:30:04 --> Loader Class Initialized
INFO - 2017-01-19 13:30:04 --> Helper loaded: url_helper
INFO - 2017-01-19 13:30:04 --> Helper loaded: language_helper
INFO - 2017-01-19 13:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:30:04 --> Controller Class Initialized
INFO - 2017-01-19 13:30:04 --> Database Driver Class Initialized
INFO - 2017-01-19 13:30:04 --> Model Class Initialized
INFO - 2017-01-19 13:30:04 --> Model Class Initialized
INFO - 2017-01-19 13:30:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:30:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:30:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 13:30:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:30:04 --> Final output sent to browser
DEBUG - 2017-01-19 13:30:04 --> Total execution time: 0.1070
INFO - 2017-01-19 13:30:08 --> Config Class Initialized
INFO - 2017-01-19 13:30:08 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:30:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:30:08 --> Utf8 Class Initialized
INFO - 2017-01-19 13:30:08 --> URI Class Initialized
INFO - 2017-01-19 13:30:08 --> Router Class Initialized
INFO - 2017-01-19 13:30:08 --> Output Class Initialized
INFO - 2017-01-19 13:30:08 --> Security Class Initialized
DEBUG - 2017-01-19 13:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:30:08 --> Input Class Initialized
INFO - 2017-01-19 13:30:08 --> Language Class Initialized
INFO - 2017-01-19 13:30:08 --> Loader Class Initialized
INFO - 2017-01-19 13:30:08 --> Helper loaded: url_helper
INFO - 2017-01-19 13:30:08 --> Helper loaded: language_helper
INFO - 2017-01-19 13:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:30:08 --> Controller Class Initialized
INFO - 2017-01-19 13:30:08 --> Database Driver Class Initialized
INFO - 2017-01-19 13:30:08 --> Model Class Initialized
INFO - 2017-01-19 13:30:08 --> Model Class Initialized
INFO - 2017-01-19 13:30:08 --> Model Class Initialized
INFO - 2017-01-19 13:30:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:30:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:30:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 13:30:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:30:08 --> Final output sent to browser
DEBUG - 2017-01-19 13:30:08 --> Total execution time: 0.1985
INFO - 2017-01-19 13:59:02 --> Config Class Initialized
INFO - 2017-01-19 13:59:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:59:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:59:02 --> Utf8 Class Initialized
INFO - 2017-01-19 13:59:02 --> URI Class Initialized
INFO - 2017-01-19 13:59:02 --> Router Class Initialized
INFO - 2017-01-19 13:59:02 --> Output Class Initialized
INFO - 2017-01-19 13:59:02 --> Security Class Initialized
DEBUG - 2017-01-19 13:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:59:02 --> Input Class Initialized
INFO - 2017-01-19 13:59:02 --> Language Class Initialized
INFO - 2017-01-19 13:59:02 --> Loader Class Initialized
INFO - 2017-01-19 13:59:02 --> Helper loaded: url_helper
INFO - 2017-01-19 13:59:02 --> Helper loaded: language_helper
INFO - 2017-01-19 13:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:59:02 --> Controller Class Initialized
INFO - 2017-01-19 13:59:02 --> Database Driver Class Initialized
INFO - 2017-01-19 13:59:02 --> Model Class Initialized
INFO - 2017-01-19 13:59:02 --> Model Class Initialized
INFO - 2017-01-19 13:59:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:59:02 --> Model Class Initialized
INFO - 2017-01-19 13:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 13:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:59:02 --> Final output sent to browser
DEBUG - 2017-01-19 13:59:02 --> Total execution time: 0.1743
INFO - 2017-01-19 13:59:07 --> Config Class Initialized
INFO - 2017-01-19 13:59:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 13:59:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 13:59:07 --> Utf8 Class Initialized
INFO - 2017-01-19 13:59:07 --> URI Class Initialized
INFO - 2017-01-19 13:59:07 --> Router Class Initialized
INFO - 2017-01-19 13:59:07 --> Output Class Initialized
INFO - 2017-01-19 13:59:07 --> Security Class Initialized
DEBUG - 2017-01-19 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 13:59:07 --> Input Class Initialized
INFO - 2017-01-19 13:59:07 --> Language Class Initialized
INFO - 2017-01-19 13:59:07 --> Loader Class Initialized
INFO - 2017-01-19 13:59:07 --> Helper loaded: url_helper
INFO - 2017-01-19 13:59:07 --> Helper loaded: language_helper
INFO - 2017-01-19 13:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 13:59:07 --> Controller Class Initialized
INFO - 2017-01-19 13:59:07 --> Database Driver Class Initialized
INFO - 2017-01-19 13:59:07 --> Model Class Initialized
INFO - 2017-01-19 13:59:07 --> Model Class Initialized
INFO - 2017-01-19 13:59:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 13:59:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 13:59:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 13:59:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 13:59:07 --> Final output sent to browser
DEBUG - 2017-01-19 13:59:07 --> Total execution time: 0.1067
INFO - 2017-01-19 14:02:45 --> Config Class Initialized
INFO - 2017-01-19 14:02:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:02:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:02:45 --> Utf8 Class Initialized
INFO - 2017-01-19 14:02:45 --> URI Class Initialized
INFO - 2017-01-19 14:02:45 --> Router Class Initialized
INFO - 2017-01-19 14:02:45 --> Output Class Initialized
INFO - 2017-01-19 14:02:45 --> Security Class Initialized
DEBUG - 2017-01-19 14:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:02:45 --> Input Class Initialized
INFO - 2017-01-19 14:02:45 --> Language Class Initialized
INFO - 2017-01-19 14:02:45 --> Loader Class Initialized
INFO - 2017-01-19 14:02:45 --> Helper loaded: url_helper
INFO - 2017-01-19 14:02:45 --> Helper loaded: language_helper
INFO - 2017-01-19 14:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:02:45 --> Controller Class Initialized
INFO - 2017-01-19 14:02:45 --> Database Driver Class Initialized
INFO - 2017-01-19 14:02:45 --> Model Class Initialized
INFO - 2017-01-19 14:02:45 --> Model Class Initialized
INFO - 2017-01-19 14:02:45 --> Model Class Initialized
INFO - 2017-01-19 14:02:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:02:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:02:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 14:02:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:02:45 --> Final output sent to browser
DEBUG - 2017-01-19 14:02:45 --> Total execution time: 0.1616
INFO - 2017-01-19 14:03:55 --> Config Class Initialized
INFO - 2017-01-19 14:03:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:03:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:03:55 --> Utf8 Class Initialized
INFO - 2017-01-19 14:03:55 --> URI Class Initialized
INFO - 2017-01-19 14:03:55 --> Router Class Initialized
INFO - 2017-01-19 14:03:55 --> Output Class Initialized
INFO - 2017-01-19 14:03:55 --> Security Class Initialized
DEBUG - 2017-01-19 14:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:03:55 --> Input Class Initialized
INFO - 2017-01-19 14:03:55 --> Language Class Initialized
INFO - 2017-01-19 14:03:55 --> Loader Class Initialized
INFO - 2017-01-19 14:03:55 --> Helper loaded: url_helper
INFO - 2017-01-19 14:03:55 --> Helper loaded: language_helper
INFO - 2017-01-19 14:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:03:55 --> Controller Class Initialized
INFO - 2017-01-19 14:03:55 --> Database Driver Class Initialized
INFO - 2017-01-19 14:03:55 --> Model Class Initialized
INFO - 2017-01-19 14:03:55 --> Model Class Initialized
INFO - 2017-01-19 14:03:55 --> Model Class Initialized
INFO - 2017-01-19 14:03:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:03:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:03:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 14:03:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:03:55 --> Final output sent to browser
DEBUG - 2017-01-19 14:03:55 --> Total execution time: 0.1645
INFO - 2017-01-19 14:08:48 --> Config Class Initialized
INFO - 2017-01-19 14:08:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:08:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:08:48 --> Utf8 Class Initialized
INFO - 2017-01-19 14:08:48 --> URI Class Initialized
INFO - 2017-01-19 14:08:48 --> Router Class Initialized
INFO - 2017-01-19 14:08:48 --> Output Class Initialized
INFO - 2017-01-19 14:08:48 --> Security Class Initialized
DEBUG - 2017-01-19 14:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:08:48 --> Input Class Initialized
INFO - 2017-01-19 14:08:48 --> Language Class Initialized
INFO - 2017-01-19 14:08:48 --> Loader Class Initialized
INFO - 2017-01-19 14:08:48 --> Helper loaded: url_helper
INFO - 2017-01-19 14:08:48 --> Helper loaded: language_helper
INFO - 2017-01-19 14:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:08:48 --> Controller Class Initialized
INFO - 2017-01-19 14:08:48 --> Database Driver Class Initialized
INFO - 2017-01-19 14:08:48 --> Model Class Initialized
INFO - 2017-01-19 14:08:48 --> Model Class Initialized
INFO - 2017-01-19 14:08:48 --> Model Class Initialized
INFO - 2017-01-19 14:08:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:08:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:08:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 14:08:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:08:48 --> Final output sent to browser
DEBUG - 2017-01-19 14:08:48 --> Total execution time: 0.2767
INFO - 2017-01-19 14:08:55 --> Config Class Initialized
INFO - 2017-01-19 14:08:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:08:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:08:55 --> Utf8 Class Initialized
INFO - 2017-01-19 14:08:55 --> URI Class Initialized
INFO - 2017-01-19 14:08:55 --> Router Class Initialized
INFO - 2017-01-19 14:08:55 --> Output Class Initialized
INFO - 2017-01-19 14:08:55 --> Security Class Initialized
DEBUG - 2017-01-19 14:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:08:55 --> Input Class Initialized
INFO - 2017-01-19 14:08:55 --> Language Class Initialized
INFO - 2017-01-19 14:08:55 --> Loader Class Initialized
INFO - 2017-01-19 14:08:55 --> Helper loaded: url_helper
INFO - 2017-01-19 14:08:55 --> Helper loaded: language_helper
INFO - 2017-01-19 14:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:08:55 --> Controller Class Initialized
INFO - 2017-01-19 14:08:55 --> Database Driver Class Initialized
INFO - 2017-01-19 14:08:55 --> Model Class Initialized
INFO - 2017-01-19 14:08:55 --> Model Class Initialized
INFO - 2017-01-19 14:08:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:08:55 --> Model Class Initialized
INFO - 2017-01-19 14:08:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:08:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-01-19 14:08:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:08:55 --> Final output sent to browser
DEBUG - 2017-01-19 14:08:55 --> Total execution time: 0.1225
INFO - 2017-01-19 14:09:01 --> Config Class Initialized
INFO - 2017-01-19 14:09:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:09:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:09:01 --> Utf8 Class Initialized
INFO - 2017-01-19 14:09:01 --> URI Class Initialized
INFO - 2017-01-19 14:09:01 --> Router Class Initialized
INFO - 2017-01-19 14:09:01 --> Output Class Initialized
INFO - 2017-01-19 14:09:01 --> Security Class Initialized
DEBUG - 2017-01-19 14:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:09:01 --> Input Class Initialized
INFO - 2017-01-19 14:09:01 --> Language Class Initialized
INFO - 2017-01-19 14:09:01 --> Loader Class Initialized
INFO - 2017-01-19 14:09:01 --> Helper loaded: url_helper
INFO - 2017-01-19 14:09:01 --> Helper loaded: language_helper
INFO - 2017-01-19 14:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:09:01 --> Controller Class Initialized
INFO - 2017-01-19 14:09:01 --> Database Driver Class Initialized
INFO - 2017-01-19 14:09:01 --> Model Class Initialized
INFO - 2017-01-19 14:09:01 --> Model Class Initialized
INFO - 2017-01-19 14:09:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:09:01 --> Helper loaded: form_helper
INFO - 2017-01-19 14:09:01 --> Form Validation Class Initialized
INFO - 2017-01-19 14:09:01 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-01-19 14:09:01 --> Config Class Initialized
INFO - 2017-01-19 14:09:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:09:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:09:01 --> Utf8 Class Initialized
INFO - 2017-01-19 14:09:01 --> URI Class Initialized
INFO - 2017-01-19 14:09:01 --> Router Class Initialized
INFO - 2017-01-19 14:09:01 --> Output Class Initialized
INFO - 2017-01-19 14:09:01 --> Security Class Initialized
DEBUG - 2017-01-19 14:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:09:01 --> Input Class Initialized
INFO - 2017-01-19 14:09:01 --> Language Class Initialized
INFO - 2017-01-19 14:09:01 --> Loader Class Initialized
INFO - 2017-01-19 14:09:01 --> Helper loaded: url_helper
INFO - 2017-01-19 14:09:01 --> Helper loaded: language_helper
INFO - 2017-01-19 14:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:09:01 --> Controller Class Initialized
INFO - 2017-01-19 14:09:01 --> Database Driver Class Initialized
INFO - 2017-01-19 14:09:01 --> Model Class Initialized
INFO - 2017-01-19 14:09:01 --> Model Class Initialized
INFO - 2017-01-19 14:09:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:09:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:09:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-19 14:09:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:09:01 --> Final output sent to browser
DEBUG - 2017-01-19 14:09:01 --> Total execution time: 0.1441
INFO - 2017-01-19 14:09:06 --> Config Class Initialized
INFO - 2017-01-19 14:09:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:09:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:09:06 --> Utf8 Class Initialized
INFO - 2017-01-19 14:09:06 --> URI Class Initialized
INFO - 2017-01-19 14:09:06 --> Router Class Initialized
INFO - 2017-01-19 14:09:06 --> Output Class Initialized
INFO - 2017-01-19 14:09:06 --> Security Class Initialized
DEBUG - 2017-01-19 14:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:09:06 --> Input Class Initialized
INFO - 2017-01-19 14:09:06 --> Language Class Initialized
INFO - 2017-01-19 14:09:06 --> Loader Class Initialized
INFO - 2017-01-19 14:09:06 --> Helper loaded: url_helper
INFO - 2017-01-19 14:09:06 --> Helper loaded: language_helper
INFO - 2017-01-19 14:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:09:06 --> Controller Class Initialized
INFO - 2017-01-19 14:09:06 --> Database Driver Class Initialized
INFO - 2017-01-19 14:09:06 --> Model Class Initialized
INFO - 2017-01-19 14:09:06 --> Model Class Initialized
INFO - 2017-01-19 14:09:06 --> Model Class Initialized
INFO - 2017-01-19 14:09:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:09:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:09:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 14:09:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:09:06 --> Final output sent to browser
DEBUG - 2017-01-19 14:09:06 --> Total execution time: 0.2629
INFO - 2017-01-19 14:09:21 --> Config Class Initialized
INFO - 2017-01-19 14:09:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:09:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:09:21 --> Utf8 Class Initialized
INFO - 2017-01-19 14:09:21 --> URI Class Initialized
INFO - 2017-01-19 14:09:21 --> Router Class Initialized
INFO - 2017-01-19 14:09:21 --> Output Class Initialized
INFO - 2017-01-19 14:09:21 --> Security Class Initialized
DEBUG - 2017-01-19 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:09:21 --> Input Class Initialized
INFO - 2017-01-19 14:09:21 --> Language Class Initialized
INFO - 2017-01-19 14:09:21 --> Loader Class Initialized
INFO - 2017-01-19 14:09:21 --> Helper loaded: url_helper
INFO - 2017-01-19 14:09:21 --> Helper loaded: language_helper
INFO - 2017-01-19 14:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:09:21 --> Controller Class Initialized
INFO - 2017-01-19 14:09:21 --> Database Driver Class Initialized
INFO - 2017-01-19 14:09:21 --> Model Class Initialized
INFO - 2017-01-19 14:09:21 --> Model Class Initialized
INFO - 2017-01-19 14:09:21 --> Model Class Initialized
INFO - 2017-01-19 14:09:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 14:09:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 14:09:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 14:09:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 14:09:21 --> Final output sent to browser
DEBUG - 2017-01-19 14:09:21 --> Total execution time: 0.2731
INFO - 2017-01-19 15:45:33 --> Config Class Initialized
INFO - 2017-01-19 15:45:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:45:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:45:33 --> Utf8 Class Initialized
INFO - 2017-01-19 15:45:33 --> URI Class Initialized
INFO - 2017-01-19 15:45:33 --> Router Class Initialized
INFO - 2017-01-19 15:45:33 --> Output Class Initialized
INFO - 2017-01-19 15:45:33 --> Security Class Initialized
DEBUG - 2017-01-19 15:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:45:33 --> Input Class Initialized
INFO - 2017-01-19 15:45:33 --> Language Class Initialized
INFO - 2017-01-19 15:45:33 --> Loader Class Initialized
INFO - 2017-01-19 15:45:33 --> Helper loaded: url_helper
INFO - 2017-01-19 15:45:33 --> Helper loaded: language_helper
INFO - 2017-01-19 15:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:45:33 --> Controller Class Initialized
INFO - 2017-01-19 15:45:33 --> Database Driver Class Initialized
ERROR - 2017-01-19 15:45:33 --> Severity: Compile Error --> Cannot redeclare Ujian_model::count_result() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 729
INFO - 2017-01-19 15:45:53 --> Config Class Initialized
INFO - 2017-01-19 15:45:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:45:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:45:53 --> Utf8 Class Initialized
INFO - 2017-01-19 15:45:53 --> URI Class Initialized
INFO - 2017-01-19 15:45:53 --> Router Class Initialized
INFO - 2017-01-19 15:45:53 --> Output Class Initialized
INFO - 2017-01-19 15:45:53 --> Security Class Initialized
DEBUG - 2017-01-19 15:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:45:54 --> Input Class Initialized
INFO - 2017-01-19 15:45:54 --> Language Class Initialized
INFO - 2017-01-19 15:45:54 --> Loader Class Initialized
INFO - 2017-01-19 15:45:54 --> Helper loaded: url_helper
INFO - 2017-01-19 15:45:54 --> Helper loaded: language_helper
INFO - 2017-01-19 15:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:45:54 --> Controller Class Initialized
INFO - 2017-01-19 15:45:54 --> Database Driver Class Initialized
ERROR - 2017-01-19 15:45:54 --> Severity: Compile Error --> Cannot redeclare Ujian_model::count_result() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 729
INFO - 2017-01-19 15:48:01 --> Config Class Initialized
INFO - 2017-01-19 15:48:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:48:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:48:01 --> Utf8 Class Initialized
INFO - 2017-01-19 15:48:01 --> URI Class Initialized
INFO - 2017-01-19 15:48:01 --> Router Class Initialized
INFO - 2017-01-19 15:48:01 --> Output Class Initialized
INFO - 2017-01-19 15:48:01 --> Security Class Initialized
DEBUG - 2017-01-19 15:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:48:01 --> Input Class Initialized
INFO - 2017-01-19 15:48:01 --> Language Class Initialized
INFO - 2017-01-19 15:48:01 --> Loader Class Initialized
INFO - 2017-01-19 15:48:01 --> Helper loaded: url_helper
INFO - 2017-01-19 15:48:01 --> Helper loaded: language_helper
INFO - 2017-01-19 15:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:48:01 --> Controller Class Initialized
INFO - 2017-01-19 15:48:01 --> Database Driver Class Initialized
ERROR - 2017-01-19 15:48:01 --> Severity: Compile Error --> Cannot redeclare Ujian_model::count_result() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 741
INFO - 2017-01-19 15:49:50 --> Config Class Initialized
INFO - 2017-01-19 15:49:50 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:49:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:49:50 --> Utf8 Class Initialized
INFO - 2017-01-19 15:49:50 --> URI Class Initialized
INFO - 2017-01-19 15:49:50 --> Router Class Initialized
INFO - 2017-01-19 15:49:50 --> Output Class Initialized
INFO - 2017-01-19 15:49:50 --> Security Class Initialized
DEBUG - 2017-01-19 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:49:50 --> Input Class Initialized
INFO - 2017-01-19 15:49:50 --> Language Class Initialized
INFO - 2017-01-19 15:49:50 --> Loader Class Initialized
INFO - 2017-01-19 15:49:50 --> Helper loaded: url_helper
INFO - 2017-01-19 15:49:50 --> Helper loaded: language_helper
INFO - 2017-01-19 15:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:49:50 --> Controller Class Initialized
INFO - 2017-01-19 15:49:50 --> Database Driver Class Initialized
ERROR - 2017-01-19 15:49:50 --> Severity: Compile Error --> Cannot redeclare Ujian_model::is_reach_max() C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 729
INFO - 2017-01-19 15:50:26 --> Config Class Initialized
INFO - 2017-01-19 15:50:26 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:50:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:50:26 --> Utf8 Class Initialized
INFO - 2017-01-19 15:50:26 --> URI Class Initialized
INFO - 2017-01-19 15:50:26 --> Router Class Initialized
INFO - 2017-01-19 15:50:26 --> Output Class Initialized
INFO - 2017-01-19 15:50:26 --> Security Class Initialized
DEBUG - 2017-01-19 15:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:50:26 --> Input Class Initialized
INFO - 2017-01-19 15:50:26 --> Language Class Initialized
INFO - 2017-01-19 15:50:26 --> Loader Class Initialized
INFO - 2017-01-19 15:50:26 --> Helper loaded: url_helper
INFO - 2017-01-19 15:50:26 --> Helper loaded: language_helper
INFO - 2017-01-19 15:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:50:26 --> Controller Class Initialized
INFO - 2017-01-19 15:50:26 --> Database Driver Class Initialized
INFO - 2017-01-19 15:50:26 --> Model Class Initialized
INFO - 2017-01-19 15:50:26 --> Model Class Initialized
INFO - 2017-01-19 15:50:26 --> Model Class Initialized
INFO - 2017-01-19 15:50:26 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:50:26 --> Severity: Error --> Call to undefined method Ujian_model::is_max_attempt() C:\wamp64\www\savsoftquiz\application\controllers\Ujian.php 62
INFO - 2017-01-19 15:51:15 --> Config Class Initialized
INFO - 2017-01-19 15:51:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:51:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:51:15 --> Utf8 Class Initialized
INFO - 2017-01-19 15:51:15 --> URI Class Initialized
INFO - 2017-01-19 15:51:15 --> Router Class Initialized
INFO - 2017-01-19 15:51:15 --> Output Class Initialized
INFO - 2017-01-19 15:51:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:51:15 --> Input Class Initialized
INFO - 2017-01-19 15:51:15 --> Language Class Initialized
INFO - 2017-01-19 15:51:15 --> Loader Class Initialized
INFO - 2017-01-19 15:51:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:51:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:51:15 --> Controller Class Initialized
INFO - 2017-01-19 15:51:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:51:15 --> Model Class Initialized
INFO - 2017-01-19 15:51:15 --> Model Class Initialized
INFO - 2017-01-19 15:51:15 --> Model Class Initialized
INFO - 2017-01-19 15:51:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:51:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:51:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:51:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:51:15 --> Final output sent to browser
DEBUG - 2017-01-19 15:51:15 --> Total execution time: 0.1857
INFO - 2017-01-19 15:52:49 --> Config Class Initialized
INFO - 2017-01-19 15:52:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:52:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:52:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:52:49 --> URI Class Initialized
INFO - 2017-01-19 15:52:49 --> Router Class Initialized
INFO - 2017-01-19 15:52:49 --> Output Class Initialized
INFO - 2017-01-19 15:52:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:52:49 --> Input Class Initialized
INFO - 2017-01-19 15:52:49 --> Language Class Initialized
INFO - 2017-01-19 15:52:49 --> Loader Class Initialized
INFO - 2017-01-19 15:52:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:52:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:52:49 --> Controller Class Initialized
INFO - 2017-01-19 15:52:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:52:49 --> Model Class Initialized
INFO - 2017-01-19 15:52:49 --> Model Class Initialized
INFO - 2017-01-19 15:52:49 --> Model Class Initialized
INFO - 2017-01-19 15:52:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:52:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:52:50 --> Final output sent to browser
DEBUG - 2017-01-19 15:52:50 --> Total execution time: 0.2336
INFO - 2017-01-19 15:53:54 --> Config Class Initialized
INFO - 2017-01-19 15:53:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:53:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:53:54 --> Utf8 Class Initialized
INFO - 2017-01-19 15:53:54 --> URI Class Initialized
INFO - 2017-01-19 15:53:54 --> Router Class Initialized
INFO - 2017-01-19 15:53:54 --> Output Class Initialized
INFO - 2017-01-19 15:53:54 --> Security Class Initialized
DEBUG - 2017-01-19 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:53:54 --> Input Class Initialized
INFO - 2017-01-19 15:53:54 --> Language Class Initialized
INFO - 2017-01-19 15:53:54 --> Loader Class Initialized
INFO - 2017-01-19 15:53:54 --> Helper loaded: url_helper
INFO - 2017-01-19 15:53:54 --> Helper loaded: language_helper
INFO - 2017-01-19 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:53:54 --> Controller Class Initialized
INFO - 2017-01-19 15:53:54 --> Database Driver Class Initialized
INFO - 2017-01-19 15:53:54 --> Model Class Initialized
INFO - 2017-01-19 15:53:54 --> Model Class Initialized
INFO - 2017-01-19 15:53:54 --> Model Class Initialized
INFO - 2017-01-19 15:53:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:53:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:53:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:53:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:53:54 --> Final output sent to browser
DEBUG - 2017-01-19 15:53:54 --> Total execution time: 0.2086
INFO - 2017-01-19 15:53:57 --> Config Class Initialized
INFO - 2017-01-19 15:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:53:57 --> Utf8 Class Initialized
INFO - 2017-01-19 15:53:57 --> URI Class Initialized
INFO - 2017-01-19 15:53:57 --> Router Class Initialized
INFO - 2017-01-19 15:53:57 --> Output Class Initialized
INFO - 2017-01-19 15:53:57 --> Security Class Initialized
DEBUG - 2017-01-19 15:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:53:57 --> Input Class Initialized
INFO - 2017-01-19 15:53:57 --> Language Class Initialized
INFO - 2017-01-19 15:53:57 --> Loader Class Initialized
INFO - 2017-01-19 15:53:57 --> Helper loaded: url_helper
INFO - 2017-01-19 15:53:57 --> Helper loaded: language_helper
INFO - 2017-01-19 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:53:57 --> Controller Class Initialized
INFO - 2017-01-19 15:53:57 --> Database Driver Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:53:57 --> Config Class Initialized
INFO - 2017-01-19 15:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:53:57 --> Utf8 Class Initialized
INFO - 2017-01-19 15:53:57 --> URI Class Initialized
INFO - 2017-01-19 15:53:57 --> Router Class Initialized
INFO - 2017-01-19 15:53:57 --> Output Class Initialized
INFO - 2017-01-19 15:53:57 --> Security Class Initialized
DEBUG - 2017-01-19 15:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:53:57 --> Input Class Initialized
INFO - 2017-01-19 15:53:57 --> Language Class Initialized
INFO - 2017-01-19 15:53:57 --> Loader Class Initialized
INFO - 2017-01-19 15:53:57 --> Helper loaded: url_helper
INFO - 2017-01-19 15:53:57 --> Helper loaded: language_helper
INFO - 2017-01-19 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:53:57 --> Controller Class Initialized
INFO - 2017-01-19 15:53:57 --> Database Driver Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:53:57 --> Config Class Initialized
INFO - 2017-01-19 15:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:53:57 --> Utf8 Class Initialized
INFO - 2017-01-19 15:53:57 --> URI Class Initialized
INFO - 2017-01-19 15:53:57 --> Router Class Initialized
INFO - 2017-01-19 15:53:57 --> Output Class Initialized
INFO - 2017-01-19 15:53:57 --> Security Class Initialized
DEBUG - 2017-01-19 15:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:53:57 --> Input Class Initialized
INFO - 2017-01-19 15:53:57 --> Language Class Initialized
INFO - 2017-01-19 15:53:57 --> Loader Class Initialized
INFO - 2017-01-19 15:53:57 --> Helper loaded: url_helper
INFO - 2017-01-19 15:53:57 --> Helper loaded: language_helper
INFO - 2017-01-19 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:53:57 --> Controller Class Initialized
INFO - 2017-01-19 15:53:57 --> Database Driver Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:53:57 --> Config Class Initialized
INFO - 2017-01-19 15:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:53:57 --> Utf8 Class Initialized
INFO - 2017-01-19 15:53:57 --> URI Class Initialized
INFO - 2017-01-19 15:53:57 --> Router Class Initialized
INFO - 2017-01-19 15:53:57 --> Output Class Initialized
INFO - 2017-01-19 15:53:57 --> Security Class Initialized
DEBUG - 2017-01-19 15:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:53:57 --> Input Class Initialized
INFO - 2017-01-19 15:53:57 --> Language Class Initialized
INFO - 2017-01-19 15:53:57 --> Loader Class Initialized
INFO - 2017-01-19 15:53:57 --> Helper loaded: url_helper
INFO - 2017-01-19 15:53:57 --> Helper loaded: language_helper
INFO - 2017-01-19 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:53:57 --> Controller Class Initialized
INFO - 2017-01-19 15:53:57 --> Database Driver Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:53:57 --> Config Class Initialized
INFO - 2017-01-19 15:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:53:57 --> Utf8 Class Initialized
INFO - 2017-01-19 15:53:57 --> URI Class Initialized
INFO - 2017-01-19 15:53:57 --> Router Class Initialized
INFO - 2017-01-19 15:53:57 --> Output Class Initialized
INFO - 2017-01-19 15:53:57 --> Security Class Initialized
DEBUG - 2017-01-19 15:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:53:57 --> Input Class Initialized
INFO - 2017-01-19 15:53:57 --> Language Class Initialized
INFO - 2017-01-19 15:53:57 --> Loader Class Initialized
INFO - 2017-01-19 15:53:57 --> Helper loaded: url_helper
INFO - 2017-01-19 15:53:57 --> Helper loaded: language_helper
INFO - 2017-01-19 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:53:57 --> Controller Class Initialized
INFO - 2017-01-19 15:53:57 --> Database Driver Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Model Class Initialized
INFO - 2017-01-19 15:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:53:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:53:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2017-01-19 15:53:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:53:57 --> Final output sent to browser
DEBUG - 2017-01-19 15:53:57 --> Total execution time: 0.1194
INFO - 2017-01-19 15:54:03 --> Config Class Initialized
INFO - 2017-01-19 15:54:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:03 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:03 --> URI Class Initialized
INFO - 2017-01-19 15:54:03 --> Router Class Initialized
INFO - 2017-01-19 15:54:03 --> Output Class Initialized
INFO - 2017-01-19 15:54:03 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:03 --> Input Class Initialized
INFO - 2017-01-19 15:54:03 --> Language Class Initialized
INFO - 2017-01-19 15:54:03 --> Loader Class Initialized
INFO - 2017-01-19 15:54:03 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:03 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:03 --> Controller Class Initialized
INFO - 2017-01-19 15:54:03 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:03 --> Model Class Initialized
INFO - 2017-01-19 15:54:03 --> Model Class Initialized
INFO - 2017-01-19 15:54:03 --> Model Class Initialized
INFO - 2017-01-19 15:54:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:04 --> Config Class Initialized
INFO - 2017-01-19 15:54:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:04 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:04 --> URI Class Initialized
INFO - 2017-01-19 15:54:04 --> Router Class Initialized
INFO - 2017-01-19 15:54:04 --> Output Class Initialized
INFO - 2017-01-19 15:54:04 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:04 --> Input Class Initialized
INFO - 2017-01-19 15:54:04 --> Language Class Initialized
INFO - 2017-01-19 15:54:04 --> Loader Class Initialized
INFO - 2017-01-19 15:54:04 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:04 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:04 --> Controller Class Initialized
INFO - 2017-01-19 15:54:04 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2017-01-19 15:54:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:04 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:04 --> Total execution time: 0.1407
INFO - 2017-01-19 15:54:04 --> Config Class Initialized
INFO - 2017-01-19 15:54:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:04 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:04 --> Config Class Initialized
INFO - 2017-01-19 15:54:04 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:04 --> URI Class Initialized
INFO - 2017-01-19 15:54:04 --> Router Class Initialized
INFO - 2017-01-19 15:54:04 --> Output Class Initialized
DEBUG - 2017-01-19 15:54:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:04 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:04 --> Security Class Initialized
INFO - 2017-01-19 15:54:04 --> URI Class Initialized
DEBUG - 2017-01-19 15:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:04 --> Input Class Initialized
INFO - 2017-01-19 15:54:04 --> Language Class Initialized
INFO - 2017-01-19 15:54:04 --> Router Class Initialized
INFO - 2017-01-19 15:54:04 --> Output Class Initialized
INFO - 2017-01-19 15:54:04 --> Loader Class Initialized
INFO - 2017-01-19 15:54:04 --> Security Class Initialized
INFO - 2017-01-19 15:54:04 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:04 --> Helper loaded: language_helper
DEBUG - 2017-01-19 15:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:04 --> Input Class Initialized
INFO - 2017-01-19 15:54:04 --> Language Class Initialized
INFO - 2017-01-19 15:54:04 --> Loader Class Initialized
INFO - 2017-01-19 15:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:04 --> Controller Class Initialized
INFO - 2017-01-19 15:54:04 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:04 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:04 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:04 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:04 --> Total execution time: 0.1383
INFO - 2017-01-19 15:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:04 --> Controller Class Initialized
INFO - 2017-01-19 15:54:04 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Model Class Initialized
INFO - 2017-01-19 15:54:04 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:54:04 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:54:04 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:04 --> Total execution time: 0.1950
INFO - 2017-01-19 15:54:08 --> Config Class Initialized
INFO - 2017-01-19 15:54:08 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:08 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:08 --> Config Class Initialized
INFO - 2017-01-19 15:54:08 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:08 --> URI Class Initialized
INFO - 2017-01-19 15:54:08 --> Router Class Initialized
DEBUG - 2017-01-19 15:54:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:08 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:08 --> Output Class Initialized
INFO - 2017-01-19 15:54:08 --> URI Class Initialized
INFO - 2017-01-19 15:54:08 --> Security Class Initialized
INFO - 2017-01-19 15:54:08 --> Router Class Initialized
DEBUG - 2017-01-19 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:08 --> Input Class Initialized
INFO - 2017-01-19 15:54:08 --> Language Class Initialized
INFO - 2017-01-19 15:54:08 --> Output Class Initialized
INFO - 2017-01-19 15:54:08 --> Security Class Initialized
INFO - 2017-01-19 15:54:08 --> Loader Class Initialized
INFO - 2017-01-19 15:54:08 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:08 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:08 --> Input Class Initialized
INFO - 2017-01-19 15:54:08 --> Language Class Initialized
INFO - 2017-01-19 15:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:08 --> Controller Class Initialized
INFO - 2017-01-19 15:54:08 --> Loader Class Initialized
INFO - 2017-01-19 15:54:08 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:08 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:08 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:08 --> Model Class Initialized
INFO - 2017-01-19 15:54:08 --> Model Class Initialized
INFO - 2017-01-19 15:54:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:08 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:08 --> Total execution time: 0.1186
INFO - 2017-01-19 15:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:08 --> Controller Class Initialized
INFO - 2017-01-19 15:54:08 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:08 --> Model Class Initialized
INFO - 2017-01-19 15:54:08 --> Model Class Initialized
INFO - 2017-01-19 15:54:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:08 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:08 --> Total execution time: 0.1917
INFO - 2017-01-19 15:54:10 --> Config Class Initialized
INFO - 2017-01-19 15:54:10 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:10 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:10 --> URI Class Initialized
INFO - 2017-01-19 15:54:10 --> Config Class Initialized
INFO - 2017-01-19 15:54:10 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:10 --> Router Class Initialized
INFO - 2017-01-19 15:54:10 --> Output Class Initialized
INFO - 2017-01-19 15:54:10 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:10 --> Input Class Initialized
DEBUG - 2017-01-19 15:54:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:10 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:10 --> Language Class Initialized
INFO - 2017-01-19 15:54:10 --> URI Class Initialized
INFO - 2017-01-19 15:54:10 --> Router Class Initialized
INFO - 2017-01-19 15:54:10 --> Loader Class Initialized
INFO - 2017-01-19 15:54:10 --> Output Class Initialized
INFO - 2017-01-19 15:54:10 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:10 --> Security Class Initialized
INFO - 2017-01-19 15:54:10 --> Helper loaded: language_helper
DEBUG - 2017-01-19 15:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:10 --> Input Class Initialized
INFO - 2017-01-19 15:54:10 --> Language Class Initialized
INFO - 2017-01-19 15:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:11 --> Controller Class Initialized
INFO - 2017-01-19 15:54:11 --> Loader Class Initialized
INFO - 2017-01-19 15:54:11 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:11 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:11 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:11 --> Model Class Initialized
INFO - 2017-01-19 15:54:11 --> Model Class Initialized
INFO - 2017-01-19 15:54:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:11 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:11 --> Total execution time: 0.1371
INFO - 2017-01-19 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:11 --> Controller Class Initialized
INFO - 2017-01-19 15:54:11 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:11 --> Model Class Initialized
INFO - 2017-01-19 15:54:11 --> Model Class Initialized
INFO - 2017-01-19 15:54:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:11 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:11 --> Total execution time: 0.2176
INFO - 2017-01-19 15:54:14 --> Config Class Initialized
INFO - 2017-01-19 15:54:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:14 --> URI Class Initialized
INFO - 2017-01-19 15:54:14 --> Router Class Initialized
INFO - 2017-01-19 15:54:14 --> Output Class Initialized
INFO - 2017-01-19 15:54:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:14 --> Input Class Initialized
INFO - 2017-01-19 15:54:14 --> Language Class Initialized
INFO - 2017-01-19 15:54:14 --> Loader Class Initialized
INFO - 2017-01-19 15:54:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:14 --> Controller Class Initialized
INFO - 2017-01-19 15:54:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:14 --> Model Class Initialized
INFO - 2017-01-19 15:54:14 --> Model Class Initialized
INFO - 2017-01-19 15:54:14 --> Model Class Initialized
INFO - 2017-01-19 15:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:14 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:14 --> Total execution time: 0.2191
INFO - 2017-01-19 15:54:19 --> Config Class Initialized
INFO - 2017-01-19 15:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:19 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:19 --> URI Class Initialized
INFO - 2017-01-19 15:54:19 --> Router Class Initialized
INFO - 2017-01-19 15:54:19 --> Output Class Initialized
INFO - 2017-01-19 15:54:19 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:19 --> Input Class Initialized
INFO - 2017-01-19 15:54:19 --> Language Class Initialized
INFO - 2017-01-19 15:54:19 --> Loader Class Initialized
INFO - 2017-01-19 15:54:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:19 --> Controller Class Initialized
INFO - 2017-01-19 15:54:19 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:19 --> Config Class Initialized
INFO - 2017-01-19 15:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:19 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:19 --> URI Class Initialized
INFO - 2017-01-19 15:54:19 --> Router Class Initialized
INFO - 2017-01-19 15:54:19 --> Output Class Initialized
INFO - 2017-01-19 15:54:19 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:19 --> Input Class Initialized
INFO - 2017-01-19 15:54:19 --> Language Class Initialized
INFO - 2017-01-19 15:54:19 --> Loader Class Initialized
INFO - 2017-01-19 15:54:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:19 --> Controller Class Initialized
INFO - 2017-01-19 15:54:19 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:19 --> Config Class Initialized
INFO - 2017-01-19 15:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:19 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:19 --> URI Class Initialized
INFO - 2017-01-19 15:54:19 --> Router Class Initialized
INFO - 2017-01-19 15:54:19 --> Output Class Initialized
INFO - 2017-01-19 15:54:19 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:19 --> Input Class Initialized
INFO - 2017-01-19 15:54:19 --> Language Class Initialized
INFO - 2017-01-19 15:54:19 --> Loader Class Initialized
INFO - 2017-01-19 15:54:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:19 --> Controller Class Initialized
INFO - 2017-01-19 15:54:19 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Model Class Initialized
INFO - 2017-01-19 15:54:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:19 --> Config Class Initialized
INFO - 2017-01-19 15:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:19 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:19 --> URI Class Initialized
INFO - 2017-01-19 15:54:19 --> Router Class Initialized
INFO - 2017-01-19 15:54:19 --> Output Class Initialized
INFO - 2017-01-19 15:54:19 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:19 --> Input Class Initialized
INFO - 2017-01-19 15:54:19 --> Language Class Initialized
INFO - 2017-01-19 15:54:19 --> Loader Class Initialized
INFO - 2017-01-19 15:54:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:19 --> Controller Class Initialized
INFO - 2017-01-19 15:54:20 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:20 --> Config Class Initialized
INFO - 2017-01-19 15:54:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:20 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:20 --> URI Class Initialized
INFO - 2017-01-19 15:54:20 --> Router Class Initialized
INFO - 2017-01-19 15:54:20 --> Output Class Initialized
INFO - 2017-01-19 15:54:20 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:20 --> Input Class Initialized
INFO - 2017-01-19 15:54:20 --> Language Class Initialized
INFO - 2017-01-19 15:54:20 --> Loader Class Initialized
INFO - 2017-01-19 15:54:20 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:20 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:20 --> Controller Class Initialized
INFO - 2017-01-19 15:54:20 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:20 --> Config Class Initialized
INFO - 2017-01-19 15:54:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:20 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:20 --> URI Class Initialized
INFO - 2017-01-19 15:54:20 --> Router Class Initialized
INFO - 2017-01-19 15:54:20 --> Output Class Initialized
INFO - 2017-01-19 15:54:20 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:20 --> Input Class Initialized
INFO - 2017-01-19 15:54:20 --> Language Class Initialized
INFO - 2017-01-19 15:54:20 --> Loader Class Initialized
INFO - 2017-01-19 15:54:20 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:20 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:20 --> Controller Class Initialized
INFO - 2017-01-19 15:54:20 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Model Class Initialized
INFO - 2017-01-19 15:54:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2017-01-19 15:54:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:20 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:20 --> Total execution time: 0.1277
INFO - 2017-01-19 15:54:28 --> Config Class Initialized
INFO - 2017-01-19 15:54:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:28 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:28 --> URI Class Initialized
INFO - 2017-01-19 15:54:28 --> Router Class Initialized
INFO - 2017-01-19 15:54:28 --> Output Class Initialized
INFO - 2017-01-19 15:54:28 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:28 --> Input Class Initialized
INFO - 2017-01-19 15:54:28 --> Language Class Initialized
INFO - 2017-01-19 15:54:28 --> Loader Class Initialized
INFO - 2017-01-19 15:54:28 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:28 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:28 --> Controller Class Initialized
INFO - 2017-01-19 15:54:28 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:28 --> Model Class Initialized
INFO - 2017-01-19 15:54:28 --> Model Class Initialized
INFO - 2017-01-19 15:54:28 --> Model Class Initialized
INFO - 2017-01-19 15:54:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:28 --> Config Class Initialized
INFO - 2017-01-19 15:54:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:28 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:28 --> URI Class Initialized
INFO - 2017-01-19 15:54:28 --> Router Class Initialized
INFO - 2017-01-19 15:54:28 --> Output Class Initialized
INFO - 2017-01-19 15:54:28 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:28 --> Input Class Initialized
INFO - 2017-01-19 15:54:28 --> Language Class Initialized
INFO - 2017-01-19 15:54:28 --> Loader Class Initialized
INFO - 2017-01-19 15:54:28 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:28 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:28 --> Controller Class Initialized
INFO - 2017-01-19 15:54:28 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:28 --> Model Class Initialized
INFO - 2017-01-19 15:54:28 --> Model Class Initialized
INFO - 2017-01-19 15:54:28 --> Model Class Initialized
INFO - 2017-01-19 15:54:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2017-01-19 15:54:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:28 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:28 --> Total execution time: 0.1493
INFO - 2017-01-19 15:54:29 --> Config Class Initialized
INFO - 2017-01-19 15:54:29 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:29 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:29 --> Config Class Initialized
INFO - 2017-01-19 15:54:29 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:29 --> URI Class Initialized
DEBUG - 2017-01-19 15:54:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:29 --> Router Class Initialized
INFO - 2017-01-19 15:54:29 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:29 --> URI Class Initialized
INFO - 2017-01-19 15:54:29 --> Output Class Initialized
INFO - 2017-01-19 15:54:29 --> Router Class Initialized
INFO - 2017-01-19 15:54:29 --> Security Class Initialized
INFO - 2017-01-19 15:54:29 --> Output Class Initialized
INFO - 2017-01-19 15:54:29 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:29 --> Input Class Initialized
DEBUG - 2017-01-19 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:29 --> Language Class Initialized
INFO - 2017-01-19 15:54:29 --> Input Class Initialized
INFO - 2017-01-19 15:54:29 --> Language Class Initialized
INFO - 2017-01-19 15:54:29 --> Loader Class Initialized
INFO - 2017-01-19 15:54:29 --> Loader Class Initialized
INFO - 2017-01-19 15:54:29 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:29 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:29 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:29 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:29 --> Controller Class Initialized
INFO - 2017-01-19 15:54:29 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:29 --> Model Class Initialized
INFO - 2017-01-19 15:54:29 --> Model Class Initialized
INFO - 2017-01-19 15:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:29 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:29 --> Total execution time: 0.2946
INFO - 2017-01-19 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:29 --> Controller Class Initialized
INFO - 2017-01-19 15:54:29 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:29 --> Model Class Initialized
INFO - 2017-01-19 15:54:29 --> Model Class Initialized
INFO - 2017-01-19 15:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:29 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:29 --> Total execution time: 0.3632
INFO - 2017-01-19 15:54:32 --> Config Class Initialized
INFO - 2017-01-19 15:54:32 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:32 --> Config Class Initialized
INFO - 2017-01-19 15:54:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:32 --> Utf8 Class Initialized
DEBUG - 2017-01-19 15:54:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:32 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:32 --> URI Class Initialized
INFO - 2017-01-19 15:54:32 --> URI Class Initialized
INFO - 2017-01-19 15:54:32 --> Router Class Initialized
INFO - 2017-01-19 15:54:32 --> Router Class Initialized
INFO - 2017-01-19 15:54:32 --> Output Class Initialized
INFO - 2017-01-19 15:54:32 --> Output Class Initialized
INFO - 2017-01-19 15:54:32 --> Security Class Initialized
INFO - 2017-01-19 15:54:32 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:32 --> Input Class Initialized
INFO - 2017-01-19 15:54:32 --> Language Class Initialized
INFO - 2017-01-19 15:54:32 --> Loader Class Initialized
DEBUG - 2017-01-19 15:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:32 --> Input Class Initialized
INFO - 2017-01-19 15:54:32 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:32 --> Language Class Initialized
INFO - 2017-01-19 15:54:32 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:32 --> Loader Class Initialized
INFO - 2017-01-19 15:54:32 --> Controller Class Initialized
INFO - 2017-01-19 15:54:32 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:32 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:32 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:32 --> Model Class Initialized
INFO - 2017-01-19 15:54:32 --> Model Class Initialized
INFO - 2017-01-19 15:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:32 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:32 --> Total execution time: 0.1233
INFO - 2017-01-19 15:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:32 --> Controller Class Initialized
INFO - 2017-01-19 15:54:32 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:32 --> Model Class Initialized
INFO - 2017-01-19 15:54:32 --> Model Class Initialized
INFO - 2017-01-19 15:54:32 --> Model Class Initialized
INFO - 2017-01-19 15:54:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:54:32 --> Severity: Notice --> Undefined variable: marks_1 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 542
ERROR - 2017-01-19 15:54:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 542
ERROR - 2017-01-19 15:54:32 --> Severity: Notice --> Undefined variable: marks_2 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 542
ERROR - 2017-01-19 15:54:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 542
INFO - 2017-01-19 15:54:32 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:32 --> Total execution time: 0.4381
INFO - 2017-01-19 15:54:37 --> Config Class Initialized
INFO - 2017-01-19 15:54:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:37 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:37 --> URI Class Initialized
INFO - 2017-01-19 15:54:37 --> Router Class Initialized
INFO - 2017-01-19 15:54:37 --> Output Class Initialized
INFO - 2017-01-19 15:54:37 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:37 --> Input Class Initialized
INFO - 2017-01-19 15:54:37 --> Language Class Initialized
INFO - 2017-01-19 15:54:37 --> Loader Class Initialized
INFO - 2017-01-19 15:54:37 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:37 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:37 --> Controller Class Initialized
INFO - 2017-01-19 15:54:37 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:37 --> Model Class Initialized
INFO - 2017-01-19 15:54:37 --> Model Class Initialized
INFO - 2017-01-19 15:54:37 --> Model Class Initialized
INFO - 2017-01-19 15:54:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:54:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:37 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:37 --> Total execution time: 0.1668
INFO - 2017-01-19 15:54:41 --> Config Class Initialized
INFO - 2017-01-19 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:41 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:41 --> URI Class Initialized
INFO - 2017-01-19 15:54:41 --> Router Class Initialized
INFO - 2017-01-19 15:54:41 --> Output Class Initialized
INFO - 2017-01-19 15:54:41 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:41 --> Input Class Initialized
INFO - 2017-01-19 15:54:41 --> Language Class Initialized
INFO - 2017-01-19 15:54:41 --> Loader Class Initialized
INFO - 2017-01-19 15:54:41 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:41 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:41 --> Controller Class Initialized
INFO - 2017-01-19 15:54:41 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:41 --> Config Class Initialized
INFO - 2017-01-19 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:41 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:41 --> URI Class Initialized
INFO - 2017-01-19 15:54:41 --> Router Class Initialized
INFO - 2017-01-19 15:54:41 --> Output Class Initialized
INFO - 2017-01-19 15:54:41 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:41 --> Input Class Initialized
INFO - 2017-01-19 15:54:41 --> Language Class Initialized
INFO - 2017-01-19 15:54:41 --> Loader Class Initialized
INFO - 2017-01-19 15:54:41 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:41 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:41 --> Controller Class Initialized
INFO - 2017-01-19 15:54:41 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:41 --> Config Class Initialized
INFO - 2017-01-19 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:41 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:41 --> URI Class Initialized
INFO - 2017-01-19 15:54:41 --> Router Class Initialized
INFO - 2017-01-19 15:54:41 --> Output Class Initialized
INFO - 2017-01-19 15:54:41 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:41 --> Input Class Initialized
INFO - 2017-01-19 15:54:41 --> Language Class Initialized
INFO - 2017-01-19 15:54:41 --> Loader Class Initialized
INFO - 2017-01-19 15:54:41 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:41 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:41 --> Controller Class Initialized
INFO - 2017-01-19 15:54:41 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:41 --> Config Class Initialized
INFO - 2017-01-19 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:41 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:41 --> URI Class Initialized
INFO - 2017-01-19 15:54:41 --> Router Class Initialized
INFO - 2017-01-19 15:54:41 --> Output Class Initialized
INFO - 2017-01-19 15:54:41 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:41 --> Input Class Initialized
INFO - 2017-01-19 15:54:41 --> Language Class Initialized
INFO - 2017-01-19 15:54:41 --> Loader Class Initialized
INFO - 2017-01-19 15:54:41 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:41 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:41 --> Controller Class Initialized
INFO - 2017-01-19 15:54:41 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:41 --> Config Class Initialized
INFO - 2017-01-19 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:41 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:41 --> URI Class Initialized
INFO - 2017-01-19 15:54:41 --> Router Class Initialized
INFO - 2017-01-19 15:54:41 --> Output Class Initialized
INFO - 2017-01-19 15:54:41 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:41 --> Input Class Initialized
INFO - 2017-01-19 15:54:41 --> Language Class Initialized
INFO - 2017-01-19 15:54:41 --> Loader Class Initialized
INFO - 2017-01-19 15:54:41 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:41 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:41 --> Controller Class Initialized
INFO - 2017-01-19 15:54:41 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:41 --> Config Class Initialized
INFO - 2017-01-19 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:41 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:41 --> URI Class Initialized
INFO - 2017-01-19 15:54:41 --> Router Class Initialized
INFO - 2017-01-19 15:54:41 --> Output Class Initialized
INFO - 2017-01-19 15:54:41 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:41 --> Input Class Initialized
INFO - 2017-01-19 15:54:41 --> Language Class Initialized
INFO - 2017-01-19 15:54:41 --> Loader Class Initialized
INFO - 2017-01-19 15:54:41 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:41 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:41 --> Controller Class Initialized
INFO - 2017-01-19 15:54:41 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Model Class Initialized
INFO - 2017-01-19 15:54:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:42 --> Config Class Initialized
INFO - 2017-01-19 15:54:42 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:42 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:42 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:42 --> URI Class Initialized
INFO - 2017-01-19 15:54:42 --> Router Class Initialized
INFO - 2017-01-19 15:54:42 --> Output Class Initialized
INFO - 2017-01-19 15:54:42 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:42 --> Input Class Initialized
INFO - 2017-01-19 15:54:42 --> Language Class Initialized
INFO - 2017-01-19 15:54:42 --> Loader Class Initialized
INFO - 2017-01-19 15:54:42 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:42 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:42 --> Controller Class Initialized
INFO - 2017-01-19 15:54:42 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:42 --> Model Class Initialized
INFO - 2017-01-19 15:54:42 --> Model Class Initialized
INFO - 2017-01-19 15:54:42 --> Model Class Initialized
INFO - 2017-01-19 15:54:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2017-01-19 15:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:42 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:42 --> Total execution time: 0.1475
INFO - 2017-01-19 15:54:45 --> Config Class Initialized
INFO - 2017-01-19 15:54:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:45 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:45 --> URI Class Initialized
INFO - 2017-01-19 15:54:45 --> Router Class Initialized
INFO - 2017-01-19 15:54:45 --> Output Class Initialized
INFO - 2017-01-19 15:54:45 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:45 --> Input Class Initialized
INFO - 2017-01-19 15:54:45 --> Language Class Initialized
INFO - 2017-01-19 15:54:45 --> Loader Class Initialized
INFO - 2017-01-19 15:54:45 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:45 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:45 --> Controller Class Initialized
INFO - 2017-01-19 15:54:45 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:45 --> Model Class Initialized
INFO - 2017-01-19 15:54:45 --> Model Class Initialized
INFO - 2017-01-19 15:54:45 --> Model Class Initialized
INFO - 2017-01-19 15:54:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:45 --> Config Class Initialized
INFO - 2017-01-19 15:54:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:45 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:45 --> URI Class Initialized
INFO - 2017-01-19 15:54:45 --> Router Class Initialized
INFO - 2017-01-19 15:54:45 --> Output Class Initialized
INFO - 2017-01-19 15:54:45 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:45 --> Input Class Initialized
INFO - 2017-01-19 15:54:45 --> Language Class Initialized
INFO - 2017-01-19 15:54:45 --> Loader Class Initialized
INFO - 2017-01-19 15:54:45 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:45 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:45 --> Controller Class Initialized
INFO - 2017-01-19 15:54:45 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:45 --> Model Class Initialized
INFO - 2017-01-19 15:54:45 --> Model Class Initialized
INFO - 2017-01-19 15:54:45 --> Model Class Initialized
INFO - 2017-01-19 15:54:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2017-01-19 15:54:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:45 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:45 --> Total execution time: 0.1461
INFO - 2017-01-19 15:54:46 --> Config Class Initialized
INFO - 2017-01-19 15:54:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:46 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:46 --> Config Class Initialized
INFO - 2017-01-19 15:54:46 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:46 --> URI Class Initialized
INFO - 2017-01-19 15:54:46 --> Router Class Initialized
DEBUG - 2017-01-19 15:54:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:46 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:46 --> Output Class Initialized
INFO - 2017-01-19 15:54:46 --> URI Class Initialized
INFO - 2017-01-19 15:54:46 --> Security Class Initialized
INFO - 2017-01-19 15:54:46 --> Router Class Initialized
DEBUG - 2017-01-19 15:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:46 --> Input Class Initialized
INFO - 2017-01-19 15:54:46 --> Output Class Initialized
INFO - 2017-01-19 15:54:46 --> Language Class Initialized
INFO - 2017-01-19 15:54:46 --> Security Class Initialized
INFO - 2017-01-19 15:54:46 --> Loader Class Initialized
DEBUG - 2017-01-19 15:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:46 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:46 --> Input Class Initialized
INFO - 2017-01-19 15:54:46 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:46 --> Language Class Initialized
INFO - 2017-01-19 15:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:46 --> Controller Class Initialized
INFO - 2017-01-19 15:54:46 --> Loader Class Initialized
INFO - 2017-01-19 15:54:46 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:46 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:46 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:46 --> Model Class Initialized
INFO - 2017-01-19 15:54:46 --> Model Class Initialized
INFO - 2017-01-19 15:54:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:46 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:46 --> Total execution time: 0.1299
INFO - 2017-01-19 15:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:46 --> Controller Class Initialized
INFO - 2017-01-19 15:54:46 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:46 --> Model Class Initialized
INFO - 2017-01-19 15:54:46 --> Model Class Initialized
INFO - 2017-01-19 15:54:46 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:54:46 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:54:46 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:46 --> Total execution time: 0.2061
INFO - 2017-01-19 15:54:50 --> Config Class Initialized
INFO - 2017-01-19 15:54:50 --> Hooks Class Initialized
INFO - 2017-01-19 15:54:50 --> Config Class Initialized
INFO - 2017-01-19 15:54:50 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:50 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:50 --> URI Class Initialized
INFO - 2017-01-19 15:54:50 --> Router Class Initialized
DEBUG - 2017-01-19 15:54:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:50 --> Output Class Initialized
INFO - 2017-01-19 15:54:50 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:50 --> Security Class Initialized
INFO - 2017-01-19 15:54:50 --> URI Class Initialized
DEBUG - 2017-01-19 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:50 --> Router Class Initialized
INFO - 2017-01-19 15:54:50 --> Input Class Initialized
INFO - 2017-01-19 15:54:50 --> Language Class Initialized
INFO - 2017-01-19 15:54:50 --> Output Class Initialized
INFO - 2017-01-19 15:54:50 --> Security Class Initialized
INFO - 2017-01-19 15:54:50 --> Loader Class Initialized
INFO - 2017-01-19 15:54:50 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:50 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:50 --> Input Class Initialized
INFO - 2017-01-19 15:54:50 --> Language Class Initialized
INFO - 2017-01-19 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:50 --> Controller Class Initialized
INFO - 2017-01-19 15:54:50 --> Loader Class Initialized
INFO - 2017-01-19 15:54:50 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:50 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:50 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:50 --> Model Class Initialized
INFO - 2017-01-19 15:54:50 --> Model Class Initialized
INFO - 2017-01-19 15:54:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:50 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:50 --> Total execution time: 0.1278
INFO - 2017-01-19 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:50 --> Controller Class Initialized
INFO - 2017-01-19 15:54:50 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:50 --> Model Class Initialized
INFO - 2017-01-19 15:54:50 --> Model Class Initialized
INFO - 2017-01-19 15:54:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:50 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:50 --> Total execution time: 0.1818
INFO - 2017-01-19 15:54:56 --> Config Class Initialized
INFO - 2017-01-19 15:54:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:56 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:56 --> URI Class Initialized
DEBUG - 2017-01-19 15:54:56 --> No URI present. Default controller set.
INFO - 2017-01-19 15:54:56 --> Router Class Initialized
INFO - 2017-01-19 15:54:56 --> Output Class Initialized
INFO - 2017-01-19 15:54:56 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:56 --> Input Class Initialized
INFO - 2017-01-19 15:54:56 --> Language Class Initialized
INFO - 2017-01-19 15:54:56 --> Loader Class Initialized
INFO - 2017-01-19 15:54:56 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:56 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:56 --> Controller Class Initialized
INFO - 2017-01-19 15:54:56 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:56 --> Model Class Initialized
INFO - 2017-01-19 15:54:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:56 --> Config Class Initialized
INFO - 2017-01-19 15:54:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:54:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:54:56 --> Utf8 Class Initialized
INFO - 2017-01-19 15:54:56 --> URI Class Initialized
INFO - 2017-01-19 15:54:56 --> Router Class Initialized
INFO - 2017-01-19 15:54:56 --> Output Class Initialized
INFO - 2017-01-19 15:54:56 --> Security Class Initialized
DEBUG - 2017-01-19 15:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:54:56 --> Input Class Initialized
INFO - 2017-01-19 15:54:56 --> Language Class Initialized
INFO - 2017-01-19 15:54:56 --> Loader Class Initialized
INFO - 2017-01-19 15:54:56 --> Helper loaded: url_helper
INFO - 2017-01-19 15:54:56 --> Helper loaded: language_helper
INFO - 2017-01-19 15:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:54:56 --> Controller Class Initialized
INFO - 2017-01-19 15:54:56 --> Database Driver Class Initialized
INFO - 2017-01-19 15:54:56 --> Model Class Initialized
INFO - 2017-01-19 15:54:56 --> Model Class Initialized
INFO - 2017-01-19 15:54:56 --> Model Class Initialized
INFO - 2017-01-19 15:54:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:54:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:54:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:54:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:54:56 --> Final output sent to browser
DEBUG - 2017-01-19 15:54:56 --> Total execution time: 0.1462
INFO - 2017-01-19 15:55:00 --> Config Class Initialized
INFO - 2017-01-19 15:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:00 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:00 --> URI Class Initialized
INFO - 2017-01-19 15:55:00 --> Router Class Initialized
INFO - 2017-01-19 15:55:00 --> Output Class Initialized
INFO - 2017-01-19 15:55:00 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:00 --> Input Class Initialized
INFO - 2017-01-19 15:55:00 --> Language Class Initialized
INFO - 2017-01-19 15:55:00 --> Loader Class Initialized
INFO - 2017-01-19 15:55:00 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:00 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:00 --> Controller Class Initialized
INFO - 2017-01-19 15:55:00 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:00 --> Config Class Initialized
INFO - 2017-01-19 15:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:00 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:00 --> URI Class Initialized
INFO - 2017-01-19 15:55:00 --> Router Class Initialized
INFO - 2017-01-19 15:55:00 --> Output Class Initialized
INFO - 2017-01-19 15:55:00 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:00 --> Input Class Initialized
INFO - 2017-01-19 15:55:00 --> Language Class Initialized
INFO - 2017-01-19 15:55:00 --> Loader Class Initialized
INFO - 2017-01-19 15:55:00 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:00 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:00 --> Controller Class Initialized
INFO - 2017-01-19 15:55:00 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:00 --> Config Class Initialized
INFO - 2017-01-19 15:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:00 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:00 --> URI Class Initialized
INFO - 2017-01-19 15:55:00 --> Router Class Initialized
INFO - 2017-01-19 15:55:00 --> Output Class Initialized
INFO - 2017-01-19 15:55:00 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:00 --> Input Class Initialized
INFO - 2017-01-19 15:55:00 --> Language Class Initialized
INFO - 2017-01-19 15:55:00 --> Loader Class Initialized
INFO - 2017-01-19 15:55:00 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:00 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:00 --> Controller Class Initialized
INFO - 2017-01-19 15:55:00 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:00 --> Config Class Initialized
INFO - 2017-01-19 15:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:00 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:00 --> URI Class Initialized
INFO - 2017-01-19 15:55:00 --> Router Class Initialized
INFO - 2017-01-19 15:55:00 --> Output Class Initialized
INFO - 2017-01-19 15:55:00 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:00 --> Input Class Initialized
INFO - 2017-01-19 15:55:00 --> Language Class Initialized
INFO - 2017-01-19 15:55:00 --> Loader Class Initialized
INFO - 2017-01-19 15:55:00 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:00 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:00 --> Controller Class Initialized
INFO - 2017-01-19 15:55:00 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:00 --> Config Class Initialized
INFO - 2017-01-19 15:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:00 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:00 --> URI Class Initialized
INFO - 2017-01-19 15:55:00 --> Router Class Initialized
INFO - 2017-01-19 15:55:00 --> Output Class Initialized
INFO - 2017-01-19 15:55:00 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:00 --> Input Class Initialized
INFO - 2017-01-19 15:55:00 --> Language Class Initialized
INFO - 2017-01-19 15:55:00 --> Loader Class Initialized
INFO - 2017-01-19 15:55:00 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:00 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:00 --> Controller Class Initialized
INFO - 2017-01-19 15:55:00 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Model Class Initialized
INFO - 2017-01-19 15:55:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:00 --> Config Class Initialized
INFO - 2017-01-19 15:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:00 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:00 --> URI Class Initialized
INFO - 2017-01-19 15:55:00 --> Router Class Initialized
INFO - 2017-01-19 15:55:01 --> Output Class Initialized
INFO - 2017-01-19 15:55:01 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:01 --> Input Class Initialized
INFO - 2017-01-19 15:55:01 --> Language Class Initialized
INFO - 2017-01-19 15:55:01 --> Loader Class Initialized
INFO - 2017-01-19 15:55:01 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:01 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:01 --> Controller Class Initialized
INFO - 2017-01-19 15:55:01 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:01 --> Config Class Initialized
INFO - 2017-01-19 15:55:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:01 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:01 --> URI Class Initialized
INFO - 2017-01-19 15:55:01 --> Router Class Initialized
INFO - 2017-01-19 15:55:01 --> Output Class Initialized
INFO - 2017-01-19 15:55:01 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:01 --> Input Class Initialized
INFO - 2017-01-19 15:55:01 --> Language Class Initialized
INFO - 2017-01-19 15:55:01 --> Loader Class Initialized
INFO - 2017-01-19 15:55:01 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:01 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:01 --> Controller Class Initialized
INFO - 2017-01-19 15:55:01 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:01 --> Config Class Initialized
INFO - 2017-01-19 15:55:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:01 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:01 --> URI Class Initialized
INFO - 2017-01-19 15:55:01 --> Router Class Initialized
INFO - 2017-01-19 15:55:01 --> Output Class Initialized
INFO - 2017-01-19 15:55:01 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:01 --> Input Class Initialized
INFO - 2017-01-19 15:55:01 --> Language Class Initialized
INFO - 2017-01-19 15:55:01 --> Loader Class Initialized
INFO - 2017-01-19 15:55:01 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:01 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:01 --> Controller Class Initialized
INFO - 2017-01-19 15:55:01 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Model Class Initialized
INFO - 2017-01-19 15:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2017-01-19 15:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:01 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:01 --> Total execution time: 0.1146
INFO - 2017-01-19 15:55:04 --> Config Class Initialized
INFO - 2017-01-19 15:55:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:04 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:04 --> URI Class Initialized
INFO - 2017-01-19 15:55:04 --> Router Class Initialized
INFO - 2017-01-19 15:55:04 --> Output Class Initialized
INFO - 2017-01-19 15:55:04 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:04 --> Input Class Initialized
INFO - 2017-01-19 15:55:04 --> Language Class Initialized
INFO - 2017-01-19 15:55:04 --> Loader Class Initialized
INFO - 2017-01-19 15:55:04 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:04 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:04 --> Controller Class Initialized
INFO - 2017-01-19 15:55:04 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:04 --> Model Class Initialized
INFO - 2017-01-19 15:55:04 --> Model Class Initialized
INFO - 2017-01-19 15:55:04 --> Model Class Initialized
INFO - 2017-01-19 15:55:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:04 --> Config Class Initialized
INFO - 2017-01-19 15:55:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:04 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:04 --> URI Class Initialized
INFO - 2017-01-19 15:55:04 --> Router Class Initialized
INFO - 2017-01-19 15:55:04 --> Output Class Initialized
INFO - 2017-01-19 15:55:04 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:04 --> Input Class Initialized
INFO - 2017-01-19 15:55:04 --> Language Class Initialized
INFO - 2017-01-19 15:55:04 --> Loader Class Initialized
INFO - 2017-01-19 15:55:04 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:04 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:04 --> Controller Class Initialized
INFO - 2017-01-19 15:55:04 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:04 --> Model Class Initialized
INFO - 2017-01-19 15:55:04 --> Model Class Initialized
INFO - 2017-01-19 15:55:04 --> Model Class Initialized
INFO - 2017-01-19 15:55:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06_attempt.php
INFO - 2017-01-19 15:55:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:04 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:04 --> Total execution time: 0.1717
INFO - 2017-01-19 15:55:05 --> Config Class Initialized
INFO - 2017-01-19 15:55:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:05 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:05 --> Config Class Initialized
INFO - 2017-01-19 15:55:05 --> Hooks Class Initialized
INFO - 2017-01-19 15:55:05 --> URI Class Initialized
DEBUG - 2017-01-19 15:55:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:05 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:05 --> Router Class Initialized
INFO - 2017-01-19 15:55:05 --> URI Class Initialized
INFO - 2017-01-19 15:55:05 --> Output Class Initialized
INFO - 2017-01-19 15:55:05 --> Router Class Initialized
INFO - 2017-01-19 15:55:05 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:05 --> Input Class Initialized
INFO - 2017-01-19 15:55:05 --> Output Class Initialized
INFO - 2017-01-19 15:55:05 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:05 --> Input Class Initialized
INFO - 2017-01-19 15:55:05 --> Language Class Initialized
INFO - 2017-01-19 15:55:05 --> Language Class Initialized
INFO - 2017-01-19 15:55:05 --> Loader Class Initialized
INFO - 2017-01-19 15:55:05 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:05 --> Loader Class Initialized
INFO - 2017-01-19 15:55:05 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:05 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:05 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:05 --> Controller Class Initialized
INFO - 2017-01-19 15:55:05 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:05 --> Model Class Initialized
INFO - 2017-01-19 15:55:05 --> Model Class Initialized
INFO - 2017-01-19 15:55:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:05 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:05 --> Total execution time: 0.1727
INFO - 2017-01-19 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:05 --> Controller Class Initialized
INFO - 2017-01-19 15:55:05 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:05 --> Model Class Initialized
INFO - 2017-01-19 15:55:05 --> Model Class Initialized
INFO - 2017-01-19 15:55:05 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:55:05 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:55:05 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:05 --> Total execution time: 0.2394
INFO - 2017-01-19 15:55:11 --> Config Class Initialized
INFO - 2017-01-19 15:55:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:11 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:11 --> URI Class Initialized
INFO - 2017-01-19 15:55:11 --> Router Class Initialized
INFO - 2017-01-19 15:55:11 --> Output Class Initialized
INFO - 2017-01-19 15:55:11 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:11 --> Input Class Initialized
INFO - 2017-01-19 15:55:11 --> Language Class Initialized
INFO - 2017-01-19 15:55:11 --> Loader Class Initialized
INFO - 2017-01-19 15:55:11 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:11 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:11 --> Controller Class Initialized
INFO - 2017-01-19 15:55:11 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:11 --> Model Class Initialized
INFO - 2017-01-19 15:55:11 --> Model Class Initialized
INFO - 2017-01-19 15:55:11 --> Model Class Initialized
INFO - 2017-01-19 15:55:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:55:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:11 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:11 --> Total execution time: 0.1552
INFO - 2017-01-19 15:55:13 --> Config Class Initialized
INFO - 2017-01-19 15:55:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:13 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:13 --> URI Class Initialized
INFO - 2017-01-19 15:55:13 --> Router Class Initialized
INFO - 2017-01-19 15:55:13 --> Output Class Initialized
INFO - 2017-01-19 15:55:13 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:13 --> Input Class Initialized
INFO - 2017-01-19 15:55:13 --> Language Class Initialized
INFO - 2017-01-19 15:55:13 --> Loader Class Initialized
INFO - 2017-01-19 15:55:13 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:13 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:13 --> Controller Class Initialized
INFO - 2017-01-19 15:55:13 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:14 --> Config Class Initialized
INFO - 2017-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:14 --> URI Class Initialized
INFO - 2017-01-19 15:55:14 --> Router Class Initialized
INFO - 2017-01-19 15:55:14 --> Output Class Initialized
INFO - 2017-01-19 15:55:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:14 --> Input Class Initialized
INFO - 2017-01-19 15:55:14 --> Language Class Initialized
INFO - 2017-01-19 15:55:14 --> Loader Class Initialized
INFO - 2017-01-19 15:55:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:14 --> Controller Class Initialized
INFO - 2017-01-19 15:55:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:14 --> Config Class Initialized
INFO - 2017-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:14 --> URI Class Initialized
INFO - 2017-01-19 15:55:14 --> Router Class Initialized
INFO - 2017-01-19 15:55:14 --> Output Class Initialized
INFO - 2017-01-19 15:55:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:14 --> Input Class Initialized
INFO - 2017-01-19 15:55:14 --> Language Class Initialized
INFO - 2017-01-19 15:55:14 --> Loader Class Initialized
INFO - 2017-01-19 15:55:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:14 --> Controller Class Initialized
INFO - 2017-01-19 15:55:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:14 --> Config Class Initialized
INFO - 2017-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:14 --> URI Class Initialized
INFO - 2017-01-19 15:55:14 --> Router Class Initialized
INFO - 2017-01-19 15:55:14 --> Output Class Initialized
INFO - 2017-01-19 15:55:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:14 --> Input Class Initialized
INFO - 2017-01-19 15:55:14 --> Language Class Initialized
INFO - 2017-01-19 15:55:14 --> Loader Class Initialized
INFO - 2017-01-19 15:55:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:14 --> Controller Class Initialized
INFO - 2017-01-19 15:55:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:14 --> Config Class Initialized
INFO - 2017-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:14 --> URI Class Initialized
INFO - 2017-01-19 15:55:14 --> Router Class Initialized
INFO - 2017-01-19 15:55:14 --> Output Class Initialized
INFO - 2017-01-19 15:55:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:14 --> Input Class Initialized
INFO - 2017-01-19 15:55:14 --> Language Class Initialized
INFO - 2017-01-19 15:55:14 --> Loader Class Initialized
INFO - 2017-01-19 15:55:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:14 --> Controller Class Initialized
INFO - 2017-01-19 15:55:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:14 --> Config Class Initialized
INFO - 2017-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:14 --> URI Class Initialized
INFO - 2017-01-19 15:55:14 --> Router Class Initialized
INFO - 2017-01-19 15:55:14 --> Output Class Initialized
INFO - 2017-01-19 15:55:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:14 --> Input Class Initialized
INFO - 2017-01-19 15:55:14 --> Language Class Initialized
INFO - 2017-01-19 15:55:14 --> Loader Class Initialized
INFO - 2017-01-19 15:55:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:14 --> Controller Class Initialized
INFO - 2017-01-19 15:55:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Model Class Initialized
INFO - 2017-01-19 15:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:14 --> Config Class Initialized
INFO - 2017-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:15 --> URI Class Initialized
INFO - 2017-01-19 15:55:15 --> Router Class Initialized
INFO - 2017-01-19 15:55:15 --> Output Class Initialized
INFO - 2017-01-19 15:55:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:15 --> Input Class Initialized
INFO - 2017-01-19 15:55:15 --> Language Class Initialized
INFO - 2017-01-19 15:55:15 --> Loader Class Initialized
INFO - 2017-01-19 15:55:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:15 --> Controller Class Initialized
INFO - 2017-01-19 15:55:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:15 --> Config Class Initialized
INFO - 2017-01-19 15:55:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:15 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:15 --> URI Class Initialized
INFO - 2017-01-19 15:55:15 --> Router Class Initialized
INFO - 2017-01-19 15:55:15 --> Output Class Initialized
INFO - 2017-01-19 15:55:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:15 --> Input Class Initialized
INFO - 2017-01-19 15:55:15 --> Language Class Initialized
INFO - 2017-01-19 15:55:15 --> Loader Class Initialized
INFO - 2017-01-19 15:55:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:15 --> Controller Class Initialized
INFO - 2017-01-19 15:55:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:15 --> Config Class Initialized
INFO - 2017-01-19 15:55:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:15 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:15 --> URI Class Initialized
INFO - 2017-01-19 15:55:15 --> Router Class Initialized
INFO - 2017-01-19 15:55:15 --> Output Class Initialized
INFO - 2017-01-19 15:55:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:15 --> Input Class Initialized
INFO - 2017-01-19 15:55:15 --> Language Class Initialized
INFO - 2017-01-19 15:55:15 --> Loader Class Initialized
INFO - 2017-01-19 15:55:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:15 --> Controller Class Initialized
INFO - 2017-01-19 15:55:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Model Class Initialized
INFO - 2017-01-19 15:55:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2017-01-19 15:55:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:15 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:15 --> Total execution time: 0.1618
INFO - 2017-01-19 15:55:18 --> Config Class Initialized
INFO - 2017-01-19 15:55:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:18 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:18 --> URI Class Initialized
INFO - 2017-01-19 15:55:18 --> Router Class Initialized
INFO - 2017-01-19 15:55:18 --> Output Class Initialized
INFO - 2017-01-19 15:55:18 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:18 --> Input Class Initialized
INFO - 2017-01-19 15:55:18 --> Language Class Initialized
INFO - 2017-01-19 15:55:18 --> Loader Class Initialized
INFO - 2017-01-19 15:55:18 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:18 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:18 --> Controller Class Initialized
INFO - 2017-01-19 15:55:18 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:18 --> Model Class Initialized
INFO - 2017-01-19 15:55:18 --> Model Class Initialized
INFO - 2017-01-19 15:55:18 --> Model Class Initialized
INFO - 2017-01-19 15:55:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:19 --> Config Class Initialized
INFO - 2017-01-19 15:55:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:19 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:19 --> URI Class Initialized
INFO - 2017-01-19 15:55:19 --> Router Class Initialized
INFO - 2017-01-19 15:55:19 --> Output Class Initialized
INFO - 2017-01-19 15:55:19 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:19 --> Input Class Initialized
INFO - 2017-01-19 15:55:19 --> Language Class Initialized
INFO - 2017-01-19 15:55:19 --> Loader Class Initialized
INFO - 2017-01-19 15:55:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:19 --> Controller Class Initialized
INFO - 2017-01-19 15:55:19 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:19 --> Model Class Initialized
INFO - 2017-01-19 15:55:19 --> Model Class Initialized
INFO - 2017-01-19 15:55:19 --> Model Class Initialized
INFO - 2017-01-19 15:55:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07_attempt.php
INFO - 2017-01-19 15:55:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:19 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:19 --> Total execution time: 0.1399
INFO - 2017-01-19 15:55:19 --> Config Class Initialized
INFO - 2017-01-19 15:55:19 --> Hooks Class Initialized
INFO - 2017-01-19 15:55:19 --> Config Class Initialized
INFO - 2017-01-19 15:55:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:19 --> Utf8 Class Initialized
DEBUG - 2017-01-19 15:55:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:19 --> URI Class Initialized
INFO - 2017-01-19 15:55:19 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:19 --> URI Class Initialized
INFO - 2017-01-19 15:55:19 --> Router Class Initialized
INFO - 2017-01-19 15:55:19 --> Router Class Initialized
INFO - 2017-01-19 15:55:19 --> Output Class Initialized
INFO - 2017-01-19 15:55:19 --> Output Class Initialized
INFO - 2017-01-19 15:55:19 --> Security Class Initialized
INFO - 2017-01-19 15:55:19 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:19 --> Input Class Initialized
INFO - 2017-01-19 15:55:19 --> Language Class Initialized
DEBUG - 2017-01-19 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:19 --> Input Class Initialized
INFO - 2017-01-19 15:55:19 --> Language Class Initialized
INFO - 2017-01-19 15:55:19 --> Loader Class Initialized
INFO - 2017-01-19 15:55:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:19 --> Loader Class Initialized
INFO - 2017-01-19 15:55:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:19 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:19 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:19 --> Controller Class Initialized
INFO - 2017-01-19 15:55:20 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:20 --> Model Class Initialized
INFO - 2017-01-19 15:55:20 --> Model Class Initialized
INFO - 2017-01-19 15:55:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:20 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:20 --> Total execution time: 0.1339
INFO - 2017-01-19 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:20 --> Controller Class Initialized
INFO - 2017-01-19 15:55:20 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:20 --> Model Class Initialized
INFO - 2017-01-19 15:55:20 --> Model Class Initialized
INFO - 2017-01-19 15:55:20 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:55:20 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:55:20 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:20 --> Total execution time: 0.2340
INFO - 2017-01-19 15:55:23 --> Config Class Initialized
INFO - 2017-01-19 15:55:23 --> Hooks Class Initialized
INFO - 2017-01-19 15:55:23 --> Config Class Initialized
INFO - 2017-01-19 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:23 --> Utf8 Class Initialized
DEBUG - 2017-01-19 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:23 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:23 --> URI Class Initialized
INFO - 2017-01-19 15:55:23 --> URI Class Initialized
INFO - 2017-01-19 15:55:23 --> Router Class Initialized
INFO - 2017-01-19 15:55:23 --> Router Class Initialized
INFO - 2017-01-19 15:55:23 --> Output Class Initialized
INFO - 2017-01-19 15:55:23 --> Output Class Initialized
INFO - 2017-01-19 15:55:23 --> Security Class Initialized
INFO - 2017-01-19 15:55:23 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:23 --> Input Class Initialized
INFO - 2017-01-19 15:55:23 --> Language Class Initialized
DEBUG - 2017-01-19 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:23 --> Input Class Initialized
INFO - 2017-01-19 15:55:23 --> Language Class Initialized
INFO - 2017-01-19 15:55:23 --> Loader Class Initialized
INFO - 2017-01-19 15:55:23 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:23 --> Loader Class Initialized
INFO - 2017-01-19 15:55:23 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:23 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:23 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:23 --> Controller Class Initialized
INFO - 2017-01-19 15:55:23 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:23 --> Model Class Initialized
INFO - 2017-01-19 15:55:23 --> Model Class Initialized
INFO - 2017-01-19 15:55:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:23 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:23 --> Total execution time: 0.1493
INFO - 2017-01-19 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:23 --> Controller Class Initialized
INFO - 2017-01-19 15:55:23 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:23 --> Model Class Initialized
INFO - 2017-01-19 15:55:23 --> Model Class Initialized
INFO - 2017-01-19 15:55:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:23 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:23 --> Total execution time: 0.2492
INFO - 2017-01-19 15:55:26 --> Config Class Initialized
INFO - 2017-01-19 15:55:26 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:26 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:26 --> URI Class Initialized
DEBUG - 2017-01-19 15:55:26 --> No URI present. Default controller set.
INFO - 2017-01-19 15:55:26 --> Router Class Initialized
INFO - 2017-01-19 15:55:26 --> Output Class Initialized
INFO - 2017-01-19 15:55:26 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:26 --> Input Class Initialized
INFO - 2017-01-19 15:55:26 --> Language Class Initialized
INFO - 2017-01-19 15:55:26 --> Loader Class Initialized
INFO - 2017-01-19 15:55:26 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:26 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:26 --> Controller Class Initialized
INFO - 2017-01-19 15:55:26 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:26 --> Model Class Initialized
INFO - 2017-01-19 15:55:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:27 --> Config Class Initialized
INFO - 2017-01-19 15:55:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:27 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:27 --> URI Class Initialized
INFO - 2017-01-19 15:55:27 --> Router Class Initialized
INFO - 2017-01-19 15:55:27 --> Output Class Initialized
INFO - 2017-01-19 15:55:27 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:27 --> Input Class Initialized
INFO - 2017-01-19 15:55:27 --> Language Class Initialized
INFO - 2017-01-19 15:55:27 --> Loader Class Initialized
INFO - 2017-01-19 15:55:27 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:27 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:27 --> Controller Class Initialized
INFO - 2017-01-19 15:55:27 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:27 --> Model Class Initialized
INFO - 2017-01-19 15:55:27 --> Model Class Initialized
INFO - 2017-01-19 15:55:27 --> Model Class Initialized
INFO - 2017-01-19 15:55:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:55:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:27 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:27 --> Total execution time: 0.1730
INFO - 2017-01-19 15:55:30 --> Config Class Initialized
INFO - 2017-01-19 15:55:30 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:30 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:30 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:30 --> URI Class Initialized
INFO - 2017-01-19 15:55:30 --> Router Class Initialized
INFO - 2017-01-19 15:55:30 --> Output Class Initialized
INFO - 2017-01-19 15:55:30 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:30 --> Input Class Initialized
INFO - 2017-01-19 15:55:30 --> Language Class Initialized
INFO - 2017-01-19 15:55:30 --> Loader Class Initialized
INFO - 2017-01-19 15:55:30 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:30 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:30 --> Controller Class Initialized
INFO - 2017-01-19 15:55:30 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:30 --> Model Class Initialized
INFO - 2017-01-19 15:55:30 --> Model Class Initialized
INFO - 2017-01-19 15:55:30 --> Model Class Initialized
INFO - 2017-01-19 15:55:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:30 --> Config Class Initialized
INFO - 2017-01-19 15:55:30 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:30 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:30 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:30 --> URI Class Initialized
INFO - 2017-01-19 15:55:30 --> Router Class Initialized
INFO - 2017-01-19 15:55:30 --> Output Class Initialized
INFO - 2017-01-19 15:55:30 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:30 --> Input Class Initialized
INFO - 2017-01-19 15:55:30 --> Language Class Initialized
INFO - 2017-01-19 15:55:30 --> Loader Class Initialized
INFO - 2017-01-19 15:55:30 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:30 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:30 --> Controller Class Initialized
INFO - 2017-01-19 15:55:30 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:30 --> Model Class Initialized
INFO - 2017-01-19 15:55:30 --> Model Class Initialized
INFO - 2017-01-19 15:55:30 --> Model Class Initialized
INFO - 2017-01-19 15:55:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:30 --> Config Class Initialized
INFO - 2017-01-19 15:55:30 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:30 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:30 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:30 --> URI Class Initialized
INFO - 2017-01-19 15:55:30 --> Router Class Initialized
INFO - 2017-01-19 15:55:30 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:31 --> Controller Class Initialized
INFO - 2017-01-19 15:55:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:31 --> Config Class Initialized
INFO - 2017-01-19 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:31 --> URI Class Initialized
INFO - 2017-01-19 15:55:31 --> Router Class Initialized
INFO - 2017-01-19 15:55:31 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:31 --> Controller Class Initialized
INFO - 2017-01-19 15:55:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:31 --> Config Class Initialized
INFO - 2017-01-19 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:31 --> URI Class Initialized
INFO - 2017-01-19 15:55:31 --> Router Class Initialized
INFO - 2017-01-19 15:55:31 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:31 --> Controller Class Initialized
INFO - 2017-01-19 15:55:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:31 --> Config Class Initialized
INFO - 2017-01-19 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:31 --> URI Class Initialized
INFO - 2017-01-19 15:55:31 --> Router Class Initialized
INFO - 2017-01-19 15:55:31 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:31 --> Controller Class Initialized
INFO - 2017-01-19 15:55:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:31 --> Config Class Initialized
INFO - 2017-01-19 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:31 --> URI Class Initialized
INFO - 2017-01-19 15:55:31 --> Router Class Initialized
INFO - 2017-01-19 15:55:31 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:31 --> Controller Class Initialized
INFO - 2017-01-19 15:55:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:31 --> Config Class Initialized
INFO - 2017-01-19 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:31 --> URI Class Initialized
INFO - 2017-01-19 15:55:31 --> Router Class Initialized
INFO - 2017-01-19 15:55:31 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:31 --> Controller Class Initialized
INFO - 2017-01-19 15:55:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Model Class Initialized
INFO - 2017-01-19 15:55:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:31 --> Config Class Initialized
INFO - 2017-01-19 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:31 --> URI Class Initialized
INFO - 2017-01-19 15:55:31 --> Router Class Initialized
INFO - 2017-01-19 15:55:31 --> Output Class Initialized
INFO - 2017-01-19 15:55:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:31 --> Input Class Initialized
INFO - 2017-01-19 15:55:31 --> Language Class Initialized
INFO - 2017-01-19 15:55:31 --> Loader Class Initialized
INFO - 2017-01-19 15:55:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:32 --> Controller Class Initialized
INFO - 2017-01-19 15:55:32 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:32 --> Model Class Initialized
INFO - 2017-01-19 15:55:32 --> Model Class Initialized
INFO - 2017-01-19 15:55:32 --> Model Class Initialized
INFO - 2017-01-19 15:55:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:32 --> Config Class Initialized
INFO - 2017-01-19 15:55:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:32 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:32 --> URI Class Initialized
INFO - 2017-01-19 15:55:32 --> Router Class Initialized
INFO - 2017-01-19 15:55:32 --> Output Class Initialized
INFO - 2017-01-19 15:55:32 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:32 --> Input Class Initialized
INFO - 2017-01-19 15:55:32 --> Language Class Initialized
INFO - 2017-01-19 15:55:32 --> Loader Class Initialized
INFO - 2017-01-19 15:55:32 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:32 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:32 --> Controller Class Initialized
INFO - 2017-01-19 15:55:32 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:32 --> Model Class Initialized
INFO - 2017-01-19 15:55:32 --> Model Class Initialized
INFO - 2017-01-19 15:55:32 --> Model Class Initialized
INFO - 2017-01-19 15:55:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2017-01-19 15:55:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:32 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:32 --> Total execution time: 0.1284
INFO - 2017-01-19 15:55:34 --> Config Class Initialized
INFO - 2017-01-19 15:55:34 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:34 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:34 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:34 --> URI Class Initialized
INFO - 2017-01-19 15:55:34 --> Router Class Initialized
INFO - 2017-01-19 15:55:34 --> Output Class Initialized
INFO - 2017-01-19 15:55:34 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:34 --> Input Class Initialized
INFO - 2017-01-19 15:55:34 --> Language Class Initialized
INFO - 2017-01-19 15:55:34 --> Loader Class Initialized
INFO - 2017-01-19 15:55:34 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:34 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:35 --> Controller Class Initialized
INFO - 2017-01-19 15:55:35 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:35 --> Model Class Initialized
INFO - 2017-01-19 15:55:35 --> Model Class Initialized
INFO - 2017-01-19 15:55:35 --> Model Class Initialized
INFO - 2017-01-19 15:55:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:35 --> Config Class Initialized
INFO - 2017-01-19 15:55:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:35 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:35 --> URI Class Initialized
INFO - 2017-01-19 15:55:35 --> Router Class Initialized
INFO - 2017-01-19 15:55:35 --> Output Class Initialized
INFO - 2017-01-19 15:55:35 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:35 --> Input Class Initialized
INFO - 2017-01-19 15:55:35 --> Language Class Initialized
INFO - 2017-01-19 15:55:35 --> Loader Class Initialized
INFO - 2017-01-19 15:55:35 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:35 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:35 --> Controller Class Initialized
INFO - 2017-01-19 15:55:35 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:35 --> Model Class Initialized
INFO - 2017-01-19 15:55:35 --> Model Class Initialized
INFO - 2017-01-19 15:55:35 --> Model Class Initialized
INFO - 2017-01-19 15:55:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08_attempt.php
INFO - 2017-01-19 15:55:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:35 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:35 --> Total execution time: 0.1345
INFO - 2017-01-19 15:55:35 --> Config Class Initialized
INFO - 2017-01-19 15:55:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:35 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:35 --> URI Class Initialized
INFO - 2017-01-19 15:55:35 --> Config Class Initialized
INFO - 2017-01-19 15:55:35 --> Hooks Class Initialized
INFO - 2017-01-19 15:55:35 --> Router Class Initialized
DEBUG - 2017-01-19 15:55:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:35 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:35 --> Output Class Initialized
INFO - 2017-01-19 15:55:35 --> URI Class Initialized
INFO - 2017-01-19 15:55:35 --> Security Class Initialized
INFO - 2017-01-19 15:55:35 --> Router Class Initialized
DEBUG - 2017-01-19 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:35 --> Input Class Initialized
INFO - 2017-01-19 15:55:35 --> Language Class Initialized
INFO - 2017-01-19 15:55:35 --> Output Class Initialized
INFO - 2017-01-19 15:55:35 --> Security Class Initialized
INFO - 2017-01-19 15:55:35 --> Loader Class Initialized
DEBUG - 2017-01-19 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:35 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:35 --> Input Class Initialized
INFO - 2017-01-19 15:55:35 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:36 --> Language Class Initialized
INFO - 2017-01-19 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:36 --> Controller Class Initialized
INFO - 2017-01-19 15:55:36 --> Loader Class Initialized
INFO - 2017-01-19 15:55:36 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:36 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:36 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:36 --> Model Class Initialized
INFO - 2017-01-19 15:55:36 --> Model Class Initialized
INFO - 2017-01-19 15:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:36 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:36 --> Total execution time: 0.1433
INFO - 2017-01-19 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:36 --> Controller Class Initialized
INFO - 2017-01-19 15:55:36 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:36 --> Model Class Initialized
INFO - 2017-01-19 15:55:36 --> Model Class Initialized
INFO - 2017-01-19 15:55:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:55:36 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:55:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:55:36 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:36 --> Total execution time: 0.2190
INFO - 2017-01-19 15:55:39 --> Config Class Initialized
INFO - 2017-01-19 15:55:39 --> Hooks Class Initialized
INFO - 2017-01-19 15:55:39 --> Config Class Initialized
INFO - 2017-01-19 15:55:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:39 --> Utf8 Class Initialized
DEBUG - 2017-01-19 15:55:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:39 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:39 --> URI Class Initialized
INFO - 2017-01-19 15:55:39 --> URI Class Initialized
INFO - 2017-01-19 15:55:39 --> Router Class Initialized
INFO - 2017-01-19 15:55:39 --> Router Class Initialized
INFO - 2017-01-19 15:55:39 --> Output Class Initialized
INFO - 2017-01-19 15:55:39 --> Output Class Initialized
INFO - 2017-01-19 15:55:39 --> Security Class Initialized
INFO - 2017-01-19 15:55:39 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:39 --> Input Class Initialized
DEBUG - 2017-01-19 15:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:39 --> Input Class Initialized
INFO - 2017-01-19 15:55:39 --> Language Class Initialized
INFO - 2017-01-19 15:55:39 --> Language Class Initialized
INFO - 2017-01-19 15:55:39 --> Loader Class Initialized
INFO - 2017-01-19 15:55:39 --> Loader Class Initialized
INFO - 2017-01-19 15:55:39 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:39 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:39 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:39 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:39 --> Controller Class Initialized
INFO - 2017-01-19 15:55:39 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:39 --> Model Class Initialized
INFO - 2017-01-19 15:55:39 --> Model Class Initialized
INFO - 2017-01-19 15:55:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:39 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:39 --> Total execution time: 0.1405
INFO - 2017-01-19 15:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:39 --> Controller Class Initialized
INFO - 2017-01-19 15:55:39 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:39 --> Model Class Initialized
INFO - 2017-01-19 15:55:39 --> Model Class Initialized
INFO - 2017-01-19 15:55:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:39 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:39 --> Total execution time: 0.1835
INFO - 2017-01-19 15:55:45 --> Config Class Initialized
INFO - 2017-01-19 15:55:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:45 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:45 --> URI Class Initialized
DEBUG - 2017-01-19 15:55:45 --> No URI present. Default controller set.
INFO - 2017-01-19 15:55:45 --> Router Class Initialized
INFO - 2017-01-19 15:55:45 --> Output Class Initialized
INFO - 2017-01-19 15:55:45 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:45 --> Input Class Initialized
INFO - 2017-01-19 15:55:45 --> Language Class Initialized
INFO - 2017-01-19 15:55:45 --> Loader Class Initialized
INFO - 2017-01-19 15:55:45 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:45 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:45 --> Controller Class Initialized
INFO - 2017-01-19 15:55:45 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:45 --> Model Class Initialized
INFO - 2017-01-19 15:55:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:45 --> Config Class Initialized
INFO - 2017-01-19 15:55:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:45 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:45 --> URI Class Initialized
INFO - 2017-01-19 15:55:45 --> Router Class Initialized
INFO - 2017-01-19 15:55:45 --> Output Class Initialized
INFO - 2017-01-19 15:55:45 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:45 --> Input Class Initialized
INFO - 2017-01-19 15:55:45 --> Language Class Initialized
INFO - 2017-01-19 15:55:45 --> Loader Class Initialized
INFO - 2017-01-19 15:55:45 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:45 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:45 --> Controller Class Initialized
INFO - 2017-01-19 15:55:45 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:45 --> Model Class Initialized
INFO - 2017-01-19 15:55:45 --> Model Class Initialized
INFO - 2017-01-19 15:55:45 --> Model Class Initialized
INFO - 2017-01-19 15:55:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:55:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:45 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:45 --> Total execution time: 0.1343
INFO - 2017-01-19 15:55:48 --> Config Class Initialized
INFO - 2017-01-19 15:55:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:48 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:48 --> URI Class Initialized
INFO - 2017-01-19 15:55:48 --> Router Class Initialized
INFO - 2017-01-19 15:55:48 --> Output Class Initialized
INFO - 2017-01-19 15:55:48 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:48 --> Input Class Initialized
INFO - 2017-01-19 15:55:48 --> Language Class Initialized
INFO - 2017-01-19 15:55:48 --> Loader Class Initialized
INFO - 2017-01-19 15:55:48 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:48 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:48 --> Controller Class Initialized
INFO - 2017-01-19 15:55:48 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:48 --> Config Class Initialized
INFO - 2017-01-19 15:55:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:48 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:48 --> URI Class Initialized
INFO - 2017-01-19 15:55:48 --> Router Class Initialized
INFO - 2017-01-19 15:55:48 --> Output Class Initialized
INFO - 2017-01-19 15:55:48 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:48 --> Input Class Initialized
INFO - 2017-01-19 15:55:48 --> Language Class Initialized
INFO - 2017-01-19 15:55:48 --> Loader Class Initialized
INFO - 2017-01-19 15:55:48 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:48 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:48 --> Controller Class Initialized
INFO - 2017-01-19 15:55:48 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:48 --> Config Class Initialized
INFO - 2017-01-19 15:55:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:48 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:48 --> URI Class Initialized
INFO - 2017-01-19 15:55:48 --> Router Class Initialized
INFO - 2017-01-19 15:55:48 --> Output Class Initialized
INFO - 2017-01-19 15:55:48 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:48 --> Input Class Initialized
INFO - 2017-01-19 15:55:48 --> Language Class Initialized
INFO - 2017-01-19 15:55:48 --> Loader Class Initialized
INFO - 2017-01-19 15:55:48 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:48 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:48 --> Controller Class Initialized
INFO - 2017-01-19 15:55:48 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Model Class Initialized
INFO - 2017-01-19 15:55:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:48 --> Config Class Initialized
INFO - 2017-01-19 15:55:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:48 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:48 --> URI Class Initialized
INFO - 2017-01-19 15:55:48 --> Router Class Initialized
INFO - 2017-01-19 15:55:48 --> Output Class Initialized
INFO - 2017-01-19 15:55:48 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:48 --> Input Class Initialized
INFO - 2017-01-19 15:55:48 --> Language Class Initialized
INFO - 2017-01-19 15:55:48 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:49 --> URI Class Initialized
INFO - 2017-01-19 15:55:49 --> Router Class Initialized
INFO - 2017-01-19 15:55:49 --> Output Class Initialized
INFO - 2017-01-19 15:55:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:49 --> Input Class Initialized
INFO - 2017-01-19 15:55:49 --> Language Class Initialized
INFO - 2017-01-19 15:55:49 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:49 --> URI Class Initialized
INFO - 2017-01-19 15:55:49 --> Router Class Initialized
INFO - 2017-01-19 15:55:49 --> Output Class Initialized
INFO - 2017-01-19 15:55:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:49 --> Input Class Initialized
INFO - 2017-01-19 15:55:49 --> Language Class Initialized
INFO - 2017-01-19 15:55:49 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:49 --> URI Class Initialized
INFO - 2017-01-19 15:55:49 --> Router Class Initialized
INFO - 2017-01-19 15:55:49 --> Output Class Initialized
INFO - 2017-01-19 15:55:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:49 --> Input Class Initialized
INFO - 2017-01-19 15:55:49 --> Language Class Initialized
INFO - 2017-01-19 15:55:49 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:49 --> URI Class Initialized
INFO - 2017-01-19 15:55:49 --> Router Class Initialized
INFO - 2017-01-19 15:55:49 --> Output Class Initialized
INFO - 2017-01-19 15:55:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:49 --> Input Class Initialized
INFO - 2017-01-19 15:55:49 --> Language Class Initialized
INFO - 2017-01-19 15:55:49 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:49 --> URI Class Initialized
INFO - 2017-01-19 15:55:49 --> Router Class Initialized
INFO - 2017-01-19 15:55:49 --> Output Class Initialized
INFO - 2017-01-19 15:55:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:49 --> Input Class Initialized
INFO - 2017-01-19 15:55:49 --> Language Class Initialized
INFO - 2017-01-19 15:55:49 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:49 --> URI Class Initialized
INFO - 2017-01-19 15:55:49 --> Router Class Initialized
INFO - 2017-01-19 15:55:49 --> Output Class Initialized
INFO - 2017-01-19 15:55:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:49 --> Input Class Initialized
INFO - 2017-01-19 15:55:49 --> Language Class Initialized
INFO - 2017-01-19 15:55:49 --> Loader Class Initialized
INFO - 2017-01-19 15:55:49 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:49 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:49 --> Controller Class Initialized
INFO - 2017-01-19 15:55:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Model Class Initialized
INFO - 2017-01-19 15:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:49 --> Config Class Initialized
INFO - 2017-01-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:55:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:55:50 --> Utf8 Class Initialized
INFO - 2017-01-19 15:55:50 --> URI Class Initialized
INFO - 2017-01-19 15:55:50 --> Router Class Initialized
INFO - 2017-01-19 15:55:50 --> Output Class Initialized
INFO - 2017-01-19 15:55:50 --> Security Class Initialized
DEBUG - 2017-01-19 15:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:55:50 --> Input Class Initialized
INFO - 2017-01-19 15:55:50 --> Language Class Initialized
INFO - 2017-01-19 15:55:50 --> Loader Class Initialized
INFO - 2017-01-19 15:55:50 --> Helper loaded: url_helper
INFO - 2017-01-19 15:55:50 --> Helper loaded: language_helper
INFO - 2017-01-19 15:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:55:50 --> Controller Class Initialized
INFO - 2017-01-19 15:55:50 --> Database Driver Class Initialized
INFO - 2017-01-19 15:55:50 --> Model Class Initialized
INFO - 2017-01-19 15:55:50 --> Model Class Initialized
INFO - 2017-01-19 15:55:50 --> Model Class Initialized
INFO - 2017-01-19 15:55:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2017-01-19 15:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:55:50 --> Final output sent to browser
DEBUG - 2017-01-19 15:55:50 --> Total execution time: 0.1106
INFO - 2017-01-19 15:58:54 --> Config Class Initialized
INFO - 2017-01-19 15:58:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:58:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:58:54 --> Utf8 Class Initialized
INFO - 2017-01-19 15:58:54 --> URI Class Initialized
INFO - 2017-01-19 15:58:54 --> Router Class Initialized
INFO - 2017-01-19 15:58:54 --> Output Class Initialized
INFO - 2017-01-19 15:58:54 --> Security Class Initialized
DEBUG - 2017-01-19 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:58:54 --> Input Class Initialized
INFO - 2017-01-19 15:58:54 --> Language Class Initialized
INFO - 2017-01-19 15:58:54 --> Loader Class Initialized
INFO - 2017-01-19 15:58:54 --> Helper loaded: url_helper
INFO - 2017-01-19 15:58:54 --> Helper loaded: language_helper
INFO - 2017-01-19 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:58:54 --> Controller Class Initialized
INFO - 2017-01-19 15:58:54 --> Database Driver Class Initialized
INFO - 2017-01-19 15:58:54 --> Model Class Initialized
INFO - 2017-01-19 15:58:54 --> Model Class Initialized
INFO - 2017-01-19 15:58:54 --> Model Class Initialized
INFO - 2017-01-19 15:58:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:58:54 --> Config Class Initialized
INFO - 2017-01-19 15:58:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:58:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:58:54 --> Utf8 Class Initialized
INFO - 2017-01-19 15:58:54 --> URI Class Initialized
INFO - 2017-01-19 15:58:54 --> Router Class Initialized
INFO - 2017-01-19 15:58:54 --> Output Class Initialized
INFO - 2017-01-19 15:58:54 --> Security Class Initialized
DEBUG - 2017-01-19 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:58:54 --> Input Class Initialized
INFO - 2017-01-19 15:58:54 --> Language Class Initialized
INFO - 2017-01-19 15:58:54 --> Loader Class Initialized
INFO - 2017-01-19 15:58:54 --> Helper loaded: url_helper
INFO - 2017-01-19 15:58:54 --> Helper loaded: language_helper
INFO - 2017-01-19 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:58:54 --> Controller Class Initialized
INFO - 2017-01-19 15:58:54 --> Database Driver Class Initialized
INFO - 2017-01-19 15:58:54 --> Model Class Initialized
INFO - 2017-01-19 15:58:54 --> Model Class Initialized
INFO - 2017-01-19 15:58:54 --> Model Class Initialized
INFO - 2017-01-19 15:58:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:58:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:58:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2017-01-19 15:58:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:58:54 --> Final output sent to browser
DEBUG - 2017-01-19 15:58:54 --> Total execution time: 0.1431
INFO - 2017-01-19 15:58:55 --> Config Class Initialized
INFO - 2017-01-19 15:58:55 --> Config Class Initialized
INFO - 2017-01-19 15:58:55 --> Hooks Class Initialized
INFO - 2017-01-19 15:58:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:58:55 --> UTF-8 Support Enabled
DEBUG - 2017-01-19 15:58:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:58:55 --> Utf8 Class Initialized
INFO - 2017-01-19 15:58:55 --> Utf8 Class Initialized
INFO - 2017-01-19 15:58:55 --> URI Class Initialized
INFO - 2017-01-19 15:58:55 --> URI Class Initialized
INFO - 2017-01-19 15:58:55 --> Router Class Initialized
INFO - 2017-01-19 15:58:55 --> Router Class Initialized
INFO - 2017-01-19 15:58:55 --> Output Class Initialized
INFO - 2017-01-19 15:58:55 --> Output Class Initialized
INFO - 2017-01-19 15:58:55 --> Security Class Initialized
INFO - 2017-01-19 15:58:55 --> Security Class Initialized
DEBUG - 2017-01-19 15:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:58:55 --> Input Class Initialized
INFO - 2017-01-19 15:58:55 --> Language Class Initialized
DEBUG - 2017-01-19 15:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:58:55 --> Input Class Initialized
INFO - 2017-01-19 15:58:55 --> Language Class Initialized
INFO - 2017-01-19 15:58:55 --> Loader Class Initialized
INFO - 2017-01-19 15:58:55 --> Loader Class Initialized
INFO - 2017-01-19 15:58:55 --> Helper loaded: url_helper
INFO - 2017-01-19 15:58:55 --> Helper loaded: language_helper
INFO - 2017-01-19 15:58:55 --> Helper loaded: url_helper
INFO - 2017-01-19 15:58:55 --> Helper loaded: language_helper
INFO - 2017-01-19 15:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:58:55 --> Controller Class Initialized
INFO - 2017-01-19 15:58:55 --> Database Driver Class Initialized
INFO - 2017-01-19 15:58:55 --> Model Class Initialized
INFO - 2017-01-19 15:58:55 --> Model Class Initialized
INFO - 2017-01-19 15:58:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:58:55 --> Final output sent to browser
DEBUG - 2017-01-19 15:58:55 --> Total execution time: 0.1570
INFO - 2017-01-19 15:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:58:55 --> Controller Class Initialized
INFO - 2017-01-19 15:58:55 --> Database Driver Class Initialized
INFO - 2017-01-19 15:58:55 --> Model Class Initialized
INFO - 2017-01-19 15:58:55 --> Model Class Initialized
INFO - 2017-01-19 15:58:55 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:58:55 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:58:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:58:55 --> Final output sent to browser
DEBUG - 2017-01-19 15:58:55 --> Total execution time: 0.2343
INFO - 2017-01-19 15:59:07 --> Config Class Initialized
INFO - 2017-01-19 15:59:07 --> Hooks Class Initialized
INFO - 2017-01-19 15:59:07 --> Config Class Initialized
INFO - 2017-01-19 15:59:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:07 --> Utf8 Class Initialized
DEBUG - 2017-01-19 15:59:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:07 --> URI Class Initialized
INFO - 2017-01-19 15:59:07 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:07 --> URI Class Initialized
INFO - 2017-01-19 15:59:07 --> Router Class Initialized
INFO - 2017-01-19 15:59:07 --> Router Class Initialized
INFO - 2017-01-19 15:59:07 --> Output Class Initialized
INFO - 2017-01-19 15:59:07 --> Output Class Initialized
INFO - 2017-01-19 15:59:07 --> Security Class Initialized
INFO - 2017-01-19 15:59:07 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:07 --> Input Class Initialized
INFO - 2017-01-19 15:59:07 --> Language Class Initialized
DEBUG - 2017-01-19 15:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:07 --> Input Class Initialized
INFO - 2017-01-19 15:59:07 --> Language Class Initialized
INFO - 2017-01-19 15:59:07 --> Loader Class Initialized
INFO - 2017-01-19 15:59:07 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:07 --> Loader Class Initialized
INFO - 2017-01-19 15:59:07 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:07 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:07 --> Controller Class Initialized
INFO - 2017-01-19 15:59:07 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:07 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:07 --> Model Class Initialized
INFO - 2017-01-19 15:59:07 --> Model Class Initialized
INFO - 2017-01-19 15:59:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:07 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:07 --> Total execution time: 0.1238
INFO - 2017-01-19 15:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:07 --> Controller Class Initialized
INFO - 2017-01-19 15:59:07 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:07 --> Model Class Initialized
INFO - 2017-01-19 15:59:07 --> Model Class Initialized
INFO - 2017-01-19 15:59:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:07 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:07 --> Total execution time: 0.1862
INFO - 2017-01-19 15:59:11 --> Config Class Initialized
INFO - 2017-01-19 15:59:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:11 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:11 --> URI Class Initialized
INFO - 2017-01-19 15:59:11 --> Router Class Initialized
INFO - 2017-01-19 15:59:11 --> Output Class Initialized
INFO - 2017-01-19 15:59:11 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:11 --> Input Class Initialized
INFO - 2017-01-19 15:59:11 --> Language Class Initialized
INFO - 2017-01-19 15:59:11 --> Loader Class Initialized
INFO - 2017-01-19 15:59:11 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:11 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:11 --> Controller Class Initialized
INFO - 2017-01-19 15:59:11 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:11 --> Model Class Initialized
INFO - 2017-01-19 15:59:11 --> Model Class Initialized
INFO - 2017-01-19 15:59:11 --> Model Class Initialized
INFO - 2017-01-19 15:59:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:59:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:59:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:59:11 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:11 --> Total execution time: 0.1505
INFO - 2017-01-19 15:59:13 --> Config Class Initialized
INFO - 2017-01-19 15:59:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:13 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:13 --> URI Class Initialized
INFO - 2017-01-19 15:59:13 --> Router Class Initialized
INFO - 2017-01-19 15:59:13 --> Output Class Initialized
INFO - 2017-01-19 15:59:13 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:13 --> Input Class Initialized
INFO - 2017-01-19 15:59:13 --> Language Class Initialized
INFO - 2017-01-19 15:59:13 --> Loader Class Initialized
INFO - 2017-01-19 15:59:13 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:13 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:13 --> Controller Class Initialized
INFO - 2017-01-19 15:59:13 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:13 --> Config Class Initialized
INFO - 2017-01-19 15:59:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:13 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:13 --> URI Class Initialized
INFO - 2017-01-19 15:59:13 --> Router Class Initialized
INFO - 2017-01-19 15:59:13 --> Output Class Initialized
INFO - 2017-01-19 15:59:13 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:13 --> Input Class Initialized
INFO - 2017-01-19 15:59:13 --> Language Class Initialized
INFO - 2017-01-19 15:59:13 --> Loader Class Initialized
INFO - 2017-01-19 15:59:13 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:13 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:13 --> Controller Class Initialized
INFO - 2017-01-19 15:59:13 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:13 --> Config Class Initialized
INFO - 2017-01-19 15:59:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:13 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:13 --> URI Class Initialized
INFO - 2017-01-19 15:59:13 --> Router Class Initialized
INFO - 2017-01-19 15:59:13 --> Output Class Initialized
INFO - 2017-01-19 15:59:13 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:13 --> Input Class Initialized
INFO - 2017-01-19 15:59:13 --> Language Class Initialized
INFO - 2017-01-19 15:59:13 --> Loader Class Initialized
INFO - 2017-01-19 15:59:13 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:13 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:13 --> Controller Class Initialized
INFO - 2017-01-19 15:59:13 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Model Class Initialized
INFO - 2017-01-19 15:59:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:13 --> Config Class Initialized
INFO - 2017-01-19 15:59:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:13 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:13 --> URI Class Initialized
INFO - 2017-01-19 15:59:13 --> Router Class Initialized
INFO - 2017-01-19 15:59:13 --> Output Class Initialized
INFO - 2017-01-19 15:59:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:14 --> Input Class Initialized
INFO - 2017-01-19 15:59:14 --> Language Class Initialized
INFO - 2017-01-19 15:59:14 --> Loader Class Initialized
INFO - 2017-01-19 15:59:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:14 --> Controller Class Initialized
INFO - 2017-01-19 15:59:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:14 --> Config Class Initialized
INFO - 2017-01-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:14 --> URI Class Initialized
INFO - 2017-01-19 15:59:14 --> Router Class Initialized
INFO - 2017-01-19 15:59:14 --> Output Class Initialized
INFO - 2017-01-19 15:59:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:14 --> Input Class Initialized
INFO - 2017-01-19 15:59:14 --> Language Class Initialized
INFO - 2017-01-19 15:59:14 --> Loader Class Initialized
INFO - 2017-01-19 15:59:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:14 --> Controller Class Initialized
INFO - 2017-01-19 15:59:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:14 --> Config Class Initialized
INFO - 2017-01-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:14 --> URI Class Initialized
INFO - 2017-01-19 15:59:14 --> Router Class Initialized
INFO - 2017-01-19 15:59:14 --> Output Class Initialized
INFO - 2017-01-19 15:59:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:14 --> Input Class Initialized
INFO - 2017-01-19 15:59:14 --> Language Class Initialized
INFO - 2017-01-19 15:59:14 --> Loader Class Initialized
INFO - 2017-01-19 15:59:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:14 --> Controller Class Initialized
INFO - 2017-01-19 15:59:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:14 --> Config Class Initialized
INFO - 2017-01-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:14 --> URI Class Initialized
INFO - 2017-01-19 15:59:14 --> Router Class Initialized
INFO - 2017-01-19 15:59:14 --> Output Class Initialized
INFO - 2017-01-19 15:59:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:14 --> Input Class Initialized
INFO - 2017-01-19 15:59:14 --> Language Class Initialized
INFO - 2017-01-19 15:59:14 --> Loader Class Initialized
INFO - 2017-01-19 15:59:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:14 --> Controller Class Initialized
INFO - 2017-01-19 15:59:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:14 --> Config Class Initialized
INFO - 2017-01-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:14 --> URI Class Initialized
INFO - 2017-01-19 15:59:14 --> Router Class Initialized
INFO - 2017-01-19 15:59:14 --> Output Class Initialized
INFO - 2017-01-19 15:59:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:14 --> Input Class Initialized
INFO - 2017-01-19 15:59:14 --> Language Class Initialized
INFO - 2017-01-19 15:59:14 --> Loader Class Initialized
INFO - 2017-01-19 15:59:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:14 --> Controller Class Initialized
INFO - 2017-01-19 15:59:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:14 --> Config Class Initialized
INFO - 2017-01-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:14 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:14 --> URI Class Initialized
INFO - 2017-01-19 15:59:14 --> Router Class Initialized
INFO - 2017-01-19 15:59:14 --> Output Class Initialized
INFO - 2017-01-19 15:59:14 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:14 --> Input Class Initialized
INFO - 2017-01-19 15:59:14 --> Language Class Initialized
INFO - 2017-01-19 15:59:14 --> Loader Class Initialized
INFO - 2017-01-19 15:59:14 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:14 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:14 --> Controller Class Initialized
INFO - 2017-01-19 15:59:14 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Model Class Initialized
INFO - 2017-01-19 15:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:15 --> Config Class Initialized
INFO - 2017-01-19 15:59:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:15 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:15 --> URI Class Initialized
INFO - 2017-01-19 15:59:15 --> Router Class Initialized
INFO - 2017-01-19 15:59:15 --> Output Class Initialized
INFO - 2017-01-19 15:59:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:15 --> Input Class Initialized
INFO - 2017-01-19 15:59:15 --> Language Class Initialized
INFO - 2017-01-19 15:59:15 --> Loader Class Initialized
INFO - 2017-01-19 15:59:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:15 --> Controller Class Initialized
INFO - 2017-01-19 15:59:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:15 --> Config Class Initialized
INFO - 2017-01-19 15:59:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:15 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:15 --> URI Class Initialized
INFO - 2017-01-19 15:59:15 --> Router Class Initialized
INFO - 2017-01-19 15:59:15 --> Output Class Initialized
INFO - 2017-01-19 15:59:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:15 --> Input Class Initialized
INFO - 2017-01-19 15:59:15 --> Language Class Initialized
INFO - 2017-01-19 15:59:15 --> Loader Class Initialized
INFO - 2017-01-19 15:59:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:15 --> Controller Class Initialized
INFO - 2017-01-19 15:59:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:15 --> Config Class Initialized
INFO - 2017-01-19 15:59:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:15 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:15 --> URI Class Initialized
INFO - 2017-01-19 15:59:15 --> Router Class Initialized
INFO - 2017-01-19 15:59:15 --> Output Class Initialized
INFO - 2017-01-19 15:59:15 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:15 --> Input Class Initialized
INFO - 2017-01-19 15:59:15 --> Language Class Initialized
INFO - 2017-01-19 15:59:15 --> Loader Class Initialized
INFO - 2017-01-19 15:59:15 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:15 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:15 --> Controller Class Initialized
INFO - 2017-01-19 15:59:15 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Model Class Initialized
INFO - 2017-01-19 15:59:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:59:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-01-19 15:59:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:59:15 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:15 --> Total execution time: 0.1344
INFO - 2017-01-19 15:59:17 --> Config Class Initialized
INFO - 2017-01-19 15:59:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:17 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:17 --> URI Class Initialized
INFO - 2017-01-19 15:59:17 --> Router Class Initialized
INFO - 2017-01-19 15:59:17 --> Output Class Initialized
INFO - 2017-01-19 15:59:17 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:17 --> Input Class Initialized
INFO - 2017-01-19 15:59:17 --> Language Class Initialized
INFO - 2017-01-19 15:59:17 --> Loader Class Initialized
INFO - 2017-01-19 15:59:17 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:17 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:17 --> Controller Class Initialized
INFO - 2017-01-19 15:59:17 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:17 --> Config Class Initialized
INFO - 2017-01-19 15:59:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:17 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:17 --> URI Class Initialized
INFO - 2017-01-19 15:59:17 --> Router Class Initialized
INFO - 2017-01-19 15:59:17 --> Output Class Initialized
INFO - 2017-01-19 15:59:17 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:17 --> Input Class Initialized
INFO - 2017-01-19 15:59:17 --> Language Class Initialized
INFO - 2017-01-19 15:59:17 --> Loader Class Initialized
INFO - 2017-01-19 15:59:17 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:17 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:17 --> Controller Class Initialized
INFO - 2017-01-19 15:59:17 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:17 --> Model Class Initialized
INFO - 2017-01-19 15:59:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:59:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-01-19 15:59:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:59:17 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:17 --> Total execution time: 0.2482
INFO - 2017-01-19 15:59:18 --> Config Class Initialized
INFO - 2017-01-19 15:59:18 --> Hooks Class Initialized
INFO - 2017-01-19 15:59:18 --> Config Class Initialized
INFO - 2017-01-19 15:59:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:18 --> UTF-8 Support Enabled
DEBUG - 2017-01-19 15:59:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:18 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:18 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:18 --> URI Class Initialized
INFO - 2017-01-19 15:59:18 --> URI Class Initialized
INFO - 2017-01-19 15:59:18 --> Router Class Initialized
INFO - 2017-01-19 15:59:18 --> Router Class Initialized
INFO - 2017-01-19 15:59:18 --> Output Class Initialized
INFO - 2017-01-19 15:59:18 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:18 --> Output Class Initialized
INFO - 2017-01-19 15:59:18 --> Input Class Initialized
INFO - 2017-01-19 15:59:18 --> Language Class Initialized
INFO - 2017-01-19 15:59:18 --> Security Class Initialized
INFO - 2017-01-19 15:59:18 --> Loader Class Initialized
DEBUG - 2017-01-19 15:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:18 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:18 --> Input Class Initialized
INFO - 2017-01-19 15:59:18 --> Language Class Initialized
INFO - 2017-01-19 15:59:18 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:18 --> Loader Class Initialized
INFO - 2017-01-19 15:59:18 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:18 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:18 --> Controller Class Initialized
INFO - 2017-01-19 15:59:18 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:18 --> Model Class Initialized
INFO - 2017-01-19 15:59:18 --> Model Class Initialized
INFO - 2017-01-19 15:59:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:18 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:18 --> Total execution time: 0.1233
INFO - 2017-01-19 15:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:18 --> Controller Class Initialized
INFO - 2017-01-19 15:59:18 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:18 --> Model Class Initialized
INFO - 2017-01-19 15:59:18 --> Model Class Initialized
INFO - 2017-01-19 15:59:18 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 15:59:18 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-01-19 15:59:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-01-19 15:59:18 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:18 --> Total execution time: 0.1977
INFO - 2017-01-19 15:59:31 --> Config Class Initialized
INFO - 2017-01-19 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:59:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:59:31 --> URI Class Initialized
INFO - 2017-01-19 15:59:31 --> Router Class Initialized
INFO - 2017-01-19 15:59:31 --> Output Class Initialized
INFO - 2017-01-19 15:59:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:59:31 --> Input Class Initialized
INFO - 2017-01-19 15:59:31 --> Language Class Initialized
INFO - 2017-01-19 15:59:31 --> Loader Class Initialized
INFO - 2017-01-19 15:59:31 --> Helper loaded: url_helper
INFO - 2017-01-19 15:59:31 --> Helper loaded: language_helper
INFO - 2017-01-19 15:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:59:31 --> Controller Class Initialized
INFO - 2017-01-19 15:59:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:59:31 --> Model Class Initialized
INFO - 2017-01-19 15:59:31 --> Model Class Initialized
INFO - 2017-01-19 15:59:31 --> Model Class Initialized
INFO - 2017-01-19 15:59:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 15:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 15:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-19 15:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 15:59:31 --> Final output sent to browser
DEBUG - 2017-01-19 15:59:31 --> Total execution time: 0.1627
INFO - 2017-01-19 16:32:40 --> Config Class Initialized
INFO - 2017-01-19 16:32:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:32:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:32:40 --> Utf8 Class Initialized
INFO - 2017-01-19 16:32:40 --> URI Class Initialized
INFO - 2017-01-19 16:32:40 --> Router Class Initialized
INFO - 2017-01-19 16:32:40 --> Output Class Initialized
INFO - 2017-01-19 16:32:40 --> Security Class Initialized
DEBUG - 2017-01-19 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:32:40 --> Input Class Initialized
INFO - 2017-01-19 16:32:40 --> Language Class Initialized
INFO - 2017-01-19 16:32:40 --> Loader Class Initialized
INFO - 2017-01-19 16:32:40 --> Helper loaded: url_helper
INFO - 2017-01-19 16:32:40 --> Helper loaded: language_helper
INFO - 2017-01-19 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:32:40 --> Controller Class Initialized
INFO - 2017-01-19 16:32:40 --> Database Driver Class Initialized
INFO - 2017-01-19 16:32:40 --> Model Class Initialized
INFO - 2017-01-19 16:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:32:40 --> Config Class Initialized
INFO - 2017-01-19 16:32:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:32:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:32:40 --> Utf8 Class Initialized
INFO - 2017-01-19 16:32:40 --> URI Class Initialized
INFO - 2017-01-19 16:32:40 --> Router Class Initialized
INFO - 2017-01-19 16:32:40 --> Output Class Initialized
INFO - 2017-01-19 16:32:40 --> Security Class Initialized
DEBUG - 2017-01-19 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:32:40 --> Input Class Initialized
INFO - 2017-01-19 16:32:40 --> Language Class Initialized
INFO - 2017-01-19 16:32:40 --> Loader Class Initialized
INFO - 2017-01-19 16:32:40 --> Helper loaded: url_helper
INFO - 2017-01-19 16:32:40 --> Helper loaded: language_helper
INFO - 2017-01-19 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:32:40 --> Controller Class Initialized
INFO - 2017-01-19 16:32:40 --> Database Driver Class Initialized
INFO - 2017-01-19 16:32:40 --> Model Class Initialized
INFO - 2017-01-19 16:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 16:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 16:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 16:32:40 --> Final output sent to browser
DEBUG - 2017-01-19 16:32:40 --> Total execution time: 0.0860
INFO - 2017-01-19 16:32:46 --> Config Class Initialized
INFO - 2017-01-19 16:32:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:32:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:32:46 --> Utf8 Class Initialized
INFO - 2017-01-19 16:32:46 --> URI Class Initialized
INFO - 2017-01-19 16:32:46 --> Router Class Initialized
INFO - 2017-01-19 16:32:46 --> Output Class Initialized
INFO - 2017-01-19 16:32:46 --> Security Class Initialized
DEBUG - 2017-01-19 16:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:32:46 --> Input Class Initialized
INFO - 2017-01-19 16:32:46 --> Language Class Initialized
INFO - 2017-01-19 16:32:46 --> Loader Class Initialized
INFO - 2017-01-19 16:32:46 --> Helper loaded: url_helper
INFO - 2017-01-19 16:32:46 --> Helper loaded: language_helper
INFO - 2017-01-19 16:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:32:46 --> Controller Class Initialized
INFO - 2017-01-19 16:32:46 --> Database Driver Class Initialized
INFO - 2017-01-19 16:32:46 --> Model Class Initialized
INFO - 2017-01-19 16:32:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:32:47 --> Config Class Initialized
INFO - 2017-01-19 16:32:47 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:32:47 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:32:47 --> Utf8 Class Initialized
INFO - 2017-01-19 16:32:47 --> URI Class Initialized
INFO - 2017-01-19 16:32:47 --> Router Class Initialized
INFO - 2017-01-19 16:32:47 --> Output Class Initialized
INFO - 2017-01-19 16:32:47 --> Security Class Initialized
DEBUG - 2017-01-19 16:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:32:47 --> Input Class Initialized
INFO - 2017-01-19 16:32:47 --> Language Class Initialized
INFO - 2017-01-19 16:32:47 --> Loader Class Initialized
INFO - 2017-01-19 16:32:47 --> Helper loaded: url_helper
INFO - 2017-01-19 16:32:47 --> Helper loaded: language_helper
INFO - 2017-01-19 16:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:32:47 --> Controller Class Initialized
INFO - 2017-01-19 16:32:47 --> Database Driver Class Initialized
INFO - 2017-01-19 16:32:47 --> Model Class Initialized
INFO - 2017-01-19 16:32:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 16:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 16:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 16:32:47 --> Final output sent to browser
DEBUG - 2017-01-19 16:32:47 --> Total execution time: 0.0943
INFO - 2017-01-19 16:32:55 --> Config Class Initialized
INFO - 2017-01-19 16:32:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:32:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:32:55 --> Utf8 Class Initialized
INFO - 2017-01-19 16:32:55 --> URI Class Initialized
INFO - 2017-01-19 16:32:55 --> Router Class Initialized
INFO - 2017-01-19 16:32:55 --> Output Class Initialized
INFO - 2017-01-19 16:32:55 --> Security Class Initialized
DEBUG - 2017-01-19 16:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:32:55 --> Input Class Initialized
INFO - 2017-01-19 16:32:55 --> Language Class Initialized
INFO - 2017-01-19 16:32:55 --> Loader Class Initialized
INFO - 2017-01-19 16:32:55 --> Helper loaded: url_helper
INFO - 2017-01-19 16:32:55 --> Helper loaded: language_helper
INFO - 2017-01-19 16:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:32:55 --> Controller Class Initialized
INFO - 2017-01-19 16:32:55 --> Database Driver Class Initialized
INFO - 2017-01-19 16:32:55 --> Model Class Initialized
INFO - 2017-01-19 16:32:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:32:55 --> Config Class Initialized
INFO - 2017-01-19 16:32:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:32:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:32:55 --> Utf8 Class Initialized
INFO - 2017-01-19 16:32:55 --> URI Class Initialized
INFO - 2017-01-19 16:32:55 --> Router Class Initialized
INFO - 2017-01-19 16:32:55 --> Output Class Initialized
INFO - 2017-01-19 16:32:55 --> Security Class Initialized
DEBUG - 2017-01-19 16:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:32:55 --> Input Class Initialized
INFO - 2017-01-19 16:32:55 --> Language Class Initialized
INFO - 2017-01-19 16:32:55 --> Loader Class Initialized
INFO - 2017-01-19 16:32:55 --> Helper loaded: url_helper
INFO - 2017-01-19 16:32:55 --> Helper loaded: language_helper
INFO - 2017-01-19 16:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:32:55 --> Controller Class Initialized
INFO - 2017-01-19 16:32:55 --> Database Driver Class Initialized
INFO - 2017-01-19 16:32:55 --> Model Class Initialized
INFO - 2017-01-19 16:32:55 --> Model Class Initialized
INFO - 2017-01-19 16:32:55 --> Model Class Initialized
INFO - 2017-01-19 16:32:55 --> Model Class Initialized
INFO - 2017-01-19 16:32:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:32:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 16:32:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-19 16:32:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:32:55 --> Final output sent to browser
DEBUG - 2017-01-19 16:32:55 --> Total execution time: 0.1138
INFO - 2017-01-19 16:33:01 --> Config Class Initialized
INFO - 2017-01-19 16:33:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:33:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:33:01 --> Utf8 Class Initialized
INFO - 2017-01-19 16:33:01 --> URI Class Initialized
INFO - 2017-01-19 16:33:01 --> Router Class Initialized
INFO - 2017-01-19 16:33:01 --> Output Class Initialized
INFO - 2017-01-19 16:33:01 --> Security Class Initialized
DEBUG - 2017-01-19 16:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:33:01 --> Input Class Initialized
INFO - 2017-01-19 16:33:01 --> Language Class Initialized
INFO - 2017-01-19 16:33:01 --> Loader Class Initialized
INFO - 2017-01-19 16:33:01 --> Helper loaded: url_helper
INFO - 2017-01-19 16:33:01 --> Helper loaded: language_helper
INFO - 2017-01-19 16:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:33:01 --> Controller Class Initialized
INFO - 2017-01-19 16:33:01 --> Database Driver Class Initialized
INFO - 2017-01-19 16:33:01 --> Model Class Initialized
INFO - 2017-01-19 16:33:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:33:01 --> Helper loaded: form_helper
INFO - 2017-01-19 16:33:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:33:01 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:33:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:33:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:33:01 --> Final output sent to browser
DEBUG - 2017-01-19 16:33:01 --> Total execution time: 0.1097
INFO - 2017-01-19 16:34:39 --> Config Class Initialized
INFO - 2017-01-19 16:34:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:34:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:34:39 --> Utf8 Class Initialized
INFO - 2017-01-19 16:34:39 --> URI Class Initialized
INFO - 2017-01-19 16:34:39 --> Router Class Initialized
INFO - 2017-01-19 16:34:39 --> Output Class Initialized
INFO - 2017-01-19 16:34:39 --> Security Class Initialized
DEBUG - 2017-01-19 16:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:34:39 --> Input Class Initialized
INFO - 2017-01-19 16:34:39 --> Language Class Initialized
INFO - 2017-01-19 16:34:39 --> Loader Class Initialized
INFO - 2017-01-19 16:34:39 --> Helper loaded: url_helper
INFO - 2017-01-19 16:34:39 --> Helper loaded: language_helper
INFO - 2017-01-19 16:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:34:39 --> Controller Class Initialized
INFO - 2017-01-19 16:34:39 --> Database Driver Class Initialized
INFO - 2017-01-19 16:34:39 --> Model Class Initialized
INFO - 2017-01-19 16:34:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:34:39 --> Helper loaded: form_helper
INFO - 2017-01-19 16:34:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:34:39 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:34:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:34:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:34:39 --> Final output sent to browser
DEBUG - 2017-01-19 16:34:39 --> Total execution time: 0.1106
INFO - 2017-01-19 16:36:36 --> Config Class Initialized
INFO - 2017-01-19 16:36:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:36:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:36:36 --> Utf8 Class Initialized
INFO - 2017-01-19 16:36:36 --> URI Class Initialized
INFO - 2017-01-19 16:36:36 --> Router Class Initialized
INFO - 2017-01-19 16:36:36 --> Output Class Initialized
INFO - 2017-01-19 16:36:36 --> Security Class Initialized
DEBUG - 2017-01-19 16:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:36:36 --> Input Class Initialized
INFO - 2017-01-19 16:36:36 --> Language Class Initialized
INFO - 2017-01-19 16:36:36 --> Loader Class Initialized
INFO - 2017-01-19 16:36:36 --> Helper loaded: url_helper
INFO - 2017-01-19 16:36:36 --> Helper loaded: language_helper
INFO - 2017-01-19 16:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:36:36 --> Controller Class Initialized
INFO - 2017-01-19 16:36:36 --> Database Driver Class Initialized
INFO - 2017-01-19 16:36:37 --> Model Class Initialized
INFO - 2017-01-19 16:36:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:36:37 --> Helper loaded: form_helper
INFO - 2017-01-19 16:36:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:36:37 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:36:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:36:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:36:37 --> Final output sent to browser
DEBUG - 2017-01-19 16:36:37 --> Total execution time: 0.1456
INFO - 2017-01-19 16:42:39 --> Config Class Initialized
INFO - 2017-01-19 16:42:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:42:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:42:39 --> Utf8 Class Initialized
INFO - 2017-01-19 16:42:39 --> URI Class Initialized
INFO - 2017-01-19 16:42:39 --> Router Class Initialized
INFO - 2017-01-19 16:42:39 --> Output Class Initialized
INFO - 2017-01-19 16:42:39 --> Security Class Initialized
DEBUG - 2017-01-19 16:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:42:39 --> Input Class Initialized
INFO - 2017-01-19 16:42:39 --> Language Class Initialized
INFO - 2017-01-19 16:42:39 --> Loader Class Initialized
INFO - 2017-01-19 16:42:39 --> Helper loaded: url_helper
INFO - 2017-01-19 16:42:39 --> Helper loaded: language_helper
INFO - 2017-01-19 16:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:42:39 --> Controller Class Initialized
INFO - 2017-01-19 16:42:39 --> Database Driver Class Initialized
INFO - 2017-01-19 16:42:39 --> Model Class Initialized
INFO - 2017-01-19 16:42:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:42:39 --> Helper loaded: form_helper
INFO - 2017-01-19 16:42:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:42:39 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:42:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:42:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:42:39 --> Final output sent to browser
DEBUG - 2017-01-19 16:42:39 --> Total execution time: 0.1478
INFO - 2017-01-19 16:43:15 --> Config Class Initialized
INFO - 2017-01-19 16:43:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:43:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:43:15 --> Utf8 Class Initialized
INFO - 2017-01-19 16:43:15 --> URI Class Initialized
INFO - 2017-01-19 16:43:15 --> Router Class Initialized
INFO - 2017-01-19 16:43:15 --> Output Class Initialized
INFO - 2017-01-19 16:43:15 --> Security Class Initialized
DEBUG - 2017-01-19 16:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:43:15 --> Input Class Initialized
INFO - 2017-01-19 16:43:15 --> Language Class Initialized
INFO - 2017-01-19 16:43:15 --> Loader Class Initialized
INFO - 2017-01-19 16:43:15 --> Helper loaded: url_helper
INFO - 2017-01-19 16:43:15 --> Helper loaded: language_helper
INFO - 2017-01-19 16:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:43:15 --> Controller Class Initialized
INFO - 2017-01-19 16:43:15 --> Database Driver Class Initialized
INFO - 2017-01-19 16:43:15 --> Model Class Initialized
INFO - 2017-01-19 16:43:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:43:15 --> Helper loaded: form_helper
INFO - 2017-01-19 16:43:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:43:15 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:43:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:43:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:43:15 --> Final output sent to browser
DEBUG - 2017-01-19 16:43:15 --> Total execution time: 0.1415
INFO - 2017-01-19 16:44:31 --> Config Class Initialized
INFO - 2017-01-19 16:44:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:44:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:44:31 --> Utf8 Class Initialized
INFO - 2017-01-19 16:44:31 --> URI Class Initialized
INFO - 2017-01-19 16:44:31 --> Router Class Initialized
INFO - 2017-01-19 16:44:31 --> Output Class Initialized
INFO - 2017-01-19 16:44:31 --> Security Class Initialized
DEBUG - 2017-01-19 16:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:44:31 --> Input Class Initialized
INFO - 2017-01-19 16:44:31 --> Language Class Initialized
INFO - 2017-01-19 16:44:31 --> Loader Class Initialized
INFO - 2017-01-19 16:44:31 --> Helper loaded: url_helper
INFO - 2017-01-19 16:44:31 --> Helper loaded: language_helper
INFO - 2017-01-19 16:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:44:31 --> Controller Class Initialized
INFO - 2017-01-19 16:44:31 --> Database Driver Class Initialized
INFO - 2017-01-19 16:44:31 --> Model Class Initialized
INFO - 2017-01-19 16:44:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:44:31 --> Helper loaded: form_helper
INFO - 2017-01-19 16:44:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:44:31 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:44:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:44:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:44:31 --> Final output sent to browser
DEBUG - 2017-01-19 16:44:31 --> Total execution time: 0.1676
INFO - 2017-01-19 16:45:00 --> Config Class Initialized
INFO - 2017-01-19 16:45:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:45:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:45:00 --> Utf8 Class Initialized
INFO - 2017-01-19 16:45:00 --> URI Class Initialized
INFO - 2017-01-19 16:45:00 --> Router Class Initialized
INFO - 2017-01-19 16:45:00 --> Output Class Initialized
INFO - 2017-01-19 16:45:00 --> Security Class Initialized
DEBUG - 2017-01-19 16:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:45:00 --> Input Class Initialized
INFO - 2017-01-19 16:45:00 --> Language Class Initialized
INFO - 2017-01-19 16:45:00 --> Loader Class Initialized
INFO - 2017-01-19 16:45:00 --> Helper loaded: url_helper
INFO - 2017-01-19 16:45:00 --> Helper loaded: language_helper
INFO - 2017-01-19 16:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:45:00 --> Controller Class Initialized
INFO - 2017-01-19 16:45:00 --> Database Driver Class Initialized
INFO - 2017-01-19 16:45:00 --> Model Class Initialized
INFO - 2017-01-19 16:45:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:45:00 --> Config Class Initialized
INFO - 2017-01-19 16:45:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:45:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:45:00 --> Utf8 Class Initialized
INFO - 2017-01-19 16:45:00 --> URI Class Initialized
INFO - 2017-01-19 16:45:00 --> Router Class Initialized
INFO - 2017-01-19 16:45:00 --> Output Class Initialized
INFO - 2017-01-19 16:45:00 --> Security Class Initialized
DEBUG - 2017-01-19 16:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:45:00 --> Input Class Initialized
INFO - 2017-01-19 16:45:00 --> Language Class Initialized
INFO - 2017-01-19 16:45:00 --> Loader Class Initialized
INFO - 2017-01-19 16:45:00 --> Helper loaded: url_helper
INFO - 2017-01-19 16:45:00 --> Helper loaded: language_helper
INFO - 2017-01-19 16:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:45:00 --> Controller Class Initialized
INFO - 2017-01-19 16:45:00 --> Database Driver Class Initialized
INFO - 2017-01-19 16:45:00 --> Model Class Initialized
INFO - 2017-01-19 16:45:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:45:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-19 16:45:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-19 16:45:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-19 16:45:00 --> Final output sent to browser
DEBUG - 2017-01-19 16:45:00 --> Total execution time: 0.1724
INFO - 2017-01-19 16:45:06 --> Config Class Initialized
INFO - 2017-01-19 16:45:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:45:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:45:06 --> Utf8 Class Initialized
INFO - 2017-01-19 16:45:06 --> URI Class Initialized
INFO - 2017-01-19 16:45:06 --> Router Class Initialized
INFO - 2017-01-19 16:45:06 --> Output Class Initialized
INFO - 2017-01-19 16:45:06 --> Security Class Initialized
DEBUG - 2017-01-19 16:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:45:06 --> Input Class Initialized
INFO - 2017-01-19 16:45:06 --> Language Class Initialized
INFO - 2017-01-19 16:45:06 --> Loader Class Initialized
INFO - 2017-01-19 16:45:06 --> Helper loaded: url_helper
INFO - 2017-01-19 16:45:06 --> Helper loaded: language_helper
INFO - 2017-01-19 16:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:45:06 --> Controller Class Initialized
INFO - 2017-01-19 16:45:06 --> Database Driver Class Initialized
INFO - 2017-01-19 16:45:06 --> Model Class Initialized
INFO - 2017-01-19 16:45:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:45:06 --> Config Class Initialized
INFO - 2017-01-19 16:45:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:45:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:45:06 --> Utf8 Class Initialized
INFO - 2017-01-19 16:45:06 --> URI Class Initialized
INFO - 2017-01-19 16:45:06 --> Router Class Initialized
INFO - 2017-01-19 16:45:06 --> Output Class Initialized
INFO - 2017-01-19 16:45:06 --> Security Class Initialized
DEBUG - 2017-01-19 16:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:45:06 --> Input Class Initialized
INFO - 2017-01-19 16:45:06 --> Language Class Initialized
INFO - 2017-01-19 16:45:06 --> Loader Class Initialized
INFO - 2017-01-19 16:45:06 --> Helper loaded: url_helper
INFO - 2017-01-19 16:45:06 --> Helper loaded: language_helper
INFO - 2017-01-19 16:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:45:06 --> Controller Class Initialized
INFO - 2017-01-19 16:45:06 --> Database Driver Class Initialized
INFO - 2017-01-19 16:45:06 --> Model Class Initialized
INFO - 2017-01-19 16:45:06 --> Model Class Initialized
INFO - 2017-01-19 16:45:06 --> Model Class Initialized
INFO - 2017-01-19 16:45:06 --> Model Class Initialized
INFO - 2017-01-19 16:45:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:45:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 16:45:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-19 16:45:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:45:06 --> Final output sent to browser
DEBUG - 2017-01-19 16:45:06 --> Total execution time: 0.1450
INFO - 2017-01-19 16:45:10 --> Config Class Initialized
INFO - 2017-01-19 16:45:10 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:45:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:45:10 --> Utf8 Class Initialized
INFO - 2017-01-19 16:45:10 --> URI Class Initialized
INFO - 2017-01-19 16:45:10 --> Router Class Initialized
INFO - 2017-01-19 16:45:10 --> Output Class Initialized
INFO - 2017-01-19 16:45:10 --> Security Class Initialized
DEBUG - 2017-01-19 16:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:45:10 --> Input Class Initialized
INFO - 2017-01-19 16:45:10 --> Language Class Initialized
INFO - 2017-01-19 16:45:10 --> Loader Class Initialized
INFO - 2017-01-19 16:45:10 --> Helper loaded: url_helper
INFO - 2017-01-19 16:45:10 --> Helper loaded: language_helper
INFO - 2017-01-19 16:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:45:10 --> Controller Class Initialized
INFO - 2017-01-19 16:45:10 --> Database Driver Class Initialized
INFO - 2017-01-19 16:45:10 --> Model Class Initialized
INFO - 2017-01-19 16:45:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:45:10 --> Helper loaded: form_helper
INFO - 2017-01-19 16:45:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:45:10 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:45:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:45:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:45:10 --> Final output sent to browser
DEBUG - 2017-01-19 16:45:10 --> Total execution time: 0.1670
INFO - 2017-01-19 16:46:45 --> Config Class Initialized
INFO - 2017-01-19 16:46:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:46:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:46:45 --> Utf8 Class Initialized
INFO - 2017-01-19 16:46:45 --> URI Class Initialized
INFO - 2017-01-19 16:46:45 --> Router Class Initialized
INFO - 2017-01-19 16:46:45 --> Output Class Initialized
INFO - 2017-01-19 16:46:45 --> Security Class Initialized
DEBUG - 2017-01-19 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:46:45 --> Input Class Initialized
INFO - 2017-01-19 16:46:45 --> Language Class Initialized
INFO - 2017-01-19 16:46:45 --> Loader Class Initialized
INFO - 2017-01-19 16:46:45 --> Helper loaded: url_helper
INFO - 2017-01-19 16:46:45 --> Helper loaded: language_helper
INFO - 2017-01-19 16:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:46:45 --> Controller Class Initialized
INFO - 2017-01-19 16:46:45 --> Database Driver Class Initialized
INFO - 2017-01-19 16:46:45 --> Model Class Initialized
INFO - 2017-01-19 16:46:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:46:45 --> Helper loaded: form_helper
INFO - 2017-01-19 16:46:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:46:45 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:46:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:46:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:46:45 --> Final output sent to browser
DEBUG - 2017-01-19 16:46:45 --> Total execution time: 0.1648
INFO - 2017-01-19 16:47:17 --> Config Class Initialized
INFO - 2017-01-19 16:47:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:47:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:47:17 --> Utf8 Class Initialized
INFO - 2017-01-19 16:47:17 --> URI Class Initialized
INFO - 2017-01-19 16:47:17 --> Router Class Initialized
INFO - 2017-01-19 16:47:17 --> Output Class Initialized
INFO - 2017-01-19 16:47:17 --> Security Class Initialized
DEBUG - 2017-01-19 16:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:47:17 --> Input Class Initialized
INFO - 2017-01-19 16:47:17 --> Language Class Initialized
INFO - 2017-01-19 16:47:17 --> Loader Class Initialized
INFO - 2017-01-19 16:47:17 --> Helper loaded: url_helper
INFO - 2017-01-19 16:47:17 --> Helper loaded: language_helper
INFO - 2017-01-19 16:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:47:17 --> Controller Class Initialized
INFO - 2017-01-19 16:47:17 --> Database Driver Class Initialized
INFO - 2017-01-19 16:47:17 --> Model Class Initialized
INFO - 2017-01-19 16:47:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:47:17 --> Helper loaded: form_helper
INFO - 2017-01-19 16:47:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:47:17 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:47:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:47:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:47:17 --> Final output sent to browser
DEBUG - 2017-01-19 16:47:17 --> Total execution time: 0.1064
INFO - 2017-01-19 16:48:47 --> Config Class Initialized
INFO - 2017-01-19 16:48:47 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:48:47 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:48:47 --> Utf8 Class Initialized
INFO - 2017-01-19 16:48:47 --> URI Class Initialized
INFO - 2017-01-19 16:48:47 --> Router Class Initialized
INFO - 2017-01-19 16:48:47 --> Output Class Initialized
INFO - 2017-01-19 16:48:47 --> Security Class Initialized
DEBUG - 2017-01-19 16:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:48:47 --> Input Class Initialized
INFO - 2017-01-19 16:48:47 --> Language Class Initialized
INFO - 2017-01-19 16:48:47 --> Loader Class Initialized
INFO - 2017-01-19 16:48:47 --> Helper loaded: url_helper
INFO - 2017-01-19 16:48:47 --> Helper loaded: language_helper
INFO - 2017-01-19 16:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:48:47 --> Controller Class Initialized
INFO - 2017-01-19 16:48:47 --> Database Driver Class Initialized
INFO - 2017-01-19 16:48:47 --> Model Class Initialized
INFO - 2017-01-19 16:48:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:48:47 --> Helper loaded: form_helper
INFO - 2017-01-19 16:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:48:47 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:48:47 --> Final output sent to browser
DEBUG - 2017-01-19 16:48:47 --> Total execution time: 0.1378
INFO - 2017-01-19 16:48:54 --> Config Class Initialized
INFO - 2017-01-19 16:48:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:48:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:48:54 --> Utf8 Class Initialized
INFO - 2017-01-19 16:48:54 --> URI Class Initialized
INFO - 2017-01-19 16:48:54 --> Router Class Initialized
INFO - 2017-01-19 16:48:54 --> Output Class Initialized
INFO - 2017-01-19 16:48:54 --> Security Class Initialized
DEBUG - 2017-01-19 16:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:48:54 --> Input Class Initialized
INFO - 2017-01-19 16:48:54 --> Language Class Initialized
INFO - 2017-01-19 16:48:54 --> Loader Class Initialized
INFO - 2017-01-19 16:48:54 --> Helper loaded: url_helper
INFO - 2017-01-19 16:48:54 --> Helper loaded: language_helper
INFO - 2017-01-19 16:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:48:54 --> Controller Class Initialized
INFO - 2017-01-19 16:48:54 --> Database Driver Class Initialized
INFO - 2017-01-19 16:48:54 --> Model Class Initialized
INFO - 2017-01-19 16:48:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:48:54 --> Config Class Initialized
INFO - 2017-01-19 16:48:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:48:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:48:54 --> Utf8 Class Initialized
INFO - 2017-01-19 16:48:54 --> URI Class Initialized
INFO - 2017-01-19 16:48:54 --> Router Class Initialized
INFO - 2017-01-19 16:48:54 --> Output Class Initialized
INFO - 2017-01-19 16:48:54 --> Security Class Initialized
DEBUG - 2017-01-19 16:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:48:54 --> Input Class Initialized
INFO - 2017-01-19 16:48:54 --> Language Class Initialized
INFO - 2017-01-19 16:48:54 --> Loader Class Initialized
INFO - 2017-01-19 16:48:54 --> Helper loaded: url_helper
INFO - 2017-01-19 16:48:54 --> Helper loaded: language_helper
INFO - 2017-01-19 16:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:48:54 --> Controller Class Initialized
INFO - 2017-01-19 16:48:54 --> Database Driver Class Initialized
INFO - 2017-01-19 16:48:54 --> Model Class Initialized
INFO - 2017-01-19 16:48:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:48:54 --> Helper loaded: form_helper
INFO - 2017-01-19 16:48:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:48:54 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:48:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:48:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:48:54 --> Final output sent to browser
DEBUG - 2017-01-19 16:48:54 --> Total execution time: 0.1396
INFO - 2017-01-19 16:51:13 --> Config Class Initialized
INFO - 2017-01-19 16:51:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:13 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:13 --> URI Class Initialized
INFO - 2017-01-19 16:51:13 --> Router Class Initialized
INFO - 2017-01-19 16:51:13 --> Output Class Initialized
INFO - 2017-01-19 16:51:13 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:13 --> Input Class Initialized
INFO - 2017-01-19 16:51:13 --> Language Class Initialized
INFO - 2017-01-19 16:51:13 --> Loader Class Initialized
INFO - 2017-01-19 16:51:13 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:13 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:13 --> Controller Class Initialized
INFO - 2017-01-19 16:51:13 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:13 --> Model Class Initialized
INFO - 2017-01-19 16:51:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:13 --> Helper loaded: form_helper
INFO - 2017-01-19 16:51:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:51:13 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:51:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:51:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:51:13 --> Final output sent to browser
DEBUG - 2017-01-19 16:51:13 --> Total execution time: 0.1342
INFO - 2017-01-19 16:51:18 --> Config Class Initialized
INFO - 2017-01-19 16:51:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:18 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:18 --> URI Class Initialized
INFO - 2017-01-19 16:51:18 --> Router Class Initialized
INFO - 2017-01-19 16:51:18 --> Output Class Initialized
INFO - 2017-01-19 16:51:18 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:18 --> Input Class Initialized
INFO - 2017-01-19 16:51:18 --> Language Class Initialized
INFO - 2017-01-19 16:51:18 --> Loader Class Initialized
INFO - 2017-01-19 16:51:18 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:18 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:18 --> Controller Class Initialized
INFO - 2017-01-19 16:51:18 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:18 --> Model Class Initialized
INFO - 2017-01-19 16:51:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:18 --> Config Class Initialized
INFO - 2017-01-19 16:51:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:18 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:18 --> URI Class Initialized
INFO - 2017-01-19 16:51:18 --> Router Class Initialized
INFO - 2017-01-19 16:51:18 --> Output Class Initialized
INFO - 2017-01-19 16:51:18 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:18 --> Input Class Initialized
INFO - 2017-01-19 16:51:18 --> Language Class Initialized
INFO - 2017-01-19 16:51:18 --> Loader Class Initialized
INFO - 2017-01-19 16:51:18 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:18 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:18 --> Controller Class Initialized
INFO - 2017-01-19 16:51:18 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:18 --> Model Class Initialized
INFO - 2017-01-19 16:51:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:18 --> Helper loaded: form_helper
INFO - 2017-01-19 16:51:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:51:18 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:51:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:51:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:51:18 --> Final output sent to browser
DEBUG - 2017-01-19 16:51:18 --> Total execution time: 0.1076
INFO - 2017-01-19 16:51:23 --> Config Class Initialized
INFO - 2017-01-19 16:51:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:23 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:23 --> URI Class Initialized
INFO - 2017-01-19 16:51:23 --> Router Class Initialized
INFO - 2017-01-19 16:51:23 --> Output Class Initialized
INFO - 2017-01-19 16:51:23 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:23 --> Input Class Initialized
INFO - 2017-01-19 16:51:23 --> Language Class Initialized
INFO - 2017-01-19 16:51:23 --> Loader Class Initialized
INFO - 2017-01-19 16:51:23 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:23 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:23 --> Controller Class Initialized
INFO - 2017-01-19 16:51:23 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:23 --> Model Class Initialized
INFO - 2017-01-19 16:51:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:23 --> Helper loaded: form_helper
INFO - 2017-01-19 16:51:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 16:51:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 16:51:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:51:23 --> Final output sent to browser
DEBUG - 2017-01-19 16:51:23 --> Total execution time: 0.1437
INFO - 2017-01-19 16:51:29 --> Config Class Initialized
INFO - 2017-01-19 16:51:29 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:29 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:29 --> URI Class Initialized
INFO - 2017-01-19 16:51:29 --> Router Class Initialized
INFO - 2017-01-19 16:51:29 --> Output Class Initialized
INFO - 2017-01-19 16:51:29 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:29 --> Input Class Initialized
INFO - 2017-01-19 16:51:29 --> Language Class Initialized
INFO - 2017-01-19 16:51:29 --> Loader Class Initialized
INFO - 2017-01-19 16:51:29 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:29 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:30 --> Controller Class Initialized
INFO - 2017-01-19 16:51:30 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:30 --> Model Class Initialized
INFO - 2017-01-19 16:51:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:30 --> Helper loaded: form_helper
INFO - 2017-01-19 16:51:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:51:30 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:51:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:51:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:51:30 --> Final output sent to browser
DEBUG - 2017-01-19 16:51:30 --> Total execution time: 0.1196
INFO - 2017-01-19 16:51:36 --> Config Class Initialized
INFO - 2017-01-19 16:51:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:36 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:36 --> URI Class Initialized
INFO - 2017-01-19 16:51:36 --> Router Class Initialized
INFO - 2017-01-19 16:51:36 --> Output Class Initialized
INFO - 2017-01-19 16:51:36 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:36 --> Input Class Initialized
INFO - 2017-01-19 16:51:36 --> Language Class Initialized
INFO - 2017-01-19 16:51:36 --> Loader Class Initialized
INFO - 2017-01-19 16:51:36 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:36 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:36 --> Controller Class Initialized
INFO - 2017-01-19 16:51:36 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:36 --> Model Class Initialized
INFO - 2017-01-19 16:51:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:36 --> Config Class Initialized
INFO - 2017-01-19 16:51:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:36 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:36 --> URI Class Initialized
INFO - 2017-01-19 16:51:36 --> Router Class Initialized
INFO - 2017-01-19 16:51:36 --> Output Class Initialized
INFO - 2017-01-19 16:51:36 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:36 --> Input Class Initialized
INFO - 2017-01-19 16:51:36 --> Language Class Initialized
INFO - 2017-01-19 16:51:36 --> Loader Class Initialized
INFO - 2017-01-19 16:51:36 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:36 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:36 --> Controller Class Initialized
INFO - 2017-01-19 16:51:36 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:36 --> Model Class Initialized
INFO - 2017-01-19 16:51:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:36 --> Helper loaded: form_helper
INFO - 2017-01-19 16:51:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 16:51:36 --> Could not find the language line "import_user"
INFO - 2017-01-19 16:51:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 16:51:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:51:36 --> Final output sent to browser
DEBUG - 2017-01-19 16:51:36 --> Total execution time: 0.1560
INFO - 2017-01-19 16:51:39 --> Config Class Initialized
INFO - 2017-01-19 16:51:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:51:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:51:39 --> Utf8 Class Initialized
INFO - 2017-01-19 16:51:40 --> URI Class Initialized
INFO - 2017-01-19 16:51:40 --> Router Class Initialized
INFO - 2017-01-19 16:51:40 --> Output Class Initialized
INFO - 2017-01-19 16:51:40 --> Security Class Initialized
DEBUG - 2017-01-19 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:51:40 --> Input Class Initialized
INFO - 2017-01-19 16:51:40 --> Language Class Initialized
INFO - 2017-01-19 16:51:40 --> Loader Class Initialized
INFO - 2017-01-19 16:51:40 --> Helper loaded: url_helper
INFO - 2017-01-19 16:51:40 --> Helper loaded: language_helper
INFO - 2017-01-19 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:51:40 --> Controller Class Initialized
INFO - 2017-01-19 16:51:40 --> Database Driver Class Initialized
INFO - 2017-01-19 16:51:40 --> Model Class Initialized
INFO - 2017-01-19 16:51:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 16:51:40 --> Helper loaded: form_helper
INFO - 2017-01-19 16:51:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 16:51:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 16:51:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 16:51:40 --> Final output sent to browser
DEBUG - 2017-01-19 16:51:40 --> Total execution time: 0.1747
INFO - 2017-01-19 17:14:49 --> Config Class Initialized
INFO - 2017-01-19 17:14:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:14:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:14:49 --> Utf8 Class Initialized
INFO - 2017-01-19 17:14:49 --> URI Class Initialized
INFO - 2017-01-19 17:14:49 --> Router Class Initialized
INFO - 2017-01-19 17:14:49 --> Output Class Initialized
INFO - 2017-01-19 17:14:49 --> Security Class Initialized
DEBUG - 2017-01-19 17:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:14:49 --> Input Class Initialized
INFO - 2017-01-19 17:14:49 --> Language Class Initialized
INFO - 2017-01-19 17:14:49 --> Loader Class Initialized
INFO - 2017-01-19 17:14:49 --> Helper loaded: url_helper
INFO - 2017-01-19 17:14:49 --> Helper loaded: language_helper
INFO - 2017-01-19 17:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:14:49 --> Controller Class Initialized
INFO - 2017-01-19 17:14:49 --> Database Driver Class Initialized
INFO - 2017-01-19 17:14:49 --> Model Class Initialized
INFO - 2017-01-19 17:14:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:14:49 --> Helper loaded: form_helper
ERROR - 2017-01-19 17:14:49 --> Severity: Notice --> Undefined property: User::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\User.php 34
ERROR - 2017-01-19 17:14:49 --> Severity: Error --> Call to a member function quiz_list() on null C:\wamp64\www\savsoftquiz\application\controllers\User.php 34
INFO - 2017-01-19 17:16:19 --> Config Class Initialized
INFO - 2017-01-19 17:16:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:16:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:16:19 --> Utf8 Class Initialized
INFO - 2017-01-19 17:16:19 --> URI Class Initialized
INFO - 2017-01-19 17:16:19 --> Router Class Initialized
INFO - 2017-01-19 17:16:19 --> Output Class Initialized
INFO - 2017-01-19 17:16:19 --> Security Class Initialized
DEBUG - 2017-01-19 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:16:19 --> Input Class Initialized
INFO - 2017-01-19 17:16:19 --> Language Class Initialized
INFO - 2017-01-19 17:16:19 --> Loader Class Initialized
INFO - 2017-01-19 17:16:19 --> Helper loaded: url_helper
INFO - 2017-01-19 17:16:19 --> Helper loaded: language_helper
INFO - 2017-01-19 17:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:16:19 --> Controller Class Initialized
INFO - 2017-01-19 17:16:19 --> Database Driver Class Initialized
INFO - 2017-01-19 17:16:19 --> Model Class Initialized
INFO - 2017-01-19 17:16:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:16:19 --> Helper loaded: form_helper
ERROR - 2017-01-19 17:16:19 --> Severity: Notice --> Undefined property: User::$quiz_model C:\wamp64\www\savsoftquiz\application\controllers\User.php 35
ERROR - 2017-01-19 17:16:19 --> Severity: Error --> Call to a member function quiz_list() on null C:\wamp64\www\savsoftquiz\application\controllers\User.php 35
INFO - 2017-01-19 17:17:44 --> Config Class Initialized
INFO - 2017-01-19 17:17:44 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:17:44 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:17:44 --> Utf8 Class Initialized
INFO - 2017-01-19 17:17:44 --> URI Class Initialized
INFO - 2017-01-19 17:17:44 --> Router Class Initialized
INFO - 2017-01-19 17:17:44 --> Output Class Initialized
INFO - 2017-01-19 17:17:44 --> Security Class Initialized
DEBUG - 2017-01-19 17:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:17:44 --> Input Class Initialized
INFO - 2017-01-19 17:17:44 --> Language Class Initialized
INFO - 2017-01-19 17:17:44 --> Loader Class Initialized
INFO - 2017-01-19 17:17:44 --> Helper loaded: url_helper
INFO - 2017-01-19 17:17:44 --> Helper loaded: language_helper
INFO - 2017-01-19 17:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:17:44 --> Controller Class Initialized
INFO - 2017-01-19 17:17:44 --> Database Driver Class Initialized
INFO - 2017-01-19 17:17:44 --> Model Class Initialized
INFO - 2017-01-19 17:17:44 --> Model Class Initialized
INFO - 2017-01-19 17:17:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:17:44 --> Helper loaded: form_helper
INFO - 2017-01-19 17:17:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:17:44 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:17:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:17:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:17:44 --> Final output sent to browser
DEBUG - 2017-01-19 17:17:44 --> Total execution time: 0.1184
INFO - 2017-01-19 17:19:04 --> Config Class Initialized
INFO - 2017-01-19 17:19:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:19:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:19:04 --> Utf8 Class Initialized
INFO - 2017-01-19 17:19:04 --> URI Class Initialized
INFO - 2017-01-19 17:19:04 --> Router Class Initialized
INFO - 2017-01-19 17:19:04 --> Output Class Initialized
INFO - 2017-01-19 17:19:04 --> Security Class Initialized
DEBUG - 2017-01-19 17:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:19:04 --> Input Class Initialized
INFO - 2017-01-19 17:19:04 --> Language Class Initialized
INFO - 2017-01-19 17:19:04 --> Loader Class Initialized
INFO - 2017-01-19 17:19:04 --> Helper loaded: url_helper
INFO - 2017-01-19 17:19:04 --> Helper loaded: language_helper
INFO - 2017-01-19 17:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:19:04 --> Controller Class Initialized
INFO - 2017-01-19 17:19:04 --> Database Driver Class Initialized
INFO - 2017-01-19 17:19:04 --> Model Class Initialized
INFO - 2017-01-19 17:19:04 --> Model Class Initialized
INFO - 2017-01-19 17:19:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:19:04 --> Helper loaded: form_helper
INFO - 2017-01-19 17:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:19:04 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:19:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:19:04 --> Final output sent to browser
DEBUG - 2017-01-19 17:19:04 --> Total execution time: 0.1254
INFO - 2017-01-19 17:19:42 --> Config Class Initialized
INFO - 2017-01-19 17:19:42 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:19:42 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:19:42 --> Utf8 Class Initialized
INFO - 2017-01-19 17:19:42 --> URI Class Initialized
INFO - 2017-01-19 17:19:42 --> Router Class Initialized
INFO - 2017-01-19 17:19:42 --> Output Class Initialized
INFO - 2017-01-19 17:19:42 --> Security Class Initialized
DEBUG - 2017-01-19 17:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:19:42 --> Input Class Initialized
INFO - 2017-01-19 17:19:42 --> Language Class Initialized
INFO - 2017-01-19 17:19:42 --> Loader Class Initialized
INFO - 2017-01-19 17:19:42 --> Helper loaded: url_helper
INFO - 2017-01-19 17:19:42 --> Helper loaded: language_helper
INFO - 2017-01-19 17:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:19:42 --> Controller Class Initialized
INFO - 2017-01-19 17:19:42 --> Database Driver Class Initialized
INFO - 2017-01-19 17:19:42 --> Model Class Initialized
INFO - 2017-01-19 17:19:42 --> Model Class Initialized
INFO - 2017-01-19 17:19:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:19:42 --> Helper loaded: form_helper
INFO - 2017-01-19 17:19:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:19:42 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:19:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:19:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:19:42 --> Final output sent to browser
DEBUG - 2017-01-19 17:19:42 --> Total execution time: 0.1092
INFO - 2017-01-19 17:20:06 --> Config Class Initialized
INFO - 2017-01-19 17:20:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:20:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:20:06 --> Utf8 Class Initialized
INFO - 2017-01-19 17:20:06 --> URI Class Initialized
INFO - 2017-01-19 17:20:06 --> Router Class Initialized
INFO - 2017-01-19 17:20:06 --> Output Class Initialized
INFO - 2017-01-19 17:20:06 --> Security Class Initialized
DEBUG - 2017-01-19 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:20:06 --> Input Class Initialized
INFO - 2017-01-19 17:20:06 --> Language Class Initialized
INFO - 2017-01-19 17:20:06 --> Loader Class Initialized
INFO - 2017-01-19 17:20:06 --> Helper loaded: url_helper
INFO - 2017-01-19 17:20:06 --> Helper loaded: language_helper
INFO - 2017-01-19 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:20:06 --> Controller Class Initialized
INFO - 2017-01-19 17:20:06 --> Database Driver Class Initialized
INFO - 2017-01-19 17:20:06 --> Model Class Initialized
INFO - 2017-01-19 17:20:06 --> Model Class Initialized
INFO - 2017-01-19 17:20:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:20:06 --> Helper loaded: form_helper
INFO - 2017-01-19 17:20:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:20:06 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:20:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:20:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:20:06 --> Final output sent to browser
DEBUG - 2017-01-19 17:20:06 --> Total execution time: 0.1554
INFO - 2017-01-19 17:25:07 --> Config Class Initialized
INFO - 2017-01-19 17:25:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:25:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:25:07 --> Utf8 Class Initialized
INFO - 2017-01-19 17:25:07 --> URI Class Initialized
INFO - 2017-01-19 17:25:07 --> Router Class Initialized
INFO - 2017-01-19 17:25:07 --> Output Class Initialized
INFO - 2017-01-19 17:25:07 --> Security Class Initialized
DEBUG - 2017-01-19 17:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:25:07 --> Input Class Initialized
INFO - 2017-01-19 17:25:07 --> Language Class Initialized
INFO - 2017-01-19 17:25:07 --> Loader Class Initialized
INFO - 2017-01-19 17:25:07 --> Helper loaded: url_helper
INFO - 2017-01-19 17:25:07 --> Helper loaded: language_helper
INFO - 2017-01-19 17:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:25:07 --> Controller Class Initialized
INFO - 2017-01-19 17:25:07 --> Database Driver Class Initialized
INFO - 2017-01-19 17:25:07 --> Model Class Initialized
INFO - 2017-01-19 17:25:07 --> Model Class Initialized
INFO - 2017-01-19 17:25:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:25:07 --> Helper loaded: form_helper
INFO - 2017-01-19 17:25:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:25:07 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:25:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:25:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:25:07 --> Final output sent to browser
DEBUG - 2017-01-19 17:25:07 --> Total execution time: 0.1370
INFO - 2017-01-19 17:25:19 --> Config Class Initialized
INFO - 2017-01-19 17:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:25:19 --> Utf8 Class Initialized
INFO - 2017-01-19 17:25:19 --> URI Class Initialized
INFO - 2017-01-19 17:25:19 --> Router Class Initialized
INFO - 2017-01-19 17:25:19 --> Output Class Initialized
INFO - 2017-01-19 17:25:19 --> Security Class Initialized
DEBUG - 2017-01-19 17:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:25:19 --> Input Class Initialized
INFO - 2017-01-19 17:25:19 --> Language Class Initialized
INFO - 2017-01-19 17:25:19 --> Loader Class Initialized
INFO - 2017-01-19 17:25:19 --> Helper loaded: url_helper
INFO - 2017-01-19 17:25:19 --> Helper loaded: language_helper
INFO - 2017-01-19 17:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:25:19 --> Controller Class Initialized
INFO - 2017-01-19 17:25:19 --> Database Driver Class Initialized
INFO - 2017-01-19 17:25:19 --> Model Class Initialized
INFO - 2017-01-19 17:25:19 --> Model Class Initialized
INFO - 2017-01-19 17:25:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:25:19 --> Query error: Unknown column 'quid' in 'where clause' - Invalid query: DELETE FROM `answers`
WHERE `uid` = '36'
AND `quid` = '20'
INFO - 2017-01-19 17:25:19 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-19 17:29:21 --> Config Class Initialized
INFO - 2017-01-19 17:29:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:29:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:29:21 --> Utf8 Class Initialized
INFO - 2017-01-19 17:29:21 --> URI Class Initialized
INFO - 2017-01-19 17:29:21 --> Router Class Initialized
INFO - 2017-01-19 17:29:21 --> Output Class Initialized
INFO - 2017-01-19 17:29:21 --> Security Class Initialized
DEBUG - 2017-01-19 17:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:29:21 --> Input Class Initialized
INFO - 2017-01-19 17:29:21 --> Language Class Initialized
INFO - 2017-01-19 17:29:21 --> Loader Class Initialized
INFO - 2017-01-19 17:29:21 --> Helper loaded: url_helper
INFO - 2017-01-19 17:29:21 --> Helper loaded: language_helper
INFO - 2017-01-19 17:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:29:21 --> Controller Class Initialized
INFO - 2017-01-19 17:29:21 --> Database Driver Class Initialized
INFO - 2017-01-19 17:29:21 --> Model Class Initialized
INFO - 2017-01-19 17:29:21 --> Model Class Initialized
INFO - 2017-01-19 17:29:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:29:21 --> Helper loaded: form_helper
INFO - 2017-01-19 17:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:29:21 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:29:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:29:21 --> Final output sent to browser
DEBUG - 2017-01-19 17:29:21 --> Total execution time: 0.1399
INFO - 2017-01-19 17:37:15 --> Config Class Initialized
INFO - 2017-01-19 17:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:15 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:15 --> URI Class Initialized
INFO - 2017-01-19 17:37:15 --> Router Class Initialized
INFO - 2017-01-19 17:37:15 --> Output Class Initialized
INFO - 2017-01-19 17:37:15 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:15 --> Input Class Initialized
INFO - 2017-01-19 17:37:15 --> Language Class Initialized
INFO - 2017-01-19 17:37:15 --> Loader Class Initialized
INFO - 2017-01-19 17:37:15 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:15 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:15 --> Controller Class Initialized
INFO - 2017-01-19 17:37:15 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:15 --> Model Class Initialized
INFO - 2017-01-19 17:37:15 --> Model Class Initialized
INFO - 2017-01-19 17:37:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:37:15 --> Helper loaded: form_helper
INFO - 2017-01-19 17:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:37:15 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:37:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:37:15 --> Final output sent to browser
DEBUG - 2017-01-19 17:37:15 --> Total execution time: 0.1566
INFO - 2017-01-19 17:37:21 --> Config Class Initialized
INFO - 2017-01-19 17:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:21 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:21 --> URI Class Initialized
INFO - 2017-01-19 17:37:21 --> Router Class Initialized
INFO - 2017-01-19 17:37:21 --> Output Class Initialized
INFO - 2017-01-19 17:37:21 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:21 --> Input Class Initialized
INFO - 2017-01-19 17:37:21 --> Language Class Initialized
INFO - 2017-01-19 17:37:21 --> Loader Class Initialized
INFO - 2017-01-19 17:37:21 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:21 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:21 --> Controller Class Initialized
INFO - 2017-01-19 17:37:21 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:21 --> Model Class Initialized
INFO - 2017-01-19 17:37:21 --> Model Class Initialized
INFO - 2017-01-19 17:37:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:37:21 --> Query error: Unknown column 'quid' in 'where clause' - Invalid query: DELETE FROM `answers`
WHERE `quid` = '20'
INFO - 2017-01-19 17:37:21 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-19 17:37:41 --> Config Class Initialized
INFO - 2017-01-19 17:37:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:41 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:41 --> URI Class Initialized
INFO - 2017-01-19 17:37:41 --> Router Class Initialized
INFO - 2017-01-19 17:37:41 --> Output Class Initialized
INFO - 2017-01-19 17:37:41 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:41 --> Input Class Initialized
INFO - 2017-01-19 17:37:41 --> Language Class Initialized
INFO - 2017-01-19 17:37:41 --> Loader Class Initialized
INFO - 2017-01-19 17:37:41 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:41 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:41 --> Controller Class Initialized
INFO - 2017-01-19 17:37:41 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:41 --> Model Class Initialized
INFO - 2017-01-19 17:37:41 --> Model Class Initialized
INFO - 2017-01-19 17:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:37:41 --> Helper loaded: form_helper
INFO - 2017-01-19 17:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:37:41 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:37:41 --> Final output sent to browser
DEBUG - 2017-01-19 17:37:41 --> Total execution time: 0.1871
INFO - 2017-01-19 17:37:43 --> Config Class Initialized
INFO - 2017-01-19 17:37:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:43 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:43 --> URI Class Initialized
INFO - 2017-01-19 17:37:43 --> Router Class Initialized
INFO - 2017-01-19 17:37:43 --> Output Class Initialized
INFO - 2017-01-19 17:37:43 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:43 --> Input Class Initialized
INFO - 2017-01-19 17:37:43 --> Language Class Initialized
INFO - 2017-01-19 17:37:43 --> Loader Class Initialized
INFO - 2017-01-19 17:37:43 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:43 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:43 --> Controller Class Initialized
INFO - 2017-01-19 17:37:43 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:43 --> Model Class Initialized
INFO - 2017-01-19 17:37:43 --> Model Class Initialized
INFO - 2017-01-19 17:37:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:37:43 --> Helper loaded: form_helper
INFO - 2017-01-19 17:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:37:43 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:37:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:37:43 --> Final output sent to browser
DEBUG - 2017-01-19 17:37:43 --> Total execution time: 0.1429
INFO - 2017-01-19 17:37:48 --> Config Class Initialized
INFO - 2017-01-19 17:37:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:48 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:48 --> URI Class Initialized
INFO - 2017-01-19 17:37:48 --> Router Class Initialized
INFO - 2017-01-19 17:37:48 --> Output Class Initialized
INFO - 2017-01-19 17:37:48 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:48 --> Input Class Initialized
INFO - 2017-01-19 17:37:48 --> Language Class Initialized
INFO - 2017-01-19 17:37:48 --> Loader Class Initialized
INFO - 2017-01-19 17:37:48 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:48 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:48 --> Controller Class Initialized
INFO - 2017-01-19 17:37:48 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:48 --> Model Class Initialized
INFO - 2017-01-19 17:37:48 --> Model Class Initialized
INFO - 2017-01-19 17:37:48 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:37:48 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 308
ERROR - 2017-01-19 17:37:48 --> Severity: Warning --> Missing argument 2 for User_model::reset_quiz_table_disc_answers(), called in C:\wamp64\www\savsoftquiz\application\models\User_model.php on line 298 and defined C:\wamp64\www\savsoftquiz\application\models\User_model.php 329
ERROR - 2017-01-19 17:37:48 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 331
INFO - 2017-01-19 17:37:48 --> Config Class Initialized
INFO - 2017-01-19 17:37:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:48 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:48 --> URI Class Initialized
INFO - 2017-01-19 17:37:48 --> Router Class Initialized
INFO - 2017-01-19 17:37:48 --> Output Class Initialized
INFO - 2017-01-19 17:37:48 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:48 --> Input Class Initialized
INFO - 2017-01-19 17:37:48 --> Language Class Initialized
INFO - 2017-01-19 17:37:48 --> Loader Class Initialized
INFO - 2017-01-19 17:37:48 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:48 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:48 --> Controller Class Initialized
INFO - 2017-01-19 17:37:48 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:48 --> Model Class Initialized
INFO - 2017-01-19 17:37:48 --> Model Class Initialized
INFO - 2017-01-19 17:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:37:48 --> Helper loaded: form_helper
INFO - 2017-01-19 17:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:37:48 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:37:48 --> Final output sent to browser
DEBUG - 2017-01-19 17:37:48 --> Total execution time: 0.1285
INFO - 2017-01-19 17:37:56 --> Config Class Initialized
INFO - 2017-01-19 17:37:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:56 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:56 --> URI Class Initialized
INFO - 2017-01-19 17:37:56 --> Router Class Initialized
INFO - 2017-01-19 17:37:56 --> Output Class Initialized
INFO - 2017-01-19 17:37:56 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:56 --> Input Class Initialized
INFO - 2017-01-19 17:37:56 --> Language Class Initialized
INFO - 2017-01-19 17:37:56 --> Loader Class Initialized
INFO - 2017-01-19 17:37:56 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:56 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:56 --> Controller Class Initialized
INFO - 2017-01-19 17:37:56 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:56 --> Model Class Initialized
INFO - 2017-01-19 17:37:56 --> Model Class Initialized
INFO - 2017-01-19 17:37:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:37:56 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 308
ERROR - 2017-01-19 17:37:56 --> Severity: Warning --> Missing argument 2 for User_model::reset_quiz_table_disc_answers(), called in C:\wamp64\www\savsoftquiz\application\models\User_model.php on line 298 and defined C:\wamp64\www\savsoftquiz\application\models\User_model.php 329
ERROR - 2017-01-19 17:37:56 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 331
INFO - 2017-01-19 17:37:57 --> Config Class Initialized
INFO - 2017-01-19 17:37:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:37:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:37:57 --> Utf8 Class Initialized
INFO - 2017-01-19 17:37:57 --> URI Class Initialized
INFO - 2017-01-19 17:37:57 --> Router Class Initialized
INFO - 2017-01-19 17:37:57 --> Output Class Initialized
INFO - 2017-01-19 17:37:57 --> Security Class Initialized
DEBUG - 2017-01-19 17:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:37:57 --> Input Class Initialized
INFO - 2017-01-19 17:37:57 --> Language Class Initialized
INFO - 2017-01-19 17:37:57 --> Loader Class Initialized
INFO - 2017-01-19 17:37:57 --> Helper loaded: url_helper
INFO - 2017-01-19 17:37:57 --> Helper loaded: language_helper
INFO - 2017-01-19 17:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:37:57 --> Controller Class Initialized
INFO - 2017-01-19 17:37:57 --> Database Driver Class Initialized
INFO - 2017-01-19 17:37:57 --> Model Class Initialized
INFO - 2017-01-19 17:37:57 --> Model Class Initialized
INFO - 2017-01-19 17:37:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:37:57 --> Helper loaded: form_helper
INFO - 2017-01-19 17:37:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:37:57 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:37:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:37:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:37:57 --> Final output sent to browser
DEBUG - 2017-01-19 17:37:57 --> Total execution time: 0.1213
INFO - 2017-01-19 17:38:03 --> Config Class Initialized
INFO - 2017-01-19 17:38:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:38:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:38:03 --> Utf8 Class Initialized
INFO - 2017-01-19 17:38:03 --> URI Class Initialized
INFO - 2017-01-19 17:38:03 --> Router Class Initialized
INFO - 2017-01-19 17:38:03 --> Output Class Initialized
INFO - 2017-01-19 17:38:03 --> Security Class Initialized
DEBUG - 2017-01-19 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:38:03 --> Input Class Initialized
INFO - 2017-01-19 17:38:03 --> Language Class Initialized
INFO - 2017-01-19 17:38:03 --> Loader Class Initialized
INFO - 2017-01-19 17:38:03 --> Helper loaded: url_helper
INFO - 2017-01-19 17:38:03 --> Helper loaded: language_helper
INFO - 2017-01-19 17:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:38:03 --> Controller Class Initialized
INFO - 2017-01-19 17:38:03 --> Database Driver Class Initialized
INFO - 2017-01-19 17:38:03 --> Model Class Initialized
INFO - 2017-01-19 17:38:03 --> Model Class Initialized
INFO - 2017-01-19 17:38:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:38:03 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 308
ERROR - 2017-01-19 17:38:03 --> Severity: Warning --> Missing argument 2 for User_model::reset_quiz_table_disc_answers(), called in C:\wamp64\www\savsoftquiz\application\models\User_model.php on line 298 and defined C:\wamp64\www\savsoftquiz\application\models\User_model.php 329
ERROR - 2017-01-19 17:38:03 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 331
INFO - 2017-01-19 17:38:03 --> Config Class Initialized
INFO - 2017-01-19 17:38:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:38:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:38:04 --> Utf8 Class Initialized
INFO - 2017-01-19 17:38:04 --> URI Class Initialized
INFO - 2017-01-19 17:38:04 --> Router Class Initialized
INFO - 2017-01-19 17:38:04 --> Output Class Initialized
INFO - 2017-01-19 17:38:04 --> Security Class Initialized
DEBUG - 2017-01-19 17:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:38:04 --> Input Class Initialized
INFO - 2017-01-19 17:38:04 --> Language Class Initialized
INFO - 2017-01-19 17:38:04 --> Loader Class Initialized
INFO - 2017-01-19 17:38:04 --> Helper loaded: url_helper
INFO - 2017-01-19 17:38:04 --> Helper loaded: language_helper
INFO - 2017-01-19 17:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:38:04 --> Controller Class Initialized
INFO - 2017-01-19 17:38:04 --> Database Driver Class Initialized
INFO - 2017-01-19 17:38:04 --> Model Class Initialized
INFO - 2017-01-19 17:38:04 --> Model Class Initialized
INFO - 2017-01-19 17:38:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:38:04 --> Helper loaded: form_helper
INFO - 2017-01-19 17:38:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:38:04 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:38:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:38:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:38:04 --> Final output sent to browser
DEBUG - 2017-01-19 17:38:04 --> Total execution time: 0.1352
INFO - 2017-01-19 17:38:09 --> Config Class Initialized
INFO - 2017-01-19 17:38:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:38:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:38:09 --> Utf8 Class Initialized
INFO - 2017-01-19 17:38:09 --> URI Class Initialized
INFO - 2017-01-19 17:38:09 --> Router Class Initialized
INFO - 2017-01-19 17:38:09 --> Output Class Initialized
INFO - 2017-01-19 17:38:09 --> Security Class Initialized
DEBUG - 2017-01-19 17:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:38:09 --> Input Class Initialized
INFO - 2017-01-19 17:38:09 --> Language Class Initialized
INFO - 2017-01-19 17:38:09 --> Loader Class Initialized
INFO - 2017-01-19 17:38:09 --> Helper loaded: url_helper
INFO - 2017-01-19 17:38:09 --> Helper loaded: language_helper
INFO - 2017-01-19 17:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:38:09 --> Controller Class Initialized
INFO - 2017-01-19 17:38:09 --> Database Driver Class Initialized
INFO - 2017-01-19 17:38:09 --> Model Class Initialized
INFO - 2017-01-19 17:38:09 --> Model Class Initialized
INFO - 2017-01-19 17:38:09 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:38:09 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 308
ERROR - 2017-01-19 17:38:09 --> Severity: Warning --> Missing argument 2 for User_model::reset_quiz_table_disc_answers(), called in C:\wamp64\www\savsoftquiz\application\models\User_model.php on line 298 and defined C:\wamp64\www\savsoftquiz\application\models\User_model.php 329
ERROR - 2017-01-19 17:38:09 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 331
INFO - 2017-01-19 17:38:09 --> Config Class Initialized
INFO - 2017-01-19 17:38:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:38:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:38:09 --> Utf8 Class Initialized
INFO - 2017-01-19 17:38:09 --> URI Class Initialized
INFO - 2017-01-19 17:38:09 --> Router Class Initialized
INFO - 2017-01-19 17:38:09 --> Output Class Initialized
INFO - 2017-01-19 17:38:09 --> Security Class Initialized
DEBUG - 2017-01-19 17:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:38:09 --> Input Class Initialized
INFO - 2017-01-19 17:38:09 --> Language Class Initialized
INFO - 2017-01-19 17:38:09 --> Loader Class Initialized
INFO - 2017-01-19 17:38:09 --> Helper loaded: url_helper
INFO - 2017-01-19 17:38:09 --> Helper loaded: language_helper
INFO - 2017-01-19 17:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:38:09 --> Controller Class Initialized
INFO - 2017-01-19 17:38:09 --> Database Driver Class Initialized
INFO - 2017-01-19 17:38:09 --> Model Class Initialized
INFO - 2017-01-19 17:38:09 --> Model Class Initialized
INFO - 2017-01-19 17:38:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:38:09 --> Helper loaded: form_helper
INFO - 2017-01-19 17:38:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:38:09 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:38:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:38:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:38:09 --> Final output sent to browser
DEBUG - 2017-01-19 17:38:09 --> Total execution time: 0.1234
INFO - 2017-01-19 17:39:43 --> Config Class Initialized
INFO - 2017-01-19 17:39:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:39:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:39:43 --> Utf8 Class Initialized
INFO - 2017-01-19 17:39:43 --> URI Class Initialized
INFO - 2017-01-19 17:39:43 --> Router Class Initialized
INFO - 2017-01-19 17:39:43 --> Output Class Initialized
INFO - 2017-01-19 17:39:43 --> Security Class Initialized
DEBUG - 2017-01-19 17:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:39:43 --> Input Class Initialized
INFO - 2017-01-19 17:39:43 --> Language Class Initialized
INFO - 2017-01-19 17:39:43 --> Loader Class Initialized
INFO - 2017-01-19 17:39:43 --> Helper loaded: url_helper
INFO - 2017-01-19 17:39:43 --> Helper loaded: language_helper
INFO - 2017-01-19 17:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:39:43 --> Controller Class Initialized
INFO - 2017-01-19 17:39:43 --> Database Driver Class Initialized
INFO - 2017-01-19 17:39:43 --> Model Class Initialized
INFO - 2017-01-19 17:39:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:39:43 --> Helper loaded: form_helper
INFO - 2017-01-19 17:39:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 17:39:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 17:39:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:39:43 --> Final output sent to browser
DEBUG - 2017-01-19 17:39:43 --> Total execution time: 0.1414
INFO - 2017-01-19 17:39:57 --> Config Class Initialized
INFO - 2017-01-19 17:39:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:39:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:39:57 --> Utf8 Class Initialized
INFO - 2017-01-19 17:39:57 --> URI Class Initialized
INFO - 2017-01-19 17:39:57 --> Router Class Initialized
INFO - 2017-01-19 17:39:57 --> Output Class Initialized
INFO - 2017-01-19 17:39:57 --> Security Class Initialized
DEBUG - 2017-01-19 17:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:39:57 --> Input Class Initialized
INFO - 2017-01-19 17:39:57 --> Language Class Initialized
INFO - 2017-01-19 17:39:57 --> Loader Class Initialized
INFO - 2017-01-19 17:39:57 --> Helper loaded: url_helper
INFO - 2017-01-19 17:39:57 --> Helper loaded: language_helper
INFO - 2017-01-19 17:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:39:57 --> Controller Class Initialized
INFO - 2017-01-19 17:39:57 --> Database Driver Class Initialized
INFO - 2017-01-19 17:39:57 --> Model Class Initialized
INFO - 2017-01-19 17:39:57 --> Model Class Initialized
INFO - 2017-01-19 17:39:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:39:57 --> Helper loaded: form_helper
INFO - 2017-01-19 17:39:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:39:57 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:39:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:39:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:39:57 --> Final output sent to browser
DEBUG - 2017-01-19 17:39:57 --> Total execution time: 0.1166
INFO - 2017-01-19 17:40:23 --> Config Class Initialized
INFO - 2017-01-19 17:40:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:40:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:40:23 --> Utf8 Class Initialized
INFO - 2017-01-19 17:40:23 --> URI Class Initialized
INFO - 2017-01-19 17:40:23 --> Router Class Initialized
INFO - 2017-01-19 17:40:23 --> Output Class Initialized
INFO - 2017-01-19 17:40:23 --> Security Class Initialized
DEBUG - 2017-01-19 17:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:40:23 --> Input Class Initialized
INFO - 2017-01-19 17:40:23 --> Language Class Initialized
INFO - 2017-01-19 17:40:23 --> Loader Class Initialized
INFO - 2017-01-19 17:40:23 --> Helper loaded: url_helper
INFO - 2017-01-19 17:40:23 --> Helper loaded: language_helper
INFO - 2017-01-19 17:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:40:23 --> Controller Class Initialized
INFO - 2017-01-19 17:40:23 --> Database Driver Class Initialized
INFO - 2017-01-19 17:40:23 --> Model Class Initialized
INFO - 2017-01-19 17:40:23 --> Model Class Initialized
INFO - 2017-01-19 17:40:23 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-19 17:40:24 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 308
ERROR - 2017-01-19 17:40:24 --> Severity: Warning --> Missing argument 2 for User_model::reset_quiz_table_disc_answers(), called in C:\wamp64\www\savsoftquiz\application\models\User_model.php on line 298 and defined C:\wamp64\www\savsoftquiz\application\models\User_model.php 329
ERROR - 2017-01-19 17:40:24 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\models\User_model.php 331
INFO - 2017-01-19 17:40:24 --> Config Class Initialized
INFO - 2017-01-19 17:40:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:40:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:40:24 --> Utf8 Class Initialized
INFO - 2017-01-19 17:40:24 --> URI Class Initialized
INFO - 2017-01-19 17:40:24 --> Router Class Initialized
INFO - 2017-01-19 17:40:24 --> Output Class Initialized
INFO - 2017-01-19 17:40:24 --> Security Class Initialized
DEBUG - 2017-01-19 17:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:40:24 --> Input Class Initialized
INFO - 2017-01-19 17:40:24 --> Language Class Initialized
INFO - 2017-01-19 17:40:24 --> Loader Class Initialized
INFO - 2017-01-19 17:40:24 --> Helper loaded: url_helper
INFO - 2017-01-19 17:40:24 --> Helper loaded: language_helper
INFO - 2017-01-19 17:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:40:24 --> Controller Class Initialized
INFO - 2017-01-19 17:40:24 --> Database Driver Class Initialized
INFO - 2017-01-19 17:40:24 --> Model Class Initialized
INFO - 2017-01-19 17:40:24 --> Model Class Initialized
INFO - 2017-01-19 17:40:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:40:24 --> Helper loaded: form_helper
INFO - 2017-01-19 17:40:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:40:24 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:40:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:40:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:40:24 --> Final output sent to browser
DEBUG - 2017-01-19 17:40:24 --> Total execution time: 0.1323
INFO - 2017-01-19 17:43:35 --> Config Class Initialized
INFO - 2017-01-19 17:43:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:43:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:43:35 --> Utf8 Class Initialized
INFO - 2017-01-19 17:43:35 --> URI Class Initialized
INFO - 2017-01-19 17:43:35 --> Router Class Initialized
INFO - 2017-01-19 17:43:35 --> Output Class Initialized
INFO - 2017-01-19 17:43:35 --> Security Class Initialized
DEBUG - 2017-01-19 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:43:35 --> Input Class Initialized
INFO - 2017-01-19 17:43:35 --> Language Class Initialized
INFO - 2017-01-19 17:43:35 --> Loader Class Initialized
INFO - 2017-01-19 17:43:35 --> Helper loaded: url_helper
INFO - 2017-01-19 17:43:35 --> Helper loaded: language_helper
INFO - 2017-01-19 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:43:35 --> Controller Class Initialized
INFO - 2017-01-19 17:43:35 --> Database Driver Class Initialized
INFO - 2017-01-19 17:43:35 --> Model Class Initialized
INFO - 2017-01-19 17:43:35 --> Model Class Initialized
INFO - 2017-01-19 17:43:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:43:35 --> Helper loaded: form_helper
INFO - 2017-01-19 17:43:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:43:35 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:43:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:43:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:43:35 --> Final output sent to browser
DEBUG - 2017-01-19 17:43:35 --> Total execution time: 0.1339
INFO - 2017-01-19 17:43:58 --> Config Class Initialized
INFO - 2017-01-19 17:43:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:43:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:43:58 --> Utf8 Class Initialized
INFO - 2017-01-19 17:43:58 --> URI Class Initialized
INFO - 2017-01-19 17:43:58 --> Router Class Initialized
INFO - 2017-01-19 17:43:58 --> Output Class Initialized
INFO - 2017-01-19 17:43:58 --> Security Class Initialized
DEBUG - 2017-01-19 17:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:43:58 --> Input Class Initialized
INFO - 2017-01-19 17:43:58 --> Language Class Initialized
INFO - 2017-01-19 17:43:58 --> Loader Class Initialized
INFO - 2017-01-19 17:43:58 --> Helper loaded: url_helper
INFO - 2017-01-19 17:43:58 --> Helper loaded: language_helper
INFO - 2017-01-19 17:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:43:58 --> Controller Class Initialized
INFO - 2017-01-19 17:43:58 --> Database Driver Class Initialized
INFO - 2017-01-19 17:43:58 --> Model Class Initialized
INFO - 2017-01-19 17:43:58 --> Model Class Initialized
INFO - 2017-01-19 17:43:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:43:58 --> Helper loaded: form_helper
INFO - 2017-01-19 17:43:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:43:58 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:43:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:43:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:43:58 --> Final output sent to browser
DEBUG - 2017-01-19 17:43:58 --> Total execution time: 0.1086
INFO - 2017-01-19 17:44:06 --> Config Class Initialized
INFO - 2017-01-19 17:44:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:06 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:06 --> URI Class Initialized
INFO - 2017-01-19 17:44:06 --> Router Class Initialized
INFO - 2017-01-19 17:44:06 --> Output Class Initialized
INFO - 2017-01-19 17:44:06 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:06 --> Input Class Initialized
INFO - 2017-01-19 17:44:06 --> Language Class Initialized
INFO - 2017-01-19 17:44:06 --> Loader Class Initialized
INFO - 2017-01-19 17:44:06 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:06 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:06 --> Controller Class Initialized
INFO - 2017-01-19 17:44:06 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:06 --> Model Class Initialized
INFO - 2017-01-19 17:44:06 --> Model Class Initialized
INFO - 2017-01-19 17:44:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:06 --> Config Class Initialized
INFO - 2017-01-19 17:44:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:06 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:06 --> URI Class Initialized
INFO - 2017-01-19 17:44:06 --> Router Class Initialized
INFO - 2017-01-19 17:44:07 --> Output Class Initialized
INFO - 2017-01-19 17:44:07 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:07 --> Input Class Initialized
INFO - 2017-01-19 17:44:07 --> Language Class Initialized
INFO - 2017-01-19 17:44:07 --> Loader Class Initialized
INFO - 2017-01-19 17:44:07 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:07 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:07 --> Controller Class Initialized
INFO - 2017-01-19 17:44:07 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:07 --> Model Class Initialized
INFO - 2017-01-19 17:44:07 --> Model Class Initialized
INFO - 2017-01-19 17:44:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:07 --> Helper loaded: form_helper
INFO - 2017-01-19 17:44:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:44:07 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:44:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:44:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:44:07 --> Final output sent to browser
DEBUG - 2017-01-19 17:44:07 --> Total execution time: 0.1551
INFO - 2017-01-19 17:44:14 --> Config Class Initialized
INFO - 2017-01-19 17:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:14 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:14 --> URI Class Initialized
INFO - 2017-01-19 17:44:14 --> Router Class Initialized
INFO - 2017-01-19 17:44:14 --> Output Class Initialized
INFO - 2017-01-19 17:44:14 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:14 --> Input Class Initialized
INFO - 2017-01-19 17:44:14 --> Language Class Initialized
INFO - 2017-01-19 17:44:14 --> Loader Class Initialized
INFO - 2017-01-19 17:44:14 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:14 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:14 --> Controller Class Initialized
INFO - 2017-01-19 17:44:14 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:14 --> Model Class Initialized
INFO - 2017-01-19 17:44:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:14 --> Helper loaded: form_helper
INFO - 2017-01-19 17:44:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 17:44:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 17:44:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:44:14 --> Final output sent to browser
DEBUG - 2017-01-19 17:44:14 --> Total execution time: 0.1086
INFO - 2017-01-19 17:44:19 --> Config Class Initialized
INFO - 2017-01-19 17:44:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:19 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:19 --> URI Class Initialized
INFO - 2017-01-19 17:44:19 --> Router Class Initialized
INFO - 2017-01-19 17:44:19 --> Output Class Initialized
INFO - 2017-01-19 17:44:19 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:19 --> Input Class Initialized
INFO - 2017-01-19 17:44:19 --> Language Class Initialized
INFO - 2017-01-19 17:44:19 --> Loader Class Initialized
INFO - 2017-01-19 17:44:19 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:19 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:19 --> Controller Class Initialized
INFO - 2017-01-19 17:44:19 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:19 --> Model Class Initialized
INFO - 2017-01-19 17:44:19 --> Model Class Initialized
INFO - 2017-01-19 17:44:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:19 --> Helper loaded: form_helper
INFO - 2017-01-19 17:44:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:44:19 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:44:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:44:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:44:19 --> Final output sent to browser
DEBUG - 2017-01-19 17:44:19 --> Total execution time: 0.1052
INFO - 2017-01-19 17:44:25 --> Config Class Initialized
INFO - 2017-01-19 17:44:25 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:25 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:25 --> URI Class Initialized
INFO - 2017-01-19 17:44:25 --> Router Class Initialized
INFO - 2017-01-19 17:44:25 --> Output Class Initialized
INFO - 2017-01-19 17:44:25 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:25 --> Input Class Initialized
INFO - 2017-01-19 17:44:25 --> Language Class Initialized
INFO - 2017-01-19 17:44:25 --> Loader Class Initialized
INFO - 2017-01-19 17:44:25 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:25 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:25 --> Controller Class Initialized
INFO - 2017-01-19 17:44:25 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:25 --> Model Class Initialized
INFO - 2017-01-19 17:44:25 --> Model Class Initialized
INFO - 2017-01-19 17:44:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:25 --> Config Class Initialized
INFO - 2017-01-19 17:44:25 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:25 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:25 --> URI Class Initialized
INFO - 2017-01-19 17:44:25 --> Router Class Initialized
INFO - 2017-01-19 17:44:25 --> Output Class Initialized
INFO - 2017-01-19 17:44:25 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:25 --> Input Class Initialized
INFO - 2017-01-19 17:44:25 --> Language Class Initialized
INFO - 2017-01-19 17:44:25 --> Loader Class Initialized
INFO - 2017-01-19 17:44:25 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:25 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:25 --> Controller Class Initialized
INFO - 2017-01-19 17:44:25 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:25 --> Model Class Initialized
INFO - 2017-01-19 17:44:25 --> Model Class Initialized
INFO - 2017-01-19 17:44:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:25 --> Helper loaded: form_helper
INFO - 2017-01-19 17:44:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-19 17:44:25 --> Could not find the language line "import_user"
INFO - 2017-01-19 17:44:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-19 17:44:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:44:25 --> Final output sent to browser
DEBUG - 2017-01-19 17:44:25 --> Total execution time: 0.1259
INFO - 2017-01-19 17:44:27 --> Config Class Initialized
INFO - 2017-01-19 17:44:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:27 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:27 --> URI Class Initialized
INFO - 2017-01-19 17:44:27 --> Router Class Initialized
INFO - 2017-01-19 17:44:27 --> Output Class Initialized
INFO - 2017-01-19 17:44:27 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:27 --> Input Class Initialized
INFO - 2017-01-19 17:44:27 --> Language Class Initialized
INFO - 2017-01-19 17:44:27 --> Loader Class Initialized
INFO - 2017-01-19 17:44:27 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:27 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:27 --> Controller Class Initialized
INFO - 2017-01-19 17:44:27 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:27 --> Model Class Initialized
INFO - 2017-01-19 17:44:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:27 --> Helper loaded: form_helper
INFO - 2017-01-19 17:44:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 17:44:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-19 17:44:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:44:27 --> Final output sent to browser
DEBUG - 2017-01-19 17:44:27 --> Total execution time: 0.1245
INFO - 2017-01-19 17:44:32 --> Config Class Initialized
INFO - 2017-01-19 17:44:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 17:44:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 17:44:32 --> Utf8 Class Initialized
INFO - 2017-01-19 17:44:32 --> URI Class Initialized
INFO - 2017-01-19 17:44:32 --> Router Class Initialized
INFO - 2017-01-19 17:44:32 --> Output Class Initialized
INFO - 2017-01-19 17:44:32 --> Security Class Initialized
DEBUG - 2017-01-19 17:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 17:44:32 --> Input Class Initialized
INFO - 2017-01-19 17:44:32 --> Language Class Initialized
INFO - 2017-01-19 17:44:32 --> Loader Class Initialized
INFO - 2017-01-19 17:44:32 --> Helper loaded: url_helper
INFO - 2017-01-19 17:44:32 --> Helper loaded: language_helper
INFO - 2017-01-19 17:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 17:44:32 --> Controller Class Initialized
INFO - 2017-01-19 17:44:32 --> Database Driver Class Initialized
INFO - 2017-01-19 17:44:32 --> Model Class Initialized
INFO - 2017-01-19 17:44:32 --> Model Class Initialized
INFO - 2017-01-19 17:44:32 --> Model Class Initialized
INFO - 2017-01-19 17:44:32 --> Model Class Initialized
INFO - 2017-01-19 17:44:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-19 17:44:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-19 17:44:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-19 17:44:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-19 17:44:32 --> Final output sent to browser
DEBUG - 2017-01-19 17:44:32 --> Total execution time: 0.1434
