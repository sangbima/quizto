<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-20 08:25:14 --> Config Class Initialized
INFO - 2017-01-20 08:25:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:25:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:25:14 --> Utf8 Class Initialized
INFO - 2017-01-20 08:25:14 --> URI Class Initialized
INFO - 2017-01-20 08:25:14 --> Router Class Initialized
INFO - 2017-01-20 08:25:14 --> Output Class Initialized
INFO - 2017-01-20 08:25:14 --> Security Class Initialized
DEBUG - 2017-01-20 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:25:14 --> Input Class Initialized
INFO - 2017-01-20 08:25:14 --> Language Class Initialized
INFO - 2017-01-20 08:25:14 --> Loader Class Initialized
INFO - 2017-01-20 08:25:14 --> Helper loaded: url_helper
INFO - 2017-01-20 08:25:14 --> Helper loaded: language_helper
INFO - 2017-01-20 08:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:25:14 --> Controller Class Initialized
INFO - 2017-01-20 08:25:14 --> Database Driver Class Initialized
INFO - 2017-01-20 08:25:14 --> Model Class Initialized
INFO - 2017-01-20 08:25:14 --> Model Class Initialized
INFO - 2017-01-20 08:25:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:25:14 --> Config Class Initialized
INFO - 2017-01-20 08:25:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:25:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:25:14 --> Utf8 Class Initialized
INFO - 2017-01-20 08:25:14 --> URI Class Initialized
INFO - 2017-01-20 08:25:14 --> Router Class Initialized
INFO - 2017-01-20 08:25:14 --> Output Class Initialized
INFO - 2017-01-20 08:25:14 --> Security Class Initialized
DEBUG - 2017-01-20 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:25:14 --> Input Class Initialized
INFO - 2017-01-20 08:25:14 --> Language Class Initialized
INFO - 2017-01-20 08:25:14 --> Loader Class Initialized
INFO - 2017-01-20 08:25:14 --> Helper loaded: url_helper
INFO - 2017-01-20 08:25:14 --> Helper loaded: language_helper
INFO - 2017-01-20 08:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:25:14 --> Controller Class Initialized
INFO - 2017-01-20 08:25:14 --> Database Driver Class Initialized
INFO - 2017-01-20 08:25:14 --> Model Class Initialized
INFO - 2017-01-20 08:25:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:25:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-20 08:25:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-20 08:25:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-20 08:25:14 --> Final output sent to browser
DEBUG - 2017-01-20 08:25:14 --> Total execution time: 0.0686
INFO - 2017-01-20 08:25:24 --> Config Class Initialized
INFO - 2017-01-20 08:25:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:25:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:25:24 --> Utf8 Class Initialized
INFO - 2017-01-20 08:25:24 --> URI Class Initialized
INFO - 2017-01-20 08:25:24 --> Router Class Initialized
INFO - 2017-01-20 08:25:24 --> Output Class Initialized
INFO - 2017-01-20 08:25:24 --> Security Class Initialized
DEBUG - 2017-01-20 08:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:25:24 --> Input Class Initialized
INFO - 2017-01-20 08:25:24 --> Language Class Initialized
INFO - 2017-01-20 08:25:24 --> Loader Class Initialized
INFO - 2017-01-20 08:25:24 --> Helper loaded: url_helper
INFO - 2017-01-20 08:25:24 --> Helper loaded: language_helper
INFO - 2017-01-20 08:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:25:24 --> Controller Class Initialized
INFO - 2017-01-20 08:25:24 --> Database Driver Class Initialized
INFO - 2017-01-20 08:25:24 --> Model Class Initialized
INFO - 2017-01-20 08:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:25:24 --> Config Class Initialized
INFO - 2017-01-20 08:25:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:25:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:25:24 --> Utf8 Class Initialized
INFO - 2017-01-20 08:25:24 --> URI Class Initialized
INFO - 2017-01-20 08:25:24 --> Router Class Initialized
INFO - 2017-01-20 08:25:24 --> Output Class Initialized
INFO - 2017-01-20 08:25:24 --> Security Class Initialized
DEBUG - 2017-01-20 08:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:25:24 --> Input Class Initialized
INFO - 2017-01-20 08:25:24 --> Language Class Initialized
INFO - 2017-01-20 08:25:24 --> Loader Class Initialized
INFO - 2017-01-20 08:25:24 --> Helper loaded: url_helper
INFO - 2017-01-20 08:25:24 --> Helper loaded: language_helper
INFO - 2017-01-20 08:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:25:24 --> Controller Class Initialized
INFO - 2017-01-20 08:25:24 --> Database Driver Class Initialized
INFO - 2017-01-20 08:25:24 --> Model Class Initialized
INFO - 2017-01-20 08:25:24 --> Model Class Initialized
INFO - 2017-01-20 08:25:24 --> Model Class Initialized
INFO - 2017-01-20 08:25:24 --> Model Class Initialized
INFO - 2017-01-20 08:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-20 08:25:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:25:24 --> Final output sent to browser
DEBUG - 2017-01-20 08:25:24 --> Total execution time: 0.0899
INFO - 2017-01-20 08:25:26 --> Config Class Initialized
INFO - 2017-01-20 08:25:26 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:25:26 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:25:26 --> Utf8 Class Initialized
INFO - 2017-01-20 08:25:26 --> URI Class Initialized
INFO - 2017-01-20 08:25:26 --> Router Class Initialized
INFO - 2017-01-20 08:25:26 --> Output Class Initialized
INFO - 2017-01-20 08:25:26 --> Security Class Initialized
DEBUG - 2017-01-20 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:25:26 --> Input Class Initialized
INFO - 2017-01-20 08:25:26 --> Language Class Initialized
INFO - 2017-01-20 08:25:26 --> Loader Class Initialized
INFO - 2017-01-20 08:25:26 --> Helper loaded: url_helper
INFO - 2017-01-20 08:25:26 --> Helper loaded: language_helper
INFO - 2017-01-20 08:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:25:26 --> Controller Class Initialized
INFO - 2017-01-20 08:25:26 --> Database Driver Class Initialized
INFO - 2017-01-20 08:25:26 --> Model Class Initialized
INFO - 2017-01-20 08:25:26 --> Model Class Initialized
INFO - 2017-01-20 08:25:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:25:26 --> Helper loaded: form_helper
INFO - 2017-01-20 08:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:25:26 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:25:26 --> Final output sent to browser
DEBUG - 2017-01-20 08:25:26 --> Total execution time: 0.0878
INFO - 2017-01-20 08:26:51 --> Config Class Initialized
INFO - 2017-01-20 08:26:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:26:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:26:51 --> Utf8 Class Initialized
INFO - 2017-01-20 08:26:51 --> URI Class Initialized
INFO - 2017-01-20 08:26:51 --> Router Class Initialized
INFO - 2017-01-20 08:26:51 --> Output Class Initialized
INFO - 2017-01-20 08:26:51 --> Security Class Initialized
DEBUG - 2017-01-20 08:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:26:51 --> Input Class Initialized
INFO - 2017-01-20 08:26:51 --> Language Class Initialized
INFO - 2017-01-20 08:26:51 --> Loader Class Initialized
INFO - 2017-01-20 08:26:51 --> Helper loaded: url_helper
INFO - 2017-01-20 08:26:51 --> Helper loaded: language_helper
INFO - 2017-01-20 08:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:26:51 --> Controller Class Initialized
INFO - 2017-01-20 08:26:51 --> Database Driver Class Initialized
INFO - 2017-01-20 08:26:51 --> Model Class Initialized
INFO - 2017-01-20 08:26:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:26:51 --> Config Class Initialized
INFO - 2017-01-20 08:26:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:26:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:26:51 --> Utf8 Class Initialized
INFO - 2017-01-20 08:26:51 --> URI Class Initialized
INFO - 2017-01-20 08:26:51 --> Router Class Initialized
INFO - 2017-01-20 08:26:51 --> Output Class Initialized
INFO - 2017-01-20 08:26:51 --> Security Class Initialized
DEBUG - 2017-01-20 08:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:26:51 --> Input Class Initialized
INFO - 2017-01-20 08:26:51 --> Language Class Initialized
INFO - 2017-01-20 08:26:51 --> Loader Class Initialized
INFO - 2017-01-20 08:26:51 --> Helper loaded: url_helper
INFO - 2017-01-20 08:26:51 --> Helper loaded: language_helper
INFO - 2017-01-20 08:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:26:51 --> Controller Class Initialized
INFO - 2017-01-20 08:26:51 --> Database Driver Class Initialized
INFO - 2017-01-20 08:26:51 --> Model Class Initialized
INFO - 2017-01-20 08:26:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:26:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-20 08:26:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-20 08:26:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-20 08:26:51 --> Final output sent to browser
DEBUG - 2017-01-20 08:26:51 --> Total execution time: 0.0813
INFO - 2017-01-20 08:26:58 --> Config Class Initialized
INFO - 2017-01-20 08:26:58 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:26:58 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:26:58 --> Utf8 Class Initialized
INFO - 2017-01-20 08:26:58 --> URI Class Initialized
INFO - 2017-01-20 08:26:58 --> Router Class Initialized
INFO - 2017-01-20 08:26:58 --> Output Class Initialized
INFO - 2017-01-20 08:26:58 --> Security Class Initialized
DEBUG - 2017-01-20 08:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:26:58 --> Input Class Initialized
INFO - 2017-01-20 08:26:58 --> Language Class Initialized
INFO - 2017-01-20 08:26:58 --> Loader Class Initialized
INFO - 2017-01-20 08:26:58 --> Helper loaded: url_helper
INFO - 2017-01-20 08:26:58 --> Helper loaded: language_helper
INFO - 2017-01-20 08:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:26:58 --> Controller Class Initialized
INFO - 2017-01-20 08:26:58 --> Database Driver Class Initialized
INFO - 2017-01-20 08:26:58 --> Model Class Initialized
INFO - 2017-01-20 08:26:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:26:58 --> Helper loaded: form_helper
INFO - 2017-01-20 08:26:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:26:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:26:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:26:58 --> Final output sent to browser
DEBUG - 2017-01-20 08:26:58 --> Total execution time: 0.0898
INFO - 2017-01-20 08:27:00 --> Config Class Initialized
INFO - 2017-01-20 08:27:00 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:27:00 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:27:00 --> Utf8 Class Initialized
INFO - 2017-01-20 08:27:00 --> URI Class Initialized
INFO - 2017-01-20 08:27:00 --> Router Class Initialized
INFO - 2017-01-20 08:27:00 --> Output Class Initialized
INFO - 2017-01-20 08:27:00 --> Security Class Initialized
DEBUG - 2017-01-20 08:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:27:00 --> Input Class Initialized
INFO - 2017-01-20 08:27:00 --> Language Class Initialized
INFO - 2017-01-20 08:27:00 --> Loader Class Initialized
INFO - 2017-01-20 08:27:00 --> Helper loaded: url_helper
INFO - 2017-01-20 08:27:00 --> Helper loaded: language_helper
INFO - 2017-01-20 08:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:27:00 --> Controller Class Initialized
INFO - 2017-01-20 08:27:00 --> Database Driver Class Initialized
INFO - 2017-01-20 08:27:00 --> Model Class Initialized
INFO - 2017-01-20 08:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:27:00 --> Helper loaded: form_helper
INFO - 2017-01-20 08:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:27:00 --> Final output sent to browser
DEBUG - 2017-01-20 08:27:00 --> Total execution time: 0.0928
INFO - 2017-01-20 08:27:01 --> Config Class Initialized
INFO - 2017-01-20 08:27:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:27:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:27:01 --> Utf8 Class Initialized
INFO - 2017-01-20 08:27:01 --> URI Class Initialized
INFO - 2017-01-20 08:27:01 --> Router Class Initialized
INFO - 2017-01-20 08:27:01 --> Output Class Initialized
INFO - 2017-01-20 08:27:01 --> Security Class Initialized
DEBUG - 2017-01-20 08:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:27:01 --> Input Class Initialized
INFO - 2017-01-20 08:27:01 --> Language Class Initialized
INFO - 2017-01-20 08:27:01 --> Loader Class Initialized
INFO - 2017-01-20 08:27:01 --> Helper loaded: url_helper
INFO - 2017-01-20 08:27:01 --> Helper loaded: language_helper
INFO - 2017-01-20 08:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:27:01 --> Controller Class Initialized
INFO - 2017-01-20 08:27:01 --> Database Driver Class Initialized
INFO - 2017-01-20 08:27:01 --> Model Class Initialized
INFO - 2017-01-20 08:27:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:27:01 --> Helper loaded: form_helper
INFO - 2017-01-20 08:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:27:01 --> Final output sent to browser
DEBUG - 2017-01-20 08:27:01 --> Total execution time: 0.0909
INFO - 2017-01-20 08:27:16 --> Config Class Initialized
INFO - 2017-01-20 08:27:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:27:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:27:16 --> Utf8 Class Initialized
INFO - 2017-01-20 08:27:16 --> URI Class Initialized
INFO - 2017-01-20 08:27:16 --> Router Class Initialized
INFO - 2017-01-20 08:27:16 --> Output Class Initialized
INFO - 2017-01-20 08:27:16 --> Security Class Initialized
DEBUG - 2017-01-20 08:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:27:16 --> Input Class Initialized
INFO - 2017-01-20 08:27:16 --> Language Class Initialized
INFO - 2017-01-20 08:27:16 --> Loader Class Initialized
INFO - 2017-01-20 08:27:16 --> Helper loaded: url_helper
INFO - 2017-01-20 08:27:16 --> Helper loaded: language_helper
INFO - 2017-01-20 08:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:27:16 --> Controller Class Initialized
INFO - 2017-01-20 08:27:16 --> Database Driver Class Initialized
INFO - 2017-01-20 08:27:16 --> Model Class Initialized
INFO - 2017-01-20 08:27:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:27:16 --> Helper loaded: form_helper
INFO - 2017-01-20 08:27:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:27:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 08:27:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:27:16 --> Final output sent to browser
DEBUG - 2017-01-20 08:27:16 --> Total execution time: 0.0808
INFO - 2017-01-20 08:27:19 --> Config Class Initialized
INFO - 2017-01-20 08:27:19 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:27:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:27:19 --> Utf8 Class Initialized
INFO - 2017-01-20 08:27:19 --> URI Class Initialized
INFO - 2017-01-20 08:27:19 --> Router Class Initialized
INFO - 2017-01-20 08:27:19 --> Output Class Initialized
INFO - 2017-01-20 08:27:19 --> Security Class Initialized
DEBUG - 2017-01-20 08:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:27:19 --> Input Class Initialized
INFO - 2017-01-20 08:27:19 --> Language Class Initialized
INFO - 2017-01-20 08:27:19 --> Loader Class Initialized
INFO - 2017-01-20 08:27:19 --> Helper loaded: url_helper
INFO - 2017-01-20 08:27:19 --> Helper loaded: language_helper
INFO - 2017-01-20 08:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:27:19 --> Controller Class Initialized
INFO - 2017-01-20 08:27:19 --> Database Driver Class Initialized
INFO - 2017-01-20 08:27:19 --> Model Class Initialized
INFO - 2017-01-20 08:27:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:27:19 --> Helper loaded: form_helper
INFO - 2017-01-20 08:27:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:27:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-20 08:27:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:27:19 --> Final output sent to browser
DEBUG - 2017-01-20 08:27:19 --> Total execution time: 0.1001
INFO - 2017-01-20 08:27:25 --> Config Class Initialized
INFO - 2017-01-20 08:27:25 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:27:25 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:27:25 --> Utf8 Class Initialized
INFO - 2017-01-20 08:27:25 --> URI Class Initialized
INFO - 2017-01-20 08:27:25 --> Router Class Initialized
INFO - 2017-01-20 08:27:25 --> Output Class Initialized
INFO - 2017-01-20 08:27:25 --> Security Class Initialized
DEBUG - 2017-01-20 08:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:27:25 --> Input Class Initialized
INFO - 2017-01-20 08:27:25 --> Language Class Initialized
INFO - 2017-01-20 08:27:25 --> Loader Class Initialized
INFO - 2017-01-20 08:27:25 --> Helper loaded: url_helper
INFO - 2017-01-20 08:27:25 --> Helper loaded: language_helper
INFO - 2017-01-20 08:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:27:25 --> Controller Class Initialized
INFO - 2017-01-20 08:27:25 --> Database Driver Class Initialized
INFO - 2017-01-20 08:27:25 --> Model Class Initialized
INFO - 2017-01-20 08:27:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:27:25 --> Helper loaded: form_helper
INFO - 2017-01-20 08:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:27:25 --> Final output sent to browser
DEBUG - 2017-01-20 08:27:25 --> Total execution time: 0.0839
INFO - 2017-01-20 08:35:49 --> Config Class Initialized
INFO - 2017-01-20 08:35:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:35:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:35:49 --> Utf8 Class Initialized
INFO - 2017-01-20 08:35:49 --> URI Class Initialized
INFO - 2017-01-20 08:35:49 --> Router Class Initialized
INFO - 2017-01-20 08:35:49 --> Output Class Initialized
INFO - 2017-01-20 08:35:49 --> Security Class Initialized
DEBUG - 2017-01-20 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:35:49 --> Input Class Initialized
INFO - 2017-01-20 08:35:49 --> Language Class Initialized
INFO - 2017-01-20 08:35:49 --> Loader Class Initialized
INFO - 2017-01-20 08:35:49 --> Helper loaded: url_helper
INFO - 2017-01-20 08:35:49 --> Helper loaded: language_helper
INFO - 2017-01-20 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:35:49 --> Controller Class Initialized
INFO - 2017-01-20 08:35:49 --> Database Driver Class Initialized
INFO - 2017-01-20 08:35:49 --> Model Class Initialized
INFO - 2017-01-20 08:35:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:35:49 --> Helper loaded: form_helper
INFO - 2017-01-20 08:35:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:35:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:35:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:35:50 --> Final output sent to browser
DEBUG - 2017-01-20 08:35:50 --> Total execution time: 0.1379
INFO - 2017-01-20 08:35:52 --> Config Class Initialized
INFO - 2017-01-20 08:35:52 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:35:52 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:35:52 --> Utf8 Class Initialized
INFO - 2017-01-20 08:35:52 --> URI Class Initialized
INFO - 2017-01-20 08:35:52 --> Router Class Initialized
INFO - 2017-01-20 08:35:52 --> Output Class Initialized
INFO - 2017-01-20 08:35:52 --> Security Class Initialized
DEBUG - 2017-01-20 08:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:35:52 --> Input Class Initialized
INFO - 2017-01-20 08:35:52 --> Language Class Initialized
INFO - 2017-01-20 08:35:52 --> Loader Class Initialized
INFO - 2017-01-20 08:35:52 --> Helper loaded: url_helper
INFO - 2017-01-20 08:35:52 --> Helper loaded: language_helper
INFO - 2017-01-20 08:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:35:52 --> Controller Class Initialized
INFO - 2017-01-20 08:35:52 --> Database Driver Class Initialized
INFO - 2017-01-20 08:35:52 --> Model Class Initialized
INFO - 2017-01-20 08:35:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:35:52 --> Helper loaded: form_helper
INFO - 2017-01-20 08:35:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:35:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:35:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:35:52 --> Final output sent to browser
DEBUG - 2017-01-20 08:35:52 --> Total execution time: 0.1348
INFO - 2017-01-20 08:35:54 --> Config Class Initialized
INFO - 2017-01-20 08:35:54 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:35:54 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:35:54 --> Utf8 Class Initialized
INFO - 2017-01-20 08:35:54 --> URI Class Initialized
INFO - 2017-01-20 08:35:54 --> Router Class Initialized
INFO - 2017-01-20 08:35:54 --> Output Class Initialized
INFO - 2017-01-20 08:35:54 --> Security Class Initialized
DEBUG - 2017-01-20 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:35:54 --> Input Class Initialized
INFO - 2017-01-20 08:35:54 --> Language Class Initialized
INFO - 2017-01-20 08:35:54 --> Loader Class Initialized
INFO - 2017-01-20 08:35:54 --> Helper loaded: url_helper
INFO - 2017-01-20 08:35:54 --> Helper loaded: language_helper
INFO - 2017-01-20 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:35:54 --> Controller Class Initialized
INFO - 2017-01-20 08:35:54 --> Database Driver Class Initialized
INFO - 2017-01-20 08:35:54 --> Model Class Initialized
INFO - 2017-01-20 08:35:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:35:54 --> Helper loaded: form_helper
INFO - 2017-01-20 08:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:35:54 --> Final output sent to browser
DEBUG - 2017-01-20 08:35:54 --> Total execution time: 0.1457
INFO - 2017-01-20 08:36:09 --> Config Class Initialized
INFO - 2017-01-20 08:36:09 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:36:09 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:36:09 --> Utf8 Class Initialized
INFO - 2017-01-20 08:36:09 --> URI Class Initialized
INFO - 2017-01-20 08:36:09 --> Router Class Initialized
INFO - 2017-01-20 08:36:09 --> Output Class Initialized
INFO - 2017-01-20 08:36:09 --> Security Class Initialized
DEBUG - 2017-01-20 08:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:36:09 --> Input Class Initialized
INFO - 2017-01-20 08:36:09 --> Language Class Initialized
INFO - 2017-01-20 08:36:09 --> Loader Class Initialized
INFO - 2017-01-20 08:36:09 --> Helper loaded: url_helper
INFO - 2017-01-20 08:36:09 --> Helper loaded: language_helper
INFO - 2017-01-20 08:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:36:09 --> Controller Class Initialized
INFO - 2017-01-20 08:36:09 --> Database Driver Class Initialized
INFO - 2017-01-20 08:36:09 --> Model Class Initialized
INFO - 2017-01-20 08:36:09 --> Model Class Initialized
INFO - 2017-01-20 08:36:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:36:09 --> Helper loaded: form_helper
INFO - 2017-01-20 08:36:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:36:09 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:36:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:36:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:36:09 --> Final output sent to browser
DEBUG - 2017-01-20 08:36:09 --> Total execution time: 0.1139
INFO - 2017-01-20 08:37:18 --> Config Class Initialized
INFO - 2017-01-20 08:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:37:18 --> Utf8 Class Initialized
INFO - 2017-01-20 08:37:18 --> URI Class Initialized
INFO - 2017-01-20 08:37:18 --> Router Class Initialized
INFO - 2017-01-20 08:37:18 --> Output Class Initialized
INFO - 2017-01-20 08:37:18 --> Security Class Initialized
DEBUG - 2017-01-20 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:37:18 --> Input Class Initialized
INFO - 2017-01-20 08:37:18 --> Language Class Initialized
INFO - 2017-01-20 08:37:18 --> Loader Class Initialized
INFO - 2017-01-20 08:37:18 --> Helper loaded: url_helper
INFO - 2017-01-20 08:37:18 --> Helper loaded: language_helper
INFO - 2017-01-20 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:37:18 --> Controller Class Initialized
INFO - 2017-01-20 08:37:18 --> Database Driver Class Initialized
INFO - 2017-01-20 08:37:18 --> Model Class Initialized
INFO - 2017-01-20 08:37:18 --> Model Class Initialized
INFO - 2017-01-20 08:37:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:37:18 --> Helper loaded: form_helper
INFO - 2017-01-20 08:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:37:18 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:37:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:37:18 --> Final output sent to browser
DEBUG - 2017-01-20 08:37:18 --> Total execution time: 0.1000
INFO - 2017-01-20 08:37:28 --> Config Class Initialized
INFO - 2017-01-20 08:37:28 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:37:28 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:37:28 --> Utf8 Class Initialized
INFO - 2017-01-20 08:37:28 --> URI Class Initialized
INFO - 2017-01-20 08:37:28 --> Router Class Initialized
INFO - 2017-01-20 08:37:28 --> Output Class Initialized
INFO - 2017-01-20 08:37:28 --> Security Class Initialized
DEBUG - 2017-01-20 08:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:37:28 --> Input Class Initialized
INFO - 2017-01-20 08:37:28 --> Language Class Initialized
INFO - 2017-01-20 08:37:28 --> Loader Class Initialized
INFO - 2017-01-20 08:37:28 --> Helper loaded: url_helper
INFO - 2017-01-20 08:37:28 --> Helper loaded: language_helper
INFO - 2017-01-20 08:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:37:28 --> Controller Class Initialized
INFO - 2017-01-20 08:37:28 --> Database Driver Class Initialized
INFO - 2017-01-20 08:37:28 --> Model Class Initialized
INFO - 2017-01-20 08:37:28 --> Model Class Initialized
INFO - 2017-01-20 08:37:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:37:28 --> Helper loaded: form_helper
INFO - 2017-01-20 08:37:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:37:28 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:37:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:37:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:37:28 --> Final output sent to browser
DEBUG - 2017-01-20 08:37:28 --> Total execution time: 0.1070
INFO - 2017-01-20 08:50:01 --> Config Class Initialized
INFO - 2017-01-20 08:50:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:50:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:50:01 --> Utf8 Class Initialized
INFO - 2017-01-20 08:50:01 --> URI Class Initialized
INFO - 2017-01-20 08:50:01 --> Router Class Initialized
INFO - 2017-01-20 08:50:01 --> Output Class Initialized
INFO - 2017-01-20 08:50:01 --> Security Class Initialized
DEBUG - 2017-01-20 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:50:01 --> Input Class Initialized
INFO - 2017-01-20 08:50:01 --> Language Class Initialized
INFO - 2017-01-20 08:50:01 --> Loader Class Initialized
INFO - 2017-01-20 08:50:01 --> Helper loaded: url_helper
INFO - 2017-01-20 08:50:01 --> Helper loaded: language_helper
INFO - 2017-01-20 08:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:50:01 --> Controller Class Initialized
INFO - 2017-01-20 08:50:01 --> Database Driver Class Initialized
INFO - 2017-01-20 08:50:02 --> Model Class Initialized
INFO - 2017-01-20 08:50:02 --> Model Class Initialized
INFO - 2017-01-20 08:50:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:50:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:50:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-20 08:50:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:50:02 --> Final output sent to browser
DEBUG - 2017-01-20 08:50:02 --> Total execution time: 0.0851
INFO - 2017-01-20 08:50:08 --> Config Class Initialized
INFO - 2017-01-20 08:50:08 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:50:08 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:50:08 --> Utf8 Class Initialized
INFO - 2017-01-20 08:50:08 --> URI Class Initialized
INFO - 2017-01-20 08:50:08 --> Router Class Initialized
INFO - 2017-01-20 08:50:08 --> Output Class Initialized
INFO - 2017-01-20 08:50:08 --> Security Class Initialized
DEBUG - 2017-01-20 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:50:08 --> Input Class Initialized
INFO - 2017-01-20 08:50:08 --> Language Class Initialized
INFO - 2017-01-20 08:50:08 --> Loader Class Initialized
INFO - 2017-01-20 08:50:08 --> Helper loaded: url_helper
INFO - 2017-01-20 08:50:08 --> Helper loaded: language_helper
INFO - 2017-01-20 08:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:50:08 --> Controller Class Initialized
INFO - 2017-01-20 08:50:08 --> Database Driver Class Initialized
INFO - 2017-01-20 08:50:08 --> Model Class Initialized
INFO - 2017-01-20 08:50:08 --> Model Class Initialized
INFO - 2017-01-20 08:50:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:50:08 --> Helper loaded: form_helper
INFO - 2017-01-20 08:50:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:50:08 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:50:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:50:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:50:08 --> Final output sent to browser
DEBUG - 2017-01-20 08:50:08 --> Total execution time: 0.0945
INFO - 2017-01-20 08:50:11 --> Config Class Initialized
INFO - 2017-01-20 08:50:11 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:50:11 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:50:11 --> Utf8 Class Initialized
INFO - 2017-01-20 08:50:11 --> URI Class Initialized
INFO - 2017-01-20 08:50:11 --> Router Class Initialized
INFO - 2017-01-20 08:50:11 --> Output Class Initialized
INFO - 2017-01-20 08:50:11 --> Security Class Initialized
DEBUG - 2017-01-20 08:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:50:11 --> Input Class Initialized
INFO - 2017-01-20 08:50:11 --> Language Class Initialized
INFO - 2017-01-20 08:50:11 --> Loader Class Initialized
INFO - 2017-01-20 08:50:11 --> Helper loaded: url_helper
INFO - 2017-01-20 08:50:11 --> Helper loaded: language_helper
INFO - 2017-01-20 08:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:50:11 --> Controller Class Initialized
INFO - 2017-01-20 08:50:11 --> Database Driver Class Initialized
INFO - 2017-01-20 08:50:11 --> Model Class Initialized
INFO - 2017-01-20 08:50:11 --> Model Class Initialized
INFO - 2017-01-20 08:50:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:50:11 --> Helper loaded: form_helper
INFO - 2017-01-20 08:50:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:50:11 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:50:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:50:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:50:11 --> Final output sent to browser
DEBUG - 2017-01-20 08:50:11 --> Total execution time: 0.1015
INFO - 2017-01-20 08:52:18 --> Config Class Initialized
INFO - 2017-01-20 08:52:18 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:52:18 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:52:18 --> Utf8 Class Initialized
INFO - 2017-01-20 08:52:18 --> URI Class Initialized
INFO - 2017-01-20 08:52:18 --> Router Class Initialized
INFO - 2017-01-20 08:52:18 --> Output Class Initialized
INFO - 2017-01-20 08:52:18 --> Security Class Initialized
DEBUG - 2017-01-20 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:52:18 --> Input Class Initialized
INFO - 2017-01-20 08:52:18 --> Language Class Initialized
INFO - 2017-01-20 08:52:18 --> Loader Class Initialized
INFO - 2017-01-20 08:52:18 --> Helper loaded: url_helper
INFO - 2017-01-20 08:52:18 --> Helper loaded: language_helper
INFO - 2017-01-20 08:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:52:18 --> Controller Class Initialized
INFO - 2017-01-20 08:52:18 --> Database Driver Class Initialized
INFO - 2017-01-20 08:52:18 --> Model Class Initialized
INFO - 2017-01-20 08:52:18 --> Model Class Initialized
INFO - 2017-01-20 08:52:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:52:18 --> Helper loaded: form_helper
INFO - 2017-01-20 08:52:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:52:18 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:52:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:52:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:52:18 --> Final output sent to browser
DEBUG - 2017-01-20 08:52:18 --> Total execution time: 0.1021
INFO - 2017-01-20 08:52:21 --> Config Class Initialized
INFO - 2017-01-20 08:52:21 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:52:21 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:52:21 --> Utf8 Class Initialized
INFO - 2017-01-20 08:52:21 --> URI Class Initialized
INFO - 2017-01-20 08:52:21 --> Router Class Initialized
INFO - 2017-01-20 08:52:21 --> Output Class Initialized
INFO - 2017-01-20 08:52:21 --> Security Class Initialized
DEBUG - 2017-01-20 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:52:21 --> Input Class Initialized
INFO - 2017-01-20 08:52:21 --> Language Class Initialized
INFO - 2017-01-20 08:52:21 --> Loader Class Initialized
INFO - 2017-01-20 08:52:21 --> Helper loaded: url_helper
INFO - 2017-01-20 08:52:21 --> Helper loaded: language_helper
INFO - 2017-01-20 08:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:52:21 --> Controller Class Initialized
INFO - 2017-01-20 08:52:21 --> Database Driver Class Initialized
INFO - 2017-01-20 08:52:21 --> Model Class Initialized
INFO - 2017-01-20 08:52:21 --> Model Class Initialized
INFO - 2017-01-20 08:52:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:52:21 --> Helper loaded: form_helper
INFO - 2017-01-20 08:52:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:52:21 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:52:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:52:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:52:21 --> Final output sent to browser
DEBUG - 2017-01-20 08:52:21 --> Total execution time: 0.1083
INFO - 2017-01-20 08:53:29 --> Config Class Initialized
INFO - 2017-01-20 08:53:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:53:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:53:29 --> Utf8 Class Initialized
INFO - 2017-01-20 08:53:30 --> URI Class Initialized
INFO - 2017-01-20 08:53:30 --> Router Class Initialized
INFO - 2017-01-20 08:53:30 --> Output Class Initialized
INFO - 2017-01-20 08:53:30 --> Security Class Initialized
DEBUG - 2017-01-20 08:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:53:30 --> Input Class Initialized
INFO - 2017-01-20 08:53:30 --> Language Class Initialized
INFO - 2017-01-20 08:53:30 --> Loader Class Initialized
INFO - 2017-01-20 08:53:30 --> Helper loaded: url_helper
INFO - 2017-01-20 08:53:30 --> Helper loaded: language_helper
INFO - 2017-01-20 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:53:30 --> Controller Class Initialized
INFO - 2017-01-20 08:53:30 --> Database Driver Class Initialized
INFO - 2017-01-20 08:53:30 --> Model Class Initialized
INFO - 2017-01-20 08:53:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:53:30 --> Helper loaded: form_helper
INFO - 2017-01-20 08:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:53:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:53:30 --> Final output sent to browser
DEBUG - 2017-01-20 08:53:30 --> Total execution time: 0.1051
INFO - 2017-01-20 08:53:32 --> Config Class Initialized
INFO - 2017-01-20 08:53:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:53:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:53:32 --> Utf8 Class Initialized
INFO - 2017-01-20 08:53:32 --> URI Class Initialized
INFO - 2017-01-20 08:53:32 --> Router Class Initialized
INFO - 2017-01-20 08:53:32 --> Output Class Initialized
INFO - 2017-01-20 08:53:32 --> Security Class Initialized
DEBUG - 2017-01-20 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:53:32 --> Input Class Initialized
INFO - 2017-01-20 08:53:32 --> Language Class Initialized
INFO - 2017-01-20 08:53:32 --> Loader Class Initialized
INFO - 2017-01-20 08:53:32 --> Helper loaded: url_helper
INFO - 2017-01-20 08:53:32 --> Helper loaded: language_helper
INFO - 2017-01-20 08:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:53:32 --> Controller Class Initialized
INFO - 2017-01-20 08:53:32 --> Database Driver Class Initialized
INFO - 2017-01-20 08:53:32 --> Model Class Initialized
INFO - 2017-01-20 08:53:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:53:32 --> Helper loaded: form_helper
INFO - 2017-01-20 08:53:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:53:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:53:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:53:32 --> Final output sent to browser
DEBUG - 2017-01-20 08:53:32 --> Total execution time: 0.1226
INFO - 2017-01-20 08:53:35 --> Config Class Initialized
INFO - 2017-01-20 08:53:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:53:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:53:35 --> Utf8 Class Initialized
INFO - 2017-01-20 08:53:35 --> URI Class Initialized
INFO - 2017-01-20 08:53:35 --> Router Class Initialized
INFO - 2017-01-20 08:53:35 --> Output Class Initialized
INFO - 2017-01-20 08:53:35 --> Security Class Initialized
DEBUG - 2017-01-20 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:53:35 --> Input Class Initialized
INFO - 2017-01-20 08:53:35 --> Language Class Initialized
INFO - 2017-01-20 08:53:35 --> Loader Class Initialized
INFO - 2017-01-20 08:53:35 --> Helper loaded: url_helper
INFO - 2017-01-20 08:53:35 --> Helper loaded: language_helper
INFO - 2017-01-20 08:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:53:35 --> Controller Class Initialized
INFO - 2017-01-20 08:53:35 --> Database Driver Class Initialized
INFO - 2017-01-20 08:53:35 --> Model Class Initialized
INFO - 2017-01-20 08:53:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:53:35 --> Helper loaded: form_helper
INFO - 2017-01-20 08:53:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:53:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:53:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:53:35 --> Final output sent to browser
DEBUG - 2017-01-20 08:53:35 --> Total execution time: 0.1009
INFO - 2017-01-20 08:53:49 --> Config Class Initialized
INFO - 2017-01-20 08:53:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:53:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:53:49 --> Utf8 Class Initialized
INFO - 2017-01-20 08:53:49 --> URI Class Initialized
INFO - 2017-01-20 08:53:49 --> Router Class Initialized
INFO - 2017-01-20 08:53:49 --> Output Class Initialized
INFO - 2017-01-20 08:53:49 --> Security Class Initialized
DEBUG - 2017-01-20 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:53:49 --> Input Class Initialized
INFO - 2017-01-20 08:53:49 --> Language Class Initialized
INFO - 2017-01-20 08:53:49 --> Loader Class Initialized
INFO - 2017-01-20 08:53:49 --> Helper loaded: url_helper
INFO - 2017-01-20 08:53:49 --> Helper loaded: language_helper
INFO - 2017-01-20 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:53:49 --> Controller Class Initialized
INFO - 2017-01-20 08:53:49 --> Database Driver Class Initialized
INFO - 2017-01-20 08:53:50 --> Model Class Initialized
INFO - 2017-01-20 08:53:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:53:50 --> Helper loaded: form_helper
INFO - 2017-01-20 08:53:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:53:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:53:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:53:50 --> Final output sent to browser
DEBUG - 2017-01-20 08:53:50 --> Total execution time: 0.1057
INFO - 2017-01-20 08:53:57 --> Config Class Initialized
INFO - 2017-01-20 08:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:53:57 --> Utf8 Class Initialized
INFO - 2017-01-20 08:53:57 --> URI Class Initialized
INFO - 2017-01-20 08:53:57 --> Router Class Initialized
INFO - 2017-01-20 08:53:57 --> Output Class Initialized
INFO - 2017-01-20 08:53:57 --> Security Class Initialized
DEBUG - 2017-01-20 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:53:57 --> Input Class Initialized
INFO - 2017-01-20 08:53:57 --> Language Class Initialized
INFO - 2017-01-20 08:53:57 --> Loader Class Initialized
INFO - 2017-01-20 08:53:57 --> Helper loaded: url_helper
INFO - 2017-01-20 08:53:57 --> Helper loaded: language_helper
INFO - 2017-01-20 08:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:53:57 --> Controller Class Initialized
INFO - 2017-01-20 08:53:57 --> Database Driver Class Initialized
INFO - 2017-01-20 08:53:57 --> Model Class Initialized
INFO - 2017-01-20 08:53:57 --> Model Class Initialized
INFO - 2017-01-20 08:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:53:57 --> Config Class Initialized
INFO - 2017-01-20 08:53:57 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:53:57 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:53:57 --> Utf8 Class Initialized
INFO - 2017-01-20 08:53:57 --> URI Class Initialized
INFO - 2017-01-20 08:53:57 --> Router Class Initialized
INFO - 2017-01-20 08:53:57 --> Output Class Initialized
INFO - 2017-01-20 08:53:57 --> Security Class Initialized
DEBUG - 2017-01-20 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:53:57 --> Input Class Initialized
INFO - 2017-01-20 08:53:57 --> Language Class Initialized
INFO - 2017-01-20 08:53:57 --> Loader Class Initialized
INFO - 2017-01-20 08:53:57 --> Helper loaded: url_helper
INFO - 2017-01-20 08:53:57 --> Helper loaded: language_helper
INFO - 2017-01-20 08:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:53:57 --> Controller Class Initialized
INFO - 2017-01-20 08:53:57 --> Database Driver Class Initialized
INFO - 2017-01-20 08:53:57 --> Model Class Initialized
INFO - 2017-01-20 08:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:53:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-20 08:53:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-20 08:53:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-20 08:53:57 --> Final output sent to browser
DEBUG - 2017-01-20 08:53:57 --> Total execution time: 0.0633
INFO - 2017-01-20 08:54:02 --> Config Class Initialized
INFO - 2017-01-20 08:54:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:54:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:54:02 --> Utf8 Class Initialized
INFO - 2017-01-20 08:54:02 --> URI Class Initialized
INFO - 2017-01-20 08:54:02 --> Router Class Initialized
INFO - 2017-01-20 08:54:02 --> Output Class Initialized
INFO - 2017-01-20 08:54:02 --> Security Class Initialized
DEBUG - 2017-01-20 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:54:02 --> Input Class Initialized
INFO - 2017-01-20 08:54:02 --> Language Class Initialized
INFO - 2017-01-20 08:54:02 --> Loader Class Initialized
INFO - 2017-01-20 08:54:02 --> Helper loaded: url_helper
INFO - 2017-01-20 08:54:02 --> Helper loaded: language_helper
INFO - 2017-01-20 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:54:02 --> Controller Class Initialized
INFO - 2017-01-20 08:54:02 --> Database Driver Class Initialized
INFO - 2017-01-20 08:54:02 --> Model Class Initialized
INFO - 2017-01-20 08:54:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:54:02 --> Config Class Initialized
INFO - 2017-01-20 08:54:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:54:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:54:02 --> Utf8 Class Initialized
INFO - 2017-01-20 08:54:02 --> URI Class Initialized
INFO - 2017-01-20 08:54:02 --> Router Class Initialized
INFO - 2017-01-20 08:54:02 --> Output Class Initialized
INFO - 2017-01-20 08:54:02 --> Security Class Initialized
DEBUG - 2017-01-20 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:54:02 --> Input Class Initialized
INFO - 2017-01-20 08:54:02 --> Language Class Initialized
INFO - 2017-01-20 08:54:02 --> Loader Class Initialized
INFO - 2017-01-20 08:54:02 --> Helper loaded: url_helper
INFO - 2017-01-20 08:54:02 --> Helper loaded: language_helper
INFO - 2017-01-20 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:54:02 --> Controller Class Initialized
INFO - 2017-01-20 08:54:02 --> Database Driver Class Initialized
INFO - 2017-01-20 08:54:02 --> Model Class Initialized
INFO - 2017-01-20 08:54:02 --> Model Class Initialized
INFO - 2017-01-20 08:54:02 --> Model Class Initialized
INFO - 2017-01-20 08:54:02 --> Model Class Initialized
INFO - 2017-01-20 08:54:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:54:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:54:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-20 08:54:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:54:02 --> Final output sent to browser
DEBUG - 2017-01-20 08:54:02 --> Total execution time: 0.0881
INFO - 2017-01-20 08:54:11 --> Config Class Initialized
INFO - 2017-01-20 08:54:11 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:54:11 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:54:11 --> Utf8 Class Initialized
INFO - 2017-01-20 08:54:11 --> URI Class Initialized
INFO - 2017-01-20 08:54:11 --> Router Class Initialized
INFO - 2017-01-20 08:54:11 --> Output Class Initialized
INFO - 2017-01-20 08:54:11 --> Security Class Initialized
DEBUG - 2017-01-20 08:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:54:11 --> Input Class Initialized
INFO - 2017-01-20 08:54:11 --> Language Class Initialized
INFO - 2017-01-20 08:54:11 --> Loader Class Initialized
INFO - 2017-01-20 08:54:11 --> Helper loaded: url_helper
INFO - 2017-01-20 08:54:11 --> Helper loaded: language_helper
INFO - 2017-01-20 08:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:54:11 --> Controller Class Initialized
INFO - 2017-01-20 08:54:11 --> Database Driver Class Initialized
INFO - 2017-01-20 08:54:11 --> Model Class Initialized
INFO - 2017-01-20 08:54:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:54:11 --> Helper loaded: form_helper
INFO - 2017-01-20 08:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:54:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:54:11 --> Final output sent to browser
DEBUG - 2017-01-20 08:54:11 --> Total execution time: 0.1033
INFO - 2017-01-20 08:54:14 --> Config Class Initialized
INFO - 2017-01-20 08:54:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:54:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:54:14 --> Utf8 Class Initialized
INFO - 2017-01-20 08:54:14 --> URI Class Initialized
INFO - 2017-01-20 08:54:14 --> Router Class Initialized
INFO - 2017-01-20 08:54:14 --> Output Class Initialized
INFO - 2017-01-20 08:54:14 --> Security Class Initialized
DEBUG - 2017-01-20 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:54:14 --> Input Class Initialized
INFO - 2017-01-20 08:54:14 --> Language Class Initialized
INFO - 2017-01-20 08:54:14 --> Loader Class Initialized
INFO - 2017-01-20 08:54:14 --> Helper loaded: url_helper
INFO - 2017-01-20 08:54:14 --> Helper loaded: language_helper
INFO - 2017-01-20 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:54:14 --> Controller Class Initialized
INFO - 2017-01-20 08:54:14 --> Database Driver Class Initialized
INFO - 2017-01-20 08:54:14 --> Model Class Initialized
INFO - 2017-01-20 08:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:54:14 --> Helper loaded: form_helper
INFO - 2017-01-20 08:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:54:14 --> Final output sent to browser
DEBUG - 2017-01-20 08:54:14 --> Total execution time: 0.1076
INFO - 2017-01-20 08:54:16 --> Config Class Initialized
INFO - 2017-01-20 08:54:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:54:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:54:16 --> Utf8 Class Initialized
INFO - 2017-01-20 08:54:16 --> URI Class Initialized
INFO - 2017-01-20 08:54:16 --> Router Class Initialized
INFO - 2017-01-20 08:54:16 --> Output Class Initialized
INFO - 2017-01-20 08:54:16 --> Security Class Initialized
DEBUG - 2017-01-20 08:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:54:16 --> Input Class Initialized
INFO - 2017-01-20 08:54:16 --> Language Class Initialized
INFO - 2017-01-20 08:54:16 --> Loader Class Initialized
INFO - 2017-01-20 08:54:16 --> Helper loaded: url_helper
INFO - 2017-01-20 08:54:16 --> Helper loaded: language_helper
INFO - 2017-01-20 08:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:54:16 --> Controller Class Initialized
INFO - 2017-01-20 08:54:16 --> Database Driver Class Initialized
INFO - 2017-01-20 08:54:16 --> Model Class Initialized
INFO - 2017-01-20 08:54:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:54:16 --> Helper loaded: form_helper
INFO - 2017-01-20 08:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:54:16 --> Final output sent to browser
DEBUG - 2017-01-20 08:54:16 --> Total execution time: 0.1212
INFO - 2017-01-20 08:55:36 --> Config Class Initialized
INFO - 2017-01-20 08:55:36 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:36 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:36 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:36 --> URI Class Initialized
INFO - 2017-01-20 08:55:36 --> Router Class Initialized
INFO - 2017-01-20 08:55:36 --> Output Class Initialized
INFO - 2017-01-20 08:55:36 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:36 --> Input Class Initialized
INFO - 2017-01-20 08:55:36 --> Language Class Initialized
INFO - 2017-01-20 08:55:36 --> Loader Class Initialized
INFO - 2017-01-20 08:55:36 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:36 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:36 --> Controller Class Initialized
INFO - 2017-01-20 08:55:36 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:36 --> Model Class Initialized
INFO - 2017-01-20 08:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:36 --> Config Class Initialized
INFO - 2017-01-20 08:55:36 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:36 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:36 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:36 --> URI Class Initialized
INFO - 2017-01-20 08:55:36 --> Router Class Initialized
INFO - 2017-01-20 08:55:36 --> Output Class Initialized
INFO - 2017-01-20 08:55:36 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:36 --> Input Class Initialized
INFO - 2017-01-20 08:55:36 --> Language Class Initialized
INFO - 2017-01-20 08:55:36 --> Loader Class Initialized
INFO - 2017-01-20 08:55:36 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:36 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:36 --> Controller Class Initialized
INFO - 2017-01-20 08:55:36 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:36 --> Model Class Initialized
INFO - 2017-01-20 08:55:36 --> Model Class Initialized
INFO - 2017-01-20 08:55:36 --> Model Class Initialized
INFO - 2017-01-20 08:55:36 --> Model Class Initialized
INFO - 2017-01-20 08:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-20 08:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:55:36 --> Final output sent to browser
DEBUG - 2017-01-20 08:55:36 --> Total execution time: 0.1002
INFO - 2017-01-20 08:55:39 --> Config Class Initialized
INFO - 2017-01-20 08:55:40 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:40 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:40 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:40 --> URI Class Initialized
INFO - 2017-01-20 08:55:40 --> Router Class Initialized
INFO - 2017-01-20 08:55:40 --> Output Class Initialized
INFO - 2017-01-20 08:55:40 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:40 --> Input Class Initialized
INFO - 2017-01-20 08:55:40 --> Language Class Initialized
INFO - 2017-01-20 08:55:40 --> Loader Class Initialized
INFO - 2017-01-20 08:55:40 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:40 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:40 --> Controller Class Initialized
INFO - 2017-01-20 08:55:40 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:40 --> Model Class Initialized
INFO - 2017-01-20 08:55:40 --> Model Class Initialized
INFO - 2017-01-20 08:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:40 --> Helper loaded: form_helper
INFO - 2017-01-20 08:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:55:40 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:55:40 --> Final output sent to browser
DEBUG - 2017-01-20 08:55:40 --> Total execution time: 0.0876
INFO - 2017-01-20 08:55:42 --> Config Class Initialized
INFO - 2017-01-20 08:55:42 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:42 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:42 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:42 --> URI Class Initialized
INFO - 2017-01-20 08:55:42 --> Router Class Initialized
INFO - 2017-01-20 08:55:42 --> Output Class Initialized
INFO - 2017-01-20 08:55:42 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:42 --> Input Class Initialized
INFO - 2017-01-20 08:55:42 --> Language Class Initialized
INFO - 2017-01-20 08:55:42 --> Loader Class Initialized
INFO - 2017-01-20 08:55:42 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:42 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:42 --> Controller Class Initialized
INFO - 2017-01-20 08:55:42 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:42 --> Model Class Initialized
INFO - 2017-01-20 08:55:42 --> Model Class Initialized
INFO - 2017-01-20 08:55:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:42 --> Helper loaded: form_helper
INFO - 2017-01-20 08:55:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 08:55:42 --> Could not find the language line "import_user"
INFO - 2017-01-20 08:55:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 08:55:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:55:42 --> Final output sent to browser
DEBUG - 2017-01-20 08:55:42 --> Total execution time: 0.0909
INFO - 2017-01-20 08:55:47 --> Config Class Initialized
INFO - 2017-01-20 08:55:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:47 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:47 --> URI Class Initialized
INFO - 2017-01-20 08:55:47 --> Router Class Initialized
INFO - 2017-01-20 08:55:47 --> Output Class Initialized
INFO - 2017-01-20 08:55:47 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:47 --> Input Class Initialized
INFO - 2017-01-20 08:55:47 --> Language Class Initialized
INFO - 2017-01-20 08:55:47 --> Loader Class Initialized
INFO - 2017-01-20 08:55:47 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:47 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:47 --> Controller Class Initialized
INFO - 2017-01-20 08:55:47 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:47 --> Model Class Initialized
INFO - 2017-01-20 08:55:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:47 --> Helper loaded: form_helper
INFO - 2017-01-20 08:55:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:55:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:55:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:55:47 --> Final output sent to browser
DEBUG - 2017-01-20 08:55:47 --> Total execution time: 0.1031
INFO - 2017-01-20 08:55:49 --> Config Class Initialized
INFO - 2017-01-20 08:55:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:49 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:49 --> URI Class Initialized
INFO - 2017-01-20 08:55:49 --> Router Class Initialized
INFO - 2017-01-20 08:55:49 --> Output Class Initialized
INFO - 2017-01-20 08:55:49 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:49 --> Input Class Initialized
INFO - 2017-01-20 08:55:49 --> Language Class Initialized
INFO - 2017-01-20 08:55:49 --> Loader Class Initialized
INFO - 2017-01-20 08:55:49 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:49 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:49 --> Controller Class Initialized
INFO - 2017-01-20 08:55:49 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:49 --> Model Class Initialized
INFO - 2017-01-20 08:55:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:49 --> Helper loaded: form_helper
INFO - 2017-01-20 08:55:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:55:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:55:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:55:49 --> Final output sent to browser
DEBUG - 2017-01-20 08:55:49 --> Total execution time: 0.0912
INFO - 2017-01-20 08:55:52 --> Config Class Initialized
INFO - 2017-01-20 08:55:52 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:55:52 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:55:52 --> Utf8 Class Initialized
INFO - 2017-01-20 08:55:52 --> URI Class Initialized
INFO - 2017-01-20 08:55:52 --> Router Class Initialized
INFO - 2017-01-20 08:55:52 --> Output Class Initialized
INFO - 2017-01-20 08:55:52 --> Security Class Initialized
DEBUG - 2017-01-20 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:55:52 --> Input Class Initialized
INFO - 2017-01-20 08:55:52 --> Language Class Initialized
INFO - 2017-01-20 08:55:52 --> Loader Class Initialized
INFO - 2017-01-20 08:55:52 --> Helper loaded: url_helper
INFO - 2017-01-20 08:55:52 --> Helper loaded: language_helper
INFO - 2017-01-20 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:55:52 --> Controller Class Initialized
INFO - 2017-01-20 08:55:52 --> Database Driver Class Initialized
INFO - 2017-01-20 08:55:52 --> Model Class Initialized
INFO - 2017-01-20 08:55:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:55:52 --> Helper loaded: form_helper
INFO - 2017-01-20 08:55:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:55:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:55:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:55:52 --> Final output sent to browser
DEBUG - 2017-01-20 08:55:52 --> Total execution time: 0.0987
INFO - 2017-01-20 08:57:20 --> Config Class Initialized
INFO - 2017-01-20 08:57:20 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:57:20 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:57:20 --> Utf8 Class Initialized
INFO - 2017-01-20 08:57:20 --> URI Class Initialized
INFO - 2017-01-20 08:57:20 --> Router Class Initialized
INFO - 2017-01-20 08:57:20 --> Output Class Initialized
INFO - 2017-01-20 08:57:20 --> Security Class Initialized
DEBUG - 2017-01-20 08:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:57:20 --> Input Class Initialized
INFO - 2017-01-20 08:57:20 --> Language Class Initialized
INFO - 2017-01-20 08:57:20 --> Loader Class Initialized
INFO - 2017-01-20 08:57:20 --> Helper loaded: url_helper
INFO - 2017-01-20 08:57:20 --> Helper loaded: language_helper
INFO - 2017-01-20 08:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:57:20 --> Controller Class Initialized
INFO - 2017-01-20 08:57:20 --> Database Driver Class Initialized
INFO - 2017-01-20 08:57:20 --> Model Class Initialized
INFO - 2017-01-20 08:57:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:57:20 --> Helper loaded: form_helper
ERROR - 2017-01-20 08:57:20 --> Severity: Notice --> Undefined variable: script C:\wamp64\www\savsoftquiz\application\models\Hasil_model.php 55
ERROR - 2017-01-20 08:57:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum' at line 1 - Invalid query: round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum(case when c.cid=12 then a.score_u else null end), 0) as ist2,round(sum(case when c.cid=13 then a.score_u else null end), 0) as ist3,round(sum(case when c.cid=14 then a.score_u else null end), 0) as ist4,round(sum(case when c.cid=15 then a.score_u else null end), 0) as ist5,round(sum(case when c.cid=16 then a.score_u else null end), 0) as ist6,round(sum(case when c.cid=17 then a.score_u else null end), 0) as ist7,round(sum(case when c.cid=19 then a.score_u else null end), 0) as ist8,round(sum(case when c.cid=20 then a.score_u else null end), 0) as ist9,round(sum(case when c.cid=22 then a.score_u else null end), 0) as ist10,
                round(sum(a.score_u), 0) as total
                from answers a
                left join qbank b on b.qid = a.qid
                left join category c on c.cid = b.cid
                left join users d on d.uid = a.uid
                where su != 1
                group by d.uid
                order by total desc limit 30 offset 0
INFO - 2017-01-20 08:57:20 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-20 08:58:23 --> Config Class Initialized
INFO - 2017-01-20 08:58:23 --> Hooks Class Initialized
DEBUG - 2017-01-20 08:58:23 --> UTF-8 Support Enabled
INFO - 2017-01-20 08:58:23 --> Utf8 Class Initialized
INFO - 2017-01-20 08:58:23 --> URI Class Initialized
INFO - 2017-01-20 08:58:23 --> Router Class Initialized
INFO - 2017-01-20 08:58:23 --> Output Class Initialized
INFO - 2017-01-20 08:58:23 --> Security Class Initialized
DEBUG - 2017-01-20 08:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 08:58:23 --> Input Class Initialized
INFO - 2017-01-20 08:58:23 --> Language Class Initialized
INFO - 2017-01-20 08:58:24 --> Loader Class Initialized
INFO - 2017-01-20 08:58:24 --> Helper loaded: url_helper
INFO - 2017-01-20 08:58:24 --> Helper loaded: language_helper
INFO - 2017-01-20 08:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 08:58:24 --> Controller Class Initialized
INFO - 2017-01-20 08:58:24 --> Database Driver Class Initialized
INFO - 2017-01-20 08:58:24 --> Model Class Initialized
INFO - 2017-01-20 08:58:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 08:58:24 --> Helper loaded: form_helper
INFO - 2017-01-20 08:58:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 08:58:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 08:58:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 08:58:24 --> Final output sent to browser
DEBUG - 2017-01-20 08:58:24 --> Total execution time: 0.0950
INFO - 2017-01-20 09:00:38 --> Config Class Initialized
INFO - 2017-01-20 09:00:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:00:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:00:38 --> Utf8 Class Initialized
INFO - 2017-01-20 09:00:38 --> URI Class Initialized
INFO - 2017-01-20 09:00:38 --> Router Class Initialized
INFO - 2017-01-20 09:00:38 --> Output Class Initialized
INFO - 2017-01-20 09:00:38 --> Security Class Initialized
DEBUG - 2017-01-20 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:00:38 --> Input Class Initialized
INFO - 2017-01-20 09:00:38 --> Language Class Initialized
INFO - 2017-01-20 09:00:38 --> Loader Class Initialized
INFO - 2017-01-20 09:00:38 --> Helper loaded: url_helper
INFO - 2017-01-20 09:00:38 --> Helper loaded: language_helper
INFO - 2017-01-20 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:00:38 --> Controller Class Initialized
INFO - 2017-01-20 09:00:38 --> Database Driver Class Initialized
INFO - 2017-01-20 09:00:38 --> Model Class Initialized
INFO - 2017-01-20 09:00:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:00:38 --> Helper loaded: form_helper
ERROR - 2017-01-20 09:00:38 --> Severity: Notice --> Undefined variable: full_range C:\wamp64\www\savsoftquiz\application\models\Hasil_model.php 6
INFO - 2017-01-20 09:00:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:00:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:00:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:00:39 --> Final output sent to browser
DEBUG - 2017-01-20 09:00:39 --> Total execution time: 0.1029
INFO - 2017-01-20 09:00:59 --> Config Class Initialized
INFO - 2017-01-20 09:00:59 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:00:59 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:00:59 --> Utf8 Class Initialized
INFO - 2017-01-20 09:00:59 --> URI Class Initialized
INFO - 2017-01-20 09:00:59 --> Router Class Initialized
INFO - 2017-01-20 09:00:59 --> Output Class Initialized
INFO - 2017-01-20 09:00:59 --> Security Class Initialized
DEBUG - 2017-01-20 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:00:59 --> Input Class Initialized
INFO - 2017-01-20 09:00:59 --> Language Class Initialized
INFO - 2017-01-20 09:00:59 --> Loader Class Initialized
INFO - 2017-01-20 09:00:59 --> Helper loaded: url_helper
INFO - 2017-01-20 09:00:59 --> Helper loaded: language_helper
INFO - 2017-01-20 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:00:59 --> Controller Class Initialized
INFO - 2017-01-20 09:00:59 --> Database Driver Class Initialized
INFO - 2017-01-20 09:00:59 --> Model Class Initialized
INFO - 2017-01-20 09:00:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:00:59 --> Helper loaded: form_helper
INFO - 2017-01-20 09:00:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:00:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:00:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:00:59 --> Final output sent to browser
DEBUG - 2017-01-20 09:00:59 --> Total execution time: 0.0963
INFO - 2017-01-20 09:01:02 --> Config Class Initialized
INFO - 2017-01-20 09:01:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:01:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:01:02 --> Utf8 Class Initialized
INFO - 2017-01-20 09:01:02 --> URI Class Initialized
INFO - 2017-01-20 09:01:02 --> Router Class Initialized
INFO - 2017-01-20 09:01:02 --> Output Class Initialized
INFO - 2017-01-20 09:01:02 --> Security Class Initialized
DEBUG - 2017-01-20 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:01:02 --> Input Class Initialized
INFO - 2017-01-20 09:01:02 --> Language Class Initialized
INFO - 2017-01-20 09:01:02 --> Loader Class Initialized
INFO - 2017-01-20 09:01:02 --> Helper loaded: url_helper
INFO - 2017-01-20 09:01:02 --> Helper loaded: language_helper
INFO - 2017-01-20 09:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:01:02 --> Controller Class Initialized
INFO - 2017-01-20 09:01:02 --> Database Driver Class Initialized
INFO - 2017-01-20 09:01:02 --> Model Class Initialized
INFO - 2017-01-20 09:01:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:01:02 --> Helper loaded: form_helper
INFO - 2017-01-20 09:01:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:01:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:01:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:01:02 --> Final output sent to browser
DEBUG - 2017-01-20 09:01:02 --> Total execution time: 0.1016
INFO - 2017-01-20 09:01:06 --> Config Class Initialized
INFO - 2017-01-20 09:01:06 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:01:06 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:01:06 --> Utf8 Class Initialized
INFO - 2017-01-20 09:01:06 --> URI Class Initialized
INFO - 2017-01-20 09:01:06 --> Router Class Initialized
INFO - 2017-01-20 09:01:06 --> Output Class Initialized
INFO - 2017-01-20 09:01:06 --> Security Class Initialized
DEBUG - 2017-01-20 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:01:06 --> Input Class Initialized
INFO - 2017-01-20 09:01:06 --> Language Class Initialized
INFO - 2017-01-20 09:01:06 --> Loader Class Initialized
INFO - 2017-01-20 09:01:06 --> Helper loaded: url_helper
INFO - 2017-01-20 09:01:06 --> Helper loaded: language_helper
INFO - 2017-01-20 09:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:01:06 --> Controller Class Initialized
INFO - 2017-01-20 09:01:06 --> Database Driver Class Initialized
INFO - 2017-01-20 09:01:06 --> Model Class Initialized
INFO - 2017-01-20 09:01:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:01:06 --> Helper loaded: form_helper
INFO - 2017-01-20 09:01:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:01:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:01:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:01:06 --> Final output sent to browser
DEBUG - 2017-01-20 09:01:06 --> Total execution time: 0.0928
INFO - 2017-01-20 09:01:49 --> Config Class Initialized
INFO - 2017-01-20 09:01:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:01:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:01:49 --> Utf8 Class Initialized
INFO - 2017-01-20 09:01:49 --> URI Class Initialized
INFO - 2017-01-20 09:01:49 --> Router Class Initialized
INFO - 2017-01-20 09:01:49 --> Output Class Initialized
INFO - 2017-01-20 09:01:49 --> Security Class Initialized
DEBUG - 2017-01-20 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:01:49 --> Input Class Initialized
INFO - 2017-01-20 09:01:49 --> Language Class Initialized
INFO - 2017-01-20 09:01:49 --> Loader Class Initialized
INFO - 2017-01-20 09:01:49 --> Helper loaded: url_helper
INFO - 2017-01-20 09:01:49 --> Helper loaded: language_helper
INFO - 2017-01-20 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:01:49 --> Controller Class Initialized
INFO - 2017-01-20 09:01:49 --> Database Driver Class Initialized
INFO - 2017-01-20 09:01:49 --> Model Class Initialized
INFO - 2017-01-20 09:01:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:01:49 --> Helper loaded: form_helper
INFO - 2017-01-20 09:01:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:01:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:01:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:01:49 --> Final output sent to browser
DEBUG - 2017-01-20 09:01:49 --> Total execution time: 0.0956
INFO - 2017-01-20 09:01:53 --> Config Class Initialized
INFO - 2017-01-20 09:01:53 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:01:53 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:01:53 --> Utf8 Class Initialized
INFO - 2017-01-20 09:01:53 --> URI Class Initialized
INFO - 2017-01-20 09:01:53 --> Router Class Initialized
INFO - 2017-01-20 09:01:53 --> Output Class Initialized
INFO - 2017-01-20 09:01:53 --> Security Class Initialized
DEBUG - 2017-01-20 09:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:01:53 --> Input Class Initialized
INFO - 2017-01-20 09:01:53 --> Language Class Initialized
INFO - 2017-01-20 09:01:53 --> Loader Class Initialized
INFO - 2017-01-20 09:01:53 --> Helper loaded: url_helper
INFO - 2017-01-20 09:01:53 --> Helper loaded: language_helper
INFO - 2017-01-20 09:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:01:53 --> Controller Class Initialized
INFO - 2017-01-20 09:01:53 --> Database Driver Class Initialized
INFO - 2017-01-20 09:01:53 --> Model Class Initialized
INFO - 2017-01-20 09:01:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:01:53 --> Helper loaded: form_helper
INFO - 2017-01-20 09:01:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:01:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:01:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:01:53 --> Final output sent to browser
DEBUG - 2017-01-20 09:01:53 --> Total execution time: 0.1022
INFO - 2017-01-20 09:01:54 --> Config Class Initialized
INFO - 2017-01-20 09:01:54 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:01:54 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:01:54 --> Utf8 Class Initialized
INFO - 2017-01-20 09:01:54 --> URI Class Initialized
INFO - 2017-01-20 09:01:54 --> Router Class Initialized
INFO - 2017-01-20 09:01:54 --> Output Class Initialized
INFO - 2017-01-20 09:01:54 --> Security Class Initialized
DEBUG - 2017-01-20 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:01:54 --> Input Class Initialized
INFO - 2017-01-20 09:01:54 --> Language Class Initialized
INFO - 2017-01-20 09:01:54 --> Loader Class Initialized
INFO - 2017-01-20 09:01:54 --> Helper loaded: url_helper
INFO - 2017-01-20 09:01:54 --> Helper loaded: language_helper
INFO - 2017-01-20 09:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:01:54 --> Controller Class Initialized
INFO - 2017-01-20 09:01:54 --> Database Driver Class Initialized
INFO - 2017-01-20 09:01:54 --> Model Class Initialized
INFO - 2017-01-20 09:01:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:01:54 --> Helper loaded: form_helper
INFO - 2017-01-20 09:01:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:01:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:01:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:01:54 --> Final output sent to browser
DEBUG - 2017-01-20 09:01:54 --> Total execution time: 0.1212
INFO - 2017-01-20 09:02:30 --> Config Class Initialized
INFO - 2017-01-20 09:02:30 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:02:30 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:02:30 --> Utf8 Class Initialized
INFO - 2017-01-20 09:02:30 --> URI Class Initialized
INFO - 2017-01-20 09:02:30 --> Router Class Initialized
INFO - 2017-01-20 09:02:30 --> Output Class Initialized
INFO - 2017-01-20 09:02:30 --> Security Class Initialized
DEBUG - 2017-01-20 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:02:30 --> Input Class Initialized
INFO - 2017-01-20 09:02:30 --> Language Class Initialized
INFO - 2017-01-20 09:02:30 --> Loader Class Initialized
INFO - 2017-01-20 09:02:30 --> Helper loaded: url_helper
INFO - 2017-01-20 09:02:30 --> Helper loaded: language_helper
INFO - 2017-01-20 09:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:02:30 --> Controller Class Initialized
INFO - 2017-01-20 09:02:30 --> Database Driver Class Initialized
INFO - 2017-01-20 09:02:30 --> Model Class Initialized
INFO - 2017-01-20 09:02:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:02:30 --> Helper loaded: form_helper
INFO - 2017-01-20 09:02:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:02:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:02:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:02:30 --> Final output sent to browser
DEBUG - 2017-01-20 09:02:30 --> Total execution time: 0.1027
INFO - 2017-01-20 09:02:32 --> Config Class Initialized
INFO - 2017-01-20 09:02:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:02:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:02:32 --> Utf8 Class Initialized
INFO - 2017-01-20 09:02:32 --> URI Class Initialized
INFO - 2017-01-20 09:02:32 --> Router Class Initialized
INFO - 2017-01-20 09:02:32 --> Output Class Initialized
INFO - 2017-01-20 09:02:32 --> Security Class Initialized
DEBUG - 2017-01-20 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:02:32 --> Input Class Initialized
INFO - 2017-01-20 09:02:32 --> Language Class Initialized
INFO - 2017-01-20 09:02:32 --> Loader Class Initialized
INFO - 2017-01-20 09:02:32 --> Helper loaded: url_helper
INFO - 2017-01-20 09:02:32 --> Helper loaded: language_helper
INFO - 2017-01-20 09:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:02:32 --> Controller Class Initialized
INFO - 2017-01-20 09:02:32 --> Database Driver Class Initialized
INFO - 2017-01-20 09:02:32 --> Model Class Initialized
INFO - 2017-01-20 09:02:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:02:32 --> Helper loaded: form_helper
INFO - 2017-01-20 09:02:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:02:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:02:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:02:32 --> Final output sent to browser
DEBUG - 2017-01-20 09:02:32 --> Total execution time: 0.1079
INFO - 2017-01-20 09:02:35 --> Config Class Initialized
INFO - 2017-01-20 09:02:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:02:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:02:35 --> Utf8 Class Initialized
INFO - 2017-01-20 09:02:35 --> URI Class Initialized
INFO - 2017-01-20 09:02:35 --> Router Class Initialized
INFO - 2017-01-20 09:02:35 --> Output Class Initialized
INFO - 2017-01-20 09:02:35 --> Security Class Initialized
DEBUG - 2017-01-20 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:02:35 --> Input Class Initialized
INFO - 2017-01-20 09:02:35 --> Language Class Initialized
INFO - 2017-01-20 09:02:35 --> Loader Class Initialized
INFO - 2017-01-20 09:02:35 --> Helper loaded: url_helper
INFO - 2017-01-20 09:02:35 --> Helper loaded: language_helper
INFO - 2017-01-20 09:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:02:35 --> Controller Class Initialized
INFO - 2017-01-20 09:02:35 --> Database Driver Class Initialized
INFO - 2017-01-20 09:02:35 --> Model Class Initialized
INFO - 2017-01-20 09:02:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:02:35 --> Helper loaded: form_helper
INFO - 2017-01-20 09:02:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:02:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:02:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:02:35 --> Final output sent to browser
DEBUG - 2017-01-20 09:02:35 --> Total execution time: 0.1003
INFO - 2017-01-20 09:02:49 --> Config Class Initialized
INFO - 2017-01-20 09:02:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:02:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:02:49 --> Utf8 Class Initialized
INFO - 2017-01-20 09:02:49 --> URI Class Initialized
INFO - 2017-01-20 09:02:49 --> Router Class Initialized
INFO - 2017-01-20 09:02:49 --> Output Class Initialized
INFO - 2017-01-20 09:02:49 --> Security Class Initialized
DEBUG - 2017-01-20 09:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:02:49 --> Input Class Initialized
INFO - 2017-01-20 09:02:49 --> Language Class Initialized
INFO - 2017-01-20 09:02:49 --> Loader Class Initialized
INFO - 2017-01-20 09:02:49 --> Helper loaded: url_helper
INFO - 2017-01-20 09:02:49 --> Helper loaded: language_helper
INFO - 2017-01-20 09:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:02:49 --> Controller Class Initialized
INFO - 2017-01-20 09:02:49 --> Database Driver Class Initialized
INFO - 2017-01-20 09:02:49 --> Model Class Initialized
INFO - 2017-01-20 09:02:49 --> Model Class Initialized
INFO - 2017-01-20 09:02:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:02:49 --> Helper loaded: form_helper
INFO - 2017-01-20 09:02:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:02:49 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:02:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:02:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:02:49 --> Final output sent to browser
DEBUG - 2017-01-20 09:02:49 --> Total execution time: 0.0888
INFO - 2017-01-20 09:03:51 --> Config Class Initialized
INFO - 2017-01-20 09:03:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:03:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:03:51 --> Utf8 Class Initialized
INFO - 2017-01-20 09:03:51 --> URI Class Initialized
INFO - 2017-01-20 09:03:51 --> Router Class Initialized
INFO - 2017-01-20 09:03:51 --> Output Class Initialized
INFO - 2017-01-20 09:03:51 --> Security Class Initialized
DEBUG - 2017-01-20 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:03:51 --> Input Class Initialized
INFO - 2017-01-20 09:03:51 --> Language Class Initialized
INFO - 2017-01-20 09:03:51 --> Loader Class Initialized
INFO - 2017-01-20 09:03:51 --> Helper loaded: url_helper
INFO - 2017-01-20 09:03:51 --> Helper loaded: language_helper
INFO - 2017-01-20 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:03:51 --> Controller Class Initialized
INFO - 2017-01-20 09:03:51 --> Database Driver Class Initialized
INFO - 2017-01-20 09:03:51 --> Model Class Initialized
INFO - 2017-01-20 09:03:51 --> Model Class Initialized
INFO - 2017-01-20 09:03:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:03:51 --> Helper loaded: form_helper
INFO - 2017-01-20 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:03:51 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:03:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:03:51 --> Final output sent to browser
DEBUG - 2017-01-20 09:03:51 --> Total execution time: 0.0959
INFO - 2017-01-20 09:03:54 --> Config Class Initialized
INFO - 2017-01-20 09:03:54 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:03:54 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:03:54 --> Utf8 Class Initialized
INFO - 2017-01-20 09:03:54 --> URI Class Initialized
INFO - 2017-01-20 09:03:54 --> Router Class Initialized
INFO - 2017-01-20 09:03:54 --> Output Class Initialized
INFO - 2017-01-20 09:03:54 --> Security Class Initialized
DEBUG - 2017-01-20 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:03:54 --> Input Class Initialized
INFO - 2017-01-20 09:03:54 --> Language Class Initialized
INFO - 2017-01-20 09:03:54 --> Loader Class Initialized
INFO - 2017-01-20 09:03:54 --> Helper loaded: url_helper
INFO - 2017-01-20 09:03:54 --> Helper loaded: language_helper
INFO - 2017-01-20 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:03:54 --> Controller Class Initialized
INFO - 2017-01-20 09:03:54 --> Database Driver Class Initialized
INFO - 2017-01-20 09:03:54 --> Model Class Initialized
INFO - 2017-01-20 09:03:54 --> Model Class Initialized
INFO - 2017-01-20 09:03:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:03:54 --> Helper loaded: form_helper
INFO - 2017-01-20 09:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:03:54 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:03:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:03:54 --> Final output sent to browser
DEBUG - 2017-01-20 09:03:54 --> Total execution time: 0.0919
INFO - 2017-01-20 09:04:23 --> Config Class Initialized
INFO - 2017-01-20 09:04:23 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:04:23 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:04:23 --> Utf8 Class Initialized
INFO - 2017-01-20 09:04:23 --> URI Class Initialized
INFO - 2017-01-20 09:04:23 --> Router Class Initialized
INFO - 2017-01-20 09:04:23 --> Output Class Initialized
INFO - 2017-01-20 09:04:23 --> Security Class Initialized
DEBUG - 2017-01-20 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:04:23 --> Input Class Initialized
INFO - 2017-01-20 09:04:23 --> Language Class Initialized
INFO - 2017-01-20 09:04:23 --> Loader Class Initialized
INFO - 2017-01-20 09:04:23 --> Helper loaded: url_helper
INFO - 2017-01-20 09:04:23 --> Helper loaded: language_helper
INFO - 2017-01-20 09:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:04:23 --> Controller Class Initialized
INFO - 2017-01-20 09:04:23 --> Database Driver Class Initialized
INFO - 2017-01-20 09:04:23 --> Model Class Initialized
INFO - 2017-01-20 09:04:23 --> Model Class Initialized
INFO - 2017-01-20 09:04:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:04:23 --> Helper loaded: form_helper
INFO - 2017-01-20 09:04:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:04:23 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:04:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:04:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:04:23 --> Final output sent to browser
DEBUG - 2017-01-20 09:04:23 --> Total execution time: 0.0933
INFO - 2017-01-20 09:04:40 --> Config Class Initialized
INFO - 2017-01-20 09:04:40 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:04:40 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:04:40 --> Utf8 Class Initialized
INFO - 2017-01-20 09:04:40 --> URI Class Initialized
INFO - 2017-01-20 09:04:40 --> Router Class Initialized
INFO - 2017-01-20 09:04:40 --> Output Class Initialized
INFO - 2017-01-20 09:04:40 --> Security Class Initialized
DEBUG - 2017-01-20 09:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:04:40 --> Input Class Initialized
INFO - 2017-01-20 09:04:40 --> Language Class Initialized
INFO - 2017-01-20 09:04:40 --> Loader Class Initialized
INFO - 2017-01-20 09:04:40 --> Helper loaded: url_helper
INFO - 2017-01-20 09:04:40 --> Helper loaded: language_helper
INFO - 2017-01-20 09:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:04:40 --> Controller Class Initialized
INFO - 2017-01-20 09:04:40 --> Database Driver Class Initialized
INFO - 2017-01-20 09:04:40 --> Model Class Initialized
INFO - 2017-01-20 09:04:40 --> Model Class Initialized
INFO - 2017-01-20 09:04:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:04:40 --> Helper loaded: form_helper
INFO - 2017-01-20 09:04:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:04:40 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:04:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:04:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:04:40 --> Final output sent to browser
DEBUG - 2017-01-20 09:04:40 --> Total execution time: 0.1018
INFO - 2017-01-20 09:04:47 --> Config Class Initialized
INFO - 2017-01-20 09:04:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:04:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:04:47 --> Utf8 Class Initialized
INFO - 2017-01-20 09:04:47 --> URI Class Initialized
INFO - 2017-01-20 09:04:47 --> Router Class Initialized
INFO - 2017-01-20 09:04:47 --> Output Class Initialized
INFO - 2017-01-20 09:04:47 --> Security Class Initialized
DEBUG - 2017-01-20 09:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:04:47 --> Input Class Initialized
INFO - 2017-01-20 09:04:47 --> Language Class Initialized
INFO - 2017-01-20 09:04:47 --> Loader Class Initialized
INFO - 2017-01-20 09:04:47 --> Helper loaded: url_helper
INFO - 2017-01-20 09:04:47 --> Helper loaded: language_helper
INFO - 2017-01-20 09:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:04:47 --> Controller Class Initialized
INFO - 2017-01-20 09:04:47 --> Database Driver Class Initialized
INFO - 2017-01-20 09:04:47 --> Model Class Initialized
INFO - 2017-01-20 09:04:47 --> Model Class Initialized
INFO - 2017-01-20 09:04:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:04:47 --> Helper loaded: form_helper
INFO - 2017-01-20 09:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:04:47 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:04:47 --> Final output sent to browser
DEBUG - 2017-01-20 09:04:47 --> Total execution time: 0.1043
INFO - 2017-01-20 09:05:25 --> Config Class Initialized
INFO - 2017-01-20 09:05:25 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:05:25 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:05:25 --> Utf8 Class Initialized
INFO - 2017-01-20 09:05:25 --> URI Class Initialized
INFO - 2017-01-20 09:05:25 --> Router Class Initialized
INFO - 2017-01-20 09:05:25 --> Output Class Initialized
INFO - 2017-01-20 09:05:25 --> Security Class Initialized
DEBUG - 2017-01-20 09:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:05:25 --> Input Class Initialized
INFO - 2017-01-20 09:05:25 --> Language Class Initialized
INFO - 2017-01-20 09:05:25 --> Loader Class Initialized
INFO - 2017-01-20 09:05:25 --> Helper loaded: url_helper
INFO - 2017-01-20 09:05:25 --> Helper loaded: language_helper
INFO - 2017-01-20 09:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:05:25 --> Controller Class Initialized
INFO - 2017-01-20 09:05:25 --> Database Driver Class Initialized
INFO - 2017-01-20 09:05:25 --> Model Class Initialized
INFO - 2017-01-20 09:05:25 --> Model Class Initialized
INFO - 2017-01-20 09:05:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:05:25 --> Helper loaded: form_helper
INFO - 2017-01-20 09:05:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:05:25 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:05:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:05:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:05:25 --> Final output sent to browser
DEBUG - 2017-01-20 09:05:25 --> Total execution time: 0.0871
INFO - 2017-01-20 09:05:34 --> Config Class Initialized
INFO - 2017-01-20 09:05:34 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:05:34 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:05:34 --> Utf8 Class Initialized
INFO - 2017-01-20 09:05:34 --> URI Class Initialized
INFO - 2017-01-20 09:05:34 --> Router Class Initialized
INFO - 2017-01-20 09:05:34 --> Output Class Initialized
INFO - 2017-01-20 09:05:34 --> Security Class Initialized
DEBUG - 2017-01-20 09:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:05:34 --> Input Class Initialized
INFO - 2017-01-20 09:05:34 --> Language Class Initialized
INFO - 2017-01-20 09:05:34 --> Loader Class Initialized
INFO - 2017-01-20 09:05:34 --> Helper loaded: url_helper
INFO - 2017-01-20 09:05:34 --> Helper loaded: language_helper
INFO - 2017-01-20 09:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:05:34 --> Controller Class Initialized
INFO - 2017-01-20 09:05:34 --> Database Driver Class Initialized
INFO - 2017-01-20 09:05:34 --> Model Class Initialized
INFO - 2017-01-20 09:05:34 --> Model Class Initialized
INFO - 2017-01-20 09:05:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:05:34 --> Helper loaded: form_helper
INFO - 2017-01-20 09:05:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:05:34 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:05:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:05:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:05:34 --> Final output sent to browser
DEBUG - 2017-01-20 09:05:34 --> Total execution time: 0.1028
INFO - 2017-01-20 09:05:51 --> Config Class Initialized
INFO - 2017-01-20 09:05:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:05:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:05:51 --> Utf8 Class Initialized
INFO - 2017-01-20 09:05:51 --> URI Class Initialized
INFO - 2017-01-20 09:05:51 --> Router Class Initialized
INFO - 2017-01-20 09:05:51 --> Output Class Initialized
INFO - 2017-01-20 09:05:51 --> Security Class Initialized
DEBUG - 2017-01-20 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:05:51 --> Input Class Initialized
INFO - 2017-01-20 09:05:51 --> Language Class Initialized
INFO - 2017-01-20 09:05:51 --> Loader Class Initialized
INFO - 2017-01-20 09:05:51 --> Helper loaded: url_helper
INFO - 2017-01-20 09:05:51 --> Helper loaded: language_helper
INFO - 2017-01-20 09:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:05:51 --> Controller Class Initialized
INFO - 2017-01-20 09:05:51 --> Database Driver Class Initialized
INFO - 2017-01-20 09:05:51 --> Model Class Initialized
INFO - 2017-01-20 09:05:51 --> Model Class Initialized
INFO - 2017-01-20 09:05:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:05:51 --> Helper loaded: form_helper
INFO - 2017-01-20 09:05:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:05:51 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:05:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:05:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:05:51 --> Final output sent to browser
DEBUG - 2017-01-20 09:05:51 --> Total execution time: 0.0872
INFO - 2017-01-20 09:06:17 --> Config Class Initialized
INFO - 2017-01-20 09:06:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:06:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:06:17 --> Utf8 Class Initialized
INFO - 2017-01-20 09:06:17 --> URI Class Initialized
INFO - 2017-01-20 09:06:17 --> Router Class Initialized
INFO - 2017-01-20 09:06:17 --> Output Class Initialized
INFO - 2017-01-20 09:06:17 --> Security Class Initialized
DEBUG - 2017-01-20 09:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:06:17 --> Input Class Initialized
INFO - 2017-01-20 09:06:17 --> Language Class Initialized
INFO - 2017-01-20 09:06:17 --> Loader Class Initialized
INFO - 2017-01-20 09:06:17 --> Helper loaded: url_helper
INFO - 2017-01-20 09:06:17 --> Helper loaded: language_helper
INFO - 2017-01-20 09:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:06:17 --> Controller Class Initialized
INFO - 2017-01-20 09:06:17 --> Database Driver Class Initialized
INFO - 2017-01-20 09:06:18 --> Model Class Initialized
INFO - 2017-01-20 09:06:18 --> Model Class Initialized
INFO - 2017-01-20 09:06:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:06:18 --> Helper loaded: form_helper
INFO - 2017-01-20 09:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:06:18 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:06:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:06:18 --> Final output sent to browser
DEBUG - 2017-01-20 09:06:18 --> Total execution time: 0.0892
INFO - 2017-01-20 09:06:35 --> Config Class Initialized
INFO - 2017-01-20 09:06:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:06:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:06:35 --> Utf8 Class Initialized
INFO - 2017-01-20 09:06:35 --> URI Class Initialized
INFO - 2017-01-20 09:06:35 --> Router Class Initialized
INFO - 2017-01-20 09:06:35 --> Output Class Initialized
INFO - 2017-01-20 09:06:35 --> Security Class Initialized
DEBUG - 2017-01-20 09:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:06:35 --> Input Class Initialized
INFO - 2017-01-20 09:06:35 --> Language Class Initialized
INFO - 2017-01-20 09:06:35 --> Loader Class Initialized
INFO - 2017-01-20 09:06:35 --> Helper loaded: url_helper
INFO - 2017-01-20 09:06:35 --> Helper loaded: language_helper
INFO - 2017-01-20 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:06:35 --> Controller Class Initialized
INFO - 2017-01-20 09:06:35 --> Database Driver Class Initialized
INFO - 2017-01-20 09:06:35 --> Model Class Initialized
INFO - 2017-01-20 09:06:35 --> Model Class Initialized
INFO - 2017-01-20 09:06:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:06:35 --> Helper loaded: form_helper
INFO - 2017-01-20 09:06:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:06:35 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:06:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:06:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:06:35 --> Final output sent to browser
DEBUG - 2017-01-20 09:06:35 --> Total execution time: 0.0875
INFO - 2017-01-20 09:06:41 --> Config Class Initialized
INFO - 2017-01-20 09:06:41 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:06:41 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:06:41 --> Utf8 Class Initialized
INFO - 2017-01-20 09:06:41 --> URI Class Initialized
INFO - 2017-01-20 09:06:41 --> Router Class Initialized
INFO - 2017-01-20 09:06:41 --> Output Class Initialized
INFO - 2017-01-20 09:06:41 --> Security Class Initialized
DEBUG - 2017-01-20 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:06:41 --> Input Class Initialized
INFO - 2017-01-20 09:06:41 --> Language Class Initialized
INFO - 2017-01-20 09:06:41 --> Loader Class Initialized
INFO - 2017-01-20 09:06:41 --> Helper loaded: url_helper
INFO - 2017-01-20 09:06:41 --> Helper loaded: language_helper
INFO - 2017-01-20 09:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:06:41 --> Controller Class Initialized
INFO - 2017-01-20 09:06:41 --> Database Driver Class Initialized
INFO - 2017-01-20 09:06:41 --> Model Class Initialized
INFO - 2017-01-20 09:06:41 --> Model Class Initialized
INFO - 2017-01-20 09:06:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:06:41 --> Helper loaded: form_helper
INFO - 2017-01-20 09:06:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:06:41 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:06:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:06:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:06:41 --> Final output sent to browser
DEBUG - 2017-01-20 09:06:41 --> Total execution time: 0.0990
INFO - 2017-01-20 09:07:48 --> Config Class Initialized
INFO - 2017-01-20 09:07:48 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:07:48 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:07:48 --> Utf8 Class Initialized
INFO - 2017-01-20 09:07:48 --> URI Class Initialized
INFO - 2017-01-20 09:07:48 --> Router Class Initialized
INFO - 2017-01-20 09:07:48 --> Output Class Initialized
INFO - 2017-01-20 09:07:48 --> Security Class Initialized
DEBUG - 2017-01-20 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:07:48 --> Input Class Initialized
INFO - 2017-01-20 09:07:48 --> Language Class Initialized
INFO - 2017-01-20 09:07:48 --> Loader Class Initialized
INFO - 2017-01-20 09:07:48 --> Helper loaded: url_helper
INFO - 2017-01-20 09:07:48 --> Helper loaded: language_helper
INFO - 2017-01-20 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:07:48 --> Controller Class Initialized
INFO - 2017-01-20 09:07:48 --> Database Driver Class Initialized
INFO - 2017-01-20 09:07:48 --> Model Class Initialized
INFO - 2017-01-20 09:07:48 --> Model Class Initialized
INFO - 2017-01-20 09:07:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:07:48 --> Helper loaded: form_helper
INFO - 2017-01-20 09:07:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:07:48 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:07:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:07:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:07:48 --> Final output sent to browser
DEBUG - 2017-01-20 09:07:48 --> Total execution time: 0.0853
INFO - 2017-01-20 09:08:15 --> Config Class Initialized
INFO - 2017-01-20 09:08:15 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:08:15 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:08:15 --> Utf8 Class Initialized
INFO - 2017-01-20 09:08:15 --> URI Class Initialized
INFO - 2017-01-20 09:08:15 --> Router Class Initialized
INFO - 2017-01-20 09:08:15 --> Output Class Initialized
INFO - 2017-01-20 09:08:15 --> Security Class Initialized
DEBUG - 2017-01-20 09:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:08:15 --> Input Class Initialized
INFO - 2017-01-20 09:08:15 --> Language Class Initialized
INFO - 2017-01-20 09:08:15 --> Loader Class Initialized
INFO - 2017-01-20 09:08:15 --> Helper loaded: url_helper
INFO - 2017-01-20 09:08:15 --> Helper loaded: language_helper
INFO - 2017-01-20 09:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:08:15 --> Controller Class Initialized
INFO - 2017-01-20 09:08:15 --> Database Driver Class Initialized
INFO - 2017-01-20 09:08:15 --> Model Class Initialized
INFO - 2017-01-20 09:08:15 --> Model Class Initialized
INFO - 2017-01-20 09:08:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:08:15 --> Helper loaded: form_helper
INFO - 2017-01-20 09:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:08:15 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:08:15 --> Final output sent to browser
DEBUG - 2017-01-20 09:08:15 --> Total execution time: 0.0867
INFO - 2017-01-20 09:08:28 --> Config Class Initialized
INFO - 2017-01-20 09:08:28 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:08:28 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:08:28 --> Utf8 Class Initialized
INFO - 2017-01-20 09:08:28 --> URI Class Initialized
INFO - 2017-01-20 09:08:28 --> Router Class Initialized
INFO - 2017-01-20 09:08:28 --> Output Class Initialized
INFO - 2017-01-20 09:08:28 --> Security Class Initialized
DEBUG - 2017-01-20 09:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:08:28 --> Input Class Initialized
INFO - 2017-01-20 09:08:28 --> Language Class Initialized
INFO - 2017-01-20 09:08:28 --> Loader Class Initialized
INFO - 2017-01-20 09:08:28 --> Helper loaded: url_helper
INFO - 2017-01-20 09:08:28 --> Helper loaded: language_helper
INFO - 2017-01-20 09:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:08:28 --> Controller Class Initialized
INFO - 2017-01-20 09:08:28 --> Database Driver Class Initialized
INFO - 2017-01-20 09:08:28 --> Model Class Initialized
INFO - 2017-01-20 09:08:28 --> Model Class Initialized
INFO - 2017-01-20 09:08:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:08:28 --> Helper loaded: form_helper
INFO - 2017-01-20 09:08:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:08:28 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:08:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:08:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:08:28 --> Final output sent to browser
DEBUG - 2017-01-20 09:08:28 --> Total execution time: 0.0966
INFO - 2017-01-20 09:09:57 --> Config Class Initialized
INFO - 2017-01-20 09:09:57 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:09:57 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:09:57 --> Utf8 Class Initialized
INFO - 2017-01-20 09:09:57 --> URI Class Initialized
INFO - 2017-01-20 09:09:57 --> Router Class Initialized
INFO - 2017-01-20 09:09:57 --> Output Class Initialized
INFO - 2017-01-20 09:09:57 --> Security Class Initialized
DEBUG - 2017-01-20 09:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:09:57 --> Input Class Initialized
INFO - 2017-01-20 09:09:57 --> Language Class Initialized
INFO - 2017-01-20 09:09:57 --> Loader Class Initialized
INFO - 2017-01-20 09:09:57 --> Helper loaded: url_helper
INFO - 2017-01-20 09:09:57 --> Helper loaded: language_helper
INFO - 2017-01-20 09:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:09:57 --> Controller Class Initialized
INFO - 2017-01-20 09:09:57 --> Database Driver Class Initialized
INFO - 2017-01-20 09:09:57 --> Model Class Initialized
INFO - 2017-01-20 09:09:57 --> Model Class Initialized
INFO - 2017-01-20 09:09:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:09:57 --> Helper loaded: form_helper
INFO - 2017-01-20 09:09:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:09:57 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:09:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:09:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:09:57 --> Final output sent to browser
DEBUG - 2017-01-20 09:09:57 --> Total execution time: 0.1277
INFO - 2017-01-20 09:10:04 --> Config Class Initialized
INFO - 2017-01-20 09:10:04 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:10:04 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:10:04 --> Utf8 Class Initialized
INFO - 2017-01-20 09:10:04 --> URI Class Initialized
INFO - 2017-01-20 09:10:04 --> Router Class Initialized
INFO - 2017-01-20 09:10:04 --> Output Class Initialized
INFO - 2017-01-20 09:10:04 --> Security Class Initialized
DEBUG - 2017-01-20 09:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:10:04 --> Input Class Initialized
INFO - 2017-01-20 09:10:04 --> Language Class Initialized
INFO - 2017-01-20 09:10:04 --> Loader Class Initialized
INFO - 2017-01-20 09:10:04 --> Helper loaded: url_helper
INFO - 2017-01-20 09:10:04 --> Helper loaded: language_helper
INFO - 2017-01-20 09:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:10:04 --> Controller Class Initialized
INFO - 2017-01-20 09:10:04 --> Database Driver Class Initialized
INFO - 2017-01-20 09:10:05 --> Model Class Initialized
INFO - 2017-01-20 09:10:05 --> Model Class Initialized
INFO - 2017-01-20 09:10:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:10:05 --> Helper loaded: form_helper
INFO - 2017-01-20 09:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:10:05 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:10:05 --> Final output sent to browser
DEBUG - 2017-01-20 09:10:05 --> Total execution time: 0.0961
INFO - 2017-01-20 09:10:39 --> Config Class Initialized
INFO - 2017-01-20 09:10:39 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:10:39 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:10:39 --> Utf8 Class Initialized
INFO - 2017-01-20 09:10:39 --> URI Class Initialized
INFO - 2017-01-20 09:10:39 --> Router Class Initialized
INFO - 2017-01-20 09:10:39 --> Output Class Initialized
INFO - 2017-01-20 09:10:39 --> Security Class Initialized
DEBUG - 2017-01-20 09:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:10:39 --> Input Class Initialized
INFO - 2017-01-20 09:10:39 --> Language Class Initialized
INFO - 2017-01-20 09:10:39 --> Loader Class Initialized
INFO - 2017-01-20 09:10:39 --> Helper loaded: url_helper
INFO - 2017-01-20 09:10:39 --> Helper loaded: language_helper
INFO - 2017-01-20 09:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:10:39 --> Controller Class Initialized
INFO - 2017-01-20 09:10:39 --> Database Driver Class Initialized
INFO - 2017-01-20 09:10:39 --> Model Class Initialized
INFO - 2017-01-20 09:10:39 --> Model Class Initialized
INFO - 2017-01-20 09:10:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:10:39 --> Helper loaded: form_helper
INFO - 2017-01-20 09:10:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:10:39 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:10:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:10:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:10:39 --> Final output sent to browser
DEBUG - 2017-01-20 09:10:39 --> Total execution time: 0.0844
INFO - 2017-01-20 09:10:43 --> Config Class Initialized
INFO - 2017-01-20 09:10:43 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:10:43 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:10:43 --> Utf8 Class Initialized
INFO - 2017-01-20 09:10:43 --> URI Class Initialized
INFO - 2017-01-20 09:10:43 --> Router Class Initialized
INFO - 2017-01-20 09:10:43 --> Output Class Initialized
INFO - 2017-01-20 09:10:43 --> Security Class Initialized
DEBUG - 2017-01-20 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:10:43 --> Input Class Initialized
INFO - 2017-01-20 09:10:43 --> Language Class Initialized
INFO - 2017-01-20 09:10:43 --> Loader Class Initialized
INFO - 2017-01-20 09:10:43 --> Helper loaded: url_helper
INFO - 2017-01-20 09:10:43 --> Helper loaded: language_helper
INFO - 2017-01-20 09:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:10:43 --> Controller Class Initialized
INFO - 2017-01-20 09:10:43 --> Database Driver Class Initialized
INFO - 2017-01-20 09:10:43 --> Model Class Initialized
INFO - 2017-01-20 09:10:43 --> Model Class Initialized
INFO - 2017-01-20 09:10:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:10:43 --> Helper loaded: form_helper
INFO - 2017-01-20 09:10:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:10:43 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:10:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:10:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:10:43 --> Final output sent to browser
DEBUG - 2017-01-20 09:10:43 --> Total execution time: 0.0970
INFO - 2017-01-20 09:10:46 --> Config Class Initialized
INFO - 2017-01-20 09:10:46 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:10:46 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:10:46 --> Utf8 Class Initialized
INFO - 2017-01-20 09:10:46 --> URI Class Initialized
INFO - 2017-01-20 09:10:46 --> Router Class Initialized
INFO - 2017-01-20 09:10:46 --> Output Class Initialized
INFO - 2017-01-20 09:10:46 --> Security Class Initialized
DEBUG - 2017-01-20 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:10:46 --> Input Class Initialized
INFO - 2017-01-20 09:10:46 --> Language Class Initialized
INFO - 2017-01-20 09:10:46 --> Loader Class Initialized
INFO - 2017-01-20 09:10:46 --> Helper loaded: url_helper
INFO - 2017-01-20 09:10:46 --> Helper loaded: language_helper
INFO - 2017-01-20 09:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:10:46 --> Controller Class Initialized
INFO - 2017-01-20 09:10:46 --> Database Driver Class Initialized
INFO - 2017-01-20 09:10:46 --> Model Class Initialized
INFO - 2017-01-20 09:10:46 --> Model Class Initialized
INFO - 2017-01-20 09:10:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:10:46 --> Helper loaded: form_helper
INFO - 2017-01-20 09:10:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:10:46 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:10:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:10:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:10:46 --> Final output sent to browser
DEBUG - 2017-01-20 09:10:46 --> Total execution time: 0.0843
INFO - 2017-01-20 09:10:47 --> Config Class Initialized
INFO - 2017-01-20 09:10:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:10:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:10:47 --> Utf8 Class Initialized
INFO - 2017-01-20 09:10:47 --> URI Class Initialized
INFO - 2017-01-20 09:10:47 --> Router Class Initialized
INFO - 2017-01-20 09:10:47 --> Output Class Initialized
INFO - 2017-01-20 09:10:47 --> Security Class Initialized
DEBUG - 2017-01-20 09:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:10:47 --> Input Class Initialized
INFO - 2017-01-20 09:10:47 --> Language Class Initialized
INFO - 2017-01-20 09:10:47 --> Loader Class Initialized
INFO - 2017-01-20 09:10:47 --> Helper loaded: url_helper
INFO - 2017-01-20 09:10:47 --> Helper loaded: language_helper
INFO - 2017-01-20 09:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:10:47 --> Controller Class Initialized
INFO - 2017-01-20 09:10:47 --> Database Driver Class Initialized
INFO - 2017-01-20 09:10:47 --> Model Class Initialized
INFO - 2017-01-20 09:10:47 --> Model Class Initialized
INFO - 2017-01-20 09:10:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:10:47 --> Helper loaded: form_helper
INFO - 2017-01-20 09:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:10:47 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:10:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:10:47 --> Final output sent to browser
DEBUG - 2017-01-20 09:10:47 --> Total execution time: 0.0970
INFO - 2017-01-20 09:10:49 --> Config Class Initialized
INFO - 2017-01-20 09:10:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:10:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:10:49 --> Utf8 Class Initialized
INFO - 2017-01-20 09:10:49 --> URI Class Initialized
INFO - 2017-01-20 09:10:49 --> Router Class Initialized
INFO - 2017-01-20 09:10:49 --> Output Class Initialized
INFO - 2017-01-20 09:10:49 --> Security Class Initialized
DEBUG - 2017-01-20 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:10:49 --> Input Class Initialized
INFO - 2017-01-20 09:10:49 --> Language Class Initialized
INFO - 2017-01-20 09:10:49 --> Loader Class Initialized
INFO - 2017-01-20 09:10:49 --> Helper loaded: url_helper
INFO - 2017-01-20 09:10:49 --> Helper loaded: language_helper
INFO - 2017-01-20 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:10:49 --> Controller Class Initialized
INFO - 2017-01-20 09:10:49 --> Database Driver Class Initialized
INFO - 2017-01-20 09:10:50 --> Model Class Initialized
INFO - 2017-01-20 09:10:50 --> Model Class Initialized
INFO - 2017-01-20 09:10:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:10:50 --> Helper loaded: form_helper
INFO - 2017-01-20 09:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:10:50 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:10:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:10:50 --> Final output sent to browser
DEBUG - 2017-01-20 09:10:50 --> Total execution time: 0.0924
INFO - 2017-01-20 09:12:36 --> Config Class Initialized
INFO - 2017-01-20 09:12:36 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:12:36 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:12:36 --> Utf8 Class Initialized
INFO - 2017-01-20 09:12:36 --> URI Class Initialized
INFO - 2017-01-20 09:12:36 --> Router Class Initialized
INFO - 2017-01-20 09:12:36 --> Output Class Initialized
INFO - 2017-01-20 09:12:36 --> Security Class Initialized
DEBUG - 2017-01-20 09:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:12:36 --> Input Class Initialized
INFO - 2017-01-20 09:12:36 --> Language Class Initialized
INFO - 2017-01-20 09:12:36 --> Loader Class Initialized
INFO - 2017-01-20 09:12:36 --> Helper loaded: url_helper
INFO - 2017-01-20 09:12:36 --> Helper loaded: language_helper
INFO - 2017-01-20 09:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:12:36 --> Controller Class Initialized
INFO - 2017-01-20 09:12:36 --> Database Driver Class Initialized
INFO - 2017-01-20 09:12:36 --> Model Class Initialized
INFO - 2017-01-20 09:12:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:12:36 --> Helper loaded: form_helper
INFO - 2017-01-20 09:12:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:12:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:12:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:12:36 --> Final output sent to browser
DEBUG - 2017-01-20 09:12:36 --> Total execution time: 0.0945
INFO - 2017-01-20 09:12:38 --> Config Class Initialized
INFO - 2017-01-20 09:12:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:12:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:12:38 --> Utf8 Class Initialized
INFO - 2017-01-20 09:12:38 --> URI Class Initialized
INFO - 2017-01-20 09:12:38 --> Router Class Initialized
INFO - 2017-01-20 09:12:38 --> Output Class Initialized
INFO - 2017-01-20 09:12:38 --> Security Class Initialized
DEBUG - 2017-01-20 09:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:12:38 --> Input Class Initialized
INFO - 2017-01-20 09:12:38 --> Language Class Initialized
INFO - 2017-01-20 09:12:38 --> Loader Class Initialized
INFO - 2017-01-20 09:12:38 --> Helper loaded: url_helper
INFO - 2017-01-20 09:12:38 --> Helper loaded: language_helper
INFO - 2017-01-20 09:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:12:38 --> Controller Class Initialized
INFO - 2017-01-20 09:12:38 --> Database Driver Class Initialized
INFO - 2017-01-20 09:12:38 --> Model Class Initialized
INFO - 2017-01-20 09:12:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:12:38 --> Helper loaded: form_helper
INFO - 2017-01-20 09:12:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:12:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:12:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:12:38 --> Final output sent to browser
DEBUG - 2017-01-20 09:12:38 --> Total execution time: 0.1027
INFO - 2017-01-20 09:12:40 --> Config Class Initialized
INFO - 2017-01-20 09:12:40 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:12:40 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:12:40 --> Utf8 Class Initialized
INFO - 2017-01-20 09:12:40 --> URI Class Initialized
INFO - 2017-01-20 09:12:40 --> Router Class Initialized
INFO - 2017-01-20 09:12:40 --> Output Class Initialized
INFO - 2017-01-20 09:12:40 --> Security Class Initialized
DEBUG - 2017-01-20 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:12:40 --> Input Class Initialized
INFO - 2017-01-20 09:12:40 --> Language Class Initialized
INFO - 2017-01-20 09:12:40 --> Loader Class Initialized
INFO - 2017-01-20 09:12:40 --> Helper loaded: url_helper
INFO - 2017-01-20 09:12:40 --> Helper loaded: language_helper
INFO - 2017-01-20 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:12:40 --> Controller Class Initialized
INFO - 2017-01-20 09:12:40 --> Database Driver Class Initialized
INFO - 2017-01-20 09:12:40 --> Model Class Initialized
INFO - 2017-01-20 09:12:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:12:40 --> Helper loaded: form_helper
INFO - 2017-01-20 09:12:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:12:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:12:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:12:40 --> Final output sent to browser
DEBUG - 2017-01-20 09:12:40 --> Total execution time: 0.1005
INFO - 2017-01-20 09:12:41 --> Config Class Initialized
INFO - 2017-01-20 09:12:41 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:12:41 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:12:41 --> Utf8 Class Initialized
INFO - 2017-01-20 09:12:41 --> URI Class Initialized
INFO - 2017-01-20 09:12:41 --> Router Class Initialized
INFO - 2017-01-20 09:12:41 --> Output Class Initialized
INFO - 2017-01-20 09:12:41 --> Security Class Initialized
DEBUG - 2017-01-20 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:12:41 --> Input Class Initialized
INFO - 2017-01-20 09:12:41 --> Language Class Initialized
INFO - 2017-01-20 09:12:41 --> Loader Class Initialized
INFO - 2017-01-20 09:12:42 --> Helper loaded: url_helper
INFO - 2017-01-20 09:12:42 --> Helper loaded: language_helper
INFO - 2017-01-20 09:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:12:42 --> Controller Class Initialized
INFO - 2017-01-20 09:12:42 --> Database Driver Class Initialized
INFO - 2017-01-20 09:12:42 --> Model Class Initialized
INFO - 2017-01-20 09:12:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:12:42 --> Helper loaded: form_helper
INFO - 2017-01-20 09:12:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:12:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:12:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:12:42 --> Final output sent to browser
DEBUG - 2017-01-20 09:12:42 --> Total execution time: 0.1194
INFO - 2017-01-20 09:12:54 --> Config Class Initialized
INFO - 2017-01-20 09:12:54 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:12:54 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:12:54 --> Utf8 Class Initialized
INFO - 2017-01-20 09:12:54 --> URI Class Initialized
INFO - 2017-01-20 09:12:54 --> Router Class Initialized
INFO - 2017-01-20 09:12:54 --> Output Class Initialized
INFO - 2017-01-20 09:12:54 --> Security Class Initialized
DEBUG - 2017-01-20 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:12:54 --> Input Class Initialized
INFO - 2017-01-20 09:12:54 --> Language Class Initialized
INFO - 2017-01-20 09:12:54 --> Loader Class Initialized
INFO - 2017-01-20 09:12:54 --> Helper loaded: url_helper
INFO - 2017-01-20 09:12:54 --> Helper loaded: language_helper
INFO - 2017-01-20 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:12:54 --> Controller Class Initialized
INFO - 2017-01-20 09:12:54 --> Database Driver Class Initialized
INFO - 2017-01-20 09:12:54 --> Model Class Initialized
INFO - 2017-01-20 09:12:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:12:54 --> Helper loaded: form_helper
INFO - 2017-01-20 09:12:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:12:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:12:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:12:54 --> Final output sent to browser
DEBUG - 2017-01-20 09:12:54 --> Total execution time: 0.1008
INFO - 2017-01-20 09:12:58 --> Config Class Initialized
INFO - 2017-01-20 09:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:12:58 --> Utf8 Class Initialized
INFO - 2017-01-20 09:12:58 --> URI Class Initialized
INFO - 2017-01-20 09:12:58 --> Router Class Initialized
INFO - 2017-01-20 09:12:58 --> Output Class Initialized
INFO - 2017-01-20 09:12:58 --> Security Class Initialized
DEBUG - 2017-01-20 09:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:12:58 --> Input Class Initialized
INFO - 2017-01-20 09:12:58 --> Language Class Initialized
INFO - 2017-01-20 09:12:58 --> Loader Class Initialized
INFO - 2017-01-20 09:12:58 --> Helper loaded: url_helper
INFO - 2017-01-20 09:12:58 --> Helper loaded: language_helper
INFO - 2017-01-20 09:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:12:58 --> Controller Class Initialized
INFO - 2017-01-20 09:12:58 --> Database Driver Class Initialized
INFO - 2017-01-20 09:12:58 --> Model Class Initialized
INFO - 2017-01-20 09:12:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:12:58 --> Helper loaded: form_helper
INFO - 2017-01-20 09:12:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:12:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:12:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:12:59 --> Final output sent to browser
DEBUG - 2017-01-20 09:12:59 --> Total execution time: 0.0996
INFO - 2017-01-20 09:13:42 --> Config Class Initialized
INFO - 2017-01-20 09:13:42 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:13:42 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:13:42 --> Utf8 Class Initialized
INFO - 2017-01-20 09:13:42 --> URI Class Initialized
INFO - 2017-01-20 09:13:42 --> Router Class Initialized
INFO - 2017-01-20 09:13:42 --> Output Class Initialized
INFO - 2017-01-20 09:13:42 --> Security Class Initialized
DEBUG - 2017-01-20 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:13:42 --> Input Class Initialized
INFO - 2017-01-20 09:13:42 --> Language Class Initialized
INFO - 2017-01-20 09:13:42 --> Loader Class Initialized
INFO - 2017-01-20 09:13:42 --> Helper loaded: url_helper
INFO - 2017-01-20 09:13:42 --> Helper loaded: language_helper
INFO - 2017-01-20 09:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:13:42 --> Controller Class Initialized
INFO - 2017-01-20 09:13:42 --> Database Driver Class Initialized
INFO - 2017-01-20 09:13:42 --> Model Class Initialized
INFO - 2017-01-20 09:13:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:13:42 --> Helper loaded: form_helper
INFO - 2017-01-20 09:13:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:13:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:13:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:13:42 --> Final output sent to browser
DEBUG - 2017-01-20 09:13:42 --> Total execution time: 0.0932
INFO - 2017-01-20 09:13:45 --> Config Class Initialized
INFO - 2017-01-20 09:13:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:13:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:13:45 --> Utf8 Class Initialized
INFO - 2017-01-20 09:13:45 --> URI Class Initialized
INFO - 2017-01-20 09:13:45 --> Router Class Initialized
INFO - 2017-01-20 09:13:45 --> Output Class Initialized
INFO - 2017-01-20 09:13:45 --> Security Class Initialized
DEBUG - 2017-01-20 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:13:45 --> Input Class Initialized
INFO - 2017-01-20 09:13:45 --> Language Class Initialized
INFO - 2017-01-20 09:13:45 --> Loader Class Initialized
INFO - 2017-01-20 09:13:45 --> Helper loaded: url_helper
INFO - 2017-01-20 09:13:45 --> Helper loaded: language_helper
INFO - 2017-01-20 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:13:45 --> Controller Class Initialized
INFO - 2017-01-20 09:13:45 --> Database Driver Class Initialized
INFO - 2017-01-20 09:13:45 --> Model Class Initialized
INFO - 2017-01-20 09:13:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:13:45 --> Helper loaded: form_helper
INFO - 2017-01-20 09:13:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:13:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:13:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:13:45 --> Final output sent to browser
DEBUG - 2017-01-20 09:13:45 --> Total execution time: 0.0941
INFO - 2017-01-20 09:13:46 --> Config Class Initialized
INFO - 2017-01-20 09:13:46 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:13:46 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:13:46 --> Utf8 Class Initialized
INFO - 2017-01-20 09:13:46 --> URI Class Initialized
INFO - 2017-01-20 09:13:46 --> Router Class Initialized
INFO - 2017-01-20 09:13:46 --> Output Class Initialized
INFO - 2017-01-20 09:13:46 --> Security Class Initialized
DEBUG - 2017-01-20 09:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:13:46 --> Input Class Initialized
INFO - 2017-01-20 09:13:46 --> Language Class Initialized
INFO - 2017-01-20 09:13:46 --> Loader Class Initialized
INFO - 2017-01-20 09:13:46 --> Helper loaded: url_helper
INFO - 2017-01-20 09:13:46 --> Helper loaded: language_helper
INFO - 2017-01-20 09:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:13:46 --> Controller Class Initialized
INFO - 2017-01-20 09:13:46 --> Database Driver Class Initialized
INFO - 2017-01-20 09:13:46 --> Model Class Initialized
INFO - 2017-01-20 09:13:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:13:46 --> Helper loaded: form_helper
INFO - 2017-01-20 09:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:13:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:13:46 --> Final output sent to browser
DEBUG - 2017-01-20 09:13:46 --> Total execution time: 0.1085
INFO - 2017-01-20 09:13:50 --> Config Class Initialized
INFO - 2017-01-20 09:13:50 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:13:50 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:13:50 --> Utf8 Class Initialized
INFO - 2017-01-20 09:13:50 --> URI Class Initialized
INFO - 2017-01-20 09:13:50 --> Router Class Initialized
INFO - 2017-01-20 09:13:50 --> Output Class Initialized
INFO - 2017-01-20 09:13:50 --> Security Class Initialized
DEBUG - 2017-01-20 09:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:13:50 --> Input Class Initialized
INFO - 2017-01-20 09:13:50 --> Language Class Initialized
INFO - 2017-01-20 09:13:50 --> Loader Class Initialized
INFO - 2017-01-20 09:13:50 --> Helper loaded: url_helper
INFO - 2017-01-20 09:13:50 --> Helper loaded: language_helper
INFO - 2017-01-20 09:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:13:50 --> Controller Class Initialized
INFO - 2017-01-20 09:13:50 --> Database Driver Class Initialized
INFO - 2017-01-20 09:13:50 --> Model Class Initialized
INFO - 2017-01-20 09:13:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:13:50 --> Helper loaded: form_helper
INFO - 2017-01-20 09:13:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:13:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:13:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:13:50 --> Final output sent to browser
DEBUG - 2017-01-20 09:13:50 --> Total execution time: 0.1287
INFO - 2017-01-20 09:14:17 --> Config Class Initialized
INFO - 2017-01-20 09:14:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:14:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:14:17 --> Utf8 Class Initialized
INFO - 2017-01-20 09:14:17 --> URI Class Initialized
INFO - 2017-01-20 09:14:17 --> Router Class Initialized
INFO - 2017-01-20 09:14:17 --> Output Class Initialized
INFO - 2017-01-20 09:14:17 --> Security Class Initialized
DEBUG - 2017-01-20 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:14:18 --> Input Class Initialized
INFO - 2017-01-20 09:14:18 --> Language Class Initialized
INFO - 2017-01-20 09:14:18 --> Loader Class Initialized
INFO - 2017-01-20 09:14:18 --> Helper loaded: url_helper
INFO - 2017-01-20 09:14:18 --> Helper loaded: language_helper
INFO - 2017-01-20 09:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:14:18 --> Controller Class Initialized
INFO - 2017-01-20 09:14:18 --> Database Driver Class Initialized
INFO - 2017-01-20 09:14:18 --> Model Class Initialized
INFO - 2017-01-20 09:14:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:14:18 --> Helper loaded: form_helper
INFO - 2017-01-20 09:14:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:14:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:14:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:14:18 --> Final output sent to browser
DEBUG - 2017-01-20 09:14:18 --> Total execution time: 0.0972
INFO - 2017-01-20 09:19:34 --> Config Class Initialized
INFO - 2017-01-20 09:19:34 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:19:34 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:19:34 --> Utf8 Class Initialized
INFO - 2017-01-20 09:19:34 --> URI Class Initialized
INFO - 2017-01-20 09:19:34 --> Router Class Initialized
INFO - 2017-01-20 09:19:34 --> Output Class Initialized
INFO - 2017-01-20 09:19:34 --> Security Class Initialized
DEBUG - 2017-01-20 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:19:34 --> Input Class Initialized
INFO - 2017-01-20 09:19:34 --> Language Class Initialized
INFO - 2017-01-20 09:19:34 --> Loader Class Initialized
INFO - 2017-01-20 09:19:34 --> Helper loaded: url_helper
INFO - 2017-01-20 09:19:34 --> Helper loaded: language_helper
INFO - 2017-01-20 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:19:34 --> Controller Class Initialized
INFO - 2017-01-20 09:19:34 --> Database Driver Class Initialized
INFO - 2017-01-20 09:19:34 --> Model Class Initialized
INFO - 2017-01-20 09:19:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:19:34 --> Helper loaded: form_helper
ERROR - 2017-01-20 09:19:34 --> Severity: Notice --> Undefined variable: script C:\wamp64\www\savsoftquiz\application\models\Hasil_model.php 62
ERROR - 2017-01-20 09:19:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum' at line 1 - Invalid query: round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum(case when c.cid=12 then a.score_u else null end), 0) as ist2,round(sum(case when c.cid=13 then a.score_u else null end), 0) as ist3,round(sum(case when c.cid=14 then a.score_u else null end), 0) as ist4,round(sum(case when c.cid=15 then a.score_u else null end), 0) as ist5,round(sum(case when c.cid=16 then a.score_u else null end), 0) as ist6,round(sum(case when c.cid=17 then a.score_u else null end), 0) as ist7,round(sum(case when c.cid=19 then a.score_u else null end), 0) as ist8,round(sum(case when c.cid=20 then a.score_u else null end), 0) as ist9,round(sum(case when c.cid=22 then a.score_u else null end), 0) as ist10,
                round(sum(a.score_u), 0) as total
                from answers a
                left join qbank b on b.qid = a.qid
                left join category c on c.cid = b.cid
                left join users d on d.uid = a.uid
                where su != 1
                group by d.uid
                order by total desc  limit 30 offset 0
INFO - 2017-01-20 09:19:34 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-20 09:19:36 --> Config Class Initialized
INFO - 2017-01-20 09:19:36 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:19:36 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:19:36 --> Utf8 Class Initialized
INFO - 2017-01-20 09:19:36 --> URI Class Initialized
INFO - 2017-01-20 09:19:36 --> Router Class Initialized
INFO - 2017-01-20 09:19:36 --> Output Class Initialized
INFO - 2017-01-20 09:19:36 --> Security Class Initialized
DEBUG - 2017-01-20 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:19:36 --> Input Class Initialized
INFO - 2017-01-20 09:19:36 --> Language Class Initialized
INFO - 2017-01-20 09:19:36 --> Loader Class Initialized
INFO - 2017-01-20 09:19:36 --> Helper loaded: url_helper
INFO - 2017-01-20 09:19:36 --> Helper loaded: language_helper
INFO - 2017-01-20 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:19:36 --> Controller Class Initialized
INFO - 2017-01-20 09:19:36 --> Database Driver Class Initialized
INFO - 2017-01-20 09:19:36 --> Model Class Initialized
INFO - 2017-01-20 09:19:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:19:36 --> Helper loaded: form_helper
ERROR - 2017-01-20 09:19:36 --> Severity: Notice --> Undefined variable: script C:\wamp64\www\savsoftquiz\application\models\Hasil_model.php 62
ERROR - 2017-01-20 09:19:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum' at line 1 - Invalid query: round(sum(case when c.cid=11 then a.score_u else null end), 0) as ist1,round(sum(case when c.cid=12 then a.score_u else null end), 0) as ist2,round(sum(case when c.cid=13 then a.score_u else null end), 0) as ist3,round(sum(case when c.cid=14 then a.score_u else null end), 0) as ist4,round(sum(case when c.cid=15 then a.score_u else null end), 0) as ist5,round(sum(case when c.cid=16 then a.score_u else null end), 0) as ist6,round(sum(case when c.cid=17 then a.score_u else null end), 0) as ist7,round(sum(case when c.cid=19 then a.score_u else null end), 0) as ist8,round(sum(case when c.cid=20 then a.score_u else null end), 0) as ist9,round(sum(case when c.cid=22 then a.score_u else null end), 0) as ist10,
                round(sum(a.score_u), 0) as total
                from answers a
                left join qbank b on b.qid = a.qid
                left join category c on c.cid = b.cid
                left join users d on d.uid = a.uid
                where su != 1
                group by d.uid
                order by total desc  limit 30 offset 0
INFO - 2017-01-20 09:19:36 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-01-20 09:21:51 --> Config Class Initialized
INFO - 2017-01-20 09:21:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:21:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:21:51 --> Utf8 Class Initialized
INFO - 2017-01-20 09:21:51 --> URI Class Initialized
INFO - 2017-01-20 09:21:51 --> Router Class Initialized
INFO - 2017-01-20 09:21:51 --> Output Class Initialized
INFO - 2017-01-20 09:21:51 --> Security Class Initialized
DEBUG - 2017-01-20 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:21:51 --> Input Class Initialized
INFO - 2017-01-20 09:21:51 --> Language Class Initialized
INFO - 2017-01-20 09:21:51 --> Loader Class Initialized
INFO - 2017-01-20 09:21:51 --> Helper loaded: url_helper
INFO - 2017-01-20 09:21:51 --> Helper loaded: language_helper
INFO - 2017-01-20 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:21:51 --> Controller Class Initialized
INFO - 2017-01-20 09:21:51 --> Database Driver Class Initialized
INFO - 2017-01-20 09:21:51 --> Model Class Initialized
INFO - 2017-01-20 09:21:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:21:51 --> Helper loaded: form_helper
INFO - 2017-01-20 09:21:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:21:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:21:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:21:51 --> Final output sent to browser
DEBUG - 2017-01-20 09:21:51 --> Total execution time: 0.1016
INFO - 2017-01-20 09:21:54 --> Config Class Initialized
INFO - 2017-01-20 09:21:54 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:21:54 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:21:54 --> Utf8 Class Initialized
INFO - 2017-01-20 09:21:54 --> URI Class Initialized
INFO - 2017-01-20 09:21:54 --> Router Class Initialized
INFO - 2017-01-20 09:21:54 --> Output Class Initialized
INFO - 2017-01-20 09:21:54 --> Security Class Initialized
DEBUG - 2017-01-20 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:21:54 --> Input Class Initialized
INFO - 2017-01-20 09:21:54 --> Language Class Initialized
INFO - 2017-01-20 09:21:54 --> Loader Class Initialized
INFO - 2017-01-20 09:21:54 --> Helper loaded: url_helper
INFO - 2017-01-20 09:21:54 --> Helper loaded: language_helper
INFO - 2017-01-20 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:21:54 --> Controller Class Initialized
INFO - 2017-01-20 09:21:54 --> Database Driver Class Initialized
INFO - 2017-01-20 09:21:54 --> Model Class Initialized
INFO - 2017-01-20 09:21:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:21:54 --> Helper loaded: form_helper
INFO - 2017-01-20 09:21:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:21:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:21:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:21:54 --> Final output sent to browser
DEBUG - 2017-01-20 09:21:54 --> Total execution time: 0.1018
INFO - 2017-01-20 09:21:56 --> Config Class Initialized
INFO - 2017-01-20 09:21:56 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:21:56 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:21:56 --> Utf8 Class Initialized
INFO - 2017-01-20 09:21:56 --> URI Class Initialized
INFO - 2017-01-20 09:21:56 --> Router Class Initialized
INFO - 2017-01-20 09:21:56 --> Output Class Initialized
INFO - 2017-01-20 09:21:56 --> Security Class Initialized
DEBUG - 2017-01-20 09:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:21:56 --> Input Class Initialized
INFO - 2017-01-20 09:21:56 --> Language Class Initialized
INFO - 2017-01-20 09:21:56 --> Loader Class Initialized
INFO - 2017-01-20 09:21:56 --> Helper loaded: url_helper
INFO - 2017-01-20 09:21:56 --> Helper loaded: language_helper
INFO - 2017-01-20 09:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:21:56 --> Controller Class Initialized
INFO - 2017-01-20 09:21:56 --> Database Driver Class Initialized
INFO - 2017-01-20 09:21:56 --> Model Class Initialized
INFO - 2017-01-20 09:21:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:21:56 --> Helper loaded: form_helper
INFO - 2017-01-20 09:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:21:56 --> Final output sent to browser
DEBUG - 2017-01-20 09:21:56 --> Total execution time: 0.1095
INFO - 2017-01-20 09:22:01 --> Config Class Initialized
INFO - 2017-01-20 09:22:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:22:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:22:01 --> Utf8 Class Initialized
INFO - 2017-01-20 09:22:01 --> URI Class Initialized
INFO - 2017-01-20 09:22:01 --> Router Class Initialized
INFO - 2017-01-20 09:22:01 --> Output Class Initialized
INFO - 2017-01-20 09:22:01 --> Security Class Initialized
DEBUG - 2017-01-20 09:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:22:01 --> Input Class Initialized
INFO - 2017-01-20 09:22:01 --> Language Class Initialized
INFO - 2017-01-20 09:22:01 --> Loader Class Initialized
INFO - 2017-01-20 09:22:01 --> Helper loaded: url_helper
INFO - 2017-01-20 09:22:01 --> Helper loaded: language_helper
INFO - 2017-01-20 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:22:01 --> Controller Class Initialized
INFO - 2017-01-20 09:22:01 --> Database Driver Class Initialized
INFO - 2017-01-20 09:22:01 --> Model Class Initialized
INFO - 2017-01-20 09:22:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:22:01 --> Helper loaded: form_helper
INFO - 2017-01-20 09:22:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:22:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:22:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:22:01 --> Final output sent to browser
DEBUG - 2017-01-20 09:22:01 --> Total execution time: 0.0986
INFO - 2017-01-20 09:22:03 --> Config Class Initialized
INFO - 2017-01-20 09:22:03 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:22:03 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:22:03 --> Utf8 Class Initialized
INFO - 2017-01-20 09:22:03 --> URI Class Initialized
INFO - 2017-01-20 09:22:03 --> Router Class Initialized
INFO - 2017-01-20 09:22:03 --> Output Class Initialized
INFO - 2017-01-20 09:22:03 --> Security Class Initialized
DEBUG - 2017-01-20 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:22:03 --> Input Class Initialized
INFO - 2017-01-20 09:22:03 --> Language Class Initialized
INFO - 2017-01-20 09:22:03 --> Loader Class Initialized
INFO - 2017-01-20 09:22:03 --> Helper loaded: url_helper
INFO - 2017-01-20 09:22:03 --> Helper loaded: language_helper
INFO - 2017-01-20 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:22:03 --> Controller Class Initialized
INFO - 2017-01-20 09:22:03 --> Database Driver Class Initialized
INFO - 2017-01-20 09:22:03 --> Model Class Initialized
INFO - 2017-01-20 09:22:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:22:03 --> Helper loaded: form_helper
INFO - 2017-01-20 09:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:22:03 --> Final output sent to browser
DEBUG - 2017-01-20 09:22:03 --> Total execution time: 0.0978
INFO - 2017-01-20 09:22:18 --> Config Class Initialized
INFO - 2017-01-20 09:22:18 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:22:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:22:19 --> Utf8 Class Initialized
INFO - 2017-01-20 09:22:19 --> URI Class Initialized
INFO - 2017-01-20 09:22:19 --> Router Class Initialized
INFO - 2017-01-20 09:22:19 --> Output Class Initialized
INFO - 2017-01-20 09:22:19 --> Security Class Initialized
DEBUG - 2017-01-20 09:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:22:19 --> Input Class Initialized
INFO - 2017-01-20 09:22:19 --> Language Class Initialized
INFO - 2017-01-20 09:22:19 --> Loader Class Initialized
INFO - 2017-01-20 09:22:19 --> Helper loaded: url_helper
INFO - 2017-01-20 09:22:19 --> Helper loaded: language_helper
INFO - 2017-01-20 09:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:22:19 --> Controller Class Initialized
INFO - 2017-01-20 09:22:19 --> Database Driver Class Initialized
INFO - 2017-01-20 09:22:19 --> Model Class Initialized
INFO - 2017-01-20 09:22:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:22:19 --> Helper loaded: form_helper
INFO - 2017-01-20 09:22:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:22:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:22:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:22:19 --> Final output sent to browser
DEBUG - 2017-01-20 09:22:19 --> Total execution time: 0.1181
INFO - 2017-01-20 09:22:20 --> Config Class Initialized
INFO - 2017-01-20 09:22:20 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:22:20 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:22:20 --> Utf8 Class Initialized
INFO - 2017-01-20 09:22:20 --> URI Class Initialized
INFO - 2017-01-20 09:22:20 --> Router Class Initialized
INFO - 2017-01-20 09:22:20 --> Output Class Initialized
INFO - 2017-01-20 09:22:20 --> Security Class Initialized
DEBUG - 2017-01-20 09:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:22:20 --> Input Class Initialized
INFO - 2017-01-20 09:22:20 --> Language Class Initialized
INFO - 2017-01-20 09:22:20 --> Loader Class Initialized
INFO - 2017-01-20 09:22:20 --> Helper loaded: url_helper
INFO - 2017-01-20 09:22:20 --> Helper loaded: language_helper
INFO - 2017-01-20 09:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:22:20 --> Controller Class Initialized
INFO - 2017-01-20 09:22:20 --> Database Driver Class Initialized
INFO - 2017-01-20 09:22:20 --> Model Class Initialized
INFO - 2017-01-20 09:22:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:22:20 --> Helper loaded: form_helper
INFO - 2017-01-20 09:22:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:22:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:22:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:22:20 --> Final output sent to browser
DEBUG - 2017-01-20 09:22:20 --> Total execution time: 0.1183
INFO - 2017-01-20 09:22:23 --> Config Class Initialized
INFO - 2017-01-20 09:22:23 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:22:23 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:22:23 --> Utf8 Class Initialized
INFO - 2017-01-20 09:22:23 --> URI Class Initialized
INFO - 2017-01-20 09:22:23 --> Router Class Initialized
INFO - 2017-01-20 09:22:23 --> Output Class Initialized
INFO - 2017-01-20 09:22:23 --> Security Class Initialized
DEBUG - 2017-01-20 09:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:22:23 --> Input Class Initialized
INFO - 2017-01-20 09:22:23 --> Language Class Initialized
INFO - 2017-01-20 09:22:23 --> Loader Class Initialized
INFO - 2017-01-20 09:22:23 --> Helper loaded: url_helper
INFO - 2017-01-20 09:22:23 --> Helper loaded: language_helper
INFO - 2017-01-20 09:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:22:23 --> Controller Class Initialized
INFO - 2017-01-20 09:22:23 --> Database Driver Class Initialized
INFO - 2017-01-20 09:22:23 --> Model Class Initialized
INFO - 2017-01-20 09:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:22:23 --> Helper loaded: form_helper
INFO - 2017-01-20 09:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:22:23 --> Final output sent to browser
DEBUG - 2017-01-20 09:22:23 --> Total execution time: 0.0943
INFO - 2017-01-20 09:22:24 --> Config Class Initialized
INFO - 2017-01-20 09:22:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:22:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:22:24 --> Utf8 Class Initialized
INFO - 2017-01-20 09:22:24 --> URI Class Initialized
INFO - 2017-01-20 09:22:24 --> Router Class Initialized
INFO - 2017-01-20 09:22:24 --> Output Class Initialized
INFO - 2017-01-20 09:22:24 --> Security Class Initialized
DEBUG - 2017-01-20 09:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:22:24 --> Input Class Initialized
INFO - 2017-01-20 09:22:24 --> Language Class Initialized
INFO - 2017-01-20 09:22:24 --> Loader Class Initialized
INFO - 2017-01-20 09:22:24 --> Helper loaded: url_helper
INFO - 2017-01-20 09:22:24 --> Helper loaded: language_helper
INFO - 2017-01-20 09:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:22:24 --> Controller Class Initialized
INFO - 2017-01-20 09:22:24 --> Database Driver Class Initialized
INFO - 2017-01-20 09:22:24 --> Model Class Initialized
INFO - 2017-01-20 09:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:22:24 --> Helper loaded: form_helper
INFO - 2017-01-20 09:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:22:24 --> Final output sent to browser
DEBUG - 2017-01-20 09:22:24 --> Total execution time: 0.0966
INFO - 2017-01-20 09:23:02 --> Config Class Initialized
INFO - 2017-01-20 09:23:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:23:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:23:02 --> Utf8 Class Initialized
INFO - 2017-01-20 09:23:02 --> URI Class Initialized
INFO - 2017-01-20 09:23:02 --> Router Class Initialized
INFO - 2017-01-20 09:23:02 --> Output Class Initialized
INFO - 2017-01-20 09:23:02 --> Security Class Initialized
DEBUG - 2017-01-20 09:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:23:02 --> Input Class Initialized
INFO - 2017-01-20 09:23:02 --> Language Class Initialized
INFO - 2017-01-20 09:23:02 --> Loader Class Initialized
INFO - 2017-01-20 09:23:02 --> Helper loaded: url_helper
INFO - 2017-01-20 09:23:02 --> Helper loaded: language_helper
INFO - 2017-01-20 09:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:23:02 --> Controller Class Initialized
INFO - 2017-01-20 09:23:02 --> Database Driver Class Initialized
INFO - 2017-01-20 09:23:02 --> Model Class Initialized
INFO - 2017-01-20 09:23:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:23:02 --> Helper loaded: form_helper
INFO - 2017-01-20 09:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:23:02 --> Final output sent to browser
DEBUG - 2017-01-20 09:23:02 --> Total execution time: 0.0943
INFO - 2017-01-20 09:23:29 --> Config Class Initialized
INFO - 2017-01-20 09:23:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:23:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:23:29 --> Utf8 Class Initialized
INFO - 2017-01-20 09:23:29 --> URI Class Initialized
INFO - 2017-01-20 09:23:29 --> Router Class Initialized
INFO - 2017-01-20 09:23:29 --> Output Class Initialized
INFO - 2017-01-20 09:23:29 --> Security Class Initialized
DEBUG - 2017-01-20 09:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:23:29 --> Input Class Initialized
INFO - 2017-01-20 09:23:29 --> Language Class Initialized
INFO - 2017-01-20 09:23:29 --> Loader Class Initialized
INFO - 2017-01-20 09:23:29 --> Helper loaded: url_helper
INFO - 2017-01-20 09:23:29 --> Helper loaded: language_helper
INFO - 2017-01-20 09:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:23:29 --> Controller Class Initialized
INFO - 2017-01-20 09:23:29 --> Database Driver Class Initialized
INFO - 2017-01-20 09:23:29 --> Model Class Initialized
INFO - 2017-01-20 09:23:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:23:29 --> Helper loaded: form_helper
INFO - 2017-01-20 09:23:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:23:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:23:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:23:29 --> Final output sent to browser
DEBUG - 2017-01-20 09:23:29 --> Total execution time: 0.0894
INFO - 2017-01-20 09:23:30 --> Config Class Initialized
INFO - 2017-01-20 09:23:30 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:23:30 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:23:30 --> Utf8 Class Initialized
INFO - 2017-01-20 09:23:30 --> URI Class Initialized
INFO - 2017-01-20 09:23:30 --> Router Class Initialized
INFO - 2017-01-20 09:23:30 --> Output Class Initialized
INFO - 2017-01-20 09:23:30 --> Security Class Initialized
DEBUG - 2017-01-20 09:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:23:30 --> Input Class Initialized
INFO - 2017-01-20 09:23:30 --> Language Class Initialized
INFO - 2017-01-20 09:23:30 --> Loader Class Initialized
INFO - 2017-01-20 09:23:30 --> Helper loaded: url_helper
INFO - 2017-01-20 09:23:30 --> Helper loaded: language_helper
INFO - 2017-01-20 09:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:23:30 --> Controller Class Initialized
INFO - 2017-01-20 09:23:30 --> Database Driver Class Initialized
INFO - 2017-01-20 09:23:30 --> Model Class Initialized
INFO - 2017-01-20 09:23:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:23:30 --> Helper loaded: form_helper
INFO - 2017-01-20 09:23:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:23:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:23:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:23:30 --> Final output sent to browser
DEBUG - 2017-01-20 09:23:30 --> Total execution time: 0.1231
INFO - 2017-01-20 09:23:32 --> Config Class Initialized
INFO - 2017-01-20 09:23:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:23:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:23:32 --> Utf8 Class Initialized
INFO - 2017-01-20 09:23:32 --> URI Class Initialized
INFO - 2017-01-20 09:23:32 --> Router Class Initialized
INFO - 2017-01-20 09:23:32 --> Output Class Initialized
INFO - 2017-01-20 09:23:32 --> Security Class Initialized
DEBUG - 2017-01-20 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:23:32 --> Input Class Initialized
INFO - 2017-01-20 09:23:32 --> Language Class Initialized
INFO - 2017-01-20 09:23:32 --> Loader Class Initialized
INFO - 2017-01-20 09:23:32 --> Helper loaded: url_helper
INFO - 2017-01-20 09:23:32 --> Helper loaded: language_helper
INFO - 2017-01-20 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:23:32 --> Controller Class Initialized
INFO - 2017-01-20 09:23:32 --> Database Driver Class Initialized
INFO - 2017-01-20 09:23:32 --> Model Class Initialized
INFO - 2017-01-20 09:23:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:23:32 --> Helper loaded: form_helper
INFO - 2017-01-20 09:23:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:23:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:23:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:23:32 --> Final output sent to browser
DEBUG - 2017-01-20 09:23:32 --> Total execution time: 0.0978
INFO - 2017-01-20 09:26:06 --> Config Class Initialized
INFO - 2017-01-20 09:26:06 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:26:06 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:26:06 --> Utf8 Class Initialized
INFO - 2017-01-20 09:26:06 --> URI Class Initialized
INFO - 2017-01-20 09:26:06 --> Router Class Initialized
INFO - 2017-01-20 09:26:06 --> Output Class Initialized
INFO - 2017-01-20 09:26:06 --> Security Class Initialized
DEBUG - 2017-01-20 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:26:06 --> Input Class Initialized
INFO - 2017-01-20 09:26:06 --> Language Class Initialized
INFO - 2017-01-20 09:26:06 --> Loader Class Initialized
INFO - 2017-01-20 09:26:06 --> Helper loaded: url_helper
INFO - 2017-01-20 09:26:06 --> Helper loaded: language_helper
INFO - 2017-01-20 09:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:26:06 --> Controller Class Initialized
INFO - 2017-01-20 09:26:06 --> Database Driver Class Initialized
INFO - 2017-01-20 09:26:06 --> Model Class Initialized
INFO - 2017-01-20 09:26:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:26:06 --> Helper loaded: form_helper
INFO - 2017-01-20 09:26:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:26:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:26:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:26:06 --> Final output sent to browser
DEBUG - 2017-01-20 09:26:06 --> Total execution time: 0.0958
INFO - 2017-01-20 09:26:10 --> Config Class Initialized
INFO - 2017-01-20 09:26:10 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:26:10 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:26:10 --> Utf8 Class Initialized
INFO - 2017-01-20 09:26:10 --> URI Class Initialized
INFO - 2017-01-20 09:26:10 --> Router Class Initialized
INFO - 2017-01-20 09:26:10 --> Output Class Initialized
INFO - 2017-01-20 09:26:10 --> Security Class Initialized
DEBUG - 2017-01-20 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:26:10 --> Input Class Initialized
INFO - 2017-01-20 09:26:10 --> Language Class Initialized
INFO - 2017-01-20 09:26:10 --> Loader Class Initialized
INFO - 2017-01-20 09:26:10 --> Helper loaded: url_helper
INFO - 2017-01-20 09:26:10 --> Helper loaded: language_helper
INFO - 2017-01-20 09:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:26:10 --> Controller Class Initialized
INFO - 2017-01-20 09:26:10 --> Database Driver Class Initialized
INFO - 2017-01-20 09:26:10 --> Model Class Initialized
INFO - 2017-01-20 09:26:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:26:10 --> Helper loaded: form_helper
INFO - 2017-01-20 09:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:26:10 --> Final output sent to browser
DEBUG - 2017-01-20 09:26:10 --> Total execution time: 0.0988
INFO - 2017-01-20 09:26:12 --> Config Class Initialized
INFO - 2017-01-20 09:26:12 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:26:12 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:26:12 --> Utf8 Class Initialized
INFO - 2017-01-20 09:26:12 --> URI Class Initialized
INFO - 2017-01-20 09:26:12 --> Router Class Initialized
INFO - 2017-01-20 09:26:12 --> Output Class Initialized
INFO - 2017-01-20 09:26:12 --> Security Class Initialized
DEBUG - 2017-01-20 09:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:26:12 --> Input Class Initialized
INFO - 2017-01-20 09:26:12 --> Language Class Initialized
INFO - 2017-01-20 09:26:12 --> Loader Class Initialized
INFO - 2017-01-20 09:26:12 --> Helper loaded: url_helper
INFO - 2017-01-20 09:26:12 --> Helper loaded: language_helper
INFO - 2017-01-20 09:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:26:12 --> Controller Class Initialized
INFO - 2017-01-20 09:26:12 --> Database Driver Class Initialized
INFO - 2017-01-20 09:26:12 --> Model Class Initialized
INFO - 2017-01-20 09:26:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:26:12 --> Helper loaded: form_helper
INFO - 2017-01-20 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:26:13 --> Final output sent to browser
DEBUG - 2017-01-20 09:26:13 --> Total execution time: 0.0944
INFO - 2017-01-20 09:26:14 --> Config Class Initialized
INFO - 2017-01-20 09:26:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:26:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:26:14 --> Utf8 Class Initialized
INFO - 2017-01-20 09:26:14 --> URI Class Initialized
INFO - 2017-01-20 09:26:14 --> Router Class Initialized
INFO - 2017-01-20 09:26:14 --> Output Class Initialized
INFO - 2017-01-20 09:26:14 --> Security Class Initialized
DEBUG - 2017-01-20 09:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:26:14 --> Input Class Initialized
INFO - 2017-01-20 09:26:14 --> Language Class Initialized
INFO - 2017-01-20 09:26:14 --> Loader Class Initialized
INFO - 2017-01-20 09:26:14 --> Helper loaded: url_helper
INFO - 2017-01-20 09:26:14 --> Helper loaded: language_helper
INFO - 2017-01-20 09:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:26:14 --> Controller Class Initialized
INFO - 2017-01-20 09:26:14 --> Database Driver Class Initialized
INFO - 2017-01-20 09:26:14 --> Model Class Initialized
INFO - 2017-01-20 09:26:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:26:14 --> Helper loaded: form_helper
INFO - 2017-01-20 09:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:26:14 --> Final output sent to browser
DEBUG - 2017-01-20 09:26:14 --> Total execution time: 0.1191
INFO - 2017-01-20 09:26:16 --> Config Class Initialized
INFO - 2017-01-20 09:26:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:26:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:26:16 --> Utf8 Class Initialized
INFO - 2017-01-20 09:26:16 --> URI Class Initialized
INFO - 2017-01-20 09:26:16 --> Router Class Initialized
INFO - 2017-01-20 09:26:16 --> Output Class Initialized
INFO - 2017-01-20 09:26:16 --> Security Class Initialized
DEBUG - 2017-01-20 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:26:16 --> Input Class Initialized
INFO - 2017-01-20 09:26:16 --> Language Class Initialized
INFO - 2017-01-20 09:26:16 --> Loader Class Initialized
INFO - 2017-01-20 09:26:16 --> Helper loaded: url_helper
INFO - 2017-01-20 09:26:16 --> Helper loaded: language_helper
INFO - 2017-01-20 09:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:26:16 --> Controller Class Initialized
INFO - 2017-01-20 09:26:16 --> Database Driver Class Initialized
INFO - 2017-01-20 09:26:16 --> Model Class Initialized
INFO - 2017-01-20 09:26:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:26:16 --> Helper loaded: form_helper
INFO - 2017-01-20 09:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:26:16 --> Final output sent to browser
DEBUG - 2017-01-20 09:26:16 --> Total execution time: 0.1088
INFO - 2017-01-20 09:27:07 --> Config Class Initialized
INFO - 2017-01-20 09:27:07 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:27:07 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:27:07 --> Utf8 Class Initialized
INFO - 2017-01-20 09:27:07 --> URI Class Initialized
INFO - 2017-01-20 09:27:07 --> Router Class Initialized
INFO - 2017-01-20 09:27:08 --> Output Class Initialized
INFO - 2017-01-20 09:27:08 --> Security Class Initialized
DEBUG - 2017-01-20 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:27:08 --> Input Class Initialized
INFO - 2017-01-20 09:27:08 --> Language Class Initialized
INFO - 2017-01-20 09:27:08 --> Loader Class Initialized
INFO - 2017-01-20 09:27:08 --> Helper loaded: url_helper
INFO - 2017-01-20 09:27:08 --> Helper loaded: language_helper
INFO - 2017-01-20 09:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:27:08 --> Controller Class Initialized
INFO - 2017-01-20 09:27:08 --> Database Driver Class Initialized
INFO - 2017-01-20 09:27:08 --> Model Class Initialized
INFO - 2017-01-20 09:27:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:27:08 --> Helper loaded: form_helper
INFO - 2017-01-20 09:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:27:08 --> Final output sent to browser
DEBUG - 2017-01-20 09:27:08 --> Total execution time: 0.0943
INFO - 2017-01-20 09:27:09 --> Config Class Initialized
INFO - 2017-01-20 09:27:09 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:27:09 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:27:09 --> Utf8 Class Initialized
INFO - 2017-01-20 09:27:09 --> URI Class Initialized
INFO - 2017-01-20 09:27:09 --> Router Class Initialized
INFO - 2017-01-20 09:27:09 --> Output Class Initialized
INFO - 2017-01-20 09:27:09 --> Security Class Initialized
DEBUG - 2017-01-20 09:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:27:09 --> Input Class Initialized
INFO - 2017-01-20 09:27:09 --> Language Class Initialized
INFO - 2017-01-20 09:27:09 --> Loader Class Initialized
INFO - 2017-01-20 09:27:09 --> Helper loaded: url_helper
INFO - 2017-01-20 09:27:09 --> Helper loaded: language_helper
INFO - 2017-01-20 09:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:27:09 --> Controller Class Initialized
INFO - 2017-01-20 09:27:09 --> Database Driver Class Initialized
INFO - 2017-01-20 09:27:09 --> Model Class Initialized
INFO - 2017-01-20 09:27:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:27:09 --> Helper loaded: form_helper
INFO - 2017-01-20 09:27:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:27:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:27:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:27:09 --> Final output sent to browser
DEBUG - 2017-01-20 09:27:09 --> Total execution time: 0.1204
INFO - 2017-01-20 09:27:12 --> Config Class Initialized
INFO - 2017-01-20 09:27:12 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:27:12 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:27:12 --> Utf8 Class Initialized
INFO - 2017-01-20 09:27:12 --> URI Class Initialized
INFO - 2017-01-20 09:27:12 --> Router Class Initialized
INFO - 2017-01-20 09:27:12 --> Output Class Initialized
INFO - 2017-01-20 09:27:12 --> Security Class Initialized
DEBUG - 2017-01-20 09:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:27:12 --> Input Class Initialized
INFO - 2017-01-20 09:27:12 --> Language Class Initialized
INFO - 2017-01-20 09:27:12 --> Loader Class Initialized
INFO - 2017-01-20 09:27:12 --> Helper loaded: url_helper
INFO - 2017-01-20 09:27:12 --> Helper loaded: language_helper
INFO - 2017-01-20 09:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:27:12 --> Controller Class Initialized
INFO - 2017-01-20 09:27:12 --> Database Driver Class Initialized
INFO - 2017-01-20 09:27:12 --> Model Class Initialized
INFO - 2017-01-20 09:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:27:12 --> Helper loaded: form_helper
INFO - 2017-01-20 09:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:27:12 --> Final output sent to browser
DEBUG - 2017-01-20 09:27:12 --> Total execution time: 0.0955
INFO - 2017-01-20 09:27:13 --> Config Class Initialized
INFO - 2017-01-20 09:27:13 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:27:13 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:27:13 --> Utf8 Class Initialized
INFO - 2017-01-20 09:27:13 --> URI Class Initialized
INFO - 2017-01-20 09:27:13 --> Router Class Initialized
INFO - 2017-01-20 09:27:13 --> Output Class Initialized
INFO - 2017-01-20 09:27:13 --> Security Class Initialized
DEBUG - 2017-01-20 09:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:27:13 --> Input Class Initialized
INFO - 2017-01-20 09:27:13 --> Language Class Initialized
INFO - 2017-01-20 09:27:13 --> Loader Class Initialized
INFO - 2017-01-20 09:27:13 --> Helper loaded: url_helper
INFO - 2017-01-20 09:27:13 --> Helper loaded: language_helper
INFO - 2017-01-20 09:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:27:13 --> Controller Class Initialized
INFO - 2017-01-20 09:27:13 --> Database Driver Class Initialized
INFO - 2017-01-20 09:27:13 --> Model Class Initialized
INFO - 2017-01-20 09:27:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:27:13 --> Helper loaded: form_helper
INFO - 2017-01-20 09:27:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:27:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:27:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:27:13 --> Final output sent to browser
DEBUG - 2017-01-20 09:27:13 --> Total execution time: 0.1108
INFO - 2017-01-20 09:27:15 --> Config Class Initialized
INFO - 2017-01-20 09:27:15 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:27:15 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:27:15 --> Utf8 Class Initialized
INFO - 2017-01-20 09:27:15 --> URI Class Initialized
INFO - 2017-01-20 09:27:15 --> Router Class Initialized
INFO - 2017-01-20 09:27:15 --> Output Class Initialized
INFO - 2017-01-20 09:27:15 --> Security Class Initialized
DEBUG - 2017-01-20 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:27:15 --> Input Class Initialized
INFO - 2017-01-20 09:27:15 --> Language Class Initialized
INFO - 2017-01-20 09:27:15 --> Loader Class Initialized
INFO - 2017-01-20 09:27:15 --> Helper loaded: url_helper
INFO - 2017-01-20 09:27:15 --> Helper loaded: language_helper
INFO - 2017-01-20 09:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:27:15 --> Controller Class Initialized
INFO - 2017-01-20 09:27:15 --> Database Driver Class Initialized
INFO - 2017-01-20 09:27:15 --> Model Class Initialized
INFO - 2017-01-20 09:27:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:27:15 --> Helper loaded: form_helper
INFO - 2017-01-20 09:27:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:27:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 09:27:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:27:15 --> Final output sent to browser
DEBUG - 2017-01-20 09:27:15 --> Total execution time: 0.1222
INFO - 2017-01-20 09:28:29 --> Config Class Initialized
INFO - 2017-01-20 09:28:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:28:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:28:29 --> Utf8 Class Initialized
INFO - 2017-01-20 09:28:29 --> URI Class Initialized
INFO - 2017-01-20 09:28:29 --> Router Class Initialized
INFO - 2017-01-20 09:28:29 --> Output Class Initialized
INFO - 2017-01-20 09:28:29 --> Security Class Initialized
DEBUG - 2017-01-20 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:28:29 --> Input Class Initialized
INFO - 2017-01-20 09:28:29 --> Language Class Initialized
INFO - 2017-01-20 09:28:29 --> Loader Class Initialized
INFO - 2017-01-20 09:28:29 --> Helper loaded: url_helper
INFO - 2017-01-20 09:28:29 --> Helper loaded: language_helper
INFO - 2017-01-20 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:28:29 --> Controller Class Initialized
INFO - 2017-01-20 09:28:29 --> Database Driver Class Initialized
INFO - 2017-01-20 09:28:29 --> Model Class Initialized
INFO - 2017-01-20 09:28:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:28:29 --> Helper loaded: form_helper
INFO - 2017-01-20 09:28:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:28:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:28:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:28:29 --> Final output sent to browser
DEBUG - 2017-01-20 09:28:29 --> Total execution time: 0.0908
INFO - 2017-01-20 09:28:32 --> Config Class Initialized
INFO - 2017-01-20 09:28:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:28:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:28:32 --> Utf8 Class Initialized
INFO - 2017-01-20 09:28:32 --> URI Class Initialized
INFO - 2017-01-20 09:28:32 --> Router Class Initialized
INFO - 2017-01-20 09:28:32 --> Output Class Initialized
INFO - 2017-01-20 09:28:32 --> Security Class Initialized
DEBUG - 2017-01-20 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:28:32 --> Input Class Initialized
INFO - 2017-01-20 09:28:32 --> Language Class Initialized
INFO - 2017-01-20 09:28:32 --> Loader Class Initialized
INFO - 2017-01-20 09:28:32 --> Helper loaded: url_helper
INFO - 2017-01-20 09:28:32 --> Helper loaded: language_helper
INFO - 2017-01-20 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:28:32 --> Controller Class Initialized
INFO - 2017-01-20 09:28:32 --> Database Driver Class Initialized
INFO - 2017-01-20 09:28:32 --> Model Class Initialized
INFO - 2017-01-20 09:28:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:28:32 --> Helper loaded: form_helper
INFO - 2017-01-20 09:28:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:28:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:28:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:28:32 --> Final output sent to browser
DEBUG - 2017-01-20 09:28:32 --> Total execution time: 0.1085
INFO - 2017-01-20 09:28:34 --> Config Class Initialized
INFO - 2017-01-20 09:28:34 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:28:34 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:28:34 --> Utf8 Class Initialized
INFO - 2017-01-20 09:28:34 --> URI Class Initialized
INFO - 2017-01-20 09:28:34 --> Router Class Initialized
INFO - 2017-01-20 09:28:34 --> Output Class Initialized
INFO - 2017-01-20 09:28:34 --> Security Class Initialized
DEBUG - 2017-01-20 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:28:34 --> Input Class Initialized
INFO - 2017-01-20 09:28:34 --> Language Class Initialized
INFO - 2017-01-20 09:28:34 --> Loader Class Initialized
INFO - 2017-01-20 09:28:34 --> Helper loaded: url_helper
INFO - 2017-01-20 09:28:34 --> Helper loaded: language_helper
INFO - 2017-01-20 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:28:34 --> Controller Class Initialized
INFO - 2017-01-20 09:28:34 --> Database Driver Class Initialized
INFO - 2017-01-20 09:28:34 --> Model Class Initialized
INFO - 2017-01-20 09:28:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:28:34 --> Helper loaded: form_helper
INFO - 2017-01-20 09:28:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:28:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:28:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:28:34 --> Final output sent to browser
DEBUG - 2017-01-20 09:28:34 --> Total execution time: 0.1064
INFO - 2017-01-20 09:28:35 --> Config Class Initialized
INFO - 2017-01-20 09:28:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:28:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:28:35 --> Utf8 Class Initialized
INFO - 2017-01-20 09:28:35 --> URI Class Initialized
INFO - 2017-01-20 09:28:35 --> Router Class Initialized
INFO - 2017-01-20 09:28:35 --> Output Class Initialized
INFO - 2017-01-20 09:28:35 --> Security Class Initialized
DEBUG - 2017-01-20 09:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:28:35 --> Input Class Initialized
INFO - 2017-01-20 09:28:35 --> Language Class Initialized
INFO - 2017-01-20 09:28:35 --> Loader Class Initialized
INFO - 2017-01-20 09:28:35 --> Helper loaded: url_helper
INFO - 2017-01-20 09:28:35 --> Helper loaded: language_helper
INFO - 2017-01-20 09:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:28:35 --> Controller Class Initialized
INFO - 2017-01-20 09:28:35 --> Database Driver Class Initialized
INFO - 2017-01-20 09:28:35 --> Model Class Initialized
INFO - 2017-01-20 09:28:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:28:35 --> Helper loaded: form_helper
INFO - 2017-01-20 09:28:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:28:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:28:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:28:35 --> Final output sent to browser
DEBUG - 2017-01-20 09:28:35 --> Total execution time: 0.0964
INFO - 2017-01-20 09:28:38 --> Config Class Initialized
INFO - 2017-01-20 09:28:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:28:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:28:38 --> Utf8 Class Initialized
INFO - 2017-01-20 09:28:38 --> URI Class Initialized
INFO - 2017-01-20 09:28:38 --> Router Class Initialized
INFO - 2017-01-20 09:28:38 --> Output Class Initialized
INFO - 2017-01-20 09:28:38 --> Security Class Initialized
DEBUG - 2017-01-20 09:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:28:38 --> Input Class Initialized
INFO - 2017-01-20 09:28:38 --> Language Class Initialized
INFO - 2017-01-20 09:28:38 --> Loader Class Initialized
INFO - 2017-01-20 09:28:38 --> Helper loaded: url_helper
INFO - 2017-01-20 09:28:38 --> Helper loaded: language_helper
INFO - 2017-01-20 09:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:28:38 --> Controller Class Initialized
INFO - 2017-01-20 09:28:38 --> Database Driver Class Initialized
INFO - 2017-01-20 09:28:38 --> Model Class Initialized
INFO - 2017-01-20 09:28:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:28:38 --> Helper loaded: form_helper
INFO - 2017-01-20 09:28:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:28:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:28:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:28:38 --> Final output sent to browser
DEBUG - 2017-01-20 09:28:38 --> Total execution time: 0.0962
INFO - 2017-01-20 09:28:41 --> Config Class Initialized
INFO - 2017-01-20 09:28:41 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:28:41 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:28:41 --> Utf8 Class Initialized
INFO - 2017-01-20 09:28:41 --> URI Class Initialized
INFO - 2017-01-20 09:28:41 --> Router Class Initialized
INFO - 2017-01-20 09:28:41 --> Output Class Initialized
INFO - 2017-01-20 09:28:41 --> Security Class Initialized
DEBUG - 2017-01-20 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:28:41 --> Input Class Initialized
INFO - 2017-01-20 09:28:41 --> Language Class Initialized
INFO - 2017-01-20 09:28:41 --> Loader Class Initialized
INFO - 2017-01-20 09:28:41 --> Helper loaded: url_helper
INFO - 2017-01-20 09:28:41 --> Helper loaded: language_helper
INFO - 2017-01-20 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:28:41 --> Controller Class Initialized
INFO - 2017-01-20 09:28:41 --> Database Driver Class Initialized
INFO - 2017-01-20 09:28:41 --> Model Class Initialized
INFO - 2017-01-20 09:28:41 --> Model Class Initialized
INFO - 2017-01-20 09:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:28:41 --> Helper loaded: form_helper
INFO - 2017-01-20 09:28:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:28:42 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:28:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:28:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:28:42 --> Final output sent to browser
DEBUG - 2017-01-20 09:28:42 --> Total execution time: 0.0810
INFO - 2017-01-20 09:41:27 --> Config Class Initialized
INFO - 2017-01-20 09:41:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:41:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:41:27 --> Utf8 Class Initialized
INFO - 2017-01-20 09:41:27 --> URI Class Initialized
INFO - 2017-01-20 09:41:27 --> Router Class Initialized
INFO - 2017-01-20 09:41:27 --> Output Class Initialized
INFO - 2017-01-20 09:41:27 --> Security Class Initialized
DEBUG - 2017-01-20 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:41:27 --> Input Class Initialized
INFO - 2017-01-20 09:41:27 --> Language Class Initialized
INFO - 2017-01-20 09:41:27 --> Loader Class Initialized
INFO - 2017-01-20 09:41:27 --> Helper loaded: url_helper
INFO - 2017-01-20 09:41:27 --> Helper loaded: language_helper
INFO - 2017-01-20 09:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:41:27 --> Controller Class Initialized
INFO - 2017-01-20 09:41:27 --> Database Driver Class Initialized
INFO - 2017-01-20 09:41:27 --> Model Class Initialized
INFO - 2017-01-20 09:41:27 --> Model Class Initialized
INFO - 2017-01-20 09:41:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:41:27 --> Helper loaded: form_helper
INFO - 2017-01-20 09:41:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-20 09:41:27 --> Could not find the language line "import_user"
INFO - 2017-01-20 09:41:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-20 09:41:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:41:27 --> Final output sent to browser
DEBUG - 2017-01-20 09:41:27 --> Total execution time: 0.0963
INFO - 2017-01-20 09:41:31 --> Config Class Initialized
INFO - 2017-01-20 09:41:31 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:41:31 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:41:31 --> Utf8 Class Initialized
INFO - 2017-01-20 09:41:31 --> URI Class Initialized
INFO - 2017-01-20 09:41:31 --> Router Class Initialized
INFO - 2017-01-20 09:41:31 --> Output Class Initialized
INFO - 2017-01-20 09:41:31 --> Security Class Initialized
DEBUG - 2017-01-20 09:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:41:31 --> Input Class Initialized
INFO - 2017-01-20 09:41:31 --> Language Class Initialized
INFO - 2017-01-20 09:41:31 --> Loader Class Initialized
INFO - 2017-01-20 09:41:31 --> Helper loaded: url_helper
INFO - 2017-01-20 09:41:31 --> Helper loaded: language_helper
INFO - 2017-01-20 09:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:41:31 --> Controller Class Initialized
INFO - 2017-01-20 09:41:31 --> Database Driver Class Initialized
INFO - 2017-01-20 09:41:31 --> Model Class Initialized
INFO - 2017-01-20 09:41:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:41:31 --> Helper loaded: form_helper
INFO - 2017-01-20 09:41:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:41:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:41:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:41:31 --> Final output sent to browser
DEBUG - 2017-01-20 09:41:31 --> Total execution time: 0.0997
INFO - 2017-01-20 09:43:34 --> Config Class Initialized
INFO - 2017-01-20 09:43:34 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:43:34 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:43:34 --> Utf8 Class Initialized
INFO - 2017-01-20 09:43:34 --> URI Class Initialized
INFO - 2017-01-20 09:43:34 --> Router Class Initialized
INFO - 2017-01-20 09:43:34 --> Output Class Initialized
INFO - 2017-01-20 09:43:34 --> Security Class Initialized
DEBUG - 2017-01-20 09:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:43:34 --> Input Class Initialized
INFO - 2017-01-20 09:43:34 --> Language Class Initialized
INFO - 2017-01-20 09:43:34 --> Loader Class Initialized
INFO - 2017-01-20 09:43:34 --> Helper loaded: url_helper
INFO - 2017-01-20 09:43:34 --> Helper loaded: language_helper
INFO - 2017-01-20 09:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:43:34 --> Controller Class Initialized
INFO - 2017-01-20 09:43:34 --> Database Driver Class Initialized
INFO - 2017-01-20 09:43:34 --> Model Class Initialized
INFO - 2017-01-20 09:43:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:43:34 --> Helper loaded: form_helper
INFO - 2017-01-20 09:43:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:43:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:43:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:43:34 --> Final output sent to browser
DEBUG - 2017-01-20 09:43:34 --> Total execution time: 0.1092
INFO - 2017-01-20 09:46:04 --> Config Class Initialized
INFO - 2017-01-20 09:46:04 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:05 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:05 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:05 --> URI Class Initialized
INFO - 2017-01-20 09:46:05 --> Router Class Initialized
INFO - 2017-01-20 09:46:05 --> Output Class Initialized
INFO - 2017-01-20 09:46:05 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:05 --> Input Class Initialized
INFO - 2017-01-20 09:46:05 --> Language Class Initialized
INFO - 2017-01-20 09:46:05 --> Loader Class Initialized
INFO - 2017-01-20 09:46:05 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:05 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:05 --> Controller Class Initialized
INFO - 2017-01-20 09:46:05 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:05 --> Model Class Initialized
INFO - 2017-01-20 09:46:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:05 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:46:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:05 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:05 --> Total execution time: 0.1977
INFO - 2017-01-20 09:46:17 --> Config Class Initialized
INFO - 2017-01-20 09:46:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:17 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:17 --> URI Class Initialized
INFO - 2017-01-20 09:46:17 --> Router Class Initialized
INFO - 2017-01-20 09:46:17 --> Output Class Initialized
INFO - 2017-01-20 09:46:17 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:17 --> Input Class Initialized
INFO - 2017-01-20 09:46:17 --> Language Class Initialized
INFO - 2017-01-20 09:46:17 --> Loader Class Initialized
INFO - 2017-01-20 09:46:17 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:17 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:17 --> Controller Class Initialized
INFO - 2017-01-20 09:46:17 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:17 --> Model Class Initialized
INFO - 2017-01-20 09:46:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:17 --> Model Class Initialized
INFO - 2017-01-20 09:46:17 --> Model Class Initialized
INFO - 2017-01-20 09:46:17 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-20 09:46:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:17 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:17 --> Total execution time: 0.1562
INFO - 2017-01-20 09:46:23 --> Config Class Initialized
INFO - 2017-01-20 09:46:23 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:23 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:23 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:23 --> URI Class Initialized
INFO - 2017-01-20 09:46:23 --> Router Class Initialized
INFO - 2017-01-20 09:46:23 --> Output Class Initialized
INFO - 2017-01-20 09:46:23 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:23 --> Input Class Initialized
INFO - 2017-01-20 09:46:23 --> Language Class Initialized
INFO - 2017-01-20 09:46:23 --> Loader Class Initialized
INFO - 2017-01-20 09:46:23 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:23 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:23 --> Controller Class Initialized
INFO - 2017-01-20 09:46:23 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:23 --> Model Class Initialized
INFO - 2017-01-20 09:46:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:23 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:46:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:23 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:23 --> Total execution time: 0.1848
INFO - 2017-01-20 09:46:26 --> Config Class Initialized
INFO - 2017-01-20 09:46:26 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:26 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:26 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:26 --> URI Class Initialized
INFO - 2017-01-20 09:46:26 --> Router Class Initialized
INFO - 2017-01-20 09:46:26 --> Output Class Initialized
INFO - 2017-01-20 09:46:26 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:26 --> Input Class Initialized
INFO - 2017-01-20 09:46:26 --> Language Class Initialized
INFO - 2017-01-20 09:46:26 --> Loader Class Initialized
INFO - 2017-01-20 09:46:26 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:26 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:26 --> Controller Class Initialized
INFO - 2017-01-20 09:46:26 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:26 --> Model Class Initialized
INFO - 2017-01-20 09:46:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:26 --> Model Class Initialized
INFO - 2017-01-20 09:46:26 --> Model Class Initialized
INFO - 2017-01-20 09:46:26 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-20 09:46:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:26 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:26 --> Total execution time: 0.1449
INFO - 2017-01-20 09:46:30 --> Config Class Initialized
INFO - 2017-01-20 09:46:30 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:30 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:30 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:30 --> URI Class Initialized
INFO - 2017-01-20 09:46:30 --> Router Class Initialized
INFO - 2017-01-20 09:46:30 --> Output Class Initialized
INFO - 2017-01-20 09:46:30 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:30 --> Input Class Initialized
INFO - 2017-01-20 09:46:30 --> Language Class Initialized
INFO - 2017-01-20 09:46:30 --> Loader Class Initialized
INFO - 2017-01-20 09:46:30 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:30 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:30 --> Controller Class Initialized
INFO - 2017-01-20 09:46:30 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:30 --> Model Class Initialized
INFO - 2017-01-20 09:46:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:30 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:46:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:30 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:30 --> Total execution time: 0.1832
INFO - 2017-01-20 09:46:32 --> Config Class Initialized
INFO - 2017-01-20 09:46:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:32 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:32 --> URI Class Initialized
INFO - 2017-01-20 09:46:32 --> Router Class Initialized
INFO - 2017-01-20 09:46:32 --> Output Class Initialized
INFO - 2017-01-20 09:46:32 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:32 --> Input Class Initialized
INFO - 2017-01-20 09:46:32 --> Language Class Initialized
INFO - 2017-01-20 09:46:32 --> Loader Class Initialized
INFO - 2017-01-20 09:46:32 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:32 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:32 --> Controller Class Initialized
INFO - 2017-01-20 09:46:32 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:32 --> Model Class Initialized
INFO - 2017-01-20 09:46:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:32 --> Model Class Initialized
INFO - 2017-01-20 09:46:32 --> Model Class Initialized
INFO - 2017-01-20 09:46:32 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-20 09:46:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:32 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:32 --> Total execution time: 0.1459
INFO - 2017-01-20 09:46:37 --> Config Class Initialized
INFO - 2017-01-20 09:46:37 --> Hooks Class Initialized
DEBUG - 2017-01-20 09:46:37 --> UTF-8 Support Enabled
INFO - 2017-01-20 09:46:37 --> Utf8 Class Initialized
INFO - 2017-01-20 09:46:37 --> URI Class Initialized
INFO - 2017-01-20 09:46:37 --> Router Class Initialized
INFO - 2017-01-20 09:46:37 --> Output Class Initialized
INFO - 2017-01-20 09:46:37 --> Security Class Initialized
DEBUG - 2017-01-20 09:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 09:46:37 --> Input Class Initialized
INFO - 2017-01-20 09:46:37 --> Language Class Initialized
INFO - 2017-01-20 09:46:37 --> Loader Class Initialized
INFO - 2017-01-20 09:46:37 --> Helper loaded: url_helper
INFO - 2017-01-20 09:46:37 --> Helper loaded: language_helper
INFO - 2017-01-20 09:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 09:46:37 --> Controller Class Initialized
INFO - 2017-01-20 09:46:37 --> Database Driver Class Initialized
INFO - 2017-01-20 09:46:37 --> Model Class Initialized
INFO - 2017-01-20 09:46:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 09:46:37 --> Helper loaded: form_helper
INFO - 2017-01-20 09:46:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 09:46:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 09:46:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 09:46:37 --> Final output sent to browser
DEBUG - 2017-01-20 09:46:37 --> Total execution time: 0.1771
INFO - 2017-01-20 10:13:01 --> Config Class Initialized
INFO - 2017-01-20 10:13:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 10:13:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 10:13:01 --> Utf8 Class Initialized
INFO - 2017-01-20 10:13:01 --> URI Class Initialized
INFO - 2017-01-20 10:13:01 --> Router Class Initialized
INFO - 2017-01-20 10:13:01 --> Output Class Initialized
INFO - 2017-01-20 10:13:01 --> Security Class Initialized
DEBUG - 2017-01-20 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 10:13:01 --> Input Class Initialized
INFO - 2017-01-20 10:13:01 --> Language Class Initialized
INFO - 2017-01-20 10:13:01 --> Loader Class Initialized
INFO - 2017-01-20 10:13:01 --> Helper loaded: url_helper
INFO - 2017-01-20 10:13:01 --> Helper loaded: language_helper
INFO - 2017-01-20 10:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 10:13:01 --> Controller Class Initialized
INFO - 2017-01-20 10:13:01 --> Database Driver Class Initialized
INFO - 2017-01-20 10:13:01 --> Model Class Initialized
INFO - 2017-01-20 10:13:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 10:13:01 --> Helper loaded: form_helper
INFO - 2017-01-20 10:13:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 10:13:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 10:13:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 10:13:02 --> Final output sent to browser
DEBUG - 2017-01-20 10:13:02 --> Total execution time: 0.2541
INFO - 2017-01-20 10:13:08 --> Config Class Initialized
INFO - 2017-01-20 10:13:08 --> Hooks Class Initialized
DEBUG - 2017-01-20 10:13:08 --> UTF-8 Support Enabled
INFO - 2017-01-20 10:13:08 --> Utf8 Class Initialized
INFO - 2017-01-20 10:13:08 --> URI Class Initialized
INFO - 2017-01-20 10:13:08 --> Router Class Initialized
INFO - 2017-01-20 10:13:08 --> Output Class Initialized
INFO - 2017-01-20 10:13:08 --> Security Class Initialized
DEBUG - 2017-01-20 10:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 10:13:08 --> Input Class Initialized
INFO - 2017-01-20 10:13:08 --> Language Class Initialized
INFO - 2017-01-20 10:13:08 --> Loader Class Initialized
INFO - 2017-01-20 10:13:08 --> Helper loaded: url_helper
INFO - 2017-01-20 10:13:08 --> Helper loaded: language_helper
INFO - 2017-01-20 10:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 10:13:08 --> Controller Class Initialized
INFO - 2017-01-20 10:13:08 --> Database Driver Class Initialized
INFO - 2017-01-20 10:13:08 --> Model Class Initialized
INFO - 2017-01-20 10:13:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 10:13:08 --> Model Class Initialized
INFO - 2017-01-20 10:13:08 --> Model Class Initialized
INFO - 2017-01-20 10:13:08 --> Helper loaded: form_helper
INFO - 2017-01-20 10:13:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 10:13:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-20 10:13:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 10:13:09 --> Final output sent to browser
DEBUG - 2017-01-20 10:13:09 --> Total execution time: 0.1941
INFO - 2017-01-20 10:13:29 --> Config Class Initialized
INFO - 2017-01-20 10:13:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 10:13:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 10:13:29 --> Utf8 Class Initialized
INFO - 2017-01-20 10:13:29 --> URI Class Initialized
INFO - 2017-01-20 10:13:29 --> Router Class Initialized
INFO - 2017-01-20 10:13:29 --> Output Class Initialized
INFO - 2017-01-20 10:13:29 --> Security Class Initialized
DEBUG - 2017-01-20 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 10:13:29 --> Input Class Initialized
INFO - 2017-01-20 10:13:29 --> Language Class Initialized
INFO - 2017-01-20 10:13:29 --> Loader Class Initialized
INFO - 2017-01-20 10:13:29 --> Helper loaded: url_helper
INFO - 2017-01-20 10:13:29 --> Helper loaded: language_helper
INFO - 2017-01-20 10:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 10:13:29 --> Controller Class Initialized
INFO - 2017-01-20 10:13:29 --> Database Driver Class Initialized
INFO - 2017-01-20 10:13:29 --> Model Class Initialized
INFO - 2017-01-20 10:13:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 10:13:29 --> Helper loaded: form_helper
INFO - 2017-01-20 10:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 10:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 10:13:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 10:13:29 --> Final output sent to browser
DEBUG - 2017-01-20 10:13:29 --> Total execution time: 0.2142
INFO - 2017-01-20 10:13:32 --> Config Class Initialized
INFO - 2017-01-20 10:13:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 10:13:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 10:13:32 --> Utf8 Class Initialized
INFO - 2017-01-20 10:13:32 --> URI Class Initialized
INFO - 2017-01-20 10:13:32 --> Router Class Initialized
INFO - 2017-01-20 10:13:32 --> Output Class Initialized
INFO - 2017-01-20 10:13:32 --> Security Class Initialized
DEBUG - 2017-01-20 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 10:13:32 --> Input Class Initialized
INFO - 2017-01-20 10:13:32 --> Language Class Initialized
INFO - 2017-01-20 10:13:32 --> Loader Class Initialized
INFO - 2017-01-20 10:13:32 --> Helper loaded: url_helper
INFO - 2017-01-20 10:13:32 --> Helper loaded: language_helper
INFO - 2017-01-20 10:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 10:13:33 --> Controller Class Initialized
INFO - 2017-01-20 10:13:33 --> Database Driver Class Initialized
INFO - 2017-01-20 10:13:33 --> Model Class Initialized
INFO - 2017-01-20 10:13:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 10:13:33 --> Model Class Initialized
INFO - 2017-01-20 10:13:33 --> Model Class Initialized
INFO - 2017-01-20 10:13:33 --> Helper loaded: form_helper
INFO - 2017-01-20 10:13:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 10:13:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-20 10:13:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 10:13:33 --> Final output sent to browser
DEBUG - 2017-01-20 10:13:33 --> Total execution time: 0.1982
INFO - 2017-01-20 10:15:32 --> Config Class Initialized
INFO - 2017-01-20 10:15:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 10:15:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 10:15:32 --> Utf8 Class Initialized
INFO - 2017-01-20 10:15:32 --> URI Class Initialized
INFO - 2017-01-20 10:15:32 --> Router Class Initialized
INFO - 2017-01-20 10:15:32 --> Output Class Initialized
INFO - 2017-01-20 10:15:32 --> Security Class Initialized
DEBUG - 2017-01-20 10:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 10:15:32 --> Input Class Initialized
INFO - 2017-01-20 10:15:32 --> Language Class Initialized
INFO - 2017-01-20 10:15:32 --> Loader Class Initialized
INFO - 2017-01-20 10:15:32 --> Helper loaded: url_helper
INFO - 2017-01-20 10:15:32 --> Helper loaded: language_helper
INFO - 2017-01-20 10:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 10:15:32 --> Controller Class Initialized
INFO - 2017-01-20 10:15:32 --> Database Driver Class Initialized
INFO - 2017-01-20 10:15:32 --> Model Class Initialized
INFO - 2017-01-20 10:15:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 10:15:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 10:15:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2017-01-20 10:15:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 10:15:32 --> Final output sent to browser
DEBUG - 2017-01-20 10:15:32 --> Total execution time: 0.1437
INFO - 2017-01-20 12:00:02 --> Config Class Initialized
INFO - 2017-01-20 12:00:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 12:00:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 12:00:02 --> Utf8 Class Initialized
INFO - 2017-01-20 12:00:02 --> URI Class Initialized
INFO - 2017-01-20 12:00:02 --> Router Class Initialized
INFO - 2017-01-20 12:00:02 --> Output Class Initialized
INFO - 2017-01-20 12:00:02 --> Security Class Initialized
DEBUG - 2017-01-20 12:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 12:00:02 --> Input Class Initialized
INFO - 2017-01-20 12:00:02 --> Language Class Initialized
INFO - 2017-01-20 12:00:02 --> Loader Class Initialized
INFO - 2017-01-20 12:00:02 --> Helper loaded: url_helper
INFO - 2017-01-20 12:00:02 --> Helper loaded: language_helper
INFO - 2017-01-20 12:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 12:00:02 --> Controller Class Initialized
INFO - 2017-01-20 12:00:02 --> Database Driver Class Initialized
INFO - 2017-01-20 12:00:02 --> Model Class Initialized
INFO - 2017-01-20 12:00:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 12:00:02 --> Helper loaded: form_helper
INFO - 2017-01-20 12:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 12:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-01-20 12:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 12:00:02 --> Final output sent to browser
DEBUG - 2017-01-20 12:00:02 --> Total execution time: 0.1606
INFO - 2017-01-20 13:00:47 --> Config Class Initialized
INFO - 2017-01-20 13:00:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:00:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:00:47 --> Utf8 Class Initialized
INFO - 2017-01-20 13:00:47 --> URI Class Initialized
INFO - 2017-01-20 13:00:47 --> Router Class Initialized
INFO - 2017-01-20 13:00:47 --> Output Class Initialized
INFO - 2017-01-20 13:00:47 --> Security Class Initialized
DEBUG - 2017-01-20 13:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:00:47 --> Input Class Initialized
INFO - 2017-01-20 13:00:47 --> Language Class Initialized
INFO - 2017-01-20 13:00:47 --> Loader Class Initialized
INFO - 2017-01-20 13:00:47 --> Helper loaded: url_helper
INFO - 2017-01-20 13:00:47 --> Helper loaded: language_helper
INFO - 2017-01-20 13:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:00:47 --> Controller Class Initialized
INFO - 2017-01-20 13:00:47 --> Database Driver Class Initialized
INFO - 2017-01-20 13:00:47 --> Model Class Initialized
INFO - 2017-01-20 13:00:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:00:47 --> Helper loaded: form_helper
INFO - 2017-01-20 13:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:00:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:00:47 --> Final output sent to browser
DEBUG - 2017-01-20 13:00:47 --> Total execution time: 0.2463
INFO - 2017-01-20 13:01:19 --> Config Class Initialized
INFO - 2017-01-20 13:01:19 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:19 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:19 --> URI Class Initialized
INFO - 2017-01-20 13:01:19 --> Router Class Initialized
INFO - 2017-01-20 13:01:19 --> Output Class Initialized
INFO - 2017-01-20 13:01:19 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:19 --> Input Class Initialized
INFO - 2017-01-20 13:01:19 --> Language Class Initialized
INFO - 2017-01-20 13:01:19 --> Loader Class Initialized
INFO - 2017-01-20 13:01:19 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:19 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:19 --> Controller Class Initialized
INFO - 2017-01-20 13:01:19 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:19 --> Model Class Initialized
INFO - 2017-01-20 13:01:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:19 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:01:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:19 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:19 --> Total execution time: 0.2456
INFO - 2017-01-20 13:01:22 --> Config Class Initialized
INFO - 2017-01-20 13:01:22 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:22 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:22 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:22 --> URI Class Initialized
INFO - 2017-01-20 13:01:22 --> Router Class Initialized
INFO - 2017-01-20 13:01:22 --> Output Class Initialized
INFO - 2017-01-20 13:01:22 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:22 --> Input Class Initialized
INFO - 2017-01-20 13:01:22 --> Language Class Initialized
INFO - 2017-01-20 13:01:22 --> Loader Class Initialized
INFO - 2017-01-20 13:01:22 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:22 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:22 --> Controller Class Initialized
INFO - 2017-01-20 13:01:22 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:22 --> Model Class Initialized
INFO - 2017-01-20 13:01:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:22 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:01:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:22 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:22 --> Total execution time: 0.2376
INFO - 2017-01-20 13:01:25 --> Config Class Initialized
INFO - 2017-01-20 13:01:25 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:25 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:25 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:25 --> URI Class Initialized
INFO - 2017-01-20 13:01:25 --> Router Class Initialized
INFO - 2017-01-20 13:01:25 --> Output Class Initialized
INFO - 2017-01-20 13:01:25 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:25 --> Input Class Initialized
INFO - 2017-01-20 13:01:25 --> Language Class Initialized
INFO - 2017-01-20 13:01:25 --> Loader Class Initialized
INFO - 2017-01-20 13:01:25 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:25 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:25 --> Controller Class Initialized
INFO - 2017-01-20 13:01:25 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:25 --> Model Class Initialized
INFO - 2017-01-20 13:01:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:25 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:01:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:25 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:25 --> Total execution time: 0.2734
INFO - 2017-01-20 13:01:42 --> Config Class Initialized
INFO - 2017-01-20 13:01:42 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:42 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:42 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:42 --> URI Class Initialized
INFO - 2017-01-20 13:01:42 --> Router Class Initialized
INFO - 2017-01-20 13:01:42 --> Output Class Initialized
INFO - 2017-01-20 13:01:42 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:42 --> Input Class Initialized
INFO - 2017-01-20 13:01:42 --> Language Class Initialized
INFO - 2017-01-20 13:01:42 --> Loader Class Initialized
INFO - 2017-01-20 13:01:42 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:42 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:42 --> Controller Class Initialized
INFO - 2017-01-20 13:01:42 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:42 --> Model Class Initialized
INFO - 2017-01-20 13:01:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:42 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:01:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:43 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:43 --> Total execution time: 0.2795
INFO - 2017-01-20 13:01:45 --> Config Class Initialized
INFO - 2017-01-20 13:01:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:45 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:45 --> URI Class Initialized
INFO - 2017-01-20 13:01:45 --> Router Class Initialized
INFO - 2017-01-20 13:01:45 --> Output Class Initialized
INFO - 2017-01-20 13:01:45 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:45 --> Input Class Initialized
INFO - 2017-01-20 13:01:45 --> Language Class Initialized
INFO - 2017-01-20 13:01:45 --> Loader Class Initialized
INFO - 2017-01-20 13:01:45 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:45 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:45 --> Controller Class Initialized
INFO - 2017-01-20 13:01:45 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:45 --> Model Class Initialized
INFO - 2017-01-20 13:01:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:45 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:01:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:45 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:45 --> Total execution time: 0.2500
INFO - 2017-01-20 13:01:47 --> Config Class Initialized
INFO - 2017-01-20 13:01:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:47 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:47 --> URI Class Initialized
INFO - 2017-01-20 13:01:47 --> Router Class Initialized
INFO - 2017-01-20 13:01:47 --> Output Class Initialized
INFO - 2017-01-20 13:01:47 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:47 --> Input Class Initialized
INFO - 2017-01-20 13:01:47 --> Language Class Initialized
INFO - 2017-01-20 13:01:47 --> Loader Class Initialized
INFO - 2017-01-20 13:01:47 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:47 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:47 --> Controller Class Initialized
INFO - 2017-01-20 13:01:47 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:47 --> Model Class Initialized
INFO - 2017-01-20 13:01:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:47 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:01:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:48 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:48 --> Total execution time: 0.2816
INFO - 2017-01-20 13:01:51 --> Config Class Initialized
INFO - 2017-01-20 13:01:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:01:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:01:51 --> Utf8 Class Initialized
INFO - 2017-01-20 13:01:51 --> URI Class Initialized
INFO - 2017-01-20 13:01:51 --> Router Class Initialized
INFO - 2017-01-20 13:01:51 --> Output Class Initialized
INFO - 2017-01-20 13:01:51 --> Security Class Initialized
DEBUG - 2017-01-20 13:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:01:51 --> Input Class Initialized
INFO - 2017-01-20 13:01:51 --> Language Class Initialized
INFO - 2017-01-20 13:01:51 --> Loader Class Initialized
INFO - 2017-01-20 13:01:51 --> Helper loaded: url_helper
INFO - 2017-01-20 13:01:51 --> Helper loaded: language_helper
INFO - 2017-01-20 13:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:01:51 --> Controller Class Initialized
INFO - 2017-01-20 13:01:51 --> Database Driver Class Initialized
INFO - 2017-01-20 13:01:51 --> Model Class Initialized
INFO - 2017-01-20 13:01:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:01:51 --> Helper loaded: form_helper
INFO - 2017-01-20 13:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:01:51 --> Final output sent to browser
DEBUG - 2017-01-20 13:01:51 --> Total execution time: 0.1956
INFO - 2017-01-20 13:02:00 --> Config Class Initialized
INFO - 2017-01-20 13:02:00 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:00 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:00 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:00 --> URI Class Initialized
INFO - 2017-01-20 13:02:00 --> Router Class Initialized
INFO - 2017-01-20 13:02:00 --> Output Class Initialized
INFO - 2017-01-20 13:02:00 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:00 --> Input Class Initialized
INFO - 2017-01-20 13:02:00 --> Language Class Initialized
INFO - 2017-01-20 13:02:00 --> Loader Class Initialized
INFO - 2017-01-20 13:02:00 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:00 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:00 --> Controller Class Initialized
INFO - 2017-01-20 13:02:00 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:00 --> Model Class Initialized
INFO - 2017-01-20 13:02:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:00 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:02:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:00 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:00 --> Total execution time: 0.1780
INFO - 2017-01-20 13:02:03 --> Config Class Initialized
INFO - 2017-01-20 13:02:03 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:03 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:03 --> URI Class Initialized
INFO - 2017-01-20 13:02:03 --> Router Class Initialized
INFO - 2017-01-20 13:02:03 --> Output Class Initialized
INFO - 2017-01-20 13:02:03 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:03 --> Input Class Initialized
INFO - 2017-01-20 13:02:03 --> Language Class Initialized
INFO - 2017-01-20 13:02:03 --> Loader Class Initialized
INFO - 2017-01-20 13:02:03 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:03 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:04 --> Controller Class Initialized
INFO - 2017-01-20 13:02:04 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:04 --> Model Class Initialized
INFO - 2017-01-20 13:02:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:04 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:02:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:04 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:04 --> Total execution time: 0.1836
INFO - 2017-01-20 13:02:16 --> Config Class Initialized
INFO - 2017-01-20 13:02:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:16 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:16 --> URI Class Initialized
INFO - 2017-01-20 13:02:16 --> Router Class Initialized
INFO - 2017-01-20 13:02:16 --> Output Class Initialized
INFO - 2017-01-20 13:02:16 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:16 --> Input Class Initialized
INFO - 2017-01-20 13:02:16 --> Language Class Initialized
INFO - 2017-01-20 13:02:16 --> Loader Class Initialized
INFO - 2017-01-20 13:02:16 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:16 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:16 --> Controller Class Initialized
INFO - 2017-01-20 13:02:16 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:16 --> Model Class Initialized
INFO - 2017-01-20 13:02:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:16 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:02:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:17 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:17 --> Total execution time: 0.2965
INFO - 2017-01-20 13:02:19 --> Config Class Initialized
INFO - 2017-01-20 13:02:19 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:19 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:19 --> URI Class Initialized
INFO - 2017-01-20 13:02:19 --> Router Class Initialized
INFO - 2017-01-20 13:02:19 --> Output Class Initialized
INFO - 2017-01-20 13:02:19 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:19 --> Input Class Initialized
INFO - 2017-01-20 13:02:19 --> Language Class Initialized
INFO - 2017-01-20 13:02:19 --> Loader Class Initialized
INFO - 2017-01-20 13:02:19 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:19 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:19 --> Controller Class Initialized
INFO - 2017-01-20 13:02:19 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:19 --> Model Class Initialized
INFO - 2017-01-20 13:02:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:19 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:02:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:19 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:19 --> Total execution time: 0.2221
INFO - 2017-01-20 13:02:22 --> Config Class Initialized
INFO - 2017-01-20 13:02:22 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:22 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:22 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:22 --> URI Class Initialized
INFO - 2017-01-20 13:02:22 --> Router Class Initialized
INFO - 2017-01-20 13:02:22 --> Output Class Initialized
INFO - 2017-01-20 13:02:22 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:22 --> Input Class Initialized
INFO - 2017-01-20 13:02:22 --> Language Class Initialized
INFO - 2017-01-20 13:02:22 --> Loader Class Initialized
INFO - 2017-01-20 13:02:23 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:23 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:23 --> Controller Class Initialized
INFO - 2017-01-20 13:02:23 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:23 --> Model Class Initialized
INFO - 2017-01-20 13:02:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:23 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:02:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:23 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:23 --> Total execution time: 0.1844
INFO - 2017-01-20 13:02:28 --> Config Class Initialized
INFO - 2017-01-20 13:02:28 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:28 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:28 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:28 --> URI Class Initialized
INFO - 2017-01-20 13:02:28 --> Router Class Initialized
INFO - 2017-01-20 13:02:28 --> Output Class Initialized
INFO - 2017-01-20 13:02:28 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:28 --> Input Class Initialized
INFO - 2017-01-20 13:02:28 --> Language Class Initialized
INFO - 2017-01-20 13:02:28 --> Loader Class Initialized
INFO - 2017-01-20 13:02:28 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:28 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:28 --> Controller Class Initialized
INFO - 2017-01-20 13:02:28 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:28 --> Model Class Initialized
INFO - 2017-01-20 13:02:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:28 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:02:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:28 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:28 --> Total execution time: 0.2251
INFO - 2017-01-20 13:02:33 --> Config Class Initialized
INFO - 2017-01-20 13:02:33 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:33 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:33 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:33 --> URI Class Initialized
INFO - 2017-01-20 13:02:33 --> Router Class Initialized
INFO - 2017-01-20 13:02:33 --> Output Class Initialized
INFO - 2017-01-20 13:02:33 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:33 --> Input Class Initialized
INFO - 2017-01-20 13:02:33 --> Language Class Initialized
INFO - 2017-01-20 13:02:33 --> Loader Class Initialized
INFO - 2017-01-20 13:02:33 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:33 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:33 --> Controller Class Initialized
INFO - 2017-01-20 13:02:33 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:33 --> Model Class Initialized
INFO - 2017-01-20 13:02:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:33 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:33 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:33 --> Total execution time: 0.2236
INFO - 2017-01-20 13:02:57 --> Config Class Initialized
INFO - 2017-01-20 13:02:57 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:57 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:57 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:57 --> URI Class Initialized
INFO - 2017-01-20 13:02:57 --> Router Class Initialized
INFO - 2017-01-20 13:02:57 --> Output Class Initialized
INFO - 2017-01-20 13:02:57 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:57 --> Input Class Initialized
INFO - 2017-01-20 13:02:57 --> Language Class Initialized
INFO - 2017-01-20 13:02:57 --> Loader Class Initialized
INFO - 2017-01-20 13:02:57 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:57 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:57 --> Controller Class Initialized
INFO - 2017-01-20 13:02:57 --> Database Driver Class Initialized
INFO - 2017-01-20 13:02:57 --> Model Class Initialized
INFO - 2017-01-20 13:02:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:02:57 --> Helper loaded: form_helper
INFO - 2017-01-20 13:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:02:57 --> Final output sent to browser
DEBUG - 2017-01-20 13:02:57 --> Total execution time: 0.1694
INFO - 2017-01-20 13:02:59 --> Config Class Initialized
INFO - 2017-01-20 13:02:59 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:02:59 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:02:59 --> Utf8 Class Initialized
INFO - 2017-01-20 13:02:59 --> URI Class Initialized
INFO - 2017-01-20 13:02:59 --> Router Class Initialized
INFO - 2017-01-20 13:02:59 --> Output Class Initialized
INFO - 2017-01-20 13:02:59 --> Security Class Initialized
DEBUG - 2017-01-20 13:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:02:59 --> Input Class Initialized
INFO - 2017-01-20 13:02:59 --> Language Class Initialized
INFO - 2017-01-20 13:02:59 --> Loader Class Initialized
INFO - 2017-01-20 13:02:59 --> Helper loaded: url_helper
INFO - 2017-01-20 13:02:59 --> Helper loaded: language_helper
INFO - 2017-01-20 13:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:02:59 --> Controller Class Initialized
INFO - 2017-01-20 13:02:59 --> Database Driver Class Initialized
INFO - 2017-01-20 13:03:00 --> Model Class Initialized
INFO - 2017-01-20 13:03:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:03:00 --> Helper loaded: form_helper
INFO - 2017-01-20 13:03:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:03:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:03:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:03:00 --> Final output sent to browser
DEBUG - 2017-01-20 13:03:00 --> Total execution time: 0.2144
INFO - 2017-01-20 13:03:02 --> Config Class Initialized
INFO - 2017-01-20 13:03:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:03:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:03:02 --> Utf8 Class Initialized
INFO - 2017-01-20 13:03:02 --> URI Class Initialized
INFO - 2017-01-20 13:03:02 --> Router Class Initialized
INFO - 2017-01-20 13:03:02 --> Output Class Initialized
INFO - 2017-01-20 13:03:02 --> Security Class Initialized
DEBUG - 2017-01-20 13:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:03:02 --> Input Class Initialized
INFO - 2017-01-20 13:03:02 --> Language Class Initialized
INFO - 2017-01-20 13:03:02 --> Loader Class Initialized
INFO - 2017-01-20 13:03:02 --> Helper loaded: url_helper
INFO - 2017-01-20 13:03:02 --> Helper loaded: language_helper
INFO - 2017-01-20 13:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:03:02 --> Controller Class Initialized
INFO - 2017-01-20 13:03:02 --> Database Driver Class Initialized
INFO - 2017-01-20 13:03:02 --> Model Class Initialized
INFO - 2017-01-20 13:03:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:03:02 --> Helper loaded: form_helper
INFO - 2017-01-20 13:03:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:03:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:03:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:03:02 --> Final output sent to browser
DEBUG - 2017-01-20 13:03:02 --> Total execution time: 0.2079
INFO - 2017-01-20 13:04:35 --> Config Class Initialized
INFO - 2017-01-20 13:04:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:04:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:04:35 --> Utf8 Class Initialized
INFO - 2017-01-20 13:04:35 --> URI Class Initialized
INFO - 2017-01-20 13:04:35 --> Router Class Initialized
INFO - 2017-01-20 13:04:35 --> Output Class Initialized
INFO - 2017-01-20 13:04:35 --> Security Class Initialized
DEBUG - 2017-01-20 13:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:04:35 --> Input Class Initialized
INFO - 2017-01-20 13:04:35 --> Language Class Initialized
INFO - 2017-01-20 13:04:35 --> Loader Class Initialized
INFO - 2017-01-20 13:04:35 --> Helper loaded: url_helper
INFO - 2017-01-20 13:04:35 --> Helper loaded: language_helper
INFO - 2017-01-20 13:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:04:35 --> Controller Class Initialized
INFO - 2017-01-20 13:04:35 --> Database Driver Class Initialized
INFO - 2017-01-20 13:04:35 --> Model Class Initialized
INFO - 2017-01-20 13:04:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:04:35 --> Helper loaded: form_helper
INFO - 2017-01-20 13:04:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:04:36 --> Final output sent to browser
DEBUG - 2017-01-20 13:04:36 --> Total execution time: 0.1929
INFO - 2017-01-20 13:05:07 --> Config Class Initialized
INFO - 2017-01-20 13:05:07 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:05:07 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:05:07 --> Utf8 Class Initialized
INFO - 2017-01-20 13:05:07 --> URI Class Initialized
INFO - 2017-01-20 13:05:07 --> Router Class Initialized
INFO - 2017-01-20 13:05:07 --> Output Class Initialized
INFO - 2017-01-20 13:05:07 --> Security Class Initialized
DEBUG - 2017-01-20 13:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:05:07 --> Input Class Initialized
INFO - 2017-01-20 13:05:07 --> Language Class Initialized
INFO - 2017-01-20 13:05:07 --> Loader Class Initialized
INFO - 2017-01-20 13:05:07 --> Helper loaded: url_helper
INFO - 2017-01-20 13:05:07 --> Helper loaded: language_helper
INFO - 2017-01-20 13:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:05:07 --> Controller Class Initialized
INFO - 2017-01-20 13:05:07 --> Database Driver Class Initialized
INFO - 2017-01-20 13:05:07 --> Model Class Initialized
INFO - 2017-01-20 13:05:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:05:07 --> Helper loaded: form_helper
INFO - 2017-01-20 13:05:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:05:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:05:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:05:07 --> Final output sent to browser
DEBUG - 2017-01-20 13:05:07 --> Total execution time: 0.1487
INFO - 2017-01-20 13:05:10 --> Config Class Initialized
INFO - 2017-01-20 13:05:10 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:05:10 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:05:10 --> Utf8 Class Initialized
INFO - 2017-01-20 13:05:10 --> URI Class Initialized
INFO - 2017-01-20 13:05:10 --> Router Class Initialized
INFO - 2017-01-20 13:05:10 --> Output Class Initialized
INFO - 2017-01-20 13:05:10 --> Security Class Initialized
DEBUG - 2017-01-20 13:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:05:10 --> Input Class Initialized
INFO - 2017-01-20 13:05:10 --> Language Class Initialized
INFO - 2017-01-20 13:05:10 --> Loader Class Initialized
INFO - 2017-01-20 13:05:10 --> Helper loaded: url_helper
INFO - 2017-01-20 13:05:10 --> Helper loaded: language_helper
INFO - 2017-01-20 13:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:05:10 --> Controller Class Initialized
INFO - 2017-01-20 13:05:10 --> Database Driver Class Initialized
INFO - 2017-01-20 13:05:10 --> Model Class Initialized
INFO - 2017-01-20 13:05:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:05:10 --> Helper loaded: form_helper
INFO - 2017-01-20 13:05:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:05:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:05:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:05:10 --> Final output sent to browser
DEBUG - 2017-01-20 13:05:10 --> Total execution time: 0.1976
INFO - 2017-01-20 13:05:13 --> Config Class Initialized
INFO - 2017-01-20 13:05:13 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:05:13 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:05:13 --> Utf8 Class Initialized
INFO - 2017-01-20 13:05:13 --> URI Class Initialized
INFO - 2017-01-20 13:05:13 --> Router Class Initialized
INFO - 2017-01-20 13:05:13 --> Output Class Initialized
INFO - 2017-01-20 13:05:13 --> Security Class Initialized
DEBUG - 2017-01-20 13:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:05:13 --> Input Class Initialized
INFO - 2017-01-20 13:05:13 --> Language Class Initialized
INFO - 2017-01-20 13:05:13 --> Loader Class Initialized
INFO - 2017-01-20 13:05:13 --> Helper loaded: url_helper
INFO - 2017-01-20 13:05:13 --> Helper loaded: language_helper
INFO - 2017-01-20 13:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:05:13 --> Controller Class Initialized
INFO - 2017-01-20 13:05:13 --> Database Driver Class Initialized
INFO - 2017-01-20 13:05:13 --> Model Class Initialized
INFO - 2017-01-20 13:05:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:05:13 --> Helper loaded: form_helper
INFO - 2017-01-20 13:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:05:13 --> Final output sent to browser
DEBUG - 2017-01-20 13:05:13 --> Total execution time: 0.1926
INFO - 2017-01-20 13:17:00 --> Config Class Initialized
INFO - 2017-01-20 13:17:00 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:17:00 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:17:00 --> Utf8 Class Initialized
INFO - 2017-01-20 13:17:00 --> URI Class Initialized
INFO - 2017-01-20 13:17:00 --> Router Class Initialized
INFO - 2017-01-20 13:17:00 --> Output Class Initialized
INFO - 2017-01-20 13:17:00 --> Security Class Initialized
DEBUG - 2017-01-20 13:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:17:00 --> Input Class Initialized
INFO - 2017-01-20 13:17:00 --> Language Class Initialized
INFO - 2017-01-20 13:17:00 --> Loader Class Initialized
INFO - 2017-01-20 13:17:00 --> Helper loaded: url_helper
INFO - 2017-01-20 13:17:00 --> Helper loaded: language_helper
INFO - 2017-01-20 13:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:17:00 --> Controller Class Initialized
INFO - 2017-01-20 13:17:00 --> Database Driver Class Initialized
INFO - 2017-01-20 13:17:00 --> Model Class Initialized
INFO - 2017-01-20 13:17:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:17:00 --> Helper loaded: form_helper
INFO - 2017-01-20 13:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:17:00 --> Final output sent to browser
DEBUG - 2017-01-20 13:17:00 --> Total execution time: 0.2746
INFO - 2017-01-20 13:24:06 --> Config Class Initialized
INFO - 2017-01-20 13:24:06 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:24:06 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:24:06 --> Utf8 Class Initialized
INFO - 2017-01-20 13:24:06 --> URI Class Initialized
INFO - 2017-01-20 13:24:06 --> Router Class Initialized
INFO - 2017-01-20 13:24:06 --> Output Class Initialized
INFO - 2017-01-20 13:24:06 --> Security Class Initialized
DEBUG - 2017-01-20 13:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:24:06 --> Input Class Initialized
INFO - 2017-01-20 13:24:06 --> Language Class Initialized
INFO - 2017-01-20 13:24:06 --> Loader Class Initialized
INFO - 2017-01-20 13:24:06 --> Helper loaded: url_helper
INFO - 2017-01-20 13:24:06 --> Helper loaded: language_helper
INFO - 2017-01-20 13:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:24:06 --> Controller Class Initialized
INFO - 2017-01-20 13:24:06 --> Database Driver Class Initialized
INFO - 2017-01-20 13:24:06 --> Model Class Initialized
INFO - 2017-01-20 13:24:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:24:06 --> Helper loaded: form_helper
INFO - 2017-01-20 13:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:24:06 --> Final output sent to browser
DEBUG - 2017-01-20 13:24:06 --> Total execution time: 0.1937
INFO - 2017-01-20 13:24:11 --> Config Class Initialized
INFO - 2017-01-20 13:24:11 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:24:11 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:24:11 --> Utf8 Class Initialized
INFO - 2017-01-20 13:24:11 --> URI Class Initialized
INFO - 2017-01-20 13:24:11 --> Router Class Initialized
INFO - 2017-01-20 13:24:11 --> Output Class Initialized
INFO - 2017-01-20 13:24:11 --> Security Class Initialized
DEBUG - 2017-01-20 13:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:24:11 --> Input Class Initialized
INFO - 2017-01-20 13:24:11 --> Language Class Initialized
INFO - 2017-01-20 13:24:11 --> Loader Class Initialized
INFO - 2017-01-20 13:24:11 --> Helper loaded: url_helper
INFO - 2017-01-20 13:24:11 --> Helper loaded: language_helper
INFO - 2017-01-20 13:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:24:11 --> Controller Class Initialized
INFO - 2017-01-20 13:24:11 --> Database Driver Class Initialized
INFO - 2017-01-20 13:24:11 --> Model Class Initialized
INFO - 2017-01-20 13:24:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:24:11 --> Helper loaded: form_helper
INFO - 2017-01-20 13:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:24:11 --> Final output sent to browser
DEBUG - 2017-01-20 13:24:11 --> Total execution time: 0.1851
INFO - 2017-01-20 13:24:17 --> Config Class Initialized
INFO - 2017-01-20 13:24:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:24:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:24:17 --> Utf8 Class Initialized
INFO - 2017-01-20 13:24:17 --> URI Class Initialized
INFO - 2017-01-20 13:24:17 --> Router Class Initialized
INFO - 2017-01-20 13:24:17 --> Output Class Initialized
INFO - 2017-01-20 13:24:17 --> Security Class Initialized
DEBUG - 2017-01-20 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:24:17 --> Input Class Initialized
INFO - 2017-01-20 13:24:17 --> Language Class Initialized
INFO - 2017-01-20 13:24:17 --> Loader Class Initialized
INFO - 2017-01-20 13:24:17 --> Helper loaded: url_helper
INFO - 2017-01-20 13:24:17 --> Helper loaded: language_helper
INFO - 2017-01-20 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:24:17 --> Controller Class Initialized
INFO - 2017-01-20 13:24:17 --> Database Driver Class Initialized
INFO - 2017-01-20 13:24:17 --> Model Class Initialized
INFO - 2017-01-20 13:24:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:24:17 --> Model Class Initialized
INFO - 2017-01-20 13:24:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:24:19 --> Final output sent to browser
DEBUG - 2017-01-20 13:24:19 --> Total execution time: 1.9297
INFO - 2017-01-20 13:25:06 --> Config Class Initialized
INFO - 2017-01-20 13:25:06 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:25:06 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:25:06 --> Utf8 Class Initialized
INFO - 2017-01-20 13:25:06 --> URI Class Initialized
INFO - 2017-01-20 13:25:06 --> Router Class Initialized
INFO - 2017-01-20 13:25:06 --> Output Class Initialized
INFO - 2017-01-20 13:25:06 --> Security Class Initialized
DEBUG - 2017-01-20 13:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:25:06 --> Input Class Initialized
INFO - 2017-01-20 13:25:06 --> Language Class Initialized
INFO - 2017-01-20 13:25:06 --> Loader Class Initialized
INFO - 2017-01-20 13:25:06 --> Helper loaded: url_helper
INFO - 2017-01-20 13:25:06 --> Helper loaded: language_helper
INFO - 2017-01-20 13:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:25:06 --> Controller Class Initialized
INFO - 2017-01-20 13:25:06 --> Database Driver Class Initialized
INFO - 2017-01-20 13:25:06 --> Model Class Initialized
INFO - 2017-01-20 13:25:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:25:06 --> Model Class Initialized
INFO - 2017-01-20 13:25:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:25:08 --> Final output sent to browser
DEBUG - 2017-01-20 13:25:08 --> Total execution time: 1.7152
INFO - 2017-01-20 13:25:18 --> Config Class Initialized
INFO - 2017-01-20 13:25:18 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:25:18 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:25:18 --> Utf8 Class Initialized
INFO - 2017-01-20 13:25:18 --> URI Class Initialized
INFO - 2017-01-20 13:25:18 --> Router Class Initialized
INFO - 2017-01-20 13:25:18 --> Output Class Initialized
INFO - 2017-01-20 13:25:18 --> Security Class Initialized
DEBUG - 2017-01-20 13:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:25:18 --> Input Class Initialized
INFO - 2017-01-20 13:25:18 --> Language Class Initialized
INFO - 2017-01-20 13:25:18 --> Loader Class Initialized
INFO - 2017-01-20 13:25:18 --> Helper loaded: url_helper
INFO - 2017-01-20 13:25:18 --> Helper loaded: language_helper
INFO - 2017-01-20 13:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:25:18 --> Controller Class Initialized
INFO - 2017-01-20 13:25:18 --> Database Driver Class Initialized
INFO - 2017-01-20 13:25:18 --> Model Class Initialized
INFO - 2017-01-20 13:25:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:25:18 --> Helper loaded: form_helper
INFO - 2017-01-20 13:25:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:25:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:25:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:25:18 --> Final output sent to browser
DEBUG - 2017-01-20 13:25:18 --> Total execution time: 0.2203
INFO - 2017-01-20 13:25:21 --> Config Class Initialized
INFO - 2017-01-20 13:25:21 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:25:21 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:25:21 --> Utf8 Class Initialized
INFO - 2017-01-20 13:25:21 --> URI Class Initialized
INFO - 2017-01-20 13:25:21 --> Router Class Initialized
INFO - 2017-01-20 13:25:21 --> Output Class Initialized
INFO - 2017-01-20 13:25:21 --> Security Class Initialized
DEBUG - 2017-01-20 13:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:25:21 --> Input Class Initialized
INFO - 2017-01-20 13:25:21 --> Language Class Initialized
INFO - 2017-01-20 13:25:21 --> Loader Class Initialized
INFO - 2017-01-20 13:25:21 --> Helper loaded: url_helper
INFO - 2017-01-20 13:25:21 --> Helper loaded: language_helper
INFO - 2017-01-20 13:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:25:21 --> Controller Class Initialized
INFO - 2017-01-20 13:25:21 --> Database Driver Class Initialized
INFO - 2017-01-20 13:25:21 --> Model Class Initialized
INFO - 2017-01-20 13:25:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:25:21 --> Helper loaded: form_helper
INFO - 2017-01-20 13:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:25:21 --> Final output sent to browser
DEBUG - 2017-01-20 13:25:21 --> Total execution time: 0.1781
INFO - 2017-01-20 13:25:24 --> Config Class Initialized
INFO - 2017-01-20 13:25:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:25:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:25:24 --> Utf8 Class Initialized
INFO - 2017-01-20 13:25:24 --> URI Class Initialized
INFO - 2017-01-20 13:25:24 --> Router Class Initialized
INFO - 2017-01-20 13:25:24 --> Output Class Initialized
INFO - 2017-01-20 13:25:24 --> Security Class Initialized
DEBUG - 2017-01-20 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:25:24 --> Input Class Initialized
INFO - 2017-01-20 13:25:24 --> Language Class Initialized
INFO - 2017-01-20 13:25:24 --> Loader Class Initialized
INFO - 2017-01-20 13:25:24 --> Helper loaded: url_helper
INFO - 2017-01-20 13:25:24 --> Helper loaded: language_helper
INFO - 2017-01-20 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:25:24 --> Controller Class Initialized
INFO - 2017-01-20 13:25:24 --> Database Driver Class Initialized
INFO - 2017-01-20 13:25:24 --> Model Class Initialized
INFO - 2017-01-20 13:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:25:24 --> Model Class Initialized
INFO - 2017-01-20 13:25:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:25:25 --> Final output sent to browser
DEBUG - 2017-01-20 13:25:25 --> Total execution time: 1.6692
INFO - 2017-01-20 13:27:52 --> Config Class Initialized
INFO - 2017-01-20 13:27:52 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:27:52 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:27:52 --> Utf8 Class Initialized
INFO - 2017-01-20 13:27:52 --> URI Class Initialized
INFO - 2017-01-20 13:27:52 --> Router Class Initialized
INFO - 2017-01-20 13:27:52 --> Output Class Initialized
INFO - 2017-01-20 13:27:52 --> Security Class Initialized
DEBUG - 2017-01-20 13:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:27:52 --> Input Class Initialized
INFO - 2017-01-20 13:27:52 --> Language Class Initialized
INFO - 2017-01-20 13:27:52 --> Loader Class Initialized
INFO - 2017-01-20 13:27:52 --> Helper loaded: url_helper
INFO - 2017-01-20 13:27:52 --> Helper loaded: language_helper
INFO - 2017-01-20 13:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:27:52 --> Controller Class Initialized
INFO - 2017-01-20 13:27:52 --> Database Driver Class Initialized
INFO - 2017-01-20 13:27:52 --> Model Class Initialized
INFO - 2017-01-20 13:27:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:27:52 --> Helper loaded: form_helper
INFO - 2017-01-20 13:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:27:53 --> Final output sent to browser
DEBUG - 2017-01-20 13:27:53 --> Total execution time: 0.1615
INFO - 2017-01-20 13:27:56 --> Config Class Initialized
INFO - 2017-01-20 13:27:56 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:27:56 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:27:56 --> Utf8 Class Initialized
INFO - 2017-01-20 13:27:56 --> URI Class Initialized
INFO - 2017-01-20 13:27:56 --> Router Class Initialized
INFO - 2017-01-20 13:27:56 --> Output Class Initialized
INFO - 2017-01-20 13:27:56 --> Security Class Initialized
DEBUG - 2017-01-20 13:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:27:56 --> Input Class Initialized
INFO - 2017-01-20 13:27:56 --> Language Class Initialized
INFO - 2017-01-20 13:27:56 --> Loader Class Initialized
INFO - 2017-01-20 13:27:56 --> Helper loaded: url_helper
INFO - 2017-01-20 13:27:56 --> Helper loaded: language_helper
INFO - 2017-01-20 13:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:27:56 --> Controller Class Initialized
INFO - 2017-01-20 13:27:56 --> Database Driver Class Initialized
INFO - 2017-01-20 13:27:56 --> Model Class Initialized
INFO - 2017-01-20 13:27:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:27:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:27:57 --> Model Class Initialized
INFO - 2017-01-20 13:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:27:58 --> Final output sent to browser
DEBUG - 2017-01-20 13:27:58 --> Total execution time: 2.2896
INFO - 2017-01-20 13:28:24 --> Config Class Initialized
INFO - 2017-01-20 13:28:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:28:25 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:28:25 --> Utf8 Class Initialized
INFO - 2017-01-20 13:28:25 --> URI Class Initialized
INFO - 2017-01-20 13:28:25 --> Router Class Initialized
INFO - 2017-01-20 13:28:25 --> Output Class Initialized
INFO - 2017-01-20 13:28:25 --> Security Class Initialized
DEBUG - 2017-01-20 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:28:25 --> Input Class Initialized
INFO - 2017-01-20 13:28:25 --> Language Class Initialized
INFO - 2017-01-20 13:28:25 --> Loader Class Initialized
INFO - 2017-01-20 13:28:25 --> Helper loaded: url_helper
INFO - 2017-01-20 13:28:25 --> Helper loaded: language_helper
INFO - 2017-01-20 13:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:28:25 --> Controller Class Initialized
INFO - 2017-01-20 13:28:25 --> Database Driver Class Initialized
INFO - 2017-01-20 13:28:25 --> Model Class Initialized
INFO - 2017-01-20 13:28:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:28:25 --> Helper loaded: form_helper
INFO - 2017-01-20 13:28:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:28:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:28:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:28:25 --> Final output sent to browser
DEBUG - 2017-01-20 13:28:25 --> Total execution time: 0.1733
INFO - 2017-01-20 13:28:30 --> Config Class Initialized
INFO - 2017-01-20 13:28:30 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:28:30 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:28:30 --> Utf8 Class Initialized
INFO - 2017-01-20 13:28:30 --> URI Class Initialized
INFO - 2017-01-20 13:28:30 --> Router Class Initialized
INFO - 2017-01-20 13:28:30 --> Output Class Initialized
INFO - 2017-01-20 13:28:30 --> Security Class Initialized
DEBUG - 2017-01-20 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:28:30 --> Input Class Initialized
INFO - 2017-01-20 13:28:30 --> Language Class Initialized
INFO - 2017-01-20 13:28:30 --> Loader Class Initialized
INFO - 2017-01-20 13:28:30 --> Helper loaded: url_helper
INFO - 2017-01-20 13:28:30 --> Helper loaded: language_helper
INFO - 2017-01-20 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:28:30 --> Controller Class Initialized
INFO - 2017-01-20 13:28:30 --> Database Driver Class Initialized
INFO - 2017-01-20 13:28:30 --> Model Class Initialized
INFO - 2017-01-20 13:28:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:28:30 --> Helper loaded: form_helper
INFO - 2017-01-20 13:28:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:28:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:28:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:28:30 --> Final output sent to browser
DEBUG - 2017-01-20 13:28:30 --> Total execution time: 0.1790
INFO - 2017-01-20 13:29:29 --> Config Class Initialized
INFO - 2017-01-20 13:29:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:29:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:29:29 --> Utf8 Class Initialized
INFO - 2017-01-20 13:29:29 --> URI Class Initialized
INFO - 2017-01-20 13:29:29 --> Router Class Initialized
INFO - 2017-01-20 13:29:29 --> Output Class Initialized
INFO - 2017-01-20 13:29:29 --> Security Class Initialized
DEBUG - 2017-01-20 13:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:29:29 --> Input Class Initialized
INFO - 2017-01-20 13:29:29 --> Language Class Initialized
INFO - 2017-01-20 13:29:29 --> Loader Class Initialized
INFO - 2017-01-20 13:29:29 --> Helper loaded: url_helper
INFO - 2017-01-20 13:29:29 --> Helper loaded: language_helper
INFO - 2017-01-20 13:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:29:29 --> Controller Class Initialized
INFO - 2017-01-20 13:29:29 --> Database Driver Class Initialized
INFO - 2017-01-20 13:29:29 --> Model Class Initialized
INFO - 2017-01-20 13:29:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:29:29 --> Helper loaded: form_helper
INFO - 2017-01-20 13:29:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:29:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:29:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:29:29 --> Final output sent to browser
DEBUG - 2017-01-20 13:29:29 --> Total execution time: 0.2042
INFO - 2017-01-20 13:29:32 --> Config Class Initialized
INFO - 2017-01-20 13:29:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:29:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:29:32 --> Utf8 Class Initialized
INFO - 2017-01-20 13:29:32 --> URI Class Initialized
INFO - 2017-01-20 13:29:32 --> Router Class Initialized
INFO - 2017-01-20 13:29:32 --> Output Class Initialized
INFO - 2017-01-20 13:29:32 --> Security Class Initialized
DEBUG - 2017-01-20 13:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:29:32 --> Input Class Initialized
INFO - 2017-01-20 13:29:32 --> Language Class Initialized
INFO - 2017-01-20 13:29:32 --> Loader Class Initialized
INFO - 2017-01-20 13:29:32 --> Helper loaded: url_helper
INFO - 2017-01-20 13:29:32 --> Helper loaded: language_helper
INFO - 2017-01-20 13:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:29:32 --> Controller Class Initialized
INFO - 2017-01-20 13:29:32 --> Database Driver Class Initialized
INFO - 2017-01-20 13:29:32 --> Model Class Initialized
INFO - 2017-01-20 13:29:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:29:32 --> Model Class Initialized
INFO - 2017-01-20 13:29:32 --> Helper loaded: form_helper
INFO - 2017-01-20 13:29:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:29:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:29:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:29:32 --> Final output sent to browser
DEBUG - 2017-01-20 13:29:32 --> Total execution time: 0.7560
INFO - 2017-01-20 13:29:41 --> Config Class Initialized
INFO - 2017-01-20 13:29:41 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:29:41 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:29:41 --> Utf8 Class Initialized
INFO - 2017-01-20 13:29:41 --> URI Class Initialized
INFO - 2017-01-20 13:29:41 --> Router Class Initialized
INFO - 2017-01-20 13:29:41 --> Output Class Initialized
INFO - 2017-01-20 13:29:41 --> Security Class Initialized
DEBUG - 2017-01-20 13:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:29:41 --> Input Class Initialized
INFO - 2017-01-20 13:29:41 --> Language Class Initialized
INFO - 2017-01-20 13:29:41 --> Loader Class Initialized
INFO - 2017-01-20 13:29:41 --> Helper loaded: url_helper
INFO - 2017-01-20 13:29:41 --> Helper loaded: language_helper
INFO - 2017-01-20 13:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:29:42 --> Controller Class Initialized
INFO - 2017-01-20 13:29:42 --> Database Driver Class Initialized
INFO - 2017-01-20 13:29:42 --> Model Class Initialized
INFO - 2017-01-20 13:29:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:29:42 --> Model Class Initialized
INFO - 2017-01-20 13:29:42 --> Helper loaded: form_helper
INFO - 2017-01-20 13:29:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:29:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:29:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:29:42 --> Final output sent to browser
DEBUG - 2017-01-20 13:29:42 --> Total execution time: 0.5703
INFO - 2017-01-20 13:29:45 --> Config Class Initialized
INFO - 2017-01-20 13:29:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:29:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:29:45 --> Utf8 Class Initialized
INFO - 2017-01-20 13:29:45 --> URI Class Initialized
INFO - 2017-01-20 13:29:45 --> Router Class Initialized
INFO - 2017-01-20 13:29:45 --> Output Class Initialized
INFO - 2017-01-20 13:29:45 --> Security Class Initialized
DEBUG - 2017-01-20 13:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:29:45 --> Input Class Initialized
INFO - 2017-01-20 13:29:45 --> Language Class Initialized
INFO - 2017-01-20 13:29:45 --> Loader Class Initialized
INFO - 2017-01-20 13:29:45 --> Helper loaded: url_helper
INFO - 2017-01-20 13:29:45 --> Helper loaded: language_helper
INFO - 2017-01-20 13:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:29:45 --> Controller Class Initialized
INFO - 2017-01-20 13:29:45 --> Database Driver Class Initialized
INFO - 2017-01-20 13:29:45 --> Model Class Initialized
INFO - 2017-01-20 13:29:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:29:45 --> Model Class Initialized
INFO - 2017-01-20 13:29:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:29:47 --> Final output sent to browser
DEBUG - 2017-01-20 13:29:47 --> Total execution time: 1.6047
INFO - 2017-01-20 13:30:27 --> Config Class Initialized
INFO - 2017-01-20 13:30:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:30:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:30:27 --> Utf8 Class Initialized
INFO - 2017-01-20 13:30:27 --> URI Class Initialized
INFO - 2017-01-20 13:30:27 --> Router Class Initialized
INFO - 2017-01-20 13:30:27 --> Output Class Initialized
INFO - 2017-01-20 13:30:27 --> Security Class Initialized
DEBUG - 2017-01-20 13:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:30:27 --> Input Class Initialized
INFO - 2017-01-20 13:30:27 --> Language Class Initialized
INFO - 2017-01-20 13:30:27 --> Loader Class Initialized
INFO - 2017-01-20 13:30:27 --> Helper loaded: url_helper
INFO - 2017-01-20 13:30:27 --> Helper loaded: language_helper
INFO - 2017-01-20 13:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:30:27 --> Controller Class Initialized
INFO - 2017-01-20 13:30:27 --> Database Driver Class Initialized
INFO - 2017-01-20 13:30:27 --> Model Class Initialized
INFO - 2017-01-20 13:30:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:30:27 --> Model Class Initialized
INFO - 2017-01-20 13:30:27 --> Helper loaded: form_helper
INFO - 2017-01-20 13:30:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:30:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:30:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:30:28 --> Final output sent to browser
DEBUG - 2017-01-20 13:30:28 --> Total execution time: 0.6039
INFO - 2017-01-20 13:30:31 --> Config Class Initialized
INFO - 2017-01-20 13:30:31 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:30:31 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:30:31 --> Utf8 Class Initialized
INFO - 2017-01-20 13:30:31 --> URI Class Initialized
INFO - 2017-01-20 13:30:31 --> Router Class Initialized
INFO - 2017-01-20 13:30:31 --> Output Class Initialized
INFO - 2017-01-20 13:30:31 --> Security Class Initialized
DEBUG - 2017-01-20 13:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:30:31 --> Input Class Initialized
INFO - 2017-01-20 13:30:31 --> Language Class Initialized
INFO - 2017-01-20 13:30:32 --> Loader Class Initialized
INFO - 2017-01-20 13:30:32 --> Helper loaded: url_helper
INFO - 2017-01-20 13:30:32 --> Helper loaded: language_helper
INFO - 2017-01-20 13:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:30:32 --> Controller Class Initialized
INFO - 2017-01-20 13:30:32 --> Database Driver Class Initialized
INFO - 2017-01-20 13:30:32 --> Model Class Initialized
INFO - 2017-01-20 13:30:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:30:32 --> Helper loaded: form_helper
INFO - 2017-01-20 13:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:30:32 --> Final output sent to browser
DEBUG - 2017-01-20 13:30:32 --> Total execution time: 0.1627
INFO - 2017-01-20 13:31:22 --> Config Class Initialized
INFO - 2017-01-20 13:31:22 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:31:22 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:31:22 --> Utf8 Class Initialized
INFO - 2017-01-20 13:31:22 --> URI Class Initialized
INFO - 2017-01-20 13:31:22 --> Router Class Initialized
INFO - 2017-01-20 13:31:22 --> Output Class Initialized
INFO - 2017-01-20 13:31:22 --> Security Class Initialized
DEBUG - 2017-01-20 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:31:22 --> Input Class Initialized
INFO - 2017-01-20 13:31:22 --> Language Class Initialized
INFO - 2017-01-20 13:31:22 --> Loader Class Initialized
INFO - 2017-01-20 13:31:22 --> Helper loaded: url_helper
INFO - 2017-01-20 13:31:22 --> Helper loaded: language_helper
INFO - 2017-01-20 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:31:22 --> Controller Class Initialized
INFO - 2017-01-20 13:31:22 --> Database Driver Class Initialized
INFO - 2017-01-20 13:31:22 --> Model Class Initialized
INFO - 2017-01-20 13:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:31:22 --> Config Class Initialized
INFO - 2017-01-20 13:31:22 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:31:22 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:31:22 --> Utf8 Class Initialized
INFO - 2017-01-20 13:31:22 --> URI Class Initialized
INFO - 2017-01-20 13:31:22 --> Router Class Initialized
INFO - 2017-01-20 13:31:22 --> Output Class Initialized
INFO - 2017-01-20 13:31:22 --> Security Class Initialized
DEBUG - 2017-01-20 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:31:22 --> Input Class Initialized
INFO - 2017-01-20 13:31:22 --> Language Class Initialized
INFO - 2017-01-20 13:31:22 --> Loader Class Initialized
INFO - 2017-01-20 13:31:22 --> Helper loaded: url_helper
INFO - 2017-01-20 13:31:22 --> Helper loaded: language_helper
INFO - 2017-01-20 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:31:22 --> Controller Class Initialized
INFO - 2017-01-20 13:31:22 --> Database Driver Class Initialized
INFO - 2017-01-20 13:31:22 --> Model Class Initialized
INFO - 2017-01-20 13:31:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:31:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-20 13:31:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-20 13:31:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-20 13:31:22 --> Final output sent to browser
DEBUG - 2017-01-20 13:31:22 --> Total execution time: 0.1042
INFO - 2017-01-20 13:31:29 --> Config Class Initialized
INFO - 2017-01-20 13:31:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:31:29 --> Utf8 Class Initialized
INFO - 2017-01-20 13:31:29 --> URI Class Initialized
INFO - 2017-01-20 13:31:29 --> Router Class Initialized
INFO - 2017-01-20 13:31:29 --> Output Class Initialized
INFO - 2017-01-20 13:31:29 --> Security Class Initialized
DEBUG - 2017-01-20 13:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:31:29 --> Input Class Initialized
INFO - 2017-01-20 13:31:29 --> Language Class Initialized
INFO - 2017-01-20 13:31:29 --> Loader Class Initialized
INFO - 2017-01-20 13:31:29 --> Helper loaded: url_helper
INFO - 2017-01-20 13:31:29 --> Helper loaded: language_helper
INFO - 2017-01-20 13:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:31:29 --> Controller Class Initialized
INFO - 2017-01-20 13:31:29 --> Database Driver Class Initialized
INFO - 2017-01-20 13:31:29 --> Model Class Initialized
INFO - 2017-01-20 13:31:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:31:29 --> Config Class Initialized
INFO - 2017-01-20 13:31:29 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:31:29 --> Utf8 Class Initialized
INFO - 2017-01-20 13:31:29 --> URI Class Initialized
INFO - 2017-01-20 13:31:29 --> Router Class Initialized
INFO - 2017-01-20 13:31:29 --> Output Class Initialized
INFO - 2017-01-20 13:31:29 --> Security Class Initialized
DEBUG - 2017-01-20 13:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:31:29 --> Input Class Initialized
INFO - 2017-01-20 13:31:29 --> Language Class Initialized
INFO - 2017-01-20 13:31:29 --> Loader Class Initialized
INFO - 2017-01-20 13:31:29 --> Helper loaded: url_helper
INFO - 2017-01-20 13:31:29 --> Helper loaded: language_helper
INFO - 2017-01-20 13:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:31:29 --> Controller Class Initialized
INFO - 2017-01-20 13:31:29 --> Database Driver Class Initialized
INFO - 2017-01-20 13:31:29 --> Model Class Initialized
INFO - 2017-01-20 13:31:29 --> Model Class Initialized
INFO - 2017-01-20 13:31:29 --> Model Class Initialized
INFO - 2017-01-20 13:31:29 --> Model Class Initialized
INFO - 2017-01-20 13:31:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-20 13:31:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:31:29 --> Final output sent to browser
DEBUG - 2017-01-20 13:31:29 --> Total execution time: 0.1792
INFO - 2017-01-20 13:31:32 --> Config Class Initialized
INFO - 2017-01-20 13:31:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:31:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:31:32 --> Utf8 Class Initialized
INFO - 2017-01-20 13:31:32 --> URI Class Initialized
INFO - 2017-01-20 13:31:32 --> Router Class Initialized
INFO - 2017-01-20 13:31:32 --> Output Class Initialized
INFO - 2017-01-20 13:31:33 --> Security Class Initialized
DEBUG - 2017-01-20 13:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:31:33 --> Input Class Initialized
INFO - 2017-01-20 13:31:33 --> Language Class Initialized
INFO - 2017-01-20 13:31:33 --> Loader Class Initialized
INFO - 2017-01-20 13:31:33 --> Helper loaded: url_helper
INFO - 2017-01-20 13:31:33 --> Helper loaded: language_helper
INFO - 2017-01-20 13:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:31:33 --> Controller Class Initialized
INFO - 2017-01-20 13:31:33 --> Database Driver Class Initialized
INFO - 2017-01-20 13:31:33 --> Model Class Initialized
INFO - 2017-01-20 13:31:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:31:33 --> Helper loaded: form_helper
INFO - 2017-01-20 13:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:31:33 --> Final output sent to browser
DEBUG - 2017-01-20 13:31:33 --> Total execution time: 0.1509
INFO - 2017-01-20 13:31:34 --> Config Class Initialized
INFO - 2017-01-20 13:31:34 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:31:34 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:31:34 --> Utf8 Class Initialized
INFO - 2017-01-20 13:31:34 --> URI Class Initialized
INFO - 2017-01-20 13:31:34 --> Router Class Initialized
INFO - 2017-01-20 13:31:34 --> Output Class Initialized
INFO - 2017-01-20 13:31:34 --> Security Class Initialized
DEBUG - 2017-01-20 13:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:31:34 --> Input Class Initialized
INFO - 2017-01-20 13:31:34 --> Language Class Initialized
INFO - 2017-01-20 13:31:34 --> Loader Class Initialized
INFO - 2017-01-20 13:31:34 --> Helper loaded: url_helper
INFO - 2017-01-20 13:31:34 --> Helper loaded: language_helper
INFO - 2017-01-20 13:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:31:34 --> Controller Class Initialized
INFO - 2017-01-20 13:31:34 --> Database Driver Class Initialized
INFO - 2017-01-20 13:31:34 --> Model Class Initialized
INFO - 2017-01-20 13:31:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:31:34 --> Model Class Initialized
INFO - 2017-01-20 13:31:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:31:36 --> Final output sent to browser
DEBUG - 2017-01-20 13:31:36 --> Total execution time: 1.8671
INFO - 2017-01-20 13:32:45 --> Config Class Initialized
INFO - 2017-01-20 13:32:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:32:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:32:45 --> Utf8 Class Initialized
INFO - 2017-01-20 13:32:45 --> URI Class Initialized
INFO - 2017-01-20 13:32:45 --> Router Class Initialized
INFO - 2017-01-20 13:32:45 --> Output Class Initialized
INFO - 2017-01-20 13:32:45 --> Security Class Initialized
DEBUG - 2017-01-20 13:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:32:45 --> Input Class Initialized
INFO - 2017-01-20 13:32:45 --> Language Class Initialized
INFO - 2017-01-20 13:32:45 --> Loader Class Initialized
INFO - 2017-01-20 13:32:45 --> Helper loaded: url_helper
INFO - 2017-01-20 13:32:45 --> Helper loaded: language_helper
INFO - 2017-01-20 13:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:32:45 --> Controller Class Initialized
INFO - 2017-01-20 13:32:45 --> Database Driver Class Initialized
INFO - 2017-01-20 13:32:45 --> Model Class Initialized
INFO - 2017-01-20 13:32:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:32:45 --> Helper loaded: form_helper
INFO - 2017-01-20 13:32:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:32:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:32:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:32:45 --> Final output sent to browser
DEBUG - 2017-01-20 13:32:45 --> Total execution time: 0.2113
INFO - 2017-01-20 13:32:49 --> Config Class Initialized
INFO - 2017-01-20 13:32:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:32:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:32:49 --> Utf8 Class Initialized
INFO - 2017-01-20 13:32:49 --> URI Class Initialized
INFO - 2017-01-20 13:32:49 --> Router Class Initialized
INFO - 2017-01-20 13:32:49 --> Output Class Initialized
INFO - 2017-01-20 13:32:49 --> Security Class Initialized
DEBUG - 2017-01-20 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:32:49 --> Input Class Initialized
INFO - 2017-01-20 13:32:49 --> Language Class Initialized
INFO - 2017-01-20 13:32:49 --> Loader Class Initialized
INFO - 2017-01-20 13:32:49 --> Helper loaded: url_helper
INFO - 2017-01-20 13:32:49 --> Helper loaded: language_helper
INFO - 2017-01-20 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:32:49 --> Controller Class Initialized
INFO - 2017-01-20 13:32:49 --> Database Driver Class Initialized
INFO - 2017-01-20 13:32:49 --> Model Class Initialized
INFO - 2017-01-20 13:32:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:32:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:32:50 --> Final output sent to browser
DEBUG - 2017-01-20 13:32:50 --> Total execution time: 0.9014
INFO - 2017-01-20 13:33:06 --> Config Class Initialized
INFO - 2017-01-20 13:33:06 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:33:06 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:33:06 --> Utf8 Class Initialized
INFO - 2017-01-20 13:33:06 --> URI Class Initialized
INFO - 2017-01-20 13:33:06 --> Router Class Initialized
INFO - 2017-01-20 13:33:06 --> Output Class Initialized
INFO - 2017-01-20 13:33:06 --> Security Class Initialized
DEBUG - 2017-01-20 13:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:33:06 --> Input Class Initialized
INFO - 2017-01-20 13:33:06 --> Language Class Initialized
INFO - 2017-01-20 13:33:06 --> Loader Class Initialized
INFO - 2017-01-20 13:33:06 --> Helper loaded: url_helper
INFO - 2017-01-20 13:33:06 --> Helper loaded: language_helper
INFO - 2017-01-20 13:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:33:06 --> Controller Class Initialized
INFO - 2017-01-20 13:33:06 --> Database Driver Class Initialized
INFO - 2017-01-20 13:33:06 --> Model Class Initialized
INFO - 2017-01-20 13:33:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:33:06 --> Helper loaded: form_helper
INFO - 2017-01-20 13:33:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:33:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:33:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:33:06 --> Final output sent to browser
DEBUG - 2017-01-20 13:33:06 --> Total execution time: 0.1392
INFO - 2017-01-20 13:33:09 --> Config Class Initialized
INFO - 2017-01-20 13:33:09 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:33:09 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:33:09 --> Utf8 Class Initialized
INFO - 2017-01-20 13:33:09 --> URI Class Initialized
INFO - 2017-01-20 13:33:09 --> Router Class Initialized
INFO - 2017-01-20 13:33:09 --> Output Class Initialized
INFO - 2017-01-20 13:33:09 --> Security Class Initialized
DEBUG - 2017-01-20 13:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:33:09 --> Input Class Initialized
INFO - 2017-01-20 13:33:09 --> Language Class Initialized
INFO - 2017-01-20 13:33:09 --> Loader Class Initialized
INFO - 2017-01-20 13:33:09 --> Helper loaded: url_helper
INFO - 2017-01-20 13:33:09 --> Helper loaded: language_helper
INFO - 2017-01-20 13:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:33:09 --> Controller Class Initialized
INFO - 2017-01-20 13:33:09 --> Database Driver Class Initialized
INFO - 2017-01-20 13:33:09 --> Model Class Initialized
INFO - 2017-01-20 13:33:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:33:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:33:10 --> Final output sent to browser
DEBUG - 2017-01-20 13:33:10 --> Total execution time: 0.9645
INFO - 2017-01-20 13:34:48 --> Config Class Initialized
INFO - 2017-01-20 13:34:48 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:34:48 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:34:48 --> Utf8 Class Initialized
INFO - 2017-01-20 13:34:48 --> URI Class Initialized
INFO - 2017-01-20 13:34:48 --> Router Class Initialized
INFO - 2017-01-20 13:34:48 --> Output Class Initialized
INFO - 2017-01-20 13:34:48 --> Security Class Initialized
DEBUG - 2017-01-20 13:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:34:48 --> Input Class Initialized
INFO - 2017-01-20 13:34:48 --> Language Class Initialized
INFO - 2017-01-20 13:34:48 --> Loader Class Initialized
INFO - 2017-01-20 13:34:48 --> Helper loaded: url_helper
INFO - 2017-01-20 13:34:48 --> Helper loaded: language_helper
INFO - 2017-01-20 13:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:34:48 --> Controller Class Initialized
INFO - 2017-01-20 13:34:48 --> Database Driver Class Initialized
INFO - 2017-01-20 13:34:48 --> Model Class Initialized
INFO - 2017-01-20 13:34:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:34:48 --> Helper loaded: form_helper
INFO - 2017-01-20 13:34:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:34:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:34:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:34:48 --> Final output sent to browser
DEBUG - 2017-01-20 13:34:48 --> Total execution time: 0.1550
INFO - 2017-01-20 13:36:05 --> Config Class Initialized
INFO - 2017-01-20 13:36:05 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:36:05 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:36:05 --> Utf8 Class Initialized
INFO - 2017-01-20 13:36:05 --> URI Class Initialized
INFO - 2017-01-20 13:36:05 --> Router Class Initialized
INFO - 2017-01-20 13:36:05 --> Output Class Initialized
INFO - 2017-01-20 13:36:05 --> Security Class Initialized
DEBUG - 2017-01-20 13:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:36:05 --> Input Class Initialized
INFO - 2017-01-20 13:36:05 --> Language Class Initialized
INFO - 2017-01-20 13:36:05 --> Loader Class Initialized
INFO - 2017-01-20 13:36:05 --> Helper loaded: url_helper
INFO - 2017-01-20 13:36:05 --> Helper loaded: language_helper
INFO - 2017-01-20 13:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:36:05 --> Controller Class Initialized
INFO - 2017-01-20 13:36:05 --> Database Driver Class Initialized
INFO - 2017-01-20 13:36:05 --> Model Class Initialized
INFO - 2017-01-20 13:36:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:36:05 --> Helper loaded: form_helper
INFO - 2017-01-20 13:36:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:36:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:36:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:36:05 --> Final output sent to browser
DEBUG - 2017-01-20 13:36:05 --> Total execution time: 0.1562
INFO - 2017-01-20 13:37:40 --> Config Class Initialized
INFO - 2017-01-20 13:37:40 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:37:40 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:37:40 --> Utf8 Class Initialized
INFO - 2017-01-20 13:37:40 --> URI Class Initialized
INFO - 2017-01-20 13:37:40 --> Router Class Initialized
INFO - 2017-01-20 13:37:40 --> Output Class Initialized
INFO - 2017-01-20 13:37:40 --> Security Class Initialized
DEBUG - 2017-01-20 13:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:37:40 --> Input Class Initialized
INFO - 2017-01-20 13:37:40 --> Language Class Initialized
INFO - 2017-01-20 13:37:40 --> Loader Class Initialized
INFO - 2017-01-20 13:37:40 --> Helper loaded: url_helper
INFO - 2017-01-20 13:37:40 --> Helper loaded: language_helper
INFO - 2017-01-20 13:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:37:40 --> Controller Class Initialized
INFO - 2017-01-20 13:37:40 --> Database Driver Class Initialized
INFO - 2017-01-20 13:37:41 --> Model Class Initialized
INFO - 2017-01-20 13:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:37:41 --> Helper loaded: form_helper
INFO - 2017-01-20 13:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:37:41 --> Final output sent to browser
DEBUG - 2017-01-20 13:37:41 --> Total execution time: 0.2107
INFO - 2017-01-20 13:38:31 --> Config Class Initialized
INFO - 2017-01-20 13:38:31 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:38:31 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:38:31 --> Utf8 Class Initialized
INFO - 2017-01-20 13:38:31 --> URI Class Initialized
INFO - 2017-01-20 13:38:31 --> Router Class Initialized
INFO - 2017-01-20 13:38:31 --> Output Class Initialized
INFO - 2017-01-20 13:38:31 --> Security Class Initialized
DEBUG - 2017-01-20 13:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:38:31 --> Input Class Initialized
INFO - 2017-01-20 13:38:31 --> Language Class Initialized
INFO - 2017-01-20 13:38:31 --> Loader Class Initialized
INFO - 2017-01-20 13:38:31 --> Helper loaded: url_helper
INFO - 2017-01-20 13:38:31 --> Helper loaded: language_helper
INFO - 2017-01-20 13:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:38:31 --> Controller Class Initialized
INFO - 2017-01-20 13:38:31 --> Database Driver Class Initialized
INFO - 2017-01-20 13:38:31 --> Model Class Initialized
INFO - 2017-01-20 13:38:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:38:31 --> Helper loaded: form_helper
INFO - 2017-01-20 13:38:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:38:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:38:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:38:32 --> Final output sent to browser
DEBUG - 2017-01-20 13:38:32 --> Total execution time: 0.1409
INFO - 2017-01-20 13:40:17 --> Config Class Initialized
INFO - 2017-01-20 13:40:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:40:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:40:17 --> Utf8 Class Initialized
INFO - 2017-01-20 13:40:17 --> URI Class Initialized
INFO - 2017-01-20 13:40:17 --> Router Class Initialized
INFO - 2017-01-20 13:40:17 --> Output Class Initialized
INFO - 2017-01-20 13:40:17 --> Security Class Initialized
DEBUG - 2017-01-20 13:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:40:17 --> Input Class Initialized
INFO - 2017-01-20 13:40:17 --> Language Class Initialized
INFO - 2017-01-20 13:40:17 --> Loader Class Initialized
INFO - 2017-01-20 13:40:17 --> Helper loaded: url_helper
INFO - 2017-01-20 13:40:17 --> Helper loaded: language_helper
INFO - 2017-01-20 13:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:40:17 --> Controller Class Initialized
INFO - 2017-01-20 13:40:17 --> Database Driver Class Initialized
INFO - 2017-01-20 13:40:17 --> Model Class Initialized
INFO - 2017-01-20 13:40:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:40:17 --> Helper loaded: form_helper
INFO - 2017-01-20 13:40:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:40:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:40:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:40:17 --> Final output sent to browser
DEBUG - 2017-01-20 13:40:17 --> Total execution time: 0.1643
INFO - 2017-01-20 13:40:27 --> Config Class Initialized
INFO - 2017-01-20 13:40:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:40:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:40:27 --> Utf8 Class Initialized
INFO - 2017-01-20 13:40:27 --> URI Class Initialized
INFO - 2017-01-20 13:40:27 --> Router Class Initialized
INFO - 2017-01-20 13:40:27 --> Output Class Initialized
INFO - 2017-01-20 13:40:27 --> Security Class Initialized
DEBUG - 2017-01-20 13:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:40:27 --> Input Class Initialized
INFO - 2017-01-20 13:40:27 --> Language Class Initialized
INFO - 2017-01-20 13:40:27 --> Loader Class Initialized
INFO - 2017-01-20 13:40:27 --> Helper loaded: url_helper
INFO - 2017-01-20 13:40:27 --> Helper loaded: language_helper
INFO - 2017-01-20 13:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:40:27 --> Controller Class Initialized
INFO - 2017-01-20 13:40:27 --> Database Driver Class Initialized
INFO - 2017-01-20 13:40:27 --> Model Class Initialized
INFO - 2017-01-20 13:40:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:40:27 --> Final output sent to browser
DEBUG - 2017-01-20 13:40:27 --> Total execution time: 0.7398
INFO - 2017-01-20 13:40:47 --> Config Class Initialized
INFO - 2017-01-20 13:40:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:40:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:40:47 --> Utf8 Class Initialized
INFO - 2017-01-20 13:40:47 --> URI Class Initialized
INFO - 2017-01-20 13:40:47 --> Router Class Initialized
INFO - 2017-01-20 13:40:47 --> Output Class Initialized
INFO - 2017-01-20 13:40:47 --> Security Class Initialized
DEBUG - 2017-01-20 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:40:47 --> Input Class Initialized
INFO - 2017-01-20 13:40:47 --> Language Class Initialized
INFO - 2017-01-20 13:40:47 --> Loader Class Initialized
INFO - 2017-01-20 13:40:47 --> Helper loaded: url_helper
INFO - 2017-01-20 13:40:47 --> Helper loaded: language_helper
INFO - 2017-01-20 13:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:40:47 --> Controller Class Initialized
INFO - 2017-01-20 13:40:47 --> Database Driver Class Initialized
INFO - 2017-01-20 13:40:47 --> Model Class Initialized
INFO - 2017-01-20 13:40:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:40:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:40:48 --> Final output sent to browser
DEBUG - 2017-01-20 13:40:48 --> Total execution time: 0.9639
INFO - 2017-01-20 13:41:12 --> Config Class Initialized
INFO - 2017-01-20 13:41:12 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:41:12 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:41:12 --> Utf8 Class Initialized
INFO - 2017-01-20 13:41:12 --> URI Class Initialized
INFO - 2017-01-20 13:41:12 --> Router Class Initialized
INFO - 2017-01-20 13:41:12 --> Output Class Initialized
INFO - 2017-01-20 13:41:12 --> Security Class Initialized
DEBUG - 2017-01-20 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:41:12 --> Input Class Initialized
INFO - 2017-01-20 13:41:12 --> Language Class Initialized
INFO - 2017-01-20 13:41:12 --> Loader Class Initialized
INFO - 2017-01-20 13:41:12 --> Helper loaded: url_helper
INFO - 2017-01-20 13:41:12 --> Helper loaded: language_helper
INFO - 2017-01-20 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:41:12 --> Controller Class Initialized
INFO - 2017-01-20 13:41:12 --> Database Driver Class Initialized
INFO - 2017-01-20 13:41:12 --> Model Class Initialized
INFO - 2017-01-20 13:41:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:41:12 --> Helper loaded: form_helper
INFO - 2017-01-20 13:41:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:41:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:41:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:41:12 --> Final output sent to browser
DEBUG - 2017-01-20 13:41:12 --> Total execution time: 0.1696
INFO - 2017-01-20 13:41:14 --> Config Class Initialized
INFO - 2017-01-20 13:41:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:41:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:41:14 --> Utf8 Class Initialized
INFO - 2017-01-20 13:41:14 --> URI Class Initialized
INFO - 2017-01-20 13:41:14 --> Router Class Initialized
INFO - 2017-01-20 13:41:14 --> Output Class Initialized
INFO - 2017-01-20 13:41:14 --> Security Class Initialized
DEBUG - 2017-01-20 13:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:41:14 --> Input Class Initialized
INFO - 2017-01-20 13:41:14 --> Language Class Initialized
INFO - 2017-01-20 13:41:14 --> Loader Class Initialized
INFO - 2017-01-20 13:41:14 --> Helper loaded: url_helper
INFO - 2017-01-20 13:41:14 --> Helper loaded: language_helper
INFO - 2017-01-20 13:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:41:14 --> Controller Class Initialized
INFO - 2017-01-20 13:41:14 --> Database Driver Class Initialized
INFO - 2017-01-20 13:41:14 --> Model Class Initialized
INFO - 2017-01-20 13:41:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:41:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:41:15 --> Final output sent to browser
DEBUG - 2017-01-20 13:41:15 --> Total execution time: 1.1404
INFO - 2017-01-20 13:41:39 --> Config Class Initialized
INFO - 2017-01-20 13:41:39 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:41:39 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:41:39 --> Utf8 Class Initialized
INFO - 2017-01-20 13:41:39 --> URI Class Initialized
INFO - 2017-01-20 13:41:39 --> Router Class Initialized
INFO - 2017-01-20 13:41:39 --> Output Class Initialized
INFO - 2017-01-20 13:41:39 --> Security Class Initialized
DEBUG - 2017-01-20 13:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:41:39 --> Input Class Initialized
INFO - 2017-01-20 13:41:39 --> Language Class Initialized
INFO - 2017-01-20 13:41:39 --> Loader Class Initialized
INFO - 2017-01-20 13:41:39 --> Helper loaded: url_helper
INFO - 2017-01-20 13:41:39 --> Helper loaded: language_helper
INFO - 2017-01-20 13:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:41:39 --> Controller Class Initialized
INFO - 2017-01-20 13:41:39 --> Database Driver Class Initialized
INFO - 2017-01-20 13:41:39 --> Model Class Initialized
INFO - 2017-01-20 13:41:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:41:39 --> Helper loaded: form_helper
INFO - 2017-01-20 13:41:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:41:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:41:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:41:39 --> Final output sent to browser
DEBUG - 2017-01-20 13:41:39 --> Total execution time: 0.1582
INFO - 2017-01-20 13:43:22 --> Config Class Initialized
INFO - 2017-01-20 13:43:22 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:43:22 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:43:22 --> Utf8 Class Initialized
INFO - 2017-01-20 13:43:22 --> URI Class Initialized
INFO - 2017-01-20 13:43:22 --> Router Class Initialized
INFO - 2017-01-20 13:43:22 --> Output Class Initialized
INFO - 2017-01-20 13:43:22 --> Security Class Initialized
DEBUG - 2017-01-20 13:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:43:22 --> Input Class Initialized
INFO - 2017-01-20 13:43:22 --> Language Class Initialized
INFO - 2017-01-20 13:43:22 --> Loader Class Initialized
INFO - 2017-01-20 13:43:22 --> Helper loaded: url_helper
INFO - 2017-01-20 13:43:22 --> Helper loaded: language_helper
INFO - 2017-01-20 13:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:43:22 --> Controller Class Initialized
INFO - 2017-01-20 13:43:22 --> Database Driver Class Initialized
INFO - 2017-01-20 13:43:22 --> Model Class Initialized
INFO - 2017-01-20 13:43:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:43:22 --> Helper loaded: form_helper
INFO - 2017-01-20 13:43:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:43:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:43:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:43:22 --> Final output sent to browser
DEBUG - 2017-01-20 13:43:22 --> Total execution time: 0.1740
INFO - 2017-01-20 13:43:27 --> Config Class Initialized
INFO - 2017-01-20 13:43:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:43:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:43:27 --> Utf8 Class Initialized
INFO - 2017-01-20 13:43:27 --> URI Class Initialized
INFO - 2017-01-20 13:43:27 --> Router Class Initialized
INFO - 2017-01-20 13:43:27 --> Output Class Initialized
INFO - 2017-01-20 13:43:27 --> Security Class Initialized
DEBUG - 2017-01-20 13:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:43:27 --> Input Class Initialized
INFO - 2017-01-20 13:43:27 --> Language Class Initialized
INFO - 2017-01-20 13:43:27 --> Loader Class Initialized
INFO - 2017-01-20 13:43:27 --> Helper loaded: url_helper
INFO - 2017-01-20 13:43:27 --> Helper loaded: language_helper
INFO - 2017-01-20 13:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:43:27 --> Controller Class Initialized
INFO - 2017-01-20 13:43:27 --> Database Driver Class Initialized
INFO - 2017-01-20 13:43:27 --> Model Class Initialized
INFO - 2017-01-20 13:43:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:43:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:43:28 --> Final output sent to browser
DEBUG - 2017-01-20 13:43:28 --> Total execution time: 0.7349
INFO - 2017-01-20 13:43:41 --> Config Class Initialized
INFO - 2017-01-20 13:43:41 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:43:41 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:43:41 --> Utf8 Class Initialized
INFO - 2017-01-20 13:43:41 --> URI Class Initialized
INFO - 2017-01-20 13:43:41 --> Router Class Initialized
INFO - 2017-01-20 13:43:41 --> Output Class Initialized
INFO - 2017-01-20 13:43:41 --> Security Class Initialized
DEBUG - 2017-01-20 13:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:43:41 --> Input Class Initialized
INFO - 2017-01-20 13:43:41 --> Language Class Initialized
INFO - 2017-01-20 13:43:41 --> Loader Class Initialized
INFO - 2017-01-20 13:43:41 --> Helper loaded: url_helper
INFO - 2017-01-20 13:43:41 --> Helper loaded: language_helper
INFO - 2017-01-20 13:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:43:41 --> Controller Class Initialized
INFO - 2017-01-20 13:43:41 --> Database Driver Class Initialized
INFO - 2017-01-20 13:43:41 --> Model Class Initialized
INFO - 2017-01-20 13:43:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:43:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:43:42 --> Final output sent to browser
DEBUG - 2017-01-20 13:43:42 --> Total execution time: 0.9825
INFO - 2017-01-20 13:44:28 --> Config Class Initialized
INFO - 2017-01-20 13:44:28 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:44:28 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:44:28 --> Utf8 Class Initialized
INFO - 2017-01-20 13:44:28 --> URI Class Initialized
INFO - 2017-01-20 13:44:28 --> Router Class Initialized
INFO - 2017-01-20 13:44:28 --> Output Class Initialized
INFO - 2017-01-20 13:44:28 --> Security Class Initialized
DEBUG - 2017-01-20 13:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:44:28 --> Input Class Initialized
INFO - 2017-01-20 13:44:28 --> Language Class Initialized
INFO - 2017-01-20 13:44:28 --> Loader Class Initialized
INFO - 2017-01-20 13:44:28 --> Helper loaded: url_helper
INFO - 2017-01-20 13:44:28 --> Helper loaded: language_helper
INFO - 2017-01-20 13:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:44:28 --> Controller Class Initialized
INFO - 2017-01-20 13:44:28 --> Database Driver Class Initialized
INFO - 2017-01-20 13:44:28 --> Model Class Initialized
INFO - 2017-01-20 13:44:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:44:28 --> Helper loaded: form_helper
INFO - 2017-01-20 13:44:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:44:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:44:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:44:28 --> Final output sent to browser
DEBUG - 2017-01-20 13:44:28 --> Total execution time: 0.2439
INFO - 2017-01-20 13:44:31 --> Config Class Initialized
INFO - 2017-01-20 13:44:31 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:44:31 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:44:31 --> Utf8 Class Initialized
INFO - 2017-01-20 13:44:31 --> URI Class Initialized
INFO - 2017-01-20 13:44:31 --> Router Class Initialized
INFO - 2017-01-20 13:44:31 --> Output Class Initialized
INFO - 2017-01-20 13:44:31 --> Security Class Initialized
DEBUG - 2017-01-20 13:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:44:31 --> Input Class Initialized
INFO - 2017-01-20 13:44:31 --> Language Class Initialized
INFO - 2017-01-20 13:44:31 --> Loader Class Initialized
INFO - 2017-01-20 13:44:31 --> Helper loaded: url_helper
INFO - 2017-01-20 13:44:31 --> Helper loaded: language_helper
INFO - 2017-01-20 13:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:44:31 --> Controller Class Initialized
INFO - 2017-01-20 13:44:31 --> Database Driver Class Initialized
INFO - 2017-01-20 13:44:31 --> Model Class Initialized
INFO - 2017-01-20 13:44:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:44:31 --> Model Class Initialized
INFO - 2017-01-20 13:44:31 --> Helper loaded: form_helper
INFO - 2017-01-20 13:44:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:44:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:44:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:44:31 --> Final output sent to browser
DEBUG - 2017-01-20 13:44:31 --> Total execution time: 0.7085
INFO - 2017-01-20 13:44:33 --> Config Class Initialized
INFO - 2017-01-20 13:44:33 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:44:33 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:44:33 --> Utf8 Class Initialized
INFO - 2017-01-20 13:44:33 --> URI Class Initialized
INFO - 2017-01-20 13:44:33 --> Router Class Initialized
INFO - 2017-01-20 13:44:33 --> Output Class Initialized
INFO - 2017-01-20 13:44:33 --> Security Class Initialized
DEBUG - 2017-01-20 13:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:44:33 --> Input Class Initialized
INFO - 2017-01-20 13:44:34 --> Language Class Initialized
INFO - 2017-01-20 13:44:34 --> Loader Class Initialized
INFO - 2017-01-20 13:44:34 --> Helper loaded: url_helper
INFO - 2017-01-20 13:44:34 --> Helper loaded: language_helper
INFO - 2017-01-20 13:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:44:34 --> Controller Class Initialized
INFO - 2017-01-20 13:44:34 --> Database Driver Class Initialized
INFO - 2017-01-20 13:44:34 --> Model Class Initialized
INFO - 2017-01-20 13:44:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:44:34 --> Model Class Initialized
INFO - 2017-01-20 13:44:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:44:35 --> Final output sent to browser
DEBUG - 2017-01-20 13:44:35 --> Total execution time: 1.4994
INFO - 2017-01-20 13:44:38 --> Config Class Initialized
INFO - 2017-01-20 13:44:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:44:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:44:38 --> Utf8 Class Initialized
INFO - 2017-01-20 13:44:38 --> URI Class Initialized
INFO - 2017-01-20 13:44:38 --> Router Class Initialized
INFO - 2017-01-20 13:44:38 --> Output Class Initialized
INFO - 2017-01-20 13:44:38 --> Security Class Initialized
DEBUG - 2017-01-20 13:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:44:38 --> Input Class Initialized
INFO - 2017-01-20 13:44:38 --> Language Class Initialized
INFO - 2017-01-20 13:44:38 --> Loader Class Initialized
INFO - 2017-01-20 13:44:38 --> Helper loaded: url_helper
INFO - 2017-01-20 13:44:38 --> Helper loaded: language_helper
INFO - 2017-01-20 13:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:44:38 --> Controller Class Initialized
INFO - 2017-01-20 13:44:38 --> Database Driver Class Initialized
INFO - 2017-01-20 13:44:38 --> Model Class Initialized
INFO - 2017-01-20 13:44:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:44:38 --> Model Class Initialized
INFO - 2017-01-20 13:44:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:44:39 --> Final output sent to browser
DEBUG - 2017-01-20 13:44:39 --> Total execution time: 0.9373
INFO - 2017-01-20 13:45:27 --> Config Class Initialized
INFO - 2017-01-20 13:45:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:45:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:45:27 --> Utf8 Class Initialized
INFO - 2017-01-20 13:45:27 --> URI Class Initialized
INFO - 2017-01-20 13:45:27 --> Router Class Initialized
INFO - 2017-01-20 13:45:27 --> Output Class Initialized
INFO - 2017-01-20 13:45:27 --> Security Class Initialized
DEBUG - 2017-01-20 13:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:45:27 --> Input Class Initialized
INFO - 2017-01-20 13:45:27 --> Language Class Initialized
INFO - 2017-01-20 13:45:27 --> Loader Class Initialized
INFO - 2017-01-20 13:45:27 --> Helper loaded: url_helper
INFO - 2017-01-20 13:45:27 --> Helper loaded: language_helper
INFO - 2017-01-20 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:45:27 --> Controller Class Initialized
INFO - 2017-01-20 13:45:27 --> Database Driver Class Initialized
INFO - 2017-01-20 13:45:27 --> Model Class Initialized
INFO - 2017-01-20 13:45:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:45:27 --> Model Class Initialized
INFO - 2017-01-20 13:45:27 --> Helper loaded: form_helper
INFO - 2017-01-20 13:45:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:45:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:45:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:45:28 --> Final output sent to browser
DEBUG - 2017-01-20 13:45:28 --> Total execution time: 0.6445
INFO - 2017-01-20 13:45:32 --> Config Class Initialized
INFO - 2017-01-20 13:45:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:45:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:45:32 --> Utf8 Class Initialized
INFO - 2017-01-20 13:45:32 --> URI Class Initialized
INFO - 2017-01-20 13:45:32 --> Router Class Initialized
INFO - 2017-01-20 13:45:32 --> Output Class Initialized
INFO - 2017-01-20 13:45:32 --> Security Class Initialized
DEBUG - 2017-01-20 13:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:45:32 --> Input Class Initialized
INFO - 2017-01-20 13:45:32 --> Language Class Initialized
INFO - 2017-01-20 13:45:32 --> Loader Class Initialized
INFO - 2017-01-20 13:45:32 --> Helper loaded: url_helper
INFO - 2017-01-20 13:45:32 --> Helper loaded: language_helper
INFO - 2017-01-20 13:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:45:32 --> Controller Class Initialized
INFO - 2017-01-20 13:45:32 --> Database Driver Class Initialized
INFO - 2017-01-20 13:45:32 --> Model Class Initialized
INFO - 2017-01-20 13:45:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:45:32 --> Model Class Initialized
INFO - 2017-01-20 13:45:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:45:33 --> Final output sent to browser
DEBUG - 2017-01-20 13:45:33 --> Total execution time: 0.8185
INFO - 2017-01-20 13:45:39 --> Config Class Initialized
INFO - 2017-01-20 13:45:39 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:45:39 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:45:39 --> Utf8 Class Initialized
INFO - 2017-01-20 13:45:39 --> URI Class Initialized
INFO - 2017-01-20 13:45:39 --> Router Class Initialized
INFO - 2017-01-20 13:45:39 --> Output Class Initialized
INFO - 2017-01-20 13:45:39 --> Security Class Initialized
DEBUG - 2017-01-20 13:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:45:39 --> Input Class Initialized
INFO - 2017-01-20 13:45:39 --> Language Class Initialized
INFO - 2017-01-20 13:45:39 --> Loader Class Initialized
INFO - 2017-01-20 13:45:39 --> Helper loaded: url_helper
INFO - 2017-01-20 13:45:39 --> Helper loaded: language_helper
INFO - 2017-01-20 13:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:45:39 --> Controller Class Initialized
INFO - 2017-01-20 13:45:39 --> Database Driver Class Initialized
INFO - 2017-01-20 13:45:39 --> Model Class Initialized
INFO - 2017-01-20 13:45:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:45:39 --> Model Class Initialized
INFO - 2017-01-20 13:45:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:45:41 --> Final output sent to browser
DEBUG - 2017-01-20 13:45:41 --> Total execution time: 1.4281
INFO - 2017-01-20 13:45:48 --> Config Class Initialized
INFO - 2017-01-20 13:45:48 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:45:48 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:45:48 --> Utf8 Class Initialized
INFO - 2017-01-20 13:45:48 --> URI Class Initialized
INFO - 2017-01-20 13:45:48 --> Router Class Initialized
INFO - 2017-01-20 13:45:48 --> Output Class Initialized
INFO - 2017-01-20 13:45:48 --> Security Class Initialized
DEBUG - 2017-01-20 13:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:45:48 --> Input Class Initialized
INFO - 2017-01-20 13:45:48 --> Language Class Initialized
INFO - 2017-01-20 13:45:48 --> Loader Class Initialized
INFO - 2017-01-20 13:45:48 --> Helper loaded: url_helper
INFO - 2017-01-20 13:45:48 --> Helper loaded: language_helper
INFO - 2017-01-20 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:45:48 --> Controller Class Initialized
INFO - 2017-01-20 13:45:48 --> Database Driver Class Initialized
INFO - 2017-01-20 13:45:48 --> Model Class Initialized
INFO - 2017-01-20 13:45:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:45:48 --> Model Class Initialized
INFO - 2017-01-20 13:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:45:49 --> Final output sent to browser
DEBUG - 2017-01-20 13:45:49 --> Total execution time: 1.1874
INFO - 2017-01-20 13:45:52 --> Config Class Initialized
INFO - 2017-01-20 13:45:52 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:45:52 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:45:52 --> Utf8 Class Initialized
INFO - 2017-01-20 13:45:52 --> URI Class Initialized
INFO - 2017-01-20 13:45:52 --> Router Class Initialized
INFO - 2017-01-20 13:45:52 --> Output Class Initialized
INFO - 2017-01-20 13:45:52 --> Security Class Initialized
DEBUG - 2017-01-20 13:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:45:52 --> Input Class Initialized
INFO - 2017-01-20 13:45:52 --> Language Class Initialized
INFO - 2017-01-20 13:45:52 --> Loader Class Initialized
INFO - 2017-01-20 13:45:52 --> Helper loaded: url_helper
INFO - 2017-01-20 13:45:52 --> Helper loaded: language_helper
INFO - 2017-01-20 13:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:45:52 --> Controller Class Initialized
INFO - 2017-01-20 13:45:52 --> Database Driver Class Initialized
INFO - 2017-01-20 13:45:52 --> Model Class Initialized
INFO - 2017-01-20 13:45:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:45:52 --> Model Class Initialized
INFO - 2017-01-20 13:45:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:45:53 --> Final output sent to browser
DEBUG - 2017-01-20 13:45:53 --> Total execution time: 0.8667
INFO - 2017-01-20 13:46:18 --> Config Class Initialized
INFO - 2017-01-20 13:46:18 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:46:18 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:46:18 --> Utf8 Class Initialized
INFO - 2017-01-20 13:46:18 --> URI Class Initialized
INFO - 2017-01-20 13:46:18 --> Router Class Initialized
INFO - 2017-01-20 13:46:18 --> Output Class Initialized
INFO - 2017-01-20 13:46:18 --> Security Class Initialized
DEBUG - 2017-01-20 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:46:18 --> Input Class Initialized
INFO - 2017-01-20 13:46:18 --> Language Class Initialized
INFO - 2017-01-20 13:46:18 --> Loader Class Initialized
INFO - 2017-01-20 13:46:18 --> Helper loaded: url_helper
INFO - 2017-01-20 13:46:18 --> Helper loaded: language_helper
INFO - 2017-01-20 13:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:46:18 --> Controller Class Initialized
INFO - 2017-01-20 13:46:18 --> Database Driver Class Initialized
INFO - 2017-01-20 13:46:18 --> Model Class Initialized
INFO - 2017-01-20 13:46:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:46:18 --> Model Class Initialized
INFO - 2017-01-20 13:46:18 --> Helper loaded: form_helper
INFO - 2017-01-20 13:46:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:46:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:46:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:46:19 --> Final output sent to browser
DEBUG - 2017-01-20 13:46:19 --> Total execution time: 0.5886
INFO - 2017-01-20 13:46:21 --> Config Class Initialized
INFO - 2017-01-20 13:46:21 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:46:21 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:46:21 --> Utf8 Class Initialized
INFO - 2017-01-20 13:46:21 --> URI Class Initialized
INFO - 2017-01-20 13:46:21 --> Router Class Initialized
INFO - 2017-01-20 13:46:21 --> Output Class Initialized
INFO - 2017-01-20 13:46:21 --> Security Class Initialized
DEBUG - 2017-01-20 13:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:46:21 --> Input Class Initialized
INFO - 2017-01-20 13:46:21 --> Language Class Initialized
INFO - 2017-01-20 13:46:21 --> Loader Class Initialized
INFO - 2017-01-20 13:46:21 --> Helper loaded: url_helper
INFO - 2017-01-20 13:46:21 --> Helper loaded: language_helper
INFO - 2017-01-20 13:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:46:21 --> Controller Class Initialized
INFO - 2017-01-20 13:46:21 --> Database Driver Class Initialized
INFO - 2017-01-20 13:46:22 --> Model Class Initialized
INFO - 2017-01-20 13:46:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:46:22 --> Model Class Initialized
INFO - 2017-01-20 13:46:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:46:22 --> Final output sent to browser
DEBUG - 2017-01-20 13:46:22 --> Total execution time: 0.8596
INFO - 2017-01-20 13:46:26 --> Config Class Initialized
INFO - 2017-01-20 13:46:26 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:46:26 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:46:26 --> Utf8 Class Initialized
INFO - 2017-01-20 13:46:26 --> URI Class Initialized
INFO - 2017-01-20 13:46:26 --> Router Class Initialized
INFO - 2017-01-20 13:46:26 --> Output Class Initialized
INFO - 2017-01-20 13:46:26 --> Security Class Initialized
DEBUG - 2017-01-20 13:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:46:26 --> Input Class Initialized
INFO - 2017-01-20 13:46:26 --> Language Class Initialized
INFO - 2017-01-20 13:46:26 --> Loader Class Initialized
INFO - 2017-01-20 13:46:26 --> Helper loaded: url_helper
INFO - 2017-01-20 13:46:26 --> Helper loaded: language_helper
INFO - 2017-01-20 13:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:46:26 --> Controller Class Initialized
INFO - 2017-01-20 13:46:26 --> Database Driver Class Initialized
INFO - 2017-01-20 13:46:26 --> Model Class Initialized
INFO - 2017-01-20 13:46:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:46:26 --> Model Class Initialized
INFO - 2017-01-20 13:46:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:46:27 --> Final output sent to browser
DEBUG - 2017-01-20 13:46:27 --> Total execution time: 1.1497
INFO - 2017-01-20 13:46:46 --> Config Class Initialized
INFO - 2017-01-20 13:46:46 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:46:46 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:46:46 --> Utf8 Class Initialized
INFO - 2017-01-20 13:46:46 --> URI Class Initialized
INFO - 2017-01-20 13:46:46 --> Router Class Initialized
INFO - 2017-01-20 13:46:46 --> Output Class Initialized
INFO - 2017-01-20 13:46:46 --> Security Class Initialized
DEBUG - 2017-01-20 13:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:46:46 --> Input Class Initialized
INFO - 2017-01-20 13:46:46 --> Language Class Initialized
INFO - 2017-01-20 13:46:46 --> Loader Class Initialized
INFO - 2017-01-20 13:46:46 --> Helper loaded: url_helper
INFO - 2017-01-20 13:46:46 --> Helper loaded: language_helper
INFO - 2017-01-20 13:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:46:46 --> Controller Class Initialized
INFO - 2017-01-20 13:46:46 --> Database Driver Class Initialized
INFO - 2017-01-20 13:46:46 --> Model Class Initialized
INFO - 2017-01-20 13:46:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:46:46 --> Helper loaded: form_helper
INFO - 2017-01-20 13:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:46:47 --> Final output sent to browser
DEBUG - 2017-01-20 13:46:47 --> Total execution time: 0.2041
INFO - 2017-01-20 13:46:50 --> Config Class Initialized
INFO - 2017-01-20 13:46:50 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:46:50 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:46:50 --> Utf8 Class Initialized
INFO - 2017-01-20 13:46:50 --> URI Class Initialized
INFO - 2017-01-20 13:46:50 --> Router Class Initialized
INFO - 2017-01-20 13:46:50 --> Output Class Initialized
INFO - 2017-01-20 13:46:50 --> Security Class Initialized
DEBUG - 2017-01-20 13:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:46:50 --> Input Class Initialized
INFO - 2017-01-20 13:46:50 --> Language Class Initialized
INFO - 2017-01-20 13:46:50 --> Loader Class Initialized
INFO - 2017-01-20 13:46:50 --> Helper loaded: url_helper
INFO - 2017-01-20 13:46:50 --> Helper loaded: language_helper
INFO - 2017-01-20 13:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:46:50 --> Controller Class Initialized
INFO - 2017-01-20 13:46:50 --> Database Driver Class Initialized
INFO - 2017-01-20 13:46:50 --> Model Class Initialized
INFO - 2017-01-20 13:46:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:46:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:46:50 --> Final output sent to browser
DEBUG - 2017-01-20 13:46:50 --> Total execution time: 0.7030
INFO - 2017-01-20 13:46:55 --> Config Class Initialized
INFO - 2017-01-20 13:46:55 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:46:55 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:46:55 --> Utf8 Class Initialized
INFO - 2017-01-20 13:46:55 --> URI Class Initialized
INFO - 2017-01-20 13:46:55 --> Router Class Initialized
INFO - 2017-01-20 13:46:55 --> Output Class Initialized
INFO - 2017-01-20 13:46:55 --> Security Class Initialized
DEBUG - 2017-01-20 13:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:46:55 --> Input Class Initialized
INFO - 2017-01-20 13:46:55 --> Language Class Initialized
INFO - 2017-01-20 13:46:55 --> Loader Class Initialized
INFO - 2017-01-20 13:46:55 --> Helper loaded: url_helper
INFO - 2017-01-20 13:46:55 --> Helper loaded: language_helper
INFO - 2017-01-20 13:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:46:55 --> Controller Class Initialized
INFO - 2017-01-20 13:46:55 --> Database Driver Class Initialized
INFO - 2017-01-20 13:46:56 --> Model Class Initialized
INFO - 2017-01-20 13:46:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:46:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:46:56 --> Final output sent to browser
DEBUG - 2017-01-20 13:46:56 --> Total execution time: 0.9899
INFO - 2017-01-20 13:48:42 --> Config Class Initialized
INFO - 2017-01-20 13:48:42 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:48:42 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:48:42 --> Utf8 Class Initialized
INFO - 2017-01-20 13:48:42 --> URI Class Initialized
INFO - 2017-01-20 13:48:42 --> Router Class Initialized
INFO - 2017-01-20 13:48:42 --> Output Class Initialized
INFO - 2017-01-20 13:48:42 --> Security Class Initialized
DEBUG - 2017-01-20 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:48:42 --> Input Class Initialized
INFO - 2017-01-20 13:48:42 --> Language Class Initialized
INFO - 2017-01-20 13:48:42 --> Loader Class Initialized
INFO - 2017-01-20 13:48:42 --> Helper loaded: url_helper
INFO - 2017-01-20 13:48:42 --> Helper loaded: language_helper
INFO - 2017-01-20 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:48:42 --> Controller Class Initialized
INFO - 2017-01-20 13:48:42 --> Database Driver Class Initialized
INFO - 2017-01-20 13:48:42 --> Model Class Initialized
INFO - 2017-01-20 13:48:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:48:42 --> Helper loaded: form_helper
INFO - 2017-01-20 13:48:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:48:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:48:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:48:42 --> Final output sent to browser
DEBUG - 2017-01-20 13:48:42 --> Total execution time: 0.1427
INFO - 2017-01-20 13:48:46 --> Config Class Initialized
INFO - 2017-01-20 13:48:46 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:48:46 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:48:46 --> Utf8 Class Initialized
INFO - 2017-01-20 13:48:47 --> URI Class Initialized
INFO - 2017-01-20 13:48:47 --> Router Class Initialized
INFO - 2017-01-20 13:48:47 --> Output Class Initialized
INFO - 2017-01-20 13:48:47 --> Security Class Initialized
DEBUG - 2017-01-20 13:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:48:47 --> Input Class Initialized
INFO - 2017-01-20 13:48:47 --> Language Class Initialized
INFO - 2017-01-20 13:48:47 --> Loader Class Initialized
INFO - 2017-01-20 13:48:47 --> Helper loaded: url_helper
INFO - 2017-01-20 13:48:47 --> Helper loaded: language_helper
INFO - 2017-01-20 13:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:48:47 --> Controller Class Initialized
INFO - 2017-01-20 13:48:47 --> Database Driver Class Initialized
INFO - 2017-01-20 13:48:47 --> Model Class Initialized
INFO - 2017-01-20 13:48:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:48:47 --> Final output sent to browser
DEBUG - 2017-01-20 13:48:47 --> Total execution time: 0.8232
INFO - 2017-01-20 13:49:05 --> Config Class Initialized
INFO - 2017-01-20 13:49:05 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:49:05 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:49:05 --> Utf8 Class Initialized
INFO - 2017-01-20 13:49:05 --> URI Class Initialized
INFO - 2017-01-20 13:49:05 --> Router Class Initialized
INFO - 2017-01-20 13:49:05 --> Output Class Initialized
INFO - 2017-01-20 13:49:05 --> Security Class Initialized
DEBUG - 2017-01-20 13:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:49:05 --> Input Class Initialized
INFO - 2017-01-20 13:49:05 --> Language Class Initialized
INFO - 2017-01-20 13:49:05 --> Loader Class Initialized
INFO - 2017-01-20 13:49:05 --> Helper loaded: url_helper
INFO - 2017-01-20 13:49:05 --> Helper loaded: language_helper
INFO - 2017-01-20 13:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:49:05 --> Controller Class Initialized
INFO - 2017-01-20 13:49:05 --> Database Driver Class Initialized
INFO - 2017-01-20 13:49:05 --> Model Class Initialized
INFO - 2017-01-20 13:49:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:49:05 --> Helper loaded: form_helper
INFO - 2017-01-20 13:49:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:49:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:49:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:49:05 --> Final output sent to browser
DEBUG - 2017-01-20 13:49:05 --> Total execution time: 0.1359
INFO - 2017-01-20 13:49:08 --> Config Class Initialized
INFO - 2017-01-20 13:49:08 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:49:08 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:49:08 --> Utf8 Class Initialized
INFO - 2017-01-20 13:49:08 --> URI Class Initialized
INFO - 2017-01-20 13:49:08 --> Router Class Initialized
INFO - 2017-01-20 13:49:08 --> Output Class Initialized
INFO - 2017-01-20 13:49:08 --> Security Class Initialized
DEBUG - 2017-01-20 13:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:49:08 --> Input Class Initialized
INFO - 2017-01-20 13:49:08 --> Language Class Initialized
INFO - 2017-01-20 13:49:08 --> Loader Class Initialized
INFO - 2017-01-20 13:49:08 --> Helper loaded: url_helper
INFO - 2017-01-20 13:49:08 --> Helper loaded: language_helper
INFO - 2017-01-20 13:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:49:08 --> Controller Class Initialized
INFO - 2017-01-20 13:49:08 --> Database Driver Class Initialized
INFO - 2017-01-20 13:49:08 --> Model Class Initialized
INFO - 2017-01-20 13:49:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:49:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:49:08 --> Final output sent to browser
DEBUG - 2017-01-20 13:49:08 --> Total execution time: 0.8988
INFO - 2017-01-20 13:49:24 --> Config Class Initialized
INFO - 2017-01-20 13:49:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:49:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:49:24 --> Utf8 Class Initialized
INFO - 2017-01-20 13:49:24 --> URI Class Initialized
INFO - 2017-01-20 13:49:24 --> Router Class Initialized
INFO - 2017-01-20 13:49:24 --> Output Class Initialized
INFO - 2017-01-20 13:49:24 --> Security Class Initialized
DEBUG - 2017-01-20 13:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:49:24 --> Input Class Initialized
INFO - 2017-01-20 13:49:24 --> Language Class Initialized
INFO - 2017-01-20 13:49:24 --> Loader Class Initialized
INFO - 2017-01-20 13:49:24 --> Helper loaded: url_helper
INFO - 2017-01-20 13:49:24 --> Helper loaded: language_helper
INFO - 2017-01-20 13:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:49:24 --> Controller Class Initialized
INFO - 2017-01-20 13:49:24 --> Database Driver Class Initialized
INFO - 2017-01-20 13:49:24 --> Model Class Initialized
INFO - 2017-01-20 13:49:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:49:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:49:25 --> Final output sent to browser
DEBUG - 2017-01-20 13:49:25 --> Total execution time: 0.7293
INFO - 2017-01-20 13:49:45 --> Config Class Initialized
INFO - 2017-01-20 13:49:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:49:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:49:45 --> Utf8 Class Initialized
INFO - 2017-01-20 13:49:45 --> URI Class Initialized
INFO - 2017-01-20 13:49:45 --> Router Class Initialized
INFO - 2017-01-20 13:49:45 --> Output Class Initialized
INFO - 2017-01-20 13:49:45 --> Security Class Initialized
DEBUG - 2017-01-20 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:49:45 --> Input Class Initialized
INFO - 2017-01-20 13:49:45 --> Language Class Initialized
INFO - 2017-01-20 13:49:45 --> Loader Class Initialized
INFO - 2017-01-20 13:49:45 --> Helper loaded: url_helper
INFO - 2017-01-20 13:49:45 --> Helper loaded: language_helper
INFO - 2017-01-20 13:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:49:45 --> Controller Class Initialized
INFO - 2017-01-20 13:49:45 --> Database Driver Class Initialized
INFO - 2017-01-20 13:49:45 --> Model Class Initialized
INFO - 2017-01-20 13:49:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:49:45 --> Helper loaded: form_helper
INFO - 2017-01-20 13:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:49:45 --> Final output sent to browser
DEBUG - 2017-01-20 13:49:45 --> Total execution time: 0.1563
INFO - 2017-01-20 13:49:48 --> Config Class Initialized
INFO - 2017-01-20 13:49:48 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:49:48 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:49:48 --> Utf8 Class Initialized
INFO - 2017-01-20 13:49:48 --> URI Class Initialized
INFO - 2017-01-20 13:49:48 --> Router Class Initialized
INFO - 2017-01-20 13:49:48 --> Output Class Initialized
INFO - 2017-01-20 13:49:48 --> Security Class Initialized
DEBUG - 2017-01-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:49:48 --> Input Class Initialized
INFO - 2017-01-20 13:49:48 --> Language Class Initialized
INFO - 2017-01-20 13:49:48 --> Loader Class Initialized
INFO - 2017-01-20 13:49:48 --> Helper loaded: url_helper
INFO - 2017-01-20 13:49:48 --> Helper loaded: language_helper
INFO - 2017-01-20 13:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:49:48 --> Controller Class Initialized
INFO - 2017-01-20 13:49:48 --> Database Driver Class Initialized
INFO - 2017-01-20 13:49:48 --> Model Class Initialized
INFO - 2017-01-20 13:49:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:49:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan.php
INFO - 2017-01-20 13:49:48 --> Final output sent to browser
DEBUG - 2017-01-20 13:49:48 --> Total execution time: 0.7495
INFO - 2017-01-20 13:50:01 --> Config Class Initialized
INFO - 2017-01-20 13:50:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:50:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:50:01 --> Utf8 Class Initialized
INFO - 2017-01-20 13:50:01 --> URI Class Initialized
INFO - 2017-01-20 13:50:01 --> Router Class Initialized
INFO - 2017-01-20 13:50:01 --> Output Class Initialized
INFO - 2017-01-20 13:50:01 --> Security Class Initialized
DEBUG - 2017-01-20 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:50:01 --> Input Class Initialized
INFO - 2017-01-20 13:50:01 --> Language Class Initialized
INFO - 2017-01-20 13:50:01 --> Loader Class Initialized
INFO - 2017-01-20 13:50:01 --> Helper loaded: url_helper
INFO - 2017-01-20 13:50:01 --> Helper loaded: language_helper
INFO - 2017-01-20 13:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:50:01 --> Controller Class Initialized
INFO - 2017-01-20 13:50:01 --> Database Driver Class Initialized
INFO - 2017-01-20 13:50:01 --> Model Class Initialized
INFO - 2017-01-20 13:50:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:50:01 --> Helper loaded: form_helper
INFO - 2017-01-20 13:50:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:50:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:50:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:50:01 --> Final output sent to browser
DEBUG - 2017-01-20 13:50:01 --> Total execution time: 0.2010
INFO - 2017-01-20 13:50:04 --> Config Class Initialized
INFO - 2017-01-20 13:50:04 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:50:04 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:50:04 --> Utf8 Class Initialized
INFO - 2017-01-20 13:50:04 --> URI Class Initialized
INFO - 2017-01-20 13:50:04 --> Router Class Initialized
INFO - 2017-01-20 13:50:04 --> Output Class Initialized
INFO - 2017-01-20 13:50:04 --> Security Class Initialized
DEBUG - 2017-01-20 13:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:50:04 --> Input Class Initialized
INFO - 2017-01-20 13:50:04 --> Language Class Initialized
INFO - 2017-01-20 13:50:04 --> Loader Class Initialized
INFO - 2017-01-20 13:50:04 --> Helper loaded: url_helper
INFO - 2017-01-20 13:50:04 --> Helper loaded: language_helper
INFO - 2017-01-20 13:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:50:04 --> Controller Class Initialized
INFO - 2017-01-20 13:50:04 --> Database Driver Class Initialized
INFO - 2017-01-20 13:50:04 --> Model Class Initialized
INFO - 2017-01-20 13:50:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:50:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:50:05 --> Final output sent to browser
DEBUG - 2017-01-20 13:50:05 --> Total execution time: 0.9145
INFO - 2017-01-20 13:50:25 --> Config Class Initialized
INFO - 2017-01-20 13:50:25 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:50:25 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:50:25 --> Utf8 Class Initialized
INFO - 2017-01-20 13:50:25 --> URI Class Initialized
INFO - 2017-01-20 13:50:25 --> Router Class Initialized
INFO - 2017-01-20 13:50:25 --> Output Class Initialized
INFO - 2017-01-20 13:50:25 --> Security Class Initialized
DEBUG - 2017-01-20 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:50:25 --> Input Class Initialized
INFO - 2017-01-20 13:50:25 --> Language Class Initialized
INFO - 2017-01-20 13:50:25 --> Loader Class Initialized
INFO - 2017-01-20 13:50:25 --> Helper loaded: url_helper
INFO - 2017-01-20 13:50:25 --> Helper loaded: language_helper
INFO - 2017-01-20 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:50:25 --> Controller Class Initialized
INFO - 2017-01-20 13:50:25 --> Database Driver Class Initialized
INFO - 2017-01-20 13:50:25 --> Model Class Initialized
INFO - 2017-01-20 13:50:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:50:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ist.php
INFO - 2017-01-20 13:50:26 --> Final output sent to browser
DEBUG - 2017-01-20 13:50:26 --> Total execution time: 0.9120
INFO - 2017-01-20 13:50:44 --> Config Class Initialized
INFO - 2017-01-20 13:50:44 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:50:44 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:50:44 --> Utf8 Class Initialized
INFO - 2017-01-20 13:50:44 --> URI Class Initialized
INFO - 2017-01-20 13:50:44 --> Router Class Initialized
INFO - 2017-01-20 13:50:44 --> Output Class Initialized
INFO - 2017-01-20 13:50:44 --> Security Class Initialized
DEBUG - 2017-01-20 13:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:50:44 --> Input Class Initialized
INFO - 2017-01-20 13:50:44 --> Language Class Initialized
INFO - 2017-01-20 13:50:44 --> Loader Class Initialized
INFO - 2017-01-20 13:50:44 --> Helper loaded: url_helper
INFO - 2017-01-20 13:50:44 --> Helper loaded: language_helper
INFO - 2017-01-20 13:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:50:44 --> Controller Class Initialized
INFO - 2017-01-20 13:50:44 --> Database Driver Class Initialized
INFO - 2017-01-20 13:50:44 --> Model Class Initialized
INFO - 2017-01-20 13:50:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:50:44 --> Model Class Initialized
INFO - 2017-01-20 13:50:44 --> Helper loaded: form_helper
INFO - 2017-01-20 13:50:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:50:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:50:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:50:44 --> Final output sent to browser
DEBUG - 2017-01-20 13:50:44 --> Total execution time: 0.5853
INFO - 2017-01-20 13:50:47 --> Config Class Initialized
INFO - 2017-01-20 13:50:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:50:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:50:47 --> Utf8 Class Initialized
INFO - 2017-01-20 13:50:47 --> URI Class Initialized
INFO - 2017-01-20 13:50:47 --> Router Class Initialized
INFO - 2017-01-20 13:50:47 --> Output Class Initialized
INFO - 2017-01-20 13:50:47 --> Security Class Initialized
DEBUG - 2017-01-20 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:50:47 --> Input Class Initialized
INFO - 2017-01-20 13:50:47 --> Language Class Initialized
INFO - 2017-01-20 13:50:47 --> Loader Class Initialized
INFO - 2017-01-20 13:50:47 --> Helper loaded: url_helper
INFO - 2017-01-20 13:50:47 --> Helper loaded: language_helper
INFO - 2017-01-20 13:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:50:47 --> Controller Class Initialized
INFO - 2017-01-20 13:50:47 --> Database Driver Class Initialized
INFO - 2017-01-20 13:50:47 --> Model Class Initialized
INFO - 2017-01-20 13:50:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:50:47 --> Model Class Initialized
INFO - 2017-01-20 13:50:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:50:48 --> Final output sent to browser
DEBUG - 2017-01-20 13:50:48 --> Total execution time: 1.4337
INFO - 2017-01-20 13:51:16 --> Config Class Initialized
INFO - 2017-01-20 13:51:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:51:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:51:16 --> Utf8 Class Initialized
INFO - 2017-01-20 13:51:16 --> URI Class Initialized
INFO - 2017-01-20 13:51:16 --> Router Class Initialized
INFO - 2017-01-20 13:51:16 --> Output Class Initialized
INFO - 2017-01-20 13:51:16 --> Security Class Initialized
DEBUG - 2017-01-20 13:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:51:16 --> Input Class Initialized
INFO - 2017-01-20 13:51:16 --> Language Class Initialized
INFO - 2017-01-20 13:51:16 --> Loader Class Initialized
INFO - 2017-01-20 13:51:16 --> Helper loaded: url_helper
INFO - 2017-01-20 13:51:16 --> Helper loaded: language_helper
INFO - 2017-01-20 13:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:51:16 --> Controller Class Initialized
INFO - 2017-01-20 13:51:16 --> Database Driver Class Initialized
INFO - 2017-01-20 13:51:16 --> Model Class Initialized
INFO - 2017-01-20 13:51:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:51:16 --> Model Class Initialized
INFO - 2017-01-20 13:51:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-01-20 13:51:16 --> Final output sent to browser
DEBUG - 2017-01-20 13:51:16 --> Total execution time: 0.7865
INFO - 2017-01-20 13:51:35 --> Config Class Initialized
INFO - 2017-01-20 13:51:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:51:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:51:35 --> Utf8 Class Initialized
INFO - 2017-01-20 13:51:35 --> URI Class Initialized
INFO - 2017-01-20 13:51:35 --> Router Class Initialized
INFO - 2017-01-20 13:51:35 --> Output Class Initialized
INFO - 2017-01-20 13:51:35 --> Security Class Initialized
DEBUG - 2017-01-20 13:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:51:35 --> Input Class Initialized
INFO - 2017-01-20 13:51:35 --> Language Class Initialized
INFO - 2017-01-20 13:51:35 --> Loader Class Initialized
INFO - 2017-01-20 13:51:35 --> Helper loaded: url_helper
INFO - 2017-01-20 13:51:35 --> Helper loaded: language_helper
INFO - 2017-01-20 13:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:51:35 --> Controller Class Initialized
INFO - 2017-01-20 13:51:35 --> Database Driver Class Initialized
INFO - 2017-01-20 13:51:35 --> Model Class Initialized
INFO - 2017-01-20 13:51:35 --> Model Class Initialized
INFO - 2017-01-20 13:51:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-01-20 13:51:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:51:35 --> Final output sent to browser
DEBUG - 2017-01-20 13:51:35 --> Total execution time: 0.1133
INFO - 2017-01-20 13:52:06 --> Config Class Initialized
INFO - 2017-01-20 13:52:06 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:06 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:06 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:06 --> URI Class Initialized
INFO - 2017-01-20 13:52:06 --> Router Class Initialized
INFO - 2017-01-20 13:52:06 --> Output Class Initialized
INFO - 2017-01-20 13:52:06 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:06 --> Input Class Initialized
INFO - 2017-01-20 13:52:06 --> Language Class Initialized
INFO - 2017-01-20 13:52:06 --> Loader Class Initialized
INFO - 2017-01-20 13:52:06 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:06 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:06 --> Controller Class Initialized
INFO - 2017-01-20 13:52:06 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:06 --> Model Class Initialized
INFO - 2017-01-20 13:52:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:06 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:52:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:06 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:06 --> Total execution time: 0.2147
INFO - 2017-01-20 13:52:08 --> Config Class Initialized
INFO - 2017-01-20 13:52:08 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:08 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:08 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:08 --> URI Class Initialized
INFO - 2017-01-20 13:52:08 --> Router Class Initialized
INFO - 2017-01-20 13:52:08 --> Output Class Initialized
INFO - 2017-01-20 13:52:08 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:08 --> Input Class Initialized
INFO - 2017-01-20 13:52:08 --> Language Class Initialized
INFO - 2017-01-20 13:52:08 --> Loader Class Initialized
INFO - 2017-01-20 13:52:08 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:08 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:08 --> Controller Class Initialized
INFO - 2017-01-20 13:52:08 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:08 --> Model Class Initialized
INFO - 2017-01-20 13:52:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:08 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:52:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:08 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:08 --> Total execution time: 0.2265
INFO - 2017-01-20 13:52:10 --> Config Class Initialized
INFO - 2017-01-20 13:52:10 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:10 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:10 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:10 --> URI Class Initialized
INFO - 2017-01-20 13:52:10 --> Router Class Initialized
INFO - 2017-01-20 13:52:10 --> Output Class Initialized
INFO - 2017-01-20 13:52:10 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:10 --> Input Class Initialized
INFO - 2017-01-20 13:52:10 --> Language Class Initialized
INFO - 2017-01-20 13:52:10 --> Loader Class Initialized
INFO - 2017-01-20 13:52:10 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:10 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:10 --> Controller Class Initialized
INFO - 2017-01-20 13:52:10 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:10 --> Model Class Initialized
INFO - 2017-01-20 13:52:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:10 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:52:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:11 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:11 --> Total execution time: 0.2025
INFO - 2017-01-20 13:52:13 --> Config Class Initialized
INFO - 2017-01-20 13:52:13 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:13 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:13 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:13 --> URI Class Initialized
INFO - 2017-01-20 13:52:13 --> Router Class Initialized
INFO - 2017-01-20 13:52:13 --> Output Class Initialized
INFO - 2017-01-20 13:52:13 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:13 --> Input Class Initialized
INFO - 2017-01-20 13:52:13 --> Language Class Initialized
INFO - 2017-01-20 13:52:13 --> Loader Class Initialized
INFO - 2017-01-20 13:52:13 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:13 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:13 --> Controller Class Initialized
INFO - 2017-01-20 13:52:13 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:13 --> Model Class Initialized
INFO - 2017-01-20 13:52:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:13 --> Model Class Initialized
INFO - 2017-01-20 13:52:13 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-20 13:52:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:14 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:14 --> Total execution time: 0.6383
INFO - 2017-01-20 13:52:17 --> Config Class Initialized
INFO - 2017-01-20 13:52:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:17 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:17 --> URI Class Initialized
INFO - 2017-01-20 13:52:17 --> Router Class Initialized
INFO - 2017-01-20 13:52:17 --> Output Class Initialized
INFO - 2017-01-20 13:52:17 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:17 --> Input Class Initialized
INFO - 2017-01-20 13:52:17 --> Language Class Initialized
INFO - 2017-01-20 13:52:17 --> Loader Class Initialized
INFO - 2017-01-20 13:52:17 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:17 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:17 --> Controller Class Initialized
INFO - 2017-01-20 13:52:17 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:17 --> Model Class Initialized
INFO - 2017-01-20 13:52:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:17 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:17 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:17 --> Total execution time: 0.1501
INFO - 2017-01-20 13:52:19 --> Config Class Initialized
INFO - 2017-01-20 13:52:19 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:19 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:19 --> URI Class Initialized
INFO - 2017-01-20 13:52:19 --> Router Class Initialized
INFO - 2017-01-20 13:52:19 --> Output Class Initialized
INFO - 2017-01-20 13:52:19 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:19 --> Input Class Initialized
INFO - 2017-01-20 13:52:19 --> Language Class Initialized
INFO - 2017-01-20 13:52:19 --> Loader Class Initialized
INFO - 2017-01-20 13:52:19 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:19 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:19 --> Controller Class Initialized
INFO - 2017-01-20 13:52:19 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:19 --> Model Class Initialized
INFO - 2017-01-20 13:52:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:19 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:52:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:19 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:19 --> Total execution time: 0.1536
INFO - 2017-01-20 13:52:22 --> Config Class Initialized
INFO - 2017-01-20 13:52:22 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:22 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:22 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:22 --> URI Class Initialized
INFO - 2017-01-20 13:52:22 --> Router Class Initialized
INFO - 2017-01-20 13:52:22 --> Output Class Initialized
INFO - 2017-01-20 13:52:22 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:22 --> Input Class Initialized
INFO - 2017-01-20 13:52:22 --> Language Class Initialized
INFO - 2017-01-20 13:52:22 --> Loader Class Initialized
INFO - 2017-01-20 13:52:22 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:22 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:22 --> Controller Class Initialized
INFO - 2017-01-20 13:52:22 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:22 --> Model Class Initialized
INFO - 2017-01-20 13:52:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:22 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:52:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:22 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:22 --> Total execution time: 0.1926
INFO - 2017-01-20 13:52:24 --> Config Class Initialized
INFO - 2017-01-20 13:52:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:24 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:24 --> URI Class Initialized
INFO - 2017-01-20 13:52:24 --> Router Class Initialized
INFO - 2017-01-20 13:52:24 --> Output Class Initialized
INFO - 2017-01-20 13:52:24 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:24 --> Input Class Initialized
INFO - 2017-01-20 13:52:24 --> Language Class Initialized
INFO - 2017-01-20 13:52:24 --> Loader Class Initialized
INFO - 2017-01-20 13:52:24 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:24 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:24 --> Controller Class Initialized
INFO - 2017-01-20 13:52:24 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:24 --> Model Class Initialized
INFO - 2017-01-20 13:52:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:24 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 13:52:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:24 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:24 --> Total execution time: 0.1613
INFO - 2017-01-20 13:52:30 --> Config Class Initialized
INFO - 2017-01-20 13:52:30 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:30 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:30 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:30 --> URI Class Initialized
INFO - 2017-01-20 13:52:30 --> Router Class Initialized
INFO - 2017-01-20 13:52:30 --> Output Class Initialized
INFO - 2017-01-20 13:52:30 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:30 --> Input Class Initialized
INFO - 2017-01-20 13:52:30 --> Language Class Initialized
INFO - 2017-01-20 13:52:30 --> Loader Class Initialized
INFO - 2017-01-20 13:52:30 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:30 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:30 --> Controller Class Initialized
INFO - 2017-01-20 13:52:30 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:30 --> Model Class Initialized
INFO - 2017-01-20 13:52:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:30 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:52:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:30 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:30 --> Total execution time: 0.1321
INFO - 2017-01-20 13:52:49 --> Config Class Initialized
INFO - 2017-01-20 13:52:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:52:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:52:49 --> Utf8 Class Initialized
INFO - 2017-01-20 13:52:49 --> URI Class Initialized
INFO - 2017-01-20 13:52:49 --> Router Class Initialized
INFO - 2017-01-20 13:52:49 --> Output Class Initialized
INFO - 2017-01-20 13:52:49 --> Security Class Initialized
DEBUG - 2017-01-20 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:52:49 --> Input Class Initialized
INFO - 2017-01-20 13:52:49 --> Language Class Initialized
INFO - 2017-01-20 13:52:49 --> Loader Class Initialized
INFO - 2017-01-20 13:52:49 --> Helper loaded: url_helper
INFO - 2017-01-20 13:52:49 --> Helper loaded: language_helper
INFO - 2017-01-20 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:52:49 --> Controller Class Initialized
INFO - 2017-01-20 13:52:49 --> Database Driver Class Initialized
INFO - 2017-01-20 13:52:49 --> Model Class Initialized
INFO - 2017-01-20 13:52:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:52:49 --> Helper loaded: form_helper
INFO - 2017-01-20 13:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:52:49 --> Final output sent to browser
DEBUG - 2017-01-20 13:52:49 --> Total execution time: 0.1557
INFO - 2017-01-20 13:53:53 --> Config Class Initialized
INFO - 2017-01-20 13:53:53 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:53:53 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:53:53 --> Utf8 Class Initialized
INFO - 2017-01-20 13:53:53 --> URI Class Initialized
INFO - 2017-01-20 13:53:53 --> Router Class Initialized
INFO - 2017-01-20 13:53:53 --> Output Class Initialized
INFO - 2017-01-20 13:53:53 --> Security Class Initialized
DEBUG - 2017-01-20 13:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:53:53 --> Input Class Initialized
INFO - 2017-01-20 13:53:53 --> Language Class Initialized
INFO - 2017-01-20 13:53:53 --> Loader Class Initialized
INFO - 2017-01-20 13:53:53 --> Helper loaded: url_helper
INFO - 2017-01-20 13:53:53 --> Helper loaded: language_helper
INFO - 2017-01-20 13:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:53:53 --> Controller Class Initialized
INFO - 2017-01-20 13:53:53 --> Database Driver Class Initialized
INFO - 2017-01-20 13:53:53 --> Model Class Initialized
INFO - 2017-01-20 13:53:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:53:53 --> Helper loaded: form_helper
INFO - 2017-01-20 13:53:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:53:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:53:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:53:53 --> Final output sent to browser
DEBUG - 2017-01-20 13:53:53 --> Total execution time: 0.1558
INFO - 2017-01-20 13:53:55 --> Config Class Initialized
INFO - 2017-01-20 13:53:55 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:53:55 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:53:55 --> Utf8 Class Initialized
INFO - 2017-01-20 13:53:55 --> URI Class Initialized
INFO - 2017-01-20 13:53:55 --> Router Class Initialized
INFO - 2017-01-20 13:53:55 --> Output Class Initialized
INFO - 2017-01-20 13:53:55 --> Security Class Initialized
DEBUG - 2017-01-20 13:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:53:55 --> Input Class Initialized
INFO - 2017-01-20 13:53:55 --> Language Class Initialized
INFO - 2017-01-20 13:53:55 --> Loader Class Initialized
INFO - 2017-01-20 13:53:55 --> Helper loaded: url_helper
INFO - 2017-01-20 13:53:55 --> Helper loaded: language_helper
INFO - 2017-01-20 13:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:53:55 --> Controller Class Initialized
INFO - 2017-01-20 13:53:55 --> Database Driver Class Initialized
INFO - 2017-01-20 13:53:55 --> Model Class Initialized
INFO - 2017-01-20 13:53:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:53:55 --> Helper loaded: form_helper
INFO - 2017-01-20 13:53:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:53:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:53:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:53:55 --> Final output sent to browser
DEBUG - 2017-01-20 13:53:55 --> Total execution time: 0.2261
INFO - 2017-01-20 13:53:59 --> Config Class Initialized
INFO - 2017-01-20 13:53:59 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:53:59 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:53:59 --> Utf8 Class Initialized
INFO - 2017-01-20 13:53:59 --> URI Class Initialized
INFO - 2017-01-20 13:53:59 --> Router Class Initialized
INFO - 2017-01-20 13:53:59 --> Output Class Initialized
INFO - 2017-01-20 13:53:59 --> Security Class Initialized
DEBUG - 2017-01-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:53:59 --> Input Class Initialized
INFO - 2017-01-20 13:53:59 --> Language Class Initialized
INFO - 2017-01-20 13:53:59 --> Loader Class Initialized
INFO - 2017-01-20 13:53:59 --> Helper loaded: url_helper
INFO - 2017-01-20 13:53:59 --> Helper loaded: language_helper
INFO - 2017-01-20 13:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:53:59 --> Controller Class Initialized
INFO - 2017-01-20 13:53:59 --> Database Driver Class Initialized
INFO - 2017-01-20 13:53:59 --> Model Class Initialized
INFO - 2017-01-20 13:53:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:53:59 --> Helper loaded: form_helper
INFO - 2017-01-20 13:53:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:53:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:53:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:53:59 --> Final output sent to browser
DEBUG - 2017-01-20 13:53:59 --> Total execution time: 0.1660
INFO - 2017-01-20 13:54:01 --> Config Class Initialized
INFO - 2017-01-20 13:54:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:54:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:54:01 --> Utf8 Class Initialized
INFO - 2017-01-20 13:54:01 --> URI Class Initialized
INFO - 2017-01-20 13:54:01 --> Router Class Initialized
INFO - 2017-01-20 13:54:01 --> Output Class Initialized
INFO - 2017-01-20 13:54:01 --> Security Class Initialized
DEBUG - 2017-01-20 13:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:54:01 --> Input Class Initialized
INFO - 2017-01-20 13:54:01 --> Language Class Initialized
INFO - 2017-01-20 13:54:01 --> Loader Class Initialized
INFO - 2017-01-20 13:54:01 --> Helper loaded: url_helper
INFO - 2017-01-20 13:54:01 --> Helper loaded: language_helper
INFO - 2017-01-20 13:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:54:01 --> Controller Class Initialized
INFO - 2017-01-20 13:54:01 --> Database Driver Class Initialized
INFO - 2017-01-20 13:54:01 --> Model Class Initialized
INFO - 2017-01-20 13:54:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:54:01 --> Helper loaded: form_helper
INFO - 2017-01-20 13:54:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:54:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:54:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:54:01 --> Final output sent to browser
DEBUG - 2017-01-20 13:54:01 --> Total execution time: 0.2113
INFO - 2017-01-20 13:54:05 --> Config Class Initialized
INFO - 2017-01-20 13:54:05 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:54:05 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:54:05 --> Utf8 Class Initialized
INFO - 2017-01-20 13:54:05 --> URI Class Initialized
INFO - 2017-01-20 13:54:05 --> Router Class Initialized
INFO - 2017-01-20 13:54:05 --> Output Class Initialized
INFO - 2017-01-20 13:54:05 --> Security Class Initialized
DEBUG - 2017-01-20 13:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:54:05 --> Input Class Initialized
INFO - 2017-01-20 13:54:05 --> Language Class Initialized
INFO - 2017-01-20 13:54:05 --> Loader Class Initialized
INFO - 2017-01-20 13:54:05 --> Helper loaded: url_helper
INFO - 2017-01-20 13:54:05 --> Helper loaded: language_helper
INFO - 2017-01-20 13:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:54:05 --> Controller Class Initialized
INFO - 2017-01-20 13:54:05 --> Database Driver Class Initialized
INFO - 2017-01-20 13:54:05 --> Model Class Initialized
INFO - 2017-01-20 13:54:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:54:05 --> Helper loaded: form_helper
INFO - 2017-01-20 13:54:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:54:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 13:54:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:54:05 --> Final output sent to browser
DEBUG - 2017-01-20 13:54:05 --> Total execution time: 0.1834
INFO - 2017-01-20 13:57:18 --> Config Class Initialized
INFO - 2017-01-20 13:57:18 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:57:18 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:57:18 --> Utf8 Class Initialized
INFO - 2017-01-20 13:57:18 --> URI Class Initialized
INFO - 2017-01-20 13:57:18 --> Router Class Initialized
INFO - 2017-01-20 13:57:18 --> Output Class Initialized
INFO - 2017-01-20 13:57:18 --> Security Class Initialized
DEBUG - 2017-01-20 13:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:57:18 --> Input Class Initialized
INFO - 2017-01-20 13:57:18 --> Language Class Initialized
INFO - 2017-01-20 13:57:18 --> Loader Class Initialized
INFO - 2017-01-20 13:57:18 --> Helper loaded: url_helper
INFO - 2017-01-20 13:57:18 --> Helper loaded: language_helper
INFO - 2017-01-20 13:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:57:18 --> Controller Class Initialized
INFO - 2017-01-20 13:57:18 --> Database Driver Class Initialized
INFO - 2017-01-20 13:57:18 --> Model Class Initialized
INFO - 2017-01-20 13:57:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 13:57:18 --> Helper loaded: form_helper
INFO - 2017-01-20 13:57:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 13:57:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 13:57:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 13:57:19 --> Final output sent to browser
DEBUG - 2017-01-20 13:57:19 --> Total execution time: 0.1820
INFO - 2017-01-20 14:25:44 --> Config Class Initialized
INFO - 2017-01-20 14:25:44 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:25:44 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:25:44 --> Utf8 Class Initialized
INFO - 2017-01-20 14:25:44 --> URI Class Initialized
INFO - 2017-01-20 14:25:44 --> Router Class Initialized
INFO - 2017-01-20 14:25:44 --> Output Class Initialized
INFO - 2017-01-20 14:25:44 --> Security Class Initialized
DEBUG - 2017-01-20 14:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:25:44 --> Input Class Initialized
INFO - 2017-01-20 14:25:44 --> Language Class Initialized
INFO - 2017-01-20 14:25:44 --> Loader Class Initialized
INFO - 2017-01-20 14:25:44 --> Helper loaded: url_helper
INFO - 2017-01-20 14:25:44 --> Helper loaded: language_helper
INFO - 2017-01-20 14:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:25:44 --> Controller Class Initialized
INFO - 2017-01-20 14:25:44 --> Database Driver Class Initialized
INFO - 2017-01-20 14:25:44 --> Model Class Initialized
INFO - 2017-01-20 14:25:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:25:44 --> Helper loaded: form_helper
INFO - 2017-01-20 14:25:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:25:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-20 14:25:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:25:44 --> Final output sent to browser
DEBUG - 2017-01-20 14:25:44 --> Total execution time: 0.1635
INFO - 2017-01-20 14:25:49 --> Config Class Initialized
INFO - 2017-01-20 14:25:49 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:25:49 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:25:49 --> Utf8 Class Initialized
INFO - 2017-01-20 14:25:49 --> URI Class Initialized
INFO - 2017-01-20 14:25:49 --> Router Class Initialized
INFO - 2017-01-20 14:25:49 --> Output Class Initialized
INFO - 2017-01-20 14:25:49 --> Security Class Initialized
DEBUG - 2017-01-20 14:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:25:49 --> Input Class Initialized
INFO - 2017-01-20 14:25:49 --> Language Class Initialized
INFO - 2017-01-20 14:25:49 --> Loader Class Initialized
INFO - 2017-01-20 14:25:49 --> Helper loaded: url_helper
INFO - 2017-01-20 14:25:49 --> Helper loaded: language_helper
INFO - 2017-01-20 14:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:25:49 --> Controller Class Initialized
INFO - 2017-01-20 14:25:49 --> Database Driver Class Initialized
INFO - 2017-01-20 14:25:49 --> Model Class Initialized
INFO - 2017-01-20 14:25:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:25:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:25:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:25:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:25:49 --> Final output sent to browser
DEBUG - 2017-01-20 14:25:49 --> Total execution time: 0.1183
INFO - 2017-01-20 14:26:05 --> Config Class Initialized
INFO - 2017-01-20 14:26:05 --> Hooks Class Initialized
INFO - 2017-01-20 14:26:05 --> Config Class Initialized
INFO - 2017-01-20 14:26:05 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:26:05 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:26:05 --> Utf8 Class Initialized
DEBUG - 2017-01-20 14:26:05 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:26:05 --> Utf8 Class Initialized
INFO - 2017-01-20 14:26:05 --> URI Class Initialized
INFO - 2017-01-20 14:26:05 --> Router Class Initialized
INFO - 2017-01-20 14:26:05 --> Output Class Initialized
INFO - 2017-01-20 14:26:05 --> Security Class Initialized
INFO - 2017-01-20 14:26:05 --> URI Class Initialized
DEBUG - 2017-01-20 14:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:26:05 --> Input Class Initialized
INFO - 2017-01-20 14:26:05 --> Router Class Initialized
INFO - 2017-01-20 14:26:05 --> Language Class Initialized
INFO - 2017-01-20 14:26:05 --> Output Class Initialized
INFO - 2017-01-20 14:26:05 --> Security Class Initialized
DEBUG - 2017-01-20 14:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:26:05 --> Input Class Initialized
INFO - 2017-01-20 14:26:05 --> Language Class Initialized
ERROR - 2017-01-20 14:26:05 --> 404 Page Not Found: Bootstrap-datepicker/css
ERROR - 2017-01-20 14:26:05 --> 404 Page Not Found: Bootstrap-datepicker/css
INFO - 2017-01-20 14:26:27 --> Config Class Initialized
INFO - 2017-01-20 14:26:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:26:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:26:27 --> Utf8 Class Initialized
INFO - 2017-01-20 14:26:27 --> URI Class Initialized
INFO - 2017-01-20 14:26:27 --> Router Class Initialized
INFO - 2017-01-20 14:26:27 --> Output Class Initialized
INFO - 2017-01-20 14:26:27 --> Security Class Initialized
DEBUG - 2017-01-20 14:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:26:27 --> Input Class Initialized
INFO - 2017-01-20 14:26:27 --> Language Class Initialized
INFO - 2017-01-20 14:26:27 --> Loader Class Initialized
INFO - 2017-01-20 14:26:27 --> Helper loaded: url_helper
INFO - 2017-01-20 14:26:27 --> Helper loaded: language_helper
INFO - 2017-01-20 14:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:26:27 --> Controller Class Initialized
INFO - 2017-01-20 14:26:27 --> Database Driver Class Initialized
INFO - 2017-01-20 14:26:27 --> Model Class Initialized
INFO - 2017-01-20 14:26:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:26:27 --> Final output sent to browser
DEBUG - 2017-01-20 14:26:27 --> Total execution time: 0.1504
INFO - 2017-01-20 14:26:27 --> Config Class Initialized
INFO - 2017-01-20 14:26:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:26:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:26:27 --> Utf8 Class Initialized
INFO - 2017-01-20 14:26:27 --> URI Class Initialized
INFO - 2017-01-20 14:26:27 --> Router Class Initialized
INFO - 2017-01-20 14:26:27 --> Output Class Initialized
INFO - 2017-01-20 14:26:27 --> Security Class Initialized
INFO - 2017-01-20 14:26:27 --> Config Class Initialized
DEBUG - 2017-01-20 14:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:26:27 --> Input Class Initialized
INFO - 2017-01-20 14:26:27 --> Hooks Class Initialized
INFO - 2017-01-20 14:26:27 --> Language Class Initialized
ERROR - 2017-01-20 14:26:27 --> 404 Page Not Found: Bootstrap-datepicker/css
DEBUG - 2017-01-20 14:26:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:26:27 --> Utf8 Class Initialized
INFO - 2017-01-20 14:26:27 --> URI Class Initialized
INFO - 2017-01-20 14:26:27 --> Router Class Initialized
INFO - 2017-01-20 14:26:27 --> Output Class Initialized
INFO - 2017-01-20 14:26:27 --> Security Class Initialized
DEBUG - 2017-01-20 14:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:26:27 --> Input Class Initialized
INFO - 2017-01-20 14:26:27 --> Language Class Initialized
ERROR - 2017-01-20 14:26:27 --> 404 Page Not Found: Bootstrap-datepicker/css
INFO - 2017-01-20 14:27:21 --> Config Class Initialized
INFO - 2017-01-20 14:27:21 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:27:21 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:27:21 --> Utf8 Class Initialized
INFO - 2017-01-20 14:27:21 --> URI Class Initialized
INFO - 2017-01-20 14:27:21 --> Router Class Initialized
INFO - 2017-01-20 14:27:21 --> Output Class Initialized
INFO - 2017-01-20 14:27:21 --> Security Class Initialized
DEBUG - 2017-01-20 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:27:21 --> Input Class Initialized
INFO - 2017-01-20 14:27:21 --> Language Class Initialized
INFO - 2017-01-20 14:27:21 --> Loader Class Initialized
INFO - 2017-01-20 14:27:21 --> Helper loaded: url_helper
INFO - 2017-01-20 14:27:21 --> Helper loaded: language_helper
INFO - 2017-01-20 14:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:27:21 --> Controller Class Initialized
INFO - 2017-01-20 14:27:21 --> Database Driver Class Initialized
INFO - 2017-01-20 14:27:22 --> Model Class Initialized
INFO - 2017-01-20 14:27:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:27:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:27:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:27:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:27:22 --> Final output sent to browser
DEBUG - 2017-01-20 14:27:22 --> Total execution time: 0.1412
INFO - 2017-01-20 14:31:45 --> Config Class Initialized
INFO - 2017-01-20 14:31:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:31:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:31:45 --> Utf8 Class Initialized
INFO - 2017-01-20 14:31:45 --> URI Class Initialized
INFO - 2017-01-20 14:31:45 --> Router Class Initialized
INFO - 2017-01-20 14:31:45 --> Output Class Initialized
INFO - 2017-01-20 14:31:45 --> Security Class Initialized
DEBUG - 2017-01-20 14:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:31:45 --> Input Class Initialized
INFO - 2017-01-20 14:31:45 --> Language Class Initialized
INFO - 2017-01-20 14:31:45 --> Loader Class Initialized
INFO - 2017-01-20 14:31:45 --> Helper loaded: url_helper
INFO - 2017-01-20 14:31:45 --> Helper loaded: language_helper
INFO - 2017-01-20 14:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:31:45 --> Controller Class Initialized
INFO - 2017-01-20 14:31:45 --> Database Driver Class Initialized
INFO - 2017-01-20 14:31:45 --> Model Class Initialized
INFO - 2017-01-20 14:31:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:31:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:31:45 --> Final output sent to browser
DEBUG - 2017-01-20 14:31:45 --> Total execution time: 0.1737
INFO - 2017-01-20 14:32:43 --> Config Class Initialized
INFO - 2017-01-20 14:32:43 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:32:43 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:32:43 --> Utf8 Class Initialized
INFO - 2017-01-20 14:32:43 --> URI Class Initialized
INFO - 2017-01-20 14:32:43 --> Router Class Initialized
INFO - 2017-01-20 14:32:43 --> Output Class Initialized
INFO - 2017-01-20 14:32:43 --> Security Class Initialized
DEBUG - 2017-01-20 14:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:32:43 --> Input Class Initialized
INFO - 2017-01-20 14:32:43 --> Language Class Initialized
INFO - 2017-01-20 14:32:43 --> Loader Class Initialized
INFO - 2017-01-20 14:32:43 --> Helper loaded: url_helper
INFO - 2017-01-20 14:32:43 --> Helper loaded: language_helper
INFO - 2017-01-20 14:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:32:43 --> Controller Class Initialized
INFO - 2017-01-20 14:32:43 --> Database Driver Class Initialized
INFO - 2017-01-20 14:32:43 --> Model Class Initialized
INFO - 2017-01-20 14:32:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:32:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:32:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:32:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:32:43 --> Final output sent to browser
DEBUG - 2017-01-20 14:32:43 --> Total execution time: 0.1280
INFO - 2017-01-20 14:33:03 --> Config Class Initialized
INFO - 2017-01-20 14:33:03 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:33:03 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:33:03 --> Utf8 Class Initialized
INFO - 2017-01-20 14:33:03 --> URI Class Initialized
INFO - 2017-01-20 14:33:03 --> Router Class Initialized
INFO - 2017-01-20 14:33:03 --> Output Class Initialized
INFO - 2017-01-20 14:33:03 --> Security Class Initialized
DEBUG - 2017-01-20 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:33:03 --> Input Class Initialized
INFO - 2017-01-20 14:33:03 --> Language Class Initialized
INFO - 2017-01-20 14:33:03 --> Loader Class Initialized
INFO - 2017-01-20 14:33:03 --> Helper loaded: url_helper
INFO - 2017-01-20 14:33:03 --> Helper loaded: language_helper
INFO - 2017-01-20 14:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:33:03 --> Controller Class Initialized
INFO - 2017-01-20 14:33:03 --> Database Driver Class Initialized
INFO - 2017-01-20 14:33:03 --> Model Class Initialized
INFO - 2017-01-20 14:33:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:33:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:33:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:33:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:33:03 --> Final output sent to browser
DEBUG - 2017-01-20 14:33:03 --> Total execution time: 0.1028
INFO - 2017-01-20 14:33:16 --> Config Class Initialized
INFO - 2017-01-20 14:33:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:33:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:33:16 --> Utf8 Class Initialized
INFO - 2017-01-20 14:33:16 --> URI Class Initialized
INFO - 2017-01-20 14:33:16 --> Router Class Initialized
INFO - 2017-01-20 14:33:16 --> Output Class Initialized
INFO - 2017-01-20 14:33:16 --> Security Class Initialized
DEBUG - 2017-01-20 14:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:33:16 --> Input Class Initialized
INFO - 2017-01-20 14:33:16 --> Language Class Initialized
INFO - 2017-01-20 14:33:16 --> Loader Class Initialized
INFO - 2017-01-20 14:33:16 --> Helper loaded: url_helper
INFO - 2017-01-20 14:33:16 --> Helper loaded: language_helper
INFO - 2017-01-20 14:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:33:16 --> Controller Class Initialized
INFO - 2017-01-20 14:33:16 --> Database Driver Class Initialized
INFO - 2017-01-20 14:33:16 --> Model Class Initialized
INFO - 2017-01-20 14:33:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:33:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:33:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:33:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:33:16 --> Final output sent to browser
DEBUG - 2017-01-20 14:33:16 --> Total execution time: 0.1214
INFO - 2017-01-20 14:33:30 --> Config Class Initialized
INFO - 2017-01-20 14:33:30 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:33:30 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:33:30 --> Utf8 Class Initialized
INFO - 2017-01-20 14:33:30 --> URI Class Initialized
INFO - 2017-01-20 14:33:30 --> Router Class Initialized
INFO - 2017-01-20 14:33:30 --> Output Class Initialized
INFO - 2017-01-20 14:33:30 --> Security Class Initialized
DEBUG - 2017-01-20 14:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:33:30 --> Input Class Initialized
INFO - 2017-01-20 14:33:30 --> Language Class Initialized
INFO - 2017-01-20 14:33:30 --> Loader Class Initialized
INFO - 2017-01-20 14:33:30 --> Helper loaded: url_helper
INFO - 2017-01-20 14:33:30 --> Helper loaded: language_helper
INFO - 2017-01-20 14:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:33:30 --> Controller Class Initialized
INFO - 2017-01-20 14:33:30 --> Database Driver Class Initialized
INFO - 2017-01-20 14:33:30 --> Model Class Initialized
INFO - 2017-01-20 14:33:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:33:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:33:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:33:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:33:30 --> Final output sent to browser
DEBUG - 2017-01-20 14:33:30 --> Total execution time: 0.1254
INFO - 2017-01-20 14:33:40 --> Config Class Initialized
INFO - 2017-01-20 14:33:40 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:33:40 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:33:40 --> Utf8 Class Initialized
INFO - 2017-01-20 14:33:40 --> URI Class Initialized
INFO - 2017-01-20 14:33:40 --> Router Class Initialized
INFO - 2017-01-20 14:33:40 --> Output Class Initialized
INFO - 2017-01-20 14:33:40 --> Security Class Initialized
DEBUG - 2017-01-20 14:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:33:40 --> Input Class Initialized
INFO - 2017-01-20 14:33:40 --> Language Class Initialized
INFO - 2017-01-20 14:33:40 --> Loader Class Initialized
INFO - 2017-01-20 14:33:40 --> Helper loaded: url_helper
INFO - 2017-01-20 14:33:40 --> Helper loaded: language_helper
INFO - 2017-01-20 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:33:40 --> Controller Class Initialized
INFO - 2017-01-20 14:33:40 --> Database Driver Class Initialized
INFO - 2017-01-20 14:33:40 --> Model Class Initialized
INFO - 2017-01-20 14:33:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:33:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:33:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:33:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:33:40 --> Final output sent to browser
DEBUG - 2017-01-20 14:33:40 --> Total execution time: 0.1509
INFO - 2017-01-20 14:35:14 --> Config Class Initialized
INFO - 2017-01-20 14:35:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:35:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:35:14 --> Utf8 Class Initialized
INFO - 2017-01-20 14:35:14 --> URI Class Initialized
INFO - 2017-01-20 14:35:14 --> Router Class Initialized
INFO - 2017-01-20 14:35:14 --> Output Class Initialized
INFO - 2017-01-20 14:35:14 --> Security Class Initialized
DEBUG - 2017-01-20 14:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:35:14 --> Input Class Initialized
INFO - 2017-01-20 14:35:14 --> Language Class Initialized
INFO - 2017-01-20 14:35:14 --> Loader Class Initialized
INFO - 2017-01-20 14:35:14 --> Helper loaded: url_helper
INFO - 2017-01-20 14:35:14 --> Helper loaded: language_helper
INFO - 2017-01-20 14:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:35:14 --> Controller Class Initialized
INFO - 2017-01-20 14:35:14 --> Database Driver Class Initialized
INFO - 2017-01-20 14:35:14 --> Model Class Initialized
INFO - 2017-01-20 14:35:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:35:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:35:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:35:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:35:14 --> Final output sent to browser
DEBUG - 2017-01-20 14:35:14 --> Total execution time: 0.1161
INFO - 2017-01-20 14:35:55 --> Config Class Initialized
INFO - 2017-01-20 14:35:55 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:35:55 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:35:55 --> Utf8 Class Initialized
INFO - 2017-01-20 14:35:55 --> URI Class Initialized
INFO - 2017-01-20 14:35:55 --> Router Class Initialized
INFO - 2017-01-20 14:35:55 --> Output Class Initialized
INFO - 2017-01-20 14:35:55 --> Security Class Initialized
DEBUG - 2017-01-20 14:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:35:55 --> Input Class Initialized
INFO - 2017-01-20 14:35:55 --> Language Class Initialized
INFO - 2017-01-20 14:35:55 --> Loader Class Initialized
INFO - 2017-01-20 14:35:55 --> Helper loaded: url_helper
INFO - 2017-01-20 14:35:55 --> Helper loaded: language_helper
INFO - 2017-01-20 14:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:35:55 --> Controller Class Initialized
INFO - 2017-01-20 14:35:55 --> Database Driver Class Initialized
INFO - 2017-01-20 14:35:55 --> Model Class Initialized
INFO - 2017-01-20 14:35:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:35:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:35:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:35:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:35:55 --> Final output sent to browser
DEBUG - 2017-01-20 14:35:55 --> Total execution time: 0.1023
INFO - 2017-01-20 14:36:12 --> Config Class Initialized
INFO - 2017-01-20 14:36:12 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:36:12 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:36:12 --> Utf8 Class Initialized
INFO - 2017-01-20 14:36:12 --> URI Class Initialized
INFO - 2017-01-20 14:36:12 --> Router Class Initialized
INFO - 2017-01-20 14:36:12 --> Output Class Initialized
INFO - 2017-01-20 14:36:12 --> Security Class Initialized
DEBUG - 2017-01-20 14:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:36:12 --> Input Class Initialized
INFO - 2017-01-20 14:36:12 --> Language Class Initialized
INFO - 2017-01-20 14:36:12 --> Loader Class Initialized
INFO - 2017-01-20 14:36:12 --> Helper loaded: url_helper
INFO - 2017-01-20 14:36:12 --> Helper loaded: language_helper
INFO - 2017-01-20 14:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:36:12 --> Controller Class Initialized
INFO - 2017-01-20 14:36:12 --> Database Driver Class Initialized
INFO - 2017-01-20 14:36:12 --> Model Class Initialized
INFO - 2017-01-20 14:36:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:36:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:36:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:36:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:36:13 --> Final output sent to browser
DEBUG - 2017-01-20 14:36:13 --> Total execution time: 0.1142
INFO - 2017-01-20 14:36:32 --> Config Class Initialized
INFO - 2017-01-20 14:36:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:36:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:36:32 --> Utf8 Class Initialized
INFO - 2017-01-20 14:36:32 --> URI Class Initialized
INFO - 2017-01-20 14:36:32 --> Router Class Initialized
INFO - 2017-01-20 14:36:32 --> Output Class Initialized
INFO - 2017-01-20 14:36:32 --> Security Class Initialized
DEBUG - 2017-01-20 14:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:36:32 --> Input Class Initialized
INFO - 2017-01-20 14:36:32 --> Language Class Initialized
INFO - 2017-01-20 14:36:32 --> Loader Class Initialized
INFO - 2017-01-20 14:36:32 --> Helper loaded: url_helper
INFO - 2017-01-20 14:36:32 --> Helper loaded: language_helper
INFO - 2017-01-20 14:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:36:32 --> Controller Class Initialized
INFO - 2017-01-20 14:36:32 --> Database Driver Class Initialized
INFO - 2017-01-20 14:36:32 --> Model Class Initialized
INFO - 2017-01-20 14:36:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:36:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:36:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-20 14:36:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:36:32 --> Final output sent to browser
DEBUG - 2017-01-20 14:36:32 --> Total execution time: 0.0842
INFO - 2017-01-20 14:45:03 --> Config Class Initialized
INFO - 2017-01-20 14:45:03 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:45:03 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:45:03 --> Utf8 Class Initialized
INFO - 2017-01-20 14:45:03 --> URI Class Initialized
INFO - 2017-01-20 14:45:03 --> Router Class Initialized
INFO - 2017-01-20 14:45:03 --> Output Class Initialized
INFO - 2017-01-20 14:45:03 --> Security Class Initialized
DEBUG - 2017-01-20 14:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:45:03 --> Input Class Initialized
INFO - 2017-01-20 14:45:03 --> Language Class Initialized
INFO - 2017-01-20 14:45:03 --> Loader Class Initialized
INFO - 2017-01-20 14:45:03 --> Helper loaded: url_helper
INFO - 2017-01-20 14:45:03 --> Helper loaded: language_helper
INFO - 2017-01-20 14:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:45:03 --> Controller Class Initialized
INFO - 2017-01-20 14:45:03 --> Database Driver Class Initialized
INFO - 2017-01-20 14:45:03 --> Model Class Initialized
INFO - 2017-01-20 14:45:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:45:03 --> Helper loaded: form_helper
INFO - 2017-01-20 14:45:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:45:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 14:45:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:45:03 --> Final output sent to browser
DEBUG - 2017-01-20 14:45:03 --> Total execution time: 0.1785
INFO - 2017-01-20 14:45:10 --> Config Class Initialized
INFO - 2017-01-20 14:45:10 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:45:10 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:45:10 --> Utf8 Class Initialized
INFO - 2017-01-20 14:45:10 --> URI Class Initialized
INFO - 2017-01-20 14:45:10 --> Router Class Initialized
INFO - 2017-01-20 14:45:10 --> Output Class Initialized
INFO - 2017-01-20 14:45:10 --> Security Class Initialized
DEBUG - 2017-01-20 14:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:45:10 --> Input Class Initialized
INFO - 2017-01-20 14:45:10 --> Language Class Initialized
INFO - 2017-01-20 14:45:10 --> Loader Class Initialized
INFO - 2017-01-20 14:45:10 --> Helper loaded: url_helper
INFO - 2017-01-20 14:45:10 --> Helper loaded: language_helper
INFO - 2017-01-20 14:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:45:10 --> Controller Class Initialized
INFO - 2017-01-20 14:45:10 --> Database Driver Class Initialized
INFO - 2017-01-20 14:45:10 --> Model Class Initialized
INFO - 2017-01-20 14:45:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:45:10 --> Helper loaded: form_helper
INFO - 2017-01-20 14:45:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_tpu_tpa.php
INFO - 2017-01-20 14:45:11 --> Final output sent to browser
DEBUG - 2017-01-20 14:45:11 --> Total execution time: 0.4763
INFO - 2017-01-20 14:45:51 --> Config Class Initialized
INFO - 2017-01-20 14:45:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:45:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:45:51 --> Utf8 Class Initialized
INFO - 2017-01-20 14:45:51 --> URI Class Initialized
INFO - 2017-01-20 14:45:51 --> Router Class Initialized
INFO - 2017-01-20 14:45:51 --> Output Class Initialized
INFO - 2017-01-20 14:45:51 --> Security Class Initialized
DEBUG - 2017-01-20 14:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:45:51 --> Input Class Initialized
INFO - 2017-01-20 14:45:51 --> Language Class Initialized
INFO - 2017-01-20 14:45:51 --> Loader Class Initialized
INFO - 2017-01-20 14:45:51 --> Helper loaded: url_helper
INFO - 2017-01-20 14:45:51 --> Helper loaded: language_helper
INFO - 2017-01-20 14:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:45:51 --> Controller Class Initialized
INFO - 2017-01-20 14:45:51 --> Database Driver Class Initialized
INFO - 2017-01-20 14:45:51 --> Model Class Initialized
INFO - 2017-01-20 14:45:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:45:51 --> Helper loaded: form_helper
INFO - 2017-01-20 14:45:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:45:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 14:45:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:45:51 --> Final output sent to browser
DEBUG - 2017-01-20 14:45:51 --> Total execution time: 0.2145
INFO - 2017-01-20 14:45:56 --> Config Class Initialized
INFO - 2017-01-20 14:45:56 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:45:56 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:45:56 --> Utf8 Class Initialized
INFO - 2017-01-20 14:45:56 --> URI Class Initialized
INFO - 2017-01-20 14:45:56 --> Router Class Initialized
INFO - 2017-01-20 14:45:56 --> Output Class Initialized
INFO - 2017-01-20 14:45:56 --> Security Class Initialized
DEBUG - 2017-01-20 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:45:56 --> Input Class Initialized
INFO - 2017-01-20 14:45:56 --> Language Class Initialized
INFO - 2017-01-20 14:45:56 --> Loader Class Initialized
INFO - 2017-01-20 14:45:56 --> Helper loaded: url_helper
INFO - 2017-01-20 14:45:56 --> Helper loaded: language_helper
INFO - 2017-01-20 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:45:56 --> Controller Class Initialized
INFO - 2017-01-20 14:45:56 --> Database Driver Class Initialized
INFO - 2017-01-20 14:45:56 --> Model Class Initialized
INFO - 2017-01-20 14:45:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:45:56 --> Helper loaded: form_helper
INFO - 2017-01-20 14:45:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:45:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-20 14:45:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:45:57 --> Final output sent to browser
DEBUG - 2017-01-20 14:45:57 --> Total execution time: 0.1624
INFO - 2017-01-20 14:46:01 --> Config Class Initialized
INFO - 2017-01-20 14:46:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:46:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:46:01 --> Utf8 Class Initialized
INFO - 2017-01-20 14:46:01 --> URI Class Initialized
INFO - 2017-01-20 14:46:01 --> Router Class Initialized
INFO - 2017-01-20 14:46:01 --> Output Class Initialized
INFO - 2017-01-20 14:46:01 --> Security Class Initialized
DEBUG - 2017-01-20 14:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:46:01 --> Input Class Initialized
INFO - 2017-01-20 14:46:01 --> Language Class Initialized
INFO - 2017-01-20 14:46:01 --> Loader Class Initialized
INFO - 2017-01-20 14:46:01 --> Helper loaded: url_helper
INFO - 2017-01-20 14:46:01 --> Helper loaded: language_helper
INFO - 2017-01-20 14:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:46:01 --> Controller Class Initialized
INFO - 2017-01-20 14:46:01 --> Database Driver Class Initialized
INFO - 2017-01-20 14:46:01 --> Model Class Initialized
INFO - 2017-01-20 14:46:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:46:01 --> Helper loaded: form_helper
INFO - 2017-01-20 14:46:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_tpu_tpa.php
INFO - 2017-01-20 14:46:01 --> Final output sent to browser
DEBUG - 2017-01-20 14:46:01 --> Total execution time: 0.5442
INFO - 2017-01-20 14:47:51 --> Config Class Initialized
INFO - 2017-01-20 14:47:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 14:47:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 14:47:51 --> Utf8 Class Initialized
INFO - 2017-01-20 14:47:51 --> URI Class Initialized
INFO - 2017-01-20 14:47:51 --> Router Class Initialized
INFO - 2017-01-20 14:47:51 --> Output Class Initialized
INFO - 2017-01-20 14:47:51 --> Security Class Initialized
DEBUG - 2017-01-20 14:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 14:47:51 --> Input Class Initialized
INFO - 2017-01-20 14:47:51 --> Language Class Initialized
INFO - 2017-01-20 14:47:51 --> Loader Class Initialized
INFO - 2017-01-20 14:47:51 --> Helper loaded: url_helper
INFO - 2017-01-20 14:47:51 --> Helper loaded: language_helper
INFO - 2017-01-20 14:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 14:47:51 --> Controller Class Initialized
INFO - 2017-01-20 14:47:51 --> Database Driver Class Initialized
INFO - 2017-01-20 14:47:51 --> Model Class Initialized
INFO - 2017-01-20 14:47:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-20 14:47:51 --> Helper loaded: form_helper
INFO - 2017-01-20 14:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-20 14:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-20 14:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-20 14:47:51 --> Final output sent to browser
DEBUG - 2017-01-20 14:47:51 --> Total execution time: 0.1796
