<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-23 13:17:56 --> Config Class Initialized
INFO - 2017-01-23 13:17:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:17:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:17:56 --> Utf8 Class Initialized
INFO - 2017-01-23 13:17:56 --> URI Class Initialized
DEBUG - 2017-01-23 13:17:56 --> No URI present. Default controller set.
INFO - 2017-01-23 13:17:56 --> Router Class Initialized
INFO - 2017-01-23 13:17:56 --> Output Class Initialized
INFO - 2017-01-23 13:17:56 --> Security Class Initialized
DEBUG - 2017-01-23 13:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:17:56 --> Input Class Initialized
INFO - 2017-01-23 13:17:56 --> Language Class Initialized
INFO - 2017-01-23 13:17:56 --> Loader Class Initialized
INFO - 2017-01-23 13:17:56 --> Helper loaded: url_helper
INFO - 2017-01-23 13:17:56 --> Helper loaded: language_helper
INFO - 2017-01-23 13:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:17:56 --> Controller Class Initialized
INFO - 2017-01-23 13:17:56 --> Database Driver Class Initialized
INFO - 2017-01-23 13:17:56 --> Model Class Initialized
INFO - 2017-01-23 13:17:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:17:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-23 13:17:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-23 13:17:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-23 13:17:56 --> Final output sent to browser
DEBUG - 2017-01-23 13:17:56 --> Total execution time: 0.1053
INFO - 2017-01-23 13:17:56 --> Config Class Initialized
INFO - 2017-01-23 13:17:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:17:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:17:56 --> Utf8 Class Initialized
INFO - 2017-01-23 13:17:56 --> URI Class Initialized
INFO - 2017-01-23 13:17:56 --> Router Class Initialized
INFO - 2017-01-23 13:17:56 --> Output Class Initialized
INFO - 2017-01-23 13:17:56 --> Security Class Initialized
DEBUG - 2017-01-23 13:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:17:56 --> Input Class Initialized
INFO - 2017-01-23 13:17:56 --> Language Class Initialized
ERROR - 2017-01-23 13:17:56 --> 404 Page Not Found: Faviconico/index
INFO - 2017-01-23 13:18:07 --> Config Class Initialized
INFO - 2017-01-23 13:18:07 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:07 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:07 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:07 --> URI Class Initialized
INFO - 2017-01-23 13:18:07 --> Router Class Initialized
INFO - 2017-01-23 13:18:07 --> Output Class Initialized
INFO - 2017-01-23 13:18:07 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:07 --> Input Class Initialized
INFO - 2017-01-23 13:18:07 --> Language Class Initialized
INFO - 2017-01-23 13:18:07 --> Loader Class Initialized
INFO - 2017-01-23 13:18:07 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:07 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:07 --> Controller Class Initialized
INFO - 2017-01-23 13:18:07 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:07 --> Model Class Initialized
INFO - 2017-01-23 13:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:07 --> Config Class Initialized
INFO - 2017-01-23 13:18:07 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:07 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:07 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:07 --> URI Class Initialized
INFO - 2017-01-23 13:18:07 --> Router Class Initialized
INFO - 2017-01-23 13:18:07 --> Output Class Initialized
INFO - 2017-01-23 13:18:07 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:07 --> Input Class Initialized
INFO - 2017-01-23 13:18:07 --> Language Class Initialized
INFO - 2017-01-23 13:18:07 --> Loader Class Initialized
INFO - 2017-01-23 13:18:07 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:07 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:07 --> Controller Class Initialized
INFO - 2017-01-23 13:18:07 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:07 --> Model Class Initialized
INFO - 2017-01-23 13:18:07 --> Model Class Initialized
INFO - 2017-01-23 13:18:07 --> Model Class Initialized
INFO - 2017-01-23 13:18:07 --> Model Class Initialized
INFO - 2017-01-23 13:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-23 13:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-23 13:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:07 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:07 --> Total execution time: 0.0979
INFO - 2017-01-23 13:18:10 --> Config Class Initialized
INFO - 2017-01-23 13:18:10 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:10 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:10 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:10 --> URI Class Initialized
INFO - 2017-01-23 13:18:10 --> Router Class Initialized
INFO - 2017-01-23 13:18:10 --> Output Class Initialized
INFO - 2017-01-23 13:18:10 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:10 --> Input Class Initialized
INFO - 2017-01-23 13:18:10 --> Language Class Initialized
INFO - 2017-01-23 13:18:10 --> Loader Class Initialized
INFO - 2017-01-23 13:18:10 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:10 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:10 --> Controller Class Initialized
INFO - 2017-01-23 13:18:10 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:10 --> Model Class Initialized
INFO - 2017-01-23 13:18:10 --> Model Class Initialized
INFO - 2017-01-23 13:18:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:10 --> Helper loaded: form_helper
INFO - 2017-01-23 13:18:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-23 13:18:10 --> Could not find the language line "import_user"
INFO - 2017-01-23 13:18:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-23 13:18:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:10 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:10 --> Total execution time: 0.0844
INFO - 2017-01-23 13:18:19 --> Config Class Initialized
INFO - 2017-01-23 13:18:19 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:19 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:19 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:19 --> URI Class Initialized
INFO - 2017-01-23 13:18:19 --> Router Class Initialized
INFO - 2017-01-23 13:18:19 --> Output Class Initialized
INFO - 2017-01-23 13:18:19 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:19 --> Input Class Initialized
INFO - 2017-01-23 13:18:19 --> Language Class Initialized
INFO - 2017-01-23 13:18:19 --> Loader Class Initialized
INFO - 2017-01-23 13:18:19 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:19 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:19 --> Controller Class Initialized
INFO - 2017-01-23 13:18:19 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:19 --> Model Class Initialized
INFO - 2017-01-23 13:18:19 --> Model Class Initialized
INFO - 2017-01-23 13:18:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:19 --> Helper loaded: form_helper
INFO - 2017-01-23 13:18:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-23 13:18:19 --> Could not find the language line "import_user"
INFO - 2017-01-23 13:18:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-23 13:18:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:19 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:19 --> Total execution time: 0.0872
INFO - 2017-01-23 13:18:27 --> Config Class Initialized
INFO - 2017-01-23 13:18:27 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:27 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:27 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:27 --> URI Class Initialized
INFO - 2017-01-23 13:18:27 --> Router Class Initialized
INFO - 2017-01-23 13:18:27 --> Output Class Initialized
INFO - 2017-01-23 13:18:27 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:27 --> Input Class Initialized
INFO - 2017-01-23 13:18:27 --> Language Class Initialized
INFO - 2017-01-23 13:18:27 --> Loader Class Initialized
INFO - 2017-01-23 13:18:27 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:27 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:27 --> Controller Class Initialized
INFO - 2017-01-23 13:18:27 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:27 --> Model Class Initialized
INFO - 2017-01-23 13:18:27 --> Model Class Initialized
INFO - 2017-01-23 13:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:27 --> Helper loaded: form_helper
INFO - 2017-01-23 13:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-23 13:18:27 --> Could not find the language line "import_user"
INFO - 2017-01-23 13:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-23 13:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:27 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:27 --> Total execution time: 0.0838
INFO - 2017-01-23 13:18:35 --> Config Class Initialized
INFO - 2017-01-23 13:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:35 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:35 --> URI Class Initialized
INFO - 2017-01-23 13:18:35 --> Router Class Initialized
INFO - 2017-01-23 13:18:35 --> Output Class Initialized
INFO - 2017-01-23 13:18:35 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:35 --> Input Class Initialized
INFO - 2017-01-23 13:18:35 --> Language Class Initialized
INFO - 2017-01-23 13:18:35 --> Loader Class Initialized
INFO - 2017-01-23 13:18:35 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:35 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:35 --> Controller Class Initialized
INFO - 2017-01-23 13:18:35 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:35 --> Model Class Initialized
INFO - 2017-01-23 13:18:35 --> Model Class Initialized
INFO - 2017-01-23 13:18:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:35 --> Helper loaded: form_helper
INFO - 2017-01-23 13:18:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-23 13:18:35 --> Could not find the language line "import_user"
INFO - 2017-01-23 13:18:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-23 13:18:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:35 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:35 --> Total execution time: 0.0864
INFO - 2017-01-23 13:18:40 --> Config Class Initialized
INFO - 2017-01-23 13:18:40 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:40 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:40 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:40 --> URI Class Initialized
INFO - 2017-01-23 13:18:40 --> Router Class Initialized
INFO - 2017-01-23 13:18:40 --> Output Class Initialized
INFO - 2017-01-23 13:18:40 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:40 --> Input Class Initialized
INFO - 2017-01-23 13:18:40 --> Language Class Initialized
INFO - 2017-01-23 13:18:40 --> Loader Class Initialized
INFO - 2017-01-23 13:18:40 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:40 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:40 --> Controller Class Initialized
INFO - 2017-01-23 13:18:40 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:40 --> Model Class Initialized
INFO - 2017-01-23 13:18:40 --> Model Class Initialized
INFO - 2017-01-23 13:18:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:40 --> Helper loaded: form_helper
INFO - 2017-01-23 13:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-23 13:18:40 --> Could not find the language line "import_user"
INFO - 2017-01-23 13:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-23 13:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:40 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:40 --> Total execution time: 0.0798
INFO - 2017-01-23 13:18:44 --> Config Class Initialized
INFO - 2017-01-23 13:18:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 13:18:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 13:18:44 --> Utf8 Class Initialized
INFO - 2017-01-23 13:18:44 --> URI Class Initialized
INFO - 2017-01-23 13:18:44 --> Router Class Initialized
INFO - 2017-01-23 13:18:44 --> Output Class Initialized
INFO - 2017-01-23 13:18:44 --> Security Class Initialized
DEBUG - 2017-01-23 13:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 13:18:44 --> Input Class Initialized
INFO - 2017-01-23 13:18:44 --> Language Class Initialized
INFO - 2017-01-23 13:18:44 --> Loader Class Initialized
INFO - 2017-01-23 13:18:44 --> Helper loaded: url_helper
INFO - 2017-01-23 13:18:44 --> Helper loaded: language_helper
INFO - 2017-01-23 13:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 13:18:44 --> Controller Class Initialized
INFO - 2017-01-23 13:18:44 --> Database Driver Class Initialized
INFO - 2017-01-23 13:18:44 --> Model Class Initialized
INFO - 2017-01-23 13:18:44 --> Model Class Initialized
INFO - 2017-01-23 13:18:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-23 13:18:44 --> Helper loaded: form_helper
INFO - 2017-01-23 13:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-23 13:18:44 --> Could not find the language line "import_user"
INFO - 2017-01-23 13:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-23 13:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-23 13:18:44 --> Final output sent to browser
DEBUG - 2017-01-23 13:18:44 --> Total execution time: 0.0773
