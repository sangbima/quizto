<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-24 09:11:03 --> Config Class Initialized
INFO - 2017-01-24 09:11:03 --> Hooks Class Initialized
DEBUG - 2017-01-24 09:11:03 --> UTF-8 Support Enabled
INFO - 2017-01-24 09:11:03 --> Utf8 Class Initialized
INFO - 2017-01-24 09:11:03 --> URI Class Initialized
DEBUG - 2017-01-24 09:11:03 --> No URI present. Default controller set.
INFO - 2017-01-24 09:11:03 --> Router Class Initialized
INFO - 2017-01-24 09:11:03 --> Output Class Initialized
INFO - 2017-01-24 09:11:03 --> Security Class Initialized
DEBUG - 2017-01-24 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 09:11:03 --> Input Class Initialized
INFO - 2017-01-24 09:11:03 --> Language Class Initialized
INFO - 2017-01-24 09:11:03 --> Loader Class Initialized
INFO - 2017-01-24 09:11:03 --> Helper loaded: url_helper
INFO - 2017-01-24 09:11:03 --> Helper loaded: language_helper
INFO - 2017-01-24 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 09:11:03 --> Controller Class Initialized
INFO - 2017-01-24 09:11:03 --> Database Driver Class Initialized
INFO - 2017-01-24 09:11:03 --> Model Class Initialized
INFO - 2017-01-24 09:11:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-24 09:11:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-24 09:11:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-24 09:11:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-24 09:11:03 --> Final output sent to browser
DEBUG - 2017-01-24 09:11:03 --> Total execution time: 0.0997
