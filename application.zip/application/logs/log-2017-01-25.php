<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-25 09:11:13 --> Config Class Initialized
INFO - 2017-01-25 09:11:13 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:11:13 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:11:13 --> Utf8 Class Initialized
INFO - 2017-01-25 09:11:13 --> URI Class Initialized
DEBUG - 2017-01-25 09:11:13 --> No URI present. Default controller set.
INFO - 2017-01-25 09:11:13 --> Router Class Initialized
INFO - 2017-01-25 09:11:13 --> Output Class Initialized
INFO - 2017-01-25 09:11:13 --> Security Class Initialized
DEBUG - 2017-01-25 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:11:13 --> Input Class Initialized
INFO - 2017-01-25 09:11:13 --> Language Class Initialized
INFO - 2017-01-25 09:11:13 --> Loader Class Initialized
INFO - 2017-01-25 09:11:13 --> Helper loaded: url_helper
INFO - 2017-01-25 09:11:13 --> Helper loaded: language_helper
INFO - 2017-01-25 09:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:11:13 --> Controller Class Initialized
INFO - 2017-01-25 09:11:13 --> Database Driver Class Initialized
INFO - 2017-01-25 09:11:13 --> Model Class Initialized
INFO - 2017-01-25 09:11:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:11:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-25 09:11:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-25 09:11:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-25 09:11:13 --> Final output sent to browser
DEBUG - 2017-01-25 09:11:13 --> Total execution time: 0.0917
INFO - 2017-01-25 09:11:21 --> Config Class Initialized
INFO - 2017-01-25 09:11:21 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:11:21 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:11:21 --> Utf8 Class Initialized
INFO - 2017-01-25 09:11:21 --> URI Class Initialized
INFO - 2017-01-25 09:11:21 --> Router Class Initialized
INFO - 2017-01-25 09:11:21 --> Output Class Initialized
INFO - 2017-01-25 09:11:21 --> Security Class Initialized
DEBUG - 2017-01-25 09:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:11:21 --> Input Class Initialized
INFO - 2017-01-25 09:11:21 --> Language Class Initialized
INFO - 2017-01-25 09:11:21 --> Loader Class Initialized
INFO - 2017-01-25 09:11:21 --> Helper loaded: url_helper
INFO - 2017-01-25 09:11:21 --> Helper loaded: language_helper
INFO - 2017-01-25 09:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:11:21 --> Controller Class Initialized
INFO - 2017-01-25 09:11:21 --> Database Driver Class Initialized
INFO - 2017-01-25 09:11:21 --> Model Class Initialized
INFO - 2017-01-25 09:11:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:11:21 --> Config Class Initialized
INFO - 2017-01-25 09:11:21 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:11:21 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:11:21 --> Utf8 Class Initialized
INFO - 2017-01-25 09:11:21 --> URI Class Initialized
INFO - 2017-01-25 09:11:21 --> Router Class Initialized
INFO - 2017-01-25 09:11:21 --> Output Class Initialized
INFO - 2017-01-25 09:11:21 --> Security Class Initialized
DEBUG - 2017-01-25 09:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:11:21 --> Input Class Initialized
INFO - 2017-01-25 09:11:21 --> Language Class Initialized
INFO - 2017-01-25 09:11:21 --> Loader Class Initialized
INFO - 2017-01-25 09:11:21 --> Helper loaded: url_helper
INFO - 2017-01-25 09:11:21 --> Helper loaded: language_helper
INFO - 2017-01-25 09:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:11:21 --> Controller Class Initialized
INFO - 2017-01-25 09:11:21 --> Database Driver Class Initialized
INFO - 2017-01-25 09:11:21 --> Model Class Initialized
INFO - 2017-01-25 09:11:21 --> Model Class Initialized
INFO - 2017-01-25 09:11:21 --> Model Class Initialized
INFO - 2017-01-25 09:11:21 --> Model Class Initialized
INFO - 2017-01-25 09:11:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:11:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:11:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-25 09:11:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:11:21 --> Final output sent to browser
DEBUG - 2017-01-25 09:11:21 --> Total execution time: 0.0909
INFO - 2017-01-25 09:11:26 --> Config Class Initialized
INFO - 2017-01-25 09:11:26 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:11:26 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:11:26 --> Utf8 Class Initialized
INFO - 2017-01-25 09:11:26 --> URI Class Initialized
INFO - 2017-01-25 09:11:26 --> Router Class Initialized
INFO - 2017-01-25 09:11:26 --> Output Class Initialized
INFO - 2017-01-25 09:11:26 --> Security Class Initialized
DEBUG - 2017-01-25 09:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:11:26 --> Input Class Initialized
INFO - 2017-01-25 09:11:26 --> Language Class Initialized
INFO - 2017-01-25 09:11:26 --> Loader Class Initialized
INFO - 2017-01-25 09:11:26 --> Helper loaded: url_helper
INFO - 2017-01-25 09:11:26 --> Helper loaded: language_helper
INFO - 2017-01-25 09:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:11:26 --> Controller Class Initialized
INFO - 2017-01-25 09:11:26 --> Database Driver Class Initialized
INFO - 2017-01-25 09:11:26 --> Model Class Initialized
INFO - 2017-01-25 09:11:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:11:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:11:26 --> Final output sent to browser
DEBUG - 2017-01-25 09:11:26 --> Total execution time: 0.0619
INFO - 2017-01-25 09:15:59 --> Config Class Initialized
INFO - 2017-01-25 09:15:59 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:15:59 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:15:59 --> Utf8 Class Initialized
INFO - 2017-01-25 09:15:59 --> URI Class Initialized
INFO - 2017-01-25 09:15:59 --> Router Class Initialized
INFO - 2017-01-25 09:15:59 --> Output Class Initialized
INFO - 2017-01-25 09:15:59 --> Security Class Initialized
DEBUG - 2017-01-25 09:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:15:59 --> Input Class Initialized
INFO - 2017-01-25 09:15:59 --> Language Class Initialized
INFO - 2017-01-25 09:15:59 --> Loader Class Initialized
INFO - 2017-01-25 09:15:59 --> Helper loaded: url_helper
INFO - 2017-01-25 09:15:59 --> Helper loaded: language_helper
INFO - 2017-01-25 09:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:15:59 --> Controller Class Initialized
INFO - 2017-01-25 09:15:59 --> Database Driver Class Initialized
INFO - 2017-01-25 09:15:59 --> Model Class Initialized
INFO - 2017-01-25 09:15:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:15:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:15:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:15:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:15:59 --> Final output sent to browser
DEBUG - 2017-01-25 09:15:59 --> Total execution time: 0.0665
INFO - 2017-01-25 09:16:12 --> Config Class Initialized
INFO - 2017-01-25 09:16:12 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:16:12 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:16:12 --> Utf8 Class Initialized
INFO - 2017-01-25 09:16:12 --> URI Class Initialized
INFO - 2017-01-25 09:16:12 --> Router Class Initialized
INFO - 2017-01-25 09:16:12 --> Output Class Initialized
INFO - 2017-01-25 09:16:12 --> Security Class Initialized
DEBUG - 2017-01-25 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:16:12 --> Input Class Initialized
INFO - 2017-01-25 09:16:12 --> Language Class Initialized
INFO - 2017-01-25 09:16:12 --> Loader Class Initialized
INFO - 2017-01-25 09:16:12 --> Helper loaded: url_helper
INFO - 2017-01-25 09:16:12 --> Helper loaded: language_helper
INFO - 2017-01-25 09:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:16:12 --> Controller Class Initialized
INFO - 2017-01-25 09:16:12 --> Database Driver Class Initialized
INFO - 2017-01-25 09:16:12 --> Model Class Initialized
INFO - 2017-01-25 09:16:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:16:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:16:12 --> Final output sent to browser
DEBUG - 2017-01-25 09:16:12 --> Total execution time: 0.0645
INFO - 2017-01-25 09:17:26 --> Config Class Initialized
INFO - 2017-01-25 09:17:26 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:17:26 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:17:26 --> Utf8 Class Initialized
INFO - 2017-01-25 09:17:26 --> URI Class Initialized
INFO - 2017-01-25 09:17:26 --> Router Class Initialized
INFO - 2017-01-25 09:17:26 --> Output Class Initialized
INFO - 2017-01-25 09:17:26 --> Security Class Initialized
DEBUG - 2017-01-25 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:17:26 --> Input Class Initialized
INFO - 2017-01-25 09:17:26 --> Language Class Initialized
INFO - 2017-01-25 09:17:26 --> Loader Class Initialized
INFO - 2017-01-25 09:17:26 --> Helper loaded: url_helper
INFO - 2017-01-25 09:17:26 --> Helper loaded: language_helper
INFO - 2017-01-25 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:17:26 --> Controller Class Initialized
INFO - 2017-01-25 09:17:26 --> Database Driver Class Initialized
INFO - 2017-01-25 09:17:26 --> Model Class Initialized
INFO - 2017-01-25 09:17:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:17:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:17:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:17:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:17:26 --> Final output sent to browser
DEBUG - 2017-01-25 09:17:26 --> Total execution time: 0.0660
INFO - 2017-01-25 09:20:37 --> Config Class Initialized
INFO - 2017-01-25 09:20:37 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:37 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:37 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:37 --> URI Class Initialized
INFO - 2017-01-25 09:20:37 --> Router Class Initialized
INFO - 2017-01-25 09:20:37 --> Output Class Initialized
INFO - 2017-01-25 09:20:37 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:37 --> Input Class Initialized
INFO - 2017-01-25 09:20:37 --> Language Class Initialized
INFO - 2017-01-25 09:20:37 --> Loader Class Initialized
INFO - 2017-01-25 09:20:37 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:37 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:37 --> Controller Class Initialized
INFO - 2017-01-25 09:20:37 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:37 --> Model Class Initialized
INFO - 2017-01-25 09:20:37 --> Model Class Initialized
INFO - 2017-01-25 09:20:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:37 --> Config Class Initialized
INFO - 2017-01-25 09:20:37 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:37 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:37 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:37 --> URI Class Initialized
INFO - 2017-01-25 09:20:37 --> Router Class Initialized
INFO - 2017-01-25 09:20:37 --> Output Class Initialized
INFO - 2017-01-25 09:20:37 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:37 --> Input Class Initialized
INFO - 2017-01-25 09:20:37 --> Language Class Initialized
INFO - 2017-01-25 09:20:37 --> Loader Class Initialized
INFO - 2017-01-25 09:20:37 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:37 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:37 --> Controller Class Initialized
INFO - 2017-01-25 09:20:37 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:37 --> Model Class Initialized
INFO - 2017-01-25 09:20:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-25 09:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-25 09:20:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-25 09:20:37 --> Final output sent to browser
DEBUG - 2017-01-25 09:20:37 --> Total execution time: 0.0624
INFO - 2017-01-25 09:20:41 --> Config Class Initialized
INFO - 2017-01-25 09:20:41 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:41 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:41 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:41 --> URI Class Initialized
INFO - 2017-01-25 09:20:41 --> Router Class Initialized
INFO - 2017-01-25 09:20:41 --> Output Class Initialized
INFO - 2017-01-25 09:20:41 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:41 --> Input Class Initialized
INFO - 2017-01-25 09:20:41 --> Language Class Initialized
INFO - 2017-01-25 09:20:41 --> Loader Class Initialized
INFO - 2017-01-25 09:20:41 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:41 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:41 --> Controller Class Initialized
INFO - 2017-01-25 09:20:41 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:41 --> Model Class Initialized
INFO - 2017-01-25 09:20:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:41 --> Config Class Initialized
INFO - 2017-01-25 09:20:41 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:41 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:41 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:41 --> URI Class Initialized
INFO - 2017-01-25 09:20:41 --> Router Class Initialized
INFO - 2017-01-25 09:20:41 --> Output Class Initialized
INFO - 2017-01-25 09:20:41 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:41 --> Input Class Initialized
INFO - 2017-01-25 09:20:41 --> Language Class Initialized
INFO - 2017-01-25 09:20:41 --> Loader Class Initialized
INFO - 2017-01-25 09:20:41 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:41 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:41 --> Controller Class Initialized
INFO - 2017-01-25 09:20:41 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:41 --> Model Class Initialized
INFO - 2017-01-25 09:20:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-25 09:20:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-25 09:20:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-25 09:20:41 --> Final output sent to browser
DEBUG - 2017-01-25 09:20:41 --> Total execution time: 0.0706
INFO - 2017-01-25 09:20:47 --> Config Class Initialized
INFO - 2017-01-25 09:20:47 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:47 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:47 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:47 --> URI Class Initialized
INFO - 2017-01-25 09:20:47 --> Router Class Initialized
INFO - 2017-01-25 09:20:47 --> Output Class Initialized
INFO - 2017-01-25 09:20:47 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:47 --> Input Class Initialized
INFO - 2017-01-25 09:20:47 --> Language Class Initialized
INFO - 2017-01-25 09:20:47 --> Loader Class Initialized
INFO - 2017-01-25 09:20:47 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:47 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:47 --> Controller Class Initialized
INFO - 2017-01-25 09:20:47 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:47 --> Model Class Initialized
INFO - 2017-01-25 09:20:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:47 --> Config Class Initialized
INFO - 2017-01-25 09:20:47 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:47 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:47 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:47 --> URI Class Initialized
INFO - 2017-01-25 09:20:47 --> Router Class Initialized
INFO - 2017-01-25 09:20:47 --> Output Class Initialized
INFO - 2017-01-25 09:20:47 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:47 --> Input Class Initialized
INFO - 2017-01-25 09:20:47 --> Language Class Initialized
INFO - 2017-01-25 09:20:47 --> Loader Class Initialized
INFO - 2017-01-25 09:20:47 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:47 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:47 --> Controller Class Initialized
INFO - 2017-01-25 09:20:47 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:47 --> Model Class Initialized
INFO - 2017-01-25 09:20:47 --> Model Class Initialized
INFO - 2017-01-25 09:20:47 --> Model Class Initialized
INFO - 2017-01-25 09:20:47 --> Model Class Initialized
INFO - 2017-01-25 09:20:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-25 09:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:20:47 --> Final output sent to browser
DEBUG - 2017-01-25 09:20:47 --> Total execution time: 0.0839
INFO - 2017-01-25 09:20:53 --> Config Class Initialized
INFO - 2017-01-25 09:20:53 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:20:53 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:20:53 --> Utf8 Class Initialized
INFO - 2017-01-25 09:20:53 --> URI Class Initialized
INFO - 2017-01-25 09:20:53 --> Router Class Initialized
INFO - 2017-01-25 09:20:53 --> Output Class Initialized
INFO - 2017-01-25 09:20:53 --> Security Class Initialized
DEBUG - 2017-01-25 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:20:53 --> Input Class Initialized
INFO - 2017-01-25 09:20:53 --> Language Class Initialized
INFO - 2017-01-25 09:20:53 --> Loader Class Initialized
INFO - 2017-01-25 09:20:53 --> Helper loaded: url_helper
INFO - 2017-01-25 09:20:53 --> Helper loaded: language_helper
INFO - 2017-01-25 09:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:20:53 --> Controller Class Initialized
INFO - 2017-01-25 09:20:53 --> Database Driver Class Initialized
INFO - 2017-01-25 09:20:53 --> Model Class Initialized
INFO - 2017-01-25 09:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:20:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:20:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:20:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:20:53 --> Final output sent to browser
DEBUG - 2017-01-25 09:20:53 --> Total execution time: 0.0617
INFO - 2017-01-25 09:24:04 --> Config Class Initialized
INFO - 2017-01-25 09:24:04 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:04 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:04 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:04 --> URI Class Initialized
INFO - 2017-01-25 09:24:04 --> Router Class Initialized
INFO - 2017-01-25 09:24:04 --> Output Class Initialized
INFO - 2017-01-25 09:24:04 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:04 --> Input Class Initialized
INFO - 2017-01-25 09:24:04 --> Language Class Initialized
INFO - 2017-01-25 09:24:04 --> Loader Class Initialized
INFO - 2017-01-25 09:24:04 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:04 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:04 --> Controller Class Initialized
INFO - 2017-01-25 09:24:04 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:04 --> Model Class Initialized
INFO - 2017-01-25 09:24:04 --> Model Class Initialized
INFO - 2017-01-25 09:24:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:24:04 --> Helper loaded: form_helper
INFO - 2017-01-25 09:24:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-25 09:24:04 --> Could not find the language line "import_user"
INFO - 2017-01-25 09:24:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-25 09:24:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:24:04 --> Final output sent to browser
DEBUG - 2017-01-25 09:24:04 --> Total execution time: 0.0756
INFO - 2017-01-25 09:24:11 --> Config Class Initialized
INFO - 2017-01-25 09:24:11 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:11 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:11 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:11 --> URI Class Initialized
INFO - 2017-01-25 09:24:11 --> Router Class Initialized
INFO - 2017-01-25 09:24:11 --> Output Class Initialized
INFO - 2017-01-25 09:24:11 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:11 --> Input Class Initialized
INFO - 2017-01-25 09:24:11 --> Language Class Initialized
INFO - 2017-01-25 09:24:11 --> Loader Class Initialized
INFO - 2017-01-25 09:24:11 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:11 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:11 --> Controller Class Initialized
INFO - 2017-01-25 09:24:11 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:11 --> Model Class Initialized
INFO - 2017-01-25 09:24:11 --> Model Class Initialized
INFO - 2017-01-25 09:24:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:24:11 --> Helper loaded: form_helper
INFO - 2017-01-25 09:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-01-25 09:24:11 --> Could not find the language line "import_user"
INFO - 2017-01-25 09:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-01-25 09:24:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:24:11 --> Final output sent to browser
DEBUG - 2017-01-25 09:24:11 --> Total execution time: 0.0794
INFO - 2017-01-25 09:24:18 --> Config Class Initialized
INFO - 2017-01-25 09:24:18 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:18 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:18 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:18 --> URI Class Initialized
INFO - 2017-01-25 09:24:18 --> Router Class Initialized
INFO - 2017-01-25 09:24:18 --> Output Class Initialized
INFO - 2017-01-25 09:24:18 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:18 --> Input Class Initialized
INFO - 2017-01-25 09:24:18 --> Language Class Initialized
INFO - 2017-01-25 09:24:18 --> Loader Class Initialized
INFO - 2017-01-25 09:24:18 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:18 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:18 --> Controller Class Initialized
INFO - 2017-01-25 09:24:18 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:18 --> Model Class Initialized
INFO - 2017-01-25 09:24:18 --> Model Class Initialized
INFO - 2017-01-25 09:24:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:24:18 --> Config Class Initialized
INFO - 2017-01-25 09:24:18 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:18 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:18 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:18 --> URI Class Initialized
INFO - 2017-01-25 09:24:18 --> Router Class Initialized
INFO - 2017-01-25 09:24:18 --> Output Class Initialized
INFO - 2017-01-25 09:24:18 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:18 --> Input Class Initialized
INFO - 2017-01-25 09:24:18 --> Language Class Initialized
INFO - 2017-01-25 09:24:18 --> Loader Class Initialized
INFO - 2017-01-25 09:24:18 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:18 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:18 --> Controller Class Initialized
INFO - 2017-01-25 09:24:18 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:18 --> Model Class Initialized
INFO - 2017-01-25 09:24:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:24:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-25 09:24:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-25 09:24:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-25 09:24:18 --> Final output sent to browser
DEBUG - 2017-01-25 09:24:18 --> Total execution time: 0.0592
INFO - 2017-01-25 09:24:23 --> Config Class Initialized
INFO - 2017-01-25 09:24:23 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:23 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:23 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:23 --> URI Class Initialized
INFO - 2017-01-25 09:24:23 --> Router Class Initialized
INFO - 2017-01-25 09:24:23 --> Output Class Initialized
INFO - 2017-01-25 09:24:23 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:23 --> Input Class Initialized
INFO - 2017-01-25 09:24:23 --> Language Class Initialized
INFO - 2017-01-25 09:24:23 --> Loader Class Initialized
INFO - 2017-01-25 09:24:23 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:23 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:23 --> Controller Class Initialized
INFO - 2017-01-25 09:24:23 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:23 --> Model Class Initialized
INFO - 2017-01-25 09:24:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:24:23 --> Config Class Initialized
INFO - 2017-01-25 09:24:23 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:23 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:23 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:23 --> URI Class Initialized
INFO - 2017-01-25 09:24:23 --> Router Class Initialized
INFO - 2017-01-25 09:24:23 --> Output Class Initialized
INFO - 2017-01-25 09:24:23 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:23 --> Input Class Initialized
INFO - 2017-01-25 09:24:23 --> Language Class Initialized
INFO - 2017-01-25 09:24:23 --> Loader Class Initialized
INFO - 2017-01-25 09:24:23 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:23 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:23 --> Controller Class Initialized
INFO - 2017-01-25 09:24:23 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:23 --> Model Class Initialized
INFO - 2017-01-25 09:24:23 --> Model Class Initialized
INFO - 2017-01-25 09:24:23 --> Model Class Initialized
INFO - 2017-01-25 09:24:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:24:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:24:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-25 09:24:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:24:23 --> Final output sent to browser
DEBUG - 2017-01-25 09:24:23 --> Total execution time: 0.1078
INFO - 2017-01-25 09:24:27 --> Config Class Initialized
INFO - 2017-01-25 09:24:27 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:24:27 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:24:27 --> Utf8 Class Initialized
INFO - 2017-01-25 09:24:27 --> URI Class Initialized
INFO - 2017-01-25 09:24:27 --> Router Class Initialized
INFO - 2017-01-25 09:24:27 --> Output Class Initialized
INFO - 2017-01-25 09:24:27 --> Security Class Initialized
DEBUG - 2017-01-25 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:24:27 --> Input Class Initialized
INFO - 2017-01-25 09:24:27 --> Language Class Initialized
INFO - 2017-01-25 09:24:27 --> Loader Class Initialized
INFO - 2017-01-25 09:24:27 --> Helper loaded: url_helper
INFO - 2017-01-25 09:24:27 --> Helper loaded: language_helper
INFO - 2017-01-25 09:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:24:27 --> Controller Class Initialized
INFO - 2017-01-25 09:24:27 --> Database Driver Class Initialized
INFO - 2017-01-25 09:24:27 --> Model Class Initialized
INFO - 2017-01-25 09:24:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:10 --> Config Class Initialized
INFO - 2017-01-25 09:25:10 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:10 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:10 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:10 --> URI Class Initialized
DEBUG - 2017-01-25 09:25:10 --> No URI present. Default controller set.
INFO - 2017-01-25 09:25:10 --> Router Class Initialized
INFO - 2017-01-25 09:25:10 --> Output Class Initialized
INFO - 2017-01-25 09:25:10 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:10 --> Input Class Initialized
INFO - 2017-01-25 09:25:10 --> Language Class Initialized
INFO - 2017-01-25 09:25:10 --> Loader Class Initialized
INFO - 2017-01-25 09:25:10 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:10 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:10 --> Controller Class Initialized
INFO - 2017-01-25 09:25:10 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:10 --> Config Class Initialized
INFO - 2017-01-25 09:25:10 --> Hooks Class Initialized
INFO - 2017-01-25 09:25:10 --> Model Class Initialized
INFO - 2017-01-25 09:25:10 --> Language file loaded: language/indonesia/basic_lang.php
DEBUG - 2017-01-25 09:25:10 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:10 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:10 --> URI Class Initialized
DEBUG - 2017-01-25 09:25:10 --> No URI present. Default controller set.
INFO - 2017-01-25 09:25:10 --> Router Class Initialized
INFO - 2017-01-25 09:25:10 --> Output Class Initialized
INFO - 2017-01-25 09:25:10 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:10 --> Input Class Initialized
INFO - 2017-01-25 09:25:10 --> Language Class Initialized
INFO - 2017-01-25 09:25:10 --> Loader Class Initialized
INFO - 2017-01-25 09:25:10 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:10 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:10 --> Controller Class Initialized
INFO - 2017-01-25 09:25:10 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:10 --> Model Class Initialized
INFO - 2017-01-25 09:25:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:10 --> Config Class Initialized
INFO - 2017-01-25 09:25:10 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:10 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:10 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:10 --> URI Class Initialized
INFO - 2017-01-25 09:25:10 --> Router Class Initialized
INFO - 2017-01-25 09:25:10 --> Output Class Initialized
INFO - 2017-01-25 09:25:10 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:10 --> Input Class Initialized
INFO - 2017-01-25 09:25:10 --> Language Class Initialized
INFO - 2017-01-25 09:25:10 --> Loader Class Initialized
INFO - 2017-01-25 09:25:10 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:10 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:10 --> Controller Class Initialized
INFO - 2017-01-25 09:25:10 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:10 --> Model Class Initialized
INFO - 2017-01-25 09:25:10 --> Model Class Initialized
INFO - 2017-01-25 09:25:10 --> Model Class Initialized
INFO - 2017-01-25 09:25:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-25 09:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:25:10 --> Final output sent to browser
DEBUG - 2017-01-25 09:25:10 --> Total execution time: 0.0897
INFO - 2017-01-25 09:25:16 --> Config Class Initialized
INFO - 2017-01-25 09:25:16 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:16 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:16 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:16 --> URI Class Initialized
INFO - 2017-01-25 09:25:16 --> Router Class Initialized
INFO - 2017-01-25 09:25:16 --> Output Class Initialized
INFO - 2017-01-25 09:25:16 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:16 --> Input Class Initialized
INFO - 2017-01-25 09:25:16 --> Language Class Initialized
INFO - 2017-01-25 09:25:16 --> Loader Class Initialized
INFO - 2017-01-25 09:25:16 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:16 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:16 --> Controller Class Initialized
INFO - 2017-01-25 09:25:16 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:16 --> Model Class Initialized
INFO - 2017-01-25 09:25:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:16 --> Helper loaded: form_helper
INFO - 2017-01-25 09:25:19 --> Config Class Initialized
INFO - 2017-01-25 09:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:19 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:19 --> URI Class Initialized
DEBUG - 2017-01-25 09:25:19 --> No URI present. Default controller set.
INFO - 2017-01-25 09:25:19 --> Router Class Initialized
INFO - 2017-01-25 09:25:19 --> Output Class Initialized
INFO - 2017-01-25 09:25:19 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:19 --> Input Class Initialized
INFO - 2017-01-25 09:25:19 --> Language Class Initialized
INFO - 2017-01-25 09:25:19 --> Loader Class Initialized
INFO - 2017-01-25 09:25:19 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:19 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:19 --> Controller Class Initialized
INFO - 2017-01-25 09:25:19 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:19 --> Model Class Initialized
INFO - 2017-01-25 09:25:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:19 --> Config Class Initialized
INFO - 2017-01-25 09:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:19 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:19 --> URI Class Initialized
INFO - 2017-01-25 09:25:19 --> Router Class Initialized
INFO - 2017-01-25 09:25:19 --> Output Class Initialized
INFO - 2017-01-25 09:25:19 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:19 --> Input Class Initialized
INFO - 2017-01-25 09:25:19 --> Language Class Initialized
INFO - 2017-01-25 09:25:19 --> Loader Class Initialized
INFO - 2017-01-25 09:25:19 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:19 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:19 --> Controller Class Initialized
INFO - 2017-01-25 09:25:19 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:19 --> Model Class Initialized
INFO - 2017-01-25 09:25:19 --> Model Class Initialized
INFO - 2017-01-25 09:25:19 --> Model Class Initialized
INFO - 2017-01-25 09:25:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:25:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-01-25 09:25:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:25:19 --> Final output sent to browser
DEBUG - 2017-01-25 09:25:19 --> Total execution time: 0.0895
INFO - 2017-01-25 09:25:21 --> Config Class Initialized
INFO - 2017-01-25 09:25:21 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:21 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:21 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:21 --> URI Class Initialized
INFO - 2017-01-25 09:25:21 --> Router Class Initialized
INFO - 2017-01-25 09:25:21 --> Output Class Initialized
INFO - 2017-01-25 09:25:21 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:21 --> Input Class Initialized
INFO - 2017-01-25 09:25:21 --> Language Class Initialized
INFO - 2017-01-25 09:25:21 --> Loader Class Initialized
INFO - 2017-01-25 09:25:21 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:21 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:21 --> Controller Class Initialized
INFO - 2017-01-25 09:25:21 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:21 --> Model Class Initialized
INFO - 2017-01-25 09:25:21 --> Model Class Initialized
INFO - 2017-01-25 09:25:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:21 --> Config Class Initialized
INFO - 2017-01-25 09:25:21 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:21 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:21 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:21 --> URI Class Initialized
INFO - 2017-01-25 09:25:21 --> Router Class Initialized
INFO - 2017-01-25 09:25:21 --> Output Class Initialized
INFO - 2017-01-25 09:25:21 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:21 --> Input Class Initialized
INFO - 2017-01-25 09:25:21 --> Language Class Initialized
INFO - 2017-01-25 09:25:21 --> Loader Class Initialized
INFO - 2017-01-25 09:25:21 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:21 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:21 --> Controller Class Initialized
INFO - 2017-01-25 09:25:21 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:21 --> Model Class Initialized
INFO - 2017-01-25 09:25:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-25 09:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-25 09:25:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-25 09:25:21 --> Final output sent to browser
DEBUG - 2017-01-25 09:25:21 --> Total execution time: 0.0705
INFO - 2017-01-25 09:25:26 --> Config Class Initialized
INFO - 2017-01-25 09:25:26 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:26 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:26 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:26 --> URI Class Initialized
INFO - 2017-01-25 09:25:26 --> Router Class Initialized
INFO - 2017-01-25 09:25:26 --> Output Class Initialized
INFO - 2017-01-25 09:25:26 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:26 --> Input Class Initialized
INFO - 2017-01-25 09:25:26 --> Language Class Initialized
INFO - 2017-01-25 09:25:26 --> Loader Class Initialized
INFO - 2017-01-25 09:25:26 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:26 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:26 --> Controller Class Initialized
INFO - 2017-01-25 09:25:26 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:26 --> Model Class Initialized
INFO - 2017-01-25 09:25:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:26 --> Config Class Initialized
INFO - 2017-01-25 09:25:26 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:26 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:26 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:26 --> URI Class Initialized
INFO - 2017-01-25 09:25:26 --> Router Class Initialized
INFO - 2017-01-25 09:25:26 --> Output Class Initialized
INFO - 2017-01-25 09:25:26 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:26 --> Input Class Initialized
INFO - 2017-01-25 09:25:26 --> Language Class Initialized
INFO - 2017-01-25 09:25:26 --> Loader Class Initialized
INFO - 2017-01-25 09:25:26 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:26 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:26 --> Controller Class Initialized
INFO - 2017-01-25 09:25:26 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:26 --> Model Class Initialized
INFO - 2017-01-25 09:25:26 --> Model Class Initialized
INFO - 2017-01-25 09:25:26 --> Model Class Initialized
INFO - 2017-01-25 09:25:26 --> Model Class Initialized
INFO - 2017-01-25 09:25:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-25 09:25:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:25:26 --> Final output sent to browser
DEBUG - 2017-01-25 09:25:26 --> Total execution time: 0.0825
INFO - 2017-01-25 09:25:29 --> Config Class Initialized
INFO - 2017-01-25 09:25:29 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:25:29 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:25:29 --> Utf8 Class Initialized
INFO - 2017-01-25 09:25:29 --> URI Class Initialized
INFO - 2017-01-25 09:25:29 --> Router Class Initialized
INFO - 2017-01-25 09:25:29 --> Output Class Initialized
INFO - 2017-01-25 09:25:29 --> Security Class Initialized
DEBUG - 2017-01-25 09:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:25:29 --> Input Class Initialized
INFO - 2017-01-25 09:25:29 --> Language Class Initialized
INFO - 2017-01-25 09:25:29 --> Loader Class Initialized
INFO - 2017-01-25 09:25:29 --> Helper loaded: url_helper
INFO - 2017-01-25 09:25:29 --> Helper loaded: language_helper
INFO - 2017-01-25 09:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:25:29 --> Controller Class Initialized
INFO - 2017-01-25 09:25:29 --> Database Driver Class Initialized
INFO - 2017-01-25 09:25:29 --> Model Class Initialized
INFO - 2017-01-25 09:25:29 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-25 09:25:29 --> Severity: Notice --> Undefined variable: uid C:\wamp64\www\savsoftquiz\application\controllers\Reset.php 29
INFO - 2017-01-25 09:25:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:25:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:25:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:25:29 --> Final output sent to browser
DEBUG - 2017-01-25 09:25:29 --> Total execution time: 0.0646
INFO - 2017-01-25 09:26:26 --> Config Class Initialized
INFO - 2017-01-25 09:26:26 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:26:26 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:26:26 --> Utf8 Class Initialized
INFO - 2017-01-25 09:26:26 --> URI Class Initialized
INFO - 2017-01-25 09:26:26 --> Router Class Initialized
INFO - 2017-01-25 09:26:26 --> Output Class Initialized
INFO - 2017-01-25 09:26:26 --> Security Class Initialized
DEBUG - 2017-01-25 09:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:26:26 --> Input Class Initialized
INFO - 2017-01-25 09:26:26 --> Language Class Initialized
INFO - 2017-01-25 09:26:26 --> Loader Class Initialized
INFO - 2017-01-25 09:26:26 --> Helper loaded: url_helper
INFO - 2017-01-25 09:26:26 --> Helper loaded: language_helper
INFO - 2017-01-25 09:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:26:26 --> Controller Class Initialized
INFO - 2017-01-25 09:26:26 --> Database Driver Class Initialized
INFO - 2017-01-25 09:26:26 --> Model Class Initialized
INFO - 2017-01-25 09:26:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:26:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:26:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:26:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:26:26 --> Final output sent to browser
DEBUG - 2017-01-25 09:26:26 --> Total execution time: 0.0844
INFO - 2017-01-25 09:36:06 --> Config Class Initialized
INFO - 2017-01-25 09:36:06 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:36:06 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:36:06 --> Utf8 Class Initialized
INFO - 2017-01-25 09:36:06 --> URI Class Initialized
INFO - 2017-01-25 09:36:06 --> Router Class Initialized
INFO - 2017-01-25 09:36:06 --> Output Class Initialized
INFO - 2017-01-25 09:36:06 --> Security Class Initialized
DEBUG - 2017-01-25 09:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:36:06 --> Input Class Initialized
INFO - 2017-01-25 09:36:06 --> Language Class Initialized
INFO - 2017-01-25 09:36:06 --> Loader Class Initialized
INFO - 2017-01-25 09:36:06 --> Helper loaded: url_helper
INFO - 2017-01-25 09:36:06 --> Helper loaded: language_helper
INFO - 2017-01-25 09:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:36:06 --> Controller Class Initialized
INFO - 2017-01-25 09:36:06 --> Database Driver Class Initialized
INFO - 2017-01-25 09:36:06 --> Model Class Initialized
INFO - 2017-01-25 09:36:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:36:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:36:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:36:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:36:06 --> Final output sent to browser
DEBUG - 2017-01-25 09:36:06 --> Total execution time: 0.0896
INFO - 2017-01-25 09:36:40 --> Config Class Initialized
INFO - 2017-01-25 09:36:40 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:36:40 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:36:40 --> Utf8 Class Initialized
INFO - 2017-01-25 09:36:40 --> URI Class Initialized
INFO - 2017-01-25 09:36:40 --> Router Class Initialized
INFO - 2017-01-25 09:36:40 --> Output Class Initialized
INFO - 2017-01-25 09:36:40 --> Security Class Initialized
DEBUG - 2017-01-25 09:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:36:40 --> Input Class Initialized
INFO - 2017-01-25 09:36:40 --> Language Class Initialized
INFO - 2017-01-25 09:36:40 --> Loader Class Initialized
INFO - 2017-01-25 09:36:40 --> Helper loaded: url_helper
INFO - 2017-01-25 09:36:40 --> Helper loaded: language_helper
INFO - 2017-01-25 09:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:36:40 --> Controller Class Initialized
INFO - 2017-01-25 09:36:40 --> Database Driver Class Initialized
INFO - 2017-01-25 09:36:40 --> Model Class Initialized
INFO - 2017-01-25 09:36:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:36:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:36:40 --> Final output sent to browser
DEBUG - 2017-01-25 09:36:40 --> Total execution time: 0.0778
INFO - 2017-01-25 09:37:52 --> Config Class Initialized
INFO - 2017-01-25 09:37:52 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:37:52 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:37:52 --> Utf8 Class Initialized
INFO - 2017-01-25 09:37:52 --> URI Class Initialized
INFO - 2017-01-25 09:37:52 --> Router Class Initialized
INFO - 2017-01-25 09:37:52 --> Output Class Initialized
INFO - 2017-01-25 09:37:52 --> Security Class Initialized
DEBUG - 2017-01-25 09:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:37:52 --> Input Class Initialized
INFO - 2017-01-25 09:37:52 --> Language Class Initialized
INFO - 2017-01-25 09:37:52 --> Loader Class Initialized
INFO - 2017-01-25 09:37:52 --> Helper loaded: url_helper
INFO - 2017-01-25 09:37:52 --> Helper loaded: language_helper
INFO - 2017-01-25 09:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:37:52 --> Controller Class Initialized
INFO - 2017-01-25 09:37:52 --> Database Driver Class Initialized
INFO - 2017-01-25 09:37:52 --> Model Class Initialized
INFO - 2017-01-25 09:37:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:37:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:37:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:37:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:37:52 --> Final output sent to browser
DEBUG - 2017-01-25 09:37:52 --> Total execution time: 0.0865
INFO - 2017-01-25 09:38:08 --> Config Class Initialized
INFO - 2017-01-25 09:38:08 --> Hooks Class Initialized
DEBUG - 2017-01-25 09:38:08 --> UTF-8 Support Enabled
INFO - 2017-01-25 09:38:08 --> Utf8 Class Initialized
INFO - 2017-01-25 09:38:08 --> URI Class Initialized
INFO - 2017-01-25 09:38:08 --> Router Class Initialized
INFO - 2017-01-25 09:38:08 --> Output Class Initialized
INFO - 2017-01-25 09:38:08 --> Security Class Initialized
DEBUG - 2017-01-25 09:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 09:38:08 --> Input Class Initialized
INFO - 2017-01-25 09:38:08 --> Language Class Initialized
INFO - 2017-01-25 09:38:08 --> Loader Class Initialized
INFO - 2017-01-25 09:38:08 --> Helper loaded: url_helper
INFO - 2017-01-25 09:38:08 --> Helper loaded: language_helper
INFO - 2017-01-25 09:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 09:38:08 --> Controller Class Initialized
INFO - 2017-01-25 09:38:08 --> Database Driver Class Initialized
INFO - 2017-01-25 09:38:08 --> Model Class Initialized
INFO - 2017-01-25 09:38:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 09:38:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 09:38:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 09:38:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 09:38:08 --> Final output sent to browser
DEBUG - 2017-01-25 09:38:08 --> Total execution time: 0.0731
INFO - 2017-01-25 10:19:45 --> Config Class Initialized
INFO - 2017-01-25 10:19:45 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:19:45 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:19:45 --> Utf8 Class Initialized
INFO - 2017-01-25 10:19:45 --> URI Class Initialized
INFO - 2017-01-25 10:19:45 --> Router Class Initialized
INFO - 2017-01-25 10:19:45 --> Output Class Initialized
INFO - 2017-01-25 10:19:45 --> Security Class Initialized
DEBUG - 2017-01-25 10:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:19:45 --> Input Class Initialized
INFO - 2017-01-25 10:19:45 --> Language Class Initialized
INFO - 2017-01-25 10:19:45 --> Loader Class Initialized
INFO - 2017-01-25 10:19:45 --> Helper loaded: url_helper
INFO - 2017-01-25 10:19:45 --> Helper loaded: language_helper
INFO - 2017-01-25 10:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:19:45 --> Controller Class Initialized
INFO - 2017-01-25 10:19:45 --> Database Driver Class Initialized
INFO - 2017-01-25 10:19:45 --> Model Class Initialized
INFO - 2017-01-25 10:19:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:19:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:19:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:19:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:19:45 --> Final output sent to browser
DEBUG - 2017-01-25 10:19:45 --> Total execution time: 0.1100
INFO - 2017-01-25 10:20:17 --> Config Class Initialized
INFO - 2017-01-25 10:20:17 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:20:17 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:20:17 --> Utf8 Class Initialized
INFO - 2017-01-25 10:20:17 --> URI Class Initialized
INFO - 2017-01-25 10:20:17 --> Router Class Initialized
INFO - 2017-01-25 10:20:17 --> Output Class Initialized
INFO - 2017-01-25 10:20:17 --> Security Class Initialized
DEBUG - 2017-01-25 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:20:17 --> Input Class Initialized
INFO - 2017-01-25 10:20:17 --> Language Class Initialized
INFO - 2017-01-25 10:20:17 --> Loader Class Initialized
INFO - 2017-01-25 10:20:17 --> Helper loaded: url_helper
INFO - 2017-01-25 10:20:17 --> Helper loaded: language_helper
INFO - 2017-01-25 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:20:17 --> Controller Class Initialized
INFO - 2017-01-25 10:20:17 --> Database Driver Class Initialized
INFO - 2017-01-25 10:20:17 --> Model Class Initialized
INFO - 2017-01-25 10:20:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:20:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:20:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:20:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:20:17 --> Final output sent to browser
DEBUG - 2017-01-25 10:20:17 --> Total execution time: 0.1419
INFO - 2017-01-25 10:21:02 --> Config Class Initialized
INFO - 2017-01-25 10:21:02 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:21:02 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:21:02 --> Utf8 Class Initialized
INFO - 2017-01-25 10:21:02 --> URI Class Initialized
INFO - 2017-01-25 10:21:02 --> Router Class Initialized
INFO - 2017-01-25 10:21:02 --> Output Class Initialized
INFO - 2017-01-25 10:21:02 --> Security Class Initialized
DEBUG - 2017-01-25 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:21:02 --> Input Class Initialized
INFO - 2017-01-25 10:21:02 --> Language Class Initialized
INFO - 2017-01-25 10:21:02 --> Loader Class Initialized
INFO - 2017-01-25 10:21:02 --> Helper loaded: url_helper
INFO - 2017-01-25 10:21:02 --> Helper loaded: language_helper
INFO - 2017-01-25 10:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:21:02 --> Controller Class Initialized
INFO - 2017-01-25 10:21:02 --> Database Driver Class Initialized
INFO - 2017-01-25 10:21:02 --> Model Class Initialized
INFO - 2017-01-25 10:21:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:21:02 --> Final output sent to browser
DEBUG - 2017-01-25 10:21:02 --> Total execution time: 0.1188
INFO - 2017-01-25 10:21:23 --> Config Class Initialized
INFO - 2017-01-25 10:21:23 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:21:23 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:21:23 --> Utf8 Class Initialized
INFO - 2017-01-25 10:21:23 --> URI Class Initialized
INFO - 2017-01-25 10:21:23 --> Router Class Initialized
INFO - 2017-01-25 10:21:23 --> Output Class Initialized
INFO - 2017-01-25 10:21:23 --> Security Class Initialized
DEBUG - 2017-01-25 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:21:23 --> Input Class Initialized
INFO - 2017-01-25 10:21:23 --> Language Class Initialized
INFO - 2017-01-25 10:21:23 --> Loader Class Initialized
INFO - 2017-01-25 10:21:23 --> Helper loaded: url_helper
INFO - 2017-01-25 10:21:23 --> Helper loaded: language_helper
INFO - 2017-01-25 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:21:23 --> Controller Class Initialized
INFO - 2017-01-25 10:21:23 --> Database Driver Class Initialized
INFO - 2017-01-25 10:21:23 --> Model Class Initialized
INFO - 2017-01-25 10:21:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:21:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:21:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:21:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:21:23 --> Final output sent to browser
DEBUG - 2017-01-25 10:21:23 --> Total execution time: 0.0842
INFO - 2017-01-25 10:21:24 --> Config Class Initialized
INFO - 2017-01-25 10:21:24 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:21:24 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:21:24 --> Utf8 Class Initialized
INFO - 2017-01-25 10:21:24 --> URI Class Initialized
INFO - 2017-01-25 10:21:24 --> Router Class Initialized
INFO - 2017-01-25 10:21:24 --> Output Class Initialized
INFO - 2017-01-25 10:21:24 --> Security Class Initialized
DEBUG - 2017-01-25 10:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:21:24 --> Input Class Initialized
INFO - 2017-01-25 10:21:24 --> Language Class Initialized
INFO - 2017-01-25 10:21:24 --> Loader Class Initialized
INFO - 2017-01-25 10:21:24 --> Helper loaded: url_helper
INFO - 2017-01-25 10:21:24 --> Helper loaded: language_helper
INFO - 2017-01-25 10:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:21:24 --> Controller Class Initialized
INFO - 2017-01-25 10:21:24 --> Database Driver Class Initialized
INFO - 2017-01-25 10:21:24 --> Model Class Initialized
INFO - 2017-01-25 10:21:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:21:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:21:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:21:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:21:24 --> Final output sent to browser
DEBUG - 2017-01-25 10:21:24 --> Total execution time: 0.1230
INFO - 2017-01-25 10:21:59 --> Config Class Initialized
INFO - 2017-01-25 10:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:21:59 --> Utf8 Class Initialized
INFO - 2017-01-25 10:21:59 --> URI Class Initialized
INFO - 2017-01-25 10:21:59 --> Router Class Initialized
INFO - 2017-01-25 10:21:59 --> Output Class Initialized
INFO - 2017-01-25 10:21:59 --> Security Class Initialized
DEBUG - 2017-01-25 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:21:59 --> Input Class Initialized
INFO - 2017-01-25 10:21:59 --> Language Class Initialized
INFO - 2017-01-25 10:21:59 --> Loader Class Initialized
INFO - 2017-01-25 10:21:59 --> Helper loaded: url_helper
INFO - 2017-01-25 10:21:59 --> Helper loaded: language_helper
INFO - 2017-01-25 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:21:59 --> Controller Class Initialized
INFO - 2017-01-25 10:21:59 --> Database Driver Class Initialized
INFO - 2017-01-25 10:21:59 --> Model Class Initialized
INFO - 2017-01-25 10:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:21:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:21:59 --> Final output sent to browser
DEBUG - 2017-01-25 10:21:59 --> Total execution time: 0.1362
INFO - 2017-01-25 10:24:03 --> Config Class Initialized
INFO - 2017-01-25 10:24:03 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:24:03 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:24:03 --> Utf8 Class Initialized
INFO - 2017-01-25 10:24:03 --> URI Class Initialized
INFO - 2017-01-25 10:24:03 --> Router Class Initialized
INFO - 2017-01-25 10:24:03 --> Output Class Initialized
INFO - 2017-01-25 10:24:03 --> Security Class Initialized
DEBUG - 2017-01-25 10:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:24:03 --> Input Class Initialized
INFO - 2017-01-25 10:24:03 --> Language Class Initialized
INFO - 2017-01-25 10:24:03 --> Loader Class Initialized
INFO - 2017-01-25 10:24:03 --> Helper loaded: url_helper
INFO - 2017-01-25 10:24:03 --> Helper loaded: language_helper
INFO - 2017-01-25 10:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:24:03 --> Controller Class Initialized
INFO - 2017-01-25 10:24:03 --> Database Driver Class Initialized
INFO - 2017-01-25 10:24:03 --> Model Class Initialized
INFO - 2017-01-25 10:24:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:24:03 --> Final output sent to browser
DEBUG - 2017-01-25 10:24:03 --> Total execution time: 0.0954
INFO - 2017-01-25 10:24:30 --> Config Class Initialized
INFO - 2017-01-25 10:24:30 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:24:30 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:24:30 --> Utf8 Class Initialized
INFO - 2017-01-25 10:24:30 --> URI Class Initialized
INFO - 2017-01-25 10:24:30 --> Router Class Initialized
INFO - 2017-01-25 10:24:30 --> Output Class Initialized
INFO - 2017-01-25 10:24:30 --> Security Class Initialized
DEBUG - 2017-01-25 10:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:24:30 --> Input Class Initialized
INFO - 2017-01-25 10:24:30 --> Language Class Initialized
INFO - 2017-01-25 10:24:30 --> Loader Class Initialized
INFO - 2017-01-25 10:24:30 --> Helper loaded: url_helper
INFO - 2017-01-25 10:24:30 --> Helper loaded: language_helper
INFO - 2017-01-25 10:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:24:30 --> Controller Class Initialized
INFO - 2017-01-25 10:24:30 --> Database Driver Class Initialized
INFO - 2017-01-25 10:24:31 --> Model Class Initialized
INFO - 2017-01-25 10:24:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:24:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:24:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:24:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:24:31 --> Final output sent to browser
DEBUG - 2017-01-25 10:24:31 --> Total execution time: 1.1141
INFO - 2017-01-25 10:24:34 --> Config Class Initialized
INFO - 2017-01-25 10:24:34 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:24:34 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:24:34 --> Utf8 Class Initialized
INFO - 2017-01-25 10:24:34 --> URI Class Initialized
INFO - 2017-01-25 10:24:34 --> Router Class Initialized
INFO - 2017-01-25 10:24:34 --> Output Class Initialized
INFO - 2017-01-25 10:24:34 --> Security Class Initialized
DEBUG - 2017-01-25 10:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:24:34 --> Input Class Initialized
INFO - 2017-01-25 10:24:34 --> Language Class Initialized
INFO - 2017-01-25 10:24:34 --> Loader Class Initialized
INFO - 2017-01-25 10:24:34 --> Helper loaded: url_helper
INFO - 2017-01-25 10:24:34 --> Helper loaded: language_helper
INFO - 2017-01-25 10:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:24:34 --> Controller Class Initialized
INFO - 2017-01-25 10:24:34 --> Database Driver Class Initialized
INFO - 2017-01-25 10:24:34 --> Model Class Initialized
INFO - 2017-01-25 10:24:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:24:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:24:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:24:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:24:34 --> Final output sent to browser
DEBUG - 2017-01-25 10:24:34 --> Total execution time: 0.1070
INFO - 2017-01-25 10:25:48 --> Config Class Initialized
INFO - 2017-01-25 10:25:48 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:25:48 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:25:48 --> Utf8 Class Initialized
INFO - 2017-01-25 10:25:48 --> URI Class Initialized
INFO - 2017-01-25 10:25:48 --> Router Class Initialized
INFO - 2017-01-25 10:25:48 --> Output Class Initialized
INFO - 2017-01-25 10:25:48 --> Security Class Initialized
DEBUG - 2017-01-25 10:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:25:48 --> Input Class Initialized
INFO - 2017-01-25 10:25:48 --> Language Class Initialized
INFO - 2017-01-25 10:25:48 --> Loader Class Initialized
INFO - 2017-01-25 10:25:48 --> Helper loaded: url_helper
INFO - 2017-01-25 10:25:48 --> Helper loaded: language_helper
INFO - 2017-01-25 10:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:25:48 --> Controller Class Initialized
INFO - 2017-01-25 10:25:48 --> Database Driver Class Initialized
INFO - 2017-01-25 10:25:48 --> Model Class Initialized
INFO - 2017-01-25 10:25:48 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-01-25 10:25:48 --> Severity: Notice --> Undefined property: Reset::$reset_model C:\wamp64\www\savsoftquiz\application\controllers\Reset.php 45
ERROR - 2017-01-25 10:25:48 --> Severity: Error --> Call to a member function reset() on null C:\wamp64\www\savsoftquiz\application\controllers\Reset.php 45
INFO - 2017-01-25 10:26:12 --> Config Class Initialized
INFO - 2017-01-25 10:26:12 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:26:12 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:26:12 --> Utf8 Class Initialized
INFO - 2017-01-25 10:26:12 --> URI Class Initialized
INFO - 2017-01-25 10:26:12 --> Router Class Initialized
INFO - 2017-01-25 10:26:12 --> Output Class Initialized
INFO - 2017-01-25 10:26:12 --> Security Class Initialized
DEBUG - 2017-01-25 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:26:12 --> Input Class Initialized
INFO - 2017-01-25 10:26:12 --> Language Class Initialized
INFO - 2017-01-25 10:26:12 --> Loader Class Initialized
INFO - 2017-01-25 10:26:12 --> Helper loaded: url_helper
INFO - 2017-01-25 10:26:12 --> Helper loaded: language_helper
INFO - 2017-01-25 10:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:26:12 --> Controller Class Initialized
INFO - 2017-01-25 10:26:12 --> Database Driver Class Initialized
INFO - 2017-01-25 10:26:12 --> Model Class Initialized
INFO - 2017-01-25 10:26:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:26:13 --> Config Class Initialized
INFO - 2017-01-25 10:26:13 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:26:13 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:26:13 --> Utf8 Class Initialized
INFO - 2017-01-25 10:26:13 --> URI Class Initialized
INFO - 2017-01-25 10:26:13 --> Router Class Initialized
INFO - 2017-01-25 10:26:13 --> Output Class Initialized
INFO - 2017-01-25 10:26:13 --> Security Class Initialized
DEBUG - 2017-01-25 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:26:13 --> Input Class Initialized
INFO - 2017-01-25 10:26:13 --> Language Class Initialized
INFO - 2017-01-25 10:26:13 --> Loader Class Initialized
INFO - 2017-01-25 10:26:13 --> Helper loaded: url_helper
INFO - 2017-01-25 10:26:13 --> Helper loaded: language_helper
INFO - 2017-01-25 10:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:26:13 --> Controller Class Initialized
INFO - 2017-01-25 10:26:13 --> Database Driver Class Initialized
INFO - 2017-01-25 10:26:13 --> Model Class Initialized
INFO - 2017-01-25 10:26:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:26:13 --> Final output sent to browser
DEBUG - 2017-01-25 10:26:13 --> Total execution time: 0.0914
INFO - 2017-01-25 10:26:16 --> Config Class Initialized
INFO - 2017-01-25 10:26:16 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:26:16 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:26:16 --> Utf8 Class Initialized
INFO - 2017-01-25 10:26:16 --> URI Class Initialized
INFO - 2017-01-25 10:26:16 --> Router Class Initialized
INFO - 2017-01-25 10:26:16 --> Output Class Initialized
INFO - 2017-01-25 10:26:16 --> Security Class Initialized
DEBUG - 2017-01-25 10:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:26:16 --> Input Class Initialized
INFO - 2017-01-25 10:26:16 --> Language Class Initialized
INFO - 2017-01-25 10:26:16 --> Loader Class Initialized
INFO - 2017-01-25 10:26:16 --> Helper loaded: url_helper
INFO - 2017-01-25 10:26:16 --> Helper loaded: language_helper
INFO - 2017-01-25 10:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:26:16 --> Controller Class Initialized
INFO - 2017-01-25 10:26:16 --> Database Driver Class Initialized
INFO - 2017-01-25 10:26:16 --> Model Class Initialized
INFO - 2017-01-25 10:26:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:26:16 --> Config Class Initialized
INFO - 2017-01-25 10:26:16 --> Hooks Class Initialized
DEBUG - 2017-01-25 10:26:16 --> UTF-8 Support Enabled
INFO - 2017-01-25 10:26:16 --> Utf8 Class Initialized
INFO - 2017-01-25 10:26:16 --> URI Class Initialized
INFO - 2017-01-25 10:26:16 --> Router Class Initialized
INFO - 2017-01-25 10:26:16 --> Output Class Initialized
INFO - 2017-01-25 10:26:16 --> Security Class Initialized
DEBUG - 2017-01-25 10:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 10:26:16 --> Input Class Initialized
INFO - 2017-01-25 10:26:16 --> Language Class Initialized
INFO - 2017-01-25 10:26:16 --> Loader Class Initialized
INFO - 2017-01-25 10:26:16 --> Helper loaded: url_helper
INFO - 2017-01-25 10:26:16 --> Helper loaded: language_helper
INFO - 2017-01-25 10:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 10:26:16 --> Controller Class Initialized
INFO - 2017-01-25 10:26:16 --> Database Driver Class Initialized
INFO - 2017-01-25 10:26:16 --> Model Class Initialized
INFO - 2017-01-25 10:26:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 10:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-25 10:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\reset.php
INFO - 2017-01-25 10:26:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-25 10:26:16 --> Final output sent to browser
DEBUG - 2017-01-25 10:26:16 --> Total execution time: 0.0717
INFO - 2017-01-25 13:44:51 --> Config Class Initialized
INFO - 2017-01-25 13:44:51 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:44:51 --> UTF-8 Support Enabled
INFO - 2017-01-25 13:44:51 --> Utf8 Class Initialized
INFO - 2017-01-25 13:44:51 --> URI Class Initialized
INFO - 2017-01-25 13:44:51 --> Router Class Initialized
INFO - 2017-01-25 13:44:51 --> Output Class Initialized
INFO - 2017-01-25 13:44:51 --> Security Class Initialized
DEBUG - 2017-01-25 13:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 13:44:51 --> Input Class Initialized
INFO - 2017-01-25 13:44:51 --> Language Class Initialized
INFO - 2017-01-25 13:44:51 --> Loader Class Initialized
INFO - 2017-01-25 13:44:51 --> Helper loaded: url_helper
INFO - 2017-01-25 13:44:51 --> Helper loaded: language_helper
INFO - 2017-01-25 13:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 13:44:51 --> Controller Class Initialized
INFO - 2017-01-25 13:44:51 --> Database Driver Class Initialized
INFO - 2017-01-25 13:44:51 --> Model Class Initialized
INFO - 2017-01-25 13:44:51 --> Model Class Initialized
INFO - 2017-01-25 13:44:51 --> Model Class Initialized
INFO - 2017-01-25 13:44:51 --> Model Class Initialized
INFO - 2017-01-25 13:44:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 13:44:51 --> Config Class Initialized
INFO - 2017-01-25 13:44:51 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:44:51 --> UTF-8 Support Enabled
INFO - 2017-01-25 13:44:51 --> Utf8 Class Initialized
INFO - 2017-01-25 13:44:51 --> URI Class Initialized
INFO - 2017-01-25 13:44:51 --> Router Class Initialized
INFO - 2017-01-25 13:44:51 --> Output Class Initialized
INFO - 2017-01-25 13:44:51 --> Security Class Initialized
DEBUG - 2017-01-25 13:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-25 13:44:51 --> Input Class Initialized
INFO - 2017-01-25 13:44:51 --> Language Class Initialized
INFO - 2017-01-25 13:44:51 --> Loader Class Initialized
INFO - 2017-01-25 13:44:51 --> Helper loaded: url_helper
INFO - 2017-01-25 13:44:51 --> Helper loaded: language_helper
INFO - 2017-01-25 13:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-25 13:44:51 --> Controller Class Initialized
INFO - 2017-01-25 13:44:51 --> Database Driver Class Initialized
INFO - 2017-01-25 13:44:51 --> Model Class Initialized
INFO - 2017-01-25 13:44:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-25 13:44:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-25 13:44:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-25 13:44:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-25 13:44:51 --> Final output sent to browser
DEBUG - 2017-01-25 13:44:51 --> Total execution time: 0.0639
