<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-26 08:25:10 --> Config Class Initialized
INFO - 2017-01-26 08:25:10 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:25:10 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:25:10 --> Utf8 Class Initialized
INFO - 2017-01-26 08:25:10 --> URI Class Initialized
DEBUG - 2017-01-26 08:25:10 --> No URI present. Default controller set.
INFO - 2017-01-26 08:25:10 --> Router Class Initialized
INFO - 2017-01-26 08:25:10 --> Output Class Initialized
INFO - 2017-01-26 08:25:10 --> Security Class Initialized
DEBUG - 2017-01-26 08:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:25:10 --> Input Class Initialized
INFO - 2017-01-26 08:25:10 --> Language Class Initialized
INFO - 2017-01-26 08:25:10 --> Loader Class Initialized
INFO - 2017-01-26 08:25:10 --> Helper loaded: url_helper
INFO - 2017-01-26 08:25:10 --> Helper loaded: language_helper
INFO - 2017-01-26 08:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:25:10 --> Controller Class Initialized
INFO - 2017-01-26 08:25:10 --> Database Driver Class Initialized
INFO - 2017-01-26 08:25:10 --> Model Class Initialized
INFO - 2017-01-26 08:25:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 08:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-26 08:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-26 08:25:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-26 08:25:10 --> Final output sent to browser
DEBUG - 2017-01-26 08:25:10 --> Total execution time: 0.0948
INFO - 2017-01-26 08:25:11 --> Config Class Initialized
INFO - 2017-01-26 08:25:11 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:25:11 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:25:11 --> Utf8 Class Initialized
INFO - 2017-01-26 08:25:11 --> URI Class Initialized
INFO - 2017-01-26 08:25:11 --> Router Class Initialized
INFO - 2017-01-26 08:25:11 --> Output Class Initialized
INFO - 2017-01-26 08:25:11 --> Security Class Initialized
DEBUG - 2017-01-26 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:25:11 --> Input Class Initialized
INFO - 2017-01-26 08:25:11 --> Language Class Initialized
INFO - 2017-01-26 08:25:11 --> Loader Class Initialized
INFO - 2017-01-26 08:25:11 --> Helper loaded: url_helper
INFO - 2017-01-26 08:25:11 --> Helper loaded: language_helper
INFO - 2017-01-26 08:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:25:11 --> Controller Class Initialized
DEBUG - 2017-01-26 08:25:11 --> Excel class already loaded. Second attempt ignored.
INFO - 2017-01-26 08:25:11 --> Final output sent to browser
DEBUG - 2017-01-26 08:25:11 --> Total execution time: 0.0497
INFO - 2017-01-26 08:29:14 --> Config Class Initialized
INFO - 2017-01-26 08:29:14 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:29:14 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:29:14 --> Utf8 Class Initialized
INFO - 2017-01-26 08:29:14 --> URI Class Initialized
INFO - 2017-01-26 08:29:14 --> Router Class Initialized
INFO - 2017-01-26 08:29:14 --> Output Class Initialized
INFO - 2017-01-26 08:29:14 --> Security Class Initialized
DEBUG - 2017-01-26 08:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:29:14 --> Input Class Initialized
INFO - 2017-01-26 08:29:14 --> Language Class Initialized
INFO - 2017-01-26 08:29:14 --> Loader Class Initialized
INFO - 2017-01-26 08:29:14 --> Helper loaded: url_helper
INFO - 2017-01-26 08:29:14 --> Helper loaded: language_helper
INFO - 2017-01-26 08:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:29:14 --> Controller Class Initialized
DEBUG - 2017-01-26 08:29:14 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:29:14 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:29:14 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:32:35 --> Config Class Initialized
INFO - 2017-01-26 08:32:35 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:32:35 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:32:35 --> Utf8 Class Initialized
INFO - 2017-01-26 08:32:35 --> URI Class Initialized
INFO - 2017-01-26 08:32:35 --> Router Class Initialized
INFO - 2017-01-26 08:32:35 --> Output Class Initialized
INFO - 2017-01-26 08:32:35 --> Security Class Initialized
DEBUG - 2017-01-26 08:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:32:35 --> Input Class Initialized
INFO - 2017-01-26 08:32:35 --> Language Class Initialized
INFO - 2017-01-26 08:32:35 --> Loader Class Initialized
INFO - 2017-01-26 08:32:35 --> Helper loaded: url_helper
INFO - 2017-01-26 08:32:35 --> Helper loaded: language_helper
INFO - 2017-01-26 08:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:32:35 --> Controller Class Initialized
DEBUG - 2017-01-26 08:32:35 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:32:35 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:32:35 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:32:48 --> Config Class Initialized
INFO - 2017-01-26 08:32:48 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:32:48 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:32:48 --> Utf8 Class Initialized
INFO - 2017-01-26 08:32:48 --> URI Class Initialized
INFO - 2017-01-26 08:32:48 --> Router Class Initialized
INFO - 2017-01-26 08:32:48 --> Output Class Initialized
INFO - 2017-01-26 08:32:48 --> Security Class Initialized
DEBUG - 2017-01-26 08:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:32:48 --> Input Class Initialized
INFO - 2017-01-26 08:32:48 --> Language Class Initialized
INFO - 2017-01-26 08:32:48 --> Loader Class Initialized
INFO - 2017-01-26 08:32:48 --> Helper loaded: url_helper
INFO - 2017-01-26 08:32:48 --> Helper loaded: language_helper
INFO - 2017-01-26 08:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:32:48 --> Controller Class Initialized
DEBUG - 2017-01-26 08:32:48 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:32:48 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:32:48 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:36:06 --> Config Class Initialized
INFO - 2017-01-26 08:36:06 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:36:06 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:36:06 --> Utf8 Class Initialized
INFO - 2017-01-26 08:36:06 --> URI Class Initialized
INFO - 2017-01-26 08:36:06 --> Router Class Initialized
INFO - 2017-01-26 08:36:06 --> Output Class Initialized
INFO - 2017-01-26 08:36:06 --> Security Class Initialized
DEBUG - 2017-01-26 08:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:36:06 --> Input Class Initialized
INFO - 2017-01-26 08:36:06 --> Language Class Initialized
INFO - 2017-01-26 08:36:06 --> Loader Class Initialized
INFO - 2017-01-26 08:36:06 --> Helper loaded: url_helper
INFO - 2017-01-26 08:36:06 --> Helper loaded: language_helper
INFO - 2017-01-26 08:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:36:06 --> Controller Class Initialized
DEBUG - 2017-01-26 08:36:06 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:36:06 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:36:06 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:36:07 --> Config Class Initialized
INFO - 2017-01-26 08:36:07 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:36:07 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:36:07 --> Utf8 Class Initialized
INFO - 2017-01-26 08:36:07 --> URI Class Initialized
INFO - 2017-01-26 08:36:07 --> Router Class Initialized
INFO - 2017-01-26 08:36:07 --> Output Class Initialized
INFO - 2017-01-26 08:36:07 --> Security Class Initialized
DEBUG - 2017-01-26 08:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:36:07 --> Input Class Initialized
INFO - 2017-01-26 08:36:07 --> Language Class Initialized
INFO - 2017-01-26 08:36:07 --> Loader Class Initialized
INFO - 2017-01-26 08:36:07 --> Helper loaded: url_helper
INFO - 2017-01-26 08:36:07 --> Helper loaded: language_helper
INFO - 2017-01-26 08:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:36:07 --> Controller Class Initialized
DEBUG - 2017-01-26 08:36:07 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:36:07 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:36:07 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:36:07 --> Config Class Initialized
INFO - 2017-01-26 08:36:07 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:36:07 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:36:07 --> Utf8 Class Initialized
INFO - 2017-01-26 08:36:07 --> URI Class Initialized
INFO - 2017-01-26 08:36:07 --> Router Class Initialized
INFO - 2017-01-26 08:36:07 --> Output Class Initialized
INFO - 2017-01-26 08:36:07 --> Security Class Initialized
DEBUG - 2017-01-26 08:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:36:07 --> Input Class Initialized
INFO - 2017-01-26 08:36:07 --> Language Class Initialized
INFO - 2017-01-26 08:36:07 --> Loader Class Initialized
INFO - 2017-01-26 08:36:07 --> Helper loaded: url_helper
INFO - 2017-01-26 08:36:07 --> Helper loaded: language_helper
INFO - 2017-01-26 08:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:36:07 --> Controller Class Initialized
DEBUG - 2017-01-26 08:36:07 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:36:07 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:36:07 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:36:08 --> Config Class Initialized
INFO - 2017-01-26 08:36:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:36:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:36:08 --> Utf8 Class Initialized
INFO - 2017-01-26 08:36:08 --> URI Class Initialized
INFO - 2017-01-26 08:36:08 --> Router Class Initialized
INFO - 2017-01-26 08:36:08 --> Output Class Initialized
INFO - 2017-01-26 08:36:08 --> Security Class Initialized
DEBUG - 2017-01-26 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:36:08 --> Input Class Initialized
INFO - 2017-01-26 08:36:08 --> Language Class Initialized
INFO - 2017-01-26 08:36:08 --> Loader Class Initialized
INFO - 2017-01-26 08:36:08 --> Helper loaded: url_helper
INFO - 2017-01-26 08:36:08 --> Helper loaded: language_helper
INFO - 2017-01-26 08:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:36:08 --> Controller Class Initialized
DEBUG - 2017-01-26 08:36:08 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:36:08 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:36:08 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:36:08 --> Config Class Initialized
INFO - 2017-01-26 08:36:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:36:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:36:08 --> Utf8 Class Initialized
INFO - 2017-01-26 08:36:08 --> URI Class Initialized
INFO - 2017-01-26 08:36:08 --> Router Class Initialized
INFO - 2017-01-26 08:36:08 --> Output Class Initialized
INFO - 2017-01-26 08:36:08 --> Security Class Initialized
DEBUG - 2017-01-26 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:36:08 --> Input Class Initialized
INFO - 2017-01-26 08:36:08 --> Language Class Initialized
INFO - 2017-01-26 08:36:08 --> Loader Class Initialized
INFO - 2017-01-26 08:36:08 --> Helper loaded: url_helper
INFO - 2017-01-26 08:36:08 --> Helper loaded: language_helper
INFO - 2017-01-26 08:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:36:08 --> Controller Class Initialized
DEBUG - 2017-01-26 08:36:08 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:36:08 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:36:08 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:40:39 --> Config Class Initialized
INFO - 2017-01-26 08:40:39 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:40:39 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:40:39 --> Utf8 Class Initialized
INFO - 2017-01-26 08:40:39 --> URI Class Initialized
INFO - 2017-01-26 08:40:39 --> Router Class Initialized
INFO - 2017-01-26 08:40:39 --> Output Class Initialized
INFO - 2017-01-26 08:40:39 --> Security Class Initialized
DEBUG - 2017-01-26 08:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:40:39 --> Input Class Initialized
INFO - 2017-01-26 08:40:39 --> Language Class Initialized
INFO - 2017-01-26 08:40:39 --> Loader Class Initialized
INFO - 2017-01-26 08:40:39 --> Helper loaded: url_helper
INFO - 2017-01-26 08:40:39 --> Helper loaded: language_helper
INFO - 2017-01-26 08:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:40:39 --> Controller Class Initialized
DEBUG - 2017-01-26 08:40:39 --> Excel class already loaded. Second attempt ignored.
ERROR - 2017-01-26 08:40:39 --> Severity: Notice --> Undefined property: Excel::$excel C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
ERROR - 2017-01-26 08:40:39 --> Severity: Error --> Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:41:09 --> Config Class Initialized
INFO - 2017-01-26 08:41:09 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:41:09 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:41:09 --> Utf8 Class Initialized
INFO - 2017-01-26 08:41:09 --> URI Class Initialized
INFO - 2017-01-26 08:41:09 --> Router Class Initialized
INFO - 2017-01-26 08:41:09 --> Output Class Initialized
INFO - 2017-01-26 08:41:09 --> Security Class Initialized
DEBUG - 2017-01-26 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:41:09 --> Input Class Initialized
INFO - 2017-01-26 08:41:09 --> Language Class Initialized
INFO - 2017-01-26 08:41:09 --> Loader Class Initialized
INFO - 2017-01-26 08:41:09 --> Helper loaded: url_helper
INFO - 2017-01-26 08:41:09 --> Helper loaded: language_helper
INFO - 2017-01-26 08:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:41:09 --> Controller Class Initialized
INFO - 2017-01-26 08:41:12 --> Config Class Initialized
INFO - 2017-01-26 08:41:12 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:41:12 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:41:12 --> Utf8 Class Initialized
INFO - 2017-01-26 08:41:12 --> URI Class Initialized
INFO - 2017-01-26 08:41:12 --> Router Class Initialized
INFO - 2017-01-26 08:41:12 --> Output Class Initialized
INFO - 2017-01-26 08:41:12 --> Security Class Initialized
DEBUG - 2017-01-26 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:41:12 --> Input Class Initialized
INFO - 2017-01-26 08:41:12 --> Language Class Initialized
INFO - 2017-01-26 08:41:12 --> Loader Class Initialized
INFO - 2017-01-26 08:41:12 --> Helper loaded: url_helper
INFO - 2017-01-26 08:41:12 --> Helper loaded: language_helper
INFO - 2017-01-26 08:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:41:12 --> Controller Class Initialized
INFO - 2017-01-26 08:41:31 --> Config Class Initialized
INFO - 2017-01-26 08:41:31 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:41:31 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:41:31 --> Utf8 Class Initialized
INFO - 2017-01-26 08:41:31 --> URI Class Initialized
INFO - 2017-01-26 08:41:31 --> Router Class Initialized
INFO - 2017-01-26 08:41:31 --> Output Class Initialized
INFO - 2017-01-26 08:41:31 --> Security Class Initialized
DEBUG - 2017-01-26 08:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:41:31 --> Input Class Initialized
INFO - 2017-01-26 08:41:31 --> Language Class Initialized
INFO - 2017-01-26 08:41:31 --> Loader Class Initialized
INFO - 2017-01-26 08:41:31 --> Helper loaded: url_helper
INFO - 2017-01-26 08:41:31 --> Helper loaded: language_helper
INFO - 2017-01-26 08:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:41:31 --> Controller Class Initialized
INFO - 2017-01-26 08:41:52 --> Config Class Initialized
INFO - 2017-01-26 08:41:52 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:41:52 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:41:52 --> Utf8 Class Initialized
INFO - 2017-01-26 08:41:52 --> URI Class Initialized
INFO - 2017-01-26 08:41:52 --> Router Class Initialized
INFO - 2017-01-26 08:41:52 --> Output Class Initialized
INFO - 2017-01-26 08:41:52 --> Security Class Initialized
DEBUG - 2017-01-26 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:41:52 --> Input Class Initialized
INFO - 2017-01-26 08:41:52 --> Language Class Initialized
INFO - 2017-01-26 08:41:52 --> Loader Class Initialized
INFO - 2017-01-26 08:41:52 --> Helper loaded: url_helper
INFO - 2017-01-26 08:41:52 --> Helper loaded: language_helper
INFO - 2017-01-26 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:41:52 --> Controller Class Initialized
INFO - 2017-01-26 08:42:57 --> Config Class Initialized
INFO - 2017-01-26 08:42:57 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:42:57 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:42:57 --> Utf8 Class Initialized
INFO - 2017-01-26 08:42:57 --> URI Class Initialized
INFO - 2017-01-26 08:42:57 --> Router Class Initialized
INFO - 2017-01-26 08:42:57 --> Output Class Initialized
INFO - 2017-01-26 08:42:57 --> Security Class Initialized
DEBUG - 2017-01-26 08:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:42:57 --> Input Class Initialized
INFO - 2017-01-26 08:42:57 --> Language Class Initialized
INFO - 2017-01-26 08:42:57 --> Loader Class Initialized
INFO - 2017-01-26 08:42:57 --> Helper loaded: url_helper
INFO - 2017-01-26 08:42:57 --> Helper loaded: language_helper
INFO - 2017-01-26 08:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:42:57 --> Controller Class Initialized
INFO - 2017-01-26 08:42:57 --> Final output sent to browser
DEBUG - 2017-01-26 08:42:57 --> Total execution time: 0.0465
INFO - 2017-01-26 08:43:09 --> Config Class Initialized
INFO - 2017-01-26 08:43:09 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:43:09 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:43:09 --> Utf8 Class Initialized
INFO - 2017-01-26 08:43:09 --> URI Class Initialized
INFO - 2017-01-26 08:43:09 --> Router Class Initialized
INFO - 2017-01-26 08:43:09 --> Output Class Initialized
INFO - 2017-01-26 08:43:09 --> Security Class Initialized
DEBUG - 2017-01-26 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:43:09 --> Input Class Initialized
INFO - 2017-01-26 08:43:09 --> Language Class Initialized
INFO - 2017-01-26 08:43:09 --> Loader Class Initialized
INFO - 2017-01-26 08:43:09 --> Helper loaded: url_helper
INFO - 2017-01-26 08:43:09 --> Helper loaded: language_helper
INFO - 2017-01-26 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:43:09 --> Controller Class Initialized
INFO - 2017-01-26 08:43:09 --> Final output sent to browser
DEBUG - 2017-01-26 08:43:09 --> Total execution time: 0.0458
INFO - 2017-01-26 08:43:19 --> Config Class Initialized
INFO - 2017-01-26 08:43:19 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:43:19 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:43:19 --> Utf8 Class Initialized
INFO - 2017-01-26 08:43:19 --> URI Class Initialized
INFO - 2017-01-26 08:43:19 --> Router Class Initialized
INFO - 2017-01-26 08:43:19 --> Output Class Initialized
INFO - 2017-01-26 08:43:19 --> Security Class Initialized
DEBUG - 2017-01-26 08:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:43:19 --> Input Class Initialized
INFO - 2017-01-26 08:43:19 --> Language Class Initialized
INFO - 2017-01-26 08:43:19 --> Loader Class Initialized
INFO - 2017-01-26 08:43:19 --> Helper loaded: url_helper
INFO - 2017-01-26 08:43:19 --> Helper loaded: language_helper
INFO - 2017-01-26 08:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:43:19 --> Controller Class Initialized
INFO - 2017-01-26 08:43:19 --> Final output sent to browser
DEBUG - 2017-01-26 08:43:19 --> Total execution time: 0.1044
INFO - 2017-01-26 08:43:25 --> Config Class Initialized
INFO - 2017-01-26 08:43:25 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:43:25 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:43:25 --> Utf8 Class Initialized
INFO - 2017-01-26 08:43:25 --> URI Class Initialized
INFO - 2017-01-26 08:43:25 --> Router Class Initialized
INFO - 2017-01-26 08:43:25 --> Output Class Initialized
INFO - 2017-01-26 08:43:25 --> Security Class Initialized
DEBUG - 2017-01-26 08:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:43:25 --> Input Class Initialized
INFO - 2017-01-26 08:43:25 --> Language Class Initialized
INFO - 2017-01-26 08:43:25 --> Loader Class Initialized
INFO - 2017-01-26 08:43:25 --> Helper loaded: url_helper
INFO - 2017-01-26 08:43:25 --> Helper loaded: language_helper
INFO - 2017-01-26 08:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:43:25 --> Controller Class Initialized
INFO - 2017-01-26 08:43:26 --> Final output sent to browser
DEBUG - 2017-01-26 08:43:26 --> Total execution time: 0.1053
INFO - 2017-01-26 08:43:36 --> Config Class Initialized
INFO - 2017-01-26 08:43:36 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:43:36 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:43:36 --> Utf8 Class Initialized
INFO - 2017-01-26 08:43:36 --> URI Class Initialized
INFO - 2017-01-26 08:43:36 --> Router Class Initialized
INFO - 2017-01-26 08:43:36 --> Output Class Initialized
INFO - 2017-01-26 08:43:36 --> Security Class Initialized
DEBUG - 2017-01-26 08:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:43:36 --> Input Class Initialized
INFO - 2017-01-26 08:43:36 --> Language Class Initialized
INFO - 2017-01-26 08:43:36 --> Loader Class Initialized
INFO - 2017-01-26 08:43:36 --> Helper loaded: url_helper
INFO - 2017-01-26 08:43:36 --> Helper loaded: language_helper
INFO - 2017-01-26 08:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:43:36 --> Controller Class Initialized
INFO - 2017-01-26 08:45:27 --> Config Class Initialized
INFO - 2017-01-26 08:45:27 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:45:27 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:45:27 --> Utf8 Class Initialized
INFO - 2017-01-26 08:45:27 --> URI Class Initialized
DEBUG - 2017-01-26 08:45:27 --> No URI present. Default controller set.
INFO - 2017-01-26 08:45:27 --> Router Class Initialized
INFO - 2017-01-26 08:45:27 --> Output Class Initialized
INFO - 2017-01-26 08:45:27 --> Security Class Initialized
DEBUG - 2017-01-26 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:45:27 --> Input Class Initialized
INFO - 2017-01-26 08:45:27 --> Language Class Initialized
INFO - 2017-01-26 08:45:27 --> Loader Class Initialized
INFO - 2017-01-26 08:45:27 --> Helper loaded: url_helper
INFO - 2017-01-26 08:45:27 --> Helper loaded: language_helper
INFO - 2017-01-26 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:45:27 --> Controller Class Initialized
INFO - 2017-01-26 08:45:27 --> Database Driver Class Initialized
INFO - 2017-01-26 08:45:27 --> Model Class Initialized
INFO - 2017-01-26 08:45:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 08:45:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-26 08:45:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-26 08:45:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-26 08:45:27 --> Final output sent to browser
DEBUG - 2017-01-26 08:45:27 --> Total execution time: 0.0613
INFO - 2017-01-26 08:45:34 --> Config Class Initialized
INFO - 2017-01-26 08:45:34 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:45:34 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:45:34 --> Utf8 Class Initialized
INFO - 2017-01-26 08:45:34 --> URI Class Initialized
INFO - 2017-01-26 08:45:34 --> Router Class Initialized
INFO - 2017-01-26 08:45:34 --> Output Class Initialized
INFO - 2017-01-26 08:45:34 --> Security Class Initialized
DEBUG - 2017-01-26 08:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:45:34 --> Input Class Initialized
INFO - 2017-01-26 08:45:34 --> Language Class Initialized
INFO - 2017-01-26 08:45:34 --> Loader Class Initialized
INFO - 2017-01-26 08:45:34 --> Helper loaded: url_helper
INFO - 2017-01-26 08:45:34 --> Helper loaded: language_helper
INFO - 2017-01-26 08:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:45:34 --> Controller Class Initialized
INFO - 2017-01-26 08:45:34 --> Database Driver Class Initialized
INFO - 2017-01-26 08:45:34 --> Model Class Initialized
INFO - 2017-01-26 08:45:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 08:45:34 --> Config Class Initialized
INFO - 2017-01-26 08:45:34 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:45:34 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:45:34 --> Utf8 Class Initialized
INFO - 2017-01-26 08:45:34 --> URI Class Initialized
INFO - 2017-01-26 08:45:34 --> Router Class Initialized
INFO - 2017-01-26 08:45:34 --> Output Class Initialized
INFO - 2017-01-26 08:45:34 --> Security Class Initialized
DEBUG - 2017-01-26 08:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:45:34 --> Input Class Initialized
INFO - 2017-01-26 08:45:34 --> Language Class Initialized
INFO - 2017-01-26 08:45:34 --> Loader Class Initialized
INFO - 2017-01-26 08:45:34 --> Helper loaded: url_helper
INFO - 2017-01-26 08:45:34 --> Helper loaded: language_helper
INFO - 2017-01-26 08:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:45:34 --> Controller Class Initialized
INFO - 2017-01-26 08:45:34 --> Database Driver Class Initialized
INFO - 2017-01-26 08:45:34 --> Model Class Initialized
INFO - 2017-01-26 08:45:34 --> Model Class Initialized
INFO - 2017-01-26 08:45:34 --> Model Class Initialized
INFO - 2017-01-26 08:45:34 --> Model Class Initialized
INFO - 2017-01-26 08:45:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 08:45:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-26 08:45:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-26 08:45:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-26 08:45:34 --> Final output sent to browser
DEBUG - 2017-01-26 08:45:34 --> Total execution time: 0.1066
INFO - 2017-01-26 08:45:39 --> Config Class Initialized
INFO - 2017-01-26 08:45:39 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:45:39 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:45:39 --> Utf8 Class Initialized
INFO - 2017-01-26 08:45:39 --> URI Class Initialized
INFO - 2017-01-26 08:45:39 --> Router Class Initialized
INFO - 2017-01-26 08:45:39 --> Output Class Initialized
INFO - 2017-01-26 08:45:39 --> Security Class Initialized
DEBUG - 2017-01-26 08:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:45:39 --> Input Class Initialized
INFO - 2017-01-26 08:45:39 --> Language Class Initialized
INFO - 2017-01-26 08:45:39 --> Loader Class Initialized
INFO - 2017-01-26 08:45:39 --> Helper loaded: url_helper
INFO - 2017-01-26 08:45:39 --> Helper loaded: language_helper
INFO - 2017-01-26 08:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:45:39 --> Controller Class Initialized
INFO - 2017-01-26 08:45:39 --> Final output sent to browser
DEBUG - 2017-01-26 08:45:39 --> Total execution time: 0.1013
INFO - 2017-01-26 08:45:53 --> Config Class Initialized
INFO - 2017-01-26 08:45:53 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:45:53 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:45:53 --> Utf8 Class Initialized
INFO - 2017-01-26 08:45:53 --> URI Class Initialized
INFO - 2017-01-26 08:45:53 --> Router Class Initialized
INFO - 2017-01-26 08:45:53 --> Output Class Initialized
INFO - 2017-01-26 08:45:53 --> Security Class Initialized
DEBUG - 2017-01-26 08:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:45:53 --> Input Class Initialized
INFO - 2017-01-26 08:45:53 --> Language Class Initialized
INFO - 2017-01-26 08:45:53 --> Loader Class Initialized
INFO - 2017-01-26 08:45:53 --> Helper loaded: url_helper
INFO - 2017-01-26 08:45:53 --> Helper loaded: language_helper
INFO - 2017-01-26 08:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:45:53 --> Controller Class Initialized
INFO - 2017-01-26 08:46:03 --> Config Class Initialized
INFO - 2017-01-26 08:46:03 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:03 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:03 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:03 --> URI Class Initialized
INFO - 2017-01-26 08:46:03 --> Router Class Initialized
INFO - 2017-01-26 08:46:03 --> Output Class Initialized
INFO - 2017-01-26 08:46:03 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:03 --> Input Class Initialized
INFO - 2017-01-26 08:46:03 --> Language Class Initialized
INFO - 2017-01-26 08:46:03 --> Loader Class Initialized
INFO - 2017-01-26 08:46:03 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:03 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:03 --> Controller Class Initialized
INFO - 2017-01-26 08:46:36 --> Config Class Initialized
INFO - 2017-01-26 08:46:36 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:36 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:36 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:36 --> URI Class Initialized
INFO - 2017-01-26 08:46:36 --> Router Class Initialized
INFO - 2017-01-26 08:46:36 --> Output Class Initialized
INFO - 2017-01-26 08:46:36 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:36 --> Input Class Initialized
INFO - 2017-01-26 08:46:36 --> Language Class Initialized
INFO - 2017-01-26 08:46:36 --> Loader Class Initialized
INFO - 2017-01-26 08:46:36 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:36 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:36 --> Controller Class Initialized
INFO - 2017-01-26 08:46:37 --> Config Class Initialized
INFO - 2017-01-26 08:46:37 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:37 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:37 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:37 --> URI Class Initialized
INFO - 2017-01-26 08:46:37 --> Router Class Initialized
INFO - 2017-01-26 08:46:37 --> Output Class Initialized
INFO - 2017-01-26 08:46:37 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:37 --> Input Class Initialized
INFO - 2017-01-26 08:46:37 --> Language Class Initialized
INFO - 2017-01-26 08:46:37 --> Loader Class Initialized
INFO - 2017-01-26 08:46:37 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:37 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:37 --> Controller Class Initialized
INFO - 2017-01-26 08:46:38 --> Config Class Initialized
INFO - 2017-01-26 08:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:38 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:38 --> URI Class Initialized
INFO - 2017-01-26 08:46:38 --> Router Class Initialized
INFO - 2017-01-26 08:46:38 --> Output Class Initialized
INFO - 2017-01-26 08:46:38 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:38 --> Input Class Initialized
INFO - 2017-01-26 08:46:38 --> Language Class Initialized
INFO - 2017-01-26 08:46:38 --> Loader Class Initialized
INFO - 2017-01-26 08:46:38 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:38 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:38 --> Controller Class Initialized
INFO - 2017-01-26 08:46:38 --> Config Class Initialized
INFO - 2017-01-26 08:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:38 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:38 --> URI Class Initialized
INFO - 2017-01-26 08:46:38 --> Router Class Initialized
INFO - 2017-01-26 08:46:38 --> Output Class Initialized
INFO - 2017-01-26 08:46:38 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:38 --> Input Class Initialized
INFO - 2017-01-26 08:46:38 --> Language Class Initialized
INFO - 2017-01-26 08:46:38 --> Loader Class Initialized
INFO - 2017-01-26 08:46:38 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:38 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:38 --> Controller Class Initialized
INFO - 2017-01-26 08:46:38 --> Config Class Initialized
INFO - 2017-01-26 08:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:38 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:38 --> URI Class Initialized
INFO - 2017-01-26 08:46:38 --> Router Class Initialized
INFO - 2017-01-26 08:46:38 --> Output Class Initialized
INFO - 2017-01-26 08:46:38 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:38 --> Input Class Initialized
INFO - 2017-01-26 08:46:38 --> Language Class Initialized
INFO - 2017-01-26 08:46:38 --> Loader Class Initialized
INFO - 2017-01-26 08:46:38 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:38 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:38 --> Controller Class Initialized
INFO - 2017-01-26 08:46:55 --> Config Class Initialized
INFO - 2017-01-26 08:46:55 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:46:55 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:46:55 --> Utf8 Class Initialized
INFO - 2017-01-26 08:46:55 --> URI Class Initialized
INFO - 2017-01-26 08:46:55 --> Router Class Initialized
INFO - 2017-01-26 08:46:55 --> Output Class Initialized
INFO - 2017-01-26 08:46:55 --> Security Class Initialized
DEBUG - 2017-01-26 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:46:55 --> Input Class Initialized
INFO - 2017-01-26 08:46:55 --> Language Class Initialized
INFO - 2017-01-26 08:46:55 --> Loader Class Initialized
INFO - 2017-01-26 08:46:55 --> Helper loaded: url_helper
INFO - 2017-01-26 08:46:55 --> Helper loaded: language_helper
INFO - 2017-01-26 08:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:46:55 --> Controller Class Initialized
INFO - 2017-01-26 08:46:55 --> Final output sent to browser
DEBUG - 2017-01-26 08:46:55 --> Total execution time: 0.1061
INFO - 2017-01-26 08:47:35 --> Config Class Initialized
INFO - 2017-01-26 08:47:35 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:47:35 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:47:35 --> Utf8 Class Initialized
INFO - 2017-01-26 08:47:35 --> URI Class Initialized
INFO - 2017-01-26 08:47:35 --> Router Class Initialized
INFO - 2017-01-26 08:47:35 --> Output Class Initialized
INFO - 2017-01-26 08:47:35 --> Security Class Initialized
DEBUG - 2017-01-26 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:47:35 --> Input Class Initialized
INFO - 2017-01-26 08:47:35 --> Language Class Initialized
INFO - 2017-01-26 08:47:35 --> Loader Class Initialized
INFO - 2017-01-26 08:47:35 --> Helper loaded: url_helper
INFO - 2017-01-26 08:47:35 --> Helper loaded: language_helper
INFO - 2017-01-26 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:47:35 --> Controller Class Initialized
INFO - 2017-01-26 08:47:35 --> Final output sent to browser
DEBUG - 2017-01-26 08:47:35 --> Total execution time: 0.0959
INFO - 2017-01-26 08:47:49 --> Config Class Initialized
INFO - 2017-01-26 08:47:49 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:47:49 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:47:49 --> Utf8 Class Initialized
INFO - 2017-01-26 08:47:49 --> URI Class Initialized
INFO - 2017-01-26 08:47:49 --> Router Class Initialized
INFO - 2017-01-26 08:47:49 --> Output Class Initialized
INFO - 2017-01-26 08:47:49 --> Security Class Initialized
DEBUG - 2017-01-26 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:47:49 --> Input Class Initialized
INFO - 2017-01-26 08:47:49 --> Language Class Initialized
INFO - 2017-01-26 08:47:49 --> Loader Class Initialized
INFO - 2017-01-26 08:47:49 --> Helper loaded: url_helper
INFO - 2017-01-26 08:47:49 --> Helper loaded: language_helper
INFO - 2017-01-26 08:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:47:49 --> Controller Class Initialized
ERROR - 2017-01-26 08:47:49 --> Severity: error --> Exception: Call to a member function setActiveSheetIndex() on null C:\wamp64\www\savsoftquiz\application\controllers\Excel.php 13
INFO - 2017-01-26 08:48:04 --> Config Class Initialized
INFO - 2017-01-26 08:48:04 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:04 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:04 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:04 --> URI Class Initialized
INFO - 2017-01-26 08:48:04 --> Router Class Initialized
INFO - 2017-01-26 08:48:04 --> Output Class Initialized
INFO - 2017-01-26 08:48:04 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:04 --> Input Class Initialized
INFO - 2017-01-26 08:48:04 --> Language Class Initialized
INFO - 2017-01-26 08:48:04 --> Loader Class Initialized
INFO - 2017-01-26 08:48:04 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:04 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:04 --> Controller Class Initialized
INFO - 2017-01-26 08:48:04 --> Final output sent to browser
DEBUG - 2017-01-26 08:48:04 --> Total execution time: 0.0963
INFO - 2017-01-26 08:48:21 --> Config Class Initialized
INFO - 2017-01-26 08:48:21 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:21 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:21 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:21 --> URI Class Initialized
INFO - 2017-01-26 08:48:21 --> Router Class Initialized
INFO - 2017-01-26 08:48:21 --> Output Class Initialized
INFO - 2017-01-26 08:48:21 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:21 --> Input Class Initialized
INFO - 2017-01-26 08:48:21 --> Language Class Initialized
INFO - 2017-01-26 08:48:21 --> Loader Class Initialized
INFO - 2017-01-26 08:48:21 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:21 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:21 --> Controller Class Initialized
INFO - 2017-01-26 08:48:21 --> Final output sent to browser
DEBUG - 2017-01-26 08:48:21 --> Total execution time: 0.1023
INFO - 2017-01-26 08:48:33 --> Config Class Initialized
INFO - 2017-01-26 08:48:33 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:33 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:33 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:33 --> URI Class Initialized
INFO - 2017-01-26 08:48:33 --> Router Class Initialized
INFO - 2017-01-26 08:48:33 --> Output Class Initialized
INFO - 2017-01-26 08:48:33 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:33 --> Input Class Initialized
INFO - 2017-01-26 08:48:33 --> Language Class Initialized
INFO - 2017-01-26 08:48:33 --> Loader Class Initialized
INFO - 2017-01-26 08:48:33 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:33 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:33 --> Controller Class Initialized
ERROR - 2017-01-26 08:48:33 --> Severity: error --> Exception: Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in C:\wamp64\www\savsoftquiz\application\controllers\Excel.php on line 24 C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\IOFactory.php 132
INFO - 2017-01-26 08:48:33 --> Config Class Initialized
INFO - 2017-01-26 08:48:33 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:33 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:33 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:33 --> URI Class Initialized
INFO - 2017-01-26 08:48:33 --> Router Class Initialized
INFO - 2017-01-26 08:48:33 --> Output Class Initialized
INFO - 2017-01-26 08:48:33 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:33 --> Input Class Initialized
INFO - 2017-01-26 08:48:33 --> Language Class Initialized
INFO - 2017-01-26 08:48:33 --> Loader Class Initialized
INFO - 2017-01-26 08:48:33 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:33 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:33 --> Controller Class Initialized
ERROR - 2017-01-26 08:48:34 --> Severity: error --> Exception: Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in C:\wamp64\www\savsoftquiz\application\controllers\Excel.php on line 24 C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\IOFactory.php 132
INFO - 2017-01-26 08:48:39 --> Config Class Initialized
INFO - 2017-01-26 08:48:39 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:39 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:39 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:39 --> URI Class Initialized
INFO - 2017-01-26 08:48:39 --> Router Class Initialized
INFO - 2017-01-26 08:48:39 --> Output Class Initialized
INFO - 2017-01-26 08:48:39 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:39 --> Input Class Initialized
INFO - 2017-01-26 08:48:39 --> Language Class Initialized
INFO - 2017-01-26 08:48:39 --> Loader Class Initialized
INFO - 2017-01-26 08:48:39 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:39 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:39 --> Controller Class Initialized
ERROR - 2017-01-26 08:48:39 --> Severity: error --> Exception: Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in C:\wamp64\www\savsoftquiz\application\controllers\Excel.php on line 24 C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\IOFactory.php 132
INFO - 2017-01-26 08:48:41 --> Config Class Initialized
INFO - 2017-01-26 08:48:41 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:41 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:41 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:41 --> URI Class Initialized
INFO - 2017-01-26 08:48:41 --> Router Class Initialized
INFO - 2017-01-26 08:48:41 --> Output Class Initialized
INFO - 2017-01-26 08:48:41 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:41 --> Input Class Initialized
INFO - 2017-01-26 08:48:41 --> Language Class Initialized
INFO - 2017-01-26 08:48:41 --> Loader Class Initialized
INFO - 2017-01-26 08:48:41 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:41 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:41 --> Controller Class Initialized
ERROR - 2017-01-26 08:48:42 --> Severity: error --> Exception: Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in C:\wamp64\www\savsoftquiz\application\controllers\Excel.php on line 24 C:\wamp64\www\savsoftquiz\application\third_party\PHPExcel\IOFactory.php 132
INFO - 2017-01-26 08:48:56 --> Config Class Initialized
INFO - 2017-01-26 08:48:56 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:56 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:56 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:56 --> URI Class Initialized
INFO - 2017-01-26 08:48:56 --> Router Class Initialized
INFO - 2017-01-26 08:48:56 --> Output Class Initialized
INFO - 2017-01-26 08:48:56 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:56 --> Input Class Initialized
INFO - 2017-01-26 08:48:56 --> Language Class Initialized
INFO - 2017-01-26 08:48:56 --> Loader Class Initialized
INFO - 2017-01-26 08:48:56 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:56 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:56 --> Controller Class Initialized
INFO - 2017-01-26 08:48:57 --> Config Class Initialized
INFO - 2017-01-26 08:48:57 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:48:57 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:48:57 --> Utf8 Class Initialized
INFO - 2017-01-26 08:48:57 --> URI Class Initialized
INFO - 2017-01-26 08:48:57 --> Router Class Initialized
INFO - 2017-01-26 08:48:57 --> Output Class Initialized
INFO - 2017-01-26 08:48:57 --> Security Class Initialized
DEBUG - 2017-01-26 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:48:57 --> Input Class Initialized
INFO - 2017-01-26 08:48:57 --> Language Class Initialized
INFO - 2017-01-26 08:48:57 --> Loader Class Initialized
INFO - 2017-01-26 08:48:57 --> Helper loaded: url_helper
INFO - 2017-01-26 08:48:57 --> Helper loaded: language_helper
INFO - 2017-01-26 08:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:48:57 --> Controller Class Initialized
INFO - 2017-01-26 08:49:06 --> Config Class Initialized
INFO - 2017-01-26 08:49:06 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:49:06 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:49:06 --> Utf8 Class Initialized
INFO - 2017-01-26 08:49:06 --> URI Class Initialized
INFO - 2017-01-26 08:49:06 --> Router Class Initialized
INFO - 2017-01-26 08:49:06 --> Output Class Initialized
INFO - 2017-01-26 08:49:06 --> Security Class Initialized
DEBUG - 2017-01-26 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:49:06 --> Input Class Initialized
INFO - 2017-01-26 08:49:06 --> Language Class Initialized
INFO - 2017-01-26 08:49:06 --> Loader Class Initialized
INFO - 2017-01-26 08:49:06 --> Helper loaded: url_helper
INFO - 2017-01-26 08:49:06 --> Helper loaded: language_helper
INFO - 2017-01-26 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:49:06 --> Controller Class Initialized
INFO - 2017-01-26 08:49:06 --> Final output sent to browser
DEBUG - 2017-01-26 08:49:06 --> Total execution time: 0.1375
INFO - 2017-01-26 08:49:15 --> Config Class Initialized
INFO - 2017-01-26 08:49:15 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:49:15 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:49:15 --> Utf8 Class Initialized
INFO - 2017-01-26 08:49:15 --> URI Class Initialized
INFO - 2017-01-26 08:49:15 --> Router Class Initialized
INFO - 2017-01-26 08:49:15 --> Output Class Initialized
INFO - 2017-01-26 08:49:15 --> Security Class Initialized
DEBUG - 2017-01-26 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:49:15 --> Input Class Initialized
INFO - 2017-01-26 08:49:15 --> Language Class Initialized
INFO - 2017-01-26 08:49:15 --> Loader Class Initialized
INFO - 2017-01-26 08:49:15 --> Helper loaded: url_helper
INFO - 2017-01-26 08:49:15 --> Helper loaded: language_helper
INFO - 2017-01-26 08:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:49:15 --> Controller Class Initialized
INFO - 2017-01-26 08:49:15 --> Final output sent to browser
DEBUG - 2017-01-26 08:49:15 --> Total execution time: 0.1486
INFO - 2017-01-26 08:49:28 --> Config Class Initialized
INFO - 2017-01-26 08:49:28 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:49:28 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:49:28 --> Utf8 Class Initialized
INFO - 2017-01-26 08:49:28 --> URI Class Initialized
INFO - 2017-01-26 08:49:28 --> Router Class Initialized
INFO - 2017-01-26 08:49:28 --> Output Class Initialized
INFO - 2017-01-26 08:49:28 --> Security Class Initialized
DEBUG - 2017-01-26 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:49:28 --> Input Class Initialized
INFO - 2017-01-26 08:49:28 --> Language Class Initialized
INFO - 2017-01-26 08:49:28 --> Loader Class Initialized
INFO - 2017-01-26 08:49:28 --> Helper loaded: url_helper
INFO - 2017-01-26 08:49:28 --> Helper loaded: language_helper
INFO - 2017-01-26 08:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:49:28 --> Controller Class Initialized
INFO - 2017-01-26 08:49:28 --> Final output sent to browser
DEBUG - 2017-01-26 08:49:28 --> Total execution time: 0.1033
INFO - 2017-01-26 08:49:42 --> Config Class Initialized
INFO - 2017-01-26 08:49:42 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:49:42 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:49:42 --> Utf8 Class Initialized
INFO - 2017-01-26 08:49:42 --> URI Class Initialized
INFO - 2017-01-26 08:49:42 --> Router Class Initialized
INFO - 2017-01-26 08:49:42 --> Output Class Initialized
INFO - 2017-01-26 08:49:42 --> Security Class Initialized
DEBUG - 2017-01-26 08:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:49:42 --> Input Class Initialized
INFO - 2017-01-26 08:49:42 --> Language Class Initialized
INFO - 2017-01-26 08:49:42 --> Loader Class Initialized
INFO - 2017-01-26 08:49:42 --> Helper loaded: url_helper
INFO - 2017-01-26 08:49:42 --> Helper loaded: language_helper
INFO - 2017-01-26 08:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:49:42 --> Controller Class Initialized
INFO - 2017-01-26 08:49:42 --> Final output sent to browser
DEBUG - 2017-01-26 08:49:42 --> Total execution time: 0.1031
INFO - 2017-01-26 08:49:54 --> Config Class Initialized
INFO - 2017-01-26 08:49:54 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:49:54 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:49:54 --> Utf8 Class Initialized
INFO - 2017-01-26 08:49:54 --> URI Class Initialized
INFO - 2017-01-26 08:49:54 --> Router Class Initialized
INFO - 2017-01-26 08:49:54 --> Output Class Initialized
INFO - 2017-01-26 08:49:54 --> Security Class Initialized
DEBUG - 2017-01-26 08:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:49:54 --> Input Class Initialized
INFO - 2017-01-26 08:49:54 --> Language Class Initialized
INFO - 2017-01-26 08:49:54 --> Loader Class Initialized
INFO - 2017-01-26 08:49:54 --> Helper loaded: url_helper
INFO - 2017-01-26 08:49:54 --> Helper loaded: language_helper
INFO - 2017-01-26 08:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:49:54 --> Controller Class Initialized
INFO - 2017-01-26 08:49:54 --> Final output sent to browser
DEBUG - 2017-01-26 08:49:54 --> Total execution time: 0.1372
INFO - 2017-01-26 08:50:03 --> Config Class Initialized
INFO - 2017-01-26 08:50:03 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:50:03 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:50:03 --> Utf8 Class Initialized
INFO - 2017-01-26 08:50:03 --> URI Class Initialized
INFO - 2017-01-26 08:50:03 --> Router Class Initialized
INFO - 2017-01-26 08:50:03 --> Output Class Initialized
INFO - 2017-01-26 08:50:03 --> Security Class Initialized
DEBUG - 2017-01-26 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:50:03 --> Input Class Initialized
INFO - 2017-01-26 08:50:03 --> Language Class Initialized
INFO - 2017-01-26 08:50:03 --> Loader Class Initialized
INFO - 2017-01-26 08:50:03 --> Helper loaded: url_helper
INFO - 2017-01-26 08:50:03 --> Helper loaded: language_helper
INFO - 2017-01-26 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:50:03 --> Controller Class Initialized
INFO - 2017-01-26 08:50:03 --> Config Class Initialized
INFO - 2017-01-26 08:50:03 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:50:03 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:50:03 --> Utf8 Class Initialized
INFO - 2017-01-26 08:50:03 --> URI Class Initialized
INFO - 2017-01-26 08:50:03 --> Router Class Initialized
INFO - 2017-01-26 08:50:03 --> Output Class Initialized
INFO - 2017-01-26 08:50:03 --> Security Class Initialized
DEBUG - 2017-01-26 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:50:03 --> Input Class Initialized
INFO - 2017-01-26 08:50:03 --> Language Class Initialized
INFO - 2017-01-26 08:50:03 --> Loader Class Initialized
INFO - 2017-01-26 08:50:03 --> Helper loaded: url_helper
INFO - 2017-01-26 08:50:03 --> Helper loaded: language_helper
INFO - 2017-01-26 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:50:03 --> Controller Class Initialized
INFO - 2017-01-26 08:50:08 --> Config Class Initialized
INFO - 2017-01-26 08:50:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:50:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:50:08 --> Utf8 Class Initialized
INFO - 2017-01-26 08:50:08 --> URI Class Initialized
INFO - 2017-01-26 08:50:08 --> Router Class Initialized
INFO - 2017-01-26 08:50:08 --> Output Class Initialized
INFO - 2017-01-26 08:50:08 --> Security Class Initialized
DEBUG - 2017-01-26 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:50:08 --> Input Class Initialized
INFO - 2017-01-26 08:50:08 --> Language Class Initialized
INFO - 2017-01-26 08:50:08 --> Loader Class Initialized
INFO - 2017-01-26 08:50:08 --> Helper loaded: url_helper
INFO - 2017-01-26 08:50:08 --> Helper loaded: language_helper
INFO - 2017-01-26 08:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:50:08 --> Controller Class Initialized
INFO - 2017-01-26 08:52:17 --> Config Class Initialized
INFO - 2017-01-26 08:52:17 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:52:17 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:52:17 --> Utf8 Class Initialized
INFO - 2017-01-26 08:52:17 --> URI Class Initialized
INFO - 2017-01-26 08:52:17 --> Router Class Initialized
INFO - 2017-01-26 08:52:17 --> Output Class Initialized
INFO - 2017-01-26 08:52:17 --> Security Class Initialized
DEBUG - 2017-01-26 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:52:17 --> Input Class Initialized
INFO - 2017-01-26 08:52:17 --> Language Class Initialized
INFO - 2017-01-26 08:52:17 --> Loader Class Initialized
INFO - 2017-01-26 08:52:17 --> Helper loaded: url_helper
INFO - 2017-01-26 08:52:17 --> Helper loaded: language_helper
INFO - 2017-01-26 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:52:17 --> Controller Class Initialized
INFO - 2017-01-26 08:52:26 --> Config Class Initialized
INFO - 2017-01-26 08:52:26 --> Hooks Class Initialized
DEBUG - 2017-01-26 08:52:26 --> UTF-8 Support Enabled
INFO - 2017-01-26 08:52:26 --> Utf8 Class Initialized
INFO - 2017-01-26 08:52:26 --> URI Class Initialized
INFO - 2017-01-26 08:52:26 --> Router Class Initialized
INFO - 2017-01-26 08:52:26 --> Output Class Initialized
INFO - 2017-01-26 08:52:26 --> Security Class Initialized
DEBUG - 2017-01-26 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 08:52:26 --> Input Class Initialized
INFO - 2017-01-26 08:52:26 --> Language Class Initialized
INFO - 2017-01-26 08:52:26 --> Loader Class Initialized
INFO - 2017-01-26 08:52:26 --> Helper loaded: url_helper
INFO - 2017-01-26 08:52:26 --> Helper loaded: language_helper
INFO - 2017-01-26 08:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 08:52:26 --> Controller Class Initialized
INFO - 2017-01-26 08:52:26 --> Final output sent to browser
DEBUG - 2017-01-26 08:52:26 --> Total execution time: 0.1073
INFO - 2017-01-26 09:00:31 --> Config Class Initialized
INFO - 2017-01-26 09:00:31 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:31 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:31 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:31 --> URI Class Initialized
INFO - 2017-01-26 09:00:31 --> Router Class Initialized
INFO - 2017-01-26 09:00:31 --> Output Class Initialized
INFO - 2017-01-26 09:00:31 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:31 --> Input Class Initialized
INFO - 2017-01-26 09:00:31 --> Language Class Initialized
INFO - 2017-01-26 09:00:31 --> Loader Class Initialized
INFO - 2017-01-26 09:00:31 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:31 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:31 --> Controller Class Initialized
INFO - 2017-01-26 09:00:31 --> Final output sent to browser
DEBUG - 2017-01-26 09:00:31 --> Total execution time: 0.1112
INFO - 2017-01-26 09:00:42 --> Config Class Initialized
INFO - 2017-01-26 09:00:42 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:42 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:42 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:42 --> URI Class Initialized
INFO - 2017-01-26 09:00:42 --> Router Class Initialized
INFO - 2017-01-26 09:00:42 --> Output Class Initialized
INFO - 2017-01-26 09:00:42 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:42 --> Input Class Initialized
INFO - 2017-01-26 09:00:42 --> Language Class Initialized
INFO - 2017-01-26 09:00:42 --> Loader Class Initialized
INFO - 2017-01-26 09:00:42 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:42 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:42 --> Controller Class Initialized
INFO - 2017-01-26 09:00:43 --> Config Class Initialized
INFO - 2017-01-26 09:00:43 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:43 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:43 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:43 --> URI Class Initialized
INFO - 2017-01-26 09:00:43 --> Router Class Initialized
INFO - 2017-01-26 09:00:43 --> Output Class Initialized
INFO - 2017-01-26 09:00:43 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:43 --> Input Class Initialized
INFO - 2017-01-26 09:00:43 --> Language Class Initialized
INFO - 2017-01-26 09:00:43 --> Loader Class Initialized
INFO - 2017-01-26 09:00:43 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:43 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:43 --> Controller Class Initialized
INFO - 2017-01-26 09:00:43 --> Config Class Initialized
INFO - 2017-01-26 09:00:43 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:43 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:43 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:43 --> URI Class Initialized
INFO - 2017-01-26 09:00:43 --> Router Class Initialized
INFO - 2017-01-26 09:00:43 --> Output Class Initialized
INFO - 2017-01-26 09:00:43 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:43 --> Input Class Initialized
INFO - 2017-01-26 09:00:43 --> Language Class Initialized
INFO - 2017-01-26 09:00:43 --> Loader Class Initialized
INFO - 2017-01-26 09:00:43 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:43 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:43 --> Controller Class Initialized
INFO - 2017-01-26 09:00:44 --> Config Class Initialized
INFO - 2017-01-26 09:00:44 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:44 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:44 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:44 --> URI Class Initialized
INFO - 2017-01-26 09:00:44 --> Router Class Initialized
INFO - 2017-01-26 09:00:44 --> Output Class Initialized
INFO - 2017-01-26 09:00:44 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:44 --> Input Class Initialized
INFO - 2017-01-26 09:00:44 --> Language Class Initialized
INFO - 2017-01-26 09:00:44 --> Loader Class Initialized
INFO - 2017-01-26 09:00:44 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:44 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:44 --> Controller Class Initialized
INFO - 2017-01-26 09:00:44 --> Config Class Initialized
INFO - 2017-01-26 09:00:44 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:44 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:44 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:44 --> URI Class Initialized
INFO - 2017-01-26 09:00:44 --> Router Class Initialized
INFO - 2017-01-26 09:00:44 --> Output Class Initialized
INFO - 2017-01-26 09:00:44 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:44 --> Input Class Initialized
INFO - 2017-01-26 09:00:44 --> Language Class Initialized
INFO - 2017-01-26 09:00:44 --> Loader Class Initialized
INFO - 2017-01-26 09:00:44 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:44 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:44 --> Controller Class Initialized
INFO - 2017-01-26 09:00:58 --> Config Class Initialized
INFO - 2017-01-26 09:00:58 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:00:58 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:00:58 --> Utf8 Class Initialized
INFO - 2017-01-26 09:00:58 --> URI Class Initialized
INFO - 2017-01-26 09:00:58 --> Router Class Initialized
INFO - 2017-01-26 09:00:58 --> Output Class Initialized
INFO - 2017-01-26 09:00:58 --> Security Class Initialized
DEBUG - 2017-01-26 09:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:00:58 --> Input Class Initialized
INFO - 2017-01-26 09:00:58 --> Language Class Initialized
INFO - 2017-01-26 09:00:58 --> Loader Class Initialized
INFO - 2017-01-26 09:00:58 --> Helper loaded: url_helper
INFO - 2017-01-26 09:00:58 --> Helper loaded: language_helper
INFO - 2017-01-26 09:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:00:58 --> Controller Class Initialized
INFO - 2017-01-26 09:04:08 --> Config Class Initialized
INFO - 2017-01-26 09:04:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:04:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:04:08 --> Utf8 Class Initialized
INFO - 2017-01-26 09:04:08 --> URI Class Initialized
INFO - 2017-01-26 09:04:08 --> Router Class Initialized
INFO - 2017-01-26 09:04:08 --> Output Class Initialized
INFO - 2017-01-26 09:04:08 --> Security Class Initialized
DEBUG - 2017-01-26 09:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:04:08 --> Input Class Initialized
INFO - 2017-01-26 09:04:08 --> Language Class Initialized
INFO - 2017-01-26 09:04:08 --> Loader Class Initialized
INFO - 2017-01-26 09:04:08 --> Helper loaded: url_helper
INFO - 2017-01-26 09:04:08 --> Helper loaded: language_helper
INFO - 2017-01-26 09:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:04:08 --> Controller Class Initialized
INFO - 2017-01-26 09:04:08 --> Final output sent to browser
DEBUG - 2017-01-26 09:04:08 --> Total execution time: 0.2509
INFO - 2017-01-26 09:04:43 --> Config Class Initialized
INFO - 2017-01-26 09:04:43 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:04:43 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:04:43 --> Utf8 Class Initialized
INFO - 2017-01-26 09:04:43 --> URI Class Initialized
INFO - 2017-01-26 09:04:43 --> Router Class Initialized
INFO - 2017-01-26 09:04:43 --> Output Class Initialized
INFO - 2017-01-26 09:04:43 --> Security Class Initialized
DEBUG - 2017-01-26 09:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:04:43 --> Input Class Initialized
INFO - 2017-01-26 09:04:43 --> Language Class Initialized
INFO - 2017-01-26 09:04:43 --> Loader Class Initialized
INFO - 2017-01-26 09:04:43 --> Helper loaded: url_helper
INFO - 2017-01-26 09:04:43 --> Helper loaded: language_helper
INFO - 2017-01-26 09:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:04:43 --> Controller Class Initialized
INFO - 2017-01-26 09:04:43 --> Final output sent to browser
DEBUG - 2017-01-26 09:04:43 --> Total execution time: 0.1890
INFO - 2017-01-26 09:05:21 --> Config Class Initialized
INFO - 2017-01-26 09:05:21 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:05:21 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:05:21 --> Utf8 Class Initialized
INFO - 2017-01-26 09:05:21 --> URI Class Initialized
DEBUG - 2017-01-26 09:05:21 --> No URI present. Default controller set.
INFO - 2017-01-26 09:05:21 --> Router Class Initialized
INFO - 2017-01-26 09:05:21 --> Output Class Initialized
INFO - 2017-01-26 09:05:21 --> Security Class Initialized
DEBUG - 2017-01-26 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:05:21 --> Input Class Initialized
INFO - 2017-01-26 09:05:21 --> Language Class Initialized
INFO - 2017-01-26 09:05:21 --> Loader Class Initialized
INFO - 2017-01-26 09:05:21 --> Helper loaded: url_helper
INFO - 2017-01-26 09:05:21 --> Helper loaded: language_helper
INFO - 2017-01-26 09:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:05:21 --> Controller Class Initialized
INFO - 2017-01-26 09:05:21 --> Database Driver Class Initialized
INFO - 2017-01-26 09:05:21 --> Model Class Initialized
INFO - 2017-01-26 09:05:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 09:05:21 --> Config Class Initialized
INFO - 2017-01-26 09:05:21 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:05:21 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:05:21 --> Utf8 Class Initialized
INFO - 2017-01-26 09:05:21 --> URI Class Initialized
INFO - 2017-01-26 09:05:21 --> Router Class Initialized
INFO - 2017-01-26 09:05:21 --> Output Class Initialized
INFO - 2017-01-26 09:05:21 --> Security Class Initialized
DEBUG - 2017-01-26 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:05:21 --> Input Class Initialized
INFO - 2017-01-26 09:05:21 --> Language Class Initialized
INFO - 2017-01-26 09:05:21 --> Loader Class Initialized
INFO - 2017-01-26 09:05:21 --> Helper loaded: url_helper
INFO - 2017-01-26 09:05:21 --> Helper loaded: language_helper
INFO - 2017-01-26 09:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:05:21 --> Controller Class Initialized
INFO - 2017-01-26 09:05:21 --> Database Driver Class Initialized
INFO - 2017-01-26 09:05:21 --> Model Class Initialized
INFO - 2017-01-26 09:05:21 --> Model Class Initialized
INFO - 2017-01-26 09:05:21 --> Model Class Initialized
INFO - 2017-01-26 09:05:21 --> Model Class Initialized
INFO - 2017-01-26 09:05:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 09:05:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-26 09:05:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-26 09:05:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-26 09:05:21 --> Final output sent to browser
DEBUG - 2017-01-26 09:05:21 --> Total execution time: 0.1699
INFO - 2017-01-26 09:05:26 --> Config Class Initialized
INFO - 2017-01-26 09:05:26 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:05:26 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:05:26 --> Utf8 Class Initialized
INFO - 2017-01-26 09:05:26 --> URI Class Initialized
INFO - 2017-01-26 09:05:26 --> Router Class Initialized
INFO - 2017-01-26 09:05:26 --> Output Class Initialized
INFO - 2017-01-26 09:05:26 --> Security Class Initialized
DEBUG - 2017-01-26 09:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:05:26 --> Input Class Initialized
INFO - 2017-01-26 09:05:26 --> Language Class Initialized
INFO - 2017-01-26 09:05:26 --> Loader Class Initialized
INFO - 2017-01-26 09:05:26 --> Helper loaded: url_helper
INFO - 2017-01-26 09:05:26 --> Helper loaded: language_helper
INFO - 2017-01-26 09:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:05:26 --> Controller Class Initialized
INFO - 2017-01-26 09:05:26 --> Final output sent to browser
DEBUG - 2017-01-26 09:05:26 --> Total execution time: 0.3227
INFO - 2017-01-26 09:48:19 --> Config Class Initialized
INFO - 2017-01-26 09:48:19 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:48:19 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:48:19 --> Utf8 Class Initialized
INFO - 2017-01-26 09:48:19 --> URI Class Initialized
DEBUG - 2017-01-26 09:48:19 --> No URI present. Default controller set.
INFO - 2017-01-26 09:48:19 --> Router Class Initialized
INFO - 2017-01-26 09:48:19 --> Output Class Initialized
INFO - 2017-01-26 09:48:19 --> Security Class Initialized
DEBUG - 2017-01-26 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:48:19 --> Input Class Initialized
INFO - 2017-01-26 09:48:19 --> Language Class Initialized
INFO - 2017-01-26 09:48:19 --> Loader Class Initialized
INFO - 2017-01-26 09:48:19 --> Helper loaded: url_helper
INFO - 2017-01-26 09:48:19 --> Helper loaded: language_helper
INFO - 2017-01-26 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:48:19 --> Controller Class Initialized
INFO - 2017-01-26 09:48:19 --> Database Driver Class Initialized
INFO - 2017-01-26 09:48:19 --> Model Class Initialized
INFO - 2017-01-26 09:48:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 09:48:19 --> Config Class Initialized
INFO - 2017-01-26 09:48:19 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:48:19 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:48:19 --> Utf8 Class Initialized
INFO - 2017-01-26 09:48:19 --> URI Class Initialized
INFO - 2017-01-26 09:48:19 --> Router Class Initialized
INFO - 2017-01-26 09:48:19 --> Output Class Initialized
INFO - 2017-01-26 09:48:19 --> Security Class Initialized
DEBUG - 2017-01-26 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:48:19 --> Input Class Initialized
INFO - 2017-01-26 09:48:19 --> Language Class Initialized
INFO - 2017-01-26 09:48:19 --> Loader Class Initialized
INFO - 2017-01-26 09:48:19 --> Helper loaded: url_helper
INFO - 2017-01-26 09:48:19 --> Helper loaded: language_helper
INFO - 2017-01-26 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 09:48:19 --> Controller Class Initialized
INFO - 2017-01-26 09:48:19 --> Database Driver Class Initialized
INFO - 2017-01-26 09:48:19 --> Model Class Initialized
INFO - 2017-01-26 09:48:19 --> Model Class Initialized
INFO - 2017-01-26 09:48:19 --> Model Class Initialized
INFO - 2017-01-26 09:48:19 --> Model Class Initialized
INFO - 2017-01-26 09:48:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-26 09:48:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-26 09:48:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-26 09:48:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-26 09:48:19 --> Final output sent to browser
DEBUG - 2017-01-26 09:48:19 --> Total execution time: 0.1662
INFO - 2017-01-26 09:48:20 --> Config Class Initialized
INFO - 2017-01-26 09:48:20 --> Hooks Class Initialized
DEBUG - 2017-01-26 09:48:20 --> UTF-8 Support Enabled
INFO - 2017-01-26 09:48:20 --> Utf8 Class Initialized
INFO - 2017-01-26 09:48:20 --> URI Class Initialized
INFO - 2017-01-26 09:48:20 --> Router Class Initialized
INFO - 2017-01-26 09:48:20 --> Output Class Initialized
INFO - 2017-01-26 09:48:20 --> Security Class Initialized
DEBUG - 2017-01-26 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 09:48:20 --> Input Class Initialized
INFO - 2017-01-26 09:48:20 --> Language Class Initialized
ERROR - 2017-01-26 09:48:20 --> 404 Page Not Found: Faviconico/index
