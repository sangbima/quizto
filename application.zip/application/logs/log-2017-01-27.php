<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-27 09:09:32 --> Config Class Initialized
INFO - 2017-01-27 09:09:32 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:09:32 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:09:32 --> Utf8 Class Initialized
INFO - 2017-01-27 09:09:32 --> URI Class Initialized
DEBUG - 2017-01-27 09:09:32 --> No URI present. Default controller set.
INFO - 2017-01-27 09:09:32 --> Router Class Initialized
INFO - 2017-01-27 09:09:32 --> Output Class Initialized
INFO - 2017-01-27 09:09:32 --> Security Class Initialized
DEBUG - 2017-01-27 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:09:32 --> Input Class Initialized
INFO - 2017-01-27 09:09:32 --> Language Class Initialized
INFO - 2017-01-27 09:09:32 --> Loader Class Initialized
INFO - 2017-01-27 09:09:32 --> Helper loaded: url_helper
INFO - 2017-01-27 09:09:32 --> Helper loaded: language_helper
INFO - 2017-01-27 09:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:09:32 --> Controller Class Initialized
INFO - 2017-01-27 09:09:32 --> Database Driver Class Initialized
INFO - 2017-01-27 09:09:32 --> Model Class Initialized
INFO - 2017-01-27 09:09:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-01-27 09:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-01-27 09:09:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-01-27 09:09:32 --> Final output sent to browser
DEBUG - 2017-01-27 09:09:32 --> Total execution time: 0.0979
INFO - 2017-01-27 09:09:37 --> Config Class Initialized
INFO - 2017-01-27 09:09:37 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:09:37 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:09:37 --> Utf8 Class Initialized
INFO - 2017-01-27 09:09:37 --> URI Class Initialized
INFO - 2017-01-27 09:09:37 --> Router Class Initialized
INFO - 2017-01-27 09:09:37 --> Output Class Initialized
INFO - 2017-01-27 09:09:37 --> Security Class Initialized
DEBUG - 2017-01-27 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:09:37 --> Input Class Initialized
INFO - 2017-01-27 09:09:37 --> Language Class Initialized
INFO - 2017-01-27 09:09:37 --> Loader Class Initialized
INFO - 2017-01-27 09:09:37 --> Helper loaded: url_helper
INFO - 2017-01-27 09:09:37 --> Helper loaded: language_helper
INFO - 2017-01-27 09:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:09:37 --> Controller Class Initialized
INFO - 2017-01-27 09:09:37 --> Database Driver Class Initialized
INFO - 2017-01-27 09:09:37 --> Model Class Initialized
INFO - 2017-01-27 09:09:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:09:37 --> Config Class Initialized
INFO - 2017-01-27 09:09:38 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:09:38 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:09:38 --> Utf8 Class Initialized
INFO - 2017-01-27 09:09:38 --> URI Class Initialized
INFO - 2017-01-27 09:09:38 --> Router Class Initialized
INFO - 2017-01-27 09:09:38 --> Output Class Initialized
INFO - 2017-01-27 09:09:38 --> Security Class Initialized
DEBUG - 2017-01-27 09:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:09:38 --> Input Class Initialized
INFO - 2017-01-27 09:09:38 --> Language Class Initialized
INFO - 2017-01-27 09:09:38 --> Loader Class Initialized
INFO - 2017-01-27 09:09:38 --> Helper loaded: url_helper
INFO - 2017-01-27 09:09:38 --> Helper loaded: language_helper
INFO - 2017-01-27 09:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:09:38 --> Controller Class Initialized
INFO - 2017-01-27 09:09:38 --> Database Driver Class Initialized
INFO - 2017-01-27 09:09:38 --> Model Class Initialized
INFO - 2017-01-27 09:09:38 --> Model Class Initialized
INFO - 2017-01-27 09:09:38 --> Model Class Initialized
INFO - 2017-01-27 09:09:38 --> Model Class Initialized
INFO - 2017-01-27 09:09:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:09:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:09:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-01-27 09:09:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:09:38 --> Final output sent to browser
DEBUG - 2017-01-27 09:09:38 --> Total execution time: 0.0995
INFO - 2017-01-27 09:09:40 --> Config Class Initialized
INFO - 2017-01-27 09:09:40 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:09:40 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:09:40 --> Utf8 Class Initialized
INFO - 2017-01-27 09:09:40 --> URI Class Initialized
INFO - 2017-01-27 09:09:40 --> Router Class Initialized
INFO - 2017-01-27 09:09:40 --> Output Class Initialized
INFO - 2017-01-27 09:09:40 --> Security Class Initialized
DEBUG - 2017-01-27 09:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:09:40 --> Input Class Initialized
INFO - 2017-01-27 09:09:40 --> Language Class Initialized
INFO - 2017-01-27 09:09:40 --> Loader Class Initialized
INFO - 2017-01-27 09:09:40 --> Helper loaded: url_helper
INFO - 2017-01-27 09:09:40 --> Helper loaded: language_helper
INFO - 2017-01-27 09:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:09:40 --> Controller Class Initialized
INFO - 2017-01-27 09:09:40 --> Database Driver Class Initialized
INFO - 2017-01-27 09:09:40 --> Model Class Initialized
INFO - 2017-01-27 09:09:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:09:40 --> Helper loaded: form_helper
INFO - 2017-01-27 09:09:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:09:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-27 09:09:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:09:40 --> Final output sent to browser
DEBUG - 2017-01-27 09:09:40 --> Total execution time: 0.1482
INFO - 2017-01-27 09:09:43 --> Config Class Initialized
INFO - 2017-01-27 09:09:43 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:09:43 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:09:43 --> Utf8 Class Initialized
INFO - 2017-01-27 09:09:43 --> URI Class Initialized
INFO - 2017-01-27 09:09:43 --> Router Class Initialized
INFO - 2017-01-27 09:09:43 --> Output Class Initialized
INFO - 2017-01-27 09:09:43 --> Security Class Initialized
DEBUG - 2017-01-27 09:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:09:43 --> Input Class Initialized
INFO - 2017-01-27 09:09:43 --> Language Class Initialized
INFO - 2017-01-27 09:09:43 --> Loader Class Initialized
INFO - 2017-01-27 09:09:43 --> Helper loaded: url_helper
INFO - 2017-01-27 09:09:43 --> Helper loaded: language_helper
INFO - 2017-01-27 09:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:09:43 --> Controller Class Initialized
INFO - 2017-01-27 09:09:43 --> Database Driver Class Initialized
INFO - 2017-01-27 09:09:43 --> Model Class Initialized
INFO - 2017-01-27 09:09:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:09:43 --> Model Class Initialized
INFO - 2017-01-27 09:09:43 --> Model Class Initialized
INFO - 2017-01-27 09:09:43 --> Helper loaded: form_helper
INFO - 2017-01-27 09:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:09:43 --> Final output sent to browser
DEBUG - 2017-01-27 09:09:43 --> Total execution time: 0.1461
INFO - 2017-01-27 09:09:48 --> Config Class Initialized
INFO - 2017-01-27 09:09:48 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:09:48 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:09:48 --> Utf8 Class Initialized
INFO - 2017-01-27 09:09:48 --> URI Class Initialized
INFO - 2017-01-27 09:09:48 --> Router Class Initialized
INFO - 2017-01-27 09:09:48 --> Output Class Initialized
INFO - 2017-01-27 09:09:48 --> Security Class Initialized
DEBUG - 2017-01-27 09:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:09:48 --> Input Class Initialized
INFO - 2017-01-27 09:09:48 --> Language Class Initialized
INFO - 2017-01-27 09:09:48 --> Loader Class Initialized
INFO - 2017-01-27 09:09:48 --> Helper loaded: url_helper
INFO - 2017-01-27 09:09:48 --> Helper loaded: language_helper
INFO - 2017-01-27 09:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:09:48 --> Controller Class Initialized
INFO - 2017-01-27 09:09:48 --> Database Driver Class Initialized
INFO - 2017-01-27 09:09:48 --> Model Class Initialized
INFO - 2017-01-27 09:09:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:09:48 --> Model Class Initialized
INFO - 2017-01-27 09:09:48 --> Model Class Initialized
INFO - 2017-01-27 09:09:48 --> Helper loaded: form_helper
INFO - 2017-01-27 09:09:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan_detail.php
INFO - 2017-01-27 09:09:49 --> Final output sent to browser
DEBUG - 2017-01-27 09:09:49 --> Total execution time: 0.6725
INFO - 2017-01-27 09:10:53 --> Config Class Initialized
INFO - 2017-01-27 09:10:53 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:10:53 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:10:53 --> Utf8 Class Initialized
INFO - 2017-01-27 09:10:53 --> URI Class Initialized
INFO - 2017-01-27 09:10:53 --> Router Class Initialized
INFO - 2017-01-27 09:10:53 --> Output Class Initialized
INFO - 2017-01-27 09:10:53 --> Security Class Initialized
DEBUG - 2017-01-27 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:10:53 --> Input Class Initialized
INFO - 2017-01-27 09:10:53 --> Language Class Initialized
INFO - 2017-01-27 09:10:53 --> Loader Class Initialized
INFO - 2017-01-27 09:10:53 --> Helper loaded: url_helper
INFO - 2017-01-27 09:10:53 --> Helper loaded: language_helper
INFO - 2017-01-27 09:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:10:53 --> Controller Class Initialized
INFO - 2017-01-27 09:10:53 --> Database Driver Class Initialized
INFO - 2017-01-27 09:10:53 --> Model Class Initialized
INFO - 2017-01-27 09:10:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:10:53 --> Model Class Initialized
INFO - 2017-01-27 09:10:53 --> Model Class Initialized
INFO - 2017-01-27 09:10:53 --> Helper loaded: form_helper
INFO - 2017-01-27 09:10:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan_detail.php
INFO - 2017-01-27 09:10:54 --> Final output sent to browser
DEBUG - 2017-01-27 09:10:54 --> Total execution time: 0.5954
INFO - 2017-01-27 09:12:27 --> Config Class Initialized
INFO - 2017-01-27 09:12:27 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:12:27 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:12:27 --> Utf8 Class Initialized
INFO - 2017-01-27 09:12:27 --> URI Class Initialized
INFO - 2017-01-27 09:12:27 --> Router Class Initialized
INFO - 2017-01-27 09:12:27 --> Output Class Initialized
INFO - 2017-01-27 09:12:27 --> Security Class Initialized
DEBUG - 2017-01-27 09:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:12:27 --> Input Class Initialized
INFO - 2017-01-27 09:12:27 --> Language Class Initialized
INFO - 2017-01-27 09:12:27 --> Loader Class Initialized
INFO - 2017-01-27 09:12:27 --> Helper loaded: url_helper
INFO - 2017-01-27 09:12:27 --> Helper loaded: language_helper
INFO - 2017-01-27 09:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:12:27 --> Controller Class Initialized
INFO - 2017-01-27 09:12:27 --> Database Driver Class Initialized
INFO - 2017-01-27 09:12:27 --> Model Class Initialized
INFO - 2017-01-27 09:12:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:12:27 --> Helper loaded: form_helper
INFO - 2017-01-27 09:12:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:12:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-01-27 09:12:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:12:27 --> Final output sent to browser
DEBUG - 2017-01-27 09:12:27 --> Total execution time: 0.1121
INFO - 2017-01-27 09:12:29 --> Config Class Initialized
INFO - 2017-01-27 09:12:30 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:12:30 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:12:30 --> Utf8 Class Initialized
INFO - 2017-01-27 09:12:30 --> URI Class Initialized
INFO - 2017-01-27 09:12:30 --> Router Class Initialized
INFO - 2017-01-27 09:12:30 --> Output Class Initialized
INFO - 2017-01-27 09:12:30 --> Security Class Initialized
DEBUG - 2017-01-27 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:12:30 --> Input Class Initialized
INFO - 2017-01-27 09:12:30 --> Language Class Initialized
INFO - 2017-01-27 09:12:30 --> Loader Class Initialized
INFO - 2017-01-27 09:12:30 --> Helper loaded: url_helper
INFO - 2017-01-27 09:12:30 --> Helper loaded: language_helper
INFO - 2017-01-27 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:12:30 --> Controller Class Initialized
INFO - 2017-01-27 09:12:30 --> Database Driver Class Initialized
INFO - 2017-01-27 09:12:30 --> Model Class Initialized
INFO - 2017-01-27 09:12:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:12:30 --> Helper loaded: form_helper
INFO - 2017-01-27 09:12:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:12:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-01-27 09:12:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:12:30 --> Final output sent to browser
DEBUG - 2017-01-27 09:12:30 --> Total execution time: 0.1102
INFO - 2017-01-27 09:12:31 --> Config Class Initialized
INFO - 2017-01-27 09:12:31 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:12:31 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:12:31 --> Utf8 Class Initialized
INFO - 2017-01-27 09:12:31 --> URI Class Initialized
INFO - 2017-01-27 09:12:31 --> Router Class Initialized
INFO - 2017-01-27 09:12:31 --> Output Class Initialized
INFO - 2017-01-27 09:12:31 --> Security Class Initialized
DEBUG - 2017-01-27 09:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:12:31 --> Input Class Initialized
INFO - 2017-01-27 09:12:31 --> Language Class Initialized
INFO - 2017-01-27 09:12:31 --> Loader Class Initialized
INFO - 2017-01-27 09:12:31 --> Helper loaded: url_helper
INFO - 2017-01-27 09:12:31 --> Helper loaded: language_helper
INFO - 2017-01-27 09:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:12:31 --> Controller Class Initialized
INFO - 2017-01-27 09:12:31 --> Database Driver Class Initialized
INFO - 2017-01-27 09:12:31 --> Model Class Initialized
INFO - 2017-01-27 09:12:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:12:31 --> Model Class Initialized
INFO - 2017-01-27 09:12:31 --> Model Class Initialized
INFO - 2017-01-27 09:12:31 --> Helper loaded: form_helper
INFO - 2017-01-27 09:12:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:12:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-01-27 09:12:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:12:31 --> Final output sent to browser
DEBUG - 2017-01-27 09:12:31 --> Total execution time: 0.1324
INFO - 2017-01-27 09:12:35 --> Config Class Initialized
INFO - 2017-01-27 09:12:35 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:12:35 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:12:35 --> Utf8 Class Initialized
INFO - 2017-01-27 09:12:35 --> URI Class Initialized
INFO - 2017-01-27 09:12:35 --> Router Class Initialized
INFO - 2017-01-27 09:12:35 --> Output Class Initialized
INFO - 2017-01-27 09:12:35 --> Security Class Initialized
DEBUG - 2017-01-27 09:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:12:35 --> Input Class Initialized
INFO - 2017-01-27 09:12:35 --> Language Class Initialized
INFO - 2017-01-27 09:12:35 --> Loader Class Initialized
INFO - 2017-01-27 09:12:35 --> Helper loaded: url_helper
INFO - 2017-01-27 09:12:35 --> Helper loaded: language_helper
INFO - 2017-01-27 09:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:12:35 --> Controller Class Initialized
INFO - 2017-01-27 09:12:36 --> Database Driver Class Initialized
INFO - 2017-01-27 09:12:36 --> Model Class Initialized
INFO - 2017-01-27 09:12:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:12:36 --> Model Class Initialized
INFO - 2017-01-27 09:12:36 --> Helper loaded: form_helper
INFO - 2017-01-27 09:12:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:12:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-01-27 09:12:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:12:36 --> Final output sent to browser
DEBUG - 2017-01-27 09:12:36 --> Total execution time: 0.3397
INFO - 2017-01-27 09:12:38 --> Config Class Initialized
INFO - 2017-01-27 09:12:38 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:12:38 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:12:38 --> Utf8 Class Initialized
INFO - 2017-01-27 09:12:38 --> URI Class Initialized
INFO - 2017-01-27 09:12:38 --> Router Class Initialized
INFO - 2017-01-27 09:12:38 --> Output Class Initialized
INFO - 2017-01-27 09:12:38 --> Security Class Initialized
DEBUG - 2017-01-27 09:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:12:38 --> Input Class Initialized
INFO - 2017-01-27 09:12:38 --> Language Class Initialized
INFO - 2017-01-27 09:12:38 --> Loader Class Initialized
INFO - 2017-01-27 09:12:38 --> Helper loaded: url_helper
INFO - 2017-01-27 09:12:38 --> Helper loaded: language_helper
INFO - 2017-01-27 09:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:12:38 --> Controller Class Initialized
INFO - 2017-01-27 09:12:38 --> Database Driver Class Initialized
INFO - 2017-01-27 09:12:38 --> Model Class Initialized
INFO - 2017-01-27 09:12:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:12:38 --> Model Class Initialized
INFO - 2017-01-27 09:12:38 --> Model Class Initialized
INFO - 2017-01-27 09:12:38 --> Helper loaded: form_helper
INFO - 2017-01-27 09:12:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:12:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_disc.php
INFO - 2017-01-27 09:12:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:12:38 --> Final output sent to browser
DEBUG - 2017-01-27 09:12:38 --> Total execution time: 0.0986
INFO - 2017-01-27 09:12:41 --> Config Class Initialized
INFO - 2017-01-27 09:12:41 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:12:41 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:12:41 --> Utf8 Class Initialized
INFO - 2017-01-27 09:12:41 --> URI Class Initialized
INFO - 2017-01-27 09:12:41 --> Router Class Initialized
INFO - 2017-01-27 09:12:41 --> Output Class Initialized
INFO - 2017-01-27 09:12:41 --> Security Class Initialized
DEBUG - 2017-01-27 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:12:41 --> Input Class Initialized
INFO - 2017-01-27 09:12:41 --> Language Class Initialized
INFO - 2017-01-27 09:12:41 --> Loader Class Initialized
INFO - 2017-01-27 09:12:41 --> Helper loaded: url_helper
INFO - 2017-01-27 09:12:41 --> Helper loaded: language_helper
INFO - 2017-01-27 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:12:41 --> Controller Class Initialized
INFO - 2017-01-27 09:12:41 --> Database Driver Class Initialized
INFO - 2017-01-27 09:12:41 --> Model Class Initialized
INFO - 2017-01-27 09:12:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:12:41 --> Model Class Initialized
INFO - 2017-01-27 09:12:41 --> Model Class Initialized
INFO - 2017-01-27 09:12:41 --> Helper loaded: form_helper
INFO - 2017-01-27 09:12:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc_detail.php
INFO - 2017-01-27 09:12:41 --> Final output sent to browser
DEBUG - 2017-01-27 09:12:41 --> Total execution time: 0.5262
INFO - 2017-01-27 09:18:43 --> Config Class Initialized
INFO - 2017-01-27 09:18:43 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:18:43 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:18:43 --> Utf8 Class Initialized
INFO - 2017-01-27 09:18:43 --> URI Class Initialized
INFO - 2017-01-27 09:18:43 --> Router Class Initialized
INFO - 2017-01-27 09:18:43 --> Output Class Initialized
INFO - 2017-01-27 09:18:43 --> Security Class Initialized
DEBUG - 2017-01-27 09:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:18:43 --> Input Class Initialized
INFO - 2017-01-27 09:18:43 --> Language Class Initialized
INFO - 2017-01-27 09:18:44 --> Loader Class Initialized
INFO - 2017-01-27 09:18:44 --> Helper loaded: url_helper
INFO - 2017-01-27 09:18:44 --> Helper loaded: language_helper
INFO - 2017-01-27 09:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:18:44 --> Controller Class Initialized
INFO - 2017-01-27 09:18:44 --> Database Driver Class Initialized
INFO - 2017-01-27 09:18:44 --> Model Class Initialized
INFO - 2017-01-27 09:18:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:18:44 --> Helper loaded: form_helper
INFO - 2017-01-27 09:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-27 09:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:18:44 --> Final output sent to browser
DEBUG - 2017-01-27 09:18:44 --> Total execution time: 0.1066
INFO - 2017-01-27 09:18:45 --> Config Class Initialized
INFO - 2017-01-27 09:18:45 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:18:45 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:18:45 --> Utf8 Class Initialized
INFO - 2017-01-27 09:18:45 --> URI Class Initialized
INFO - 2017-01-27 09:18:45 --> Router Class Initialized
INFO - 2017-01-27 09:18:45 --> Output Class Initialized
INFO - 2017-01-27 09:18:45 --> Security Class Initialized
DEBUG - 2017-01-27 09:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:18:45 --> Input Class Initialized
INFO - 2017-01-27 09:18:45 --> Language Class Initialized
INFO - 2017-01-27 09:18:45 --> Loader Class Initialized
INFO - 2017-01-27 09:18:45 --> Helper loaded: url_helper
INFO - 2017-01-27 09:18:45 --> Helper loaded: language_helper
INFO - 2017-01-27 09:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:18:45 --> Controller Class Initialized
INFO - 2017-01-27 09:18:45 --> Database Driver Class Initialized
INFO - 2017-01-27 09:18:45 --> Model Class Initialized
INFO - 2017-01-27 09:18:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:18:45 --> Model Class Initialized
INFO - 2017-01-27 09:18:45 --> Model Class Initialized
INFO - 2017-01-27 09:18:45 --> Helper loaded: form_helper
INFO - 2017-01-27 09:18:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:18:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:18:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:18:45 --> Final output sent to browser
DEBUG - 2017-01-27 09:18:45 --> Total execution time: 0.1255
INFO - 2017-01-27 09:18:47 --> Config Class Initialized
INFO - 2017-01-27 09:18:47 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:18:47 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:18:47 --> Utf8 Class Initialized
INFO - 2017-01-27 09:18:47 --> URI Class Initialized
INFO - 2017-01-27 09:18:47 --> Router Class Initialized
INFO - 2017-01-27 09:18:47 --> Output Class Initialized
INFO - 2017-01-27 09:18:47 --> Security Class Initialized
DEBUG - 2017-01-27 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:18:47 --> Input Class Initialized
INFO - 2017-01-27 09:18:47 --> Language Class Initialized
INFO - 2017-01-27 09:18:47 --> Loader Class Initialized
INFO - 2017-01-27 09:18:47 --> Helper loaded: url_helper
INFO - 2017-01-27 09:18:47 --> Helper loaded: language_helper
INFO - 2017-01-27 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:18:47 --> Controller Class Initialized
INFO - 2017-01-27 09:18:47 --> Database Driver Class Initialized
INFO - 2017-01-27 09:18:47 --> Model Class Initialized
INFO - 2017-01-27 09:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:18:47 --> Model Class Initialized
INFO - 2017-01-27 09:18:47 --> Model Class Initialized
INFO - 2017-01-27 09:18:47 --> Helper loaded: form_helper
INFO - 2017-01-27 09:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_ringkasan_detail.php
INFO - 2017-01-27 09:18:48 --> Final output sent to browser
DEBUG - 2017-01-27 09:18:48 --> Total execution time: 0.5945
INFO - 2017-01-27 09:21:07 --> Config Class Initialized
INFO - 2017-01-27 09:21:07 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:21:07 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:21:07 --> Utf8 Class Initialized
INFO - 2017-01-27 09:21:07 --> URI Class Initialized
INFO - 2017-01-27 09:21:07 --> Router Class Initialized
INFO - 2017-01-27 09:21:07 --> Output Class Initialized
INFO - 2017-01-27 09:21:07 --> Security Class Initialized
DEBUG - 2017-01-27 09:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:21:07 --> Input Class Initialized
INFO - 2017-01-27 09:21:07 --> Language Class Initialized
INFO - 2017-01-27 09:21:07 --> Loader Class Initialized
INFO - 2017-01-27 09:21:07 --> Helper loaded: url_helper
INFO - 2017-01-27 09:21:07 --> Helper loaded: language_helper
INFO - 2017-01-27 09:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:21:07 --> Controller Class Initialized
INFO - 2017-01-27 09:21:07 --> Database Driver Class Initialized
INFO - 2017-01-27 09:21:07 --> Model Class Initialized
INFO - 2017-01-27 09:21:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:21:07 --> Model Class Initialized
INFO - 2017-01-27 09:21:07 --> Model Class Initialized
INFO - 2017-01-27 09:21:07 --> Helper loaded: form_helper
INFO - 2017-01-27 09:21:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:21:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:21:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:21:07 --> Final output sent to browser
DEBUG - 2017-01-27 09:21:07 --> Total execution time: 0.1206
INFO - 2017-01-27 09:25:42 --> Config Class Initialized
INFO - 2017-01-27 09:25:42 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:25:42 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:25:42 --> Utf8 Class Initialized
INFO - 2017-01-27 09:25:42 --> URI Class Initialized
INFO - 2017-01-27 09:25:42 --> Router Class Initialized
INFO - 2017-01-27 09:25:42 --> Output Class Initialized
INFO - 2017-01-27 09:25:42 --> Security Class Initialized
DEBUG - 2017-01-27 09:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:25:42 --> Input Class Initialized
INFO - 2017-01-27 09:25:42 --> Language Class Initialized
INFO - 2017-01-27 09:25:42 --> Loader Class Initialized
INFO - 2017-01-27 09:25:42 --> Helper loaded: url_helper
INFO - 2017-01-27 09:25:42 --> Helper loaded: language_helper
INFO - 2017-01-27 09:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:25:42 --> Controller Class Initialized
INFO - 2017-01-27 09:25:42 --> Database Driver Class Initialized
INFO - 2017-01-27 09:25:42 --> Model Class Initialized
INFO - 2017-01-27 09:25:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:25:42 --> Model Class Initialized
INFO - 2017-01-27 09:25:42 --> Model Class Initialized
INFO - 2017-01-27 09:25:42 --> Helper loaded: form_helper
INFO - 2017-01-27 09:25:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:25:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:25:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:25:42 --> Final output sent to browser
DEBUG - 2017-01-27 09:25:42 --> Total execution time: 0.1208
INFO - 2017-01-27 09:25:54 --> Config Class Initialized
INFO - 2017-01-27 09:25:54 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:25:54 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:25:54 --> Utf8 Class Initialized
INFO - 2017-01-27 09:25:54 --> URI Class Initialized
INFO - 2017-01-27 09:25:54 --> Router Class Initialized
INFO - 2017-01-27 09:25:54 --> Output Class Initialized
INFO - 2017-01-27 09:25:54 --> Security Class Initialized
DEBUG - 2017-01-27 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:25:54 --> Input Class Initialized
INFO - 2017-01-27 09:25:54 --> Language Class Initialized
INFO - 2017-01-27 09:25:54 --> Loader Class Initialized
INFO - 2017-01-27 09:25:54 --> Helper loaded: url_helper
INFO - 2017-01-27 09:25:54 --> Helper loaded: language_helper
INFO - 2017-01-27 09:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:25:54 --> Controller Class Initialized
INFO - 2017-01-27 09:25:54 --> Database Driver Class Initialized
INFO - 2017-01-27 09:25:54 --> Model Class Initialized
INFO - 2017-01-27 09:25:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:25:54 --> Model Class Initialized
INFO - 2017-01-27 09:25:54 --> Model Class Initialized
INFO - 2017-01-27 09:25:54 --> Helper loaded: form_helper
INFO - 2017-01-27 09:25:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:25:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:25:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:25:55 --> Final output sent to browser
DEBUG - 2017-01-27 09:25:55 --> Total execution time: 0.1254
INFO - 2017-01-27 09:26:13 --> Config Class Initialized
INFO - 2017-01-27 09:26:13 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:26:13 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:26:13 --> Utf8 Class Initialized
INFO - 2017-01-27 09:26:13 --> URI Class Initialized
INFO - 2017-01-27 09:26:13 --> Router Class Initialized
INFO - 2017-01-27 09:26:13 --> Output Class Initialized
INFO - 2017-01-27 09:26:13 --> Security Class Initialized
DEBUG - 2017-01-27 09:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:26:13 --> Input Class Initialized
INFO - 2017-01-27 09:26:13 --> Language Class Initialized
INFO - 2017-01-27 09:26:13 --> Loader Class Initialized
INFO - 2017-01-27 09:26:13 --> Helper loaded: url_helper
INFO - 2017-01-27 09:26:13 --> Helper loaded: language_helper
INFO - 2017-01-27 09:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:26:13 --> Controller Class Initialized
INFO - 2017-01-27 09:26:13 --> Database Driver Class Initialized
INFO - 2017-01-27 09:26:13 --> Model Class Initialized
INFO - 2017-01-27 09:26:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:26:13 --> Model Class Initialized
INFO - 2017-01-27 09:26:13 --> Model Class Initialized
INFO - 2017-01-27 09:26:13 --> Helper loaded: form_helper
INFO - 2017-01-27 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:26:13 --> Final output sent to browser
DEBUG - 2017-01-27 09:26:13 --> Total execution time: 0.1107
INFO - 2017-01-27 09:26:30 --> Config Class Initialized
INFO - 2017-01-27 09:26:30 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:26:30 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:26:30 --> Utf8 Class Initialized
INFO - 2017-01-27 09:26:30 --> URI Class Initialized
INFO - 2017-01-27 09:26:30 --> Router Class Initialized
INFO - 2017-01-27 09:26:30 --> Output Class Initialized
INFO - 2017-01-27 09:26:30 --> Security Class Initialized
DEBUG - 2017-01-27 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:26:30 --> Input Class Initialized
INFO - 2017-01-27 09:26:30 --> Language Class Initialized
INFO - 2017-01-27 09:26:30 --> Loader Class Initialized
INFO - 2017-01-27 09:26:30 --> Helper loaded: url_helper
INFO - 2017-01-27 09:26:30 --> Helper loaded: language_helper
INFO - 2017-01-27 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:26:30 --> Controller Class Initialized
INFO - 2017-01-27 09:26:30 --> Database Driver Class Initialized
INFO - 2017-01-27 09:26:30 --> Model Class Initialized
INFO - 2017-01-27 09:26:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:26:30 --> Helper loaded: form_helper
INFO - 2017-01-27 09:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-27 09:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:26:30 --> Final output sent to browser
DEBUG - 2017-01-27 09:26:30 --> Total execution time: 0.1014
INFO - 2017-01-27 09:26:44 --> Config Class Initialized
INFO - 2017-01-27 09:26:44 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:26:44 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:26:44 --> Utf8 Class Initialized
INFO - 2017-01-27 09:26:44 --> URI Class Initialized
INFO - 2017-01-27 09:26:44 --> Router Class Initialized
INFO - 2017-01-27 09:26:44 --> Output Class Initialized
INFO - 2017-01-27 09:26:44 --> Security Class Initialized
DEBUG - 2017-01-27 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:26:44 --> Input Class Initialized
INFO - 2017-01-27 09:26:44 --> Language Class Initialized
INFO - 2017-01-27 09:26:44 --> Loader Class Initialized
INFO - 2017-01-27 09:26:44 --> Helper loaded: url_helper
INFO - 2017-01-27 09:26:44 --> Helper loaded: language_helper
INFO - 2017-01-27 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:26:44 --> Controller Class Initialized
INFO - 2017-01-27 09:26:44 --> Database Driver Class Initialized
INFO - 2017-01-27 09:26:44 --> Model Class Initialized
INFO - 2017-01-27 09:26:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:26:44 --> Helper loaded: form_helper
INFO - 2017-01-27 09:26:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:26:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-27 09:26:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:26:44 --> Final output sent to browser
DEBUG - 2017-01-27 09:26:44 --> Total execution time: 0.1007
INFO - 2017-01-27 09:26:47 --> Config Class Initialized
INFO - 2017-01-27 09:26:47 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:26:47 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:26:47 --> Utf8 Class Initialized
INFO - 2017-01-27 09:26:47 --> URI Class Initialized
INFO - 2017-01-27 09:26:47 --> Router Class Initialized
INFO - 2017-01-27 09:26:47 --> Output Class Initialized
INFO - 2017-01-27 09:26:47 --> Security Class Initialized
DEBUG - 2017-01-27 09:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:26:47 --> Input Class Initialized
INFO - 2017-01-27 09:26:47 --> Language Class Initialized
INFO - 2017-01-27 09:26:47 --> Loader Class Initialized
INFO - 2017-01-27 09:26:47 --> Helper loaded: url_helper
INFO - 2017-01-27 09:26:47 --> Helper loaded: language_helper
INFO - 2017-01-27 09:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:26:47 --> Controller Class Initialized
INFO - 2017-01-27 09:26:47 --> Database Driver Class Initialized
INFO - 2017-01-27 09:26:47 --> Model Class Initialized
INFO - 2017-01-27 09:26:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:26:47 --> Model Class Initialized
INFO - 2017-01-27 09:26:47 --> Model Class Initialized
INFO - 2017-01-27 09:26:47 --> Helper loaded: form_helper
INFO - 2017-01-27 09:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:26:47 --> Final output sent to browser
DEBUG - 2017-01-27 09:26:47 --> Total execution time: 0.0986
INFO - 2017-01-27 09:26:57 --> Config Class Initialized
INFO - 2017-01-27 09:26:57 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:26:57 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:26:57 --> Utf8 Class Initialized
INFO - 2017-01-27 09:26:57 --> URI Class Initialized
INFO - 2017-01-27 09:26:57 --> Router Class Initialized
INFO - 2017-01-27 09:26:57 --> Output Class Initialized
INFO - 2017-01-27 09:26:57 --> Security Class Initialized
DEBUG - 2017-01-27 09:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:26:57 --> Input Class Initialized
INFO - 2017-01-27 09:26:57 --> Language Class Initialized
INFO - 2017-01-27 09:26:57 --> Loader Class Initialized
INFO - 2017-01-27 09:26:57 --> Helper loaded: url_helper
INFO - 2017-01-27 09:26:57 --> Helper loaded: language_helper
INFO - 2017-01-27 09:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:26:57 --> Controller Class Initialized
INFO - 2017-01-27 09:26:57 --> Database Driver Class Initialized
INFO - 2017-01-27 09:26:57 --> Model Class Initialized
INFO - 2017-01-27 09:26:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:26:57 --> Helper loaded: form_helper
INFO - 2017-01-27 09:26:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:26:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-01-27 09:26:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:26:57 --> Final output sent to browser
DEBUG - 2017-01-27 09:26:57 --> Total execution time: 0.1009
INFO - 2017-01-27 09:27:01 --> Config Class Initialized
INFO - 2017-01-27 09:27:01 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:27:01 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:27:01 --> Utf8 Class Initialized
INFO - 2017-01-27 09:27:01 --> URI Class Initialized
INFO - 2017-01-27 09:27:01 --> Router Class Initialized
INFO - 2017-01-27 09:27:01 --> Output Class Initialized
INFO - 2017-01-27 09:27:01 --> Security Class Initialized
DEBUG - 2017-01-27 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:27:01 --> Input Class Initialized
INFO - 2017-01-27 09:27:01 --> Language Class Initialized
INFO - 2017-01-27 09:27:01 --> Loader Class Initialized
INFO - 2017-01-27 09:27:01 --> Helper loaded: url_helper
INFO - 2017-01-27 09:27:01 --> Helper loaded: language_helper
INFO - 2017-01-27 09:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:27:01 --> Controller Class Initialized
INFO - 2017-01-27 09:27:01 --> Database Driver Class Initialized
INFO - 2017-01-27 09:27:01 --> Model Class Initialized
INFO - 2017-01-27 09:27:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:27:01 --> Model Class Initialized
INFO - 2017-01-27 09:27:01 --> Model Class Initialized
INFO - 2017-01-27 09:27:01 --> Helper loaded: form_helper
INFO - 2017-01-27 09:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:27:01 --> Final output sent to browser
DEBUG - 2017-01-27 09:27:01 --> Total execution time: 0.1057
INFO - 2017-01-27 09:30:10 --> Config Class Initialized
INFO - 2017-01-27 09:30:10 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:30:10 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:30:10 --> Utf8 Class Initialized
INFO - 2017-01-27 09:30:10 --> URI Class Initialized
INFO - 2017-01-27 09:30:10 --> Router Class Initialized
INFO - 2017-01-27 09:30:10 --> Output Class Initialized
INFO - 2017-01-27 09:30:10 --> Security Class Initialized
DEBUG - 2017-01-27 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:30:10 --> Input Class Initialized
INFO - 2017-01-27 09:30:10 --> Language Class Initialized
INFO - 2017-01-27 09:30:10 --> Loader Class Initialized
INFO - 2017-01-27 09:30:10 --> Helper loaded: url_helper
INFO - 2017-01-27 09:30:10 --> Helper loaded: language_helper
INFO - 2017-01-27 09:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:30:10 --> Controller Class Initialized
INFO - 2017-01-27 09:30:10 --> Database Driver Class Initialized
INFO - 2017-01-27 09:30:10 --> Model Class Initialized
INFO - 2017-01-27 09:30:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:30:10 --> Model Class Initialized
INFO - 2017-01-27 09:30:10 --> Model Class Initialized
INFO - 2017-01-27 09:30:10 --> Helper loaded: form_helper
INFO - 2017-01-27 09:30:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:30:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:30:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:30:10 --> Final output sent to browser
DEBUG - 2017-01-27 09:30:10 --> Total execution time: 0.1045
INFO - 2017-01-27 09:31:33 --> Config Class Initialized
INFO - 2017-01-27 09:31:33 --> Hooks Class Initialized
DEBUG - 2017-01-27 09:31:33 --> UTF-8 Support Enabled
INFO - 2017-01-27 09:31:33 --> Utf8 Class Initialized
INFO - 2017-01-27 09:31:33 --> URI Class Initialized
INFO - 2017-01-27 09:31:33 --> Router Class Initialized
INFO - 2017-01-27 09:31:33 --> Output Class Initialized
INFO - 2017-01-27 09:31:33 --> Security Class Initialized
DEBUG - 2017-01-27 09:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 09:31:33 --> Input Class Initialized
INFO - 2017-01-27 09:31:33 --> Language Class Initialized
INFO - 2017-01-27 09:31:33 --> Loader Class Initialized
INFO - 2017-01-27 09:31:33 --> Helper loaded: url_helper
INFO - 2017-01-27 09:31:33 --> Helper loaded: language_helper
INFO - 2017-01-27 09:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 09:31:33 --> Controller Class Initialized
INFO - 2017-01-27 09:31:33 --> Database Driver Class Initialized
INFO - 2017-01-27 09:31:33 --> Model Class Initialized
INFO - 2017-01-27 09:31:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-01-27 09:31:33 --> Model Class Initialized
INFO - 2017-01-27 09:31:33 --> Model Class Initialized
INFO - 2017-01-27 09:31:33 --> Helper loaded: form_helper
INFO - 2017-01-27 09:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-01-27 09:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-01-27 09:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-01-27 09:31:33 --> Final output sent to browser
DEBUG - 2017-01-27 09:31:33 --> Total execution time: 0.1075
