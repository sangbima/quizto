<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-01 12:44:58 --> Config Class Initialized
INFO - 2017-02-01 12:44:58 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:44:58 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:44:58 --> Utf8 Class Initialized
INFO - 2017-02-01 12:44:58 --> URI Class Initialized
INFO - 2017-02-01 12:44:58 --> Router Class Initialized
INFO - 2017-02-01 12:44:58 --> Output Class Initialized
INFO - 2017-02-01 12:44:58 --> Security Class Initialized
DEBUG - 2017-02-01 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:44:58 --> Input Class Initialized
INFO - 2017-02-01 12:44:58 --> Language Class Initialized
INFO - 2017-02-01 12:44:58 --> Loader Class Initialized
INFO - 2017-02-01 12:44:58 --> Helper loaded: url_helper
INFO - 2017-02-01 12:44:58 --> Helper loaded: language_helper
INFO - 2017-02-01 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:44:58 --> Controller Class Initialized
INFO - 2017-02-01 12:44:58 --> Database Driver Class Initialized
INFO - 2017-02-01 12:44:58 --> Model Class Initialized
INFO - 2017-02-01 12:44:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:44:58 --> Config Class Initialized
INFO - 2017-02-01 12:44:58 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:44:58 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:44:58 --> Utf8 Class Initialized
INFO - 2017-02-01 12:44:58 --> URI Class Initialized
INFO - 2017-02-01 12:44:58 --> Router Class Initialized
INFO - 2017-02-01 12:44:58 --> Output Class Initialized
INFO - 2017-02-01 12:44:58 --> Security Class Initialized
DEBUG - 2017-02-01 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:44:58 --> Input Class Initialized
INFO - 2017-02-01 12:44:58 --> Language Class Initialized
INFO - 2017-02-01 12:44:58 --> Loader Class Initialized
INFO - 2017-02-01 12:44:58 --> Helper loaded: url_helper
INFO - 2017-02-01 12:44:58 --> Helper loaded: language_helper
INFO - 2017-02-01 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:44:58 --> Controller Class Initialized
INFO - 2017-02-01 12:44:59 --> Database Driver Class Initialized
INFO - 2017-02-01 12:44:59 --> Model Class Initialized
INFO - 2017-02-01 12:44:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:44:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-01 12:44:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-01 12:44:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-01 12:44:59 --> Final output sent to browser
DEBUG - 2017-02-01 12:44:59 --> Total execution time: 0.1723
INFO - 2017-02-01 12:45:08 --> Config Class Initialized
INFO - 2017-02-01 12:45:08 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:45:08 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:45:08 --> Utf8 Class Initialized
INFO - 2017-02-01 12:45:08 --> URI Class Initialized
INFO - 2017-02-01 12:45:08 --> Router Class Initialized
INFO - 2017-02-01 12:45:08 --> Output Class Initialized
INFO - 2017-02-01 12:45:08 --> Security Class Initialized
DEBUG - 2017-02-01 12:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:45:08 --> Input Class Initialized
INFO - 2017-02-01 12:45:08 --> Language Class Initialized
INFO - 2017-02-01 12:45:08 --> Loader Class Initialized
INFO - 2017-02-01 12:45:08 --> Helper loaded: url_helper
INFO - 2017-02-01 12:45:08 --> Helper loaded: language_helper
INFO - 2017-02-01 12:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:45:08 --> Controller Class Initialized
INFO - 2017-02-01 12:45:08 --> Database Driver Class Initialized
INFO - 2017-02-01 12:45:08 --> Model Class Initialized
INFO - 2017-02-01 12:45:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:45:08 --> Config Class Initialized
INFO - 2017-02-01 12:45:08 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:45:08 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:45:08 --> Utf8 Class Initialized
INFO - 2017-02-01 12:45:08 --> URI Class Initialized
INFO - 2017-02-01 12:45:08 --> Router Class Initialized
INFO - 2017-02-01 12:45:08 --> Output Class Initialized
INFO - 2017-02-01 12:45:08 --> Security Class Initialized
DEBUG - 2017-02-01 12:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:45:08 --> Input Class Initialized
INFO - 2017-02-01 12:45:08 --> Language Class Initialized
INFO - 2017-02-01 12:45:08 --> Loader Class Initialized
INFO - 2017-02-01 12:45:08 --> Helper loaded: url_helper
INFO - 2017-02-01 12:45:08 --> Helper loaded: language_helper
INFO - 2017-02-01 12:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:45:08 --> Controller Class Initialized
INFO - 2017-02-01 12:45:08 --> Database Driver Class Initialized
INFO - 2017-02-01 12:45:08 --> Model Class Initialized
INFO - 2017-02-01 12:45:08 --> Model Class Initialized
INFO - 2017-02-01 12:45:08 --> Model Class Initialized
INFO - 2017-02-01 12:45:08 --> Model Class Initialized
INFO - 2017-02-01 12:45:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:45:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:45:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-01 12:45:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:45:08 --> Final output sent to browser
DEBUG - 2017-02-01 12:45:08 --> Total execution time: 0.1750
INFO - 2017-02-01 12:45:11 --> Config Class Initialized
INFO - 2017-02-01 12:45:11 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:45:11 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:45:11 --> Utf8 Class Initialized
INFO - 2017-02-01 12:45:11 --> URI Class Initialized
INFO - 2017-02-01 12:45:11 --> Router Class Initialized
INFO - 2017-02-01 12:45:11 --> Output Class Initialized
INFO - 2017-02-01 12:45:11 --> Security Class Initialized
DEBUG - 2017-02-01 12:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:45:11 --> Input Class Initialized
INFO - 2017-02-01 12:45:11 --> Language Class Initialized
INFO - 2017-02-01 12:45:11 --> Loader Class Initialized
INFO - 2017-02-01 12:45:11 --> Helper loaded: url_helper
INFO - 2017-02-01 12:45:11 --> Helper loaded: language_helper
INFO - 2017-02-01 12:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:45:11 --> Controller Class Initialized
INFO - 2017-02-01 12:45:11 --> Database Driver Class Initialized
INFO - 2017-02-01 12:45:11 --> Model Class Initialized
INFO - 2017-02-01 12:45:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:45:11 --> Model Class Initialized
INFO - 2017-02-01 12:45:11 --> Helper loaded: form_helper
INFO - 2017-02-01 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:45:12 --> Final output sent to browser
DEBUG - 2017-02-01 12:45:12 --> Total execution time: 0.9607
INFO - 2017-02-01 12:47:49 --> Config Class Initialized
INFO - 2017-02-01 12:47:49 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:47:49 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:47:49 --> Utf8 Class Initialized
INFO - 2017-02-01 12:47:49 --> URI Class Initialized
INFO - 2017-02-01 12:47:50 --> Router Class Initialized
INFO - 2017-02-01 12:47:50 --> Output Class Initialized
INFO - 2017-02-01 12:47:50 --> Security Class Initialized
DEBUG - 2017-02-01 12:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:47:50 --> Input Class Initialized
INFO - 2017-02-01 12:47:50 --> Language Class Initialized
INFO - 2017-02-01 12:47:50 --> Loader Class Initialized
INFO - 2017-02-01 12:47:50 --> Helper loaded: url_helper
INFO - 2017-02-01 12:47:50 --> Helper loaded: language_helper
INFO - 2017-02-01 12:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:47:50 --> Controller Class Initialized
INFO - 2017-02-01 12:47:50 --> Database Driver Class Initialized
INFO - 2017-02-01 12:47:50 --> Model Class Initialized
INFO - 2017-02-01 12:47:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:47:50 --> Model Class Initialized
INFO - 2017-02-01 12:47:50 --> Helper loaded: form_helper
INFO - 2017-02-01 12:47:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:47:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:47:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:47:50 --> Final output sent to browser
DEBUG - 2017-02-01 12:47:50 --> Total execution time: 0.1233
INFO - 2017-02-01 12:48:37 --> Config Class Initialized
INFO - 2017-02-01 12:48:37 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:48:37 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:48:37 --> Utf8 Class Initialized
INFO - 2017-02-01 12:48:37 --> URI Class Initialized
INFO - 2017-02-01 12:48:37 --> Router Class Initialized
INFO - 2017-02-01 12:48:37 --> Output Class Initialized
INFO - 2017-02-01 12:48:37 --> Security Class Initialized
DEBUG - 2017-02-01 12:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:48:37 --> Input Class Initialized
INFO - 2017-02-01 12:48:37 --> Language Class Initialized
INFO - 2017-02-01 12:48:37 --> Loader Class Initialized
INFO - 2017-02-01 12:48:37 --> Helper loaded: url_helper
INFO - 2017-02-01 12:48:37 --> Helper loaded: language_helper
INFO - 2017-02-01 12:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:48:37 --> Controller Class Initialized
INFO - 2017-02-01 12:48:37 --> Database Driver Class Initialized
INFO - 2017-02-01 12:48:37 --> Model Class Initialized
INFO - 2017-02-01 12:48:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:48:37 --> Model Class Initialized
INFO - 2017-02-01 12:48:37 --> Helper loaded: form_helper
INFO - 2017-02-01 12:48:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:48:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:48:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:48:38 --> Final output sent to browser
DEBUG - 2017-02-01 12:48:38 --> Total execution time: 0.1383
INFO - 2017-02-01 12:49:36 --> Config Class Initialized
INFO - 2017-02-01 12:49:36 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:49:36 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:49:36 --> Utf8 Class Initialized
INFO - 2017-02-01 12:49:36 --> URI Class Initialized
INFO - 2017-02-01 12:49:36 --> Router Class Initialized
INFO - 2017-02-01 12:49:36 --> Output Class Initialized
INFO - 2017-02-01 12:49:36 --> Security Class Initialized
DEBUG - 2017-02-01 12:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:49:36 --> Input Class Initialized
INFO - 2017-02-01 12:49:36 --> Language Class Initialized
INFO - 2017-02-01 12:49:36 --> Loader Class Initialized
INFO - 2017-02-01 12:49:36 --> Helper loaded: url_helper
INFO - 2017-02-01 12:49:36 --> Helper loaded: language_helper
INFO - 2017-02-01 12:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:49:36 --> Controller Class Initialized
INFO - 2017-02-01 12:49:36 --> Database Driver Class Initialized
INFO - 2017-02-01 12:49:36 --> Model Class Initialized
INFO - 2017-02-01 12:49:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:49:36 --> Model Class Initialized
INFO - 2017-02-01 12:49:36 --> Helper loaded: form_helper
INFO - 2017-02-01 12:49:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:49:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:49:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:49:36 --> Final output sent to browser
DEBUG - 2017-02-01 12:49:36 --> Total execution time: 0.2318
INFO - 2017-02-01 12:49:59 --> Config Class Initialized
INFO - 2017-02-01 12:49:59 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:49:59 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:49:59 --> Utf8 Class Initialized
INFO - 2017-02-01 12:49:59 --> URI Class Initialized
INFO - 2017-02-01 12:49:59 --> Router Class Initialized
INFO - 2017-02-01 12:49:59 --> Output Class Initialized
INFO - 2017-02-01 12:49:59 --> Security Class Initialized
DEBUG - 2017-02-01 12:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:49:59 --> Input Class Initialized
INFO - 2017-02-01 12:49:59 --> Language Class Initialized
INFO - 2017-02-01 12:49:59 --> Loader Class Initialized
INFO - 2017-02-01 12:49:59 --> Helper loaded: url_helper
INFO - 2017-02-01 12:49:59 --> Helper loaded: language_helper
INFO - 2017-02-01 12:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:49:59 --> Controller Class Initialized
INFO - 2017-02-01 12:49:59 --> Database Driver Class Initialized
INFO - 2017-02-01 12:49:59 --> Model Class Initialized
INFO - 2017-02-01 12:49:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:49:59 --> Model Class Initialized
INFO - 2017-02-01 12:49:59 --> Helper loaded: form_helper
INFO - 2017-02-01 12:49:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:49:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:49:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:49:59 --> Final output sent to browser
DEBUG - 2017-02-01 12:49:59 --> Total execution time: 0.1173
INFO - 2017-02-01 12:50:43 --> Config Class Initialized
INFO - 2017-02-01 12:50:43 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:50:43 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:50:43 --> Utf8 Class Initialized
INFO - 2017-02-01 12:50:43 --> URI Class Initialized
INFO - 2017-02-01 12:50:43 --> Router Class Initialized
INFO - 2017-02-01 12:50:43 --> Output Class Initialized
INFO - 2017-02-01 12:50:43 --> Security Class Initialized
DEBUG - 2017-02-01 12:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:50:43 --> Input Class Initialized
INFO - 2017-02-01 12:50:43 --> Language Class Initialized
INFO - 2017-02-01 12:50:43 --> Loader Class Initialized
INFO - 2017-02-01 12:50:43 --> Helper loaded: url_helper
INFO - 2017-02-01 12:50:43 --> Helper loaded: language_helper
INFO - 2017-02-01 12:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:50:43 --> Controller Class Initialized
INFO - 2017-02-01 12:50:43 --> Database Driver Class Initialized
INFO - 2017-02-01 12:50:43 --> Model Class Initialized
INFO - 2017-02-01 12:50:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:50:43 --> Model Class Initialized
INFO - 2017-02-01 12:50:43 --> Helper loaded: form_helper
INFO - 2017-02-01 12:50:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:50:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:50:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:50:43 --> Final output sent to browser
DEBUG - 2017-02-01 12:50:43 --> Total execution time: 0.2340
INFO - 2017-02-01 12:51:39 --> Config Class Initialized
INFO - 2017-02-01 12:51:39 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:51:39 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:51:39 --> Utf8 Class Initialized
INFO - 2017-02-01 12:51:39 --> URI Class Initialized
INFO - 2017-02-01 12:51:39 --> Router Class Initialized
INFO - 2017-02-01 12:51:39 --> Output Class Initialized
INFO - 2017-02-01 12:51:39 --> Security Class Initialized
DEBUG - 2017-02-01 12:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:51:39 --> Input Class Initialized
INFO - 2017-02-01 12:51:39 --> Language Class Initialized
INFO - 2017-02-01 12:51:39 --> Loader Class Initialized
INFO - 2017-02-01 12:51:39 --> Helper loaded: url_helper
INFO - 2017-02-01 12:51:39 --> Helper loaded: language_helper
INFO - 2017-02-01 12:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:51:39 --> Controller Class Initialized
INFO - 2017-02-01 12:51:39 --> Database Driver Class Initialized
INFO - 2017-02-01 12:51:39 --> Model Class Initialized
INFO - 2017-02-01 12:51:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:51:39 --> Model Class Initialized
INFO - 2017-02-01 12:51:39 --> Helper loaded: form_helper
INFO - 2017-02-01 12:51:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:51:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:51:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:51:39 --> Final output sent to browser
DEBUG - 2017-02-01 12:51:39 --> Total execution time: 0.1129
INFO - 2017-02-01 12:51:57 --> Config Class Initialized
INFO - 2017-02-01 12:51:57 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:51:57 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:51:57 --> Utf8 Class Initialized
INFO - 2017-02-01 12:51:57 --> URI Class Initialized
INFO - 2017-02-01 12:51:57 --> Router Class Initialized
INFO - 2017-02-01 12:51:57 --> Output Class Initialized
INFO - 2017-02-01 12:51:57 --> Security Class Initialized
DEBUG - 2017-02-01 12:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:51:57 --> Input Class Initialized
INFO - 2017-02-01 12:51:57 --> Language Class Initialized
INFO - 2017-02-01 12:51:57 --> Loader Class Initialized
INFO - 2017-02-01 12:51:57 --> Helper loaded: url_helper
INFO - 2017-02-01 12:51:57 --> Helper loaded: language_helper
INFO - 2017-02-01 12:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:51:57 --> Controller Class Initialized
INFO - 2017-02-01 12:51:57 --> Database Driver Class Initialized
INFO - 2017-02-01 12:51:57 --> Model Class Initialized
INFO - 2017-02-01 12:51:57 --> Model Class Initialized
INFO - 2017-02-01 12:51:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:51:57 --> Config Class Initialized
INFO - 2017-02-01 12:51:57 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:51:57 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:51:57 --> Utf8 Class Initialized
INFO - 2017-02-01 12:51:57 --> URI Class Initialized
INFO - 2017-02-01 12:51:57 --> Router Class Initialized
INFO - 2017-02-01 12:51:57 --> Output Class Initialized
INFO - 2017-02-01 12:51:57 --> Security Class Initialized
DEBUG - 2017-02-01 12:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:51:57 --> Input Class Initialized
INFO - 2017-02-01 12:51:57 --> Language Class Initialized
INFO - 2017-02-01 12:51:57 --> Loader Class Initialized
INFO - 2017-02-01 12:51:57 --> Helper loaded: url_helper
INFO - 2017-02-01 12:51:57 --> Helper loaded: language_helper
INFO - 2017-02-01 12:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:51:57 --> Controller Class Initialized
INFO - 2017-02-01 12:51:57 --> Database Driver Class Initialized
INFO - 2017-02-01 12:51:57 --> Model Class Initialized
INFO - 2017-02-01 12:51:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-01 12:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-01 12:51:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-01 12:51:57 --> Final output sent to browser
DEBUG - 2017-02-01 12:51:57 --> Total execution time: 0.0833
INFO - 2017-02-01 12:52:04 --> Config Class Initialized
INFO - 2017-02-01 12:52:04 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:04 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:04 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:04 --> URI Class Initialized
INFO - 2017-02-01 12:52:04 --> Router Class Initialized
INFO - 2017-02-01 12:52:04 --> Output Class Initialized
INFO - 2017-02-01 12:52:04 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:04 --> Input Class Initialized
INFO - 2017-02-01 12:52:04 --> Language Class Initialized
INFO - 2017-02-01 12:52:04 --> Loader Class Initialized
INFO - 2017-02-01 12:52:04 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:04 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:04 --> Controller Class Initialized
INFO - 2017-02-01 12:52:04 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:04 --> Model Class Initialized
INFO - 2017-02-01 12:52:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:04 --> Config Class Initialized
INFO - 2017-02-01 12:52:04 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:04 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:04 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:04 --> URI Class Initialized
INFO - 2017-02-01 12:52:04 --> Router Class Initialized
INFO - 2017-02-01 12:52:04 --> Output Class Initialized
INFO - 2017-02-01 12:52:04 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:04 --> Input Class Initialized
INFO - 2017-02-01 12:52:04 --> Language Class Initialized
INFO - 2017-02-01 12:52:04 --> Loader Class Initialized
INFO - 2017-02-01 12:52:04 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:04 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:04 --> Controller Class Initialized
INFO - 2017-02-01 12:52:04 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:04 --> Model Class Initialized
INFO - 2017-02-01 12:52:04 --> Model Class Initialized
INFO - 2017-02-01 12:52:04 --> Model Class Initialized
INFO - 2017-02-01 12:52:04 --> Model Class Initialized
INFO - 2017-02-01 12:52:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:52:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-01 12:52:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:52:04 --> Final output sent to browser
DEBUG - 2017-02-01 12:52:04 --> Total execution time: 0.1612
INFO - 2017-02-01 12:52:07 --> Config Class Initialized
INFO - 2017-02-01 12:52:07 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:07 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:07 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:07 --> URI Class Initialized
INFO - 2017-02-01 12:52:07 --> Router Class Initialized
INFO - 2017-02-01 12:52:07 --> Output Class Initialized
INFO - 2017-02-01 12:52:07 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:07 --> Input Class Initialized
INFO - 2017-02-01 12:52:07 --> Language Class Initialized
INFO - 2017-02-01 12:52:07 --> Loader Class Initialized
INFO - 2017-02-01 12:52:07 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:07 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:07 --> Controller Class Initialized
INFO - 2017-02-01 12:52:07 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:07 --> Model Class Initialized
INFO - 2017-02-01 12:52:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:07 --> Model Class Initialized
INFO - 2017-02-01 12:52:07 --> Helper loaded: form_helper
INFO - 2017-02-01 12:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:52:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:52:07 --> Final output sent to browser
DEBUG - 2017-02-01 12:52:07 --> Total execution time: 0.0861
INFO - 2017-02-01 12:52:13 --> Config Class Initialized
INFO - 2017-02-01 12:52:13 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:13 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:13 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:13 --> URI Class Initialized
INFO - 2017-02-01 12:52:13 --> Router Class Initialized
INFO - 2017-02-01 12:52:13 --> Output Class Initialized
INFO - 2017-02-01 12:52:13 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:13 --> Input Class Initialized
INFO - 2017-02-01 12:52:13 --> Language Class Initialized
INFO - 2017-02-01 12:52:13 --> Loader Class Initialized
INFO - 2017-02-01 12:52:13 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:13 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:13 --> Controller Class Initialized
INFO - 2017-02-01 12:52:13 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:13 --> Model Class Initialized
INFO - 2017-02-01 12:52:13 --> Model Class Initialized
INFO - 2017-02-01 12:52:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:13 --> Config Class Initialized
INFO - 2017-02-01 12:52:13 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:13 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:13 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:13 --> URI Class Initialized
INFO - 2017-02-01 12:52:13 --> Router Class Initialized
INFO - 2017-02-01 12:52:13 --> Output Class Initialized
INFO - 2017-02-01 12:52:13 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:13 --> Input Class Initialized
INFO - 2017-02-01 12:52:13 --> Language Class Initialized
INFO - 2017-02-01 12:52:13 --> Loader Class Initialized
INFO - 2017-02-01 12:52:13 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:13 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:13 --> Controller Class Initialized
INFO - 2017-02-01 12:52:13 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:13 --> Model Class Initialized
INFO - 2017-02-01 12:52:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-01 12:52:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-01 12:52:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-01 12:52:13 --> Final output sent to browser
DEBUG - 2017-02-01 12:52:13 --> Total execution time: 0.1289
INFO - 2017-02-01 12:52:18 --> Config Class Initialized
INFO - 2017-02-01 12:52:18 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:18 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:18 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:18 --> URI Class Initialized
INFO - 2017-02-01 12:52:18 --> Router Class Initialized
INFO - 2017-02-01 12:52:18 --> Output Class Initialized
INFO - 2017-02-01 12:52:18 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:18 --> Input Class Initialized
INFO - 2017-02-01 12:52:18 --> Language Class Initialized
INFO - 2017-02-01 12:52:18 --> Loader Class Initialized
INFO - 2017-02-01 12:52:18 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:18 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:18 --> Controller Class Initialized
INFO - 2017-02-01 12:52:18 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:18 --> Model Class Initialized
INFO - 2017-02-01 12:52:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:18 --> Config Class Initialized
INFO - 2017-02-01 12:52:18 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:52:18 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:52:18 --> Utf8 Class Initialized
INFO - 2017-02-01 12:52:18 --> URI Class Initialized
INFO - 2017-02-01 12:52:18 --> Router Class Initialized
INFO - 2017-02-01 12:52:18 --> Output Class Initialized
INFO - 2017-02-01 12:52:18 --> Security Class Initialized
DEBUG - 2017-02-01 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:52:18 --> Input Class Initialized
INFO - 2017-02-01 12:52:18 --> Language Class Initialized
INFO - 2017-02-01 12:52:18 --> Loader Class Initialized
INFO - 2017-02-01 12:52:18 --> Helper loaded: url_helper
INFO - 2017-02-01 12:52:18 --> Helper loaded: language_helper
INFO - 2017-02-01 12:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:52:18 --> Controller Class Initialized
INFO - 2017-02-01 12:52:18 --> Database Driver Class Initialized
INFO - 2017-02-01 12:52:18 --> Model Class Initialized
INFO - 2017-02-01 12:52:18 --> Model Class Initialized
INFO - 2017-02-01 12:52:18 --> Model Class Initialized
INFO - 2017-02-01 12:52:18 --> Model Class Initialized
INFO - 2017-02-01 12:52:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:52:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:52:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-01 12:52:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:52:18 --> Final output sent to browser
DEBUG - 2017-02-01 12:52:18 --> Total execution time: 0.1395
INFO - 2017-02-01 12:53:32 --> Config Class Initialized
INFO - 2017-02-01 12:53:32 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:53:32 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:53:32 --> Utf8 Class Initialized
INFO - 2017-02-01 12:53:32 --> URI Class Initialized
INFO - 2017-02-01 12:53:32 --> Router Class Initialized
INFO - 2017-02-01 12:53:32 --> Output Class Initialized
INFO - 2017-02-01 12:53:32 --> Security Class Initialized
DEBUG - 2017-02-01 12:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:53:32 --> Input Class Initialized
INFO - 2017-02-01 12:53:32 --> Language Class Initialized
INFO - 2017-02-01 12:53:32 --> Loader Class Initialized
INFO - 2017-02-01 12:53:32 --> Helper loaded: url_helper
INFO - 2017-02-01 12:53:32 --> Helper loaded: language_helper
INFO - 2017-02-01 12:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:53:32 --> Controller Class Initialized
INFO - 2017-02-01 12:53:32 --> Database Driver Class Initialized
INFO - 2017-02-01 12:53:32 --> Model Class Initialized
INFO - 2017-02-01 12:53:32 --> Model Class Initialized
INFO - 2017-02-01 12:53:32 --> Model Class Initialized
INFO - 2017-02-01 12:53:32 --> Model Class Initialized
INFO - 2017-02-01 12:53:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:53:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:53:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-01 12:53:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:53:32 --> Final output sent to browser
DEBUG - 2017-02-01 12:53:32 --> Total execution time: 0.1427
INFO - 2017-02-01 12:53:37 --> Config Class Initialized
INFO - 2017-02-01 12:53:37 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:53:37 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:53:37 --> Utf8 Class Initialized
INFO - 2017-02-01 12:53:37 --> URI Class Initialized
INFO - 2017-02-01 12:53:37 --> Router Class Initialized
INFO - 2017-02-01 12:53:37 --> Output Class Initialized
INFO - 2017-02-01 12:53:37 --> Security Class Initialized
DEBUG - 2017-02-01 12:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:53:37 --> Input Class Initialized
INFO - 2017-02-01 12:53:37 --> Language Class Initialized
INFO - 2017-02-01 12:53:37 --> Loader Class Initialized
INFO - 2017-02-01 12:53:37 --> Helper loaded: url_helper
INFO - 2017-02-01 12:53:37 --> Helper loaded: language_helper
INFO - 2017-02-01 12:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:53:37 --> Controller Class Initialized
INFO - 2017-02-01 12:53:37 --> Database Driver Class Initialized
INFO - 2017-02-01 12:53:37 --> Model Class Initialized
INFO - 2017-02-01 12:53:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:53:37 --> Model Class Initialized
INFO - 2017-02-01 12:53:37 --> Helper loaded: form_helper
INFO - 2017-02-01 12:53:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:53:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:53:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:53:37 --> Final output sent to browser
DEBUG - 2017-02-01 12:53:37 --> Total execution time: 0.1054
INFO - 2017-02-01 12:54:20 --> Config Class Initialized
INFO - 2017-02-01 12:54:20 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:54:20 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:54:20 --> Utf8 Class Initialized
INFO - 2017-02-01 12:54:20 --> URI Class Initialized
INFO - 2017-02-01 12:54:20 --> Router Class Initialized
INFO - 2017-02-01 12:54:20 --> Output Class Initialized
INFO - 2017-02-01 12:54:20 --> Security Class Initialized
DEBUG - 2017-02-01 12:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:54:20 --> Input Class Initialized
INFO - 2017-02-01 12:54:20 --> Language Class Initialized
INFO - 2017-02-01 12:54:20 --> Loader Class Initialized
INFO - 2017-02-01 12:54:20 --> Helper loaded: url_helper
INFO - 2017-02-01 12:54:20 --> Helper loaded: language_helper
INFO - 2017-02-01 12:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:54:20 --> Controller Class Initialized
INFO - 2017-02-01 12:54:20 --> Database Driver Class Initialized
INFO - 2017-02-01 12:54:20 --> Model Class Initialized
INFO - 2017-02-01 12:54:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:54:20 --> Model Class Initialized
INFO - 2017-02-01 12:54:20 --> Helper loaded: form_helper
INFO - 2017-02-01 12:54:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:54:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:54:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:54:20 --> Final output sent to browser
DEBUG - 2017-02-01 12:54:20 --> Total execution time: 0.1372
INFO - 2017-02-01 12:54:44 --> Config Class Initialized
INFO - 2017-02-01 12:54:44 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:54:44 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:54:44 --> Utf8 Class Initialized
INFO - 2017-02-01 12:54:44 --> URI Class Initialized
INFO - 2017-02-01 12:54:44 --> Router Class Initialized
INFO - 2017-02-01 12:54:44 --> Output Class Initialized
INFO - 2017-02-01 12:54:44 --> Security Class Initialized
DEBUG - 2017-02-01 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:54:44 --> Input Class Initialized
INFO - 2017-02-01 12:54:44 --> Language Class Initialized
INFO - 2017-02-01 12:54:44 --> Loader Class Initialized
INFO - 2017-02-01 12:54:44 --> Helper loaded: url_helper
INFO - 2017-02-01 12:54:44 --> Helper loaded: language_helper
INFO - 2017-02-01 12:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:54:44 --> Controller Class Initialized
INFO - 2017-02-01 12:54:44 --> Database Driver Class Initialized
INFO - 2017-02-01 12:54:44 --> Model Class Initialized
INFO - 2017-02-01 12:54:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:54:44 --> Model Class Initialized
INFO - 2017-02-01 12:54:44 --> Helper loaded: form_helper
INFO - 2017-02-01 12:54:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:54:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:54:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:54:44 --> Final output sent to browser
DEBUG - 2017-02-01 12:54:44 --> Total execution time: 0.1032
INFO - 2017-02-01 12:55:15 --> Config Class Initialized
INFO - 2017-02-01 12:55:15 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:55:15 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:55:15 --> Utf8 Class Initialized
INFO - 2017-02-01 12:55:15 --> URI Class Initialized
INFO - 2017-02-01 12:55:15 --> Router Class Initialized
INFO - 2017-02-01 12:55:15 --> Output Class Initialized
INFO - 2017-02-01 12:55:15 --> Security Class Initialized
DEBUG - 2017-02-01 12:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:55:15 --> Input Class Initialized
INFO - 2017-02-01 12:55:15 --> Language Class Initialized
INFO - 2017-02-01 12:55:15 --> Loader Class Initialized
INFO - 2017-02-01 12:55:15 --> Helper loaded: url_helper
INFO - 2017-02-01 12:55:15 --> Helper loaded: language_helper
INFO - 2017-02-01 12:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:55:15 --> Controller Class Initialized
INFO - 2017-02-01 12:55:15 --> Database Driver Class Initialized
INFO - 2017-02-01 12:55:15 --> Model Class Initialized
INFO - 2017-02-01 12:55:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:55:15 --> Model Class Initialized
INFO - 2017-02-01 12:55:15 --> Helper loaded: form_helper
INFO - 2017-02-01 12:55:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:55:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:55:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:55:15 --> Final output sent to browser
DEBUG - 2017-02-01 12:55:15 --> Total execution time: 0.1095
INFO - 2017-02-01 12:56:37 --> Config Class Initialized
INFO - 2017-02-01 12:56:37 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:56:37 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:56:37 --> Utf8 Class Initialized
INFO - 2017-02-01 12:56:37 --> URI Class Initialized
INFO - 2017-02-01 12:56:37 --> Router Class Initialized
INFO - 2017-02-01 12:56:37 --> Output Class Initialized
INFO - 2017-02-01 12:56:37 --> Security Class Initialized
DEBUG - 2017-02-01 12:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:56:37 --> Input Class Initialized
INFO - 2017-02-01 12:56:37 --> Language Class Initialized
INFO - 2017-02-01 12:56:37 --> Loader Class Initialized
INFO - 2017-02-01 12:56:37 --> Helper loaded: url_helper
INFO - 2017-02-01 12:56:37 --> Helper loaded: language_helper
INFO - 2017-02-01 12:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:56:37 --> Controller Class Initialized
INFO - 2017-02-01 12:56:37 --> Database Driver Class Initialized
INFO - 2017-02-01 12:56:37 --> Model Class Initialized
INFO - 2017-02-01 12:56:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:56:37 --> Model Class Initialized
INFO - 2017-02-01 12:56:37 --> Helper loaded: form_helper
INFO - 2017-02-01 12:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:56:37 --> Final output sent to browser
DEBUG - 2017-02-01 12:56:37 --> Total execution time: 0.1551
INFO - 2017-02-01 12:56:44 --> Config Class Initialized
INFO - 2017-02-01 12:56:44 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:56:44 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:56:44 --> Utf8 Class Initialized
INFO - 2017-02-01 12:56:44 --> URI Class Initialized
INFO - 2017-02-01 12:56:44 --> Router Class Initialized
INFO - 2017-02-01 12:56:44 --> Output Class Initialized
INFO - 2017-02-01 12:56:44 --> Security Class Initialized
DEBUG - 2017-02-01 12:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:56:44 --> Input Class Initialized
INFO - 2017-02-01 12:56:44 --> Language Class Initialized
INFO - 2017-02-01 12:56:44 --> Loader Class Initialized
INFO - 2017-02-01 12:56:44 --> Helper loaded: url_helper
INFO - 2017-02-01 12:56:44 --> Helper loaded: language_helper
INFO - 2017-02-01 12:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:56:44 --> Controller Class Initialized
INFO - 2017-02-01 12:56:44 --> Database Driver Class Initialized
INFO - 2017-02-01 12:56:44 --> Model Class Initialized
INFO - 2017-02-01 12:56:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:56:44 --> Model Class Initialized
INFO - 2017-02-01 12:56:44 --> Helper loaded: form_helper
INFO - 2017-02-01 12:56:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:56:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:56:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:56:44 --> Final output sent to browser
DEBUG - 2017-02-01 12:56:44 --> Total execution time: 0.2261
INFO - 2017-02-01 12:56:53 --> Config Class Initialized
INFO - 2017-02-01 12:56:53 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:56:53 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:56:53 --> Utf8 Class Initialized
INFO - 2017-02-01 12:56:53 --> URI Class Initialized
INFO - 2017-02-01 12:56:53 --> Router Class Initialized
INFO - 2017-02-01 12:56:53 --> Output Class Initialized
INFO - 2017-02-01 12:56:53 --> Security Class Initialized
DEBUG - 2017-02-01 12:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:56:53 --> Input Class Initialized
INFO - 2017-02-01 12:56:53 --> Language Class Initialized
INFO - 2017-02-01 12:56:53 --> Loader Class Initialized
INFO - 2017-02-01 12:56:53 --> Helper loaded: url_helper
INFO - 2017-02-01 12:56:53 --> Helper loaded: language_helper
INFO - 2017-02-01 12:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:56:53 --> Controller Class Initialized
INFO - 2017-02-01 12:56:53 --> Database Driver Class Initialized
INFO - 2017-02-01 12:56:53 --> Model Class Initialized
INFO - 2017-02-01 12:56:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:56:53 --> Model Class Initialized
INFO - 2017-02-01 12:56:53 --> Helper loaded: form_helper
INFO - 2017-02-01 12:56:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:56:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:56:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:56:53 --> Final output sent to browser
DEBUG - 2017-02-01 12:56:53 --> Total execution time: 0.1471
INFO - 2017-02-01 12:56:58 --> Config Class Initialized
INFO - 2017-02-01 12:56:58 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:56:58 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:56:58 --> Utf8 Class Initialized
INFO - 2017-02-01 12:56:58 --> URI Class Initialized
INFO - 2017-02-01 12:56:58 --> Router Class Initialized
INFO - 2017-02-01 12:56:58 --> Output Class Initialized
INFO - 2017-02-01 12:56:58 --> Security Class Initialized
DEBUG - 2017-02-01 12:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:56:58 --> Input Class Initialized
INFO - 2017-02-01 12:56:58 --> Language Class Initialized
INFO - 2017-02-01 12:56:58 --> Loader Class Initialized
INFO - 2017-02-01 12:56:58 --> Helper loaded: url_helper
INFO - 2017-02-01 12:56:58 --> Helper loaded: language_helper
INFO - 2017-02-01 12:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:56:58 --> Controller Class Initialized
INFO - 2017-02-01 12:56:59 --> Database Driver Class Initialized
INFO - 2017-02-01 12:56:59 --> Model Class Initialized
INFO - 2017-02-01 12:56:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:56:59 --> Model Class Initialized
INFO - 2017-02-01 12:56:59 --> Helper loaded: form_helper
INFO - 2017-02-01 12:56:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:56:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:56:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:56:59 --> Final output sent to browser
DEBUG - 2017-02-01 12:56:59 --> Total execution time: 0.2587
INFO - 2017-02-01 12:57:08 --> Config Class Initialized
INFO - 2017-02-01 12:57:08 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:57:08 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:57:08 --> Utf8 Class Initialized
INFO - 2017-02-01 12:57:08 --> URI Class Initialized
INFO - 2017-02-01 12:57:08 --> Router Class Initialized
INFO - 2017-02-01 12:57:08 --> Output Class Initialized
INFO - 2017-02-01 12:57:08 --> Security Class Initialized
DEBUG - 2017-02-01 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:57:08 --> Input Class Initialized
INFO - 2017-02-01 12:57:08 --> Language Class Initialized
INFO - 2017-02-01 12:57:08 --> Loader Class Initialized
INFO - 2017-02-01 12:57:08 --> Helper loaded: url_helper
INFO - 2017-02-01 12:57:08 --> Helper loaded: language_helper
INFO - 2017-02-01 12:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:57:08 --> Controller Class Initialized
INFO - 2017-02-01 12:57:08 --> Database Driver Class Initialized
INFO - 2017-02-01 12:57:08 --> Model Class Initialized
INFO - 2017-02-01 12:57:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:57:08 --> Model Class Initialized
INFO - 2017-02-01 12:57:08 --> Helper loaded: form_helper
INFO - 2017-02-01 12:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:57:08 --> Final output sent to browser
DEBUG - 2017-02-01 12:57:08 --> Total execution time: 0.1913
INFO - 2017-02-01 12:57:15 --> Config Class Initialized
INFO - 2017-02-01 12:57:15 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:57:15 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:57:15 --> Utf8 Class Initialized
INFO - 2017-02-01 12:57:15 --> URI Class Initialized
INFO - 2017-02-01 12:57:15 --> Router Class Initialized
INFO - 2017-02-01 12:57:15 --> Output Class Initialized
INFO - 2017-02-01 12:57:15 --> Security Class Initialized
DEBUG - 2017-02-01 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:57:15 --> Input Class Initialized
INFO - 2017-02-01 12:57:15 --> Language Class Initialized
INFO - 2017-02-01 12:57:15 --> Loader Class Initialized
INFO - 2017-02-01 12:57:15 --> Helper loaded: url_helper
INFO - 2017-02-01 12:57:15 --> Helper loaded: language_helper
INFO - 2017-02-01 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:57:15 --> Controller Class Initialized
INFO - 2017-02-01 12:57:15 --> Database Driver Class Initialized
INFO - 2017-02-01 12:57:15 --> Model Class Initialized
INFO - 2017-02-01 12:57:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:57:15 --> Model Class Initialized
INFO - 2017-02-01 12:57:15 --> Helper loaded: form_helper
INFO - 2017-02-01 12:57:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:57:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:57:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:57:15 --> Final output sent to browser
DEBUG - 2017-02-01 12:57:15 --> Total execution time: 0.1931
INFO - 2017-02-01 12:57:26 --> Config Class Initialized
INFO - 2017-02-01 12:57:26 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:57:26 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:57:26 --> Utf8 Class Initialized
INFO - 2017-02-01 12:57:26 --> URI Class Initialized
INFO - 2017-02-01 12:57:26 --> Router Class Initialized
INFO - 2017-02-01 12:57:26 --> Output Class Initialized
INFO - 2017-02-01 12:57:26 --> Security Class Initialized
DEBUG - 2017-02-01 12:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:57:26 --> Input Class Initialized
INFO - 2017-02-01 12:57:26 --> Language Class Initialized
INFO - 2017-02-01 12:57:26 --> Loader Class Initialized
INFO - 2017-02-01 12:57:27 --> Helper loaded: url_helper
INFO - 2017-02-01 12:57:27 --> Helper loaded: language_helper
INFO - 2017-02-01 12:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:57:27 --> Controller Class Initialized
INFO - 2017-02-01 12:57:27 --> Database Driver Class Initialized
INFO - 2017-02-01 12:57:27 --> Model Class Initialized
INFO - 2017-02-01 12:57:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:57:27 --> Model Class Initialized
INFO - 2017-02-01 12:57:27 --> Helper loaded: form_helper
INFO - 2017-02-01 12:57:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:57:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:57:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:57:27 --> Final output sent to browser
DEBUG - 2017-02-01 12:57:27 --> Total execution time: 0.1404
INFO - 2017-02-01 12:58:12 --> Config Class Initialized
INFO - 2017-02-01 12:58:12 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:58:12 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:58:12 --> Utf8 Class Initialized
INFO - 2017-02-01 12:58:12 --> URI Class Initialized
INFO - 2017-02-01 12:58:12 --> Router Class Initialized
INFO - 2017-02-01 12:58:12 --> Output Class Initialized
INFO - 2017-02-01 12:58:12 --> Security Class Initialized
DEBUG - 2017-02-01 12:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:58:12 --> Input Class Initialized
INFO - 2017-02-01 12:58:12 --> Language Class Initialized
INFO - 2017-02-01 12:58:12 --> Loader Class Initialized
INFO - 2017-02-01 12:58:12 --> Helper loaded: url_helper
INFO - 2017-02-01 12:58:12 --> Helper loaded: language_helper
INFO - 2017-02-01 12:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:58:12 --> Controller Class Initialized
INFO - 2017-02-01 12:58:12 --> Database Driver Class Initialized
INFO - 2017-02-01 12:58:12 --> Model Class Initialized
INFO - 2017-02-01 12:58:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:58:12 --> Model Class Initialized
INFO - 2017-02-01 12:58:12 --> Helper loaded: form_helper
INFO - 2017-02-01 12:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:58:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:58:12 --> Final output sent to browser
DEBUG - 2017-02-01 12:58:12 --> Total execution time: 0.1998
INFO - 2017-02-01 12:58:47 --> Config Class Initialized
INFO - 2017-02-01 12:58:47 --> Hooks Class Initialized
DEBUG - 2017-02-01 12:58:47 --> UTF-8 Support Enabled
INFO - 2017-02-01 12:58:47 --> Utf8 Class Initialized
INFO - 2017-02-01 12:58:47 --> URI Class Initialized
INFO - 2017-02-01 12:58:47 --> Router Class Initialized
INFO - 2017-02-01 12:58:47 --> Output Class Initialized
INFO - 2017-02-01 12:58:47 --> Security Class Initialized
DEBUG - 2017-02-01 12:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 12:58:47 --> Input Class Initialized
INFO - 2017-02-01 12:58:47 --> Language Class Initialized
INFO - 2017-02-01 12:58:47 --> Loader Class Initialized
INFO - 2017-02-01 12:58:47 --> Helper loaded: url_helper
INFO - 2017-02-01 12:58:47 --> Helper loaded: language_helper
INFO - 2017-02-01 12:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 12:58:47 --> Controller Class Initialized
INFO - 2017-02-01 12:58:47 --> Database Driver Class Initialized
INFO - 2017-02-01 12:58:47 --> Model Class Initialized
INFO - 2017-02-01 12:58:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 12:58:47 --> Model Class Initialized
INFO - 2017-02-01 12:58:47 --> Helper loaded: form_helper
INFO - 2017-02-01 12:58:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 12:58:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 12:58:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 12:58:47 --> Final output sent to browser
DEBUG - 2017-02-01 12:58:47 --> Total execution time: 0.1364
INFO - 2017-02-01 13:05:13 --> Config Class Initialized
INFO - 2017-02-01 13:05:13 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:05:13 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:05:13 --> Utf8 Class Initialized
INFO - 2017-02-01 13:05:13 --> URI Class Initialized
INFO - 2017-02-01 13:05:13 --> Router Class Initialized
INFO - 2017-02-01 13:05:13 --> Output Class Initialized
INFO - 2017-02-01 13:05:13 --> Security Class Initialized
DEBUG - 2017-02-01 13:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:05:13 --> Input Class Initialized
INFO - 2017-02-01 13:05:13 --> Language Class Initialized
INFO - 2017-02-01 13:05:13 --> Loader Class Initialized
INFO - 2017-02-01 13:05:13 --> Helper loaded: url_helper
INFO - 2017-02-01 13:05:13 --> Helper loaded: language_helper
INFO - 2017-02-01 13:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:05:13 --> Controller Class Initialized
INFO - 2017-02-01 13:05:13 --> Database Driver Class Initialized
INFO - 2017-02-01 13:05:13 --> Model Class Initialized
INFO - 2017-02-01 13:05:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:05:13 --> Model Class Initialized
INFO - 2017-02-01 13:05:13 --> Helper loaded: form_helper
INFO - 2017-02-01 13:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:05:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:05:13 --> Final output sent to browser
DEBUG - 2017-02-01 13:05:13 --> Total execution time: 0.0977
INFO - 2017-02-01 13:06:09 --> Config Class Initialized
INFO - 2017-02-01 13:06:09 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:06:09 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:06:09 --> Utf8 Class Initialized
INFO - 2017-02-01 13:06:09 --> URI Class Initialized
INFO - 2017-02-01 13:06:09 --> Router Class Initialized
INFO - 2017-02-01 13:06:09 --> Output Class Initialized
INFO - 2017-02-01 13:06:09 --> Security Class Initialized
DEBUG - 2017-02-01 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:06:09 --> Input Class Initialized
INFO - 2017-02-01 13:06:09 --> Language Class Initialized
INFO - 2017-02-01 13:06:09 --> Loader Class Initialized
INFO - 2017-02-01 13:06:09 --> Helper loaded: url_helper
INFO - 2017-02-01 13:06:09 --> Helper loaded: language_helper
INFO - 2017-02-01 13:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:06:09 --> Controller Class Initialized
INFO - 2017-02-01 13:06:09 --> Database Driver Class Initialized
INFO - 2017-02-01 13:06:09 --> Model Class Initialized
INFO - 2017-02-01 13:06:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:06:09 --> Model Class Initialized
INFO - 2017-02-01 13:06:09 --> Helper loaded: form_helper
INFO - 2017-02-01 13:06:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:06:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:06:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:06:09 --> Final output sent to browser
DEBUG - 2017-02-01 13:06:09 --> Total execution time: 0.1512
INFO - 2017-02-01 13:07:08 --> Config Class Initialized
INFO - 2017-02-01 13:07:08 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:07:08 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:07:08 --> Utf8 Class Initialized
INFO - 2017-02-01 13:07:08 --> URI Class Initialized
INFO - 2017-02-01 13:07:08 --> Router Class Initialized
INFO - 2017-02-01 13:07:08 --> Output Class Initialized
INFO - 2017-02-01 13:07:08 --> Security Class Initialized
DEBUG - 2017-02-01 13:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:07:08 --> Input Class Initialized
INFO - 2017-02-01 13:07:08 --> Language Class Initialized
INFO - 2017-02-01 13:07:08 --> Loader Class Initialized
INFO - 2017-02-01 13:07:08 --> Helper loaded: url_helper
INFO - 2017-02-01 13:07:08 --> Helper loaded: language_helper
INFO - 2017-02-01 13:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:07:08 --> Controller Class Initialized
INFO - 2017-02-01 13:07:08 --> Database Driver Class Initialized
INFO - 2017-02-01 13:07:08 --> Model Class Initialized
INFO - 2017-02-01 13:07:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:07:08 --> Model Class Initialized
INFO - 2017-02-01 13:07:08 --> Helper loaded: form_helper
INFO - 2017-02-01 13:07:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:07:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:07:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:07:09 --> Final output sent to browser
DEBUG - 2017-02-01 13:07:09 --> Total execution time: 0.4710
INFO - 2017-02-01 13:09:23 --> Config Class Initialized
INFO - 2017-02-01 13:09:23 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:09:23 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:09:23 --> Utf8 Class Initialized
INFO - 2017-02-01 13:09:23 --> URI Class Initialized
INFO - 2017-02-01 13:09:23 --> Router Class Initialized
INFO - 2017-02-01 13:09:23 --> Output Class Initialized
INFO - 2017-02-01 13:09:23 --> Security Class Initialized
DEBUG - 2017-02-01 13:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:09:23 --> Input Class Initialized
INFO - 2017-02-01 13:09:23 --> Language Class Initialized
INFO - 2017-02-01 13:09:23 --> Loader Class Initialized
INFO - 2017-02-01 13:09:23 --> Helper loaded: url_helper
INFO - 2017-02-01 13:09:23 --> Helper loaded: language_helper
INFO - 2017-02-01 13:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:09:23 --> Controller Class Initialized
INFO - 2017-02-01 13:09:23 --> Database Driver Class Initialized
INFO - 2017-02-01 13:09:23 --> Model Class Initialized
INFO - 2017-02-01 13:09:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:09:23 --> Model Class Initialized
INFO - 2017-02-01 13:09:23 --> Helper loaded: form_helper
INFO - 2017-02-01 13:09:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:09:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:09:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:09:23 --> Final output sent to browser
DEBUG - 2017-02-01 13:09:23 --> Total execution time: 0.1077
INFO - 2017-02-01 13:16:00 --> Config Class Initialized
INFO - 2017-02-01 13:16:00 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:16:00 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:16:00 --> Utf8 Class Initialized
INFO - 2017-02-01 13:16:00 --> URI Class Initialized
INFO - 2017-02-01 13:16:00 --> Router Class Initialized
INFO - 2017-02-01 13:16:00 --> Output Class Initialized
INFO - 2017-02-01 13:16:00 --> Security Class Initialized
DEBUG - 2017-02-01 13:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:16:00 --> Input Class Initialized
INFO - 2017-02-01 13:16:00 --> Language Class Initialized
INFO - 2017-02-01 13:16:00 --> Loader Class Initialized
INFO - 2017-02-01 13:16:00 --> Helper loaded: url_helper
INFO - 2017-02-01 13:16:00 --> Helper loaded: language_helper
INFO - 2017-02-01 13:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:16:00 --> Controller Class Initialized
INFO - 2017-02-01 13:16:00 --> Database Driver Class Initialized
INFO - 2017-02-01 13:16:00 --> Model Class Initialized
INFO - 2017-02-01 13:16:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:16:00 --> Model Class Initialized
INFO - 2017-02-01 13:16:00 --> Helper loaded: form_helper
INFO - 2017-02-01 13:16:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:16:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:16:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:16:00 --> Final output sent to browser
DEBUG - 2017-02-01 13:16:00 --> Total execution time: 0.1277
INFO - 2017-02-01 13:16:21 --> Config Class Initialized
INFO - 2017-02-01 13:16:21 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:16:21 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:16:21 --> Utf8 Class Initialized
INFO - 2017-02-01 13:16:21 --> URI Class Initialized
INFO - 2017-02-01 13:16:21 --> Router Class Initialized
INFO - 2017-02-01 13:16:21 --> Output Class Initialized
INFO - 2017-02-01 13:16:21 --> Security Class Initialized
DEBUG - 2017-02-01 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:16:21 --> Input Class Initialized
INFO - 2017-02-01 13:16:21 --> Language Class Initialized
INFO - 2017-02-01 13:16:21 --> Loader Class Initialized
INFO - 2017-02-01 13:16:21 --> Helper loaded: url_helper
INFO - 2017-02-01 13:16:21 --> Helper loaded: language_helper
INFO - 2017-02-01 13:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:16:21 --> Controller Class Initialized
INFO - 2017-02-01 13:16:21 --> Database Driver Class Initialized
INFO - 2017-02-01 13:16:21 --> Model Class Initialized
INFO - 2017-02-01 13:16:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:16:21 --> Model Class Initialized
INFO - 2017-02-01 13:16:21 --> Helper loaded: form_helper
INFO - 2017-02-01 13:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:16:21 --> Final output sent to browser
DEBUG - 2017-02-01 13:16:21 --> Total execution time: 0.1202
INFO - 2017-02-01 13:16:40 --> Config Class Initialized
INFO - 2017-02-01 13:16:40 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:16:40 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:16:40 --> Utf8 Class Initialized
INFO - 2017-02-01 13:16:40 --> URI Class Initialized
INFO - 2017-02-01 13:16:40 --> Router Class Initialized
INFO - 2017-02-01 13:16:40 --> Output Class Initialized
INFO - 2017-02-01 13:16:40 --> Security Class Initialized
DEBUG - 2017-02-01 13:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:16:40 --> Input Class Initialized
INFO - 2017-02-01 13:16:40 --> Language Class Initialized
INFO - 2017-02-01 13:16:40 --> Loader Class Initialized
INFO - 2017-02-01 13:16:40 --> Helper loaded: url_helper
INFO - 2017-02-01 13:16:40 --> Helper loaded: language_helper
INFO - 2017-02-01 13:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:16:40 --> Controller Class Initialized
INFO - 2017-02-01 13:16:40 --> Database Driver Class Initialized
INFO - 2017-02-01 13:16:40 --> Model Class Initialized
INFO - 2017-02-01 13:16:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:16:40 --> Model Class Initialized
INFO - 2017-02-01 13:16:40 --> Helper loaded: form_helper
INFO - 2017-02-01 13:16:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:16:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:16:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:16:40 --> Final output sent to browser
DEBUG - 2017-02-01 13:16:40 --> Total execution time: 0.1437
INFO - 2017-02-01 13:17:07 --> Config Class Initialized
INFO - 2017-02-01 13:17:07 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:17:07 --> Utf8 Class Initialized
INFO - 2017-02-01 13:17:07 --> URI Class Initialized
INFO - 2017-02-01 13:17:07 --> Router Class Initialized
INFO - 2017-02-01 13:17:07 --> Output Class Initialized
INFO - 2017-02-01 13:17:07 --> Security Class Initialized
DEBUG - 2017-02-01 13:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:17:07 --> Input Class Initialized
INFO - 2017-02-01 13:17:07 --> Language Class Initialized
INFO - 2017-02-01 13:17:07 --> Loader Class Initialized
INFO - 2017-02-01 13:17:07 --> Helper loaded: url_helper
INFO - 2017-02-01 13:17:07 --> Helper loaded: language_helper
INFO - 2017-02-01 13:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:17:07 --> Controller Class Initialized
INFO - 2017-02-01 13:17:07 --> Database Driver Class Initialized
INFO - 2017-02-01 13:17:07 --> Model Class Initialized
INFO - 2017-02-01 13:17:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:17:07 --> Model Class Initialized
INFO - 2017-02-01 13:17:07 --> Helper loaded: form_helper
INFO - 2017-02-01 13:17:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:17:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:17:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:17:07 --> Final output sent to browser
DEBUG - 2017-02-01 13:17:07 --> Total execution time: 0.1456
INFO - 2017-02-01 13:17:10 --> Config Class Initialized
INFO - 2017-02-01 13:17:10 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:17:10 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:17:10 --> Utf8 Class Initialized
INFO - 2017-02-01 13:17:10 --> URI Class Initialized
INFO - 2017-02-01 13:17:10 --> Router Class Initialized
INFO - 2017-02-01 13:17:10 --> Output Class Initialized
INFO - 2017-02-01 13:17:10 --> Security Class Initialized
DEBUG - 2017-02-01 13:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:17:10 --> Input Class Initialized
INFO - 2017-02-01 13:17:10 --> Language Class Initialized
INFO - 2017-02-01 13:17:10 --> Loader Class Initialized
INFO - 2017-02-01 13:17:10 --> Helper loaded: url_helper
INFO - 2017-02-01 13:17:10 --> Helper loaded: language_helper
INFO - 2017-02-01 13:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:17:10 --> Controller Class Initialized
INFO - 2017-02-01 13:17:10 --> Database Driver Class Initialized
INFO - 2017-02-01 13:17:10 --> Model Class Initialized
INFO - 2017-02-01 13:17:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:17:10 --> Model Class Initialized
INFO - 2017-02-01 13:17:10 --> Helper loaded: form_helper
INFO - 2017-02-01 13:17:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:17:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:17:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:17:10 --> Final output sent to browser
DEBUG - 2017-02-01 13:17:10 --> Total execution time: 0.1164
INFO - 2017-02-01 13:17:18 --> Config Class Initialized
INFO - 2017-02-01 13:17:18 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:17:18 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:17:18 --> Utf8 Class Initialized
INFO - 2017-02-01 13:17:18 --> URI Class Initialized
INFO - 2017-02-01 13:17:18 --> Router Class Initialized
INFO - 2017-02-01 13:17:18 --> Output Class Initialized
INFO - 2017-02-01 13:17:18 --> Security Class Initialized
DEBUG - 2017-02-01 13:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:17:18 --> Input Class Initialized
INFO - 2017-02-01 13:17:18 --> Language Class Initialized
INFO - 2017-02-01 13:17:18 --> Loader Class Initialized
INFO - 2017-02-01 13:17:18 --> Helper loaded: url_helper
INFO - 2017-02-01 13:17:18 --> Helper loaded: language_helper
INFO - 2017-02-01 13:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:17:18 --> Controller Class Initialized
INFO - 2017-02-01 13:17:18 --> Database Driver Class Initialized
INFO - 2017-02-01 13:17:18 --> Model Class Initialized
INFO - 2017-02-01 13:17:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:17:18 --> Model Class Initialized
INFO - 2017-02-01 13:17:18 --> Helper loaded: form_helper
INFO - 2017-02-01 13:17:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:17:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:17:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:17:18 --> Final output sent to browser
DEBUG - 2017-02-01 13:17:18 --> Total execution time: 0.1267
INFO - 2017-02-01 13:19:09 --> Config Class Initialized
INFO - 2017-02-01 13:19:09 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:19:09 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:19:09 --> Utf8 Class Initialized
INFO - 2017-02-01 13:19:09 --> URI Class Initialized
INFO - 2017-02-01 13:19:09 --> Router Class Initialized
INFO - 2017-02-01 13:19:09 --> Output Class Initialized
INFO - 2017-02-01 13:19:09 --> Security Class Initialized
DEBUG - 2017-02-01 13:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:19:09 --> Input Class Initialized
INFO - 2017-02-01 13:19:09 --> Language Class Initialized
INFO - 2017-02-01 13:19:09 --> Loader Class Initialized
INFO - 2017-02-01 13:19:09 --> Helper loaded: url_helper
INFO - 2017-02-01 13:19:09 --> Helper loaded: language_helper
INFO - 2017-02-01 13:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:19:09 --> Controller Class Initialized
INFO - 2017-02-01 13:19:09 --> Database Driver Class Initialized
INFO - 2017-02-01 13:19:09 --> Model Class Initialized
INFO - 2017-02-01 13:19:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:19:09 --> Model Class Initialized
INFO - 2017-02-01 13:19:09 --> Helper loaded: form_helper
INFO - 2017-02-01 13:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:19:09 --> Final output sent to browser
DEBUG - 2017-02-01 13:19:09 --> Total execution time: 0.1079
INFO - 2017-02-01 13:21:53 --> Config Class Initialized
INFO - 2017-02-01 13:21:53 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:21:53 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:21:53 --> Utf8 Class Initialized
INFO - 2017-02-01 13:21:53 --> URI Class Initialized
INFO - 2017-02-01 13:21:53 --> Router Class Initialized
INFO - 2017-02-01 13:21:53 --> Output Class Initialized
INFO - 2017-02-01 13:21:53 --> Security Class Initialized
DEBUG - 2017-02-01 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:21:53 --> Input Class Initialized
INFO - 2017-02-01 13:21:53 --> Language Class Initialized
INFO - 2017-02-01 13:21:53 --> Loader Class Initialized
INFO - 2017-02-01 13:21:53 --> Helper loaded: url_helper
INFO - 2017-02-01 13:21:53 --> Helper loaded: language_helper
INFO - 2017-02-01 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:21:53 --> Controller Class Initialized
INFO - 2017-02-01 13:21:53 --> Database Driver Class Initialized
INFO - 2017-02-01 13:21:53 --> Model Class Initialized
INFO - 2017-02-01 13:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:21:53 --> Model Class Initialized
INFO - 2017-02-01 13:21:53 --> Helper loaded: form_helper
INFO - 2017-02-01 13:21:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:21:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:21:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:21:54 --> Final output sent to browser
DEBUG - 2017-02-01 13:21:54 --> Total execution time: 0.5653
INFO - 2017-02-01 13:21:58 --> Config Class Initialized
INFO - 2017-02-01 13:21:58 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:21:58 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:21:58 --> Utf8 Class Initialized
INFO - 2017-02-01 13:21:58 --> URI Class Initialized
INFO - 2017-02-01 13:21:58 --> Router Class Initialized
INFO - 2017-02-01 13:21:58 --> Output Class Initialized
INFO - 2017-02-01 13:21:58 --> Security Class Initialized
DEBUG - 2017-02-01 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:21:58 --> Input Class Initialized
INFO - 2017-02-01 13:21:58 --> Language Class Initialized
INFO - 2017-02-01 13:21:58 --> Loader Class Initialized
INFO - 2017-02-01 13:21:58 --> Helper loaded: url_helper
INFO - 2017-02-01 13:21:58 --> Helper loaded: language_helper
INFO - 2017-02-01 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:21:58 --> Controller Class Initialized
INFO - 2017-02-01 13:21:58 --> Database Driver Class Initialized
INFO - 2017-02-01 13:21:58 --> Model Class Initialized
INFO - 2017-02-01 13:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:21:58 --> Model Class Initialized
INFO - 2017-02-01 13:21:58 --> Helper loaded: form_helper
INFO - 2017-02-01 13:21:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:21:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:21:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:21:58 --> Final output sent to browser
DEBUG - 2017-02-01 13:21:58 --> Total execution time: 0.4273
INFO - 2017-02-01 13:22:03 --> Config Class Initialized
INFO - 2017-02-01 13:22:03 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:22:03 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:22:03 --> Utf8 Class Initialized
INFO - 2017-02-01 13:22:03 --> URI Class Initialized
INFO - 2017-02-01 13:22:03 --> Router Class Initialized
INFO - 2017-02-01 13:22:03 --> Output Class Initialized
INFO - 2017-02-01 13:22:03 --> Security Class Initialized
DEBUG - 2017-02-01 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:22:03 --> Input Class Initialized
INFO - 2017-02-01 13:22:03 --> Language Class Initialized
INFO - 2017-02-01 13:22:03 --> Loader Class Initialized
INFO - 2017-02-01 13:22:03 --> Helper loaded: url_helper
INFO - 2017-02-01 13:22:03 --> Helper loaded: language_helper
INFO - 2017-02-01 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:22:03 --> Controller Class Initialized
INFO - 2017-02-01 13:22:03 --> Database Driver Class Initialized
INFO - 2017-02-01 13:22:03 --> Model Class Initialized
INFO - 2017-02-01 13:22:03 --> Model Class Initialized
INFO - 2017-02-01 13:22:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:22:03 --> Config Class Initialized
INFO - 2017-02-01 13:22:03 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:22:03 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:22:03 --> Utf8 Class Initialized
INFO - 2017-02-01 13:22:03 --> URI Class Initialized
INFO - 2017-02-01 13:22:03 --> Router Class Initialized
INFO - 2017-02-01 13:22:03 --> Output Class Initialized
INFO - 2017-02-01 13:22:03 --> Security Class Initialized
DEBUG - 2017-02-01 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:22:03 --> Input Class Initialized
INFO - 2017-02-01 13:22:03 --> Language Class Initialized
INFO - 2017-02-01 13:22:03 --> Loader Class Initialized
INFO - 2017-02-01 13:22:03 --> Helper loaded: url_helper
INFO - 2017-02-01 13:22:03 --> Helper loaded: language_helper
INFO - 2017-02-01 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:22:03 --> Controller Class Initialized
INFO - 2017-02-01 13:22:03 --> Database Driver Class Initialized
INFO - 2017-02-01 13:22:03 --> Model Class Initialized
INFO - 2017-02-01 13:22:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-01 13:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-01 13:22:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-01 13:22:03 --> Final output sent to browser
DEBUG - 2017-02-01 13:22:03 --> Total execution time: 0.1268
INFO - 2017-02-01 13:22:10 --> Config Class Initialized
INFO - 2017-02-01 13:22:10 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:22:10 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:22:10 --> Utf8 Class Initialized
INFO - 2017-02-01 13:22:10 --> URI Class Initialized
INFO - 2017-02-01 13:22:10 --> Router Class Initialized
INFO - 2017-02-01 13:22:10 --> Output Class Initialized
INFO - 2017-02-01 13:22:10 --> Security Class Initialized
DEBUG - 2017-02-01 13:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:22:10 --> Input Class Initialized
INFO - 2017-02-01 13:22:10 --> Language Class Initialized
INFO - 2017-02-01 13:22:10 --> Loader Class Initialized
INFO - 2017-02-01 13:22:10 --> Helper loaded: url_helper
INFO - 2017-02-01 13:22:10 --> Helper loaded: language_helper
INFO - 2017-02-01 13:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:22:10 --> Controller Class Initialized
INFO - 2017-02-01 13:22:10 --> Database Driver Class Initialized
INFO - 2017-02-01 13:22:10 --> Model Class Initialized
INFO - 2017-02-01 13:22:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:22:10 --> Config Class Initialized
INFO - 2017-02-01 13:22:10 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:22:10 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:22:10 --> Utf8 Class Initialized
INFO - 2017-02-01 13:22:10 --> URI Class Initialized
INFO - 2017-02-01 13:22:10 --> Router Class Initialized
INFO - 2017-02-01 13:22:10 --> Output Class Initialized
INFO - 2017-02-01 13:22:10 --> Security Class Initialized
DEBUG - 2017-02-01 13:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:22:10 --> Input Class Initialized
INFO - 2017-02-01 13:22:10 --> Language Class Initialized
INFO - 2017-02-01 13:22:10 --> Loader Class Initialized
INFO - 2017-02-01 13:22:10 --> Helper loaded: url_helper
INFO - 2017-02-01 13:22:10 --> Helper loaded: language_helper
INFO - 2017-02-01 13:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:22:10 --> Controller Class Initialized
INFO - 2017-02-01 13:22:10 --> Database Driver Class Initialized
INFO - 2017-02-01 13:22:10 --> Model Class Initialized
INFO - 2017-02-01 13:22:10 --> Model Class Initialized
INFO - 2017-02-01 13:22:10 --> Model Class Initialized
INFO - 2017-02-01 13:22:10 --> Model Class Initialized
INFO - 2017-02-01 13:22:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-01 13:22:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:22:10 --> Final output sent to browser
DEBUG - 2017-02-01 13:22:10 --> Total execution time: 0.1310
INFO - 2017-02-01 13:22:13 --> Config Class Initialized
INFO - 2017-02-01 13:22:13 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:22:13 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:22:13 --> Utf8 Class Initialized
INFO - 2017-02-01 13:22:13 --> URI Class Initialized
INFO - 2017-02-01 13:22:13 --> Router Class Initialized
INFO - 2017-02-01 13:22:13 --> Output Class Initialized
INFO - 2017-02-01 13:22:13 --> Security Class Initialized
DEBUG - 2017-02-01 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:22:13 --> Input Class Initialized
INFO - 2017-02-01 13:22:13 --> Language Class Initialized
INFO - 2017-02-01 13:22:13 --> Loader Class Initialized
INFO - 2017-02-01 13:22:13 --> Helper loaded: url_helper
INFO - 2017-02-01 13:22:13 --> Helper loaded: language_helper
INFO - 2017-02-01 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:22:13 --> Controller Class Initialized
INFO - 2017-02-01 13:22:13 --> Database Driver Class Initialized
INFO - 2017-02-01 13:22:13 --> Model Class Initialized
INFO - 2017-02-01 13:22:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:22:13 --> Model Class Initialized
INFO - 2017-02-01 13:22:13 --> Helper loaded: form_helper
INFO - 2017-02-01 13:22:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:22:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-01 13:22:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:22:13 --> Final output sent to browser
DEBUG - 2017-02-01 13:22:13 --> Total execution time: 0.1530
INFO - 2017-02-01 13:25:58 --> Config Class Initialized
INFO - 2017-02-01 13:25:58 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:25:58 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:25:58 --> Utf8 Class Initialized
INFO - 2017-02-01 13:25:59 --> URI Class Initialized
INFO - 2017-02-01 13:25:59 --> Router Class Initialized
INFO - 2017-02-01 13:25:59 --> Output Class Initialized
INFO - 2017-02-01 13:25:59 --> Security Class Initialized
DEBUG - 2017-02-01 13:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:25:59 --> Input Class Initialized
INFO - 2017-02-01 13:25:59 --> Language Class Initialized
INFO - 2017-02-01 13:25:59 --> Loader Class Initialized
INFO - 2017-02-01 13:25:59 --> Helper loaded: url_helper
INFO - 2017-02-01 13:25:59 --> Helper loaded: language_helper
INFO - 2017-02-01 13:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:25:59 --> Controller Class Initialized
INFO - 2017-02-01 13:25:59 --> Database Driver Class Initialized
INFO - 2017-02-01 13:25:59 --> Model Class Initialized
INFO - 2017-02-01 13:25:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:25:59 --> Model Class Initialized
INFO - 2017-02-01 13:25:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-02-01 13:25:59 --> Final output sent to browser
DEBUG - 2017-02-01 13:25:59 --> Total execution time: 0.5854
INFO - 2017-02-01 13:26:17 --> Config Class Initialized
INFO - 2017-02-01 13:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:26:17 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:26:17 --> Utf8 Class Initialized
INFO - 2017-02-01 13:26:17 --> URI Class Initialized
INFO - 2017-02-01 13:26:17 --> Router Class Initialized
INFO - 2017-02-01 13:26:17 --> Output Class Initialized
INFO - 2017-02-01 13:26:17 --> Security Class Initialized
DEBUG - 2017-02-01 13:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:26:17 --> Input Class Initialized
INFO - 2017-02-01 13:26:17 --> Language Class Initialized
INFO - 2017-02-01 13:26:17 --> Loader Class Initialized
INFO - 2017-02-01 13:26:17 --> Helper loaded: url_helper
INFO - 2017-02-01 13:26:17 --> Helper loaded: language_helper
INFO - 2017-02-01 13:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:26:17 --> Controller Class Initialized
INFO - 2017-02-01 13:26:17 --> Database Driver Class Initialized
INFO - 2017-02-01 13:26:17 --> Model Class Initialized
INFO - 2017-02-01 13:26:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:26:17 --> Model Class Initialized
INFO - 2017-02-01 13:26:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\export_hasil_disc.php
INFO - 2017-02-01 13:26:17 --> Final output sent to browser
DEBUG - 2017-02-01 13:26:17 --> Total execution time: 0.4210
INFO - 2017-02-01 13:26:37 --> Config Class Initialized
INFO - 2017-02-01 13:26:37 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:26:37 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:26:37 --> Utf8 Class Initialized
INFO - 2017-02-01 13:26:37 --> URI Class Initialized
INFO - 2017-02-01 13:26:37 --> Router Class Initialized
INFO - 2017-02-01 13:26:37 --> Output Class Initialized
INFO - 2017-02-01 13:26:37 --> Security Class Initialized
DEBUG - 2017-02-01 13:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:26:37 --> Input Class Initialized
INFO - 2017-02-01 13:26:37 --> Language Class Initialized
INFO - 2017-02-01 13:26:37 --> Loader Class Initialized
INFO - 2017-02-01 13:26:37 --> Helper loaded: url_helper
INFO - 2017-02-01 13:26:37 --> Helper loaded: language_helper
INFO - 2017-02-01 13:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:26:37 --> Controller Class Initialized
INFO - 2017-02-01 13:26:37 --> Database Driver Class Initialized
INFO - 2017-02-01 13:26:37 --> Model Class Initialized
INFO - 2017-02-01 13:26:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:26:37 --> Helper loaded: form_helper
INFO - 2017-02-01 13:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-01 13:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:26:37 --> Final output sent to browser
DEBUG - 2017-02-01 13:26:37 --> Total execution time: 0.1627
INFO - 2017-02-01 13:26:39 --> Config Class Initialized
INFO - 2017-02-01 13:26:39 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:26:39 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:26:39 --> Utf8 Class Initialized
INFO - 2017-02-01 13:26:39 --> URI Class Initialized
INFO - 2017-02-01 13:26:39 --> Router Class Initialized
INFO - 2017-02-01 13:26:39 --> Output Class Initialized
INFO - 2017-02-01 13:26:39 --> Security Class Initialized
DEBUG - 2017-02-01 13:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:26:39 --> Input Class Initialized
INFO - 2017-02-01 13:26:39 --> Language Class Initialized
INFO - 2017-02-01 13:26:39 --> Loader Class Initialized
INFO - 2017-02-01 13:26:39 --> Helper loaded: url_helper
INFO - 2017-02-01 13:26:39 --> Helper loaded: language_helper
INFO - 2017-02-01 13:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:26:39 --> Controller Class Initialized
INFO - 2017-02-01 13:26:39 --> Database Driver Class Initialized
INFO - 2017-02-01 13:26:39 --> Model Class Initialized
INFO - 2017-02-01 13:26:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:26:39 --> Helper loaded: form_helper
INFO - 2017-02-01 13:26:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:26:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-01 13:26:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:26:39 --> Final output sent to browser
DEBUG - 2017-02-01 13:26:39 --> Total execution time: 0.1867
INFO - 2017-02-01 13:26:47 --> Config Class Initialized
INFO - 2017-02-01 13:26:47 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:26:47 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:26:47 --> Utf8 Class Initialized
INFO - 2017-02-01 13:26:47 --> URI Class Initialized
INFO - 2017-02-01 13:26:47 --> Router Class Initialized
INFO - 2017-02-01 13:26:47 --> Output Class Initialized
INFO - 2017-02-01 13:26:47 --> Security Class Initialized
DEBUG - 2017-02-01 13:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:26:47 --> Input Class Initialized
INFO - 2017-02-01 13:26:47 --> Language Class Initialized
INFO - 2017-02-01 13:26:47 --> Loader Class Initialized
INFO - 2017-02-01 13:26:47 --> Helper loaded: url_helper
INFO - 2017-02-01 13:26:47 --> Helper loaded: language_helper
INFO - 2017-02-01 13:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:26:47 --> Controller Class Initialized
INFO - 2017-02-01 13:26:47 --> Database Driver Class Initialized
INFO - 2017-02-01 13:26:47 --> Model Class Initialized
INFO - 2017-02-01 13:26:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:26:47 --> Helper loaded: form_helper
INFO - 2017-02-01 13:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-01 13:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:26:47 --> Final output sent to browser
DEBUG - 2017-02-01 13:26:47 --> Total execution time: 0.1162
INFO - 2017-02-01 13:26:54 --> Config Class Initialized
INFO - 2017-02-01 13:26:54 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:26:54 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:26:54 --> Utf8 Class Initialized
INFO - 2017-02-01 13:26:54 --> URI Class Initialized
INFO - 2017-02-01 13:26:54 --> Router Class Initialized
INFO - 2017-02-01 13:26:54 --> Output Class Initialized
INFO - 2017-02-01 13:26:54 --> Security Class Initialized
DEBUG - 2017-02-01 13:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:26:54 --> Input Class Initialized
INFO - 2017-02-01 13:26:54 --> Language Class Initialized
INFO - 2017-02-01 13:26:54 --> Loader Class Initialized
INFO - 2017-02-01 13:26:54 --> Helper loaded: url_helper
INFO - 2017-02-01 13:26:54 --> Helper loaded: language_helper
INFO - 2017-02-01 13:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:26:54 --> Controller Class Initialized
INFO - 2017-02-01 13:26:54 --> Database Driver Class Initialized
INFO - 2017-02-01 13:26:54 --> Model Class Initialized
INFO - 2017-02-01 13:26:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:26:54 --> Model Class Initialized
INFO - 2017-02-01 13:26:54 --> Model Class Initialized
INFO - 2017-02-01 13:26:54 --> Helper loaded: form_helper
INFO - 2017-02-01 13:26:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:26:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-01 13:26:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:26:54 --> Final output sent to browser
DEBUG - 2017-02-01 13:26:54 --> Total execution time: 0.1978
INFO - 2017-02-01 13:27:10 --> Config Class Initialized
INFO - 2017-02-01 13:27:10 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:27:10 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:27:10 --> Utf8 Class Initialized
INFO - 2017-02-01 13:27:10 --> URI Class Initialized
INFO - 2017-02-01 13:27:10 --> Router Class Initialized
INFO - 2017-02-01 13:27:10 --> Output Class Initialized
INFO - 2017-02-01 13:27:10 --> Security Class Initialized
DEBUG - 2017-02-01 13:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:27:10 --> Input Class Initialized
INFO - 2017-02-01 13:27:10 --> Language Class Initialized
INFO - 2017-02-01 13:27:10 --> Loader Class Initialized
INFO - 2017-02-01 13:27:10 --> Helper loaded: url_helper
INFO - 2017-02-01 13:27:10 --> Helper loaded: language_helper
INFO - 2017-02-01 13:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:27:10 --> Controller Class Initialized
INFO - 2017-02-01 13:27:11 --> Database Driver Class Initialized
INFO - 2017-02-01 13:27:11 --> Model Class Initialized
INFO - 2017-02-01 13:27:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:27:11 --> Helper loaded: form_helper
INFO - 2017-02-01 13:27:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:27:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-01 13:27:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:27:11 --> Final output sent to browser
DEBUG - 2017-02-01 13:27:11 --> Total execution time: 0.1072
INFO - 2017-02-01 13:27:14 --> Config Class Initialized
INFO - 2017-02-01 13:27:14 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:27:14 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:27:14 --> Utf8 Class Initialized
INFO - 2017-02-01 13:27:14 --> URI Class Initialized
INFO - 2017-02-01 13:27:14 --> Router Class Initialized
INFO - 2017-02-01 13:27:14 --> Output Class Initialized
INFO - 2017-02-01 13:27:14 --> Security Class Initialized
DEBUG - 2017-02-01 13:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:27:14 --> Input Class Initialized
INFO - 2017-02-01 13:27:14 --> Language Class Initialized
INFO - 2017-02-01 13:27:14 --> Loader Class Initialized
INFO - 2017-02-01 13:27:14 --> Helper loaded: url_helper
INFO - 2017-02-01 13:27:14 --> Helper loaded: language_helper
INFO - 2017-02-01 13:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:27:14 --> Controller Class Initialized
INFO - 2017-02-01 13:27:14 --> Database Driver Class Initialized
INFO - 2017-02-01 13:27:14 --> Model Class Initialized
INFO - 2017-02-01 13:27:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:27:14 --> Model Class Initialized
INFO - 2017-02-01 13:27:14 --> Model Class Initialized
INFO - 2017-02-01 13:27:14 --> Helper loaded: form_helper
INFO - 2017-02-01 13:27:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:27:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-01 13:27:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:27:14 --> Final output sent to browser
DEBUG - 2017-02-01 13:27:14 --> Total execution time: 0.1814
INFO - 2017-02-01 13:28:09 --> Config Class Initialized
INFO - 2017-02-01 13:28:09 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:09 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:09 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:09 --> URI Class Initialized
INFO - 2017-02-01 13:28:09 --> Router Class Initialized
INFO - 2017-02-01 13:28:09 --> Output Class Initialized
INFO - 2017-02-01 13:28:09 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:09 --> Input Class Initialized
INFO - 2017-02-01 13:28:09 --> Language Class Initialized
INFO - 2017-02-01 13:28:09 --> Loader Class Initialized
INFO - 2017-02-01 13:28:09 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:09 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:09 --> Controller Class Initialized
INFO - 2017-02-01 13:28:09 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:09 --> Model Class Initialized
INFO - 2017-02-01 13:28:09 --> Model Class Initialized
INFO - 2017-02-01 13:28:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:09 --> Helper loaded: form_helper
INFO - 2017-02-01 13:28:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-01 13:28:09 --> Could not find the language line "import_user"
INFO - 2017-02-01 13:28:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-01 13:28:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:28:09 --> Final output sent to browser
DEBUG - 2017-02-01 13:28:09 --> Total execution time: 0.0895
INFO - 2017-02-01 13:28:15 --> Config Class Initialized
INFO - 2017-02-01 13:28:15 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:15 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:15 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:15 --> URI Class Initialized
INFO - 2017-02-01 13:28:15 --> Router Class Initialized
INFO - 2017-02-01 13:28:15 --> Output Class Initialized
INFO - 2017-02-01 13:28:15 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:15 --> Input Class Initialized
INFO - 2017-02-01 13:28:15 --> Language Class Initialized
INFO - 2017-02-01 13:28:15 --> Loader Class Initialized
INFO - 2017-02-01 13:28:15 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:15 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:15 --> Controller Class Initialized
INFO - 2017-02-01 13:28:15 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:15 --> Model Class Initialized
INFO - 2017-02-01 13:28:15 --> Model Class Initialized
INFO - 2017-02-01 13:28:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:28:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-01 13:28:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:28:15 --> Final output sent to browser
DEBUG - 2017-02-01 13:28:15 --> Total execution time: 0.1534
INFO - 2017-02-01 13:28:15 --> Config Class Initialized
INFO - 2017-02-01 13:28:15 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:15 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:15 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:15 --> URI Class Initialized
INFO - 2017-02-01 13:28:15 --> Router Class Initialized
INFO - 2017-02-01 13:28:15 --> Output Class Initialized
INFO - 2017-02-01 13:28:15 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:15 --> Input Class Initialized
INFO - 2017-02-01 13:28:15 --> Language Class Initialized
INFO - 2017-02-01 13:28:15 --> Loader Class Initialized
INFO - 2017-02-01 13:28:15 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:15 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:15 --> Controller Class Initialized
INFO - 2017-02-01 13:28:15 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:15 --> Model Class Initialized
INFO - 2017-02-01 13:28:15 --> Model Class Initialized
INFO - 2017-02-01 13:28:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:15 --> Final output sent to browser
DEBUG - 2017-02-01 13:28:15 --> Total execution time: 0.1349
INFO - 2017-02-01 13:28:24 --> Config Class Initialized
INFO - 2017-02-01 13:28:24 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:24 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:24 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:24 --> URI Class Initialized
INFO - 2017-02-01 13:28:24 --> Router Class Initialized
INFO - 2017-02-01 13:28:24 --> Output Class Initialized
INFO - 2017-02-01 13:28:24 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:24 --> Input Class Initialized
INFO - 2017-02-01 13:28:24 --> Language Class Initialized
INFO - 2017-02-01 13:28:24 --> Loader Class Initialized
INFO - 2017-02-01 13:28:24 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:24 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:24 --> Controller Class Initialized
INFO - 2017-02-01 13:28:24 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:24 --> Model Class Initialized
INFO - 2017-02-01 13:28:24 --> Model Class Initialized
INFO - 2017-02-01 13:28:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:24 --> Config Class Initialized
INFO - 2017-02-01 13:28:24 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:24 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:24 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:24 --> URI Class Initialized
INFO - 2017-02-01 13:28:24 --> Router Class Initialized
INFO - 2017-02-01 13:28:24 --> Output Class Initialized
INFO - 2017-02-01 13:28:24 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:24 --> Input Class Initialized
INFO - 2017-02-01 13:28:24 --> Language Class Initialized
INFO - 2017-02-01 13:28:24 --> Loader Class Initialized
INFO - 2017-02-01 13:28:24 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:24 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:24 --> Controller Class Initialized
INFO - 2017-02-01 13:28:24 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:24 --> Model Class Initialized
INFO - 2017-02-01 13:28:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-01 13:28:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-01 13:28:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-01 13:28:24 --> Final output sent to browser
DEBUG - 2017-02-01 13:28:24 --> Total execution time: 0.1113
INFO - 2017-02-01 13:28:30 --> Config Class Initialized
INFO - 2017-02-01 13:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:30 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:30 --> URI Class Initialized
INFO - 2017-02-01 13:28:30 --> Router Class Initialized
INFO - 2017-02-01 13:28:30 --> Output Class Initialized
INFO - 2017-02-01 13:28:30 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:30 --> Input Class Initialized
INFO - 2017-02-01 13:28:30 --> Language Class Initialized
INFO - 2017-02-01 13:28:30 --> Loader Class Initialized
INFO - 2017-02-01 13:28:30 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:30 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:30 --> Controller Class Initialized
INFO - 2017-02-01 13:28:30 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:30 --> Model Class Initialized
INFO - 2017-02-01 13:28:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:30 --> Config Class Initialized
INFO - 2017-02-01 13:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-01 13:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-01 13:28:30 --> Utf8 Class Initialized
INFO - 2017-02-01 13:28:30 --> URI Class Initialized
INFO - 2017-02-01 13:28:30 --> Router Class Initialized
INFO - 2017-02-01 13:28:30 --> Output Class Initialized
INFO - 2017-02-01 13:28:30 --> Security Class Initialized
DEBUG - 2017-02-01 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 13:28:30 --> Input Class Initialized
INFO - 2017-02-01 13:28:30 --> Language Class Initialized
INFO - 2017-02-01 13:28:30 --> Loader Class Initialized
INFO - 2017-02-01 13:28:30 --> Helper loaded: url_helper
INFO - 2017-02-01 13:28:30 --> Helper loaded: language_helper
INFO - 2017-02-01 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-01 13:28:30 --> Controller Class Initialized
INFO - 2017-02-01 13:28:30 --> Database Driver Class Initialized
INFO - 2017-02-01 13:28:30 --> Model Class Initialized
INFO - 2017-02-01 13:28:30 --> Model Class Initialized
INFO - 2017-02-01 13:28:30 --> Model Class Initialized
INFO - 2017-02-01 13:28:30 --> Model Class Initialized
INFO - 2017-02-01 13:28:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-01 13:28:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-01 13:28:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-01 13:28:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-01 13:28:30 --> Final output sent to browser
DEBUG - 2017-02-01 13:28:30 --> Total execution time: 0.1616
