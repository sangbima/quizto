<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-02 14:05:11 --> Config Class Initialized
INFO - 2017-02-02 14:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:05:11 --> Utf8 Class Initialized
INFO - 2017-02-02 14:05:11 --> URI Class Initialized
INFO - 2017-02-02 14:05:11 --> Router Class Initialized
INFO - 2017-02-02 14:05:11 --> Output Class Initialized
INFO - 2017-02-02 14:05:11 --> Security Class Initialized
DEBUG - 2017-02-02 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:05:11 --> Input Class Initialized
INFO - 2017-02-02 14:05:11 --> Language Class Initialized
INFO - 2017-02-02 14:05:11 --> Loader Class Initialized
INFO - 2017-02-02 14:05:11 --> Helper loaded: url_helper
INFO - 2017-02-02 14:05:11 --> Helper loaded: language_helper
INFO - 2017-02-02 14:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:05:11 --> Controller Class Initialized
INFO - 2017-02-02 14:05:11 --> Database Driver Class Initialized
INFO - 2017-02-02 14:05:11 --> Model Class Initialized
INFO - 2017-02-02 14:05:11 --> Model Class Initialized
INFO - 2017-02-02 14:05:11 --> Model Class Initialized
INFO - 2017-02-02 14:05:11 --> Model Class Initialized
INFO - 2017-02-02 14:05:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:05:11 --> Config Class Initialized
INFO - 2017-02-02 14:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:05:11 --> Utf8 Class Initialized
INFO - 2017-02-02 14:05:11 --> URI Class Initialized
INFO - 2017-02-02 14:05:11 --> Router Class Initialized
INFO - 2017-02-02 14:05:11 --> Output Class Initialized
INFO - 2017-02-02 14:05:11 --> Security Class Initialized
DEBUG - 2017-02-02 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:05:11 --> Input Class Initialized
INFO - 2017-02-02 14:05:11 --> Language Class Initialized
INFO - 2017-02-02 14:05:11 --> Loader Class Initialized
INFO - 2017-02-02 14:05:11 --> Helper loaded: url_helper
INFO - 2017-02-02 14:05:11 --> Helper loaded: language_helper
INFO - 2017-02-02 14:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:05:11 --> Controller Class Initialized
INFO - 2017-02-02 14:05:11 --> Database Driver Class Initialized
INFO - 2017-02-02 14:05:11 --> Model Class Initialized
INFO - 2017-02-02 14:05:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:05:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-02 14:05:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-02 14:05:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-02 14:05:11 --> Final output sent to browser
DEBUG - 2017-02-02 14:05:11 --> Total execution time: 0.0660
INFO - 2017-02-02 14:05:16 --> Config Class Initialized
INFO - 2017-02-02 14:05:16 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:05:16 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:05:16 --> Utf8 Class Initialized
INFO - 2017-02-02 14:05:16 --> URI Class Initialized
INFO - 2017-02-02 14:05:16 --> Router Class Initialized
INFO - 2017-02-02 14:05:16 --> Output Class Initialized
INFO - 2017-02-02 14:05:16 --> Security Class Initialized
DEBUG - 2017-02-02 14:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:05:16 --> Input Class Initialized
INFO - 2017-02-02 14:05:16 --> Language Class Initialized
INFO - 2017-02-02 14:05:16 --> Loader Class Initialized
INFO - 2017-02-02 14:05:16 --> Helper loaded: url_helper
INFO - 2017-02-02 14:05:16 --> Helper loaded: language_helper
INFO - 2017-02-02 14:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:05:16 --> Controller Class Initialized
INFO - 2017-02-02 14:05:16 --> Database Driver Class Initialized
INFO - 2017-02-02 14:05:16 --> Model Class Initialized
INFO - 2017-02-02 14:05:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:05:16 --> Config Class Initialized
INFO - 2017-02-02 14:05:16 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:05:16 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:05:16 --> Utf8 Class Initialized
INFO - 2017-02-02 14:05:16 --> URI Class Initialized
INFO - 2017-02-02 14:05:16 --> Router Class Initialized
INFO - 2017-02-02 14:05:16 --> Output Class Initialized
INFO - 2017-02-02 14:05:16 --> Security Class Initialized
DEBUG - 2017-02-02 14:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:05:16 --> Input Class Initialized
INFO - 2017-02-02 14:05:16 --> Language Class Initialized
INFO - 2017-02-02 14:05:16 --> Loader Class Initialized
INFO - 2017-02-02 14:05:16 --> Helper loaded: url_helper
INFO - 2017-02-02 14:05:16 --> Helper loaded: language_helper
INFO - 2017-02-02 14:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:05:16 --> Controller Class Initialized
INFO - 2017-02-02 14:05:16 --> Database Driver Class Initialized
INFO - 2017-02-02 14:05:16 --> Model Class Initialized
INFO - 2017-02-02 14:05:16 --> Model Class Initialized
INFO - 2017-02-02 14:05:16 --> Model Class Initialized
INFO - 2017-02-02 14:05:16 --> Model Class Initialized
INFO - 2017-02-02 14:05:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:05:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:05:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-02 14:05:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:05:17 --> Final output sent to browser
DEBUG - 2017-02-02 14:05:17 --> Total execution time: 0.1143
INFO - 2017-02-02 14:05:32 --> Config Class Initialized
INFO - 2017-02-02 14:05:32 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:05:32 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:05:32 --> Utf8 Class Initialized
INFO - 2017-02-02 14:05:32 --> URI Class Initialized
INFO - 2017-02-02 14:05:32 --> Router Class Initialized
INFO - 2017-02-02 14:05:32 --> Output Class Initialized
INFO - 2017-02-02 14:05:32 --> Security Class Initialized
DEBUG - 2017-02-02 14:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:05:32 --> Input Class Initialized
INFO - 2017-02-02 14:05:32 --> Language Class Initialized
INFO - 2017-02-02 14:05:32 --> Loader Class Initialized
INFO - 2017-02-02 14:05:32 --> Helper loaded: url_helper
INFO - 2017-02-02 14:05:32 --> Helper loaded: language_helper
INFO - 2017-02-02 14:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:05:32 --> Controller Class Initialized
INFO - 2017-02-02 14:05:32 --> Database Driver Class Initialized
INFO - 2017-02-02 14:05:32 --> Model Class Initialized
INFO - 2017-02-02 14:05:32 --> Model Class Initialized
INFO - 2017-02-02 14:05:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:05:32 --> Helper loaded: form_helper
INFO - 2017-02-02 14:05:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:05:32 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:05:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:05:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:05:32 --> Final output sent to browser
DEBUG - 2017-02-02 14:05:32 --> Total execution time: 0.0960
INFO - 2017-02-02 14:17:57 --> Config Class Initialized
INFO - 2017-02-02 14:17:57 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:17:57 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:17:57 --> Utf8 Class Initialized
INFO - 2017-02-02 14:17:57 --> URI Class Initialized
INFO - 2017-02-02 14:17:57 --> Router Class Initialized
INFO - 2017-02-02 14:17:57 --> Output Class Initialized
INFO - 2017-02-02 14:17:57 --> Security Class Initialized
DEBUG - 2017-02-02 14:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:17:57 --> Input Class Initialized
INFO - 2017-02-02 14:17:57 --> Language Class Initialized
INFO - 2017-02-02 14:17:57 --> Loader Class Initialized
INFO - 2017-02-02 14:17:57 --> Helper loaded: url_helper
INFO - 2017-02-02 14:17:57 --> Helper loaded: language_helper
INFO - 2017-02-02 14:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:17:57 --> Controller Class Initialized
INFO - 2017-02-02 14:17:57 --> Database Driver Class Initialized
INFO - 2017-02-02 14:17:57 --> Model Class Initialized
INFO - 2017-02-02 14:17:57 --> Model Class Initialized
INFO - 2017-02-02 14:17:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:17:57 --> Helper loaded: form_helper
INFO - 2017-02-02 14:17:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:17:57 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:17:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:17:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:17:57 --> Final output sent to browser
DEBUG - 2017-02-02 14:17:57 --> Total execution time: 0.0851
INFO - 2017-02-02 14:18:32 --> Config Class Initialized
INFO - 2017-02-02 14:18:32 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:32 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:32 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:32 --> URI Class Initialized
INFO - 2017-02-02 14:18:32 --> Router Class Initialized
INFO - 2017-02-02 14:18:32 --> Output Class Initialized
INFO - 2017-02-02 14:18:32 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:32 --> Input Class Initialized
INFO - 2017-02-02 14:18:32 --> Language Class Initialized
INFO - 2017-02-02 14:18:32 --> Loader Class Initialized
INFO - 2017-02-02 14:18:32 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:32 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:32 --> Controller Class Initialized
INFO - 2017-02-02 14:18:32 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:32 --> Model Class Initialized
INFO - 2017-02-02 14:18:33 --> Model Class Initialized
INFO - 2017-02-02 14:18:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:33 --> Helper loaded: form_helper
INFO - 2017-02-02 14:18:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:18:33 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:18:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:18:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:18:33 --> Final output sent to browser
DEBUG - 2017-02-02 14:18:33 --> Total execution time: 0.0940
INFO - 2017-02-02 14:18:38 --> Config Class Initialized
INFO - 2017-02-02 14:18:38 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:38 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:38 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:38 --> URI Class Initialized
INFO - 2017-02-02 14:18:38 --> Router Class Initialized
INFO - 2017-02-02 14:18:38 --> Output Class Initialized
INFO - 2017-02-02 14:18:38 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:38 --> Input Class Initialized
INFO - 2017-02-02 14:18:38 --> Language Class Initialized
INFO - 2017-02-02 14:18:38 --> Loader Class Initialized
INFO - 2017-02-02 14:18:38 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:38 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:38 --> Controller Class Initialized
INFO - 2017-02-02 14:18:38 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:38 --> Model Class Initialized
INFO - 2017-02-02 14:18:38 --> Model Class Initialized
INFO - 2017-02-02 14:18:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:38 --> Model Class Initialized
INFO - 2017-02-02 14:18:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:18:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-02-02 14:18:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:18:38 --> Final output sent to browser
DEBUG - 2017-02-02 14:18:38 --> Total execution time: 0.0874
INFO - 2017-02-02 14:18:44 --> Config Class Initialized
INFO - 2017-02-02 14:18:44 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:44 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:44 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:44 --> URI Class Initialized
INFO - 2017-02-02 14:18:44 --> Router Class Initialized
INFO - 2017-02-02 14:18:44 --> Output Class Initialized
INFO - 2017-02-02 14:18:44 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:44 --> Input Class Initialized
INFO - 2017-02-02 14:18:44 --> Language Class Initialized
INFO - 2017-02-02 14:18:44 --> Loader Class Initialized
INFO - 2017-02-02 14:18:44 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:44 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:44 --> Controller Class Initialized
INFO - 2017-02-02 14:18:44 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:44 --> Model Class Initialized
INFO - 2017-02-02 14:18:44 --> Model Class Initialized
INFO - 2017-02-02 14:18:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:44 --> Helper loaded: form_helper
INFO - 2017-02-02 14:18:44 --> Form Validation Class Initialized
INFO - 2017-02-02 14:18:44 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-02 14:18:44 --> Severity: Notice --> Undefined variable: logged_in C:\wamp64\www\savsoftquiz\application\models\User_model.php 237
ERROR - 2017-02-02 14:18:44 --> Severity: Notice --> Undefined variable: logged_in C:\wamp64\www\savsoftquiz\application\models\User_model.php 237
INFO - 2017-02-02 14:18:44 --> Config Class Initialized
INFO - 2017-02-02 14:18:44 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:44 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:44 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:44 --> URI Class Initialized
INFO - 2017-02-02 14:18:44 --> Router Class Initialized
INFO - 2017-02-02 14:18:44 --> Output Class Initialized
INFO - 2017-02-02 14:18:44 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:44 --> Input Class Initialized
INFO - 2017-02-02 14:18:44 --> Language Class Initialized
INFO - 2017-02-02 14:18:44 --> Loader Class Initialized
INFO - 2017-02-02 14:18:44 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:44 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:44 --> Controller Class Initialized
INFO - 2017-02-02 14:18:44 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:44 --> Model Class Initialized
INFO - 2017-02-02 14:18:44 --> Model Class Initialized
INFO - 2017-02-02 14:18:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:44 --> Model Class Initialized
INFO - 2017-02-02 14:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-02-02 14:18:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:18:44 --> Final output sent to browser
DEBUG - 2017-02-02 14:18:44 --> Total execution time: 0.0793
INFO - 2017-02-02 14:18:48 --> Config Class Initialized
INFO - 2017-02-02 14:18:48 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:48 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:48 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:48 --> URI Class Initialized
INFO - 2017-02-02 14:18:48 --> Router Class Initialized
INFO - 2017-02-02 14:18:48 --> Output Class Initialized
INFO - 2017-02-02 14:18:48 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:48 --> Input Class Initialized
INFO - 2017-02-02 14:18:48 --> Language Class Initialized
INFO - 2017-02-02 14:18:48 --> Loader Class Initialized
INFO - 2017-02-02 14:18:48 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:48 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:48 --> Controller Class Initialized
INFO - 2017-02-02 14:18:48 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:48 --> Model Class Initialized
INFO - 2017-02-02 14:18:48 --> Model Class Initialized
INFO - 2017-02-02 14:18:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:48 --> Helper loaded: form_helper
INFO - 2017-02-02 14:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:18:48 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:18:48 --> Final output sent to browser
DEBUG - 2017-02-02 14:18:48 --> Total execution time: 0.0844
INFO - 2017-02-02 14:18:52 --> Config Class Initialized
INFO - 2017-02-02 14:18:52 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:52 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:52 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:52 --> URI Class Initialized
INFO - 2017-02-02 14:18:52 --> Router Class Initialized
INFO - 2017-02-02 14:18:52 --> Output Class Initialized
INFO - 2017-02-02 14:18:52 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:52 --> Input Class Initialized
INFO - 2017-02-02 14:18:52 --> Language Class Initialized
INFO - 2017-02-02 14:18:52 --> Loader Class Initialized
INFO - 2017-02-02 14:18:52 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:52 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:52 --> Controller Class Initialized
INFO - 2017-02-02 14:18:52 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:52 --> Model Class Initialized
INFO - 2017-02-02 14:18:52 --> Model Class Initialized
INFO - 2017-02-02 14:18:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:52 --> Helper loaded: form_helper
INFO - 2017-02-02 14:18:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:18:52 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:18:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:18:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:18:52 --> Final output sent to browser
DEBUG - 2017-02-02 14:18:52 --> Total execution time: 0.1024
INFO - 2017-02-02 14:18:56 --> Config Class Initialized
INFO - 2017-02-02 14:18:56 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:56 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:56 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:56 --> URI Class Initialized
INFO - 2017-02-02 14:18:56 --> Router Class Initialized
INFO - 2017-02-02 14:18:56 --> Output Class Initialized
INFO - 2017-02-02 14:18:56 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:56 --> Input Class Initialized
INFO - 2017-02-02 14:18:56 --> Language Class Initialized
INFO - 2017-02-02 14:18:56 --> Loader Class Initialized
INFO - 2017-02-02 14:18:56 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:56 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:56 --> Controller Class Initialized
INFO - 2017-02-02 14:18:56 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:56 --> Model Class Initialized
INFO - 2017-02-02 14:18:56 --> Model Class Initialized
INFO - 2017-02-02 14:18:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:56 --> Config Class Initialized
INFO - 2017-02-02 14:18:56 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:18:56 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:18:56 --> Utf8 Class Initialized
INFO - 2017-02-02 14:18:56 --> URI Class Initialized
INFO - 2017-02-02 14:18:56 --> Router Class Initialized
INFO - 2017-02-02 14:18:56 --> Output Class Initialized
INFO - 2017-02-02 14:18:56 --> Security Class Initialized
DEBUG - 2017-02-02 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:18:56 --> Input Class Initialized
INFO - 2017-02-02 14:18:56 --> Language Class Initialized
INFO - 2017-02-02 14:18:56 --> Loader Class Initialized
INFO - 2017-02-02 14:18:56 --> Helper loaded: url_helper
INFO - 2017-02-02 14:18:56 --> Helper loaded: language_helper
INFO - 2017-02-02 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:18:56 --> Controller Class Initialized
INFO - 2017-02-02 14:18:56 --> Database Driver Class Initialized
INFO - 2017-02-02 14:18:56 --> Model Class Initialized
INFO - 2017-02-02 14:18:56 --> Model Class Initialized
INFO - 2017-02-02 14:18:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:18:56 --> Helper loaded: form_helper
INFO - 2017-02-02 14:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:18:56 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:18:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:18:56 --> Final output sent to browser
DEBUG - 2017-02-02 14:18:56 --> Total execution time: 0.0786
INFO - 2017-02-02 14:19:09 --> Config Class Initialized
INFO - 2017-02-02 14:19:09 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:09 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:09 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:09 --> URI Class Initialized
INFO - 2017-02-02 14:19:09 --> Router Class Initialized
INFO - 2017-02-02 14:19:09 --> Output Class Initialized
INFO - 2017-02-02 14:19:09 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:09 --> Input Class Initialized
INFO - 2017-02-02 14:19:09 --> Language Class Initialized
INFO - 2017-02-02 14:19:09 --> Loader Class Initialized
INFO - 2017-02-02 14:19:09 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:09 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:09 --> Controller Class Initialized
INFO - 2017-02-02 14:19:09 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:09 --> Model Class Initialized
INFO - 2017-02-02 14:19:09 --> Model Class Initialized
INFO - 2017-02-02 14:19:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:09 --> Config Class Initialized
INFO - 2017-02-02 14:19:09 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:09 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:09 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:09 --> URI Class Initialized
INFO - 2017-02-02 14:19:09 --> Router Class Initialized
INFO - 2017-02-02 14:19:09 --> Output Class Initialized
INFO - 2017-02-02 14:19:09 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:09 --> Input Class Initialized
INFO - 2017-02-02 14:19:09 --> Language Class Initialized
INFO - 2017-02-02 14:19:09 --> Loader Class Initialized
INFO - 2017-02-02 14:19:09 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:09 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:09 --> Controller Class Initialized
INFO - 2017-02-02 14:19:09 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:09 --> Model Class Initialized
INFO - 2017-02-02 14:19:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-02 14:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-02 14:19:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-02 14:19:09 --> Final output sent to browser
DEBUG - 2017-02-02 14:19:09 --> Total execution time: 0.0695
INFO - 2017-02-02 14:19:21 --> Config Class Initialized
INFO - 2017-02-02 14:19:21 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:21 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:21 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:21 --> URI Class Initialized
INFO - 2017-02-02 14:19:21 --> Router Class Initialized
INFO - 2017-02-02 14:19:21 --> Output Class Initialized
INFO - 2017-02-02 14:19:21 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:21 --> Input Class Initialized
INFO - 2017-02-02 14:19:21 --> Language Class Initialized
INFO - 2017-02-02 14:19:21 --> Loader Class Initialized
INFO - 2017-02-02 14:19:21 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:21 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:21 --> Controller Class Initialized
INFO - 2017-02-02 14:19:21 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:21 --> Model Class Initialized
INFO - 2017-02-02 14:19:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:21 --> Config Class Initialized
INFO - 2017-02-02 14:19:21 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:21 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:21 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:21 --> URI Class Initialized
INFO - 2017-02-02 14:19:21 --> Router Class Initialized
INFO - 2017-02-02 14:19:21 --> Output Class Initialized
INFO - 2017-02-02 14:19:21 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:21 --> Input Class Initialized
INFO - 2017-02-02 14:19:21 --> Language Class Initialized
INFO - 2017-02-02 14:19:21 --> Loader Class Initialized
INFO - 2017-02-02 14:19:21 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:21 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:21 --> Controller Class Initialized
INFO - 2017-02-02 14:19:21 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:21 --> Model Class Initialized
INFO - 2017-02-02 14:19:21 --> Model Class Initialized
INFO - 2017-02-02 14:19:21 --> Model Class Initialized
INFO - 2017-02-02 14:19:21 --> Model Class Initialized
INFO - 2017-02-02 14:19:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:19:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-02 14:19:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:19:21 --> Final output sent to browser
DEBUG - 2017-02-02 14:19:21 --> Total execution time: 0.0798
INFO - 2017-02-02 14:19:26 --> Config Class Initialized
INFO - 2017-02-02 14:19:26 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:26 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:26 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:26 --> URI Class Initialized
INFO - 2017-02-02 14:19:26 --> Router Class Initialized
INFO - 2017-02-02 14:19:26 --> Output Class Initialized
INFO - 2017-02-02 14:19:26 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:26 --> Input Class Initialized
INFO - 2017-02-02 14:19:26 --> Language Class Initialized
INFO - 2017-02-02 14:19:26 --> Loader Class Initialized
INFO - 2017-02-02 14:19:26 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:26 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:26 --> Controller Class Initialized
INFO - 2017-02-02 14:19:26 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:26 --> Model Class Initialized
INFO - 2017-02-02 14:19:26 --> Model Class Initialized
INFO - 2017-02-02 14:19:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:19:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:19:26 --> Final output sent to browser
DEBUG - 2017-02-02 14:19:26 --> Total execution time: 0.0722
INFO - 2017-02-02 14:19:30 --> Config Class Initialized
INFO - 2017-02-02 14:19:30 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:30 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:30 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:30 --> URI Class Initialized
INFO - 2017-02-02 14:19:30 --> Router Class Initialized
INFO - 2017-02-02 14:19:30 --> Output Class Initialized
INFO - 2017-02-02 14:19:30 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:30 --> Input Class Initialized
INFO - 2017-02-02 14:19:30 --> Language Class Initialized
INFO - 2017-02-02 14:19:30 --> Loader Class Initialized
INFO - 2017-02-02 14:19:30 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:30 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:30 --> Controller Class Initialized
INFO - 2017-02-02 14:19:30 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:30 --> Model Class Initialized
INFO - 2017-02-02 14:19:30 --> Model Class Initialized
INFO - 2017-02-02 14:19:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:30 --> Model Class Initialized
INFO - 2017-02-02 14:19:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:19:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-02 14:19:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:19:30 --> Final output sent to browser
DEBUG - 2017-02-02 14:19:30 --> Total execution time: 0.1151
INFO - 2017-02-02 14:19:51 --> Config Class Initialized
INFO - 2017-02-02 14:19:51 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:51 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:51 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:51 --> URI Class Initialized
INFO - 2017-02-02 14:19:51 --> Router Class Initialized
INFO - 2017-02-02 14:19:51 --> Output Class Initialized
INFO - 2017-02-02 14:19:51 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:51 --> Input Class Initialized
INFO - 2017-02-02 14:19:51 --> Language Class Initialized
INFO - 2017-02-02 14:19:51 --> Loader Class Initialized
INFO - 2017-02-02 14:19:51 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:51 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:51 --> Controller Class Initialized
INFO - 2017-02-02 14:19:51 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:51 --> Model Class Initialized
INFO - 2017-02-02 14:19:51 --> Model Class Initialized
INFO - 2017-02-02 14:19:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:51 --> Helper loaded: form_helper
INFO - 2017-02-02 14:19:51 --> Form Validation Class Initialized
INFO - 2017-02-02 14:19:51 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-02 14:19:51 --> Config Class Initialized
INFO - 2017-02-02 14:19:51 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:51 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:51 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:51 --> URI Class Initialized
INFO - 2017-02-02 14:19:51 --> Router Class Initialized
INFO - 2017-02-02 14:19:51 --> Output Class Initialized
INFO - 2017-02-02 14:19:51 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:51 --> Input Class Initialized
INFO - 2017-02-02 14:19:51 --> Language Class Initialized
INFO - 2017-02-02 14:19:51 --> Loader Class Initialized
INFO - 2017-02-02 14:19:51 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:51 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:51 --> Controller Class Initialized
INFO - 2017-02-02 14:19:51 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:51 --> Model Class Initialized
INFO - 2017-02-02 14:19:51 --> Model Class Initialized
INFO - 2017-02-02 14:19:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:19:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:19:51 --> Final output sent to browser
DEBUG - 2017-02-02 14:19:51 --> Total execution time: 0.0759
INFO - 2017-02-02 14:19:58 --> Config Class Initialized
INFO - 2017-02-02 14:19:58 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:19:58 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:19:58 --> Utf8 Class Initialized
INFO - 2017-02-02 14:19:58 --> URI Class Initialized
INFO - 2017-02-02 14:19:58 --> Router Class Initialized
INFO - 2017-02-02 14:19:58 --> Output Class Initialized
INFO - 2017-02-02 14:19:58 --> Security Class Initialized
DEBUG - 2017-02-02 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:19:58 --> Input Class Initialized
INFO - 2017-02-02 14:19:58 --> Language Class Initialized
INFO - 2017-02-02 14:19:58 --> Loader Class Initialized
INFO - 2017-02-02 14:19:58 --> Helper loaded: url_helper
INFO - 2017-02-02 14:19:58 --> Helper loaded: language_helper
INFO - 2017-02-02 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:19:58 --> Controller Class Initialized
INFO - 2017-02-02 14:19:58 --> Database Driver Class Initialized
INFO - 2017-02-02 14:19:58 --> Model Class Initialized
INFO - 2017-02-02 14:19:58 --> Model Class Initialized
INFO - 2017-02-02 14:19:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:19:58 --> Model Class Initialized
INFO - 2017-02-02 14:19:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:19:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-02 14:19:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:19:58 --> Final output sent to browser
DEBUG - 2017-02-02 14:19:58 --> Total execution time: 0.0916
INFO - 2017-02-02 14:20:03 --> Config Class Initialized
INFO - 2017-02-02 14:20:03 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:03 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:03 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:03 --> URI Class Initialized
INFO - 2017-02-02 14:20:03 --> Router Class Initialized
INFO - 2017-02-02 14:20:03 --> Output Class Initialized
INFO - 2017-02-02 14:20:03 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:03 --> Input Class Initialized
INFO - 2017-02-02 14:20:03 --> Language Class Initialized
INFO - 2017-02-02 14:20:03 --> Loader Class Initialized
INFO - 2017-02-02 14:20:03 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:03 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:03 --> Controller Class Initialized
INFO - 2017-02-02 14:20:04 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:04 --> Model Class Initialized
INFO - 2017-02-02 14:20:04 --> Model Class Initialized
INFO - 2017-02-02 14:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:04 --> Helper loaded: form_helper
INFO - 2017-02-02 14:20:04 --> Form Validation Class Initialized
INFO - 2017-02-02 14:20:04 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-02 14:20:04 --> Config Class Initialized
INFO - 2017-02-02 14:20:04 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:04 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:04 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:04 --> URI Class Initialized
INFO - 2017-02-02 14:20:04 --> Router Class Initialized
INFO - 2017-02-02 14:20:04 --> Output Class Initialized
INFO - 2017-02-02 14:20:04 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:04 --> Input Class Initialized
INFO - 2017-02-02 14:20:04 --> Language Class Initialized
INFO - 2017-02-02 14:20:04 --> Loader Class Initialized
INFO - 2017-02-02 14:20:04 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:04 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:04 --> Controller Class Initialized
INFO - 2017-02-02 14:20:04 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:04 --> Model Class Initialized
INFO - 2017-02-02 14:20:04 --> Model Class Initialized
INFO - 2017-02-02 14:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:20:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:04 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:04 --> Total execution time: 0.0707
INFO - 2017-02-02 14:20:07 --> Config Class Initialized
INFO - 2017-02-02 14:20:07 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:07 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:07 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:07 --> URI Class Initialized
INFO - 2017-02-02 14:20:07 --> Router Class Initialized
INFO - 2017-02-02 14:20:07 --> Output Class Initialized
INFO - 2017-02-02 14:20:07 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:07 --> Input Class Initialized
INFO - 2017-02-02 14:20:07 --> Language Class Initialized
INFO - 2017-02-02 14:20:07 --> Loader Class Initialized
INFO - 2017-02-02 14:20:07 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:07 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:07 --> Controller Class Initialized
INFO - 2017-02-02 14:20:07 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:07 --> Model Class Initialized
INFO - 2017-02-02 14:20:07 --> Model Class Initialized
INFO - 2017-02-02 14:20:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:20:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:07 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:07 --> Total execution time: 0.0761
INFO - 2017-02-02 14:20:10 --> Config Class Initialized
INFO - 2017-02-02 14:20:10 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:10 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:10 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:10 --> URI Class Initialized
INFO - 2017-02-02 14:20:10 --> Router Class Initialized
INFO - 2017-02-02 14:20:10 --> Output Class Initialized
INFO - 2017-02-02 14:20:10 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:10 --> Input Class Initialized
INFO - 2017-02-02 14:20:10 --> Language Class Initialized
INFO - 2017-02-02 14:20:10 --> Loader Class Initialized
INFO - 2017-02-02 14:20:10 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:10 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:10 --> Controller Class Initialized
INFO - 2017-02-02 14:20:10 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:10 --> Model Class Initialized
INFO - 2017-02-02 14:20:10 --> Model Class Initialized
INFO - 2017-02-02 14:20:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:10 --> Model Class Initialized
INFO - 2017-02-02 14:20:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-02 14:20:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:10 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:10 --> Total execution time: 0.1092
INFO - 2017-02-02 14:20:16 --> Config Class Initialized
INFO - 2017-02-02 14:20:16 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:16 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:16 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:16 --> URI Class Initialized
INFO - 2017-02-02 14:20:16 --> Router Class Initialized
INFO - 2017-02-02 14:20:16 --> Output Class Initialized
INFO - 2017-02-02 14:20:16 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:16 --> Input Class Initialized
INFO - 2017-02-02 14:20:16 --> Language Class Initialized
INFO - 2017-02-02 14:20:16 --> Loader Class Initialized
INFO - 2017-02-02 14:20:16 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:16 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:16 --> Controller Class Initialized
INFO - 2017-02-02 14:20:16 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:16 --> Model Class Initialized
INFO - 2017-02-02 14:20:16 --> Model Class Initialized
INFO - 2017-02-02 14:20:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:16 --> Helper loaded: form_helper
INFO - 2017-02-02 14:20:16 --> Form Validation Class Initialized
INFO - 2017-02-02 14:20:16 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-02 14:20:16 --> Config Class Initialized
INFO - 2017-02-02 14:20:16 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:16 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:16 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:16 --> URI Class Initialized
INFO - 2017-02-02 14:20:16 --> Router Class Initialized
INFO - 2017-02-02 14:20:16 --> Output Class Initialized
INFO - 2017-02-02 14:20:16 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:16 --> Input Class Initialized
INFO - 2017-02-02 14:20:16 --> Language Class Initialized
INFO - 2017-02-02 14:20:16 --> Loader Class Initialized
INFO - 2017-02-02 14:20:16 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:16 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:16 --> Controller Class Initialized
INFO - 2017-02-02 14:20:16 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:16 --> Model Class Initialized
INFO - 2017-02-02 14:20:16 --> Model Class Initialized
INFO - 2017-02-02 14:20:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:20:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:16 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:16 --> Total execution time: 0.0692
INFO - 2017-02-02 14:20:20 --> Config Class Initialized
INFO - 2017-02-02 14:20:20 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:20 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:20 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:20 --> URI Class Initialized
INFO - 2017-02-02 14:20:20 --> Router Class Initialized
INFO - 2017-02-02 14:20:20 --> Output Class Initialized
INFO - 2017-02-02 14:20:20 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:20 --> Input Class Initialized
INFO - 2017-02-02 14:20:20 --> Language Class Initialized
INFO - 2017-02-02 14:20:20 --> Loader Class Initialized
INFO - 2017-02-02 14:20:20 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:20 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:20 --> Controller Class Initialized
INFO - 2017-02-02 14:20:20 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:20 --> Model Class Initialized
INFO - 2017-02-02 14:20:20 --> Model Class Initialized
INFO - 2017-02-02 14:20:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:20:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:20 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:20 --> Total execution time: 0.0676
INFO - 2017-02-02 14:20:23 --> Config Class Initialized
INFO - 2017-02-02 14:20:23 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:23 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:23 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:23 --> URI Class Initialized
INFO - 2017-02-02 14:20:23 --> Router Class Initialized
INFO - 2017-02-02 14:20:23 --> Output Class Initialized
INFO - 2017-02-02 14:20:23 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:23 --> Input Class Initialized
INFO - 2017-02-02 14:20:23 --> Language Class Initialized
INFO - 2017-02-02 14:20:23 --> Loader Class Initialized
INFO - 2017-02-02 14:20:23 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:23 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:23 --> Controller Class Initialized
INFO - 2017-02-02 14:20:23 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:23 --> Model Class Initialized
INFO - 2017-02-02 14:20:23 --> Model Class Initialized
INFO - 2017-02-02 14:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:23 --> Model Class Initialized
INFO - 2017-02-02 14:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-02 14:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:23 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:23 --> Total execution time: 0.0927
INFO - 2017-02-02 14:20:29 --> Config Class Initialized
INFO - 2017-02-02 14:20:29 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:29 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:29 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:29 --> URI Class Initialized
INFO - 2017-02-02 14:20:29 --> Router Class Initialized
INFO - 2017-02-02 14:20:29 --> Output Class Initialized
INFO - 2017-02-02 14:20:29 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:29 --> Input Class Initialized
INFO - 2017-02-02 14:20:29 --> Language Class Initialized
INFO - 2017-02-02 14:20:29 --> Loader Class Initialized
INFO - 2017-02-02 14:20:29 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:29 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:29 --> Controller Class Initialized
INFO - 2017-02-02 14:20:29 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:29 --> Model Class Initialized
INFO - 2017-02-02 14:20:29 --> Model Class Initialized
INFO - 2017-02-02 14:20:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:29 --> Helper loaded: form_helper
INFO - 2017-02-02 14:20:29 --> Form Validation Class Initialized
INFO - 2017-02-02 14:20:29 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-02 14:20:29 --> Config Class Initialized
INFO - 2017-02-02 14:20:29 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:29 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:29 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:29 --> URI Class Initialized
INFO - 2017-02-02 14:20:29 --> Router Class Initialized
INFO - 2017-02-02 14:20:29 --> Output Class Initialized
INFO - 2017-02-02 14:20:29 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:29 --> Input Class Initialized
INFO - 2017-02-02 14:20:29 --> Language Class Initialized
INFO - 2017-02-02 14:20:29 --> Loader Class Initialized
INFO - 2017-02-02 14:20:29 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:29 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:29 --> Controller Class Initialized
INFO - 2017-02-02 14:20:29 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:29 --> Model Class Initialized
INFO - 2017-02-02 14:20:29 --> Model Class Initialized
INFO - 2017-02-02 14:20:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:20:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:29 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:29 --> Total execution time: 0.0770
INFO - 2017-02-02 14:20:33 --> Config Class Initialized
INFO - 2017-02-02 14:20:33 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:33 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:33 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:33 --> URI Class Initialized
INFO - 2017-02-02 14:20:33 --> Router Class Initialized
INFO - 2017-02-02 14:20:33 --> Output Class Initialized
INFO - 2017-02-02 14:20:33 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:33 --> Input Class Initialized
INFO - 2017-02-02 14:20:33 --> Language Class Initialized
INFO - 2017-02-02 14:20:33 --> Loader Class Initialized
INFO - 2017-02-02 14:20:33 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:33 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:33 --> Controller Class Initialized
INFO - 2017-02-02 14:20:33 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:33 --> Model Class Initialized
INFO - 2017-02-02 14:20:33 --> Model Class Initialized
INFO - 2017-02-02 14:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-02 14:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:33 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:33 --> Total execution time: 0.0711
INFO - 2017-02-02 14:20:35 --> Config Class Initialized
INFO - 2017-02-02 14:20:35 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:35 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:35 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:35 --> URI Class Initialized
INFO - 2017-02-02 14:20:35 --> Router Class Initialized
INFO - 2017-02-02 14:20:35 --> Output Class Initialized
INFO - 2017-02-02 14:20:35 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:35 --> Input Class Initialized
INFO - 2017-02-02 14:20:35 --> Language Class Initialized
INFO - 2017-02-02 14:20:35 --> Loader Class Initialized
INFO - 2017-02-02 14:20:35 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:35 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:35 --> Controller Class Initialized
INFO - 2017-02-02 14:20:35 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:35 --> Model Class Initialized
INFO - 2017-02-02 14:20:35 --> Model Class Initialized
INFO - 2017-02-02 14:20:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:35 --> Config Class Initialized
INFO - 2017-02-02 14:20:35 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:35 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:35 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:35 --> URI Class Initialized
INFO - 2017-02-02 14:20:35 --> Router Class Initialized
INFO - 2017-02-02 14:20:35 --> Output Class Initialized
INFO - 2017-02-02 14:20:35 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:35 --> Input Class Initialized
INFO - 2017-02-02 14:20:35 --> Language Class Initialized
INFO - 2017-02-02 14:20:35 --> Loader Class Initialized
INFO - 2017-02-02 14:20:35 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:35 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:35 --> Controller Class Initialized
INFO - 2017-02-02 14:20:35 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:35 --> Model Class Initialized
INFO - 2017-02-02 14:20:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-02 14:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-02 14:20:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-02 14:20:35 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:35 --> Total execution time: 0.0740
INFO - 2017-02-02 14:20:48 --> Config Class Initialized
INFO - 2017-02-02 14:20:48 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:48 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:48 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:48 --> URI Class Initialized
INFO - 2017-02-02 14:20:48 --> Router Class Initialized
INFO - 2017-02-02 14:20:48 --> Output Class Initialized
INFO - 2017-02-02 14:20:48 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:48 --> Input Class Initialized
INFO - 2017-02-02 14:20:48 --> Language Class Initialized
INFO - 2017-02-02 14:20:48 --> Loader Class Initialized
INFO - 2017-02-02 14:20:48 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:48 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:48 --> Controller Class Initialized
INFO - 2017-02-02 14:20:48 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:48 --> Model Class Initialized
INFO - 2017-02-02 14:20:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:48 --> Config Class Initialized
INFO - 2017-02-02 14:20:48 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:48 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:48 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:48 --> URI Class Initialized
INFO - 2017-02-02 14:20:48 --> Router Class Initialized
INFO - 2017-02-02 14:20:48 --> Output Class Initialized
INFO - 2017-02-02 14:20:48 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:48 --> Input Class Initialized
INFO - 2017-02-02 14:20:48 --> Language Class Initialized
INFO - 2017-02-02 14:20:48 --> Loader Class Initialized
INFO - 2017-02-02 14:20:48 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:48 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:48 --> Controller Class Initialized
INFO - 2017-02-02 14:20:48 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:48 --> Model Class Initialized
INFO - 2017-02-02 14:20:48 --> Model Class Initialized
INFO - 2017-02-02 14:20:48 --> Model Class Initialized
INFO - 2017-02-02 14:20:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-02 14:20:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:48 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:48 --> Total execution time: 0.0926
INFO - 2017-02-02 14:20:52 --> Config Class Initialized
INFO - 2017-02-02 14:20:52 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:52 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:52 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:52 --> URI Class Initialized
INFO - 2017-02-02 14:20:52 --> Router Class Initialized
INFO - 2017-02-02 14:20:52 --> Output Class Initialized
INFO - 2017-02-02 14:20:52 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:52 --> Input Class Initialized
INFO - 2017-02-02 14:20:52 --> Language Class Initialized
INFO - 2017-02-02 14:20:52 --> Loader Class Initialized
INFO - 2017-02-02 14:20:52 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:52 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:52 --> Controller Class Initialized
INFO - 2017-02-02 14:20:52 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:52 --> Model Class Initialized
INFO - 2017-02-02 14:20:52 --> Model Class Initialized
INFO - 2017-02-02 14:20:52 --> Model Class Initialized
INFO - 2017-02-02 14:20:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:53 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Model Class Initialized
INFO - 2017-02-02 14:20:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:53 --> Config Class Initialized
INFO - 2017-02-02 14:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:53 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:53 --> URI Class Initialized
INFO - 2017-02-02 14:20:53 --> Router Class Initialized
INFO - 2017-02-02 14:20:53 --> Output Class Initialized
INFO - 2017-02-02 14:20:53 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:53 --> Input Class Initialized
INFO - 2017-02-02 14:20:53 --> Language Class Initialized
INFO - 2017-02-02 14:20:53 --> Loader Class Initialized
INFO - 2017-02-02 14:20:53 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:53 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:53 --> Controller Class Initialized
INFO - 2017-02-02 14:20:54 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:54 --> Model Class Initialized
INFO - 2017-02-02 14:20:54 --> Model Class Initialized
INFO - 2017-02-02 14:20:54 --> Model Class Initialized
INFO - 2017-02-02 14:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-02-02 14:20:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:54 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:54 --> Total execution time: 0.0794
INFO - 2017-02-02 14:20:56 --> Config Class Initialized
INFO - 2017-02-02 14:20:56 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:56 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:56 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:56 --> URI Class Initialized
INFO - 2017-02-02 14:20:56 --> Router Class Initialized
INFO - 2017-02-02 14:20:56 --> Output Class Initialized
INFO - 2017-02-02 14:20:56 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:56 --> Input Class Initialized
INFO - 2017-02-02 14:20:56 --> Language Class Initialized
INFO - 2017-02-02 14:20:56 --> Loader Class Initialized
INFO - 2017-02-02 14:20:56 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:56 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:56 --> Controller Class Initialized
INFO - 2017-02-02 14:20:56 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:56 --> Config Class Initialized
INFO - 2017-02-02 14:20:56 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:56 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:56 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:56 --> URI Class Initialized
INFO - 2017-02-02 14:20:56 --> Router Class Initialized
INFO - 2017-02-02 14:20:56 --> Output Class Initialized
INFO - 2017-02-02 14:20:56 --> Security Class Initialized
DEBUG - 2017-02-02 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:56 --> Input Class Initialized
INFO - 2017-02-02 14:20:56 --> Language Class Initialized
INFO - 2017-02-02 14:20:56 --> Loader Class Initialized
INFO - 2017-02-02 14:20:56 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:56 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:56 --> Controller Class Initialized
INFO - 2017-02-02 14:20:56 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:56 --> Model Class Initialized
INFO - 2017-02-02 14:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-02-02 14:20:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:20:56 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:56 --> Total execution time: 0.1043
INFO - 2017-02-02 14:20:57 --> Config Class Initialized
INFO - 2017-02-02 14:20:57 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:20:57 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:57 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:57 --> URI Class Initialized
INFO - 2017-02-02 14:20:57 --> Router Class Initialized
INFO - 2017-02-02 14:20:57 --> Config Class Initialized
INFO - 2017-02-02 14:20:57 --> Hooks Class Initialized
INFO - 2017-02-02 14:20:57 --> Output Class Initialized
DEBUG - 2017-02-02 14:20:57 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:20:57 --> Utf8 Class Initialized
INFO - 2017-02-02 14:20:57 --> Security Class Initialized
INFO - 2017-02-02 14:20:57 --> URI Class Initialized
DEBUG - 2017-02-02 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:57 --> Input Class Initialized
INFO - 2017-02-02 14:20:57 --> Router Class Initialized
INFO - 2017-02-02 14:20:57 --> Language Class Initialized
INFO - 2017-02-02 14:20:57 --> Output Class Initialized
INFO - 2017-02-02 14:20:57 --> Security Class Initialized
INFO - 2017-02-02 14:20:57 --> Loader Class Initialized
INFO - 2017-02-02 14:20:57 --> Helper loaded: url_helper
DEBUG - 2017-02-02 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:20:57 --> Input Class Initialized
INFO - 2017-02-02 14:20:57 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:57 --> Language Class Initialized
INFO - 2017-02-02 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:57 --> Controller Class Initialized
INFO - 2017-02-02 14:20:57 --> Loader Class Initialized
INFO - 2017-02-02 14:20:57 --> Helper loaded: url_helper
INFO - 2017-02-02 14:20:57 --> Helper loaded: language_helper
INFO - 2017-02-02 14:20:57 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:57 --> Model Class Initialized
INFO - 2017-02-02 14:20:57 --> Model Class Initialized
INFO - 2017-02-02 14:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:20:57 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:57 --> Total execution time: 0.0907
INFO - 2017-02-02 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:20:57 --> Controller Class Initialized
INFO - 2017-02-02 14:20:57 --> Database Driver Class Initialized
INFO - 2017-02-02 14:20:57 --> Model Class Initialized
INFO - 2017-02-02 14:20:57 --> Model Class Initialized
INFO - 2017-02-02 14:20:57 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-02 14:20:57 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-02 14:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-02 14:20:57 --> Final output sent to browser
DEBUG - 2017-02-02 14:20:57 --> Total execution time: 0.1376
INFO - 2017-02-02 14:21:27 --> Config Class Initialized
INFO - 2017-02-02 14:21:27 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:21:27 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:21:27 --> Utf8 Class Initialized
INFO - 2017-02-02 14:21:27 --> URI Class Initialized
INFO - 2017-02-02 14:21:27 --> Router Class Initialized
INFO - 2017-02-02 14:21:27 --> Output Class Initialized
INFO - 2017-02-02 14:21:27 --> Security Class Initialized
DEBUG - 2017-02-02 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:21:27 --> Input Class Initialized
INFO - 2017-02-02 14:21:27 --> Language Class Initialized
INFO - 2017-02-02 14:21:27 --> Loader Class Initialized
INFO - 2017-02-02 14:21:27 --> Helper loaded: url_helper
INFO - 2017-02-02 14:21:27 --> Helper loaded: language_helper
INFO - 2017-02-02 14:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:21:27 --> Controller Class Initialized
INFO - 2017-02-02 14:21:27 --> Database Driver Class Initialized
INFO - 2017-02-02 14:21:27 --> Model Class Initialized
INFO - 2017-02-02 14:21:27 --> Model Class Initialized
INFO - 2017-02-02 14:21:27 --> Model Class Initialized
INFO - 2017-02-02 14:21:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:21:27 --> Final output sent to browser
DEBUG - 2017-02-02 14:21:27 --> Total execution time: 0.0774
INFO - 2017-02-02 14:21:57 --> Config Class Initialized
INFO - 2017-02-02 14:21:57 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:21:57 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:21:57 --> Utf8 Class Initialized
INFO - 2017-02-02 14:21:57 --> URI Class Initialized
INFO - 2017-02-02 14:21:57 --> Router Class Initialized
INFO - 2017-02-02 14:21:57 --> Output Class Initialized
INFO - 2017-02-02 14:21:57 --> Security Class Initialized
DEBUG - 2017-02-02 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:21:57 --> Input Class Initialized
INFO - 2017-02-02 14:21:57 --> Language Class Initialized
INFO - 2017-02-02 14:21:57 --> Loader Class Initialized
INFO - 2017-02-02 14:21:57 --> Helper loaded: url_helper
INFO - 2017-02-02 14:21:57 --> Helper loaded: language_helper
INFO - 2017-02-02 14:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:21:57 --> Controller Class Initialized
INFO - 2017-02-02 14:21:57 --> Database Driver Class Initialized
INFO - 2017-02-02 14:21:57 --> Model Class Initialized
INFO - 2017-02-02 14:21:57 --> Model Class Initialized
INFO - 2017-02-02 14:21:57 --> Model Class Initialized
INFO - 2017-02-02 14:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:21:57 --> Final output sent to browser
DEBUG - 2017-02-02 14:21:57 --> Total execution time: 0.0905
INFO - 2017-02-02 14:22:27 --> Config Class Initialized
INFO - 2017-02-02 14:22:27 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:22:27 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:22:27 --> Utf8 Class Initialized
INFO - 2017-02-02 14:22:27 --> URI Class Initialized
INFO - 2017-02-02 14:22:27 --> Router Class Initialized
INFO - 2017-02-02 14:22:27 --> Output Class Initialized
INFO - 2017-02-02 14:22:27 --> Security Class Initialized
DEBUG - 2017-02-02 14:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:22:27 --> Input Class Initialized
INFO - 2017-02-02 14:22:27 --> Language Class Initialized
INFO - 2017-02-02 14:22:27 --> Loader Class Initialized
INFO - 2017-02-02 14:22:27 --> Helper loaded: url_helper
INFO - 2017-02-02 14:22:27 --> Helper loaded: language_helper
INFO - 2017-02-02 14:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:22:27 --> Controller Class Initialized
INFO - 2017-02-02 14:22:27 --> Database Driver Class Initialized
INFO - 2017-02-02 14:22:27 --> Model Class Initialized
INFO - 2017-02-02 14:22:27 --> Model Class Initialized
INFO - 2017-02-02 14:22:27 --> Model Class Initialized
INFO - 2017-02-02 14:22:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:22:27 --> Final output sent to browser
DEBUG - 2017-02-02 14:22:27 --> Total execution time: 0.0715
INFO - 2017-02-02 14:22:47 --> Config Class Initialized
INFO - 2017-02-02 14:22:47 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:22:47 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:22:47 --> Utf8 Class Initialized
INFO - 2017-02-02 14:22:47 --> URI Class Initialized
INFO - 2017-02-02 14:22:47 --> Router Class Initialized
INFO - 2017-02-02 14:22:47 --> Output Class Initialized
INFO - 2017-02-02 14:22:47 --> Security Class Initialized
DEBUG - 2017-02-02 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:22:47 --> Input Class Initialized
INFO - 2017-02-02 14:22:47 --> Language Class Initialized
INFO - 2017-02-02 14:22:47 --> Loader Class Initialized
INFO - 2017-02-02 14:22:47 --> Helper loaded: url_helper
INFO - 2017-02-02 14:22:47 --> Helper loaded: language_helper
INFO - 2017-02-02 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:22:47 --> Controller Class Initialized
INFO - 2017-02-02 14:22:47 --> Database Driver Class Initialized
INFO - 2017-02-02 14:22:47 --> Model Class Initialized
INFO - 2017-02-02 14:22:47 --> Model Class Initialized
INFO - 2017-02-02 14:22:47 --> Model Class Initialized
INFO - 2017-02-02 14:22:47 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined index: correct_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 193
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined index: incorrect_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 194
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined index: pass_percentage C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 211
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
ERROR - 2017-02-02 14:22:47 --> Severity: Notice --> Undefined offset: 9 C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 268
INFO - 2017-02-02 14:22:47 --> Config Class Initialized
INFO - 2017-02-02 14:22:47 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:22:47 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:22:47 --> Utf8 Class Initialized
INFO - 2017-02-02 14:22:47 --> URI Class Initialized
INFO - 2017-02-02 14:22:47 --> Router Class Initialized
INFO - 2017-02-02 14:22:47 --> Output Class Initialized
INFO - 2017-02-02 14:22:47 --> Security Class Initialized
DEBUG - 2017-02-02 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:22:47 --> Input Class Initialized
INFO - 2017-02-02 14:22:47 --> Language Class Initialized
INFO - 2017-02-02 14:22:47 --> Loader Class Initialized
INFO - 2017-02-02 14:22:47 --> Helper loaded: url_helper
INFO - 2017-02-02 14:22:47 --> Helper loaded: language_helper
INFO - 2017-02-02 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:22:47 --> Controller Class Initialized
INFO - 2017-02-02 14:22:47 --> Database Driver Class Initialized
INFO - 2017-02-02 14:22:47 --> Model Class Initialized
INFO - 2017-02-02 14:22:47 --> Model Class Initialized
INFO - 2017-02-02 14:22:47 --> Model Class Initialized
INFO - 2017-02-02 14:22:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-02 14:22:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:22:47 --> Final output sent to browser
DEBUG - 2017-02-02 14:22:47 --> Total execution time: 0.0909
INFO - 2017-02-02 14:22:52 --> Config Class Initialized
INFO - 2017-02-02 14:22:52 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:22:52 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:22:52 --> Utf8 Class Initialized
INFO - 2017-02-02 14:22:52 --> URI Class Initialized
INFO - 2017-02-02 14:22:52 --> Router Class Initialized
INFO - 2017-02-02 14:22:52 --> Output Class Initialized
INFO - 2017-02-02 14:22:52 --> Security Class Initialized
DEBUG - 2017-02-02 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:22:52 --> Input Class Initialized
INFO - 2017-02-02 14:22:52 --> Language Class Initialized
INFO - 2017-02-02 14:22:52 --> Loader Class Initialized
INFO - 2017-02-02 14:22:52 --> Helper loaded: url_helper
INFO - 2017-02-02 14:22:52 --> Helper loaded: language_helper
INFO - 2017-02-02 14:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:22:52 --> Controller Class Initialized
INFO - 2017-02-02 14:22:52 --> Database Driver Class Initialized
INFO - 2017-02-02 14:22:52 --> Model Class Initialized
INFO - 2017-02-02 14:22:52 --> Model Class Initialized
INFO - 2017-02-02 14:22:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:22:52 --> Config Class Initialized
INFO - 2017-02-02 14:22:52 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:22:52 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:22:52 --> Utf8 Class Initialized
INFO - 2017-02-02 14:22:52 --> URI Class Initialized
INFO - 2017-02-02 14:22:52 --> Router Class Initialized
INFO - 2017-02-02 14:22:52 --> Output Class Initialized
INFO - 2017-02-02 14:22:52 --> Security Class Initialized
DEBUG - 2017-02-02 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:22:52 --> Input Class Initialized
INFO - 2017-02-02 14:22:52 --> Language Class Initialized
INFO - 2017-02-02 14:22:52 --> Loader Class Initialized
INFO - 2017-02-02 14:22:52 --> Helper loaded: url_helper
INFO - 2017-02-02 14:22:52 --> Helper loaded: language_helper
INFO - 2017-02-02 14:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:22:52 --> Controller Class Initialized
INFO - 2017-02-02 14:22:52 --> Database Driver Class Initialized
INFO - 2017-02-02 14:22:52 --> Model Class Initialized
INFO - 2017-02-02 14:22:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:22:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-02 14:22:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-02 14:22:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-02 14:22:52 --> Final output sent to browser
DEBUG - 2017-02-02 14:22:52 --> Total execution time: 0.0584
INFO - 2017-02-02 14:23:02 --> Config Class Initialized
INFO - 2017-02-02 14:23:02 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:02 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:02 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:02 --> URI Class Initialized
INFO - 2017-02-02 14:23:02 --> Router Class Initialized
INFO - 2017-02-02 14:23:02 --> Output Class Initialized
INFO - 2017-02-02 14:23:02 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:02 --> Input Class Initialized
INFO - 2017-02-02 14:23:02 --> Language Class Initialized
INFO - 2017-02-02 14:23:02 --> Loader Class Initialized
INFO - 2017-02-02 14:23:02 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:02 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:02 --> Controller Class Initialized
INFO - 2017-02-02 14:23:02 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:02 --> Model Class Initialized
INFO - 2017-02-02 14:23:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:02 --> Config Class Initialized
INFO - 2017-02-02 14:23:02 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:02 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:02 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:02 --> URI Class Initialized
INFO - 2017-02-02 14:23:02 --> Router Class Initialized
INFO - 2017-02-02 14:23:02 --> Output Class Initialized
INFO - 2017-02-02 14:23:02 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:02 --> Input Class Initialized
INFO - 2017-02-02 14:23:02 --> Language Class Initialized
INFO - 2017-02-02 14:23:02 --> Loader Class Initialized
INFO - 2017-02-02 14:23:02 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:02 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:02 --> Controller Class Initialized
INFO - 2017-02-02 14:23:02 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:02 --> Model Class Initialized
INFO - 2017-02-02 14:23:02 --> Model Class Initialized
INFO - 2017-02-02 14:23:02 --> Model Class Initialized
INFO - 2017-02-02 14:23:02 --> Model Class Initialized
INFO - 2017-02-02 14:23:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-02 14:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:23:02 --> Final output sent to browser
DEBUG - 2017-02-02 14:23:02 --> Total execution time: 0.0998
INFO - 2017-02-02 14:23:06 --> Config Class Initialized
INFO - 2017-02-02 14:23:06 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:06 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:06 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:06 --> URI Class Initialized
INFO - 2017-02-02 14:23:06 --> Router Class Initialized
INFO - 2017-02-02 14:23:06 --> Output Class Initialized
INFO - 2017-02-02 14:23:06 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:06 --> Input Class Initialized
INFO - 2017-02-02 14:23:06 --> Language Class Initialized
INFO - 2017-02-02 14:23:06 --> Loader Class Initialized
INFO - 2017-02-02 14:23:06 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:06 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:06 --> Controller Class Initialized
INFO - 2017-02-02 14:23:06 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:06 --> Model Class Initialized
INFO - 2017-02-02 14:23:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:06 --> Model Class Initialized
INFO - 2017-02-02 14:23:06 --> Helper loaded: form_helper
INFO - 2017-02-02 14:23:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:23:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 14:23:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:23:07 --> Final output sent to browser
DEBUG - 2017-02-02 14:23:07 --> Total execution time: 0.3643
INFO - 2017-02-02 14:23:13 --> Config Class Initialized
INFO - 2017-02-02 14:23:13 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:13 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:13 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:13 --> URI Class Initialized
INFO - 2017-02-02 14:23:13 --> Router Class Initialized
INFO - 2017-02-02 14:23:13 --> Output Class Initialized
INFO - 2017-02-02 14:23:13 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:13 --> Input Class Initialized
INFO - 2017-02-02 14:23:13 --> Language Class Initialized
INFO - 2017-02-02 14:23:13 --> Loader Class Initialized
INFO - 2017-02-02 14:23:13 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:13 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:13 --> Controller Class Initialized
INFO - 2017-02-02 14:23:13 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:13 --> Model Class Initialized
INFO - 2017-02-02 14:23:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:13 --> Model Class Initialized
INFO - 2017-02-02 14:23:13 --> Helper loaded: form_helper
INFO - 2017-02-02 14:23:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:23:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 14:23:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:23:13 --> Final output sent to browser
DEBUG - 2017-02-02 14:23:13 --> Total execution time: 0.3192
INFO - 2017-02-02 14:23:16 --> Config Class Initialized
INFO - 2017-02-02 14:23:16 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:16 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:16 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:16 --> URI Class Initialized
INFO - 2017-02-02 14:23:16 --> Router Class Initialized
INFO - 2017-02-02 14:23:16 --> Output Class Initialized
INFO - 2017-02-02 14:23:16 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:16 --> Input Class Initialized
INFO - 2017-02-02 14:23:16 --> Language Class Initialized
INFO - 2017-02-02 14:23:16 --> Loader Class Initialized
INFO - 2017-02-02 14:23:16 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:16 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:16 --> Controller Class Initialized
INFO - 2017-02-02 14:23:16 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:16 --> Model Class Initialized
INFO - 2017-02-02 14:23:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:16 --> Model Class Initialized
INFO - 2017-02-02 14:23:16 --> Helper loaded: form_helper
INFO - 2017-02-02 14:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 14:23:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:23:16 --> Final output sent to browser
DEBUG - 2017-02-02 14:23:16 --> Total execution time: 0.0956
INFO - 2017-02-02 14:23:18 --> Config Class Initialized
INFO - 2017-02-02 14:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:18 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:18 --> URI Class Initialized
INFO - 2017-02-02 14:23:18 --> Router Class Initialized
INFO - 2017-02-02 14:23:18 --> Output Class Initialized
INFO - 2017-02-02 14:23:18 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:18 --> Input Class Initialized
INFO - 2017-02-02 14:23:18 --> Language Class Initialized
INFO - 2017-02-02 14:23:18 --> Loader Class Initialized
INFO - 2017-02-02 14:23:18 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:18 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:18 --> Controller Class Initialized
INFO - 2017-02-02 14:23:19 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:19 --> Model Class Initialized
INFO - 2017-02-02 14:23:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:19 --> Model Class Initialized
INFO - 2017-02-02 14:23:19 --> Helper loaded: form_helper
INFO - 2017-02-02 14:23:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:23:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 14:23:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:23:19 --> Final output sent to browser
DEBUG - 2017-02-02 14:23:19 --> Total execution time: 0.2773
INFO - 2017-02-02 14:23:30 --> Config Class Initialized
INFO - 2017-02-02 14:23:30 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:23:30 --> Utf8 Class Initialized
INFO - 2017-02-02 14:23:30 --> URI Class Initialized
INFO - 2017-02-02 14:23:30 --> Router Class Initialized
INFO - 2017-02-02 14:23:30 --> Output Class Initialized
INFO - 2017-02-02 14:23:30 --> Security Class Initialized
DEBUG - 2017-02-02 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:23:30 --> Input Class Initialized
INFO - 2017-02-02 14:23:30 --> Language Class Initialized
INFO - 2017-02-02 14:23:30 --> Loader Class Initialized
INFO - 2017-02-02 14:23:30 --> Helper loaded: url_helper
INFO - 2017-02-02 14:23:30 --> Helper loaded: language_helper
INFO - 2017-02-02 14:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:23:30 --> Controller Class Initialized
INFO - 2017-02-02 14:23:30 --> Database Driver Class Initialized
INFO - 2017-02-02 14:23:30 --> Model Class Initialized
INFO - 2017-02-02 14:23:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:23:30 --> Model Class Initialized
INFO - 2017-02-02 14:23:30 --> Helper loaded: form_helper
INFO - 2017-02-02 14:23:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:23:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 14:23:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:23:30 --> Final output sent to browser
DEBUG - 2017-02-02 14:23:30 --> Total execution time: 0.3543
INFO - 2017-02-02 14:24:12 --> Config Class Initialized
INFO - 2017-02-02 14:24:12 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:24:12 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:24:12 --> Utf8 Class Initialized
INFO - 2017-02-02 14:24:12 --> URI Class Initialized
INFO - 2017-02-02 14:24:12 --> Router Class Initialized
INFO - 2017-02-02 14:24:12 --> Output Class Initialized
INFO - 2017-02-02 14:24:12 --> Security Class Initialized
DEBUG - 2017-02-02 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:24:12 --> Input Class Initialized
INFO - 2017-02-02 14:24:12 --> Language Class Initialized
INFO - 2017-02-02 14:24:12 --> Loader Class Initialized
INFO - 2017-02-02 14:24:12 --> Helper loaded: url_helper
INFO - 2017-02-02 14:24:12 --> Helper loaded: language_helper
INFO - 2017-02-02 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:24:12 --> Controller Class Initialized
INFO - 2017-02-02 14:24:12 --> Database Driver Class Initialized
INFO - 2017-02-02 14:24:12 --> Model Class Initialized
INFO - 2017-02-02 14:24:12 --> Model Class Initialized
INFO - 2017-02-02 14:24:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:24:12 --> Helper loaded: form_helper
INFO - 2017-02-02 14:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:24:12 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:24:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:24:12 --> Final output sent to browser
DEBUG - 2017-02-02 14:24:12 --> Total execution time: 0.1070
INFO - 2017-02-02 14:24:15 --> Config Class Initialized
INFO - 2017-02-02 14:24:15 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:24:15 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:24:15 --> Utf8 Class Initialized
INFO - 2017-02-02 14:24:15 --> URI Class Initialized
INFO - 2017-02-02 14:24:15 --> Router Class Initialized
INFO - 2017-02-02 14:24:15 --> Output Class Initialized
INFO - 2017-02-02 14:24:15 --> Security Class Initialized
DEBUG - 2017-02-02 14:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:24:15 --> Input Class Initialized
INFO - 2017-02-02 14:24:15 --> Language Class Initialized
INFO - 2017-02-02 14:24:15 --> Loader Class Initialized
INFO - 2017-02-02 14:24:15 --> Helper loaded: url_helper
INFO - 2017-02-02 14:24:15 --> Helper loaded: language_helper
INFO - 2017-02-02 14:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:24:15 --> Controller Class Initialized
INFO - 2017-02-02 14:24:15 --> Database Driver Class Initialized
INFO - 2017-02-02 14:24:15 --> Model Class Initialized
INFO - 2017-02-02 14:24:15 --> Model Class Initialized
INFO - 2017-02-02 14:24:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:24:15 --> Helper loaded: form_helper
INFO - 2017-02-02 14:24:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:24:15 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:24:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:24:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:24:15 --> Final output sent to browser
DEBUG - 2017-02-02 14:24:15 --> Total execution time: 0.0723
INFO - 2017-02-02 14:34:52 --> Config Class Initialized
INFO - 2017-02-02 14:34:52 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:34:52 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:34:52 --> Utf8 Class Initialized
INFO - 2017-02-02 14:34:52 --> URI Class Initialized
INFO - 2017-02-02 14:34:52 --> Router Class Initialized
INFO - 2017-02-02 14:34:52 --> Output Class Initialized
INFO - 2017-02-02 14:34:52 --> Security Class Initialized
DEBUG - 2017-02-02 14:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:34:52 --> Input Class Initialized
INFO - 2017-02-02 14:34:52 --> Language Class Initialized
INFO - 2017-02-02 14:34:52 --> Loader Class Initialized
INFO - 2017-02-02 14:34:52 --> Helper loaded: url_helper
INFO - 2017-02-02 14:34:52 --> Helper loaded: language_helper
INFO - 2017-02-02 14:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:34:52 --> Controller Class Initialized
INFO - 2017-02-02 14:34:52 --> Database Driver Class Initialized
INFO - 2017-02-02 14:34:52 --> Model Class Initialized
INFO - 2017-02-02 14:34:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:34:52 --> Helper loaded: form_helper
INFO - 2017-02-02 14:34:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:34:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:34:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:34:52 --> Final output sent to browser
DEBUG - 2017-02-02 14:34:52 --> Total execution time: 0.1265
INFO - 2017-02-02 14:34:56 --> Config Class Initialized
INFO - 2017-02-02 14:34:56 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:34:56 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:34:56 --> Utf8 Class Initialized
INFO - 2017-02-02 14:34:56 --> URI Class Initialized
INFO - 2017-02-02 14:34:56 --> Router Class Initialized
INFO - 2017-02-02 14:34:56 --> Output Class Initialized
INFO - 2017-02-02 14:34:56 --> Security Class Initialized
DEBUG - 2017-02-02 14:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:34:56 --> Input Class Initialized
INFO - 2017-02-02 14:34:56 --> Language Class Initialized
INFO - 2017-02-02 14:34:56 --> Loader Class Initialized
INFO - 2017-02-02 14:34:56 --> Helper loaded: url_helper
INFO - 2017-02-02 14:34:56 --> Helper loaded: language_helper
INFO - 2017-02-02 14:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:34:56 --> Controller Class Initialized
INFO - 2017-02-02 14:34:56 --> Database Driver Class Initialized
INFO - 2017-02-02 14:34:56 --> Model Class Initialized
INFO - 2017-02-02 14:34:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:34:56 --> Helper loaded: form_helper
INFO - 2017-02-02 14:34:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:34:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:34:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:34:57 --> Final output sent to browser
DEBUG - 2017-02-02 14:34:57 --> Total execution time: 0.1052
INFO - 2017-02-02 14:35:02 --> Config Class Initialized
INFO - 2017-02-02 14:35:02 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:35:02 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:35:02 --> Utf8 Class Initialized
INFO - 2017-02-02 14:35:02 --> URI Class Initialized
INFO - 2017-02-02 14:35:02 --> Router Class Initialized
INFO - 2017-02-02 14:35:02 --> Output Class Initialized
INFO - 2017-02-02 14:35:02 --> Security Class Initialized
DEBUG - 2017-02-02 14:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:35:02 --> Input Class Initialized
INFO - 2017-02-02 14:35:02 --> Language Class Initialized
INFO - 2017-02-02 14:35:02 --> Loader Class Initialized
INFO - 2017-02-02 14:35:02 --> Helper loaded: url_helper
INFO - 2017-02-02 14:35:02 --> Helper loaded: language_helper
INFO - 2017-02-02 14:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:35:02 --> Controller Class Initialized
INFO - 2017-02-02 14:35:02 --> Database Driver Class Initialized
INFO - 2017-02-02 14:35:02 --> Model Class Initialized
INFO - 2017-02-02 14:35:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:35:02 --> Helper loaded: form_helper
INFO - 2017-02-02 14:35:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:35:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:35:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:35:02 --> Final output sent to browser
DEBUG - 2017-02-02 14:35:02 --> Total execution time: 0.1023
INFO - 2017-02-02 14:35:04 --> Config Class Initialized
INFO - 2017-02-02 14:35:04 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:35:04 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:35:04 --> Utf8 Class Initialized
INFO - 2017-02-02 14:35:04 --> URI Class Initialized
INFO - 2017-02-02 14:35:04 --> Router Class Initialized
INFO - 2017-02-02 14:35:04 --> Output Class Initialized
INFO - 2017-02-02 14:35:04 --> Security Class Initialized
DEBUG - 2017-02-02 14:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:35:04 --> Input Class Initialized
INFO - 2017-02-02 14:35:04 --> Language Class Initialized
INFO - 2017-02-02 14:35:04 --> Loader Class Initialized
INFO - 2017-02-02 14:35:04 --> Helper loaded: url_helper
INFO - 2017-02-02 14:35:04 --> Helper loaded: language_helper
INFO - 2017-02-02 14:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:35:04 --> Controller Class Initialized
INFO - 2017-02-02 14:35:04 --> Database Driver Class Initialized
INFO - 2017-02-02 14:35:04 --> Model Class Initialized
INFO - 2017-02-02 14:35:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:35:04 --> Helper loaded: form_helper
INFO - 2017-02-02 14:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:35:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:35:04 --> Final output sent to browser
DEBUG - 2017-02-02 14:35:04 --> Total execution time: 0.1180
INFO - 2017-02-02 14:44:42 --> Config Class Initialized
INFO - 2017-02-02 14:44:42 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:44:42 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:44:42 --> Utf8 Class Initialized
INFO - 2017-02-02 14:44:42 --> URI Class Initialized
INFO - 2017-02-02 14:44:42 --> Router Class Initialized
INFO - 2017-02-02 14:44:42 --> Output Class Initialized
INFO - 2017-02-02 14:44:42 --> Security Class Initialized
DEBUG - 2017-02-02 14:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:44:42 --> Input Class Initialized
INFO - 2017-02-02 14:44:42 --> Language Class Initialized
INFO - 2017-02-02 14:44:42 --> Loader Class Initialized
INFO - 2017-02-02 14:44:42 --> Helper loaded: url_helper
INFO - 2017-02-02 14:44:42 --> Helper loaded: language_helper
INFO - 2017-02-02 14:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:44:42 --> Controller Class Initialized
INFO - 2017-02-02 14:44:42 --> Database Driver Class Initialized
INFO - 2017-02-02 14:44:42 --> Model Class Initialized
INFO - 2017-02-02 14:44:42 --> Model Class Initialized
INFO - 2017-02-02 14:44:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:44:42 --> Helper loaded: form_helper
INFO - 2017-02-02 14:44:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:44:42 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:44:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:44:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:44:42 --> Final output sent to browser
DEBUG - 2017-02-02 14:44:42 --> Total execution time: 0.0790
INFO - 2017-02-02 14:44:46 --> Config Class Initialized
INFO - 2017-02-02 14:44:46 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:44:46 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:44:46 --> Utf8 Class Initialized
INFO - 2017-02-02 14:44:46 --> URI Class Initialized
INFO - 2017-02-02 14:44:46 --> Router Class Initialized
INFO - 2017-02-02 14:44:46 --> Output Class Initialized
INFO - 2017-02-02 14:44:46 --> Security Class Initialized
DEBUG - 2017-02-02 14:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:44:46 --> Input Class Initialized
INFO - 2017-02-02 14:44:46 --> Language Class Initialized
INFO - 2017-02-02 14:44:46 --> Loader Class Initialized
INFO - 2017-02-02 14:44:46 --> Helper loaded: url_helper
INFO - 2017-02-02 14:44:46 --> Helper loaded: language_helper
INFO - 2017-02-02 14:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:44:46 --> Controller Class Initialized
INFO - 2017-02-02 14:44:46 --> Database Driver Class Initialized
INFO - 2017-02-02 14:44:46 --> Model Class Initialized
INFO - 2017-02-02 14:44:46 --> Model Class Initialized
INFO - 2017-02-02 14:44:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:44:46 --> Helper loaded: form_helper
INFO - 2017-02-02 14:44:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-02 14:44:46 --> Could not find the language line "import_user"
INFO - 2017-02-02 14:44:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-02 14:44:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:44:46 --> Final output sent to browser
DEBUG - 2017-02-02 14:44:46 --> Total execution time: 0.0786
INFO - 2017-02-02 14:45:49 --> Config Class Initialized
INFO - 2017-02-02 14:45:49 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:45:49 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:45:49 --> Utf8 Class Initialized
INFO - 2017-02-02 14:45:49 --> URI Class Initialized
INFO - 2017-02-02 14:45:49 --> Router Class Initialized
INFO - 2017-02-02 14:45:49 --> Output Class Initialized
INFO - 2017-02-02 14:45:49 --> Security Class Initialized
DEBUG - 2017-02-02 14:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:45:49 --> Input Class Initialized
INFO - 2017-02-02 14:45:49 --> Language Class Initialized
INFO - 2017-02-02 14:45:49 --> Loader Class Initialized
INFO - 2017-02-02 14:45:49 --> Helper loaded: url_helper
INFO - 2017-02-02 14:45:49 --> Helper loaded: language_helper
INFO - 2017-02-02 14:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:45:49 --> Controller Class Initialized
INFO - 2017-02-02 14:45:49 --> Database Driver Class Initialized
INFO - 2017-02-02 14:45:49 --> Model Class Initialized
INFO - 2017-02-02 14:45:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:45:49 --> Helper loaded: form_helper
INFO - 2017-02-02 14:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:45:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:45:49 --> Final output sent to browser
DEBUG - 2017-02-02 14:45:49 --> Total execution time: 0.1209
INFO - 2017-02-02 14:46:16 --> Config Class Initialized
INFO - 2017-02-02 14:46:16 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:46:16 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:46:16 --> Utf8 Class Initialized
INFO - 2017-02-02 14:46:16 --> URI Class Initialized
INFO - 2017-02-02 14:46:16 --> Router Class Initialized
INFO - 2017-02-02 14:46:16 --> Output Class Initialized
INFO - 2017-02-02 14:46:16 --> Security Class Initialized
DEBUG - 2017-02-02 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:46:16 --> Input Class Initialized
INFO - 2017-02-02 14:46:16 --> Language Class Initialized
INFO - 2017-02-02 14:46:16 --> Loader Class Initialized
INFO - 2017-02-02 14:46:16 --> Helper loaded: url_helper
INFO - 2017-02-02 14:46:16 --> Helper loaded: language_helper
INFO - 2017-02-02 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:46:16 --> Controller Class Initialized
INFO - 2017-02-02 14:46:16 --> Database Driver Class Initialized
INFO - 2017-02-02 14:46:16 --> Model Class Initialized
INFO - 2017-02-02 14:46:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:46:16 --> Model Class Initialized
INFO - 2017-02-02 14:46:16 --> Model Class Initialized
INFO - 2017-02-02 14:46:16 --> Helper loaded: form_helper
INFO - 2017-02-02 14:46:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:46:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-02 14:46:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:46:16 --> Final output sent to browser
DEBUG - 2017-02-02 14:46:16 --> Total execution time: 0.1516
INFO - 2017-02-02 14:46:47 --> Config Class Initialized
INFO - 2017-02-02 14:46:47 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:46:47 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:46:47 --> Utf8 Class Initialized
INFO - 2017-02-02 14:46:47 --> URI Class Initialized
INFO - 2017-02-02 14:46:47 --> Router Class Initialized
INFO - 2017-02-02 14:46:47 --> Output Class Initialized
INFO - 2017-02-02 14:46:47 --> Security Class Initialized
DEBUG - 2017-02-02 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:46:47 --> Input Class Initialized
INFO - 2017-02-02 14:46:47 --> Language Class Initialized
INFO - 2017-02-02 14:46:47 --> Loader Class Initialized
INFO - 2017-02-02 14:46:47 --> Helper loaded: url_helper
INFO - 2017-02-02 14:46:47 --> Helper loaded: language_helper
INFO - 2017-02-02 14:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:46:47 --> Controller Class Initialized
INFO - 2017-02-02 14:46:47 --> Database Driver Class Initialized
INFO - 2017-02-02 14:46:47 --> Model Class Initialized
INFO - 2017-02-02 14:46:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:46:47 --> Helper loaded: form_helper
INFO - 2017-02-02 14:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:46:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:46:47 --> Final output sent to browser
DEBUG - 2017-02-02 14:46:47 --> Total execution time: 0.1436
INFO - 2017-02-02 14:46:59 --> Config Class Initialized
INFO - 2017-02-02 14:46:59 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:46:59 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:46:59 --> Utf8 Class Initialized
INFO - 2017-02-02 14:46:59 --> URI Class Initialized
INFO - 2017-02-02 14:46:59 --> Router Class Initialized
INFO - 2017-02-02 14:46:59 --> Output Class Initialized
INFO - 2017-02-02 14:46:59 --> Security Class Initialized
DEBUG - 2017-02-02 14:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:46:59 --> Input Class Initialized
INFO - 2017-02-02 14:46:59 --> Language Class Initialized
INFO - 2017-02-02 14:46:59 --> Loader Class Initialized
INFO - 2017-02-02 14:46:59 --> Helper loaded: url_helper
INFO - 2017-02-02 14:46:59 --> Helper loaded: language_helper
INFO - 2017-02-02 14:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:46:59 --> Controller Class Initialized
INFO - 2017-02-02 14:46:59 --> Database Driver Class Initialized
INFO - 2017-02-02 14:46:59 --> Model Class Initialized
INFO - 2017-02-02 14:46:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:46:59 --> Model Class Initialized
INFO - 2017-02-02 14:46:59 --> Helper loaded: form_helper
INFO - 2017-02-02 14:46:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:46:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 14:46:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:46:59 --> Final output sent to browser
DEBUG - 2017-02-02 14:46:59 --> Total execution time: 0.3424
INFO - 2017-02-02 14:47:30 --> Config Class Initialized
INFO - 2017-02-02 14:47:30 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:47:30 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:47:30 --> Utf8 Class Initialized
INFO - 2017-02-02 14:47:30 --> URI Class Initialized
INFO - 2017-02-02 14:47:30 --> Router Class Initialized
INFO - 2017-02-02 14:47:30 --> Output Class Initialized
INFO - 2017-02-02 14:47:30 --> Security Class Initialized
DEBUG - 2017-02-02 14:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:47:30 --> Input Class Initialized
INFO - 2017-02-02 14:47:30 --> Language Class Initialized
INFO - 2017-02-02 14:47:30 --> Loader Class Initialized
INFO - 2017-02-02 14:47:30 --> Helper loaded: url_helper
INFO - 2017-02-02 14:47:30 --> Helper loaded: language_helper
INFO - 2017-02-02 14:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:47:30 --> Controller Class Initialized
INFO - 2017-02-02 14:47:30 --> Database Driver Class Initialized
INFO - 2017-02-02 14:47:30 --> Model Class Initialized
INFO - 2017-02-02 14:47:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:47:30 --> Model Class Initialized
INFO - 2017-02-02 14:47:30 --> Model Class Initialized
INFO - 2017-02-02 14:47:30 --> Helper loaded: form_helper
INFO - 2017-02-02 14:47:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:47:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_disc.php
INFO - 2017-02-02 14:47:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:47:30 --> Final output sent to browser
DEBUG - 2017-02-02 14:47:30 --> Total execution time: 0.0877
INFO - 2017-02-02 14:47:55 --> Config Class Initialized
INFO - 2017-02-02 14:47:55 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:47:55 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:47:55 --> Utf8 Class Initialized
INFO - 2017-02-02 14:47:55 --> URI Class Initialized
INFO - 2017-02-02 14:47:55 --> Router Class Initialized
INFO - 2017-02-02 14:47:55 --> Output Class Initialized
INFO - 2017-02-02 14:47:55 --> Security Class Initialized
DEBUG - 2017-02-02 14:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:47:55 --> Input Class Initialized
INFO - 2017-02-02 14:47:55 --> Language Class Initialized
INFO - 2017-02-02 14:47:55 --> Loader Class Initialized
INFO - 2017-02-02 14:47:55 --> Helper loaded: url_helper
INFO - 2017-02-02 14:47:55 --> Helper loaded: language_helper
INFO - 2017-02-02 14:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:47:55 --> Controller Class Initialized
INFO - 2017-02-02 14:47:55 --> Database Driver Class Initialized
INFO - 2017-02-02 14:47:55 --> Model Class Initialized
INFO - 2017-02-02 14:47:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:47:55 --> Helper loaded: form_helper
INFO - 2017-02-02 14:47:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:47:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-02 14:47:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:47:55 --> Final output sent to browser
DEBUG - 2017-02-02 14:47:55 --> Total execution time: 0.0992
INFO - 2017-02-02 14:48:01 --> Config Class Initialized
INFO - 2017-02-02 14:48:01 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:48:01 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:48:01 --> Utf8 Class Initialized
INFO - 2017-02-02 14:48:01 --> URI Class Initialized
INFO - 2017-02-02 14:48:01 --> Router Class Initialized
INFO - 2017-02-02 14:48:01 --> Output Class Initialized
INFO - 2017-02-02 14:48:01 --> Security Class Initialized
DEBUG - 2017-02-02 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:48:01 --> Input Class Initialized
INFO - 2017-02-02 14:48:01 --> Language Class Initialized
INFO - 2017-02-02 14:48:01 --> Loader Class Initialized
INFO - 2017-02-02 14:48:01 --> Helper loaded: url_helper
INFO - 2017-02-02 14:48:01 --> Helper loaded: language_helper
INFO - 2017-02-02 14:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:48:01 --> Controller Class Initialized
INFO - 2017-02-02 14:48:01 --> Database Driver Class Initialized
INFO - 2017-02-02 14:48:01 --> Model Class Initialized
INFO - 2017-02-02 14:48:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:48:01 --> Helper loaded: form_helper
INFO - 2017-02-02 14:48:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:48:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:48:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:48:01 --> Final output sent to browser
DEBUG - 2017-02-02 14:48:01 --> Total execution time: 0.0995
INFO - 2017-02-02 14:48:12 --> Config Class Initialized
INFO - 2017-02-02 14:48:12 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:48:12 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:48:12 --> Utf8 Class Initialized
INFO - 2017-02-02 14:48:12 --> URI Class Initialized
INFO - 2017-02-02 14:48:12 --> Router Class Initialized
INFO - 2017-02-02 14:48:12 --> Output Class Initialized
INFO - 2017-02-02 14:48:12 --> Security Class Initialized
DEBUG - 2017-02-02 14:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:48:12 --> Input Class Initialized
INFO - 2017-02-02 14:48:12 --> Language Class Initialized
INFO - 2017-02-02 14:48:12 --> Loader Class Initialized
INFO - 2017-02-02 14:48:12 --> Helper loaded: url_helper
INFO - 2017-02-02 14:48:12 --> Helper loaded: language_helper
INFO - 2017-02-02 14:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:48:12 --> Controller Class Initialized
INFO - 2017-02-02 14:48:12 --> Database Driver Class Initialized
INFO - 2017-02-02 14:48:12 --> Model Class Initialized
INFO - 2017-02-02 14:48:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:48:12 --> Model Class Initialized
INFO - 2017-02-02 14:48:12 --> Model Class Initialized
INFO - 2017-02-02 14:48:12 --> Helper loaded: form_helper
INFO - 2017-02-02 14:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-02 14:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:48:12 --> Final output sent to browser
DEBUG - 2017-02-02 14:48:12 --> Total execution time: 0.1108
INFO - 2017-02-02 14:49:54 --> Config Class Initialized
INFO - 2017-02-02 14:49:54 --> Hooks Class Initialized
DEBUG - 2017-02-02 14:49:54 --> UTF-8 Support Enabled
INFO - 2017-02-02 14:49:54 --> Utf8 Class Initialized
INFO - 2017-02-02 14:49:54 --> URI Class Initialized
INFO - 2017-02-02 14:49:54 --> Router Class Initialized
INFO - 2017-02-02 14:49:54 --> Output Class Initialized
INFO - 2017-02-02 14:49:54 --> Security Class Initialized
DEBUG - 2017-02-02 14:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 14:49:54 --> Input Class Initialized
INFO - 2017-02-02 14:49:54 --> Language Class Initialized
INFO - 2017-02-02 14:49:54 --> Loader Class Initialized
INFO - 2017-02-02 14:49:54 --> Helper loaded: url_helper
INFO - 2017-02-02 14:49:54 --> Helper loaded: language_helper
INFO - 2017-02-02 14:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 14:49:54 --> Controller Class Initialized
INFO - 2017-02-02 14:49:54 --> Database Driver Class Initialized
INFO - 2017-02-02 14:49:54 --> Model Class Initialized
INFO - 2017-02-02 14:49:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 14:49:54 --> Helper loaded: form_helper
INFO - 2017-02-02 14:49:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 14:49:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-02 14:49:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 14:49:54 --> Final output sent to browser
DEBUG - 2017-02-02 14:49:54 --> Total execution time: 0.1085
INFO - 2017-02-02 15:07:22 --> Config Class Initialized
INFO - 2017-02-02 15:07:22 --> Hooks Class Initialized
DEBUG - 2017-02-02 15:07:22 --> UTF-8 Support Enabled
INFO - 2017-02-02 15:07:22 --> Utf8 Class Initialized
INFO - 2017-02-02 15:07:22 --> URI Class Initialized
INFO - 2017-02-02 15:07:22 --> Router Class Initialized
INFO - 2017-02-02 15:07:22 --> Output Class Initialized
INFO - 2017-02-02 15:07:22 --> Security Class Initialized
DEBUG - 2017-02-02 15:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 15:07:22 --> Input Class Initialized
INFO - 2017-02-02 15:07:22 --> Language Class Initialized
INFO - 2017-02-02 15:07:22 --> Loader Class Initialized
INFO - 2017-02-02 15:07:22 --> Helper loaded: url_helper
INFO - 2017-02-02 15:07:22 --> Helper loaded: language_helper
INFO - 2017-02-02 15:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 15:07:22 --> Controller Class Initialized
INFO - 2017-02-02 15:07:22 --> Database Driver Class Initialized
INFO - 2017-02-02 15:07:22 --> Model Class Initialized
INFO - 2017-02-02 15:07:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 15:07:22 --> Model Class Initialized
INFO - 2017-02-02 15:07:22 --> Helper loaded: form_helper
INFO - 2017-02-02 15:07:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 15:07:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-02 15:07:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 15:07:23 --> Final output sent to browser
DEBUG - 2017-02-02 15:07:23 --> Total execution time: 0.4276
INFO - 2017-02-02 15:07:24 --> Config Class Initialized
INFO - 2017-02-02 15:07:24 --> Hooks Class Initialized
DEBUG - 2017-02-02 15:07:24 --> UTF-8 Support Enabled
INFO - 2017-02-02 15:07:24 --> Utf8 Class Initialized
INFO - 2017-02-02 15:07:24 --> URI Class Initialized
INFO - 2017-02-02 15:07:24 --> Router Class Initialized
INFO - 2017-02-02 15:07:24 --> Output Class Initialized
INFO - 2017-02-02 15:07:24 --> Security Class Initialized
DEBUG - 2017-02-02 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 15:07:24 --> Input Class Initialized
INFO - 2017-02-02 15:07:24 --> Language Class Initialized
INFO - 2017-02-02 15:07:24 --> Loader Class Initialized
INFO - 2017-02-02 15:07:24 --> Helper loaded: url_helper
INFO - 2017-02-02 15:07:24 --> Helper loaded: language_helper
INFO - 2017-02-02 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 15:07:24 --> Controller Class Initialized
INFO - 2017-02-02 15:07:24 --> Database Driver Class Initialized
INFO - 2017-02-02 15:07:24 --> Model Class Initialized
INFO - 2017-02-02 15:07:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 15:07:24 --> Model Class Initialized
INFO - 2017-02-02 15:07:24 --> Model Class Initialized
INFO - 2017-02-02 15:07:24 --> Helper loaded: form_helper
INFO - 2017-02-02 15:07:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 15:07:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_disc.php
INFO - 2017-02-02 15:07:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 15:07:24 --> Final output sent to browser
DEBUG - 2017-02-02 15:07:24 --> Total execution time: 0.1308
INFO - 2017-02-02 15:07:51 --> Config Class Initialized
INFO - 2017-02-02 15:07:51 --> Hooks Class Initialized
DEBUG - 2017-02-02 15:07:51 --> UTF-8 Support Enabled
INFO - 2017-02-02 15:07:51 --> Utf8 Class Initialized
INFO - 2017-02-02 15:07:51 --> URI Class Initialized
INFO - 2017-02-02 15:07:51 --> Router Class Initialized
INFO - 2017-02-02 15:07:51 --> Output Class Initialized
INFO - 2017-02-02 15:07:51 --> Security Class Initialized
DEBUG - 2017-02-02 15:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-02 15:07:51 --> Input Class Initialized
INFO - 2017-02-02 15:07:51 --> Language Class Initialized
INFO - 2017-02-02 15:07:51 --> Loader Class Initialized
INFO - 2017-02-02 15:07:51 --> Helper loaded: url_helper
INFO - 2017-02-02 15:07:51 --> Helper loaded: language_helper
INFO - 2017-02-02 15:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-02 15:07:51 --> Controller Class Initialized
INFO - 2017-02-02 15:07:51 --> Database Driver Class Initialized
INFO - 2017-02-02 15:07:51 --> Model Class Initialized
INFO - 2017-02-02 15:07:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-02 15:07:51 --> Model Class Initialized
INFO - 2017-02-02 15:07:51 --> Model Class Initialized
INFO - 2017-02-02 15:07:51 --> Helper loaded: form_helper
INFO - 2017-02-02 15:07:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-02 15:07:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_disc.php
INFO - 2017-02-02 15:07:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-02 15:07:51 --> Final output sent to browser
DEBUG - 2017-02-02 15:07:51 --> Total execution time: 0.0912
