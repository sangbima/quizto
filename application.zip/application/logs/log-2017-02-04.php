<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-04 16:20:12 --> Config Class Initialized
INFO - 2017-02-04 16:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:12 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:12 --> URI Class Initialized
INFO - 2017-02-04 16:20:12 --> Router Class Initialized
INFO - 2017-02-04 16:20:12 --> Output Class Initialized
INFO - 2017-02-04 16:20:12 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:12 --> Input Class Initialized
INFO - 2017-02-04 16:20:12 --> Language Class Initialized
INFO - 2017-02-04 16:20:12 --> Loader Class Initialized
INFO - 2017-02-04 16:20:12 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:12 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:12 --> Controller Class Initialized
INFO - 2017-02-04 16:20:12 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:12 --> Model Class Initialized
INFO - 2017-02-04 16:20:12 --> Model Class Initialized
INFO - 2017-02-04 16:20:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:12 --> Config Class Initialized
INFO - 2017-02-04 16:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:12 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:12 --> URI Class Initialized
INFO - 2017-02-04 16:20:12 --> Router Class Initialized
INFO - 2017-02-04 16:20:12 --> Output Class Initialized
INFO - 2017-02-04 16:20:12 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:12 --> Input Class Initialized
INFO - 2017-02-04 16:20:12 --> Language Class Initialized
INFO - 2017-02-04 16:20:12 --> Loader Class Initialized
INFO - 2017-02-04 16:20:12 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:12 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:12 --> Controller Class Initialized
INFO - 2017-02-04 16:20:12 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:12 --> Model Class Initialized
INFO - 2017-02-04 16:20:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-04 16:20:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-04 16:20:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-04 16:20:12 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:12 --> Total execution time: 0.0615
INFO - 2017-02-04 16:20:19 --> Config Class Initialized
INFO - 2017-02-04 16:20:19 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:19 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:19 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:19 --> URI Class Initialized
INFO - 2017-02-04 16:20:19 --> Router Class Initialized
INFO - 2017-02-04 16:20:19 --> Output Class Initialized
INFO - 2017-02-04 16:20:19 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:19 --> Input Class Initialized
INFO - 2017-02-04 16:20:19 --> Language Class Initialized
INFO - 2017-02-04 16:20:19 --> Loader Class Initialized
INFO - 2017-02-04 16:20:19 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:19 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:19 --> Controller Class Initialized
INFO - 2017-02-04 16:20:19 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:19 --> Model Class Initialized
INFO - 2017-02-04 16:20:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:19 --> Config Class Initialized
INFO - 2017-02-04 16:20:19 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:19 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:19 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:19 --> URI Class Initialized
INFO - 2017-02-04 16:20:19 --> Router Class Initialized
INFO - 2017-02-04 16:20:19 --> Output Class Initialized
INFO - 2017-02-04 16:20:19 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:19 --> Input Class Initialized
INFO - 2017-02-04 16:20:19 --> Language Class Initialized
INFO - 2017-02-04 16:20:19 --> Loader Class Initialized
INFO - 2017-02-04 16:20:19 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:19 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:19 --> Controller Class Initialized
INFO - 2017-02-04 16:20:19 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:19 --> Model Class Initialized
INFO - 2017-02-04 16:20:19 --> Model Class Initialized
INFO - 2017-02-04 16:20:19 --> Model Class Initialized
INFO - 2017-02-04 16:20:19 --> Model Class Initialized
INFO - 2017-02-04 16:20:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:20:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-04 16:20:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:19 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:19 --> Total execution time: 0.0822
INFO - 2017-02-04 16:20:23 --> Config Class Initialized
INFO - 2017-02-04 16:20:23 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:23 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:23 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:23 --> URI Class Initialized
INFO - 2017-02-04 16:20:23 --> Router Class Initialized
INFO - 2017-02-04 16:20:23 --> Output Class Initialized
INFO - 2017-02-04 16:20:23 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:23 --> Input Class Initialized
INFO - 2017-02-04 16:20:23 --> Language Class Initialized
INFO - 2017-02-04 16:20:23 --> Loader Class Initialized
INFO - 2017-02-04 16:20:23 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:23 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:23 --> Controller Class Initialized
INFO - 2017-02-04 16:20:23 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:23 --> Model Class Initialized
INFO - 2017-02-04 16:20:23 --> Model Class Initialized
INFO - 2017-02-04 16:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:23 --> Helper loaded: form_helper
INFO - 2017-02-04 16:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:20:23 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:20:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:23 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:23 --> Total execution time: 0.0799
INFO - 2017-02-04 16:20:27 --> Config Class Initialized
INFO - 2017-02-04 16:20:27 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:27 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:27 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:27 --> URI Class Initialized
INFO - 2017-02-04 16:20:27 --> Router Class Initialized
INFO - 2017-02-04 16:20:27 --> Output Class Initialized
INFO - 2017-02-04 16:20:27 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:27 --> Input Class Initialized
INFO - 2017-02-04 16:20:27 --> Language Class Initialized
INFO - 2017-02-04 16:20:27 --> Loader Class Initialized
INFO - 2017-02-04 16:20:27 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:27 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:27 --> Controller Class Initialized
INFO - 2017-02-04 16:20:27 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:27 --> Model Class Initialized
INFO - 2017-02-04 16:20:27 --> Model Class Initialized
INFO - 2017-02-04 16:20:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:27 --> Helper loaded: form_helper
INFO - 2017-02-04 16:20:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:20:27 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:20:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:20:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:27 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:27 --> Total execution time: 0.0730
INFO - 2017-02-04 16:20:33 --> Config Class Initialized
INFO - 2017-02-04 16:20:33 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:33 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:33 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:33 --> URI Class Initialized
INFO - 2017-02-04 16:20:33 --> Router Class Initialized
INFO - 2017-02-04 16:20:33 --> Output Class Initialized
INFO - 2017-02-04 16:20:33 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:33 --> Input Class Initialized
INFO - 2017-02-04 16:20:33 --> Language Class Initialized
INFO - 2017-02-04 16:20:33 --> Loader Class Initialized
INFO - 2017-02-04 16:20:33 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:33 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:33 --> Controller Class Initialized
INFO - 2017-02-04 16:20:33 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:33 --> Model Class Initialized
INFO - 2017-02-04 16:20:33 --> Model Class Initialized
INFO - 2017-02-04 16:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:33 --> Config Class Initialized
INFO - 2017-02-04 16:20:33 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:33 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:33 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:33 --> URI Class Initialized
INFO - 2017-02-04 16:20:33 --> Router Class Initialized
INFO - 2017-02-04 16:20:33 --> Output Class Initialized
INFO - 2017-02-04 16:20:33 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:33 --> Input Class Initialized
INFO - 2017-02-04 16:20:33 --> Language Class Initialized
INFO - 2017-02-04 16:20:33 --> Loader Class Initialized
INFO - 2017-02-04 16:20:33 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:33 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:33 --> Controller Class Initialized
INFO - 2017-02-04 16:20:33 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:33 --> Model Class Initialized
INFO - 2017-02-04 16:20:33 --> Model Class Initialized
INFO - 2017-02-04 16:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:33 --> Helper loaded: form_helper
INFO - 2017-02-04 16:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:20:33 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:33 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:33 --> Total execution time: 0.0753
INFO - 2017-02-04 16:20:38 --> Config Class Initialized
INFO - 2017-02-04 16:20:38 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:38 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:38 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:38 --> URI Class Initialized
INFO - 2017-02-04 16:20:38 --> Router Class Initialized
INFO - 2017-02-04 16:20:38 --> Output Class Initialized
INFO - 2017-02-04 16:20:38 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:38 --> Input Class Initialized
INFO - 2017-02-04 16:20:38 --> Language Class Initialized
INFO - 2017-02-04 16:20:38 --> Loader Class Initialized
INFO - 2017-02-04 16:20:38 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:38 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:38 --> Controller Class Initialized
INFO - 2017-02-04 16:20:38 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:38 --> Model Class Initialized
INFO - 2017-02-04 16:20:38 --> Model Class Initialized
INFO - 2017-02-04 16:20:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:38 --> Helper loaded: form_helper
INFO - 2017-02-04 16:20:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:20:38 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:20:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:20:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:38 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:38 --> Total execution time: 0.0767
INFO - 2017-02-04 16:20:43 --> Config Class Initialized
INFO - 2017-02-04 16:20:43 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:43 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:43 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:43 --> URI Class Initialized
INFO - 2017-02-04 16:20:43 --> Router Class Initialized
INFO - 2017-02-04 16:20:43 --> Output Class Initialized
INFO - 2017-02-04 16:20:43 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:43 --> Input Class Initialized
INFO - 2017-02-04 16:20:43 --> Language Class Initialized
INFO - 2017-02-04 16:20:43 --> Loader Class Initialized
INFO - 2017-02-04 16:20:43 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:43 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:43 --> Controller Class Initialized
INFO - 2017-02-04 16:20:43 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:43 --> Model Class Initialized
INFO - 2017-02-04 16:20:43 --> Model Class Initialized
INFO - 2017-02-04 16:20:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:20:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-04 16:20:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:43 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:43 --> Total execution time: 0.0710
INFO - 2017-02-04 16:20:46 --> Config Class Initialized
INFO - 2017-02-04 16:20:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:46 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:46 --> URI Class Initialized
INFO - 2017-02-04 16:20:46 --> Router Class Initialized
INFO - 2017-02-04 16:20:46 --> Output Class Initialized
INFO - 2017-02-04 16:20:46 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:46 --> Input Class Initialized
INFO - 2017-02-04 16:20:46 --> Language Class Initialized
INFO - 2017-02-04 16:20:46 --> Loader Class Initialized
INFO - 2017-02-04 16:20:46 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:46 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:46 --> Controller Class Initialized
INFO - 2017-02-04 16:20:46 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:46 --> Model Class Initialized
INFO - 2017-02-04 16:20:46 --> Model Class Initialized
INFO - 2017-02-04 16:20:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:46 --> Config Class Initialized
INFO - 2017-02-04 16:20:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:46 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:46 --> URI Class Initialized
INFO - 2017-02-04 16:20:46 --> Router Class Initialized
INFO - 2017-02-04 16:20:46 --> Output Class Initialized
INFO - 2017-02-04 16:20:46 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:46 --> Input Class Initialized
INFO - 2017-02-04 16:20:46 --> Language Class Initialized
INFO - 2017-02-04 16:20:46 --> Loader Class Initialized
INFO - 2017-02-04 16:20:46 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:46 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:46 --> Controller Class Initialized
INFO - 2017-02-04 16:20:46 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:46 --> Model Class Initialized
INFO - 2017-02-04 16:20:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-04 16:20:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-04 16:20:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-04 16:20:46 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:46 --> Total execution time: 0.0598
INFO - 2017-02-04 16:20:50 --> Config Class Initialized
INFO - 2017-02-04 16:20:50 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:50 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:50 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:50 --> URI Class Initialized
INFO - 2017-02-04 16:20:50 --> Router Class Initialized
INFO - 2017-02-04 16:20:50 --> Output Class Initialized
INFO - 2017-02-04 16:20:50 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:50 --> Input Class Initialized
INFO - 2017-02-04 16:20:50 --> Language Class Initialized
INFO - 2017-02-04 16:20:50 --> Loader Class Initialized
INFO - 2017-02-04 16:20:50 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:50 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:50 --> Controller Class Initialized
INFO - 2017-02-04 16:20:50 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:50 --> Model Class Initialized
INFO - 2017-02-04 16:20:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:50 --> Config Class Initialized
INFO - 2017-02-04 16:20:50 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:50 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:50 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:50 --> URI Class Initialized
INFO - 2017-02-04 16:20:50 --> Router Class Initialized
INFO - 2017-02-04 16:20:50 --> Output Class Initialized
INFO - 2017-02-04 16:20:50 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:50 --> Input Class Initialized
INFO - 2017-02-04 16:20:50 --> Language Class Initialized
INFO - 2017-02-04 16:20:50 --> Loader Class Initialized
INFO - 2017-02-04 16:20:50 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:50 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:50 --> Controller Class Initialized
INFO - 2017-02-04 16:20:50 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:50 --> Model Class Initialized
INFO - 2017-02-04 16:20:50 --> Model Class Initialized
INFO - 2017-02-04 16:20:50 --> Model Class Initialized
INFO - 2017-02-04 16:20:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:20:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-04 16:20:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:50 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:50 --> Total execution time: 0.0763
INFO - 2017-02-04 16:20:54 --> Config Class Initialized
INFO - 2017-02-04 16:20:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:54 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:54 --> URI Class Initialized
INFO - 2017-02-04 16:20:54 --> Router Class Initialized
INFO - 2017-02-04 16:20:54 --> Output Class Initialized
INFO - 2017-02-04 16:20:54 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:54 --> Input Class Initialized
INFO - 2017-02-04 16:20:54 --> Language Class Initialized
INFO - 2017-02-04 16:20:54 --> Loader Class Initialized
INFO - 2017-02-04 16:20:54 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:54 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:54 --> Controller Class Initialized
INFO - 2017-02-04 16:20:54 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:54 --> Model Class Initialized
INFO - 2017-02-04 16:20:54 --> Model Class Initialized
INFO - 2017-02-04 16:20:54 --> Model Class Initialized
INFO - 2017-02-04 16:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:54 --> Config Class Initialized
INFO - 2017-02-04 16:20:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:54 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:54 --> URI Class Initialized
INFO - 2017-02-04 16:20:54 --> Router Class Initialized
INFO - 2017-02-04 16:20:54 --> Output Class Initialized
INFO - 2017-02-04 16:20:54 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:54 --> Input Class Initialized
INFO - 2017-02-04 16:20:54 --> Language Class Initialized
INFO - 2017-02-04 16:20:54 --> Loader Class Initialized
INFO - 2017-02-04 16:20:54 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:54 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:54 --> Controller Class Initialized
INFO - 2017-02-04 16:20:54 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:54 --> Model Class Initialized
INFO - 2017-02-04 16:20:54 --> Model Class Initialized
INFO - 2017-02-04 16:20:54 --> Model Class Initialized
INFO - 2017-02-04 16:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:54 --> Config Class Initialized
INFO - 2017-02-04 16:20:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:54 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:54 --> URI Class Initialized
INFO - 2017-02-04 16:20:54 --> Router Class Initialized
INFO - 2017-02-04 16:20:54 --> Output Class Initialized
INFO - 2017-02-04 16:20:54 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:54 --> Input Class Initialized
INFO - 2017-02-04 16:20:54 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> Config Class Initialized
INFO - 2017-02-04 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:55 --> URI Class Initialized
INFO - 2017-02-04 16:20:55 --> Router Class Initialized
INFO - 2017-02-04 16:20:55 --> Output Class Initialized
INFO - 2017-02-04 16:20:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:55 --> Input Class Initialized
INFO - 2017-02-04 16:20:55 --> Language Class Initialized
INFO - 2017-02-04 16:20:55 --> Loader Class Initialized
INFO - 2017-02-04 16:20:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:55 --> Controller Class Initialized
INFO - 2017-02-04 16:20:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Model Class Initialized
INFO - 2017-02-04 16:20:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:20:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-02-04 16:20:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:55 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:55 --> Total execution time: 0.0807
INFO - 2017-02-04 16:20:57 --> Config Class Initialized
INFO - 2017-02-04 16:20:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:57 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:57 --> URI Class Initialized
INFO - 2017-02-04 16:20:57 --> Router Class Initialized
INFO - 2017-02-04 16:20:57 --> Output Class Initialized
INFO - 2017-02-04 16:20:57 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:57 --> Input Class Initialized
INFO - 2017-02-04 16:20:57 --> Language Class Initialized
INFO - 2017-02-04 16:20:57 --> Loader Class Initialized
INFO - 2017-02-04 16:20:57 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:57 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:57 --> Controller Class Initialized
INFO - 2017-02-04 16:20:57 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:57 --> Config Class Initialized
INFO - 2017-02-04 16:20:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:57 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:57 --> URI Class Initialized
INFO - 2017-02-04 16:20:57 --> Router Class Initialized
INFO - 2017-02-04 16:20:57 --> Output Class Initialized
INFO - 2017-02-04 16:20:57 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:57 --> Input Class Initialized
INFO - 2017-02-04 16:20:57 --> Language Class Initialized
INFO - 2017-02-04 16:20:57 --> Loader Class Initialized
INFO - 2017-02-04 16:20:57 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:57 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:57 --> Controller Class Initialized
INFO - 2017-02-04 16:20:57 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:57 --> Model Class Initialized
INFO - 2017-02-04 16:20:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:20:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-02-04 16:20:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:20:58 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:58 --> Total execution time: 0.1036
INFO - 2017-02-04 16:20:58 --> Config Class Initialized
INFO - 2017-02-04 16:20:58 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:20:58 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:58 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:58 --> URI Class Initialized
INFO - 2017-02-04 16:20:58 --> Router Class Initialized
INFO - 2017-02-04 16:20:58 --> Output Class Initialized
INFO - 2017-02-04 16:20:58 --> Security Class Initialized
DEBUG - 2017-02-04 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:58 --> Input Class Initialized
INFO - 2017-02-04 16:20:58 --> Config Class Initialized
INFO - 2017-02-04 16:20:58 --> Hooks Class Initialized
INFO - 2017-02-04 16:20:58 --> Language Class Initialized
INFO - 2017-02-04 16:20:58 --> Loader Class Initialized
DEBUG - 2017-02-04 16:20:58 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:20:58 --> Utf8 Class Initialized
INFO - 2017-02-04 16:20:58 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:58 --> URI Class Initialized
INFO - 2017-02-04 16:20:58 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:58 --> Router Class Initialized
INFO - 2017-02-04 16:20:58 --> Output Class Initialized
INFO - 2017-02-04 16:20:58 --> Security Class Initialized
INFO - 2017-02-04 16:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:58 --> Controller Class Initialized
DEBUG - 2017-02-04 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:20:58 --> Input Class Initialized
INFO - 2017-02-04 16:20:58 --> Language Class Initialized
INFO - 2017-02-04 16:20:58 --> Loader Class Initialized
INFO - 2017-02-04 16:20:58 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:58 --> Helper loaded: url_helper
INFO - 2017-02-04 16:20:58 --> Helper loaded: language_helper
INFO - 2017-02-04 16:20:58 --> Model Class Initialized
INFO - 2017-02-04 16:20:58 --> Model Class Initialized
INFO - 2017-02-04 16:20:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:20:58 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:58 --> Total execution time: 0.0918
INFO - 2017-02-04 16:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:20:58 --> Controller Class Initialized
INFO - 2017-02-04 16:20:58 --> Database Driver Class Initialized
INFO - 2017-02-04 16:20:58 --> Model Class Initialized
INFO - 2017-02-04 16:20:58 --> Model Class Initialized
INFO - 2017-02-04 16:20:58 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-04 16:20:58 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-04 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-04 16:20:58 --> Final output sent to browser
DEBUG - 2017-02-04 16:20:58 --> Total execution time: 0.1277
INFO - 2017-02-04 16:21:28 --> Config Class Initialized
INFO - 2017-02-04 16:21:28 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:21:28 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:21:28 --> Utf8 Class Initialized
INFO - 2017-02-04 16:21:28 --> URI Class Initialized
INFO - 2017-02-04 16:21:28 --> Router Class Initialized
INFO - 2017-02-04 16:21:28 --> Output Class Initialized
INFO - 2017-02-04 16:21:28 --> Security Class Initialized
DEBUG - 2017-02-04 16:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:21:28 --> Input Class Initialized
INFO - 2017-02-04 16:21:28 --> Language Class Initialized
INFO - 2017-02-04 16:21:28 --> Loader Class Initialized
INFO - 2017-02-04 16:21:28 --> Helper loaded: url_helper
INFO - 2017-02-04 16:21:28 --> Helper loaded: language_helper
INFO - 2017-02-04 16:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:21:28 --> Controller Class Initialized
INFO - 2017-02-04 16:21:28 --> Database Driver Class Initialized
INFO - 2017-02-04 16:21:28 --> Model Class Initialized
INFO - 2017-02-04 16:21:28 --> Model Class Initialized
INFO - 2017-02-04 16:21:28 --> Model Class Initialized
INFO - 2017-02-04 16:21:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:21:28 --> Final output sent to browser
DEBUG - 2017-02-04 16:21:28 --> Total execution time: 0.0731
INFO - 2017-02-04 16:21:54 --> Config Class Initialized
INFO - 2017-02-04 16:21:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:21:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:21:55 --> Utf8 Class Initialized
INFO - 2017-02-04 16:21:55 --> URI Class Initialized
INFO - 2017-02-04 16:21:55 --> Router Class Initialized
INFO - 2017-02-04 16:21:55 --> Output Class Initialized
INFO - 2017-02-04 16:21:55 --> Security Class Initialized
DEBUG - 2017-02-04 16:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:21:55 --> Input Class Initialized
INFO - 2017-02-04 16:21:55 --> Language Class Initialized
INFO - 2017-02-04 16:21:55 --> Loader Class Initialized
INFO - 2017-02-04 16:21:55 --> Helper loaded: url_helper
INFO - 2017-02-04 16:21:55 --> Helper loaded: language_helper
INFO - 2017-02-04 16:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:21:55 --> Controller Class Initialized
INFO - 2017-02-04 16:21:55 --> Database Driver Class Initialized
INFO - 2017-02-04 16:21:55 --> Model Class Initialized
INFO - 2017-02-04 16:21:55 --> Model Class Initialized
INFO - 2017-02-04 16:21:55 --> Model Class Initialized
INFO - 2017-02-04 16:21:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:23:56 --> Config Class Initialized
INFO - 2017-02-04 16:23:56 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:23:56 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:23:56 --> Utf8 Class Initialized
INFO - 2017-02-04 16:23:56 --> URI Class Initialized
INFO - 2017-02-04 16:23:56 --> Router Class Initialized
INFO - 2017-02-04 16:23:56 --> Output Class Initialized
INFO - 2017-02-04 16:23:56 --> Security Class Initialized
DEBUG - 2017-02-04 16:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:23:56 --> Input Class Initialized
INFO - 2017-02-04 16:23:56 --> Language Class Initialized
INFO - 2017-02-04 16:23:56 --> Loader Class Initialized
INFO - 2017-02-04 16:23:56 --> Helper loaded: url_helper
INFO - 2017-02-04 16:23:56 --> Helper loaded: language_helper
INFO - 2017-02-04 16:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:23:56 --> Controller Class Initialized
INFO - 2017-02-04 16:23:56 --> Database Driver Class Initialized
INFO - 2017-02-04 16:23:56 --> Model Class Initialized
INFO - 2017-02-04 16:23:56 --> Model Class Initialized
INFO - 2017-02-04 16:23:56 --> Model Class Initialized
INFO - 2017-02-04 16:23:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-04 16:23:56 --> Severity: Notice --> Undefined index: correct_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 194
ERROR - 2017-02-04 16:23:56 --> Severity: Notice --> Undefined index: incorrect_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 195
ERROR - 2017-02-04 16:23:56 --> Severity: Notice --> Undefined index: pass_percentage C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 212
INFO - 2017-02-04 16:23:56 --> Config Class Initialized
INFO - 2017-02-04 16:23:56 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:23:56 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:23:56 --> Utf8 Class Initialized
INFO - 2017-02-04 16:23:56 --> URI Class Initialized
INFO - 2017-02-04 16:23:56 --> Router Class Initialized
INFO - 2017-02-04 16:23:56 --> Output Class Initialized
INFO - 2017-02-04 16:23:56 --> Security Class Initialized
DEBUG - 2017-02-04 16:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:23:56 --> Input Class Initialized
INFO - 2017-02-04 16:23:56 --> Language Class Initialized
INFO - 2017-02-04 16:23:56 --> Loader Class Initialized
INFO - 2017-02-04 16:23:56 --> Helper loaded: url_helper
INFO - 2017-02-04 16:23:56 --> Helper loaded: language_helper
INFO - 2017-02-04 16:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:23:56 --> Controller Class Initialized
INFO - 2017-02-04 16:23:56 --> Database Driver Class Initialized
INFO - 2017-02-04 16:23:56 --> Model Class Initialized
INFO - 2017-02-04 16:23:56 --> Model Class Initialized
INFO - 2017-02-04 16:23:56 --> Model Class Initialized
INFO - 2017-02-04 16:23:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-04 16:23:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:23:56 --> Final output sent to browser
DEBUG - 2017-02-04 16:23:56 --> Total execution time: 0.0766
INFO - 2017-02-04 16:24:31 --> Config Class Initialized
INFO - 2017-02-04 16:24:31 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:24:31 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:24:31 --> Utf8 Class Initialized
INFO - 2017-02-04 16:24:31 --> URI Class Initialized
INFO - 2017-02-04 16:24:31 --> Router Class Initialized
INFO - 2017-02-04 16:24:31 --> Output Class Initialized
INFO - 2017-02-04 16:24:31 --> Security Class Initialized
DEBUG - 2017-02-04 16:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:24:31 --> Input Class Initialized
INFO - 2017-02-04 16:24:31 --> Language Class Initialized
INFO - 2017-02-04 16:24:31 --> Loader Class Initialized
INFO - 2017-02-04 16:24:31 --> Helper loaded: url_helper
INFO - 2017-02-04 16:24:31 --> Helper loaded: language_helper
INFO - 2017-02-04 16:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:24:31 --> Controller Class Initialized
INFO - 2017-02-04 16:24:31 --> Database Driver Class Initialized
INFO - 2017-02-04 16:24:31 --> Model Class Initialized
INFO - 2017-02-04 16:24:31 --> Model Class Initialized
INFO - 2017-02-04 16:24:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:24:31 --> Config Class Initialized
INFO - 2017-02-04 16:24:31 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:24:31 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:24:31 --> Utf8 Class Initialized
INFO - 2017-02-04 16:24:31 --> URI Class Initialized
INFO - 2017-02-04 16:24:31 --> Router Class Initialized
INFO - 2017-02-04 16:24:31 --> Output Class Initialized
INFO - 2017-02-04 16:24:31 --> Security Class Initialized
DEBUG - 2017-02-04 16:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:24:31 --> Input Class Initialized
INFO - 2017-02-04 16:24:31 --> Language Class Initialized
INFO - 2017-02-04 16:24:31 --> Loader Class Initialized
INFO - 2017-02-04 16:24:31 --> Helper loaded: url_helper
INFO - 2017-02-04 16:24:31 --> Helper loaded: language_helper
INFO - 2017-02-04 16:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:24:31 --> Controller Class Initialized
INFO - 2017-02-04 16:24:31 --> Database Driver Class Initialized
INFO - 2017-02-04 16:24:31 --> Model Class Initialized
INFO - 2017-02-04 16:24:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:24:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-04 16:24:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-04 16:24:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-04 16:24:31 --> Final output sent to browser
DEBUG - 2017-02-04 16:24:31 --> Total execution time: 0.0600
INFO - 2017-02-04 16:26:03 --> Config Class Initialized
INFO - 2017-02-04 16:26:03 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:03 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:03 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:03 --> URI Class Initialized
INFO - 2017-02-04 16:26:03 --> Router Class Initialized
INFO - 2017-02-04 16:26:03 --> Output Class Initialized
INFO - 2017-02-04 16:26:03 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:03 --> Input Class Initialized
INFO - 2017-02-04 16:26:03 --> Language Class Initialized
INFO - 2017-02-04 16:26:03 --> Loader Class Initialized
INFO - 2017-02-04 16:26:03 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:03 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:03 --> Controller Class Initialized
INFO - 2017-02-04 16:26:03 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:03 --> Model Class Initialized
INFO - 2017-02-04 16:26:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:03 --> Config Class Initialized
INFO - 2017-02-04 16:26:03 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:03 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:03 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:03 --> URI Class Initialized
INFO - 2017-02-04 16:26:03 --> Router Class Initialized
INFO - 2017-02-04 16:26:03 --> Output Class Initialized
INFO - 2017-02-04 16:26:03 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:03 --> Input Class Initialized
INFO - 2017-02-04 16:26:03 --> Language Class Initialized
INFO - 2017-02-04 16:26:03 --> Loader Class Initialized
INFO - 2017-02-04 16:26:03 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:03 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:03 --> Controller Class Initialized
INFO - 2017-02-04 16:26:03 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:03 --> Model Class Initialized
INFO - 2017-02-04 16:26:03 --> Model Class Initialized
INFO - 2017-02-04 16:26:03 --> Model Class Initialized
INFO - 2017-02-04 16:26:03 --> Model Class Initialized
INFO - 2017-02-04 16:26:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-04 16:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:26:03 --> Final output sent to browser
DEBUG - 2017-02-04 16:26:04 --> Total execution time: 0.0767
INFO - 2017-02-04 16:26:07 --> Config Class Initialized
INFO - 2017-02-04 16:26:07 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:07 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:07 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:07 --> URI Class Initialized
INFO - 2017-02-04 16:26:07 --> Router Class Initialized
INFO - 2017-02-04 16:26:07 --> Output Class Initialized
INFO - 2017-02-04 16:26:07 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:07 --> Input Class Initialized
INFO - 2017-02-04 16:26:07 --> Language Class Initialized
INFO - 2017-02-04 16:26:07 --> Loader Class Initialized
INFO - 2017-02-04 16:26:07 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:07 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:07 --> Controller Class Initialized
INFO - 2017-02-04 16:26:07 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:07 --> Model Class Initialized
INFO - 2017-02-04 16:26:07 --> Model Class Initialized
INFO - 2017-02-04 16:26:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:07 --> Helper loaded: form_helper
INFO - 2017-02-04 16:26:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:26:07 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:26:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:26:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:26:07 --> Final output sent to browser
DEBUG - 2017-02-04 16:26:07 --> Total execution time: 0.0755
INFO - 2017-02-04 16:26:10 --> Config Class Initialized
INFO - 2017-02-04 16:26:10 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:10 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:10 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:10 --> URI Class Initialized
INFO - 2017-02-04 16:26:10 --> Router Class Initialized
INFO - 2017-02-04 16:26:10 --> Output Class Initialized
INFO - 2017-02-04 16:26:10 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:10 --> Input Class Initialized
INFO - 2017-02-04 16:26:10 --> Language Class Initialized
INFO - 2017-02-04 16:26:10 --> Loader Class Initialized
INFO - 2017-02-04 16:26:10 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:10 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:10 --> Controller Class Initialized
INFO - 2017-02-04 16:26:10 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:10 --> Model Class Initialized
INFO - 2017-02-04 16:26:10 --> Model Class Initialized
INFO - 2017-02-04 16:26:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:10 --> Helper loaded: form_helper
INFO - 2017-02-04 16:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:26:10 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:26:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:26:10 --> Final output sent to browser
DEBUG - 2017-02-04 16:26:10 --> Total execution time: 0.0758
INFO - 2017-02-04 16:26:13 --> Config Class Initialized
INFO - 2017-02-04 16:26:13 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:13 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:13 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:13 --> URI Class Initialized
INFO - 2017-02-04 16:26:13 --> Router Class Initialized
INFO - 2017-02-04 16:26:13 --> Output Class Initialized
INFO - 2017-02-04 16:26:13 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:13 --> Input Class Initialized
INFO - 2017-02-04 16:26:13 --> Language Class Initialized
INFO - 2017-02-04 16:26:13 --> Loader Class Initialized
INFO - 2017-02-04 16:26:13 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:13 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:13 --> Controller Class Initialized
INFO - 2017-02-04 16:26:13 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:13 --> Model Class Initialized
INFO - 2017-02-04 16:26:13 --> Model Class Initialized
INFO - 2017-02-04 16:26:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:13 --> Config Class Initialized
INFO - 2017-02-04 16:26:13 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:13 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:13 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:13 --> URI Class Initialized
INFO - 2017-02-04 16:26:13 --> Router Class Initialized
INFO - 2017-02-04 16:26:13 --> Output Class Initialized
INFO - 2017-02-04 16:26:13 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:13 --> Input Class Initialized
INFO - 2017-02-04 16:26:13 --> Language Class Initialized
INFO - 2017-02-04 16:26:13 --> Loader Class Initialized
INFO - 2017-02-04 16:26:13 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:13 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:13 --> Controller Class Initialized
INFO - 2017-02-04 16:26:13 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:13 --> Model Class Initialized
INFO - 2017-02-04 16:26:13 --> Model Class Initialized
INFO - 2017-02-04 16:26:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:13 --> Helper loaded: form_helper
INFO - 2017-02-04 16:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:26:13 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:26:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:26:13 --> Final output sent to browser
DEBUG - 2017-02-04 16:26:13 --> Total execution time: 0.0759
INFO - 2017-02-04 16:26:20 --> Config Class Initialized
INFO - 2017-02-04 16:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:20 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:20 --> URI Class Initialized
INFO - 2017-02-04 16:26:20 --> Router Class Initialized
INFO - 2017-02-04 16:26:20 --> Output Class Initialized
INFO - 2017-02-04 16:26:20 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:20 --> Input Class Initialized
INFO - 2017-02-04 16:26:20 --> Language Class Initialized
INFO - 2017-02-04 16:26:20 --> Loader Class Initialized
INFO - 2017-02-04 16:26:20 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:20 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:20 --> Controller Class Initialized
INFO - 2017-02-04 16:26:20 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:20 --> Model Class Initialized
INFO - 2017-02-04 16:26:20 --> Model Class Initialized
INFO - 2017-02-04 16:26:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:20 --> Helper loaded: form_helper
INFO - 2017-02-04 16:26:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 16:26:20 --> Could not find the language line "import_user"
INFO - 2017-02-04 16:26:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 16:26:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:26:20 --> Final output sent to browser
DEBUG - 2017-02-04 16:26:20 --> Total execution time: 0.0784
INFO - 2017-02-04 16:26:23 --> Config Class Initialized
INFO - 2017-02-04 16:26:23 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:26:23 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:26:23 --> Utf8 Class Initialized
INFO - 2017-02-04 16:26:23 --> URI Class Initialized
INFO - 2017-02-04 16:26:23 --> Router Class Initialized
INFO - 2017-02-04 16:26:23 --> Output Class Initialized
INFO - 2017-02-04 16:26:23 --> Security Class Initialized
DEBUG - 2017-02-04 16:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:26:23 --> Input Class Initialized
INFO - 2017-02-04 16:26:23 --> Language Class Initialized
INFO - 2017-02-04 16:26:23 --> Loader Class Initialized
INFO - 2017-02-04 16:26:23 --> Helper loaded: url_helper
INFO - 2017-02-04 16:26:23 --> Helper loaded: language_helper
INFO - 2017-02-04 16:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:26:23 --> Controller Class Initialized
INFO - 2017-02-04 16:26:23 --> Database Driver Class Initialized
INFO - 2017-02-04 16:26:23 --> Model Class Initialized
INFO - 2017-02-04 16:26:23 --> Model Class Initialized
INFO - 2017-02-04 16:26:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:26:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:26:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-04 16:26:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:26:24 --> Final output sent to browser
DEBUG - 2017-02-04 16:26:24 --> Total execution time: 0.0719
INFO - 2017-02-04 16:27:25 --> Config Class Initialized
INFO - 2017-02-04 16:27:25 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:27:25 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:27:25 --> Utf8 Class Initialized
INFO - 2017-02-04 16:27:25 --> URI Class Initialized
INFO - 2017-02-04 16:27:25 --> Router Class Initialized
INFO - 2017-02-04 16:27:25 --> Output Class Initialized
INFO - 2017-02-04 16:27:25 --> Security Class Initialized
DEBUG - 2017-02-04 16:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:27:25 --> Input Class Initialized
INFO - 2017-02-04 16:27:25 --> Language Class Initialized
INFO - 2017-02-04 16:27:25 --> Loader Class Initialized
INFO - 2017-02-04 16:27:25 --> Helper loaded: url_helper
INFO - 2017-02-04 16:27:25 --> Helper loaded: language_helper
INFO - 2017-02-04 16:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:27:25 --> Controller Class Initialized
INFO - 2017-02-04 16:27:25 --> Database Driver Class Initialized
INFO - 2017-02-04 16:27:25 --> Model Class Initialized
INFO - 2017-02-04 16:27:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:27:25 --> Model Class Initialized
INFO - 2017-02-04 16:27:25 --> Helper loaded: form_helper
INFO - 2017-02-04 16:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-04 16:27:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:27:25 --> Final output sent to browser
DEBUG - 2017-02-04 16:27:25 --> Total execution time: 0.4043
INFO - 2017-02-04 16:27:28 --> Config Class Initialized
INFO - 2017-02-04 16:27:28 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:27:28 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:27:28 --> Utf8 Class Initialized
INFO - 2017-02-04 16:27:28 --> URI Class Initialized
INFO - 2017-02-04 16:27:28 --> Router Class Initialized
INFO - 2017-02-04 16:27:28 --> Output Class Initialized
INFO - 2017-02-04 16:27:28 --> Security Class Initialized
DEBUG - 2017-02-04 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:27:28 --> Input Class Initialized
INFO - 2017-02-04 16:27:28 --> Language Class Initialized
INFO - 2017-02-04 16:27:28 --> Loader Class Initialized
INFO - 2017-02-04 16:27:28 --> Helper loaded: url_helper
INFO - 2017-02-04 16:27:28 --> Helper loaded: language_helper
INFO - 2017-02-04 16:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:27:28 --> Controller Class Initialized
INFO - 2017-02-04 16:27:28 --> Database Driver Class Initialized
INFO - 2017-02-04 16:27:28 --> Model Class Initialized
INFO - 2017-02-04 16:27:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:27:28 --> Model Class Initialized
INFO - 2017-02-04 16:27:28 --> Helper loaded: form_helper
INFO - 2017-02-04 16:27:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:27:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-04 16:27:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:27:28 --> Final output sent to browser
DEBUG - 2017-02-04 16:27:28 --> Total execution time: 0.2982
INFO - 2017-02-04 16:34:57 --> Config Class Initialized
INFO - 2017-02-04 16:34:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:34:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:34:57 --> Utf8 Class Initialized
INFO - 2017-02-04 16:34:57 --> URI Class Initialized
INFO - 2017-02-04 16:34:57 --> Router Class Initialized
INFO - 2017-02-04 16:34:57 --> Output Class Initialized
INFO - 2017-02-04 16:34:57 --> Security Class Initialized
DEBUG - 2017-02-04 16:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:34:57 --> Input Class Initialized
INFO - 2017-02-04 16:34:57 --> Language Class Initialized
INFO - 2017-02-04 16:34:57 --> Loader Class Initialized
INFO - 2017-02-04 16:34:57 --> Helper loaded: url_helper
INFO - 2017-02-04 16:34:57 --> Helper loaded: language_helper
INFO - 2017-02-04 16:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:34:57 --> Controller Class Initialized
INFO - 2017-02-04 16:34:57 --> Database Driver Class Initialized
INFO - 2017-02-04 16:34:57 --> Model Class Initialized
INFO - 2017-02-04 16:34:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:34:57 --> Model Class Initialized
INFO - 2017-02-04 16:34:57 --> Helper loaded: form_helper
ERROR - 2017-02-04 16:34:57 --> Query error: Unknown column 'a.score_u' in 'field list' - Invalid query: SELECT d.uid,concat(d.first_name,' ',d.last_name) as fullname,
                round(sum(a.score_u), 0) as total
                from disc_answers a
                left join qbank b on b.qid = a.qid
                left join category c on c.cid = b.cid
                left join users d on d.uid = a.uid
                where su != 1  group by d.uid
                order by total desc  limit 30 offset 30
INFO - 2017-02-04 16:34:57 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-04 16:37:14 --> Config Class Initialized
INFO - 2017-02-04 16:37:14 --> Hooks Class Initialized
DEBUG - 2017-02-04 16:37:14 --> UTF-8 Support Enabled
INFO - 2017-02-04 16:37:14 --> Utf8 Class Initialized
INFO - 2017-02-04 16:37:14 --> URI Class Initialized
INFO - 2017-02-04 16:37:14 --> Router Class Initialized
INFO - 2017-02-04 16:37:14 --> Output Class Initialized
INFO - 2017-02-04 16:37:14 --> Security Class Initialized
DEBUG - 2017-02-04 16:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 16:37:14 --> Input Class Initialized
INFO - 2017-02-04 16:37:14 --> Language Class Initialized
INFO - 2017-02-04 16:37:14 --> Loader Class Initialized
INFO - 2017-02-04 16:37:14 --> Helper loaded: url_helper
INFO - 2017-02-04 16:37:14 --> Helper loaded: language_helper
INFO - 2017-02-04 16:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 16:37:14 --> Controller Class Initialized
INFO - 2017-02-04 16:37:14 --> Database Driver Class Initialized
INFO - 2017-02-04 16:37:14 --> Model Class Initialized
INFO - 2017-02-04 16:37:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 16:37:14 --> Model Class Initialized
INFO - 2017-02-04 16:37:14 --> Helper loaded: form_helper
INFO - 2017-02-04 16:37:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 16:37:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-04 16:37:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 16:37:14 --> Final output sent to browser
DEBUG - 2017-02-04 16:37:14 --> Total execution time: 0.2778
INFO - 2017-02-04 17:02:24 --> Config Class Initialized
INFO - 2017-02-04 17:02:24 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:24 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:24 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:24 --> URI Class Initialized
INFO - 2017-02-04 17:02:24 --> Router Class Initialized
INFO - 2017-02-04 17:02:24 --> Output Class Initialized
INFO - 2017-02-04 17:02:24 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:24 --> Input Class Initialized
INFO - 2017-02-04 17:02:24 --> Language Class Initialized
INFO - 2017-02-04 17:02:24 --> Loader Class Initialized
INFO - 2017-02-04 17:02:24 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:24 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:24 --> Controller Class Initialized
INFO - 2017-02-04 17:02:24 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:24 --> Model Class Initialized
INFO - 2017-02-04 17:02:24 --> Model Class Initialized
INFO - 2017-02-04 17:02:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:24 --> Helper loaded: form_helper
INFO - 2017-02-04 17:02:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 17:02:24 --> Could not find the language line "import_user"
INFO - 2017-02-04 17:02:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 17:02:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:02:24 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:24 --> Total execution time: 0.1102
INFO - 2017-02-04 17:02:32 --> Config Class Initialized
INFO - 2017-02-04 17:02:32 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:32 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:32 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:32 --> URI Class Initialized
INFO - 2017-02-04 17:02:32 --> Router Class Initialized
INFO - 2017-02-04 17:02:32 --> Output Class Initialized
INFO - 2017-02-04 17:02:32 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:32 --> Input Class Initialized
INFO - 2017-02-04 17:02:32 --> Language Class Initialized
INFO - 2017-02-04 17:02:32 --> Loader Class Initialized
INFO - 2017-02-04 17:02:32 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:32 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:32 --> Controller Class Initialized
INFO - 2017-02-04 17:02:32 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:32 --> Model Class Initialized
INFO - 2017-02-04 17:02:32 --> Model Class Initialized
INFO - 2017-02-04 17:02:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:32 --> Helper loaded: form_helper
INFO - 2017-02-04 17:02:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-04 17:02:32 --> Could not find the language line "import_user"
INFO - 2017-02-04 17:02:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-04 17:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:02:33 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:33 --> Total execution time: 0.0900
INFO - 2017-02-04 17:02:46 --> Config Class Initialized
INFO - 2017-02-04 17:02:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:46 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:46 --> URI Class Initialized
INFO - 2017-02-04 17:02:46 --> Router Class Initialized
INFO - 2017-02-04 17:02:46 --> Output Class Initialized
INFO - 2017-02-04 17:02:46 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:46 --> Input Class Initialized
INFO - 2017-02-04 17:02:46 --> Language Class Initialized
INFO - 2017-02-04 17:02:46 --> Loader Class Initialized
INFO - 2017-02-04 17:02:46 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:46 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:46 --> Controller Class Initialized
INFO - 2017-02-04 17:02:46 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:46 --> Model Class Initialized
INFO - 2017-02-04 17:02:46 --> Model Class Initialized
INFO - 2017-02-04 17:02:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:46 --> Config Class Initialized
INFO - 2017-02-04 17:02:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:46 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:46 --> URI Class Initialized
INFO - 2017-02-04 17:02:46 --> Router Class Initialized
INFO - 2017-02-04 17:02:46 --> Output Class Initialized
INFO - 2017-02-04 17:02:46 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:46 --> Input Class Initialized
INFO - 2017-02-04 17:02:46 --> Language Class Initialized
INFO - 2017-02-04 17:02:46 --> Loader Class Initialized
INFO - 2017-02-04 17:02:46 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:46 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:46 --> Controller Class Initialized
INFO - 2017-02-04 17:02:46 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:46 --> Model Class Initialized
INFO - 2017-02-04 17:02:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-04 17:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-04 17:02:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-04 17:02:46 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:46 --> Total execution time: 0.0665
INFO - 2017-02-04 17:02:52 --> Config Class Initialized
INFO - 2017-02-04 17:02:52 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:52 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:52 --> URI Class Initialized
INFO - 2017-02-04 17:02:52 --> Router Class Initialized
INFO - 2017-02-04 17:02:52 --> Output Class Initialized
INFO - 2017-02-04 17:02:52 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:52 --> Input Class Initialized
INFO - 2017-02-04 17:02:52 --> Language Class Initialized
INFO - 2017-02-04 17:02:52 --> Loader Class Initialized
INFO - 2017-02-04 17:02:53 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:53 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:53 --> Controller Class Initialized
INFO - 2017-02-04 17:02:53 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:53 --> Model Class Initialized
INFO - 2017-02-04 17:02:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:53 --> Config Class Initialized
INFO - 2017-02-04 17:02:53 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:53 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:53 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:53 --> URI Class Initialized
INFO - 2017-02-04 17:02:53 --> Router Class Initialized
INFO - 2017-02-04 17:02:53 --> Output Class Initialized
INFO - 2017-02-04 17:02:53 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:53 --> Input Class Initialized
INFO - 2017-02-04 17:02:53 --> Language Class Initialized
INFO - 2017-02-04 17:02:53 --> Loader Class Initialized
INFO - 2017-02-04 17:02:53 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:53 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:53 --> Controller Class Initialized
INFO - 2017-02-04 17:02:53 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:53 --> Model Class Initialized
INFO - 2017-02-04 17:02:53 --> Model Class Initialized
INFO - 2017-02-04 17:02:53 --> Model Class Initialized
INFO - 2017-02-04 17:02:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:02:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-04 17:02:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:02:53 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:53 --> Total execution time: 0.1129
INFO - 2017-02-04 17:02:54 --> Config Class Initialized
INFO - 2017-02-04 17:02:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:54 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:54 --> URI Class Initialized
INFO - 2017-02-04 17:02:54 --> Router Class Initialized
INFO - 2017-02-04 17:02:54 --> Output Class Initialized
INFO - 2017-02-04 17:02:54 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:54 --> Input Class Initialized
INFO - 2017-02-04 17:02:54 --> Language Class Initialized
INFO - 2017-02-04 17:02:54 --> Loader Class Initialized
INFO - 2017-02-04 17:02:54 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:54 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:54 --> Controller Class Initialized
INFO - 2017-02-04 17:02:54 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:54 --> Model Class Initialized
INFO - 2017-02-04 17:02:54 --> Model Class Initialized
INFO - 2017-02-04 17:02:54 --> Model Class Initialized
INFO - 2017-02-04 17:02:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:54 --> Config Class Initialized
INFO - 2017-02-04 17:02:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:54 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:54 --> URI Class Initialized
INFO - 2017-02-04 17:02:54 --> Router Class Initialized
INFO - 2017-02-04 17:02:54 --> Output Class Initialized
INFO - 2017-02-04 17:02:54 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:54 --> Input Class Initialized
INFO - 2017-02-04 17:02:54 --> Language Class Initialized
INFO - 2017-02-04 17:02:54 --> Loader Class Initialized
INFO - 2017-02-04 17:02:54 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:54 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:54 --> Controller Class Initialized
INFO - 2017-02-04 17:02:54 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:54 --> Model Class Initialized
INFO - 2017-02-04 17:02:54 --> Model Class Initialized
INFO - 2017-02-04 17:02:54 --> Model Class Initialized
INFO - 2017-02-04 17:02:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:54 --> Config Class Initialized
INFO - 2017-02-04 17:02:54 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:54 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:54 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:54 --> URI Class Initialized
INFO - 2017-02-04 17:02:54 --> Router Class Initialized
INFO - 2017-02-04 17:02:54 --> Output Class Initialized
INFO - 2017-02-04 17:02:54 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:54 --> Input Class Initialized
INFO - 2017-02-04 17:02:54 --> Language Class Initialized
INFO - 2017-02-04 17:02:54 --> Loader Class Initialized
INFO - 2017-02-04 17:02:54 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:54 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:54 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:55 --> Config Class Initialized
INFO - 2017-02-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:55 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:55 --> URI Class Initialized
INFO - 2017-02-04 17:02:55 --> Router Class Initialized
INFO - 2017-02-04 17:02:55 --> Output Class Initialized
INFO - 2017-02-04 17:02:55 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:55 --> Input Class Initialized
INFO - 2017-02-04 17:02:55 --> Language Class Initialized
INFO - 2017-02-04 17:02:55 --> Loader Class Initialized
INFO - 2017-02-04 17:02:55 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:55 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:55 --> Controller Class Initialized
INFO - 2017-02-04 17:02:55 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Model Class Initialized
INFO - 2017-02-04 17:02:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:56 --> Config Class Initialized
INFO - 2017-02-04 17:02:56 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:56 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:56 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:56 --> URI Class Initialized
INFO - 2017-02-04 17:02:56 --> Router Class Initialized
INFO - 2017-02-04 17:02:56 --> Output Class Initialized
INFO - 2017-02-04 17:02:56 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:56 --> Input Class Initialized
INFO - 2017-02-04 17:02:56 --> Language Class Initialized
INFO - 2017-02-04 17:02:56 --> Loader Class Initialized
INFO - 2017-02-04 17:02:56 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:56 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:56 --> Controller Class Initialized
INFO - 2017-02-04 17:02:56 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:56 --> Model Class Initialized
INFO - 2017-02-04 17:02:56 --> Model Class Initialized
INFO - 2017-02-04 17:02:56 --> Model Class Initialized
INFO - 2017-02-04 17:02:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:02:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-02-04 17:02:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:02:56 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:56 --> Total execution time: 0.0827
INFO - 2017-02-04 17:02:57 --> Config Class Initialized
INFO - 2017-02-04 17:02:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:57 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:57 --> URI Class Initialized
INFO - 2017-02-04 17:02:57 --> Router Class Initialized
INFO - 2017-02-04 17:02:57 --> Output Class Initialized
INFO - 2017-02-04 17:02:57 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:57 --> Input Class Initialized
INFO - 2017-02-04 17:02:57 --> Language Class Initialized
INFO - 2017-02-04 17:02:57 --> Loader Class Initialized
INFO - 2017-02-04 17:02:57 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:57 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:57 --> Controller Class Initialized
INFO - 2017-02-04 17:02:57 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:57 --> Config Class Initialized
INFO - 2017-02-04 17:02:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:57 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:57 --> URI Class Initialized
INFO - 2017-02-04 17:02:57 --> Router Class Initialized
INFO - 2017-02-04 17:02:57 --> Output Class Initialized
INFO - 2017-02-04 17:02:57 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:57 --> Input Class Initialized
INFO - 2017-02-04 17:02:57 --> Language Class Initialized
INFO - 2017-02-04 17:02:57 --> Loader Class Initialized
INFO - 2017-02-04 17:02:57 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:57 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:57 --> Controller Class Initialized
INFO - 2017-02-04 17:02:57 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-02-04 17:02:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:02:57 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:57 --> Total execution time: 0.1362
INFO - 2017-02-04 17:02:57 --> Config Class Initialized
INFO - 2017-02-04 17:02:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:02:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:57 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:57 --> URI Class Initialized
INFO - 2017-02-04 17:02:57 --> Router Class Initialized
INFO - 2017-02-04 17:02:57 --> Output Class Initialized
INFO - 2017-02-04 17:02:57 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:57 --> Input Class Initialized
INFO - 2017-02-04 17:02:57 --> Language Class Initialized
INFO - 2017-02-04 17:02:57 --> Config Class Initialized
INFO - 2017-02-04 17:02:57 --> Hooks Class Initialized
INFO - 2017-02-04 17:02:57 --> Loader Class Initialized
INFO - 2017-02-04 17:02:57 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:57 --> Helper loaded: language_helper
DEBUG - 2017-02-04 17:02:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:02:57 --> Utf8 Class Initialized
INFO - 2017-02-04 17:02:57 --> URI Class Initialized
INFO - 2017-02-04 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:57 --> Router Class Initialized
INFO - 2017-02-04 17:02:57 --> Controller Class Initialized
INFO - 2017-02-04 17:02:57 --> Output Class Initialized
INFO - 2017-02-04 17:02:57 --> Security Class Initialized
DEBUG - 2017-02-04 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:02:57 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:57 --> Input Class Initialized
INFO - 2017-02-04 17:02:57 --> Language Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Model Class Initialized
INFO - 2017-02-04 17:02:57 --> Loader Class Initialized
INFO - 2017-02-04 17:02:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:02:57 --> Helper loaded: url_helper
INFO - 2017-02-04 17:02:57 --> Helper loaded: language_helper
INFO - 2017-02-04 17:02:57 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:57 --> Total execution time: 0.1051
INFO - 2017-02-04 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:02:57 --> Controller Class Initialized
INFO - 2017-02-04 17:02:57 --> Database Driver Class Initialized
INFO - 2017-02-04 17:02:58 --> Model Class Initialized
INFO - 2017-02-04 17:02:58 --> Model Class Initialized
INFO - 2017-02-04 17:02:58 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-04 17:02:58 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-04 17:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-04 17:02:58 --> Final output sent to browser
DEBUG - 2017-02-04 17:02:58 --> Total execution time: 0.1585
INFO - 2017-02-04 17:03:27 --> Config Class Initialized
INFO - 2017-02-04 17:03:27 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:03:27 --> Utf8 Class Initialized
INFO - 2017-02-04 17:03:27 --> URI Class Initialized
INFO - 2017-02-04 17:03:27 --> Router Class Initialized
INFO - 2017-02-04 17:03:27 --> Output Class Initialized
INFO - 2017-02-04 17:03:27 --> Security Class Initialized
DEBUG - 2017-02-04 17:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:03:27 --> Input Class Initialized
INFO - 2017-02-04 17:03:27 --> Language Class Initialized
INFO - 2017-02-04 17:03:27 --> Loader Class Initialized
INFO - 2017-02-04 17:03:27 --> Helper loaded: url_helper
INFO - 2017-02-04 17:03:27 --> Helper loaded: language_helper
INFO - 2017-02-04 17:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:03:27 --> Controller Class Initialized
INFO - 2017-02-04 17:03:27 --> Database Driver Class Initialized
INFO - 2017-02-04 17:03:27 --> Model Class Initialized
INFO - 2017-02-04 17:03:27 --> Model Class Initialized
INFO - 2017-02-04 17:03:27 --> Model Class Initialized
INFO - 2017-02-04 17:03:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:03:27 --> Final output sent to browser
DEBUG - 2017-02-04 17:03:27 --> Total execution time: 0.0693
INFO - 2017-02-04 17:03:57 --> Config Class Initialized
INFO - 2017-02-04 17:03:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:03:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:03:57 --> Utf8 Class Initialized
INFO - 2017-02-04 17:03:57 --> URI Class Initialized
INFO - 2017-02-04 17:03:57 --> Router Class Initialized
INFO - 2017-02-04 17:03:57 --> Output Class Initialized
INFO - 2017-02-04 17:03:57 --> Security Class Initialized
DEBUG - 2017-02-04 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:03:57 --> Input Class Initialized
INFO - 2017-02-04 17:03:57 --> Language Class Initialized
INFO - 2017-02-04 17:03:57 --> Loader Class Initialized
INFO - 2017-02-04 17:03:57 --> Helper loaded: url_helper
INFO - 2017-02-04 17:03:57 --> Helper loaded: language_helper
INFO - 2017-02-04 17:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:03:57 --> Controller Class Initialized
INFO - 2017-02-04 17:03:57 --> Database Driver Class Initialized
INFO - 2017-02-04 17:03:57 --> Model Class Initialized
INFO - 2017-02-04 17:03:57 --> Model Class Initialized
INFO - 2017-02-04 17:03:57 --> Model Class Initialized
INFO - 2017-02-04 17:03:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:03:57 --> Final output sent to browser
DEBUG - 2017-02-04 17:03:57 --> Total execution time: 0.0739
INFO - 2017-02-04 17:04:03 --> Config Class Initialized
INFO - 2017-02-04 17:04:03 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:04:03 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:04:03 --> Utf8 Class Initialized
INFO - 2017-02-04 17:04:03 --> URI Class Initialized
INFO - 2017-02-04 17:04:03 --> Router Class Initialized
INFO - 2017-02-04 17:04:03 --> Output Class Initialized
INFO - 2017-02-04 17:04:03 --> Security Class Initialized
DEBUG - 2017-02-04 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:04:03 --> Input Class Initialized
INFO - 2017-02-04 17:04:03 --> Language Class Initialized
INFO - 2017-02-04 17:04:03 --> Loader Class Initialized
INFO - 2017-02-04 17:04:03 --> Helper loaded: url_helper
INFO - 2017-02-04 17:04:03 --> Helper loaded: language_helper
INFO - 2017-02-04 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:04:03 --> Controller Class Initialized
INFO - 2017-02-04 17:04:03 --> Database Driver Class Initialized
INFO - 2017-02-04 17:04:03 --> Model Class Initialized
INFO - 2017-02-04 17:04:03 --> Model Class Initialized
INFO - 2017-02-04 17:04:03 --> Model Class Initialized
INFO - 2017-02-04 17:04:03 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-04 17:04:03 --> Severity: Notice --> Undefined index: correct_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 193
ERROR - 2017-02-04 17:04:03 --> Severity: Notice --> Undefined index: incorrect_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 194
ERROR - 2017-02-04 17:04:03 --> Severity: Notice --> Undefined index: pass_percentage C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 211
INFO - 2017-02-04 17:04:03 --> Config Class Initialized
INFO - 2017-02-04 17:04:03 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:04:03 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:04:03 --> Utf8 Class Initialized
INFO - 2017-02-04 17:04:03 --> URI Class Initialized
INFO - 2017-02-04 17:04:03 --> Router Class Initialized
INFO - 2017-02-04 17:04:03 --> Output Class Initialized
INFO - 2017-02-04 17:04:03 --> Security Class Initialized
DEBUG - 2017-02-04 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:04:03 --> Input Class Initialized
INFO - 2017-02-04 17:04:03 --> Language Class Initialized
INFO - 2017-02-04 17:04:03 --> Loader Class Initialized
INFO - 2017-02-04 17:04:03 --> Helper loaded: url_helper
INFO - 2017-02-04 17:04:03 --> Helper loaded: language_helper
INFO - 2017-02-04 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:04:03 --> Controller Class Initialized
INFO - 2017-02-04 17:04:03 --> Database Driver Class Initialized
INFO - 2017-02-04 17:04:03 --> Model Class Initialized
INFO - 2017-02-04 17:04:03 --> Model Class Initialized
INFO - 2017-02-04 17:04:03 --> Model Class Initialized
INFO - 2017-02-04 17:04:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:04:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:04:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-04 17:04:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:04:03 --> Final output sent to browser
DEBUG - 2017-02-04 17:04:03 --> Total execution time: 0.0854
INFO - 2017-02-04 17:13:12 --> Config Class Initialized
INFO - 2017-02-04 17:13:12 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:13:12 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:13:12 --> Utf8 Class Initialized
INFO - 2017-02-04 17:13:12 --> URI Class Initialized
INFO - 2017-02-04 17:13:12 --> Router Class Initialized
INFO - 2017-02-04 17:13:12 --> Output Class Initialized
INFO - 2017-02-04 17:13:12 --> Security Class Initialized
DEBUG - 2017-02-04 17:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:13:12 --> Input Class Initialized
INFO - 2017-02-04 17:13:12 --> Language Class Initialized
INFO - 2017-02-04 17:13:12 --> Loader Class Initialized
INFO - 2017-02-04 17:13:12 --> Helper loaded: url_helper
INFO - 2017-02-04 17:13:12 --> Helper loaded: language_helper
INFO - 2017-02-04 17:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:13:12 --> Controller Class Initialized
INFO - 2017-02-04 17:13:12 --> Database Driver Class Initialized
INFO - 2017-02-04 17:13:12 --> Model Class Initialized
INFO - 2017-02-04 17:13:12 --> Model Class Initialized
INFO - 2017-02-04 17:13:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:13:12 --> Config Class Initialized
INFO - 2017-02-04 17:13:12 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:13:12 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:13:12 --> Utf8 Class Initialized
INFO - 2017-02-04 17:13:12 --> URI Class Initialized
INFO - 2017-02-04 17:13:12 --> Router Class Initialized
INFO - 2017-02-04 17:13:12 --> Output Class Initialized
INFO - 2017-02-04 17:13:12 --> Security Class Initialized
DEBUG - 2017-02-04 17:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:13:12 --> Input Class Initialized
INFO - 2017-02-04 17:13:12 --> Language Class Initialized
INFO - 2017-02-04 17:13:12 --> Loader Class Initialized
INFO - 2017-02-04 17:13:12 --> Helper loaded: url_helper
INFO - 2017-02-04 17:13:12 --> Helper loaded: language_helper
INFO - 2017-02-04 17:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:13:12 --> Controller Class Initialized
INFO - 2017-02-04 17:13:12 --> Database Driver Class Initialized
INFO - 2017-02-04 17:13:12 --> Model Class Initialized
INFO - 2017-02-04 17:13:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-04 17:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-04 17:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-04 17:13:12 --> Final output sent to browser
DEBUG - 2017-02-04 17:13:12 --> Total execution time: 0.0684
INFO - 2017-02-04 17:13:17 --> Config Class Initialized
INFO - 2017-02-04 17:13:17 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:13:17 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:13:17 --> Utf8 Class Initialized
INFO - 2017-02-04 17:13:17 --> URI Class Initialized
INFO - 2017-02-04 17:13:17 --> Router Class Initialized
INFO - 2017-02-04 17:13:17 --> Output Class Initialized
INFO - 2017-02-04 17:13:17 --> Security Class Initialized
DEBUG - 2017-02-04 17:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:13:17 --> Input Class Initialized
INFO - 2017-02-04 17:13:17 --> Language Class Initialized
INFO - 2017-02-04 17:13:17 --> Loader Class Initialized
INFO - 2017-02-04 17:13:17 --> Helper loaded: url_helper
INFO - 2017-02-04 17:13:17 --> Helper loaded: language_helper
INFO - 2017-02-04 17:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:13:17 --> Controller Class Initialized
INFO - 2017-02-04 17:13:17 --> Database Driver Class Initialized
INFO - 2017-02-04 17:13:17 --> Model Class Initialized
INFO - 2017-02-04 17:13:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:13:17 --> Config Class Initialized
INFO - 2017-02-04 17:13:17 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:13:17 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:13:17 --> Utf8 Class Initialized
INFO - 2017-02-04 17:13:17 --> URI Class Initialized
INFO - 2017-02-04 17:13:17 --> Router Class Initialized
INFO - 2017-02-04 17:13:17 --> Output Class Initialized
INFO - 2017-02-04 17:13:17 --> Security Class Initialized
DEBUG - 2017-02-04 17:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:13:17 --> Input Class Initialized
INFO - 2017-02-04 17:13:17 --> Language Class Initialized
INFO - 2017-02-04 17:13:17 --> Loader Class Initialized
INFO - 2017-02-04 17:13:17 --> Helper loaded: url_helper
INFO - 2017-02-04 17:13:17 --> Helper loaded: language_helper
INFO - 2017-02-04 17:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:13:17 --> Controller Class Initialized
INFO - 2017-02-04 17:13:17 --> Database Driver Class Initialized
INFO - 2017-02-04 17:13:17 --> Model Class Initialized
INFO - 2017-02-04 17:13:17 --> Model Class Initialized
INFO - 2017-02-04 17:13:17 --> Model Class Initialized
INFO - 2017-02-04 17:13:17 --> Model Class Initialized
INFO - 2017-02-04 17:13:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:13:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:13:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-04 17:13:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:13:17 --> Final output sent to browser
DEBUG - 2017-02-04 17:13:17 --> Total execution time: 0.0813
INFO - 2017-02-04 17:13:21 --> Config Class Initialized
INFO - 2017-02-04 17:13:21 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:13:21 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:13:21 --> Utf8 Class Initialized
INFO - 2017-02-04 17:13:21 --> URI Class Initialized
INFO - 2017-02-04 17:13:21 --> Router Class Initialized
INFO - 2017-02-04 17:13:21 --> Output Class Initialized
INFO - 2017-02-04 17:13:21 --> Security Class Initialized
DEBUG - 2017-02-04 17:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:13:21 --> Input Class Initialized
INFO - 2017-02-04 17:13:21 --> Language Class Initialized
INFO - 2017-02-04 17:13:21 --> Loader Class Initialized
INFO - 2017-02-04 17:13:21 --> Helper loaded: url_helper
INFO - 2017-02-04 17:13:21 --> Helper loaded: language_helper
INFO - 2017-02-04 17:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:13:21 --> Controller Class Initialized
INFO - 2017-02-04 17:13:21 --> Database Driver Class Initialized
INFO - 2017-02-04 17:13:21 --> Model Class Initialized
INFO - 2017-02-04 17:13:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:13:21 --> Helper loaded: form_helper
INFO - 2017-02-04 17:13:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:13:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-04 17:13:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:13:21 --> Final output sent to browser
DEBUG - 2017-02-04 17:13:21 --> Total execution time: 0.1066
INFO - 2017-02-04 17:13:26 --> Config Class Initialized
INFO - 2017-02-04 17:13:26 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:13:26 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:13:26 --> Utf8 Class Initialized
INFO - 2017-02-04 17:13:26 --> URI Class Initialized
INFO - 2017-02-04 17:13:26 --> Router Class Initialized
INFO - 2017-02-04 17:13:26 --> Output Class Initialized
INFO - 2017-02-04 17:13:26 --> Security Class Initialized
DEBUG - 2017-02-04 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:13:26 --> Input Class Initialized
INFO - 2017-02-04 17:13:26 --> Language Class Initialized
INFO - 2017-02-04 17:13:26 --> Loader Class Initialized
INFO - 2017-02-04 17:13:26 --> Helper loaded: url_helper
INFO - 2017-02-04 17:13:26 --> Helper loaded: language_helper
INFO - 2017-02-04 17:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:13:26 --> Controller Class Initialized
INFO - 2017-02-04 17:13:26 --> Database Driver Class Initialized
INFO - 2017-02-04 17:13:26 --> Model Class Initialized
INFO - 2017-02-04 17:13:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:13:26 --> Helper loaded: form_helper
INFO - 2017-02-04 17:13:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:13:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-04 17:13:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:13:26 --> Final output sent to browser
DEBUG - 2017-02-04 17:13:26 --> Total execution time: 0.1102
INFO - 2017-02-04 17:14:45 --> Config Class Initialized
INFO - 2017-02-04 17:14:45 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:14:45 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:14:45 --> Utf8 Class Initialized
INFO - 2017-02-04 17:14:45 --> URI Class Initialized
INFO - 2017-02-04 17:14:45 --> Router Class Initialized
INFO - 2017-02-04 17:14:45 --> Output Class Initialized
INFO - 2017-02-04 17:14:45 --> Security Class Initialized
DEBUG - 2017-02-04 17:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:14:45 --> Input Class Initialized
INFO - 2017-02-04 17:14:45 --> Language Class Initialized
INFO - 2017-02-04 17:14:45 --> Loader Class Initialized
INFO - 2017-02-04 17:14:45 --> Helper loaded: url_helper
INFO - 2017-02-04 17:14:45 --> Helper loaded: language_helper
INFO - 2017-02-04 17:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:14:45 --> Controller Class Initialized
INFO - 2017-02-04 17:14:45 --> Database Driver Class Initialized
INFO - 2017-02-04 17:14:45 --> Model Class Initialized
INFO - 2017-02-04 17:14:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:14:45 --> Helper loaded: form_helper
INFO - 2017-02-04 17:14:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:14:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-04 17:14:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:14:45 --> Final output sent to browser
DEBUG - 2017-02-04 17:14:45 --> Total execution time: 0.1070
INFO - 2017-02-04 17:15:04 --> Config Class Initialized
INFO - 2017-02-04 17:15:04 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:15:04 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:15:04 --> Utf8 Class Initialized
INFO - 2017-02-04 17:15:04 --> URI Class Initialized
INFO - 2017-02-04 17:15:04 --> Router Class Initialized
INFO - 2017-02-04 17:15:04 --> Output Class Initialized
INFO - 2017-02-04 17:15:04 --> Security Class Initialized
DEBUG - 2017-02-04 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:15:04 --> Input Class Initialized
INFO - 2017-02-04 17:15:04 --> Language Class Initialized
INFO - 2017-02-04 17:15:04 --> Loader Class Initialized
INFO - 2017-02-04 17:15:04 --> Helper loaded: url_helper
INFO - 2017-02-04 17:15:04 --> Helper loaded: language_helper
INFO - 2017-02-04 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:15:04 --> Controller Class Initialized
INFO - 2017-02-04 17:15:04 --> Database Driver Class Initialized
INFO - 2017-02-04 17:15:04 --> Model Class Initialized
INFO - 2017-02-04 17:15:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:15:04 --> Helper loaded: form_helper
INFO - 2017-02-04 17:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-04 17:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:15:04 --> Final output sent to browser
DEBUG - 2017-02-04 17:15:04 --> Total execution time: 0.1086
INFO - 2017-02-04 17:26:43 --> Config Class Initialized
INFO - 2017-02-04 17:26:43 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:26:43 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:26:43 --> Utf8 Class Initialized
INFO - 2017-02-04 17:26:43 --> URI Class Initialized
INFO - 2017-02-04 17:26:43 --> Router Class Initialized
INFO - 2017-02-04 17:26:43 --> Output Class Initialized
INFO - 2017-02-04 17:26:43 --> Security Class Initialized
DEBUG - 2017-02-04 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:26:43 --> Input Class Initialized
INFO - 2017-02-04 17:26:43 --> Language Class Initialized
INFO - 2017-02-04 17:26:43 --> Loader Class Initialized
INFO - 2017-02-04 17:26:43 --> Helper loaded: url_helper
INFO - 2017-02-04 17:26:43 --> Helper loaded: language_helper
INFO - 2017-02-04 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:26:43 --> Controller Class Initialized
INFO - 2017-02-04 17:26:43 --> Database Driver Class Initialized
INFO - 2017-02-04 17:26:43 --> Model Class Initialized
INFO - 2017-02-04 17:26:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:26:43 --> Helper loaded: form_helper
INFO - 2017-02-04 17:26:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:26:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-02-04 17:26:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:26:43 --> Final output sent to browser
DEBUG - 2017-02-04 17:26:43 --> Total execution time: 0.0923
INFO - 2017-02-04 17:26:48 --> Config Class Initialized
INFO - 2017-02-04 17:26:48 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:26:48 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:26:48 --> Utf8 Class Initialized
INFO - 2017-02-04 17:26:48 --> URI Class Initialized
INFO - 2017-02-04 17:26:48 --> Router Class Initialized
INFO - 2017-02-04 17:26:48 --> Output Class Initialized
INFO - 2017-02-04 17:26:48 --> Security Class Initialized
DEBUG - 2017-02-04 17:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:26:48 --> Input Class Initialized
INFO - 2017-02-04 17:26:48 --> Language Class Initialized
INFO - 2017-02-04 17:26:48 --> Loader Class Initialized
INFO - 2017-02-04 17:26:48 --> Helper loaded: url_helper
INFO - 2017-02-04 17:26:48 --> Helper loaded: language_helper
INFO - 2017-02-04 17:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:26:48 --> Controller Class Initialized
INFO - 2017-02-04 17:26:48 --> Database Driver Class Initialized
INFO - 2017-02-04 17:26:48 --> Model Class Initialized
INFO - 2017-02-04 17:26:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:26:48 --> Config Class Initialized
INFO - 2017-02-04 17:26:48 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:26:49 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:26:49 --> Utf8 Class Initialized
INFO - 2017-02-04 17:26:49 --> URI Class Initialized
INFO - 2017-02-04 17:26:49 --> Router Class Initialized
INFO - 2017-02-04 17:26:49 --> Output Class Initialized
INFO - 2017-02-04 17:26:49 --> Security Class Initialized
DEBUG - 2017-02-04 17:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:26:49 --> Input Class Initialized
INFO - 2017-02-04 17:26:49 --> Language Class Initialized
INFO - 2017-02-04 17:26:49 --> Loader Class Initialized
INFO - 2017-02-04 17:26:49 --> Helper loaded: url_helper
INFO - 2017-02-04 17:26:49 --> Helper loaded: language_helper
INFO - 2017-02-04 17:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:26:49 --> Controller Class Initialized
INFO - 2017-02-04 17:26:49 --> Database Driver Class Initialized
INFO - 2017-02-04 17:26:49 --> Model Class Initialized
INFO - 2017-02-04 17:26:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:26:49 --> Helper loaded: form_helper
INFO - 2017-02-04 17:26:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:26:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-02-04 17:26:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:26:49 --> Final output sent to browser
DEBUG - 2017-02-04 17:26:49 --> Total execution time: 0.1446
INFO - 2017-02-04 17:26:56 --> Config Class Initialized
INFO - 2017-02-04 17:26:56 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:26:56 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:26:56 --> Utf8 Class Initialized
INFO - 2017-02-04 17:26:56 --> URI Class Initialized
INFO - 2017-02-04 17:26:56 --> Router Class Initialized
INFO - 2017-02-04 17:26:56 --> Output Class Initialized
INFO - 2017-02-04 17:26:56 --> Security Class Initialized
DEBUG - 2017-02-04 17:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:26:56 --> Input Class Initialized
INFO - 2017-02-04 17:26:56 --> Language Class Initialized
INFO - 2017-02-04 17:26:56 --> Loader Class Initialized
INFO - 2017-02-04 17:26:56 --> Helper loaded: url_helper
INFO - 2017-02-04 17:26:56 --> Helper loaded: language_helper
INFO - 2017-02-04 17:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:26:56 --> Controller Class Initialized
INFO - 2017-02-04 17:26:56 --> Database Driver Class Initialized
INFO - 2017-02-04 17:26:56 --> Model Class Initialized
INFO - 2017-02-04 17:26:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:26:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:26:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2017-02-04 17:26:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:26:56 --> Final output sent to browser
DEBUG - 2017-02-04 17:26:56 --> Total execution time: 0.1733
INFO - 2017-02-04 17:27:10 --> Config Class Initialized
INFO - 2017-02-04 17:27:10 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:27:10 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:27:10 --> Utf8 Class Initialized
INFO - 2017-02-04 17:27:10 --> URI Class Initialized
INFO - 2017-02-04 17:27:10 --> Router Class Initialized
INFO - 2017-02-04 17:27:10 --> Output Class Initialized
INFO - 2017-02-04 17:27:10 --> Security Class Initialized
DEBUG - 2017-02-04 17:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:27:10 --> Input Class Initialized
INFO - 2017-02-04 17:27:10 --> Language Class Initialized
INFO - 2017-02-04 17:27:10 --> Loader Class Initialized
INFO - 2017-02-04 17:27:10 --> Helper loaded: url_helper
INFO - 2017-02-04 17:27:10 --> Helper loaded: language_helper
INFO - 2017-02-04 17:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:27:10 --> Controller Class Initialized
INFO - 2017-02-04 17:27:10 --> Database Driver Class Initialized
INFO - 2017-02-04 17:27:10 --> Model Class Initialized
INFO - 2017-02-04 17:27:10 --> Model Class Initialized
INFO - 2017-02-04 17:27:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:27:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:27:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\disc_list.php
INFO - 2017-02-04 17:27:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:27:10 --> Final output sent to browser
DEBUG - 2017-02-04 17:27:10 --> Total execution time: 0.1607
INFO - 2017-02-04 17:27:30 --> Config Class Initialized
INFO - 2017-02-04 17:27:30 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:27:30 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:27:30 --> Utf8 Class Initialized
INFO - 2017-02-04 17:27:30 --> URI Class Initialized
INFO - 2017-02-04 17:27:30 --> Router Class Initialized
INFO - 2017-02-04 17:27:30 --> Output Class Initialized
INFO - 2017-02-04 17:27:30 --> Security Class Initialized
DEBUG - 2017-02-04 17:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:27:30 --> Input Class Initialized
INFO - 2017-02-04 17:27:30 --> Language Class Initialized
INFO - 2017-02-04 17:27:30 --> Loader Class Initialized
INFO - 2017-02-04 17:27:30 --> Helper loaded: url_helper
INFO - 2017-02-04 17:27:30 --> Helper loaded: language_helper
INFO - 2017-02-04 17:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:27:30 --> Controller Class Initialized
INFO - 2017-02-04 17:27:30 --> Database Driver Class Initialized
INFO - 2017-02-04 17:27:30 --> Model Class Initialized
INFO - 2017-02-04 17:27:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:27:30 --> Helper loaded: form_helper
INFO - 2017-02-04 17:27:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:27:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-02-04 17:27:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:27:30 --> Final output sent to browser
DEBUG - 2017-02-04 17:27:30 --> Total execution time: 0.1927
INFO - 2017-02-04 17:27:36 --> Config Class Initialized
INFO - 2017-02-04 17:27:36 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:27:36 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:27:36 --> Utf8 Class Initialized
INFO - 2017-02-04 17:27:36 --> URI Class Initialized
INFO - 2017-02-04 17:27:36 --> Router Class Initialized
INFO - 2017-02-04 17:27:36 --> Output Class Initialized
INFO - 2017-02-04 17:27:36 --> Security Class Initialized
DEBUG - 2017-02-04 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:27:36 --> Input Class Initialized
INFO - 2017-02-04 17:27:36 --> Language Class Initialized
INFO - 2017-02-04 17:27:36 --> Loader Class Initialized
INFO - 2017-02-04 17:27:36 --> Helper loaded: url_helper
INFO - 2017-02-04 17:27:36 --> Helper loaded: language_helper
INFO - 2017-02-04 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:27:36 --> Controller Class Initialized
INFO - 2017-02-04 17:27:36 --> Database Driver Class Initialized
INFO - 2017-02-04 17:27:36 --> Model Class Initialized
INFO - 2017-02-04 17:27:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:27:36 --> Config Class Initialized
INFO - 2017-02-04 17:27:36 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:27:36 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:27:36 --> Utf8 Class Initialized
INFO - 2017-02-04 17:27:36 --> URI Class Initialized
INFO - 2017-02-04 17:27:36 --> Router Class Initialized
INFO - 2017-02-04 17:27:36 --> Output Class Initialized
INFO - 2017-02-04 17:27:36 --> Security Class Initialized
DEBUG - 2017-02-04 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:27:36 --> Input Class Initialized
INFO - 2017-02-04 17:27:36 --> Language Class Initialized
INFO - 2017-02-04 17:27:36 --> Loader Class Initialized
INFO - 2017-02-04 17:27:36 --> Helper loaded: url_helper
INFO - 2017-02-04 17:27:36 --> Helper loaded: language_helper
INFO - 2017-02-04 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:27:36 --> Controller Class Initialized
INFO - 2017-02-04 17:27:36 --> Database Driver Class Initialized
INFO - 2017-02-04 17:27:36 --> Model Class Initialized
INFO - 2017-02-04 17:27:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:27:36 --> Helper loaded: form_helper
INFO - 2017-02-04 17:27:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:27:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-02-04 17:27:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:27:36 --> Final output sent to browser
DEBUG - 2017-02-04 17:27:36 --> Total execution time: 0.1132
INFO - 2017-02-04 17:27:42 --> Config Class Initialized
INFO - 2017-02-04 17:27:42 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:27:42 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:27:42 --> Utf8 Class Initialized
INFO - 2017-02-04 17:27:42 --> URI Class Initialized
INFO - 2017-02-04 17:27:42 --> Router Class Initialized
INFO - 2017-02-04 17:27:42 --> Output Class Initialized
INFO - 2017-02-04 17:27:42 --> Security Class Initialized
DEBUG - 2017-02-04 17:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:27:42 --> Input Class Initialized
INFO - 2017-02-04 17:27:42 --> Language Class Initialized
INFO - 2017-02-04 17:27:42 --> Loader Class Initialized
INFO - 2017-02-04 17:27:42 --> Helper loaded: url_helper
INFO - 2017-02-04 17:27:42 --> Helper loaded: language_helper
INFO - 2017-02-04 17:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:27:42 --> Controller Class Initialized
INFO - 2017-02-04 17:27:42 --> Database Driver Class Initialized
INFO - 2017-02-04 17:27:42 --> Model Class Initialized
INFO - 2017-02-04 17:27:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_6.php
INFO - 2017-02-04 17:27:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:27:42 --> Final output sent to browser
DEBUG - 2017-02-04 17:27:42 --> Total execution time: 0.1608
INFO - 2017-02-04 17:28:17 --> Config Class Initialized
INFO - 2017-02-04 17:28:17 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:28:17 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:28:17 --> Utf8 Class Initialized
INFO - 2017-02-04 17:28:17 --> URI Class Initialized
INFO - 2017-02-04 17:28:17 --> Router Class Initialized
INFO - 2017-02-04 17:28:17 --> Output Class Initialized
INFO - 2017-02-04 17:28:17 --> Security Class Initialized
DEBUG - 2017-02-04 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:28:17 --> Input Class Initialized
INFO - 2017-02-04 17:28:17 --> Language Class Initialized
INFO - 2017-02-04 17:28:17 --> Loader Class Initialized
INFO - 2017-02-04 17:28:17 --> Helper loaded: url_helper
INFO - 2017-02-04 17:28:17 --> Helper loaded: language_helper
INFO - 2017-02-04 17:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:28:17 --> Controller Class Initialized
INFO - 2017-02-04 17:28:17 --> Database Driver Class Initialized
INFO - 2017-02-04 17:28:17 --> Model Class Initialized
INFO - 2017-02-04 17:28:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:28:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:28:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\pre_new_question.php
INFO - 2017-02-04 17:28:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:28:17 --> Final output sent to browser
DEBUG - 2017-02-04 17:28:17 --> Total execution time: 0.0754
INFO - 2017-02-04 17:28:21 --> Config Class Initialized
INFO - 2017-02-04 17:28:21 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:28:21 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:28:21 --> Utf8 Class Initialized
INFO - 2017-02-04 17:28:21 --> URI Class Initialized
INFO - 2017-02-04 17:28:21 --> Router Class Initialized
INFO - 2017-02-04 17:28:21 --> Output Class Initialized
INFO - 2017-02-04 17:28:21 --> Security Class Initialized
DEBUG - 2017-02-04 17:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:28:21 --> Input Class Initialized
INFO - 2017-02-04 17:28:21 --> Language Class Initialized
INFO - 2017-02-04 17:28:21 --> Loader Class Initialized
INFO - 2017-02-04 17:28:21 --> Helper loaded: url_helper
INFO - 2017-02-04 17:28:21 --> Helper loaded: language_helper
INFO - 2017-02-04 17:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:28:21 --> Controller Class Initialized
INFO - 2017-02-04 17:28:21 --> Database Driver Class Initialized
INFO - 2017-02-04 17:28:21 --> Model Class Initialized
INFO - 2017-02-04 17:28:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:28:21 --> Config Class Initialized
INFO - 2017-02-04 17:28:21 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:28:21 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:28:21 --> Utf8 Class Initialized
INFO - 2017-02-04 17:28:21 --> URI Class Initialized
INFO - 2017-02-04 17:28:21 --> Router Class Initialized
INFO - 2017-02-04 17:28:21 --> Output Class Initialized
INFO - 2017-02-04 17:28:21 --> Security Class Initialized
DEBUG - 2017-02-04 17:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:28:21 --> Input Class Initialized
INFO - 2017-02-04 17:28:21 --> Language Class Initialized
INFO - 2017-02-04 17:28:21 --> Loader Class Initialized
INFO - 2017-02-04 17:28:21 --> Helper loaded: url_helper
INFO - 2017-02-04 17:28:21 --> Helper loaded: language_helper
INFO - 2017-02-04 17:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:28:21 --> Controller Class Initialized
INFO - 2017-02-04 17:28:21 --> Database Driver Class Initialized
INFO - 2017-02-04 17:28:21 --> Model Class Initialized
INFO - 2017-02-04 17:28:21 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-04 17:28:21 --> Could not find the language line "savsoft_quiz"
INFO - 2017-02-04 17:28:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_disc.php
INFO - 2017-02-04 17:28:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_question_6.php
INFO - 2017-02-04 17:28:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_disc.php
INFO - 2017-02-04 17:28:21 --> Final output sent to browser
DEBUG - 2017-02-04 17:28:21 --> Total execution time: 0.1227
INFO - 2017-02-04 17:32:06 --> Config Class Initialized
INFO - 2017-02-04 17:32:06 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:32:06 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:32:06 --> Utf8 Class Initialized
INFO - 2017-02-04 17:32:06 --> URI Class Initialized
INFO - 2017-02-04 17:32:06 --> Router Class Initialized
INFO - 2017-02-04 17:32:06 --> Output Class Initialized
INFO - 2017-02-04 17:32:06 --> Security Class Initialized
DEBUG - 2017-02-04 17:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:32:06 --> Input Class Initialized
INFO - 2017-02-04 17:32:06 --> Language Class Initialized
INFO - 2017-02-04 17:32:06 --> Loader Class Initialized
INFO - 2017-02-04 17:32:06 --> Helper loaded: url_helper
INFO - 2017-02-04 17:32:06 --> Helper loaded: language_helper
INFO - 2017-02-04 17:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:32:06 --> Controller Class Initialized
INFO - 2017-02-04 17:32:06 --> Database Driver Class Initialized
INFO - 2017-02-04 17:32:06 --> Model Class Initialized
INFO - 2017-02-04 17:32:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:32:06 --> Helper loaded: form_helper
INFO - 2017-02-04 17:32:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:32:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-02-04 17:32:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:32:06 --> Final output sent to browser
DEBUG - 2017-02-04 17:32:06 --> Total execution time: 0.0967
INFO - 2017-02-04 17:32:37 --> Config Class Initialized
INFO - 2017-02-04 17:32:37 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:32:37 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:32:37 --> Utf8 Class Initialized
INFO - 2017-02-04 17:32:37 --> URI Class Initialized
INFO - 2017-02-04 17:32:37 --> Router Class Initialized
INFO - 2017-02-04 17:32:37 --> Output Class Initialized
INFO - 2017-02-04 17:32:37 --> Security Class Initialized
DEBUG - 2017-02-04 17:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:32:37 --> Input Class Initialized
INFO - 2017-02-04 17:32:37 --> Language Class Initialized
INFO - 2017-02-04 17:32:37 --> Loader Class Initialized
INFO - 2017-02-04 17:32:37 --> Helper loaded: url_helper
INFO - 2017-02-04 17:32:37 --> Helper loaded: language_helper
INFO - 2017-02-04 17:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:32:37 --> Controller Class Initialized
INFO - 2017-02-04 17:32:37 --> Database Driver Class Initialized
INFO - 2017-02-04 17:32:37 --> Model Class Initialized
INFO - 2017-02-04 17:32:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:32:37 --> Helper loaded: form_helper
INFO - 2017-02-04 17:32:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:32:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-04 17:32:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:32:37 --> Final output sent to browser
DEBUG - 2017-02-04 17:32:37 --> Total execution time: 0.1636
INFO - 2017-02-04 17:32:47 --> Config Class Initialized
INFO - 2017-02-04 17:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-04 17:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-04 17:32:47 --> Utf8 Class Initialized
INFO - 2017-02-04 17:32:47 --> URI Class Initialized
INFO - 2017-02-04 17:32:47 --> Router Class Initialized
INFO - 2017-02-04 17:32:47 --> Output Class Initialized
INFO - 2017-02-04 17:32:47 --> Security Class Initialized
DEBUG - 2017-02-04 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 17:32:47 --> Input Class Initialized
INFO - 2017-02-04 17:32:47 --> Language Class Initialized
INFO - 2017-02-04 17:32:47 --> Loader Class Initialized
INFO - 2017-02-04 17:32:47 --> Helper loaded: url_helper
INFO - 2017-02-04 17:32:47 --> Helper loaded: language_helper
INFO - 2017-02-04 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 17:32:47 --> Controller Class Initialized
INFO - 2017-02-04 17:32:47 --> Database Driver Class Initialized
INFO - 2017-02-04 17:32:47 --> Model Class Initialized
INFO - 2017-02-04 17:32:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-04 17:32:47 --> Helper loaded: form_helper
INFO - 2017-02-04 17:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-04 17:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-04 17:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-04 17:32:47 --> Final output sent to browser
DEBUG - 2017-02-04 17:32:47 --> Total execution time: 0.1583
