<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-05 11:52:37 --> Config Class Initialized
INFO - 2017-02-05 11:52:37 --> Hooks Class Initialized
DEBUG - 2017-02-05 11:52:37 --> UTF-8 Support Enabled
INFO - 2017-02-05 11:52:37 --> Utf8 Class Initialized
INFO - 2017-02-05 11:52:37 --> URI Class Initialized
INFO - 2017-02-05 11:52:37 --> Router Class Initialized
INFO - 2017-02-05 11:52:37 --> Output Class Initialized
INFO - 2017-02-05 11:52:37 --> Security Class Initialized
DEBUG - 2017-02-05 11:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 11:52:37 --> Input Class Initialized
INFO - 2017-02-05 11:52:37 --> Language Class Initialized
INFO - 2017-02-05 11:52:37 --> Loader Class Initialized
INFO - 2017-02-05 11:52:37 --> Helper loaded: url_helper
INFO - 2017-02-05 11:52:37 --> Helper loaded: language_helper
INFO - 2017-02-05 11:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 11:52:37 --> Controller Class Initialized
INFO - 2017-02-05 11:52:37 --> Database Driver Class Initialized
INFO - 2017-02-05 11:52:37 --> Model Class Initialized
INFO - 2017-02-05 11:52:37 --> Language file loaded: language/indonesia/basic_lang.php
