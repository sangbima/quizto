<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-07 08:25:22 --> Config Class Initialized
INFO - 2017-02-07 08:25:22 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:25:22 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:25:22 --> Utf8 Class Initialized
INFO - 2017-02-07 08:25:22 --> URI Class Initialized
INFO - 2017-02-07 08:25:22 --> Router Class Initialized
INFO - 2017-02-07 08:25:22 --> Output Class Initialized
INFO - 2017-02-07 08:25:22 --> Security Class Initialized
DEBUG - 2017-02-07 08:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:25:22 --> Input Class Initialized
INFO - 2017-02-07 08:25:22 --> Language Class Initialized
INFO - 2017-02-07 08:25:22 --> Loader Class Initialized
INFO - 2017-02-07 08:25:22 --> Helper loaded: url_helper
INFO - 2017-02-07 08:25:22 --> Helper loaded: language_helper
INFO - 2017-02-07 08:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:25:22 --> Controller Class Initialized
INFO - 2017-02-07 08:25:22 --> Database Driver Class Initialized
INFO - 2017-02-07 08:25:22 --> Model Class Initialized
INFO - 2017-02-07 08:25:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:25:22 --> Config Class Initialized
INFO - 2017-02-07 08:25:22 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:25:22 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:25:22 --> Utf8 Class Initialized
INFO - 2017-02-07 08:25:22 --> URI Class Initialized
INFO - 2017-02-07 08:25:22 --> Router Class Initialized
INFO - 2017-02-07 08:25:22 --> Output Class Initialized
INFO - 2017-02-07 08:25:22 --> Security Class Initialized
DEBUG - 2017-02-07 08:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:25:22 --> Input Class Initialized
INFO - 2017-02-07 08:25:22 --> Language Class Initialized
INFO - 2017-02-07 08:25:22 --> Loader Class Initialized
INFO - 2017-02-07 08:25:22 --> Helper loaded: url_helper
INFO - 2017-02-07 08:25:22 --> Helper loaded: language_helper
INFO - 2017-02-07 08:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:25:22 --> Controller Class Initialized
INFO - 2017-02-07 08:25:22 --> Database Driver Class Initialized
INFO - 2017-02-07 08:25:22 --> Model Class Initialized
INFO - 2017-02-07 08:25:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:25:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-07 08:25:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-07 08:25:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-07 08:25:22 --> Final output sent to browser
DEBUG - 2017-02-07 08:25:22 --> Total execution time: 0.0765
INFO - 2017-02-07 08:25:27 --> Config Class Initialized
INFO - 2017-02-07 08:25:27 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:25:27 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:25:27 --> Utf8 Class Initialized
INFO - 2017-02-07 08:25:27 --> URI Class Initialized
INFO - 2017-02-07 08:25:27 --> Router Class Initialized
INFO - 2017-02-07 08:25:27 --> Output Class Initialized
INFO - 2017-02-07 08:25:27 --> Security Class Initialized
DEBUG - 2017-02-07 08:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:25:27 --> Input Class Initialized
INFO - 2017-02-07 08:25:27 --> Language Class Initialized
INFO - 2017-02-07 08:25:27 --> Loader Class Initialized
INFO - 2017-02-07 08:25:27 --> Helper loaded: url_helper
INFO - 2017-02-07 08:25:27 --> Helper loaded: language_helper
INFO - 2017-02-07 08:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:25:27 --> Controller Class Initialized
INFO - 2017-02-07 08:25:27 --> Database Driver Class Initialized
INFO - 2017-02-07 08:25:27 --> Model Class Initialized
INFO - 2017-02-07 08:25:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:25:27 --> Config Class Initialized
INFO - 2017-02-07 08:25:27 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:25:27 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:25:27 --> Utf8 Class Initialized
INFO - 2017-02-07 08:25:27 --> URI Class Initialized
INFO - 2017-02-07 08:25:27 --> Router Class Initialized
INFO - 2017-02-07 08:25:27 --> Output Class Initialized
INFO - 2017-02-07 08:25:27 --> Security Class Initialized
DEBUG - 2017-02-07 08:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:25:27 --> Input Class Initialized
INFO - 2017-02-07 08:25:27 --> Language Class Initialized
INFO - 2017-02-07 08:25:27 --> Loader Class Initialized
INFO - 2017-02-07 08:25:27 --> Helper loaded: url_helper
INFO - 2017-02-07 08:25:27 --> Helper loaded: language_helper
INFO - 2017-02-07 08:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:25:27 --> Controller Class Initialized
INFO - 2017-02-07 08:25:27 --> Database Driver Class Initialized
INFO - 2017-02-07 08:25:27 --> Model Class Initialized
INFO - 2017-02-07 08:25:27 --> Model Class Initialized
INFO - 2017-02-07 08:25:27 --> Model Class Initialized
INFO - 2017-02-07 08:25:27 --> Model Class Initialized
INFO - 2017-02-07 08:25:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:25:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:25:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-07 08:25:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:25:27 --> Final output sent to browser
DEBUG - 2017-02-07 08:25:27 --> Total execution time: 0.0966
INFO - 2017-02-07 08:25:29 --> Config Class Initialized
INFO - 2017-02-07 08:25:29 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:25:29 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:25:29 --> Utf8 Class Initialized
INFO - 2017-02-07 08:25:29 --> URI Class Initialized
INFO - 2017-02-07 08:25:29 --> Router Class Initialized
INFO - 2017-02-07 08:25:29 --> Output Class Initialized
INFO - 2017-02-07 08:25:29 --> Security Class Initialized
DEBUG - 2017-02-07 08:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:25:29 --> Input Class Initialized
INFO - 2017-02-07 08:25:29 --> Language Class Initialized
INFO - 2017-02-07 08:25:29 --> Loader Class Initialized
INFO - 2017-02-07 08:25:29 --> Helper loaded: url_helper
INFO - 2017-02-07 08:25:29 --> Helper loaded: language_helper
INFO - 2017-02-07 08:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:25:29 --> Controller Class Initialized
INFO - 2017-02-07 08:25:30 --> Database Driver Class Initialized
INFO - 2017-02-07 08:25:30 --> Model Class Initialized
INFO - 2017-02-07 08:25:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:25:30 --> Helper loaded: form_helper
INFO - 2017-02-07 08:25:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:25:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:25:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:25:30 --> Final output sent to browser
DEBUG - 2017-02-07 08:25:30 --> Total execution time: 0.1239
INFO - 2017-02-07 08:26:52 --> Config Class Initialized
INFO - 2017-02-07 08:26:52 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:26:52 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:26:52 --> Utf8 Class Initialized
INFO - 2017-02-07 08:26:52 --> URI Class Initialized
INFO - 2017-02-07 08:26:52 --> Router Class Initialized
INFO - 2017-02-07 08:26:52 --> Output Class Initialized
INFO - 2017-02-07 08:26:52 --> Security Class Initialized
DEBUG - 2017-02-07 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:26:52 --> Input Class Initialized
INFO - 2017-02-07 08:26:52 --> Language Class Initialized
INFO - 2017-02-07 08:26:52 --> Loader Class Initialized
INFO - 2017-02-07 08:26:52 --> Helper loaded: url_helper
INFO - 2017-02-07 08:26:52 --> Helper loaded: language_helper
INFO - 2017-02-07 08:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:26:52 --> Controller Class Initialized
INFO - 2017-02-07 08:26:52 --> Database Driver Class Initialized
INFO - 2017-02-07 08:26:52 --> Model Class Initialized
INFO - 2017-02-07 08:26:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:26:52 --> Helper loaded: form_helper
INFO - 2017-02-07 08:26:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:26:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:26:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:26:52 --> Final output sent to browser
DEBUG - 2017-02-07 08:26:52 --> Total execution time: 0.1322
INFO - 2017-02-07 08:27:12 --> Config Class Initialized
INFO - 2017-02-07 08:27:12 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:27:12 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:27:12 --> Utf8 Class Initialized
INFO - 2017-02-07 08:27:12 --> URI Class Initialized
INFO - 2017-02-07 08:27:12 --> Router Class Initialized
INFO - 2017-02-07 08:27:12 --> Output Class Initialized
INFO - 2017-02-07 08:27:12 --> Security Class Initialized
DEBUG - 2017-02-07 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:27:12 --> Input Class Initialized
INFO - 2017-02-07 08:27:12 --> Language Class Initialized
INFO - 2017-02-07 08:27:12 --> Loader Class Initialized
INFO - 2017-02-07 08:27:12 --> Helper loaded: url_helper
INFO - 2017-02-07 08:27:12 --> Helper loaded: language_helper
INFO - 2017-02-07 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:27:12 --> Controller Class Initialized
INFO - 2017-02-07 08:27:12 --> Database Driver Class Initialized
INFO - 2017-02-07 08:27:12 --> Model Class Initialized
INFO - 2017-02-07 08:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:27:12 --> Helper loaded: form_helper
INFO - 2017-02-07 08:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:27:12 --> Final output sent to browser
DEBUG - 2017-02-07 08:27:12 --> Total execution time: 0.1343
INFO - 2017-02-07 08:27:53 --> Config Class Initialized
INFO - 2017-02-07 08:27:53 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:27:53 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:27:53 --> Utf8 Class Initialized
INFO - 2017-02-07 08:27:53 --> URI Class Initialized
INFO - 2017-02-07 08:27:53 --> Router Class Initialized
INFO - 2017-02-07 08:27:53 --> Output Class Initialized
INFO - 2017-02-07 08:27:53 --> Security Class Initialized
DEBUG - 2017-02-07 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:27:53 --> Input Class Initialized
INFO - 2017-02-07 08:27:53 --> Language Class Initialized
INFO - 2017-02-07 08:27:53 --> Loader Class Initialized
INFO - 2017-02-07 08:27:53 --> Helper loaded: url_helper
INFO - 2017-02-07 08:27:53 --> Helper loaded: language_helper
INFO - 2017-02-07 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:27:53 --> Controller Class Initialized
INFO - 2017-02-07 08:27:53 --> Database Driver Class Initialized
INFO - 2017-02-07 08:27:53 --> Model Class Initialized
INFO - 2017-02-07 08:27:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:27:53 --> Helper loaded: form_helper
INFO - 2017-02-07 08:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:27:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:27:53 --> Final output sent to browser
DEBUG - 2017-02-07 08:27:53 --> Total execution time: 0.1102
INFO - 2017-02-07 08:27:55 --> Config Class Initialized
INFO - 2017-02-07 08:27:55 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:27:55 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:27:55 --> Utf8 Class Initialized
INFO - 2017-02-07 08:27:55 --> URI Class Initialized
INFO - 2017-02-07 08:27:55 --> Router Class Initialized
INFO - 2017-02-07 08:27:55 --> Output Class Initialized
INFO - 2017-02-07 08:27:55 --> Security Class Initialized
DEBUG - 2017-02-07 08:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:27:55 --> Input Class Initialized
INFO - 2017-02-07 08:27:55 --> Language Class Initialized
INFO - 2017-02-07 08:27:55 --> Loader Class Initialized
INFO - 2017-02-07 08:27:55 --> Helper loaded: url_helper
INFO - 2017-02-07 08:27:55 --> Helper loaded: language_helper
INFO - 2017-02-07 08:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:27:55 --> Controller Class Initialized
INFO - 2017-02-07 08:27:55 --> Database Driver Class Initialized
INFO - 2017-02-07 08:27:55 --> Model Class Initialized
INFO - 2017-02-07 08:27:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:27:55 --> Helper loaded: form_helper
INFO - 2017-02-07 08:27:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:27:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:27:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:27:55 --> Final output sent to browser
DEBUG - 2017-02-07 08:27:55 --> Total execution time: 0.1297
INFO - 2017-02-07 08:29:05 --> Config Class Initialized
INFO - 2017-02-07 08:29:05 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:29:05 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:29:05 --> Utf8 Class Initialized
INFO - 2017-02-07 08:29:05 --> URI Class Initialized
INFO - 2017-02-07 08:29:05 --> Router Class Initialized
INFO - 2017-02-07 08:29:05 --> Output Class Initialized
INFO - 2017-02-07 08:29:05 --> Security Class Initialized
DEBUG - 2017-02-07 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:29:05 --> Input Class Initialized
INFO - 2017-02-07 08:29:05 --> Language Class Initialized
INFO - 2017-02-07 08:29:05 --> Loader Class Initialized
INFO - 2017-02-07 08:29:05 --> Helper loaded: url_helper
INFO - 2017-02-07 08:29:05 --> Helper loaded: language_helper
INFO - 2017-02-07 08:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:29:05 --> Controller Class Initialized
INFO - 2017-02-07 08:29:05 --> Database Driver Class Initialized
INFO - 2017-02-07 08:29:05 --> Model Class Initialized
INFO - 2017-02-07 08:29:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:29:05 --> Helper loaded: form_helper
INFO - 2017-02-07 08:29:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:29:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:29:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:29:05 --> Final output sent to browser
DEBUG - 2017-02-07 08:29:05 --> Total execution time: 0.1120
INFO - 2017-02-07 08:29:23 --> Config Class Initialized
INFO - 2017-02-07 08:29:23 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:29:23 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:29:23 --> Utf8 Class Initialized
INFO - 2017-02-07 08:29:23 --> URI Class Initialized
INFO - 2017-02-07 08:29:23 --> Router Class Initialized
INFO - 2017-02-07 08:29:23 --> Output Class Initialized
INFO - 2017-02-07 08:29:23 --> Security Class Initialized
DEBUG - 2017-02-07 08:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:29:23 --> Input Class Initialized
INFO - 2017-02-07 08:29:23 --> Language Class Initialized
INFO - 2017-02-07 08:29:23 --> Loader Class Initialized
INFO - 2017-02-07 08:29:24 --> Helper loaded: url_helper
INFO - 2017-02-07 08:29:24 --> Helper loaded: language_helper
INFO - 2017-02-07 08:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:29:24 --> Controller Class Initialized
INFO - 2017-02-07 08:29:24 --> Database Driver Class Initialized
INFO - 2017-02-07 08:29:24 --> Model Class Initialized
INFO - 2017-02-07 08:29:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:29:24 --> Helper loaded: form_helper
INFO - 2017-02-07 08:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:29:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:29:24 --> Final output sent to browser
DEBUG - 2017-02-07 08:29:24 --> Total execution time: 0.1163
INFO - 2017-02-07 08:29:33 --> Config Class Initialized
INFO - 2017-02-07 08:29:33 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:29:33 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:29:33 --> Utf8 Class Initialized
INFO - 2017-02-07 08:29:33 --> URI Class Initialized
INFO - 2017-02-07 08:29:33 --> Router Class Initialized
INFO - 2017-02-07 08:29:33 --> Output Class Initialized
INFO - 2017-02-07 08:29:33 --> Security Class Initialized
DEBUG - 2017-02-07 08:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:29:33 --> Input Class Initialized
INFO - 2017-02-07 08:29:33 --> Language Class Initialized
INFO - 2017-02-07 08:29:33 --> Loader Class Initialized
INFO - 2017-02-07 08:29:33 --> Helper loaded: url_helper
INFO - 2017-02-07 08:29:33 --> Helper loaded: language_helper
INFO - 2017-02-07 08:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:29:33 --> Controller Class Initialized
INFO - 2017-02-07 08:29:33 --> Database Driver Class Initialized
INFO - 2017-02-07 08:29:33 --> Model Class Initialized
INFO - 2017-02-07 08:29:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:29:33 --> Helper loaded: form_helper
INFO - 2017-02-07 08:29:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:29:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:29:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:29:33 --> Final output sent to browser
DEBUG - 2017-02-07 08:29:33 --> Total execution time: 0.1190
INFO - 2017-02-07 08:30:34 --> Config Class Initialized
INFO - 2017-02-07 08:30:34 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:30:34 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:30:34 --> Utf8 Class Initialized
INFO - 2017-02-07 08:30:34 --> URI Class Initialized
INFO - 2017-02-07 08:30:34 --> Router Class Initialized
INFO - 2017-02-07 08:30:34 --> Output Class Initialized
INFO - 2017-02-07 08:30:34 --> Security Class Initialized
DEBUG - 2017-02-07 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:30:34 --> Input Class Initialized
INFO - 2017-02-07 08:30:34 --> Language Class Initialized
INFO - 2017-02-07 08:30:34 --> Loader Class Initialized
INFO - 2017-02-07 08:30:34 --> Helper loaded: url_helper
INFO - 2017-02-07 08:30:34 --> Helper loaded: language_helper
INFO - 2017-02-07 08:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:30:34 --> Controller Class Initialized
INFO - 2017-02-07 08:30:34 --> Database Driver Class Initialized
INFO - 2017-02-07 08:30:34 --> Model Class Initialized
INFO - 2017-02-07 08:30:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:30:34 --> Helper loaded: form_helper
INFO - 2017-02-07 08:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:30:34 --> Final output sent to browser
DEBUG - 2017-02-07 08:30:34 --> Total execution time: 0.1090
INFO - 2017-02-07 08:31:19 --> Config Class Initialized
INFO - 2017-02-07 08:31:19 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:31:19 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:31:19 --> Utf8 Class Initialized
INFO - 2017-02-07 08:31:19 --> URI Class Initialized
INFO - 2017-02-07 08:31:19 --> Router Class Initialized
INFO - 2017-02-07 08:31:19 --> Output Class Initialized
INFO - 2017-02-07 08:31:19 --> Security Class Initialized
DEBUG - 2017-02-07 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:31:19 --> Input Class Initialized
INFO - 2017-02-07 08:31:19 --> Language Class Initialized
INFO - 2017-02-07 08:31:19 --> Loader Class Initialized
INFO - 2017-02-07 08:31:19 --> Helper loaded: url_helper
INFO - 2017-02-07 08:31:19 --> Helper loaded: language_helper
INFO - 2017-02-07 08:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:31:19 --> Controller Class Initialized
INFO - 2017-02-07 08:31:19 --> Database Driver Class Initialized
INFO - 2017-02-07 08:31:19 --> Model Class Initialized
INFO - 2017-02-07 08:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:31:19 --> Helper loaded: form_helper
INFO - 2017-02-07 08:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:31:19 --> Final output sent to browser
DEBUG - 2017-02-07 08:31:19 --> Total execution time: 0.1076
INFO - 2017-02-07 08:35:03 --> Config Class Initialized
INFO - 2017-02-07 08:35:03 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:35:03 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:35:03 --> Utf8 Class Initialized
INFO - 2017-02-07 08:35:03 --> URI Class Initialized
INFO - 2017-02-07 08:35:03 --> Router Class Initialized
INFO - 2017-02-07 08:35:03 --> Output Class Initialized
INFO - 2017-02-07 08:35:03 --> Security Class Initialized
DEBUG - 2017-02-07 08:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:35:03 --> Input Class Initialized
INFO - 2017-02-07 08:35:03 --> Language Class Initialized
INFO - 2017-02-07 08:35:03 --> Loader Class Initialized
INFO - 2017-02-07 08:35:03 --> Helper loaded: url_helper
INFO - 2017-02-07 08:35:03 --> Helper loaded: language_helper
INFO - 2017-02-07 08:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:35:03 --> Controller Class Initialized
INFO - 2017-02-07 08:35:03 --> Database Driver Class Initialized
INFO - 2017-02-07 08:35:03 --> Model Class Initialized
INFO - 2017-02-07 08:35:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:35:03 --> Helper loaded: form_helper
INFO - 2017-02-07 08:35:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:35:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:35:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:35:03 --> Final output sent to browser
DEBUG - 2017-02-07 08:35:03 --> Total execution time: 0.1125
INFO - 2017-02-07 08:36:23 --> Config Class Initialized
INFO - 2017-02-07 08:36:23 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:36:23 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:36:23 --> Utf8 Class Initialized
INFO - 2017-02-07 08:36:23 --> URI Class Initialized
INFO - 2017-02-07 08:36:23 --> Router Class Initialized
INFO - 2017-02-07 08:36:23 --> Output Class Initialized
INFO - 2017-02-07 08:36:23 --> Security Class Initialized
DEBUG - 2017-02-07 08:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:36:23 --> Input Class Initialized
INFO - 2017-02-07 08:36:23 --> Language Class Initialized
INFO - 2017-02-07 08:36:23 --> Loader Class Initialized
INFO - 2017-02-07 08:36:23 --> Helper loaded: url_helper
INFO - 2017-02-07 08:36:23 --> Helper loaded: language_helper
INFO - 2017-02-07 08:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:36:23 --> Controller Class Initialized
INFO - 2017-02-07 08:36:23 --> Database Driver Class Initialized
INFO - 2017-02-07 08:36:23 --> Model Class Initialized
INFO - 2017-02-07 08:36:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:36:23 --> Helper loaded: form_helper
INFO - 2017-02-07 08:36:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:36:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:36:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:36:24 --> Final output sent to browser
DEBUG - 2017-02-07 08:36:24 --> Total execution time: 0.2188
INFO - 2017-02-07 08:36:58 --> Config Class Initialized
INFO - 2017-02-07 08:36:58 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:36:58 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:36:58 --> Utf8 Class Initialized
INFO - 2017-02-07 08:36:58 --> URI Class Initialized
INFO - 2017-02-07 08:36:58 --> Router Class Initialized
INFO - 2017-02-07 08:36:58 --> Output Class Initialized
INFO - 2017-02-07 08:36:58 --> Security Class Initialized
DEBUG - 2017-02-07 08:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:36:58 --> Input Class Initialized
INFO - 2017-02-07 08:36:58 --> Language Class Initialized
INFO - 2017-02-07 08:36:58 --> Loader Class Initialized
INFO - 2017-02-07 08:36:58 --> Helper loaded: url_helper
INFO - 2017-02-07 08:36:58 --> Helper loaded: language_helper
INFO - 2017-02-07 08:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:36:58 --> Controller Class Initialized
INFO - 2017-02-07 08:36:58 --> Database Driver Class Initialized
INFO - 2017-02-07 08:36:58 --> Model Class Initialized
INFO - 2017-02-07 08:36:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:36:58 --> Helper loaded: form_helper
INFO - 2017-02-07 08:36:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:36:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:36:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:36:58 --> Final output sent to browser
DEBUG - 2017-02-07 08:36:58 --> Total execution time: 0.1735
INFO - 2017-02-07 08:37:38 --> Config Class Initialized
INFO - 2017-02-07 08:37:38 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:37:38 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:37:38 --> Utf8 Class Initialized
INFO - 2017-02-07 08:37:38 --> URI Class Initialized
INFO - 2017-02-07 08:37:38 --> Router Class Initialized
INFO - 2017-02-07 08:37:38 --> Output Class Initialized
INFO - 2017-02-07 08:37:38 --> Security Class Initialized
DEBUG - 2017-02-07 08:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:37:38 --> Input Class Initialized
INFO - 2017-02-07 08:37:38 --> Language Class Initialized
INFO - 2017-02-07 08:37:38 --> Loader Class Initialized
INFO - 2017-02-07 08:37:38 --> Helper loaded: url_helper
INFO - 2017-02-07 08:37:38 --> Helper loaded: language_helper
INFO - 2017-02-07 08:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:37:38 --> Controller Class Initialized
INFO - 2017-02-07 08:37:38 --> Database Driver Class Initialized
INFO - 2017-02-07 08:37:38 --> Model Class Initialized
INFO - 2017-02-07 08:37:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:37:38 --> Helper loaded: form_helper
INFO - 2017-02-07 08:37:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:37:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:37:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:37:38 --> Final output sent to browser
DEBUG - 2017-02-07 08:37:38 --> Total execution time: 0.2021
INFO - 2017-02-07 08:38:02 --> Config Class Initialized
INFO - 2017-02-07 08:38:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:38:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:38:02 --> Utf8 Class Initialized
INFO - 2017-02-07 08:38:02 --> URI Class Initialized
INFO - 2017-02-07 08:38:02 --> Router Class Initialized
INFO - 2017-02-07 08:38:02 --> Output Class Initialized
INFO - 2017-02-07 08:38:02 --> Security Class Initialized
DEBUG - 2017-02-07 08:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:38:02 --> Input Class Initialized
INFO - 2017-02-07 08:38:02 --> Language Class Initialized
INFO - 2017-02-07 08:38:02 --> Loader Class Initialized
INFO - 2017-02-07 08:38:02 --> Helper loaded: url_helper
INFO - 2017-02-07 08:38:02 --> Helper loaded: language_helper
INFO - 2017-02-07 08:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:38:02 --> Controller Class Initialized
INFO - 2017-02-07 08:38:02 --> Database Driver Class Initialized
INFO - 2017-02-07 08:38:02 --> Model Class Initialized
INFO - 2017-02-07 08:38:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:38:02 --> Helper loaded: form_helper
INFO - 2017-02-07 08:38:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:38:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:38:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:38:02 --> Final output sent to browser
DEBUG - 2017-02-07 08:38:02 --> Total execution time: 0.1366
INFO - 2017-02-07 08:38:11 --> Config Class Initialized
INFO - 2017-02-07 08:38:11 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:38:11 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:38:11 --> Utf8 Class Initialized
INFO - 2017-02-07 08:38:11 --> URI Class Initialized
INFO - 2017-02-07 08:38:11 --> Router Class Initialized
INFO - 2017-02-07 08:38:11 --> Output Class Initialized
INFO - 2017-02-07 08:38:11 --> Security Class Initialized
DEBUG - 2017-02-07 08:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:38:11 --> Input Class Initialized
INFO - 2017-02-07 08:38:11 --> Language Class Initialized
INFO - 2017-02-07 08:38:11 --> Loader Class Initialized
INFO - 2017-02-07 08:38:11 --> Helper loaded: url_helper
INFO - 2017-02-07 08:38:11 --> Helper loaded: language_helper
INFO - 2017-02-07 08:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:38:11 --> Controller Class Initialized
INFO - 2017-02-07 08:38:11 --> Database Driver Class Initialized
INFO - 2017-02-07 08:38:11 --> Model Class Initialized
INFO - 2017-02-07 08:38:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:38:11 --> Helper loaded: form_helper
INFO - 2017-02-07 08:38:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:38:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:38:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:38:11 --> Final output sent to browser
DEBUG - 2017-02-07 08:38:11 --> Total execution time: 0.1806
INFO - 2017-02-07 08:42:54 --> Config Class Initialized
INFO - 2017-02-07 08:42:54 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:42:54 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:42:54 --> Utf8 Class Initialized
INFO - 2017-02-07 08:42:54 --> URI Class Initialized
INFO - 2017-02-07 08:42:54 --> Router Class Initialized
INFO - 2017-02-07 08:42:54 --> Output Class Initialized
INFO - 2017-02-07 08:42:54 --> Security Class Initialized
DEBUG - 2017-02-07 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:42:54 --> Input Class Initialized
INFO - 2017-02-07 08:42:54 --> Language Class Initialized
INFO - 2017-02-07 08:42:54 --> Loader Class Initialized
INFO - 2017-02-07 08:42:54 --> Helper loaded: url_helper
INFO - 2017-02-07 08:42:54 --> Helper loaded: language_helper
INFO - 2017-02-07 08:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:42:54 --> Controller Class Initialized
INFO - 2017-02-07 08:42:54 --> Database Driver Class Initialized
INFO - 2017-02-07 08:42:54 --> Model Class Initialized
INFO - 2017-02-07 08:42:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:42:54 --> Helper loaded: form_helper
INFO - 2017-02-07 08:42:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:42:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:42:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:42:54 --> Final output sent to browser
DEBUG - 2017-02-07 08:42:54 --> Total execution time: 0.2403
INFO - 2017-02-07 08:43:26 --> Config Class Initialized
INFO - 2017-02-07 08:43:26 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:43:26 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:43:26 --> Utf8 Class Initialized
INFO - 2017-02-07 08:43:26 --> URI Class Initialized
INFO - 2017-02-07 08:43:26 --> Router Class Initialized
INFO - 2017-02-07 08:43:26 --> Output Class Initialized
INFO - 2017-02-07 08:43:26 --> Security Class Initialized
DEBUG - 2017-02-07 08:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:43:26 --> Input Class Initialized
INFO - 2017-02-07 08:43:26 --> Language Class Initialized
INFO - 2017-02-07 08:43:26 --> Loader Class Initialized
INFO - 2017-02-07 08:43:26 --> Helper loaded: url_helper
INFO - 2017-02-07 08:43:26 --> Helper loaded: language_helper
INFO - 2017-02-07 08:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:43:26 --> Controller Class Initialized
INFO - 2017-02-07 08:43:26 --> Database Driver Class Initialized
INFO - 2017-02-07 08:43:26 --> Model Class Initialized
INFO - 2017-02-07 08:43:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:43:26 --> Helper loaded: form_helper
INFO - 2017-02-07 08:43:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:43:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:43:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:43:26 --> Final output sent to browser
DEBUG - 2017-02-07 08:43:26 --> Total execution time: 0.2132
INFO - 2017-02-07 08:43:56 --> Config Class Initialized
INFO - 2017-02-07 08:43:56 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:43:56 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:43:56 --> Utf8 Class Initialized
INFO - 2017-02-07 08:43:56 --> URI Class Initialized
INFO - 2017-02-07 08:43:56 --> Router Class Initialized
INFO - 2017-02-07 08:43:56 --> Output Class Initialized
INFO - 2017-02-07 08:43:56 --> Security Class Initialized
DEBUG - 2017-02-07 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:43:56 --> Input Class Initialized
INFO - 2017-02-07 08:43:56 --> Language Class Initialized
INFO - 2017-02-07 08:43:56 --> Loader Class Initialized
INFO - 2017-02-07 08:43:56 --> Helper loaded: url_helper
INFO - 2017-02-07 08:43:56 --> Helper loaded: language_helper
INFO - 2017-02-07 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:43:56 --> Controller Class Initialized
INFO - 2017-02-07 08:43:56 --> Database Driver Class Initialized
INFO - 2017-02-07 08:43:56 --> Model Class Initialized
INFO - 2017-02-07 08:43:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:43:56 --> Helper loaded: form_helper
INFO - 2017-02-07 08:43:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:43:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:43:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:43:56 --> Final output sent to browser
DEBUG - 2017-02-07 08:43:56 --> Total execution time: 0.1825
INFO - 2017-02-07 08:47:25 --> Config Class Initialized
INFO - 2017-02-07 08:47:25 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:47:25 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:47:25 --> Utf8 Class Initialized
INFO - 2017-02-07 08:47:25 --> URI Class Initialized
INFO - 2017-02-07 08:47:25 --> Router Class Initialized
INFO - 2017-02-07 08:47:25 --> Output Class Initialized
INFO - 2017-02-07 08:47:25 --> Security Class Initialized
DEBUG - 2017-02-07 08:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:47:25 --> Input Class Initialized
INFO - 2017-02-07 08:47:25 --> Language Class Initialized
INFO - 2017-02-07 08:47:25 --> Loader Class Initialized
INFO - 2017-02-07 08:47:25 --> Helper loaded: url_helper
INFO - 2017-02-07 08:47:25 --> Helper loaded: language_helper
INFO - 2017-02-07 08:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:47:25 --> Controller Class Initialized
INFO - 2017-02-07 08:47:25 --> Database Driver Class Initialized
INFO - 2017-02-07 08:47:25 --> Model Class Initialized
INFO - 2017-02-07 08:47:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:47:25 --> Helper loaded: form_helper
INFO - 2017-02-07 08:47:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:47:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:47:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:47:25 --> Final output sent to browser
DEBUG - 2017-02-07 08:47:25 --> Total execution time: 0.2341
INFO - 2017-02-07 08:54:49 --> Config Class Initialized
INFO - 2017-02-07 08:54:49 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:54:49 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:54:49 --> Utf8 Class Initialized
INFO - 2017-02-07 08:54:49 --> URI Class Initialized
INFO - 2017-02-07 08:54:49 --> Router Class Initialized
INFO - 2017-02-07 08:54:49 --> Output Class Initialized
INFO - 2017-02-07 08:54:49 --> Security Class Initialized
DEBUG - 2017-02-07 08:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:54:49 --> Input Class Initialized
INFO - 2017-02-07 08:54:49 --> Language Class Initialized
INFO - 2017-02-07 08:54:49 --> Loader Class Initialized
INFO - 2017-02-07 08:54:49 --> Helper loaded: url_helper
INFO - 2017-02-07 08:54:49 --> Helper loaded: language_helper
INFO - 2017-02-07 08:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:54:49 --> Controller Class Initialized
INFO - 2017-02-07 08:54:49 --> Database Driver Class Initialized
INFO - 2017-02-07 08:54:49 --> Model Class Initialized
INFO - 2017-02-07 08:54:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:54:49 --> Helper loaded: form_helper
INFO - 2017-02-07 08:54:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:54:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:54:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:54:49 --> Final output sent to browser
DEBUG - 2017-02-07 08:54:49 --> Total execution time: 0.1900
INFO - 2017-02-07 08:55:57 --> Config Class Initialized
INFO - 2017-02-07 08:55:57 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:55:57 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:55:57 --> Utf8 Class Initialized
INFO - 2017-02-07 08:55:57 --> URI Class Initialized
INFO - 2017-02-07 08:55:57 --> Router Class Initialized
INFO - 2017-02-07 08:55:57 --> Output Class Initialized
INFO - 2017-02-07 08:55:57 --> Security Class Initialized
DEBUG - 2017-02-07 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:55:57 --> Input Class Initialized
INFO - 2017-02-07 08:55:57 --> Language Class Initialized
INFO - 2017-02-07 08:55:57 --> Loader Class Initialized
INFO - 2017-02-07 08:55:57 --> Helper loaded: url_helper
INFO - 2017-02-07 08:55:57 --> Helper loaded: language_helper
INFO - 2017-02-07 08:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:55:57 --> Controller Class Initialized
INFO - 2017-02-07 08:55:57 --> Database Driver Class Initialized
INFO - 2017-02-07 08:55:57 --> Model Class Initialized
INFO - 2017-02-07 08:55:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:55:57 --> Helper loaded: form_helper
INFO - 2017-02-07 08:55:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:55:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:55:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:55:57 --> Final output sent to browser
DEBUG - 2017-02-07 08:55:57 --> Total execution time: 0.1676
INFO - 2017-02-07 08:56:27 --> Config Class Initialized
INFO - 2017-02-07 08:56:27 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:56:27 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:56:27 --> Utf8 Class Initialized
INFO - 2017-02-07 08:56:27 --> URI Class Initialized
INFO - 2017-02-07 08:56:27 --> Router Class Initialized
INFO - 2017-02-07 08:56:27 --> Output Class Initialized
INFO - 2017-02-07 08:56:27 --> Security Class Initialized
DEBUG - 2017-02-07 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:56:27 --> Input Class Initialized
INFO - 2017-02-07 08:56:27 --> Language Class Initialized
INFO - 2017-02-07 08:56:27 --> Loader Class Initialized
INFO - 2017-02-07 08:56:27 --> Helper loaded: url_helper
INFO - 2017-02-07 08:56:27 --> Helper loaded: language_helper
INFO - 2017-02-07 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:56:27 --> Controller Class Initialized
INFO - 2017-02-07 08:56:27 --> Database Driver Class Initialized
INFO - 2017-02-07 08:56:27 --> Model Class Initialized
INFO - 2017-02-07 08:56:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:56:27 --> Helper loaded: form_helper
INFO - 2017-02-07 08:56:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:56:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:56:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:56:27 --> Final output sent to browser
DEBUG - 2017-02-07 08:56:27 --> Total execution time: 0.2101
INFO - 2017-02-07 08:56:46 --> Config Class Initialized
INFO - 2017-02-07 08:56:46 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:56:46 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:56:46 --> Utf8 Class Initialized
INFO - 2017-02-07 08:56:46 --> URI Class Initialized
INFO - 2017-02-07 08:56:46 --> Router Class Initialized
INFO - 2017-02-07 08:56:46 --> Output Class Initialized
INFO - 2017-02-07 08:56:46 --> Security Class Initialized
DEBUG - 2017-02-07 08:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:56:46 --> Input Class Initialized
INFO - 2017-02-07 08:56:46 --> Language Class Initialized
INFO - 2017-02-07 08:56:46 --> Loader Class Initialized
INFO - 2017-02-07 08:56:46 --> Helper loaded: url_helper
INFO - 2017-02-07 08:56:46 --> Helper loaded: language_helper
INFO - 2017-02-07 08:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:56:46 --> Controller Class Initialized
INFO - 2017-02-07 08:56:46 --> Database Driver Class Initialized
INFO - 2017-02-07 08:56:46 --> Model Class Initialized
INFO - 2017-02-07 08:56:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:56:46 --> Helper loaded: form_helper
INFO - 2017-02-07 08:56:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:56:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:56:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:56:46 --> Final output sent to browser
DEBUG - 2017-02-07 08:56:46 --> Total execution time: 0.2032
INFO - 2017-02-07 08:57:11 --> Config Class Initialized
INFO - 2017-02-07 08:57:11 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:57:11 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:57:11 --> Utf8 Class Initialized
INFO - 2017-02-07 08:57:11 --> URI Class Initialized
INFO - 2017-02-07 08:57:11 --> Router Class Initialized
INFO - 2017-02-07 08:57:11 --> Output Class Initialized
INFO - 2017-02-07 08:57:11 --> Security Class Initialized
DEBUG - 2017-02-07 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:57:11 --> Input Class Initialized
INFO - 2017-02-07 08:57:11 --> Language Class Initialized
INFO - 2017-02-07 08:57:11 --> Loader Class Initialized
INFO - 2017-02-07 08:57:11 --> Helper loaded: url_helper
INFO - 2017-02-07 08:57:11 --> Helper loaded: language_helper
INFO - 2017-02-07 08:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:57:11 --> Controller Class Initialized
INFO - 2017-02-07 08:57:11 --> Database Driver Class Initialized
INFO - 2017-02-07 08:57:11 --> Model Class Initialized
INFO - 2017-02-07 08:57:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:57:11 --> Helper loaded: form_helper
INFO - 2017-02-07 08:57:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:57:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:57:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:57:11 --> Final output sent to browser
DEBUG - 2017-02-07 08:57:11 --> Total execution time: 0.1934
INFO - 2017-02-07 08:57:47 --> Config Class Initialized
INFO - 2017-02-07 08:57:47 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:57:47 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:57:47 --> Utf8 Class Initialized
INFO - 2017-02-07 08:57:47 --> URI Class Initialized
INFO - 2017-02-07 08:57:47 --> Router Class Initialized
INFO - 2017-02-07 08:57:47 --> Output Class Initialized
INFO - 2017-02-07 08:57:47 --> Security Class Initialized
DEBUG - 2017-02-07 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:57:47 --> Input Class Initialized
INFO - 2017-02-07 08:57:47 --> Language Class Initialized
INFO - 2017-02-07 08:57:47 --> Loader Class Initialized
INFO - 2017-02-07 08:57:47 --> Helper loaded: url_helper
INFO - 2017-02-07 08:57:47 --> Helper loaded: language_helper
INFO - 2017-02-07 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:57:47 --> Controller Class Initialized
INFO - 2017-02-07 08:57:47 --> Database Driver Class Initialized
INFO - 2017-02-07 08:57:47 --> Model Class Initialized
INFO - 2017-02-07 08:57:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:57:47 --> Helper loaded: form_helper
INFO - 2017-02-07 08:57:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:57:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:57:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:57:47 --> Final output sent to browser
DEBUG - 2017-02-07 08:57:47 --> Total execution time: 0.2036
INFO - 2017-02-07 08:58:51 --> Config Class Initialized
INFO - 2017-02-07 08:58:51 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:58:51 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:58:51 --> Utf8 Class Initialized
INFO - 2017-02-07 08:58:51 --> URI Class Initialized
INFO - 2017-02-07 08:58:51 --> Router Class Initialized
INFO - 2017-02-07 08:58:51 --> Output Class Initialized
INFO - 2017-02-07 08:58:51 --> Security Class Initialized
DEBUG - 2017-02-07 08:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:58:51 --> Input Class Initialized
INFO - 2017-02-07 08:58:51 --> Language Class Initialized
INFO - 2017-02-07 08:58:51 --> Loader Class Initialized
INFO - 2017-02-07 08:58:51 --> Helper loaded: url_helper
INFO - 2017-02-07 08:58:51 --> Helper loaded: language_helper
INFO - 2017-02-07 08:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:58:51 --> Controller Class Initialized
INFO - 2017-02-07 08:58:51 --> Database Driver Class Initialized
INFO - 2017-02-07 08:58:51 --> Model Class Initialized
INFO - 2017-02-07 08:58:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:58:51 --> Helper loaded: form_helper
INFO - 2017-02-07 08:58:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:58:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:58:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:58:51 --> Final output sent to browser
DEBUG - 2017-02-07 08:58:51 --> Total execution time: 0.2356
INFO - 2017-02-07 08:59:20 --> Config Class Initialized
INFO - 2017-02-07 08:59:20 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:59:20 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:59:20 --> Utf8 Class Initialized
INFO - 2017-02-07 08:59:20 --> URI Class Initialized
INFO - 2017-02-07 08:59:20 --> Router Class Initialized
INFO - 2017-02-07 08:59:20 --> Output Class Initialized
INFO - 2017-02-07 08:59:20 --> Security Class Initialized
DEBUG - 2017-02-07 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:59:20 --> Input Class Initialized
INFO - 2017-02-07 08:59:20 --> Language Class Initialized
INFO - 2017-02-07 08:59:20 --> Loader Class Initialized
INFO - 2017-02-07 08:59:20 --> Helper loaded: url_helper
INFO - 2017-02-07 08:59:20 --> Helper loaded: language_helper
INFO - 2017-02-07 08:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:59:20 --> Controller Class Initialized
INFO - 2017-02-07 08:59:20 --> Database Driver Class Initialized
INFO - 2017-02-07 08:59:20 --> Model Class Initialized
INFO - 2017-02-07 08:59:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 08:59:20 --> Helper loaded: form_helper
INFO - 2017-02-07 08:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 08:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 08:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 08:59:20 --> Final output sent to browser
DEBUG - 2017-02-07 08:59:20 --> Total execution time: 0.2110
INFO - 2017-02-07 09:02:18 --> Config Class Initialized
INFO - 2017-02-07 09:02:18 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:02:18 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:02:18 --> Utf8 Class Initialized
INFO - 2017-02-07 09:02:18 --> URI Class Initialized
INFO - 2017-02-07 09:02:18 --> Router Class Initialized
INFO - 2017-02-07 09:02:18 --> Output Class Initialized
INFO - 2017-02-07 09:02:18 --> Security Class Initialized
DEBUG - 2017-02-07 09:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:02:18 --> Input Class Initialized
INFO - 2017-02-07 09:02:18 --> Language Class Initialized
INFO - 2017-02-07 09:02:18 --> Loader Class Initialized
INFO - 2017-02-07 09:02:18 --> Helper loaded: url_helper
INFO - 2017-02-07 09:02:18 --> Helper loaded: language_helper
INFO - 2017-02-07 09:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:02:18 --> Controller Class Initialized
INFO - 2017-02-07 09:02:18 --> Database Driver Class Initialized
INFO - 2017-02-07 09:02:18 --> Model Class Initialized
INFO - 2017-02-07 09:02:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:02:18 --> Helper loaded: form_helper
INFO - 2017-02-07 09:02:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:02:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:02:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:02:18 --> Final output sent to browser
DEBUG - 2017-02-07 09:02:18 --> Total execution time: 0.1664
INFO - 2017-02-07 09:03:37 --> Config Class Initialized
INFO - 2017-02-07 09:03:37 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:03:37 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:03:37 --> Utf8 Class Initialized
INFO - 2017-02-07 09:03:37 --> URI Class Initialized
INFO - 2017-02-07 09:03:37 --> Router Class Initialized
INFO - 2017-02-07 09:03:37 --> Output Class Initialized
INFO - 2017-02-07 09:03:37 --> Security Class Initialized
DEBUG - 2017-02-07 09:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:03:37 --> Input Class Initialized
INFO - 2017-02-07 09:03:37 --> Language Class Initialized
INFO - 2017-02-07 09:03:37 --> Loader Class Initialized
INFO - 2017-02-07 09:03:37 --> Helper loaded: url_helper
INFO - 2017-02-07 09:03:37 --> Helper loaded: language_helper
INFO - 2017-02-07 09:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:03:37 --> Controller Class Initialized
INFO - 2017-02-07 09:03:37 --> Database Driver Class Initialized
INFO - 2017-02-07 09:03:37 --> Model Class Initialized
INFO - 2017-02-07 09:03:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:03:37 --> Helper loaded: form_helper
INFO - 2017-02-07 09:03:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:03:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:03:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:03:37 --> Final output sent to browser
DEBUG - 2017-02-07 09:03:37 --> Total execution time: 0.1674
INFO - 2017-02-07 09:05:14 --> Config Class Initialized
INFO - 2017-02-07 09:05:14 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:05:14 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:05:14 --> Utf8 Class Initialized
INFO - 2017-02-07 09:05:14 --> URI Class Initialized
INFO - 2017-02-07 09:05:14 --> Router Class Initialized
INFO - 2017-02-07 09:05:14 --> Output Class Initialized
INFO - 2017-02-07 09:05:14 --> Security Class Initialized
DEBUG - 2017-02-07 09:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:05:14 --> Input Class Initialized
INFO - 2017-02-07 09:05:14 --> Language Class Initialized
INFO - 2017-02-07 09:05:14 --> Loader Class Initialized
INFO - 2017-02-07 09:05:14 --> Helper loaded: url_helper
INFO - 2017-02-07 09:05:14 --> Helper loaded: language_helper
INFO - 2017-02-07 09:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:05:14 --> Controller Class Initialized
INFO - 2017-02-07 09:05:14 --> Database Driver Class Initialized
INFO - 2017-02-07 09:05:14 --> Model Class Initialized
INFO - 2017-02-07 09:05:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:05:14 --> Helper loaded: form_helper
INFO - 2017-02-07 09:05:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:05:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:05:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:05:14 --> Final output sent to browser
DEBUG - 2017-02-07 09:05:14 --> Total execution time: 0.2527
INFO - 2017-02-07 09:06:14 --> Config Class Initialized
INFO - 2017-02-07 09:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:06:14 --> Utf8 Class Initialized
INFO - 2017-02-07 09:06:14 --> URI Class Initialized
INFO - 2017-02-07 09:06:14 --> Router Class Initialized
INFO - 2017-02-07 09:06:14 --> Output Class Initialized
INFO - 2017-02-07 09:06:14 --> Security Class Initialized
DEBUG - 2017-02-07 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:06:14 --> Input Class Initialized
INFO - 2017-02-07 09:06:14 --> Language Class Initialized
INFO - 2017-02-07 09:06:14 --> Loader Class Initialized
INFO - 2017-02-07 09:06:14 --> Helper loaded: url_helper
INFO - 2017-02-07 09:06:14 --> Helper loaded: language_helper
INFO - 2017-02-07 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:06:14 --> Controller Class Initialized
INFO - 2017-02-07 09:06:14 --> Database Driver Class Initialized
INFO - 2017-02-07 09:06:14 --> Model Class Initialized
INFO - 2017-02-07 09:06:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:06:14 --> Helper loaded: form_helper
INFO - 2017-02-07 09:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:06:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:06:14 --> Final output sent to browser
DEBUG - 2017-02-07 09:06:14 --> Total execution time: 0.1974
INFO - 2017-02-07 09:06:26 --> Config Class Initialized
INFO - 2017-02-07 09:06:26 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:06:26 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:06:26 --> Utf8 Class Initialized
INFO - 2017-02-07 09:06:26 --> URI Class Initialized
INFO - 2017-02-07 09:06:26 --> Router Class Initialized
INFO - 2017-02-07 09:06:26 --> Output Class Initialized
INFO - 2017-02-07 09:06:26 --> Security Class Initialized
DEBUG - 2017-02-07 09:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:06:26 --> Input Class Initialized
INFO - 2017-02-07 09:06:26 --> Language Class Initialized
INFO - 2017-02-07 09:06:26 --> Loader Class Initialized
INFO - 2017-02-07 09:06:26 --> Helper loaded: url_helper
INFO - 2017-02-07 09:06:26 --> Helper loaded: language_helper
INFO - 2017-02-07 09:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:06:26 --> Controller Class Initialized
INFO - 2017-02-07 09:06:26 --> Database Driver Class Initialized
INFO - 2017-02-07 09:06:26 --> Model Class Initialized
INFO - 2017-02-07 09:06:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:06:26 --> Helper loaded: form_helper
INFO - 2017-02-07 09:06:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:06:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:06:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:06:26 --> Final output sent to browser
DEBUG - 2017-02-07 09:06:26 --> Total execution time: 0.2095
INFO - 2017-02-07 09:06:52 --> Config Class Initialized
INFO - 2017-02-07 09:06:52 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:06:52 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:06:52 --> Utf8 Class Initialized
INFO - 2017-02-07 09:06:52 --> URI Class Initialized
INFO - 2017-02-07 09:06:52 --> Router Class Initialized
INFO - 2017-02-07 09:06:52 --> Output Class Initialized
INFO - 2017-02-07 09:06:52 --> Security Class Initialized
DEBUG - 2017-02-07 09:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:06:52 --> Input Class Initialized
INFO - 2017-02-07 09:06:52 --> Language Class Initialized
INFO - 2017-02-07 09:06:52 --> Loader Class Initialized
INFO - 2017-02-07 09:06:52 --> Helper loaded: url_helper
INFO - 2017-02-07 09:06:52 --> Helper loaded: language_helper
INFO - 2017-02-07 09:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:06:52 --> Controller Class Initialized
INFO - 2017-02-07 09:06:52 --> Database Driver Class Initialized
INFO - 2017-02-07 09:06:52 --> Model Class Initialized
INFO - 2017-02-07 09:06:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:06:52 --> Helper loaded: form_helper
INFO - 2017-02-07 09:06:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:06:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:06:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:06:52 --> Final output sent to browser
DEBUG - 2017-02-07 09:06:52 --> Total execution time: 0.2714
INFO - 2017-02-07 09:07:03 --> Config Class Initialized
INFO - 2017-02-07 09:07:03 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:07:03 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:07:03 --> Utf8 Class Initialized
INFO - 2017-02-07 09:07:03 --> URI Class Initialized
INFO - 2017-02-07 09:07:03 --> Router Class Initialized
INFO - 2017-02-07 09:07:03 --> Output Class Initialized
INFO - 2017-02-07 09:07:03 --> Security Class Initialized
DEBUG - 2017-02-07 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:07:03 --> Input Class Initialized
INFO - 2017-02-07 09:07:03 --> Language Class Initialized
INFO - 2017-02-07 09:07:03 --> Loader Class Initialized
INFO - 2017-02-07 09:07:03 --> Helper loaded: url_helper
INFO - 2017-02-07 09:07:03 --> Helper loaded: language_helper
INFO - 2017-02-07 09:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:07:03 --> Controller Class Initialized
INFO - 2017-02-07 09:07:03 --> Database Driver Class Initialized
INFO - 2017-02-07 09:07:03 --> Model Class Initialized
INFO - 2017-02-07 09:07:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:07:03 --> Helper loaded: form_helper
INFO - 2017-02-07 09:07:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:07:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:07:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:07:03 --> Final output sent to browser
DEBUG - 2017-02-07 09:07:03 --> Total execution time: 0.2012
INFO - 2017-02-07 09:08:02 --> Config Class Initialized
INFO - 2017-02-07 09:08:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:08:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:08:02 --> Utf8 Class Initialized
INFO - 2017-02-07 09:08:02 --> URI Class Initialized
INFO - 2017-02-07 09:08:02 --> Router Class Initialized
INFO - 2017-02-07 09:08:02 --> Output Class Initialized
INFO - 2017-02-07 09:08:02 --> Security Class Initialized
DEBUG - 2017-02-07 09:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:08:02 --> Input Class Initialized
INFO - 2017-02-07 09:08:02 --> Language Class Initialized
INFO - 2017-02-07 09:08:02 --> Loader Class Initialized
INFO - 2017-02-07 09:08:02 --> Helper loaded: url_helper
INFO - 2017-02-07 09:08:02 --> Helper loaded: language_helper
INFO - 2017-02-07 09:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:08:02 --> Controller Class Initialized
INFO - 2017-02-07 09:08:02 --> Database Driver Class Initialized
INFO - 2017-02-07 09:08:02 --> Model Class Initialized
INFO - 2017-02-07 09:08:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:08:02 --> Helper loaded: form_helper
INFO - 2017-02-07 09:08:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:08:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:08:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:08:02 --> Final output sent to browser
DEBUG - 2017-02-07 09:08:02 --> Total execution time: 0.1834
INFO - 2017-02-07 09:09:15 --> Config Class Initialized
INFO - 2017-02-07 09:09:15 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:09:15 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:09:15 --> Utf8 Class Initialized
INFO - 2017-02-07 09:09:15 --> URI Class Initialized
INFO - 2017-02-07 09:09:15 --> Router Class Initialized
INFO - 2017-02-07 09:09:15 --> Output Class Initialized
INFO - 2017-02-07 09:09:15 --> Security Class Initialized
DEBUG - 2017-02-07 09:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:09:15 --> Input Class Initialized
INFO - 2017-02-07 09:09:15 --> Language Class Initialized
INFO - 2017-02-07 09:09:15 --> Loader Class Initialized
INFO - 2017-02-07 09:09:15 --> Helper loaded: url_helper
INFO - 2017-02-07 09:09:15 --> Helper loaded: language_helper
INFO - 2017-02-07 09:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:09:15 --> Controller Class Initialized
INFO - 2017-02-07 09:09:15 --> Database Driver Class Initialized
INFO - 2017-02-07 09:09:15 --> Model Class Initialized
INFO - 2017-02-07 09:09:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:09:15 --> Helper loaded: form_helper
INFO - 2017-02-07 09:09:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:09:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:09:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:09:15 --> Final output sent to browser
DEBUG - 2017-02-07 09:09:15 --> Total execution time: 0.2143
INFO - 2017-02-07 09:10:20 --> Config Class Initialized
INFO - 2017-02-07 09:10:20 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:10:20 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:10:20 --> Utf8 Class Initialized
INFO - 2017-02-07 09:10:20 --> URI Class Initialized
INFO - 2017-02-07 09:10:20 --> Router Class Initialized
INFO - 2017-02-07 09:10:20 --> Output Class Initialized
INFO - 2017-02-07 09:10:20 --> Security Class Initialized
DEBUG - 2017-02-07 09:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:10:20 --> Input Class Initialized
INFO - 2017-02-07 09:10:20 --> Language Class Initialized
INFO - 2017-02-07 09:10:20 --> Loader Class Initialized
INFO - 2017-02-07 09:10:20 --> Helper loaded: url_helper
INFO - 2017-02-07 09:10:20 --> Helper loaded: language_helper
INFO - 2017-02-07 09:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:10:20 --> Controller Class Initialized
INFO - 2017-02-07 09:10:20 --> Database Driver Class Initialized
INFO - 2017-02-07 09:10:20 --> Model Class Initialized
INFO - 2017-02-07 09:10:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:10:20 --> Helper loaded: form_helper
INFO - 2017-02-07 09:10:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:10:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:10:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:10:21 --> Final output sent to browser
DEBUG - 2017-02-07 09:10:21 --> Total execution time: 0.2870
INFO - 2017-02-07 09:11:01 --> Config Class Initialized
INFO - 2017-02-07 09:11:01 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:11:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:11:01 --> Utf8 Class Initialized
INFO - 2017-02-07 09:11:01 --> URI Class Initialized
INFO - 2017-02-07 09:11:01 --> Router Class Initialized
INFO - 2017-02-07 09:11:01 --> Output Class Initialized
INFO - 2017-02-07 09:11:01 --> Security Class Initialized
DEBUG - 2017-02-07 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:11:01 --> Input Class Initialized
INFO - 2017-02-07 09:11:01 --> Language Class Initialized
INFO - 2017-02-07 09:11:01 --> Loader Class Initialized
INFO - 2017-02-07 09:11:01 --> Helper loaded: url_helper
INFO - 2017-02-07 09:11:01 --> Helper loaded: language_helper
INFO - 2017-02-07 09:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:11:01 --> Controller Class Initialized
INFO - 2017-02-07 09:11:01 --> Database Driver Class Initialized
INFO - 2017-02-07 09:11:01 --> Model Class Initialized
INFO - 2017-02-07 09:11:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:11:01 --> Helper loaded: form_helper
INFO - 2017-02-07 09:11:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:11:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:11:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:11:01 --> Final output sent to browser
DEBUG - 2017-02-07 09:11:01 --> Total execution time: 0.1721
INFO - 2017-02-07 09:11:23 --> Config Class Initialized
INFO - 2017-02-07 09:11:23 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:11:23 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:11:23 --> Utf8 Class Initialized
INFO - 2017-02-07 09:11:23 --> URI Class Initialized
INFO - 2017-02-07 09:11:23 --> Router Class Initialized
INFO - 2017-02-07 09:11:23 --> Output Class Initialized
INFO - 2017-02-07 09:11:23 --> Security Class Initialized
DEBUG - 2017-02-07 09:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:11:23 --> Input Class Initialized
INFO - 2017-02-07 09:11:23 --> Language Class Initialized
INFO - 2017-02-07 09:11:23 --> Loader Class Initialized
INFO - 2017-02-07 09:11:23 --> Helper loaded: url_helper
INFO - 2017-02-07 09:11:23 --> Helper loaded: language_helper
INFO - 2017-02-07 09:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:11:23 --> Controller Class Initialized
INFO - 2017-02-07 09:11:23 --> Database Driver Class Initialized
INFO - 2017-02-07 09:11:23 --> Model Class Initialized
INFO - 2017-02-07 09:11:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:11:24 --> Helper loaded: form_helper
INFO - 2017-02-07 09:11:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:11:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:11:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:11:24 --> Final output sent to browser
DEBUG - 2017-02-07 09:11:24 --> Total execution time: 0.2138
INFO - 2017-02-07 09:12:04 --> Config Class Initialized
INFO - 2017-02-07 09:12:04 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:12:04 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:12:04 --> Utf8 Class Initialized
INFO - 2017-02-07 09:12:04 --> URI Class Initialized
INFO - 2017-02-07 09:12:04 --> Router Class Initialized
INFO - 2017-02-07 09:12:04 --> Output Class Initialized
INFO - 2017-02-07 09:12:04 --> Security Class Initialized
DEBUG - 2017-02-07 09:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:12:04 --> Input Class Initialized
INFO - 2017-02-07 09:12:04 --> Language Class Initialized
INFO - 2017-02-07 09:12:04 --> Loader Class Initialized
INFO - 2017-02-07 09:12:04 --> Helper loaded: url_helper
INFO - 2017-02-07 09:12:04 --> Helper loaded: language_helper
INFO - 2017-02-07 09:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:12:04 --> Controller Class Initialized
INFO - 2017-02-07 09:12:04 --> Database Driver Class Initialized
INFO - 2017-02-07 09:12:04 --> Model Class Initialized
INFO - 2017-02-07 09:12:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:12:04 --> Helper loaded: form_helper
INFO - 2017-02-07 09:12:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:12:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:12:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:12:04 --> Final output sent to browser
DEBUG - 2017-02-07 09:12:04 --> Total execution time: 0.2011
INFO - 2017-02-07 09:15:03 --> Config Class Initialized
INFO - 2017-02-07 09:15:03 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:15:03 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:15:03 --> Utf8 Class Initialized
INFO - 2017-02-07 09:15:03 --> URI Class Initialized
INFO - 2017-02-07 09:15:03 --> Router Class Initialized
INFO - 2017-02-07 09:15:03 --> Output Class Initialized
INFO - 2017-02-07 09:15:03 --> Security Class Initialized
DEBUG - 2017-02-07 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:15:03 --> Input Class Initialized
INFO - 2017-02-07 09:15:03 --> Language Class Initialized
INFO - 2017-02-07 09:15:04 --> Loader Class Initialized
INFO - 2017-02-07 09:15:04 --> Helper loaded: url_helper
INFO - 2017-02-07 09:15:04 --> Helper loaded: language_helper
INFO - 2017-02-07 09:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:15:04 --> Controller Class Initialized
INFO - 2017-02-07 09:15:04 --> Database Driver Class Initialized
INFO - 2017-02-07 09:15:04 --> Model Class Initialized
INFO - 2017-02-07 09:15:04 --> Model Class Initialized
INFO - 2017-02-07 09:15:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:15:04 --> Helper loaded: form_helper
INFO - 2017-02-07 09:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:15:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:15:04 --> Final output sent to browser
DEBUG - 2017-02-07 09:15:04 --> Total execution time: 0.2156
INFO - 2017-02-07 09:17:49 --> Config Class Initialized
INFO - 2017-02-07 09:17:49 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:17:49 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:17:49 --> Utf8 Class Initialized
INFO - 2017-02-07 09:17:49 --> URI Class Initialized
INFO - 2017-02-07 09:17:49 --> Router Class Initialized
INFO - 2017-02-07 09:17:49 --> Output Class Initialized
INFO - 2017-02-07 09:17:49 --> Security Class Initialized
DEBUG - 2017-02-07 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:17:49 --> Input Class Initialized
INFO - 2017-02-07 09:17:49 --> Language Class Initialized
INFO - 2017-02-07 09:17:49 --> Loader Class Initialized
INFO - 2017-02-07 09:17:49 --> Helper loaded: url_helper
INFO - 2017-02-07 09:17:49 --> Helper loaded: language_helper
INFO - 2017-02-07 09:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:17:49 --> Controller Class Initialized
INFO - 2017-02-07 09:17:49 --> Database Driver Class Initialized
INFO - 2017-02-07 09:17:49 --> Model Class Initialized
INFO - 2017-02-07 09:17:49 --> Model Class Initialized
INFO - 2017-02-07 09:17:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:17:49 --> Helper loaded: form_helper
INFO - 2017-02-07 09:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:17:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:17:49 --> Final output sent to browser
DEBUG - 2017-02-07 09:17:49 --> Total execution time: 0.1725
INFO - 2017-02-07 09:18:25 --> Config Class Initialized
INFO - 2017-02-07 09:18:25 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:18:25 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:18:25 --> Utf8 Class Initialized
INFO - 2017-02-07 09:18:25 --> URI Class Initialized
INFO - 2017-02-07 09:18:25 --> Router Class Initialized
INFO - 2017-02-07 09:18:25 --> Output Class Initialized
INFO - 2017-02-07 09:18:25 --> Security Class Initialized
DEBUG - 2017-02-07 09:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:18:25 --> Input Class Initialized
INFO - 2017-02-07 09:18:25 --> Language Class Initialized
INFO - 2017-02-07 09:18:25 --> Loader Class Initialized
INFO - 2017-02-07 09:18:25 --> Helper loaded: url_helper
INFO - 2017-02-07 09:18:25 --> Helper loaded: language_helper
INFO - 2017-02-07 09:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:18:25 --> Controller Class Initialized
INFO - 2017-02-07 09:18:25 --> Database Driver Class Initialized
INFO - 2017-02-07 09:18:25 --> Model Class Initialized
INFO - 2017-02-07 09:18:25 --> Model Class Initialized
INFO - 2017-02-07 09:18:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:18:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:18:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-07 09:18:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:18:25 --> Final output sent to browser
DEBUG - 2017-02-07 09:18:25 --> Total execution time: 0.0967
INFO - 2017-02-07 09:18:27 --> Config Class Initialized
INFO - 2017-02-07 09:18:27 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:18:27 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:18:27 --> Utf8 Class Initialized
INFO - 2017-02-07 09:18:27 --> URI Class Initialized
INFO - 2017-02-07 09:18:27 --> Router Class Initialized
INFO - 2017-02-07 09:18:27 --> Output Class Initialized
INFO - 2017-02-07 09:18:27 --> Security Class Initialized
DEBUG - 2017-02-07 09:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:18:27 --> Input Class Initialized
INFO - 2017-02-07 09:18:27 --> Language Class Initialized
INFO - 2017-02-07 09:18:27 --> Loader Class Initialized
INFO - 2017-02-07 09:18:27 --> Helper loaded: url_helper
INFO - 2017-02-07 09:18:27 --> Helper loaded: language_helper
INFO - 2017-02-07 09:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:18:27 --> Controller Class Initialized
INFO - 2017-02-07 09:18:27 --> Database Driver Class Initialized
INFO - 2017-02-07 09:18:27 --> Model Class Initialized
INFO - 2017-02-07 09:18:27 --> Model Class Initialized
INFO - 2017-02-07 09:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-07 09:18:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:18:27 --> Final output sent to browser
DEBUG - 2017-02-07 09:18:27 --> Total execution time: 0.1495
INFO - 2017-02-07 09:18:32 --> Config Class Initialized
INFO - 2017-02-07 09:18:32 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:18:32 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:18:32 --> Utf8 Class Initialized
INFO - 2017-02-07 09:18:32 --> URI Class Initialized
INFO - 2017-02-07 09:18:32 --> Router Class Initialized
INFO - 2017-02-07 09:18:32 --> Output Class Initialized
INFO - 2017-02-07 09:18:32 --> Security Class Initialized
DEBUG - 2017-02-07 09:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:18:32 --> Input Class Initialized
INFO - 2017-02-07 09:18:32 --> Language Class Initialized
INFO - 2017-02-07 09:18:32 --> Loader Class Initialized
INFO - 2017-02-07 09:18:32 --> Helper loaded: url_helper
INFO - 2017-02-07 09:18:32 --> Helper loaded: language_helper
INFO - 2017-02-07 09:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:18:32 --> Controller Class Initialized
INFO - 2017-02-07 09:18:32 --> Database Driver Class Initialized
INFO - 2017-02-07 09:18:33 --> Model Class Initialized
INFO - 2017-02-07 09:18:33 --> Model Class Initialized
INFO - 2017-02-07 09:18:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:18:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:18:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-07 09:18:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:18:33 --> Final output sent to browser
DEBUG - 2017-02-07 09:18:33 --> Total execution time: 0.1230
INFO - 2017-02-07 09:19:16 --> Config Class Initialized
INFO - 2017-02-07 09:19:16 --> Hooks Class Initialized
DEBUG - 2017-02-07 09:19:16 --> UTF-8 Support Enabled
INFO - 2017-02-07 09:19:16 --> Utf8 Class Initialized
INFO - 2017-02-07 09:19:16 --> URI Class Initialized
INFO - 2017-02-07 09:19:16 --> Router Class Initialized
INFO - 2017-02-07 09:19:16 --> Output Class Initialized
INFO - 2017-02-07 09:19:16 --> Security Class Initialized
DEBUG - 2017-02-07 09:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 09:19:16 --> Input Class Initialized
INFO - 2017-02-07 09:19:16 --> Language Class Initialized
INFO - 2017-02-07 09:19:16 --> Loader Class Initialized
INFO - 2017-02-07 09:19:16 --> Helper loaded: url_helper
INFO - 2017-02-07 09:19:16 --> Helper loaded: language_helper
INFO - 2017-02-07 09:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 09:19:16 --> Controller Class Initialized
INFO - 2017-02-07 09:19:16 --> Database Driver Class Initialized
INFO - 2017-02-07 09:19:16 --> Model Class Initialized
INFO - 2017-02-07 09:19:16 --> Model Class Initialized
INFO - 2017-02-07 09:19:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 09:19:16 --> Helper loaded: form_helper
INFO - 2017-02-07 09:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 09:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 09:19:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 09:19:16 --> Final output sent to browser
DEBUG - 2017-02-07 09:19:16 --> Total execution time: 0.2545
INFO - 2017-02-07 15:12:58 --> Config Class Initialized
INFO - 2017-02-07 15:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:12:58 --> Utf8 Class Initialized
INFO - 2017-02-07 15:12:58 --> URI Class Initialized
INFO - 2017-02-07 15:12:58 --> Router Class Initialized
INFO - 2017-02-07 15:12:58 --> Output Class Initialized
INFO - 2017-02-07 15:12:58 --> Security Class Initialized
DEBUG - 2017-02-07 15:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:12:58 --> Input Class Initialized
INFO - 2017-02-07 15:12:58 --> Language Class Initialized
INFO - 2017-02-07 15:12:58 --> Loader Class Initialized
INFO - 2017-02-07 15:12:58 --> Helper loaded: url_helper
INFO - 2017-02-07 15:12:58 --> Helper loaded: language_helper
INFO - 2017-02-07 15:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:12:58 --> Controller Class Initialized
INFO - 2017-02-07 15:12:59 --> Database Driver Class Initialized
INFO - 2017-02-07 15:12:59 --> Model Class Initialized
INFO - 2017-02-07 15:12:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:12:59 --> Config Class Initialized
INFO - 2017-02-07 15:12:59 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:12:59 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:12:59 --> Utf8 Class Initialized
INFO - 2017-02-07 15:12:59 --> URI Class Initialized
INFO - 2017-02-07 15:12:59 --> Router Class Initialized
INFO - 2017-02-07 15:12:59 --> Output Class Initialized
INFO - 2017-02-07 15:12:59 --> Security Class Initialized
DEBUG - 2017-02-07 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:12:59 --> Input Class Initialized
INFO - 2017-02-07 15:12:59 --> Language Class Initialized
INFO - 2017-02-07 15:12:59 --> Loader Class Initialized
INFO - 2017-02-07 15:12:59 --> Helper loaded: url_helper
INFO - 2017-02-07 15:12:59 --> Helper loaded: language_helper
INFO - 2017-02-07 15:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:12:59 --> Controller Class Initialized
INFO - 2017-02-07 15:12:59 --> Database Driver Class Initialized
INFO - 2017-02-07 15:12:59 --> Model Class Initialized
INFO - 2017-02-07 15:12:59 --> Model Class Initialized
INFO - 2017-02-07 15:12:59 --> Model Class Initialized
INFO - 2017-02-07 15:12:59 --> Model Class Initialized
INFO - 2017-02-07 15:12:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:12:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:12:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-07 15:12:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:12:59 --> Final output sent to browser
DEBUG - 2017-02-07 15:12:59 --> Total execution time: 0.1763
INFO - 2017-02-07 15:13:02 --> Config Class Initialized
INFO - 2017-02-07 15:13:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:13:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:13:02 --> Utf8 Class Initialized
INFO - 2017-02-07 15:13:02 --> URI Class Initialized
INFO - 2017-02-07 15:13:02 --> Router Class Initialized
INFO - 2017-02-07 15:13:02 --> Output Class Initialized
INFO - 2017-02-07 15:13:02 --> Security Class Initialized
DEBUG - 2017-02-07 15:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:13:02 --> Input Class Initialized
INFO - 2017-02-07 15:13:02 --> Language Class Initialized
INFO - 2017-02-07 15:13:02 --> Loader Class Initialized
INFO - 2017-02-07 15:13:02 --> Helper loaded: url_helper
INFO - 2017-02-07 15:13:02 --> Helper loaded: language_helper
INFO - 2017-02-07 15:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:13:02 --> Controller Class Initialized
INFO - 2017-02-07 15:13:02 --> Database Driver Class Initialized
INFO - 2017-02-07 15:13:02 --> Model Class Initialized
INFO - 2017-02-07 15:13:02 --> Model Class Initialized
INFO - 2017-02-07 15:13:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:13:02 --> Helper loaded: form_helper
INFO - 2017-02-07 15:13:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:13:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:13:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:13:02 --> Final output sent to browser
DEBUG - 2017-02-07 15:13:02 --> Total execution time: 0.2278
INFO - 2017-02-07 15:13:05 --> Config Class Initialized
INFO - 2017-02-07 15:13:05 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:13:05 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:13:05 --> Utf8 Class Initialized
INFO - 2017-02-07 15:13:05 --> URI Class Initialized
INFO - 2017-02-07 15:13:05 --> Router Class Initialized
INFO - 2017-02-07 15:13:05 --> Output Class Initialized
INFO - 2017-02-07 15:13:05 --> Security Class Initialized
DEBUG - 2017-02-07 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:13:05 --> Input Class Initialized
INFO - 2017-02-07 15:13:05 --> Language Class Initialized
INFO - 2017-02-07 15:13:05 --> Loader Class Initialized
INFO - 2017-02-07 15:13:05 --> Helper loaded: url_helper
INFO - 2017-02-07 15:13:05 --> Helper loaded: language_helper
INFO - 2017-02-07 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:13:05 --> Controller Class Initialized
INFO - 2017-02-07 15:13:05 --> Database Driver Class Initialized
INFO - 2017-02-07 15:13:05 --> Model Class Initialized
INFO - 2017-02-07 15:13:05 --> Model Class Initialized
INFO - 2017-02-07 15:13:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:13:05 --> Model Class Initialized
INFO - 2017-02-07 15:13:05 --> Helper loaded: form_helper
INFO - 2017-02-07 15:13:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:13:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:13:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:13:05 --> Final output sent to browser
DEBUG - 2017-02-07 15:13:05 --> Total execution time: 0.1918
INFO - 2017-02-07 15:14:40 --> Config Class Initialized
INFO - 2017-02-07 15:14:40 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:14:40 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:14:40 --> Utf8 Class Initialized
INFO - 2017-02-07 15:14:40 --> URI Class Initialized
INFO - 2017-02-07 15:14:40 --> Router Class Initialized
INFO - 2017-02-07 15:14:40 --> Output Class Initialized
INFO - 2017-02-07 15:14:40 --> Security Class Initialized
DEBUG - 2017-02-07 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:14:40 --> Input Class Initialized
INFO - 2017-02-07 15:14:40 --> Language Class Initialized
INFO - 2017-02-07 15:14:40 --> Loader Class Initialized
INFO - 2017-02-07 15:14:40 --> Helper loaded: url_helper
INFO - 2017-02-07 15:14:40 --> Helper loaded: language_helper
INFO - 2017-02-07 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:14:40 --> Controller Class Initialized
INFO - 2017-02-07 15:14:40 --> Database Driver Class Initialized
INFO - 2017-02-07 15:14:41 --> Model Class Initialized
INFO - 2017-02-07 15:14:41 --> Model Class Initialized
INFO - 2017-02-07 15:14:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:14:41 --> Helper loaded: form_helper
INFO - 2017-02-07 15:14:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:14:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:14:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:14:41 --> Final output sent to browser
DEBUG - 2017-02-07 15:14:41 --> Total execution time: 0.1765
INFO - 2017-02-07 15:15:41 --> Config Class Initialized
INFO - 2017-02-07 15:15:41 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:15:41 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:15:41 --> Utf8 Class Initialized
INFO - 2017-02-07 15:15:41 --> URI Class Initialized
INFO - 2017-02-07 15:15:41 --> Router Class Initialized
INFO - 2017-02-07 15:15:41 --> Output Class Initialized
INFO - 2017-02-07 15:15:41 --> Security Class Initialized
DEBUG - 2017-02-07 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:15:41 --> Input Class Initialized
INFO - 2017-02-07 15:15:41 --> Language Class Initialized
INFO - 2017-02-07 15:15:41 --> Loader Class Initialized
INFO - 2017-02-07 15:15:41 --> Helper loaded: url_helper
INFO - 2017-02-07 15:15:41 --> Helper loaded: language_helper
INFO - 2017-02-07 15:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:15:41 --> Controller Class Initialized
INFO - 2017-02-07 15:15:41 --> Database Driver Class Initialized
INFO - 2017-02-07 15:15:41 --> Model Class Initialized
INFO - 2017-02-07 15:15:41 --> Model Class Initialized
INFO - 2017-02-07 15:15:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:15:41 --> Model Class Initialized
INFO - 2017-02-07 15:15:41 --> Helper loaded: form_helper
INFO - 2017-02-07 15:15:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:15:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:15:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:15:42 --> Final output sent to browser
DEBUG - 2017-02-07 15:15:42 --> Total execution time: 0.1825
INFO - 2017-02-07 15:15:46 --> Config Class Initialized
INFO - 2017-02-07 15:15:46 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:15:46 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:15:46 --> Utf8 Class Initialized
INFO - 2017-02-07 15:15:46 --> URI Class Initialized
INFO - 2017-02-07 15:15:46 --> Router Class Initialized
INFO - 2017-02-07 15:15:46 --> Output Class Initialized
INFO - 2017-02-07 15:15:46 --> Security Class Initialized
DEBUG - 2017-02-07 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:15:46 --> Input Class Initialized
INFO - 2017-02-07 15:15:46 --> Language Class Initialized
INFO - 2017-02-07 15:15:46 --> Loader Class Initialized
INFO - 2017-02-07 15:15:46 --> Helper loaded: url_helper
INFO - 2017-02-07 15:15:46 --> Helper loaded: language_helper
INFO - 2017-02-07 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:15:46 --> Controller Class Initialized
INFO - 2017-02-07 15:15:46 --> Database Driver Class Initialized
INFO - 2017-02-07 15:15:46 --> Model Class Initialized
INFO - 2017-02-07 15:15:46 --> Model Class Initialized
INFO - 2017-02-07 15:15:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:15:46 --> Helper loaded: form_helper
INFO - 2017-02-07 15:15:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:15:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:15:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:15:47 --> Final output sent to browser
DEBUG - 2017-02-07 15:15:47 --> Total execution time: 0.1820
INFO - 2017-02-07 15:15:56 --> Config Class Initialized
INFO - 2017-02-07 15:15:56 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:15:56 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:15:56 --> Utf8 Class Initialized
INFO - 2017-02-07 15:15:56 --> URI Class Initialized
INFO - 2017-02-07 15:15:56 --> Router Class Initialized
INFO - 2017-02-07 15:15:56 --> Output Class Initialized
INFO - 2017-02-07 15:15:56 --> Security Class Initialized
DEBUG - 2017-02-07 15:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:15:56 --> Input Class Initialized
INFO - 2017-02-07 15:15:56 --> Language Class Initialized
INFO - 2017-02-07 15:15:56 --> Loader Class Initialized
INFO - 2017-02-07 15:15:56 --> Helper loaded: url_helper
INFO - 2017-02-07 15:15:56 --> Helper loaded: language_helper
INFO - 2017-02-07 15:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:15:56 --> Controller Class Initialized
INFO - 2017-02-07 15:15:56 --> Database Driver Class Initialized
INFO - 2017-02-07 15:15:56 --> Model Class Initialized
INFO - 2017-02-07 15:15:56 --> Model Class Initialized
INFO - 2017-02-07 15:15:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:15:56 --> Model Class Initialized
INFO - 2017-02-07 15:15:56 --> Helper loaded: form_helper
INFO - 2017-02-07 15:15:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:15:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:15:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:15:56 --> Final output sent to browser
DEBUG - 2017-02-07 15:15:56 --> Total execution time: 0.1677
INFO - 2017-02-07 15:16:08 --> Config Class Initialized
INFO - 2017-02-07 15:16:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:16:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:16:08 --> Utf8 Class Initialized
INFO - 2017-02-07 15:16:08 --> URI Class Initialized
INFO - 2017-02-07 15:16:08 --> Router Class Initialized
INFO - 2017-02-07 15:16:08 --> Output Class Initialized
INFO - 2017-02-07 15:16:08 --> Security Class Initialized
DEBUG - 2017-02-07 15:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:16:08 --> Input Class Initialized
INFO - 2017-02-07 15:16:08 --> Language Class Initialized
INFO - 2017-02-07 15:16:08 --> Loader Class Initialized
INFO - 2017-02-07 15:16:08 --> Helper loaded: url_helper
INFO - 2017-02-07 15:16:08 --> Helper loaded: language_helper
INFO - 2017-02-07 15:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:16:08 --> Controller Class Initialized
INFO - 2017-02-07 15:16:08 --> Database Driver Class Initialized
INFO - 2017-02-07 15:16:08 --> Model Class Initialized
INFO - 2017-02-07 15:16:08 --> Model Class Initialized
INFO - 2017-02-07 15:16:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:16:08 --> Helper loaded: form_helper
INFO - 2017-02-07 15:16:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:16:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:16:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:16:08 --> Final output sent to browser
DEBUG - 2017-02-07 15:16:08 --> Total execution time: 0.2118
INFO - 2017-02-07 15:16:21 --> Config Class Initialized
INFO - 2017-02-07 15:16:21 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:16:21 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:16:21 --> Utf8 Class Initialized
INFO - 2017-02-07 15:16:21 --> URI Class Initialized
INFO - 2017-02-07 15:16:21 --> Router Class Initialized
INFO - 2017-02-07 15:16:21 --> Output Class Initialized
INFO - 2017-02-07 15:16:21 --> Security Class Initialized
DEBUG - 2017-02-07 15:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:16:21 --> Input Class Initialized
INFO - 2017-02-07 15:16:21 --> Language Class Initialized
INFO - 2017-02-07 15:16:21 --> Loader Class Initialized
INFO - 2017-02-07 15:16:21 --> Helper loaded: url_helper
INFO - 2017-02-07 15:16:21 --> Helper loaded: language_helper
INFO - 2017-02-07 15:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:16:21 --> Controller Class Initialized
INFO - 2017-02-07 15:16:21 --> Database Driver Class Initialized
INFO - 2017-02-07 15:16:21 --> Model Class Initialized
INFO - 2017-02-07 15:16:21 --> Model Class Initialized
INFO - 2017-02-07 15:16:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:16:21 --> Model Class Initialized
INFO - 2017-02-07 15:16:21 --> Helper loaded: form_helper
INFO - 2017-02-07 15:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:16:21 --> Config Class Initialized
INFO - 2017-02-07 15:16:21 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:16:21 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:16:21 --> Utf8 Class Initialized
INFO - 2017-02-07 15:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:16:21 --> URI Class Initialized
INFO - 2017-02-07 15:16:21 --> Final output sent to browser
INFO - 2017-02-07 15:16:21 --> Router Class Initialized
DEBUG - 2017-02-07 15:16:21 --> Total execution time: 0.2464
INFO - 2017-02-07 15:16:21 --> Output Class Initialized
INFO - 2017-02-07 15:16:21 --> Security Class Initialized
DEBUG - 2017-02-07 15:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:16:21 --> Input Class Initialized
INFO - 2017-02-07 15:16:21 --> Language Class Initialized
INFO - 2017-02-07 15:16:21 --> Loader Class Initialized
INFO - 2017-02-07 15:16:21 --> Helper loaded: url_helper
INFO - 2017-02-07 15:16:21 --> Helper loaded: language_helper
INFO - 2017-02-07 15:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:16:21 --> Controller Class Initialized
INFO - 2017-02-07 15:16:21 --> Database Driver Class Initialized
INFO - 2017-02-07 15:16:21 --> Model Class Initialized
INFO - 2017-02-07 15:16:21 --> Model Class Initialized
INFO - 2017-02-07 15:16:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:16:21 --> Helper loaded: form_helper
INFO - 2017-02-07 15:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:16:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:16:21 --> Final output sent to browser
DEBUG - 2017-02-07 15:16:21 --> Total execution time: 0.3137
INFO - 2017-02-07 15:16:51 --> Config Class Initialized
INFO - 2017-02-07 15:16:51 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:16:51 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:16:51 --> Utf8 Class Initialized
INFO - 2017-02-07 15:16:51 --> URI Class Initialized
INFO - 2017-02-07 15:16:51 --> Router Class Initialized
INFO - 2017-02-07 15:16:51 --> Output Class Initialized
INFO - 2017-02-07 15:16:51 --> Security Class Initialized
DEBUG - 2017-02-07 15:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:16:51 --> Input Class Initialized
INFO - 2017-02-07 15:16:51 --> Language Class Initialized
INFO - 2017-02-07 15:16:51 --> Loader Class Initialized
INFO - 2017-02-07 15:16:51 --> Helper loaded: url_helper
INFO - 2017-02-07 15:16:51 --> Helper loaded: language_helper
INFO - 2017-02-07 15:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:16:51 --> Controller Class Initialized
INFO - 2017-02-07 15:16:51 --> Database Driver Class Initialized
INFO - 2017-02-07 15:16:51 --> Model Class Initialized
INFO - 2017-02-07 15:16:51 --> Model Class Initialized
INFO - 2017-02-07 15:16:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:16:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:16:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-07 15:16:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:16:51 --> Final output sent to browser
DEBUG - 2017-02-07 15:16:51 --> Total execution time: 0.1555
INFO - 2017-02-07 15:17:07 --> Config Class Initialized
INFO - 2017-02-07 15:17:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:17:07 --> Utf8 Class Initialized
INFO - 2017-02-07 15:17:07 --> URI Class Initialized
INFO - 2017-02-07 15:17:07 --> Router Class Initialized
INFO - 2017-02-07 15:17:07 --> Output Class Initialized
INFO - 2017-02-07 15:17:07 --> Security Class Initialized
DEBUG - 2017-02-07 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:17:07 --> Input Class Initialized
INFO - 2017-02-07 15:17:07 --> Language Class Initialized
INFO - 2017-02-07 15:17:07 --> Loader Class Initialized
INFO - 2017-02-07 15:17:07 --> Helper loaded: url_helper
INFO - 2017-02-07 15:17:07 --> Helper loaded: language_helper
INFO - 2017-02-07 15:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:17:07 --> Controller Class Initialized
INFO - 2017-02-07 15:17:07 --> Database Driver Class Initialized
INFO - 2017-02-07 15:17:07 --> Model Class Initialized
INFO - 2017-02-07 15:17:07 --> Model Class Initialized
INFO - 2017-02-07 15:17:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:17:07 --> Helper loaded: form_helper
INFO - 2017-02-07 15:17:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:17:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:17:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:17:07 --> Final output sent to browser
DEBUG - 2017-02-07 15:17:07 --> Total execution time: 0.1982
INFO - 2017-02-07 15:17:48 --> Config Class Initialized
INFO - 2017-02-07 15:17:48 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:17:48 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:17:48 --> Utf8 Class Initialized
INFO - 2017-02-07 15:17:48 --> URI Class Initialized
INFO - 2017-02-07 15:17:48 --> Router Class Initialized
INFO - 2017-02-07 15:17:48 --> Output Class Initialized
INFO - 2017-02-07 15:17:48 --> Security Class Initialized
DEBUG - 2017-02-07 15:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:17:48 --> Input Class Initialized
INFO - 2017-02-07 15:17:48 --> Language Class Initialized
INFO - 2017-02-07 15:17:48 --> Loader Class Initialized
INFO - 2017-02-07 15:17:48 --> Helper loaded: url_helper
INFO - 2017-02-07 15:17:48 --> Helper loaded: language_helper
INFO - 2017-02-07 15:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:17:48 --> Controller Class Initialized
INFO - 2017-02-07 15:17:48 --> Database Driver Class Initialized
INFO - 2017-02-07 15:17:48 --> Model Class Initialized
INFO - 2017-02-07 15:17:48 --> Model Class Initialized
INFO - 2017-02-07 15:17:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:17:48 --> Helper loaded: form_helper
INFO - 2017-02-07 15:17:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:17:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-07 15:17:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:17:48 --> Final output sent to browser
DEBUG - 2017-02-07 15:17:48 --> Total execution time: 0.2345
INFO - 2017-02-07 15:19:05 --> Config Class Initialized
INFO - 2017-02-07 15:19:05 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:19:05 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:19:05 --> Utf8 Class Initialized
INFO - 2017-02-07 15:19:05 --> URI Class Initialized
INFO - 2017-02-07 15:19:05 --> Router Class Initialized
INFO - 2017-02-07 15:19:05 --> Output Class Initialized
INFO - 2017-02-07 15:19:05 --> Security Class Initialized
DEBUG - 2017-02-07 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:19:05 --> Input Class Initialized
INFO - 2017-02-07 15:19:05 --> Language Class Initialized
INFO - 2017-02-07 15:19:05 --> Loader Class Initialized
INFO - 2017-02-07 15:19:05 --> Helper loaded: url_helper
INFO - 2017-02-07 15:19:05 --> Helper loaded: language_helper
INFO - 2017-02-07 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:19:05 --> Controller Class Initialized
INFO - 2017-02-07 15:19:05 --> Database Driver Class Initialized
INFO - 2017-02-07 15:19:05 --> Model Class Initialized
INFO - 2017-02-07 15:19:05 --> Model Class Initialized
INFO - 2017-02-07 15:19:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:19:05 --> Model Class Initialized
INFO - 2017-02-07 15:19:05 --> Helper loaded: form_helper
INFO - 2017-02-07 15:19:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:19:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:19:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:19:06 --> Final output sent to browser
DEBUG - 2017-02-07 15:19:06 --> Total execution time: 0.2013
INFO - 2017-02-07 15:20:02 --> Config Class Initialized
INFO - 2017-02-07 15:20:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:20:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:20:02 --> Utf8 Class Initialized
INFO - 2017-02-07 15:20:02 --> URI Class Initialized
INFO - 2017-02-07 15:20:02 --> Router Class Initialized
INFO - 2017-02-07 15:20:02 --> Output Class Initialized
INFO - 2017-02-07 15:20:02 --> Security Class Initialized
DEBUG - 2017-02-07 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:20:02 --> Input Class Initialized
INFO - 2017-02-07 15:20:02 --> Language Class Initialized
INFO - 2017-02-07 15:20:02 --> Loader Class Initialized
INFO - 2017-02-07 15:20:02 --> Helper loaded: url_helper
INFO - 2017-02-07 15:20:02 --> Helper loaded: language_helper
INFO - 2017-02-07 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:20:02 --> Controller Class Initialized
INFO - 2017-02-07 15:20:02 --> Database Driver Class Initialized
INFO - 2017-02-07 15:20:02 --> Model Class Initialized
INFO - 2017-02-07 15:20:02 --> Model Class Initialized
INFO - 2017-02-07 15:20:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:20:02 --> Model Class Initialized
INFO - 2017-02-07 15:20:02 --> Helper loaded: form_helper
INFO - 2017-02-07 15:20:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:20:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:20:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:20:02 --> Final output sent to browser
DEBUG - 2017-02-07 15:20:02 --> Total execution time: 0.2267
INFO - 2017-02-07 15:24:52 --> Config Class Initialized
INFO - 2017-02-07 15:24:52 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:24:52 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:24:52 --> Utf8 Class Initialized
INFO - 2017-02-07 15:24:52 --> URI Class Initialized
INFO - 2017-02-07 15:24:52 --> Router Class Initialized
INFO - 2017-02-07 15:24:52 --> Output Class Initialized
INFO - 2017-02-07 15:24:52 --> Security Class Initialized
DEBUG - 2017-02-07 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:24:52 --> Input Class Initialized
INFO - 2017-02-07 15:24:52 --> Language Class Initialized
INFO - 2017-02-07 15:24:52 --> Loader Class Initialized
INFO - 2017-02-07 15:24:52 --> Helper loaded: url_helper
INFO - 2017-02-07 15:24:52 --> Helper loaded: language_helper
INFO - 2017-02-07 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:24:52 --> Controller Class Initialized
INFO - 2017-02-07 15:24:52 --> Database Driver Class Initialized
INFO - 2017-02-07 15:24:53 --> Model Class Initialized
INFO - 2017-02-07 15:24:53 --> Model Class Initialized
INFO - 2017-02-07 15:24:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:24:53 --> Model Class Initialized
INFO - 2017-02-07 15:24:53 --> Helper loaded: form_helper
INFO - 2017-02-07 15:24:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:24:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:24:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:24:53 --> Final output sent to browser
DEBUG - 2017-02-07 15:24:53 --> Total execution time: 0.1787
INFO - 2017-02-07 15:25:30 --> Config Class Initialized
INFO - 2017-02-07 15:25:30 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:25:30 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:25:30 --> Utf8 Class Initialized
INFO - 2017-02-07 15:25:30 --> URI Class Initialized
INFO - 2017-02-07 15:25:30 --> Router Class Initialized
INFO - 2017-02-07 15:25:30 --> Output Class Initialized
INFO - 2017-02-07 15:25:30 --> Security Class Initialized
DEBUG - 2017-02-07 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:25:30 --> Input Class Initialized
INFO - 2017-02-07 15:25:30 --> Language Class Initialized
INFO - 2017-02-07 15:25:30 --> Loader Class Initialized
INFO - 2017-02-07 15:25:30 --> Helper loaded: url_helper
INFO - 2017-02-07 15:25:30 --> Helper loaded: language_helper
INFO - 2017-02-07 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:25:30 --> Controller Class Initialized
INFO - 2017-02-07 15:25:30 --> Database Driver Class Initialized
INFO - 2017-02-07 15:25:30 --> Model Class Initialized
INFO - 2017-02-07 15:25:30 --> Model Class Initialized
INFO - 2017-02-07 15:25:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:25:30 --> Model Class Initialized
INFO - 2017-02-07 15:25:30 --> Helper loaded: form_helper
INFO - 2017-02-07 15:25:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:25:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:25:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:25:30 --> Final output sent to browser
DEBUG - 2017-02-07 15:25:30 --> Total execution time: 0.2062
INFO - 2017-02-07 15:26:50 --> Config Class Initialized
INFO - 2017-02-07 15:26:50 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:26:50 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:26:50 --> Utf8 Class Initialized
INFO - 2017-02-07 15:26:50 --> URI Class Initialized
INFO - 2017-02-07 15:26:50 --> Router Class Initialized
INFO - 2017-02-07 15:26:50 --> Output Class Initialized
INFO - 2017-02-07 15:26:50 --> Security Class Initialized
DEBUG - 2017-02-07 15:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:26:50 --> Input Class Initialized
INFO - 2017-02-07 15:26:50 --> Language Class Initialized
INFO - 2017-02-07 15:26:50 --> Loader Class Initialized
INFO - 2017-02-07 15:26:50 --> Helper loaded: url_helper
INFO - 2017-02-07 15:26:50 --> Helper loaded: language_helper
INFO - 2017-02-07 15:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:26:50 --> Controller Class Initialized
INFO - 2017-02-07 15:26:50 --> Database Driver Class Initialized
INFO - 2017-02-07 15:26:50 --> Model Class Initialized
INFO - 2017-02-07 15:26:50 --> Model Class Initialized
INFO - 2017-02-07 15:26:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:26:50 --> Model Class Initialized
INFO - 2017-02-07 15:26:50 --> Helper loaded: form_helper
INFO - 2017-02-07 15:26:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:26:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:26:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:26:50 --> Final output sent to browser
DEBUG - 2017-02-07 15:26:50 --> Total execution time: 0.2022
INFO - 2017-02-07 15:28:35 --> Config Class Initialized
INFO - 2017-02-07 15:28:35 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:28:35 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:28:35 --> Utf8 Class Initialized
INFO - 2017-02-07 15:28:35 --> URI Class Initialized
INFO - 2017-02-07 15:28:35 --> Router Class Initialized
INFO - 2017-02-07 15:28:35 --> Output Class Initialized
INFO - 2017-02-07 15:28:35 --> Security Class Initialized
DEBUG - 2017-02-07 15:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:28:35 --> Input Class Initialized
INFO - 2017-02-07 15:28:35 --> Language Class Initialized
INFO - 2017-02-07 15:28:35 --> Loader Class Initialized
INFO - 2017-02-07 15:28:35 --> Helper loaded: url_helper
INFO - 2017-02-07 15:28:35 --> Helper loaded: language_helper
INFO - 2017-02-07 15:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:28:35 --> Controller Class Initialized
INFO - 2017-02-07 15:28:35 --> Database Driver Class Initialized
INFO - 2017-02-07 15:28:35 --> Model Class Initialized
INFO - 2017-02-07 15:28:35 --> Model Class Initialized
INFO - 2017-02-07 15:28:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-07 15:28:35 --> Model Class Initialized
INFO - 2017-02-07 15:28:35 --> Helper loaded: form_helper
INFO - 2017-02-07 15:28:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-07 15:28:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-07 15:28:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-07 15:28:35 --> Final output sent to browser
DEBUG - 2017-02-07 15:28:35 --> Total execution time: 0.1710
